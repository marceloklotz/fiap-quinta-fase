<!-- METADADOS: doenca: Acromegalia | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 23, DE 22 DE OUTUBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Acromegalia.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a acromegalia no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup>º</sup> 1002/2025 e o Relatório de Recomendação nº 1005/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Acromegalia.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral de acromegalia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da acromegalia.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 2, de 7 de janeiro de 2019, publicada no Diário Oficial da União (DOU) nº 9, de 14 de janeiro de 2019, seção 1, página 70.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Acromegalia | secao: FERNANDA DE NEGRI -->
1

---

<!-- METADADOS: doenca: Acromegalia | secao: **1. INTRODUÇÃO** -->
A acromegalia é uma doença crônica e insidiosa que, em cerca de 98% dos casos, é causada por adenomas hipofisários secretores de hormônio do crescimento (GH), conhecidos como somatotropinomas. Estes tumores são classificados de acordo com o tamanho: microadenomas (menos de 1 cm) ou macroadenomas (1 cm ou mais), sendo que mais de 70% dos tumores associados à acromegalia são macroadenomas<sup>1–3</sup> .  
Os somatotropinomas são tumores monoclonais que podem ocorrer de forma esporádica ou, mais raramente, de forma familiar<sup>4</sup> . Além disso, existem sete tipos histológicos diferentes<sup>5</sup> , os quais apresentam comportamentos biológicos heterogêneos. Essa diferença afeta a resposta aos diferentes tratamentos da doença, já que, por exemplo, há diferença na expressão dos receptores dopaminérgicos e somatostatinérgicos<sup>6,7</sup> .  
Em aproximadamente 2% dos casos, a acromegalia é causada por hipersecreção do hormônio liberador de GH (GHRH), no próprio hipotálamo ou de origem ectópica (por exemplo, carcinoide brônquico e tumor de ilhota pancreática). A secreção ectópica do GH é extremamente rara<sup>8</sup> .  
O excesso de GH estimula a hipersecreção do fator de crescimento semelhante à insulina tipo I (IGF-I) principalmente pelo fígado, mas também por diversas células do organismo. O aumento dos níveis de IGF-I é o responsável pela maioria dos sinais e sintomas clínicos associados à acromegalia<sup>1–3</sup> .  
A acromegalia pode ocorrer em qualquer idade, porém é mais comum entre os 30 e 50 anos. Em crianças e adolescentes, a doença ocorre antes do fechamento das placas de crescimento epifisárias, portanto, é chamada de gigantismo hipofisário. Cerca de 10% dos pacientes com acromegalia têm alta estatura, indicando que o início da doença ocorreu antes do fechamento da placa de crescimento epifisária<sup>9</sup> .  
A acromegalia e o gigantismo são incomuns, com a prevalência variando entre 2,8 e 13,7 casos por 100.000 habitantes, e uma incidência anual de 0,2 a 1,17 casos por 100.000 pessoas, considerando dados de diversas regiões geográficas do mundo<sup>10–</sup> 12. Dessa forma, apesar de não haver estudos abrangentes realizados no Brasil, por meio desses dados epidemiológicos, estimase uma prevalência de 5.768 a 27.398 pessoas acometidas e que cerca de 412 a 2.300 novos casos de acromegalia sejam diagnosticados anualmente no país. Estudo realizado em um único centro de referência regional em Londrina encontrou uma prevalência de 1,27 casos de acromegalia por 100.000 habitantes<sup>13</sup> .  
Não foram encontrados dados epidemiológicos brasileiros específicos para o gigantismo. Um estudo retrospectivo multicêntrico internacional abrangendo 208 casos de gigantismo hipofisário revelou uma predominância do sexo masculino (78%), sendo a causa genética conhecida em cerca de 50% dos casos de gigantismo<sup>14,15</sup> . A mutação germinativa no gene _AIP_ é a principal alteração genética e pacientes com esta mutação não respondem adequadamente aos ligantes do receptor da somatostatina de primeira geração<sup>16</sup> .  
Tanto o GH quanto o IGF-I possuem receptores em diversos órgãos e sistemas, o que torna a acromegalia uma doença sistêmica com diversas comorbidades, tais como: hipertensão arterial, diabete melito, apneia do sono, fraturas vertebrais e manifestações musculoesqueléticas, neoplasia colorretal e artropatia/osteoartropatia. Além disso, o paciente com acromegalia apresenta alterações fenotípicas como fácies acromegálica e crescimento de extremidades. Tanto as alterações fenotípicas quanto as comorbidades contribuem para a redução da qualidade de vida destes pacientes<sup>17–20</sup> .  
Pacientes mais jovens tendem a apresentar tumores mais agressivos e também possuem maior chance de desenvolver sinais e sintomas compressivos decorrentes do efeito de massa do tumor, como perda visual<sup>21</sup> . No caso do gigantismo, a principal  
2  
manifestação clínica é a alta estatura decorrente de crescimento exagerado, podendo a mesma estar associada a outros achados fenotípicos similares aos observados nos pacientes adultos com acromegalia e também a sinais e sintomas compressivos. Em mulheres adolescentes com adenomas hipofisários secretores de GH, também são relatados casos de amenorreia, com ou sem galactorreia e, em ambos os sexos, a doença pode se manifestar inicialmente pelo quadro de diabete melito em adolescentes<sup>14</sup> .  
Finalmente, fatores associados a um pior prognóstico em pacientes com acromegalia têm sido identificados, indicando maior atenção no cuidado de pacientes com essas características já que não costumam responder adequadamente aos medicamentos de primeira linha – ligantes do receptor da somatostatina de primeira geração<sup>22</sup> . Entre os fatores, destacam-se: idade (jovens); aspectos bioquímicos (níveis mais altos de GH e IGF-I); histológicos (adenomas esparsamente granulados; baixa expressão do receptor da somatostatina subtipo 2 – SST2); moleculares (mutação germinativa no gene _AIP_ ) e radiológicos (maior volume tumoral, invasão do seio cavernoso, hipersinal em T2 na ressonância magnética de sela túrcica)<sup>23–25</sup> .  
A acromegalia está associada à elevada mortalidade se não adequadamente controlada (níveis séricos de GH e IGF-I elevados)<sup>26–28</sup> . No entanto, com o tratamento adequado e o controle das comorbidades, a taxa de mortalidade é igual à da população geral. Além de um tratamento adequado, o diagnóstico precoce também desempenha um papel essencial na redução da elevada taxa de mortalidade associada à acromegalia<sup>26,29</sup> .  
Dessa forma, a identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para atendimento especializado multidisciplinar dão à Atenção Primária à Saúde um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Acromegalia | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
 E22.0 Acromegalia e gigantismo hipofisário

---

<!-- METADADOS: doenca: Acromegalia | secao: **3. DIAGNÓSTICO** -->
O diagnóstico de acromegalia é feito a partir da suspeita clínica, por comprovação de excesso hormonal em exames laboratoriais e por exames de imagem para determinação da causa de excesso de GH<sup>31–33</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **3.1      Diagnóstico clínico** -->
Por ser uma doença insidiosa, o atraso no diagnóstico em geral é de 7 a 10 anos. Os sintomas da acromegalia podem decorrer do próprio tumor hipofisário produtor de GH, como defeitos visuais, paralisia de nervos cranianos (por invasão de seio cavernoso) e cefaleia, ou resultar do excesso de GH e de IGF-I (somatomedina C)<sup>1,2</sup> .  
O excesso de GH pode se manifestar por sinais clínicos de crescimento excessivo (macrognatia, crescimento de pés e mãos, hipertrofia de tecidos moles, macroglossia), por complicações musculoesqueléticas (artralgias, síndrome do túnel do carpo, miopatia) e por complicações sistêmicas, como hipertensão arterial sistêmica (em até 30% dos pacientes) e ainda diabete melito, cardiopatia, hipertrofia de ventrículo esquerdo e apneia do sono<sup>34</sup> . Em pacientes jovens que ainda não tiveram o fechamento da cartilagem de crescimento, há registro de crescimento exagerado e gigantismo<sup>1,2,35</sup> . Em jovens e adolescentes com gigantismo, que apresentem tumores de crescimento rápido, agressivos ou invasivos, associados a elevados níveis de GH ao diagnóstico, deve-se considerar ampliar a investigação clínica para condições familiares ou genéticas, como Neoplasia Endócrina Múltipla tipo 1 (NEM-1), Adenomas Hipofisários Familiares Isolados (FIPA), Acrogigantismo Ligado ao X, que cursam frequentemente com resistência ao tratamento medicamentoso de primeira linha e requerem múltiplas intervenções terapêuticas<sup>36,37</sup> .  
3  
Além disso, a evidência atualmente disponível sugere o aumento da incidência de neoplasia, especialmente de cólon, porém tal associação permanece controversa<sup>19</sup> .  
Um grupo significativo de pacientes pode apresentar sintomas e sinais decorrentes da hiperprolactinemia, tais como alterações menstruais e galactorreia no sexo feminino, e impotência, sintomas de hipogonadismo e galactorreia no sexo masculino<sup>38</sup> , o que muitas vezes leva ao diagnóstico da doença. Doenças prostáticas também são mais comuns em homens com acromegalia<sup>39</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **3.2      Diagnóstico laboratorial** -->
A maioria dos pacientes com acromegalia apresenta níveis elevados de GH e IGF-I. A comprovação desse excesso hormonal é imprescindível para o diagnóstico e deve ser feita pela dosagem de níveis séricos basais de IGF-I e de GH, podendo ser realizada dosagem após sobrecarga de glicose<sup>31–33,40</sup> .  
A dosagem do nível sérico de IGF-I é o melhor teste inicial para o rastreamento diagnóstico, estando os níveis elevados na maioria dos pacientes com acromegalia. Destaca-se que, em pacientes com apresentação clínica sugestiva de acromegalia e com IGF-1 acima de 30% do limite superior da referência, a supressão do GH não é necessária<sup>41</sup> . Os valores de referência variam de acordo com a idade, índice de massa corporal (IMC) e com os métodos de dosagem utilizados. Os resultados, portanto, devem ser avaliados considerando essas variações, com os valores de referência sendo fornecidos pelo laboratório. Por tais razões, é importante que, durante o tratamento e a monitorização da doença, sejam utilizados os mesmos métodos de dosagem dos níveis séricos de GH e IGF-I<sup>1,31,34,40,42</sup> .  
A avaliação laboratorial se inicia com a dosagem de IGF-I, seguida, em alguns casos da dosagem de GH basal ou após supressão com glicose. A secreção de GH em indivíduos normais é pulsátil e estimulada por diversos fatores. Além disso, a concentração sérica de GH pode ser alterada por uso concomitante de alguns medicamentos (arginina, contraceptivos orais, esteroides)<sup>1</sup> , além de doenças, como diabete melito descompensada, doenças hepáticas e desnutrição<sup>34</sup> . Assim, a dosagem isolada de GH tem pouca utilidade diagnóstica, pois valores elevados são encontrados em indivíduos normais em resposta a estímulos fisiológicos ou em indivíduos com outras doenças que tenham ocasionado sua elevação<sup>1,34</sup> . Entretanto, um valor muito baixo de GH (menor que 0,4 ng/mL), utilizando método ultrassensível, exclui o diagnóstico de acromegalia, especialmente se estiver associado a nível sérico de IGF-I normal<sup>2,31,42</sup> .  
A dosagem de GH após sobrecarga de glicose é um teste laboratorial dinâmico que permite a demonstração da não supressão da secreção de GH. O teste é feito com dosagens de GH antes e 30, 60, 90 e 120 minutos após o paciente receber 75 g de glicose anidra por via oral. Em indivíduos saudáveis, as concentrações de GH caem para níveis inferiores a 0,4 ng/mL em pelo menos uma das dosagens, sendo esse o ponto de corte acima do qual é considerada a ausência de supressão fisiológica, sugerindo a secreção desregulada de GH<sup>33,43–45</sup> . Pacientes com diagnóstico de diabete melito não devem ser submetidos à sobrecarga de glicose. A alta concentração de IGF-I e nível de GH basal maior que 0,4 ng/mL na presença de hiperglicemia podem ser utilizados no diagnóstico laboratorial do paciente<sup>46</sup> .  
Ainda que não sejam obrigatórios, outros exames laboratoriais importantes são as dosagens de glicose de jejum e de hemoglobina glicada, pela elevada prevalência de diabete melito nos pacientes com acromegalia. A função adeno-hipofisária deve ser avaliada por meio das determinações séricas dos seguintes hormônios: cortisol, TSH, T4 livre, prolactina, LH e FSH. Adicionalmente, homens devem realizar a dosagem sérica de testosterona total e dos testes de gonadotrofina (LH e FSH). Para mulheres com ciclo menstrual irregular ou pós-menopausa, deve-se considerar as dosagens de estradiol, LH e FSH<sup>31–33</sup> . Para mulheres com ciclo menstrual regular, não é necessário realizar a dosagem de gonadotrofinas e estradiol.  
4

---

<!-- METADADOS: doenca: Acromegalia | secao: **3.3      Diagnóstico por exames de imagem** -->
Os exames de imagem permitem determinar a origem do excesso de GH. Como a principal causa de acromegalia (cerca de 98% dos casos) é um tumor hipofisário produtor de GH, todos os pacientes devem ser submetidos à ressonância magnética (RM) de sela túrcica<sup>34,42</sup> ou, se apresentarem contraindicação a esse exame, devem realizar tomografia computadorizada (TC) de sela túrcica. Nos raros casos em que haja diagnóstico clínico e laboratorial de acromegalia com RM ou TC de sela túrcica sem evidência de adenoma, tumores ectópicos produtores de GH ou de GHRH devem ser pesquisados. Para isso, o paciente deve ser submetido à TC de tórax e de abdômen<sup>1</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **3.4      Outros exames** -->
Para avaliação das complicações decorrentes da acromegalia, os exames a serem solicitados devem ser individualizados, podendo incluir ecocardiografia, tomografia computadorizada seios da face, radiografia de coluna, ultrassonografia de tireoide, avaliação de distúrbios do sono (polissonografia) e, devido a relatos de aumento da incidência de neoplasia de cólon em alguns estudos, colonoscopia<sup>1,33,34</sup> . Além disso, pacientes com tumores hipofisários, que à RM apresentem contato com o nervo óptico ou tenham queixas visuais, devem ser submetidos à exame oftalmológico com realização de campimetria visual manual<sup>34,42</sup> .  
A incidência de doenças e câncer de tireoide também parece ser maior nos pacientes com acromegalia do que na população em geral. Por isso, recomenda-se que o exame clínico inclua a avaliação da tireoide pela palpação e, em pacientes com nódulo palpável, seja realizada ecografia de tireoide<sup>34,47,48</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
São incluídos nesse PCDT as crianças, adolescentes e adultos com suspeita ou diagnóstico de acromegalia ou gigantismo confirmado por manifestações clínicas, comprovação laboratorial de excesso hormonal e por exame de imagem com identificação da causa da doença.  
Para o tratamento com **octreotida e lanreotida** , o paciente também deve apresentar os seguintes critérios:  
No tratamento primário: o paciente deve ter contraindicação ao tratamento cirúrgico ou ter baixa probabilidade de benefício com a cirurgia (devido a tumores invasivos predominantemente de seios cavernosos), e não apresentar risco de perda visual devido à extensão supra-selar do tumor.  
No tratamento complementar: três meses após procedimento cirúrgico, o paciente que não apresente critérios laboratoriais de controle da doença (IGF-I elevado).  
Para o tratamento com **cabergolina** , o paciente também deve apresentar:  
No tratamento primário: pacientes com adenomas hipofisários coprodutores de prolactina e GH ou pacientes com tumores não invasivos e com níveis pouco elevados de GH e IGF-I (menor do que 1,5 vezes o limite superior da normalidade para a idade do paciente).  
Tratamento complementar: pacientes que, três meses após uso regular de octreotida ou lanreotida, não apresentem critérios laboratoriais de controle da doença, ou seja, redução nos níveis de GH e IGF-I, sem atingir os níveis de normalidade.  
Para o tratamento com **pasireotida** , o paciente também deve apresentar idade a partir de 12 anos **e** exame de imagem que evidencie tumor remanescente após cirurgia no exame de imagem, sem resposta ao tratamento com octreotida ou lanreotida, associado ou não à cabergolina.  
5

---

<!-- METADADOS: doenca: Acromegalia | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes com intolerância, hipersensibilidade ou contraindicação aos medicamentos ou procedimentos preconizados neste Protocolo serão excluídos dos respectivos medicamentos ou procedimentos. Para o uso de pasireotida, serão excluídos pacientes que apresentem diagnóstico de diabete melito não controlado (HbA1c superior a 8%).

---

<!-- METADADOS: doenca: Acromegalia | secao: **6. TRATAMENTO** -->
O tratamento da acromegalia pode envolver procedimentos cirúrgicos, radioterapia e terapia medicamentosa. A acromegalia deve ser acompanhada não só para o controle dos sintomas, mas também para a diminuição da mortalidade<sup>23</sup> . Se necessário, os pacientes também devem receber tratamento para as eventuais complicações decorrentes da acromegalia, como hipertensão arterial sistêmica, diabete melito e doenças cardíacas.

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.1.    Tratamento cirúrgico** -->
O tratamento cirúrgico, com remoção do tumor, é o tratamento primário dos pacientes com acromegalia, na maioria dos casos. A remoção completa do tumor secretor de GH resulta em normalização das taxas hormonais com consequente melhoria das alterações clínicas e laboratoriais. A ressecção cirúrgica com consequente remissão da acromegalia pode reduzir as causas de mortalidade dos pacientes acromegálicos para os níveis normais da população<sup>23,31,32,34,42,49–51</sup> .  
Como a cirurgia pode levar à cura, é o tratamento de escolha em pacientes com acromegalia. Também é o tratamento inicial nos tumores que provocam sintomas compressivos, em especial do quiasma óptico com perda de campo visual.  
O resultado do tratamento cirúrgico depende da ressecção completa das células produtoras de GH, com interferências de diversos fatores, tais como características anatômicas do tumor, tamanho e invasão de seio cavernoso. A experiência da equipe cirúrgica e a realização do procedimento em centros especializados também interferem nas taxas de cura<sup>52</sup> . Pacientes que apresentem Classificação Knosp (avaliação da extensão do tumor hipofisário em relação ao seio cavernoso) graus 3 ou 4 e níveis elevados de IGF-I pré-operatório têm pior prognóstico de sucesso da cirurgia<sup>53,54</sup> .  
Em pacientes com microadenomas, a taxa de sucesso (normalização do IGF-I) descrita na literatura é de 75% a 95%; em pacientes com macroadenomas não invasivos, a taxa é de 40% a 68%<sup>32,34,42,51,55–57</sup> . Um estudo brasileiro identificou que em pacientes com acromegalia submetidos à cirurgia transesfenoidal (84% com macroadenomas), a remissão cirúrgica (definida como IGF-I normal e GH menor que 1 mcg/L três meses após a cirurgia) foi alcançada em 45% dos casos (56% em indivíduos com tumores não invasivos e 19% naqueles com tumores invasivos). A invasão do seio cavernoso foi considerado o único preditor pré-operatório de remissão cirúrgica<sup>58</sup> . Outros três estudos retrospectivos realizados no Brasil, com abordagens endoscópicas diferentes, mostraram taxas de remissão bioquímica (dosagem de IGF-I dentro dos níveis normais para sexo e idade e nadir de GH após sobrecarga de glicose abaixo de 1 ng/mL) de 16%, 35,5% e 70,7%, respectivamente<sup>59–61</sup> .  
Para tumores com extensão para seio cavernoso ou outras características de maior invasão, o tratamento cirúrgico não resultará em cura. Contudo, apesar da baixa probabilidade de cura, os pacientes podem se beneficiar do tratamento cirúrgico, pois ele proporciona melhor resposta a outras terapias posteriores<sup>62,63</sup> . O procedimento cirúrgico também permite redução da massa tumoral e, quando presentes, descompressão de estruturas neurais, como terceiro ventrículo, artérias carótidas, parênquima cerebral adjacente e quiasma óptico, melhorando os sintomas visuais. Quando a primeira cirurgia não resultou em controle da doença, um novo tratamento cirúrgico pode levar a cura em aproximadamente 50% dos casos<sup>56</sup> .  
O tratamento cirúrgico de escolha dos adenomas hipofisários produtores de GH se faz por via transesfenoidal com acesso endoscópico ou por microscopia (a abordagem transcraniana é raramente utilizada). O acesso por craniotomia fronto-temporal e ressecção microcirúrgica do tumor também pode ser indicado, em especial nos pacientes que apresentam extensão do tumor  
6  
acima do diafragma selar com extensões laterais. Entretanto, tal decisão deve ser individualizada e discutida pela equipe multidisciplinar<sup>42,51,64,65</sup> .  
As principais complicações relacionadas ao tratamento cirúrgico são: fístula liquórica, infecções (meningite e sinusite), hipopituitarismo e deficiência transitória de vasopressina. Outras complicações decorrentes do ato cirúrgico incluem: perda visual e sangramentos<sup>51,66</sup> . A taxa de mortalidade da cirurgia transesfenoidal, quando realizada por neurocirurgiões com experiência no procedimento, é inferior a 1%<sup>32</sup> . O tratamento pré-operatório com análogos da somatostatina não é preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.2.     Radioterapia** -->
A radioterapia pode ser considerada terapia de segunda ou terceira linha naqueles que apresentarem contraindicação a cirurgia ou em que, após tratamento cirúrgico e medicamentoso, não houve controle adequado da doença<sup>42,49</sup> . A seleção dos pacientes para o tratamento radioterápico deve ser feita em bases individuais, mas o procedimento estará geralmente indicado em pacientes com contraindicação à realização de cirurgia, com lesões de localização irressecável e resistentes ao tratamento medicamentoso. Deve ser dividida em duas modalidades de tratamento: radioterapia convencional fracionada e radiocirurgia estereotáxica (essa ainda podendo ser dividida em diferentes modalidades).  
Há maior experiência terapêutica com a radioterapia convencional, a qual é administrada por um acelerador linear (4 a 8 MeV) com uma dose total de 40 a 45 Gy, fracionada em pelo menos 20 sessões. Em geral, a normalização de GH e IGF- 1, ou seja, o controle da doença, ocorre em 50% a 60% dos pacientes em 5 a 10 anos e em 65% a 87% dos pacientes em 15 anos, demonstrando a dependência do tempo para o efeito completo da radiação. Já o controle do crescimento do tumor ocorre em 90% a 100% dos casos logo após o tratamento<sup>67–70</sup> . Além do tempo para o efeito, 5 a 15 anos até benefício máximo, o alto risco de eventos adversos em longo prazo também é um problema desta técnica, podendo ocorrer: hipopituitarismo em 30% a 80% dos pacientes, neuropatia óptica em 0% a 5%, neoplasia secundária em até 2%, doença cerebrovascular em 4% dos pacientes após 5 anos e em até 21% depois de 20 anos. Esses eventos indesejados são atribuídos à radiação de tecidos circundantes saudáveis, o que reforça a necessidade de monitorização contínua<sup>40,71</sup> .  
As técnicas estereotáxicas foram desenvolvidas a partir de 1950 e incluem a radiocirurgia estereotáxica e a radioterapia fracionada estereotáxica. Ambas fornecem uma alta dose de radiação para um alvo definido com uma dose acentuada na margem do tumor, limitando assim a irradiação e o dano às estruturas do cérebro adjacentes<sup>71</sup> . A taxa de cura bioquímica com estas técnicas é de 40% a 60% dos pacientes aos 5 anos. De forma semelhante à radioterapia convencional, o tamanho do tumor diminui ou se mantém estável em 93% a 100% dos pacientes com 5 a 10 anos de seguimento. A taxa de hipopituitarismo é de 10% a 50% após 5 anos e o risco de outras complicações induzidas por radiação é baixa: 0% a 5% para novos déficits visuais, dano dos nervos cranianos ou radionecrose cerebral e 0% a 1% para tumores cerebrais secundários<sup>71</sup> .  
A comparação das duas modalidades de radioterapia foi alvo de uma revisão sistemática com meta-análise. As taxas de controle, definido pela normalização de GH e IGF-I, com os dois tipos de radioterapia foram comparáveis: 52% para radiocirurgia vs. 36% para radioterapia convencional, p=0,14. O uso de radiocirurgia foi associado com menores taxas de hipopituitarismo com nível de significância marginal (32% vs. 51%, p=0,05)<sup>72</sup> . Adicionalmente, uma revisão sistemática indicou que as técnicas foram comparáveis em termos de taxa de redução do tamanho tumoral, controle tumoral e eventos adversos. Entretanto, uma maior taxa de remissão bioquímica (43% vs 28%, p =0,02) foi observada entre aqueles tratados com radiocirurgia. Contudo, estes dados devem ser vistos com cautela pelas limitações dos estudos incluídos, como sua elevada heterogeneidade<sup>73</sup> .  
As principais complicações da radioterapia são hipopituitarismo, defeitos visuais, tumores secundários, eventos cerebrovasculares e, possivelmente, alterações neurocognitivas em longo prazo<sup>1</sup> .  
7

---

<!-- METADADOS: doenca: Acromegalia | secao: **ANÁLOGOS DA SOMATOSTATINA OU LIGANTES DO RECEPTOR DA SOMATOSTATINA DE PRIMEIRA GERAÇÃO (OCTREOTIDA E LANREOTIDA)** -->
Os análogos da somatostatina são alguns dos principais medicamentos usados no tratamento da acromegalia e agem pela estimulação do receptor da somatostatina. Dessa maneira, eles diminuem a secreção de GH e a proliferação dos tumoral<sup>1</sup> .  
A octreotida e a lanreotida são os dois análogos da somatostatina preconizados neste Protocolo, disponíveis em formulações de curta e longa duração, sendo esta última a mais utilizada atualmente na prática clínica.  
Há evidências sobre o uso desses medicamentos como tratamento primário (prévio à cirurgia) e secundário (após a cirurgia)<sup>74–78</sup> . No entanto, o tratamento primário deve ser realizado apenas em pacientes com contraindicação ao tratamento cirúrgico ou que tenham baixa probabilidade de benefício com a cirurgia (devido a tumores invasivos predominantemente de seios cavernosos) e que não apresentem risco de perda visual devido à extensão supra-selar do tumor.

---

<!-- METADADOS: doenca: Acromegalia | secao: **AGONISTA DOPAMINÉRGICO (CABERGOLINA)** -->
Diversos estudos avaliaram o uso da cabergolina para o tratamento de pacientes com acromegalia<sup>42,79–81</sup> . Uma metaanálise incluindo 9 estudos avaliou o uso de cabergolina em monoterapia e indicou que 34% dos pacientes alcançaram níveis normais de IGF-I. Outros cinco estudos avaliaram o uso de cabergolina em associação com análogos da somatostatina em pacientes que não apresentaram o controle dos níveis de IGF-I apenas com o uso de octreotida ou lanreotida e apontaram que, com o uso da combinação, 52% dos pacientes alcançaram níveis normais de IGF-I<sup>79</sup> .  
Um estudo brasileiro avaliou o uso da cabergolina, em monoterapia ou em associação com análogos da somatostatina. O controle da doença de curto prazo, definido como nível de GH menor que 1,0 µg/L e nível normal de IGF-I correspondente à idade após 3 a 6 meses de tratamento com a dose mais alta usada, foi alcançado por 21% dos pacientes em monoterapia e por 32% dos pacientes em uso da combinação. Foi concluído que a eficácia da cabergolina parece ser menor do que a de outros medicamentos, podendo ser necessária a mudança do tratamento após um acompanhamento de longo prazo<sup>82</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **SEGUNDA GERAÇÃO (PASIREOTIDA)** -->
O principal estudo de avaliação da pasireotida foi o PAOLA, um ensaio clínico randomizado que avaliou a sua segurança e eficácia em comparação com a terapia continuada com octreotida e lanreotida em pacientes com acromegalia que não foram bem controlados, apesar do uso de altas doses desses medicamentos. Nenhum paciente do grupo controle ativo teve resposta bioquímica. No entanto, 15% dos pacientes do grupo pasireotida 40 mg e 20% dos pacientes do grupo pasireotida 60 mg alcançaram a resposta bioquímica, ou seja, um nível médio de GH menor que 2,5 μg/L e nível normal de IGF-I em 24 semanas (p = 0,0001). Nesse estudo, a normalização do IGF-I foi obtida por 25% e 26% dos indivíduos que foram tratados com pasireotida 40 mg e 60 mg, respectivamente (versus 0% no grupo de pacientes que receberam o controle ativo)<sup>83</sup> .  
Um estudo brasileiro retrospectivo avaliou o uso da pasireotida em pacientes com acromegalia. O controle do IGF-I foi alcançado por 54% dos pacientes, que também apresentaram melhoria de qualidade de vida e dos sintomas da doença. Já a redução do volume tumoral foi observada em 63% dos pacientes. Nesse estudo, a maioria dos pacientes apresentou eventos hiperglicêmicos, incluindo 63% dos pacientes com glicemia normal antes do tratamento<sup>84</sup> . O pamoato de pasireotida é recomendado neste Protocolo para o tratamento de pacientes com acromegalia, conforme Portaria SECTICS/MS nº 25, de 19 de junho de 2024.  
Diretrizes clínicas<sup>85,86</sup> também recomendam o uso do pegvisomanto, especialmente para pacientes que não respondem adequadamente ao tratamento com análogos da somatostatina ou que apresentam intolerância a outros medicamentos. Entretanto, a incorporação ao SUS do medicamento foi avaliada pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec), com recomendação de não incorporação, devido à elevada razão de custo-efetividade incremental. Portanto, este Protocolo não recomenda o uso de pegvisomanto.  
8  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
9  
**Figura 1 -** Fluxograma de tratamento.  
A imagem abaixo ilustra o algoritmo de tratamento da acromegalia.  
<!-- Start of picture text -->
| Paciente com diagnéstico confirmado de acromegalia<br>Realizar simi Tratamento Nao Considerar7  0 uso de<br>tratamento ere cabergolina’ ou andlogos<br>cirdrgico  possivel?cirurgico is ll arinfina de 1°<br>geracdo*<br>;<br>Pacientecontroleatingiu sim Monae 0 Nao /Paciente atingiu\ sim<br>laboratorial? controle<br>laboratorial?<br>Nao<br>‘Considerar nova cirurgia ou de radioterapia paciente<br>| radioterapia ou o uso de<br>de 1° geracdo, associado<br>| andalogosou nao daa  somatostatinacabergolina<br>: Sim<br>Paciente atingiu Moni °c<br>controle ent<br>laboratorial?<br>Nao<br>Faciento® \ngo__ feoneklerar oust<br>elegivel ao uso de =<br>de pasireotida?? racer<br>Sim<br>Considerar 0 uso<br>de pasireotida<br>' Uso preferencial em pacientes que apresentem tumores mistos produtores de horménio do crescimento e|<br>prolactina ou em pacientes com niveis de IGF-1 menor que 1.5 vezes 0 limite superior de normalidade<br>F Uso preferencial em pacientes que tenham contraindicacao ou baixa probabilidade de beneficio com a realizacao<br>da cirurgia<br>Critérios de elegibilidade de pasireotida: Paciente com 12 anos ou mais e tumor remanescente apés cirurgia.<br>esposta ao tratamento com octreotida ou lanreotida, associado ou nao a cabergolina e que nao apresenter<br>diagnéstico de diabete melito nao controlado.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.3.1   Medicamentos** -->
- Acetato de octreotida: solução injetável de 0,1 mg/mL; pó para suspensão injetável de 10 mg, 20 mg e 30 mg;  
- Acetato de lanreotida solução injetável de liberação controlada de 60 mg, 90 mg e 120 mg;  
- Cabergolina: comprimido de 0,5 mg;  
10  
 Pamoato de pasireotida: pó para suspensão injetável de 10 mg, 20 mg, 40 mg e 60 mg.

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.3.2   Esquemas de administração** -->
**Acetato de octreotida de liberação prolongada** : administrações intramusculares em região glútea profunda a cada 4 semanas, dose mínima de 10 mg e dose máxima de 30 mg (a dose inicial recomendada em bula é de 20 mg). Os ajustes na dose devem ser feitos a intervalos trimestrais, de acordo com a resposta clínica, os eventos adversos e os níveis séricos de IGF-I, e após o controle da atividade da doença (normalização dos níveis de IGF-I), podem ser espaçados para controles semestrais ou anuais. As aplicações devem ser feitas por profissional treinado e habilitado<sup>87</sup> .  
**Acetato de octreotida** : dose inicial de 0,05 a 0,1 mg por injeção subcutânea a cada 8 ou 12 horas. A dose ideal diária na maioria dos pacientes é de 0,3 mg. A dose máxima é de 1,5 mg/dia. O ajuste posológico deve ser baseado na avaliação mensal dos níveis de GH e IGF-I, e dos sintomas clínicos, e na tolerabilidade<sup>87</sup> .  
**Lanreotida** : administrações subcutâneas profundas em região glútea a cada 4 semanas, podendo ser estendida para 6 a 8 semanas. A dose inicial recomendada para tratamento de acromegalia pode variar de 60 mg a 120 mg. Os ajustes devem ser feitos a intervalos trimestrais de acordo com a resposta clínica, eventos adversos e os níveis séricos de IGF-I. Após o controle da atividade da doença (normalização dos níveis de IGF-I), os controles podem ser espaçados, com frequência semestral ou anual. As aplicações devem ser feitas por profissional treinado e habilitado<sup>88</sup> .  
**Cabergolina** : as doses são gradativamente tituladas até atingir 2 a 3 mg/semana, por via oral, com controle mensal ou bimestral, observando-se a resposta clínica, os eventos adversos e os níveis séricos de IGF-I. Nos casos de controle da atividade da doença (normalização dos níveis de IGF-I), o monitoramento pode ser espaçado para frequência semestral ou anual.  
**Pasireotida** : A dose inicial recomendada de pasireotida é de 40 mg, administrada por injeção intramuscular profunda a cada quatro semanas. A dose pode ser aumentada até um máximo de 60 mg em pacientes cujos níveis de IGF-I não estiverem totalmente controlados depois de três meses de tratamento com pasireotida 40 mg. O tratamento de eventos adversos ou resposta excessiva ao tratamento (IGF-I menor que o limite inferior da normalidade) pode exigir a redução temporária da dose de pasireotida para 20 mg. A dose pode ser reduzida, temporária ou permanentemente, em decréscimos de 20 mg<sup>89</sup> . Um estudo brasileiro demonstrou que 40% dos pacientes em tratamento com pasireotida se beneficiaram com a redução de dose, após a qual os níveis de IGF-I apresentaram um leve aumento, mas permaneceram dentro da faixa normal após uma mediana de 39 meses nos respondedores precoces e 17 meses nos respondedores tardios<sup>90</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.4.     Critérios de interrupção** -->
Em casos particulares em que haja controle clínico do paciente com as doses mínimas de octreotida ou lanreotida, sem o uso concomitante de cabergolina, ou apenas com cabergolina, sem tumor ou com pequena lesão remanescente não invasiva, pode-se reduzir a frequência de uso das doses dos análogos da somatostatina com posterior interrupção do tratamento e monitoramento sequencial dos níveis de GH e IGF-I para confirmação do controle da doença ou possível recorrência.  
As taxas de recorrência são altas, sendo frequentemente necessária a reintrodução do tratamento medicamentoso. Em mulheres pacientes que estiverem em tratamento e engravidarem, o tratamento medicamentoso com análogos da somatostatina deve ser suspenso. O uso desses medicamentos como rotina não é recomendado e não deve ser utilizado sem orientação médica.  
Para a pasireotida, o tratamento de suspeitas de reações adversas ou resposta excessiva ao tratamento (IGF-1 < limite inferior do normal) pode exigir a redução temporária de dose (redução temporária ou permanente em decréscimos de 20 mg). Este medicamento não deve ser utilizado por mulheres grávidas sem orientação médica<sup>89</sup> .  
11

---

<!-- METADADOS: doenca: Acromegalia | secao: **6.5.     Benefícios esperados** -->
 Melhora da sintomatologia clínica da acromegalia. Nos casos de gigantismo, controle do crescimento longitudinal excessivo provocado pelo excesso de GH e IGF-I, com normalização da curva de crescimento;  
- Melhora/controle das comorbidades presentes;  
- Controle da hipersecreção hormonal, com normalização dos níveis séricos de IGF-I;  
- Controle total ou parcial do volume do adenoma hipofisário;  
- Redução da mortalidade associada à doença não controlada.

---

<!-- METADADOS: doenca: Acromegalia | secao: **7. MONITORAMENTO** -->
Os pacientes com acromegalia devem manter acompanhamento por toda a vida, com avaliações clínica e laboratorial trimestrais no primeiro ano e, após, anualmente. Essa periodicidade pode ser modificada de acordo com a resposta aos tratamentos, conforme resultados de exames laboratoriais. As comorbidades associadas (hipertensão, diabete melito, cardiomiopatia acromegálica) também devem ser avaliadas e acompanhadas no seguimento dos pacientes.  
A avaliação da resposta ao tratamento depende da modalidade terapêutica adotada. Para avaliação da resposta ao tratamento dos pacientes submetidos ao tratamento cirúrgico, podem ser solicitadas dosagens séricas de IGF-I e GH após sobrecarga de glicose, 3 a 6 meses depois do procedimento. O nadir de GH pode ser influenciado pela idade, IMC, sexo e concentração de estrogênio. No caso de indivíduo com diabete, devem ser realizadas dosagens de IGF-I e GH basal por método ultrassensível sem sobrecarga de glicose<sup>40,51</sup> .  
As recomendações dos consensos internacionais sugeriram inicialmente que a acromegalia poderia ser considerada controlada quando a dosagem de IGF-I estivesse dentro do nível normal para sexo e idade e o nadir de GH após sobrecarga de glicose, abaixo de 1 ng/mL<sup>1,91</sup> . Sugere-se que, no pós-operatório (3 a 6 meses após cirurgia), o ponto de corte considerado como cura na supressão do GH após teste oral de tolerância a glicose seja inferior a 0,4 ng/mL com ensaios ultrassensiveis<sup>51</sup> .  
Nos pacientes em uso de análogos da somatostatina ou agonista da dopamina, a dosagem de GH após sobrecarga de glicose não é útil para monitorar a resposta terapêutica. Nesses casos, dosagens de IGF-I e de GH devem ser efetuadas<sup>33</sup> . Para o tratamento com pasireotida, a adequada monitorização dos níveis séricos de glicose e hemoglobina glicada deve ser realizada.  
No seguimento de pacientes em tratamento clínico, a concentração de IGF-I reflete a atividade da doença, porém sofre variabilidade e influência de fatores pré-analíticos e analíticos. Os parâmetros são avaliados como variação acima do limite superior da normalidade (LSN), e são considerados controlados os pacientes que apresentarem valores normais ou, ainda que não seja consenso, levemente aumentados (1,2 a 1,3 X LSN), de acordo com o cenário clínico. O GH basal, se usado no monitoramento, é considerado normal se menor que 1 ng/mL<sup>51,92</sup> . Se houver discrepância entre as dosagens de GH e IGF-I, o julgamento clínico pode ser importante e norteará a conduta. Essa situação pode ocorrer em cerca de 25% dos pacientes e está associada ao uso de ensaio ultrassensíveis de GH e tratamento com análogos de somatostatina<sup>23,51,92,93</sup> .  
Nos pacientes com doença controlada, esses exames devem ser repetidos trimestralmente no primeiro ano e, após, anualmente. Naqueles em que a doença não estiver controlada, a periodicidade dos exames deverá ser mantida no primeiro ano e, após esse período, dependerá do uso de novos tratamentos e da resposta a eles<sup>1</sup> .  
A avaliação com RM deve ser realizada no mínimo 3 meses depois da cirurgia para acompanhamento. Após o primeiro exame de seguimento, a periodicidade da avaliação por RM dependerá da resposta do paciente ao tratamento. Quando houver sinais clínicos ou laboratoriais de recorrência, a RM deverá ser realizada novamente<sup>31</sup> .  
Os principais eventos adversos dos análogos da somatostatina são desconforto e cólicas abdominais, que melhoram com a manutenção do tratamento (em torno de 8 a 10 semanas após o início). Outra complicação descrita é o desenvolvimento de litíase biliar em até 20% dos pacientes, raramente causando colecistite. Não há necessidade de realização de ultrassonografia  
12  
como avaliação de rotina para essa complicação. Há relato de casos de desenvolvimento de pancreatite<sup>32,34</sup> e de piora de estados hiperglicêmicos.  
Algumas evidências sugerem que o uso de cabergolina pode ser relacionado ao desenvolvimento de doença valvar cardíaca e à possibilidade de desordens de impulsos<sup>94,95</sup> . Contudo, elas são oriundas de estudos sobre o tratamento de doença de Parkinson, em que as doses são mais elevadas e o tratamento mais prolongado do que para acromegalia. Nas doses empregadas para tratamento de prolactinomas, não foi encontrada essa associação<sup>96,97</sup> .

---

<!-- METADADOS: doenca: Acromegalia | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com acromegalia devem ser atendidos em serviços especializados em endocrinologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com acromegalia devem ser avaliados periodicamente em relação à eficácia do tratamento e ao desenvolvimento de toxicidade aguda ou crônica, em serviços especializados de neurocirurgia com endocrinologia ou neuroendocrinologia. A existência de centro de referência facilita a avaliação diagnóstica, o tratamento, o ajuste de doses conforme necessário e o controle de eventos adversos.  
Em termos cirúrgicos, os melhores resultados e menores chances de complicações dependem da experiência do cirurgião e não da técnica utilizada (endoscopia ou microscopia), o que se observa em serviços em que apenas um ou dois neurocirurgiões são responsáveis pelas cirurgias transesfenoidais de hipófise<sup>65</sup> .  
A busca pela excelência deve ser um objetivo contínuo dos profissionais e dos gestores de saúde, e é amplamente aceito que especialistas em doenças menos prevalentes costumam fornecer melhor padrão de atendimento aos pacientes. No caso dos tumores hipofisários, há consenso amplamente difundido, indicando que o melhor atendimento é fornecido por uma equipe interdisciplinar composta por endocrinologistas dedicados e cirurgiões hipofisários experientes. Idealmente, essa equipe central precisa, muitas vezes, ser apoiada por outras áreas do conhecimento, incluindo neurorradiologia, neuropatologia, radioterapia, oftalmologia, otorrinolaringologia e enfermagem especializada<sup>17,42,51,65</sup> .  
Nesse contexto, a _Pituitary Society_ elaborou um estudo com o objetivo de validar critérios propostos anteriormente por meio da coleta e avaliação de atividade autorrelatada de vários centros hipofisários internacionais para a definição de Centros de Excelência em Tumores Hipofisários, visando contribuir para o melhor manejo dos pacientes e alcance de resultados terapêuticos satisfatórios. Entre os principais pontos, foram destacados:  presença de três neurocirurgiões hipofisários especializados e 100 procedimentos cirúrgicos por centro anualmente; complicações agudas pós-cirúrgicas devem ser preferencialmente insignificantes ou inexistentes (aceitável  taxa menor que 10%) e quatro endocrinologistas dedicados à doença da hipófise<sup>98</sup> .  
Por essas razões, pacientes com acromegalia e gigantismo devem ser preferencialmente atendidos em serviços especializados que tenham ao menos ambulatório específico de endocrinologia para atendimento de pacientes com doenças hipofisárias e hipotalâmicas, com acesso a equipe de neurocirurgia com experiência comprovada em cirurgias para tumores hipofisários (CID-10: D35.2), para seu adequado diagnóstico, tratamento e acompanhamento, pois isso tem comprovado impacto no custo-efetividade da abordagem da acromegalia/gigantismo<sup>52</sup> .  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do (s) medicamento (s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de  
13  
Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Acromegalia | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como sobre os critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Acromegalia | secao: **10. REFERÊNCIAS** -->
1. Melmed S. Medical progress: Acromegaly. N Engl J Med. dezembro de 2006;355(24):2558–73.  
2. Melmed S. Acromegaly pathogenesis and treatment. J Clin Invest. 2009 Nov;119(11):3189-202.  
3. Fleseriu M, Langlois F, Lim DST, Varlamov E V, Melmed S. Acromegaly: pathogenesis, diagnosis, and management. Lancet Diabetes Endocrinol. 2022.  
4. Gadelha MR, Kasuki L, Korbonits M. The genetic background of acromegaly. Pituitary. fevereiro de 2017;20(1):10–21.  
5. WHO Classification of Tumours Editorial Board. Endocrine and neuroendocrine tumours. Lyon (France): International Agency for Research on Cancer; 2022. (WHO classification of tumours series, 5th ed.; vol. 10).  
6. Ershadinia N, Tritos NA. Diagnosis and treatment of acromegaly: an update. In: Mayo Clinic Proceedings. Elsevier; 2022. p. 333–46.  
7. Neto LV, Machado E de O, Luque RM, Taboada GF, Marcondes JB, Chimelli LMC, et al. Expression analysis of dopamine receptor subtypes in normal human pituitaries,  nonfunctioning pituitary adenomas and somatotropinomas, and the association between dopamine and somatostatin receptors with clinical response to octreotide-LAR in acromegaly. J Clin Endocrinol Metab. junho de 2009;94(6):1931–7.  
8. Lamback EB, Henriques DG, Vazquez-Borrego MC, de Azeredo Lima CH, Kasuki L, Luque RM, et al. Growth hormone-releasing hormone-secreting pulmonary neuroendocrine tumor  associated with pituitary hyperplasia and somatotropinoma. Vol. 65, Archives of endocrinology and metabolism. Brazil; 2021. p. 648–63.  
9. Sotos JF. Overgrowth. Hormonal Causes. Clin Pediatr (Phila). novembro de 1996;35(11):579–90.  
10. Caputo M, Ucciero A, Mele C, De Marchi L, Magnani C, Cena T, et al. Use of administrative health databases to estimate incidence and prevalence of acromegaly in Piedmont Region, Italy. J Endocrinol Invest. 2019;42:397–402.  
11. Gatto F, Trifirò G, Lapi F, Cocchiara F, Campana C, Dell’Aquila C, et al. Epidemiology of acromegaly in Italy: analysis from a large longitudinal primary care database. Endocrine. 2018;61:533–41.  
12. Dal J, Feldt-Rasmussen U, Andersen M, Kristensen LØ, Laurberg P, Pedersen L, et al. Acromegaly incidence, prevalence, complications and long-term prognosis: a  nationwide cohort study. Eur J Endocrinol. setembro de 2016;175(3):181–90.  
13. Soares LF, Outuki G, Miksza DR, Crespigio J, da Silva Mattos AM, Mazzuco TL. Registro epidemiológico e avaliação clínico-laboratorial dos pacientes acromegálicos atendidos em um centro de referência regional. Biosaúde. 2017;19(1):12–25.  
14. Eugster EA GMHAG. Pituitary gigantism [Internet]. UpToDate. 2023.  
15. Rostomyan L, Daly AF, Petrossians P, Nachev E, Lila AR, Lecoq AL, et al. Clinical and genetic characterization of pituitary gigantism: an international  collaborative study in 208 patients. Endocr Relat Cancer. outubro de 2015;22(5):745–57.  
14  
16. Daly AF, Rostomyan L, Betea D, Bonneville JF, Villa C, Pellegata NS, et al. AIP-mutated acromegaly resistant to firstgeneration somatostatin analogs:  long-term control with pasireotide LAR in two patients. Endocr Connect. abril de 2019;8(4):367–77.  
17. Giustina A, Barkan A, Beckers A, Biermasz N, Biller BMK, Boguszewski C, et al. A Consensus on the Diagnosis and Treatment of Acromegaly Comorbidities: An  Update. J Clin Endocrinol Metab. abril de 2020;105(4).  
18. Kasuki L, Antunes X, Lamback EB, Gadelha MR. Acromegaly: Update on Management and Long-Term Morbidities. Endocrinol Metab Clin North Am. setembro de 2020;49(3):475–86.  
19. Kasuki L, Maia B, Gadelha MR. Acromegaly and Colorectal Neoplasm: An Update. Front Endocrinol (Lausanne). 2022;13:924952.  
20. Gadelha MR, Kasuki L, Lim DST, Fleseriu M. Systemic Complications of Acromegaly and the Impact of the Current Treatment  Landscape: An Update. Endocr Rev. fevereiro de 2019;40(1):268–332.  
21. Gadelha MR, Kasuki L. Refractory somatotroph adenomas. Pituitary. junho de 2023;26(3):266–8.  
22. Wildemberg LE, da Silva Camacho AH, Miranda RL, Elias PCL, de Castro Musolino NR, Nazato D, et al. Machine Learning-based Prediction Model for Treatment of Acromegaly With  First-generation Somatostatin Receptor Ligands. J Clin Endocrinol Metab. junho de 2021;106(7):2047–56.  
23. Giustina A, Chanson P, Kleinberg D, Bronstein MD, Clemmons DR, Klibanski A, et al. Expert consensus document: A consensus on the medical treatment of acromegaly. Nat Rev Endocrinol. 2014 Apr;10(4):243-8.  
24. Gatto F, Wildemberg LE, Ferone D, Gadelha MR. Routine Evaluation of Somatostatin Receptor Type 2 in Patients With Acromegaly:  Do We Still Need More Evidence? Vol. 107, The Journal of clinical endocrinology and metabolism. United States; 2022. p. e4382–3.  
25. Diri H, Ozaslan E, Kurtsoy A, Bayram F. A single-center observational study assessing the predictive factors associated with the prognosis of acromegaly. Growth Hormone & IGF Research. 2020;55:101342.  
26. Kauppinen-Makelin R, Sane T, Reunanen A, Valimaki MJ, Niskanen L, Markkanen H, et al. A nationwide survey of mortality in acromegaly. J Clin Endocrinol Metab. 2005 Jul;90(7):4081-6.  
27. Holdaway IM, Rajasoorya RC, Gamble GD. Factors influencing mortality in acromegaly. J Clin Endocrinol Metab. fevereiro de 2004;89(2):667–74.  
28. Bolfi F, Neves AF, Boguszewski CL, Nunes-Nogueira VS. Mortality in acromegaly decreased in the last decade: a systematic review and  meta-analysis. Eur J Endocrinol. julho de 2018;179(1):59–71.  
29. Bengtsson BA, Eden S, Ernest I, Oden A, Sjogren B. Epidemiology and long-term survival in acromegaly. A study of 166 cases diagnosed between 1955 and 1984. Acta Med Scand. 1988;223(4):327-35.  
30. BRASIL. Ministério da Saúde. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas [Internet]. Brasília - DF; 2020 [citado 23 de novembro de 2022]. Disponível em: http://editora.saude.gov.br.  
31. Barkan A, Bronstein MD, Bruno OD, Cob A, Espinosa-de-los-Monteros AL, Gadelha MR, et al. Management of acromegaly in Latin America: expert panel recommendations. Pituitary. 2010 Jun;13(2):168- 75.  
32. Melmed S, Colao A, Barkan A, Molitch M, Grossman AB, Kleinberg D, et al. Guidelines for acromegaly management: an update. J Clin Endocrinol Metab. 2009 May;94(5):1509-17.  
33. Vieira Neto L, Abucham J, et al. Recommendations of Neuroendocrinology Department from Brazilian Society of Endocrinology and Metabolism for diagnosis and treatment of acromegaly in Brazil. Arq Bras Endocrinol Metab. 2011;55:725–6.  
34. Katznelson L, Laws ER, Jr., Melmed S, Molitch ME, Murad MH, Utz A, et al. Acromegaly: an endocrine society clinical practice guideline. J Clin Endocrinol Metab. 2014 Nov;99(11):3933-51.  
35. Molitch ME. Clinical manifestations of acromegaly. Endocrinol Metab Clin North Am. 1992 Sep;21(3):597-614.  
15  
36. Armeni E, Grossman A. The Spectrum of Familial Pituitary Neuroendocrine Tumors. Endocr Pathol. março de 2023;34(1):57–78.  
37. Daly AF, Yuan B, Fina F, Caberg JH, Trivellin G, Rostomyan L, et al. Somatic mosaicism underlies X-linked acrogigantism syndrome in sporadic male  subjects. Endocr Relat Cancer. abril de 2016;23(4):221–33.  
38. Jenkins PJ. Acromegaly and cancer. Horm Res. 2004;62 Suppl 1:108-15.  
39. Correa LL, Balarini Lima GA, Cavallieri SA, Miranda LC, Gadelha MR. Prostatic disorders in acromegalic patients experience of a Brazilian center. Int Braz J Urol. 2013 May-Jun;39(3):393-401.  
40. Fleseriu M, Biller BMK, Freda PU, Gadelha MR, Giustina A, Katznelson L, et al. A Pituitary Society update to acromegaly management guidelines. Pituitary. fevereiro de 2021;24(1):1–13.  
41. Giustina A, Biermasz N, Casanueva FF, Fleseriu M, Mortini P, Strasburger C, van der Lely AJ, Wass J, Melmed S; Acromegaly Consensus Group. Consensus on criteria for acromegaly diagnosis and remission. Pituitary. 2024 Feb;27(1):7-22.  
42. Ogedegbe OJ, Cheema AY, Khan MA, Junaid SZS, Erebo JK, Ayirebi-Acquah E, et al. A Comprehensive Review of Four Clinical Practice Guidelines of Acromegaly. Cureus. setembro de 2022;14(9):e28722.  
43. Dimaraki EV, Jaffe CA, DeMott-Friberg R, Chandler WF, Barkan AL. Acromegaly with apparently normal GH secretion: implications for diagnosis and follow-up. J Clin Endocrinol Metab. 2002 Aug;87(8):3537-42.  
44. Freda PU, Reyes CM, Nuruzzaman AT, Sundeen RE, Bruce JN. Basal and glucose-suppressed GH levels less than 1 microg/L in newly diagnosed acromegaly. Pituitary. 2003;6(4):175-80.  
45. Mercado M, Espinosa de los Monteros AL, Sosa E, Cheng S, Mendoza V, Hernandez I, et al. Clinical-biochemical correlations in acromegaly at diagnosis and the real prevalence of biochemically discordant disease. Horm Res. 2004;62(6):293-9.  
46. Rosario PW, Calsolari MR. Laboratory investigation of acromegaly: is basal or random GH > 0.4 µg/L in the  presence of normal serum IGF-1 an important result? Arch Endocrinol Metab. fevereiro de 2015;59(1):54–8.  
47. dos Santos MC, Nascimento GC, Nascimento AG, Carvalho VC, Lopes MH, Montenegro R, et al. Thyroid cancer in patients with acromegaly: a case-control study. Pituitary. 2013 Mar;16(1):109-14.  
48. Uchoa HB, Lima GA, Correa LL, Vidal AP, Cavallieri SA, Vaisman M, et al. Prevalence of thyroid diseases in patients with acromegaly: experience of a Brazilian center. Arq Bras Endocrinol Metabol. 2013 Dec;57(9):685-90.  
49. Vieira Neto L, Abucham J, et al. Recommendations of Neuroendocrinology Department from Brazilian Society of Endocrinology and Metabolism for diagnosis and treatment of acromegaly in Brazil. Arq Bras Endocrinol Metab. 2011;55:725–6.  
50. Abu Dabrh AM, Mohammed K, et al. Surgical interventions and medical treatments in treatment-naive patients with acromegaly: systematic review and meta-analysis. J Clin Endocrinol Metab. 2014 Nov;99(11):4003-14.  
51. Giustina A, Barkhoudarian G, Beckers A, Ben-Shlomo A, Biermasz N, Biller B, et al. Multidisciplinary management of acromegaly: A consensus. Rev Endocr Metab Disord. dezembro de 2020;21(4):667–78.  
52. Casanueva FF, Barkan AL, Buchfelder M, Klibanski A, Laws ER, Loeffler JS, et al. Criteria for the definition of Pituitary Tumor Centers of Excellence (PTCOE): A  Pituitary Society Statement. Pituitary. outubro de 2017;20(5):489–98.  
53. Buchfelder M, Schlaffer SM. The surgical treatment of acromegaly. Pituitary. fevereiro de 2017;20(1):76–83.  
54. Taweesomboonyat C, Oearsakul T. Prognostic Factors of Acromegalic Patients with Growth HormoneSecreting  Pituitary Adenoma After Transsphenoidal Surgery. World Neurosurg. fevereiro de 2021;146:e1360–6.  
55. Nomikos P, Buchfelder M, Fahlbusch R. The outcome of surgery in 668 patients with acromegaly using current criteria of biochemical “cure”. Eur J Endocrinol. 2005;152(3):379-87.  
16  
56. Almeida JP, Ruiz-Treviño AS, et al. Reoperation for growth hormone-secreting pituitary adenomas: report on an endonasal endoscopic series with a systematic review and meta-analysis of the literature. J Neurosurg. 2018;129(2):404416.  
57. Briceno V, Zaidi HA, et al. Efficacy of transsphenoidal surgery in achieving biochemical cure of growth hormonesecreting pituitary adenomas among patients with cavernous sinus invasion: a systematic review and meta-analysis. Neurol Res. 2017;39(5):387-39.  
58. Antunes X, Ventura N, Camilo GB, Wildemberg LE, Guasti A, Pereira PJM, et al. Predictors of surgical outcome and early criteria of remission in acromegaly. Endocrine. junho de 2018;60(3):415–22.  
59. Boeving A, Borba LA, et al. [Outcome of surgical treatment for acromegaly performed by a single neurosurgeon and cumulative meta-analysis]. Arq Bras Endocrinol Metabol. 2006;50(5):884-92.  
60. Barbosa ER, Zymberg ST, Santos R de P, Machado HR, Abucham J. [Hormonal control of pituitary adenomas by transsphenoidal surgery: results of  the first five years of experience]. Arq Bras Endocrinol Metabol. fevereiro de 2011;55(1):16–28.  
61. Gondim JA, Schops M, de Almeida JPC, de Albuquerque LAF, Gomes E, Ferraz T, et al. Endoscopic endonasal transsphenoidal surgery: surgical results of 228 pituitary  adenomas treated in a pituitary center. Pituitary. 2010;13(1):68–77.  
62. Jallad RS, Musolino NR, Kodaira S, Cescato VA, Bronstein MD. Does partial surgical tumour removal influence the response to octreotide-LAR in  acromegalic patients previously resistant to the somatostatin analogue? Clin Endocrinol (Oxf). agosto de 2007;67(2):310–5.  
63. Colao A, Attanasio R, Pivonello R, Cappabianca P, Cavallo LM, Lasio G, et al. Partial surgical removal of growth hormone-secreting pituitary tumors enhances  the response to somatostatin analogs in acromegaly. J Clin Endocrinol Metab. janeiro de 2006;91(1):85–92.  
64. Bray DP, Mannam S, Rindler RS, Quillin JW, Oyesiku NM. Surgery for acromegaly: Indications and goals. Front Endocrinol (Lausanne). 2022;13:924589.  
65. Vieira Neto L, Abucham J, Araujo LA de, Boguszewski CL, Bronstein MD, Czepielewski M, et al. Recomendações do Departamento de Neuroendocrinologia da Sociedade Brasileira de Endocrinologia e Metabologia para o diagnóstico e tratamento da acromegalia no Brasil. Vol. 55, Arquivos Brasileiros de Endocrinologia & Metabologia. scielo ; 2011.  
66. Starnoni D, Daniel RT, Marino L, Pitteloud N, Levivier M, Messerer M. Surgical treatment of acromegaly according to the 2010 remission criteria:  systematic review and meta-analysis. Acta Neurochir (Wien). novembro de 2016;158(11):2109–21.  
67. Jallad RS, Musolino NR, Salgado LR, Bronstein MD. Treatment of acromegaly: is there still a place for radiotherapy? Pituitary. 2007;10(1):53–9.  
68. Erridge SC, Conkey DS, Stockton D, Strachan MWJ, Statham PFX, Whittle IR, et al. Radiotherapy for pituitary adenomas: long-term efficacy and toxicity. Radiother Oncol. dezembro de 2009;93(3):597–601.  
69. Rowland NC, Aghi MK. Radiation treatment strategies for acromegaly. Neurosurg Focus. outubro de 2010;29(4):E12.  
70. Loeffler JS, Shih HA. Radiation therapy in the management of pituitary adenomas. J Clin Endocrinol Metab. julho de 2011;96(7):1992–2003.  
71. Gheorghiu ML. Updates in outcomes of stereotactic radiation therapy in acromegaly. Pituitary. fevereiro de 2017;20(1):154–68.  
72. Abu Dabrh A, Asi N, Farah W, Mohammed K, Wang Z, Farah M, et al. Radiotherapy vs. Radiosurgery in Treating Patients with Acromegaly: Systematic  Review and Meta-Analysis. Endocr Pract. março de 2015;1–33.  
17  
73. Zheng Q, Huang Y, Lin W, Cai L, Wen J, Chen G. Comparing Stereotactic Radiosurgery and Fractionated Stereotactic Radiotherapy in  Treating patients with Growth Hormone-Secreting Adenomas: A Systematic Review and Metaanalysis. Endocr Pract. junho de 2020;  
74. Amato G, Mazziotti G, Rotondi M, Iorio S, Doga M, Sorvillo F, et al. Long-term effects of lanreotide SR and octreotide LAR on tumour shrinkage and GH  hypersecretion in patients with previously untreated acromegaly. Clin Endocrinol (Oxf). janeiro de 2002;56(1):65–71.  
75. Andersen M, Hansen TB, Bollerslev J, Bjerre P, Schrøder HD, Hagen C. Effect of 4 weeks of octreotide treatment on prolactin, thyroid stimulating  hormone and thyroid hormones in acromegalic patients. A double blind placebo-controlled cross-over study. J Endocrinol Invest. dezembro de 1995;18(11):840–6.  
76. Andries M, Glintborg D, Kvistborg A, Hagen C, Andersen M. A 12-month randomized crossover study on the effects of lanreotide Autogel and  octreotide long-acting repeatable on GH and IGF-l in patients with acromegaly. Clin Endocrinol (Oxf). março de 2008;68(3):473–80.  
77. Jenkins PJ, Akker S, Chew SL, Besser GM, Monson JP, Grossman AB. Optimal dosage interval for depot somatostatin analogue therapy in acromegaly  requires individual titration. Clin Endocrinol (Oxf). dezembro de 2000;53(6):719–24.  
78. Melmed S, Cook D, Schopohl J, Goth MI, Lam KSL, Marek J. Rapid and sustained reduction of serum growth hormone and insulin-like growth  factor-1 in patients with acromegaly receiving lanreotide Autogel therapy: a randomized, placebo-controlled, multicenter study with a 52 week open extension. Pituitary. 2010;13(1):18–28.  
79. Sandret L, Maison P, Chanson P. Place of cabergoline in acromegaly: a meta-analysis. J Clin Endocrinol Metab. maio de 2011;96(5):1327–35.  
80. Grasso LFS, Auriemma RS, Pivonello R, Colao A. Somatostatin analogs, cabergoline and pegvisomant: comparing the efficacy of  medical treatment for acromegaly. Expert Rev Endocrinol Metab. janeiro de 2017;12(1):73–85.  
81. Kizilgul M, Duger H, Nasiroglu NI, Sencar E, Hepsen S, Akhanli P, et al. Efficacy of cabergoline add-on therapy in patients with acromegaly resistance to  somatostatin analogs treatment and the review of literature. Arch Endocrinol Metab. maio de 2022;66(3):278–85.  
82. Kasuki L, Dalmolin MD, Wildemberg LE, Gadelha MR. Treatment escape reduces the effectiveness of cabergoline during long-term  treatment of acromegaly in monotherapy or in association with first-generation somatostatin receptor ligands. Clin Endocrinol (Oxf). junho de 2018;88(6):889–95.  
83. Gadelha MR, Bronstein MD, Brue T, Coculescu M, Fleseriu M, Guitelman M, et al. Pasireotide versus continued treatment with octreotide or lanreotide in patients  with inadequately controlled acromegaly (PAOLA): a randomised, phase 3 trial. Lancet Diabetes Endocrinol. novembro de 2014;2(11):875–84.  
84. Gadelha M, Marques NV, Fialho C, Scaf C, Lamback E, Antunes X, et al. Long-term Efficacy and Safety of Pasireotide in Patients With Acromegaly: 14  Years of Single-Center Real-World Experience. J Clin Endocrinol Metab. novembro de 2023;108(12):e1571–9.  
85. Fleseriu M, Biller BMK, Freda PU, Gadelha MR, Giustina A, Katznelson L, Molitch ME, Samson SL, Strasburger CJ, van der Lely AJ, Melmed S. A Pituitary Society update to acromegaly management guidelines. Pituitary. 2021 Feb;24(1):1-13. .  
86. Katznelson L, Laws ER Jr, Melmed S, Molitch ME, Murad MH, Utz A, Wass JA; Endocrine Society. Acromegaly: an endocrine society clinical practice guideline. J Clin Endocrinol Metab. 2014 Nov;99(11):3933-51. .  
87. Agência Nacional de Vigilância Sanitária (ANVISA). Acetato de octreotida (bula do medicamento). 2024.  
88. Agência Nacional de Vigilância Sanitária (ANVISA). Lanreotida (bula do medicamento). 2024.  
89. Agência Nacional de Vigilância Sanitária (ANVISA). Pasireotida (bula do medicamento). 2024.  
18  
90. Marques NV, Wildemberg LEA, Gadelha MR. Long-term, real-world experience of pasireotide dose reduction in patients with  acromegaly. Endocr Connect. agosto de 2023;12(10).  
91. Giustina A, Chanson P, et al. A consensus on criteria for cure of acromegaly. J Clin Endocrinol Metab. 2010 Jul;95(7):3141-8.  
92. Brue T, Rahabi H, Barry A, Barlier A, Bertherat J, Borson-Chazot F, et al. Position statement on the diagnosis and management of acromegaly: the French  National Diagnosis and Treatment Protocol (NDTP). Annales d’endocrinologie. France; 2023.  
93. Kanakis GA, Chrisoulidou A, , et al. The ongoing challenge of discrepant growth hormone and insulin-like growth factor I results in the evaluation of treated acromegalic patients: a systematic review and meta-analysis. Clin Endocrinol. 2016;85:681-688.  
94. Barake M, Evins AE, Stoeckel L, Pachas GN, Nachtigall LB, Miller KK, et al. Investigation of impulsivity in patients on dopamine agonist therapy for  hyperprolactinemia: a pilot study. Pituitary. abril de 2014;17(2):150–6.  
95. Weintraub D, Koester J, Potenza MN, Siderowf AD, Stacy M, Voon V, et al. Impulse control disorders in Parkinson disease: a cross-sectional study of 3090  patients. Arch Neurol. maio de 2010;67(5):589–95.  
96. Kars M, Delgado V, et al. Aortic valve calcification and mild tricuspid regurgitation but no clinical heart disease after 8 years of dopamine agonist therapy for prolactinoma. Clin Endocrinol. 2016;85:681-688.  
97. Vallette S, Serri K, Rivera J, Santagata P, Delorme S, Garfield N, et al. Long-term cabergoline therapy is not associated with valvular heart disease in patients with prolactinomas. Pituitary. 2009;12(3):153- 7.  
98. Giustina A, Uygur MM, Frara S, Barkan A, Biermasz NR, Chanson P, et al. Pilot study to define criteria for Pituitary Tumors Centers of Excellence  (PTCOE): results of an audit of leading international centers. Pituitary. outubro de 2023;26(5):583–96.  
19

---

<!-- METADADOS: doenca: Acromegalia | secao: **OCTREOTIDA, LANREOTIDA, CABERGOLINA E PASIREOTIDA** -->
Eu, ______________________________________________________________________________________ (nome do (a) paciente), declaro ter sido informado (a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **octreotida, lanreotida, cabergolina** e **pasireotida** , indicadas para o tratamento da acromegalia. Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) _______________________________________________________________________________________________ (nome  
do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas e redução das complicações.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Os riscos do uso de octreotida, lanreotida, pasireotida e cabergolina para o bebê durante a gestação são improváveis;  
- entretanto, o uso desses medicamentos como rotina não é recomendado e não deve ser utilizado sem orientação médica;  
- **eventos adversos mais comuns da octreotida** : reações locais (dor ou sensação de picada, formigamento ou queimação no local da injeção, com vermelhidão e inchaço); náusea, vômitos, dor abdominal, gases, diarreia, fezes gordurosas; uso prolongado do medicamento: alopecia; formação de cálculos (pedras) na vesícula, problemas no fígado e pâncreas;  
- **eventos adversos mais comuns da lanreotida:** dores de cabeça, cansaço, tonturas, diminuição dos batimentos do coração, alteração do açúcar do sangue, falta de apetite, diarreia ou fezes moles, dor de barriga, enjoos, vômitos, problemas de digestão, gases, pedras na vesícula, aumento da bilirrubina, reações no local da injeção; outros efeitos: reação alérgica na pele/alopecia, queda de cabelos, agravamento do diabete, pancreatite aguda, presença de gordura nas fezes;  
- **eventos adversos mais comuns da cabergolina:** náusea, dor abdominal, dor de cabeça, tontura, dor no estômago, azia/gastrite, fraqueza e cansaço, prisão de ventre, vômitos, dor no peito, vermelhidão, depressão e cãibras; raramente pode ocasionar desmaios;  
- **eventos adversos mais comuns da pasireotida** : diarreia, dor abdominal, alopecia, formação de cálculos (pedras) na  
- vesícula, hiperglicemia e diabete melito.  
- São medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da  
- fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- ( ) Sim ( ) Não  
Meu tratamento constará do seguinte medicamento:  
- ( ) octreotida  
- ( ) lanreotida  
- ( ) cabergolina  
- ( ) pasireotida  
20  
<!-- Start of picture text -->
Local:                                                                                                      Data:<br>Nome do paciente<br>Cartão Nacional de Saúde:<br>Documento de identificação do responsável legal:<br>______________________________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:                                                               CRM:                           UF:<br>______________________________________________________<br>Assinatura e carimbo do médico<br>Data: _______________<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
21

---

<!-- METADADOS: doenca: Acromegalia | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Acromegalia, contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo EconômicoIndustrial da Saúde do Ministério da Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse e confidencialidade, os quais foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo. Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para elaboração de PCDT.  
A elaboração deste documento foi iniciada em 11 de julho de 2023 com a realização de uma reunião de escopo, a qual definiu as perguntas de pesquisa desse documento. Definiu-se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
A dinâmica da reunião foi conduzida com base no PCDT publicado por meio da Portaria SAS/MS nº 1.149, de 11 de novembro de 2015 e na estrutura de PCDT definida pela Portaria SAS/MS nº 375, de 10 de novembro de 2009.  
Cada seção do PCDT foi discutida entre o Grupo Elaborador e demais participantes da reunião de escopo, com o objetivo principal de revisar as condutas diagnósticas e identificar tecnologias em saúde que poderiam ser consideradas nas recomendações do Protocolo.  
Em uma reunião de priorização de tecnologias, realizada no dia 31 de julho de 2023, foram estabelecidas as questões de pesquisa relativas ao tratamento, referentes aos medicamentos pegvisomanto e pamoato de pasireotida.

---

<!-- METADADOS: doenca: Acromegalia | secao: Colaboração externa -->
O Protocolo foi atualizado pelo UATS do Hospital Alemão Oswaldo Cruz.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT da Acromegalia foi apresentada na 122ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 28 de janeiro de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 140ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
22

---

<!-- METADADOS: doenca: Acromegalia | secao: **3. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO **(Figura A)** .  
**Figura A** - Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
PP *Populacdo ou condic¢do clinica<br>*Intervengdo,*Fator*Teste deindice, exposic¢do, nosno caso casos em de de casoestudos estudos de estudosexperimentais de acurdcia observacionaisdiagndstica |<br>Controle,disponiveis de acordo no SUS  com tratamento/niveis de exposicdo do fator/exames |<br>*Desfechos: sempre que possivel, definidosa priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Durante a reunião de escopo deste PCDT duas questões de pesquisa foram definidas.

---

<!-- METADADOS: doenca: Acromegalia | secao: **QUESTÃO 1: A pasireotida é eficaz, efetiva e segura para o tratamento de adultos e adolescentes com gigantismo/acromegalia com tumor após cirurgia e sem resposta a análogos da somatostatina de primeira geração?** -->
**Recomendação** : Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS do pamoato de pasireotida para o tratamento de pacientes com acromegalia, conforme Protocolo Clínico do Ministério da Saúde. conforme Relatório de Recomendação nº 904/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/pamoato-de-pasireotidapara-o-tratamento-de-pacientes-com-acromegalia.  
A estrutura PICO para esta pergunta foi:  
População: 1. Pacientes com acromegalia, com tumor após cirurgia e sem resposta a análogos da somatostatina de primeira geração; 2. Pacientes adolescentes com gigantismo/acromegalia, com tumor após cirurgia e sem a normalização de IGF-I após seis meses sem resposta aos análogos de somatostatina (ou otimização de dose ou associação com cabergolina) (portanto, indicação offlabel).  
Intervenção: pasireotida em monoterapia  
Comparador: tratamento padrão (lanreotida/octreotida/cabergolina) ou placebo  
Desfechos: tamanho tumoral, controle níveis IGF-I, controle de níveis de GH, qualidade de vida e melhora de sintomas (apneia do sono, DM, HAS, sudorese, edema de tecidos moles e redução de características da acromegalia).  
Desenhos de estudo: ECR, estudos observacionais comparativos e revisões sistemáticas com meta-análise Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 904/2024  
da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 2: O pegvisomanto, em monoterapia ou combinado com octreotida, lanreotida ou cabergolina, é eficaz, efetivo e seguro para o tratamento de adultos e adolescentes com gigantismo/acromegalia sem tumor ou com remanescentes tumorais que apresentaram resposta inadequada à cirurgia e para aqueles pacientes cujo tratamento**  
23  
**medicamentoso apropriado com análogos da somatostatina não normalizou as concentrações séricas de IGF-1 ou não foi tolerado?**  
**Recomendação** : Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS do pegvisomanto para o tratamento de indivíduos com acromegalia. Conforme Relatório de Recomendação nº 903/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-903-pegvisomanto-para-o-tratamentode-individuos-com-acromegalia  
A estrutura PICO para esta pergunta foi:  
**População** : i) pacientes adultos com acromegalia, sem tumor ou remanescentes tumorais que apresentaram resposta inadequada à cirurgia e para aqueles pacientes cujo tratamento médico apropriado com análogos da somatostatina não normalizou as concentrações séricas de IGF-I ou não foi tolerado. ii) pacientes adolescentes com gigantismo/acromegalia, sem tumor ou remanescentes tumorais, sem a normalização de IGF-I após 6 meses sem resposta aos análogos de somatostatina (otimização de dose ou associação com cabergolina).  
**Intervenção** : i) pegvisomanto em monoterapia. ii) pegvisomanto combinado a octreotida, lanreotida ou cabergolina.  
**Comparador** : tratamento padrão (octreotida/lanreotida/cabergolina) ou placebo  
**Desfechos** : controle dos níveis IGF-I, controle de níveis de GH, segurança e qualidade de vida e melhora de sintomas  
(apneia do sono, DM, HAS, sudorese, edema de tecidos moles e redução de características da acromegalia).  
**Desenhos de estudo** : ECR, estudos observacionais comparativos e revisões sistemáticas com meta-análise Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 903/2024  
da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
24  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Acromegalia | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório da**||**Tecnologias avalia**|**das pela Conite**|**c**|
|---|---|---|---|---|
|**diretriz clínica (Conitec) ou**<br>**Portaria de Publicação**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não incorpora**<br>**alteração**|**ção ou não**<br>**no SUS**|
|Relatório de Recomendação nº<br>1005/2025|Atualização do PCDT, com<br>inclusão<br>de<br>pamoato<br>de<br>pasireotida|Incorporação de pamoato de<br>pasireotida<br>[Relatório<br>de<br>Recomendação nº 904/2024;<br>Portaria SECTICS/MS nº 25,<br>de 21 de junho de 2024]|Não<br>incorpo<br>pegvisomanto [<br>Recomendação<br>903/2024;<br>SECTICS/MS<br>de junho de 202|ração<br>de<br>Relatório de<br> <br>nº<br>Portaria<br>nº 23, de 17<br>4]|
|Portaria<br>Conjunta<br>SAS-<br>SCTIE/MS nº 2, de 7 de janeiro<br>de<br>2019<br>[Relatório<br>de<br>Recomendação nº 414/2019]|Atualização de conteúdo|-|Não<br>incorpo<br>pegvisomanto<br>Técnico<br>nº<br>Portaria SCTIE<br>de 29 de março|ração<br>de<br>[Relatório<br>348/2018;<br>/MS nº 14,<br>de 2018]|
||||Não<br>incorpo|ração<br>de|
|Portaria SAS/MS nº 199, de 25<br>de fevereiro de 2013|Atualização de conteúdo|-|pegvisomanto<br>Técnico<br>nº<br>Portaria SCTIE<br>17 de janeiro de|[Relatório<br>18/2013;<br>/MS nº 1, de<br>2013]|
|Portaria SAS/MS nº 471, de 23<br>de julho de 2002|Primeira versão do Protocolo|-|-||  
25

---

