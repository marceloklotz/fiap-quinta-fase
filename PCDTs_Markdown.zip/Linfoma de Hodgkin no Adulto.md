<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: Geral -->
MINITÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 24, de 29 de dezembro de 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Linfoma de Hodgkin no Adulto.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS, no uso das atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o linfoma de Hodgkin no adulto no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 523/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 543 – Julho de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Linfoma de Hodgkin no Adulto.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral do linfoma de Hodgkin no adulto, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do linfoma de Hodgkin no adulto.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: HÉLIO ANGOTTI NETO -->
**ANEXO**  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS LINFOMA DE HODGKIN NO ADULTO

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **1. INTRODUÇÃO** -->
O linfoma de Hodgkin é uma neoplasia linfoproliferativa definida pela multiplicação clonal de células com padrão morfológico e imunofenotípico peculiar, conhecidas como células de Reed-Sternberg, derivadas da transformação maligna de linfócitos B do centro germinativo. Habitualmente, as células de Reed-Sternberg representam apenas 1%-2% da massa tumoral do tecido afetado e encontram-se rodeadas por uma população heterogênea de células reacionais não neoplásicas constituída principalmente por linfócitos T e B maduros, granulócitos, histiócitos e fibroblastos<sup>1</sup> .  
O linfoma de Hodgkin corresponde a aproximadamente 10% de todos os linfomas e a cerca de 0,6% de todos os cânceres<sup>2</sup> . De acordo com os dados do Instituto Nacional de Câncer (INCA), para cada ano do biênio 2018/2019 estimou-se que fossem diagnosticados 2.530 novos casos de linfoma de Hodgkin (1.480 em homens e 1.050 em mulheres) no Brasil<sup>3</sup> .  
A incidência do linfoma de Hodgkin apresenta distribuição etária bimodal, com o primeiro pico no final da adolescência e início da idade adulta jovem e o segundo pico em idosos. No entanto, a distribuição das idades dos pacientes varia de acordo com o subtipo histopatológico<sup>2,4</sup> . As incidência e distribuição dos subtipos de linfoma de Hodgkin também sofrem a influência de fatores geográficos, socioeconômicos e de exposição a infecção pelo vírus HIV. Embora o vírus Epstein-Barr (EBV) tenha sido associado à patogênese da doença, a detecção do genoma viral só é demonstrada em um subconjunto dos casos, sendo considerado muito pequeno o risco absoluto de desenvolver linfoma de Hodgkin após infecção por EBV<sup>5</sup> .  
Com a evolução do conhecimento sobre a doença e o desenvolvimento de novas modalidades de tratamento, desde o último século, o linfoma de Hodgkin deixou de ser uma enfermidade uniformemente fatal para se transformar em uma doença curável em aproximadamente 75% dos pacientes, em todo o mundo. O tratamento do linfoma de Hodgkin evoluiu de tal forma que pacientes com doença em estágio inicial podem ser curados ou alcançar remissão de longo prazo com terapia menos intensiva, reservando-se  
as formas mais intensas de terapia para aqueles pacientes com doença em estágio avançado<sup>6</sup> .  
Nos dias atuais, a terapêutica do linfoma de Hodgkin consiste de quimioterapia, anticorpos monoclonais, radioterapia e o transplante de células-tronco hematopoéticas. Essas modalidades terapêuticas podem ser utilizadas de maneira isolada ou combinada, e a escolha do melhor tratamento deve levar em conta o tipo histopatológico (clássico ou predomínio linfocítico nodular), o estadiamento clínico, os fatores prognósticos (fatores de risco) e a fase da doença (inicial ou recidivada)<sup>6</sup> . Contudo, tendo em vista que a maioria dos pacientes passou a ser curada, os efeitos tóxicos relacionados ao tratamento tornaramse uma causa preocupante de morbimortalidade tardia. Como tal, a seleção da terapia deve equilibrar o desejo de manter uma alta taxa de cura e a necessidade de minimizar as complicações a longo prazo<sup>7</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do linfoma de Hodgkin. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
Segundo a Organização Mundial da Saúde (OMS), o linfoma de Hodgkin é classificado em dois grupos: “linfoma de Hodgkin clássico” (que corresponde a aproximadamente 90% dos casos) e “linfoma de Hodgkin de predomínio linfocitário nodular”. O linfoma de Hodgkin clássico ainda pode ser subdividido em quatro subtipos: o “esclerose nodular” é o mais comum, representando de 70% a 80% dos 10% dos casos; o “celularidade mista” é o segundo subtipo mais comum (15% dos casos); e os subtipos ricos em linfócitos e esgotados de linfócitos são menos comuns<sup>8</sup> .  
Dado que a CID-11 entrará em vigor a partir de janeiro de 2022, até dezembro de 2021 a codificação do linfoma de Hodgkin continuará a ser feita com os códigos da categoria C81 da CID-10– Doença de Hodgkin ( **Quadro 1** ).  
**Quadro 1 –** Códigos e subtipos de linfoma de Hodgkin na CID-10  
|**CID**|**Descrição**|
|---|---|
|C81.0|Doença de Hodgkin, predominância linfocítica (predominância<br>linfocítica-histocítica)|
|C81.1|Doença de Hodgkin, esclerose nodular|
|C81.2|Doença de Hodgkin, celularidade mista|
|C81.3|Doença de Hodgkin, depleção linfocítica|
|C81.7|Outra forma da doença de Hodgkin|
|C81.9|Doença de Hodgkin, não especificada|

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.1. Diagnóstico clínico** -->
A maioria dos pacientes se apresenta com doença nodal, ou seja, exclusiva ou predominantemente acometendo linfonodos. Na expressiva maioria dos casos, o linfoma de Hodgkin se inicia com linfonodomegalia progressiva na região supradiafragmática, particularmente nas regiões laterais do pescoço. É incomum que o linfoma se apresente isoladamente na região infradiafragmática, tanto intra-abdominal, quanto inguinal. A apresentação infradiafragmática exclusiva, por razões ainda desconhecidas, implica em pior prognóstico. Por isso, a cuidadosa palpação de todas as regiões linfonodais periféricas é muito relevante para o prognóstico dos casos<sup>9</sup> .  
Na maioria das vezes, pode-se palpar linfonodos na região cervical, mas, também dependendo da extensão da doença, linfonodos supra- e infraclaviculares, axilares e inguinais podem mostrar-se aumentados. As características palpatórias geralmente diferem das doenças inflamatórias ou infecciosas (amolecidos e dolorosos) e de metástases de tumores sólidos (muito endurecidos). No linfoma de Hodgkin, os linfonodos costumam ser indolores e de consistência fibroelástica (consistência de borracha) e não fistulam, como pode ocorrer em algumas infecções, como a tuberculose<sup>9,</sup> 10.  
Embora seja mais comum o acometimento de linfonodos regionais, o linfoma de Hodgkin também pode acometer locais extranodais, por invasão direta ou hematogênica,  
como o baço, fígado, pulmões e medula óssea. Há também os linfonodos internos, que muitas vezes, são identificados mais tardiamente, por não poderem ser detectados ao exame físico. Quando ocorre um crescimento insidioso destes linfonodos, ou seja, quando são assintomáticos _per se_ , mesmo que volumosos, pode ocorrer compressão de estruturas adjacentes como as vias aéreas e a veia cava superior, ocasionando tosse, dispneia ou manifestações da síndrome de compressão da veia cava superior<sup>10</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.2. Sinais e sintomas** -->
Diversos sinais e sintomas podem ser observados em cerca de 40% dos casos de linfoma de Hodgkin, particularmente nos estágios avançados. Os sinais mais significativos são: febre acima de 38ºC, perda de peso nos últimos seis meses maior que 10% do peso habitual e sudorese profusa à noite. Estes três, chamados de sintomas constitucionais, são os mais frequentes e têm relevância, pois, quando presentes, têm impacto prognóstico negativo. Em um país de clima tropical, como o Brasil, é importante analisar adequadamente a sudorese noturna. Em caso de linfoma de Hodgkin, trata-se de sudorese intensa, que frequentemente molha a roupa, diferente das que o paciente possa ter experimentado anteriormente durante a sua vida<sup>9</sup> .  
Tosse e dispneia podem estar presentes, particularmente quando há acometimento de linfonodos mediastinais. Fadiga e prurido são outros dois sintomas que podem ser observados. O prurido é uma manifestação que deve ser considerado no diagnóstico diferencial e, quando persistente, aumenta a dificuldade de tratamento com componente imunoalérgico<sup>9, 10</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.3. Diagnóstico histopatológico** -->
O diagnóstico histopatológico deve ser expresso de acordo com a classificação da Organização Mundial da Saúde (OMS), a partir de uma biópsia excisional (retirada completa) de linfonodo suspeito ou de biópsia incisional, devendo o material obtido ser congelado e fixado em formalina. A biópsia excisional de um linfonodo para exame histopatológico com imuno-histoquímica é o procedimento padrão para o diagnóstico<sup>11</sup> .  
Ressalta-se que este procedimento deve ser realizado por cirurgião treinado e ciente da importância da obtenção de material representativo e adequado. Sempre que possível, é conveniente haver contato prévio do médico assistente com o cirurgião, para reforço destas recomendações e para a escolha, em comum acordo, do linfonodo a ser  
biopsiado. Por ser uma região mais sujeita a infecções locais, a biópsia de linfonodo inguinal deve ser evitada<sup>12</sup> .  
As amostras obtidas por aspiração por agulha fina ou por biópsia com agulha grossa ( _core biopsy_ ) são geralmente inadequadas porque muitas vezes não removem o material suficiente para um diagnóstico definitivo e, portanto, impedem um diagnóstico preciso. A biópsia com agulha grossa dirigida por exame de imagem, apesar de menos frequentemente, pode ser usada nos casos de linfonodos internos e de difícil acesso<sup>13, 14</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.4. Avaliação laboratorial após diagnóstico histopatológico** -->
Com base nos achados histopatológicos e imuno-histoquímicos, no linfoma de Hodgkin clássico (LHc) a presença de células de Hodgkin e Reed-Sternberg (HRS) é definidora de doença, enquanto a detecção de células predominantes de linfócitos (PL) é necessária para o diagnóstico de linfoma de Hodgkin de predomínio linfocítico nodular (LHPLN)<sup>4, 11</sup> .  
Tipicamente, as células de Reed-Sternberg possuem pelo menos dois nucléolos em lobos nucleares separados e o imunofenótipo se caracteriza pela expressão de CD30 (100% dos casos) e CD15 (75%-85% dos casos), sendo negativo para CD45. O imunofenótipo das células malignas no LHc e LHPLN difere significativamente. Ao contrário das células HRS que apresentam manchas consistentemente positivas para CD30 e CD15, ocasionalmente positivas para CD20 e negativas para CD45, as células PL são caracterizadas pela expressão de CD20 e CD45, mas carecem de CD15 e CD30<sup>11</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.5. Exames de imagem** -->
A Tomografia Computadorizada por Emissão de Pósitrons (do inglês, _Positron Emission Tomography – Computed Tomography_ - PET-CT) de corpo inteiro é o exame considerado padrão ouro para a avaliação inicial de pacientes com linfoma de Hodgkin. A PET-CT deve ser realizada de acordo com critérios para estadiamento e avaliação da resposta terapêutica em caso de linfoma<sup>15</sup> .  
Se a PET-CT não estiver disponível para o exame de diagnóstico, uma radiografia simples de tórax e uma tomografia computadorizada (TC) com contraste do pescoço, tórax e abdômen, assim como uma biópsia da medula óssea podem ser solicitados<sup>9, 16</sup> . Dada a alta sensibilidade da PET-CT para o acometimento da medula óssea, uma biópsia da medula óssea não é indicada em pacientes submetidos à avaliação por PET-CT<sup>9, 16, 17</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.6. Outros exames** -->
Os seguintes exames complementares são considerados essenciais na avaliação inicial do paciente com linfoma de Hodgkin<sup>6</sup> :  
- <mark>Hemograma completo e contagem de plaquetas;</mark>  
- <mark>determinação da velocidade de hemossedimentação (VHS);</mark>  
- <mark>avaliação metabólica, incluindo a dosagem de proteína C reativa (PCR), fosfatase alcalina (FA), lactato desidrogenase (LDH), enzimas hepáticas e albumina;</mark>  
- <mark>exame sorológico para hepatites B e C, HIV e sífilis;</mark>  
- <mark>rastreamento da hepatite B (HBV) e de infecção latente por tuberculose (ILTB)</mark><sup>18</sup> <mark>;</mark>  
- teste para gravidez – dosagem de gonadotrofina coriônica βHCG (em mulheres em <mark>idade fértil);</mark>  
- <mark>outros exames, como provas de função pulmonar e ecocardiograma, devem ser considerados na dependência do perfil patológico e de risco do paciente e do tratamento proposto, antes de este ser iniciado.</mark>  
Como a quimioterapia e a radioterapia abdominal podem causar infertilidade permanente, deve ser oferecido a pacientes em idade reprodutiva o planejamento reprodutivo<sup>6</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.7. Estadiamento** -->
O estadiamento do linfoma de Hodgkin pode ser realizado de acordo com a classificação de Ann Arbor, que classifica os pacientes em quatro estágios, conforme representado no **Quadro 2**<sup>19</sup> . <mark>Os estádios de um a três indicam o grau de acometimento linfonodal, enquanto o estádio quatro é indicativo de acometimento disseminado de órgãos, que pode ser encontrado em 20% dos casos</mark> . Esta classificação também subdivide os pacientes de acordo com a presença de sintomas sistêmicos, como A ou B, respectivamente de acordo com a ausência ou presença de febre, sudorese noturna ou emagrecimento (perda de > 10% do peso corporal em 6 meses)<sup>19</sup> .  
**Quadro 2 -** Classificação de Ann Arbor/Costwolds modificado  
**Classificação de Ann Arbor/Cotswolds modificado**<sup>**19**</sup>  
- **<u>Estádio I</u>** <u>: acometimento de uma cadeia linfonodal ou estrutura linfoide (baço,</u> timo, anel de Waldeyer) ou sítio extra linfático (IE);  
- **<u>Estádio II</u>** <u>: acometimento de duas ou mais cadeias linfonodais localizadas no</u> mesmo lado do diafragma, que pode ter contiguidade com um local extra linfático (IIE);  
- **<u>Estádio III</u>** <u>: acometimento de cadeias linfonodais em ambos os lados do</u> diafragma, que pode estar associado a um local extra linfático (IIIE) ou acometimento do baço (IIIS), ou ambos (IIIES);  
- **<u>Estádio IV</u>** <u>: acometimento disseminado de um ou mais órgãos extra linfáticos,</u> ou ainda acometimento de um local extra linfático com acometimento linfonodal à distância.  
**A** : Ausência de sintomas sistêmicos.  
**B** : Presença de sintomas sistêmicos (febre, sudorese noturna ou perda de peso). **X** : Quando a massa linfonodal é ≥ 10 cm ou ocupa um diâmetro superior a 1/3 da caixa torácica.  
Outra opção para proceder ao estadiamento é utilizar a classificação de Lugano, que incorpora o exame de tomografia computadorizada por emissão de pósitrons (PETCT) no estadiamento inicial e na avaliação da resposta terapêutica. Este exame é a melhor técnica de imagem para confirmar o acometimento esplênico em pacientes com linfoma de Hodgkin. Os achados positivos na PET-CT incluem captação difusa, massa solitária, lesões miliares ou nódulos, e, na tomografia computadorizada, aumento maior do que 13 cm na medida craniocaudal da lesão ou presença de massa ou nódulos que não são císticos nem vasculares. Semelhante à avaliação para confirmação do acometimento esplênico, a PET-CT é indicada para a avaliação do acometimento hepático, e a captação difusa ou aumentada ou focal, com ou sem nódulos focais ou disseminados, confirma esse acometimento<sup>9</sup> .  
Com a incorporação deste exame no sistema de classificação, há simplificação da avaliação de acometimento linfonodal, e de órgãos, incluindo fígado ou baço, além de não ser necessária realização de biópsia de medula para o estadiamento ( **Quadro 3** ).  
**Quadro 3 -** Classificação de Lugano.  
**Classificação de Lugano**<sup>**9**</sup>

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **Doença Localizada** -->
- **<u>Estádio I</u>** <u>: acometimento de um sítio linfonodal.</u>  
- **<u>Estádio IE</u>** <u>: acometimento de um sítio extra nodal na ausência de acometimento</u> nodal.  
- **<u>Estádio II</u>** <u>: acometimento de duas ou mais regiões linfonodais localizadas no</u> mesmo lado do diafragma.  
- **<u>Estádio IIE</u>** <u>: acometimento de um sítio extra nodal por contiguidade com ou</u> sem acometimento de outras regiões linfonodais no mesmo lado do diafragma.  
- **<u>Estádio II</u>** **_<u>bulky</u>_**<sup>**a**</sup> : estádio II com a presença de grande massa.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **Doença Avançada** -->
- **<u>Estádio III</u>** <u>: acometimento de regiões linfonodais em ambos os lados do</u> diafragma; linfonodos acima do diafragma com acometimento esplênico  
- **<u>Estádio IV</u>**<sup>**b**</sup> : acometimento difuso ou disseminado de um ou mais órgãos extra nodais, com ou sem acometimento de linfonodo associado; ou acometimento de órgão extra nodal não contíguo em conjunto com doença nodal estádio II ou qualquer acometimento de órgão extra nodal na doença nodal estádio III.  
> **a** Estádio II _bulky_ - pode ser considerado doença localizada ou avançada, com base na histologia do linfoma e em fatores prognósticos.  
> **b** Estádio IV inclui qualquer acometimento do líquido cefalorraquidiano, medula óssea, fígado ou múltiplas lesões pulmonares.  
De acordo com a classificação de Lugano, a doença volumosa em caso de linfoma de Hodgkin ocorre quando há uma única massa nodal de 10 centímetros ou maior do que um terço do diâmetro transtorácico, em qualquer nível das vértebras torácicas, determinado por uma tomografia computadorizada. O termo “X” não é mais utilizado nesta classificação. Os pacientes continuam a receber as designações A ou B na classificação de Lugano, pois determinar a ausência ou presença de sintomas constitucionais é importante para definir o tratamento, principalmente naqueles pacientes com doença localizada<sup>9</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.8. Definição de grupo de risco** -->
Nos últimos anos, vários grupos de especialistas desenvolveram índices ou escores prognósticos, na tentativa de identificar grupos de riscos que permitissem condutas terapêuticas adaptadas ao risco. A Organização Europeia para a Pesquisa e o Tratamento do Câncer ( _European Organization for Research and Treatment of Cancer_ - EORTC), o Grupo de Estudo Alemão do Linfoma de Hodgkin ( _German Hodgkin’s Lymphoma Study Group_ - GHSG), assim como a Rede Nacional Abrangente de Câncer ( _National Comprehensive Cancer Network_ – NCCN) classificam os pacientes com linfoma de Hodgkin em três grupos de risco<sup>20-22</sup> :  
- Doença localizada sem fatores de riscos ou favorável;  
- Doença localizada com fatores de riscos ou desfavorável; e  
- Doença avançada.  
Os grupos são definidos de acordo com o estádio da doença e outros fatores prognósticos, como, por exemplo, o número de áreas linfonodais, a velocidade de hemossedimentação (VHS), o acometimento extranodal e a presença de massa mediastinal ( **quadros 4 e 5** ).  
**Quadro 4 -** Fatores de risco para estratificação de grupos de risco  
|**Fatores de**<br>**risco**|**GHSG**|**EORTC**|**NCCN**|
|---|---|---|---|
|**Idade**|-|≥ 50 anos|-|
|**VHS**<br>**e**<br>**sintomas B**|VHS > 50 mm/h sem<br>sintomas B<br>VHS > 30 mm/h<br>com sintomas B|VHS > 50 mm/h sem<br>sintomas B<br>VHS > 30 mm/h com<br>sintomas B|VHS ≥ 50 mm/h<br>ou presença de<br>sintomas B|
|**Massa**<br>**mediastinal**|RMM > 0,33|RTM > 0,35|RMM > 0,33|
|**Áreas**<br>**linfonodais**|> 2<sup>*</sup>|> 3<sup>*</sup>|> 3|  
|**Acometimento**<br>**extranodal**|Qualquer|-<br>-|
|---|---|---|
|**Grande massa**|-|-<br>>10cm|  
**GHSG–** _German Hodgkin’s Lymphoma Study Group_  
**EORTC–** _European Organization for Research and Treatment of Cancer_  
**NCCN** – _National Comprehensive Cancer Network_  
**RMM–** razão da massa mediastinal: largura máxima da massa / diâmetro intratorácico máximo  
**RTM –** razão torácica mediastinal: largura máxima da massa mediastinal / diâmetro intratorácico em T5-6  
**Sintomas B –** sintomas sistêmicos (febre, sudorese noturna, perda de peso)  
**VHS –** velocidade de hemossedimentação  
***** Vide o **Quadro 5** .  
O **Quadro 5** sintetiza as regiões linfonodais segundo sistema de estadiamento, grupos ou organizações dedicados à oncologia.  
**Quadro 5 -** Definição das regiões linfonodais  
|**Regiões linfonodais**|**Ann Arbor**|**EORTC**|**GHSG**|
|---|---|---|---|
|**Cervical/SCL direito**||||
|**ICL/subpeitoral direito**||||
|**Axilar direito**||||
|**Cervical/SCL esquerdo**||||
|**ICL/subpeitoral**<br>**esquerdo**||||
|**Axilar esquerdo**||||  
|**Mediastino**|||
|---|---|---|
|**Hilo direito**|||
|**Hilo esquerdo**|||
|**Total**|9|5<br>5|  
**GHSG** - Grupo de Estudo Alemão do Linfoma de Hodgkin  
**EORTC** - Organização Europeia para a Pesquisa e o Tratamento do Câncer **SCL** – supraclavicular;  
**ICL** - infraclavicular

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **<u>Nota:</u>** -->
As áreas linfonodais, nos critérios estabelecidos pelo grupo alemão (GHSG) e pelo grupo europeu (EORTC), não correspondem às regiões linfonodais da classificação de Ann Arbor nem da classificação de Lugano, pois uma área linfonodal pode corresponder a várias regiões linfonodais. No GHSG, a região infraclavicular é incluída juntamente com a região cervical e supraclavicular ipsilateral; os linfonodos hilares são incluídos juntamente com os do mediastino; e o abdome é dividido em duas regiões: superior (hilo esplênico, hilo hepático e celíaco) e inferior.  
Outro tipo de estratificação de risco prognóstico para pacientes com linfoma de Hodgkin é o Escore Prognóstico Internacional (IPS), que foi proposto desde 1998 e tem sido utilizado em alguns centros assistenciais para ajudar na escolha de um tratamento mais intensivo, principalmente para pacientes com pior prognóstico<sup>23</sup> .  
O IPS foi desenvolvido a partir da análise de dados clínicos e laboratoriais, formado por 25 instituições e com a participação de 5.141 pacientes com linfoma de Hodgkin em estágio avançado<sup>23</sup> . Sete fatores foram relacionados a uma menor sobrevida:  
- Sexo masculino;  
- idade superior a 45 anos;  
- estádio IV;  
- albumina sérica inferior a 4,0 g/dL;  
- hemoglobina inferior a 10,5 g/dL;  
- contagem de linfócitos inferior a 600/mm<sup>3</sup> ou inferior a 8% do total de leucócitos;  
- contagem de leucócitos acima de 15.000/mm<sup>3</sup> .  
Para interpretar o IPS, um escore igual a 3 fatores classifica como risco moderadamente alto e representa uma sobrevida livre de progressão de 55% e sobrevida global de 70% em 5 anos. Um escore maior ou igual a 4, representa um risco alto, pelo qual a sobrevida livre de progressão e a sobrevida global em 5 anos são de 47% e 59%, respectivamente. Em síntese, cada fator adicional, destes apresentados acima diminui a sobrevida livre de progressão em aproximadamente 8%<sup>23</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes adultos (19 ou mais anos) com diagnóstico de linfoma de Hodgkin.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos aqueles pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso do respectivo medicamento ou procedimento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6. TRATAMENTO** -->
O tratamento do linfoma de Hodgkin tem sido modificado com o objetivo de se reduzir os efeitos tóxicos a ele relacionados e adaptando ao risco de cada paciente, principalmente com mudanças na radioterapia, com o uso de antineoplásicos com um melhor perfil de toxicidade e a busca de terapias alvo (anticorpos monoclonais e os inibidores _checkpoint_ ). Questões terapêuticas relacionadas ao melhor esquema terapêutico, ao número ideal de ciclos de quimioterapia e à dose ideal de radioterapia devem ser definidas pela equipe médica dos hospitais habilitados em oncologia, que possuem autonomia na escolha da melhor opção para cada situação clínica, com base nas melhores evidências científicas disponíveis.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.1. Principais esquemas de tratamento da forma clássica do Linfoma de Hodgkin** -->
A quimioterapia e a radioterapia são os principais tratamentos dos pacientes com linfoma de Hodgkin clássico. Dependendo da fase da doença (inicial, intermediária ou  
avançada) e dos fatores prognósticos associados, há variações quanto a dose, o número de ciclos de quimioterapia e a combinação de medicamentos antineoplásicos prescritos.  
O esquema terapêutico mais comum para tratar o linfoma de Hodgkin é uma combinação de quatro medicamentos denominado pela sigla ABVD (Doxorrubicina + Bleomicina + Vimblastina + Dacarbazina)<sup>24</sup> .  
Para os pacientes com doença localizada desfavorável ou com doença avançada, uma outra combinação de medicamentos antineoplásicos é mais indicada: o BEACOPP. Este esquema é mais intenso e apresenta maior toxicidade aguda, só devendo ser utilizado por profissionais com experiência, em locais com cuidados de suporte apropriados e para pacientes bem selecionados (IPS ≥ 3 e idade < 60 anos)<sup>25</sup> .  
No BEACOPP, há uma variante que é formada pelos mesmos medicamentos, porém com doses intensificadas e denominada BEACOPP escalonado ( **Figura 1** ), com base na hipótese de que a resistência tumoral pode ser evitada pela administração de doses altas de quimioterápicos em rápida sucessão<sup>25</sup> .  
<!-- Start of picture text -->
ABVD BEACOPP Padrao BEACOPP Escalonado<br>* A-doxorrubicina* * Bleomicina 10 UI /m? *  Bleomicina 10 UI /m?<br>25 mg/m? D1 e D15 IV D8 IV D8 IV<br>* Bleomicina 10 UI /m2 * Etoposideo 100 mg /m? * Etoposideo 200 mg /m?<br>Die D15 IV D1laD3IV Dia D3 IV<br>* Vimblastina 6 mg/m? * A-doxorrubicina* * A-doxorrubicina*<br>Die D151IV 25 mg/m? D1IV 35 mg/m? D1IV<br>*  Dacarbazina 375 mg /m *  Ciclofosfamida *  Ciclofosfamida<br>Die D151IV 650mg/m? D1 IV 1250 mg/m? D1IV<br>* O-vincristina* * O-vincristina*<br>1,4 mg/m? DB IV 1,4 mg/m? D8 IV<br>(max.: 2 mg) (méax.: 2 mg)<br>*  Procarbazina 100 mg * Procarbazina 100 mg<br>/m? D1aD7 VO /m? D1 aD7 VO<br>*  Prednisona 40mg/m? *  Prednisona 40mg/m2<br>D1laD14VO D1aD14VO<br>* G-CSF a partir do D8 SC * G-CSF a partir do D8 SC<br>doxorrubicina*A correspondereferénciaa inicial doquandonome comercial0 protocolo da comerciais*A © O correspondemdos medicamentosas iniciais dosreferéncianomes comerciais“A € © correspondemdos medicamentosas iniciais dosreferéncia nomes<br>fol estabelecido. quando 0 protocolo fol estabelecido. quando 0 protocolo fol estabelecid.<br><!-- End of picture text -->  
**Figura 1 -** Principais esquemas de tratamento do linfoma de Hodgkin<sup>26-28</sup>

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.2. Tratamento de doença recaída ou refratária** -->
Apesar de uma alta probabilidade de sucesso com o tratamento de primeira linha, cerca de 10% dos pacientes com linfoma de Hodgkin desenvolvem doença recaída ou refratária. Doença refratária é definida como não resposta ou progressão durante o a quimioterapia ou dentro de 90 dias após o término do tratamento, enquanto a doença recorrente ou recidivada é definida como o seu reaparecimento no local anterior da doença ou em novos locais após resposta completa ao tratamento inicial<sup>24</sup> .  
As opções de tratamento com maior taxa de sobrevida para estes pacientes é a prescrição de altas as doses de quimioterapia, utilizando esquemas de poliquimioterapia à base de platina, como ICE ( **I** fosfamida, **C** arboplatina e **E** toposídeo) ou DHAP ( **D** exametasona, **C** itarabina e **C** isplatina)<sup>29,30</sup> , seguidos por um transplante de célulastronco hematopoéticas (TCTH), caso o paciente apresentar condições de a ele se submeter<sup>31</sup> . Pacientes com recidivas após o TCTH devem ser tratados com brentuximabe vedotina (BV), anticorpo monoclonal direcionado a CD30 ligado à monometilauristatina E, um agente antitubulina ( **Figura 2** )<sup>32</sup> .  
A dose recomendada de BV é 1,8 mg/kg, administrada como uma infusão intravenosa durante 30 minutos a cada três semanas. Os pacientes que apresentem melhora ou uma doença estável, devem receber um mínimo de oito doses e até um máximo de 16 ciclos (aproximadamente um ano). A dose inicial recomendada em pacientes com insuficiência renal grave é 1,2 mg/kg, e os mesmos devem ser monitorados de perto quanto à ocorrência de eventos adversos. A dose inicial recomendada em pacientes com insuficiência hepática é 1,2 mg/kg, e os mesmos devem ser monitorados de perto quanto à ocorrência de eventos adversos<sup>33</sup> .  
Preconiza-se também a obtenção de PET-CT para avaliar o perfil de risco do doente e a resposta ao tratamento<sup>34, 35</sup> . Pacientes de alto risco (por exemplo, com recidiva precoce ou recidiva extranodal) devem ser considerados para receber brentuximabe vedotina pós-transplante e radioterapia de consolidação<sup>32, 36, 37</sup> ( **Figura 2** ). Para os pacientes com linfoma de Hodgkin com risco aumentado de recidiva ou de progressão após TCTH, o tratamento com BV deve começar após a recuperação do transplante, com base na avaliação médica. Estes pacientes devem receber até 16 ciclos, devendo ser interrompido após este limite. O brentuximabe vedotina não deve ser administrado em _bolus_ intravenoso<sup>33, 38</sup> .  
<!-- Start of picture text -->
.<br><!-- End of picture text -->  
**Figura 2** **_-_** Fluxograma de tratamento de pacientes com doença recaída ou refratária

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.3.Tratamento do Linfoma de Hodgkin com predomínio linfocitário nodular** -->
As células do linfoma de Hodgkin predominante em linfócitos nodulares ( _<mark>Nodular Lymphocyte-Predominant Hodgkin</mark>_ **_<mark>Lymphoma -</mark>_** <mark>N</mark> LPHL) são caracterizadas pela expressão obrigatória de CD20 juntamente com negatividade para CD30<sup>39</sup> . Por ser uma doença rara, não há ensaios clínicos randomizados de NLPHL para a comparação entre diferentes condutas terapêuticas.  
Com base na evidência disponível, para o tratamento de pacientes com NLPHL em estágio IA, ou seja, de acometimento de um único local linfático ou acometimento localizado de um único órgão ou local extralinfático e sem associação com febre, sudorese noturna e perda de peso abrupta, preconiza-se radioterapia em campo envolvido na dose total de 30 Gy, com que foram alcançadas taxas de sobrevida livre de progressão em 91,9% dos casos e 99% de sobrevida global em oito anos<sup>40</sup> .  
Já a partir de um consenso de especialistas, recomenda-se que os pacientes com NLPHL em estágio IA sem fatores de risco sejam tratados com radioterapia em campo  
envolvido na dose total de 30 Gy. Por outro lado, todos os pacientes com NLPHL com fatores de risco ou em que o NLPHL não esteja em estágio IA devem ser tratados da mesma maneira que os pacientes com linfoma de Hodgkin clássico<sup>24</sup> .  
Quanto aos casos de transformação histológica de NLPHL em linfoma difuso de células B grandes ( _Diffuse Large B-Cell Lymphoma_ - DLBCL), que ocorre em aproximadamente 3%-5% dos casos e pode ser concomitante ou consequente ao desenvolvimento de NLPHL, deve-se seguir o tratamento preconizado no Protocolo Clínico e Diretrizes Terapêuticas do Linfoma difuso de Grandes Células B no Adulto<sup>41</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.4.1. Linfoma de Hodgkin clássico: Doença localizada** -->
Os pacientes com doença localizada devem ser tratados de acordo com as suas características prognósticas ao diagnóstico. A modalidade combinada, que consiste em quimioterapia seguida de radioterapia em campo envolvido, é a melhor opção<sup>42-44</sup> .  
O tratamento da doença localizada sem fatores de risco é de dois ciclos de ABVD seguidos de radioterapia em campo envolvido ou nodal. Para pacientes com doença localizada desfavorável, a terapia se baseia em quatro ciclos de ABVD seguidos de radioterapia ( **Figura 3** )<sup>44</sup> .  
Pacientes com doença localizada tratados apenas com quimioterapia ainda apresentam um bom prognóstico global, podendo esta modalidade terapêutica deve ser oferecida àqueles que apresentam alguma contraindicação à radioterapia<sup>45</sup> .  
<!-- Start of picture text -->
4ciclos de ABVD<br>Radioterapia em<br>campo envolvido ou<br>nodal (30 Gy)<br><!-- End of picture text -->  
**Figura 3 -** Fluxograma de tratamento de pacientes com doença localizada

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.4.2. Linfoma de Hodgkin clássico: Doença avançada** -->
Atualmente, o tratamento da doença avançada é com quimioterapia. A radioterapia é restrita aos pacientes com doença residual ou grandes massas. Entretanto, o papel da radioterapia no tratamento do linfoma de Hodgkin avançado ainda é controverso e pode aumentar a probabilidade de eventos adversos.  
Os dois principais esquemas terapêuticos da doença avançada e da doença localizada com fatores de risco ou desfavorável são o ABVD e o BEACOPP escalonado. Pacientes entre 16 e 60 anos de idade com doença avançada se beneficiam em termos de sobrevida global e sobrevida livre de progressão tumoral, a partir da quimioterapia de primeira linha, incluindo BEACOPP escalonado<sup>46</sup> . No entanto, este tratamento pode ser mais tóxico do que o ABVD, sendo os dados de eventos adversos relevantes a longo prazo ainda que incipientes.  
Preconiza-se o tratamento com 6 ciclos de ABVD e, caso haja doença residual superior a 2,5 cm, o paciente deve ser submetido à radioterapia com campo envolvido ou nodal ( **Figura 4** )<sup>6</sup> .  
<!-- Start of picture text -->
Doenga avancada<br>| 6 ciclos de ABVD |<br>Doenga residual (> 2,5 cm):<br>Radioterapia em campo envolvido<br>ou nodal (30 Gy)<br><!-- End of picture text -->  
**Figura 4 -** Fluxograma de tratamento para pacientes com doença avançada

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.5.    Tratamento adaptado à PET-CT** -->
O desafio do tratamento do linfoma de Hodgkin é o de maximizar a eficácia e minimizar os efeitos tóxicos precoces e tardias. Para minimizar a toxicidade do tratamento sem reduzir a sua eficácia, este deve ser ajustado ao risco de cada paciente. Uma das formas é avaliar a resposta ao tratamento por meio da PET-CT, segundo os Critérios de Deauville (DV) ( **Quadro 6** ). Trata-se de uma escala de 5 pontos em que se pontua a captação de maior intensidade no sítio inicial da doença, caso esteja presente<sup>47</sup> :  
**Quadro 6 -** Pontuação segundo critérios de Deauville  
|**Escore**|**Definição**|
|---|---|
|1|Sem captação|
|2|Captação ≤ mediastino|
|3|Captação > mediastino, mas ≤ fígado|
|4|Aumento moderadamente superior ao fígado|
|5|Aumento marcadamente superior ao fígado e/ou novas lesões|
|X|Novas áreas de captação provavelmente não relacionadas ao<br>linfoma|  
Fonte: Barrington et al., 2017<sup>47</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.5.1. Tratamento adaptado à PET-CT: Doença localizada** -->
No caso de doença localizada sem fatores de risco ou favorável, o tratamento adaptado à PET-CT, após os 2 ciclos iniciais de ABVD, em caso de PET-CT negativa, pode-se proceder a mais um ciclo de AVBD ou radioterapia ( **Figura 5** ). A escolha dependerá do critério de estratificação utilizado. Se o critério utilizado foi o do GHSG e PET-CT negativa com critérios de Deauville com valores de 1-3 pontos (DV:1-3), podese indicar direto a radioterapia. No caso da utilização de outros critérios de estratificação do grupo de risco, por exemplo do EORTC e PET-CT negativa com critérios de Deauville com valores de 1-2 pontos (DV:1-2), há indicação de mais um ciclo de quimioterapia<sup>47</sup> .  
Em contrapartida, se a PET-CT for positiva, pode-se proceder à quimioterapia com 2 ciclos de ABVD ou 2 ciclos de BEACOPP escalonado ( **Figura 5** ). A escolha entre um ou outro dependerá do hospital onde o paciente está sendo tratado, já que o BEACOPP é mais intensivo e resulta em maior toxicidade, só devendo ser realizado por profissionais com experiência, em locais com cuidados de suporte apropriados, e em pacientes bem selecionados (< 60 anos)<sup>47</sup> .  
<!-- Start of picture text -->
2 CICLOS DE<br>ABVD<br>PET-CT  PET-CT<br>NEGATIVA POSITIVA<br>RADIOTERAPIA<br>2 CICLOS DE<br>CAMPO<br>1 CICLO DE ABVD  2 CICLOS DE ABVD  BEACOPP<br>ENVOLVIDO OU<br>escalonado<br>NODAL 20Gy<br>RADIOTERAPIA  RADIOTERAPIA  RADIOTERAPIA<br>CAMPO  CAMPO  CAMPO<br>ENVOLVIDO OU  ENVOLVIDO OU  ENVOLVIDO OU<br>NODAL 20Gy NODAL 30Gy NODAL 30Gy<br>1  2  3  4<br><!-- End of picture text -->  
**Figura 5 -** Tratamento adaptado à PET-CT em caso de doença localizada sem fatores de risco ou favorável  
Deve-se proceder a uma nova biópsia nos pacientes que apresentarem, de acordo com os critérios de Deauville, um valor de 5 pontos (DV:5). Os pacientes com resultado positivo ao exame histopatológico do material de biopsia devem ser tratados como para doença refratária ou recaída tumoral.  
No caso de doença localizada com fatores de risco ou desfavorável, a escolha por ABVD e BEACOPP escalonado dependerá do hospital onde o paciente está sendo tratado, já que o BEACOPP é mais intensivo e resulta em maior toxicidade, só devendo  
ser realizado por profissionais com experiência, em locais com cuidados de suporte apropriados, e em pacientes com menos de 60 anos. Se a PET-CT for positiva com critério de Deauville com valor de 3 pontos (DV:3), indica-se o ABVD; se a PET-CT for positiva com critério de Deauville com valor de 4 pontos (DV:4), indica-se o BEACOPP escalonado ( **Figura 6** ).  
<!-- Start of picture text -->
2 CICLOS DE<br>ABVD<br>PET-CT  PET-CT<br>NEGATIVA POSITIVA<br>2 CICLOS DE<br>2 CICLOS DE ABVD  2 CICLOS DE ABVD  BEACOPP<br>escalonado<br>RADIOTERAPIA  RADIOTERAPIA  RADIOTERAPIA<br>CAMPO  CAMPO  CAMPO<br>ENVOLVIDO OU  ENVOLVIDO OU  ENVOLVIDO OU<br>NODAL 30Gy NODAL 30Gy NODAL 30Gy<br>1  2  3<br><!-- End of picture text -->  
**Figura 6 -** Tratamento adaptado à PET-CT em caso de doença localizada com fatores de risco ou desfavorável  
Deve-se proceder a uma nova biópsia nos pacientes que apresentarem, de acordo com os critérios de Deauville, um valor de 5 pontos (DV:5). Os pacientes com resultado positivo ao exame histopatológico do material de biopsia devem ser tratados como para doença refratária ou recaída tumoral.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.5.2. Tratamento adaptado à PET-CT: Doença avançada** -->
Até o momento, não há ensaios clínicos randomizados que tenham avaliado a intensificação do tratamento de pacientes com PET-CT interina positiva para doença avançada; portanto, o efeito preciso da intensificação do tratamento permanece incerto, apesar dos controles históricos.  
A **Figura 7** sintetiza o tratamento adaptado à PET-CT em caso de pacientes com doença avançada tratados inicialmente com ABVD. Observe-se que, no caso de PET-CT negativa, os quatro ciclos complementares ao dois ciclos iniciais de ABVD serão sem a bleomicina (AVD).  
Já a **Figura 8** resume o tratamento adaptado à PET-CT em caso de pacientes com doença avançada tratados inicialmente com BEACOPP escalonado (somente pacientes selecionados: IPS ≥ 4 e < 60 anos).  
Deve-se proceder a uma nova biópsia nos pacientes que apresentarem, de acordo com os critérios de Deauville, um valor de 5 pontos (DV:5). Os pacientes com resultado positivo ao exame histopatológico do material de biopsia devem ser tratados como para doença refratária ou recaída tumoral.  
<!-- Start of picture text -->
2 CICLOS DE ABVD<br>PET-CT  PET-CT<br>NEGATIVA POSITIVA<br>4 CICLOS ABVD<br>OU 4 CICLOS<br>4 CICLOS DE AVD<br>BEACOPP<br>escalonado<br>PET-CT  PET-CT<br>PET-CT POSITIVA PET-CT POSITIVA<br>NEGATIVA NEGATIVA<br>OBSERVAÇÃO OU  CONSIDERAR NOVA BIÓPISA OU  OBSERVAÇÃO OU  CONSIDERAR NOVA BIÓPISA OU<br>RADIOTERAPIA SE<br>RADIOTERAPIA SE  RADIOTERAPIA SE  RADIOTERAPIA SE<br>GRANDE MASSA<br>GRANDE MASSA  GRANDE MASSA INICIAL  GRANDE MASSA INICIAL<br>INICIAL OU EM ÁREAS<br>OU EM ÁREAS DE PET-CT  OU EM ÁREAS DE PET-CT<br>INICIAL<br>POSITIVA  DE PET-CT POSITIVA POSITIVA<br><!-- End of picture text -->  
**Figura 7 -** Tratamento adaptado à PET-CT em caso de pacientes com doença avançada tratados inicialmente com ABVD  
1  
2  
3  
4  
<!-- Start of picture text -->
2 CICLOS DE<br>BEACOPP<br>escalonado<br><!-- End of picture text -->  
<!-- Start of picture text -->
PET-CT  PET-CT<br>NEGATIVA POSITIVA<br>2 CICLOS DE  4 CICLOS<br>BEACOPP  BEACOPP<br>escalonado  escalonado<br>PET-CT  PET-CT  PET-CT  PET-CT<br>NEGATIVA POSITIVA NEGATIVA POSITIVA<br>OBSERVAÇÃO OU  CONSIDERAR NOVA  OBSERVAÇÃO OU  CONSIDERAR<br>RADIOTERAPIA SE  BIÓPISA OU  RADIOTERAPIA SE  NOVA BIÓPISA OU<br>GRANDE MASSA  RADIOTERAPIA SE  GRANDE MASSA  RADIOTERAPIA SE<br>GRANDE MASSA<br>INICIAL OU EM  INICIAL OU EM  INICIAL OU EM  GRANDE MASSA<br>ÁREAS DE PET-CT  ÁREAS DE PET-CT  ÁREAS DE PET-CT  INICIAL OU EM<br>POSITIVA POSITIVA POSITIVA ÁREAS DE PET-CT<br>POSITIVA<br><!-- End of picture text -->  
**Figura 8 -** Tratamento adaptado à PET-CT em caso de pacientes com doença avançada tratados inicialmente com BEACOPP escalonado (somente pacientes  
selecionados: IPS ≥ 4 e < 60 anos)  
<!-- Start of picture text -->
2  3  4<br><!-- End of picture text -->  
1

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6. Eventos Adversos** -->
O tratamento do linfoma de Hodgkin engloba diferentes doses de quimioterapia e de radioterapia, que podem ser procedidas separadamente ou em conjunto, dependendo das características de cada paciente. Mesmo em baixas doses ou de forma isolada, esses tratamentos apresentam riscos de eventos adversos, como, por exemplo, aumento do risco de desenvolver uma neoplasia maligna secundária<sup>48</sup> .  
A maioria dos eventos adversos relatados são semelhantes, tanto para quimioterapia quanto para radioterapia e envolvem efeitos tóxicos hematológicos e pulmonares<sup>48</sup> . Quanto à quimioterapia, o BEACOPP escalado causa um maior risco de eventos adversos, como anemia, neutropenia, trombocitopenia e infecções, quando comparado ao ABVD<sup>46</sup> . Até o momento não há dados de estudos relacionados à infertilidade<sup>46</sup> . Em relação à mortalidade, há estudos que relataram risco de morte por infecção, mortalidade por câncer ou doenças cardíacas, neste último caso <mark>devido à exposição à radiação, e</mark> mbora esses riscos de mortalidade não sejam altos<sup>45, 48-51</sup> .  
Disfunções da tireoide afetam aproximadamente 50% dos pacientes que recebem radioterapia no pescoço ou nas áreas do mediastino superior<sup>22, 52</sup> <mark>. A</mark> síndrome da fadiga crônica também não deve ser ignorada, o que afeta o bem-estar físico e mental dos pacientes, além de ser um fator na avaliação da sua qualidade de vida e no retorno ao funcionamento social, familiar e profissional<sup>53</sup> . O risco de câncer de mama secundário à radioterapia é particularmente alto em mulheres que receberam radiação com menos de 30 anos de idade e permanece aumentado por décadas após o término da radioterapia<sup>54</sup> .  
Pacientes que necessitam de TCTH, bem como radioterapia, têm um risco aumentado de infecção devido à imunossupressão. Por outro lado, a <mark>neuropatia é o principal efeito tóxico não hematológico do tratamento com b</mark> rentuximabe vedotina. <mark>Apesar disso, a maioria dos pacientes que tiveram neuropatia pós-linfoma de Hodgkin apresentaram melhora dos sintomas ao longo de um ano</mark><sup>55</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.1. Gestantes** -->
O linfoma de Hodgkin tem um pico de incidência que coincide com os anos reprodutivos (final da adolescência e início da idade adulta), e o estado gravídico concomitante pode estar presente em até 3% de todos os pacientes diagnosticados com  
essa doença. Com uma relação de incidência estimada entre 1:1.000 e 1:3.000 partos, o linfoma de Hodgkin é a neoplasia hematológica mais comum da gravidez<sup>56</sup> .  
O maior desafio médico da concomitância de linfoma de Hodgkin e gravidez é controlar a evolução de uma neoplasia maligna potencialmente fatal e ao mesmo tempo cuidar para que o feto tenha um desenvolvimento normal. Desse modo, o tratamento de uma paciente gestante com linfoma de Hodgkin requer um atendimento multidisciplinar, combinando conhecimentos em oncologia médica, obstetrícia de alto risco e neonatologia, além de comunicação eficaz com a paciente e sua família. A biologia, o curso clínico e o prognóstico da doença são semelhantes aos observados em mulheres não grávidas<sup>56, 57</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.1.1. Estadiamento** -->
O objetivo do estadiamento é fornecer ao médico assistente e à paciente as informações suficientes para orientar o tratamento, limitando os riscos ao feto. O uso de tomografia computadorizada e PET-CT está contraindicado por expor o feto a radiação potencialmente prejudicial<sup>58</sup> . Por outro lado, a radiografia simples de tórax (com a devida proteção abdominal), a ultrassonografia e a ressonância magnética (sem uso de gadolínio) são métodos seguros de exames de imagem durante a gravidez<sup>58-60</sup> .  
Deste modo, a avaliação para o estadiamento inicial da paciente gestante com diagnóstico de linfoma de Hodgkin deve incluir<sup>56, 61, 62</sup> :  
 Estudos laboratoriais, incluindo hemograma completo, determinação de velocidade de hemossedimentação (VHS), dosagem sérica de ureia, creatinina, enzimas hepáticas e teste sorológico para HIV. Vale lembrar que o VHS se encontra frequentemente elevado durante a gravidez normal.  
 Radiografia simples de tórax, preferencialmente apenas com projeção posterioranterior e obrigatoriamente com blindagem abdominal adequada.  
- Avaliação do abdome com ressonância magnética ou ultrassonografia.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.1.2. Tratamento** -->
A escolha do tratamento do linfoma de Hodgkin durante a gravidez depende da fase (trimestre) da gestação, bem como da localização e estágio clínico da doença. De modo geral, sempre que possível, a terapia deve ser adiada até pelo menos o início do  
segundo trimestre, uma vez que os riscos de comprometimento do feto são maiores durante os primeiros três meses do seu desenvolvimento.  
Pacientes que apresentam doença supradiafragmática assintomática, estável e não volumosa são candidatas a que a terapia seja adiada para além do primeiro trimestre de gestação. No entanto, em pacientes com doença sintomática, de acometimento subdiafragmático ou que apresentem tumores volumosos ou em progressão, o tratamento apropriado não deve ser postergado.  
Além disso, as situações em que o bem-estar imediato da mãe está comprometido (por exemplo, obstrução aguda das vias aéreas, compressão da medula espinhal ou de veia cava superior) requerem intervenção terapêutica emergente a qualquer momento<sup>56,</sup> 61, 62.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.1.3. Condutas baseadas na fase (trimestre) da gestação:** -->
A interrupção da gravidez raramente é indicada para pacientes com linfoma de Hodgkin recém-diagnosticado, dado que o tratamento quimioterápico (ABVD ou vimblastina em monoterapia) pode ser empregado com segurança até mesmo no primeiro trimestre de gestação. Da mesma forma, uma doença recidivada após radioterapia isolada pode ser tratada satisfatoriamente com quimioterapia, sem necessidade precípua de interrupção da gravidez. Por outro lado, a interrupção da gestação é mais frequentemente indicada em pacientes gestantes acometidas de linfoma de Hodgkin recidivada após uma linha completa de quimioterapia, uma vez que a quimioterapia de altas doses com suporte de células-tronco hematopoiéticas (transplante de medula óssea) deve ser a conduta terapêutica de preferência<sup>56, 61</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **1) Primeiro Trimestre** -->
Para a maioria das mulheres com linfoma de Hodgkin diagnosticado durante o primeiro trimestre de gestação, a recomendação é adiar o tratamento até o segundo ou terceiro trimestre, sempre que possível. Para pacientes com doença em progressão que necessitem de uma resposta terapêutica rápida, preconiza-se o uso de quimioterapia com ABVD.  
Pacientes com doença sintomática, mas que não necessitam de uma rápida resposta terapêutica podem, alternativamente ao ABVD, ser tratadas com vimblastina como agente único (na dose de 0,1mg/Kg/semana), mantendo o planejamento de se administrar  
esquemas de quimioterapia combinada após o parto. Nos casos em que a quimioterapia está indicada logo no início do primeiro trimestre, a possibilidade de interrupção da gravidez deve ser discutida com a paciente e familiares, tanto quanto as opções e possíveis consequências do tratamento<sup>56, 61</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **2) Segundo Trimestre** -->
Para a maioria das mulheres com diagnóstico de linfoma de Hodgkin durante o segundo trimestre de gravidez, o tratamento consiste da quimioterapia com ABVD. Ocasionalmente, diante de um cenário singular de doença supradiafragmática, assintomática, estável e não volumosa, pode-se também optar pelo monitoramento clínico rigoroso e planejar a administração da quimioterapia para após o parto. Excepcionalmente, nas situações de maior gravidade (como obstrução aguda das vias aéreas e compressão da veia cava superior), a radioterapia pode ser usada para controle local da doença supradiafragmática sintomática.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3) Terceiro Trimestre** -->
Para pacientes diagnosticadas com linfoma de Hodgkin que já se encontrem no terceiro trimestre de gravidez, recomenda-se o adiamento do tratamento até o parto sempre que possível. Esta conduta permite que a paciente seja submetida à avaliação completa para o estadiamento clínico (com tomografia computadorizada ou PET-CT), bem como a seleção da terapia apropriada após o parto. Contudo, para os casos de doença sintomática ou progressiva, especialmente com sinais de risco iminente para a mãe, que necessitem de tratamento imediato, mais uma vez o tratamento é a quimioterapia com ABVD. O BEACOPP durante a gravidez não é recomendado por conter agentes alquilantes em sua composição<sup>56</sup> .  
A radioterapia pode oferecer controle local da doença, mas está associada à teratogênese fetal e a risco aumentado de neoplasia maligna infantil. Alguns princípios devem ser seguidos quando da escolha desta modalidade de tratamento<sup>62-64</sup> :  
 A radioterapia deve ser postergada até o segundo ou terceiro trimestre, sempre que possível;  
- a dose corporal total de irradiação para o feto deve ser limitada a 0,10 Gy ou menos; e  
- o objetivo deve ser limitado ao controle de doença localizada (campo restrito) até o momento do parto.  
A **Figura 9** resume o tratamento de pacientes gestantes com linfoma de Hodgkin.  
<!-- Start of picture text -->
=<br><!-- End of picture text -->  
**Figura 9 -** Fluxograma de tratamento de pacientes gestantes com linfoma de Hodgkin

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.2. Idosos** -->
A sobrevida de pacientes com linfoma de Hodgkin melhorou sobremaneira nas últimas décadas e continua a melhorar com o desenvolvimento de novas tecnologias, tais como os anticorpos monoclonais. Além disso, com a adoção de condutas terapêuticas adaptadas à resposta (avaliada por PET-CT interina), a intensidade geral do tratamento para a maioria dos pacientes pode ser reduzida, minimizando a toxicidade aguda e tardia. Em pacientes idosos, a tolerância à quimioterapia curativa geralmente é muito reduzida,  
resultando em toxicidade excessiva e tratamento insuficiente devido a atrasos e reduções de dose no tratamento programado<sup>65</sup> .  
Ademais, pacientes idosos com linfoma de Hodgkin sofrem de uma doença biologicamente mais agressiva e menos responsiva ao tratamento, caracterizada pela prevalência de fatores de pior prognóstico: estágio clínico mais avançado (Ann Arbor III e IV), VHS frequentemente mais elevado, maior associação com o vírus de Epstein-Barr e maior prevalência de sintomas constitucionais e do subtipo celularidade mista. Em comparação com a população mais jovem, pacientes idosos enfrentam maiores taxas de recidiva de doença e de mortalidade relacionada ao tratamento, além de maior risco de exacerbação de comorbidades pré-existentes, tais como insuficiência cardíaca e doenças pulmonares crônicas<sup>65</sup> .  
Na prática assistencial, a proporção de idosos entre os pacientes com linfoma de Hodgkin pode ser estimada entre 20% e 31% de todos os casos. Estes dados estão de acordo com a distribuição etária bimodal do linfoma de Hodgkin, com um pico de incidência na idade adulta jovem (por volta de 30 anos) e outro pico em idosos (com 70 ou mais anos)<sup>65, 66</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.2.1. Estadiamento** -->
Assim como em pacientes mais jovens, a escolha da modalidade e intensidade do tratamento de pacientes idosos deve ser baseada na classificação de risco e no estadiamento clínico inicial do linfoma, geralmente definido por meio de estudos com tomografia computadorizada ou PET-CT. No entanto, a presença de comorbidades e de disfunções orgânicas pré-existentes podem limitar o uso ou a intensidade da quimioterapia com potencial curativo<sup>65</sup> .  
Por conseguinte, além da história clínica detalhada, do exame físico completo, dos exames laboratoriais e dos procedimentos de estadiamento regulamentares, parte da avaliação inicial dos pacientes idosos deve incluir a avaliação formal de comorbidades, triagem de fragilidade e avaliação de atividades da vida diária. A maioria dos estudos com foco em pacientes idosos com linfoma de Hodgkin implementa uma avaliação geriátrica abrangente, com o objetivo de orientar as decisões terapêuticas e identificar pacientes que provavelmente não se beneficiarão da quimioterapia<sup>65, 67</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.2.2. Tratamento** -->
O tratamento ideal de idosos com linfoma de Hodgkin ainda não foi completamente estabelecido, uma vez que estes pacientes representam apenas uma minoria daqueles incluídos em ensaios clínicos randomizados. Apesar disso, sempre que possível, os pacientes idosos devem receber terapia com intenção curativa, como aquela empregada para adultos mais jovens<sup>65</sup> . No entanto, a possibilidade de cura da doença em idosos geralmente deve ser alcançada com a terapia de primeira linha, dado que as opções padrão de tratamento de segunda linha, como quimioterapia de altas doses seguida de TCTH, não são aplicáveis para a grande maioria dos pacientes idosos com linfoma de Hodgkin<sup>24</sup> .  
De modo geral, o emprego de esquemas mais intensos de quimioterapia (além do ABVD) não é viável para a maioria dos pacientes idosos com linfoma de Hodgkin devido, principalmente, à toxicidade excessiva<sup>48,67</sup> . Para pacientes idosos sem comorbidades significativas, o tratamento de modalidade combinada é uma opção viável e com potencial curativo. Do mesmo modo que a população mais jovem, pacientes idosos com doença em estágio inicial favorável (sem fatores de risco) devem receber tratamento com dois ciclos de ABVD, seguidos de radioterapia localizada na dose de 20 Gy.  
Por outro lado, para os pacientes idosos com doença em estágio inicial desfavorável (com fatores de risco), a conduta consiste em aplicar dois ciclos de ABVD, seguidos de dois ciclos de AVD (omitindo-se a bleomicina), seguidos por radioterapia localizada com 30 Gy. No caso dos pacientes idosos com linfoma de Hodgkin em estágio avançado, preconiza-se quimioterapia com dois ciclos de ABVD, seguidos por quatro ciclos de AVD (omitindo-se a bleomicina), seguidos por radioterapia localizada nos sítios de doença residual (≥ 2,5 cm à tomografia ou PET-CT positiva), sempre que possível<sup>48,</sup> 65. A bleomicina deve ser usada com muito cuidado em pacientes idosos. No caso de função pulmonar reduzida pré-existente ao tratamento, o uso de bleomicina está associado a um potencial de toxicidade grave e, portanto, deve ser evitado<sup>48</sup> _._ Exemplos de pacientes para os quais a bleomicina provavelmente deve ser omitida:  
- Idade > 80 anos, muito frágil ou de cura improvável;  
- depuração da creatinina ≤ 5 ml/minuto; e  
- fumantes ativos ou com doença pulmonar subjacente significativa.  
Os fluxogramas de tratamento do linfoma de Hodgkin de pacientes idosos com doença localizada ( **Figura 10** ) e avançada ( **Figura 11** ) encontram-se a seguir.  
<!-- Start of picture text -->
| ciclos 2 de ABVD<br><!-- End of picture text -->  
**Figura 10 -** Tratamento de pacientes idosos com doença localizada  
<!-- Start of picture text -->
:<br><!-- End of picture text -->  
**Figura 11 -** Tratamento para pacientes idosos com doença avançada

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.3. Infecção pelo Vírus HIV** -->
A infecção pelo vírus da imunodeficiência humana (HIV) compromete a imunidade celular e predispõe o desenvolvimento de cânceres. De acordo com os dados dos registros norte-americanos, o linfoma de Hodgkin é o quinto câncer mais comum entre as pessoas infectadas pelo HIV, vindo logo atrás dos linfomas não Hodgkin, do sarcoma de Kaposi e dos carcinomas de pulmão e da região anal. Diferentemente destas últimas neoplasias, o linfoma de Hodgkin não é considerado uma doença maligna definidora da síndrome da imunodeficiência adquirida (AIDS)<sup>68</sup> . A incidência de linfoma de Hodgkin em indivíduos infectados pelo vírus HIV é de 5 a 20 vezes maior do que na população geral, a idade média ao diagnóstico é de 40 a 44 anos e o subtipo histopatológico mais prevalente é o celularidade mista<sup>69</sup> .  
À medida que a expectativa de vida dos portadores de HIV aumenta, as doenças malignas contribuem cada vez mais para a morbimortalidade nessa população. Desde a implementação rotineira da terapia antirretroviral (TARV), o câncer é diagnosticado em cerca de 40% das pessoas com HIV, sendo responsável por até 28% das mortes relacionadas ao vírus<sup>48</sup> . Diferentemente do observado em relação aos linfomas não  
Hodgkin, a implementação da TARV não reduziu a incidência de linfoma de Hodgkin entre os portadores de HIV. Ainda assim, provavelmente devido à melhora da resposta imune, desde a implementação da TARV, o subtipo esclerose nodular tem aparecido com maior frequência e já representa quase 50% dos casos<sup>69</sup> _._  
A redução da carga viral e a melhora da função imunológica promovidas pela TARV reduziram sobremaneira a ocorrência de infecções oportunistas, ampliaram significativamente a tolerância dos pacientes à quimioterapia e, consequentemente, melhoraram os resultados do tratamento do linfoma de Hodgkin em portadores do HIV. Atualmente, a sobrevida global nos pacientes infectados pelo HIV e com linfoma de Hodgkin assemelha-se à dos não infectados<sup>70</sup> . Deste modo, a TARV é um componente essencial para o tratamento de pacientes com linfoma relacionado ao HIV e deve ser continuada durante o período da quimioterapia, tendo por objetivo reduzir a carga viral do HIV a níveis indetectáveis<sup>71</sup> .  
Cabe ressaltar que os esquemas de TARV com inibidores de protease (CYP3A), a exemplo do ritonavir, podem potencializar a mielotoxicidade da quimioterapia. Neste cenário, os inibidores da integrase (raltegravir, dolutegravir) representam uma boa alternativa, já que esses agentes têm menor potencial para interações medicamentosas<sup>69</sup> .  
Para mais informações sobre a TARV consultar o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos<sup>72, 77</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.3.1. Estadiamento** -->
Do mesmo modo que para os pacientes não infectados, a escolha da modalidade e intensidade do tratamento em portadores do HIV deve ser baseada na classificação de risco e no estadiamento clínico inicial, geralmente definido por meio de estudos com tomografia computadorizada ou PET-CT. Contudo, as comorbidades relacionadas ao HIV têm um amplo espectro de gravidade e merecem especial atenção durante o planejamento da quimioterapia<sup>69</sup> .  
Deve-se incluir na avaliação inicial e no seguimento a aferição da carga viral HIV e a contagem de CD4. Além de servir de parâmetro de eficácia da TARV, a mensuração dos níveis de CD4 também pode orientar o uso e a escolha da profilaxia antibiótica durante o período de quimioterapia<sup>69</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **6.6.3.2. Tratamento** -->
Pacientes infectados pelo HIV devem receber o mesmo tratamento planejado para os não infectados, acrescido da TARV. Deste modo, preconiza-se<sup>69, 73, 74</sup> :  
 Pacientes com linfoma de Hodgkin relacionado ao HIV devem receber o mesmo tratamento planejado para os não infectados, de acordo com avaliação da presença ou ausência de fatores prognósticos e sintomas constitucionais, envolvendo os mesmos esquemas apresentados, acrescido da TARV.  A TARV deve ser iniciada antes ou concomitantemente com a quimioterapia e deve ser continuada durante o período de tratamento do linfoma de Hodgkin.  A carga viral do HIV e a contagem de CD4 devem ser aferidas com regularidade, antes e durante o período de quimioterapia.  
Deve-se atentar para o fato de que, durante o período de quimioterapia, para redução do risco de infecções oportunistas, há necessidade de considerar também o uso de antibioticoprofilaxia. Deste modo, deve-se seguir o preconizado no Protocolo Clínico e Diretrizes Terapêuticas para o Manejo da Infecção pelo HIV em Adultos<sup>77</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **7. MONITORAMENTO** -->
O monitoramento pós-tratamento do linfoma de Hodgkin é extremamente necessário, a fim de detectar precocemente possíveis efeitos tóxicos e até mesmo a recidiva tumoral. O monitoramento cuidadoso da detecção precoce da recidiva é particularmente importante nos primeiros 5 anos após o final do tratamento, porque 90% de todas as recidivas se enquadram nesse período. Os pacientes com linfoma de Hodgkin precisam ser acompanhados regularmente, com ênfase n <mark>a história, exame físico e análise laboratorial:</mark> a cada 3 meses no primeiro ano após o tratamento, a cada 6 meses do segundo ao quarto ano e, posteriormente, anualmente<sup>24</sup> .  
Em cada atendimento de acompanhamento, é altamente recomendável perguntar ao paciente sobre sintomas que possam indicar sequelas tardias do tratamento. Por exemplo, a imagem radiológica não deve ser realizada rotineiramente em pacientes assintomáticos durante uma avaliação de acompanhamento após o término do tratamento. Porém, se houver suspeita de recidiva, indica-se confirmá-la ou descartá-la por meio de PET-CT, se disponível, ou então de tomografia computadorizada, seguida de biópsia<sup>75</sup> .  
Pacientes assintomáticos que receberam quimioterapia mais radioterapia mediastinal na dose de 20 Gy ou mais devem ser submetidos a eletrocardiografia, ecocardiografia e a um exame para detectar ou descartar doença cardíaca coronariana<sup>76</sup> .  
É recomendado que o nível sérico do hormônio estimulador da tireoide (TSH) seja medido uma vez por ano em pacientes submetidos a radioterapia nas proximidades da região da tireoide, para descartar disfunções dessa glândula<sup>52</sup> .  
Pacientes submetidos à radioterapia pulmonar ou mediastinal devem ser submetidos a testes de função pulmonar, incluindo a medição da capacidade de difusão, 12 meses após o final do tratamento.  
Se houver suspeita de dano gonadal, este deve ser investigado em consulta, preferencialmente, com um especialista em saúde reprodutiva.  
Os pacientes com queixa de fadiga crônica devem ser encaminhados a um médico ou psicólogo com experiência no tratamento dessa condição<sup>24</sup> .

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
Pacientes com diagnóstico de linfoma de Hodgkin devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, tratar e acompanhar os pacientes.  
Além da familiaridade que tais hospitais guardam com o estadiamento, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e a garantia do atendimento das pacientes, e muito facilita as ações de controle e avaliação. Entre tais ações incluem-se a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES), a autorização prévia dos procedimentos, o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus  
ressarcidos) e a verificação dos percentuais da frequência dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda e segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou do protocolo adotados no hospital, a regulação do acesso assistencial, a qualidade da autorização, a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses), a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod), a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais e o grau de satisfação dos doentes.  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a quimioterapia do linfoma folifcular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama - que são adquiridos pelo Ministério da Saúde e fornecido aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde.  
Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais as terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados pelo SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento.  
Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento de medicamento antineoplásico é do hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos de quimioterapia do linfoma de Hodgkin são os seguintes:  
03.04.06.001-1 Quimioterapia da doença de Hodgkin - 1ª linha 03.04.06.003-8 Quimioterapia da doença de Hodgkin - 2ª linha  
03.04.06.004-6 Quimioterapia da doença de Hodgkin - 3ª linha  
O brentuximabe vedotina foi incorporado no SUS para o tratamento de pacientes adultos com linfoma de Hodgkin refratário ou recidivado após transplante de célulastronco hematopoéticas, por meio da Portaria SCTIE/MS nº 12, de 11 de março de 2019. O seu uso é compatível com o registro do procedimento de 3ª linha, cuja descrição explicita em que condições pode ser autorizado.  
Para a autorização do TCTH alogênico não aparentado, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores submetidos a TCTH originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **9. REFERÊNCIAS** -->
1. DeVita VT, Lawrence TS, Rosenberg SA. DeVita, Hellman, and Rosenberg's cancer: principles & practice of oncology. Chapter 102: Hodgkin’s lymphoma: Lippincott Williams & Wilkins; 2015.  
2. Cokkinides V, Albano J, Samuels A, Ward M, Thum J. American cancer society: Cancer facts and figures. Atlanta: American Cancer Society. 2019.  
3. Brasil. Ministério da Saúde. Instituto Nacional de Câncer, Estimativa 2018: Incidência de Câncer no Brasil. Rio de Janeiro: INCA; 2017.  
4. Laurent C, Do C, Gourraud PA, de Paiva GR, Valmary S, Brousset P. Prevalence of Common Non-Hodgkin Lymphomas and Subtypes of Hodgkin Lymphoma by Nodal Site of Involvement: A Systematic Retrospective Review of 938 Cases. Medicine (Baltimore). 2015;94(25):e987.  
5. Araujo I, Bittencourt AL, Barbosa HS, Netto EM, Mendonca N, Foss HD, et al. The high frequency of EBV infection in pediatric Hodgkin lymphoma is related to the classical type in Bahia, Brazil. Virchows Arch. 2006;449(3):315-9.  
6. Eichenauer DA, Aleman BMP, Andre M, Federico M, Hutchings M, Illidge T, et al. Hodgkin lymphoma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2018;29(Suppl 4):iv19-iv29.  
7. Spinner MA, Advani RH, Connors JM, Azzi J, Diefenbach C. New Treatment Algorithms in Hodgkin Lymphoma: Too Much or Too Little? Am Soc Clin Oncol Educ Book. 2018;38:626-36.  
8. Sabattini E, Bacci F, Sagramoso C, Pileri SA. WHO classification of tumours of haematopoietic and lymphoid tissues in 2008: an overview. Pathologica. 2010;102(3):837.  
9. Cheson BD, Fisher RI, Barrington SF, Cavalli F, Schwartz LH, Zucca E, et al. Recommendations for initial evaluation, staging, and response assessment of Hodgkin and non-Hodgkin lymphoma: the Lugano classification. J Clin Oncol. 2014;32(27):305968.  
10. Mauch PM, Kalish LA, Kadin M, Coleman CN, Osteen R, Hellman S. Patterns of presentation of Hodgkin disease. Implications for etiology and pathogenesis. Cancer. 1993;71(6):2062-71.  
11. Swerdlow SH, Campo E, Harris NL, al e. WHO classification of tumours of haematopoietic and lymphoid tissues. 4th ed. Lyon, France: IARC; 2008.  
12. Alguirre PC MB. Skin Biopsy Techniques for the Internist. J Gen Intern Med. 1998;13(1):46-54.  
13. Pappa VI, Hussain HK, Reznek RH, Whelan J, Norton AJ, Wilson AM, et al. Role of image-guided core-needle biopsy in the management of patients with lymphoma. J Clin Oncol. 1996;14(9):2427-30.  
14. Hehn ST, Grogan TM, Miller TP. Utility of fine-needle aspiration as a diagnostic technique in lymphoma. J Clin Oncol. 2004;22(15):3046-52.  
15. Brasil. PET-CT no Estadiamento e Avaliação da Resposta ao Tratamento dos Linfomas. In: Saúde Md, editor. Brasília2014.  
16. Barrington SF, Mikhaeel NG, Kostakoglu L, Meignan M, Hutchings M, Mueller SP, et al. Role of imaging in the staging and response assessment of lymphoma: consensus of the International Conference on Malignant Lymphomas Imaging Working Group. J Clin Oncol. 2014;32(27):3048-58.  
17. El-Galaly TC, d'Amore F, Mylam KJ, de Nully Brown P, Bogsted M, Bukh A, et al. Routine bone marrow biopsy has little or no therapeutic consequence for positron emission tomography/computed tomography-staged treatment-naive patients with Hodgkin lymphoma. J Clin Oncol. 2012;30(36):4508-14.  
18. Brasil. Manual de Recomendações para o Controle da Tuberculose no Brasil. In: Saúde Md, editor. 2ª Ed. ed. Brasília: Ministério da Saúde; 2019.  
19. Carbone PP, Kaplan HS, Musshoff K, Smithers DW, Tubiana M. Report of the Committee on Hodgkin's Disease Staging Classification. Cancer Res. 1971;31(11):18601.  
20. Sieber M, Engert A, Diehl V. Treatment of Hodgkin's disease: results and current concepts of the German Hodgkin's Lymphoma Study Group. Ann Oncol. 2000;11 Suppl 1:81-5.  
21. Carde P, Hagenbeek A, Hayat M, Monconduit M, Thomas J, Burgers MJ, et al. Clinical staging versus laparotomy and combined modality with MOPP versus ABVD in early-stage Hodgkin's disease: the H6 twin randomized trials from the European Organization for Research and Treatment of Cancer Lymphoma Cooperative Group. J Clin Oncol. 1993;11(11):2258-72.  
22. National Comprehensive Cancer Network. Lymphomas: Hodgkin Lymphoma [Internet]. 2019 [Available from:  
https://www.nccn.org/professionals/physician_gls/pdf/hodgkins.pdf.  
23. Hasenclever D, Diehl V. A prognostic score for advanced Hodgkin's disease. International Prognostic Factors Project on Advanced Hodgkin's Disease. N Engl J Med. 1998;339(21):1506-14.  
24. Brockelmann PJ, Eichenauer DA, Jakob T, Follmann M, Engert A, Skoetz N. Hodgkin Lymphoma in Adults. Dtsch Arztebl Int. 2018;115(31-32):535-40.  
25. von Tresckow B, Engert A. Refractory Hodgkin lymphoma. Curr Opin Oncol. 2013;25(5):463-9.  
26. Bonadonna G, Zucali R, Monfardini S, De Lena M, Uslenghi C. Combination chemotherapy of Hodgkin's disease with adriamycin, bleomycin, vinblastine, and imidazole carboxamide versus MOPP. Cancer. 1975;36(1):252-9.  
27. Diehl V, Franklin J, Pfreundschuh M, Lathan B, Paulus U, Hasenclever D, et al. Standard and increased-dose BEACOPP chemotherapy compared with COPP-ABVD for advanced Hodgkin's disease. N Engl J Med. 2003;348(24):2386-95.  
28. Loeffler M, Hasenclever D, Diehl V. Model based development of the BEACOPP regimen for advanced stage Hodgkin's disease. German Hodgkin's Lymphoma Study Group. Ann Oncol. 1998;9 Suppl 5:S73-8.  
29. Josting A, Rudolph C, Reiser M, Mapara M, Sieber M, Kirchner HH, et al. Timeintensified dexamethasone/cisplatin/cytarabine: an effective salvage therapy with low toxicity in patients with relapsed and refractory Hodgkin's disease. Ann Oncol. 2002;13(10):1628-35.  
30. Moskowitz CH, Nimer SD, Zelenetz AD, Trippett T, Hedrick EE, Filippa DA, et al. A 2-step comprehensive high-dose chemoradiotherapy second-line program for relapsed and refractory Hodgkin disease: analysis by intent to treat and development of a prognostic model. Blood. 2001;97(3):616-23.  
31. Rancea M, Monsef I, von Tresckow B, Engert A, Skoetz N. High-dose chemotherapy followed by autologous stem cell transplantation for patients with relapsed/refractory Hodgkin lymphoma. Cochrane Database Syst Rev. 2013(6):CD009411.  
32. Younes A, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al. Results of a pivotal phase II study of brentuximab vedotin for patients with relapsed or refractory Hodgkin's lymphoma. J Clin Oncol. 2012;30(18):2183-9.  
33. TAKEDA PHARMA LTDA: ADCETRIS. Nova indicação de Adcetris (brentuximabe vedotina) [Available from: http://portal.anvisa.gov.br/informacoestecnicas13?p_p_id=101_INSTANCE_WvKKx2fhdjM2&p_p_col_id=column2&p_p_col_pos=1&p_p_col_count=2&_101_INSTANCE_WvKKx2fhdjM2_groupId= 219201&_101_INSTANCE_WvKKx2fhdjM2_urlTitle=adcetris-brentuximabevedotina-nova-  
indicacao&_101_INSTANCE_WvKKx2fhdjM2_struts_action=%2Fasset_publisher%2 Fview_content&_101_INSTANCE_WvKKx2fhdjM2_assetEntryId=5555907&_101_I NSTANCE_WvKKx2fhdjM2_type=content.  
34. Gopal AK, Ramchandren R, O'Connor OA, Berryman RB, Advani RH, Chen R, et al. Safety and efficacy of brentuximab vedotin for Hodgkin lymphoma recurring after allogeneic stem cell transplantation. Blood. 2012;120(3):560-8.  
35. Aldin A, Umlauff L, Estcourt LJ, Collins G, Moons KG, Engert A, et al. Interim PET-results for prognosis in adults with Hodgkin lymphoma: a systematic review and meta-analysis of prognostic factor studies. Cochrane Database Syst Rev. 2019;9:CD012643.  
36. Moskowitz AJ, Schoder H, Yahalom J, McCall SJ, Fox SY, Gerecitano J, et al. PET-adapted sequential salvage therapy with brentuximab vedotin followed by augmented ifosamide, carboplatin, and etoposide for patients with relapsed and refractory Hodgkin's lymphoma: a non-randomised, open-label, single-centre, phase 2 study. Lancet Oncol. 2015;16(3):284-92.  
37. Sibon D, Morschhauser F, Resche-Rigon M, Ghez D, Dupuis J, Marcais A, et al. Single or tandem autologous stem-cell transplantation for first-relapsed or refractory Hodgkin lymphoma: 10-year follow-up of the prospective H96 trial by the LYSA/SFGMTC study group. Haematologic. 2016;101(4):474-81.  
38. Brasil. Portaria nº 12/SCTIE/MS, de 11 de março de 2019. Torna pública a decisão de incorporar o brentuximabe vedotina para o tratamento de pacientes adultos com linfoma de Hodgkin refratário ou recidivado após transplante autólogo de célulastronco hematopoéticas, no âmbito do Sistema Único de Saúde - SUS. In: Saúde Md, editor. 2019.  
39. Eichenauer DA, Engert A. Nodular lymphocyte-predominant Hodgkin lymphoma: a unique disease deserving unique management. Hematology Am Soc Hematol Educ Program. 2017;2017(1):324-8.  
40. Eichenauer DA, Plutschow A, Fuchs M, von Tresckow B, Boll B, Behringer K, et al. Long-Term Course of Patients With Stage IA Nodular Lymphocyte-Predominant Hodgkin Lymphoma: A Report From the German Hodgkin Study Group. J Clin Oncol. 2015;33(26):2857-62.  
41. Brasil. Portaria nº 956/SAS/MS, de 26 de setembro de 2014. Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Linfoma Difuso de Grandes Células B. In: Saúde Md, editor. 2014.  
42. Gospodarowicz MK, Meyer RM. The management of patients with limited-stage classical Hodgkin lymphoma. Hematology Am Soc Hematol Educ Program. 2006:253-8.  
43. Engert A, Franklin J, Eich HT, Brillant C, Sehlen S, Cartoni C, et al. Two cycles of doxorubicin, bleomycin, vinblastine, and dacarbazine plus extended-field radiotherapy is superior to radiotherapy alone in early favorable Hodgkin's lymphoma: final results of the GHSG HD7 trial. J Clin Oncol. 2007;25(23):3495-502.  
44. Specht L, Yahalom J, Illidge T, Berthelsen AK, Constine LS, Eich HT, et al. Modern radiation therapy for Hodgkin lymphoma: field and dose guidelines from the international lymphoma radiation oncology group (ILROG). Int J Radiat Oncol Biol Phys. 2014;89(4):854-62.  
45. Meyer RM, Gospodarowicz MK, Connors JM, Pearcey RG, Wells WA, Winter JN, et al. ABVD alone versus radiation-based therapy in limited-stage Hodgkin's lymphoma. N Engl J Med. 2012;366(5):399-408.  
46. Skoetz N, Will A, Monsef I, Brillant C, Engert A, von Tresckow B. Comparison of first-line chemotherapy including escalated BEACOPP versus chemotherapy including ABVD for people with early unfavourable or advanced stage Hodgkin lymphoma. Cochrane Database Syst Rev. 2017;5:CD007941.  
47. Barrington SF, Kluge R. FDG PET for therapy monitoring in Hodgkin and nonHodgkin lymphomas. Eur J Nucl Med Mol Imaging. 2017;44(Suppl 1):97-110.  
48. Borchmann S, Engert A, Boll B. Hodgkin lymphoma in elderly patients. Curr Opin Oncol. 2018;30(5):308-16.  
49. Radford J, Illidge T, Counsell N, Hancock B, Pettengell R, Johnson P, et al. Results of a trial of PET-directed therapy for early-stage Hodgkin's lymphoma. N Engl J Med. 2015;372(17):1598-607.  
50. Aviles A, Delgado S. A prospective clinical trial comparing chemotherapy, radiotherapy and combined therapy in the treatment of early stage Hodgkin's disease with bulky disease. Clin Lab Haematol. 1998;20(2):95-9.  
51. Bloomfield CD, Pajak TF, Glicksman AS, Gottlieb AJ, Coleman M, Nissen NI, et al. Chemotherapy and combined modality therapy for Hodgkin's disease: a progress report on Cancer and Leukemia Group B studies. Cancer Treat Rep. 1982;66(4):835-46.  
52. Hancock SL, Cox RS, McDougall IR. Thyroid diseases after treatment of Hodgkin's disease. N Engl J Med. 1991;325(9):599-605.  
53. Knobel H, Havard Loge J, Lund MB, Forfang K, Nome O, Kaasa S. Late medical complications and fatigue in Hodgkin's disease survivors. J Clin Oncol. 2001;19(13):3226-33.  
54. Aisenberg AC, Finkelstein DM, Doppke KP, Koerner FC, Boivin JF, Willett CG. High risk of breast carcinoma after irradiation of young women with Hodgkin's disease. Cancer. 1997;79(6):1203-10.  
55. Chen R, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al. Fiveyear survival and durability results of brentuximab vedotin in patients with relapsed or refractory Hodgkin lymphoma. Blood. 2016;128(12):1562-6.  
56. Bachanova V, Connors JM. Hodgkin lymphoma in pregnancy. Curr Hematol Malig Rep. 2013;8(3):211-7.  
57. Lishner M, Zemlickis D, Degendorfer P, Panzarella T, Sutcliffe SB, Koren G. Maternal and foetal outcome following Hodgkin's disease in pregnancy. Br J Cancer. 1992;65(1):114-7.  
58. Zanotti-Fregonara P, Jan S, Taieb D, Cammilleri S, Trebossen R, Hindie E, et al. Absorbed 18F-FDG dose to the fetus during early pregnancy. J Nucl Med. 2010;51(5):803-5.  
59. O'Connor SJ, Verma H, Grubnic S, Rayner CF. Chest radiographs in pregnancy. BMJ. 2009;339:b4057.  
60. Connors JM. Challenging problems: coincident pregnancy, HIV infection, and older age. Hematology Am Soc Hematol Educ Program. 2008:334-9.  
61. Eyre TA, Lau IJ, Mackillop L, Collins GP. Management and controversies of classical Hodgkin lymphoma in pregnancy. Br J Haematol. 2015;169(5):613-30.  
62. Evens AM, Advani R, Press OW, Lossos IS, Vose JM, Hernandez-Ilizaliturri FJ, et al. Lymphoma occurring during pregnancy: antenatal therapy, complications, and maternal survival in a multicenter analysis. J Clin Oncol. 2013;31(32):4132-9.  
63. Mazonakis M, Lyraraki E, Varveris C, Samara E, Zourari K, Damilakis J. Conceptus dose from involved-field radiotherapy for Hodgkin's lymphoma on a linear accelerator equipped with MLCs. Strahlenther Onkol. 2009;185(6):355-63.  
64. Friedman E, Jones GW. Fetal outcome after maternal radiation treatment of supradiaphragmatic Hodgkin's disease. CMAJ. 1993;149(9):1281-3.  
65. Boll B, Gorgen H. The treatment of older Hodgkin lymphoma patients. Br J Haematol. 2019;184(1):82-92.  
66. Shenoy P, Maggioncalda A, Malik N, Flowers CR. Incidence patterns and outcomes for hodgkin lymphoma patients in the United States. Adv Hematol. 2011;2011:725219.  
67. Bjorkholm M, Weibull CE, Eloranta S, Smedby KE, Glimelius I, Dickman PW. Greater attention should be paid to developing therapies for elderly patients with Hodgkin lymphoma-A population-based study from Sweden. Eur J Haematol. 2018;101(1):10614.  
68. Deeken JF, Tjen ALA, Rudek MA, Okuliar C, Young M, Little RF, et al. The rising challenge of non-AIDS-defining cancers in HIV-infected patients. Clin Infect Dis. 2012;55(9):1228-35.  
69. Uldrick TS, Little RF. How I treat classical Hodgkin lymphoma in patients infected with human immunodeficiency virus. Blood. 2015;125(8):1226-35; quiz 355. 70. Tan B, Ratner L. The use of new antiretroviral therapy in combination with chemotherapy. Curr Opin Oncol. 1997;9(5):455-64.  
71. Gopal S, Patel MR, Yanik EL, Cole SR, Achenbach CJ, Napravnik S, et al. Association of early HIV viremia with mortality after HIV-associated lymphoma. AIDS. 2013;27(15):2365-73.  
72. Montoto S, Shaw K, Okosun J, Gandhi S, Fields P, Wilson A, et al. HIV status does not influence outcome in patients with classical Hodgkin lymphoma treated with chemotherapy using doxorubicin, bleomycin, vinblastine, and dacarbazine in the highly active antiretroviral therapy era. J Clin Oncol. 2012;30(33):4111-6.  
73. Hentrich M, Berger M, Wyen C, Siehl J, Rockstroh JK, Muller M, et al. Stageadapted treatment of HIV-associated Hodgkin lymphoma: results of a prospective multicenter study. J Clin Oncol. 2012;30(33):4117-23.  
74. Dryver ET, Jernstrom H, Tompkins K, Buckstein R, Imrie KR. Follow-up of patients with Hodgkin's disease following curative treatment: the routine CT scan is of little value. Br J Cancer. 2003;89(3):482-6.  
75. Wongso D, Fuchs M, Plutschow A, Klimm B, Sasse S, Hertenstein B, et al. Treatment-related mortality in patients with advanced-stage hodgkin lymphoma: an analysis of the german hodgkin study group. J Clin Oncol. 2013;31(22):2819-24.  
76. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Regulação AeCCGdSdI. Manual de bases técnicas da oncologia - SIA/SUS - Sistema de Informações Ambulatoriais 2019. Disponível em: <u>ftp://arpoador.datasus.gov.br/siasus/Documentos/APAC/Manual_Oncologia_26a_edica o.pdf</u> .  
77. Brasil. Ministério da Saúde. Secretaria de Vigilância Sanitária. Protocolo Clínico e Diretrizes Terapêuticas para manejo da infecção pelo HIV em Adultos. Disponível em: http://www.aids.gov.br/pt-br/pub/2013/protocolo-clinico-e-diretrizes-terapeuticas-paramanejo-da-infeccao-pelo-hiv-em-adultos.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **1.** **<u>Escopo e finalidade do Protocolo</u>** -->
A demanda pelo Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Linfoma de Hodgkin surgiu a partir da incorporação do brentuximabe vedotina para o tratamento de pacientes com linfoma de Hodgkin CD30+ refratário ou recidivado após transplante autólogo de células tronco, em março de 2013, sendo necessárias diretrizes para viabilização do acesso à tecnologia<sup>38</sup> .  
O desenvolvimento do PCDT do Linfoma de Hodgkin teve início com reunião presencial para delimitação do escopo do Protocolo. Esta reunião foi composta por três membros do Comitê Gestor e por cinco membros do grupo elaborador, sendo dois especialistas hematologistas, dois metodologistas e a coordenadora administrativa do projeto PCDT no Hospital Alemão Oswaldo Cruz. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **2.** **<u>Equipe de elaboração e partes interessadas</u>** -->
A reunião presencial para definição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida com a presença de membros do Grupo Elaborador. Todos os participantes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **<u>Colaboração externa</u>** -->
Esse PCDT contou com a participação de especialistas da Santa Casa de São Paulo, do Hospital de Base de Brasília e do Instituto Nacional do Câncer.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
A proposta de elaboração PCDT do Linfoma de Hodgkin foi apresentada na 76º Reunião da Subcomissão Técnica de PCDT, realizada em janeiro de 2020. A reunião teve  
a presença de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SCTIE/MS), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e Departamento de Atenção Especializada e Temática (DAET/SAES/MS). Após a reunião da Subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 86ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **<u>Consulta pública</u>** -->
A Consulta Pública nº 11/2020, das Diretrizes Diagnósticas e Terapêuticas do Linfoma de Hodgkin, foi realizada entre os dias 20/03/2020 a 08/04/2020. Foram recebidas 247 contribuições, que podem ser verificadas em: <u>http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_11_2020_D DT_Linfoma.pdf.</u>

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **3.** **<u>Busca da evidência</u>** -->
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento da DDT, sendo definida a macroestrutura do Protocolo, embasado no disposto em Portaria N° 375/SAS/MS, de 10 de novembro de 2009 (78) e nas Diretrizes de Elaboração de Diretrizes Clínicas do Ministério da Saúde (79), sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Deste modo, as especialistas foram orientadas a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO ( **Figura A** ) para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além  
de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta  
|P|•População ou condição clínica|
|---|---|
|I|•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos<br>observacionais<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica|
|C|•Controle, de acordo com tratamento/níveis de<br>exposição do fator/exames disponíveis no SUS|
|O|•Desfechos: sempre que possível, definidos a<br>priori, de acordo com sua importância|  
reunião.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO -->
Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.  
Caso fossem elencadas questões de pesquisa, acordou-se que a equipe de metodologistas envolvida no processo ficaria responsável pela busca, seleção e extração de dados provenientes da literatura, de acordo com padrões adequados para manter o rigor metodológico do processo. As evidências seriam avaliadas segundo metodologia GRADE, com avaliação do corpo de evidências para cada desfecho (80).  
Para o desenvolvimento da presente DDT, não foram identificadas novas tecnologias que necessitassem ser avaliadas por meio de revisão sistemática. Deste modo, nenhuma pergunta PICO foi elencada para sua elaboração e uma única busca a respeito de diagnóstico, tratamento e recomendações relativas ao linfoma de Hodgkin (detalhada ao longo do anexo metodológico) foi feita para a escrita das diferentes seções do Protocolo.  
A relatoria das seções foi distribuída entre os especialistas posteriormente à circulação da ata da reunião de escopo para que pudesse contemplar um dos especialistas hematologistas que não pode estar presente na reunião de escopo. Como não foram  
elencadas questões de pesquisa, os especialistas foram orientados a proceder à escrita do texto baseados nas melhores e mais atuais evidências disponíveis acerca da doença, fazendo-se recomendações pautadas em prática clínica estabelecidas e apenas com as tecnologias já disponíveis no SUS com indicação para a condição. Também foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica e nos _guidelines_ internacionais ou nas revisões sistemáticas procedidas por meio de metodologia consistente.  
Ao final, a escrita do texto da DDT contou com a participação de três especialistas hematologistas e de quatro metodologistas do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **A. Estratégia de Busca** -->
Uma única busca foi realizada com o objetivo de localizar evidências disponíveis acerca do diagnóstico e tratamento do linfoma de Hodgkin. A busca foi realizada na base Espistemonikos e a estratégia pode ser vista no **Quadro A** . Também foram utilizadas referências sugeridas pelos especialistas.  
**Quadro A -** Estratégia de busca nas bases de dados  
|**Base de**<br>**dados**||**Estratégia de busca**|**Resultados**|
|---|---|---|---|
|Epistemonikos|(title:(hodgkin<br>lymphoma))|lymphoma)<br>OR<br>abstract:(hodgkin|362|

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **B. Seleção dos Estudos** -->
Na seleção das evidências, foram priorizadas revisões sistemáticas e _guidelines_ desenvolvidos por associações internacionais na área de oncologia. Caso houvesse mais de uma versão das publicações, considerou-se a versão mais atual e mais completa. Somadas a estas referências, foram incluídos os estudos indicados e utilizados pelos especialistas para a escrita do texto.  O processo de seleção das evidências pode ser visto na **Figura B** .  
<!-- Start of picture text -->
Publicações identificadas pela pesquisa na base de<br>dado: 362<br>Identificação<br>Indicação dos especialistas: 81<br>Seleção<br>Publicações após remoção de duplicatas: 443 Publicações excluídas segundo critérios<br>de exclusão: 376<br>Publicações excluídas segundo critérios<br>de exclusão: 34<br>Elegibilidade<br>Publicações selecionadas para leitura completa: 102<br>Tipo de publicação: 23<br>Tipo de desfecho: 3<br>Tipo de comparador: 4<br>Tipo de estudo: 2<br>Estudos incluídos: 68<br>Incluídos<br>RS: 2<br>Guidelines: 2<br>Estudos primários: 64<br><!-- End of picture text -->  
**Figura B -** Fluxograma de seleção dos estudos  
Os estudos selecionados foram consultados como um todo para embasar a escrita do texto em suas diferentes seções. Deste modo, não foram extraídos dados específicos das publicações. No **Quadro B** constam os estudos utilizados para a escrita do texto.  
**Quadro B -** Estudos selecionados para embasar o texto do PCDT do linfoma de Hodgkin  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Cheson BD, Fisher RI, Barrington SF, Cavalli F, Schwartz LH, Zucca E, et al.<br>Recommendations for initial evaluation, staging, and response assessment of<br>Hodgkin and non-Hodgkin lymphoma: the Lugano classification. J Clin Oncol.<br>2014;32(27):3059-68.|(9)|
|Mauch PM, Kalish LA, Kadin M, Coleman CN, Osteen R, Hellman S. Patterns<br>of presentation of Hodgkin disease. Implications for etiology and pathogenesis.<br>Cancer. 1993;71(6):2062-71.|(10)|
|Swerdlow SH, Campo E, Harris NL, al e. WHO classification of tumours of<br>haematopoietic and lymphoid tissues. 4th ed. Lyon, France: IARC; 2008.|(11)|
|Pappa VI, Hussain HK, Reznek RH, Whelan J, Norton AJ, Wilson AM, et al.<br>Role of image-guided core-needle biopsy in the management of patients with<br>lymphoma. J Clin Oncol. 1996;14(9):2427-30.|(13)|
|Hehn ST, Grogan TM, Miller TP. Utility of fine-needle aspiration as a diagnostic<br>technique in lymphoma. J Clin Oncol. 2004;22(15):3046-52.|(14)|
|Barrington SF, Mikhaeel NG, Kostakoglu L, Meignan M, Hutchings M, Mueller<br>SP, et al. Role of imaging in the staging and response assessment of lymphoma:<br>consensus of the International Conference on Malignant Lymphomas Imaging<br>Working Group. J Clin Oncol. 2014;32(27):3048-58.|(16)|
|El-Galaly TC, d'Amore F, Mylam KJ, de Nully Brown P, Bogsted M, Bukh A,<br>et al. Routine bone marrow biopsy has little or no therapeutic consequence for<br>positron emission tomography/computed tomography-staged treatment-naive<br>patients with Hodgkin lymphoma. J Clin Oncol. 2012;30(36):4508-14.|(17)|
|Carbone PP, Kaplan HS, Musshoff K, Smithers DW, Tubiana M. Report of the<br>Committee on Hodgkin's Disease Staging Classification. Cancer Res.<br>1971;31(11):1860-1.|(19)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Sieber M, Engert A, Diehl V. Treatment of Hodgkin's disease: results and current<br>concepts of the German Hodgkin's Lymphoma Study Group. Ann Oncol.<br>2000;11 Suppl 1:81-5.|(20)|
|Carde P, Hagenbeek A, Hayat M, Monconduit M, Thomas J, Burgers MJ, et al.<br>Clinical staging versus laparotomy and combined modality with MOPP versus<br>ABVD in early-stage Hodgkin's disease: the H6 twin randomized trials from the<br>European Organization for Research and Treatment of Cancer Lymphoma<br>Cooperative Group. J Clin Oncol. 1993;11(11):2258-72.|(21)|
|National Comprehensive Cancer Network. Lymphomas: Hodgkin Lymphoma<br>[Internet].<br>2019<br>[Available<br>from:<br>https://www.nccn.org/professionals/physician_gls/pdf/hodgkins.pdf.|(22)|
|Hasenclever D, Diehl V. A prognostic score for advanced Hodgkin's disease.<br>International Prognostic Factors Project on Advanced Hodgkin's Disease. N Engl<br>J Med. 1998;339(21):1506-14.|(23)|
|Brockelmann PJ, Eichenauer DA, Jakob T, Follmann M, Engert A, Skoetz N.<br>Hodgkin Lymphoma in Adults. Dtsch Arztebl Int. 2018;115(31-32):535-40.|(24)|
|von Tresckow B, Engert A. Refractory Hodgkin lymphoma. Curr Opin Oncol.<br>2013;25(5):463-9.|(25)|
|Josting A, Rudolph C, Reiser M, Mapara M, Sieber M, Kirchner HH, et al. Time-<br>intensified dexamethasone/cisplatin/cytarabine: an effective salvage therapy<br>with low toxicity in patients with relapsed and refractory Hodgkin's disease. Ann<br>Oncol. 2002;13(10):1628-35.|(29)|
|Moskowitz CH, Nimer SD, Zelenetz AD, Trippett T, Hedrick EE, Filippa DA,<br>et al. A 2-step comprehensive high-dose chemoradiotherapy second-line<br>program for relapsed and refractory Hodgkin disease: analysis by intent to treat<br>and development of a prognostic model. Blood. 2001;97(3):616-23.|(30)|
|Rancea M, Monsef I, von Tresckow B, Engert A, Skoetz N. High-dose<br>chemotherapy followed by autologous stem cell transplantation for patients with<br>relapsed/refractory Hodgkin lymphoma. Cochrane Database Syst Rev.<br>2013(6):CD009411.|(31)|
|Younes A, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al.<br>Results of a pivotal phase II study of brentuximab vedotin for patients with<br>relapsed or refractory Hodgkin's lymphoma. J Clin Oncol. 2012;30(18):2183-9.|(32)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Gopal AK, Ramchandren R, O'Connor OA, Berryman RB, Advani RH, Chen R,<br>et al. Safety and efficacy of brentuximab vedotin for Hodgkin lymphoma<br>recurring after allogeneic stem cell transplantation. Blood. 2012;120(3):560-8.|(34)|
|Aldin A, Umlauff L, Estcourt LJ, Collins G, Moons KG, Engert A, et al. Interim<br>PET-results for prognosis in adults with Hodgkin lymphoma: a systematic<br>review and meta-analysis of prognostic factor studies. Cochrane Database Syst<br>Rev. 2019;9:CD012643.|(35)|
|Moskowitz AJ, Schoder H, Yahalom J, McCall SJ, Fox SY, Gerecitano J, et al.<br>PET-adapted sequential salvage therapy with brentuximab vedotin followed by<br>augmented ifosamide, carboplatin, and etoposide for patients with relapsed and<br>refractory Hodgkin's lymphoma: a non-randomised, open-label, single-centre,<br>phase 2 study. Lancet Oncol. 2015;16(3):284-92.|(36)|
|Sibon D, Morschhauser F, Resche-Rigon M, Ghez D, Dupuis J, Marcais A, et al.<br>Single or tandem autologous stem-cell transplantation for first-relapsed or<br>refractory Hodgkin lymphoma: 10-year follow-up of the prospective H96 trial<br>by the LYSA/SFGM-TC study group. Haematologica. 2016;101(4):474-81.|(37)|
|Eichenauer DA, Engert A. Nodular lymphocyte-predominant Hodgkin<br>lymphoma: a unique disease deserving unique management. Hematology Am<br>Soc Hematol Educ Program. 2017;2017(1):324-8.|(39)|
|Eichenauer DA, Plutschow A, Fuchs M, von Tresckow B, Boll B, Behringer K,<br>et al. Long-Term Course of Patients With Stage IA Nodular Lymphocyte-<br>Predominant Hodgkin Lymphoma: A Report From the German Hodgkin Study<br>Group. J Clin Oncol. 2015;33(26):2857-62.|(40)|
|Ministério da Saúde - Secretaria de Atenção à Saúde. Diretrizes Diagnósticas e<br>Terapêuticas em Oncologia - Linfoma difuso de grandes células B no adulto<br>2012<br>[Available<br>from:<br>http://conitec.gov.br/images/Protocolos/DDT/LinfomaDifuso_GrandesCelB.pd<br>f.|(41)|
|Gospodarowicz MK, Meyer RM. The management of patients with limited-stage<br>classical Hodgkin lymphoma. Hematology Am Soc Hematol Educ Program.<br>2006:253-8.|(42)|
|Engert A, Franklin J, Eich HT, Brillant C, Sehlen S, Cartoni C, et al. Two cycles<br>of doxorubicin, bleomycin, vinblastine, and dacarbazine plus extended-field<br>radiotherapyis superior to radiotherapyalone in earlyfavorable Hodgkin's|(43)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|lymphoma: final results of the GHSG HD7 trial. J Clin Oncol.<br>2007;25(23):3495-502.||
|Specht L, Yahalom J, Illidge T, Berthelsen AK, Constine LS, Eich HT, et al.<br>Modern radiation therapy for Hodgkin lymphoma: field and dose guidelines<br>from the international lymphoma radiation oncology group (ILROG). Int J<br>Radiat Oncol Biol Phys. 2014;89(4):854-62.|(44)|
|Meyer RM, Gospodarowicz MK, Connors JM, Pearcey RG, Wells WA, Winter<br>JN, et al. ABVD alone versus radiation-based therapy in limited-stage Hodgkin's<br>lymphoma. N Engl J Med. 2012;366(5):399-408.|(45)|
|Skoetz N, Will A, Monsef I, Brillant C, Engert A, von Tresckow B. Comparison<br>of first-line chemotherapy including escalated BEACOPP versus chemotherapy<br>including ABVD for people with early unfavourable or advanced stage Hodgkin<br>lymphoma. Cochrane Database Syst Rev. 2017;5:CD007941.|(46)|
|Barrington SF, Kluge R. FDG PET for therapy monitoring in Hodgkin and non-<br>Hodgkin lymphomas. Eur J Nucl Med Mol Imaging. 2017;44(Suppl 1):97-110.|(47)|
|Borchmann S, Engert A, Boll B. Hodgkin lymphoma in elderly patients. Curr<br>Opin Oncol. 2018;30(5):308-16.|(48)|
|Radford J, Illidge T, Counsell N, Hancock B, Pettengell R, Johnson P, et al.<br>Results of a trial of PET-directed therapy for early-stage Hodgkin's lymphoma.<br>N Engl J Med. 2015;372(17):1598-607.|(49)|
|Aviles A, Delgado S. A prospective clinical trial comparing chemotherapy,<br>radiotherapy and combined therapy in the treatment of early stage Hodgkin's<br>disease with bulky disease. Clin Lab Haematol. 1998;20(2):95-9.|(50)|
|Bloomfield CD, Pajak TF, Glicksman AS, Gottlieb AJ, Coleman M, Nissen NI,<br>et al. Chemotherapy and combined modality therapy for Hodgkin's disease: a<br>progress report on Cancer and Leukemia Group B studies. Cancer Treat Rep.<br>1982;66(4):835-46.|(51)|
|Hancock SL, Cox RS, McDougall IR. Thyroid diseases after treatment of<br>Hodgkin's disease. N Engl J Med. 1991;325(9):599-605.|(52)|
|Knobel H, Havard Loge J, Lund MB, Forfang K, Nome O, Kaasa S. Late medical<br>complications and fatigue in Hodgkin's disease survivors. J Clin Oncol.<br>2001;19(13):3226-33.|(53)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Aisenberg AC, Finkelstein DM, Doppke KP, Koerner FC, Boivin JF, Willett CG.<br>High risk of breast carcinoma after irradiation of young women with Hodgkin's<br>disease. Cancer. 1997;79(6):1203-10.|(54)|
|Chen R, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al. Five-<br>year survival and durability results of brentuximab vedotin in patients with<br>relapsed or refractory Hodgkin lymphoma. Blood. 2016;128(12):1562-6.|(55)|
|Bachanova V, Connors JM. Hodgkin lymphoma in pregnancy. Curr Hematol<br>Malig Rep. 2013;8(3):211-7.|(56)|
|Lishner M, Zemlickis D, Degendorfer P, Panzarella T, Sutcliffe SB, Koren G.<br>Maternal and foetal outcome following Hodgkin's disease in pregnancy. Br J<br>Cancer. 1992;65(1):114-7.|(57)|
|Zanotti-Fregonara P, Jan S, Taieb D, Cammilleri S, Trebossen R, Hindie E, et al.<br>Absorbed 18F-FDG dose to the fetus during early pregnancy. J Nucl Med.<br>2010;51(5):803-5.|(58)|
|O'Connor SJ, Verma H, Grubnic S, Rayner CF. Chest radiographs in pregnancy.<br>BMJ. 2009;339:b4057 .|(59)|
|Connors JM. Challenging problems: coincident pregnancy, HIV infection, and<br>older age. Hematology Am Soc Hematol Educ Program. 2008:334-9.|(60)|
|Eyre TA, Lau IJ, Mackillop L, Collins GP. Management and controversies of<br>classical Hodgkin lymphoma in pregnancy. Br J Haematol. 2015;169(5):613-30.|(61)|
|Evens AM, Advani R, Press OW, Lossos IS, Vose JM, Hernandez-Ilizaliturri FJ,<br>et al. Lymphoma occurring during pregnancy: antenatal therapy, complications,<br>and maternal survival in a multicenter analysis. J Clin Oncol. 2013;31(32):4132-<br>9.|(62)|
|Mazonakis M, Lyraraki E, Varveris C, Samara E, Zourari K, Damilakis J.<br>Conceptus dose from involved-field radiotherapy for Hodgkin's lymphoma on a<br>linear accelerator equipped with MLCs. Strahlenther Onkol. 2009;185(6):355-<br>63.|(63)|
|Friedman E, Jones GW. Fetal outcome after maternal radiation treatment of<br>supradiaphragmatic Hodgkin's disease. CMAJ. 1993;149(9):1281-3.|(64)|
|Boll B, Gorgen H. The treatment of older Hodgkin lymphoma patients. Br J<br>Haematol. 2019;184(1):82-92.|(65)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Shenoy P, Maggioncalda A, Malik N, Flowers CR. Incidence patterns and<br>outcomes for hodgkin lymphoma patients in the United States. Adv Hematol.<br>2011;2011:725219.|(66)|
|Bjorkholm M, Weibull CE, Eloranta S, Smedby KE, Glimelius I, Dickman PW.<br>Greater attention should be paid to developing therapies for elderly patients with<br>Hodgkin lymphoma-A population-based study from Sweden. Eur J Haematol.<br>2018;101(1):106-14.|(67)|
|Deeken JF, Tjen ALA, Rudek MA, Okuliar C, Young M, Little RF, et al. The<br>rising challenge of non-AIDS-defining cancers in HIV-infected patients. Clin<br>Infect Dis. 2012;55(9):1228-35.|(68)|
|Uldrick TS, Little RF. How I treat classical Hodgkin lymphoma in patients<br>infected with human immunodeficiency virus. Blood. 2015;125(8):1226-35;<br>quiz 355.|(69)|
|Tan B, Ratner L. The use of new antiretroviral therapy in combination with<br>chemotherapy. Curr Opin Oncol. 1997;9(5):455-64.|(70)|
|Gopal S, Patel MR, Yanik EL, Cole SR, Achenbach CJ, Napravnik S, et al.<br>Association of early HIV viremia with mortality after HIV-associated<br>lymphoma. AIDS. 2013;27(15):2365-73.|(71)|
|Montoto S, Shaw K, Okosun J, Gandhi S, Fields P, Wilson A, et al. HIV status<br>does not influence outcome in patients with classical Hodgkin lymphoma treated<br>with chemotherapy using doxorubicin, bleomycin, vinblastine, and dacarbazine<br>in the highly active antiretroviral therapy era. J Clin Oncol. 2012;30(33):4111-<br>6.|(73)|
|Hentrich M, Berger M, Wyen C, Siehl J, Rockstroh JK, Muller M, et al. Stage-<br>adapted treatment of HIV-associated Hodgkin lymphoma: results of a<br>prospective multicenter study. J Clin Oncol. 2012;30(33):4117-23.|(74)|
|Dryver ET, Jernstrom H, Tompkins K, Buckstein R, Imrie KR. Follow-up of<br>patients with Hodgkin's disease following curative treatment: the routine CT<br>scan is of little value. Br J Cancer. 2003;89(3):482-6.|(75)|
|Wongso D, Fuchs M, Plutschow A, Klimm B, Sasse S, Hertenstein B, et al.<br>Treatment-related mortality in patients with advanced-stage hodgkin lymphoma:<br>an analysis of the german hodgkin study group. J Clin Oncol. 2013;31(22):2819-<br>24.|(76)|  
|**Estudo**|**Referênc**<br>**ia**|
|---|---|
|Brasil. Ministério da Saúde/ Secretaria de Atenção à Saúde/ Departamento de|(77)|
|Regulação AeCCGdSdI. Manual de bases técnicas da oncologia - SIA/SUS -||
|Sistema<br>de<br>Informações<br>Ambulatoriais<br>2019.<br>Disponível<br>em||
|ftp://arpoador.datasus.gov.br/siasus/Documentos/APAC/Manual_Oncologia_26<br>a_edicao.pdf .||

---

<!-- METADADOS: doenca: Linfoma de Hodgkin no Adulto | secao: **REFERÊNCIAS** -->
1. DeVita VT, Lawrence TS, Rosenberg SA. DeVita, Hellman, and Rosenberg's cancer: principles & practice of oncology. Chapter 102: Hodgkin’s lymphoma: Lippincott Williams & Wilkins; 2015.  
2. Cokkinides V, Albano J, Samuels A, Ward M, Thum J. American cancer society: Cancer facts and figures. Atlanta: American Cancer Society. 2019.  
3. Estimativa 2018: incidência de câncer no Brasil / Instituto Nacional de Câncer José Alencar Gomes da Silva. Coordenação de Prevenção e Vigilância. Rio de Janeiro: INCA; 2017.  
4. Laurent C, Do C, Gourraud PA, de Paiva GR, Valmary S, Brousset P. Prevalence of Common Non-Hodgkin Lymphomas and Subtypes of Hodgkin Lymphoma by Nodal Site of Involvement: A Systematic Retrospective Review of 938 Cases. Medicine (Baltimore). 2015;94(25):e987.  
5. Araujo I, Bittencourt AL, Barbosa HS, Netto EM, Mendonca N, Foss HD, et al. The high frequency of EBV infection in pediatric Hodgkin lymphoma is related to the classical type in Bahia, Brazil. Virchows Arch. 2006;449(3):315-9.  
6. Eichenauer DA, Aleman BMP, Andre M, Federico M, Hutchings M, Illidge T, et al. Hodgkin lymphoma: ESMO Clinical Practice Guidelines for diagnosis, treatment and followup. Ann Oncol. 2018;29(Suppl 4):iv19-iv29.  
7. Spinner MA, Advani RH, Connors JM, Azzi J, Diefenbach C. New Treatment Algorithms in Hodgkin Lymphoma: Too Much or Too Little? Am Soc Clin Oncol Educ Book. 2018;38:626-36.  
8. Sabattini E, Bacci F, Sagramoso C, Pileri SA. WHO classification of tumours of haematopoietic and lymphoid tissues in 2008: an overview. Pathologica. 2010;102(3):83-7.  
9. Cheson BD, Fisher RI, Barrington SF, Cavalli F, Schwartz LH, Zucca E, et al. Recommendations for initial evaluation, staging, and response assessment of Hodgkin and nonHodgkin lymphoma: the Lugano classification. J Clin Oncol. 2014;32(27):3059-68.  
10. Mauch PM, Kalish LA, Kadin M, Coleman CN, Osteen R, Hellman S. Patterns of presentation of Hodgkin disease. Implications for etiology and pathogenesis. Cancer. 1993;71(6):2062-71.  
11. Swerdlow SH, Campo E, Harris NL, al e. WHO classification of tumours of haematopoietic and lymphoid tissues. 4th ed. Lyon, France: IARC; 2008.  
12. Alguirre PC MB. Skin Biopsy Techniques for the Internist. J Gen Intern Med. 1998;13(1):46-54.  
13. Pappa VI, Hussain HK, Reznek RH, Whelan J, Norton AJ, Wilson AM, et al. Role of image-guided core-needle biopsy in the management of patients with lymphoma. J Clin Oncol. 1996;14(9):2427-30.  
14. Hehn ST, Grogan TM, Miller TP. Utility of fine-needle aspiration as a diagnostic technique in lymphoma. J Clin Oncol. 2004;22(15):3046-52.  
15. Brasil. PET-CT no Estadiamento e Avaliação da Resposta ao Tratamento dos Linfomas. In: Saúde Md, editor. Brasília2014.  
16. Barrington SF, Mikhaeel NG, Kostakoglu L, Meignan M, Hutchings M, Mueller SP, et al. Role of imaging in the staging and response assessment of lymphoma: consensus of the International Conference on Malignant Lymphomas Imaging Working Group. J Clin Oncol. 2014;32(27):3048-58.  
17. El-Galaly TC, d'Amore F, Mylam KJ, de Nully Brown P, Bogsted M, Bukh A, et al. Routine bone marrow biopsy has little or no therapeutic consequence for positron emission tomography/computed tomography-staged treatment-naive patients with Hodgkin lymphoma. J Clin Oncol. 2012;30(36):4508-14.  
18. Brasil. Manual de Recomendações para o Controle da Tuberculose no Brasil. In: Saúde Md, editor. 2ª Ed. ed. Brasília: Ministério da Saúde; 2019.  
19. Carbone PP, Kaplan HS, Musshoff K, Smithers DW, Tubiana M. Report of the Committee on Hodgkin's Disease Staging Classification. Cancer Res. 1971;31(11):1860-1.  
20. Sieber M, Engert A, Diehl V. Treatment of Hodgkin's disease: results and current concepts of the German Hodgkin's Lymphoma Study Group. Ann Oncol. 2000;11 Suppl 1:815.  
21. Carde P, Hagenbeek A, Hayat M, Monconduit M, Thomas J, Burgers MJ, et al. Clinical staging versus laparotomy and combined modality with MOPP versus ABVD in early-stage Hodgkin's disease: the H6 twin randomized trials from the European Organization for Research and Treatment of Cancer Lymphoma Cooperative Group. J Clin Oncol. 1993;11(11):2258-72.  
22. National Comprehensive Cancer Network. Lymphomas: Hodgkin Lymphoma [Internet]. 2019 [Available from: <u>https://www.nccn.org/professionals/physician_gls/pdf/hodgkins.pdf.</u>  
23. Hasenclever D, Diehl V. A prognostic score for advanced Hodgkin's disease. International Prognostic Factors Project on Advanced Hodgkin's Disease. N Engl J Med. 1998;339(21):1506-14.  
24. Brockelmann PJ, Eichenauer DA, Jakob T, Follmann M, Engert A, Skoetz N. Hodgkin Lymphoma in Adults. Dtsch Arztebl Int. 2018;115(31-32):535-40.  
25. von Tresckow B, Engert A. Refractory Hodgkin lymphoma. Curr Opin Oncol. 2013;25(5):463-9.  
26. Bonadonna G, Zucali R, Monfardini S, De Lena M, Uslenghi C. Combination chemotherapy of Hodgkin's disease with adriamycin, bleomycin, vinblastine, and imidazole carboxamide versus MOPP. Cancer. 1975;36(1):252-9.  
27. Diehl V, Franklin J, Pfreundschuh M, Lathan B, Paulus U, Hasenclever D, et al. Standard and increased-dose BEACOPP chemotherapy compared with COPP-ABVD for advanced Hodgkin's disease. N Engl J Med. 2003;348(24):2386-95.  
28. Loeffler M, Hasenclever D, Diehl V. Model based development of the BEACOPP regimen for advanced stage Hodgkin's disease. German Hodgkin's Lymphoma Study Group. Ann Oncol. 1998;9 Suppl 5:S73-8.  
29. Josting A, Rudolph C, Reiser M, Mapara M, Sieber M, Kirchner HH, et al. Timeintensified dexamethasone/cisplatin/cytarabine: an effective salvage therapy with low toxicity in patients with relapsed and refractory Hodgkin's disease. Ann Oncol. 2002;13(10):1628-35.  
30. Moskowitz CH, Nimer SD, Zelenetz AD, Trippett T, Hedrick EE, Filippa DA, et al. A 2-step comprehensive high-dose chemoradiotherapy second-line program for relapsed and refractory Hodgkin disease: analysis by intent to treat and development of a prognostic model. Blood. 2001;97(3):616-23.  
31. Rancea M, Monsef I, von Tresckow B, Engert A, Skoetz N. High-dose chemotherapy followed by autologous stem cell transplantation for patients with relapsed/refractory Hodgkin lymphoma. Cochrane Database Syst Rev. 2013(6):CD009411.  
32. Younes A, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al. Results of a pivotal phase II study of brentuximab vedotin for patients with relapsed or refractory Hodgkin's lymphoma. J Clin Oncol. 2012;30(18):2183-9.  
33. Takeda Pharma LTDA: Adcetris. Nova indicação de Adcetris (brentuximabe vedotina) [Available from: <u>http://portal.anvisa.gov.br/informacoestecnicas13?p_p_id=101_INSTANCE_WvKKx2fhdjM2&p_p_col_id=column2&p_p_col_pos=1&p_p_col_count=2&_101_INSTANCE_WvKKx2fhdjM2_groupId=21920 1&_101_INSTANCE_WvKKx2fhdjM2_urlTitle=adcetris-brentuximabe-vedotina-novaindicacao&_101_INSTANCE_WvKKx2fhdjM2_struts_action=%2Fasset_publisher%2Fview _content&_101_INSTANCE_WvKKx2fhdjM2_assetEntryId=5555907&_101_INSTANCE_ WvKKx2fhdjM2_type=content.</u>  
34. Gopal AK, Ramchandren R, O'Connor OA, Berryman RB, Advani RH, Chen R, et al. Safety and efficacy of brentuximab vedotin for Hodgkin lymphoma recurring after allogeneic stem cell transplantation. Blood. 2012;120(3):560-8.  
35. Aldin A, Umlauff L, Estcourt LJ, Collins G, Moons KG, Engert A, et al. Interim PETresults for prognosis in adults with Hodgkin lymphoma: a systematic review and meta-analysis of prognostic factor studies. Cochrane Database Syst Rev. 2019;9:CD012643.  
36. Moskowitz AJ, Schoder H, Yahalom J, McCall SJ, Fox SY, Gerecitano J, et al. PETadapted sequential salvage therapy with brentuximab vedotin followed by augmented ifosamide, carboplatin, and etoposide for patients with relapsed and refractory Hodgkin's  
lymphoma: a non-randomised, open-label, single-centre, phase 2 study. Lancet Oncol. 2015;16(3):284-92.  
37. Sibon D, Morschhauser F, Resche-Rigon M, Ghez D, Dupuis J, Marcais A, et al. Single or tandem autologous stem-cell transplantation for first-relapsed or refractory Hodgkin lymphoma: 10-year follow-up of the prospective H96 trial by the LYSA/SFGM-TC study group. Haematologica. 2016;101(4):474-81.  
38. Brasil. Portaria nº 12/SCTIE/MS, de 11 de março de 2019. Torna pública a decisão de incorporar o brentuximabe vedotina para o tratamento de pacientes adultos com linfoma de Hodgkin refratário ou recidivado após transplante autólogo de célulastronco hematopoéticas, no âmbito do Sistema Único de Saúde - SUS. In: Saúde Md, editor. 2019.  
39. Eichenauer DA, Engert A. Nodular lymphocyte-predominant Hodgkin lymphoma: a unique disease deserving unique management. Hematology Am Soc Hematol Educ Program. 2017;2017(1):324-8.  
40. Eichenauer DA, Plutschow A, Fuchs M, von Tresckow B, Boll B, Behringer K, et al. Long-Term Course of Patients With Stage IA Nodular Lymphocyte-Predominant Hodgkin Lymphoma: A Report From the German Hodgkin Study Group. J Clin Oncol. 2015;33(26):2857-62.  
41. Brasil. Portaria nº 956/SAS/MS, de 26 de setembro de 2014. Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Linfoma Difuso de Grandes Células B. In: Saúde Md, editor. 2014.  
42. Gospodarowicz MK, Meyer RM. The management of patients with limited-stage classical Hodgkin lymphoma. Hematology Am Soc Hematol Educ Program. 2006:253-8.  
43. Engert A, Franklin J, Eich HT, Brillant C, Sehlen S, Cartoni C, et al. Two cycles of doxorubicin, bleomycin, vinblastine, and dacarbazine plus extended-field radiotherapy is superior to radiotherapy alone in early favorable Hodgkin's lymphoma: final results of the GHSG HD7 trial. J Clin Oncol. 2007;25(23):3495-502.  
44. Specht L, Yahalom J, Illidge T, Berthelsen AK, Constine LS, Eich HT, et al. Modern radiation therapy for Hodgkin lymphoma: field and dose guidelines from the international lymphoma radiation oncology group (ILROG). Int J Radiat Oncol Biol Phys. 2014;89(4):85462.  
45. Meyer RM, Gospodarowicz MK, Connors JM, Pearcey RG, Wells WA, Winter JN, et al. ABVD alone versus radiation-based therapy in limited-stage Hodgkin's lymphoma. N Engl J Med. 2012;366(5):399-408.  
46. Skoetz N, Will A, Monsef I, Brillant C, Engert A, von Tresckow B. Comparison of firstline chemotherapy including escalated BEACOPP versus chemotherapy including ABVD for people with early unfavourable or advanced stage Hodgkin lymphoma. Cochrane Database Syst Rev. 2017;5:CD007941.  
47. Barrington SF, Kluge R. FDG PET for therapy monitoring in Hodgkin and non-Hodgkin lymphomas. Eur J Nucl Med Mol Imaging. 2017;44(Suppl 1):97-110.  
48. Borchmann S, Engert A, Boll B. Hodgkin lymphoma in elderly patients. Curr Opin Oncol. 2018;30(5):308-16.  
49. Radford J, Illidge T, Counsell N, Hancock B, Pettengell R, Johnson P, et al. Results of a trial of PET-directed therapy for early-stage Hodgkin's lymphoma. N Engl J Med. 2015;372(17):1598-607.  
50. Aviles A, Delgado S. A prospective clinical trial comparing chemotherapy, radiotherapy and combined therapy in the treatment of early stage Hodgkin's disease with bulky disease. Clin Lab Haematol. 1998;20(2):95-9.  
51. Bloomfield CD, Pajak TF, Glicksman AS, Gottlieb AJ, Coleman M, Nissen NI, et al. Chemotherapy and combined modality therapy for Hodgkin's disease: a progress report on Cancer and Leukemia Group B studies. Cancer Treat Rep. 1982;66(4):835-46.  
52. Hancock SL, Cox RS, McDougall IR. Thyroid diseases after treatment of Hodgkin's disease. N Engl J Med. 1991;325(9):599-605.  
53. Knobel H, Havard Loge J, Lund MB, Forfang K, Nome O, Kaasa S. Late medical complications and fatigue in Hodgkin's disease survivors. J Clin Oncol. 2001;19(13):3226-33.  
54. Aisenberg AC, Finkelstein DM, Doppke KP, Koerner FC, Boivin JF, Willett CG. High risk of breast carcinoma after irradiation of young women with Hodgkin's disease. Cancer. 1997;79(6):1203-10.  
55. Chen R, Gopal AK, Smith SE, Ansell SM, Rosenblatt JD, Savage KJ, et al. Five-year survival and durability results of brentuximab vedotin in patients with relapsed or refractory Hodgkin lymphoma. Blood. 2016;128(12):1562-6.  
56. Bachanova V, Connors JM. Hodgkin lymphoma in pregnancy. Curr Hematol Malig Rep. 2013;8(3):211-7.  
57. Lishner M, Zemlickis D, Degendorfer P, Panzarella T, Sutcliffe SB, Koren G. Maternal and foetal outcome following Hodgkin's disease in pregnancy. Br J Cancer. 1992;65(1):114-7.  
58. Zanotti-Fregonara P, Jan S, Taieb D, Cammilleri S, Trebossen R, Hindie E, et al. Absorbed 18F-FDG dose to the fetus during early pregnancy. J Nucl Med. 2010;51(5):803-5.  
59. O'Connor SJ, Verma H, Grubnic S, Rayner CF. Chest radiographs in pregnancy. BMJ. 2009;339:b4057.  
60. Connors JM. Challenging problems: coincident pregnancy, HIV infection, and older age. Hematology Am Soc Hematol Educ Program. 2008:334-9.  
61. Eyre TA, Lau IJ, Mackillop L, Collins GP. Management and controversies of classical Hodgkin lymphoma in pregnancy. Br J Haematol. 2015;169(5):613-30.  
62. Evens AM, Advani R, Press OW, Lossos IS, Vose JM, Hernandez-Ilizaliturri FJ, et al. Lymphoma occurring during pregnancy: antenatal therapy, complications, and maternal survival in a multicenter analysis. J Clin Oncol. 2013;31(32):4132-9.  
63. Mazonakis M, Lyraraki E, Varveris C, Samara E, Zourari K, Damilakis J. Conceptus dose from involved-field radiotherapy for Hodgkin's lymphoma on a linear accelerator equipped with MLCs. Strahlenther Onkol. 2009;185(6):355-63.  
64. Friedman E, Jones GW. Fetal outcome after maternal radiation treatment of supradiaphragmatic Hodgkin's disease. CMAJ. 1993;149(9):1281-3.  
65. Boll B, Gorgen H. The treatment of older Hodgkin lymphoma patients. Br J Haematol. 2019;184(1):82-92.  
66. Shenoy P, Maggioncalda A, Malik N, Flowers CR. Incidence patterns and outcomes for hodgkin lymphoma patients in the United States. Adv Hematol. 2011;2011:725219.  
67. Bjorkholm M, Weibull CE, Eloranta S, Smedby KE, Glimelius I, Dickman PW. Greater attention should be paid to developing therapies for elderly patients with Hodgkin lymphomaA population-based study from Sweden. Eur J Haematol. 2018;101(1):106-14.  
68. Deeken JF, Tjen ALA, Rudek MA, Okuliar C, Young M, Little RF, et al. The rising challenge of non-AIDS-defining cancers in HIV-infected patients. Clin Infect Dis. 2012;55(9):1228-35.  
69. Uldrick TS, Little RF. How I treat classical Hodgkin lymphoma in patients infected with human immunodeficiency virus. Blood. 2015;125(8):1226-35; quiz 355.  
70. Tan B, Ratner L. The use of new antiretroviral therapy in combination with chemotherapy. Curr Opin Oncol. 1997;9(5):455-64.  
71. Gopal S, Patel MR, Yanik EL, Cole SR, Achenbach CJ, Napravnik S, et al. Association of early HIV viremia with mortality after HIV-associated lymphoma. AIDS. 2013;27(15):236573.  
72. Brasil. Ministério da Saúde. In: Saúde Md, editor. Brasília, DF: Ministério da Saúde; 2017.  
73. Montoto S, Shaw K, Okosun J, Gandhi S, Fields P, Wilson A, et al. HIV status does not influence outcome in patients with classical Hodgkin lymphoma treated with chemotherapy using doxorubicin, bleomycin, vinblastine, and dacarbazine in the highly active antiretroviral therapy era. J Clin Oncol. 2012;30(33):4111-6.  
74. Hentrich M, Berger M, Wyen C, Siehl J, Rockstroh JK, Muller M, et al. Stage-adapted treatment of HIV-associated Hodgkin lymphoma: results of a prospective multicenter study. J Clin Oncol. 2012;30(33):4117-23.  
75. Dryver ET, Jernstrom H, Tompkins K, Buckstein R, Imrie KR. Follow-up of patients with Hodgkin's disease following curative treatment: the routine CT scan is of little value. Br J Cancer. 2003;89(3):482-6.  
76. Wongso D, Fuchs M, Plutschow A, Klimm B, Sasse S, Hertenstein B, et al. Treatmentrelated mortality in patients with advanced-stage hodgkin lymphoma: an analysis of the german hodgkin study group. J Clin Oncol. 2013;31(22):2819-24.  
77. Brasil. Ministério da Saúde/ Secretaria de Atenção à Saúde/ Departamento de Regulação AeCCGdSdI. Manual de bases técnicas da oncologia - SIA/SUS - Sistema de Informações Ambulatoriais 2019. Disponível em: <u>ftp://arpoador.datasus.gov.br/siasus/Documentos/APAC/Manual_Oncologia_26a_edicao.pdf .</u>  
78. Brasil. Portaria nº 375/SAS/MS, de 10 de novembro de 2009. in: Saúde Md, editor. Brasília2009.  
79. Brasil. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. In: Saúde Md, editor. Brasília2016.  
80. Guyatt GH OA, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, Schünemann HJ. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008;336(7560):924.  
ADIN  
{conitee HE.

---

