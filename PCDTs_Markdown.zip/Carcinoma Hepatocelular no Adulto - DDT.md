<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: PORTARIA CONJUNTA Nº 18, de 14 de OUTUBRO de 2022. -->
Aprova as Diretrizes Diagnósticas e Terapêuticas do Carcinoma Hepatocelular no Adulto.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Carcinoma hepatocelular no Adulto e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são  
formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 753/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 756 – Julho de 2022, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas - Carcinoma Hepatocelular no Adulto.  
Parágrafo único. As Diretrizes objeto deste artigo, que contêm o conceito geral do Carcinoma Hepatocelular no Adulto, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos</u> Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Carcinoma Hepatocelular.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS n<sup>o</sup> 602, de 26 de junho de 2012, publicada no Diário Oficial da União nº 124, de 28 de junho de 2012, seção 1, página 216.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: MAÍRA BATISTA BOTELHO -->
SANDRA DE CASTRO BARROS

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. INTRODUÇÃO** -->
As neoplasias malignas hepáticas primárias são o sexto tipo mais comum de neoplasia maligna e a quarta principal causa de morte relacionada ao câncer em todo o mundo. O carcinoma hepatocelular (CHC) representa 75 a 85% das neoplasias primárias do fígado. Sua incidência global anual é estimada entre 500.000 e 1.000.000 novos casos, levando a 700.000 mortes por ano<sup>1,2</sup> . O CHC é atualmente a complicação mais comum e a principal causa de morte em pacientes com cirrose hepática compensada<sup>3</sup> . A grande maioria dos casos (90%) está associada ao desenvolvimento de cirrose. As infecções crônicas pelos vírus da hepatite B e vírus da hepatite C estão envolvidas em mais de 80% dos casos de CHC<sup>4</sup> .  
O Brasil é considerado um país com baixa incidência de CHC, com incidência anual de 3,5% em pacientes cirróticos<sup>5</sup> . Em 2009, uma pesquisa nacional incluiu dados de 29 centros e um total de 1.405 pacientes diagnosticados com CHC. A mediana de idade foi de 59 anos e 78% dos casos eram do sexo masculino. A cirrose hepática estava presente em 98% dos casos e as etiologias mais comuns foram infecção crônica por hepatite C (54%), hepatite B (16%) e alcoolismo (14%)<sup>6</sup> .  
Os principais fatores de risco para CHC são cirrose hepática, infecções pelos vírus da hepatite C e B, contaminação de alimentos por aflatoxinas, ingestão alcoólica abusiva, diabetes, obesidade, doença hepática gordurosa não alcoólica e hemocromatose hereditária<sup>7-12</sup> . A cirrose, independentemente da etiologia, é o mais frequente fator de risco para a desenvolvimento de CHC, principalmente nos pacientes portadores de hepatite C. Ainda entre os pacientes cirróticos, aqueles com idade mais avançada, do sexo masculino, com maior atividade inflamatória hepática ou gravidade da cirrose estão sob risco ainda maior para o desenvolvimento desta neoplasia<sup>13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos do carcinoma hepatocelular no adulto, com o objetivo de orientar o que é válido e não válido técnico-cientificamente, com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C22.0 Carcinoma de células hepáticas (carcinoma hepatocelular ou hepatocarcinoma)

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.1. Rastreamento** -->
O rastreamento do CHC é indicado em pacientes cirróticos independentemente da etiologia; para os portadores de hepatite C com fibrose avançada e para os portadores de hepatite B, independentemente da função hepática. Para pacientes com doença hepática gordurosa não alcoólica associada à síndrome metabólica, o rastreamento deve ser realizado naqueles com fibrose hepática graus 3 ou 4<sup>17</sup> .  
Recomenda-se que o rastreamento seja realizado por ultrassonografia de abdome a cada 6 meses, entre os pacientes  
com diagnóstico de cirrose hepática que possam se beneficiar do tratamento curativo do tumor (classificação de Child-Pugh A ou B, sem comorbidades)<sup>15-17</sup> .  
A dosagem de alfa fetoproteína (AFP) apresenta sensibilidade e especificidade insuficientes para ser usada isoladamente no diagnóstico precoce do CHC, podendo ser realizada associada ao exame de imagem<sup>15, 16, 18</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.2. Diagnóstico por imagem** -->
O diagnóstico do CHC deve ser realizado, preferencialmente, por exames de imagem não invasivos, tais como a ultrassonografia (US), tomografia computadorizada (TC) ou ressonância magnética (RM), as quais também podem ser utilizadas para o estadiamento, conforme o método proposto pelo “ _Barcelona Clinic Liver Cancer Group_ ” (BCLC)<sup>19</sup> .  
Já o diagnóstico anatomopatológico deve ser reservado para pacientes não cirróticos e para aquelas situações em que os exames de imagem sejam inconclusivos. Nestes casos, deve-se realizar o exame citopatológico ou histopatológico de espécime tumoral obtido por punção com agulha fina ou biópsia hepática percutânea, laparoscópica ou a céu aberto<sup>20,21</sup> .  
Os nódulos hepáticos menores que 1 cm em doentes cirróticos podem ser acompanhados sem intervenção imediata, com US de abdome a cada 3 ou 4 meses. Nesses casos, se a lesão permanecer estável por 18 a 24 meses, o tempo de seguimento pode ser estendido a cada 6 a 12 meses.  
As lesões entre 1 cm e 2 cm devem ser avaliadas por punção-biópsia com agulha fina, em que pesem as taxas de resultados falsos negativos entre 30% e 40%. Em tumores com diâmetro maior que 2 cm, o diagnóstico de CHC pode ser confirmado por quaisquer métodos de imagem que mostrarem nódulo desse tamanho com presença de hipervascularização arterial e clareamento na fase portal. Deve-se realizar biópsia caso a lesão não apresentar aspecto típico de vascularização ao exame radiológico<sup>22-24</sup> .  
Para avaliar a extensão da doença, TC do tórax e TC ou RM do abdome e pelve devem ser realizadas<sup>25</sup> . Além disso, o potencial de ressecção da lesão deve ser definido por estudo angiográfico hepático, podendo ser realizado por via convencional, por TC helicoidal (angioTC) ou por angioressonância magnética (angioRM)<sup>26</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.3. Estadiamento** -->
Para o estadiamento do CHC, utiliza-se preferencialmente o método proposto pelo BCLC, que incorpora parâmetros clínicos e radiológicos:  
- Estágio 0: tumor único ocupando menos que 50% do fígado, em doente assintomático (escala de Zubrod 0), sem ascite, com níveis séricos de bilirrubina total menor que 3 mg/dL e albumina maior que 3 g/dL;  
- Estágio A: tumor único ocupando menos que 50% do fígado ou até três tumores com maior diâmetro de até 3 cm, em doente assintomático (escala de Zubrod 0), classificação de Child-Pugh A ou B;  
- Estágio B: tumor ocupando mais que 50% do fígado ou multinodular, em doente assintomático (escala de Zubrod 0), classificação Child-Pugh A ou B;  
- Estágio C: presença de pelo menos um dos seguintes critérios: invasão vascular, disseminação extra-hepática, em doente sintomático (escala de Zubrod 1 ou 2), classificação Child-Pugh A ou B;  
- Estágio D: doente incapacitado (escala de Zubrod 3 ou 4), qualquer que seja a extensão do tumor ou a função hepática (classificação Child-Pugh A, B ou C);  
A classificação de Barcelona é apropriada para definir a conduta para o doente com CHC e cirrose<sup>27</sup> , conforme a **Figura 1** .  
**Figura 1** – Fluxograma para o estadiamento do carcinoma hepatocelular e respectivas opções terapêuticas. Adaptado do BCLC<sup>27.</sup>  
<!-- Start of picture text -->
CHC<br>Estágio muito precoce (0)  Estágio inicial (A)  Estágio intermediário (B)  Estágio avançado (C)  Estágio terminal<br>Único ≤ 2 cm  Único ou 3 nódulos ≤ 3 cm  Multinodular  Invasão portal  (D)<br>Child-Pug A, PS 0  Child-Pug A/B, PS 0  Child-Pug A/B, PS 0  Disseminação extra- Child-Pug C, PS<br>hepática  3-4<br>Child-Pug A/B,<br>PS 1-2<br>Potencial candidato para<br>transplante de fígado  Único  3 nódulos ≤ 3 cm<br>Não  Sim  Pressão portal,<br>bilirrubina<br>Normal   Aumentada  Doenças<br>associadas<br>Não  Sim<br>Ablação  Ressecção  Transplante  Ablação  TACE  Tratamento<br>Sistêmico<br>Paliativo  BSC<br>Tratamento Curativo  Tratamento Paliativo<br>Prognóstico<br>Tratamento<br><!-- End of picture text -->  
CHC: carcinoma hepatocelular; BSC: _best standard supportive care_ – cuidados paliativos; TACE: quimioembolização transarterial.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nestas DDT os pacientes com idade igual ou maior a 19 anos e que tenham diagnóstico de carcinoma hepatocelular classificado histopatologicamente como carcinoma hepatocelular fibrolamelar, carcinoma hepatocelular e colangiocarcinoma combinados ou simplesmente como  Carcinoma hepatocelular sem outras especificações (SOE).  
A indicação de transplante hepático deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, devendo todos os potenciais receptores estar inscritos no Sistema Nacional de Transplantes (SNT).

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Excluem-se destas DDT os pacientes com diagnóstico de tumores primários não carcinoma hepatocelular, tais como colangiocarcinoma, ou tumores hepáticos secundários.  
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso do respectivo procedimento ou medicamento recomendados nestas DDT.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **6. PREVENÇÃO** -->
A prevenção do CHC deve incluir as seguintes condutas<sup>14</sup> :  
- Diagnóstico precoce de hepatite B e terapia antiviral precoce para portadores de hepatite C;  
- imunização universal contra hepatite B em populações em risco para o CHC;  
- prevenção e tratamento contra o abuso de álcool, principalmente nos portadores de doença hepática crônica,  
- sobretudo quando causada por vírus da hepatite B e C;  
- prevenção e tratamento do diabetes melito e da obesidade nos portadores doença hepática;  
- mudança de estilo de vida favorável ao controle do peso nos portadores de doença hepática gordurosa não alcoólica.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.1. Ressecção cirúrgica e transplante hepático** -->
A ressecção é a principal opção terapêutica curativa para o paciente com CHC e com fígado não cirrótico<sup>28</sup> .  No entato, a minoria dos pacientes (10% a 15%) apresentam condições clínicas e extensão tumoral compatíveis com realização deste procedimento cirúrgico no momento do diagnóstico. Portanto, o procedimento cirúrgico  de ressecção hepática será indicada conforme o estado clínico do paciente e da quantidade prevista de parênquima hepático restante, a qual deve ser de aproximadamente 10% do peso corporal.  
Já nos pacientes com CHC associado à cirrose, o transplante de fígado (TxH) é considerado o tratamento curativo quando o paciente possui boa função hepática (classificação Child-Pugh A, bilirrubinas normais e ausência de hipertensão portal) e o CHC é diagnosticado em estágios precoces, de acordo com os critérios de Milão (tumor único até 5 cm de diâmetro ou até três tumores de até 3 cm de diâmetro)<sup>29</sup> .  
Quando os pacientes permanecerem em lista de espera por mais de 6 meses, podem ser submetidos à quimioembolização transarterial, com o objetivo de ajudá-los a manter os critérios de Milão (“ _downstaging_ ”), de modo a serem mantidos em espera para TxH<sup>29-32</sup> .  
Pacientes com CHC candidatos à TxH dem ser tratados para infecção crônica por hepatite C, conforme Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções. Após o transplante hepático, a imunossupressão deve ocorrer conforme disposto no Protocolo Clínico e Diretrizes Terapêuticas de Imunosupressão no Transplante Hépático em Adultos. Esses protocolos estão disponíveis em https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-emsaude/protocolos-clinicos-e-diretrizes-terapeuticas.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.2.1. Ablação** -->
Os métodos ablativos, considerados curativos para o CHC, podem ser realizados por injeção alcoólica percutânea (IAP) ou por radiofrequência (RF), sendo os tratamentos de escolha para pacientes com CHC em estágio BCLC 0/A que não são elegíveis para ressecção cirúrgica<sup>34</sup> .  
A RF é o método preferencial para tumores menores que 5 cm, pois proporciona um controle superior de doença. A principal desvantagem da RF é o seu maior custo e a maior taxa de eventos adversos, tais como risco de sangramento, pneumotórax, abcesso hepático ou perfuração de alças intestinais. A taxa de mortalidade atribuível para o procedimento varia entre zero e 0,3%. Caso o tumor esteja localizado perto da árvore biliar ou de órgãos viscerais, deve-se evitar a realização de RF. Além disso, devido à dispersão do calor, a RF pode ser ineficaz em tumores localizados perto de grandes vasos sanguíneos<sup>35</sup> .  
A IAP é recomendada nos casos em que a RF não é tecnicamente viável, particularmente para nódulos menores que 3 cm. Os eventos adversos mais comuns da IAP são dor, febre e sensação de intoxicação alcoólica. Um declínio na função hepática é menos provável de ocorrer após a IAP do que com ressecção cirúrgica ou quimioembolização. A taxa de mortalidade atribuível ao procedimento é inferior a 1%. A IAP está contraindicada em casos de ascite descontrolada ou diátese hemorrágica<sup>36, 37</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.2.1.1. Radioterapia** -->
O tratamento local ablativo do CHC por radioterapia estereotáxica foi avaliado apenas em estudos retrospectivos, em sua maioria com reduzido número de pacientes. No entanto, trata-se de uma terapia não-invasiva com eficácia aparentemente semelhante à ablação por RF, conferindo taxa de controle local superior a 80%<sup>38-47</sup> . A dose total de radioterapia varia de 24 a 60 Gy em uma a seis frações.  
A radioterapia deve ser indicada para pacientes não candidatos à ressecção cirúrgica, em lesões inferiores a 3 cm e distantes das alças intestinais. A radioterapia estereotáxica pode, inclusive, ser realizada quando o paciente apresentar lesão numa área portal central, em regiões adjacentes a grandes vasos ou vias biliares, próximas ao diafragma ou à superfície hepática, situações nas quais a RF é contraindicada. A radioterapia estereotáxica hepática é relativamente bem tolerada, especialmente em pacientes com escore de Child-Pugh menor ou igual a 7, com risco de óbito associado ao tratamento inferior a 1%<sup>38-47</sup> . Os eventos adversos mais frequentes são elevação das enzimas hepáticas e bilirrubina, anorexia, dor abdominal e náusea, geralmente de grau leve<sup>38-47</sup> . Desta forma, a radioterapia estereotáxica pode ser utilizada como tratamento ablativo em locais onde a tecnologia já está disponível.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.3. Quimioembolização** -->
Quando a doença é irressecável, a embolização intra-arterial hepática pode reduzir as dimensões do CHC, tornandoo passível de resseção cirúrgica em alguns doentes e controlando temporariamente os sintomas. Porém, não há evidências de que a quimioembolização promova aumento do tempo de sobrevida<sup>48,49</sup> . O procedimento consiste na cateterização e injeção pela artéria hepática direita ou esquerda de quimioterapia antineoplásica (geralmente doxorrubicina), contraste radiopaco e um agente embolizante, para promover a necrose tumoral e mínima lesão do tecido hepático normal.  
O procedimento pode ser associado à RF e está indicado para doentes com carcinoma hepatocelular estágio B. Além disso, a indicação é limitada à capacidade funcional 0 ou 1 (escala da _Eastern Cooperative Oncology Group_ - ECOG), com tumor ocupando menos de 50% do volume hepático, com função hepática e renal preservadas, na ausência de tumor extrahepático, trombose da veia porta, infecção ativa, colestase ou comorbidades clinicamente não compensadas<sup>50, 51</sup> .  
Diversos agentes embolizantes podem ser usados, como agentes hemostáticos à base de colágeno, microesferas de acetato de polivinila e esferas carregadas com quimioterápicos, estas últimas também conhecidas como DEB ( _drug-eluting beads_ )<sup>52,53</sup> . Apesar de tratar-se de tecnologia mais moderna e com a perspectiva de menor risco de eventos adversos, ainda não se comprovou que DEB é superior à quimioembolização clássica (cTACE) para os desfechos de eficácia e eventos adversos. Além disso, trata-se de uma técnica mais custosa que a quimioembolização clássica. Dois pequenos estudos randomizados<sup>54,55</sup> compararam DEB versus cTACE e não encontraram diferenças entre os métodos para os desfechos de eficácia e segurança avaliados. Portanto, ainda não é possível recomendar DEB em detrimento à cTACE<sup>56</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.4.1. Após ressecção cirúrgica, ablação por radiofrequência ou quimioembolização transarterial** -->
A terapia antiviral pode apresentar benefícios clínicos como a redução da recorrência e o aumento da sobrevida após o tratamento local com intenção curativa do CHC relacionado à infecção crônica pelo vírus da hepatite B<sup>57, 58</sup> . Nestes casos, recomenda-se observar o disposto no Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e Coinfecções do Ministério da Saúde<sup>59</sup> .  
A terapia citotóxica com doxorrubicina, epirrubicina, capecitabina ou tegafur não produz benefício clínico em termos de redução da recorrência ou aumento da sobrevida após o tratamento local com intenção curativa do carcinoma hepatocelular em população não-asiática. Por isso, seu uso adjuvante não é recomendado por estas DDT<sup>60-66</sup> .  
A terapia antiangiogênica com sorafenibe não produz benefício clínico em termos de redução da recorrência ou aumento da sobrevida após o tratamento local com intenção curativa do carcinoma hepatocelular. Por isso, estas Diretrizes não recomendam o uso desse medicamento em pacientes que realizaram ressecção cirúrgica, ablação por radiofrequência ou quimioembolização transarterial.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.4.2. Quimioterapia paliativa** -->
A quimioterapia sistêmica paliativa pode resultar em benefício clínico (aumento de sobrevida de 2 a 3 meses), embora esteja associada ao risco de toxicidade, com incidência maior de neutropenia, trombocitopenia, neuropatia, alopecia, síndrome pé-mão, rash cutâneo, diarreia e hipertensão arterial sistêmica<sup>74-78</sup> . A quimioterapia sistêmica paliativa pode ser indicado para pacientes com<sup>75,79,80</sup> :  
- Doença avançada ou metastática, sem indicação para terapias locorregionais ou para os portadores de progressão de  
- doença após terapias locorregionais;  
- boa capacidade funcional (escores ECOG 0, 1 ou 2);  
- classificação Child-Pugh A (excepcionalmente, aqueles indivíduos com hepatite B e sem cirrose, independentemente  
- da função hepática);  
- classificação cardíaca da _New York Heart Association_ (NYHA) I ou II;  
- função renal adequada (creatinina sérica menor ou igual a 1,5 vezes o limite superior do intervalo normal);  
- função hemática adequada (contagem de plaquetas maior ou igual a 60 × 10<sup>9</sup> /L; hemoglobina maior ou igual a 8,5 g/dL; e relação internacional normalizada menor ou igual a 2,3, ou tempo de protrombina menor ou igual a 6 segundos acima de controle); e  
- se com comorbidade, expectativa de vida de 12 semanas ou mais.  
Para a quimioterapia sistêmica paliativa de primeira linha do CHC avançado ou metastático, o sorafenibe é o medicamento atual mais estudado<sup>67-73, 76,77,81,82</sup> . Este medicamento foi avaliado pela Conitec, conforme Relatório de Recomendação nº 368, de agosto de 2018 (disponível em https://www.gov.br/conitec/ptbr/midias/relatorios/2018/relatorio_sorafenibe_chc-avancado.pdf). Contudo, dado o modelo da Assistência Oncológica no SUS e a existência de procedimento específico para a quimioterapia paliativa de carcinoma hepatocelular (03.04.02.03899 - Quimioterapia de carcinoma do fígado ou do trato biliar avançado), o Plenário desta Comissão deliberou pela desnecessidade de criação de um novo procedimento específico para a incorporação do sorafenibe. Na indisponibilidade deste fármaco ou quando este for contraindicado ao paciente, pode ser utilizada quimioterapia citotóxica (doxorrubicina; 5-fluoruracil, leucovorina e oxaliplatina)<sup>78,80,83-88</sup> .  
Já a quimioterapia sistêmica paliativa de segunda-linha do CHC avançado ou metastático pode empregar regorafenibe, quando os pacientes apresentarem boa capacidade funcional (escores ECOG 0 ou 1) e tiverem apresentado falha terapêutica ao uso de sorafenibe. Não são candidatos a tal tratamento os pacientes que receberam previamente outros esquemas terapêuticos ou que interromperam o uso de sorafenibe por toxicidade deste medicamento<sup>89</sup> .  
As terapias paliativas sistêmicas empregando tamoxifeno, sunitinibe, erlotinibe, flutamida, acetato de megestrol, everolimo e ramucirumabe não demonstraram evidência de benefício clínico. Portanto, seu uso não é recomendado nestas Diretrizes<sup>90-99</sup> .  
Os pacientes com capacidade funcional comprometida (escore ECOG 3 ou 4) ou que apresentem grande extensão de doença (definido pela presença de, pelo menos, três dos seguintes achados: comprometimento pelo tumor maior que 50% do fígado, ascite, albumina sérica menor que 3 g/dL e bilirrubina total maior que 3 mg/dL) não devem receber terapia  
antineoplásica<sup>100,101</sup> .  
O **Quadro 1** resume as recomendações terapêuticas do CHC:  
**Quadro 1** – Síntese das recomendações terapêuticas para o CHC de acordo com a classificação de Barcelona (BCLC).  
|**Estágio**|**Terapia**|
|---|---|
|Estágio 0|●<br>Ressecção cirúrgica<br>●<br>Injeção percutânea de etanol<br>●<br>Ablação por radiofrequência|
||●<br>Radioterapia|
||●<br>Ressecção cirúrgica<br>●<br>Transplante hepático|
|Estágio A|●<br>Injeção percutânea de etanol<br>●<br>Ablação por radiofrequência<br>●<br>Radioterapia|
|Estágio B|●<br>Quimioembolização transarterial por cateter, seguida ou não por ressecção cirúrgica|
|Estágio C|●<br>Tratamento sistêmico paliativo|
|Estágio D|●<br>Medidas paliativas de suporte clínico, sem tratamento antitumoral|  
Adaptado de Clavein et al, 2012<sup>25</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **7.5. Critérios de interrupção** -->
O tratamento deve ser interrompido caso haja evidência de, pelo menos, um dos seguintes critérios<sup>104-106</sup> :  
- Progressão radiológica, tal como definido pelo critério mRECIST ( _Modified Response Evaluation Criteria In Solid Tumors_ ): aumento de, pelo menos, 20% na soma dos diâmetros de lesões de alvo viáveis, tomando como referência a menor soma dos diâmetros da lesão alvo;  
- progressão sintomática;  
- ocorrência de efeitos adversos inaceitáveis;  
- redução da capacidade funcional para escores ECOG 3 ou 4;  
- manifestação da vontade do paciente ou de seus responsáveis legais.  
A progressão sintomática deve ser estimada por meio de anamnese e exame físico estruturados. Questionários padronizados, como o _Functional Assessment of Cancer Therapy–Hepatobiliary Symptom Index 8_ (FHSI8), também podem ser empregados como métodos adicionais. O FHSI8 é uma subescala extraída do questionário de 45 itens de Avaliação Funcional da Terapia do Câncer - Hepatobiliar (FACT-Hep), que avalia com propriedade a qualidade de vida relacionada à saúde em pacientes com câncer de fígado, ducto e pâncreas<sup>107</sup> .  
Variações nos níveis séricos de AFP durante o tratamento (aumento ou redução) podem ser utilizadas para avaliar o prognóstico do paciente. Porém, isoladamente, não são capazes de modificar a conduta terapêutica<sup>106</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **8. MONITORAMENTO** -->
A resposta ao tratamento deve ser avaliada conforme a medida do tamanho tumoral viável, obtida por meio de TC ou RM de abdome, conforme o sistema de diagnóstico por imagem LI-RADS ( _Liver Imaging Reporting and Data System_ ) disposto no **Quadro 2**<sup>103</sup> .  
**Quadro 2** – Categorias do LI-RADS para resposta terapêutica (LR-RT) medida por meio de TC/RM.  
|Categoria de Resposta|Critério|
|---|---|
|LR-RT Não viáveis|<br>Nenhum realce lesional;<br><br>Tratamento específico padrão de realce esperado.|
|LR-RT Equivocado|Realce atípico para tratamento específico padrão de realce esperado e não<br>encontrando critérios para provavelmente ou definitivamente viáveis.|
||Nodular, pseudotumoral, e tecido de espessura irregular em ou ao longo da lesão<br>tratada com quaisquer dos seguintes:|
|LR-RT Viáveis|<br>Hiper-avanço da fase arterial;<br><br>Aparência de “_washout”;_|
||<br>Realce similar ao pré-tratamento.|  
Adaptado da _American College of Radiology_<sup>103</sup> . LR-RT: LI-RADS-Resposta Terapêutica ( _LI-RADS Treatment Response_ )  
Para o monitoramento de pacientes submetidos à radioterapia e à quimioterapia, adotam-se os respectivos cuidados e condutas institucionais estabelecidas.  
O monitoramento após tratamento cirúrgico ou transplante hepático para doentes com carcinoma hepatocelular deve incluir tomografia computadorizada ou ressonância magnética de abdome, com contraste, a cada 6 a 12 meses, associada à dosagem de AFP<sup>31</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes nestas Diretrizes, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Casos de carcinoma hepatocelular devem ser atendidos em serviços especializados em oncologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento dos pacientes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Relativamente ao sítio primário ou secundário, os procedimentos cirúrgicos da tabela do SUS aplicáveis a pacientes com diagnóstico de carcinoma hepatocelular encontram-se no Grupo 04 e podem ser acessados por código ou nome do procedimento e por código da CID-10.  
Os procedimentos radioterápicos da tabela do SUS aplicáveis a pacientes com diagnóstico de carcinoma de células renais são os seguintes:  
03.04.01.011-1 - Internação p/ radioterapia externa (cobaltoterapia/acelerador linear)  
03.04.01.037-5 - Radioterapia do aparelho digestivo  
03.04.01.052-9 - Radioterapia de metástase em sistema nervoso central  
03.04.01.053-7 - Radioterapia de plasmocitoma / mieloma / metástases em outras localizações  
O procedimento da tabela do SUS para a quimioterapia de carcinoma hepatocelular é o seguinte: _Quimioterapia paliativa – adulto_  
03.04.02.03899 - Quimioterapia de carcinoma do fígado ou do trato biliar avançado  
A indicação de transplante deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, devendo todos os potenciais receptores estar inscritos no Sistema Nacional de Transplantes (SNT).  
Os receptores submetidos a transplante originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **10. REFERÊNCIAS** -->
1.       Bray F, Ferlay J, Soerjomataram I, Siegel RL, Torre LA, Jemal A. Global cancer statistics 2018: GLOBOCAN estimates of incidence and mortality worldwide for 36 cancers in 185 countries. CA Cancer J Clin. 2018;68(6):394-424.  
2.    Chagas AL, Mattos AA, Carrilho FJ, Bittencourt PL, Vezozzo DCP, Horvat N, et al. BRAZILIAN SOCIETY OF HEPATOLOGY UPDATED RECOMMENDATIONS FOR DIAGNOSIS AND TREATMENT OF HEPATOCELLULAR CARCINOMA. Arq Gastroenterol. 2020;57(suppl 1):1-20.  
3.    Sangiovanni A, Prati GM, Fasani P, Ronchi G, Romeo R, Manini M, et al. The natural history of compensated cirrhosis due to hepatitis C virus: A 17‐year cohort study of 214 patients. Hepatology. 2006;43(6):1303-10.  
4. Okuda H. Hepatocellular carcinoma development in cirrhosis. Best Practice & Research Clinical Gastroenterology. 2007 21(1):161-73.  
5. Paranagua-Vezozzo DC, Matielo CE, Chagas AL, Kikuchi LO, Mello ES, Alves VA, et al. Incidence Of Hepatocellular Carcinoma In Cirrhotic Patients In Sao Paulo, Brazil. Hepatology. 2006;44:504A-5A.  
6. Carrilho FJ, Kikuchi L, Branco F, Goncalves CS, Mattos AA. Clinical and epidemiological aspects of hepatocellular carcinoma in Brazil. Clinics. 2010;65(12):1285-90.  
7. Montesano R, Hainaut P, Wild CP. Hepatocellular carcinoma: from gene to public health. Journal of the National Cancer Institute. 1997;89(24):1844-51.  
8. Wang P, Kang D, Cao W, Wang Y, Liu Z. Diabetes mellitus and risk of hepatocellular carcinoma: a systematic review and meta‐analysis. Diabetes/metabolism research and reviews. 2012;28(2):109-22.  
9. Larsson SC, Wolk A. Overweight, obesity and risk of liver cancer: a meta-analysis of cohort studies. British journal of cancer. 2007;97(7):1005-8.  
10. Polesel J, Zucchetto A, Montella M, Dal Maso L, Crispo A, La Vecchia C, et al. The impact of obesity and diabetes mellitus on the risk of hepatocellular carcinoma. Annals of Oncology. 2008;20(2):353-7.  
11. Michelotti GA, Machado MV, Diehl AM. AFLD, NASH and liver cancer. Nature Reviews Gastroenterology and Hepatology. 2013;10(11):656-65.  
12. Fracanzani AL, Conte D, Fraquelli M, Taioli E, Mattioli M, Losco A, et al. Increased cancer risk in a cohort of 230  
patients with hereditary hemochromatosis in comparison to matched control patients with non–iron‐related chronic liver disease. Hepatology. 2001;33(3):647-51.  
13. Fattovich G, Stroffolini T, Zagni I, Donato F. Hepatocellular carcinoma in cirrhosis: incidence and risk factors. Gastroenterology. 2004;127(5):S35-50.  
14.    Carrillo FJ, Mattos AA, Vianey AF, Vezozzo DC, Marinho F, Souto FJ, et al. Brazilian society of hepatology recommendations for the diagnosis and treatment of hepatocellular carcinoma. Arquivos de gastroenterologia. 2015;52:2-14. 15. Trinchet JC CC, Bourcier V, Degos F, Henrion J, Fontaine H, Roulot D, Mallat A, Hillaire S, Cales P, Ollivier I. Ultrasonographic surveillance of hepatocellular carcinoma in cirrhosis: A randomized trial comparing 3‐and 6‐month periodicities. Hepatology. 2011;54(6):1987-97.  
16.    Farinati F MD, De Giorgio M, Baldan A, Cantarini M, Cursaro C, Rapaccini G, Del Poggio P, Di Nolfo MA, Benvegnù L, Zoli M. Diagnostic and prognostic role of α-fetoprotein in hepatocellular carcinoma: both or neither?. . The American journal of gastroenterology. 2006;101(3):524-32.  
17. EASL Clinical Practice Guidelines: Management of hepatocellular carcinoma. J Hepatol. 2018;69(1):182-236.  
18. Zhang BH YB, Tang ZY. Randomized controlled trial of screening for hepatocellular carcinoma. Journal of cancer research and clinical oncology. 2004;130(7):417-22.  
19. Xie L, Guang Y, Ding H, Cai A, Huang Y. Diagnostic value of contrast-enhanced ultrasound, computed tomography and magnetic resonance imaging for focal liver lesions: a meta-analysis. Ultrasound in medicine & biology. 2011;37(6):85461.  
20. Colli A, Fraquelli M, Casazza G, Massironi S, Colucci A, Conte D, et al. Accuracy of ultrasonography, spiral CT, magnetic resonance, and alpha-fetoprotein in diagnosing hepatocellular carcinoma: a systematic review. The American journal of gastroenterology. 2006;101(3):513-23.  
21. Lee JM, Trevisani F, Vilgrain V, Wald C. Imaging diagnosis and staging of hepatocellular carcinoma. Liver Transplantation. 2011;17(S2):S34-43.  
22. Bruix J, Sherman M. Management of hepatocellular carcinoma: an update. Hepatology. 2011;53(3):1020-2.  
23. Kudo M, Izumi N, Kokudo N, Matsui O, Sakamoto M, Nakashima O, et al. Management of hepatocellular carcinoma in Japan: Consensus-Based Clinical Practice Guidelines proposed by the Japan Society of Hepatology (JSH) 2010 updated version. Digestive diseases. 2011;29(3):339-64.  
24. Sherman M, Burak K, Maroun J, Metrakos P, Knox JJ, Myers RP, et al. Multidisciplinary Canadian consensus recommendations for the management and treatment of hepatocellular carcinoma. Current oncology. 2011;18(5):228.  
25. Clavien PA, Lesurtel M, Bossuyt PM, Gores GJ, Langer B, Perrier A. Recommendations for liver transplantation for hepatocellular carcinoma: an international consensus conference report. The lancet oncology. 2012;13(1):e11-22.  
26. Outwater EK. Imaging of the liver for hepatocellular cancer. . Cancer control: journal of the Moffitt Cancer Center. 2010;17(2):72.  
27. Heimbach JK, Kulik LM, Finn RS, Sirlin CB, Abecassis MM, Roberts LR, et al. Aasld guidelines for the treatment of hepatocellular carcinoma. Hepatology. 2018;67(1):358-80.  
28. Mohanty S, Rajaram R, Bilimoria KY, Salem R, Pawlik TM, Bentrem DJ. Assessment of non‐surgical versus surgical therapy for localized hepatocellular carcinoma. Journal of surgical oncology. 2016;113(2):175-80.  
29. Mazzaferro V, Regalia E, Doci R, Andreola S, Pulvirenti A, Bozzetti F, et al. Liver transplantation for the treatment of small hepatocellular carcinomas in patients with cirrhosis. New England Journal of Medicine. 1996;334(11):693-700.  
30. Yao FY, Xiao L, Bass NM, Kerlan R, Ascher NL, Roberts JP. Liver transplantation for hepatocellular carcinoma:  
validation of the UCSF‐expanded criteria based on preoperative imaging. American Journal of Transplantation. 2007;7(11):2587-96.  
31. Clavien PA, Lesurtel M, Bossuyt PM, Gores GJ, Langer B, Perrier A. Recommendations for liver transplantation for hepatocellular carcinoma: an international consensus conference report. The lancet oncology. 2012;13(1):e11-22.  
32. Yu CY, Ou HY, Huang TL, Chen TY, Tsang LC, Chen CL, et al. Hepatocellular carcinoma downstaging in liver transplantation. Transplantation proceedings. 2012;44(2):412-4.  
33. Saúde BMd. Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções. In: Secretaria de Vigilância em Saúde. Departamento de Vigilância PeCdI, Sexualmente Transmissíveis dHIVAedHv, editors. Brasília: Ministério da Saúde.; 2017.  
34. European Association For The Study Of The Liver. EASL–EORTC clinical practice guidelines: management of hepatocellular carcinoma. Journal of hepatology. 2012;56(4):908-43.  
35. Livraghi T, Lazzaroni S, Meloni F. Radiofrequency thermal ablation of hepatocellular carcinoma. European Journal of ultrasound. 2001;13(2):159-66.  
36. Ebara M, Okabe S, Kita K, Sugiura N, Fukuda H, Yoshikawa M, et al. Percutaneous ethanol injection for small hepatocellular carcinoma: therapeutic efficacy based on 20-year observation. Journal of hepatology. 2005;43(3):458-64.  
37. Shiina S, Teratani T, Obi S, Hamamura K, Koike Y, Omata M. Percutaneous ethanol injection therapy for liver tumors. European journal of ultrasound. 2001;13(2):95-106.  
38. Su TS, Liang P, Liang J, Lu HZ, Jiang HY, Cheng T, et al. Long-term Survival Analysis of Stereotactic Ablative Radiotherapy Versus Liver Resection for Small Hepatocellular Carcinoma. International Journal of Radiation Oncology* Biology* Physics. 2017;98(3):639-46.  
39. Lu XJ, Dong J, Ji LJ, Xiao LX, Ling CQ, Zhou J. Tolerability and efficacy of gamma knife radiosurgery on hepatocellular carcinoma with portal vein tumor thrombosis. Oncotarget. 2016;7(3):3614-22.  
40. Matsuo Y, Yoshida K, Nishimura H, Ejima Y, Miyawaki D, Uezono H, et al. Efficacy of stereotactic body radiotherapy for hepatocellular carcinoma with portal vein tumor thrombosis/inferior vena cava tumor thrombosis: evaluation by comparison with conventional three-dimensional conformal radiotherapy. Journal of radiation research. 2016;57(5):512-23. 41. Oladeru OT, Miccio JA, Yang J, Xue Y, Ryu S, Stessin AM. Conformal external beam radiation or selective internal radiation therapy—a comparison of treatment outcomes for hepatocellular carcinoma. Journal of gastrointestinal oncology. 2016;7(3):433.  
42. Feng MU, Marshall VD, Parikh N. Use of radiofrequency ablation and stereotactic body radiotherapy for the treatment of hepatocellular carcinoma: An analysis of the SEER-Medicare database. Journal of Clinical Oncology. 2016;34(4):20167.  
43. Wahl DR, Stenmark MH, Tao Y, Pollom EL, Caoili EM, Lawrence TS, et al. Outcomes after stereotactic body radiotherapy or radiofrequency ablation for hepatocellular carcinoma. Journal of Clinical Oncology. 2015;34(5):452-9.  
44. Shiozawa K, Watanabe M, Ikehara T, Matsukiyo Y, Kogame M, Kishimoto Y, et al. Comparison of percutaneous radiofrequency ablation and CyberKnife® for initial solitary hepatocellular carcinoma: A pilot study. World journal of gastroenterology. 2015;21(48):13490.  
45. Jacob R, Turley F, Redden DT, Saddekni S, Aal AK, Keene K, et al. Adjuvant stereotactic body radiotherapy following transarterial chemoembolization in patients with non‐resectable hepatocellular carcinoma tumours of≥ 3 cm. HPB. 2015;17(2):140-9.  
46. Honda Y, Kimura T, Aikata H, Kobayashi T, Fukuhara T, Masaki K, et al. Stereotactic body radiation therapy combined  
with transcatheter arterial chemoembolization for small hepatocellular carcinoma. Journal of gastroenterology and hepatology. 2013;28(3):530-6.  
47. Huang WY, Jen YM, Lee MS, Chang LP, Chen CM, Ko KH, et al. Stereotactic body radiation therapy in recurrent hepatocellular carcinoma. International Journal of Radiation Oncology* Biology* Physics. 2012;84(2):355-61.  
48. Oliveri RS, Wetterslev J, Gluud C. Transarterial (chemo) embolisation for unresectable hepatocellular carcinoma. The Cochrane Library. 2011;3:CD004787.  
49. Doffoël M, Bonnetain F, Bouché O, Vetter D, Abergel A, Fratté S, et al. Multicentre randomised phase III trial comparing Tamoxifen alone or with Transarterial Lipiodol Chemoembolisation for unresectable hepatocellular carcinoma in cirrhotic patients (Fédération Francophone de Cancérologie Digestive 9402). European journal of cancer. 2008;44(4):52838.  
50. Wang N, Guan Q, Wang K, Zhu B, Yuan W, Zhao P, et al. TACE combined with PEI versus TACE alone in the treatment of HCC: a meta-analysis. Medical oncology. 2011;28(4):1038-43.  
51. Wang W, Shi J, Xie WF. Transarterial chemoembolization in combination with percutaneous ablation therapy in unresectable hepatocellular carcinoma: a meta‐analysis. Liver International. 2010;30(5):741-9.  
52. Marelli L, Stigliano R, Triantos C, Senzolo M, Cholongitas E, Davies N, et al. Transarterial therapy for hepatocellular carcinoma: which technique is more effective? A systematic review of cohort and randomized studies. Cardiovascular and interventional radiology. 2007;30(1):6-25.  
53. Xie F, Zang J, Guo X, Xu F, Shen R, Yan L, et al. Comparison of transcatheter arterial chemoembolization and microsphere embolization for treatment of unresectable hepatocellular carcinoma: a meta-analysis. Journal of cancer research and clinical oncology. 2012;138(3):455-62.  
54. Golfieri R, Giampalma E, Renzulli M, Cioni R, Bargellini I, Bartolozzi C, et al. Randomised controlled trial of doxorubicin-eluting beads vs conventional chemoembolisation for hepatocellular carcinoma. British journal of cancer. 2014;111(12):255-64.  
55. Lammer J, Malagari K, Vogl T, Pilleul F, Denys A, Watkinson A, et al. Prospective randomized study of doxorubicineluting-bead embolization in the treatment of hepatocellular carcinoma: results of the PRECISION V study. Cardiovascular and interventional radiology. 2010;33(1):41-52.  
56. Chen P, Yuan P, Chen B, Sun J, Shen H, Qian Y. Evaluation of drug-eluting beads versus conventional transcatheter arterial chemoembolization in patients with unresectable hepatocellular carcinoma: A systematic review and meta-analysis. Clinics and research in hepatology and gastroenterology. 2017;41(1):75-85.  
57. Liu GM, Huang XY, Shen SL, Hu WJ, Peng BG. Adjuvant antiviral therapy for hepatitis B virus‐related hepatocellular carcinoma after curative treatment: A systematic review and meta‐analysis. Hepatology Research. 2016;46(1):100-10.  
58. Xu X, Huang P, Tian H, Chen Y, Ge N, Tang W, et al. Role of lamivudine with transarterial chemoembolization in the survival of patients with hepatocellular carcinoma. Journal of gastroenterology and hepatology. 2014;29(6):1273-8.  
59. Saúde BMd. Protocolos Clínicos e Diretrizes Terapêuticas para Hepatite B e Coinfecções. In: Saúde Md, editor. Brasília2016.  
60. Hasegawa K, Takayama T, Ijichi M, Matsuyama Y, Imamura H, Sano K, et al. Uracil‐tegafur as an adjuvant for hepatocellular carcinoma: A randomized trial. Hepatology. 2006;44(4):891-5.  
61. Lai EC, Lo CM, Fan ST, Liu CL, Wong J. Postoperative adjuvant chemotherapy after curative resection of hepatocellular carcinoma: a randomized controlled trial. Archives of Surgery. 1998;133(2):183-8.  
62. Pokorny H, Gnant M, Rasoul‐Rockenschaub S, Gollackner B, Steiner B, Steger G, et al. Does additional doxorubicin  
chemotherapy improve outcome in patients with hepatocellular carcinoma treated by liver transplantation?. . American journal of transplantation. 2005;5(4):788-94.  
63. Samuel M, Chow PK, Chan Shih‐Yen E, Machin D, Soo KC. Neoadjuvant and adjuvant therapy for surgical resection of hepatocellular carcinoma. The Cochrane Library. 2009;1:CD001199.  
64. Söderdahl G BL, Isoniemi H, Cahlin C, Höckerstedt K, Broomé U, Mäkisalo H, Friman S, Ericzon BG,. A prospective, randomized, multi‐centre trial of systemic adjuvant chemotherapy versus no additional treatment in liver transplantation for hepatocellular carcinoma. Transplant international. 2006;19(4):288-94.  
65. Xia Y, Qiu Y, Li J, Shi L, Wang K, Xi T, et al. Adjuvant therapy with capecitabine postpones recurrence of hepatocellular carcinoma after curative resection: a randomized controlled trial. Annals of surgical oncology. 2010;17(12):3137-44.  
66. Ishizuka M, Kubota K, Nemoto T, Shimoda M, Kato M, Iso Y, et al. Administration of adjuvant oral tegafur/uracil chemotherapy post hepatocellular carcinoma resection: A randomized controlled trial. Asian Journal of Surgery. 2016;39(3):149-54.  
67. Bruix J TT, Mazzaferro V, Chau GY, Yang J, Kudo M, Cai J, Poon RT, Han KH, Tak WY, Lee HC,. Adjuvant sorafenib for hepatocellular carcinoma after resection or ablation (STORM): a phase 3, randomised, double-blind, placebo-controlled trial. The Lancet Oncology. 2015;16(13):1344-54.  
68. Giorgio A MM, Montesarchio L, Merola F, Santoro B, Coppola C, Gatti P, Amendola F, Di Sarno A, Calvanese A, Matteucci P. Sorafenib combined with radio-frequency ablation compared with sorafenib alone in treatment of hepatocellular carcinoma invading portal vein: a western randomized controlled trial. Anticancer research. 2016;36(11):6179-83.  
69. Hoffmann K, Ganten T, Gotthardtp D, Radeleff B, Settmacher U, Kollmar O, et al. Impact of neo-adjuvant Sorafenib treatment on liver transplantation in HCC patients-a prospective, randomized, double-blind, phase III trial. BMC Cancer. 2015;15(1):392.  
70. Kan X, Jing Y, Wan QY, Pan JC, Han M, Yang Y, et al. Sorafenib combined with percutaneous radiofrequency ablation for the treatment of medium-sized hepatocellular carcinoma. Eur Rev Med Pharmacol Sci. 2015;19(2):247-55.  
71. Kudo M IK, Chida N, Nakachi K, Tak WY, Takayama T, Yoon JH, Hori T, Kumada H, Hayashi N, Kaneko S. Phase III study of sorafenib after transarterial chemoembolisation in Japanese and Korean patients with unresectable hepatocellular carcinoma. European journal of cancer. 2011;47(14):2117-2.  
72. Meyer T FR, Ma YT, Ross PJ, James MW, Sturgess R, Stubbs C, Stocken DD, Wall L, Watkinson A, Hacking N. Sorafenib in combination with transarterial chemoembolisation in patients with unresectable hepatocellular carcinoma (TACE 2): a randomised placebo-controlled, double-blind, phase 3 trial. The Lancet Gastroenterology & Hepatology. 2017;2(8):565-75.  
73. Sansonno D LG, Russi S, Conteduca V, Sansonno L, Dammacco F. Transarterial chemoembolization plus sorafenib: a sequential therapeutic scheme for HCV-related intermediate-stage hepatocellular carcinoma: a randomized clinical trial. The oncologist. 2012;17(3):359-66.  
74. Bruix J CA, Meinhardt G, Nakajima K, De Sanctis Y, Llovet J. Prognostic factors and predictors of sorafenib benefit in patients with hepatocellular carcinoma: Analysis of two phase III studies. Journal of hepatology. 2017;67(5):999-1008.  
75. Llovet JM RS, Mazzaferro V, Hilgard P, Gane E, Blanc JF, de Oliveira AC, Santoro A, Raoul JL, Forner A, Schwartz M. Sorafenib in advanced hepatocellular carcinoma. New England journal of medicine. 2008;359(4):378-90.  
76. Zhang T DX, Wei D, Cheng P, Su X, Liu H, Wang D, Gao H. Sorafenib improves the survival of patients with advanced hepatocellular carcinoma: a meta-analysis of randomized trials. Anti-cancer drug. 2010;21(3):326-32.  
77. Wang Z WX, Zeng WZ, Xu GS, Xu H, Weng M, Hou JN, Jiang MD. Meta-analysis of the efficacy of sorafenib for hepatocellular carcinoma. Asian Pacific Journal of Cancer Prevention. 2013;14(2):691-4.  
78. Liu L ZY, Han L, Qin SK. Efficacy and safety of the oxaliplatin-based chemotherapy in the treatment of advanced primary hepatocellular carcinoma: A meta-analysis of prospective studies. Medicine. 2016;95(40):e4993.  
79. Cheng AL KY, Chen Z, Tsao CJ, Qin S, Kim JS, Luo R, Feng J, Ye S, Yang TS, Xu J. Efficacy and safety of sorafenib in patients in the Asia-Pacific region with advanced hepatocellular carcinoma: a phase III randomised, double-blind, placebocontrolled trial. The lancet oncology. 2009;10(1):25-34.  
80. Qin S BY, Lim HY, Thongprasert S, Chao Y, Fan J, Yang TS, Bhudhisawasdi V, Kang WK, Zhou Y, Lee JH. . Randomized, multicenter, open-label study of oxaliplatin plus fluorouracil/leucovorin versus doxorubicin as palliative chemotherapy in patients with advanced hepatocellular carcinoma from Asia. Journal of Clinical Oncology. 2013;31(28):3501-8.  
81. Peng S ZY, Xu F, Jia C, Xu Y, Dai C. An updated meta-analysis of randomized controlled trials assessing the effect of sorafenib in advanced hepatocellular carcinoma. PLoS One. 2014;9(12):e112530.  
82. Shao YY SW, Chan SY, Lu LC, Hsu CH, Cheng AL. . Treatment efficacy differences of sorafenib for advanced hepatocellular carcinoma: a meta-analysis of randomized clinical trials. Oncology. 2015;88(6):345-52.  
83. Abou-Alfa GK JP, Knox JJ, Capanu M, Davidenko I, Lacava J, Leung T, Gansukh B, Saltz LB. Doxorubicin plus sorafenib vs doxorubicin alone in patients with advanced hepatocellular carcinoma: a randomized trial. Jama. 2010;304(19):2154-60.  
84. Gish RG PC, Lazar L, Ruff P, Feld R, Croitoru A, Feun L, Jeziorski K, Leighton J, Knox J, Gallo J. Phase III randomized controlled trial comparing the survival of patients with unresectable hepatocellular carcinoma treated with nolatrexed or doxorubicin. Journal of clinical oncology. 2007;25(21):3069-75.  
85. Lai CL WP, Lok AF, Lin HJ, Ngan H, Lau JN, Chung HT, Ng MT, Yeoh EK, Arnold M. Recombinant α2 interferon is superior to doxorubicin for inoperable hepatocellular carcinoma: a prospective randomised trial. British journal of cancer. 1989;60(6):928-33.  
86. Melia WM JP, Williams R. Controlled clinical trial of doxorubicin and tamoxifen versus doxorubicin alone in hepatocellular carcinoma. Cancer treatment reports. 1987;71(12):1213-6.  
87. Okazaki N YM, Yoshida T, Hijikata A. A controlled study of intravenous doxorubicin versus oral tegafur in patients with hepatocellular carcinoma. Nihon Gan Chiryo Gakkai shi. 1985;20(3):556-61.  
88. Schachschal G LH, Plauth M. Controlled clinical trial of doxorubicin and tamoxifen versus tamoxifen monotherapy in hepatocellular carcinoma. European journal of gastroenterology & hepatology. 2000;12(3):281-4.  
89. Bruix J TW, Gasbarrini A, Santoro A, Colombo M, Lim HY, Mazzaferro V, Wiest R, Reig M, Wagner A, Bolondi L. Regorafenib as second-line therapy for intermediate or advanced hepatocellular carcinoma: multicentre, open-label, phase II safety study. European journal of cancer. 2013;49(16):3412-9.  
90. Cheng AL KY, Lin DY, Park JW, Kudo M, Qin S, Chung HC, Song X, Xu J, Poggi G, Omata M. Sunitinib versus sorafenib in advanced hepatocellular cancer: results of a randomized phase III trial. Journal of clinical oncology. 2013;31(32):4067-75.  
91. Manesis EK GG, Zoumboulis P, Vafiadou I, Hadziyannis SJ. Treatment of hepatocellular carcinoma with combined suppression and inhibition of sex hormones: a randomized, controlled trial. . Hepatology. 1995;21(6):1535-42.  
92. Nowak AK SM, Chow PK, Findlay M. . Use of tamoxifen in advanced‐stage hepatocellular carcinoma. Cancer. 2005;103(7):1408-14.  
93. Pan DY QJ, Chen JW, Huo YC, Zhou YK, Shi HA. Tamoxifen combined with octreotide or regular chemotherapeutic agents in treatment of primary liver cancer: a randomized controlled trial. Hepatobiliary Pancreat Dis Int. 2003;2(2):211-5. 94. Zhu AX RO, Evans TJ, Ross PJ, Santoro A, Carrilho FJ, Bruix J, Qin S, Thuluvath PJ, Llovet JM, Leberre MA. SEARCH: a phase III, randomized, double-blind, placebo-controlled trial of sorafenib plus erlotinib in patients with advanced hepatocellular carcinoma. Journal of Clinical Oncology. 2014;33(6):559-66.  
95. Groupe d'Etude et de Traitement du Carcinome Hépatocellulaire. Randomized trial of leuprorelin and flutamide in male patients with hepatocellular carcinoma treated with tamoxifen. Hepatology (Baltimore, Md). 2004;40(6):1361-9.  
96. Chow PK MD, Chen Y, Zhang X, Win KM, Hoang HH, Nguyen BD, Jin MY, Lobo R, Findlay M, Lim CH. Randomised double-blind trial of megestrol acetate vs placebo in treatment-naive advanced hepatocellular carcinoma. . British journal of cancer. 2011;105(7):945-52.  
97. Zhu AX PJ, Ryoo BY, Yen CJ, Poon R, Pastorelli D, Blanc JF, Chung HC, Baron AD, Pfiffer TE, Okusaka T. . Ramucirumab versus placebo as second-line treatment in patients with advanced hepatocellular carcinoma following firstline therapy with sorafenib (REACH): a randomised, double-blind, multicentre, phase 3 trial. The lancet oncology. 2015;16(7):859-70.  
98. Koeberle D DJ, Demeter G, Li Q, Ribi K, Samaras P, Saletti P, Roth AD, Horber D, Bühlmann M, Wagner AD. . Sorafenib with or without everolimus in patients with advanced hepatocellular carcinoma (HCC): a randomized multicenter, multinational phase II trial (SAKK 77/08 and SASL 29). Annals of oncology. 2016;27(5):856-61.  
99. Zhu AX KM, Assenat E, Cattan S, Kang YK, Lim HY, Poon RT, Blanc JF, Vogel A, Chen CL, Dorval E. . Effect of everolimus on survival in advanced hepatocellular carcinoma after failure of sorafenib: the EVOLVE-1 randomized clinical trial. Jama. 2014;312(1):57-67.  
100. Hsu CY LY, Hsia CY, Huang YH, Su CW, Lin HC, Lee RC, Chiou YY, Lee FY, Huo TI. . Performance status in patients with hepatocellular carcinoma: determinants, prognostic impact, and ability to improve the Barcelona Clinic Liver Cancer system. Hepatology. 2013;57(1):112-9.  
101. Hsu CY LP, Lee YH, Hsia CY, Huang YH, Chiou YY, Lin HC, Huo TI. Hepatocellular carcinoma patients with performance status 1 deserve new classification and treatment algorithm in the BCLC system. Medicine. 2015;94(29):e1223. 102. Abdel-Rahman O FM. Sorafenib-based combination as a first line treatment for advanced hepatocellular carcinoma: a systematic review of the literature. Critical reviews in oncology/hematology. 2014;91(1):1-8.  
103. American College of Radiology. LI-RADS archive: CT/MRI LI-RADS v2017 core.  
American College of Radiology website2017 [Available from: https://www.acr.org/Clinical-Resources/Reporting-and-DataSystems/LI-RADS/CT-MRI-LI-RADS-v2017.]  
104. Gavanier M AA, Sellal C, Orry X, Claudon M, Bronowicki JP, Laurent V. CT imaging findings in patients with advanced hepatocellular carcinoma treated with sorafenib: Alternative response criteria (Choi, European Association for the Study of the Liver, and modified Response Evaluation Criteria in Solid Tumor (mRECIST)) versus RECIST 1.1. European journal of radiology. 2016;85(1):103-12.  
105. Lencioni R LJ. Modified RECIST (mRECIST) assessment for hepatocellular carcinoma. . In: Publishers TM, editor. Seminars in liver disease 302010. p. 052-60.  
106. Raoul JL PJ, Kang YK, Finn RS, Kim JS, Yeo W, Polite BN, Chao Y, Walters I, Baudelet C, Lencioni R. Using modified RECIST and alpha-fetoprotein levels to assess treatment benefit in hepatocellular carcinoma. Liver cancer. 2014;3(3-4):43950.  
107. Cella D BZ, Kindler HL, Fuchs CS, Bray S, Barlev A, Oglesby A. . Validity of the FACT Hepatobiliary (FACT-Hep)  
questionnaire for assessing disease-related symptoms and health-related quality of life in patients with metastatic pancreatic cancer . Quality of Life Research. 2013;22(5):1105-12.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. Escopo e finalidade das Diretrizes** -->
As Diretrizes Diagnósticas e Terapêuticas (DDT) do Carcinoma Hepatocelular (CHC) no Adulto foram iniciadas com a reunião presencial para delimitação do seu escopo. Nesta reunião, estavam presentes seis membros do Grupo Elaborador, sendo quatro especialistas e dois metodologistas, e um representante do Comitê Gestor.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento das DDT, sendo definida a macroestrutura das Diretrizes, embasado no disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009<sup>1</sup> e nas Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Deste modo, o grupo de especialistas foi orientado a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor destas DDT foi composto por um painel de especialistas e metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), sob coordenação do DGITS/SCTIE/MS. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e o termo de confidencialidade. Participantes que possuíssem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da elaboração e redação de questões específicas, sem impedimento de participar da discussão das demais questões, incluindo votação caso não fosse obtido consenso.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) de Câncer de Fígado no Adulto, renomeadas para DDT de Câncer Hepatocelular no Adulto, foi inicialmente apresentada à 66ª e 75ª Reuniões da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizadas em 15 de maio de 2019 e 17 de dezembro de 2019, respectivamente. Em seguida, o tema foi apresentado ao Plenário da Conitec, à sua 86ª Reunião Ordinária, ocorrida em 04 de março de 2020, quando foram solicitadas adequações ao documento e alteração do título documento. O documento revisado foi apresentado à Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêutica, à sua 98ª  
Reunião Ordinária, ocorrida em 19 de abril de 2022, com a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE), Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). Considerando que as adequações solicitadas pelo Plenário foram realizadas, as DDT foram aprovadas para avaliação da Conitec.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3. Busca da evidência** -->
Estas DDT foram desenvolvidas conforme as Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do  
Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO (Figura 1). Durante a reunião de escopo destas DDT, sete questões de pesquisa foram levantadas **(Quadro A)** :  
**Figura 1 -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
Foe *Populacao ou condi¢ao clinica<br>Intervengao, no caso de estudos experimentais<br>*Fator de exposicao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagndstica<br>*Controle, de acordo com tratamento/niveis de<br>exposic¢ao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a priori,<br>de acordo com sua importancia<br><!-- End of picture text -->  
**Quadro A -** Questões PICO elencadas para elaboração das DDT.  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|1|Qual o desempenho diagnóstico do LI-RADS?|Diagnóstico|
|2|Qual a eficácia e segurança da ressecção em fígado de paciente com<br>carcinoma hepatocelular não cirrótico?|Tratamento|
|3|Qual a eficácia e segurança da radioterapia (estereotáxica) no carcinoma<br>hepatocelular?|Tratamento|
|4|Qual a eficácia, segurança e dose do sorafenibe para o carcinoma<br>hepatocelular?|Tratamento|
|5|Qual a eficácia das quimioterapias sistêmicas no carcinoma hepatocelular?|Tratamento|
|6|Qual a eficácia e segurança do DEB (_drug-eluting bead_) x<br>quimioembolização clássica, para o carcinoma hepatocelular estágio B?|Tratamento|
|7|Qual o efeito dos antivirais para hepatite C (alfapeginterferona 2A e 2B,<br>ribavirina, sofosbuvir, simeprevir, daclatasvir) no transplante de fígado em<br>paciente com carcinoma hepatocelular?|Tratamento|  
Os metodologistas do Grupo Elaborador elaboraram as estratégias e realizaram a busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados. A equipe de metodologistas envolvida no processo ficaria responsável pela busca e avaliação de evidências, segundo metodologia GRADE. A estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e conferida por outro, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo.  
Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança.  
Adicionalmente, conferiu-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas e referenciadas. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia.  
Durante o processo de triagem, caso fosse percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato PDF, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados das DDT.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel<sup>®</sup> . As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>3</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>4</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>5</sup> .  
Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas as estratégias de busca, síntese e avaliação das evidências para cada uma das sete questões PICO realizadas para a presente DDT.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ )<sup>113</sup> , de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **4. Recomendações** -->
A relatoria das seções das DDT foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas, interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **4.1. Questões de pesquisa** -->
**Questão de Pesquisa 1:** Qual o desempenho diagnóstico do LI-RADS?

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. Estratégia de busca** -->
MEDLINE via PubMed: ((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND (Liver Imaging Reporting and Data System OR LI-RADS OR LI RADS)  
Total: 78 referências  
Data de acesso: 16/08/2017  
EMBASE: 'liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND (('liver imaging reporting and data system'/exp OR 'liver imaging reporting and data system' OR 'lirads' OR 'li rads') AND [embase]/lim)  
Total: 88 referências  
Data do acesso: 21/08/2017

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 166 referências (78 no MEDLINE e 88 no Embase). Destas, 53 foram excluídas por estarem duplicadas. Cento e treze referências foram triadas por meio da leitura de título e resumos, das quais 39 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dezessete estudos foram excluídos nessa etapa, sendo o principal motivo a utilização de teste referência diferente do considerado padrão-ouro (diagnóstico anatomopatológico). Quatro estudos foram excluídos por não apresentarem dados referentes aos desfechos de sensibilidade, especificidade, valor preditivo positivo, valor preditivo negativo ou acurácia.  
Foram incluídos 17 estudos 114-130, sendo 1 publicado apenas como resumo de congresso 128. Como critério de  
inclusão, exigiu-se que a avaliação do desempenho diagnóstico do LI-RADS, independentemente da técnica de exame de imagem utilizada, tivesse sido realizada em relação ao teste referência considerado padrão-ouro, isto é, avaliação anatomopatológica. Foram considerados para inclusão estudos de acurácia diagnóstica e estudos caso-controle. Relatos de casos e séries de casos não foram incluídos.  
**3. Descrição dos estudos e seus resultados**  
A descrição sumária dos estudos encontra-se na **Tabela A** . As características dos pacientes encontram-se descritas na **Tabela B** . A **Tabela C** apresenta dados de acurácia do LI-RADS em relação ao teste referência (avaliação anatomopatológica).  
**Tabela A** <mark>– Características dos estudos.</mark>  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Teste Index**<br>**(Exame de Imagem)**<br>**Versão LI-RADS**|**Teste referência**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Basha et al.**<br>**2017**<sup>**114**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>do LI-RADS por tomografia<br>computadorizada|Pacientes com cirrose<br>hepática e nódulo único<br>(10-20 mm) detectado por<br>US|LI-RADS (TC) v2014|Biópsia por agulha fina|Baixo risco|
|**Becker et**<br>**al. 2017**<sup>**115**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>Avaliar concordância com<br>outro critério diagnóstico<br>Verificar concordância inter-<br>examinador|Pacientes com doença<br>hepática crônica portadores<br>de nódulos|LI-RADS (RM) v2014<br>LI-RADS m|Histopatologia|Baixo risco|
|**Granata et**<br>**al. 2017**<sup>**116**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>de cada critério LI-RADS|Pacientes cirróticos com<br>nódulos entre 1 e 2 cm|LI-RADS v 2014|Classificação histológica<br>de acordo com os<br>critérios Edmondson-<br>Steiner|Baixo risco|
|**Horvat et**<br>**al. 2017**<sup>**117**</sup>|Caso-controle<br>Diagnóstico|Avaliar acurácia diagnóstica<br>de cada critério LI-RADS,<br>diferenciando ICHC, CHC ou<br>composto<br>Verificar concordância inter-<br>examinador|Pacientes com tumores<br>hepáticos ressecados<br>cirurgicamente, com lesão<br>única|LI-RADS (RM) v2014|Resultado<br>anatomopatológico de<br>lesões ressecadas|Alto risco (estudo de<br>caso controle<br>diagnóstico; os<br>avaliadores sabiam<br>das condições<br>previamente)|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Teste Index**<br>**(Exame de Imagem)**<br>**Versão LI-RADS**|**Teste referência**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Joo et al.**<br>**2017**<sup>**118**</sup>|Estudo transversal de<br>acurácia diagnóstica|Comparar acurácia<br>diagnóstica do LI-RADS por<br>RM (ácido gadoxético) e TC<br>multifásica multidetectora|Pacientes com CHC<br>confirmados<br>histologicamente|LI-RADS (RM com ácido<br>gadoxético) v2014<br>LI-RADS (TC multifásica<br>multidetectora) v2014|Confirmação patológica|Alto risco de viés (os<br>investigadores das<br>imagens tinham<br>conhecimento dos<br>resultados<br>patológicos)|
|**Kim et al.**<br>**2017**<sup>**119**</sup>|Caso-controle|Comparar acurácia<br>diagnóstica entre LI-RADS<br>RM (ácido gadoxético) e TC<br>multidetectora|Casos: pacientes com<br>nódulos displásicos, CHC<br>inicial ou avançado<br>Controles: pacientes<br>cirróticos submetidos à<br>hepatectomia total para<br>transplante.|LI-RADS v2014 (RM)<br>LI-RADS v2014 (TC)|Base de dados<br>institucional com<br>resultados patológicos|Alto risco (estudo de<br>caso controle<br>diagnóstico)|
|**Liu et al.**<br>**2017**<sup>**120**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>para detecção de CHC por LI-<br>RADS.<br>Avaliar concordância inter-<br>examinador|Pacientes com lesões<br>suspeitas de CHC|LI-RADS (RM ou TC)|Resultado patológico pós<br>ressecção ou biópsia por<br>agulha fina|Baixo risco|
|**Barth et al.**<br>**2016**<sup>**121**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>Verificar concordância inter-<br>examinador|Pacientes com hepatite<br>crônica ou cirrose hepática|LI-RADS (RM) v 2014<br>LI-RADS m|Histopatologia ou padrão<br>de referência composto<br>incluindo seguimento<br>com exame de imagem e|Risco incerto<br>(utilização de teste<br>referência por exame<br>de imagem em alguns|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Teste Index**<br>**(Exame de Imagem)**<br>**Versão LI-RADS**|**Teste referência**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||||angiografia com<br>subtração digital|casos)|
|**Chen et al.**<br>**2016**<sup>**122**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>Avaliar concordância com<br>outro critério diagnóstico<br>Verificar concordância inter-<br>examinador|Pacientes com doença<br>hepática, com pelo menos<br>um nódulo maior que 5 mm|LI-RADS (RM ácido<br>gadoxético com fase<br>hepatócito, RM ácido<br>gadoxético sem fase<br>hepatócito, TC)<br>V2014|Diagnóstico patológico<br>confirmado por<br>hepatectomia parcial ou<br>biópsia percutânea por<br>agulha|Baixo risco|
|**Choi et al.**<br>**2016**<sup>**123**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>do LI-RADS por meio da<br>validação de suas categorias<br>LR 4 e LR 5.|Pacientes com doença<br>hepática crônica e nódulos<br>hepáticos menores ou iguais<br>a 3 cm, com um total de até<br>5 nódulos|LI-RADS (RM gadoxatato<br>dissódico)<br>v2014|Diagnóstico patológico<br>pós ressecção ou biópsia<br>por agulha|Baixo risco|
|**Choi et al.**<br>**2016b**<sup>**124**</sup>|Caso-controle<br>diagnóstico|Determinar as características<br>de imagem por ressonância<br>magnética e tomografia<br>computadorizada<br>diferenciando CHC de ICHC|Pacientes com<br>colangiocarcinoma (ICHC)<br>intra-hepático confirmado<br>por anatomopatológico<br>Controle: Pacientes com<br>CHC|LIRAD (RM ou TC dinâmica<br>ácido gadoxético)<br>m LIRAD|Diagnóstico patológico<br>de acordo com a<br>classificação da OMS de<br>2010|Alto risco de viés<br>(Desenho de caso-<br>controle diagnóstico)|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Teste Index**<br>**(Exame de Imagem)**<br>**Versão LI-RADS**|**Teste referência**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ehman et**<br>**al. 2016**<sup>**125**</sup>|Estudo transversal de<br>acurácia diagnóstica|Verificar concordância inter-<br>examinador<br>Comparar desempenho da TC<br>com RM<br>Avaliar sensibilidade LI-<br>RADS|Pacientes cirróticos<br>submetidos a transplante<br>hepático ou hepatectomia<br>parcial, com lesões<br>hepáticas maiores que 1 cm|LI-RADS (RM e TC) v 2014|Resultados patológicos<br>de fígados explantados<br>ou pós ressecção parcial|Alto risco (os<br>avaliadores das<br>imagens por LI-<br>RADS sabiam dos<br>resultados do teste<br>padrão)|
|**Joo et al.**<br>**2016**<sup>**126**</sup>|Caso-controle<br>diagnóstico|Avaliar acurácia diagnóstica<br>do LI-RADS na diferenciação<br>entre ICHC e CHC por meio<br>de ressonância magnética|Pacientes com tumores<br>CCIH e CHC ressecados<br>cirurgicamente|LI-RADS (RM com ácido<br>gadoxético) v2014|Confirmação patológica<br>não especificada|Alto risco (estudo de<br>caso controle<br>diagnóstico)|
|||||||Risco incerto|
|**Kono et al.**<br>**2016**<sup>**127**</sup>|Revisão sistemática<br>de acurácia<br>diagnóstica|Avaliar acurácia diagnóstica<br>LI-RADS US|Pacientes cirróticos com<br>CHC entre 1 e 2 cm|LI-RADS (CEUS)<br>Ultrassonografia com<br>contraste|Histologia ou RM/TC<br>multifásica usando<br>critérios AASLD|(utilização de teste<br>referência por exame<br>de imagem em alguns<br>casos)|
|**Zhao et al.**<br>**2016**<sup>**128**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>do LI-RADS em CHC<br>primário|Pacientes com alto risco de<br>desenvolver CHC|LI-RADS (RM) versão não<br>especificada|Teste referência não<br>especificado<br>(Resumo de congresso<br>sem as informações<br>necessárias para<br>determinação do método<br>de referência)|Risco incerto<br>(resumo de congresso<br>sem as informações<br>necessárias para o<br>julgamento)|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Teste Index**<br>**(Exame de Imagem)**<br>**Versão LI-RADS**|**Teste referência**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Darnell et**<br>**al. 2015**<sup>**129**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>do LI-RADS realizado por<br>ressonância magnética|Pacientes cirróticos com um<br>nódulo hepático único<br>detectado por US, com<br>diâmetro igual ou menor a 2<br>cm|LI-RADS (RM) v 2013.1|Biópsia por agulha fina|Baixo risco|
|**Zhang,**<br>**2015**<sup>**130**</sup>|Estudo transversal de<br>acurácia diagnóstica|Avaliar acurácia diagnóstica<br>Comparar desempenho da TC<br>com RM, para a detecção de<br>nódulos hepáticos.<br>Avaliar concordância inter-<br>examinador|Pacientes com hepatite<br>crônica viral ou cirrose|LI-RADS (RM ou TC)|Diagnóstico patológico<br>cirúrgico ou por biópsia<br>percutânea, ou critério de<br>avaliação integrativa,<br>usando dados clínicos<br>(presença de hepatite<br>viral ou cirrose, níveis de<br>alfafetoproteína) e dados<br>radiológicos|Risco incerto<br>(utilização de teste<br>referência composto<br>por dados clínicos e<br>exame de imagem em<br>alguns casos)|

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Seleção das evidências** -->
<mark>AASLD:</mark> _<mark>American Association for the Study of Liver Diseases</mark>_ <mark>, CEUS:</mark> _<mark>contrast-enhanced ultrasound</mark>_ <mark>, CCIH: colangiocarcinoma intrahepático, CHC: carcinoma hepatocelular, LI-RADS:</mark> _<mark>Liver Imaging Reporting and Data System</mark>_ <mark>, OMS: Organização Mundial da Saúde, RM: ressonância magnética, TC: tomografia computadorizada, US: ultrassonografia</mark>  
**<mark>Tabela B</mark>** <mark>- Características dos pacientes.</mark>  
|**Autor, ano**|**Tamanho amostral**|**Idade - Média ± DP (Faixa)**|**% sexo masculino**|**Características da amostra**|
|---|---|---|---|---|
|**Basha et al.**<br>**2017**<sup>**114**</sup>|55 pacientes|58,8 ±10,8 (39-82)|58%|LIRAD 1= 7,3%, 2 = 16,4%, 3 = 25,5%, 4 = 67%, 5= 41,8%, M = 3,6%|
|**Becker et al.**<br>**2017**<sup>**115**</sup>|84 pacientes (104 nódulos)|57 (40-75)|57%|Maioria dos pacientes portadores de cirrose hepática por vírus C|
|**Granata et al.**<br>**2017**<sup>**116**</sup>|70 pacientes (173 nódulos)|68 (52-83)|53%|BCLC classe A|
|**Horvat et al.**<br>**2017**<sup>**117**</sup>|CHC: 97 pacientes<br>Neoplasia não CHC: 51<br>pacientes|CHC: 65,3 ± 13,7<br>Não CHC: 63,1 ± 13,3|CHC = 67%<br>Não CHC = 41%|Pacientes com CHC ou outras neoplasias não CHC ressecados cirurgicamente|
|**Joo et al.**<br>**2017**<sup>**118**</sup>|182 pacientes (216 lesões<br>CHC)|57,9 ± 10,2|80%|Maioria dos pacientes Child Pugh A, cirrose por vírus B|
|**Kim et al.**|Casos: 68 pacientes|57,2 ± 9 (33-79)|Casos: 69,1%|Maioria dos pacientes com CHC inicial ou avançado|
|**2017**<sup>**119**</sup>|Controles: 57 pacientes|53,2 (31-74)|Controles: 58%|Nódulos displásicos representando a minoria dos casos.|
|**Liu et al.**<br>**2017**<sup>**120**</sup>|249 pacientes|51 anos (26 -79)|86%|Maioria dos pacientes Child Pugh A, cirrose por vírus B|
|**Barth et al.**<br>**2016**<sup>**121**</sup>|84 pacientes|57 (40-75)|70%|91% dos pacientes com cirrose, principal causa hepatite C<br>LIRAD 1 =15,6%, 2 =11,8%, 3=15,6%, 4A =19%, 4B=6,5%, 5A=15,6%,<br>5B=15,9%|
|**Chen et al.**<br>**2016**<sup>**122**</sup>|139 pacientes|68 ± 11 (18 a 89)|73%|Maioria dos pacientes com CHC moderadamente diferenciada|
|**Choi et al.**<br>**2016**<sup>**123**</sup>|300 pacientes (386 nódulos)|56,5 ± 9,4|84%|90% dos pacientes Child Pugh A|  
|**Autor, ano**|**Tamanho amostral**|**Idade - Média ± DP (Faixa)**|**% sexo masculino**|**Características da amostra**|
|---|---|---|---|---|
|**Choi et al.**<br>**2016b**<sup>**124**</sup>|Casos: 72 pacientes com<br>CCIH (78 lesões)<br>Controles:<br>72 pacientes com CHC (77<br>lesões)|CCIH: 58 (37-75)<br>CHC: 55 (36-85)|CCIH: 85%<br>CHC: 78%|Maioria dos pacientes com nódulos único e Child Pugh A|
|**Ehman et al.**<br>**2016**<sup>**125**</sup>|134 pacientes (184 nódulos<br>malignos)|58,2 ± 8,1|81%|Tamanho médio das lesões = 2,6 +- 1,3|
|**Joo et al.**|CHC: 71 pacientes|CHC: 58,9 ± 9,1|CHC 83% CCIH 71%|Pacientes com alto risco de desenvolverem CHC (portadores de vírus B ou de|
|**2016**<sup>**126**</sup>|CCIH: 35 pacientes|CCIH: 63 ± 9,1|:  :|cirrose)|
|**Kono et al.**<br>**2016**<sup>**127**</sup>|428 nódulos<br>(7 estudos primários)|Não relatado|Não relatado|284 CHC, 2 CCIH, 144 nódulos benignos|
|**Zhao et al.**<br>**2016**<sup>**128**</sup>|100 pacientes|55,9 anos (33 - 79)|Não relatado|CHC: 72<br>Nódulos regenerativos: 4<br>Hemangioma: 13<br>Cisto hepático: 4<br>Outros: 7|
|**Darnell et al.**<br>**2015**<sup>**129**</sup>|133 pacientes|64 (37-82)|61%|Maioria dos pacientes Child Pugh A LI-RADS 3-5|
|**Zhang,**<br>**2015**<sup>**130**</sup><br>Legenda:|84 pacientes|55,9 anos (33 - 79)|68%|52 pacientes Child Pugh A<br>32 pacientes Child Pugh B|  
<mark>BCLC:</mark> _<mark>Barcelona Clinic Liver Cancer</mark>_ <mark>, CCIH: colangiocarcinoma intrahepático, CHC: carcinoma hepatocelular, DP: desvio padrão, LI-RADS:</mark> _<mark>Liver Imaging Reporting and Data System.</mark>_  
**<mark>Tabela C</mark>** <mark>- Avaliação da acurácia LI-RADS em relação ao padrão ouro (diagnóstico anatomopatológico).</mark>  
|**Autor ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**|**Valor preditivo**|**Valor preditivo negativo**|**Acurácia**|
|---|---|---|---|---|---|
|**,**||**95%)**|**positivo (IC 95%)**|**(IC 95%)**|**AUC (IC 95%)**|
|**Basha et al.**|L4 = 15,4% (1,9 -45,5)<br>L5 = 66,7% (48,2-82)<br>L4 + L5= 75% (566885)|L4 = 95,5 (77,2-99,9)<br>L5 = 95,5 (77,2-99,9)<br>L4 + L5= 91,3 (72-|L4 = 66,7 (9,4-99,2)<br>L5 = 95,7 (78,1-99,9)<br>L4 + L5= 92,3 (74,9-|L4 = 65,6 (46,8-81,4)<br>L5 = 65,6 (46,8-81,4)<br>L4 + L5= 724 (527873)|L4 = 0,55 (0,38-0,72)<br>L5 = 0,81 (0,68-0,90)|
|**2017**<sup>**114**</sup>|,-,<br>L3  L4  L5 912%|98,9)|99,1)|, ,-,<br>L3  L4  L5 80 519|L4 + L5= 0,83 (0,71-0,92)|
||+  + = ,<br>(76,3-98,1)|L3 + L4 + L5= 57,1<br>(34-78,1)|L3 + L4 + L5= 77,5<br>(61,6-89,2)|+  + =  (,-<br>95,7)|L3 + L4 + L5= 0,74 (0,61-0,85)|
||LI-RADS|LI-RADS||||
||L1 = 100%|L1: 0%||||
||L2 = 98,2%|L2: 28,5%||||
||L3=96,4%|L3: 59,2%||||
||L4=74,5%|L4: 85,7%||||
|**Becker et al.**<br>**2017**<sup>**115**</sup>|L5=34,5%|L5: 98%|Não relatado|Não relatado|0,9 (LI-RADS) e 0,91 (LI-RADS m)|
||mLI-RADS|mLI-RADS||||
||L1= 100%|L1: 0%||||
||L2= 98,2%|L2: 36,7%||||
||L3= 96,4%|L3: 67,3%||||
||L4 = 74,5%|L4: 85,7%||||
||L5= 34,5%|L5: 98%||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||Hipervascularização =<br>66,14%<br>_Wh t_= 9764%|Hipervascularização =<br>29,17%<br>_Wash out_= 91,67%|Hipervascularização =<br>83,17%<br>_Wash out_= 98,41%|Hipervascularização = 14%<br>_Wash out_= 88%|Hipervascularização = 60,26%|
||_as ou_,<br>Cál  874%|Cápsula = 100%|Cápsula = 100%|Cápsula = 60%|_Wash out_= 96,69%|
|**Granata et al.**<br>**2017**<sup>**116**</sup>|psua = ,<br>Sinal hipointenso fase<br>contrastada<br>hepatoespecífica = 100%<br>Sinal hiperintenso T2 w =<br>84,25%<br>Difusão restrita = 84,25%|Sinal hipointenso fase<br>contrastada<br>hepatoespecífica =<br>70,83%<br>Sinal hiperintenso T2 w<br>= 100%<br>Difusão restrita = 100%<br>Todos os pacientes:|Sinal hipointenso fase<br>contrastada<br>hepatoespecífica =<br>94,78%<br>Sinal hiperintenso T2 w<br>= 100%<br>Difusão restrita = 100%|Sinal hipointenso fase<br>contrastada<br>hepatoespecífica = 100%<br>Sinal hiperintenso T2 w =<br>54,55%<br>Difusão restrita = 54,55%|Cápsula = 89,40%<br>Sinal hipointenso fase contrastada<br>hepatoespecífica = 95,36%<br>Sinal hiperintenso T2 w = 86,75%<br>Difusão restrita = 86,75%|
||Todos os pacientes: 0,863|0,784 (0,647 – 0,887)||||
||(0,737 - 0,943)|Tumores acima de 5||||
||Tumores acima de 5 cm:|cm:  0,842 (0,604-||||
||0,933 (0,779-0,992)|0,966)||||
|**Horvat et al.**<br>**2017**<sup>**117**</sup>|Tumores menores ou iguais<br>a 5 cm: 0,762 (0,528-0,918)|Tumores menores ou<br>iguais a 5 cm: 0,750|Não relatado|Não relatado|Não relatada|
||Tumores 3,1 a 5 cm: 0,882|(0,566-0,885)||||
||(0,636 - 0,985)|Tumores 3,1 a 5 cm:||||
||Tumores menores que 3|0,706 (0,44 – 0,897)||||
||cm: 0,25 (0,006 - 0,806)|Tumores menores que 3<br>cm: 0,8 (0,519 - 0,957)||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||LI-RADS 5/5v (RM)<br>Examinador 1: 63,4%<br>Examinador 2: 60,6%<br>LR-5 (RM)|||||
||Examinador 1: 61,1%|||||
||Examinador 2: 57,4%|||||
||LR-5v (RM)|||||
||Examinador 1: 2,3%|||||
||Examinador 2: 3,2%<br>LR-4 (RMN)|||||
||Examinador 1: 32,9%|||||
|**Joo et al. 2017**<sup>**118**</sup>|Examinador 2: 35,6%<br>LR-3 (RMN)|Não relatado|Não relatado|Não relatado|Não relatada|
||Examinador 1: 2,3%|||||
||Examinador 2: 2,8%|||||
||LR-M (RM)|||||
||Examinador 1: 1,4%|||||
||Examinador 2: 0,9%|||||
||LI-RADS 5/5v TC:|||||
||Examinador 1: 64,4%|||||
||Examinador 2: 60,6%<br>LR-5 (TC)|||||
||Examinador 1: 62,0%|||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||Examinador 2: 57,4%<br>LR-5v (TC)<br>Examinador 1: 2,3%|||||
||Examinador 2: 3,2%|||||
||LR-4 (TC)|||||
||Examinador 1: 19,9%|||||
||Examinador 2: 31,5%|||||
||LR-3 (TC)|||||
||Examinador 1: 14,8%|||||
||Examinador 2: 6,9%<br>LR-M (TC)|||||
||Examinador 1: 0,9%|||||
||Examinador 2: 0,9%|||||
||Sem diferença|||||
||estatisticamente|||||
||significativa|||||
||LI-RADS (RM)|LI-RADS (RM)||||
||Examinador 1 = 67,6%|Examinador 1 = 89,5%||||
|**Kim et al. 2017**<sup>**119**</sup>|Examinador 2 = 70,1%<br>Examinador 3 = 73,5%|Examinador 2 = 89,5%<br>Examinador 3 = 98,2%|Não relatado|Não relatado|Não relatada|
||LI-RADS (TC)|LI-RADS (TC)||||
||Examinador 1 = 57,4%|Examinador 1 = 87,7%||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
|**Liu et al. 2017**<sup>**120**</sup>|Examinador 2 = 52,9%<br>Examinador 3 = 60,3%<br>LR-5: 84,8%<br>LR-4 e 5: 93,8%|Examinador 2 = 91,2%<br>Examinador 3 = 94,7%<br>LR-5: 95,8%<br>LR-4 e 5: 88,2%|LR-5: 96,8%<br>LR-4 e 5: 92,3%|LR-5: 80,9%<br>LR-4 e 5: 90,5%|Não relatada|
|**Barth et al.**<br>**2016**<sup>**121**</sup>|Não reportada|Não reportada|Não relatado|Não relatado|0.87 (0.84-0.90)|
||Examinador 1|Examinador 1|||Examinador 1|
||RM com fase hepatócito=|RM com fase|||RM com fase hepatócito= 0,989 (0,948-0,991)|
||95%|hepatócito= 96%|Examinador 1|Examinador 1|RM sem fase hepatócito= 0,979 (0,93-0,994)|
||RM sem fase hepatócito=|RM sem fase|RM com fase|RM com fase hepatócito=|TC= 0,979 (0,948-0,991)|
||84%|hepatócito= 96%|hepatócito= 99%|87%|Examinador 2|
||TC= 84%|TC= 100%|RM sem fase|RM sem fase hepatócito=|RM com fase hepatócito= 0,989 (0,966-0,996)|
||Examinador 2|Examinador 2|hepatócito= 99%|60%|RM sem fase hepatócito= 0,981 (0,959-0,991)|
|**Chen et al.**|RM com fase hepatócito=|RM com fase|TC= 100%|TC= 64%|TC= 0,971 (0,94-0,986)|
|**2016**<sup>**122**</sup>|95%|hepatócito= 96%|Examinador 2|Examinador 2|Para lesões menores que 2 cm:|
||RM sem fase hepatócito=|RM sem fase|RM com fase|RM com fase hepatócito=|Examinador 1|
||86%|hepatócito= 100%|hepatócito= 99%|87%|RM com fase hepatócito= 0,974 (0,905-0,993)|
||TC= 89%|TC= 100%|RM sem fase|RM sem fase hepatócito=|RM sem fase hepatócito=0,952 (0,851-0,986)|
||Para lesões menores que 2|Para lesões menores|hepatócito= 100%|65%|TC= 0,953 (0,879-0,982) Examinador 2|
||cm:|que 2 cm:|TC= 100%|TC= 70%|RM com fase hepatócito= 0,974 (0,905-0,993)|
||Examinador 1|Examinador 1|||RM sem fase hepatócito= 0,974 (0,905-0,993)|
||RM com fase hepatócito=|RM com fase|||TC= 0,974 (0,905-0,993)|  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||95%|hepatócito= 96%||||
||RM sem fase hepatócito=|RM sem fase||||
||72%|hepatócito= 96%||||
||TC= 70%|TC= 100%||||
||Examinador 2|Examinador 2||||
||RM com fase hepatócito=|RM com fase||||
||93%|hepatócito= 96%||||
||RM sem fase hepatócito=|RM sem fase||||
||77%|hepatócito= 100%||||
||TC= 74%|TC= 100%||||
||LI-RADS vs. Diagnóstico||LI-RADS vs.|||
||patológico||Diagnóstico patológico|||
||LIRAD 4 inicial||LIRAD 4 inicial|||
||25,4% (20-31,6)||90% (79,5-95,7)|||
||LIRAD 4 (_upgraded_)*||LIRAD 4 (_upgraded_)*|||
|**Choi et al.**<br>**2016**<sup>**123**</sup>|17,4% (12,8-23,1)<br>LIRAD 5|Não relatado|72,5% (59-83)<br>LIRAD 5|Não relatado|Não relatado|
||57,3% (50,6-63,7)||94,6% (89-97,5)|||
||LI-RADS vs. Diagnóstico||LI-RADS vs.|||
||patológico e clínico||Diagnóstico patológico|||
||LIRAD 4 inicial: 22,0%||e clínico|||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||(17,9–26,8)||LIRAD 4 inicial:|||
||LIRAD 4 (_upgraded_)*:||92,3% (83,9–96,7)|||
||29,1% (24,4–34,2)||LIRAD 4 (_upgraded_):|||
||LIRAD 5: 48,9% (43,6–||71,4% (63,2–78,4)|||
||54,3)||LIRAD 5: 95,2%|||
||||(90,7–97,7)|||
||Sensibilidade para|Especificidade para||||
||diagnóstico diferencial com|diagnóstico diferencial||||
||CCIH|com CCIH||||
||M LIRAD 5:|M LIRAD 5:||||
||RM_washout_convencional|RM wash out||||
||= 64,9% (53,8-74,7)|convencional = 96,2%||||
||RM_washout_convencional|(88,8-99,1)||||
|**Choi et al.**<br>**2016b**<sup>**124**</sup>|+ características** = 58,4%<br>(47,3-68,8)<br>RM_washout_fase veia|RM_washout_<br>convencional +<br>características = 97,4%|Não relatado|Não relatado|Não relatado|
||porta = 55,8% (44,7-66,4)|(90,6-99,8)||||
||RM_washout_fase veia|RM_washout_fase veia||||
||porta + características =|porta = 100% (94,4-||||
||49,4% (38,5-60,3)|100)||||
||TC_washout_convencional|RM_washout_fase veia||||
||=  67,5% (56,4-77) TC|porta + características =||||
||wash out Fase veia porta =|100% (94,4-100)||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||62,3% (41,2-72,4)|TC_washout_||||
||M LIRAD 4 + 5:|convencional = 97,4%||||
||RM_washout_convencional<br>= 92,2% (83,7-96,7)|(90,6-99,8)<br>TC_washout_fase veia||||
||RM_washout_convencional|porta = 97,4% (90,6-||||
||+ características = 80,5%|99,8)||||
||(70,2-87,9)|M LIRAD 4 + 5:||||
||RM_washout_fase veia|RM_washout_||||
||porta = 92,2% (83,7-96,7)|convencional = 80,8%||||
||RM_washout_fase veia|(70,6-88,1)||||
||porta + características =|RM_washout_||||
||80,5% (70,2-87,9)|convencional +||||
||TC_washout_convencional|características = 88,5%||||
||= 85,7% (76-92)|(79,3-94)||||
||TC_washout_fase veia porta|RM_washout_fase veia||||
||= 87% (77,5-93)|porta = 87,2% (77,8-<br>93,1)||||
|||RM_washout_fase veia||||
|||porta + características =<br>92,3% (83,9-96,7)<br>TC_washout_||||
|||convencional = 76,9%||||
|||(66,4-85)||||  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
|||TC_washout_fase veia<br>porta = 80,8% (70,6-<br>88,1)||||
|**Ehman et al.**<br>**2016**<sup>**125**</sup>|LIRAD 5 = 50 - 59%<br>LIRAD 4 + 5 = 90 -91%|Não se aplica|Não se aplica|Não se aplica|Não se aplica|
||LI-RADS M:|LI-RADS M:|||LI-RADS M:|
||Examinador 1: 88,6%|Examinador 1: 87,3%|||Examinador 1: 87,7%|
||Examinador 2: 80%|Examinador 2: 77,5%|||Examinador 2: 78,3%|
|**J t l 2016**<sup>**126**</sup>|Examinador 3: 74,3%|Examinador 3: 83,1%|Não relatado|Não relatado|Examinador 3: 80,2%|
|**oo e a.**|LI-RADS 5 /5v:|LI-RADS 5 /5v:|||LI-RADS 5 /5v:|
||Examinador 1: 69%|Examinador 1: 97,1%|||Examinador 1: 78,3%|
||Examinador 2: 56,3%|Examinador 2: 94,3%|||Examinador 2: 68,9%|
||Examinador 3: 70,4%|Examinador 3: 88,6%|||Examinador 3: 76,4%|
|**Kono et al. 2016**<br>**127**|62% (39-81%)|99% (88 -100)|97% (95-100)|71% (69-72)|Não relatada|
|**Zhao et al. 2016**<br>**128**|100% (considerando LI-<br>RADS 1 e 2 = negativo e<br>LI-RADS 3 a 5 = positivo)|71,4% (considerando<br>LI-RADS 1 e 2 =<br>negativo e LI-RADS 3<br>a 5 = positivo)|LI-RADS 3 e 4 =<br>93,1%<br>LI-RADS 5 = 100%|Não relatado|0,974 (considerando LI-RADS 1 a 3 = negativo e<br>LI-RADS 4 a 5 = positivo)<br>0,925 (considerando LI-RADS 1 e 2 = negativo e<br>LI-RADS 3 a 5 = positivo)|
|**Darnell et al.**<br>**2015**<sup>**129**</sup>|LI-RADS 5 = 42,3% (33,3-<br>51,9)<br>LI-RADS 4+5 = 65,4%|LI-RADS 5 = 98,2%<br>(90,4-99,7)<br>LI-RADS 4+5 = 96,4%|LI-RADS 5 = 97,8%<br>(88,4-99,6)<br>LI-RADS 4+5 = 97,1|LI-RADS 5 = 47,4% (38,4-<br>56,5)<br>LI-RADS 4+5 = 59,6%|Não relatado|  
|**Autor, ano**|**Sensibilidade (IC 95%)**|**Especificidade (IC**<br>**95%)**|**Valor preditivo**<br>**positivo (IC 95%)**|**Valor preditivo negativo**<br>**(IC 95%)**|**Acurácia**<br>**AUC (IC 95%)**|
|---|---|---|---|---|---|
||(55,8-73,8)|(87,7-99)|(90,2 - 99,2)|(49,2-69,1)||
|**Zhang, 2015**<sup>**130**</sup>|LI-RADS ≥2:<br>RM: 100,0 (95,2–100,0)<br>TC: 100,0 (95,2–100,0)<br>LI-RADS > 2:<br>RM: 100,0 (95,2–100,0)<br>TC: 89,5 (80,3–95,3)<br>LI-RADS > 3ᶧ<br>RM = 71%<br>TC = 31,6%<br>LI-RADS > 4:<br>RM: 21,1 (12,5–31,9)<br>TC: 10,5 (4,7–19,7)<br>LI-RADS > 5:<br>RM: 0,0 (0,0–4,8)<br>TC: 0,0 (0,0–4,8)|LI-RADS ≥2:<br>RM: 0,0 (0,0–8,5)<br>TC: 0,0 (0,0–8,5)<br>LI-RADS > 2:<br>RM: 4,8 (0,7–16,2)<br>TC: 33,3 (19,6–49,5)<br>LI-RADS maior que 3ᶧ<br>RM = 61,9%<br>TC = 95,2%<br>LI-RADS > 4:<br>RM: 95,2 (83,8–99,2)<br>TC: 100,0 (91,5–100,0)<br>LI-RADS > 5:<br>RM: 100,0 (91,5–<br>100,0)<br>TC: 100,0 (91,5–100,0)|Não relatado|Não relatado|LI-RADS maior que 3<br>RM = 67,8%<br>TC = 54,3%|  
<mark>Legenda: CEUS:</mark> _<mark>contrast-enhanced ultrasound</mark>_ <mark>, CCIH: colangiocarcinoma intrahepático, CHC: carcinoma hepatocelular, LI-RADS:</mark> _<mark>Liver Imaging Reporting and Data System</mark>_ <mark>, RM: ressonância magnética, TC: tomografia computadorizada, US: ultrassonografia</mark>  
<mark>Nota:</mark> _<mark>upgraded</mark>_ <mark>= hipointensidade de fase hepatobiliar, difusão restrita, hiperintensidade leve a moderada no T2, gordura intralesional, nódulo dentro de nódulo, aumento do diâmetro menor do que o limiar de crescimento;</mark> **<mark>ᶧ</mark>** <mark>Melhor critério para maximização tanto da sensibilidade quanto da especificidade.</mark>  
**Questão de pesquisa 2:** Qual a eficácia e segurança da ressecção em fígado de paciente com carcinoma hepático não cirrótico?

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. Estratégia de busca** -->
MEDLINE via Pubmed:  ((((((((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND (("Hepatectomy"[Mesh] OR hepatectomy OR liver resection OR liver excision)))) AND (("Aged"[Mesh] OR "Middle Aged"[Mesh] OR "Adult"[Mesh] OR "Young Adult"[Mesh])))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))  
Total: 333  
Data de acesso: 16/08/2017  
EMBASE:  ((('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('liver resection'/exp OR 'liver resection' OR 'hepatectomy'/exp OR 'hepatectomy' OR 'liver excision') AND [embase]/lim) AND (('aged'/exp OR 'aged' OR 'adult'/exp OR 'adult' OR 'middle aged'/exp OR 'middle aged' OR 'young adult'/exp OR 'young adult') AND [embase]/lim)) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)  
Total: 326  
Data de acesso: 21/08/2017

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 659 referências (333 no MEDLINE e 326 no Embase). Destas, 116 foram excluídas por estarem duplicadas. Quinhentas e quarenta e três referências foram triadas por meio da leitura de título e resumos, das quais 43 tiveram seus textos completos avaliados para confirmação da elegibilidade. Quarenta referências foram excluídas nessa etapa. A principal razão de exclusão foi presença de cirrose como critério de inclusão de participantes no estudo ou, alternativamente, a predominância de pacientes cirróticos e a ausência de dados relatados para a população não cirrótica de forma discriminada.  
Foram incluídos dois estudos, sendo todos publicados em periódicos científicos<sup>131,132</sup> . Os dados de um destes estudos foram extraídos com base apenas no resumo, tendo em vista a indisponibilidade do artigo completo<sup>131</sup> . A busca manual identificou três estudos primários<sup>133-135</sup> e uma revisão sistemática<sup>136</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3. Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela D** . As características dos pacientes encontram-se descritas na **Tabela E** . A **Tabela F** apresenta dados de eficácia e fatores prognósticos favoráveis e a **Tabela G** apresenta dados de segurança.  
**Tabela D** - Características dos estudos.  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Descrição da Intervenção**|**Descrição**<br>**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Revisão Si**|**stemática**|||
|**Zhou et al.**<br>**2014**<sup>**136**</sup>|Revisão<br>sistemática de<br>estudos não<br>randomizados<br>com meta-<br>análise|Avaliar eficácia e<br>segurança da ressecção<br>para CHC em pacientes<br>não cirróticos, quando<br>comparados a pacientes<br>cirróticos|Pacientes não cirróticos<br>submetidos à ressecção<br>Comparadores: pacientes<br>cirróticos<br>Número de estudos incluídos<br>= 31<br>Número de estudos incluídos<br>em meta-análise = 31|Diferentes áreas de ressecção nos dois<br>grupos<br>Grupo não cirrótico associado a<br>ressecção maior|Nove estudos<br>usaram dados<br>comparando<br>pacientes não<br>cirróticos_vs_.<br>cirróticos|Alto risco<br>(Busca feita apenas na<br>MEDLINE; não descreve<br>estudos excluídos; não<br>mostra os resultados de<br>viés dos estudos incluídos;<br>não discute a<br>heterogeneidade e uma<br>das meta-análises)|
||||**Estudos obs**|**ervacionais**|||
|**Mohanty**<br>**et al.**<br>**2016**<sup>**132**</sup>|Coorte<br>retrospectivo|Examinar modalidade de<br>tratamento para pacientes<br>não cirróticos portadores<br>de CHC<br>Identificar fatores<br>associados ao tratamento<br>cirúrgico versus não<br>cirúrgico<br>Avaliar a associação entre<br>a modalidade de|_National Cancer Database_<br>(EUA), n =12.910<br>62% dos pacientes receberam<br>algum tipo de tratamento<br>cirúrgico, incluindo ressecção<br>cirúrgica do tumor, 27%<br>receberam tratamento não<br>cirúrgico.|27% dos pacientes foram submetidos a<br>ressecção hepática. Técnica cirúrgica<br>não especificada.|Ablação ou outro<br>tipo de destruição<br>local (21%)<br>Transplante<br>hepático (14%)<br>Tratamento não<br>cirúrgico (27%)|Risco moderado<br>(Natureza retrospectiva;<br>não demonstra análise por<br>ITT)|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Descrição da Intervenção**|**Descrição**<br>**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||tratamento e a sobrevida|||||  
|**Yip et al.**<br>**2013**<sup>**135**</sup>|Série de casos|Avaliar efetividade de<br>ressecção hepática e<br>identificar fatores<br>prognósticos|87% dos pacientes com tumor<br>solitário|Diferentes áreas e extensão de ressecção|NA|Alto risco<br>(Série de casos; não<br>comparativo)|
|---|---|---|---|---|---|---|
|||Avaliar eficácia e||||Alto risco|
|**Lanthaler**||segurança da ressecção|Tamanho do tumor (cm) em|||(Série de casos; não|
|<br>**t l**|Séi d|para CHC em pacientes|não cirróticos = 11.25|Diferentes áreas de ressecção nos dois|NA|compara os dois grupos;|
|**e a.**<br>**2008**<sup>**133**</sup>|re e casos|não cirróticos, quando<br>comparados a pacientes<br>cirróticos|Tamanho do tumor (cm) em<br>cirróticos = 7.4|grupos||não ajusta por<br>confundidores; estatística<br>descritiva)|
|**Lang et al.**<br>**2004**<sup>**134**</sup>|Série de casos|Avaliar eficácia e<br>segurança da ressecção|Pacientes não portadores de<br>hepatite viral e não cirróticos,<br>submetidos à cirurgia de<br>ressecção hepática curativa.|Maioria dos pacientes submetidos à<br>hepatectomia direita estendida (n= 8),<br>ou hepatectomia direita (n=5)|NA|Alto risco<br>(Série de casos)|
|**Hanazaki**<br>**et al.**|Coorte<br>comparativo|Avaliar desfechos de<br>efetividade e segurança e|Pacientes consecutivos com<br>CHC iguais ou maiores a 10|NR*|NR*|Alto risco<br>(Estudo observacional|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Descrição da Intervenção**|**Descrição**<br>**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**2002**<sup>**131**</sup>|(cirróticos_vs_|fatores prognósticos|cm em diâmetro submetidos à|||retrospectivo)|
||não cirróticos)||ressecção hepática.||||  
Legenda: <mark>CHC carcinoma hepatocelular, EUA Estados Unidos da América, US ultrassonografia, *</mark> dados extraídos do abstract (texto completo não disponível) NA: não se aplica; NR: não relatado.  
**<mark>Tabela E</mark>** <mark>- Características dos pacientes.</mark>  
|**Autor,**<br>**ano**|**N**<br>**Intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**% sexo**<br>**masculino**<br>**Intervenção**|**% sexo masculino**<br>**controle**|**Perdas no seguimento**<br>**N/N (%)**|**Razão para**<br>**perdas**<br>**(n paciente)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||||||**Revisão Siste**|**mática**||||
|**Zhou et**<br>**al.**<br>**2014**<sup>**136**</sup>|3771 (total)<br>1333 (Estudos<br>comparativos)|Pacientes<br>cirróticos:<br>1980<br>(estudos<br>comparativo<br>s)|61 (45 a 68)|Sem diferença<br>estatisticamen<br>te<br>significativa<br>entre<br>pacientes<br>cirróticos e<br>não cirróticos<br>(p=0,9)|77,4%|Sem diferença<br>estatisticamente<br>significativa entre<br>pacientes cirróticos<br>e não cirróticos<br>(p=0,51)|NA (revisão sistemática<br>de estudos<br>retrospectivos)|NA (revisão<br>sistemática de<br>estudos<br>retrospectivos)|Desfechos<br>apresentados<br>para 5 anos de<br>seguimento|
||||||**Estudos Observ**|**acionais**||||
|||Sem<br>tratamento|Idades para o|s dois grupos|% sexo masculin|o para os dois grupos||||
|**Mohant**||cirúrgico:|(ressecção e|controle) *:|(ressecçã|o e controle) *:||||
|**y et al.**<br>**2016**<sup>**132**</sup>|2747 pacientes|3800<br>Ablação:<br>2144|Intervenção<br>63 (5<br>Intervenção|2003-2007<br>4-73)<br>2008-2011|Intervenç<br> <br>Intervenç|ão 2003-2007<br>73,4%<br>ão 2008-2011|Estudo retrospectivo|NA|5 anos|
|||Transplante:<br>1496|62 (5|6-72)||74,1%||||  
|**Autor,**<br>**ano**|**N**<br>**Intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**% sexo**<br>**masculino**<br>**Intervenção**|**% sexo masculino**<br>**controle**|**Perdas no seguimento**<br>**N/N (%)**|**Razão para**<br>**perdas**<br>**(n paciente)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Yip et**||||||||||
|**al.**|57 pacientes|NA|70 (24-88)|NA|57,9%|NA|Estudo retrospectivo|NA|5 anos|
|**2013**<sup>**135**</sup>||||||||||
|**Lanthal**<br>**er et al.**<br>**2008**<sup>**133**</sup>|6 pacientes não<br>cirróticos|10 pacientes<br>cirróticos|70 (não<br>cirróticos)|67,8<br>(cirróticos)|83,3%|80%|1 paciente (16,6%)|Mudança de<br>cidade|22,5 meses|
|**Lang et**||||||||||
|**al.**<br>**2004**<sup>**134**</sup>|83 pacientes|NA|62|NA|70%|NA|Estudo retrospectivo|NA|5 anos|
||33 pacientes<br>consecutivos.|||||||||
|**Hanaza**<br>**ki et al.**<br>**2002**<sup>**131**</sup>|Sem descrição<br>do número de<br>pacientes<br>cirróticos e não<br>cirróticos**.|NR**|Dados NR no<br>resumo|NA|Dados NR no<br>resumo|NA|Estudo retrospectivo|NA|9 anos|  
Nota: <mark>*dados relatados de forma agrupada para todos os participantes, de acordo com a data da intervenção, **d</mark> ados extraídos do abstract (texto completo não disponível); NA: não se aplica; NA: não se aplica; NR: não relatado.  
**<mark>Tabela F</mark>** <mark>- Desfechos de eficácia.</mark>  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|||**Revisão sistemátic**|**a**||
|**Zhou et al. 2014**<sup>**136**</sup>|Pacientes cirróticos_vs_<br>não cirróticos|(OR = 0,61, IC 95%= 0,42 a 0,9) p=0,01<br>[sobrevida melhor em não cirróticos]|Favorece cirróticos (OR = 0,61, IC<br>95%= 0,51 a 0,72) p˂0,001<br>[sobrevida melhor em não<br>cirróticos]<br>Recorrência do tumor: (OR: 1,58,<br>IC95% 1,35; 1,86), p<0,001<br>[menor recorrência em não<br>cirróticos]|NR|
||**E**|**studos inclusos na Revisão sistemática de Zhou**|**et al. 2014**<sup>**136**</sup>**, sem meta-análise**||
|||Sobrevida em 1 ano = 86,9%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Arnaoutakis, 2014**|NA|3 anos = 68,9%; Sobrevida em 5 anos =<br>54,5%|71,1%, 3 anos = 45%, 5 anos =<br>35%|NR**|
|||Sobrevida em 1 ano = 92,4%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Kim, 2014**|NA|3 anos = 81,7%; Sobrevida em 5 anos =<br>73.3%|72%, 3 anos = 61%, 5 anos =<br>53,3%|NR**|
|**Beard, 2013**|NA|Sobrevida em 1 ano = 93,8%; Sobrevida em<br>3 anos = NR; Sobrevida em 5 anos = 72,9%|Sobrevida livre de doença 1 ano =<br>85,4%, 3 anos = NR, 5 anos =<br>56,7%|NR**|
|||Sobrevida em 1 ano = 75,4%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Chiche, 2013**|NA|3 anos = 54,7%; Sobrevida em 5 anos =|60,3%, 3 anos = 38%, 5 anos =|NR**|
|||38,9%|29,1%||  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|**Faber, 2013**|NA|Sobrevida em 1 ano = 94%; Sobrevida em 3<br>anos = 64%; Sobrevida em 5 anos = 26%|Sobrevida livre de doença 1 ano =<br>60,3%, 3 anos = 38%, 5 anos =<br>29,1%|Tumor único<br>Grau de diferenciação<br>Lesões menores que 10 cm|
|**Thelen, 2013**|NA|Sobrevida em 1 ano = 77,7%; Sobrevida em<br>3 anos = 60%; Sobrevida em 5 anos = 46,6%|Sobrevida livre de doença 1 ano =<br>69%, 3 anos = 53%, 5 anos = 42%|NR**|
|**Shrager, 2012**|NA|Sobrevida em 1 ano = 79,1%; Sobrevida em<br>3 anos = 60,3%; Sobrevida em 5 anos =<br>46,3%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|**Truanti, 2012**|NA|Sobrevida em 1 ano = NR; Sobrevida em 3<br>anos = NR; Sobrevida em 5 anos = 61,4%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = 58,4%|NR**|
|**Witjes, 2012**|NA|Sobrevida em 1 ano = 95%; Sobrevida em 3<br>anos = 60%; Sobrevida em 5 anos = 51%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|**Young, 2012**|NA|Sobrevida em 1 ano = 80%; Sobrevida em 3<br>anos = 62%; Sobrevida em 5 anos = 60%|Sobrevida livre de doença 1 ano =<br>70%, 3 anos = 58%, 5 anos = 51%|NR**|
|**Bhaijee, 2011**|NA|Sobrevida em 1 ano = 100%; Sobrevida em 3<br>anos = 56%; Sobrevida em 5 anos = 38%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|**Smoot, 2011**|NA|Sobrevida em 1 ano = 84,6%; Sobrevida em<br>3 anos = 51%; Sobrevida em 5 anos = 38,4%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|**Ardiles, 2010**|NA|Sobrevida em 1 ano = 90%; Sobrevida em 3<br>anos = 67%; Sobrevida em 5 anos = NR|Sobrevida livre de doença 1 ano =<br>65%, 3 anos = 37%, 5 anos = NR|NR**|
|**Lubrano, 2008**|NA|Sobrevida em 1 ano = 85%; Sobrevida em 3<br>anos = 70%; Sobrevida em 5 anos = 64%|Sobrevida livre de doença 1 ano =<br>84%, 3 anos = 66%, 5 anos = 58%|NR**|  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|**Rayya, 2008**|NA|Sobrevida em 1 ano = 69%; Sobrevida em 3<br>anos = 48%; Sobrevida em 5 anos = 48%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|||Sobrevida em 1 ano = 84,4%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Xu, 2008**|NA|3 anos = 62,5%; Sobrevida em 5 anos =|56,3%, 3 anos = 39,6%, 5 anos =|NR**|
|||47,9%|33,3%||
|**Bège, 2007**|NA|Sobrevida em 1 ano = 72%; Sobrevida em 3<br>anos = 54%; Sobrevida em 5 anos = 40%|Sobrevida livre de doença 1 ano =<br>60%, 3 anos = 40%, 5 anos = 33%|Ausência de invasão vascular|
|**Lang, 2007**|NA|Sobrevida em 1 ano = 77%; Sobrevida em 3<br>anos = 48%; Sobrevida em 5 anos = 30%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|Ausência de invasão vascular|
|**Taura, 2007**|NA|Sobrevida em 1 ano = NR; Sobrevida em 3<br>anos = NR; Sobrevida em 5 anos = 81%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = NR|NR**|
|||1 ano: 77,8%|||
|||3 anos: 55%|Cirurgia curativa de tumor primário||
|||5 anos: 44,4%|(n=69)<br>1 ano: 73%||
|||Ressecção incompleta (n=9)|3 anos: 49%|Tumor único|
|**Dupont-Bierre, 2005**|NA|17 meses: 14,8%|5 anos: 49%|Tumor menor que 8 cm<br>Ausência de ruptura de cápsula|
|||Cirurgia curativa de tumor primário (n=69)|Recorrência e ressecção curativa|Ausência de invasão vascular macroscópica|
|||1 ano: 84%|(n=6)||
|||3 anos: 62%<br>5 anos: 50%|7 meses: 0%||  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|||Recorrência e ressecção curativa (n=6)<br>21 meses: 41,7%|||
|**Laurent, 2005**|NA|Sobrevida em 1 ano = NR; Sobrevida em 3<br>anos = 55%; Sobrevida em 5 anos = 43%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = 43%, 5 anos = 29%|NR**|
|**Chang, 2004**|NA|Sobrevida em 1 ano = NR; Sobrevida em 3<br>anos = NR; Sobrevida em 5 anos = 53%|Sobrevida livre de doença 1 ano =<br>NR, 3 anos = NR, 5 anos = 36,8%|NR**|
|**Verhoef, 2004**|NA|Sobrevida em 1 ano = 96%; Sobrevida em 3<br>anos = 68%; Sobrevida em 5 anos = 68%|Sobrevida livre de doença 1 ano =<br>86%, 3 anos = NR, 5 anos = 56%|NR**|
|**Chen, 2003**|NA|Sobrevida em 1 ano = 61,9%; Sobrevida em<br>3 anos = 46%; Sobrevida em 5 anos = 35,9%|Sobrevida livre de doença 1 ano =<br>48,7%, 3 anos = 31%, 5 anos =<br>24%|NR**|
|**Grazi, 2003**|NA|Sobrevida em 1 ano = 84%; Sobrevida em 3<br>anos = 67,9%; Sobrevida em 5 anos = 51%|Sobrevida livre de doença 1 ano =<br>77,6%, 3 anos = 58%, 5 anos =<br>45,6%|NR**|
|**Nagasue, 2001**|NA|Sobrevida em 1 ano = 97%; Sobrevida em 3<br>anos = 76%; Sobrevida em 5 anos = 50%|Sobrevida livre de doença 1 ano =<br>79%, 3 anos = 38%, 5 anos = 31%|Margem de ressecção adequada<br>Ausência de metástase<br>Ausência de invasão da veia porta|
|||Sobrevida em 1 ano = 79,7%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Poon, 2000**|NA|3 anos = 58,7%; Sobrevida em 5 anos =<br>45,6%|57,2%, 3 anos = 41,9%, 5 anos =35<br>%|NR**|
|**Shimada, 2000**|NA|Sobrevida em 1 ano = 88%; Sobrevida em 3<br>anos = 75,3%; Sobrevida em 5 anos = 63%|Sobrevida livre de doença 1 ano =<br>83%, 3 anos = 54%, 5 anos = 38%|NR**|  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|**Bismuth, 1995**|NA|Sobrevida em 1 ano = 74,4%; Sobrevida em<br>3 anos = 51,6%; Sobrevida em 5 anos =<br>40.2%|Sobrevida livre de doença 1 ano =<br>70,5%, 3 anos = 42,8%, 5 anos =<br>33,4%|Lesões menores|
|**Sazaki, 1992**|NA|Sobrevida em 1 ano = 94%; Sobrevida em 3<br>anos = 84%; Sobrevida em 5 anos = 68%|Sobrevida livre de doença 1 ano =<br>79%, 3 anos = 58%, 5 anos = 54%|NR**|
|||**Estudos Observacio**|**nais**||
|||**Tratamentos vs. Embolização direta**<br>Pacientes submetidos a ressecção hepática:<br>Sobrevida em 1 ano: 83,3%<br>Sobrevida em 5 anos: 52,4%<br>HR (ajustado) = 0,34 (IC95% = 0,30 a 0,39)|||
|**Mohanty et al. 2016**<sup>**132**</sup>|Comparador utilizado:<br>Embolização|Pacientes submetidos a transplante:<br>Sobrevida em 1 ano: 90%<br>Sobrevida em 5 anos: 71,4%<br>HR (ajustado) = 0,25 (IC95% = 0,20 a 0,30)|NR|NRs|
|||Pacientes submetidos a ablação:<br>Sobrevida em 1 ano: 77,3%<br>Sobrevida em 5 anos: 26,4%<br>HR (ajustado) = 0,71 (IC95% = 0,62 a 0,82)<br>Pacientes submetidos a nenhum tratamento:|||  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
|||Sobrevida em 1 ano: 34,4%<br>Sobrevida em 5 anos: 11,3%<br>HR (ajustado) = 1,72 (IC95% = 1,52 a 1,94)|||
|||**Sobrevida em 5 anos:**<br>Transplante: 71,5%<br>Ressecção: 55,3%<br>Ablação: 37,7%<br>Não cirúrgico: 27,6%|||
|||**Tratamentos vs. Não tratamento**<br>Transplante: HR: 0,30; 95% CI, 0,27–0,34<br>Ressecção: HR, 0,43; 95%CI, 0,40–0,46<br>Ablação: HR, 0,77; 95%CI 0,71–0,83|||
|**Zhou et al. 2014**<sup>**136**</sup>|Pacientes cirróticos_vs._<br>não cirróticos|Favorece grupo cirróticos (OR = 0,61, IC<br>95%= 0,42 a 0,9) p=0,01|Sobrevida livre de doença em cinco<br>mais baixa em pacientes não<br>cirróticos (OR = 0,61, IC 95%=<br>0,51 a 0,72) p˂0,001|NRs|
|||Sobrevida em 1 ano = 73,5%; Sobrevida em|Sobrevida livre de doença 1 ano =||
|**Yip et al. 2013**<sup>**135**</sup>|NA|3 anos = 49,6%; Sobrevida em 5 anos =<br>39,5%|65,4%, 3 anos = 41,8%, 5 anos =<br>39,1%|Tamanho do tumor e grau de diferenciação|
|**Lanthaler et al.**<br>**2008**<sup>**133**</sup>|Pacientes cirróticos_vs_<br>não cirróticos|Sobrevida em 22,5 meses = 90% (pacientes<br>cirróticos) e 83,3% (pacientes não cirróticos)|Sobrevida sem recorrência = 70%<br>(pacientes cirróticos) e 50%|NRs|  
|**Autor, ano**|**Comparação**|**Sobrevida**|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|
||||(pacientes não cirróticos)||
|||1 ano: 77,8%<br>3 anos: 55%|||
|||5 anos: 44,4%|Cirurgia curativa de tumor primário||
||||(n=69)||
|||Ressecção incompleta (n=9)|1 ano: 73%||
|||17 meses: 14,8%|3 anos: 49%|Tumor único|
|**Dupont-Bierre, 2005**|NA|Cirurgia curativa de tumor primário (n=69)|5 anos: 49%|Tumor menor que 8 cm<br>Ausência de ruptura de cápsula|
|||1 ano: 84%|Recorrência e ressecção curativa|Ausência de invasão vascular macroscópica|
|||3 anos: 62%|(n=6)||
|||5 anos: 50%|7 meses: 0%||
|||Recorrência e ressecção curativa (n=6)|||
|||21 meses: 41,7%|||
|**Lang et al. 2004**<sup>**134**</sup>|NA|Sobrevida em 1 ano = 76%; Sobrevida em 3<br>anos = 38%; Sobrevida em 5 anos = 30%|NR|Ausência de invasão vascular|
|||Sobrevida dos dois grupos em 3 anos= 32%,|||
|**Hanazaki et al. 2002**<sup>**131**</sup>|Pacientes cirróticos_vs._<br>não cirróticos|5 anos= 27% e 9 anos= 17%<br>Não cirróticos:<br>5 anos: 43%<br>Cirróticos:|NR**|Presença de cirrose e estágio avançado da<br>doença (IVa vs II e III) como fatores<br>prognósticos desfavoráveis.|  
|**Autor, ano**|**Comparação**|**Sobrevida**<br>5 anos: 7%*|**Sobrevida livre de recorrência**|**Fatores prognósticos favoráveis**|
|---|---|---|---|---|  
<mark>Legenda: HR:</mark> _<mark>Hazard Ratio</mark>_ <mark>* p = 0,006, **d</mark> ados extraídos do abstract (texto completo não disponível); NA: não se aplica; NR: não relatado  
**Tabela G** - Desfechos de segurança.  
|**Autor, ano**|**Morte período pós-operatório**|**Complicações período pós-operatório**|
|---|---|---|
||**Revisão Sistemática**||
||Mortalidade maior em pacientes cirróticos,|Sem diferença em relação à morbidade pós-|
|**Zhou et al. 2014**<sup>**136**</sup>|quando comparados a não cirróticos (OR= 1,8,<br>IC95%= 1,08 a 3,00, p=0,02)|operatório entre pacientes cirróticos e não<br>cirróticos|
||**Estudos observacionais**||
|**Mohanty, 2016**<sup>**132**</sup>|NR|NR|
|**Yip et al. 2013**<sup>**135**</sup>|Mortalidade = 3,5%|Morbidade = 26,3%|
|**Lanthaler et al.**<br>**2008**<sup>**133**</sup>|Mortalidade cirróticos= 10%<br>Mortalidade não cirróticos= 16,6%|2 pacientes não cirróticos necessitaram de<br>reoperação (33,3%), um paciente cirrótico<br>necessitou de reoperação (10%)|
|**Lang et al. 2004**<sup>**134**</sup>|Mortalidade = 6,3%|Morbidade = 24%|
|**Hanazaki et al.**<br>**2002**<sup>**131**</sup>|Mortalidade nos dois grupos = 15%<br>Mortalidade hospitalar para pacientes cirróticos=<br>31%|Complicações operatórias nos dois grupos=<br>39%|  
Legenda: NR: não relatado  
**Questão de Pesquisa 3:** Qual a eficácia e segurança da radioterapia (estereotáxica) no carcinoma hepatocelular?

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. Estratégia de busca** -->
MEDLINE via Pubmed: ((((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND ("Radiosurgery"[Mesh] OR Stereotactic Radiosurgery)))  
Total: 190 referências  
Data do acesso: 10/08/2017  
EMBASE: (('aged'/exp OR 'aged' OR 'adult'/exp OR 'adult' OR 'middle aged'/exp OR 'middle aged' OR 'young adult'/exp OR 'young adult') AND [embase]/lim) AND ((('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim) AND ((('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('radiosurgery'/exp OR 'radiosurgery' OR 'stereotactic radiosurgery'/exp OR 'stereotactic radiosurgery') AND [embase]/lim)))  
Total: 173 referências  
Data do acesso: 11/08/2017

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 363 referências (190 no MEDLINE e 173 no Embase). Destas, 67 foram excluídas por estarem duplicadas. Duzentas e noventa e seis referências foram triadas por meio da leitura de título e resumos, das quais 33 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dentre os estudos excluídos, 14 eram revisões não sistemáticas, 1 revisão pictórica, 5 relatos de caso, 1 estudo de avaliação de qualidade de vida, 1 avaliação econômica, 1 estudo com pacientes com metástase cerebral. Os critérios de inclusão dos estudos consistiram em avaliar artigos comparativos que abordassem o uso das tecnologias de interesse em pacientes com carcinoma hepatocelular. Foram incluídos dez estudos (10 publicações)<sup>137-146</sup> , sendo um publicado apenas como resumo de congresso<sup>141</sup> .

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3. Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela H** . As características dos pacientes encontram-se descritas na **Tabela I** . As **Tabelas J** e **K** apresentam dados de eficácia e segurança, respectivamente.  
**Tabela H** - Características dos estudos que analisaram a eficácia e segurança da radioterapia (estereotáxica) no carcinoma hepatocelular  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Su et al.**<br>**2017**<sup>**137**</sup>|Estudo de<br>coorte<br>retrospectiva|Comparar a eficácia das<br>técnicas de SABR e<br>ressecção hepática em<br>pacientes com CHC < 5cm<br>e cirrose de classificação A<br>na escala|Pacientes com CHC primário sem tratamento<br>local prévio, 1 ou 2 lesões nodulares com no<br>máximo 5cm de diâmetro, classificação<br>Child-Pugh A, ECOG 0 a 2, ausência de<br>trombose da veia porta e metástases extra-<br>hepáticas, ausência de recidiva após<br>tratamentos prévios.|**SABR**|**Ressecção**<br>**hepática**|Moderado risco de viés/ dados<br>retrospectivos|
|**Lu et al.**<br>**2016**<sup>**138**</sup>|Estudo de<br>coorte<br>retrospectiva|Avaliar segurança e<br>eficácia da radiocirurgia<br>por gamma knife no<br>tratamento do CHC com<br>trombose da veia porta|Pacientes com CHC e trombose da veia porta<br>não expostos a tratamentos prévios e com<br>idade entre 18 e 75 anos|**SBRT com Gamma**<br>**Master Space Body**<br>**Knife System**<sup>**®**</sup>|**Tratamento**<br>**paliativo**|Moderado risco de viés/ dados<br>retrospectivos|
|||Avaliar eficácia do SBRT|||||
|**Matsuo et**<br>**al. 2016**<sup>**139**</sup>|Estudo de<br>coorte<br>retrospectiva|em comparação com<br>3DCRT em pacientes com<br>CHC e trombose da veia<br>cava ou da veia porta|Pacientes com CHC e trombose da veia cava<br>ou da veia porta, classificados com A ou B na<br>escala Child-Pugh e 0-2 na escala ECOG|**SBRT com**<br>**CyberKnife**<sup>**®**</sup>**ou**<br>**TrueBeam**<sup>**®**</sup>|**3DCRT**|Moderado risco de viés, dados<br>retrospectivos|
|**Oladeru et**<br>**al. 2016**<sup>**140**</sup>|Estudo de<br>coorte<br>retrospectiva|Comparar os desfechos de<br>sobrevida global e doença-<br>específica em decorrência<br>da utilização de SIRT<br>versus SBRT em pacientes<br>com CHC|Pacientes com CHC sem metástase,<br>submetidos aos tratamentos de interesse do<br>estudo e apenas um tumor primário|**SBRT**|**SIRT**|Alto risco de viés, dados<br>retrospectivos com carência de<br>dados de seguimento, exclusões de<br>pacientes com_missing data_|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||||Alto risco de viés|
||Resumo de||Pacientes com idade > 65 anos,|||Resumo de congresso: informações|
|**Feng et al.**|congresso:|Avaliar o uso de RFA e|diagnosticados no período de 2004-11 com|**RFA**|**NA**|insuficientes para julgamento;|
|**2016**<sup>**141**</sup>|série de casos<br>retrospectiva|SBRT nos EUA|CHC estágio I ou II, tratados com RFA ou<br>SBRT|**SBRT**||dados retrospectivos com grupos<br>heterogêneos de pacientes (série de|
|||||||casos)|
|**Wahl et al.**<br>**2016**<sup>**142**</sup>|Estudo de<br>coorte<br>retrospectiva|Comparar desfechos<br>clínicos em pacientes com<br>CHC tratados com SBRT<br>ou RFA|Pacientes com CHC não metastático que<br>foram submetidos a uma das tecnologias de<br>interesse|**SBRT**|**RFA**|Moderado risco de viés, dados<br>retrospectivos,|
|**Shiozawa et**<br>**al. 2015**<sup>**143**</sup>|Estudo de<br>coorte<br>retrospectiva|Avaliar desfechos clínicos<br>e efeitos adversos em<br>pacientes com CHC<br>solitário inicial tratados<br>com SBRT ou RFA|Pacientes com CHC solitário em fase inicial,<br>sem comorbidades localizadas nos pulmões,<br>coração ou encéfalo e tratados com RFA ou<br>SBRT|**SBRT com sistema**<br>**Cyber-knife**<sup>®</sup>|**RFA**|Alto risco de viés, dados<br>retrospectivos, viés de seleção|
|**Jacob et al.**<br>**2014**<sup>**144**</sup>|Série de Casos|Medir a sobrevivência em<br>pacientes com CHC<br>tratados com SBRT após<br>TACE|Pacientes diagnosticados com CHC|**SBRT**|**DEBTACE**|Alto risco de viés, série de casos<br>(não tem informação sobre tempo<br>de exposição e confundidores)|
|**Honda et**<br>**al. 2013**<sup>**145**</sup>|Estudo de<br>coorte<br>retrospectiva|Comparar o controle do<br>tumor e a segurança da<br>SBRT combinada com<br>TACE para CHC pequeno,<br>solitário e hipervascular|Pacientes com nódulo CHC hipervascular<br>solitário, até<br>30 mm de diâmetro, sem trombose venosa<br>portal ou metástase extra-hepática<br>e pontuação ≥7 na classificação Child-|**SBRT + TACE**|**TACE**|Moderado risco de viés/ dados<br>retrospectivos|
|||com TACE isolada.|Turcotte-Pugh||||  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Huang et**<br>**al. 2012**<sup>**146**</sup>|Estudo de<br>coorte<br>retrospectiva|Avaliar a segurança e a<br>eficácia da SBRT da<br>Cyberknife<sup>®</sup>e seu efeito<br>sobre a sobrevida em<br>pacientes com CHC<br>recorrente, em comparação<br>com outros tratamentos|Pacientes com a) diagnóstico cito-histológico<br>ou não invasivo de CHC, b) sob tratamento<br>com fins curativos, c) progressão do tamanho<br>do tumor após início do tratamento, d) tumor<br>não ressecável ou inoperável, 0 a 2 na escala<br>ECOG|**SBRT com sistema**<br>**Cyber-knife**<sup>®</sup>|**Talidomida,**<br>**sorafinibe,**<br>**TACE ou**<br>**transplante de**<br>**fígado**|Moderado risco de viés/ dados<br>retrospectivos|  
Legenda: 3DCRT: radioterapia conformal três dimensões; <mark>CHC: carcinoma hepatocelular; DEBTACE: quimioembolização transarterial com</mark> _<mark>drug eluting beads</mark>_ <mark>; E</mark> COG: _Eastern Cooperative Oncology Group_ ; <mark>RFA: Ablação por Radiofreqüência; SABR: radioterapia estereotáxica ablativa; SBRT; radioterapia estereotáxica corpórea; SIRT: radioterapia interna seletiva</mark> _<mark>;</mark>_ <mark>TACE: quimioembolização transarterial; NA: não se aplica.</mark>  
**Tabela I** - Características dos pacientes incluídos nos estudos que analisaram a eficácia e segurança da radioterapia (estereotáxica) no carcinoma hepatocelular.  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade,**<br>**Intervenção**|**Idade,**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tamanho do**<br>**tumor**<br>**(mm)**|**Pontuação**<br>**Child Pugh**<br>**(nº pacientes**<br>**-A/B/C)***|**Bilirrubina total**<br>**(mg/dL), mediana**<br>**(mín- máx)**|**Tempo de seguimento**<br>**(Meses)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Su et al.**<br>**2017**<sup>**137**</sup>|82|35|Média (±DP):<br>59,2 ± 12,6|Média (±DP):<br>44,8 ± 10,4<br>p: 0,331|82,9|82,8<br>p: 0,915|Média<br>(±DP):<br>I: 2,96 ± 1,06<br>C:3,52 ±<br>1,57<br>p: 0,95|I: 82 / 0 / 0<br>C: 35 / 0 / 0<br>p: 1,00|NR|Mediana<br>I: 42<br>C: 44|
||||||||Média (DP)<br>do maior||||
|**Lu et al.**<br>**2016**<sup>**138**</sup>|64|74|Média (± DP):<br>52,83 ±9,53|Média (± DP):<br>54,34 ±11,01<br>p: 0,39|87,6|82,8<br>p: 0,549|tumor:<br>I: 81,4 (37,3)<br>C: 97,9<br>(47,7)|I: 53 / 11 / 0<br>C: 54 / 20 / 0<br>p: 0,167|NR|Máximo: 4 anos|
||||||||p: 0,261||||
|**Matsuo et**|CK: 27|54|CK:<br><70 anos: 11<br>≥ 70 anos: 16|<70 anos: 30|CK: 89|49|NR|CK: 14 / 12 /<br>1|Mediana (min-<br>máx):<br>CK: 08 (03–17)|Mediana (min-máx):<br>CK: 7 (1–26)|
|**al. 2016**<sup>**139**</sup>|TB: 16||TB:<br><70 anos: 8<br>≥ 70 anos: 8|≥ 70 anos: 24|TB: 75|||TB: 8 / 7 / 1<br>C: 27 / 25 / 2|, ,,<br>TB: 0,9 (0,3–13,9)<br>C: 1 (0,3-8)|TB: 6,5 (1–26)<br>C: 5,5 (0-39)|
|**Oladeru et**<br>**al. 2016**<sup>**140**</sup>|112|77|Média (±DP):<br>63,79±11,99|Média (±DP):<br>62,86±10,49<br>p: 0,57|78,5|83,1<br>p:0,46|Média (DP):<br>I: 76,42<br>(93,97)|NR|NR|NR|  
|**Autor, ano**|**N**<br>**intervenção**<br>|**N**<br>**controle**|**Idade,**<br>**Intervenção**|**Idade,**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tamanho do**<br>**tumor**<br>**(mm)**|**Pontuação**<br>**Child Pugh**<br>**(nº pacientes**<br>**-A/B/C)***|**Bilirrubina total**<br>**(mg/dL), mediana**<br>**(mín- máx)**|**Tempo de seguimento**<br>**(Meses)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||C:72,31<br>(42,85)<br>p: 0,69||||
|**Feng et al.**<br>**2016**<sup>**141**</sup>|RFA:78<br>SBRT: 747||Mediana (<br>74 (6|min-máx):<br>6-90)|NR|NR|NR|NR|NR|NR|
||||||||Mediana||||
||||Mediana|Mediana|||(min-máx):|I: 57 / 24 / 2||Mediana (min-máx):|
|**Wahl et al.**<br>**2016**<sup>**142**</sup>|63|161|<br>(min-máx):<br>62 (35-85)|(min-máx):<br>60 (31-81)<br>p: 0,09|85,7|72,7<br>p: 0,04|I: 2,2 (0 - 10)<br>C:1,8 (0,6-<br>7,0)<br>p: 0,14|C: 121 / 103<br>/ 20<br>P: 0,003|NR|I: 27 (0,5-86,5)<br>C: 50,9 (3,5-112,8)<br>p: 0,001|
|**Shiozawa,**<br>**2015**<sup>**143**</sup>|35|38|Média ±DP<br>(mín-máx):<br>75,17 ± 8,1<br>(55-89)|Média ±DP<br>(mín-máx):<br>68,7 ± 10,5<br>(42-86)<br>p: 0,005|78,5|68,57<br>p: 0,82|Média ±DP<br>(mín-máx):<br>I: 28,6 ± 11,5<br>(12-50)<br>C:17,5 ± 6,1<br>(7-29)<br>p: 0,001|I: 28 / 7 / 0<br>C: 31 / 7 / 0<br>p:0,86|NR|I: 12,46 (6,7; 35,01)<br>C: 18,5 (7,3; 40,2)<br>p:0,15|
||||||||Média|Média|||
|**Jacob et al.**<br>**2014**<sup>**144**</sup>|37|124|Média (± DP):<br>64,4 ±12,7|Média (±DP):<br>62,2 ±9,0<br>p: 0,4|72,8|75,8<br>p: 0,829|(±DP):<br>I:78 ±33<br>C: 77 ±49<br>p: 0,2|(±DP):<br>I: 6,3 ±1,2<br>I: 6,7 ±1,5<br>p: 0,291|NR|NR|  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade,**<br>**Intervenção**|**Idade,**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tamanho do**<br>**tumor**<br>**(mm)**|**Pontuação**<br>**Child Pugh**<br>**(nº pacientes**<br>**-A/B/C)***|**Bilirrubina total**<br>**(mg/dL), mediana**<br>**(mín- máx)**|**Tempo de seguimento**<br>**(Meses)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Honda et al.**<br>**2013**<sup>**145**</sup>|30|38|Mediana<br>(min-máx):<br>70 (49-90)|Mediana<br>(min-máx):<br>73 (48-92)<br>p:0,08|63|39<br>p:0,08|Mediana<br>(min-máx):<br>I: 16 (10-30)<br>C: 21 (6-30)<br>p:0,05|I: 24 / 6 / 0<br>C: 31 / 7 / 0<br>p:0,39|Mediana (min-<br>máx):<br>I: 0,8 (0,2-1,6)<br>C: 0,75 (0,4-2,3)<br>p:0,51|Mediana (min-máx):<br>I: 12,3 (6-38,3)<br>C: 30,2(7,44-54,4)<br>p> 0,05|
|**Huang et al.**<br>**2012**<sup>**146**</sup>|28|28|Mediana<br>(min-máx):<br>67(36–86)|Mediana<br>(min-máx):<br>68 (36-83)<br>p: 0,465|79|61<br>p:0,13|Mediana<br>(min-máx):<br>I: 44 (11-<br>123)<br>C: 26 (8-20)<br>p:0,35|I: 28 / 7 / 1<br>C: 75 / 59 / 4<br>p: 0,034|NR|Mediana: 14 (2,0; 35) meses<br>para os 36 pacientes no grupo<br>SBRT e 20 meses para os que<br>sobreviveram|  
Legenda: <mark>I: intervenção; C: controle; CK: Cyberknife</mark><sup>**®**</sup> <mark>; TB: Truebeam</mark><sup>**®**</sup> <mark>; N: número de pacientes; n: número de pacientes que apresentaram o evento; DP: desvio-padrão; p: valor p; NA: não se aplica; NR: não relatado. *Na maioria dos estudos, a classe Child Pugh foi reportada de acordo com a quantidade de pacientes nas classes A B e C.</mark>  
**Tabela J** - Desfechos de eficácia dos estudos que analisaram a radioterapia (estereotáxica) no carcinoma hepatocelular.  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**|**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
||SABR|SG em 1, 3 e 5 anos: 100%,<br>91,8% e 74,3%||SLP em 1, 3 e 5 anos: 84,4%,<br>59,2% e 43,9%||**Taxa de controle de recorrência distante intra-**<br>**hepático em A) 1 ano; B) 3 anos e C) 5 anos:**<br>A)84,4%; B) 66,3% C) 61,5%|0,799|
|**Su et al.**<br>**2017**<sup>**137**</sup>|||0,405||0,945|**Taxa de recorrência durante o seguimento**:<br>45,71%||
|||||||**Taxa de controle de recorrência distante intra-**||
|||SG em 1 3 e 5 anos: 967%||SLP em 1, 3 e 5 anos: 69,0%,||**hepático em A) 1 ano; B) 3 anos e C) 5 anos:**|0,666|
||RH|,     ,,<br>89,3% e 69,2%||62,4% e 35,9%||A)<br>72%; B) 61,4% e C) 54,5%<br>**Taxa de recorrência durante o seguimento**:||
|||||||33,73%||
|||||||**Benefício de sobrevida**||
||Gamma Knife|SG mediana: 6,1 meses (IC<br>95%: 2,719-3,281)|NR|NR|NR|HR: 0,538 (IC 95%: 0,356-0,814)<br>**Fatores associados com maior SG**|<0,001|
|**Lu et al.**<br>**2016**<sup>**138**</sup>||SG di 3  (IC||||ECOG 0-1: HR=0,495 (IC 95%: 0,267-0,796)<br>Child A: HR= 0,534 (IC 95%: 0,333-0,857)|<0,001|
|||meana:  meses<br>95%: 4,706-||||Diâmetro do tumor ≤5cm: HR= 0,452 (IC 95%:<br>|<0,001<br>|
||Paliativo|7494)||p: 0,003||0,258-0,794)|<0,001|
|||,||||Distribuição monolobar: HR= 0,584 (IC 95%:|<0,001|
|||||||0,383-0,892)||
||||CK x|||**Taxa de resposta (%)**|**Taxa de**|
|**Mt t**|||3DCRT||SBRT x|RC: 4; RP: 67|**resposta**CK|
|**asuo e**<br>**al. 2016**<sup>**139**</sup>|CK|Taxa de SG em 1 ano: 56,7%|0,02|Progressão Local em 1 ano: 21,9%|3DCRT:<br>0,001|DE: 22; DP: 7|x 3DCRT<br>0,04|
||||TB x|||**Duração da Resposta**|TB x 3DCRT|  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**|**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
||||3DCRT<br>0,02|||Progressão local em 1 ano: 21,9%|0,04|
||TB|Taxa de SG em 1 ano: 38,1%||Progressão Local em 1 ano: 18,8%||**Taxa de resposta (%)**<br>RC: 0; RP: 62<br>DE: 19; DP: 19<br>**Duração da Resposta**<br>Progressão local em 1 ano: 18,8%||
|||||||**Taxa de resposta (%)**<br>RC: 6; RP: 41||
||3DCRT|Taxa de SG em 1 ano: 29,3%||Progressão Local em 1 ano: 43,6%||DE: 21; DP: 12<br>**Duração da Resposta**<br>Progressão local em 1 ano: 43,6%||
|**Oladeru et**|SBRT|Taxa de SG: 14 meses (IC<br>95%: 10–18)<br>Taxa de SDE: 14 meses (IC<br>95%: 12–20)|0,29|NR|NR|**Meses de sobrevida de pacientes que faleceram**<br>**pelo câncer**<br>Média (±DP): 12,79±11,15|072|
|**al. 2016**<sup>**140**</sup>|SIRT|SG: 12 meses (IC 95%: 9–<br>17)<br>SDE: 12 meses (IC 95%: 10–<br>22)|0,20|NR||**Meses de sobrevida de pacientes que faleceram**<br>**pelo câncer**<br>Média (±DP): 11,94±12,25|,|
|**Feng et al**|SBRT<br>(n: 78)|SG média: 2,04 anos||NR|NR|**Fatores associados com maior SG**<br>Mais jovens: HR=0,96|0,05|
|**.**<br>**2016**<sup>**141**</sup>|RFA<br>(n: 78)|SG média: 2,25 anos|0,06|NR||Ausência de descompensação do fígado: HR= 0,37<br>Tratamento do Oeste: HR= 0,57<br>Transplante no fígado: HR= 0,18|0,002<br>0,04<br>0,008|  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**|**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Wahl et al.**<br>**2016**<sup>**142**</sup>|SBRT<br>RFA|SG em 1 e 2 anos: 74,1% e<br>46,3%<br>SG em 1 e 2 anos: 69,6% e<br>52,9%|NR|SLP em 1 e 2 anos: 97,4% e<br>83,8%<br>SLP em 1 e 2 anos: 83,6% e<br>80,2%|NR|**Fatores associados com maior Progressão Local**<br>Tamanho do tumor (diâmetro>2cm): HR=1,35 (IC<br>95%: 0,99 – 1,84)|0,055|
|||||||**Duração da Resposta**<br>Recidiva local em 1 ano: 2,9%||
||SBRT|SC em 1 ano: 95,2%<br>Mortalidade:0|0,075|NR|NR|**Taxa de controle de recorrência distante intra-**||
|**Shiozawa,**<br>**2015**<sup>**143**</sup>||||||**hepático em 1 ano:**<br>86,1%|0,71<br>091|
||RFA|SC em 1 ano: 100%<br>Mortalidade: 2 (5,7%)||NR||**Duração da Resposta**<br>Recidiva local em 1 ano: 2,6%<br>**Taxa de controle de recorrência distante intra-**<br>**hepático em 1 ano:**<br>85,6%|,|
|||||||**Taxa de resposta (%)**<br>RC: 30,3%||
||SBRT|SG mediana: 33 meses|||NR|RP: 57,6%|NR|
|**Jacob et al.**<br>**2014**<sup>**144**</sup>||||0,02||DE: 9,1%<br>DP: 3,0%<br>**Taxa de resposta (%)**||
||TACE|SG mediana: 20 meses||||RC: 27,2<br>RP: 52,2<br>DE: 13,0|NR|  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**|**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||||DP: 7,6||
|**Honda et**<br>**al 2013**<sup>**145**</sup>|SBRT|SG mediana: NA*<br>Taxa de SG em 1 e 3 anos:<br>100%, 100%|0,469|SLP mediana: 15,2 meses<br>Taxa de SLP em 1, 2, 3 anos:<br>71,4%, 42%, 0%|<0,029|**Taxa de resposta de controle do tumor local, n/N**<br>**(%)**<br>RC: 29/30 (96,3%)<br>(Outros pacientes eram non-CR)|<0,001|
|**.**||SG mediana: 40,9 meses||SLP mediana: 4,2 meses||**Taxa de resposta de controle do tumor local, n/N**||
||TACE|Taxa de SG em 1; 2; 3 anos:||SLP em 1; 2; 3 anos: 24,8%;|NR|**(%)**||
|||88,9%; 73,6%; 66,1%||14,2%; 7%||RC: 1/30 (3,3%)||
|||Taxa de SG em 2 anos:||||**Taxa de resposta (%)**||
|||72,6% (p = 0,013 entre||||RC: 22,0%||
||SBRT|grupos)|-|NR|NR|RP: 36,6%|NR|
|**Huang et**||TTP: 8,6 meses (valor p não||||DE:39%||
|**al. 2012**<sup>**146**</sup>||relatado)||||DP: 2,4%||
|||Taxa de SG em 2 anos:||||||
||Outros|42,1%<br>TTP: 3,5 meses||NR||NR||  
Legenda: 3DCRT: radioterapia conformal três dimensões; <mark>DEBTACE: quimioembolização transarterial com</mark> _<mark>drug eluting beads;</mark>_ <mark>RFA: Ablação por Radiofreqüência; SABR: radioterapia estereotáxica ablativa; SBRT; radioterapia estereotáxica corpórea; SIRT: radioterapia interna seletiva</mark> _<mark>;</mark>_ <mark>TACE: quimioembolização transarterial; RH: ressecção hepática; CK: Cyberknife</mark><sup>**®**</sup> <mark>; TB: Truebeam</mark><sup>**®**</sup> ; SLP: Sobrevida livre de progressão; SG: Sobrevida global; <mark>SDE: sobrevida doença-específica; SC: sobrevida cumulativa; DE: doença estável; DP: doença progressiva</mark> ; RC: remissão completa; RG: resposta global: <mark>N: número de pacientes; H</mark> R: hazard ratio <mark>; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não relatado,</mark> IC: intervalo de confiança; DP: desvio-padrão; TTP: tempo até progressão; ECOG: _Eastern Cooperative Oncology Group._ *Nenhum paciente morreu no período considerado.  
**Tabela K** - Desfechos de segurança dos estudos que analisaram a radioterapia (estereotáxica) no carcinoma hepatocelular.  
|**Eventos**|**Su et**<br>**2017**|**al.**<br><sup>**137**</sup>|**Lu et al. 20**|**16**<sup>**138**</sup>||**Matsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl**<br>**201**|**et al.**<br>**6**<sup>**142**</sup>|**Shioz**<br>**2015**<sup>**1**</sup>|**awa,**<br><sup>**43**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huan**<br>**201**|**g et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**|<br>|<br>|<br>|
||**SBRT**|**RH**|**SBRT**|**Paliativo**|**CK**|**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|**TACE**|**TACE**|<br>**SBRT**|<br>**RFA**|
|Leucocitopenia|NR|NR|Total:9<br>(14,6)<br>Grau≥3: 3(4,7)|NR|Grau<br>2:7(26)<br>Grau<br>3:2(8)|Grau<br>2:7(44)<br>Grau<br>3:1(6)|Grau<br>2:18(33)<br>Grau<br>3:5(9)|NR|NR|NR|NR|NR|NR|Grau<br>1:20<br>Grau<br>2:8<br>Grau<br>3:2|Grau<br>1:30<br>Grau<br>2:8|NR|NR|
|Trombocitope-<br>nia|NR|NR|Total:27<br>(42,2)<br>Grau≥3: 3(4,7)|NR|Grau<br>2:7(26)<br>Grau<br>3:4(15)|Grau<br>2:7(44)<br>Grau<br>3:0|Grau<br>2:14(26)<br>Grau<br>3:3(6)|NR|NR|NR|NR|NR|NR|Grau<br>1:21<br>Grau<br>2:8<br>Grau<br>3:1|Grau<br>1:27<br>Grau<br>2:8<br>Grau<br>3:3|NR|LNR|
|||||||||||||||Grau|Grau|||
|Redução de<br>hemoglobina|NR|NR|Total:3<br>(4,7)<br>Grau≥3:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1:27<br>Grau<br>2:3|1:36<br>Grau<br>2:2|NR|NR|
|Hiperbilirrubi-<br>nemia|Grau<br>1:2|Grau<br>1:2|Total:33<br>(51,6)<br>Grau≥3: 3(4,7)|NR|Grau 2:<br>Grau 3:|Grau 2:<br>Grau 3:|Grau 2:<br>Grau 3:|NR|NR|NR|NR|NR|NR|Grau<br>1:27<br>Grau<br>2:3|Grau<br>1:34<br>Grau<br>2:2|NR|NR|  
|**Eventos**|**Su et**<br>**2017**|**al.**<br><sup>**137**</sup>|**Lu et al. 20**|**16**<sup>**138**</sup>||**Matsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl e**<br>**2016**|**t al.**<br><sup>**142**</sup>|**Shioz**<br>**2015**<sup>**1**</sup>|**awa,**<br><sup>**43**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huang**<br>**201**|**et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**||||
||**SBRT**|**RH**|**SBRT**|**Paliativo**|<br>**CK**|<br>**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|<br>**TACE**|<br>**TACE**|<br>**SBRT**|**RFA**|
||||||||||||||||Grau<br>3:2|||
|Elevação sérica<br>de transaminases|NR|NR|Total:39<br>(60,9)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|Grau<br>1:30|Grau<br>1:33<br>Grau<br>2:5|NR|NR|
|Elevação sérica|||<br>Grau≥3:8(12,5)|||||||||||Grau|Grau<br>1:34|||
|de fosfatase<br>alcalina|NR|NR||NR|NR|NR|NR||NR|NR|NR|NR|NR|1:30|<br>Grau<br>2:4|NR|NR|
||||Total: 2|||||||||||||||
|Creatinina|NR|NR|(3,1)<br>Grau≥3:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Aumento da<br>GGT|NR|NR|Total:39<br>(60,9)<br>Grau≥3:17(26,6)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
||Grau<br>1:2||Grau<br>1:11(17,19)|||||||||||||Grau||
|Náusea/vômito|Grau<br>2: 2|NR|Grau<br>2:15(23,44)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1:2<br>Grau|NR|
||Grau<br>3: 1||Grau 3:0<br>Grau 4:0|||||||||||||2:3||  
|**Eventos**|**Su e**<br>**201**|**t al.**<br>**7**<sup>**137**</sup>|**Lu et al. 20**|**16**<sup>**138**</sup>||**Matsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl**<br>**201**|**et al.**<br>**6**<sup>**142**</sup>|**Shioz**<br>**2015**|**awa,**<br><sup>**143**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huang**<br>**201**|**et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**||||
||**SBRT**|**RH**|**SBRT**|**Paliativo**|**CK**|**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|**TACE**|**TACE**|<br>**SBRT**|**RFA**|
||||Grau 1:8(12,5)|||||||||||||Grau||
|Anorexia|NR|NR|Grau 2:16(25)<br>Grau 3:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1:5<br>Grau|NR|
||||Grau 4:0|||||||||||||2:4||
||||Grau<br>1:12(18,75)|||||||||||||Grau<br>1:1||
|Dor abdominal|NR|NR|Grau 2:9(14,06)<br>Grau 3:2(3,13)<br>Grau 4:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|<br>Grau<br>2:1|NR|
|||||||||||||||||Grau||
|Úlcera gástrica|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2:1<br>Grau<br>3:1|NR|
||Grau||Grau 1:8(13)|||||||||||||Grau||
|Fadiga|1:1<br>Grau|Grau<br>1:2|Grau 2:5(8)<br>Grau 3:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1:12<br>Grau|NR|
||2:1||Grau 4:0|||||||||||||2:1||
|Desordens||||||||||||||||Grau<br>1:1<br>Grau||
|muscoesquelé-<br>ticas|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|<br>2:0<br>Grau<br>3:0|NR|  
|**Eventos**|**Su et**<br>**2017**|**al.**<br><sup>**137**</sup>|**Lu et al. 20**|**16**<sup>**138**</sup>||**Matsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl**<br>**201**|**et al.**<br>**6**<sup>**142**</sup>|**Shioz**<br>**2015**|**awa,**<br><sup>**143**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huang**<br>**201**|**et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**||||
||**SBRT**|**RH**|**SBRT**|**Paliativo**|**CK**|**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|**TACE**|**TACE**|<br>**SBRT**|**RFA**|
||||Grau 1:2(3,13)|||||||||||||||
|Constipação|NR|NR|Grau 2: (3,13)<br>Grau 3:0<br>Grau 4:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
||||Grau 1:0|||||||||||||||
|Pneumonia|NR|NR|Grau 2:2(3)<br>Grau 3:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
||||Grau 4:0|||||||||||||||
|Ascite|NR|NR|Grau 1:1(1,56)<br>Grau 2:0<br>Grau 3:0<br>Grau 4:0|NR|NR|NR|NR|1|NR|0|4<br>(11,4)|NR|NR|NR|NR|NR|NR|
||||Grau<br>1:11(17,19)|||||||||||||||
|Dermatite|NR|NR|Grau 2:5(7,81)<br>Grau 3:0<br>Grau 4:0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hipoalbumine-<br>mia|NR|NR|Total:13<br>(20,3)<br>Grau≥3:0|NR|Grau<br>2:9(33)<br>Grau<br>3:0|Grau<br>2:5(31)<br>Grau<br>3:1(6)|Grau<br>2:21(39)<br>Grau<br>3:1(6)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Índice<br>internacional|NR|NR|Total:11<br>(17,2)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
|**Eventos**|**Su e**<br>**201**|**t al.**<br>**7**<sup>**137**</sup>|**Lu et al. 2**|**016**<sup>**138**</sup>|**M**|**atsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl**<br>**2016**|**et al.**<br><sup>**142**</sup>|**Shioz**<br>**2015**|**awa,**<br><sup>**143**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huang**<br>**201**|**et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**||||
||**SBRT**|**RH**|**SBRT**|**Paliativo**|**CK**|**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|**TACE**|**TACE**|<br>**SBRT**|**RFA**|
|normalizado|||Grau≥3:0|||||||||||||||
|Alteração de<br>enzimas<br>hepáticas|NR|NR|NR|NR|Grau<br>2:2(8)<br>Grau<br>3:1(4)|0|Grau<br>2:5(9)<br>Grau<br>3:1(2)|1|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Aumento do<br>escore Child-<br>Pugh|Grau<br>1:3<br>Grau<br>2:1|Grau<br>1:2<br>Grau<br>2:1|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|||Grau<br>1:5||||||||||||||||
|Dor hepática|NR|Grau<br>2:3|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|||Grau<br>3:2||||||||||||||||
|||Grau<br>1:4||||||||||||||||
|Hemorragia<br>hepática|NR|Grau<br>2:3<br>Grau<br>3:4|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Perda de peso|Grau<br>1:1|Grau<br>1:3|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
|**Eventos**|**Su e**<br>**201**|**t al.**<br>**7**<sup>**137**</sup>|**Lu et al.**|**2016**<sup>**138**</sup>||**Matsuo et**<br>**2016**<sup>**139**</sup>|**al.**|**Wahl**<br>**201**|**et al.**<br>**6**<sup>**142**</sup>|**Shioz**<br>**2015**|**awa,**<br><sup>**143**</sup>******|**Jacob**<br>**2014**|**et al.**<br><sup>**144**</sup>|**Hond**<br>**201**|**a et al.**<br>**3**<sup>**145**</sup>|**Huang**<br>**201**|**et al.**<br>**2**<sup>**146**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||**SBRT**|**SBRT**||||||||**SBRT+**||||
||**SBRT**|**RH**|**SBRT**|**Paliativo**|**CK**|**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**|**RFA**|**TACE**|**TACE**|<br>**SBRT**|**RFA**|
||Grau<br>3:1|Grau<br>2:4<br>Grau<br>3:2||||||||||||||||
|Elevação da<br>alanina<br>aminotransfe-|Grau<br>1:1|Grau<br>1:2|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|rase||||||||||||||||||
|Anemia|Grau<br>1:2|Grau<br>1:2|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Pneumotórax|NR|NR|NR|NR|NR|NR|NR|NR|1|NR|NR|NR|NR|NR|NR|NR|NR|
|Hemorragia<br>Gastrointestinal|NR|NR|NR|NR|NR|NR|NR|1|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Sepse|NR|NR|NR|NR|NR|NR|NR|NR|2|NR|NR|NR|NR|NR|NR|NR|NR|
|Perfuração<br>intestinal|NR|NR|NR|NR|NR|NR|NR|NR|2|NR|NR|NR|NR|NR|NR|NR|NR|
|Hemorragia|NR|NR|NR|NR|NR|NR|NR|NR|3|NR|NR|NR|NR|NR|NR|NR|NR|
|Óbito|NR|NR|NR|NR|NR|NR|NR|0|2|NR|NR|NR|NR|NR|NR|NR|NR|
|||||||||||||Grau||||||
|Toxicidade<br>gastrointestinal|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2: 1<br>Grau<br>3:1|NR|NR|NR|NR|NR|
|Toxicidade|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|Grau|NR|NR|NR|NR|NR|  
||**Su et**|**al.**|**L et al**|**2016**<sup>**138**</sup>||**Matsuo et**|**al.**|**Wahl**|**et al.**|**Shioz**|**awa,**|**Jacob et al.**|**Honda et al.**|**Huang**|**et al.**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**|**2017**|<sup>**137**</sup>|**u  .**|||**2016**<sup>**139**</sup>||**201**|**6**<sup>**142**</sup>|**2015**<sup>**1**</sup>|<sup>**43**</sup>******|**2014**<sup>**144**</sup>|**2013**<sup>**145**</sup>|**201**|**2**<sup>**146**</sup>|
|**Adversos**|**SBRT**|**RH**|**SBRT**|**Paliativo**|**SBRT**<br>**CK**|**SBRT**<br>**TB**|**3DRCT**|**SBRT**|**RFA**|**SBRT**|**RFA**|**SBRT**<br>**RFA**|**SBRT+**<br>**TACE**<br>**TACE**|<br>**SBRT**|**RFA**|
|hematológica||||||||||||≥2: 0||||
|Dor em costelas|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1***<br>NR|NR<br>NR|NR|NR|  
<mark>Legenda: NR: não relatado, Dados foram apresentados em n/N (%), GGT: g</mark> ama glutamil transpeptidase. 3DCRT: radioterapia conformal três dimensões; <mark>DEBTACE: quimioembolização transarterial com</mark> _<mark>drug eluting beads;</mark>_ <mark>RFA: Ablação</mark>  
<mark>por Radiofreqüência; SABR: radioterapia estereotáxica ablativa; SBRT; radioterapia estereotáxica corpórea; SIRT: radioterapia interna seletiva</mark> _<mark>;</mark>_ <mark>TACE: quimioembolização transarterial; RH: ressecção hepática; CK: Cyberknife</mark> **<mark>®</mark>** <mark>; TB: Truebeam</mark> **®** .  
<mark>*Os eventos adversos relatados no estudo de Wahl et al são de grau ≥3.</mark>  
<mark>**O grau dos eventos adversos no estudo de Shiozawa e colaboradores não foi informado.</mark>  
<mark>***Grau não informado.</mark>  
**Questão de Pesquisa 4:** Qual a eficácia, segurança e dosagem do sorafenibe para o carcinoma hepatocelular?

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1. Estratégia de busca** -->
MEDLINE via Pubmed: (((((((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND (("sorafenib"[Supplementary Concept] OR Nexavar)))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh]))))  
Total: 399 referências  
<mark>Data do acesso: 10/08/2017</mark>  
EMBASE: (('aged'/exp OR 'aged' OR 'adult'/exp OR 'adult' OR 'middle aged'/exp OR 'middle aged' OR 'young adult'/exp OR 'young adult') AND [embase]/lim) AND ((('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim) AND (('sorafenib'/exp OR 'sorafenib' OR 'nexavar'/exp OR 'nexavar') AND [embase]/lim))  
Total: 208 referências  
<mark>Data do acesso: 11/08/2017</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2. Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 607 referências (399 no MEDLINE e 208 no EMBASE). Destas, 98 foram excluídas por estarem duplicadas. Ao todo, 509 referências foram triadas por meio da leitura de título e resumos, <mark>das quais 68 tiveram seus textos completos avaliados para confirmação da elegibilidade.</mark>  
<mark>Os critérios de inclusão priorizaram estudos com maior rigor metodológico (revisões sistemáticas atuais, com metaanálise direta ou indireta de resultados de ensaios clínicos randomizados, e estudos originais de ensaios clínicos randomizados) que compararam a eficácia e segurança do sorafenibe com outro tratamento quimioterápico ou placebo em pacientes diagnosticados com carcinoma hepatocelular.</mark>  
<mark>Foram identificadas 24 revisões sistemáticas com meta-análise de ensaios clínicos, das quais 21 foram excluídas: dez por haver uma revisão sistemática com meta-análise mais atual e que incluiu mais estudos, sobre a mesma gravidade da doença; cinco por não incluírem comparação da eficácia e segurança do sorafenibe; três por não incluírem resultados estratificados para carcinoma hepatocelular; um por não reportar resultados quantitativos (a meta-análise estava planejada pelo protocolo mas não foi conduzida); uma por conduzir meta-análise de participantes de estudos selecionados por conveniência (não houve revisão sistemática); e um estudo por não reportar desfechos de eficácia ou segurança. Foram identificados 44 ensaios clínicos comparativos, dos quais 42 foram excluídos: 18 por já estarem incluídos em uma das revisões sistemáticas com meta-análise incluídas neste anexo; dez por apresentarem número de amostra limitado (geralmente fase I ou fase II); cinco por não reportarem desfechos de interesse; quatro por não incluírem comparação da eficácia e segurança do sorafenibe; quatro por se tratarem de análises interinas de um mesmo estudo já incluído neste anexo; e um estudo por não estar na língua inglesa, portuguesa ou espanhola.</mark>  
<mark>Ao todo, foram incluídas três revisões sistemáticas com meta-análise de ensaios clínicos randomizados</mark><sup>147-149</sup> <mark>, abrangendo todo o espectro de gravidade da doença (leve, moderado, irressecável e grave), e um ensaio clínico randomizado</mark><sup>150</sup> <mark>que não foi incluído nas revisões sistemáticas com meta-análise.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3. Descrição dos Estudos e seus Resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela L** . As características dos participantes encontram-se descritas na **Tabela M** . Os resultados de eficácia encontram-se descritos na **Tabela N** . Os resultados de segurança (eventos adversos) das revisões sistemáticas com meta-análise e dos ensaios clínicos randomizados encontram-se descritos nas **Tabelas O** e **P** , respectivamente.  
**Tabela L** – Características dos estudos.  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**Número de ECRs e**<br>**participantes incluídos**|**Detalhes da intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Niu et al. 2016**<sup>**147**</sup>|Revisão sistemática com<br>meta-análise de<br>comparações diretas e<br>indiretas (busca até<br>setembro/2016)|Avaliar a eficácia de 7<br>tipos de terapias alvo para<br>prover evidência para<br>escolhas racionais no<br>tratamento do CHC<br>avançado|11 ECRs; total de 6594<br>participantes<br>n=2526 com sorafenibe;<br>n=1619 com placebo|**Grupo SORA:**<br>sorafenibe (7 ECRs)|**Grupo PLAC:**<br>Placebo (8 ECRs)|Baixo risco de viés|
|**Zeng et al. 2016**<sup>**149**</sup>|Revisão sistemática com<br>meta-análise de<br>comparações diretas<br>(busca até janeiro/2016)|Avaliar a eficácia do<br>tratamento com TACE +<br>sorafenibe versus TACE<br>isolado para CHC<br>intermediário ou precoce|4 ECRs; total de 877<br>participantes (variação de<br>50 – 458)|**Grupo TACE+SORA:**<br>quimioembolização<br>transarterial + sorafenibe<br>400 mg 2x/dia (4 ECRs)|**Grupo TACE:**<br>quimioembolização<br>transarterial + placebo (4<br>ECRs)|Baixo risco de viés|
|**Peng et al. 2014**<sup>**148**</sup>|Revisão sistemática com<br>meta-análise de<br>comparações diretas<br>(busca até março/2014)|Identificar se as<br>características basais dos<br>pacientes têm efeito na<br>eficácia e segurança do<br>tratamento com<br>sorafenibe para CHC<br>avançado|7 ECRs;<br>Total de 3807<br>participantes (variação de<br>52 – 1155)|**Grupo SORA:**<br>sorafenibe 400 mg 2x/dia<br>(7 ECRs)|**Grupo PLAC:**<br>Placebo (4 ECRs),<br>**Grupo SUNI:**<br>sunitinibe (1 ECR),<br>**Grupo BRIV:**<br>brivanibe (1 ECR),<br>**Grupo CAPE:**<br>capecitabina (1 ECR)|Baixo risco de viés|
|**Bruix et al.**<br>**2015**<sup>**150**</sup>|ECR, duplo-cego,<br>controlado por placebo,|Avaliar a eficácia e<br>segurança do sorafenibe|Total de 1114<br>participantes|**Grupo SORA:**<br>sorafenibe 400 mg 2x/dia|**Grupo PLAC:**<br>Placebo (n=558)|Baixo risco de viés|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**Número de ECRs e**<br>**participantes incluídos**|**Detalhes da intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||multicêntrico (202|comparado ao placebo||(n=556)|||
||centros)|como adjuvante em|||||
|||pacientes com CHC após|||||
|||tratamento curativo por|||||
|||ressecção ou ablação|||||  
Legenda: ECR: ensaio clínico randomizado; CHC: carcinoma hepatocelular; TACE: _trans arterial chemoembolization_ ; SORA: sorafenibe; PLAC: placebo; SUNI: sunitinibe; BRIV: brivanibe; CAPE: capecitabina; NR: não relatado.  
**Tabela M** - Características dos pacientes.  
|**Autor,**<br>**ano**|**Idade (anos)**<br>**(min –**|**, mediana**<br>**max)**|**Sexo mascul**|**ino, n (%)**|**BCL**|**C**|**Child-Pug**|**h, n (%)**|**Duração do**|**tratamento**|**Tempo**<br>**de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**(meses)**|
|**Niu et**<br>**al**|**SORA:**|**PLAC:**|**SORA:**|**PLAC:**|||||||Variação:|
|**.**<br>**2016**<sup>**14**</sup>|Variação:|Variação:|Variação:|Variação:|NR|NR|NR|NR|NR|NR|17 – 32|
|**7**|51 - 61|52 – 66,3|127 – 523|66 – 483|||||||Meses|
|**Zeng**<br>**et al**|**TACE+SOR**<br>**A:**|**TACE:**|**TACE+SOR**<br>**A:**|**TACE:**|**TACE+SOR**<br>**A:**|**TACE:**|**TACE+SOR**|**TACE:**||||
|**.**<br>**2016**<sup>**14**</sup>|Variação:|Variação:|Variação:|Variação:|Não mais que|Não mais|**A:**|97% classe|NR|NR|NR|
|**9**|<br>58,5 – 73,0|58,0 – 72,8|<br>58% – 90%|61% – 90%|<br>B|que B|97% classe A|A||||
|||||||**PLAC:**||**PLAC:**||||
|||||||Variação:||Variação:||||
|||**PLAC:**||**PLAC:**||B: 4% –||B: 62% –||||
|||Variação:||||17%||98%||||
|**Peng**<br>**t l**|**SORA:**|52 – 69<br>**SUNI:**<br>59 (18 – 85)|**SORA:**|Variação:<br>51% – 87%<br>**SUNI:**|**SORA:**<br>Variação:|C: 50% –<br>96%<br>**SUNI**|**SORA:**<br>Variação:|C: 1% – 4%<br>**SUNI:**<br>NR||||
|**e a.**<br>**2014**<sup>**14**</sup>|Variação:|<br>**BRIV:**|Variação:|436 (82%)|B: 5% – 18%|**:**<br>B: 67|A: 31% –|<br>**BRIV:**|NR|NR|NR|
|**8**|51 – 66|61 (19 – 87)<br>**CAPE:**|59 –  87%|**BRIV:**<br>183 (84%)<br>**CAPE:**|C: 52% –<br>95%|<br>(13%);<br>C: 462|100%<br>B: 0% – 31%|A: 531<br>(92%);||||
|||59,5 (42 –||||(87%)||B: 46 (8%)||||
|||70)||NR||**BRIV:**||**CAPE:**||||
|||||||B: 95||A: 4 (15%);||||
|||||||(16%);||B: 22||||  
|**Autor,**<br>**ano**|**Idade (anos**<br>**(min –**<br>|**), mediana**<br>**max)**<br>|**Sexo mascu**<br>|**lino, n (%)**<br>|**BC**<br>|**LC**<br>|**Child-Pu**<br>|**gh, n (%)**<br>|**Duração do**<br>|**tratamento**<br>|**Tempo**<br>**de**<br>**seguimento**<br>**(meses)**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**|**Intervenção**|**Comparador**||
|||||||C: 444<br>(77%)||(85%)||||
|||||||**CAPE:**||||||
|||||||NR||||||
|||||||||**PLAC:**||||
||||||||**SORA:**|5: 432||||
|**Bruix**<br>**et al.**<br>**2015**<sup>**15**</sup><br>**0**|**SORA:**<br>58 (24 – 85)|**PLAC:**<br>60 (19 – 83)|**SORA:**<br>451 (81%)|**PLAC:**<br>461 (83%)|NR|NR|5: 429<br>(77%)<br>6: 112<br>(20%)<br>7: 15 (3%)|(77%)<br>6: 106<br>(19%)<br>7: 16<br>(3%)|NR|NR|**SORA:**<br>8,5 meses<br>**PLAC:**8,4<br>meses|
||||||||8: 0|8: 4<br>(<1%)||||  
Legenda: BCLC: _Barcelona Clinic Liver Cancer_ ; SORA: sorafenibe; PLAC: placebo; TACE: _Transarterial chemoembolization_ ; SUNI: sunitinibe; BRIV: brivanibe; CAPE: capecitabina; min: valor mínimo; max: valor máximo; NR: não relatado.  
**Tabela N** – Desfechos de eficácia.  
|**Autor, ano**|**Sobrevida global**|**Sobrevida livre de progressão,**<br>**mediana**|**Tempo até progressão**|**Outros desfechos**|
|---|---|---|---|---|
|**Niu et al. 2016**<sup>**147**</sup>|**Meta-análise tradicional (Sorafenibe**<br>**vs. placebo):**<br>**HR:**0,69 (IC95% 0,60; 0,79), p<0,05<br>**Meta-análise em rede:**<br>**Sorafenibe vs. placebo**<br>**HR:**0,70 (IC95% 0,58; 0,84), p<0,05<br>**Sorafenibe vs. ramucirumabe**<br>**HR:**0,80 (IC95% 0,55; 1,20), NS<br>**Sorafenibe vs. everolimus**<br>**HR:**0,66 (IC95% 0,46; 0,96), NS<br>**Sorafenibe vs. brivanibe**<br>**HR:**0,90 (IC95% 0,70; 1,10), NS<br>**Sorafenibe vs. tivantinibe**<br>**HR:**0,77 (IC95% 0,45; 1,30), NS<br>**Sorafenibe vs. sunitinibe**<br>**HR:**0,77 (IC95% 0,58; 1,03), NS|NR|NR|**Resposta parcial:**<br>**Meta-análise em rede:**<br>**Sorafenibe vs. placebo**<br>**OR:**4,82 (IC95% 1,37; 15,91), p<0,05<br>**Sorafenibe vs. ramucirumabe**<br>**OR:**0,39 (IC95% 0,02; 4,76), NS<br>**Sorafenibe vs. everolimus**<br>**OR:**3,21 (IC95% 0,21; 38,12), NS<br>**Sorafenibe vs. brivanibe**<br>**OR:**1,21 (IC95% 0,22; 4,22), NS<br>**Sorafenibe vs. tivantinibe**<br>**OR:**10,51 (IC95% 0,13; 955,23), NS<br>**Sorafenibe vs. sunitinibe**<br>**OR:**0,94 (IC95% 0,13; 6,52), NS<br>**Taxa de resposta global:**<br>**Meta-análise em rede:**<br>**Sorafenibe vs. placebo**<br>**OR:**5,23 (IC95% 1,60; 18,73), p<0,05<br>**Sorafenibe vs. ramucirumabe**<br>**OR:**0,38 (IC95% 0,02; 5,05), NS<br>**Sorafenibe vs. everolimus**<br>**OR:**3,30 (IC95% 0,26; 43,89), NS<br>**Sorafenibe vs. brivanibe**<br>**OR:**1,21 (IC95% 0,21; 4,50), NS<br>**Sorafenibe vs. tivantinibe**<br>**OR:**10,07 (IC95% 0,12; 624,50), NS<br>**Sorafenibe vs. sunitinibe**<br>**OR:**0,88 (IC95% 0,14; 6,32), NS|
|||||**Taxa de resposta objetiva,**(resposta<br>|
|**Zeng et al.**<br>**2016**<sup>**149**</sup>|**HR:**0,97 (IC95% 0,72; 1,29),<br>p=0,828, 2 ECRs, I<sup>2</sup>=0%|NR|**HR:**0,77 (IC95% 0,64; 0,92),<br>p=0,005, 4 ECRs, I<sup>2</sup>=11%|completa + resposta parcial) baseada<br>no RECIST:<br>**RR:**1,20 (IC95% 0,88; 1,64),<br>p=0,257, 2 ECRs, I<sup>2</sup>=0%|

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Sobrevida livre de progressão,** -->
**Autor, ano Sobrevida global Tempo até progressão mediana**  
**Outros desfechos**  
**Taxa de controle da doença,** (resposta completa + resposta parcial + doença estável) baseada no RECIST: **RR:** 1,04 (IC95% 0,90; 1,02), 2 ECRs, I<sup>2</sup> =2,7%  
**HR:** 0,74 (IC95% 0,61; 0,90), p=0,002, 7 ECRs, I<sup>2</sup> =77% **Análises de subgrupos: HR:** 0,69 (IC95% 0,55; 0,86), **HBV positivo:** p=0,001, 6 ECRs, I<sup>2</sup> =84,4% **HR:** 0,91 (IC95% 0,76; 1,08), p=0,267 **HBV negativo: Análises de subgrupos: HR:** 0,86 (IC95% 0,44; 1,78), p=0,732 **HBV positivo: HCV positivo HR:** 0,74 (IC95% 0,48; 1,14), p=0,174 **HR:** 0,83 (IC95% 0,32; 2,15), p=0,695 **ECOG 0: ECOG 0: HR:** 0,64 (IC95% 0,35; 1,18), **Taxa de resposta global: Peng et al. HR:** 0,81 (IC95% 0,59; 1,11), p=0,193 p=<0,001 NR **HR:** 0,85 (IC95% 0,65; 1,11), p=0,105 **2014**<sup>**148**</sup> **ECOG 1-2: ECOG 1-2:** ECRs **HR:** 0,77 (IC95% 0,6; 1), p=0,05 **HR:** 0,58 (IC95% 0,44; 0,75), p<0,001 **Invasão vascular macroscópica ou Invasão vascular macroscópica ou extrahepática presente: extrahepática presente: HR:** 0,65 (IC95% 0,46; 0,93), p=0,016 **HR:** 0,44 (IC95% 0,28; 0,69), p<0,001 **Invasão vascular macroscópica ou Invasão vascular macroscópica ou extrahepática ausente: extrahepática ausente: HR:** 0,69 (IC95% 0,46; 1,05), p=0,085 **HR:** 0,62 (IC95% 0,5; 0,77), p<0,001 **Alfa-fetoproteína normal: HR:** 0,9 (IC95% 0,48; 1,71), p=0,757 **Alfa-fetoproteína elevada: HR:** 0,84 (IC95% 0,54; 1,32), p=0,449 **Sobrevida livre de recorrência: Sorafenibe:** não alcançado em 4 anos **Sorafenibe:** 33,3 meses (IC95% 27,6; **Bruix et al, Placebo:** não alcançado em 4 anos NR NR 44,0) **2015**<sup>**150**</sup> **HR:** 0,995 (IC95% 0,761; 1,300), **Placebo:** 33,7 meses (IC95% 27,6; p=0,48 39,0)  
|**Autor, ano**|**Sobrevida global**|**Sobrevida livre de progressão,**<br>**mediana**|**Tempo até progressão**|**Outros desfechos**|
|---|---|---|---|---|
|||||**HR:**0,940 (IC95% 0,780; 1,134),<br>p=0,26|
|||||**Tempo até a recorrência:**<br>**Sorafenibe:**38,5 meses (IC95% 30,4;<br>não estimável)<br>**Placebo:**35,8 meses (IC95% 30,3;<br>41,4)<br>**HR:**0,891 (IC95% 0,735; 1,081),<br>p=0,12|  
Legenda: RECIST: _response evaluation criteria in solid tumors_ ; HBV: vírus da hepatite B; HCV: vírus da hepatite C; ECOG: escala de desempenho da _Eastern Cooperative Oncology Group_ ; TACE: _Transarterial chemoembolization_ ; SUNI: sunitinibe; BRIV: brivanibe; CAPE: capecitabina; LINI: linifanibe; ECR: ensaio clínico randomizado; HR: _hazard ratio_ ; IC95%: intervalo de confiança de 95%; OR: _odds ratio;_ NR: não relatado; NS: não significante.  
**Tabela O** – Eventos adversos relatados nas revisões sistemáticas com meta-análise.  
|**Evento adverso**|**Zeng et al, 2016**<sup>**149**</sup>|**Peng et al, 2014**<sup>**148**</sup>|
|---|---|---|
||**Grupo TACE+SORA versus Grupo TACE**|**Grupo SORA versus Grupos PLAC, SUNI e BRIV**|
|Redução de dose|**RR:**2,95 (IC95% 0,68; 12,76), p=0,148|NR|
|Interrupção do tratamento|**RR:**4,09 (IC95% 1,22; 13,72), p=0,022|NR|
||**RR:**9,60 (IC95% 6,64; 13,89), 4 ECRs, I<sup>2</sup>=0%;||
|Eritrodisestesia palmo-plantar|Somente grau 3 e 4:<br>**RR:**18,95 (IC95% 1,71; 210,12), p=0,017|**RR:**5,4 (IC95% 1,8; 16,2), p=0,003|
|Erupção cutânea|**RR:**3,64 (IC95% 2,59; 5,12), 3 ECRs, I<sup>2</sup>=0%;<br>Somente grau 3 e 4:<br>**RR:**11,55 (IC95% 2,19; 60,89), p=0,004|**RR:**3,21 (IC95% 1,65; 6,26), p=0,001|
||**RR:**3,54 (IC95% 2,05; 6,14), 4 ECRs, I<sup>2</sup>=52,4%;||
|Diarreia|Somente grau 3 e 4:<br>**RR:**5,96 (IC95% 1,93; 18,40), p=0,002|**RR:**1,45 (IC95% 1,21; 2,34), p=0,003|
|Náusea|NR|**RR:**0,73 (IC95% 0,22; 2,38), p=0,595|
|Vômito|NR|**RR:**0,57 (IC95% 0,19; 1,68), p=0,308|
|Fadiga|**RR:**1,34 (IC95% 1,02; 1,76), 3 ECRs, I<sup>2</sup>=0%;|**RR:**1,7 (IC95% 1,3; 2,23), p=0|
|Hipertensão|**RR:**2,46 (IC95% 1,20; 5,04), 3 ECRs, I<sup>2</sup>=74,5%;|**RR:**0,67 (IC95% 0,32; 1,42), p=0,299|
|Neutropenia|NR|**RR:**0,28 (IC95% 0,02; 3,6), p=0,328|  
|**Evento adverso**|**Zeng et al, 2016**<sup>**149**</sup>|**Peng et al, 2014**<sup>**148**</sup>|
|---|---|---|
||**Grupo TACE+SORA versus Grupo TACE**|**Grupo SORA versus Grupos PLAC, SUNI e BRIV**|
|Leucopenia|NR|**RR:**0,82 (IC95% 0,004; 164,09), p=0,942|
|Óbito|0 vs. 0|NR|  
Legenda: PLAC: placebo; TACE: _Transarterial chemoembolization_ ; SUNI: sunitinibe; BRIV: brivanibe; ECR; ensaio clínico não randomizado; RR: risco relativo; NR: não relatado.  
**Tabela P** – Eventos adversos relatados no ensaio clínico randomizado.  
|**Evento adverso**|**Bruix et a**|**l. 2015**<sup>**150**</sup>|
|---|---|---|
||**Grupo SORA**|**Grupo PLAC**|
|Qualquer evento adverso|todos os graus: 526 (94%); grau 3: 280 (50%); grau 4: 13 (2%)|todos os graus: 254 (46%); grau 3: 48 (9%); grau 4: 3 (<1%)|
|Fadiga|todos os graus: 73 (13%); grau 3: 8 (1%); grau 4: 1 (<1%)|todos os graus: 40 (7%); grau 3: 2 (<1%); grau 4: 0 (0%)|
|Perda de peso|todos os graus: 41 (7%); grau 3: 5 (<1%); grau 4: NR|todos os graus: 2 (<1%); grau 3: 0 (0%); grau 4: NR|
|Ganho de peso|todos os graus: 1 (<1%); grau 3: 0 (0%); grau 4: NR|todos os graus: 1 (<1%); grau 3: 0 (0%); grau 4: NR|
|Redução de apetite|todos os graus: 33 (6%); grau 3: 2 (<1%); grau 4: 0 (0%)|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Artralgia|todos os graus: 10 (2%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Dor nas costas|todos os graus: 9 (2%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 1 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Cefaleia|todos os graus: 22 (4%); grau 3: 1 (<1%); grau 4: 0 (0%)|todos os graus: 10 (2%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Febre|todos os graus: 8 (1%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Insônia|todos os graus: 5 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 6 (1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Alopecia|todos os graus: 179 (32%); grau 3: NR; grau 4: NR|todos os graus: 17 (3%); grau 3: NR; grau 4: NR|
|Eritrodisestesia palmo-plantar|todos os graus: 389 (70%); grau 3: 154 (28%); grau 4: NR|todos os graus: 28 (5%); grau 3: 4 (<1%); grau 4: NR|
|Erupção cutânea|todos os graus: 91 (16%); grau 3: 15 (3%); grau 4: 1 (<1%)|todos os graus: 27 (5%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Prurido|todos os graus: 43 (8%); grau 3: 3 (<1%); grau 4: NR|todos os graus: 33 (6%); grau 3: 1 (<1%); grau 4: NR|
|Diarreia|todos os graus: 215 (38%); grau 3: 34 (6%); grau 4: 0 (0%)|todos os graus: 40 (7%); grau 3: 2 (<1%); grau 4: 0 (0%)|
|Nausea|todos os graus: 34 (6%); grau 3: 1 (<1%); grau 4: 0 (0%)|todos os graus: 8 (1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Dor abdominal|todos os graus: 29 (5%); grau 3: 6 (1%); grau 4: NR|todos os graus: 12 (2%); grau 3: 0 (0%); grau 4: NR|  
|**Evento adverso**|**Bruix et**|**al. 2015**<sup>**150**</sup>|
|---|---|---|
||**Grupo SORA**|**Grupo PLAC**|
|Constipação|todos os graus: 14 (3%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 8 (1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Ascite|todos os graus: 6 (1%); grau 3: 1 (<1%); grau 4: 0 (0%)|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Dispepsia|todos os graus: 10 (2%); grau 3: 1 (<1%); grau 4: NR|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: NR|
|Hipertensão|todos os graus: 108 (19%); grau 3: 24 (4%); grau 4: 0 (0%)|todos os graus: 35 (6%); grau 3: 6 (1%); grau 4: 0 (0%)|
|Plaquetopenia|todos os graus: 32 (6%); grau 3: 8 (1%); grau 4: 1 (<1%)|todos os graus: 13 (2%); grau 3: 1 (<1%); grau 4: 0 (0%)|
|Aumento de ALT|todos os graus: 28 (5%); grau 3: 11 (2%); grau 4: 1 (<1%)|todos os graus: 15 (3%); grau 3: 5 (<1%); grau 4: 0 (0%)|
|Aumento de AST|todos os graus: 25 (5%); grau 3: 10 (2%); grau 4: 2 (<1%)|todos os graus: 13 (2%); grau 3: 6 (1%); grau 4: 0 (0%)|
|Disfonia|todos os graus: 32 (6%); grau 3: 1 (<1%); grau 4: 0 (0%)|todos os graus: 1 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Tosse|todos os graus: 6 (1%); grau 3: 2 (<1%); grau 4: NR|todos os graus: 2 (<1%); grau 3: 0 (0%); grau 4: NR|
|Nasofaringite|todos os graus: 3 (<1%); grau 3: 0 (0%); grau 4: 0 (0%)|todos os graus: 0 (0%); grau 3: 0 (0%); grau 4: 0 (0%)|
|Reações grau 5|Insuficiência renal (n=1), doença renal (n=1), hemorragia cerebral<br>(n=1), peritonite (n=1), disfunção ou insuficiência hepática (n=4),<br>falência múltipla de órgãos (n=3), afogamento (n=1), infarto do<br>miocárdio (n=1), bloqueio atrioventricular (n=1)|Embolia periférica (n=1), hemorragia cerebral (n=1), neoplasias (n=3),<br>infecção por vírus da hepatite B (n=2), óbito (n=1), isquemia<br>miocárdica (n=1)|  
Legenda: PLAC: placebo; TACE: _Transarterial chemoembolization_ ; LINI: linifanibe; NR: não relatado. Resultados expressos em frequência: n (%).  
**<mark>Questão de Pesquisa 5:</mark>** <mark>Qual a eficácia das quimioterapias sistêmicas no carcinoma hepatocelular?</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1.** **<mark>Estratégia de busca</mark>** -->
MEDLINE via Pubmed: <mark>(((((((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND ("Chemotherapy, Adjuvant"[Mesh] OR "Maintenance Chemotherapy"[Mesh] OR "Induction Chemotherapy"[Mesh] OR "Consolidation Chemotherapy"[Mesh] OR "Antineoplastic Agents"[Mesh] OR chemotherapy))) AND ((("safety"[MeSH Terms] OR safety[Text Word] OR efficacy OR effect OR effects OR effectiveness)))) AND (("Aged"[Mesh] OR "Middle Aged"[Mesh] OR "Adult"[Mesh] OR "Young Adult"[Mesh])))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))</mark>  
<mark>Total: 693</mark>  
<mark>Data de acesso: 10/08/2017</mark>  
<mark>EMBASE: (('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('aged'/exp OR 'aged' OR 'adult'/exp OR 'adult' OR 'middle aged'/exp OR 'middle aged' OR 'young adult'/exp OR 'young adult') AND [embase]/lim) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim) AND (('chemotherapy' OR 'maintenance chemotherapy'/exp OR 'maintenance chemotherapy' OR 'induction chemotherapy'/exp OR 'induction chemotherapy' OR 'consolidation chemotherapy'/exp OR 'consolidation chemotherapy' OR 'antineoplastic agent'/exp OR 'antineoplastic agent' OR 'chemotherapy'/exp OR chemotherapy) AND [embase]/lim) AND (('adverse drug reaction'/exp OR 'adverse drug reaction' OR 'safety'/exp OR 'safety' OR 'efficacy parameters'/exp OR 'efficacy parameters' OR 'efficacy'/exp OR 'efficacy' OR 'drug efficacy'/exp OR 'drug efficacy' OR 'effectiveness' OR 'effect' OR 'effects') AND [embase]/lim)</mark>  
<mark>Total: 657</mark>  
<mark>Data de acesso: 11/08/2017</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2.** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 1350 referências (693 no MEDLINE e 657 no Embase). Destas, 230 foram excluídas por estarem duplicadas.</mark>  
<mark>Devido ao volume de referências encontradas, foram considerados apenas revisões sistemáticas de ensaios clínicos randomizados e estudos de intervenção ensaios clínicos randomizados fase III. Estudos observacionais, prospectivos ou retrospectivos foram excluídos. Foram triadas 1120 referências por meio da leitura de título e resumos, das quais 407 foram excluídas devido ao tipo de estudo (não randomizados, fase I ou II, relatos de caso, coorte, resumo de congresso), 380 pelo tipo de intervenção (terapias locorregionais, medicamentos não aprovados na ANVISA) e 194 pelo tipo de participante (não possuíam CHC ou estudo contendo participantes com outros tipos de câncer, sem estratificar os grupos). Desta forma, 139 artigos tiveram seus textos completos avaliados para confirmação da elegibilidade, dos quais 33 foram excluídos devido ao desenho do estudo, 12 foram excluídos devido ao fato de utilizarem outras intervenções, 10 não foram recuperados e cinco devido ao tipo de participante. Das 79 referências restantes, 35 correspondiam a ensaios clínicos randomizados incluídos em revisões sistemáticas ou à subanálise de estudo principal e foram excluídos.</mark>  
<mark>Assim, 44 estudos foram incluídos</mark><sup>151-194</sup> <mark>a partir da busca eletrônica da literatura nas bases de dados, e duas revisões sistemáticas provenientes de busca manual foram adicionadas</mark><sup>195, 196</sup> <mark>, totalizando 46 estudos</mark><sup>130, 136, 151-160, 162-191, 193-196</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A apresentação dos resultados foi organizada segundo a classe de medicamentos e comparações. Dentre o grupo dos agentes antineoplásicos e imunomoduladores, os agentes antineoplásicos corresponderam ao maior subgrupo de medicamentos avaliados, incluindo terapias citotóxicas, antimetabóltitos, e outros agentes antineoplásicos, como os anticorpos monoclonais, os inibidores da proteína quinase e os compostos de platina. Seis estudos avaliaram terapias citotóxicas contendo doxurrubicina</mark><sup>151-155</sup> <mark>e epirubicina</mark><sup>156</sup> <mark>, em comparação com outros esquemas quimioterápicos, placebo ou cuidados paliativos. A descrição sumária das terapias citotóxicas encontra-se na</mark> **<mark>Tabela Q</mark>** <mark>. As características dos pacientes encontram-se descritas na</mark> **<mark>Tabela R</mark>** <mark>e os dados de eficácia e segurança nas</mark> **<mark>Tabelas S</mark>** <mark>e</mark> **<mark>T</mark>** <mark>, respectivamente.</mark>  
<mark>Quatro estudos avaliaram os antimetabólitos capecitabina</mark><sup>157</sup> <mark>e tegafur uracil e combinações</mark><sup>158-160</sup> <mark>e seus resultados encontram-se nas</mark> **<mark>Tabelas U</mark>** <mark>a</mark> **<mark>X</mark>** <mark>. Um estudo avaliou o antineoplásico trióxido de arsênio</mark><sup>130</sup> <mark>e um estudo avaliou o anticorpo monoclonal ramucirumabe</mark><sup>162</sup> <mark>, cujos resultados estão nas</mark> **<mark>Tabelas Y</mark>** <mark>a</mark> **<mark>AB</mark>** <mark>.</mark>  
<mark>Dentre os agentes antineoplásicos da classe dos inibidores da proteína quinase, o sorafenibe foi o que apresentou maior número de estudos incluídos, sendo duas revisões sistemáticas</mark><sup>163,164</sup> <mark>e oito ensaios clínicos</mark><sup>165-172</sup> <mark>. Dois ensaios clínicos que avaliaram os inibidores da proteína quinase sunitinibe</mark><sup>173</sup> <mark>e erlonitibe</mark><sup>174</sup> <mark>utilizaram sorafenibe no grupo controle e o que avaliou o regorafenibe</mark><sup>175</sup> <mark>incluiu apenas pacientes com falha ao sorafenibe. Os resultados destes estudos estão nas</mark> **<mark>Tabelas AC</mark>** <mark>a</mark> **<mark>AG</mark>** <mark>.</mark>  
<mark>O subgrupo dos agentes imunoestimulantes incluiu duas revisões sistemáticas que avaliaram a eficácia do interferon</mark><sup>176,177</sup> <mark>e um estudo que avaliou o imunomodulador timostimulina</mark><sup>178</sup> <mark>, como pode ser visto nas</mark> **<mark>Tabelas AH</mark>** <mark>a</mark> **<mark>AK</mark>** <mark>.</mark>  
<mark>O subgrupo dos imunossupressores incluiu uma revisão sistemática que avaliou a talidomida</mark><sup>179</sup> <mark>e dois ensaios clínicos randomizados que avaliaram os imunossupressores seletivos sirolimo</mark><sup>180</sup> <mark>e everolimo</mark><sup>181</sup> <mark>. Os resultados destes estudos encontram-se nas</mark> **<mark>Tabelas AL</mark>** <mark>a</mark> **<mark>AO</mark>** <mark>.</mark>  
<mark>O subgrupo das terapias endócrinas incluiu onze estudos que avaliaram a eficácia e segurança de terapias hormonais, sendo duas revisões sistemáticas</mark><sup>182, 189</sup> <mark>e nove ensaios clínicos</mark><sup>183-188, 190, 191, 195, 196</sup> <mark>. Seis estudos realizaram comparações de terapias contendo tamoxifeno</mark><sup>183-186, 195</sup> <mark>, um contendo nilutamida, gosserrelina e triptorrelina</mark><sup>196</sup> <mark>, dois contendo megestrol</mark><sup>188,</sup> 190 <mark>e dois contendo o análogo de somatostatina octreotida</mark> 187, 191 <mark>. Os resultados destes estudos estão nas</mark> **<mark>Tabelas AP</mark>** <mark>a</mark> **<mark>AS</mark>** <mark>.</mark>  
<mark>Outros compostos avaliados incluíram o antiviral lamivudina</mark><sup>136</sup> <mark>e compostos de vitamina K2</mark><sup>193</sup> <mark>e vitamina K3</mark><sup>194</sup> <mark>, cujos resultados apresentam-se nas</mark> **<mark>Tabelas AT</mark>** <mark>a</mark> **<mark>AV</mark>** <mark>.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Terapias citotóxicas** -->
**Tabela Q** – Características dos estudos que avaliaram terapias citotóxicas.  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Doxorrubicina**||||
|**Qin et al.**<br>**2013**<sup>**151**</sup>|Ensaio clínico<br>randomizado, fase III,<br>multicêntrico, realizado na<br>Coreia, China, Tawain e<br>Tailândia (EACH).|Avaliar a eficáca e<br>segurança do esquema<br>FOLFOX4 como<br>quioterapia paleativa em<br>pacientes com CHC<br>avançado.|Pacientes acima de 18 anos de<br>idade, com CHC não ressecável<br>e inelegíveis a tratamentos<br>locorregionais invasivos com<br>índice de Karnofsky>=70,<br>expectativa de vida >= 3 meses,<br>BCLC B ou C, Child Pugh A ou<br>B. Foram incluídos 371<br>pacientes.|FOLFOX4 a cada duas<br>semanas<br>(Oxaliplatina mg/m<sup>2</sup>IV<br>no dia 1; Leucovorina<br>200 mg/m<sup>2</sup>IV dias 1 e<br>2; Fluoracil 400 mg/m<sup>2</sup><br>a 600mg/m<sup>2</sup>nos dias 1<br>e 2)|Doxorrubicina<br>50 mg/m<sup>2</sup>IV a<br>cada 3 semanas|Baixo risco de viés.<br>Randomização, sigilo da alocação e<br>relato de desfechos incompletos<br>adequados.  Estudo_open-label_,<br>porém com desfechos duros,<br>provavelmente não passíveis de viés<br>pela falta de cegamento.|
|||Avaliar a eficácia e||Transplante +<br>doxorrubicina 10||Alto risco de viés.<br>Radomização adequada, sigilo da|
|**Soderdahl**<br>**et al.**<br>**2006**<sup>**152**</sup>|Ensaio clínico<br>randomizado, realizado<br>em três centros na<br>Escandinávia|segurança de<br>doxorrubicina como<br>terapia adjuvante em<br>pacientes submetidos ao<br>transplante de fígado.|Pacientes adultos com CHC não<br>ressecável e sem doença extra-<br>hepática. Foram incluídos 46<br>pacientes.|<br>mg/m<sup>2</sup>por semana pré,<br>intra (15 mg/m<sup>2</sup>) e pós<br>cirurgia até atingir dose<br>cumulativa de 400<br>mg/m<sup>2</sup>|Transplante|aloação incerto e excluiu 2 pacientes<br>de cada grupo da análise final (não<br>ITT). Estudo_open-label_, porém com<br>desfechos duros, provavelmente não<br>passíveis de viés pela falta de<br>cegamento.|
|**Pokorny**|Ensaio clínico|Avaliar a eficácia e<br>segurança de|Pacientes com CHC não<br>ressecáveis e sem doena extra-|Transplante +<br>doxorrubicina 15|||
|**et al.**|randomizado, realizado|doxorrubicina como|ç<br>heática Foram incluídos 62|mg/m<sup>2</sup>a cada duas|Transplante|Baixo risco de viés.|
|**2005**<sup>**153**</sup>|em um centro na Áustria|terapia adjuvante em<br>pacientes submetidos ao|p.<br>pacientes.|semanas pré, intra e pós<br>cirurgia (até 20 ciiclos)|||  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||transplante de fígado.|||||
|**Yeo et al.**<br>**2005**<sup>**154**</sup>|Ensaio clínico<br>randomizado, fase III,<br>realizado em um hospital<br>na China.|Avaliar a eficácia e<br>segurança do esquema<br>quimioterápico<br>contendo interferon,<br>doxorrubicina,<br>cisplatina e fluoracial<br>(PIAF) em pacientes<br>com CHC não|Pacientes entre 15 e 75 anos de<br>idade, com CHC metastático ou<br>não ressecável, ECOG 0-2.<br>Foram incluídos 188 pacientes.|PIAF<br>(Doxorubicina 40<br>mg/m<sup>2</sup>no dia 1,<br>cisplatina 20 mg/m<sup>2</sup>,<br>interferon α− 2b 5 MU/<br>m<sup>2</sup>e 5-fluorouracil 400<br>mg/m<sup>2</sup>nos dias 1 a 4 a<br>cada três semanas até|Doxorubicina<br>60 mg/m2 no<br>dia 1 a cada<br>três semanas<br>até completar<br>seis cliclos|Risco de viés alto.<br>Não relata método de randomização<br>e de garantir o sigilo da alocação.<br>Relato de desfechos incompletos<br>adequado, com análise de sobrevida<br>por intenção de tratar. Estudo_open-_<br>_label_, porém com desfechos duros,<br>provavelmente não passíveis de viés|
|||ressecável.||completar seis ciclos)||pela falta de cegamento.|
|**Lai et**<br>**al.1988**<sup>**155**</sup>|Ensaio clínico<br>randomizado, fase III,<br>realizado em um hospital<br>na China.|Avaliar a eficácia e<br>segurança de<br>doxorrubicina em<br>pacientes com CHC não<br>ressecável.|Pacientes abaixo de 80 anos<br>deidade, com CHC inoperável,<br>índice Karnofsky >=50%, que<br>nunca haviam recebido<br>tratamento prévio. Foram<br>incluídos 106 pacientes.|Doxorrubicina 60 a 75<br>mg/m<sup>2</sup>IV a cada três<br>semanas|Sem<br>tratamento|Risco de viés incerto<br>. Randomização adequada, sigilo da<br>alocação incerto. Relato de<br>desfechos incompletos adequado,<br>com análise de sobrevida por<br>intenção de tratar. Estudo_open-_<br>_label_, porém com desfechos duros,<br>provavelmente não passíveis de viés<br>pela falta de cegamento.|
|**Epirubicina**|||||||
|**Lai et**<br>**al.1998**<sup>**156**</sup>|Ensaio clínico<br>randomizado, realizado<br>em um hospital na China.|Avaliar a eficácia de<br>terapia adjuvante com<br>epirubicina em<br>pacientes submetidos à<br>hepatectomia.|Pacientes que realizaram<br>ressecção do tumor com<br>sucesso, sem tratamento prévio.<br>Foram incluídos 66 pacientes.|Epirubicina 40 mg/m<sup>2</sup><br>IV a cada seis semanas<br>(até 8 ciclos) + TACE a<br>cada dois meses (3<br>ciclos)|Cuidados<br>paliativos|Baixo risco de viés.<br>Randomização, sigilo da alocação e<br>relato de desfechos incompletos<br>adequados. Estudo_open-label_,<br>porém com desfechos duros,|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||||provavelmente não passíveis de viés|
|||||||pela falta de cegamento.|  
<mark>Legenda: CHC: Carcinoma hepatocelular  celular; ECOG: e</mark> scala de desempenho da _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; IM: Intramuscular; IV: Intravenoso; NR: Não relatado; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control_ ; VO: Via oral.  
**Tabela R** – Características dos pacientes em estudos que avaliaram terapias citotóxicas.  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M (%)**|**Grau do**<br>**CHC (%)**|**Etiologia**<br>**(%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão**<br>**n/N (%)**|**Razão para suspensão**<br>**n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||**Doxorrub**|**icina**||||
|||||||||FOLFOX4: 4||FOLFOX4_vs_.|
||||||Child Pugh|||ciclos (amplitude 1|FOLFOX4:|Doxorrubicina|
||FOLFOX4|184|49,53 ±<br>10,77|90,2|A: 88,6<br>BCLC C:|HCV: 4,9<br>HBV: 92,9|30 meses|a 18)<br>Doxorrubicina: 2|174/183 (95%)<br>Doxorrubicina:|Progressão/recorrência: 93<br>(50,8)_vs_. 99 (56,9)|
||||||78,8|||ciclos (amplitude 1|166/174 (95%)|Eventos adversos: 27 (14,8)|
|**Qin et al.**||||||||a 14)||_vs_. 13 (7,5)|
|**2013**<sup>**151**</sup>|||||Child Pugh|||||Retirada de consentimento:<br>0 vs. 1 (0,6)|
||Doxorrubicina|187|49,30 ±<br>10,80|87,2|A: 87,2<br>BCLC C:<br>81,3|HCV: 8,6<br>HBV: 89,8|NR|NR|NR|Decisão do paciente: 32<br>(17,5)_vs_. 29 (16,7)<br>Morte: 11 (6,0)_vs_. 8 (4,6)<br>Outros: 11 (6,0)_vs_. 16 (9,2)|
||||||UICC||||||
|**Pokorny**<br>**et al.**<br>**2005**<sup>**153**</sup>|Transplante +<br>doxorrubicina|34|> 50 anos:<br>24 (71%)|85|I: 3<br>II: 15<br>III: 17<br>IVa: 65<br>Child Pugh<br>A: 56|HbsAg+: 15<br>HbsAg-: 85|Cinco anos|Doxorrubicina:<br>Pós cirurgia (25<br>pacientes): 13<br>ciclos (IQR 6-15,5)|7/32 (21,8)|Doxorrubicina+cirurgia<br>Progressão da doença: 7<br>(21,8)|  
||Transplante|28|> 50 anos:<br>19 (68%)|86|UICC<br>I: 4<br>II: 14<br>III: 32<br>IVa: 50<br>Child Pugh<br>A: 50|HbsAg+: 0<br>HbsAg-:<br>100|NR|NR|NR||
|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**|**Detalhes da**<br>**Intervenção/**|**N**|**Idade em**|**Sexo**|**Grau do**|**Etiologia**|**Tempo de**|**Tempo de**<br>**tratamento,**|**Suspensão n/N**|**Razão para suspensão n**|
|**ano**|<br>**comparador**||**anos**|**M (%)**|**CHC (%)**|**(%)**|**seguimento**|**mediana (mín-**<br>**máx)**|**(%)**|**(%)**|
||||||Child Pugh||||||
||PIAF|94|Mediana: 49<br>(amplitude<br>26 a 71)|92,5|A: 83<br>ECOG 0:<br>92,5<br>ECOG 1: 7,5|HCV: 31,2<br>HBV: 6,2|NR|3 ciclos|3/93 (3)|PIAF_vs_. Doxorrubicina|
|**Yeo et al.**|||||Okuda II: 87|||||Tumor não mensurável: 2|
|<br>**2005**<sup>**154**</sup>|||||Child Pugh<br>A: 87|||||(2,2) vs. 2 (2,2)<br>Perda de acompanhamento:|
||||Mediana: 54||ECOG 0:|HCV: 312||||1 (1,1)_vs_. 5 (5,6)|
||Doxorubicina|94|(amplitude<br>19 a 72)|90,4|87,2<br>ECOG 1:<br>10,6<br>Okuda II: 87|,<br>HBV: 6,2|NR|4 ciclos|7/88 (8)||
|**Soderdah**|Transplante +|19|55,4 ± 9,1|82,4|Critério|HCV: 31,2|Cinco anos|Doxorrubicina:|2/19 (10,5)|Não estratifica por grupo,|
|**l et al.**|doxorrubicina||||Milan|HBV: 6,2||10/17 completaram||Diagnóstico errôneo (n=2)|
|**2006**<sup>**152**</sup>|||||adequado:|||a dose de 400||Evidência de doença extra-|  
|||||47,1|||mg/m<sup>2</sup><br>6/17 receberam<br>dose <200 mg/m<sup>2</sup>||hepática (n=2)|
|---|---|---|---|---|---|---|---|---|---|
||Transplante|27<br>57,7 ± 8,6|84|Critério|HCV: 36,0|||2/27 (7,4)||
|||||Milan<br>adequado:<br>32,0|HBV: 12,0|||||
|**Autor,**|**Detalhes da**<br>**Intervenão/**|**N**<br>**Idade em**|**Sexo**|**Grau do**|**Etiologia**|**Tempo de**|**Tempo de**<br>**tratamento,**|**Suspensão n/N**|**Razão para suspensão n**|
|**ano**|**ç**<br>**comparador**|**anos**|**M (%)**|**CHC (%)**|**(%)**|**seguimento**|**mediana (mín-**<br>**máx)**|**(%)**|**(%)**|
|**Lai et al.**|Doxorrubicina|60<br>Mediana: 52|90|NR|HbsAg+:|NR|NR|NR||
|**1988**<sup>**155**</sup>||(amplitude|||78,3|||||
|||16-75)|||HbsAg+ e<br>antiHbs+:|||||
||||||16,7||||NR|
||Sem tratamento|46<br>Mediana: 57|83|NR|HbsAg+:|||||
|||(amplitude|||67,3|||||
|||25-80)|||HbsAg+ e|||||
||||||antiHbs+:<br>23,9|||||
||||||**Epirubi**|**cina**||||
|**Lai et al.**|Epirubicina|30<br>54,6 (IC95%|86,6|Estágio|HBV: 83,3|28,3 meses|Epirubicina: 11/30|19/30 (63,3)|Epirubicina:|
|**1998**<sup>**156**</sup>|+TACE|50,2-59)||I/II/III:||(amplitude|(36,7%)||Recorrência da doença:|
|||||3/30/67||4,9-77,1)|completaram 8||15/30 (50)|
||||||||ciclos||Evento adverso: 2/30 (6,6)|
|||||Segundo o|||TACE: 15/30||Decisão do paciente: 2/30|  
|||||_Liver_|||(50%)||(6,6)|
|---|---|---|---|---|---|---|---|---|---|
|||||_Cancer_<br>_Study Group_<br>_of Japan_|||completaram 3<br>ciclos|||
|Cuidados|36|53,4 (IC95%|75|Estágio|HBV: 86,1|NE|NE|0||
|paliativos||49,2-57,5)||I/II/III:||||||
|||||8/33/59||||||  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG:</mark> escala de desempenho da _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; N: número de pacientes; NR: Não relatado; PIAF: esquema quimioterápico contendo interferon, doxorrubicina, cisplatina e</mark> fluoracial; <mark>TACE: quimioembolização transarterial;</mark> UICC: _Union for International Cancer Control_ .  
**Tabela S** – Desfechos de eficácia dos estudos que avaliaram terapias citotóxicas.  
||**Mortalidade/Sobrevida intervenção**|**Mortalidade/Sobrevida controle**|||||
|---|---|---|---|---|---|---|
|**Autor, ano**<br>**Doxorrubicin**|**[mortalidade: n/N (%), sobrevida:**<br>**mediana em meses]**<br>**a**<br>|**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**|**p-valor**|**Resposta intervenção, n/N (%)**<br>|**Resposta controle, n/N (%)**|**p-valor**|
||Sobrevida global: 6,40 meses (IC95%<br>5,30-7,03)<br>HR: 0,80 (IC95% 0,63-1,02)|Sobrevida global: 4,97 meses|p=0,07|Taxa de Resposta Objetiva: 15/184<br>(8,15%; IC95% 4,63-13,09%)|Taxa de Resposta Objetiva: 5/187<br>(2,67%; IC95% 0,87-6,13)||
||Análise post-hoc com 30 meses de|(IC95% 4,23-6,03)||Taxa de controle da doença:|Taxa de controle da doença:||
||acompanhamento: 6,47 meses||=004|96/184 (52,17%; IC95% 45,78-|59/187 (31,55%; IC95% 25,96-|p=0,02|
|**Qin et al****_._**|(IC95% 5,33-7,03)|Análise post-hoc com 30 meses de|p,|60,64%)|39,84%)||
|**2013**<sup>**151**</sup>|HR: 0,79 (IC95% 0,63-0,99)|acompanhamento: 4,90 meses|||||
|||(IC95% 4,2-6,03) Sobrevida livre|||RC: 0|p<0,001|
||Sobrevida livre de progressão: 2,93|de progressão: 1,77 meses (IC95%||RC: 0|RP: 5 (2,67%)||
||meses (IC95% 2,43-3,53)|1,63-2,30)|<0001|RP: 15 (8,15%)|DE: 54 (28,88%)||
||HR: 0,62 (IC95% 0,49-0,79)||p,|DE: 81 (44,02%)<br>PD: 54 (29,35%)|PD: 76 (40,64%)||
||Sobrevida global em 3 anos: 63%|Sobrevida global em 3 anos: 70%|p=0,968||||
|**Soderdahl**|Sobrevida global em 5 anos: 63%|Sobrevida global em 5 anos: 58%|p=0,303||||
|**et al****_._**<br>**2006**<sup>**152**</sup>|Sobrevida livre de doença em 3 anos:<br>63%|Sobrevida livre de doença em 3<br>anos: 50%<br>Sobrevida livre de progressão em|p=0,294|NR|NR|NR|
||Sobrevida livre de progressão em 3<br>anos: 73%|<br>3 anos: 55%|p=0,265||||
|**Pokorny et**<br>**al****_._2005**<sup>**153**</sup>|Sobrevida global em 5 anos: 12/34<br>(35%)|Sobrevida global em 5 anos: 11/28<br>(38%)|p=0,53|Recorrência do tumor: 18 (53%)|Recorrência do tumor: 16 (57%)|NR|  
||**Mortalidade/Sobrevida intervenção**|**Mortalidade/Sobrevida controle**|||||
|---|---|---|---|---|---|---|
|**Autor, ano**|**[mortalidade: n/N (%), sobrevida:**<br>**mediana em meses]**|**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**|**p-valor**|**Resposta intervenção, n/N (%)**|**Resposta controle, n/N (%)**|**p-valor**|
||46,2 meses (IC95% 32,4-60,0)|57,4 meses (IC95% 40,2-74,6)|||||
||Sobrevida livre de progressão em 5<br>anos: 17/30 (43%)<br>49,8 meses (IC95% 33,3-66,3)|Sobrevida livre de progressão em<br>5 anos: 11/25 (53%)<br>68,3 meses (IC95% 48,6-88,0)|p=0,24||||
|**Yeo et al****_._**|Sobrevida global: 8,67 meses (IC95%|Sobrevida global: 6,83 meses||Taxa de resposta objetiva: 20,9%|Taxa de resposta objetiva: 10,5%|p=0,058|
|**2005**<sup>**154**</sup>|6,36-12,00)|(IC95% 4,80-9,56)|p=0,83|(IC95% 12,5 -29,2)|(IC95% 3,9-16,9)||
||HR morte: 0,97 (IC95% 0,71-1,32)||||||
||||NR|RC: 0|RC: 0||
||Mortalidade: 79/94 (84%)|Mortalidade: 84/94 (89%)||RP: 19/91 (20,9%)|RP: 9/86 (10,5%)||
||||NR|DE: 35/91 (38,5%)|DE: 37/86 (43,0%)||
||Sobrevida em 1 ano: 39% (IC95%|Sobrevida em 1 ano: 30% (IC95%||PD: 37/91 (40,7%)|PD: 40/86 (46,5%)||
||29-49)|20-39)|||||
|**Lai****_et_**|Sobrevida global: 10,6 semanas|Sobrevida global: 7,5 semanas|p=0,036|RC: 0|RC: 0|NR|
|**_al._1988**<sup>**155**</sup>|(amplitude 1,5-104)|(amplitude 0,5-68)||Regressão >25% do tumor: 5/60<br>(8,3%)<br>RP (50-75% redução tumor): 2/60|||
|||||(3,3%)|DE: semelhante à doxorrubicina||
|||||DE: 6/60 (10%)|(NR valor)|NS|
|||**Ep**|**irubicina**||||  
||**Mortalidade/Sobrevida intervenção**|**Mortalidade/Sobrevida controle**|||||
|---|---|---|---|---|---|---|
|**Autor, ano**|**[mortalidade: n/N (%), sobrevida:**|**[mortalidade: n/N (%),**|**p-valor**|**Resposta intervenção, n/N (%)**|**Resposta controle, n/N (%)**|**p-valor**|
||**mediana em meses]**|**sobrevida: mediana em meses]**|||||
|**Lai****_et_**|Mortalidade: 10/30 (33,3%)|Mortalidade: 10/36 (27,8%)|p=0,10|Recorrência da doença: 23/30|Recorrência da doença: 17/36|p = 0,01|
|**_al._1998**<sup>**156**</sup>|Sobrevida livre de doença ano 1:|Sobrevida livre de doença ano 1:|p=0,04|(76,7%)|(47,2%)||
||50%|69%|||||
||Sobrevida livre de doença ano 2:|Sobrevida livre de doença ano 2:|||||
||36%|53%|||||
||Sobrevida livre de doença ano 3:|Sobrevida livre de doença ano 3:|||||
||18%|48%|||||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**Tabela T** – Eventos adversos dos estudos que avaliaram terapias citotóxicas.  
|**Et d**|**Lai**|**et al****_._1988**<sup>**155**</sup>|**Pokorny et al**|**_._2005**<sup>**153**</sup>|**Qin et al**|**_._2013**<sup>**151**</sup>|**Yeo et**|**al.2005**|**Lai et**|**al.1998**<sup>**156**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|**venos aversos**<br>**(Grau 3-5)**|**DOX**<br>**(N=60)**|**Sem tratamento**<br>**(N=46)**|**DOX+transplant**<br>**e (N=32)**|**Transplante**<br>**(N=28)**|**FOLFOX**<br>**4 (N=183)**|**DOX**<br>**(N=174)**|**PIAF**<br>**(N=93)**|**DOX**<br>**(N=88)**|**Epirubicina +**<br>**TACE (n=30)**|**Cuidados**<br>**paliativos (n=36)**|
|Alopecia n (%)|NR|NR|NR|NR|1 (0,5)|9 (5,2)|NR|NR|NR|NR|
|Anemia n (%)|NR|NR|NR|NR|9 (4,9)|14 (8,0)|26 (28)|26 (28)|NR|NR|
|Anorexia n (%)|NR|NR|NR|NR|2 (1,1)|0|7 (7)|3 (3)|NR|NR|
|Ascite n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Azia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Cefaleia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Diarreia n (%)|NR|NR|NR|NR|4 (2,2)|3 (1,7)|11 (12)|7 (7)|NR|NR|
|Dispneia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor abdominal n (%)|NR|NR|NR|NR|NR|NR|3 (3)|6 (6)|NR|NR|
|Fadiga n (%)|NR|NR|NR|NR|2 (1,1)|1 (0,6)|NR|NR|NR|NR|
|Ginecomastia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hiperglicemia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hipertensão n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Infecção n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Leucopenia n (%)|NR|NR|NR|NR|16 (8,7)|17 (9,8)|NR|NR|1 (3,3)|0|
|Morte n (%)|15 (25)|0|NR|NR|NR|NR|3 (3)|8 (9)|NR|NR|
|Nausea n (%)|60 (100)|0|NR|NR|0|0|2 (2)|4 (4)|NR|NR|
|Neutropenia n (%)|54 (90)|0|NR|NR|56 (31)|40 (23)|77 (82)|59 (63)|NR|NR|
|Outros n (%)|9 (15)|0|NR|NR|NR|NR|NR|NR|5 (16,7)|0|
|Rash n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Reação mãos e pés n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
|**Eventos adversos**|**Lai**<br>|**et al****_._1988**<sup>**155**</sup><br>|**Pokorny et a**<br>|**l****_._2005**<sup>**153**</sup>|**Qin et al**<br>|**_._2013**<sup>**151**</sup><br>|**Yeo et**<br>|**al.2005**<br>|**Lai et**<br>|**al.1998**<sup>**156**</sup><br>|
|---|---|---|---|---|---|---|---|---|---|---|
|**(Gra 3-5)**|**DOX**|**Sem tratamento**|**DOX+transplant**|**Transplante**|**FOLFOX**|**DOX**|**PIAF**|**DOX**|**Epirubicina +**|**Cuidados**|
|**u**|**(N=60)**|**(N=46)**|**e (N=32)**|**(N=28)**|**4 (N=183)**|**(N=174)**|**(N=93)**|**(N=88)**|**TACE (n=30)**|**paliativos (n=36)**|
|Reação no local de<br>aplicação n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Rubor n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Sangramento n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Trombocitopenia n<br>(%)|NR|NR|NR|NR|14 (7,6)|11 (6,3)|54 (77)|23 (24)|NR|NR|
|Vômito n (%)|NR|NR|NR|NR|2 (1,1)|0|11 (12)|4 (4)|NR|NR|
|Todos n (%)|NR|NR|4 (12)|0|102 (55,7)|79 (45,4)|NR|NR|6 (20)|0|  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes DOX: Doxorrubicina; TACE: quimioembolização transarterial; PIAF: e</mark> squema quimioterápico contendo interferon, doxorrubicina, cisplatina e fluoracial.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Antimetabólitos** -->
**Tabela U** – Características dos estudos que avaliaram antimetabólitos.  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Capecitabina**||||
|**Xia et al.**<br>**2010**<sup>**157**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em<br>um hospital na<br>China.|Avaliar a eficácia de<br>capecitabina como terapia<br>adjuvante em prevenir a<br>recorrêencia de CHC.|Pacientes entre 18 e 70 anos de<br>idade, que realizaram com sucesso<br>ressecção do tumor <50% do<br>fígado, sem doença extra-<br>hepática, Child Pugh A,<br>expectativa de vida > 6 meses,<br>índice Karnofsky>=70%. Foram<br>incluídos 60 pacientes.|Tratamento de suporte<br>+ capecitabina 2000<br>mg/m<sup>2</sup>/dia VO por<br>duas semanas<br>consecutivas, seguida<br>de uma de descanso,<br>totalizando entre 4–6<br>ciclos.|Tratamento de<br>suporte|Baixo risco de viés.|
||||**Tegafur uracil**||||
|**Kudo et al.**<br>**2017**<sup>**158**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em<br>57 centros no<br>Japão (S-CUBE).|Avaliar a eficácia e<br>segurança de S-1, composto<br>combinado de tegafur,<br>gimeracil e oteracil.|Pacientes acima de 20 anos de<br>idade, com CHC refratário ao uso<br>de sorafenibe (progressão ou<br>intolerância), Child Pugh 5-7 e<br>ECOG 0-1. Foram incluídos 334<br>pacientes.|S-1 80 mg/m²<br>Ciclos de 28 dias com<br>intervalo de 14 dias<br>Dose diária segundo a<br>superfície corporal do<br>paciente|Placebo VO|Baixo risco de viés.<br>Randomização, sigilo da<br>alocação, cegamento e<br>relato de desfechos<br>incompletos adequados.|
||Ensaio clínico<br>randomizado|Avaliar e eficácia e|Pacientes entre 15 e 75 anos de<br>idade que realizaram ressecção de|||Alto risco de viés.<br>Estudo randomizado,|
|**Ishizuka et al.**<br>**2016**<sup>**159**</sup>|<br>realizado em um<br>hospital<br>universitário no<br>Japão|segurança de tegafur uracil<br>em evitar a recorrência de<br>CHC após transplante de<br>fígado.|CHC, com ausência de lesões um<br>mês após a cirurgia, Child Pugh A<br>ou B e ausência de doença renal<br>ou cardíaca grave. Foram<br>incluídos 117 pacientes.|Tegafur uracil 400<br>mg/dia VO +<br>transplante|Transplante|porém risco incerto para<br>sigilo da alocação, estudo<br>aberto e análise dos<br>desfechos foi feita por<br>protocolo, sendo que|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||||houve 60% de perda no<br>grupo que recebeu a<br>intervenção e zero no<br>grupo controle.|
|**Hasegawa et**<br>**al. 2006**<sup>**160**</sup>|Ensaio clínico<br>randomizado<br>realizado em um<br>hospital<br>universitário no<br>Japão|Avaliar e eficácia e<br>segurança de tegafur uracil<br>em evitar a recorrência de<br>CHC após transplante de<br>fígado.|Pacientes acima de 15 anos de<br>idade, de idade que realizaram<br>ressecção de CHC, com Child Pug<br>A ou B, sem doença extra-<br>hepática ou trombose na veia cava<br>ou porta. Foram incluídos 371<br>pacientes.|Tegafur uracil 300<br>mg/dia + transplante|Transplante|Baixo risco de viés.|  
<mark>Legenda: CHC: Carcinoma hepatocelular ; ECOG: e</mark> scala de desempenho da _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; TACE: quimioembolização transarterial; IM: Intramuscular; IV: Intravenoso;</mark> VO: Via oral <mark>; NR: Não relatado.</mark>  
**Tabela V** – Características dos pacientes em estudos que avaliaram antimetabólitos.  
|**Autor,**<br>**ano**|**Detalhes**<br>**Intervenção/**<br>**Comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia**<br>**(%)**<br>**Capecitabin**|**Tempo de**<br>**seguimento**<br>**a**|**Tempo de**<br>**tratamento**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão**<br>**n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Xia et**<br>**al.**<br>**2010**<sup>**157**</sup>|Tratamento de<br>suporte +<br>capecitabina|30|≤60<br>(90,0%)|83,3|NR|HbsAg+:<br>86,7|Mediana:<br>47,5 meses<br>(4–65|Capecitabina: 24<br>(80,0%) pacientes<br>receberam 4-6<br>ciclos|6/30 (20)|Capecitabina:<br>Eventos adversos: 2/30<br>(6,6)<br>Recorrência do tumor: 4/30|
||Tratamento de<br>suporte|30|≤60<br>(80,0%)|70|NR|HbsAg+:<br>80,0|meses)||0|<br>(13,3)|
|||||||**Tegafur ura**|**cil**||||
||S-1 80 mg/m²|223|Mediana:<br>70 (IQR<br>64–75)|82|Child Pugh 5: 47<br>Child Pugh 6: 34<br>Child Pugh 7: 19<br>ECOG 0: 85|HCV: 55<br>HBV: 20|Mediana:<br>32,4 meses<br>(IQR 24,0–|3,5 meses (IQR 1,4–<br>7,9)<br>Intensidade da dose:<br>8526% (IQR|213/223 (95,5)|S-1_vs_. placebo:<br>Progressão da doença: 165|
|**Kudo et**<br>**al**|||||ECOG 1: 15<br>BCLC avançado: 66||34,7)|,<br>69,12–98,81)||(74,0)_vs_. 97 (87,3)<br>Evento adversos: 41 (18,4)|
|**.**<br>**2017**<sup>**158**</sup>|Placebo|111|Mediana:<br>70 (IQR<br>64–75)|77|Child Pugh 5: 41<br>Child Pugh 6: 41<br>Child Pugh 7: 19<br>ECOG 0: 81<br>ECOG 1: 19<br>BCLC avançado: 67|HCV: 53<br>HBV: 23|Mediana:<br>32,9 meses<br>(IQR 23,7–<br>39,5)|2,0 meses (IQR 1,0–<br>3,8)|110/111 (99,0)|_vs_. 6 (5,4)<br>Retirada de consentimento:<br>6 (2,7)_vs_. 6 (5,4)<br>Outros: 1 (<1)_vs_. 1 (<1)|  
|**Ishizuka**|Tegafur uracil +<br>Cirurgia|61|NR|NR|NR|NR|Mediana:<br>2,8 anos|NR|37/61 (60,6)|Tegafur uracil:<br>Retirada consentimento: 14<br>(23)|
|---|---|---|---|---|---|---|---|---|---|---|
|**et al.**<br>**2016**<sup>**159**</sup>|Cirurgia|56|NR|NR|NR|NR|(amplitude<br>0,5-5,5<br>anos)||0|<br>Eventos adversos: 11 (18)<br>Disfunção hepática: 5 (8,2)<br>Outras doenças: 7 (11,5)|
||||Mediana:||||||||
|**Hasega-**<br>**wa et al**|Tegafur uracil +<br>Cirurgia|79|65<br>(amplitude<br>29-75)|76|Child Pugh A: 86|NR|Mediana:<br>4,8 anos|1 ano após cirurgia|32/79 (41)|Tegafur uracil:<br>Retirada consentimento: 17<br>(21)|
|**.**<br>**2006**<sup>**160**</sup>|||Mediana:||||(amplitude|||Eventos adversos: 5 (6)|
||Cirurgia|80|64<br>(amplitude<br>35-78)|81|Child Pugh A: 88|NR|0,5-7,9)||0|Disfunção hepática: 4 (5)<br>Supressão da medula: 6 (7)|  
<mark>Legenda: CHC: Carcinoma hepatocelular</mark> **<mark>;</mark>** <mark>ECOG: e</mark> scala de desempenho da _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; NR: não relatado; IQR: intervalo interquartil.</mark>  
**Tabela W** – Desfechos de eficácia dos estudos que avaliaram antimetabólitos.  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**|**Mortalidade/Sobrevida**<br>**controle**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em**<br>**meses]**|**p-valor**|<br>**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até**<br>**resposta**<br>**intervenção**<br>**(mediana em**<br>**meses)**|**Tempo até**<br>**resposta**<br>**controle**<br>**(mediana em**<br>**meses)**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|**Capecitabi**|**na**|||||||||
||Mortalidade em 5 anos: 11/30<br>(36,7%)|Mortalidade em 5 anos:<br>16/30 (53,3%)|NR|Recorrência do|Recorrência do|||||
||Sobrevida global: 60 meses|Sobrevida global: 52,5<br>meses|p =<br>0,216|tumor ano 1: 7/30<br>(23,3%)|tumor ano 1:<br>11/30 (36,7%)|p= 0,242||||
|**Xia et al.**|Sobrevida global ano 1: 86,7%|Sobrevida global ano 1:||Recorrência do<br>tumor ano 3: 13/30|Recorrência do<br>tumor ano 3:|p =<br>0037|Tempo até<br>recorrência:  40|Tempo até<br>recorrência:  20|p =|
|**2010**<sup>**157**</sup>|Sobrevida global ano 3: 73,3%|83,3%||<br>(43,3%)|<br>21/30 (70,0%)|,|meses (IC95%<br>31,0–49,2)|meses (IC95%<br>12,8–27,2)|0,046|
||Sobrevida global ano 5: 62,5 %|Sobrevida global ano3:<br>56,7%||Recorrência do<br>tumor ano 5: 16/30|Recorrência do<br>tumor ano 5:|p =<br>0,046||||
||Sobrevida livre da doença: HR:<br>0,42 (IC95% 0,216–0,816)|Sobrevida global ano 5:<br>39,8%|p =<br>0,011|(53,3%)|23/30 (76,7%)|||||
|||||**Tegafur uracil**||||||
||Mortalidade: 183/223 (82%)|Mortalidade: 100/111||Taxa de Resposta||p=0,068|Tempo até a|||
|**Kudo et**||(90%)||Objetiva: 12/222|||progressão: 2,6|Tempo até a||
|**al.**|Sobrevida global: 11,1 meses|||(5%; IC95% 3–9)|Taxa de Resposta||meses (IC95%|progressão:  1,4||
|**2017**<sup>**158**</sup>|(IC95% 9,7–13,1)|Sobrevida global: 11,2|||Objetiva: 1/111||2,6–2,8)|meses (1,3–2,3)|p<0,00|
|||meses (IC95% 9,2–12,8)|p=0,22||(1%; IC95% 0–5)||||01|  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**|**Mortalidade/Sobrevida**<br>**controle**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em**<br>**meses]**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até**<br>**resposta**<br>**intervenção**<br>**(mediana em**<br>**meses)**|**Tempo até**<br>**resposta**<br>**controle**<br>**(mediana em**<br>**meses)**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||HR: 0,86 (IC95% 0,67–1,10)|||Taxa de controle da||p=0,001|HR: 0,59 IC95%|||
|||||doença: 96/222|Taxa de controle||0,46–0,76|||
||Sobrevida ano 1: 46,4% (IC95%|||(43%; IC95% 37–|da doença:|||||
||39,8–53,0)|||50)|27/111 (24%;|||||
|||Sobrevida ano 1: 46,8%|||IC95% 17–33)||Tempo até a|||
||Sobrevida ano 2: 20,5% (IC95%|(IC95% 37,6–56,1)||RC: 0|||falha do|Tempo até a||
||14,9–26,0)|||RP: 12/222 (5%)|RC: 0||tratamento: 3,5|falha do||
|||Sobrevida ano 2: 18,2%||DE: 84/222 (38%)|RP: 1/111 (<1%)||meses (IC95%|tratamento: 2,0|p=0,00|
||Sobrevida livre de progressão: 2,6|(IC95% 10,9–25,6)||PD: 107/222 (48%)|DE: 26/111||2,4–3,9)|meses (1,0–2,3)|01|
||meses (IC95% 2,6–2,8)||||(23%)|||||
|||Sobrevida livre de|||PD: 74/111||HR: 0,63|||
||HR: 0,60 (IC95% 0,46–0,77)|progressão: 1,4 meses|||(67%)||(IC95% 0,50–|||
|||(1,3–2,3)|p<0,000<br>1||||0,80)|||
||Sobrevida livre de recorrência do|Sobrevida livre de||||||||
||tumor:|recorrência do tumor:|p=0,16|||||||
|**Ishizuka**<br>**et al.**|1 ano: 87%<br>3 anos: 27,5%|1 ano: 58,5%<br>3 anos: 25,4%||NR|NR|NR|NR|NR|NR|
|**2016**<sup>**159**</sup>|Sobrevida global:|Sobrevida global:||||||||
||3 anos: 89,3%|3 anos: 75,9%|p=0,29|||||||
||5 anos: 64,3%|5 anos: 62,2%||||||||  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**|**Mortalidade/Sobrevida**<br>**controle**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em**<br>**meses]**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até**<br>**resposta**<br>**intervenção**<br>**(mediana em**<br>**meses)**|**Tempo até**<br>**resposta**<br>**controle**<br>**(mediana em**<br>**meses)**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||Sobrevida livre de recorrência do|Sobrevida livre de||||||||
||tumor:|recorrência do tumor:|p=0,87|||||||
||3 anos: 41%|3 anos: 37%||||||||
|**Hasegaw**|5 anos: 29%|5 anos: 29%||||||||
|**a et al.**|HR: 1,01 (IC95% 0,84-1,22)|||NR|NR|NR|NR|NR|NR|
|**2006**<sup>**160**</sup>||||||||||
||Sobrevida global:|Sobrevida global:||||||||
||3 anos: 90%|3 anos: 92%|p=0,08|||||||
||5 anos: 58%|5 anos: 73%||||||||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**Tabela X** – Eventos adversos dos estudos que avaliaram antimetabólitos.  
||**Xia et al. 2**|**010**<sup>**157**</sup>|**Kudo e**|**t al. 2017**<sup>**158**</sup>|**Ishusuka et**|**al. 2016**<sup>**159**</sup>|
|---|---|---|---|---|---|---|
|**Eventos adversos**<br>**(Grau 3-5)**|**Capecitabina**<br>**(N=30)**|**Controle**<br>**(N=30)**|**S-1**<br>**(N= 222)**|**Placebo (N=111)**|**Tegafur+cirurgia (N=61)**|**Transplante (N=56)**|
|Alopecia n (%)|NR|NR|NR|NR|NR|NR|
|Anemia n (%)|NR|NR|NR|NR|3 (5)|0|
|Anorexia n (%)|NR|NR|NR|NR|NR|NR|
|Ascite n (%)|NR|NR|13 (5,8)|7 (6)|NR|NR|
|Azia n (%)|NR|NR|NR|NR|NR|NR|
|Cefaleia n (%)|NR|NR|NR|NR|NR|NR|
|Diarreia n (%)|NR|NR|8 (4)|1 (<1)|NR|NR|
|Dispneia n (%)|NR|NR|||NR|NR|
|Dor abdominal n (%)|NR|NR|2 (1)|1 (<1)|NR|NR|
|Fadiga n (%)|NR|NR|15 (7)|2 (2)|NR|NR|
|Ginecomastia n (%)|NR|NR|NR|NR|NR|NR|
|Hiperglicemia n (%)|NR|NR|NR|NR|NR|NR|
|Hipertensão n (%)|NR|NR|NR|NR|NR|NR|
|Infecção n (%)|NR|NR|1 (<1)|0|NR|NR|
|Leucopenia n (%)|NR|NR|29 (13)|6 (5,4)|NR|NR|
|Morte n (%)|NR|NR|NR|NR|NR|NR|
|Nausea n (%)|1 (3,3)|0|1 (<1)|0|NR|NR|
|Neutropenia n (%)|1 (3,3)|0|30 (13,5)|3 (3)|NR|NR|
|Outros n (%)|1 (3,3)|0|NR|NR|16 (26)|0|
|Rash n (%)|NR|NR|3 (1)|0|NR|NR|
|Reação mãos e pés n (%)|NR|NR|NR|NR|NR|NR|  
|**Eventos adversos**|**Xia et al. 2**|**010**<sup>**157**</sup>|**Kudo e**|**t al. 2017**<sup>**158**</sup>|**Ishusuka et**|**al. 2016**<sup>**159**</sup>|
|---|---|---|---|---|---|---|
|<br>**(Grau 3-5)**|**Capecitabina**|**Controle**|**S-1**|**Placebo (N=111)**|**Tegafur+cirurgia (N=61)**|**Transplante (N=56)**|
||**(N=30)**|**(N=30)**|**(N= 222)**||||
|Reação no local de aplicação|NR|NR|NR|NR|NR|NR|
|n (%)|||||||
|Rubor n (%)|NR|NR|NR|NR|NR|NR|
|Sangramento n (%)|NR|NR|NR|NR|NR|NR|
|Trombocitopenia n (%)|NR|NR|NR|NR|NR|NR|
|Vômito n (%)|1 (3,3)|0|2 (<1)|0|NR|NR|
|Todos n (%)|NR|NR|90 (41)|24 (22)|NR|NR|  
<mark>Legenda: NR: não relatado.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Outros antineoplásicos** -->
**Tabela Y** – Características dos estudos que avaliaram outros antineoplásicos.  
|**Autor, ano de**<br>**publicação**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Trióxido de arsênio**||||
|**Wang et al.**<br>**2015**<sup>**130**</sup>|Ensaio clínico<br>randomizado,<br>fase III, realizado<br>em um hospital<br>da China.|Avaliar a eficácia e<br>segurança de trióxido de<br>arsênio combinado à<br>TACE em pacientes com<br>CHC primário.|Pacientes entre 18 e 70 anos de idade,<br>não elegíveis à terapia cirúrgica, sem<br>doença extra-hepática, com expectativa<br>de vida >= 3 meses e Child Pugh A/B.<br>Foram incluídos 131 pacientes.|Trióxido de Arsênio 10<br>mg/dia IV por 21 dias<br>(4 ciclos com intervalo<br>de duas semanas) +<br>TACE (Oxaliplatina<br>100 mg, epirubicina 30<br>a 50 mg, lipiodol 2 a 10<br>mL)|TACE<br>(Oxaliplatina 100<br>mg, epirubicina 30 a<br>50 mg, lipiodol 2 a<br>10 mL)|<br>Risco de viés incerto.<br>Randomização e sigilo da alocação<br>adequados, porém a análise de<br>desfechos exclui seis pacientes que<br>não receberam tratamento<br>completo (2 grupos intervenção e 4<br>controles).  Estudo_open-label_,<br>porém com desfechos duros,<br>provavelmente não passíveis de<br>viés pela falta de cegamento.|
||||**Ramucirumabe**||||
|**Zhu et al.**<br>**2015**<sup>**162**</sup>|Ensaio clínico<br>randomizado,<br>fase III, em 154<br>centros em 27<br>países (REACH)|Avaliar a eficácia e<br>segurança de<br>regorafenibe em<br>pacientes com CHC que<br>apresentaram falha ou<br>intolerância ao uso de<br>sorafenibe.|Adultos com CHC e cirrose confirmada,<br>com pelo menos uma lesão mensurável,<br>BCLC B ou C, Child Pugh A, ECOG 0-<br>1, não elegíveis a tratamentos<br>locorregionais e com progressão<br>radiográfica ou intolerância à<br>sorafenibe. Foram incluídos 565<br>pacientes.|Ramucirumabe 8<br>mg/kg/dia IV a cada 2<br>semanas|Placebo IV a cada 2<br>semanas|Baixo risco de viés.|  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; IM: Intramuscular; IV: Intravenoso;</mark> VO: Via oral; <mark>TACE: quimioembolização transarterial; NR: Não relatado.</mark>  
**Tabela Z** – Características dos pacientes em estudos que avaliaram outros antineoplásicos.  
|**Autor, ano**|**Detalhes da**<br>**Intervenção/c**<br>**omparador**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do CHC**<br>**(%)**|**Etiologia**<br>**(%)**|**Tempo de**<br>**seguiment**<br>**o**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Arsênio**|||||||||||
|**Wang et al.**|Trióxido de<br>Arsênio +<br>TACE|61|54,75<br>(amplitude<br>33-70)|83,6|Child Pugh A:<br>85,2<br>BCLC B: 83,6<br>BCLC C: 16,4|HCV: 9,8<br>HBV:<br>90,2|Mediana:<br>25 meses|NR|2/61 (3,3)|NR|
|**2015**<sup>**130**</sup>|TACE|64|55,39<br>(amplitude<br>31-70)|85,9|Child Pugh A:<br>84,3<br>BCLC B: 78,1<br>BCLC C: 18,8|HCV:<br>15,7<br>HBV:<br>84,3|(amplitude<br>4-42)|NR|4/64 (6,3)||
||Ramucirumabe|283|64<br>(amplitude<br>28–87)|83|Child Pugh A:<br>98<br>ECOG 0: 56<br>ECOG 1: 44<br>BCLC C: 88|**Ramuciruma**<br>HCV: 27<br>HBV: 35<br>Outro: 37|**be**<br>Mediana:<br>8,3 meses<br>(IQR 4,0–<br>14,9)|12 semanas<br>(IQR 6,0–29,4)|272/277 (98,2)|Ramucirumabe_vs_. placebo<br>Progressão/recorrência: 191<br>(69,0)_vs_. 236 (85,5)<br>Eventos adversos: 51 (18,4)|
|**Zhu et al.**<br>**2015**<sup>**162**</sup>|Placebo|282|62<br>(amplitude<br>25–85)|86|Child Pugh A:<br>98<br>ECOG 0: 54<br>ECOG 1: 46<br>BCLC C: 88|HCV: 27<br>HBV: 36<br>Outro: 37|Mediana:<br>7,0 meses<br>(3,2–12,9)|8 semanas (IQR<br>6,0–17,8)|271/276 (98,2)|_vs_. 24 (8,7)<br>Retirada de consentimento:<br>12 (4,3)_vs_. 7 (2,5)<br>Morte: 14 (5,1)_vs_. 3 (1,1)<br>Perda acompanhamento: 2<br>(0,7)_vs_. 1 (0,4)<br>Outros: 2 (0,7)_vs_. 0|  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control._  
**Tabela AA** – Desfechos de eficácia dos estudos que avaliaram outros antineoplásicos.  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N (%), sobrevida:**<br>**mediana em meses]**|**Mortalidade/Sobrevida**<br>**controle**<br>**[mortalidade: n/N (%),**<br>**sobrevida: mediana em meses]**<br>**Trióxido**|**p-valor**<br>**de arsênio**|**Resposta intervenção, n/N (%)**|**Resposta controle, n/N (%)**|**p-valor**|
|---|---|---|---|---|---|---|
|**Wang et al.**<br>**2015**<sup>**130**</sup>|Mortalidade: 15/61 (24,6%)<br>Sobrevida global: Mediana não<br>estimada<br>HR morte: 0,37 (IC95% 0,20-0,69)<br>HR morte ajustado por sexo, idade,<br>número, tamanho e estágio do<br>tumor: 0,27 (IC95% 0,14-0,53)<br>Sobrevida ano 1: 93.4% (83.5%-<br>97.5%)|Mortalidade: 34/64 (53,1%)<br>Sobrevida global: 25 meses<br>(95% IC 13,5-36,5)<br>Sobrevida ano 1: 64.1% (51.0%-<br>74.5%)|p=0,000<br>8<br>p<0,000<br>1<br>p =<br>0,000|Taxa de resposta objetiva: 50/61<br>(81.9%; IC95% 72,3-91,6)<br>Taxa de controle da doença: 58/61<br>(95,1%; IC95% 89,6-100,0)<br>Resposta completa: 32/61 (52,4%;<br>IC95% 39,9-65,0)<br>Resposta parcial: 18/61 (29,5%;<br>IC95% 18,0-41,0)|Taxa de resposta objetiva:<br>38/64 (59,4%; IC95% 47,3-<br>71,4)<br>Taxa de controle da doença:<br>52/64 (81,3%; IC95% 71,7-<br>90,8)<br>Resposta completa: 23/64<br>(35,9%; IC95% 24,2-47,7)<br>Resposta parcial: 15/64<br>(23,4%; IC95% 13,0-33,8)|p <0,05<br>p <0,05|
||Sobrevida ano 2: 75.9% (61.7%-<br>85.4%)<br>Sobrevida ano 3: 67.0% (48.9%-<br>79.9%)|Sobrevida ano 2: 50.9% (38.0%-<br>62.5%)<br>Sobrevida ano 3: 42.9% (29.4%-<br>55.7%)<br>**Ramucirum**|p =<br>0,004<br>p =<br>0,021<br>**abe**|Doença estável: 8/61 (13,1%; IC95%<br>4,6-21,6)<br>Progressão doença: 3/61 (4,9%;<br>IC95% 0,0-10,3)|Doença estável: 14/64<br>(21,8%; IC95% 11,8-32,0)<br>Progressão doença: 12/64<br>(18,8%; IC95% 9,2-28,3)||  
Sobrevida global: 9·2 (IC95% 8·1–  
||10·6)<br>HR: 0·87 (0·72–1·05)|Sobrevida global: 7·6<br>(IC95%6·0–9·3)|0,14|Taxa de Resposta Objetiva:  20 (7% -<br>IC95% 4,6–10,7)|Taxa de Resposta Objetiva: 2<br>(<1% - IC95% 0,2–2,5)|p<0,000<br>1|
|---|---|---|---|---|---|---|
||Sobrevida live de progressão: 2·8||||Taxa de controle da doença:||
||(2·7–3·9)|Sobrevida live de progressão:||Taxa de controle da doença: 159|129 (46% - IC95% 40,0–|0011|
|**Zhu et al.**|HR: 0·63 (0·52–0·75)|2·1 (1·6–2·7)||(56% - IC95% 50,4–6,8)|51,6)|p=,|
|**2015**<sup>**162**</sup>|||<0,0001||||
||Sobrevida em 6 meses:  65·5%|||Resposta completa: 1 (<1%)|Resposta completa: 0||
||Sobrevida em 12 meses:  39·7%|Sobrevida em 6 meses:  56,1%||Resposta parcial: 19 (7%)|Resposta parcial: 2 (<1%)||
||Sobrevida livre de progressão em 6|Sobrevida em 12 meses:  33,9%||Doença estável: 139 (49%)|Doença estável: 127 (45%)||
||meses: 32,1%|Sobrevida livre de progressão||Progressão doença: 97 (34%)|Progressão doença: 129||
||Sobrevida livre de progressão em|em 6 meses: 12,9%|||(46%)||
||12 meses: 20,7%|Sobrevida livre de progressão|||||
|||em 12 meses: 8,3%|||||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**Tabela AB** – Eventos adversos dos estudos que avaliaram outros antineoplásicos.  
|**Eventos adversos**|**Wang et al.** **2015**<sup>**130**</sup>||**Zhu et al.** **2015**<sup>**162**</sup>||
|---|---|---|---|---|
|**(Grau 3-5)**|**Arsênio + TACE (N=61)**|**TACE (N=64)**|**Ramucirumabe (N=277)**|**Placebo (N=276)**|
|Alopecia n (%)|NR|NR|NR|NR|
|Anemia n (%)|NR|NR|NR|NR|
|Anorexia n (%)|NR|NR|NR|NR|
|Ascite n (%)|NR|NR|13 (5)|11 (4)|
|Azia n (%)|NR|NR|NR|NR|
|Cefaleia n (%)|NR|NR|2 (1)|0|
|Diarreia n (%)|NR|NR|3 (1)|1 (<1)|
|Dispneia n (%)|NR|NR|NR|NR|
|Dor abdominal n (%)|NR|NR|5 (2)|12 (4)|
|Fadiga n (%)|NR|NR|6 (2)|8 (3)|
|Ginecomastia n (%)|NR|NR|NR|NR|
|Hiperglicemia n (%)|NR|NR|NR|NR|
|Hipertensão n (%)|NR|NR|35 (13)|10 (4)|
|Infecção n (%)|NR|NR|NR|NR|
|Leucopenia n (%)|NR|NR|NR|NR|
|Morte n (%)|NR|NR|NR|NR|
|Nausea n (%)|NR|NR|0|0|
|Neutropenia n (%)|2 (3,3)|0|NR|NR|
|Outros n (%)|2 (3,3)|3 (4,9)|NR|NR|
|Rash n (%)|NR|NR|NR|NR|
|Reação mãos e pés n (%)|NR|NR|NR|NR|
|Reação no local de aplicação n (%)|NR|NR|3 (1)|0|
|Rubor n (%)|NR|NR|NR|NR|  
|**Eventos adversos**|**Wang et al.** **2015**<sup>**130**</sup>||**Zhu et al.** **2015**<sup>**162**</sup>||
|---|---|---|---|---|
|**(Grau 3-5)**|**Arsênio + TACE (N=61)**|**TACE (N=64)**|**Ramucirumabe (N=277)**|**Placebo (N=276)**|
|Sangramento n (%)|NR|NR|17 (6)|21 (7)|
|Trombocitopenia n (%)|NR|NR|13 (5)|1 (<1)|
|Vômito n (%)|NR|NR|2 (1)|2 (1)|
|Todos n (%)|NR|NR|100 (36)|79 (29)|  
<mark>Legenda: NR: não relatado.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **Inibidores da proteína quinase e da tirosino quinase** -->
**Tabela AC** – Características dos estudos que avaliaram inibidores da proteína quinase e da tirosino quinase.  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
|**Shao et al.**<br>**2015**<sup>**163**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia de<br>sorafenibe em pacientes<br>com CHC avançado que<br>não receberam tratamento<br>sistêmico prévio.|Quatro ensaios clínicos<br>fase III, totalizando 3.057<br>pacientes|Sorafenibe|Placebo (2 estudos)<br>Brivanibe (1<br>estudo)<br>Sunitinibe (1<br>estudo)|Alto risco de viés<br>(Não avaliou a qualidade dos<br>estudos inclusos, não avaliou<br>viés de publicação)|
|**Zhang et al.**<br>**2012**<sup>**164**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia de<br>sorafenibe em pacientes<br>com CHC avançado que<br>não receberam tratamento<br>sistêmico prévio.|Seis ensaios clínicos, com<br>1164 participantes, sendo<br>três ECR fase III,<br>utilizados na metanálise|Sorafenibe 800<br>mg/dia VO (2<br>estudos)<br>Sorafenibe 800<br>mg/dia VO +<br>doxorubicina 60<br>mg/m2 (1 estudo)|Placebo (2 estudos)<br>Doxorubicina 60<br>mg/m2 (1 estudo)|Baixo risco de viés.|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
||||Pacientes acima de 18<br>anos de idade, com||||
|**Bruix et al.**<br>**2015**<sup>**165**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>202 centros em 28 países<br>(STORM)|Avaliar a eficácia e<br>segurança de sorafenibe em<br>pacientes com resposta<br>completa à ressecação ou<br>ablação do tumor (por<br>radiofrequência ou injeção<br>de etanol)|diagnóstico confirmado<br>de CHC, até três lesões,<br>com Child-Pugh score<br>entre 5–7, ECOG=0, alfa-<br>fetoproteina<400ng/ml, e<br>que foram submetidos<br>com sucesso à ablação ou<br>ressecação do tumor.<br>1114 pacientes foram<br>incluídos.|Sorafenibe 800<br>mg/dia VO|Placebo|Baixo risco de viés.|
||||Pacientes acima de 18<br>anos, com CHC, Child-<br>Pugh escore B ou C,<br>BCLC estágio B ou C,||||
|**Ji et al. 2014**<sup>**166**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>três centros na China|Avaliar a eficácia e<br>segurança de sorafenibe em<br>pacientes com CHC com<br>Child Pugh B ou C.|ECOG <=2, sobrevida<br>estimada >=2 meses,<br>inelegíveis ou com falha<br>prévia a tratamento<br>locorregional e virgens de<br>terapia alvo específica.<br>Foram incluídos 189<br>pacientes.|Sorafenibe 800<br>mg/dia VO|Cuidados paliativos|Risco de viés incerto<br>(Não descreve sigilo de<br>alocação)|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
||||Pacientes acima de 18<br>anos de idade, com||||
||||diagnóstico confirmado||||
||||de CHC não ressecável,<br>escore Child-Pugh A,||||
|**Kudo et al.**<br>**2011**<sup>**167**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>67 centros no Japão e 6 da<br>Coréia do Sul|Avaliar a eficácia e<br>segurança de sorafenibe em<br>pacientes Japoneses e<br>Coreanos com CHC não<br>ressecável e que<br>responderam à TACE|ECOG 0-1, e resposta à<br>TACE durante 1 a 3<br>meses (>=25% melhora<br>nas lesões). 458 pacientes<br>foram incluídos, dos<br>quais 2% já haviam feito<br>uso de terapia sistêmica<br>(interferon, retinoico ou<br>vitamina K2) e 47,8%<br>haviam realizado algum<br>tratamento locorregional.<br>458 pacientes foram<br>incluídos.|Sorafenibe 400<br>mg/dia VO<br>(TACE prévia:<br>lipiodol, epirubicina,<br>cisplatina,<br>doxorubicina e<br>mitomicina)|Placebo<br>(TACE prévia:<br>lipiodol,<br>epirubicina,<br>cisplatina,<br>doxorubicina e<br>mitomicina)|Risco de viés incerto<br>(Não menciona o método de<br>randomização e de garantia<br>do sigilo de alocação)|
||||**Sorafenibe + TACE ou RFA**||||  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
|**Meyer et al.**<br>**2017**<sup>**168**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>20 hospitais do Reino<br>Unido (TACE2)|Avaliar a segurança e<br>eficácia e sorafenibe em<br>combinação com TACE em<br>pacientes com CHC não<br>ressecável.|Pacientes acima de 18<br>anos, com CHC<br>irresecável e não<br>invasivo, escore Child-<br>Pugh A, ECOG 0-1,<br>nunca tratados com<br>quimioterapia sistêmica,<br>embolização ou<br>radioterapia. 313<br>pacientes foram<br>incluídos.|Sorafenibe 800<br>mg/dia VO + DEB-<br>TACE (doxorubicina<br>150 mg)|DEB-TACE<br>(doxorubicina 150<br>mg) + placebo|Baixo risco de viés.|
|**Giorgio et al.**<br>**2016**<sup>**169**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>um centro na Itália|Avaliar a eficácia e<br>segurança de sorafenibe em<br>combinação com ablação<br>por radiofrequência em<br>pacientes cirróticos com<br>CHC e tumor da veia porta.|Pacientes com CHC e<br>tumor de veia porta,<br>virgens de tratamento,<br>com cirrose de fígado<br>Child-Pugh A. Foram<br>incluídos 99 pacientes.|Sorafenibe 800<br>mg/dia VO + RFA<br>(80-100 Watts por 5-8<br>minutos)|Sorafenibe 800<br>mg/dia VO|Risco de viés incerto.<br>Randomização, sigilo da<br>alocação. Risco incerto relato<br>de desfechos incompletos<br>(Não descreve o desfecho<br>primário para o grupo<br>comparador).|
|**Kan et al****_._**<br>**2015**<sup>**170**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>um hospital na China|Avaliar a eficácia e<br>segurança de sorafenibe em<br>combinação com<br>radiofrequência em<br>pacientes com CHC.|Pacientes com uma lesão<br>de CHC medindo entre<br>3.1-5.0 cm de diãmetro,<br>sem história prévia de<br>tratamento, score Child<br>Pugh A ou B, ECOG 0-2,|Sorafenibe 800<br>mg/dia VO + RFA<br>(1500X por 10-15<br>min)|RFA (1500X por<br>10-15 min)|Alto risco de viés. Não relata<br>método de randomização ou<br>sigilo de alocação.|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
||||que não quiseram realizar<br>hepatectomia parcial. Um<br>total de 62 pacientes<br>foram incluídos.||||
||||Pacientes acima de 18<br>anos de idade, com||||
||||diagnóstico confirmado<br>de CHC e elegíveis para||||
|**Hoffmann et**<br>**al.** **2015**<sup>**171**</sup>|Ensaio clínico<br>randomizado, fase III, em 4<br>centros na Alemanha|Avaliar a eficácia e<br>segurança de sorafenibe<br>neoadjuvante em<br>combinação com TACE em<br>pacientes aguardando<br>transplante de fígado.|transplante, sem<br>evidências de invação<br>vascular ou metástase<br>extra-hepática e com<br>índice Karnofsky> 80%.<br>Além disso, os pacientes<br>eram virgens de<br>tratamento sistêmico ou<br>locorregional. 50<br>pacientes foram<br>incluídos.|Sorafenibe 800<br>mg/dia VO + TACE<br>(carboplatina e<br>Lipiodol)|TACE<br>(carboplatina e<br>Lipiodol)<br>+ placebo|Baixo risco de viés.<br>Randomização, sigilo da<br>alocação, cegamento e relato<br>de desfechos incompletos<br>adequados.|
|||Avaliar a segurança e|Pacientes com CHC|Sorafenibe 800|TACE|Alto risco de viés. não cita os|
|**Sansonno et al.**<br>**2012**<sup>**172**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>um centro em Barcelona|eficácia e sorafenibe em<br>combinação com TACE em<br>pacientes com CHC em|estágio B segundo os<br>critérios_Barcelona Clinic_<br>_Liver Cancer,_anti-HCV e|mg/dia VO + TACE<br>(doxorubicina,<br>mitomicina, contraste|(doxorubicina,<br>mitomicina,<br>contraste e lipiodol)|métodos de randomização e<br>de garantir o cegamento dos<br>participantes. Excluiu do|
|||estágio intermediário e|HCV RNA+, escore|e lipiodol)|+ placebo|estudo pacientes com eventos|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
|||hepatite C crônica.|Child-Pugh A_,_ECOG 0-1<br>e sem uso de terapia|||adversos graves.  Além disso,<br>realizou análise de dados|
||||sistêmica alo-específica<br>por pelo menos 1 mês<br>antes do recrutamento.|||apenas para pacientes que<br>completaram o estudo.|
||||80 pacientes foram<br>incluídos.||||
||||**Sunitinibe**||||
|**Cheng et al.**<br>**2013**<sup>**173**</sup>|Ensaio clínico<br>randomizado, fase III,<br>multicêntrico|Avaliar a eficácia e<br>segurança de sunitinibe em<br>pacientes com CHC<br>avançado|Pacientes acima de 18<br>anos, com CHC, Child-<br>Pugh escore A, ECOG 0-<br>1, com pelo menos uma<br>lesão sem tratamento<br>prévio locorregional e<br>virgens de terapia<br>sistêmica. Foram<br>incluídos 1704 pacientes.|Sunitinibe 37,5<br>mg/dia VO|Sorafenibe 800<br>mg/dia VO|Baixo risco de viés.<br>Randomização, sigilo da<br>alocação e relato de desfechos<br>incompletos adequados.<br>Estudo_open-label_, porém<br>com desfechos duros,<br>provavelmente não passíveis<br>de viés pela falta de<br>cegamento.|
||||**Erlotinibe**||||
|**Zhang et al****_._**<br>**2016**<sup>**174**</sup><br>**(Resultados**<br>**apenas do**<br>**estudo fase III**<br>**de Zhu****_et_**|Revisão sistemática sem<br>meta-análise que incluiu<br>apenas um ECR fase III,<br>multinacional, realizado em<br>126 centros na<br>Europa,região Ásia-|Avaliar a eficácia de<br>erlotinibe em pacientes com<br>CHC avançado|Dez ensaios clínicos,<br>sendo nove de fase II e<br>um fase III. Apenas os<br>resultados do ensaio<br>clínico fase III foram<br>descritos neste relatório|Erlotinibe 150 mg VO<br>+ sorafenibe 800<br>mg/dia VO|Sorafenibe 800<br>mg/dia VO|Baixo risco de viés.<br>Randomização, sigilo da<br>alocação, cegamento e relato<br>de desfechos incompletos<br>adequados.|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Sorafenibe**||||
|**_al._2015)**|Pacífico e Américas||(Zhu_et al._2015). Zhu_et_<br>_al._incluíram adultos com<br>CHC avançado que não<br>haviam sido previamente<br>tratados com<br>quimioterapia sistêmica||||
||||**Regorafenibe**||||
||||Adultos com CHC e<br>cirrose confirmada, com<br>pelo menos uma lesão||||
|**Bruix et al.**<br>**2017**<sup>**175**</sup>|Ensaio clínico<br>randomizado, fase III, em<br>152 centros em 21 países<br>(RESORCE)|Avaliar a eficácia e<br>segurança de regorafenibe<br>em pacientes com CHC<br>cuja doença progrediu após<br>o uso de sorafenibe.|mensurável, BCLC B ou<br>C, Child Pugh A, com<br>tumor não ressecável, não<br>elegíveis a tratamentos<br>locorregionais e com<br>progressão radiográfica<br>após uso de sorafenibe.<br>Foram incluídos 573<br>pacientes.|Regorafenibe 160<br>mg/dia VO|Placebo|Baixo risco de viés.<br>Randomização, sigilo da<br>alocação, cegamento e relato<br>de desfechos incompletos<br>adequados.|  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; ECR: Ensaio clínico randomizado; IM: Intramuscular; IV: Intravenoso; NR: Não relatado; TACE: quimioembolização transarterial; V</mark> O: Via oral.  
**Tabela AD** – Características dos pacientes em estudos que avaliaram inibidores da proteína quisase e da tirosino quinase.  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||**Sorafenibe**|||||
||Sorafenibe|1571|Mediana<br>entre<br>estudos de|84-87|Child Pugh A<br>92 a 99<br>ECOG 0-1|HCV: 11 a 29<br>HBV: 11 a 71<br>Álcool: 14 a 26|NR|NR|NR|NR|
|**Shao et**|||51-66||92 a 100||||||
|<br>**al.**<br>**2015**<sup>**163**</sup>|Placebo<br>(2 estudos)||Mediana||Child Pugh A|HCV: 4 a 27|||||
||Brivanibe<br>(1 estudo)|1486|entre<br>estudos de|82-87|92 a 100<br>ECOG 0-1|<br>HBV: 9 a 78<br>|NR|NR|NR||
||Sunitinib||52-66||93 a 100|Álcool: 17 a 26|||||
||(1 estudo)||||||||||
||Sorafenibe<br>(2 estudos)<br>Sorafenibe +<br>|496|Mediana<br>entre<br>estudos de|66-87|Child Pugh A<br>95 a 100<br>ECOG 0-1|NR|NR|NR|NR||
|**Zhang**<br>**et al.**|doxorubicina (1<br>estudo)||51-66||85,1 a 94,6|||||NR|
|**2012**<sup>**164**</sup>|Placebo||Mediana||Child Pugh A||||||
||(2 estudos)<br>Doxorubicina|428|entre<br>estudos de|86-87|96 a 98<br>ECOG 0-1|NR|NR|NR|NR||
||(1 estudo)||52-66||83,7 a 94,7||||||  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||Sorafenibe|556|Mediana: 58<br>(24–85)|81|Child Pugh A:<br>97<br>ECOG 0: 99|HCV: 21<br>HBV: 51<br>Álcool: 9|Mediana: 8,5<br>meses (IQR<br>2,9–19,5)|Mediana (IQR)<br>12·5 (2·6–35·8)|471/556 (85)|Sorafenibe_vs_.<br>Placebo<br>Recorrência do<br>tumor: 165 (30)_vs_.<br>274 (49)|
|||||||||||Evento adverso: 133|
|||||||||||(24)_vs_. 41 (7)|
|||||||||||Retirada de<br>consentimento: 93<br>(17)_vs_. 35 (6)|
|**Bruix et**||||||||||Completou todas as|
|**al.**||||||||||avaliações do|
|**2015**<sup>**165**</sup>||||||||||estudo: 35 (6)_vs_. 65|
||Placebo|558|Mediana: 60<br>(19–83)|83|Child Pugh A:<br>96<br>ECOG 0: 100|HCV: 27<br>HBV: 47<br>Álcool: 8|Mediana: 8,4<br>meses (IQR<br>2,9–19,8)|22,2 (8,1–38,8)|447/558 (80)|(12)<br>Morte: 10 (2)_vs_. 5<br>(<1)|
|||||||||||Progressão clínica:<br>10 (2)_vs_.11 (2)<br>Perda de<br>acompanhamento: 7<br>(1)_vs_. 3 (<1)<br>Outro: 18 (3)_vs_. 13<br>(2)|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||Child Pugh B:<br>76|||||Sorafenibe_vs_.<br>cuidados paliativos|
||Sorafenibe|95|59,4 ± 11,9|85|Child Pugh C:<br>24<br>ECOG 1: 25|HCV: 3<br>HBV: 85|NR|NR|84/95 (88)|Morte: 54 (57)_vs_. 75<br>(80)<br>Retirada de|
||||||ECOG 2: 75|||||consentimento: 12|
||||||BCLC C: 88|||||(13)_vs_. 6 (6)|
|**Ji et al.**||||||||||ECOG 3-4: 5 (5)_vs_.|
|**2014**<sup>**166**</sup>|||||Child Pugh B:|||||0|
||||||74|||||Perda de|
||Cuidados<br>paliativos|94|58,6 ± 12,2|83|Child Pugh C:<br>26<br>ECOG 1: 29|HCV: 2<br>HBV: 82|NR|NR|84/94 (89)|acompanhamento: 1<br>(1)_vs_. 2 (2)<br>Evento adverso: 2|
||||||ECOG 2: 71|||||(2)_vs_. 0|
||||||BCLC C: 87|||||Cross-over: 0_vs_. 1<br>(1)|
|**Kudo et**<br>**al.**|Sorafenibe|229|69|76,0|ECOG 0: 87,8<br>ECOG 1: 122|HCV: 60,7<br>HBV: 20,5|NR|Mediana: 17,1<br>semanas<br>(amlitude 10–|205/229 (89,5)|Sorafenibe_vs_.<br>Placebo<br>Progressão da|
|**2011**<sup>**167**</sup>|||||,|Álcool: 8,3||p ,<br>112,1)||doença:  104 (45,4)<br>_vs_. 177 (77,3)|  
<!-- Start of picture text -->
Tempo de<br>Detalhes da<br>Autor,  Idade em  Sexo M  Grau do  Tempo de  tratamento,  Suspensão n/N  Razão para<br>Intervenção/  N  Etiologia (%)<br>ano  anos  (%)  carcinoma (%)  seguimento  mediana (mín- (%)  suspensão n (%)<br>comparador<br>máx)<br>Evento adverso: 93<br>(40,6)  vs . 13 (5,7)<br>Retirada de<br>consentimento: 6<br>(2,6)  vs . 3 (1,3)<br>Mediana: 20,1  Perda de<br>HCV: 64,6<br>Placebo   ECOG 0: 88,2  semanas  acompanhamento: 1<br>229  70  73,4  HBV: 22,7  NR  197/229 (86,0)<br>ECOG 1: 11,8  (ampliude 2,1– (<1)  vs . 0<br>Álcool: 5,2<br>144,1)  Violação do<br>protocolo: 1 (<1)  vs .<br>2 (<1)<br>Decisão do<br>investigador: 0  vs . 2<br>(<1)<br>Sorafenibe + TACE ou RFA<br>HCV: 12  Sorafenibe + DEB-<br>HBV: 5  Suspensão  TACE  vs . DEB-<br>Child pugh A:  Álcool: 34  precoce:  TACE+ Placebo<br>Meyer  Mediana: 620<br>Sorafenibe +  Mediana: 65  93  HCV e álcool: 8  120 dias (IQR  68/157 (43,3)  Toxicidade: 27<br>et al.  157  89  dias (IC95%<br>DEB-TACE  (IQR 57–71)  ECOG 0: 62  HBV e álcool: 2  43–266)  Perda de  (17,2)  vs .  9 (5,7)<br>2017 168 572–784)<br>ECOG 1: 37  HCV e HBV: 2  acompanhamento:   Evento adverso: 3<br>HCV, HBV e  16/157 (10,2)  (1,9)  vs . 7 (4,5)<br>álcool: 2  Retirada de<br><!-- End of picture text -->  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||DEB-TACE|156|Mediana: 68<br>(IQR 63–74)|88|Child pugh A:<br>95<br>ECOG 0: 62<br>ECOG 1: 37|HCV: 7<br>HBV: 6<br>Álcool: 33<br>HCV e álcool:<br>10<br>HBV e álcool: 2<br>HCV, HBV e<br>álcool: 2<br>HCV e HBV: 2||162 dias (IQR<br>70–323)|Suspensão<br>precoce: 40/156<br>(25,6)<br>Perda de<br>acompanhamento:<br>15/156 (9,6)|<br>consentimento:  28<br>(17,8)_vs_. 6 (3,8)<br>Violação do<br>protocolo: 2 (1,2)_vs_.<br>3 (1,9)<br>Outra neoplasia: 1<br>(<1)_vs_. 1 (<1)<br>Outros: 21 (13,4)_vs_.<br>28 (17,9)<br>Não relatado: 2 (1,3)<br>_vs_. 1 (<1)|
|**Giorgio**<br>**et al.**|Sorafenibe +<br>RFA|49|Mediana: 71<br>(amplitude<br>69-75)|75,5|Child Pugh A5:<br>51<br>Child Pugh A6:<br>49|HCV: 65,3<br>HBV: 32,6|36 meses<br>(amplitude 6-<br>42)|RFA 1,9 sessões<br>(amplitude 1-3)|10/49 (20)|NR|
|**2016**<sup>**169**</sup>|Sorafenibe|50|Mediana: 72<br>(amplitude<br>70-76)|72,0|Child Pugh A5:<br>52<br>Child Pugh A6:<br>48|HCV: 54,0<br>HBV: 34,0|36 meses<br>(amplitude 5-<br>41)||12/50 (24)||
|**Kan et**<br>**al.**<br>**2015**<sup>**170**</sup>|Sorafenibe +<br>RFA|30|53,7 ± 9,6|80|Child Pugh A:<br>40,0<br>ECOG 0: 16,6<br>ECOG 1: 76,7|Hepatite B<br>crônica: 90,3<br>Hepatite C<br>crônica: 9,7|NR|NR|NR|NR|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||ECOG 2: 6,7<br>BCLC estágio<br>C: 73,3|Não estratifica<br>por grupo|||||
||||||Child Pugh A:<br>43,8||||||
||RFA|32|52,4 ± 8,9|78,1|ECOG 0: 18,8<br>ECOG 1: 65,6<br>ECOG 2: 15,6||NR|NR|NR||
||||||BCLC estágio||||||
||||||C: 56,4||||||
||Sorafenibe +<br>TACE|24|Mediana:<br>58,5<br>(amplitude<br>44,0-66,0)|45 (90)<br>Não<br>estratific<br>a por<br>grupo|Child pugh A:<br>58,3|HCV: 45,8<br>HBV: 12,5<br>Álcool: 29,1|320 dias|125 dias|18/24(75,0)|Sorafenibe+TACE<br>_vs_. TACE+Placebo<br>Descontinuou a<br>intervenção: 9 (37,5)<br>_vs_. 8 (30,7)|
|**Hoffma**||||||||||Evento adverso: 0|
|**nn et al.**||||||||||_vs_. 2 (7,6)|
|**2015**<sup>**171**</sup>|TACE +<br>placebo|26|Mediana:<br>58,0<br>(amplitude<br>43,0-69,0)||Child pugh A:<br>76,9|HCV: 26,9<br>HBV: 11,5<br>Álcool: 42,3|NR|171 dias|16/26 (61,5)|Retirada de<br>consentimento: 6<br>(25,0)_vs_.  4 (15,3)<br>Morte: 1 (4,1)_vs_. 1<br>(3,8)<br>Violação do|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||protocolo: 2 (8,3)_vs_.|
|||||||||||1 (3,8)|  
||Sorafenibe +<br>TACE|40|73 ± 4|58|Child pugh A:<br>100<br>ECOG 0: 86|HCV:100|NR|NR|9/40 (22,5)|Sorafenibe+TACE<br>_vs_. TACE+Placebo<br>Evento adverso: 8|
|---|---|---|---|---|---|---|---|---|---|---|
|**S**|||||ECOG 1: 24|||||(20)_vs_.  0|
|**anson**<br>**no et al.**<br>**2012**<sup>**172**</sup>|||||Child pugh A:|||||Retirada de<br>consentimento: 1|
||TACE +<br>placebo|40|72,8 ± 6,4|61|100<br>ECOG 0: 77|HCV:100|NR|NR|9/40 (22,5)|(2,5)_vs_.  3 (7,5)<br>Violação do|
||||||ECOG 1: 23|||||protocolo: 0_vs_. 6<br>(15)|
|||||||**Sunitinibe**|||||  
Sunitinibe _vs_ . Sorafenibe Progressão/recorrênc ia: 277 (52,7) _vs_ . Child Pugh A: 270 (49,8) Mediana: Sunitinibe: 7,4 4 ciclos **Cheng** 99,8 HCV: 21,3 Morte: 92 (17,5) _vs_ . 59,0 meses Intensidade de **et al.** Sunitinibe 530 82,3 ECOG 0: 52,5 HBV: 54,7 506/526 (96) 83 (15,3) (amplitude Sorafenibe: 7,8 dose relativa **2013**<sup>**173**</sup> ECOG 1: 46,8 Álcool: 17,2 Evento adverso:  70 18-85) meses (mRDI): 66,6% BCLC C: 87,2 (13,3) _vs_ .  69 (12,7) Retirada de consentimento: 30 (5,7) _vs_ . 40 (7,4) Outro: 16 (3,0) _vs_ .  
**Tempo de Detalhes da Autor, Idade em Sexo M Grau do Tempo de tratamento, Suspensão n/N Razão para Intervenção/ N Etiologia (%) ano anos (%) carcinoma (%) seguimento mediana (mín(%) suspensão n (%) comparador máx)** 13 (2,4) Estudo interrompido pelo patrocinador: 10 (1,9) _vs_ .  0 Deteriorização do estado de saúde global: 6 (1,1) _vs_ .  6 (1,1) Child Pugh A: Perda de Mediana: 4 ciclos 99,4 HCV: 21,9 acompanhamento: 3 59,0 Intensidade de Sorafenibe 544 84,4 ECOG 0: 52,9 HBV: 52,9 493/542 (91) (0,6) _vs_ . 6 (1,1) (amplitude dose relativa ECOG 1: 46,7 Álcool: 15,1 Violação do 18-84) (mRDI): 71,3% BCLC C: 83,5 protocolo:  2 (0,4) _vs_ . 6 (1,1)  
|||||||**Erlotinibe**|||||
|---|---|---|---|---|---|---|---|---|---|---|
|**Zhang**|||||Child Pugh:|||||**Erlotinibe +**|
|**et al.**|||||5: 68,0|||||**sorafenibe****_vs_. **|
|**2016**<sup>**174**</sup><br>**(Zhu et**|Erlotinibe +<br>sorafenibe|362|60,5|81,5|6: 30,4<br>BCLC:|HCV: 29,6<br>HBV: 33,7|NR|86 dias|343/362 (95)|**sorafenibe:**<br>Evento adverso: 117|
|**al.**|||||B: 16,6|||||(32)_vs_. 123 (34)|
|**2015)**|||||C: 83,4|||||Retirada de|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção/**<br>**comparador**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma (%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||consentimento: 26<br>(7)_vs_. 24 (7)|
|||||||||||Morte: 31 (8,5)_vs_.<br>17 (5)|
|||||||||||Progressão da|
|||||||||||doença, recorrência:|
||||||Child Pugh:|||||155 (43)_vs_. 156 (4)|
||||||5: 70,4|||||Retirado a critério|
||Sorafenibe|358|60|79,9|6: 26,0<br>BCLC:|HCV: 23,5<br>HBV: 37,2|NR|123 dias|337/358 (94)|do pesquisador:  2<br>(<1)_vs_. 2 (<1)|
||||||B: 13,4|||||Perda de|
||||||C: 86,6|||||acompanhamento: 3<br>(<1)_vs_. 5 (1)|
|||||||||||Quebra do|
|||||||||||protocoloco: 8 (2)<br>_vs_. 9 (2)|
|||||||||||Dado faltante: 1 (<1)|
|||||||||||_vs_. 1 (<1)|
|**Regorafeni**|**be**||||||||||
|**Bruix et**<br>**al.**<br>**2017**<sup>**175**</sup>|Regorafenibe|379|Mediana: 64<br>(IQR 54–71)|88|Child Pugh A:<br>98<br>ECOG 0: 65<br>ECOG 1: 35|HCV: 21<br>HBV: 38<br>Álcool: 24|Mediana: 7,0<br>meses (IQR<br>3,7–12,6)|3,6 meses (IQR<br>1,6–7,6)<br>Dose média/dia:<br>144,1 mg (SD|309/374 (83)|Regorafenibe_vs_.<br>placebo<br>Progressão/recorrênc<br>ia: 226 (60,0)_vs_.|  
**Tempo de Detalhes da Autor, Idade em Sexo M Grau do Tempo de tratamento, Suspensão n/N Razão para Intervenção/ N Etiologia (%) ano anos (%) carcinoma (%) seguimento mediana (mín(%) suspensão n (%) comparador máx)** BCLC C: 86 21,3) 162 (84,0) Eventos adversos: 48 (12,8) _vs_ . 12 (6,2) Suspensão pelo paciente: 26 (7,0) _vs_ . 5 (2,6) Child Pugh 1,9 meses Mediana Violação do A: 97 HCV: 21 (1,4–3,9) 19 : 62 protocolo:  1 (<0,1) Placebo 88 ECOG 0: 67 HBV: 38 Dose média: 183/193 (95) 4 (IQR _vs_ . 3 (1,6) ECOG 1: 33 Álcool: 28 157,4 mg 55–68) Morte: 5 (1,3) _vs_ .  0 BCLC C: 89 (10,3) Outros: 3 (<0,1) _vs_ . 1 (<0,1)  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; RFA: Ablação por radiofrequência; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control._  
**Tabela AE** – Desfechos de eficácia dos estudos que avaliaram inibidores da proteína quinase e da tirosino quinase.  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevid**<br>**a intervenção**<br>**[mortalidade: n/N**<br>**Mortalidade/Sobrevid**<br>**a controle**<br>**[mortalidade: n/N**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até resposta**<br>**intervenção**<br>**(mediana em meses)**|**Tempo até**<br>**resposta controle**<br>**(mediana em**|**p-valor**|
|---|---|---|---|---|---|---|---|---|
||**(%), sobrevida:**<br>**mediana em meses]**<br>**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
|**Sorafenibe**|||||||||
|**Shao et**<br>**al.**<br>**2015**<sup>**163**</sup>|Sorafenibe vs. todos comparadores: HR: 0,81<br>(IC95% 0,74–0,89)<br>**Análise de subgrupo (HR):**<br>HCV+: 0,65 (0,53, 0,80)_vs_, HCV-: 0,87 (0,79,<br>0,96); p = 0,013|NR|NR||NR|NR||NR|
||HBV+: 0,92 (0,82–1,05)_vs_HCV+: 0,65 (0,53,<br>0,80); p = 0,005||||||||
||Asiáticos (HR=0,85)_vs_, Não-asiáticos (HR=0,75):<br>p = 0,183||||||||
||ECOG PS 0 (HR=0,84)_vs_, ECOG PS 1 or 2<br>(0,81); p= 0,699<br>Invasão macrovascular (HR=0,87) ou extra-<br>hepática(sim) _vs_, (não) (HR=0,75):p= 0,221||||||||
|**Zhang**<br>**et al.**|HR: 0,66 (IC95%: 0,56-0,78; I<sup>2</sup>=0%)<br>Análise de subgrupo (HR):|p<0,001|RP (Redução de pelo<br>soma do maior diâm|menos 30% na<br>etro das lesões|p=0,06|Tempo até a p<br>HR: 0,57 (IC95% 0,|rogressão:<br>47-0,68; I<sup>2</sup>=0%)|p<0,001|
|**2012**<sup>**164**</sup>|ECOG 0: 0,70 (0,52-0,94)<br>ECOG 1-2: 0,67 (0,53-0,84)<br>Invasão macrovascular (Sim):  0,66 (0,57-0,81)<br>Invasão macrovascular (Não):  0,70 (0,55-0,90)<br>Manifestação extra-hepática (Não): 0,53 (0,39-<br>0,70)||avaliada<br>OR: 2,96 (IC95% 0,96|s)<br>-9,15; I<sup>2</sup>; =0%)|||||  
|**Autor,**|<br>**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até resposta**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|**ano**|**a intervenção**|**a controle**||**intervenção, n/N**|**controle, n/N**||**intervenção**|**resposta controle**||
||**[mortalidade: n/N**|**[mortalidade: n/N**||**(%)**|**(%)**||**(mediana em meses)**|**(mediana em**||
||**(%), sobrevida:**|**(%), sobrevida:**||||||**meses)**||
||**mediana em meses]**|**mediana em meses]**||||||||  
Em pacientes com alanina aminotransferase  
normal, bilirubina elevada ou  
manifestação extra-hepáticas não houve diferença  
entre os grupos sorafenibe e placebo (p>0,05)  
|**Bruix et**|Sobrevida global: 23,0|Sobrevida global: 22,0|p=0,48|NR|NR|NA|Tempo até|Tempo até|p=0,12|
|---|---|---|---|---|---|---|---|---|---|
|**al.**|meses (IQR 12,7–36,0)|meses (IQR 14·4–35·5)|||||progressão:|progressão:||
|**2015**<sup>**165**</sup>|||||||38,5 meses (IC95%|35,8 meses||
||Sobrevida global:||||||30,4–não estimável)|(IC95% 30,3–||
||HR: 0,995 (IC95%||||||HR: 0,891|41,4)||
||0,761–1,300)||||||(IC95% 0,735–|||
|||Sobrevida livre de|||||1,081); p=0,12|||
||Sobrevida livre de|evento: 33,7 meses|p=0,26|||||||
||evento: 33,3 meses|(27,6–39,0)||||||||
||(IC95% 27,6–44,0)|||||||||
||Sobrevida livre de|||||||||
||evento:|||||||||
||HR: 0,940 (IC95%|||||||||
||0,780–1,134)|||||||||
|**Ji et al.**|Sobrevida global: 4,0|Sobrevida global: 3,5|p<0,001|RP: 1 (1%)|RP: 0|p =0,996|NR|NR|NR|
|**2014**<sup>**166**</sup>|meses|meses||||||||
||HR morte: 0, 48|||||p =0,055||||  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevid**<br>**a intervenção**<br>**[mortalidade: n/N**|**Mortalidade/Sobrevid**<br>**a controle**<br>**[mortalidade: n/N**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até resposta**<br>**intervenção**<br>**(mediana em meses)**|**Tempo até**<br>**resposta controle**<br>**(mediana em**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
||(IC95% 0,35-0,68)|||DE: 41 (43,2%)|DE: 27 (28,7%)|p =0,039||||
||Sobrevida livre de|Sobrevida livre de|p=0,002|||||||
||evento:  2,2 meses|evento: 1,9 meses||Taxa de controle da|Taxa de|||||
||HR progressão: 0,55|||doença: 44 (44,2%)|controle da|||||
||(IC95% 0,40-0,75)||||doença: 27|||||
||||||(28,7%)|||||
|**Kudo et**|Mortalidade: 43|Mortalidade: 41|p=0,79||||Tempo até a|Tempo até a|p=0,25|
|**al.**|(18,7%)|(17,9%)|||||progressão:|progressão:||
|**2011**<sup>**167**</sup>|||||||5,4 meses (IC95%|3,7 meses (IC95%||
||||||||3,8–7,2)|3,5–4,0)||
||Sobrevida global:|Sobrevida livre de|NR||||HR:0,87 (IC95%|||
||HR: 1,06 (IC95% 0,69–|evento em três meses:|||||0,70–1,09)|||
||1,64)|58,7%||||||||
||Sobrevida livre de|Sobrevida livre de||||||||
||evento em três meses:|evento em seis meses:|NR|||||||
||65,0%|33,5%||||||||
||Sobrevida livre de|Sobrevida global em 1|NR|||||||
||evento em seis meses:<br>45,7%|ano: 94,1%||||||||  
|**Autor,**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até resposta**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|**ano**|**a intervenção**|**a controle**||**intervenção, n/N**|**controle, n/N**||**intervenção**|**resposta controle**||
||**[mortalidade: n/N**|**[mortalidade: n/N**||**(%)**|**(%)**||**(mediana em meses)**|**(mediana em**||
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
||Sobrevida global em 1<br>ano: 94,6%|Sobrevida global em 2<br>anos: 73,8%|NR|||||||
||Sobrevida global em 2<br>anos: 72,1%|||**Sorafenibe + TACE**|**ou RFA**|||||
|**Meyer**|Sobrevida global: 631|Sobrevida global:  598||**Resposta pelo**|**Resposta pelo**|NR|Tempo até a|Tempo até a||
|**et al.**|dias (IC95% 473–879)|dias (IC95% 500–697)||**RECIST v1.1:**|**RECIST v1.1:**||progressão: 326 dias|progressão:  320||
|**2017**<sup>**168**</sup>|Sobrevida global:|||RC: 4 (3%)|RC: 5 (3%)||(IC95% 240–410)|dias (IC95% 234–||
||HR: 0,91 (IC95% 0,67–||p=0,57|RP: 52 (33%)|RP: 44 (28%)||HR: 0,88 (IC95%|400)||
||1,24)|||DE: 61 (39%)|DE: 72 (46%)||0,67–1,17)||p=0,38|
||Sobrevida livre de|Sobrevida livre de||PD: 15 (10%)|PD: 17 (11%)|||||
||progressão:  238 dias|progressão:  235 dias|p=0,94|Taxa de Resposta|Taxa de|||||
||(IC95% 221–281)|(IC95% 209-322)||Objetiva: 56 (36%)|Resposta|||||
|||||Taxa de controle da|Objetiva:  49|||||
||Sobrevida livre de|||doença: 117 (75%)|(31%)|||||
||progressão:||||Taxa de|||||
||HR: 0,99 (IC95% 0,77–||||controle da|||||
||1,27)||||doença: 121|||||
||||||(78%)|||||  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevid**<br>**a intervenção**<br>**[mortalidade: n/N**|**Mortalidade/Sobrevid**<br>**a controle**<br>**[mortalidade: n/N**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até resposta**<br>**intervenção**<br>**(mediana em meses)**|**Tempo até**<br>**resposta controle**<br>**(mediana em**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
|**Giorgio**|Sobrevida global em 1|Sobrevida global em 1|p<0,001|NR|NR|NR|NR|NR|NR|
|**et al.**|ano: 60%|ano: 37%||||||||
|**2016**<sup>**169**</sup>||||||||||
||Sobrevida global em 2<br>anos: 35%<br>Sobrevida global em 3<br>anos: 26%<br>HR: 2,87 (IC95% 1,61-<br>5,39)|Sobrevida global em 2<br>anos: 0%||||||||
|**Kan et**|NR|NR||Recorrência do|Recorrência do|p<0,01|Tempo até a|Tempo até a|p<0,05|
|**al****_._**||||tumor: 17 (56,7%)|tumor: 28||progressão: 17,0|progressão: 6,1||
|**2015**<sup>**170**</sup>|||||(87,5%)||meses|meses||
|**Hoffma**|Sobrevida livre de||NR|RC 1 (4,3%)|RC 0|NR|Tempo até a|Tempo até a||
|**nn et al****_._**|progressão:|<0.05||RP 4 (17,4%)|RP 7 (26,9%)||progressão: 71 dias|progressão:  85||
|**2015**<sup>**171**</sup>|HR: 1,259 (IC95%|||DE 11 (47,8%)|DE  12 (46,2%)||(amplitude: 1 a 394|dias (amplitude: 1||
||0,485 - 3,270)|||PD 7 (30,4%)|PD 7 (26,9%)||dias)<br>HR: 1,106 (IC95%|a 405 dias)|<0,05|
|||||Taxa de Resposta|Taxa de||0,387 - 3,162)|||
|||||Objetiva: 20,8%|Resposta|||||
|||||(IC95% 7,1 - 42,2)|Objetiva:|||||
||||||26,9% (IC95%:||Tempo até transplante|Tempo até|<0,05|
||||||11,6 - 47,8)||de fígado: 153 dias|transplante de||  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevid**<br>**a intervenção**<br>**[mortalidade: n/N**|**Mortalidade/Sobrevid**<br>**a controle**<br>**[mortalidade: n/N**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até resposta**<br>**intervenção**<br>**(mediana em meses)**|**Tempo até**<br>**resposta controle**<br>**(mediana em**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
|||||Taxa de controle da|Taxa de||(amplitude 31 a 339<br>dias)|fígado: 174 dias<br>(amplitude: 37 a||
|||||doença: 66,7%|controle da||HR: 0,575 (IC95%:|315 dias)||
|||||(IC95%: 44,7 - 84,4)|doença: 73,1%<br>(IC95%: 52,2 -<br>88,4)||0,192, 1,721)|||
|**Sanson**<br>**no et**|NR|NR|NA|Progressão do tumor:<br>21 (68%)|Progressão: 31<br>(100%)|NR|Tempo até a<br>progressão: 9,2 DP|Tempo até a<br>progressão: 4,9|p<0,001|
|**al.2012**<sup>**1**</sup>|||||||5,8|DP 3,2||
|**72**||||Recorrência do tumor|Recorrência em|p=|HR: 2,5 (IC95% 1,66|||
|||||em 6 meses: 7 (22%)|6 meses:<br>22(71%)|0,005|–7,56)|||
|||||Progressão local do<br>tumor: 14 (45%)|Progressão local<br>do tumor: 16<br>(52%)|p=0,3||||
|||||Progressão||||||
|||||metacrônica,|Progressão|p=0,05||||
|||||multicêntrica: 7<br>(22%)|metacrônica,<br>multicêntrica:<br>15 (48%)|||||  
|**Autor,**<br>**ano**|**Mortalidade/Sobrevid**<br>**a intervenção**<br>**[mortalidade: n/N**|**Mortalidade/Sobrevid**<br>**a controle**<br>**[mortalidade: n/N**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até resposta**<br>**intervenção**<br>**(mediana em meses)**|**Tempo até**<br>**resposta controle**<br>**(mediana em**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
|||||**Sunitinibe**||||||
|**Cheng**|Sobrevida global: 7,9|Sobrevida global: 10,2|p=0,001|Taxa de benefício|Taxa de||Tempo até a|Tempo até a|p=0,308|
|**et al.**|meses (IC95% 7,4-9,2)|meses (IC95% 8,9-||clínico: 267 (50,8%)|benefício|p=0,816|progressão:  4,1|progressão:  3,8||
|**2013**<sup>**173**</sup>|HR morte: 1,30 (1,13,|11,4)|||clínico: 280||meses (IC95% 3,2-4,1|meses (IC95%||
||1,50)||||(51,5%)||meses)|2,9-4,2 meses)||
|||||RC: 2 (<1%)|||HR: 1,13 (IC95%|||
||Sobrevida livre de|Sobrevida livre de||RP: 33 (6,2%)|RC: 1 (<1%)||0,98-1,31)|||
||progressão: 3,6 meses|progressão: 3,0 meses|p=0,228|DE: 232 (43,8%)|RP: 32 (5,9%)|||||
||(IC95% 2,8-4,1)|(IC95% 2,8-4,0)|||DE: 247|||||
||HR: 1,13 (IC95% 0,99-||||(45,4%)|||||
||1,30)|Sobrevida livre de<br>progressão em 6 meses:||||||||
||Sobrevida livre de|26,0%||||||||
||progressão em 6 meses:|||||||||
||21,5%|||||||||
|||||**Erlotinibe**||||||
|**Zhang**|Sobrevida global: 9,5|Sobrevida global: 8,5|p= 0,408|Progressão da doença|Progressão da|p=0,102|Tempo até a|Tempo até a|p=0,18|
|**et al.**|meses|meses||após 28 dias: 138/362|doença após 28||progressão:  3,2|progressão: 4||
|**2016**<sup>**174**</sup>|HR= 0.929 (IC95%|||(38,1%)|dias: 119/358||meses|meses||
|**(Zhu et**|0,781 – 1,106)||||(33,2%)||HR= 1.135 (95% CI,|||
|**al.**|||||||0.944; 1.366)|||
|**2015)**|Sobrevida livre de|||Resposta global ao|Resposta global|p=0,102||||  
|**Autor,**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até resposta**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|**ano**|**a intervenção**<br>**[mortalidade: n/N**|**a controle**<br>**[mortalidade: n/N**||**intervenção, n/N**<br>**(%)**|**controle, n/N**<br>**(%)**||**intervenção**<br>**(mediana em meses)**|**resposta controle**<br>**(mediana em**||
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||||**meses)**||
||progressão: HR= 1,111|||tratamento (Parcial +|ao tratamento|||||
||(IC95% 0,941-1,311)|||completa) após 28|(Parcial +|||||
|||||dias: 24/362 (6,6%)|completa) após|||||
||||||28 dias: 14/358<br>(3,9%)|||||
|||||Estabilização do<br>tumor em três meses:<br>135/362 (37,3%)|Estabilização do<br>tumor em três<br>meses: 174/358<br>(48,6%)|||||
|||||Taxa de controle da<br>doença: 159/362|Taxa de<br>controle da|p=0,021||||
|||||(43,9%)|doença: 188/358<br>(52,5%)|||||
|||||**Regorafenibe**||||||
|**Bruix et**|Sobrevida global: 10,6|Sobrevida global: 7,8||RC: 2 (1%)|RC: 0||Tempo até a|Tempo até a||
|**al.**|meses (IC95% 9,1-|meses (6,3–8,8)||RP: 38 (10%)|RP: 8 (4%)||progressão: 3,2 meses|progressão:   1,5||
|**2017**<sup>**175**</sup>|12,1)||p<0,000|DE: 206 (54%)|DE: 62 (32%)||(IC95% 2,9–4,2)|meses (1,4–1,6)||
||HR:  0,63 (IC95%||1|PD: 86 (23%)|PD: 108 (56%)||HR: 0,44 (IC95%|||
||0,50–0,79)||||||0,36–0,55)||p<0,001|  
|**Autor,**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até resposta**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|**ano**|**a intervenção**|**a controle**||**intervenção, n/N**|**controle, n/N**||**intervenção**|**resposta controle**||
||**[mortalidade: n/N**|**[mortalidade: n/N**||**(%)**|**(%)**||**(mediana em meses)**|**(mediana em**||
||**(%), sobrevida:**|**(%), sobrevida:**||||||**meses)**||
||**mediana em meses]**|**mediana em meses]**||||||||
|||||Taxa de Resposta|Taxa de|p=0,004||||
||Sobrevida livre de|Sobrevida livre de||Objetiva: 40 (11%)|Resposta|7||||
||progressão: 3,1 meses|progressão: 1,5 meses|||Objetiva: 8|||||
||(IC95% 2,8–4,2)|(1,4–1,6)|||(4%)|||||
||HR: 0,46 (IC95% 0,37–||p<0,000|Taxa de controle da||||||
||0,56)||1|doença: 247 (65%)|Taxa de|p<0,000||||
||||||controle da|1||||
||||||doença: 70<br>(36%)|||||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença; R</mark> C: Resposta completa; RP: Resposta parcial; <mark>RFA: Ablação por radiofrequência; TACE: quimioembolização transarterial; R</mark> R: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio;_ DP: desvio padrão.  
**Tabela AF** – Eventos adversos dos estudos que avaliaram inibidores da proteína quisase e da tirosino quinase.  
|**Eventos adversos**|**Zhang et al.**<br>**2012**<sup>**164**</sup>|**Bruix et a**|**l.** **2015**<sup>**165**</sup>|**Ji et al.**|**2014**<sup>**166**</sup>|**Kudo et al.** <br>|**2011**<sup>**167**</sup><br>|**Meyer et al**<br>|**.** **2017**<sup>**168**</sup><br>|**Kan et al.**|**2015**<sup>**170**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**(Grau 3-5)**|**Sorafenibe**|**Sorafenibe**|**Placebo**|**Sorafenib**|**Paliativo**|**Sorafenibe**<br>|**TACE+**<br>|**Sorafenibe +**<br>|**DEB-**<br>|**Sorafenibe +**|**RFA**|
||**RR (IC95%)**|**(N=559)**|**(N=548)**|**e (N=89)**|**(N=91)**|**+TACE**<br>**(N=40)**|**Placebo**<br>**(N=40)**|**DEB-TACE**<br>**(N=229)**|**TACE**<br>**(N=227)**|**RFA (N=30)**|**(N=32)**|
|Alopecia n (%)|NR|NR|NR|0|0|0|0|0|0|9<sup>§</sup>(30)|0|
|Anemia n (%)|NR|NR|NR|1 (1,1)|0|NR|NR|NR|NR|NR|NR|
|Anorexia n (%)|0,78 (0,21-2,89)|NR|NR|1 (1,1)|1 (1,1)|1 (2,5)|2 (2,5)|NR|NR|NR|NR|
|Ascite n (%)|NR|1 (<1)|0|NR|NR|NR|NR|NR|NR|NR|NR|
|Azia n (%)|NR|1 (<1)|0|NR|NR|NR|NR|NR|NR|NR|NR|
|Cefaleia n (%)|NR|1 (<1)|0|NR|NR|NR|NR|NR|NR|NR|NR|
|Diarreia n (%)|3,56 (2,03-6,26)|34 (6)|2 (<1)|5 (5,6)|1 (1,1)|1 (2,5)|3 (7,5)|14 (6)|2 (1)|14<sup>§</sup>(47)|0|
|Dispneia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor abdominal n<br>(%)|NR|6 (1)|0|NR|NR|NR|NR|NR|NR|NR|NR|
|Fadiga n (%)|1,93 (1,15-3,27)|9 (1,6)|2 (<1)|NR|NR|3 (7,5)|2 (2,5)|NR|NR|12<sup>§</sup>(40)|0|
|Ginecomastia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hiperglicemia n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hipertensão n (%)|2,31 (0,66-8,05)|24 (4)|6 (1)|NR|NR|0|0|34 (15)|2 (1)|4<sup>§</sup>(13)|0|
|Infecção n (%)|NR|0|0|NR|NR|NR|NR|NR|NR|NR|NR|
|Leucopenia n (%)|NR|NR|NR|0|0|NR|NR|NR|NR|NR|NR|
|Morte n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Náusea n (%)|0,85 (0,28-2,56)|1 (<1)|0|NR|NR|1 (2,5)|0|NR|NR|NR|NR|
|Neutropenia n (%)|NR|NR|NR|0|0|NR|NR|NR|NR|NR|NR|
|Outros n (%)|NR|46 (8,2)|13 (2,3)|4 (4,4)|1 (1,1)|3 (7,5)|0|183 (80)|36 (16)|NR|NR|  
|**Eventos adversos**|**Zhang et al.**<br>**2012**<sup>**164**</sup>|**Bruix et a**|**l.** **2015**<sup>**165**</sup>|**Ji et al.**|**2014**<sup>**166**</sup>|**Kudo et al.** <br>|**2011**<sup>**167**</sup><br>|**Meyer et al**<br>|**.** **2017**<sup>**168**</sup><br>|**Kan et al.**|**2015**<sup>**170**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**(Grau 3-5)**|**Sorafenibe**<br>**RR (IC95%)**|**Sorafenibe**<br>**(N=559)**|**Placebo**<br>**(N=548)**|**Sorafenib**<br>**e (N=89)**|**Paliativo**<br>**(N=91)**|**Sorafenibe**<br>**+TACE**<br>**(N=40)**|**TACE+**<br>**Placebo**<br>**(N=40)**|**Sorafenibe +**<br>**DEB-TACE**<br>**(N=229)**|**DEB-**<br>**TACE**<br>**(N=227)**|**Sorafenibe +**<br>**RFA (N=30)**|**RFA**<br>**(N=32)**|
|Rash n (%)|6,22 (1,44-26,89)|16 (2,8)|0|5 (5,6)|0|4 (10)|0|9 (4)|0|NR|NR|
|Reação mãos e pés<br>n (%)|25,32 (6,15-<br>104,09)|154 (28)|4 (<1)|||4 (10)|0|80 (35)|0|25<sup>§</sup>(83)|0|
|Reação no local de<br>aplicação n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Rubor n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Sangramento n (%)|1,25 (0,36-4,30)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Trombocitopenia n<br>(%)|NR|NR|NR|NR|NR|NR|NR|29 (13)|2 (1)|NR|NR|
|Vômito n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Todos n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|4,3 (14,6)|0|  
<mark>Legenda:</mark><sup>§</sup> <mark>E</mark> ventos adversos reportados sem estratificação de grau; NR: não relatado.  
**Tabela AG** – Eventos adversos de outros estudos que avaliaram inibidores da proteína quisase e da tirosino quinase.  
|**Eventos adversos**|**Hoffmann et**|**al.** **2015**<sup>**§171**</sup><br>|**Sansonno et**<br>|**al.** **2012**<sup>**172**</sup><br>|**Cheng et**|**al.** **2013**<sup>**173**</sup><br>|**Zhang et a**<br>**(Zhu et a**<br>|**l.** **2016**<sup>**174**</sup><br>**l****_._2015)**|**Bruix et a**|**l.** **2017**<sup>**175**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|**(Grau 3-5)**|**Sorafenibe +**|**TACE+**<br>|**Sorafenibe**<br>|**TACE+**<br>|**Sunitinibe**|**Sorafenib**<br>|**Erlotinibe +**<br>|**Sorafenibe**|**Regorafenibe**|**Placebo**|
||**TACE (N=24)**|**Placebo**<br>**(N=25)**|**+TACE**<br>**(N=157)**|**Placebo**<br>**(N=156)**|**(N = 526)**|**e**<br>**(N =542)**|**sorafenibe**<br>**(N=362)**|**(N=358)**|**(N= 374)**|**(N=193)**|
|Alopecia n (%)|1<sup>§</sup>(4,2)|0|1 (1)|0|0|1 (0,2)|0|0|NR|NR|
|Anemia n (%)|NR|NR|NR|NR|49 (9,3)|22 (4,0)|NR|NR|6 (1)|1(1)|
|Anorexia n (%)|NR|NR|3 (2)|2 (1)|NR|NR|15 (4,1)|20 (5,6)|10 (3)|12 (6)|
|Ascite n (%)|NR|NR|NR|NR|27 (5,2)|18 (3,3)|35 (9,7)|31 (8,7)|3 (1)|1 (1)|
|Azia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Cefaleia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Diarreia n (%)|9<sup>§</sup>(37,5)|3<sup>§</sup>(12)|16 (11)|4 (3)|38 (7,2)|49 (9)|92 (19,3)|42 (11,8)|9 (2)|0|
|Dispneia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor abdominal n<br>(%)|NR|NR|20 (13)|12 (8)|20 (3,8)|14 (2,6)|22 (6,1)|25 (7,1)|5 (1)|5 (3)|
|Fadiga n (%)|5<sup>§</sup>(20,8)|5<sup>§</sup>(20,8)|29 (19)|21 (14)|33 (6,3)|21 (3,9)|64 (17,7)|62 (17,5)|24 (6)|3 (2)|
|Ginecomastia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hiperglicemia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Hipertensão n (%)|NR|NR|NR|NR|20 (3,8)|15 (2,8)|17 (4,7)|31 (8,7)|49 (14)|6 (3)|
|Infecção n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Leucopenia n (%)|NR|NR|NR|NR|69 (13,2)|5 (0,2)|NR|NR|NR|NR|
|Morte n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Nausea n (%)|3<sup>§</sup>(12,5)|2<sup>§</sup>(8,0)|2 (1)|1 (1)|6 (1,1)|5 (0,9)|7 (1,9)|10 (2,5)|1 (<1)|0|
|Neutropenia n (%)|NR|NR|NR|NR|135 (25,7)|12 (2,2)|NR|NR|NR|NR|
|Outros n (%)|NR|NR|33 (21)|22 (14)|503 (95,4)|158 (28,5)|NR|NR|NR|NR|  
|**Eventos adversos**|**Hoffmann et a**|**l.** **2015**<sup>**§171**</sup><br>|**Sansonno et**<br>|**al.** **2012**<sup>**172**</sup><br>|**Cheng et**|**al.** **2013**<sup>**173**</sup><br>|**Zhang et al**<br>**(Zhu et al**<br>|**.** **2016**<sup>**174**</sup><br> **_._2015)**|**Bruix et a**|**l.** **2017**<sup>**175**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|**(Grau 3-5)**|**Sorafenibe +**<br>**TACE (N=24)**|**TACE+**<br>**Placebo**<br>**(N=25)**|**Sorafenibe**<br>**+TACE**<br>**(N=157)**|**TACE+**<br>**Placebo**<br>**(N=156)**|**Sunitinibe**<br>**(N = 526)**|**Sorafenib**<br>**e**<br>**(N =542)**|**Erlotinibe +**<br>**sorafenibe**<br>**(N=362)**|**Sorafenibe**<br>**(N=358)**|**Regorafenibe**<br>**(N= 374)**|**Placebo**<br>**(N=193)**|
|Rash n (%)|NR|NR|3 (2)|0|4 (0,8)|18 (3,4)|33 (9,2)|16 (4,5)|NR|NR|
|Reação mãos e pés n<br>(%)|7<sup>§</sup>(29,2)|1<sup>§</sup>(4)|12 (8)|0|70 (13,3)|115 (21,3)|NR|NR|47 (13)|1 (1)|
|Reação no local de<br>aplicação n (%)|NR|NR|NR|NR|NR|NR|37 (10,2)|62 (17,5)|NR|NR|
|Rubor n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Sangramento n (%)|NR|NR|9 (6)|2 (2)|NR|NR|NR|NR|NR|NR|
|Trombocitopenia n<br>(%)|13<sup>§</sup>(54,2)|14<sup>§</sup>(56,0)|NR|NR|NR|NR|NR|NR|1 (<1)|0|
|Vômito n (%)|NR|NR|2 (1)|1 (1)|14 (2,7)|7 (1,3)|8 (2,2)|7 (2,0)|1 (<1)|0|
|Todos n (%)|3 (12,5)<br>22<sup>§</sup>(91,7)|3 (12,5)<br>21<sup>§</sup>(84)|NR|NR|NR|NR|315 (87,0)|298 (83,4)|187 (50)|32 (17)|  
<mark>Legenda:</mark><sup>§</sup> <mark>E</mark> ventos adversos reportados sem estratificação de grau; NR: não relatado.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **<mark>Imunoestimulantes</mark>** -->
**Tabela AH** -  Características dos estudos que avaliaram imunoestimulantes.  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Interferon**||||
|**Xu et al.** **2015**<sup>**176**</sup>|Revisão sistemática<br>com meta-análise|Avaliar a eficácia e<br>segurança de interferon na<br>redução de recorrência de<br>CHC relacionado à<br>hepatite B/C após terapia<br>curativa|Dez ensaios clínicos, dos quais oito eram<br>elegíveis para meta-análise.  No total 888<br>pacientes foram avaliados.|Interferon como<br>adjuvante|Placebo ou<br>cuidados<br>paliativos|Baixo risco de<br>viés.|
|**Zhuang et al.** **2013**<sup>**177**</sup>|Revisão sistemática<br>com metanálise|Avaliar a eficácia e<br>segurança de interferon<br>em pacientes com CHC|Treze ensaios clínicos randomizados, dos<br>quais oito avaliaram interferon após terapia<br>curativa e cinco em pacientes com CHC<br>avançado na terapia curativa. Um total de<br>1344 pacientes foram avaliados.|Interferon como<br>adjuvante|Placebo ou<br>cuidados<br>paliativos|Baixo risco de<br>viés.|
||||**Timostimulina**||||
|**Dollinger et al.** **2010**<sup>**178**</sup>|Ensaio clínico<br>randomizado, fase<br>III, em 12 centros na<br>Alemanha.|Avaliar a eficácia de<br>timostimulina em<br>pacientes com CHC<br>avançado|Pacientes entre 18 e 80 anos, com CHC<br>avançado, índice de Karnofsky ≥ 60% e<br>Child Pugh ≤ 12. Foram incluídos 135<br>pacientes.|Timostimulina 75 mg<br>5 dias/ semana SC|Placebo SC +<br>tratamento de<br>suporte|Baixo risco de<br>viés.|  
<mark>Legenda: CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; ECR: Ensaio clínico randomizado; IM: Intramuscular; IV: Intravenoso; NR: Não relatado; SC: Subcutâneo; TACE: quimioembolização transarterial; V</mark> O: Via oral.  
**Tabela AI** – Características dos pacientes em estudos que avaliaram imunoestimulantes.  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||**Interfe**|**ron**||||
|**Xu et al.**|Interferon<br>como<br>adjuvante|461|49-65|70-<br>100|NR|HCV: 100 (4<br>estudos)<br>HBV: 100 (1|NR|NR|NR||
|<br>**2015**<sup>**176**</sup>|Placebo ou<br>cuidados<br>paliativos|427|49-67|60-<br>100|NR|estudo)<br>HBV: Entre<br>61,5 e 97,4 (3<br>estudos)|NR|NR|NR||
||||||||||Interferon: Entre||
|||||||HCV: 100 (4|||4,3 e 43,3||
|||||||estudos)|||Maior taxa de||
|**Zhuang et**<br>**l 2013**<sup>**177**</sup>|Interferon<br>como|675|49-65|NR|NR|HBV: 100 (2<br>estudos)|De 16-88<br>semanas||suspensão no<br>estudo de Llovet,||
|**a.**|adjuvante|||||HBV: Entre 6,7<br>e 94,3 (6|||JM et al. 2000, com<br>IFNα-2b na dose de||
|||||||estudos)|||3 x 106 IU, 3 vezes<br>por semana||  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||Placebo ou<br>cuidados<br>paliativos|669|49-67|NR|NR|HCV: 100 (4<br>estudos)<br>HBV: 100 (2<br>estudos)<br>HBV: Entre 0 e<br>94,4 (6 estudos)|||||
|**Timostimul**|**ina**||||||||||
|**Dollinger**<br>**et al.**<br>**2010**<sup>**178**</sup>|Timostimulina|67|Mediana:<br>63<br>(amplitude<br>48-79)|84|Child Pugh<br>A: 65<br>Okuda I: 35<br>Okuda II: 54<br>Okuda III:<br>11<br>BCLC C: 66<br>BCLC D: 12|HCV/HBV: 18<br>Álcool: 55|Mediana: 5,2<br>meses (IC95%<br>4,0-7,3)|3,3 meses<br>(amplitude 0 -12)|54/61 (88,5)|Timostimulina_vs_. placebo:<br>Progressão do tumor: 26 (43)<br>_vs_. 27 (40)<br>Piora da função hepática: 24<br>(39)_vs_. 28 (42)<br>Eventos adversos: 2 (3)_vs_. 2<br>(3)|
||Placebo +<br>tratamento de<br>suporte|68|Mediana:<br>63<br>(amplitude<br>39-76)|82|Child Pugh<br>A: 63<br>Okuda I: 32<br>Okuda II: 56<br>Okuda III:|HCV/HBV: 21<br>Álcool: 47|Mediana: 5,6<br>meses (IC95%<br>3,6-7,3)|3,3 meses<br>(amplitude 0 -12)|62/67 (92,5)|<br>Retirada consentimento: 1<br>(2)_vs_. 5 (7)<br>Outros: 1 (2)|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**<br>**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|
|||||12||||||
|||||BCLC C: 69||||||
|||||BCLC D: 15||||||  
<mark>Legenda: BCLC: Barcelona-Clinic Liver Cancer; CHC: Carcinoma hepatocelular ; ECOG: Eastern Cooperative Oncology Group; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; TACE: quimioembolização transarterial;</mark> UICC: _Union for International Cancer Control_ .  
**Tabela AJ** – Desfechos de eficácia dos estudos que avaliaram imunoestimulantes.  
|**Autor, ano**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevida**|**p-valor**|**Resposta intervenção,**<br>**Resposta controle,**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|
||**a intervenção**|**controle**||**n/N (%)**<br>**n/N (%)**||**resposta**|**resposta**||
||**[mortalidade: n/N**|**[mortalidade: n/N (%),**||||**intervenção**|**controle**||
||**(%), sobrevida:**|**sobrevida: mediana em**||||**(mediana em**|**(mediana em**||
||**mediana em meses]**|**meses]**||||**meses)**|**meses)**||
|**Interferon**|||||||||
|**Xu et al.**|Sobrevi|da global:||Recorrência:|p=0,06|NR|NR|NA|
|**2015**<sup>**176**</sup>|RR: 0,70 (IC95%,|0,58–0,86), I<sup>2</sup>=49%|P<0,00<br>1|RR: 0,91 (IC95% 0,82–1,00), I2=41%|||||
||Análise estratificada p|elo tamanho do tumor:||Análise estratificada pelo tamanho do tumor:|||||
||< 3 cm: RR: 0,49|(0,32–0,74), I<sup>2</sup>=0%||< 3 cm: RR: 0,50 (IC95% 0,35–0,72)|p<0,00||||
||> 3 cm: RR: 0,77 (|0,61–0,96), I<sup>2</sup>=67%|p<0,001<br>p=0,02|> 3 cm: RR:0,97 (0,86–1,09)<br>Análise estratificada pelo tipo de hepatite<br>HBV: 0,95 (0,82–1,11), I2=62%|1<br>p=0,59||||
|||||HCV: 0,94 (0,82–1,09), I2=34%|p=0,55||||
||||||p= 0,41||||
|**Zhuang et al.**|NR|NR||Recorrência:||NR|NR|NA|
|**2013**<sup>**177**</sup>||||1 ano: RR: 0,85 (IC95%, 0,73–0,99)|p=0,04||||
|||||2 anos: RR: 0,76 (IC95%, 0,6–0,96)|p=0,02||||
|||||3 anos: RR: 0,82 (IC95%, 0,7–0,96)|p=0,01||||
|||||4 anos: RR: 0,79 (IC95%, 0,68–0,91)|p<0,00||||
|||||5 anos: RR: 0,83 (IC95%, 0,74–0,93)|1||||
||||||p=0,00||||
|||||Análise de subgrupo em pacientes com HVC|2||||
|||||mostrou benefícios do interferon apenas a|||||  
|**Autor, ano**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevida**|**p-valor**|**Resposta intervenção,**|**Resposta controle,**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**a intervenção**|**controle**||**n/N (%)**|**n/N (%)**||**resposta**|**resposta**||
||**[mortalidade: n/N**|**[mortalidade: n/N (%),**|||||**intervenção**|**controle**||
||**(%), sobrevida:**|**sobrevida: mediana em**|||||**(mediana em**|**(mediana em**||
||**mediana em meses]**|**meses]**|||||**meses)**|**meses)**||
|||||partir do terc|eiro ano,|||||
|||||Análise de subgrupo em|pacientes que usaram|||||  
inteferon após cirurgia mostrou benefícios  
apenas a partir do quarto ano  
|||||**Timostimulina**||||||
|---|---|---|---|---|---|---|---|---|---|
|**Dollinger et**|Sobrevida ano 1: 28%|Sobrevida ano 1: 32%|p=0,87|Taxa de controle da|Taxa de controle da|NR|Tempo até a|Tempo até a|p =0,60|
|**al.** **2010**<sup>**178**</sup>|(IC95% 17-41%)|(IC95% 19-44%)||doença em 6 meses:|doença em 6||progressão: 5,3|progressão:||
|||||22/67 (33%)|meses: 20/68||meses (IC95%|2,9 meses||
||Sobrevida global: 5,0|Sobrevida global: 5,2|||(29%)||2,0-8,6)|(IC95% 2,6-||
||meses (IC95% 3,7-6,3)|meses (IC95% 3,5-6,9)|||||HR: 1,13|3,1)||
||HR: 1,04 (IC95%0,7-||||||(IC95% 0,7-|||
||1,6)||||||1,8)|||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**Tabela AK** – Eventos adversos dos estudos que avaliaram imunoestimulantes.  
|**Eventos adversos (Grau 3-5**)|**Dollinger et al.**|**2010**<sup>**178**</sup>|
|---|---|---|
||**Timostimulina (N=67)**|**Placebo (N=68)**|
|Alopecia n (%)|NR|NR|
|Anemia n (%)|0|1 (1)|
|Anorexia n (%)|NR|NR|
|Ascite n (%)|6 (9)|17 (25)|
|Azia n (%)|NR|NR|
|Cefaleia n (%)|NR|NR|
|Diarreia n (%)|0|2 (3)|
|Dispneia n (%)|NR|NR|
|Dor abdominal n (%)|2 (3)|2 (3)|
|Fadiga n (%)|1 (1)|3 (4)|
|Ginecomastia n (%)|NR|NR|
|Hiperglicemia n (%)|NR|NR|
|Hipertensão n (%)|NR|NR|
|Infecção n (%)|3 (4)|5 (7)|
|Leucopenia n (%)|NR|NR|
|Morte n (%)|NR|NR|
|Nausea n (%)|NR|NR|
|Neutropenia n (%)|NR|NR|
|Outros n (%)|24 (36)|42 (62)|
|Rash n (%)|NR|NR|
|Reação mãos e pés n (%)|NR|NR|
|Reação no local de aplicação n (%)|NR|NR|
|Rubor n (%)|NR|NR|
|Sangramento n (%)|NR|NR|
|Trombocitopenia n (%)|NR|NR|
|Vômito n (%)|NR|NR|
|Todos n (%)|NR|NR|  
<mark>Legenda: NR: não relatado.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **I** **<mark>munossupressores</mark>** -->
**Tabela AL** – Características dos estudos que avaliaram imunossupressores.  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de**<br>**viés**|
|---|---|---|---|---|---|---|
||||**Talidomida**||||
|**Cao et al.** **2017**<sup>**179**</sup>|Revisão sistemática<br>com meta-análise|Avaliar a eficácia e<br>segurança de talidomida<br>associada à TACE no<br>tratamento de pacientes<br>com CHC|Vinte e três ensaios clínicos<br>randomizados, realizados na China, com<br>um total de 1836 pacientes.|Talidomida 200 mg/dia<br>VO + TACE (20 estudos)<br>Talidomida 100 a 400<br>mg/dia VO + TACE (3<br>estudos)|TACE (22 estudos)<br>TACE + Sorafenibe<br>800 mg/dia VO (1<br>estudo)|Baixo<br>risco de<br>viés.|
||||**Sirolimo**||||
|**Geissler et al.** **2016**<sup>**180**</sup>|Ensaio clínico<br>randomizado, fase<br>III, em 45 centros na<br>Europa, Canadá e<br>Austrália (SiLVER)|Avaliar e eficácia e<br>segurança de sirolimo em<br>evitar a recorrência de<br>CHC após transplante de<br>fígado.|Pacientes acima de 18 anos de idade,<br>elegíveis ao transplante de fígado,<br>portadores de CHC sem doença extra-<br>hepática. Foram incluídos 525 pacientes.|Sirolimo 4-10 ng/mL VO<br>associado ou não a<br>inibidores da calcineurina|Inibidores da<br>calcineurina|Baixo<br>risco de<br>viés.|
||||**Everolimos**||||
||Ensaio clínico<br>randomizado, fase|Avaliar a eficácia e<br>segurança de everolimus|Pcientes acima de 18 anos de idade, com<br>CHC, BCLC B ou C, Child Pugh A,|Everolimo 7,5 mg/dia|Plb|Baixo|
|**Zhu et al.** **2014**<sup>**181**</sup>|III, em 111 centros<br>em 17 países|em pacientes com CHC<br>com falha prévia ao uso|ECOG 0-2, e que apresentaram progressão<br>do tumor ou intolerância ao sorafenibe.|VO + tratamento<br>paliativo|aceo + tratamento<br>paliativo|risco de<br>viés.|
||(EVOLVE-1)|de sorafenibe.|Foram incluídos 546 pacientes.||||  
<mark>Legenda: CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; ECR: Ensaio clínico randomizado; NR: Não relatado; TACE: quimioembolização transarterial; V</mark> O: Via oral.  
**Tabela AM** – Características dos pacientes em estudos que avaliaram imunossupressores.  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|<br>**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia**<br>**(%)**|**Tempo de**<br>**seguiment**<br>**o**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||**Talidom**|**ida**||||
|**Cao et**|Talidomida +<br>TACE|9<br>0<br>4|Amplitude<br>entre estudos<br>de 21 a 83|Amplitude<br>de 57,5-<br>93,5.|NR|NR|NR|NR|NR|NR|
|**al.**<br>**2017**<sup>**179**</sup>|TACE ou<br>TACE +<br>Sorafenibe|9<br>3<br>2|Amplitude<br>entre estudos<br>de 21 a 83|Não<br>estratifica<br>entre<br>grupos|NR|NR|NR|NR|NR|NR|
|||||||**Sirolim**|**o**||||
|||2|Mediana: 58,8|||HCV: 36,9||||Sirolimo_vs_. Inibidores|
||Sirolimo|6|(amplitude|89,3|NR|HBV: 11,1||NR|123/261 (47,1)|calcineurina:|
|**Geissler**||1|37-75)|||Álcool: 32,1||||Morte: 64 (24,5)_vs_. 82 (31,0)|
|**et al.**<br>**2016**<sup>**180**</sup>|Inibidores da<br>calcineurina|2<br>6<br>4|Mediana: 58,0<br>(amplitude<br>22-72)|83|NR|HCV: 36,6<br>HBV: 12,5<br>Álcool: 30,1|8 anos|NR|115/264 (43,6)|Retirada consentimento: 30<br>(11,5)_vs_. 18 (6,8)<br>Outra razão: 30 (11,5)_vs_. 15<br>(5,7)|
|||||||**Everolim**|**os**||||
|**Zhu et**<br>**al. 2014**|Everolimos|3<br>6<br>2|Mediana; 67,0<br>(amplitude<br>21-86)|83,7|Child Pugh A:<br>97,8<br>ECOG 0: 59,1<br>ECOG 1: 35,6|HCV: 26,0<br>HBV: 25,1<br>Álcool: 17,7|Mediana:<br>24,6<br>meses<br>(amplitude|9,43 semanas<br>(amplitude 0,1-<br>120,0)|357/361 (98,9)|Everolimos_vs_. placebo<br>Progressão/recorrência: 261<br>(72,3)_vs_. 149 (81,9)<br>Eventos adversos:60 (16,6)_vs_.|  
**Tempo de Grau do Tempo de Autor, Detalhes da Idade em Sexo M Etiologia tratamento, Suspensão n/N N carcinoma seguiment Razão para suspensão n (%) ano Intervenção anos (%) (%) mediana (mín(%) (%) o máx)** ECOG 2: 5,2 14,8-36,6) 14 (7,7) BCLC C: 86,5 Retirada de consentimento: 20 (5,5) _vs_ . 6 (3,3) Morte: 13 (3,6) _vs_ . 5 (2,7) Outros: 3 (0,8) _vs_ . 2 (1,1) Child Pugh A: 98,9 ECOG 0: Mediana: 1 56,5 HCV: 23,4 8,93 semanas 64,0 Placebo 8 87 ECOG 1: HBV: 28,3 (amplitude 0,4176/182 (96,7) (amplitude 4 40,2 Álcool: 24,5 136,3) 34-87) ECOG 2: 3,3 BCLC C: 85,9  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control._  
**<mark>Tabela AN</mark>** <mark>– Desfechos de eficácia dos estudos que avaliaram imunossupressores.</mark>  
|**Autor, ano**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta intervenção,**<br>**Resposta controle,**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|
||**a intervenção**|**a controle**||**n/N (%)**<br>**n/N (%)**||**resposta**|**resposta**||
||**[mortalidade: n/N**|**[mortalidade: n/N**||||**intervenção**|**controle**||
||**(%), sobrevida:**<br>**mediana em meses]**|**(%), sobrevida:**<br>**mediana em meses]**||||**(mediana em**<br>**meses)**|**(mediana em**<br>**meses)**||
|||||**Talidomida**|||||
|**Cao et al.**|Sobrevida 6 meses: OR:|1,79 (IC95% 1,02-3,15)|p=0,04|Taxa de Resposta Objetiva: OR: 1,89 (IC95%|p<0,000|NR|NR|NA|
|**2017**<sup>**179**</sup>|Sobrevida 12 meses: OR:|1,76 (IC95% 1,38-2,24)|p<0,000|1,48-2,42)|1||||
||Sobrevida 18 meses: OR:|4,72 (IC95% 2,64-8,43)|1||||||
||Sobrevida 24 meses: OR:|1,78 (IC95% 1,37-2,30)|p<0,001|**Análise estratificada por tipo de TACE**|||||
||Sobrevida 36 meses: OR:|1.54 (IC95% 0,70-3,41)|p<0,001|Talidomida + Oxaplatina:|||||
||||p=0,09|OR: 2.88 (IC95% 1,34-6,19)|p=0,007||||
||*Metanálises realizadas|com modelo de efeitos||Talidomida + cisplatina + 5-Fu:|||||
||fixos, se não houvesse he|terogeneidade estatística||OR: 1.90 (IC95% 1,31-2,76)|p<0,001||||
||import|ante.||Talidomida + 5-Fu + Adriamicina\Esquemas|||||
|||||com Epirubicina:<br>OR: 1.87 (IC95% 1,21-2,88)<br>Taxa de controle da doença: OR: 2,62 (IC95%|p=0,005<br>p<0,001||||
|||||1,90-3,63)|p<0,01||||  
|||||**Sirolimo**||||||
|---|---|---|---|---|---|---|---|---|---|
|**Geissler et**|Sobrevida livre de|Sobrevida livre de||NR|NR|NA|NR|NR|NR|
|**al****_._**|recorrência:|recorrência do tumor:||||||||
|**2016**<sup>**180**</sup>|1 ano: 233 (92,5%)|1 ano: 218 (85,2%)|p=0,012|||||||
||2 anos: 209 (82,9%)|2 anos: 198 (77,3%)|5|||||||
||3 anos: 203 (80,6%)|3 anos: 185 (72,3%)|p=0,143|||||||  
|**Autor, ano**|**Mortalidade/Sobrevid**<br>**a intervenção**|**Mortalidade/Sobrevid**<br>**a controle**|**p-valor**|**Resposta intervenção,**<br>**n/N (%)**|**Resposta controle,**<br>**n/N (%)**|**p-valor**|**Tempo até**<br>**resposta**|**Tempo até**<br>**resposta**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**[mortalidade: n/N**|**[mortalidade: n/N**|||||**intervenção**|**controle**||
||**(%), sobrevida:**|**(%), sobrevida:**|||||**(mediana em**|**(mediana em**||
||**mediana em meses]**|**mediana em meses]**|||||**meses)**|**meses)**||
||4 anos: 192 (76,2%)|4 anos: 181 (70,7%)|4|||||||
||5 anos: 183 (72,6%)|5 anos: 175 (68,4%)|p=0,049|||||||
||6 anos: 178 (70,6%)|6 anos: 170 (66,4%)|9|||||||
||7 anos: 178 (70,6%)|7 anos: 166 (64,8%)|p=0,219|||||||
||8 anos: 177 (70,2%)|8 anos: 165 (64,5%)|3|||||||
|||HR: 0,84 (0,62-1,15)|p=0,380|||||||
||||9|||||||
||Sobrevida global:|Sobrevida global:|p=0,432|||||||
||1 ano: 242 (96,0%)|1 ano: 234 (91,4%)|5|||||||
||2 anos: 228 (90,5%)|2 anos: 217 (84,8%)|p=0,279|||||||
||3 anos: 217 (86,1%)|3 anos: 201 (78,5%)|8|||||||
||4 anos: 210 (83,3%)|4 anos: 192 (75,0%)|p=0,279|||||||
||5 anos: 200 (79,4%)|5 anos: 180 (70,3%)|6|||||||
||6 anos: 192 (76,2%)|6 anos: 179 (69,9%)||||||||
||7 anos: 189 (75,0%)|7 anos: 176 (68,7%)||||||||
||8 anos: 188 (74,6%)|8 anos: 175 (68,4%)||||||||
|||HR: 0,81 (0,58-1,13)|p=0,041<br>4|||||||
||||p=0,077|||||||
||||5|||||||
||||p=0,050<br>3|||||||  
|**Autor, ano**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta intervenção,**|**Resposta controle,**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**a intervenção**|**a controle**||**n/N (%)**|**n/N (%)**||**resposta**|**resposta**||
||**[mortalidade: n/N**|**[mortalidade: n/N**|||||**intervenção**|**controle**||
||**(%), sobrevida:**|**(%), sobrevida:**|||||**(mediana em**|**(mediana em**||
||**mediana em meses]**|**mediana em meses]**|||||**meses)**|**meses)**||
||||p=0,046|||||||
||||8|||||||
||||p=0,047|||||||
||||9|||||||
||||p=0,198|||||||
||||2<br>p=0,210|||||||
||||4|||||||
||||p=0,209<br>6|||||||  
|||||**Everolimos**||||||
|---|---|---|---|---|---|---|---|---|---|
|**Zhu et al.**|Sobrevida global: 7,6|Sobrevida global: 7,3||Taxa de controle da|Taxa de controle da|p=0,01|Tempo até a|Tempo até a|NR|
|**2014**<sup>**181**</sup>|meses (IC95% 6,7-8,7)|meses (IC95% 6,3-8,7)||doença: 56,1% (IC95%|doença: 45,1%||progressão: 3,0|progressão:||
||HR: 1,05 (IC95% 0,86-||p=0,68|50,8-61,3)|(IC95% 37,8-52,6)||meses (IC95%|2,6 meses||
||1,27)||||||2,8-4,0)|(IC95% 1,5-||
|||||RC: 0|RC: 0||HR: 0,93|2,8)||
||Análise ajustada por|||RP: 8 (2,2%)|RP: 3 (1,6%)||(IC95% 0,75-|||
||fatores prognósticos:|||DE: 195 (53,9%)|DE: 80 (43,5%)||1,15)|||
||HR: 1,11 (IC95% 0,91-|||PD: 115 (31,8%)|PD: 73 (39,7%)|||||
||1,36)|||||||||  
|**Autor, ano**|**Mortalidade/Sobrevid**|**Mortalidade/Sobrevid**|**p-valor**|**Resposta intervenção,**|**Resposta controle,**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**a intervenção**|**a controle**||**n/N (%)**|**n/N (%)**||**resposta**|**resposta**||
||**[mortalidade: n/N**|**[mortalidade: n/N**|||||**intervenção**|**controle**||
||**(%), sobrevida:**|**(%), sobrevida:**|||||**(mediana em**|**(mediana em**||
||**mediana em meses]**|**mediana em meses]**|||||**meses)**|**meses)**||
||Sobrevida em 5 meses:|Sobrevida em 5 meses:||||||||
||67,0%|65,6%||||||||
||Sobrevida em 7 meses:|Sobrevida em 7 meses:||||||||
||53,4%|51,4%||||||||  
Legenda: 5-Fu: 5 Fluoracil; n <mark>: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença; R</mark> C: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**<mark>Tabela AO –</mark>** <mark>Eventos adversos dos estudos que avaliaram imunossupressores.</mark>  
|**Eventos adversos**|**Cao et al.** **2017**<sup>**179**</sup>|**Geissler et**|**al****_._2016**<sup>**§180**</sup>|**Zhu et al.**|**2014**<sup>**181**</sup>|
|---|---|---|---|---|---|
|**(Grau 3-5)**|**Talidomida**|**Sirolimo**|**Inibidores**|**Everolimos**|**Placebo**|
||**OR (IC95%) p**|**(N=261)**|**Calcineurina**<br>**(N=264)**|**(N=361)**|**(N=182)**|
|Alopecia n (%)|NR|NR|NR|NR|NR|
|Anemia n (%)|NR|45<sup>§</sup>|38<sup>§</sup>|28 (7,7)|6 (3,3)|
|Anorexia n (%)|NR|NR|NR|NR|NR|
|Ascite n (%)|NR|NR|NR|20 (5,6)|16 (8,7)|
|Azia n (%)|NR|NR|NR|NR|NR|
|Cefaleia n (%)|NR|48<sup>§</sup>|43<sup>§</sup>|NR|NR|
|Diarreia n (%)|NR|76<sup>§</sup>|72<sup>§</sup>|5 (1,4)|2 (1,1)|
|Disfunção hepática|1,00 (0,57-1,77)<br>p=0,99|NR|NR|NR|NR|
|Dispneia n (%)|NR|NR|NR|10 (2,8)|7 (3,8)|
|Dor abdominal n (%)|NR|NR|NR|12 (3,3)|9 (4,9)|
|Eventos gastrointestinais|1,30 (0,78-2,18)<br>p=0,31|NR|NR|NR|NR|
|Fadiga n (%)|NR|NR|NR|16 (4,5)|7 (3,8)|
|Ginecomastia n (%)|NR|NR|NR|NR|NR|
|Hiperglicemia n (%)|NR|NR|NR|NR|NR|
|Hipertensão n (%)|NR|77<sup>§</sup>|61<sup>§</sup>|NR|NR|
|Infecção n (%)|NR|37<sup>§</sup>*|25<sup>§</sup>*|13 (3,6)|1 (0,5)|
|Leucopenia n (%)|NR|40<sup>§</sup>|44<sup>§</sup>|NR|NR|
|Mielossupressão|1,21 (0,69-2,12)<br>p=0,51|NR|NR|NR|NR|
|Morte n (%)|NR|64 (24,5%)|82 (31,1%)|NR|NR|
|Náusea n (%)|NR|NR|NR|5 (1,4)|0|
|Neutropenia n (%)|NR|NR|NR|NR|NR|
|Rash n (%)|6,35 (IC95% 2,75-|NR|NR|3 (0,8)|0|
||14,68) p<0,01|||||
|Reação mãos e pés n (%)|NR|NR|NR|NR|NR|
|Reação no local de<br>aplicação n (%)|NR|NR|NR|NR|NR|
|Rubor n (%)|NR|NR|NR|NR|NR|
|Sangramento n (%)|NR|NR|NR|NR|NR|
|Trombocitopenia n (%)|NR|36<sup>§</sup>|24<sup>§</sup>|20 (5,6)|1 (0,5)|
|Vômito n (%)|NR|NR|NR|3 (0,8)|1 (0,5)|
|Todos n (%)|NR|4142<sup>§</sup>|3871<sup>§</sup>|256 (70,9)|95 (52,2)|
|||225 (86,2)|218 (82,6)|||  
Legenda:<sup>§</sup> Número de eventos adversos observados (e não de pacientes) independente da estratificação de grau; *Pneumonia.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **<mark>Terapias endócrinas</mark>** -->
**<mark>Tabela AP</mark>** <mark>– Características dos estudos que avaliaram terapias endócrinas.</mark>  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Tamoxifeno**|||||||
|**Nowak et al.**<br>**2005**<sup>**182**</sup>|Revisão sistemática<br>com meta-análise|Avaliar a eficácia e<br>segurança de tamoxifeno<br>em pacientes com CHC<br>avançado|Dez ECR, sendo dois resumos<br>de congresso e oito<br>publicações completas. No<br>total foram avaliados 1709<br>participantes.|Tamoxifeo 20 (5<br>estudos) a 120<br>mg/dia VO (1<br>estudo)<br>Tamoxifeno +<br>Doxorubicina 60/m2<br>a cada 3 semanas (1<br>estudo)|Placebo (9<br>estudos)<br>Doxorubicina<br>60/m2 a cada 3<br>semanas (1<br>estudo)|Qualidade moderada.<br>Possível viés de publicação<br>identificado pelo funnel plot,<br>apenas três estudos incluídos com<br>baixo risco de viés, incertezas<br>quanto à comparabilidade dos<br>estudos.|
|**Doffoel et al.**<br>**2008**<sup>**183**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em 15<br>centros na França<br>(FFCD 9402).|Avaliar a eficácia e<br>segurança de tamoxifeno<br>associado à TACE em<br>pacientes com CHC<br>avançado|Pacientes adultos <75 anos de<br>idade, com cirrose hepática e<br>CHC não ressecável, Child-<br>Pugh C, Okuda III. Foram<br>incluídos 138 pacientes.|Tamoxifeno 20<br>mg/dia VO + TACE<br>(epirubicina 50 mg)<br>a cada 2 meses - até<br>10 intervenções|Tamoxifeno 20<br>mg VO|Baixo risco de viés.|
|**Groupe**<br>**d'Etude et de**<br>**Traitement du**<br>**Carcinome**<br>**Hépatocellulai**<br>**re, 2004**<sup>**184**</sup>|Ensaio clínico<br>randomizado, fase<br>III, muticêntrico,<br>realizado na França.|Avaliar a eficácia da<br>terapia antiandrogênica<br>em pacientes com CHC.|Pacientes acima de 18 anos de<br>idade, do sexo masculino, com<br>CHC não ressecável,<br>expectativa de vida >= 3<br>meses e índice Karnofsky >=<br>30%. Foram incluídos 376<br>pacientes.|Leuprorrelina 3,75<br>mg/mês SC,<br>flutamida 750<br>mg/dia VO,<br>tamoxifeno 30<br>mg/dia VO|Tamoxifeno 30<br>mg/dia VO|Baixo risco de viés.|
|**Pan et al.**|Ensaio clínico|Avaliar a eficácia de|Pacientes adultos, com CHC|Tamoxifeno 40|5-Fluoracil 1 g|Alto risco de viés.|
|**2003**<sup>**185**</sup>|randomizado, fase|tamoxifeno combinado à|não ressecável ER (+). Foram|mg/dia VO +|duas vezes por|Não cita método de randomização,|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||III, realizado em um<br>hospital na China.|octreotida em pacientes<br>com CHC avançado.|incluídos 39 pacientes.|Octreotida 0,6<br>mg/dia IV|semana +<br>Mitomicina 20-30<br>mg IV uma vez<br>por semana<br>durante 4 semanas<br>(3 ciclos)|sigilo ou cegamento. Análise de<br>desfechos inclui 9 pacientes<br>aparentemente não randomizados.|
|||||_Intervenção 1:_|||
|**Manesis et al.**<br>**1995**<sup>**186**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em um<br>centro na Grécia.|Avaliar a eficácia e<br>segurança de terapias<br>hormonais em pacientes<br>com CHC.|Pacientes com CHC não<br>ressecável, ECOG 0-3, sem<br>doença extra-hepática ou<br>tratamento<br>cirúrgico/conservador nos<br>últimos dois meses. Foram<br>incluídos 90 pacientes.|Tamoxifeno 30<br>mg/dia VO +<br>triptorrelina 3,75<br>mg/mês IM<br>I_ntervenção 2:_<br>Flutamida 750<br>mg/dia +<br>triptorrelina 3,75<br>mg/mês IM|Placebo VO +<br>solução salina IM|Risco de viés incerto.<br>Não relata método de randomização<br>e sigilo da alocação. Cegamento<br>adequado. Excluiu da análise final 5<br>pacientes que foram randomizados,<br>dos quais dois não haviam recebido<br>terapia (grupo placebo e grupo<br>flutamida).|
|**Uchino et al.**<br>**1993**<sup>**195**</sup>|Ensaio clínico<br>randomizado em um<br>hospital no Japão|Avaliar a eficácia da<br>terapia hormonal<br>combinada à<br>quimioterapia em<br>pacientes com CHC|Pacientes com CHC não<br>ressecável (primário ou<br>recorrente). Foram incluídos<br>30 pacientes.|Tamoxifeno<br>25mg/m<sup>2</sup>/dia VO +<br>medroxiprogesteron<br>a 400 mg m<sup>2</sup>/dia VO<br>+ embolização<br>arterial<br>(cisplatina,adriamici<br>na) + 5-FU 150 mg|Embolização<br>arterial (cisplatina,<br>adriamicina) + 5-<br>FU 150 mg VO|Alto risco de viés<br>Não cita método de randomização,<br>sigilo ou cegamento. Análise de<br>desfechos exclui 4 pacientes<br>randomizados.|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||VO|||
|**Terapia antiand**|**rogênica**||||||
|||||_Intervenção 1:_<br>Nilutamida 300<br>mg/d VO (1º mês) e<br>manutenção 150|||
|||||mg/d VO + placebo|||
||Ensaio clínico||||||
||randomizado,||Pi  CHC i d|_Intervenção 2:_||Risco de viés incerto|
|**Grimaldi et al.**<br>**1998**<sup>**196**</sup>|multicêntrico,<br>realizado pela<br>_European_<br>_Organization for_<br>_Research and_|Avaliar a eficácia de<br>terapias antiandrogênicas<br>em pacientes com CHC|acentes com  vrgens e<br>tratamento (transplante,<br>tratamento sistêmico ou<br>locorregional). Foram<br>incluídos 244 pacientes.|Gosserrelina 3,6<br>mg/mês ou<br>triptorrelina 3,75<br>mg/mês IM +<br>placebo|Placebo + placebo|Não cita método de randomização<br>ou sigilo da alocação. Cegamento<br>adequado. Excluiu da análise final<br>seis pacientes considerados<br>inelegíveis.|
||_Treatment of Cancer_|||_Intervenção 3:_|||
|||||Nilutamida +|||
|||||Gosserrelina ou<br>triptorrelina +|||
|||||placebo|||
|**Megestrol**|||||||
|**Chow et al.**|Ensaio clínico<br>randomizado, fase|Avaliar a eficácia e<br>segurança de megestrol|Pacientes com CHC avançado<br>não ressecável, com ECOG 0-|Megestrol 320<br>|Placebo + terapia|Risco de viés incerto<br>(Exclui 19 pacientes de um mesmo|
|**2011**<sup>**188**</sup>|III, em seis centros<br>da Ásia-Pacífico|em pacientes com CHC<br>avançado|3 e virgens de tratamento<br>(transplante, tratamento|mg/dia VO + terapia<br>de suporte|de suporte|centro devido à ausência de dados<br>enviados e não coloca os motivos|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||(AHCC)||sistêmico ou locorregional).<br>Foram incluídos 204 pacientes.|||de tal exclusão).|
|**Villa et al.**<br>**2001**<sup>**190**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em um<br>centro na Itália.|Avaliar a eficácia e<br>segurança de megestrol<br>em pacientes com CHC<br>avançado.|Pacientes com CHC não<br>ressecável, sem doença extra-<br>hepática, com índice<br>Karnofsky >= 70. 45 pacientes<br>foram incluídos.|Megestrol 160<br>mg/dia|Não intervenção|Baixo risco de viés.|
||||**Octreotida**||||
|**Guo et al.**<br>**2009**<sup>**189**</sup>|Revisão sistemática<br>com meta-análise|Avaliar a eficácia de<br>octreotida em pacientes<br>com CHC avançado|Seis ECR, totalizando 352<br>participantes|Octreotida|Placebo ou<br>cuidados<br>paliativos|Baixo risco de viés.|
||Ensaio clínico|Avaliar a eficácia de<br>octreotida de ação|Pacientes acima de 18 anos de<br>idade, com CHC confirmado||||
|**Barbare et al.**<br>**2009**<sup>**187**</sup>|randomizado, fase<br>III, em 79 centros na<br>França.|prolongada na sobrevida<br>em pacientes com CHC<br>não elegíveis para<br>tratamentos curativos|por exame histológico ou<br>citogenético, inelegível para<br>tratamentos curativos ou com<br>falha a estes tratamentos.|Octreotida 30<br>mg/mês IM|Placebo NaCl IM<br>uma vez por mês|Baixo risco de viés.|
|**Verset et al.**<br>**2007**<sup>**191**</sup>|Ensaios clínico<br>randomizado, fase<br>III, em 18 centros na<br>Bélgica.|Avaliar a eficácia de<br>octreotida de ação<br>prolongada + tamoxifeno<br>na sobrevida em pacientes<br>com CHC não elegíveis<br>para tratamentos curativos|Pacientes acima de 18 anos de<br>idade, com CHC confirmado<br>por exame histológico ou por<br>dois exames de imagem<br>concordantes, inelegível para<br>tratamentos curativos ou com<br>falha a estes tratamentos,<br>performance status de|Octreotida 30<br>mg/mês IM +<br>tamoxifeno 20<br>mg/dia VO + terapia<br>de suporte|Tamoxifeno 20<br>mg/dia VO +<br>terapia de suporte|Baixo risco de viés|  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||Karnofsky de 60+ pontos e||||
||||com expectativa de vida igual||||
||||ou inferior a dois meses.||||  
<mark>Legenda: 5-FU: 5-Fluoruracil; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; ECR: Ensaio clínico randomizado; IM: Intramuscular; IV: Intravenoso; NR: Não relatado; TACE: quimioembolização transarterial; V</mark> O: Via oral.  
**<mark>Tabela AQ</mark>** <mark>– Características dos pacientes em estudos que avaliaram terapias endócrinas.</mark>  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Tamoxifeno**|**e combinações**||||||||||
||Tamoxifeo<br>ou<br>Tamoxifeno +|685*|Entre 52-67|Mediana<br>s de 71–<br>89.|Child Pugh C < 25<br>Okuda Stage III <<br>25|NR|NR|NR|NR||
|**Nowak et**|Doxorubicina|||||||||NR|
|**al. 2005**<sup>**182**</sup>|||Não|Não|||||||
||Placebo ou<br>Doxorubicina|624*|estratifica<br>por grupos.|estratific<br>a por<br>grupos|Não estratifica por<br>subgrupos|NR|NR|NR|NR||
||Tamoxifeno +<br>TACE|62|64,9 ± 7,3|84|Child Pugh A: 74<br>Chid Pugh B: 26<br>Okuda I: 74<br>Okuda II: 26|HCV: 10<br>HBV: 5<br>Álcool: 73|Mediana: 12,4<br>meses||NR|Tamoxifeno + TACE<br>_vs_. tamoxifeno†<br>Morte: 19 (33)_vs_. 42<br>(79)|
|**Doffoel et**<br>**al. 2008**<sup>**183**</sup>|Tamoxifeno|61|63,9 ± 7,0|90|Child Pugh A: 68<br>Chid Pugh B: 32<br>Okuda I: 69<br>Okuda II: 31|HCV: 11<br>HBV: 5<br>Álcool: 79|Mediana: 11,0<br>meses||NR|Recusa: 8 (14)_vs_. 1<br>(2)<br>Saiu do estudo: 1 (2)<br>_vs_. 2 (4)<br>Completou tratamento:<br>1 (2)_vs_. 0<br>Outros: 23 (40)_vs_. 5<br>(10)|  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||†Um paciente pode ter<br>mais de uma razão<br>para suspensão|
|**Groupe**<br>**d'Etude et**<br>**de**<br>**Traitemen**|Leuprorrelina<br>+ flutamida +<br>tamoxifeno|192|Mediana; 65<br>(amplitude<br>27–88)|100|Child Pugh A: 62<br>Child Pugh B: 35<br>Okuda I: 42,2<br>Okuda II: 55,7|HCV: 19<br>HBV: 3<br>Álcool: 72|NR|NR|52/192 (27)|Leuprorrelina+flutami<br>da+tamoxifeno_vs_.<br>tamoxifeno:|
|**t du**||||||||||Perda de|
|**Carcinom**<br>**e**<br>**Hépatocell**<br>**ulaire,**|Tamoxifeno|184|Mediana: 66<br>(amplitude<br>34–87)|100|Child Pugh A: 68<br>Child Pugh B: 31<br>Okuda I: 50,5<br>Okuda II: 45,1|HCV: 13<br>HBV: 10<br>Álcool: 74|NR|NR|28/184 (15,2)|acompanhamento: 7<br>(3,6)_vs_. 6 (3,2)<br>Eventos adversos: 45<br>(23,4)_vs_. 22 (12,0)|
|**2004**<sup>**184**</sup>|||||||||||
|**Pan et al.**<br>**2003**<sup>**185**</sup>|Tamoxifeno +<br>Octreotida|24**|52,1<br>(amplitude<br>23-68)<br>Não<br>estratifica<br>entre grupos,|71,7<br>Não<br>estratific<br>a entre<br>grupos,|Okuda II: 35,9<br>Okuda III: 64,1<br>Não estratifica entre<br>grupos,|NR|NR|NR|NR|NR|
||5-Fluoracil +<br>Mitomicina|15||||NR|NR|NR|NR||  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||Tamoxifeno +<br>triptorrelina|33|62,6 ± 10,3|78,8|Child Pugh: 7,7 ±<br>2,0<br>ECOG: 1,1 ± 0,93<br>Okuda stage I: 27,3<br>Okuda III: 18,2|HCV: 12,1<br>HBV: 69,7<br>Álcool: 32,0|||||
|**Manesis et**<br>**al. 1995**<sup>**186**</sup>|Flutamida  +<br>triptorrelina|23|61,9 ± 11,4|73,9|Child Pugh: 8,3 ±<br>1,6<br>ECOG: 1,6 ± 0,90<br>Okuda I: 21,7<br>Okuda III: 13,0|HCV: 8,7<br>HBV: 56,5<br>Álcool: 16,0|Mediana:3,7<br>meses<br>(amplitude<br>0,5-32)|NR|Não houve<br>descontinua-ção|NA|
||||||Child Pugh: 8,9 ±||||||
||||||2,1|HCV: 20,0|||||
||Placebo|29|62,2 ± 11,0|79,3|ECOG: 1,6 ± 0,95<br>Okuda I: 24,1|HBV: 58,6<br>Álcool: 22,0|||||
||||||Okuda III: 17,2||||||
|**Uchino****_et_**<br>**_al_1993**<sup>**195**</sup>|Tamoxifeno +<br>medroxipro-<br>gesterona +<br>quimioterapia|12|59,3 ± 6,4|75,0|Child Pugh B: 66,7<br>Okuda III: 25,0<br>Okuda IV-A: 41,7|HBs-Ag+:<br>16,7||Até quatro<br>ciclos|3/15 (20)|Terapias hormonais +<br>quimioterapia_vs_.<br>quimioterapia<br>Morte: 2 (13,3)_vs_. 1|
|**_._**|||||Child Pugh B: 71,4|||||(6,7)|
||Quimioterapia|14|60,3 ± 7,3|78,6|Okuda III: 35,7<br>Okuda IV-A: 35,7|HBs-Ag+: 7,1|||1/15 (6,7)|Diagnóstico de outro<br>câncer: 1 (6,7)_vs._0|
|**Terapia ant**|**iandrogênica**||||||||||  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||Nilutamida +<br>placebo|58|NR|91|ECOG 0: 21|HBV: 25,0<br>Álcool: 32,0|||3/58 (5,2)|Suspensão por eventos<br>adversos: 3 (5,2)|
||Gosserrelina||||||||||
||ou<br>triptorrelina +|61|NR|90|ECOG 0: 21|HBV: 21,0<br>Álcool: 52,0|||Não houve<br>descontinua-ção|NA|
|**Grimaldi**|placebo||||||||||
|**et al.**|Nilutamida +||||||NR|NR|||
|**1998**<sup>**196**</sup>|Gosserrelina<br>ou<br>triptorrelina +<br>placebo|60|NR|80|ECOG 0: 25|HBV: 14,0<br>Álcool: 59,0|||Não houve<br>descontinua-ção|NA|
||Placebo +<br>placebo|59|NR|78|ECOG 0: 26|HBV: 35,0<br>Álcool: 39,0|||Não houve<br>descontinua-ção|NA|
|**Megestrol**|||||||||||
|**Chow et**<br>**al. 2011**<sup>**188**</sup>|Megestrol|135|Mediana:<br>56,0<br>(amplitude<br>20,1 –<br>100,3)|87,8|Child Pugh A: 48,0<br>Child Pugh B: 36,6<br>Child Pugh C: 13,0<br>ECOG 0: 9,8<br>ECOG 1: 56,1<br>ECOG 2: 24,4<br>Okuda II: 64,2|HCV: 6,5<br>HBV: 61,0<br>HBV e HCV:<br>1,6|12 meses|1,57 meses<br>(amplitude<br>0,03 –13,67)|32/123 (26)|Megestrel_vs_. placebo<br>Perda de<br>acompanhamento: 11<br>(8,9)_vs_. 4 (6,5)<br>Violação do protocolo:<br>15 (12,2)_vs_. 8 (13,0)<br>Inelegíveis: 6 (4,8)_vs_.<br>1 (1,6)|
|**Chow et**|Placebo|69|Mediana:|82,3|Child Pugh A: 43,5|HCV: 12,9||1,35 meses|13/62 (21)||  
|**Autor,**|**Detalhes da**|**N**|**Idade em**|**Sexo M**|**Grau do carcinoma**|**Etiologia (%)**|**Tempo de**|**Tempo de**<br>**tratamento,**|**Suspensão n/N**|**Razão para**|
|---|---|---|---|---|---|---|---|---|---|---|
|**ano**|**Intervenção**||**anos**|**(%)**|**(%)**||**seguimento**|**mediana**<br>**(mín-máx)**|**(%)**|**suspensão n (%)**|
|**al. 2011**<sup>**188**</sup>|||60,9||Child Pugh B: 40,3|HBV: 53,2||(amplitude|||
||||(amplitude||Child Pugh C: 12,9|HBV e HCV:||0,03 –15,16)|||
||||31,1 – 80,9)||ECOG 0: 22,6<br>ECOG 1: 53,2|1,6|||||
||||||ECOG 2: 21,0||||||
||||||Okuda II: 56,5||||||
||Megestrol|21|63 ± 8|67|Child Pugh A: 52,3<br>Chid Pugh B: 285|HCV: 28,5<br>HBV: 66,6|NR|NR|Não houve<br>suspensão||
|**Villa et al.**|||||,|Álcool: 4,7||||NA|
|**2001**<sup>**190**</sup>|Placebo|24|60 ± 11|92|Child Pugh A: 41,6<br>Chid Pugh B: 29,1|HCV: 37,5<br>HBV: 62,5<br>Álcool: 0|||||
|**Octreotida**|||||||||||
|**Guo et al.**<br>**2009**<sup>**189**</sup>|Octreotida|177|Mediana não<br>relatada,<br>Amplitude<br>de 24 a 84<br>anos|83|Okuda III: 27<br>Variou de 5 a 100<br>entre os estudos que<br>relataram este dado|<br>NR|NR|NR|12/169 (7)|NR|
||Placebo ou<br>cuidados<br>paliativos|175|Mediana não<br>relatada,<br>amplitude de<br>24-87|84|Okuda III: 31<br>Variou de 10 a 100<br>entre os estudos que<br>relataram este dado|<br>NR|||0||  
|**Autor,**<br>**ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo M**<br>**(%)**|**Grau do carcinoma**<br>**(%)**|**Etiologia (%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx)**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão n (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Barbare et**<br>|Octreotida|135|65 ± 9|81|Child Pugh A: 67<br>CLIP score 2-3: 65|NR|31 meses|4 (0–26)<br>meses|4/135 (3)|NR|
|**al. 2009**<sup>**187**</sup>|Placebo|137|69 ± 9|69|Child Pugh A: 67<br>CLIP score 2-3: 67|NR|30 meses|5 (0–23)<br>meses|4/137 (3)||
||Octreotida  +<br>tamoxifeno|56|Mediana:<br>64,5 (39–84)|78,6|Child Pugh A: 55,4<br>Okuda II: 50,9|HCV: 33,3<br>HBV: 9,5<br>Álcool: 52,4|Mediana: 3<br>meses<br>(amplitude de<br>0,1–31)|NR|6/56 (11)|Octreotida +<br>tamoxifeno_vs_.<br>tamoxifeno:<br>Perda de|
|**Verset et**<br>**al. 2007**<sup>**191**</sup>|Tamoxifeno|53|Mediana: 68<br>(38–83)|83|Child Pugh A: 71,7<br>Okuda II: 52,2|HCV: 40,5<br>HBV: 10,8<br>Álcool: 40,5|||4/53 (8)|acompanhamento: 4<br>(7)_vs_. 2 (4)<br>Transplante: 1 (2)_vs_. 0<br>Evento adverso: 1 (2)<br>_vs_. 1 (2)<br>Quimioembolização: 0<br>_vs_. 1 (2)|  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control_ * n de pacientes considerados na análise de sobrevida ** n de pacientes total, porém análise de sobrevida considera apenas 15 pacientes.  
**<mark>Tabela AR</mark>** <mark>– Desfechos de eficácia dos estudos que avaliaram terapias endócrinas.</mark>  
|**Autor, ano**|**Mortalidade/Sobrevida**|**Mortalidade/Sobrevida**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**intervenção**|**controle**||**intervenção, n/N**|**controle, n/N**||**resposta**|**resposta**||
||**[mortalidade: n/N (%),**|**[mortalidade: n/N (%),**||**(%)**|**(%)**||**intervenção**|**controle**||
||**sobrevida: mediana em**|**sobrevida: mediana em**|||||**(mediana em**|**(mediana**||
||**meses]**|**meses]**|||||**meses)**|**em meses)**||
|**Tamoxifeno**||||||||||
|**Nowak et al.**|Sobrevida|global:|p=0,4|NR|NR|NA|NR|NR|NA|
|**2005**<sup>**182**</sup>|HR: 1,05 (IC95%|0,94 –1,16)||||||||
||Análise de subgrupo segun|do dose de tamoxifeno:||||||||
||20 mg ao dia: HR 0,88 (<br>40 mg ao dia: HR 1,00<br>60 mg ao dia: HR 1,03|IC95% 0,69 –1,44)<br>(IC95% 0,85–1,19)<br>(IC95% 0,81–1,31)|p=0,3<br>p=1,0<br>p=0,8|||||||
||120 mg ao dia: HR 1,29|(IC95% 1,04 –1,6)|p=0,02|||||||
|**Doffoel et al.**<br>**2008**<sup>**183**</sup>|Mortalidade: 58/62 (94%)|Mortalidade: 56/61 (92%)|NR|NR|NR|NA|NR|NR|NA|
||Sobrevida global: 13,8 meses|Sobrevida global: 11,0|p=0,68|||||||
||(IC95% 7,6–16,8)|meses (IC95% 7,3–15,1)||||||||
||Sobrevida global ano 1:|Sobrevida global ano 1:||||||||
||51% (IC95% 38–63)|46% (IC95% 33–58)||||||||
||Sobrevida global ano 2:|Sobrevida global ano 2:||||||||
||25% (IC95% 15–37)|22% (IC95% 12–33)||||||||
|**Groupe**|Mortalidade: 183/192 (95,3%)|Mortalidade: 177/184|NR|NR|NR|NA|NR|NR|NA|
|**d'Etude et**||(96,2%)||||||||  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**intervenção**|**Mortalidade/Sobrevida**<br>**controle**|**p-valor**|**Resposta**<br>**intervenção, n/N**|**Resposta**<br>**controle, n/N**|**p-valor**|**Tempo até**<br>**resposta**|**Tempo até**<br>**resposta**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**[mortalidade: n/N (%),**|**[mortalidade: n/N (%),**||**(%)**|**(%)**||**intervenção**|**controle**||
||**sobrevida: mediana em**<br>**meses]**|**sobrevida: mediana em**<br>**meses]**|||||**(mediana em**<br>**meses)**|**(mediana**<br>**em meses)**||
|**de**<br>**Traitement**<br>**du**|Sobrevida global: 135,5 dias<br>(IC95% 112-189)|Sobrevida global: 176 dias<br>(IC95% 141-227)|p=0,21|||||||
|**Carcinome**|Sobrevida ano 1: 23,4%|Sobrevida ano 1: 28.3%|NR|||||||
|**Hépatocellul**|(IC95% 17,4-29,4)|(95% CI, 21.7-34.8)||||||||
|**aire, 2004**<sup>**184**</sup>|HR morte: 1,14<br>(IC95% 0,93-1,40)||NR|||||||
||HR morte ajustada por fatores<br>prognósticos: 1,08 (IC95%<br>0,87-1,33)||p=0,48|||||||
|**Pan et al.**<br>**2003**<sup>**185**</sup>|Mortalidade: 21/24 (88%)|Mortalidade: 15/15 (100%)|NR|RC: 4/24 (16,7%)<br>RP: 7/24 (29,2%)|RC: 0<br>RP: 0|NR|NR|NR|NA|
||Sobrevida global: 12,8 meses|Sobrevida global: 5,5|NR|DE: 9/24 (37,5%;)|DE: 4/15|||||
|||meses||PD: 4/24 (16,7%)|(26,7%)<br>PD: 11/15|||||
||Sobrevida global ano 1:|Sobrevida global ano 1:|p<0,01||(73,3%)|||||
||63,7%|21,1%<br>Sobrevida global ano 2:|p<0,01|||||||
||Sobrevida global ano 2:|0%||||||||
||25,4%||p<0,01|||||||
|||Sobrevida global ano 3:||||||||  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**intervenção**|**Mortalidade/Sobrevida**<br>**controle**|**p-valor**|**Resposta**<br>**intervenção, n/N**|**Resposta**<br>**controle, n/N**|**p-valor**|**Tempo até**<br>**resposta**|**Tempo até**<br>**resposta**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**[mortalidade: n/N (%),**|**[mortalidade: n/N (%),**||**(%)**|**(%)**||**intervenção**|**controle**||
||**sobrevida: mediana em**|**sobrevida: mediana em**|||||**(mediana em**|**(mediana**||
||**meses]**|**meses]**|||||**meses)**|**em meses)**||
||Sobrevida global ano 3: 13,3%|0%||||||||
|**Manesis et**|Sobrevida global:|Sobrevida global:|p=0,02|NR|NR|NA|NR|NR|NA|
|**al. 1995**<sup>**186**</sup>|TAM+TRIP: 282 dias (IC95%|127 dias (IC95% 94-161)|7|||||||
||172-392)||(TAM+<br>TRIP|||||||
||FLU+TRIP: 112 dias (IC95%||_vs_.|||||||
||67-157)||demais<br>grupos)<br>NS|||||||
|**Uchino et al.**<br>**1993**<sup>**195**</sup>|Sobrevida ano 1: 83,3%|Sobrevida ano 1: 78,6%|NS|RP: 4/12(33,3%)|RP: 3/14 (21,4%)|NR|NR|NR|NR|
||||**Terapias a**|**ntiandrogênicas**||||||
|**Grimaldi et**|Mortalidade:|Mortalidade:|NR|_NIT + P_:|_P + P_: 0|NR|NR|NR|NR|
|**al. 1998**<sup>**196**</sup>|_NIT + P_: 51/58 (87,9%)<br>_GOS/TRIP + P:_57/61|P + P: 52/59 (88,1%)||RC: 1/58 (1,7%)||||||
||(93,4%)|||_GOS/TRIP + P:_||||||
||_NIT + GOS/TRIP + P:_54/60|||RP:2/61 (3,3%)||||||
||(90,0%)|||||||||
|||||_NIT + GOS/TRIP_||||||
||Sobrevida:|Sobrevida:||_+ P:_||||||
||_NIT + P_: 3,6 meses|P + P: 5,8 meses|p=0,18|RP:1/60 (1,7%)||||||
||_GOS/TRIP + P:_2,7 meses||6|||||||  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N (%),**|**Mortalidade/Sobrevida**<br>**controle**<br>**[mortalidade: n/N (%),**|**p-valor**|**Resposta**<br>**intervenção, n/N**<br>**(%)**|**Resposta**<br>**controle, n/N**<br>**(%)**|**p-valor**|**Tempo até**<br>**resposta**<br>**intervenção**|**Tempo até**<br>**resposta**<br>**controle**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**sobrevida: mediana em**|**sobrevida: mediana em**|||||**(mediana em**|**(mediana**||
||**meses]**|**meses]**|||||**meses)**|**em meses)**||
||_NIT + GOS/TRIP + P:_3,9<br>meses|||||||||
|**Megestrol**||||||||||
|**Chow et al.**|Sobrevida global: 1,88 meses|Sobrevida global: 2,14|p=0,16|NR|NR|NA||||
|**2011**<sup>**188**</sup>|HR: 1,25 (IC95% 0,92–1,71)|meses||||||||
|**Villa et al.**|Sobrevida global: 18 meses|Sobrevida global: 7 meses|p=0,00|NR|NR|NA|Tempo até|Tempo até|p=0,02|
|**2001**<sup>**190**</sup>|(IC95% 13,47–22,53)|(IC95% 3,01–10,99)|9||||progressão do|progressão||
||||||||tumor: 22|do tumor: 9||
||Sobrevida ano 1: 83%|Sobrevida ao 1: 29%|||||meses|meses||
||Sobrevida ano 2: 25%|Sobrevida ano 2: 15%||||||||
||Sobrevida ano 3 15%|Sobrevida ano 3 15%||||||||
||Sobrevida ano 4: 15%|Sobrevida ano 4: 4%||||||||
||||**O**|**ctreotide**||||||
|**Guo et al.**|Sobrevida aos seis me|ses de tratamento.||NR|NR||NR|NR|NA|
|**2009**<sup>**189**</sup>|RR= 1,30 IC 95% (1,0<br>Efeitos ale|2–1,66; I<sup>2</sup>=58,8%).<br>atórios:|p=0,03|||||||
||RR = 1,35 IC 95% (0,9|2–1,97; I<sup>2</sup>=58,8%)||||||||
||||p=0,12|||||||
||Sobrevida aos 12 mes<br>Efeitos ale|es de tratamento.<br>atórios:|p=0,16|||||||
||RR= 2,72 IC 95% (0,6|6–11,16; I<sup>2</sup>=58,8%)||||||||
|**Barbare et**|Mortalidade: 126/135 (93%)|Mortalidade: 123/137|NR|PD: 128/135 (95%)|PD: 126/137|NR|NR|Tempo em|NR|  
|**Autor, ano**|**Mortalidade/Sobrevida**|**Mortalidade/Sobrevida**|**p-valor**|**Resposta**|**Resposta**|**p-valor**|**Tempo até**|**Tempo até**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
||**intervenção**|**controle**||**intervenção, n/N**|**controle, n/N**||**resposta**|**resposta**||
||**[mortalidade: n/N (%),**|**[mortalidade: n/N (%),**||**(%)**|**(%)**||**intervenção**|**controle**||
||**sobrevida: mediana em**|**sobrevida: mediana em**|||||**(mediana em**|**(mediana**||
||**meses]**|**meses]**|||||**meses)**|**em meses)**||
|**al. 2009**<sup>**187**</sup>|SG em 6 meses: 56%|(89,7%)|NS|RC: 0|(92%)|||resposta||
||SG em 12 meses: 28%|SG em 6 meses: 53%|NS|RP: 0|RC: 1/137|||completa do||
||SG em 24 meses: 8%|SG em 12 meses: 30%|NS||RP: 3/137|||tumor: 3, 4||
|||SG em 24 meses: 14%||||||meses||
||6.53 (95% CI, 4.8–8.3) meses|7.03 (95% CI, 5.43–8.53)|0,52|||||||
||TLP: 3,37 (IC 95% 3,03-4,13)|TLP: 3,93 (IC 95% 31,13-|0,56|||||||
||meses|4,09) meses||||||||
|**Verset et al.**|Mediana sobrevida: 3 meses|Mediana sobrevida: 6|P=0,60|PD: 16/25 (52%)|PD: 15/26|p>0,05|NR|NR|NA|
|**2007**<sup>**191**</sup>|(IC95% 1,4-4,5)|meses (IC95% 2,0-10,0)|9|13/20 (65%)|(59,3%)|para||||
|||||RC: 0|RC: 0|todas as||||
|||||RP: 1/25 (4%) 1/20|RP: 1/26 (3,7%)|compar||||
|||||(5%)<br>DE: 8/25 (32%)<br>6/20 (30%)|DE: 10/26 (37%)|ações||||  
Legenda: GOS: Gosserrelina; FLU: Flutamina; NIT: Nitulamida; TRIP: Triptorrelina; TAM: Tamoxifeno; <mark>n: número de pacientes que apresentaram o evento; N: número de pacientes; P: Placebo; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**<mark>Tabela AS</mark>** <mark>– Eventos adversos dos estudos que avaliaram terapias endócrinas.</mark>  
||**GRETCH**|**, 2004**<sup>**184**</sup>|**Uchino et**|**al. 1993**<sup>**195**</sup>|**Chow et al**|**.** **2011**<sup>**188**</sup>|**Barbare et**|**al.** **2009**<sup>**187**</sup>|**Verset et**|**al.** **2007**<sup>**191**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>|**Leuprorrelina**||**Tamoxifeno+**<br>**Medroxiprogeste**||||||**Octreotida**||
|**adversos (Grau**|**+flutamida+**|**Tamoxifeno**|**-rona+**|**Quimioterapia**|**Megestrel**|**Placebo**|**Octreotida**|**Placebo**|**+**|**Tamoxifeno**|
|**3-5)**|**tamoxifeno**<br>**(N=192)**|**(N=184)**|<br>**quimioterapia**<br>**(N=12)**|**(N=14)**|**(N=123)**|**(N=62)**|**(N=135)**|**(N=137)**|**Tamoxifeno**<br>**(N=56)**|**(N=53)**|
|Alopecia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Anemia n (%)|NR|NR|NR|NR|3 (2)|1 (2)|NR|NR|NR|NR|
|Anorexia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Ascite n (%)|NR|NR|NR|NR|4 (3)|4 (6)|NR|NR|NR|NR|
|Azia n (%)|NR|NR|NR|NR|NR|NR|0 (0)|0 (0)|NR|NR|
|Cefaleia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Diarreia n (%)|NR|NR|NR|NR|NR|NR|1 (0,76)|1 (0,75)|1 (1,8)|0|
|Dispneia n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor abdominal n<br>(%)|NR|NR|NR|NR|4 (3)|1 (2)|NR|NR|NR|NR|
|Fadiga n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Ginecomastia n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|0|1 (1,9)|
|Hiperglicemia n<br>(%)|NR|NR|NR|NR|NR|NR|9 (6,82)|7 (5,26)|NR|NR|
|Hipertensão n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Infecção n (%)|NR|NR|NR|NR|1 (1)|1 (2)|NR|NR|NR|NR|
|Leucopenia n<br>(%)|NR|NR|2<sup>§</sup>(16,7)|2<sup>§</sup>(14,3)|NR|NR|NR|NR|NR|NR|  
||**GRETCH**|**, 2004**<sup>**184**</sup>|**Uchino et**|**al. 1993**<sup>**195**</sup>|**Chow et al**|**.** **2011**<sup>**188**</sup>|**Barbare et**|**al.** **2009**<sup>**187**</sup>|**Verset et**|**al.** **2007**<sup>**191**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**|**Leuprorrelina**||**Tamoxifeno+**<br>**Medroxiroeste**||||||**Octreotida**||
|**adversos (Grau**|**+flutamida+**|**Tamoxifeno**|**pg**<br>**-rona+**|**Quimioterapia**|**Megestrel**|**Placebo**|**Octreotida**|**Placebo**|**+**|**Tamoxifeno**|
|**3-5)**|**tamoxifeno**<br>**(N=192)**|**(N=184)**|<br>**quimioterapia**<br>**(N=12)**|**(N=14)**|**(N=123)**|**(N=62)**|**(N=135)**|**(N=137)**|**Tamoxifeno**<br>**(N=56)**|**(N=53)**|
|Morte n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Nausea n (%)|26 (14)|8 (4)|NR|NR|||0 (0)|0 (0)|0|1 (1,9)|
|Neutropenia n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Outros n (%)|68 (35)|36 (20)|2<sup>§</sup>(16,7)|3<sup>§</sup>(21,4)|22 (18)|8 (13)|24 (18)|36 (26)|||
|Rash n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Reação mãos e<br>pés n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Reação no local|||||||||||
|de aplicação n|NR|NR|NR|NR|NR|NR|1 (1)|0 (0)|NR|NR|
|(%)|||||||||||
|Rubor n (%)|NR|NR|NR|NR|NR|NR|NR|NR|0|1 (1,9)|
|Sangramento n<br>(%)|NR|NR|NR|NR|1 (1)|0|NR|NR|NR|NR|
|Trombocitopeni<br>a n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Vômito n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Todos n (%)|94 (49)|44 (24)|NR|NR|35 (28)|15 (24)|NR|NR|NR|NR|  
<mark>Legenda:</mark><sup>§</sup> <mark>E</mark> ventos adversos reportados sem estratificação de grau; NR: não relatado.

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **<mark>Outras terapias</mark>** -->
**<mark>Tabela AT</mark>** <mark>– Características dos estudos que avaliaram outras terapias.</mark>  
|**Autor, ano de**<br>**publicação**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Lamivudina**||||
|**Xu et al. 2014**<sup>**136**</sup>|Ensaio clínico<br>randomizado, fase<br>III, em um hospital<br>na China.|Avaliar a eficácia de<br>lamivudina na prevenção<br>da reativação de hepatite<br>B e no aumento da<br>sobrevida de pacientes<br>com CHC.|Pacientes com CHC,<br>HBsAg+, que nunca haviam<br>recebido tratamento antiviral<br>prévio, Child Pugh A ou B, e<br>sem coinfecção por hepatite<br>C ou HIV. Foram incluídos<br>181 pacientes.|Lamivudina<br>100 mg VO +<br>TACE<br>(5-Fu 750–<br>1000 mg e<br>DDP 60–80<br>mg)|TACE<br>(5-Fu 750–1000 mg e DDP<br>60–80 mg)|Baixo risco de viés.|
||||**Vitamina K2**||||
|||||||Risco incerto de viés.<br>Qualidade da evidência baixa|
|**Zhong et al.**<br>**2013**<sup>**193**</sup>|Revisão sistemática<br>com metanálise|Avaliar a eficácia de<br>análogos de vitamina K2<br>em pacientes com CHC<br>após ressecção hepática<br>curativa ou ablação local.|Seis ensaios clínicos<br>randomizados e um estudo de<br>coorte, totalizando 930<br>pacientes. Todos os estudos<br>foram realizados no Japão e a<br>qualidade metodológica dos<br>estudos variou de baixa (3<br>estudos), moderada (2) a alta<br>(2).|Vitamina K2<br>45-90 mg/dia|Sem tratamento|a alta. Busca ampla, porém,<br>com probabilidade de viés de<br>publicação avaliada pelo<br>_funnel plot_. Heterogeneidade<br>estatística importante na<br>meta-análise de recorrência<br>do tumor no ano 1 e<br>sobrevida global no ano 3.<br>Após exclusão de estudos que<br>geraram a heterogeneidade,<br>os resultados mudam de<br>direção.|  
||||**Vitamina K3**||||
|---|---|---|---|---|---|---|
|**Sarin et al.**<br>**2006**<sup>**194**</sup>|Ensaio clínico<br>randomizado, fase<br>III, realizado em um<br>centro na Índia.|Avaliar a eficácia de altas<br>doses de vitamina K3 no<br>tratamento de pacientes<br>com CHC avançado e<br>trombose de veia porta.|Pacientes com CHC<br>avançado, não ressecável,<br>com BCLC C e com padrão<br>invasivo, que não realizaram<br>tratamento nos úlmos 6<br>meses.  Foram incluídos 42<br>pacientes.|Vitamina K3<br>50 mg/dia IV<br>com aumento<br>diário de 50<br>mg por 6 dias,<br>seguido de 40<br>mg/dia IM por<br>duas semanas.|Placebo|Alto risco de viés. Não relata<br>método de randomização, de<br>sigilo da alocação ou<br>cegamento dos participantes.<br>Dados de desfechos<br>incompletos adequados,<br>realizada análise por intenção<br>de tratar.|  
Legenda: 5-Fu: 5 Fluoracil; BCLC <mark>:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ;</mark> DD <mark>P: Cisplatina; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; ECR: Ensaio clínico randomizado; IM: Intramuscular; IV: Intravenoso; NR: Não relatado; SC: Subcutâneo; TACE: quimioembolização transarterial; V</mark> O: Via oral.  
**<mark>Tabela AU</mark>** <mark>– Características dos pacientes em estudos que avaliaram outras terapias.</mark>  
|**Autor, ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia**<br>**(%)**<br>**Lamivudi**|**Tempo de**<br>**seguimento**<br>**na**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||Lamivudina +<br>TACE|92|56,0 ±<br>11,7|90,2|Child Pugh<br>A: 75<br>Child Pugh|HBeAg+:<br>39|NR|NR|3/92 (3,2)|Lamivudina + TACE_vs_.|
|**Xu et al.**|||||B: 25|||||TACE:|
|**2014**<sup>**136**</sup>|||||Child Pugh|||||Perda de acompanhamento:|
||TACE|89|55,1 ±<br>11,8|91|A: 72<br>Child Pugh<br>B: 28|HBeAg+:<br>39|NR|NR|7/89 (7,8)|3 (3,2)_vs_. 7 (7,8)|
|||||||**Vitamina**|**K2**||||
|**Zhong et al.**<br>**2013**<sup>**193**</sup>|Vitamina K2|541<br>45mg/dia:<br>356<br>90 mg/dia:<br>185|62,8-69,1|47,8 a<br>80,0|Child Pugh<br>A: 71,4 a<br>90,0|HCV: 60 a<br>100<br>HBV: 0 a<br>52|Até 48 meses|NR|NR|NR|
||Sem<br>tratamento|389|60,5-69,1|55,1 a<br>74,5|Child Pugh<br>A: 73,3 a<br>90,2|HCV: 44 a<br>100<br>HBV: 0 a<br>37,3|||||
|||||||**Vitamina**|**K3**||||
|**Sarin et al.**<br>**2006**<sup>**194**</sup>|Vitamina K3|23|Mediana:<br>48|78,3|Child Pugh<br>A: 26,1|HCV: 17,4<br>HBV: 73,9|26 ± 10,5<br>meses|NR|NR|NR|  
|**Autor, ano**|**Detalhes da**<br>**Intervenção**|**N**|**Idade em**<br>**anos**|**Sexo**<br>**M**<br>**(%)**|**Grau do**<br>**carcinoma**<br>**(%)**|**Etiologia**<br>**(%)**|**Tempo de**<br>**seguimento**|**Tempo de**<br>**tratamento,**<br>**mediana (mín-**<br>**máx)**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão n**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||(amplitud||Child Pugh||Mediana 24,5||||
||||e 27–72)||B: 73,9||meses||||
||||||Okuda II:||(amplitude||||
||||||95,7||12-48)||||
||||||Child Pugh||||||
||||Mediana:||A: 31,6||||||
||Placebo|19|54|789|Child Pugh|HCV: 15,8|||||
||||(amplitud|,|B: 68,4|HBV: 78,9|||||
||||e 41-69)||Okuda II:||||||
||||||100||||||  
<mark>Legenda: BCLC:</mark> _<mark>Barcelona-Clinic Liver Cancer</mark>_ <mark>; CHC: Carcinoma hepatocelular ; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; HBV: Hepatite B; HCV: Hepatite C; IC: Intervalo de confiança; n: número de pacientes que apresentaram o evento; IQR: Intervalo interquartil; N: número de pacientes; NR: Não relatado; TACE: quimioembolização transarterial; U</mark> ICC: _Union for International Cancer Control._  
**<mark>Tabela AV</mark>** <mark>– Desfechos de eficácia dos estudos que avaliaram outras terapias.</mark>  
|**Autor,**<br>**ano**|**Mortalidade/**<br>**Sobrevida**<br>**intervenção**<br>**[mortalidade: n/N**<br>**(%), sobrevida:**<br>**mediana em meses]**|**Mortalidade/**<br>**Sobrevida controle**<br>**[mortalidade: n/N**<br>**(%), sobrevida:**<br>**mediana em meses]**|**p-valor**|**Resposta intervenção,**<br>**n/N (%)**|**Resposta controle,**<br>**n/N (%)**|**p-**<br>**valor**|**Tempo até**<br>**resposta**<br>**intervenção**<br>**(mediana em**<br>**meses)**|**Tempo até**<br>**resposta**<br>**controle**<br>**(mediana em**<br>**meses)**|**p-valor**|
|---|---|---|---|---|---|---|---|---|---|
|||||**Lamivudina**||||||
|**Xu et**<br>**al.**<br>**2014**<sup>**136**</sup>|Sobrevida ano 1: 83%<br>Sobrevida ano 2: 69%<br>Sobrevida ano 3:<br>58%|Sobrevida ano 1: 60%<br>Sobrevida ano 2: 48%<br>Sobrevida ano 3: 48%|p=0,002|HBeAg soroconversão<br>ano 1: 4/92 (4,3%)<br>HBV-DNA indetectável<br>ano 2: 42/92 (45,6%)|HBeAg<br>soroconversão ano<br>1: 3/89 (3,3%)<br>HBV-DNA<br>indetectável: 10/89<br>(11,2%)|p=<br>0,717<br>p <<br>0,001|Tempo até a<br>progressão: 8,2<br>meses<br>RR: 0,572 (IC95%<br>0,386–0,849)|Tempo até a<br>progressão: 4,3<br>meses|p=0,005<br>p=0,006|
|||||**Vitamina K**|**2**|||||
||Metanálise de|efeitos fixos:|||||Meta-análise de|efeitos fixos:||
||Sobrevia global ano 1:|RR 1,03 (IC95% 1,01–|||||Recorrência do|tumor ano 1:||
||1,05; I<br>Subgrupo VK2 45mg|<sup>2</sup>= 0%)<br>/dia: RR 1,03 (IC95%|p=0,02<br>=002||||RR: 0,67 (IC95% 0,<br>Subgrupo VK2 45|39–1,13; I<sup>2</sup>: 64%)<br>mg/dia: RR 0,66|p=0,13|
|**Zhong**|1,00–|1,06)|p,||||(IC95% 0,4|1–1,07)|p=0,09|
|**et al.**<br>**2013**<sup>**193**</sup>|Sobrevia global ano 2:<br>1,19; I|RR 1,11 (IC95% 1,03–<br> <sup>2</sup>= 0%)|p=0,005<br>p=0,02|NR|NR|NR|Após excluir estu<br>_al._20<br>RR 0,56 (95% CI 0,|do Yoshida_et_<br>11:<br>34–0,90; I<sup>2</sup>25%)|p=0,02|
||Sobrevia global ano 3:<br>1,28; I<sup>2</sup>|RR 1,14 (IC95% 1,02–<br>= 46%)|p=0,12||||Recorrência do|tumor ano 2:||
||Após excluir estudo|de coorte Hosho_et_|||||RR: 0,65 (IC95% 0,|51–0,83; I<sup>2</sup>: 0%)|p<0,01|  
_al._ 2008:  
RR 0,12 (IC95% 0,97–1,28)  
Recorrência do tumor ano 3: RR: 0,70 (IC95% 0,58–0,85; I<sup>2</sup> = 46%) p<0,01  
||Mortalidade: 23/23<br>(100%)<br>Sobrevida global: 6<br>meses (amplitude 1–<br>37)|Mortalidade: 19/19<br>(100%)<br>Sobrevida global: 5<br>meses (amplitude|NR<br>p=0,55|**Vitamina**<br>Taxa de Resposta<br>Objetiva: 4/23 (17,4%)<br>Taxa de controle da|**K3**<br>Taxa de Resposta<br>Objetiva: 1/19<br>(5,3%)<br>Taxa de controle da||
|---|---|---|---|---|---|---|
|**Sarin et**<br>**al.**<br>**2006**<sup>**194**</sup>|<br>Sobrevida ano 1:7/23<br>(30,4%)<br>Sobrevida ano 2: 3/23|1,5–21)<br>Sobrevida ano 1: 3/19<br>(15,8%)<br>|p=0,31<br>|doença: 8/23 (34,8%)<br>RC: 1/23 (4,3%)|doença: 3/19<br>(15,8%)|NR<br>NR|
||(13,0%)<br>Sobreida ano 3: 1/23|Sobrevida ano 2:<br>1/19 (5,3%)|p=0,61<br>p=1,00|RP: 3/23 (13%)<br>DE: 4/23 (17,4%)|RC: 0<br>RP: 1/19 (5,3%)||
||v<br>(4,3%)<br>Sobrevida ano 4: 0|Sobrevida ano 3:  0<br>(0)||PD: 15/23 (65,2%)|DE: 2/19 (10,5%)<br>PD: 16/19 (84,2%)||  
<mark>Legenda: n: número de pacientes que apresentaram o evento; N: número de pacientes; DE: Doença estável; PD: Progressão da doença;</mark> RC: Resposta completa; RP: Resposta parcial; RR: Risco relativo; NA: Não se aplica; NR: Não relatado; NS: Não significativo; IC: Intervalo de confiança; HR: _Hazard ratio_ .  
**<mark>Questão de Pesquisa 6:</mark>** <mark>Qual a eficácia e segurança do DEB (drug-eluting bead) x químioembolização clássica, para o carcinoma hepatocelular estágio B?</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **<mark>1. Estratégia de busca</mark>** -->
<mark>MEDLINE via Pubmed: ((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma))) AND (((Drug-eluting beads OR Drug eluting beads OR DEB)) AND ("Chemoembolization, Therapeutic"[Mesh] OR Chemoembolization))</mark>  
<mark>Total: 261 referências</mark>  
<mark>Data do acesso: 10/08/2017</mark>  
<mark>EMBASE: (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'singleblind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim) AND ((('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('drug eluting bead'/exp OR 'drug eluting bead' OR 'drug-eluting beads' OR 'drug-eluting bead' OR 'deb') AND [embase]/lim) AND (('chemoembolization'/exp OR 'chemoembolization') AND [embase]/lim))</mark>  
<mark>Total: 130 referências</mark>  
<mark>Data do acesso: 11/08/2017</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2.** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 391 referências (261 no MEDLINE e 130 no Embase). Destas, 71 foram excluídas por estarem duplicadas. Trezentas e quarenta referências foram triadas por meio da leitura de título e resumos, das quais 38 tiveram seus textos completos avaliados para confirmação da elegibilidade. Trinta estudos foram excluídos por apresentarem resultados de pacientes classe B na escala Child-Pugh junto com resultados de pacientes de outras classes da mesma escala e um estudo foi excluído por analisar apenas 3 pacientes. Os critérios de inclusão dos estudos consistiram em avaliar artigos comparativos que abordassem o uso das tecnologias de interesse em pacientes com carcinoma hepatocelular. No total, foram incluídos seis estudos de sete referências</mark><sup>197-203</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A descrição sumária dos estudos encontra-se na</mark> **<mark>Tabela AW</mark>** <mark>. As características dos pacientes encontram-se descritas</mark>  
<mark>na</mark> **<mark>Tabela AX</mark>** <mark>. As</mark> **<mark>Tabelas AY</mark>** <mark>e</mark> **<mark>AZ</mark>** <mark>apresentam dados de eficácia e segurança, respectivamente.</mark>  
**<mark>Tabela AW</mark>** <mark>– Características dos estudos que analisaram a eficácia e segurança do DEB (</mark> _<mark>drug-eluting bead</mark>_ <mark>) x químioembolização clássica, para o carcinoma hepatocelular estágio B.</mark>  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Chen  et al.**<br>**2016**<sup>**197**</sup>|Revisão<br>sistemática com<br>meta-análise|Pesquisar a melhor<br>estratégia de TACE para<br>casos de CHC<br>irressecável|Pacientes com CHC irressecável|**cTACE**|**DEBTACE**|Moderado risco de viés<br>(Analisa ECR e estudos<br>observacionais na<br>mesma meta-análise,<br>sem análise de subgrupo)|
|**Golfieri et al.**<br>**2014**<sup>**198**</sup>|Ensaio clínico<br>randomizado|Comparar a utilização de<br>DEBTACE e cTACE em<br>relação aos seguintes<br>desfechos: sobrevida em 2<br>anos, tempo até<br>progressão do tumor e<br>eventos adversos.|Pacientes com idade superior a 18 anos,<br>diagnosticados com CHC inelegível para tratamento<br>curativo ou prévia falha/recorrência após<br>ressecção/ablação, diagnóstico por biópsia de acordo<br>com os critérios AALSD. Outros critérios de<br>inclusão foram: classe A ou B na escala Child-Pugh<br>(escore 7) e ECOG ≤ 1, sem tratamento prévio para<br>as lesões alvo do estudo.|**cTACE**|**DEBTACE**|Alto risco de viés (não<br>relata método do sigilo<br>de alocação, usou mITT,<br>amostra menor que a<br>planejada)|
|**Lammer et al.**<br>**2010; Vogl et**<br>**al. 2011**<sup>**199, 200**</sup>|Ensaio clínico<br>randomizado|Avaliar a eficácia e a<br>segurança de DEBTACE<br>e cTACE no tratamento<br>de pacientes com CHC e<br>cirrose|Pacientes com idade superior a 18 anos, CHC<br>inelegível para ressecção ou ablação percutânea,<br>sem tratamento prévio de radioterapia, quimioterapia<br>ou embolização transarterial (com ou sem<br>quimioterapia), pontuação 0 a 1 na escala ECOG e<br>classe A ou B na escala Child-Pugh|**cTACE**|**DEBTACE**|Risco moderado (utilizou<br>mITT para a correção de<br>perdas)|
|||Comparar eficácia de|Pacientes com CHC inelegível para ressecção ou|||Alto risco de viés, dada a|
|**Morimoto et**|Estudo de|curto prazo entre cTACE|ablação percutânea, sem TACE nem quimioterapia|||carência de dados sobre|
|**al. 2016**<sup>**201**</sup>|coorte<br>retrospectiva|e SAPTACE em pacientes<br>sem TACE prévia e com|sistêmica prévias, sem evidência de invasão<br>macrovascular ou metástase extra-hepática, classe A|**cTACE**|**SAPTACE**|características iniciais<br>dos pacientes e tamanho|
|||CHC irressecável|ou B na escala Child Pugh, status 0 ou 1 na escala|||da amostra|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||ECOG, função hepática adequada (albumina sérica<br>>2,0 g/dL e bilirrubina total <3 mg/dL, função renal<br>adequada (creatinina sérica <1,5 vezes o limite<br>superior do intervalo normal.||||
|||||||Alto risco de viés (dados|
|**Duan et al.**<br>**2016**<sup>**202**</sup>|Estudo de<br>coorte<br>retrospectiva|Avaliar eficácia e<br>segurança de curto prazo<br>em pacientes com CHC<br>submetidos a cTACE,<br>DEBTACE ou hqTACE|Pacientes com CHC sem metástase extra-hepática e<br>sem tratamento sistêmico concomitante com<br>Sorafenibe.<br>Estratificação da análise com pacientes classe B na<br>escala Child-Pugh, performance status 1 na escala<br>ECOG, doença bilobar ou recorrência pós ressecção|**cTACE**|**DEBTACE**|retrospectivos, pacientes<br>receberam mais de um<br>tratamento e foram<br>considerados em mais de<br>um grupo de<br>comparação, não|
|||||||controlou confundidores)|
|**Dhanasekaran**<br>**et al. 2010**<sup>**203**</sup>|Estudo de<br>coorte<br>retrospectiva|Comparar mortalidade e<br>sobrevida a longo prazo<br>após tratamento com<br>cTACE ou DEBTACE<br>em pacientes com CHC<br>irressecável|Pacientes com CHC irressecável, excluídos<br>pacientes que: a) foram previamente submetidos a<br>ressecção ou transplante, b) receberam embolização<br>branda ou radioembolização com Y 90, c) receberam<br>terapia com mais de um agente de embolização,<br>d) receberam quimioterapia sistêmica, como<br>Sorafenibe.|**cTACE**|**DEBTACE**|Alto risco (dados<br>retrospectivos, não<br>controle de<br>confundidores)|  
<mark>Legenda: CHC: carcinoma hepatocelular; cTACE: quimioembolização transarterial convencional; ECOG: escala de desempenho da</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>; 3DCRT: radioterapia conformal três dimensões, DEBTACE: quimioembolização transarterial com grânulos eluentes de fármacos, hqTACE: quimioembolização transarterial com grânulos QuadraSpheres eluentes de doxorrubicina, SAP: quimioembolização transarterial com grânulos eluentes de epirrubicina, BCLC</mark> _<mark>: Barcelona Clinic Liver Cancer</mark>_ <mark>, AALSD :</mark> _<mark>American Association for the Study of Liver Diseases.</mark>_  
**<mark>Tabela AX</mark>** <mark>– Características dos pacientes incluídos nos estudos que analisaram a eficácia e segurança do DEB (</mark> _<mark>drug-eluting bead</mark>_ <mark>) x químioembolização clássica, para o carcinoma hepatocelular estágio B.</mark>  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade,**<br>**intervenção**|**Idade,**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|<br>**Tamanho do tumor**<br>**(mm)**|**Pontuação**<br>**ECOG**|**Bilirrubina total**<br>**(mg/dL), mediana**<br>**(mín- máx)**|**Tempo de**<br>**seguimento**<br>**(Meses)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Chen  et al.**<br>**2016**<sup>**197**</sup>|339 pacient<br>CHC cla|es com<br>sse B|NR|NR|NR|NR|NR|NR|NR|NR|
|**Golfieri et al.**<br>**2014**<sup>**198**</sup>|11|14|NR|NR|NR|NR|NR|NR|NR|NR|
|**Lammer et al.**|||||||||||
|**2010; Vogl et**|19|16|NR|NR|NR|NR|NR|NR|NR|NR|
|**al. 2011**<sup>**199, 200**</sup>|||||||||||
|**Morimoto et**<br>**al. 2016**<sup>**201**</sup>|13|14|NR|NR|NR|NR|NR|NR|NR|NR|
|**Duan et al.**<br>**2016**<sup>**202**</sup>|41|10|NR|NR|NR|NR|NR|NR|NR|NR|
|**Dhanasekaran**<br>**et al. 2010**<sup>**203**</sup>|11|11|NR|NR|NR|NR|NR|NR|NR|NR|  
<mark>Legenda: I: intervenção; C: controle; N: número de pacientes; n: número de pacientes que apresentaram o evento; ECOG:</mark> _<mark>Eastern Cooperative Oncology Group</mark>_ <mark>NR: não relatado.</mark>  
**<mark>Tabela AY</mark>** <mark>– Desfechos de eficácia dos estudos que analisaram a eficácia e segurança do DEB (</mark> _<mark>drug-eluting bead</mark>_ <mark>) x químioembolização clássica, para o carcinoma hepatocelular estágio B.</mark>  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**|**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Chen  et al.**<br>**2016**<sup>**197**</sup>|DEBTACE<br>cTACE|Taxe de SG em 1 ano:<br>RR: 18,88<br>IC 95%:(5,69—62,60)|0,0001|NR|NR|**Resposta Objetiva**<br>RR:1,20<br>IC 95%:(0,46—3,14)<br>**Controle da doença**<br>RR 1,98|NR|
|||||||IC 95%: (0,92—4,24)||
|**Golfieri et al.**<br>**2014**<sup>**198**</sup>|DEBTACE<br>(n: 14)|NR||NR||**Taxa de resposta (%)**<br>RC em 1, 3 e 6 anos: 35,7; 50; 75|0,214<br>0,66|
||cTACE<br>(n:11)|NR||NR||**Taxa de resposta (%)**<br>RC em 1, 3 e 6 anos: 70; 66,7; 57,1|0,447|
||DEBTACE|NR||NR||**Taxa de resposta (%)**<br>RC: 25<br>RO: 44||
|**Lammer et al.**<br>**2010**<sup>**199**</sup>|(n: 16)||NR|||CD: 63<br>**Taxa de resposta (%)**|NR|
||cTACE<br>(n:19)|NR||NR||RC: 16<br>RO: 21||
|||||||CD: 32||
|**Morimoto et**<br>**al. 2016**|DEBTACE<br>(n: 13)<br>cTACE<br>(n:14)|NR<br>NR|0,169|NR<br>NR||**NR**<br>**NR**|NR<br>NR|
|**Duan et al.**||NR|NR|NR||**Pacientes de alto risco**|Pacientes|  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**<br>**Sobrevida Livre de Progressão**<br>**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|
|**2016**<sup>**202**</sup>||||**Taxa de resposta objetiva (%)**|de alto|
||DEBTACE|||Em todo o fígado: 56|risco|
||(n: 10)|||Lesões tratadas: 64|0,76|
|||||**Controle da doença (%)**|0,558|
|||||Em todo o fígado: 68|0,823|
|||||Lesões tratadas: 76|0,652|
|||||**Pacientes de baixo risco**|Pacientes|
|||||**Taxa de resposta objetiva (%)**|de baixo|
|||||Em todo o fígado: 63,7|risco|
|||||Lesões tratadas: 95,5|NR|
|||||**Controle da doença (%)**||
|||||Em todo o fígado: 63,8||
|||||Lesões tratadas: 95,5||
|||||**Pacientes de alto risco**||
|||||**Taxa de resposta objetiva (%)**||
|||||Em todo o fígado: 48,3||
|||||Lesões tratadas: 51,8||
|||||**Controle da doença (%)**||
||cTACE|||Em todo o fígado: 61,2||
||(n:41)|||Lesões tratadas: 67,1||
|||||**Pacientes de baixo risco**||
|||||**Taxa de resposta objetiva (%)**||
|||||Em todo o fígado: 79,8<br>Lesões tratadas: 89||  
|**Autor, ano**|**Grupo**|**Sobrevida**|**Valor p**<br>**Sobrevida Livre de Progressão**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||||**Controle da doença (%)**||
||||||Em todo o fígado: 81,1||
||||||Lesões tratadas: 94,6||  
|**Dhanasekaran**|DEBTACE<br>(n: 11)|<br>Taxa de SG em 1 ano: 73%|||||
|---|---|---|---|---|---|---|
|**et al. 2010**<sup>**203**</sup>|<br>cTACE|NR<br>Taxa de SG em 1ano:|NR|NR|**NR**|NR|
||(n:11)|27%|||||  
Legenda: SG: Sobrevida global; <mark>RC: resposta completa;</mark> RO: resposta objetiva; RR: Risco relativo; CD: controle da doença; <mark>N: número de pacientes; I</mark> C: intervalo de confiança; <mark>n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não relatado, cTACE: quimioembolização transarterial convencional; 3DCRT: radioterapia conformal três dimensões, DEBTACE: quimioembolização transarterial com grânulos eluentes de fármacos, hqTACE: quimioembolização transarterial com grânulos QuadraSpheres eluentes de doxorrubicina, SAP: quimioembolização transarterial com grânulos eluentes de epirrubicina.</mark>  
**<mark>Tabela AZ</mark>** <mark>– Desfechos de segurança dos estudos que analisaram a eficácia e segurança do DEB (Drug-eluting bead) x químioembolização clássica, para o carcinoma hepatocelular estágio B.</mark>  
|**Eventos Adversos**|**Lammer et al. 2010; Vo**|**gl et al. 2011**<sup>**199, 200**</sup>|
|---|---|---|
||**DEBTACE**|**TACE**|
|Eventos Adversos graves|19|32|
|Leucocitopenia|NR|NR|
|Trombocitopenia|NR|NR|
|Redução de hemoglobina|NR|NR|
|Hiperbilirrubinemia|NR|NR|
|Elevação sérica de transaminases|NR|NR|
|Elevação sérica de fosfatase alcalina|NR|NR|
|Embolia pulmonar|NR|NR|
|Febre|NR|NR|
|Fibrinopenia|NR|NR|
|Hematoma de tecido mole|NR|NR|
|Hematoma subdural|NR|NR|
|Hiperglicemia|NR|NR|
|Hipertensão pulmonar|NR|NR|
|Hipocalcemia|NR|NR|  
<mark>Legenda: NR: não relatado. Dados foram apresentados em n/N (%), cTACE: quimioembolização transarterial convencional, DEBTACE: quimioembolização transarteri com grânulos eluentes de fármacos.</mark>  
**Questão de Pesquisa 7:** Qual o efeito dos antivirais para hepatite C, no transplante de fígado em paciente com carcinoma hepático? (alfapeginterferona 2A e 2B, ribavirina, sofosbuvir, simeprevir, daclatasvir)

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **1.** **<mark>Estratégia de busca</mark>** -->
<mark>MEDLINE via Pubmed:</mark> (((("Carcinoma, Hepatocellular"[Mesh] OR hepatocarcinoma OR hepatoma OR malignant hepatoma)) AND ("Liver Transplantation"[Mesh] OR Liver Transplantations OR Hepatic Transplantation OR Liver Grafting)) AND ("Hepatitis C"[Mesh] OR hepatitis C OR Hepatitis, Viral, Non-A, Non-B, Parenterally-Transmitted)) AND ((((((("peginterferon alfa-2a" [Supplementary Concept] OR PEG-IFN alpha-2A OR PEG-interferon alfa-2A OR Pegasys)) OR ("peginterferon alfa-2b" [Supplementary Concept] OR pegylated interferon alfa-2b OR PEG INF alpha-2b)) OR ("Simeprevir"[Mesh] OR simeprevir OR Olysio)) OR ("BMS-790052" [Supplementary Concept] OR daclatasvir OR Daklinza)) OR ("Sofosbuvir"[Mesh] OR sovaldi OR sofosbuvir)))  
<mark>Total de referências: 78 referências</mark>  
<mark>Data de acesso: 10/08/2017</mark>  
EMBASE: (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'singleblind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim) AND ((('liver cell carcinoma'/exp OR 'liver cell carcinoma' OR 'carcinoma hepatocellular'/exp OR 'carcinoma hepatocellular') AND [embase]/lim) AND (('liver transplantation'/exp OR 'liver transplantation' OR 'liver graft'/exp OR 'liver graft' OR 'liver grafting' OR 'hepatic transplantlation') AND [embase]/lim)  
AND (('peginterferon alpha2a'/exp OR 'peginterferon alpha2a' OR 'peg-inf alpha-2a' OR 'peg-interferon alpha-2a' OR 'pegasys'/exp OR 'pegasys' OR 'peginterferon alpha2b'/exp OR 'peginterferon alpha2b' OR 'pegylated interferon alpha-2b'/exp OR 'pegylated interferon alpha-2b' OR 'peg-inf alpha 2-b' OR 'simeprevir'/exp OR 'simeprevir' OR 'olysio'/exp OR 'olysio' OR 'daclatasvir'/exp OR 'daclatasvir' OR 'daklinza'/exp OR 'daklinza' OR 'sofosbuvir'/exp OR 'sofosbuvir' OR 'sovaldi'/exp OR 'sovaldi') AND [embase]/lim) AND (('hepatitis c'/exp OR 'hepatitis c' OR (('hepatitis'/exp OR 'hepatitis') NOT ('hepatitis a'/exp OR 'hepatitis a' OR 'hepatitis b'/exp OR 'hepatitis b'))) AND [embase]/lim))  
<mark>Total:  73 referências</mark>  
<mark>Data de acesso: 11/08/2017</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **2.** **<mark>Seleção das evidências</mark>** -->
Com o intuito de fazer a busca mais específica, utilizou-se filtros validados para os ensaios clínicos nas duas bases de dados citadas acima, visando a redução do quantitativo de bibliografia encontrada.  
<mark>A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 151 referências (78 no MEDLINE e 73 no Embase). Destas, 05 (cinco) foram excluídas por estarem duplicadas. Foi realizada busca manual que resultou em 11 (onze) referências. Cento e cinquenta e sete referências foram triadas por meio da leitura de título e resumos, das quais 20 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dezenove estudos foram excluídos: oito ensaios clínicos, por selecionar todos os pacientes com cirrose e carcinoma hepatocelular e nos resultados não estratificar pela doença; onze estudos observacionais, por conter em sua população e resultados pacientes com cirrose compensada, cirrose descompensada e carcinoma hepático.</mark>  
<mark>Um estudo foi incluído por busca manual: um ensaio clínico não randomizado sem cegamento (série de casos)</mark><sup>204</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **3.** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>O estudo é apresentado de acordo com as comparações realizadas. A descrição sumária do estudo para avaliar o efeito dos antivirais para hepatite C, no transplante de fígado em pacientes com carcinoma hepático encontra-se na</mark> **<mark>Tabela BA</mark>** <mark>. As características dos pacientes para este estudo estão descritas na</mark> **<mark>Tabela BB</mark>** <mark>e os dados de desfechos de eficácia e os eventos adversos na</mark> **<mark>Tabela BC</mark>** <mark>.</mark>  
**<mark>Tabela BA</mark>** <mark>– Características do estudo incluído para avaliar o efeito dos antivirais para hepatite C no transplante de fígado em pacientes com carcinoma hepático.</mark>  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes do tratamento**|**Risco de viés**|
|---|---|---|---|---|---|
|**Curry et al.**<br>**2015**<sup>**204**</sup>|Ensaio clínico não<br>randomizado, fase II<br>(série de casos)|Determinar se a administração de até 48<br>semanas do sofosbuvir e ribavirina antes<br>do transplante hepático em pacientes com<br>CHC pode prevenir a recorrência da<br>infecção pelo HCV no pós-transplante<br>hepático.|Pacientes adultos com IMC ≥18 kg/m<sup>2,</sup><br>infecção pelo HCV por qualquer<br>genótipo e carga viral detectável > 10<sup>4</sup><br>IU/mL com Carcinoma hepatocelular<br>(critério Milan; MELD < 22; Child-<br>Turcotte-Pugh: ≤7) na fila para o<br>transplante hepático.|**Pré transplante:**<br>Sofosvubir 400 mg/ dia<br>Ribavirina 1000 mg (<75 kg)<br>Ribavirina 1200 mg (≥75 kg).|Alto: série de casos, estudo<br>sem cegamento, sem grupo<br>controle|  
Legenda: CHC: carcinoma hepatocelular; HCV: vírus hepatite C; IMC: índice de massa corporal; MELD: _Model for End-Stage Liver Disease._  
**<mark>Tabela BB</mark>** <mark>– Características dos pacientes incluídos no estudo para avaliar o efeito dos antivirais para hepatite C no transplante de fígado em pacientes com carcinoma hepático.</mark>  
|**Autor, ano**|**Detalhes da**<br>**população**<br>**n (%)**|**Idade em anos,**<br>**mediana (mínimo-**<br>**máximo)**|**Sexo**<br>**masculino**<br>**n (%)**|**Tempo de tratamento,**<br>**mediana**<br>**(Mínimo-Máximo)**|**Suspensão n (%)**|**Razão para suspensão**<br>**(n pacientes)**|**Tempo de**<br>**seguimento,**<br>**mediana**<br>**(Mínimo-Máximo)**|
|---|---|---|---|---|---|---|---|
|||||||**Pré-transplante:**||
|||||||5: falência viral||
||61 (100)|||||3: progressão da doença||
||**Genótipo:**||||Pré-transplante: 15|2: falta de resposta<br>2: progressão viral||
|**Curry et al.**<br>**2015**<sup>**204**</sup>|1a: 24 (39)<br>1b: 21 (34)|59 (46 - 73)|49 (80)|48 semanas|(25)|2: morreram (15 e 38 dias após final do<br>tratamento)|21 semanas<br>(2.3 - 52.3)|
||2:  8 (13)<br>3a: 7 (11)<br>4a: 1 (2)||||Pós transplante:  3 (5)|1: saiu da lista de espera<br>**Pós transplante:**||
|||||||2: falência viral<br>1: aumento da carga viral||  
**<mark>Tabela BC</mark>** <mark>– Desfechos de eficácia do estudo para avaliar o efeito dos antivirais para hepatite C no transplante de fígado em pacientes com carcinoma hepático.</mark>  
|**Autor, ano**|**Resposta virológica**|**Evento adversos (%)**|
|---|---|---|
||**Pós-transplante:**(IC 90%)||
||=> pTVR em 12 semanas: 30/ 43 (70%) (56-81)||
||1ª semana: 37 (86) (74 - 94)||
||2ª: semana: 35 (81) (69 - 90)<br>4ª semana: 31 (72) (59 - 83)<br>8ª semana: 31 (72) (59 - 83)<br>12ª semana: 30 (70) (56 - 81)|Fadiga: 23 (38)<br>Cefaleia: 14 (23)<br>Anemia: 13 (21)<br>Náusea: 10 (16)|
||=> pTVR em 12 semanas por genótipo|Rash: 9 (15)<br>Tosse: 7 (11)|
|**Curry et al.**<br>**2015**<sup>**204**</sup>|1a: 11/15 (73) (49 - 90)<br>1b: 8/ 16 (50) (28-72)<br>2: 6/ 6 (100) (61-100)<br>3: 4/5 (80) (34-99)<br>4: 1/1 (100) (5 - 100)|Dispneia: 7 (11)<br>Insônia: 7 (11)<br>Constipação: 6 (10)<br>Prurido: 6 (10)<br>Alterações hematológicas: 37<br>(61)|
||**Fatores associados com a não recorrência do**<br>**HCV no pós-transplante:** (OR, IC 95%)|Eventos adversos sérios: 11<br>(18)|
||- Dias consecutivos de carga viral indetectável:||
||1,047 (1,015 – 1,096, p <0,001)||
||- Não portador do HCV genótipo 1b:||
||9,826 (0,545 – 939,146, p = 0,19)||  
Legenda: HCV: vírus hepatite C; pTVR: resposta virológica pós-transplante; OR: _Odds Ratio_ ; <mark>IC 95%: intervalo de confiança em 95%.</mark>

---

<!-- METADADOS: doenca: Carcinoma Hepatocelular no Adulto - DDT | secao: **REFERÊNCIAS** -->
1. Bray F, Ferlay J, Soerjomataram I, Siegel RL, Torre LA, Jemal A. Global cancer statistics 2018: GLOBOCAN estimates of incidence and mortality worldwide for 36 cancers in 185 countries. CA Cancer J Clin. 2018;68(6):394-424.  
2. Chagas AL, Mattos AA, Carrilho FJ, Bittencourt PL, Vezozzo DCP, Horvat N, et al. BRAZILIAN SOCIETY OF HEPATOLOGY UPDATED RECOMMENDATIONS FOR DIAGNOSIS AND TREATMENT OF HEPATOCELLULAR CARCINOMA. Arq Gastroenterol. 2020;57(suppl 1):1-20.  
3. Sangiovanni A, Prati GM, Fasani P, Ronchi G, Romeo R, Manini M, et al. The natural history of compensated cirrhosis due to hepatitis C virus: A 17‐year cohort study of 214 patients. Hepatology. 2006;43(6):1303-10.  
4. Okuda H. Hepatocellular carcinoma development in cirrhosis. Best Practice & Research Clinical Gastroenterology. 2007 21(1):161-73.  
5. Paranagua-Vezozzo DC, Matielo CE, Chagas AL, Kikuchi LO, Mello ES, Alves VA, et al. Incidence Of Hepatocellular Carcinoma In Cirrhotic Patients In Sao Paulo, Brazil. Hepatology. 2006;44:504A-5A.  
6. Carrilho FJ, Kikuchi L, Branco F, Goncalves CS, Mattos AA. Clinical and epidemiological aspects of hepatocellular carcinoma in Brazil. Clinics. 2010;65(12):1285-90.  
7. Montesano R, Hainaut P, Wild CP. Hepatocellular carcinoma: from gene to public health. Journal of the National Cancer Institute. 1997;89(24):1844-51.  
8. Wang P, Kang D, Cao W, Wang Y, Liu Z. Diabetes mellitus and risk of hepatocellular carcinoma: a systematic review and meta‐analysis. Diabetes/metabolism research and reviews. 2012;28(2):109-22.  
9. Larsson SC, Wolk A. Overweight, obesity and risk of liver cancer: a meta-analysis of cohort studies. British journal of cancer. 2007;97(7):1005-8.  
10. Polesel J, Zucchetto A, Montella M, Dal Maso L, Crispo A, La Vecchia C, et al. The impact of obesity and diabetes mellitus on the risk of hepatocellular carcinoma. Annals of Oncology. 2008;20(2):353-7.  
11. Michelotti GA, Machado MV, Diehl AM. AFLD, NASH and liver cancer. Nature Reviews Gastroenterology and Hepatology. 2013;10(11):656-65.  
12. Fracanzani AL, Conte D, Fraquelli M, Taioli E, Mattioli M, Losco A, et al. Increased cancer risk in a cohort of 230 patients with hereditary hemochromatosis in comparison to matched control patients with non–iron‐related chronic liver disease. Hepatology. 2001;33(3):647-51.  
13. Fattovich G, Stroffolini T, Zagni I, Donato F. Hepatocellular carcinoma in cirrhosis: incidence and risk factors. Gastroenterology. 2004;127(5):S35-50.  
14. Carrillo FJ, Mattos AA, Vianey AF, Vezozzo DC, Marinho F, Souto FJ, et al. Brazilian society of hepatology recommendations for the diagnosis and treatment of hepatocellular carcinoma. Arquivos de gastroenterologia. 2015;52:2-14.  
15. Trinchet JC CC, Bourcier V, Degos F, Henrion J, Fontaine H, Roulot D, Mallat A, Hillaire S, Cales P, Ollivier I. Ultrasonographic surveillance of hepatocellular carcinoma in cirrhosis: A randomized trial comparing 3‐and 6‐month periodicities. Hepatology. 2011;54(6):1987-97.  
16. Farinati F MD, De Giorgio M, Baldan A, Cantarini M, Cursaro C, Rapaccini G, Del Poggio P, Di Nolfo MA, Benvegnù L, Zoli M. Diagnostic and prognostic role of α-fetoprotein in hepatocellular carcinoma: both or neither?. . The American journal of gastroenterology. 2006;101(3):524-32.  
17. EASL Clinical Practice Guidelines: Management of hepatocellular carcinoma. J Hepatol. 2018;69(1):182-236.  
18. Zhang BH YB, Tang ZY. Randomized controlled trial of screening for hepatocellular carcinoma. Journal of cancer research and clinical oncology. 2004;130(7):417-22.  
19. Xie L, Guang Y, Ding H, Cai A, Huang Y. Diagnostic value of contrast-enhanced ultrasound, computed tomography and magnetic resonance imaging for focal liver lesions: a meta-analysis. Ultrasound in medicine & biology. 2011;37(6):85461.  
20. Colli A, Fraquelli M, Casazza G, Massironi S, Colucci A, Conte D, et al. Accuracy of ultrasonography, spiral CT, magnetic resonance, and alpha-fetoprotein in diagnosing hepatocellular carcinoma: a systematic review. The American journal of gastroenterology. 2006;101(3):513-23.  
21. Lee JM, Trevisani F, Vilgrain V, Wald C. Imaging diagnosis and staging of hepatocellular carcinoma. Liver Transplantation. 2011;17(S2):S34-43.  
22. Bruix J, Sherman M. Management of hepatocellular carcinoma: an update. Hepatology. 2011;53(3):1020-2.  
23. Kudo M, Izumi N, Kokudo N, Matsui O, Sakamoto M, Nakashima O, et al. Management of hepatocellular carcinoma in Japan: Consensus-Based Clinical Practice Guidelines proposed by the Japan Society of Hepatology (JSH) 2010 updated version. Digestive diseases. 2011;29(3):339-64.  
24. Sherman M, Burak K, Maroun J, Metrakos P, Knox JJ, Myers RP, et al. Multidisciplinary Canadian consensus recommendations for the management and treatment of hepatocellular carcinoma. Current oncology. 2011;18(5):228.  
25. Clavien PA, Lesurtel M, Bossuyt PM, Gores GJ, Langer B, Perrier A. Recommendations for liver transplantation for hepatocellular carcinoma: an international consensus conference report. The lancet oncology. 2012;13(1):e11-22.  
26. Outwater EK. Imaging of the liver for hepatocellular cancer. . Cancer control: journal of the Moffitt Cancer Center. 2010;17(2):72.  
27. Heimbach JK, Kulik LM, Finn RS, Sirlin CB, Abecassis MM, Roberts LR, et al. Aasld guidelines for the treatment of hepatocellular carcinoma. Hepatology. 2018;67(1):358-80.  
28. Mohanty S, Rajaram R, Bilimoria KY, Salem R, Pawlik TM, Bentrem DJ. Assessment of non‐surgical versus surgical therapy for localized hepatocellular carcinoma. Journal of surgical oncology. 2016;113(2):175-80.  
29. Mazzaferro V, Regalia E, Doci R, Andreola S, Pulvirenti A, Bozzetti F, et al. Liver transplantation for the treatment of small hepatocellular carcinomas in patients with cirrhosis. New England Journal of Medicine. 1996;334(11):693-700.  
30. Yao FY, Xiao L, Bass NM, Kerlan R, Ascher NL, Roberts JP. Liver transplantation for hepatocellular carcinoma: validation of the UCSF‐expanded criteria based on preoperative imaging. American Journal of Transplantation. 2007;7(11):2587-96.  
31. Clavien PA, Lesurtel M, Bossuyt PM, Gores GJ, Langer B, Perrier A. Recommendations for liver transplantation for hepatocellular carcinoma: an international consensus conference report. The lancet oncology. 2012;13(1):e11-22.  
32. Yu CY, Ou HY, Huang TL, Chen TY, Tsang LC, Chen CL, et al. Hepatocellular carcinoma downstaging in liver transplantation. Transplantation proceedings. 2012;44(2):412-4.  
33. Saúde BMd. Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções. In: Secretaria de Vigilância em Saúde. Departamento de Vigilância PeCdI, Sexualmente Transmissíveis dHIVAedHv, editors. Brasília: Ministério da Saúde.; 2017.  
34. European Association For The Study Of The Liver. EASL–EORTC clinical practice guidelines: management of hepatocellular carcinoma. Journal of hepatology. 2012;56(4):908-43.  
35. Livraghi T, Lazzaroni S, Meloni F. Radiofrequency thermal ablation of hepatocellular carcinoma. European Journal of ultrasound. 2001;13(2):159-66.  
36. Ebara M, Okabe S, Kita K, Sugiura N, Fukuda H, Yoshikawa M, et al. Percutaneous ethanol injection for small hepatocellular carcinoma: therapeutic efficacy based on 20-year observation. Journal of hepatology. 2005;43(3):458-64.  
37. Shiina S, Teratani T, Obi S, Hamamura K, Koike Y, Omata M. Percutaneous ethanol injection therapy for liver tumors. European journal of ultrasound. 2001;13(2):95-106.  
38. Su TS, Liang P, Liang J, Lu HZ, Jiang HY, Cheng T, et al. Long-term Survival Analysis of Stereotactic Ablative Radiotherapy Versus Liver Resection for Small Hepatocellular Carcinoma. International Journal of Radiation Oncology* Biology* Physics. 2017;98(3):639-46.  
39. Lu XJ, Dong J, Ji LJ, Xiao LX, Ling CQ, Zhou J. Tolerability and efficacy of gamma knife radiosurgery on hepatocellular carcinoma with portal vein tumor thrombosis. Oncotarget. 2016;7(3):3614-22.  
40. Matsuo Y, Yoshida K, Nishimura H, Ejima Y, Miyawaki D, Uezono H, et al. Efficacy of stereotactic body radiotherapy for hepatocellular carcinoma with portal vein tumor thrombosis/inferior vena cava tumor thrombosis: evaluation by comparison with conventional three-dimensional conformal radiotherapy. Journal of radiation research. 2016;57(5):51223.  
41. Oladeru OT, Miccio JA, Yang J, Xue Y, Ryu S, Stessin AM. Conformal external beam radiation or selective internal radiation therapy—a comparison of treatment outcomes for hepatocellular carcinoma. Journal of gastrointestinal oncology. 2016;7(3):433.  
42. Feng MU, Marshall VD, Parikh N. Use of radiofrequency ablation and stereotactic body radiotherapy for the treatment of hepatocellular carcinoma: An analysis of the SEER-Medicare database. Journal of Clinical Oncology. 2016;34(4):2016-7.  
43. Wahl DR, Stenmark MH, Tao Y, Pollom EL, Caoili EM, Lawrence TS, et al. Outcomes after stereotactic body radiotherapy or radiofrequency ablation for hepatocellular carcinoma. Journal of Clinical Oncology. 2015;34(5):452-9.  
44. Shiozawa K, Watanabe M, Ikehara T, Matsukiyo Y, Kogame M, Kishimoto Y, et al. Comparison of percutaneous radiofrequency ablation and CyberKnife® for initial solitary hepatocellular carcinoma: A pilot study. World journal of gastroenterology. 2015;21(48):13490.  
45. Jacob R, Turley F, Redden DT, Saddekni S, Aal AK, Keene K, et al. Adjuvant stereotactic body radiotherapy following transarterial chemoembolization in patients with non‐resectable hepatocellular carcinoma tumours of≥ 3 cm. HPB. 2015;17(2):140-9.  
46. Honda Y, Kimura T, Aikata H, Kobayashi T, Fukuhara T, Masaki K, et al. Stereotactic body radiation therapy combined with transcatheter arterial chemoembolization for small hepatocellular carcinoma. Journal of gastroenterology and hepatology. 2013;28(3):530-6.  
47. Huang WY, Jen YM, Lee MS, Chang LP, Chen CM, Ko KH, et al. Stereotactic body radiation therapy in recurrent hepatocellular carcinoma. International Journal of Radiation Oncology* Biology* Physics. 2012;84(2):355-61.  
48. Oliveri RS, Wetterslev J, Gluud C. Transarterial (chemo) embolisation for unresectable hepatocellular carcinoma. The Cochrane Library. 2011;3:CD004787.  
49. Doffoël M, Bonnetain F, Bouché O, Vetter D, Abergel A, Fratté S, et al. Multicentre randomised phase III trial comparing Tamoxifen alone or with Transarterial Lipiodol Chemoembolisation for unresectable hepatocellular carcinoma in cirrhotic patients (Fédération Francophone de Cancérologie Digestive 9402). European journal of cancer. 2008;44(4):52838.  
50. Wang N, Guan Q, Wang K, Zhu B, Yuan W, Zhao P, et al. TACE combined with PEI versus TACE alone in the treatment of HCC: a meta-analysis. Medical oncology. 2011;28(4):1038-43.  
51. Wang W, Shi J, Xie WF. Transarterial chemoembolization in combination with percutaneous ablation therapy in unresectable hepatocellular carcinoma: a meta‐analysis. Liver International. 2010;30(5):741-9.  
52. Marelli L, Stigliano R, Triantos C, Senzolo M, Cholongitas E, Davies N, et al. Transarterial therapy for hepatocellular carcinoma: which technique is more effective? A systematic review of cohort and randomized studies. Cardiovascular and interventional radiology. 2007;30(1):6-25.  
53. Xie F, Zang J, Guo X, Xu F, Shen R, Yan L, et al. Comparison of transcatheter arterial chemoembolization and microsphere embolization for treatment of unresectable hepatocellular carcinoma: a meta-analysis. Journal of cancer research and clinical oncology. 2012;138(3):455-62.  
54. Golfieri R, Giampalma E, Renzulli M, Cioni R, Bargellini I, Bartolozzi C, et al. Randomised controlled trial of doxorubicin-eluting beads vs conventional chemoembolisation for hepatocellular carcinoma. British journal of cancer. 2014;111(12):255-64.  
55. Lammer J, Malagari K, Vogl T, Pilleul F, Denys A, Watkinson A, et al. Prospective randomized study of doxorubicin-eluting-bead embolization in the treatment of hepatocellular carcinoma: results of the PRECISION V study. Cardiovascular and interventional radiology. 2010;33(1):41-52.  
56. Chen P, Yuan P, Chen B, Sun J, Shen H, Qian Y. Evaluation of drug-eluting beads versus conventional transcatheter arterial chemoembolization in patients with unresectable hepatocellular carcinoma: A systematic review and meta-analysis. Clinics and research in hepatology and gastroenterology. 2017;41(1):75-85.  
57. Liu GM, Huang XY, Shen SL, Hu WJ, Peng BG. Adjuvant antiviral therapy for hepatitis B virus‐related hepatocellular carcinoma after curative treatment: A systematic review and meta‐analysis. Hepatology Research. 2016;46(1):100-10.  
58. Xu X, Huang P, Tian H, Chen Y, Ge N, Tang W, et al. Role of lamivudine with transarterial chemoembolization in the survival of patients with hepatocellular carcinoma. Journal of gastroenterology and hepatology. 2014;29(6):1273-8.  
59. Saúde BMd. Protocolos Clínicos e Diretrizes Terapêuticas para Hepatite B e Coinfecções. In: Saúde Md, editor. Brasília2016.  
60. Hasegawa K, Takayama T, Ijichi M, Matsuyama Y, Imamura H, Sano K, et al. Uracil‐tegafur as an adjuvant for hepatocellular carcinoma: A randomized trial. Hepatology. 2006;44(4):891-5.  
61. Lai EC, Lo CM, Fan ST, Liu CL, Wong J. Postoperative adjuvant chemotherapy after curative resection of hepatocellular carcinoma: a randomized controlled trial. Archives of Surgery. 1998;133(2):183-8.  
62. Pokorny H, Gnant M, Rasoul‐Rockenschaub S, Gollackner B, Steiner B, Steger G, et al. Does additional doxorubicin chemotherapy improve outcome in patients with hepatocellular carcinoma treated by liver transplantation?. . American journal of transplantation. 2005;5(4):788-94.  
63. Samuel M, Chow PK, Chan Shih‐Yen E, Machin D, Soo KC. Neoadjuvant and adjuvant therapy for surgical resection of hepatocellular carcinoma. The Cochrane Library. 2009;1:CD001199.  
64. Söderdahl G BL, Isoniemi H, Cahlin C, Höckerstedt K, Broomé U, Mäkisalo H, Friman S, Ericzon BG,. A prospective, randomized, multi‐centre trial of systemic adjuvant chemotherapy versus no additional treatment in liver transplantation for hepatocellular carcinoma. Transplant international. 2006;19(4):288-94.  
65. Xia Y, Qiu Y, Li J, Shi L, Wang K, Xi T, et al. Adjuvant therapy with capecitabine postpones recurrence of hepatocellular carcinoma after curative resection: a randomized controlled trial. Annals of surgical oncology. 2010;17(12):3137-44.  
66. Ishizuka M, Kubota K, Nemoto T, Shimoda M, Kato M, Iso Y, et al. Administration of adjuvant oral tegafur/uracil chemotherapy post hepatocellular carcinoma resection: A randomized controlled trial. Asian Journal of Surgery. 2016;39(3):149-54.  
67. Bruix J TT, Mazzaferro V, Chau GY, Yang J, Kudo M, Cai J, Poon RT, Han KH, Tak WY, Lee HC,. Adjuvant sorafenib for hepatocellular carcinoma after resection or ablation (STORM): a phase 3, randomised, double-blind, placebocontrolled trial. The Lancet Oncology. 2015;16(13):1344-54.  
68. Giorgio A MM, Montesarchio L, Merola F, Santoro B, Coppola C, Gatti P, Amendola F, Di Sarno A, Calvanese A, Matteucci P. Sorafenib combined with radio-frequency ablation compared with sorafenib alone in treatment of hepatocellular carcinoma invading portal vein: a western randomized controlled trial. Anticancer research. 2016;36(11):6179-83.  
69. Hoffmann K, Ganten T, Gotthardtp D, Radeleff B, Settmacher U, Kollmar O, et al. Impact of neo-adjuvant Sorafenib treatment on liver transplantation in HCC patients-a prospective, randomized, double-blind, phase III trial. BMC Cancer. 2015;15(1):392.  
70. Kan X, Jing Y, Wan QY, Pan JC, Han M, Yang Y, et al. Sorafenib combined with percutaneous radiofrequency ablation for the treatment of medium-sized hepatocellular carcinoma. Eur Rev Med Pharmacol Sci. 2015;19(2):247-55.  
71. Kudo M IK, Chida N, Nakachi K, Tak WY, Takayama T, Yoon JH, Hori T, Kumada H, Hayashi N, Kaneko S. Phase III study of sorafenib after transarterial chemoembolisation in Japanese and Korean patients with unresectable hepatocellular carcinoma. European journal of cancer. 2011;47(14):2117-2.  
72. Meyer T FR, Ma YT, Ross PJ, James MW, Sturgess R, Stubbs C, Stocken DD, Wall L, Watkinson A, Hacking N. Sorafenib in combination with transarterial chemoembolisation in patients with unresectable hepatocellular carcinoma (TACE 2): a randomised placebo-controlled, double-blind, phase 3 trial. The Lancet Gastroenterology & Hepatology. 2017;2(8):565-75.  
73. Sansonno D LG, Russi S, Conteduca V, Sansonno L, Dammacco F. Transarterial chemoembolization plus sorafenib: a sequential therapeutic scheme for HCV-related intermediate-stage hepatocellular carcinoma: a randomized clinical trial. The oncologist. 2012;17(3):359-66.  
74. Bruix J CA, Meinhardt G, Nakajima K, De Sanctis Y, Llovet J. Prognostic factors and predictors of sorafenib benefit in patients with hepatocellular carcinoma: Analysis of two phase III studies. Journal of hepatology. 2017;67(5):999-1008.  
75. Llovet JM RS, Mazzaferro V, Hilgard P, Gane E, Blanc JF, de Oliveira AC, Santoro A, Raoul JL, Forner A, Schwartz M. Sorafenib in advanced hepatocellular carcinoma. New England journal of medicine. 2008;359(4):378-90.  
76. Zhang T DX, Wei D, Cheng P, Su X, Liu H, Wang D, Gao H. Sorafenib improves the survival of patients with advanced hepatocellular carcinoma: a meta-analysis of randomized trials. Anti-cancer drug. 2010;21(3):326-32.  
77. Wang Z WX, Zeng WZ, Xu GS, Xu H, Weng M, Hou JN, Jiang MD. Meta-analysis of the efficacy of sorafenib for hepatocellular carcinoma. Asian Pacific Journal of Cancer Prevention. 2013;14(2):691-4.  
78. Liu L ZY, Han L, Qin SK. Efficacy and safety of the oxaliplatin-based chemotherapy in the treatment of advanced primary hepatocellular carcinoma: A meta-analysis of prospective studies. Medicine. 2016;95(40):e4993.  
79. Cheng AL KY, Chen Z, Tsao CJ, Qin S, Kim JS, Luo R, Feng J, Ye S, Yang TS, Xu J. Efficacy and safety of sorafenib in patients in the Asia-Pacific region with advanced hepatocellular carcinoma: a phase III randomised, doubleblind, placebo-controlled trial. The lancet oncology. 2009;10(1):25-34.  
80. Qin S BY, Lim HY, Thongprasert S, Chao Y, Fan J, Yang TS, Bhudhisawasdi V, Kang WK, Zhou Y, Lee JH. . Randomized, multicenter, open-label study of oxaliplatin plus fluorouracil/leucovorin versus doxorubicin as palliative chemotherapy in patients with advanced hepatocellular carcinoma from Asia. Journal of Clinical Oncology. 2013;31(28):3501-8.  
81. Peng S ZY, Xu F, Jia C, Xu Y, Dai C. An updated meta-analysis of randomized controlled trials assessing the effect of sorafenib in advanced hepatocellular carcinoma. PLoS One. 2014;9(12):e112530.  
82. Shao YY SW, Chan SY, Lu LC, Hsu CH, Cheng AL. . Treatment efficacy differences of sorafenib for advanced hepatocellular carcinoma: a meta-analysis of randomized clinical trials. Oncology. 2015;88(6):345-52.  
83. Abou-Alfa GK JP, Knox JJ, Capanu M, Davidenko I, Lacava J, Leung T, Gansukh B, Saltz LB. Doxorubicin plus sorafenib vs doxorubicin alone in patients with advanced hepatocellular carcinoma: a randomized trial. Jama. 2010;304(19):2154-60.  
84. Gish RG PC, Lazar L, Ruff P, Feld R, Croitoru A, Feun L, Jeziorski K, Leighton J, Knox J, Gallo J. Phase III randomized controlled trial comparing the survival of patients with unresectable hepatocellular carcinoma treated with nolatrexed or doxorubicin. Journal of clinical oncology. 2007;25(21):3069-75.  
85. Lai CL WP, Lok AF, Lin HJ, Ngan H, Lau JN, Chung HT, Ng MT, Yeoh EK, Arnold M. Recombinant α2 interferon is superior to doxorubicin for inoperable hepatocellular carcinoma: a prospective randomised trial. British journal of cancer. 1989;60(6):928-33.  
86. Melia WM JP, Williams R. Controlled clinical trial of doxorubicin and tamoxifen versus doxorubicin alone in hepatocellular carcinoma. Cancer treatment reports. 1987;71(12):1213-6.  
87. Okazaki N YM, Yoshida T, Hijikata A. A controlled study of intravenous doxorubicin versus oral tegafur in patients with hepatocellular carcinoma. Nihon Gan Chiryo Gakkai shi. 1985;20(3):556-61.  
88. Schachschal G LH, Plauth M. Controlled clinical trial of doxorubicin and tamoxifen versus tamoxifen monotherapy in hepatocellular carcinoma. European journal of gastroenterology & hepatology. 2000;12(3):281-4.  
89. Bruix J TW, Gasbarrini A, Santoro A, Colombo M, Lim HY, Mazzaferro V, Wiest R, Reig M, Wagner A, Bolondi L. Regorafenib as second-line therapy for intermediate or advanced hepatocellular carcinoma: multicentre, open-label, phase II safety study. European journal of cancer. 2013;49(16):3412-9.  
90. Cheng AL KY, Lin DY, Park JW, Kudo M, Qin S, Chung HC, Song X, Xu J, Poggi G, Omata M. Sunitinib versus sorafenib in advanced hepatocellular cancer: results of a randomized phase III trial. Journal of clinical oncology. 2013;31(32):4067-75.  
91. Manesis EK GG, Zoumboulis P, Vafiadou I, Hadziyannis SJ. Treatment of hepatocellular carcinoma with combined suppression and inhibition of sex hormones: a randomized, controlled trial. . Hepatology. 1995;21(6):1535-42.  
92. Nowak AK SM, Chow PK, Findlay M. . Use of tamoxifen in advanced‐stage hepatocellular carcinoma. Cancer. 2005;103(7):1408-14.  
93. Pan DY QJ, Chen JW, Huo YC, Zhou YK, Shi HA. Tamoxifen combined with octreotide or regular chemotherapeutic agents in treatment of primary liver cancer: a randomized controlled trial. Hepatobiliary Pancreat Dis Int. 2003;2(2):211-5.  
94. Zhu AX RO, Evans TJ, Ross PJ, Santoro A, Carrilho FJ, Bruix J, Qin S, Thuluvath PJ, Llovet JM, Leberre MA. SEARCH: a phase III, randomized, double-blind, placebo-controlled trial of sorafenib plus erlotinib in patients with advanced hepatocellular carcinoma. Journal of Clinical Oncology. 2014;33(6):559-66.  
95. Groupe d'Etude et de Traitement du Carcinome Hépatocellulaire. Randomized trial of leuprorelin and flutamide in male patients with hepatocellular carcinoma treated with tamoxifen. Hepatology (Baltimore, Md). 2004;40(6):1361-9.  
96. Chow PK MD, Chen Y, Zhang X, Win KM, Hoang HH, Nguyen BD, Jin MY, Lobo R, Findlay M, Lim CH. Randomised double-blind trial of megestrol acetate vs placebo in treatment-naive advanced hepatocellular carcinoma. . British journal of cancer. 2011;105(7):945-52.  
97. Zhu AX PJ, Ryoo BY, Yen CJ, Poon R, Pastorelli D, Blanc JF, Chung HC, Baron AD, Pfiffer TE, Okusaka T. . Ramucirumab versus placebo as second-line treatment in patients with advanced hepatocellular carcinoma following first-  
line therapy with sorafenib (REACH): a randomised, double-blind, multicentre, phase 3 trial. The lancet oncology. 2015;16(7):859-70.  
98. Koeberle D DJ, Demeter G, Li Q, Ribi K, Samaras P, Saletti P, Roth AD, Horber D, Bühlmann M, Wagner AD. . Sorafenib with or without everolimus in patients with advanced hepatocellular carcinoma (HCC): a randomized multicenter, multinational phase II trial (SAKK 77/08 and SASL 29). Annals of oncology. 2016;27(5):856-61.  
99. Zhu AX KM, Assenat E, Cattan S, Kang YK, Lim HY, Poon RT, Blanc JF, Vogel A, Chen CL, Dorval E. . Effect of everolimus on survival in advanced hepatocellular carcinoma after failure of sorafenib: the EVOLVE-1 randomized clinical trial. Jama. 2014;312(1):57-67.  
100. Hsu CY LY, Hsia CY, Huang YH, Su CW, Lin HC, Lee RC, Chiou YY, Lee FY, Huo TI. . Performance status in patients with hepatocellular carcinoma: determinants, prognostic impact, and ability to improve the Barcelona Clinic Liver Cancer system. Hepatology. 2013;57(1):112-9.  
101. Hsu CY LP, Lee YH, Hsia CY, Huang YH, Chiou YY, Lin HC, Huo TI. Hepatocellular carcinoma patients with performance status 1 deserve new classification and treatment algorithm in the BCLC system. Medicine. 2015;94(29):e1223. 102. Abdel-Rahman O FM. Sorafenib-based combination as a first line treatment for advanced hepatocellular carcinoma: a systematic review of the literature. Critical reviews in oncology/hematology. 2014;91(1):1-8.  
103. American College of Radiology. LI-RADS archive: CT/MRI LI-RADS v2017 core. American College of Radiology website2017 [Available from: https://www.acr.org/Clinical-Resources/Reporting-and-DataSystems/LI-RADS/CT-MRI-LI-RADS-v2017.  
104. Gavanier M AA, Sellal C, Orry X, Claudon M, Bronowicki JP, Laurent V. CT imaging findings in patients with advanced hepatocellular carcinoma treated with sorafenib: Alternative response criteria (Choi, European Association for the Study of the Liver, and modified Response Evaluation Criteria in Solid Tumor (mRECIST)) versus RECIST 1.1. European journal of radiology. 2016;85(1):103-12.  
105. Lencioni R LJ. Modified RECIST (mRECIST) assessment for hepatocellular carcinoma. . In: Publishers TM, editor. Seminars in liver disease 302010. p. 052-60.  
106. Raoul JL PJ, Kang YK, Finn RS, Kim JS, Yeo W, Polite BN, Chao Y, Walters I, Baudelet C, Lencioni R. Using modified RECIST and alpha-fetoprotein levels to assess treatment benefit in hepatocellular carcinoma. Liver cancer. 2014;3(3-4):439-50.  
107. Cella D BZ, Kindler HL, Fuchs CS, Bray S, Barlev A, Oglesby A. . Validity of the FACT Hepatobiliary (FACTHep) questionnaire for assessing disease-related symptoms and health-related quality of life in patients with metastatic pancreatic cancer. . Quality of Life Research. 2013;22(5):1105-12.  
108. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília2009.  
109. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008.  
110. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011.  
111. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
112. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36. 113. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
114. Basha MA ESD, El Sammak AA. Diagnostic efficacy of the Liver Imaging-Reporting and Data System (LI-RADS) with CT imaging in categorising small nodules (10-20 mm) detected in the cirrhotic liver at screening ultrasound. Clinical radiology. 2017.  
115. Becker Anton S, Barth Borna K, Marquez Paulo H, Donati Olivio F, Ulbrich Erika J, Karlo C, et al. Increased interreader agreement in diagnosis of hepatocellular carcinoma using an adapted LI-RADS algorithm. European journal of radiology. 2017;86:33-40.  
116. Granata V, Fusco R, Avallone A, Filice F, Tatangelo F, Piccirillo M, et al. Critical analysis of the major and ancillary imaging features of LI-RADS on 127 proven HCCs evaluated with functional and morphological MRI: Lights and shadows. Oncotarget. 2017;8(31):51224-37.  
117. Horvat N, Nikolovski I, Long N, Gerst S, Zheng J, Pak Linda M, et al. Imaging features of hepatocellular carcinoma compared to intrahepatic cholangiocarcinoma and combined tumor on MRI using liver imaging and data system (LI-RADS) version 2014. Abdominal radiology (New York). 2017.  
118. Joo I, Lee JM, Lee DH, Ahn SJ, Lee ES, Han JK. Liver imaging reporting and data system v2014 categorization of hepatocellular carcinoma on gadoxetic acid-enhanced MRI: Comparison with multiphasic multidetector computed tomography. Journal of Magnetic Resonance Imaging. 2017;45(3):731-40. 119. Kim Bo R, Lee Jeong M, Lee Dong H, Yoon Jeong H, Hur Bo Y, Suh Kyung S, et al. Diagnostic Performance of Gadoxetic Acid-enhanced Liver MR Imaging versus Multidetector CT in the Detection of Dysplastic Nodules and Early Hepatocellular Carcinoma. Radiology. 2017:162080-.  
120. Liu W, Qin J, Guo R, Xie S, Jiang H, Wang X, et al. Accuracy of the diagnostic evaluation of hepatocellular carcinoma with LI-RADS. Acta radiologica (Stockholm, Sweden : 1987). 2017:284185117716700-.  
121. Barth Borna K, Donati Olivio F, Fischer Michael A, Ulbrich Erika J, Karlo Christoph A, Becker A, et al. Reliability, Validity, and Reader Acceptance of LI-RADS-An In-depth Analysis. Academic radiology. 2016;23(9):1145-53. 122. Chen N, Motosugi U, Morisaka H, Ichikawa S, Sano K, Ichikawa T, et al. Added Value of a Gadoxetic Acidenhanced Hepatocyte-phase Image to the LI-RADS System for Diagnosing Hepatocellular Carcinoma. Magnetic resonance in medical sciences : MRMS : an official journal of Japan Society of Magnetic Resonance in Medicine. 2016;15(1):49-59.  
123. Choi Sang H, Byun Jae H, Kim So Y, Lee So J, Won Hyung J, Shin Yong M, et al. Liver Imaging Reporting and Data System v2014 With Gadoxetate Disodium-Enhanced Magnetic Resonance Imaging: Validation of LI-RADS Category 4 and 5 Criteria. Investigative radiology. 2016;51(8):483-90.  
124. Choi Sang H, Lee Seung S, Kim So Y, Park So H, Park Seong H, Kim Kang M, et al. Intrahepatic Cholangiocarcinoma in Patients with Cirrhosis: Differentiation from Hepatocellular Carcinoma by Using Gadoxetic Acidenhanced MR Imaging and Dynamic CT. Radiology. 2016;282(3):771-81.  
125. Ehman Eric C, Behr Spencer C, Umetsu Sarah E, Fidelman N, Yeh Ben M, Ferrell Linda D, et al. Rate of observation and inter-observer agreement for LI-RADS major features at CT and MRI in 184 pathology proven hepatocellular carcinomas. Abdominal radiology (New York). 2016;41(5):963-9.  
126. Joo I, Lee JM, Lee SM, Lee JS, Park JY, Han JK. Diagnostic accuracy of liver imaging reporting and data system  
(LI-RADS) v2014 for intrahepatic mass-forming cholangiocarcinomas in patients with chronic liver disease on gadoxetic acid-enhanced MRI. Journal of Magnetic Resonance Imaging. 2016;44(5):1330-8.  
127. Kono Y, Cosgrove D, Dietrich CF, Jang HJ, Kim TK, Lyshchik A, et al. Metaanalysis of diagnostic performance of CEUS LI-RADS (Contrast-Enhanced Ultrasound Liver Imaging Reporting and Data System) criteria for diagnosis of 1-2 cm hepatocellular carcinoma (HCC). Hepatology. 2016;63(1):221A.  
128. Zhao W, Li W, Yi X, Pei Y, Liu H, Zhang L, et al. [Diagnostic value of liver imaging reporting and data system MRI on primary hepatocellular carcinoma]. Zhong nan da xue xue bao Yi xue ban = Journal of Central South University Medical sciences. 2016;41(4):380-7.  
129. Darnell A, Forner A, Rimola J, Reig M, Garcia-Criado A, Ayuso C, et al. Liver Imaging Reporting and Data System with MR Imaging: Evaluation in Nodules 20 mm or Smaller Detected in Cirrhosis at Screening US. Radiology. 2015;275(3):698-707.  
130. Zhang YD, Zhu FP, Xu X, Wang Q, Wu CJ, Liu XS, et al. Liver imaging reporting and data system: Substantial discordance between CT and MR for imaging classification of hepatic nodules. Academic Radiology. 2015;23(3):344-52.  
131. Hanazaki K KS, Shimozawa N, Shimada K, Hiraguri M, Koide N, Adachi W, Amano J. Hepatic resection for hepatocellular carcinoma in diameter of> or= 10 cm. Hepato-gastroenterology. 2002;49(44):518-2. Hepatic resection for hepatocellular carcinoma in diameter of > or = 10 cm. Hepato-gastroenterology. 2002;49(44):518-23.  
132. Mohanty S, Rajaram R, Bilimoria Karl Y, Salem R, Pawlik Timothy M, Bentrem David J. Assessment of nonsurgical versus surgical therapy for localized hepatocellular carcinoma. Journal of surgical oncology. 2016;113(2):175-80. 133. Lanthaler M BM, Weissenbacher A, Margreiter R, Nehoda H. Recurrence after Liver Resection for Hepatocellular Carcinoma in Cirrhotic and Noncirrhotic Patients. Chir Gastroenterol 2008;24(1):51-4.  
134. Lang H SG, Dömland M, Frühauf NR, Paul A, Hüsing J, Malago M, Broelsch CE. Liver resection for hepatocellular carcinoma in non‐cirrhotic liver without underlying viral hepatitis. British journal of surgery. 2004;92(2):198-202.  
135. Yip VS GD, Tan CY, Staettner S, Terlizzo M, Fenwick S, Malik HZ, Ghaneh P, Poston G. Tumour size and differentiation predict survival after liver resection for hepatocellular carcinoma arising from non-cirrhotic and non-fibrotic liver: a case-controlled study. International journal of surgery. 2013;11(10):1078-82.  
136. Zhou Y LX, Wu L, Wu X, Xu D, Li B. Outcomes of hepatectomy for noncirrhotic hepatocellular carcinoma: a systematic review. Surgical oncology. 2014;23(4):236-42.  
137. Su T-S, Liang P, Liang J, Lu H-Z, Jiang H-Y, Cheng T, et al. Long-Term Survival Analysis of Stereotactic Ablative Radiotherapy Versus Liver Resection for Small Hepatocellular Carcinoma. International Journal of Radiation Oncology*Biology*Physics. 2017;98(3):639-46.  
138. Lu XJ, Dong J, Ji LJ, Xiao LX, Ling CQ, Zhou J. Tolerability and efficacy of gamma knife radiosurgery on hepatocellular carcinoma with portal vein tumor thrombosis. Oncotarget. 2016;7(3):3614-22.  
139. Matsuo Y, Yoshida K, Nishimura H, Ejima Y, Miyawaki D, Uezono H, et al. Efficacy of stereotactic body radiotherapy for hepatocellular carcinoma with portal vein tumor thrombosis/inferior vena cava tumor thrombosis: Evaluation by comparison with conventional three-dimensional conformal radiotherapy. Journal of Radiation Research. 2016;57(5):51223.  
140. Oladeru OT, Miccio JA, Yang J, Xue Y, Ryu S, Stessin AM. Conformal external beam radiation or selective internal radiation therapy-a comparison of treatment outcomes for hepatocellular carcinoma. Journal of Gastrointestinal Oncology. 2016;7(3):433-40.  
141. Feng MU-S, Marshall VD, Parikh N. Use of radiofrequency ablation and stereotactic body radiotherapy for the  
treatment of hepatocellular carcinoma: An analysis of the SEER-Medicare database. Journal of Clinical Oncology. 2016;34(4):2016-7.  
142. Wahl DR, Stenmark MH, Tao Y, Pollom EL, Caoili EM, Lawrence TS, et al. Outcomes after stereotactic body radiotherapy or radiofrequency ablation for hepatocellular carcinoma. Journal of Clinical Oncology. 2016;34(5):452-9. 143. Shiozawa K, Watanabe M, Ikehara T, Matsukiyo Y, Kogame M, Kishimoto Y, et al. Comparison of percutaneous radiofrequency ablation and CyberKnife® for initial solitary hepatocellular carcinoma: A pilot study. World Journal of Gastroenterology. 2015;21(48):13490-9.  
144. Jacob R, Turley F, Redden DT, Saddekni S, Aal AKA, Keene K, et al. Adjuvant stereotactic body radiotherapy following transarterial chemoembolization in patients with non-resectable hepatocellular carcinoma tumours of ???3 cm. Hpb. 2015;17(2):140-9.  
145. Honda Y, Kimura T, Aikata H, Kobayashi T, Fukuhara T, Masaki K, et al. Stereotactic body radiation therapy combined with transcatheter arterial chemoembolization for small hepatocellular carcinoma. Journal of Gastroenterology and Hepatology. 2013;28(3):530-6.  
146. Huang W-Y, Jen Y-M, Lee M-S, Chang L-P, Chen C-M, Ko K-H, et al. Stereotactic Body Radiation Therapy in Recurrent Hepatocellular Carcinoma. International Journal of Radiation Oncology*Biology*Physics. 2012;84(2):355-61. 147. Niu M, Hong D, Ma TC, Chen XW, Han JH, Sun J, et al. Short-term and long-term efficacy of 7 targeted therapies for the treatment of advanced hepatocellular carcinoma: a network meta-analysis: Efficacy of 7 targeted therapies for AHCC. Medicine (Baltimore). 2016;95(49):e5591.  
148. Peng S, Zhao Y, Xu F, Jia C, Xu Y, Dai C. An updated meta-analysis of randomized controlled trials assessing the effect of sorafenib in advanced hepatocellular carcinoma. PLoS One. 2014;9(12):e112530. 149. Zeng J, Lv L, Mei ZC. Efficacy and safety of transarterial chemoembolization plus sorafenib for early or intermediate stage hepatocellular carcinoma: A systematic review and meta-analysis of randomized controlled trials. Clin Res Hepatol Gastroenterol. 2016;40(6):688-97.  
150. Bruix J, Takayama T, Mazzaferro V, Chau GY, Yang J, Kudo M, et al. Adjuvant sorafenib for hepatocellular carcinoma after resection or ablation (STORM): a phase 3, randomised, double-blind, placebo-controlled trial. Lancet Oncol. 2015;16(13):1344-54.  
151. Qin S, Bai Y, Lim HY, Thongprasert S, Chao Y, Fan J, et al. Randomized, multicenter, open-label study of oxaliplatin plus fluorouracil/leucovorin versus doxorubicin as palliative chemotherapy in patients with advanced hepatocellular carcinoma from Asia. J Clin Oncol. 2013;31(28):3501-8.  
152. Soderdahl G, Backman L, Isoniemi H, Cahlin C, Hockerstedt K, Broome U, et al. A prospective, randomized, multicentre trial of systemic adjuvant chemotherapy versus no additional treatment in liver transplantation for hepatocellular carcinoma. Transpl Int. 2006;19(4):288-94.  
153. Pokorny H, Gnant M, Rasoul-Rockenschaub S, Gollackner B, Steiner B, Steger G, et al. Does additional doxorubicin chemotherapy improve outcome in patients with hepatocellular carcinoma treated by liver transplantation? American Journal of Transplantation. 2005;5(4 I):788-94.  
154. Yeo W, Mok TS, Zee B, Leung TW, Lai PB, Lau WY, et al. A randomized phase III study of doxorubicin versus cisplatin/interferon alpha-2b/doxorubicin/fluorouracil (PIAF) combination chemotherapy for unresectable hepatocellular carcinoma. J Natl Cancer Inst. 2005;97(20):1532-8.  
155. Lai CL, Wu PC, Chan GC, Lok AS, Lin HJ. Doxorubicin versus no antitumor therapy in inoperable hepatocellular carcinoma. A prospective randomized trial. Cancer. 1988;62(3):479-83.  
156. Lai EC, Lo CM, Fan ST, Liu CL, Wong J. Postoperative adjuvant chemotherapy after curative resection of hepatocellular carcinoma: a randomized controlled trial. Arch Surg. 1998b;133(2):183-8.  
157. Xia Y, Qiu Y, Li J, Shi L, Wang K, Xi T, et al. Adjuvant therapy with capecitabine postpones recurrence of hepatocellular carcinoma after curative resection: a randomized controlled trial. Ann Surg Oncol. 2010;17(12):3137-44.  
158. Kudo M, Moriguchi M, Numata K, Hidaka H, Tanaka H, Ikeda M, et al. A randomized, double-blind, placebocontrolled phase III study of S-1 in patients with sorafenib-refractory advanced hepatocellular carcinoma (S-CUBE). Journal of Clinical Oncology. 2017;33(15):2015-05.  
159. Ishizuka M, Kubota K, Nemoto T, Shimoda M, Kato M, Iso Y, et al. Administration of adjuvant oral tegafur/uracil chemotherapy post hepatocellular carcinoma resection: A randomized controlled trial. Asian J Surg. 2016;39(3):149-54.  
160. Hasegawa K, Takayama T, Ijichi M, Matsuyama Y, Imamura H, Sano K, et al. Uracil-tegafur as an adjuvant for hepatocellular carcinoma: A randomized trial. Hepatology. 2006;44(4):891-5.  
161. Wang H, Liu Y, Wang X, Liu D, Sun Z, Wang C, et al. Randomized clinical control study of locoregional therapy combined with arsenic trioxide for the treatment of hepatocellular carcinoma. Cancer. 2015;121(17):2917-25.  
162. Zhu AX, Park JO, Ryoo BY, Yen CJ, Poon R, Pastorelli D, et al. Ramucirumab versus placebo as second-line treatment in patients with advanced hepatocellular carcinoma following first-line therapy with sorafenib (REACH): a randomised, double-blind, multicentre, phase 3 trial. Lancet Oncol. 2015;16(7):859-70.  
163. Shao YY, Shau WY, Chan SY, Lu LC, Hsu CH, Cheng AL. Treatment efficacy differences of sorafenib for advanced hepatocellular carcinoma: a meta-analysis of randomized clinical trials. Oncology. 2015;88(6):345-52. 164. Zhang X, Yang XR, Huang XW, Wang WM, Shi RY, Xu Y, et al. Sorafenib in treatment of patients with advanced hepatocellular carcinoma: a systematic review. Hepatobiliary Pancreat Dis Int. 2012;11(5):458-66. 165. Bruix J, Takayama T, Mazzaferro V, Chau GY, Yang J, Kudo M, et al. Adjuvant sorafenib for hepatocellular carcinoma after resection or ablation (STORM): a phase 3, randomised, double-blind, placebo-controlled trial. Lancet Oncol. 2015;16(13):1344-54.  
166. Ji YX, Zhang ZF, Lan KT, Nie KK, Geng CX, Liu SC, et al. Sorafenib in liver function impaired advanced hepatocellular carcinoma. Chin Med Sci J. 2014;29(1):7-14.  
167. Kudo M, Imanaka K, Chida N, Nakachi K, Tak WY, Takayama T, et al. Phase III study of sorafenib after transarterial chemoembolisation in Japanese and Korean patients with unresectable hepatocellular carcinoma. Eur J Cancer. 2011;47(14):2117-27.  
168. Meyer T, Fox R, Ma YT, Ross PJ, James MW, Sturgess R, et al. Sorafenib in combination with transarterial chemoembolisation in patients with unresectable hepatocellular carcinoma (TACE 2): a randomised placebo-controlled, double-blind, phase 3 trial. The Lancet Gastroenterology and Hepatology. 2017;2(8):565-75.  
169. Giorgio A, Merola MG, Montesarchio L, Merola F, Santoro B, Coppola C, et al. Sorafenib Combined with Radiofrequency Ablation Compared with Sorafenib Alone in Treatment of Hepatocellular Carcinoma Invading Portal Vein: A Western Randomized Controlled Trial. Anticancer Res. 2016;36(11):6179-83.  
170. Kan X, Jing Y, Wan QY, Pan JC, Han M, Yang Y, et al. Sorafenib combined with percutaneous radiofrequency ablation for the treatment of medium-sized hepatocellular carcinoma. Eur Rev Med Pharmacol Sci. 2015;19(2):247-55.  
171. Hoffmann K, Ganten T, Gotthardtp D, Radeleff B, Settmacher U, Kollmar O, et al. Impact of neo-adjuvant Sorafenib treatment on liver transplantation in HCC patients - a prospective, randomized, double-blind, phase III trial. BMC Cancer. 2015;15:392.  
172. Sansonno D, Lauletta G, Russi S, Conteduca V, Sansonno L, Dammacco F. Transarterial chemoembolization plus  
sorafenib: a sequential therapeutic scheme for HCV-related intermediate-stage hepatocellular carcinoma: a randomized clinical trial. Oncologist. 2012;17(3):359-66.  
173. Cheng AL, Kang YK, Lin DY, Park JW, Kudo M, Qin S, et al. Sunitinib versus sorafenib in advanced hepatocellular cancer: results of a randomized phase III trial. J Clin Oncol. 2013;31(32):4067-75.  
174. Zhang J, Zong Y, Xu GZ, Xing K, Author A, Department of Hepatopathy HHXaJ, et al. Erlotinib for advanced hepatocellular carcinoma a systematic review of phase II/III clinical trials. Saudi Medical Journal. 2016;37(11):1184-90.  
175. Bruix J, Qin S, Merle P, Granito A, Huang YH, Bodoky G, et al. Regorafenib for patients with hepatocellular carcinoma who progressed on sorafenib treatment (RESORCE): a randomised, double-blind, placebo-controlled, phase 3 trial. Lancet. 2017;389(10064):56-66.  
176. Xu J LJ, Chen J, Liu ZJ. Effect of adjuvant interferon therapy on hepatitis b/c virus-related hepatocellular carcinoma after curative therapy-meta-analysis. . Adv Clin Exp Med. 2015;24(2):331-40.  
177. Zhuang L ZX, Yang Z, Meng Z. Effect and safety of interferon for hepatocellular carcinoma: a systematic review and meta-analysis. PLoS One. 2013;8(9):e61361.  
178. Dollinger MM, Lautenschlaeger C, Lesske J, Tannapfel A, Wagner AD, Schoppmeyer K, et al. Thymostimulin versus placebo for palliative treatment of locally advanced or metastasised hepatocellular carcinoma: a phase III clinical trial. BMC Cancer. 2010;10:457.  
179. Cao DD, Xu HL, Liu L, Zheng YF, Gao SF, Xu XM, et al. Thalidomide combined with thanscatheter artierial chemoembolzation for primary hepatocellular carcinoma: A systematic review and meta-analysis. Oncotarget. 2017;8(27):44976-93.  
180. Geissler EK, Schnitzbauer AA, Zulke C, Lamby PE, Proneth A, Duvoux C, et al. Sirolimus Use in Liver Transplant Recipients With Hepatocellular Carcinoma: A Randomized, Multicenter, Open-Label Phase 3 Trial. Transplantation. 2016;100(1):116-25.  
181. Zhu AX, Kudo M, Assenat E, Cattan S, Kang YK, Lim HY, et al. Effect of everolimus on survival in advanced hepatocellular carcinoma after failure of sorafenib: the EVOLVE-1 randomized clinical trial. JAMA. 2014;312(1):57-67.  
182. Nowak AK, Stockler MR, Chow PK, Findlay M. Use of tamoxifen in advanced-stage hepatocellular carcinoma. A systematic review. Cancer. 2005;103(7):1408-14.  
183. Doffoel M, Bonnetain F, Bouche O, Vetter D, Abergel A, Fratte S, et al. Multicentre randomised phase III trial comparing Tamoxifen alone or with Transarterial Lipiodol Chemoembolisation for unresectable hepatocellular carcinoma in cirrhotic patients (Federation Francophone de Cancerologie Digestive 9402). Eur J Cancer. 2008;44(4):528-38.  
184. GdEedTdC. H. Randomized trial of leuprorelin and flutamide in male patients with hepatocellular carcinoma treated with tamoxifen. Hepatology. 2004;40(6):1361-9.  
185. Pan DY, Qiao JG, Chen JW, Huo YC, Zhou YK, Shi HA. Tamoxifen combined with octreotide or regular chemotherapeutic agents in treatment of primary liver cancer: a randomized controlled trial. Hepatobiliary Pancreat Dis Int. 2003;2(2):211-5.  
186. Manesis EK, Giannoulis G, Zoumboulis P, Vafiadou I, Hadziyannis SJ, Author A, et al. Treatment of hepatocellular carcinoma with combined suppression and inhibition of sex hormones: A randomized, controlled trial. Hepatology. 1995;21(6):1535-42.  
187. Barbare JC, Bouche O, Bonnetain F, Dahan L, Lombard-Bohas C, Faroux R, et al. Treatment of advanced hepatocellular carcinoma with long-acting octreotide: a phase III multicentre, randomised, double blind placebo-controlled study. Eur J Cancer. 2009;45(10):1788-97.  
188. Chow PK, Machin D, Chen Y, Zhang X, Win KM, Hoang HH, et al. Randomised double-blind trial of megestrol acetate vs placebo in treatment-naive advanced hepatocellular carcinoma. Br J Cancer. 2011;105(7):945-52.  
189. Guo TK, Hao XY, Ma B, Yang KH, Li YP, Li HL, et al. Octreotide for advanced hepatocellular carcinoma: a metaanalysis of randomized controlled trials. J Cancer Res Clin Oncol. 2009;135(12):1685-92.  
190. Villa E, Ferretti I, Grottola A, Buttafoco P, Buono MG, Giannini F, et al. Hormonal therapy with megestrol in inoperable hepatocellular carcinoma characterized by variant oestrogen receptors. Br J Cancer. 2001;84(7):881-5.  
191. Verset G, Verslype C, Reynaert H, Borbath I, Langlet P, Vandebroek A, et al. Efficacy of the combination of longacting release octreotide and tamoxifen in patients with advanced hepatocellular carcinoma: a randomised multicentre phase III study. Br J Cancer. 2007;97(5):582-8.  
192. Xu X, Huang P, Tian H, Chen Y, Ge N, Tang W, et al. Role of lamivudine with transarterial chemoembolization in the survival of patients with hepatocellular carcinoma. Journal of Gastroenterology and Hepatology. 2014;(2014) 29(6):12738.  
193. Zhong JH, Mo XS, Xiang BD, Yuan WP, Jiang JF, Xie GS, et al. Postoperative use of the chemopreventive vitamin K2 analog in patients with hepatocellular carcinoma. PLoS One. 2013;8(3):e58082.  
194. Sarin SK, Kumar M, Garg S, Hissar S, Pandey C, Sharma BC. High dose vitamin K3 infusion in advanced hepatocellular carcinoma. J Gastroenterol Hepatol. 2006;21(9):1478-82.  
195. Uchino J UY, Sato Y, Gondo H, Nakajima Y, Sato N. Chemohormonal therapy of unresectable hepatocellular carcinoma. American journal of clinical oncology. 1993;16(3):206-9.  
196. Grimaldi C BH, Gay F, Messner M, Rougier P, Kok TC, Cirera L, Cervantes A, De Greve J, Paillot B, Buset M. . Evaluation of antiandrogen therapy in unresectable hepatocellular carcinoma: results of a European Organization for Research and Treatment of Cancer multicentric double-blind trial. Journal of clinical oncology. 1998;16(2):411-7.  
197. Chen P, Yuan P, Chen B, Sun J, Shen H, Qian Y. Evaluation of drug-eluting beads versus conventional transcatheter arterial chemoembolization in patients with unresectable hepatocellular carcinoma: A systematic review and meta-analysis. Clinics and Research in Hepatology and Gastroenterology. 2017;41(1):75-85. 198. Golfieri R, Giampalma E, Renzulli M, Cioni R, Bargellini I, Bartolozzi C, et al. Randomised controlled trial of doxorubicin-eluting beads vs conventional chemoembolisation for hepatocellular carcinoma. British Journal of Cancer. 2014;111(2):255-64.  
199. Lammer J, Malagari K, Vogl T, Pilleul F, Denys A, Watkinson A, et al. Prospective randomized study of doxorubicin-eluting-bead embolization in the treatment of hepatocellular carcinoma: Results of the PRECISION v study. CardioVascular and Interventional Radiology. 2010;33(1):41-52.  
200. Vogl TJ, Lammer J, Lencioni R, Malagari K, Watkinson A, Pilleul F, et al. Liver, gastrointestinal, and cardiac toxicity in intermediate hepatocellular carcinoma treated with PRECISION TACE with drug-eluting beads: Results from the PRECISION V randomized trial. American Journal of Roentgenology. 2011;197(4):562-70.  
201. Morimoto M, Kobayashi S, Moriya S, Ueno M, Tezuka S, Irie K, et al. Short-term efficacy of transarterial chemoembolization with epirubicin-loaded superabsorbent polymer microspheres for hepatocellular carcinoma: comparison with conventional transarterial chemoembolization. Abdominal Radiology. 2017;42(2):612-9.  
202. Duan F, Wang EQ, Lam MGEH, Abdelmaksoud MHK, Louie JD, Hwang GL, et al. Superselective Chemoembolization of HCC: Comparison of Short-term Safety and Efficacy between Drug-eluting LC Beads, QuadraSpheres, and Conventional Ethiodized Oil Emulsion. Radiology. 2016;278(2):612-21.  
203. Dhanasekaran R, Kooby DA, Staley CA, Kauh JS, Khanna V, Kim HS. Comparison of conventional transarterial  
chemoembolization (TACE) and chemoembolization with doxorubicin Drug Eluting Beads (DEB) for unresectable Hepatocelluar Carcinoma (HCC). Journal of Surgical Oncology. 2010;101(6):476-80.  
204. Curry MP FX, Chung RT, Terrault NA, Brown R, Fenkel JM, Gordon F, O’Leary J, Kuo A, Schiano T, Everson G. Sofosbuvir and ribavirin prevent recurrence of HCV infection after liver transplantation: an open-label study. . Gastroenterology. 2015;148(1):100-7.

---

