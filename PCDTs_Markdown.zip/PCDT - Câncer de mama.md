<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 17, DE 25 DE NOVEMBRO DE 2024  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Câncer de Mama.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: Geral -->
Considerando a necessidade de se atualizarem os parâmetros sobre o câncer de mama e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 893/2024 e o Relatório de Recomendação nº 896 – abril de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e a atualização da busca e avaliação da literatura científica; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTIC/MS), da Coordenação-Geral da Política Nacional de Prevenção e Controle do Câncer (CGCAN/SAES) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas do Câncer de Mama.  
Parágrafo único. O protocolo, objeto deste artigo, que contêm o conceito geral do Câncer de mama, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Câncer de mama.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º desta portaria.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 05, de 18 de abril de 2019, publicada no Diário Oficial da União nº 81, de 29 de abril de 2019, seção 1, página 44.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **1.        INTRODUÇÃO** -->
O câncer de mama é a neoplasia maligna mais incidente em mulheres. O risco médio de câncer de mama ao longo da vida para uma mulher nos Estados Unidos foi estimado em 12,3% (ou seja, 1 em cada 8 mulheres)<sup>1</sup> . Mundialmente, foram estimados 2,3 milhões de novos casos de câncer de mama em 2020 e cerca de 645 mil óbitos decorrentes da doença<sup>2</sup> . No Brasil, de acordo com o Instituto Nacional do Câncer (INCA), as estimativas de incidência de câncer de mama para o período 2023-2025 são de 73.610 casos, o que representa 30,1% dos cânceres em mulheres<sup>3</sup> . Em 2020, ocorreram 17.825 mortes de mulheres por câncer de mama no país<sup>3</sup> . Sem considerar os tumores de pele não melanomas, o câncer de mama é o mais frequente entre as mulheres em todas as regiões brasileiras, com risco estimado de 84,46 por 100 mil mulheres na Região Sudeste; 71,44 por 100 mil na Região Sul; 57,28 por 100 mil na Região Centro-Oeste; 52,20 por 100 mil na Região Nordeste; e 24,99 por 100 mil na Região Norte<sup>3</sup> .  
O câncer de mama tem seu prognóstico e tratamento definidos pela localização, idade de apresentação e estadiamento, bem como fatores de risco que consideram critérios histopatológicos, biológicos, moleculares e genéticos. Considera-se que o prognóstico é mais favorável quando o câncer de mama é diagnosticado e tratado precocemente comparado ao diagnóstico em estádios avançados ou com metástases sistêmicas. Um estudo acompanhou 1.381 pacientes com câncer de mama e identificou associação significativa entre maior número de metástases em linfonodos axilares, maior diâmetro máximo do tumor, maior estadiamento TNM e menor expressão ou ausência de receptores hormonais com menores taxas de sobrevida livre de doença<sup>4</sup> .  
A idade é considerada o principal fator de risco para o câncer de mama feminino, uma vez que as taxas de incidência aumentam a partir de 40 anos<sup>5</sup> . Um estudo aponta que, no Brasil, a média de idade do diagnóstico de câncer de mama foi de 54 anos<sup>6</sup> . Ainda, 41,1% das pacientes tinham menos de 50 anos ao diagnóstico, das quais 23,3% foram diagnosticadas no estádio I, 53,5% no estádio II e 23,2% no estádio III<sup>5</sup> . A taxa de sobrevida global em 5 anos foi de 96,84% para pacientes no estádio I, 94,16% no estádio II e 70,48% no estádio III<sup>6</sup> .  
Outros fatores de risco estabelecidos incluem aqueles relacionados à vida reprodutiva da mulher (menarca precoce, nuliparidade, idade da primeira gestação a termo acima dos 30 anos; menopausa tardia e terapia de reposição hormonal), alta densidade do tecido mamário, obesidade, urbanização e elevação do status socioeconômico<sup>6–8</sup> . A história familiar de câncer da mama aumenta o risco em 5,5% para mulheres com um parente de primeiro grau afetado e em 13,3%, para aquelas com dois parentes de primeiro grau<sup>5,7,8</sup> .  
Uma revisão sistemática sumarizou dados de 96 artigos e identificou 58 modelos prognósticos que previam mortalidade, recidiva ou ambos em pacientes com câncer de mama. Os preditores mais frequentemente identificados nessa revisão foram o estado nodal, o tamanho do tumor, o grau do tumor, a idade ao diagnóstico e o estado do receptor de estrogênio<sup>9</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a uniformizar o estabelecimento de protocolos terapêuticos com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. O Protocolo abordará os procedimentos e esquemas terapêuticos atualmente disponíveis no Sistema Único de Saúde (SUS). Alguns medicamentos citados <u>no texto não possuem recomendação favorável de incorporação e, portanto, não estão indicados como alternativas terapêuticas</u>  
<u>no SUS. Os esquemas terapêuticos já incorporados ao SUS estão destacados nos quadros de acordo com as linhas de tratamento.</u> As novas tecnologias em fase de avaliação ou que serão demandadas para análise pela Conitec serão incluídas nas versões subsequentes para garantir a sua atualização constante.  
Adicionalmente, esclarece-se que não serão abordados os aspectos referentes ao câncer de mama "in situ".

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **2.        METODOLOGIA** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ). O GRADE classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto). Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 3.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **3.      CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C50.0 Neoplasia maligna do mamilo e aréola  
- C50.1 Neoplasia maligna da porção central da mama  
- C50.2 Neoplasia maligna do quadrante superior interno da mama  
- C50.3 Neoplasia maligna do quadrante inferior interno da mama  
- C50.4 Neoplasia maligna do quadrante superior externo da mama  
- C50.5 Neoplasia maligna do quadrante inferior externo da mama  
- C50.6 Neoplasia maligna da porção axilar da mama  
- C50.8 Neoplasia maligna de mama com lesão invasiva  
- C50.9 Neoplasia maligna da mama, não especificado (Câncer de Mama SOE)

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.1.     Rastreamento** -->
O câncer de mama é uma das doenças mais estudadas em oncologia, considerado muito heterogêneo e, portanto, com diferentes abordagens em diretrizes e trabalhos científicos. As recomendações das diretrizes, em sua maioria, estão baseadas em ensaio clínicos randomizados de fase 3 e em revisões sistemáticas.  
Em 2015, o INCA publicou a Diretriz para a detecção precoce do câncer de mama no Brasil (rastreamento e diagnóstico precoce). Nesta, as estratégias adotadas para detecção precoce foram o rastreamento mamográfico em mulheres de 50 a 69 anos a cada dois anos e a conscientização sobre os sinais e sintomas suspeitos para encaminhamento ao serviço de diagnóstico de câncer mamário<sup>10,11</sup> .  
A estratégia de conscientização destaca a importância do diagnóstico precoce e, na prática, significa orientar a população feminina sobre as mudanças habituais das mamas em diferentes momentos do ciclo de vida e a divulgação dos principais sinais e sintomas do câncer de mama. Estimula também as mulheres a procurarem esclarecimento médico sempre que houver qualquer dúvida em relação a alguma alteração suspeita nas mamas. Com essa estratégia, estimula-se que cada mulher conheça seu corpo, observe alterações e, eventualmente, realize a autopalpação das mamas, sempre que se sentir confortável para tal (seja no banho,  
no momento da troca de roupa ou em outra situação do cotidiano), sem qualquer recomendação de técnica específica, valorizando-se a descoberta casual de pequenas alterações mamárias. Essa estratégia é distinta da antiga recomendação de rastreamento com o método de AEM, o qual apresenta técnica padronizada e periodicidade fixa<sup>10</sup> . A autopalpação das mamas sem alterações não dispensa a mulher de 50 a 74 anos de se submeter à mamografia de rastreamento.  
É importante destacar que situações especiais, como o rastreamento para a população com alto risco de desenvolvimento de câncer de mama, não foram abordadas nesta Diretriz mencionada, devendo ser discutidas e apresentadas em outra oportunidade<sup>10</sup> .  
Desta forma, atualmente a avaliação de risco da mulher deve ser feita de forma individualizada, levando em conta o histórico de risco familiar.  
Após avaliação pela Comissão Nacional de Incorporação de Tecnologias em Saúde (Conitec), tornou-se pública a decisão de não ampliar o uso da mamografia para o rastreamento do câncer de mama em mulheres assintomáticas com risco habitual e que estejam fora da faixa etária atualmente recomendada (50 a 69 anos), por meio da Portaria SCTIE/MS n° 61, de 1 de outubro de 2015<sup>12</sup> . As justificativas para esta recomendação foram que, segundo as evidências científicas disponíveis à época, havia incerteza sobre os benefícios, aliada ao sobrediagnóstico e o pequeno benefício da proposta acompanhado de aumento do risco por resultados falsos positivos, levando a biópsias e tratamentos desnecessários, além do aumento do risco radiológico por exposições repetidas.  
Cabe ressaltar, adicionalmente que, entende-se não haver embasamento científico suficiente que sustente a recomendação para realização de exame mamográfico em mulheres que atingiram a puberdade, porém ainda não satisfazem aos demais critérios estabelecidos neste documento, mesmo estando esta assegurada por força de dispositivo legal<sup>13</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.2.1.   Diagnóstico clínico** -->
A recomendação atual é que os seguintes sinais e sintomas sejam considerados como de referência urgente para serviços  
de diagnóstico mamário (recomendação favorável fraca, ou seja, os possíveis benefícios provavelmente superam os possíveis danos)<sup>10</sup> :  
- Qualquer nódulo mamário em mulheres com mais de 50 anos;  
- Nódulo mamário em mulheres com mais de 30 anos, que persistem por mais de um ciclo menstrual;  
- Nódulo mamário de consistência endurecida e fixo ou que vem aumentando de tamanho, em mulheres adultas de  
- qualquer idade;  
- Descarga papilar sanguinolenta unilateral;  
- Lesão eczematosa da pele que não responde a tratamentos tópicos;  
- Homens com mais de 50 anos com tumoração palpável unilateral;  
- Presença de linfadenopatia axilar;  
- Aumento progressivo do tamanho da mama com a presença de sinais de edema, como pele com aspecto de casca de  
- laranja;  
- Retração na pele da mama, e;  
- Mudança no formato do mamilo.  
A extensão do câncer e sua disseminação no momento do diagnóstico determinam seu estádio, que é essencial para orientar as opções de tratamento e o prognóstico. Deve-se realizar nova avaliação e exame físico completo da paciente à procura de outros potenciais sítios de doença, principalmente nas regiões axilares, cervical e supraclaviculares. Dores musculoesqueléticas  
generalizadas ou localizadas podem indicar metástases ósseas; queixas de dispneia aos esforços podem indicar metástases pulmonares; sintomas e queixas do sistema nervoso central, como parestesias, podem indicar metástases cerebrais. O exame clínico geral deve ser direcionado às metástases locorregionais linfonodais e aos potenciais sítios metastáticos sistêmicos. A ausculta pulmonar, a palpação hepática, do quadril e da coluna também devem fazer parte do exame clínico udirecionado<sup>14</sup> .  
No diagnóstico, também deve-se seguir os algoritmos de investigação preconizados pelo INCA conforme parâmetros técnicos para detecção precoce do câncer de mama, tanto em mulheres com menos de 30 anos quanto em mulheres com 30 anos ou mais de idade<sup>15</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.2.2.  Diagnóstico histopatológico e molecular** -->
A biópsia está indicada para os casos suspeitos de câncer de mama a partir de achados anormais do exame físico, de alterações na mamografia, ou em outro exame complementar necessário para complementação diagnóstica, como a ultrassonografia mamária. O objetivo inicial da biópsia é a obtenção de material suficiente para o diagnóstico definitivo do câncer, sendo primordial para a classificação da neoplasia e avaliação de vários outros parâmetros que são definidores do melhor tratamento para cada paciente.  
A seleção do tipo de biópsia é baseada em vários fatores, incluindo o tamanho, características e a localização da lesão, atributos da paciente, preferências e recursos disponíveis, devendo esta ser orientada, preferencialmente, pelos especialistas médicos mastologistas e radiologistas.  
Em caso de confirmação diagnóstica positiva para malignidade, todas as amostras devem ser submetidas a estudo imunohistoquímico (IHQ) para avaliação dos seguintes biomarcadores, que são fatores prognósticos e preditivos do câncer de mama. Para todos os tipos de carcinomas invasivos da mama, devem ser avaliados os seguintes biomarcadores:  
- Receptor de estrogênio (RE);  
- Receptor de progesterona (RP);  
- Receptor do fator de crescimento epidérmico humano tipo 2 (HER-2)<sup>16</sup> ;  
- Índice de proliferação celular (Ki67/MIB1).  
Se houver discordância entre a positividade de receptor hormonal entre a biópsia da mama, a peça cirúrgica do tumor primário ou biópsia da metástase, deve-se considerar que a paciente apresenta positividade para receptores hormonais (RH), e ela deve ser encaminhada para tratamento direcionado. Importante reforçar que a biópsia óssea negativa para receptores hormonais pode se tratar de um falso negativo, portanto, deve-se priorizar outros sítios de biópsia quando possível<sup>17</sup> .  
A maioria (75 a 80%) dos cânceres de mama é constituída por carcinomas invasivos. Destes, o tipo histológico de carcinoma invasivo mais comum é o carcinoma mamário invasivo de tipo não especial (NST), anteriormente denominado carcinoma ductal invasivo sem outra especificação (SOE), seguido pelo carcinoma lobular invasivo (CLI)<sup>18</sup> . Além disso, há vários outros tipos especiais de carcinomas invasivos (como o micropapilar, metaplásico, mucinoso, tubular, entre outros), tendo a classificação histológica da neoplasia valor prognóstico independente.  
O presente Protocolo inclui estes dois tipos histológicos somente, sendo o termo “câncer de mama” utilizado como seus sinônimos ao longo do texto. Entretanto, a classificação histológica dos carcinomas invasivos é bem mais complexa. Ademais, o termo “câncer de mama” engloba o carcinoma ductal in situ (CDIS), considerado o estágio mais inicial da doença, com elevadas taxas de cura.  
Existem algumas diferenças clínicas entre o carcinoma invasivo de tipo não especial e o lobular, além de distinções no comportamento biológico, alterações moleculares, prognóstico e história natural da doença. Os CLIs estão associados a maior chance de bilateralidade (probabilidade de diagnóstico da doença em ambas as mamas) e maior frequência de doença multicêntrica; acometem mulheres mais idosas; a sua variante clássica comumente apresenta positividade para RH e negatividade  
para HER2; tendência a evoluir com metástases à distância em topografias pouco usuais (trato gastrointestinal, trato ginecológico, cavidades corporais, meninges, globo ocular)<sup>19,20</sup> .  
A IHQ descreve a positividade de RE e de RP com percentual de acometimento. Em relação à avaliação dos RE e RP, no laudo deve constar se o tumor é positivo ou negativo para cada biomarcador, levando-se em consideração o conceito atual de positividade nuclear em no mínimo 1% de células neoplásicas; a porcentagem e intensidade de células neoplásicas com marcação nuclear sempre precisa ser relatada; a associação entre esta porcentagem e a intensidade de coloração pode ser usada para calcular o escore de Allred<sup>16,21–23</sup> .  
Na avaliação do HER2: a marcação será interpretada de acordo com as recomendações do comitê da ASCO/CAP que categoriza a expressão de HER2 em negativa (escore 0); escore 1+; duvidosa (escore 2+); e positiva para superexpressão de HER2 (escore 3+). Nos casos duvidosos (escore 2+), é mandatória a realização de teste de hibridação in situ (ISH) reflexo para a determinação do status de amplificação do gene ERBB2, através de métodos de fluorescência (FISH), cromogênicos (CISH), pela prata (SISH), ou com dupla sonda (DDISH)<sup>24</sup> . Não se indica o exame molecular para os resultados de 0/3, 1/3 ou 3/3 cruzes<sup>16,21–23</sup> .  
Tanto a categoria (negativo/duvidoso/positivo para superexpressão de HER2) como o escore em cruzes (0/1+/2+/3+) sempre devem estar presentes no laudo do estudo imuno-histoquímico, além das respectivas porcentagens de células neoplásicas com marcação de membrana, o padrão (completa circunferencial ou incompleta ou basolateral) e a intensidade desta marcação (fraca, moderada, forte). Carcinomas mamários invasivos que apresentam escore 1+ no estudo imuno-histoquímico ou escore 2+ pelo mesmo método, seguido de resultado negativo/sem amplificação gênica demonstrado pelo teste de hibridação in situ para HER2, têm sido referidos na literatura como câncer de mama com baixa expressão de HER2, do inglês "HER2-low breast cancer".

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3. Estadiamento** -->
O objetivo do estadiamento é classificar a doença de acordo com sua extensão locorregional e distância, agrupando os casos com características semelhantes e estabelecendo padrões que orientam o tratamento e o prognóstico dos casos.  
Tradicionalmente, o estadiamento do câncer de mama mais utilizado é o da União Internacional Contra o Câncer (UICC), a Classificação de Tumores Malignos, que utiliza as categorias T (tumor), N (acometimento linfonodal) e M (metástase a distância), chamada simplificadamente de TNM<sup>25</sup> . Também é utilizado o sistema TNM da _American Joint Committee for Cancer_ (AJCC)<sup>26</sup> , cuja 8ª edição expandiu a classificação e estadiamento para além dos sítios anatômicos e incluiu outros fatores prognósticos, como o grau histológico e o perfil imunohistoquímico.  
O estadiamento considera as seguintes classificações para os linfonodos regionais mamários<sup>26</sup> :  
- Axilares homolaterais: linfonodos interpeitorais (Rotter) e linfonodos ao longo da veia axilar e suas tributárias, que  
- podem ser divididos nos seguintes níveis:  
- Nível I (axilar inferior): linfonodos situados lateralmente à borda lateral do músculo pequeno peitoral (linfonodos  
- intramamários);  
- Nível II (axilar médio): linfonodos situados entre as bordas medial e lateral do músculo pequeno peitoral e linfonodos  
- interpeitorais (Rotter); e  
- Nível III (axilar apical): linfonodos apicais e aqueles situados à margem medial do músculo pequeno peitoral incluindo  
- os linfonodos infraclaviculares homolaterais.  
- Mamários internos homolaterais (linfonodos localizados nos espaços intercostais, ao longo da borda do esterno, na  
- fáscia endotorácica);  
- Supraclaviculares homolaterais.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.1.  Classificação clínica TNM da UICC** -->
Nos **Quadros 1** e **2** está apresentada a Classificação Clínica TNM da UICC<sup>25,26</sup> , a qual avalia critérios anatômicos da doença, relacionados ao tumor, acometimento linfonodal e metástase. Além dela, números podem ser adicionados a estes três componentes, a fim de indicar a extensão da doença maligna.  
**Quadro 1.** Resumo da Classificação Clínica TNM da União Internacional Contra o Câncer (UICC).  
|CATEGORIA|T (TUMOR)|
|---|---|
|Tx|O tumor não pode ser avaliado|
|T0|Não há evidência de tumor primário|
|Tis|Carcinoma in situ|
|Tis (CDIS)|Carcinoma intraductal in situ; restringe se somente ao CDIS. O carcinoma lobular in situ é considerado uma<br>doença benigna e não deve ser designado como Tis.|
|Tis (Paget)|Doença de Paget do mamilo não associada a carcinoma invasivo e/ou carcinoma in situ (CDIS ou CLIS) no<br>parênquima mamário subjacente. Os carcinomas mamários associados à doença de Paget são classificados de<br>acordo com o tamanho e características da neoplasia parenquimatosa, porém a presença da doença de Paget<br>deve ser registrada.|
|T1|Tumor com 2 cm ou menos em sua maior dimensão|
|T1mic*|Tumor com até 0,1 cm em sua maior dimensão;|
|T1a|Tumor com mais de 0,1 cm e com até 0,5 cm em sua maior dimensão;|
|T1b|Tumor com mais de 0,5 cm e com até 1 cm em sua maior dimensão;|
|T1c|Tumor com mais de 1 cm e com até 2 cm em sua maior dimensão;|
|T2|Tumor com mais de 2 cm e com até 5 cm em sua maior dimensão;|
|T3|Tumor com mais de 5 cm em sua maior dimensão;|
|T4|Tumor de qualquer tamanho, com extensão direta para a parede torácica (t4a), pele (t4b**) ou ambos (t4c);<br>(t4d) câncer inflamatório***.|
|CATEGORIA|N (ACOMETIMENTO LINFONODAL)|
|Nx|Os linfonodos regionais não podem ser avaliados (por exemplo, por terem sido previamente removidos)|
|N0|Ausência de metástase em linfonodo regional****|
|N1|Metástase em linfonodo axilar homolateral, nível I, II, móvel|
|N2|Metástase em linfonodo axilar homolateral, nível I, II, móvel, clinicamente fixos ou confluentes; ou metástase<br>detectada clinicamente***** em linfonodo mamário interno homolateral, na ausência de evidência clínica de<br>metástase em linfonodo axilar|
|N2a|Metástase em linfonodos axilares homolaterais, nível I, II, fixos uns aos outros ou a outras estruturas|
|N2b|Metástase detectada clinicamente em linfonodo mamário interno homolateral, na ausência de evidência<br>clínica de metástase em linfonodo axilar|  
|N3|Metástase em linfonodo infraclavicular homolateral (nível III) com ou sem acometimento de linfonodo axilar<br>nível I, II; ou metástase detectada clinicamente em linfonodo mamário interno homolateral, na presença de<br>evidência clínica de metástase em linfonodo axilar, nível I, II; ou metástase em linfonodo supraclavicular<br>homolateral com ou sem acometimento de linfonodo axilar ou mamário interno|
|---|---|
|N3a|Metástase em linfonodo infraclavicular homolateral, com ou sem acometimento da cadeia axilar|
|N3b|Em linfonodo mamário interno e axilar homolateral|
|N3c|Metástase em linfonodo supraclavicular homolateral|
|CATEGO|RIA M (METÁSTASE A DISTÂNCIA)|
|M0|Ausência de metástase a distância|
|M1|Presença de metástase a distância (inclusive metástase em qualquer outro linfonodo que não os regionais<br>homolaterais, entre eles os linfonodos cervicais ou mamários internos contralaterais|  
Legenda: CDIS: carcinoma invasivo não especial; CLIS: carcinoma lobular infiltrante; Mic: Microinvasão Notas:  
* Microinvasão (Mic) é a extensão de células neoplásicas além da membrana basal, alcançando os tecidos adjacentes, sem focos tumorais maiores do que 0,1 cm em sua maior dimensão. Quando há focos múltiplos de microinvasão, somente o tamanho do maior foco é utilizado para classificar a microinvasão (não usar a soma dos focos individuais). A presença de múltiplos focos de microinvasão deve ser anotada como se faz com os carcinomas invasores extensos múltiplos.  
** Somente invasão da derme não classifica o tumor como T4. A parede torácica inclui costelas, músculos intercostais e músculo serrátil anterior, mas não inclui o músculo peitoral.  
*** O carcinoma inflamatório da mama é caracterizado por um endurado difuso e intenso da pele da mama com bordas erisipeloides, geralmente sem massa tumoral subjacente. Se a biópsia da pele for negativa e não existir tumor primário localizado mensurável, o carcinoma inflamatório clínico (cT4d) é classificado patologicamente como pTX. A retração da pele e do mamilo ou outras alterações cutâneas, exceto aquelas incluídas em T4b e T4d, podem ocorrer em T1, T2 ou T3, sem alterar a classificação.  
**** A metástase em linfonodo regional diz respeito a ninhos de células tumorais isoladas [CTI (ITC) ] são células tumorais únicas ou em pequenos grupamentos celulares, não maiores que 0,2 mm em sua maior dimensão, que podem ser detectados por exame histopatológico de rotina (coloração H&E), ou por imunohistoquímica. Um critério adicional foi proposto: o de incluir ninhos celulares que contenham menos de 200 células em um único corte transversal histológico. Os linfonodos contendo somente células tumorais isoladas são excluídas da contagem do total de linfonodos positivos para a classificação N, mas devem ser incluídos no número total de linfonodos avaliados.  
***** Metástase detectada clinicamente é definida como por exame clínico ou de imagem (exceto linfocintilografia), tendo características altamente suspeitas de malignidade, ou uma micrometástase patologicamente presumida, baseada em punção aspirativa por agulha fina e exame citológico. A confirmação de metástase clinicamente detectada por punção aspirativa por agulha fina, sem biópsia excisional, é designada com um sufixo (f), por exemplo cN3a(f). A biópsia excisional de um linfonodo ou a biopsia de um linfonodo sentinela, na ausência de uma designação para pT, é uma classificação clínica para N, por exemplo cN1. A classificação patológica (pN) é usada para a excisão de um linfonodo ou biópsia de um linfonodo sentinela, somente em associação com a designação patológica do T.  
Fonte: Brierley et al, 2016<sup>25</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.2.  Classificação clínica anatômica TNM em estádios** -->
O agrupamento do sistema TNM para descrever a extensão anatômica da doença é baseado na avaliação obtida antes do início do tratamento. O estadiamento clínico anatômico utiliza o exame clínico e os exames de imagem disponíveis em um período de até quatro semanas a partir do diagnóstico ou anteriores à realização da cirurgia. O estádio clínico anatômico somente deverá ser utilizado nos locais nos quais o estadiamento clínico prognóstico não for possível<sup>26</sup> .  
**Quadro 2.** Classificação clínica anatômica TNM em estádios.  
|Estádio|T|N|M|
|---|---|---|---|
|0|Tis|N0|M0|
|IA|T1/T1 mic|N0|M0|
|IB|T0/T1|N1mi*|M0|
|IIA|T0/T1|N1|M0|
||T2|N0|M0|
|IIB|T2|N1|M0|
||T3|N0|M0|
|IIIA|T0-T3|N2|M0|
||T3|N1|M0|
|IIIB|T4|N0-N2|M0|
|IIIC|Qualquer|N3|M0|
|IV<br>Legenda:|Qualquer|Qualquer|M1|  
*mi: micrometástase (maior que 0,2 mm e/ou mais que 200 células, porém não maior que 2 mm em sua maior dimensão) Fonte: Sociedade Brasileira de Oncologia Clínica<sup>27</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.3.  Classificação clínica prognóstica TNM** -->
O agrupamento do sistema TNM para descrever o prognóstico de um caso tem como objetivos relatar o provável curso clínico de cada paciente, possibilitar a comparação com outros casos similares e auxiliar na tomada de decisão clínica do profissional. A classificação clínica prognóstica (pré-tratamento), designada TNM (ou cTNM) e apresentada no Quadro 3, tem por base o resultado da biópsia, especificamente o grau histológico e os marcadores imunohistoquímicos (RE, RP e HER-2) e incorpora estes resultados no estadiamento clínico. Dessa forma, o estadiamento clínico prognóstico associa os dados anatômicos aos patológicos-imunohistoquímicos da biópsia e, sempre que possível, deverá ser utilizado.  
**Quadro 3** . Classificação clínica prognóstica TNM em estádios.  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
|TisN0M0|Qualquer|Qualquer|Qualquer|Qualquer|0|
|T1N0M0|G1/G2|+|+<br>-|+<br>-<br>+<br>-|IA|
|<br>T0N1miM0<br>T1N1miM0||-|+|+<br>-||
||||-|+<br>-|IB|
||G3|+|+|+<br>-|IA|  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
||||-|+<br>||
||||+|-<br>+<br>-||
|||-|-|+<br>-|IB|
||||+|+<br>-|IB|
|||+|-|+|IIA|
||G1||+|-<br>+<br>|IB|
|||-|-|-<br>+<br>-|IIA|
||||+|+|IB|
|||+|-|-<br>+|IIA|
|T0N1*M0||||||
|||||-||
|T1N1*M0|G2|||||
|T2N0M0|||+|+|IB|
|||-||-<br>+|IIA|
||||-|-|IIB|
||||+|+|IB|
|||||-||
|||+|-|+<br>-|IIA|
||G3||+|+<br>-||
|||-|-|+<br>-|IIB|
||||+|+|IB|
|T2N1**M0 T3N0M0|G1|+||-<br>+|IIA|
||||-|-|IIB|
|||-|+|+|IIA|  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
||||-|-<br>+<br>-|IIB|
||||+|<br>+|IB|
|||+||-<br>+|IIA|
||G2||-|-|IIB|
||||+|+|IIA|
|||||-||
|||-|||IIB|
|||||+||
||||-|-|IIIB|
||||+|+|IB|
|||||-||
|||+|-|+<br>-|IIB|
||G3|||+||
|||-|+<br>-|-<br>+|IIIA|
|||||-|IIIB|
|||||+|IIA|
||||+|||
|||||-||
|||+|-|+<br>|IIIA|
||G1/G2|||-||
|||||+|IIA|
||||+|||
|||-||-|IIIA|
|T0N2M0|||-|+||
|T1N2M0||||-|IIIB|
|T2N2M0||||+|IIB|
|T3N1**M0 T3N2M0|||+|-||
|||+|-|+<br>-|IIIA|
||G3|||||
|||||+||
||||+|||
|||-|<br>-|-<br>+<br>-|IIIB<br>IIIC|  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
||G1/G2|+<br>-|+<br>-<br>+|+<br>-<br>+<br>-<br>+<br>-<br>+|IIIA<br>IIIB|
|T4N0M0<br>T4N1**M0|||-|-|IIIC|
|<br>T4N2M0 qqTN3M0|||+|+<br>-||
||G3|+<br>-|-<br>+<br>-|+<br>-<br>+<br>-<br>+<br>-|IIIB<br>IIIC|
|qqTqqNM1|Qualquer|Qualquer|Qualquer|Qualquer|IV|  
Legenda:  
Grau*: O patologista atribui uma nota para o câncer, que é baseada em quão a amostra de biópsia se parece com o tecido mamário normal e à rapidez com que as células cancerígenas se dividem. O grau pode prever o prognóstico de uma paciente. Em geral, menor grau (1) indica um câncer de crescimento mais lento e é menos provável que se dissemine, enquanto um grau mais alto (3) indica um câncer de crescimento mais rápido, mais provável de se disseminar. T1 inclui T1mic  
N*: Tumores cT1N1micM0 e cT0N1micM0 em termos do estadiamento prognóstico são incluídos conjuntamente com os tumores cT1N0M0 com os mesmos fatores prognósticos (grau, RE, RP e HER-2).  
N**: Tumores cT2N1mic, cT3N1mic, e cT4N1mic em termos do estadiamento prognóstico são incluídos conjuntamente com os tumores cT2N1, cT3N1 e cT4N1 com os mesmos fatores prognósticos (grau, RE, RP e HER-2). Legenda: HER-2: receptor tipo 2 do fator de crescimento epidérmico humano; RE = receptor de estrogênio; RP = receptor de progesterona.  
Fonte: Sociedade Brasileira de Oncologia Clínica<sup>27</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.4.  Classificação patológica prognóstica** -->
A classificação patológica prognóstica, realizada após o tratamento cirúrgico, deve ser precedida pela letra “p”, sendo que os critérios para a classificação do tumor (T) e metástase à distância (M) são iguais aos da classificação clínica. Essa classificação inclui os dados patológicos pós-tratamento cirúrgico e os dados prognósticos imunohistoquímicos (RE, RP, progesterona e HER-2)<sup>25,26</sup> .  
A classificação histopatológica requer o exame do carcinoma primário sem tumor macroscópico nas margens de ressecção. Ao se classificar a categoria pT, o tamanho do tumor é a medida do componente invasivo. Um caso pode ser classificado como pT se houver somente tumor microscópico em uma margem.  
Se há um grande componente _in situ_ (por exemplo, com 4 cm) e um pequeno componente invasor (por exemplo, com 0,5 cm), o tumor é codificado como pT1a<sup>25,26</sup> .  
A classificação histopatológica da invasão linfática regional, apresentada no Quadro 4, requer a ressecção e o exame, pelo menos, dos linfonodos axilares inferiores (nível I). Tal ressecção incluirá, geralmente, seis ou mais linfonodos. Se os linfonodos são negativos, mesmo que o número usualmente examinado não seja encontrado, classifica-se como pN0.  
**Quadro 4.** Classificação patológica prognóstica da invasão linfática regional.  
|**Categori**|**a N (acometimento linfonodal)***|
|---|---|
|pNX|os linfonodos regionais não podem ser avaliados (por exemplo, por terem sido removidos previamente ou não<br>terem sido removidos para estudo histopatológico)|
|pN0|ausência de metástase em linfonodos regionais**|
|pN1|micrometástase; ou metástase em um a três linfonodos axilares homolaterais; ou linfonodo mamário interno<br>homolateral com metástase detectada por biópsia de linfonodo sentinela, porém não detectada clinicamente***|
|pN1mi|micrometástase (maior que 0,2 mm ou mais que 200 células, porém não maior que 2 mm em sua maior dimensão)|
|pN1a|metástase em um a três linfonodos axilares incluindo, pelo menos, um maior que 2 mm em sua maior dimensão|
|pN1b|linfonodo mamário interno com metástase micro ou macroscópica detectada por biópsia de linfonodo sentinela,<br>porém não detectada clinicamente|
|pN1c|metástase em um a três linfonodos axilares e linfonodos mamários internos com metástase micro ou<br>macroscópica, detectada por biópsia de linfonodo sentinela, porém não detectada clinicamente; pN2: metástase<br>em quatro a nove linfonodos axilares homolaterais, ou em linfonodo mamário interno homolateral, detectada<br>clinicamente, na ausência de metástase em linfonodos axilares|
|pN2|metástase como descrita abaixo:|
|pN2a|metástase em quatro a nove linfonodos axilares, incluindo pelo menos uma maior que 2 mm;|
|pN2b|metástase em linfonodo mamário interno, detectada clinicamente, na ausência de metástase em linfonodos<br>axilares|
|pN3|metástase como descrita abaixo:|
|pN3a|metástase em 10 ou mais linfonodos axilares (pelo menos uma maior que 2 mm) ou metástase em linfonodos<br>infraclaviculares|
|pN3b|metástase detectada clinicamente em linfonodo mamário interno homolateral, na presença de linfonodos axilares<br>positivos; ou metástase em mais de três linfonodos axilares e em linfonodos mamários internos com metástase<br>micro ou macroscópica detectada por biópsia de linfonodo sentinela, porém não detectada clinicamente|
|pN3c|metástase em linfonodos supraclaviculares homolaterais.|  
Legenda:  
* Os critérios para a classificação do tumor (T) e metástase à distância (M) são iguais aos da classificação clínica, já apresentados no Quadro 1. ** Ninhos de células tumorais isoladas [CTI] são células tumorais únicas ou em pequenos grupamentos celulares, não maiores que 0,2 mm em sua maior dimensão, que podem ser detectados por exame histopatológico de rotina (coloração H&E), ou por imunohistoquímica. Um critério adicional foi proposto: o de incluir ninhos celulares que contenham menos de 200 células em um único corte transversal histológico. Os linfonodos contendo somente células tumorais isoladas são excluídas da contagem do total de linfonodos positivos para a classificação N, mas devem ser incluídos no número total de linfonodos avaliados. *** Os casos com células tumorais isoladas ou micrometástases (lesões entre 0,2 e 2 mm) identificadas por imunohistoquímica em linfonodos axilares são classificados como pN0(i+); somente deverão ser classificadas como N1 os casos de micrometástases detectadas pela coloração de hematoxilina-eosina. A invasão microscópica sem correlação clínica não possui valor para mudança do estadiamento.  
Fonte: Sociedade Brasileira de Oncologia Clínica<sup>27</sup> .  
O estadiamento patológico prognóstico é realizado após a cirurgia por meio da análise anatomopatológica dos órgãos ou tecido retirados na cirurgia. Este é o estadiamento mais importante, pois ele definirá o grau de avanço real da doença no órgão. No **Quadro 5** estão descritos o estadiamento e a classificação patológica prognóstica.  
**Quadro 5.** Estadiamento e classificação patológica prognóstica.  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
|**TisN0M0**|Qualquer|Qualquer|Qualquer|Qualquer|0|
|||+|+<br>-|+<br>-<br>+|IB|
||G1||+|-<br>+<br>-||
|||-|-|+||
||||+|-<br>+<br>-|IA|
|**T1N0M0**<br>|G2|+|-|+<br>-||
|**T0N1miM0**<br>**T1N1miM0**|||+|+<br>-||
|||-||+||
||||-|-|IB|
||||+|+<br>-||
||G3|+|-|+<br>-|IA|
||||+|+<br>-||
|||-|-|+||
|||||-|IB|
|||||||
||||+|+|IA|
|||+||-<br>+|IB|
||||-|-|IIA|
||G1||+|+|IA|
|||||-|IB|
|||-||||
|||||+||
|**T0N1*M0**|||-|-|IIA|
|**T1N1*M0**||||+|IA|
|**T2N0M0**|||+|||
|||||-||
|||+|||IB|
|||||+||
||G2||-|-|IIA|
|||||+|IA|
||||+|-||
|||-||+|IIA|
||||-|-||
||G3|+|+|+|IA|  
|**TNM**<br>**Grau**|**HER-2**|**RE**|**RP**<br>-|**Estádio**|
|---|---|---|---|---|
|||-|+<br>-|IIA|
|||+|+|IB|
||||-||
||-|-|+|IIA|
||||-||
|||+|+|IA|
||||-||
||+|-|+|IIB|
|G1|||-||
|||+|+|IA|
||||-||
||-|-|+|IIB|
||||-||
|||+|+|IB|
||||-||
||+|-|+|IIB|
|**T2N1**M0**<br>|||-||
|<br>**T3N0M0**<br>G2||+|+|IB|
||||-||
||-|-|+<br>-|IIB|
|||+|<br>+|IB|
||||-||
||+|-|+|IIB|
|G3|||-||
|||+|+|IIA|
||||-||
||-||+|IIB|
|||-|-|IIIA|
|||+|+|IB|
||||-||
||+|-|+|IIIA|
|G1|||-||
|||+|+|IB|
||||-||
||-|-|+|IIIA|
|**T0N2M0 T1N2M0**|||-||
|**T2N2M0**|||+|IB|
|<br>**T3N1**M0**||+|-||
|**T3N2M0**|+||+|IIIA|
|||-|-||
|G2||+|+|IB|
||-||-<br>+|IIIA|
|||-|-|IIIB|
||||+|IIA|
|G3|+|+|-|IIIA|  
|**TNM**|**Grau**|**HER-2**|**RE**|**RP**|**Estádio**|
|---|---|---|---|---|---|
||||-|+<br>-||
||||+|+|IIB|
|||-||-<br>+|IIIA|
||||-|-|IIIC|
||||+|+|IIIA|
|||||-||
|||+|-|+|IIIB|
|||||-||
||G1||+|+|IIIA|
|||||-||
|||-|-|+<br>-|IIIB|
|||||+|IIIA|
||||+|||
|||||-||
|||+||+|IIIB|
|**T4N0M0**|||-|||
|||||-||
|**T4N1**M0**|G2|||||
|**T4N2M0 qqTN3M0**|||+|+|IIIA|
|||||-|IIIB|
|||-||+||
||||-|-|IIIC|
||||+|+||
|||||-||
|||+|-|+|IIIB|
||G3|||-||
||G1|||+||
||||+|||
|||||-||
|||-|-|+|IIIC|
|||||-||
|**qqTqqNM1**|Qualquer|Qualquer|Qualquer|<br>Qualquer|IV|  
Notas: T1 inclui T1 mic.  
N*: Tumores cT1N1micM0 e cT0N1micM0 em termos do estadiamento prognóstico são incluídos conjuntamente com os tumores cT1N0M0 com os mesmos fatores prognósticos (grau, RE, RP e HER-2).  
N**: Tumores cT2N1mic, cT3N1mic, e cT4N1mic em termos do estadiamento prognóstico são incluídos conjuntamente com os tumores cT2N1, cT3N1 e cT4N1 com os mesmos fatores prognósticos (grau, RE, RP e HER-2). Legenda: HER-2: receptor tipo 2 do fator de crescimento epidérmico humano; RE = receptor de estrogênio; RP = receptor de progesterona.  
Fonte: Sociedade Brasileira de Oncologia Clínica<sup>27</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.5.  Classificação pós-tratamento neoadjuvante** -->
O uso da quimioterapia e da hormonioterapia neoadjuvantes tem se tornado cada vez mais frequente no tratamento do câncer de mama. O prefixo y é utilizado para designar o estadiamento clínico e patológico pós-tratamento neoadjuvante. No caso de neoadjuvância, os mesmos critérios dos Quadros 2 e 3 devem ser seguidos, porém, acrescentando o y previamente, como por exemplo, o estádio yT2 ou ypT2.  
A resposta tumoral pós-tratamento pode ser avaliada e classificada, clinicamente e patologicamente, em resposta completa  
(cCR e pCR), resposta parcial (cPR e pPR) ou em ausência de resposta (NR).

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.3.6.  Considerações adicionais** -->
O modificador “sn” é utilizado somente se a avaliação do linfonodo foi realizada por meio do linfonodo sentinela.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.4.    Avaliação diagnóstica complementar** -->
Os exames complementares necessários para o estadiamento são hemograma completo, dosagens séricas de glicose, ureia, creatinina, fosfatase alcalina (FA) e aminotransferases/transaminases, eletrocardiograma (ECG) e radiografia simples de tórax. Em casos de estádio IA, IB ou IIA com FA normal, estes exames são suficientes.  
Nos estadios iniciais, a realização de ultrassom de abdome pode ser adicionada para estadiamento. A tomografia computadorizada (TC) de tórax e abdômen superior podem ser acrescentadas na avaliação dos pacientes a partir do estádio IIB. Já a cintilografia óssea está indicada a partir do estádio IIB ou se houver dores ósseas e FA aumentada em pacientes nos estádios iniciais. Um estudo que analisou 173 pacientes nesta condição mostrou que, após estudo tomográfico, cerca de 7,5% (13 pacientes) foram estagiadas como estádio IV<sup>28</sup> .  
A ressonância magnética (RM) da mama não faz parte da rotina de estadiamento, nem do seguimento pós-tratamento. No entanto, pode ser indicada em situações clínicas específicas. A RM pode ser necessária para avaliação de metástases no sistema nervoso central e para complementar o diagnóstico de doença na síndrome de compressão medular<sup>29,30</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4.5.     Classificação de risco de recidiva** -->
Para a decisão terapêutica, deve-se considerar o estadiamento pela classificação TNM, laudo histopatológico, resultado do exame de IHQ, quadro clínico e tratamento local, caso já tenha sido realizado.  
Conforme os critérios, classifica-se o risco de recidiva do câncer de mama como baixo, intermediário ou alto, a fim de orientar a indicação de quimioterapia adjuvante. Quanto maior o risco de recidiva, maior deverá ser o benefício do tratamento. No Quadro 6 estão descritos os critérios para classificar o risco de recidiva, de acordo com o consenso de especialistas em Saint Gallen, em 2007<sup>31</sup> , atualizado em 2013, para definições clínico-patológicas de subtipos e suas implicações para a seleção do tratamento sistêmico do carcinoma de mama<sup>30</sup> .  
Preconiza-se o uso de calculadoras de risco extensamente validadas, como a ferramenta PREDICT, especialmente na impossibilidade de realizar perfis de expressão gênica que guiem a terapêutica<sup>32–36</sup> . Destaca-se que a ferramenta PREDICT é útil para decisão sobre a condução terapêutica de mulheres que fizeram cirurgia para câncer de mama invasivo em estádios iniciais.  
**Quadro 6.** Classificação de risco de recidiva.  
|Riscos|Definições clínico-patológicas|
|---|---|
|Baixo *|Linfonodo negativo e todos os seguintes critérios:|
||●<br>pT até 2 cm; e|
||●<br>Grau 1; e|
||●<br>Ausência de extensa invasão vascular peritumoral; e|
||●<br>RE ou RP positivo; e|
||●<br>Gene HER-2/neu negativo; e|
||●<br>Idade igual ou acima de 35 anos.|  
|Riscos|Def|inições clínico-patológicas|
|---|---|---|
|Médio *|Lin<br>●|fonodo negativo e pelo menos um dos seguintes critérios:<br>pT maior que 2 cm; ou|
||●|Grau 2 ou 3; ou|
||●|Presença de extensa invasão vascular peritumoral; ou|
||●|RE ou RP negativos; ou|
||●|Gene HER-2/neu positivo; ou|
||●<br>**Ou**|Idade abaixo de 35 anos.<br>|
||●|Linfonodo positivo (1 a 3 positivos) e os seguintes critérios:|
||●|RE ou RP positivo; e|
||●|Gene HER-2/neu negativo|
|Alto *|Lin<br>●|fonodo positivo (1 a 3 positivos) e um seguintes critérios:<br>RE ou RP negativos; ou|
||●<br>**Ou**|Gene HER-2/neu positivo.<br>|
||●|Linfonodo positivo (4 ou mais positivos)|  
Legenda: pT: tamanho do tumor patológico; HER-2: receptor tipo 2 do fator de crescimento epidérmico humano; RH: receptores hormonais; RE: receptor de  
estrogênio; RP: receptor de progesterona.  
Fonte: Adaptação da 10ª reunião de consenso de especialistas em Saint Gallen (Suíça)<sup>31</sup> .  
* As categorias de risco não se baseiam em métricas de probabilidade, mas em opinião de especialistas.  
Não está disponível no SUS a avaliação de risco baseado em análise genômica, com o uso de tecnologista como Mammaprint<sup>®</sup> , Oncotype<sup>®</sup> , dentre outros.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **5.        CRITÉRIOS DE INCLUSÃO** -->
Serão incluídas as pacientes de qualquer idade que apresentem um dos seguintes diagnósticos, comprovado por histologia:  
- Qualquer carcinoma invasivo da mama, incluindo Carcinoma Invasivo Misto, Carcinoma Invasivo Micropapilar e o Carcinoma Metaplásico;  
- Qualquer carcinoma de mama com histologias especiais de bom prognóstico como: Carcinoma Tubular, Carcinoma Mucinoso Invasivo, Carcinoma Cribriforme Invasivo, Carcinoma Papilífero Invasivo. Estas pacientes não costumam ter indicação para tratamento com quimioterapia adjuvante, salvo em pacientes com linfonodos comprometidos ou em idade muito jovem, mas estão contempladas neste Protocolo para regular uso de terapia endócrina (hormonioterapia).

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **6.        CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídas as pacientes que apresentarem carcinoma in situ, seja ductal ou lobular, independentemente do tamanho. Intolerância, hipersensibilidade ou contraindicação serão os critérios de exclusão ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **7.        ABORDAGEM COMPLEMENTAR** -->
A dor pode ser um sintoma em pacientes com câncer de mama e seu controle adequado está associado à melhor qualidade de vida destas pacientes. Assim, em qualquer etapa do tratamento, deve-se oferecer o acesso às estratégias medicamentosas e não medicamentosas disponíveis no SUS para controle da dor, conforme preconizado no PCDT da Dor Crônica vigente.  
Nesse sentido, destaca-se a importância do cuidado integral à paciente que deve incluir acompanhamento por uma equipe multiprofissional integrada.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.        TRATAMENTO NÃO MEDICAMENTOSO** -->
O tratamento não medicamentoso do carcinoma de mama inclui: abordagem cirúrgica do tumor e dos linfonodos axilares, reconstrução da mama e radioterapia.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.1. Cirurgia** -->
A cirurgia continua sendo o principal tratamento do câncer de mama e pode ser dividida em tratamento conservador ou radical. Habitualmente tumores iniciais e principalmente aqueles que puderem ser submetidos a cirurgia conservadora devem receber este tratamento como primeira abordagem.  
O procedimento inclui a intervenção na mama (exérese do tumor e reconstrução) e na axila (avaliação e retirada de linfonodos). As abordagens cirúrgicas podem ser parciais ou totais, dependendo das características clínicas do tumor e do prognóstico de cada paciente. Ao longo do tempo, os procedimentos cirúrgicos evoluíram de tratamentos mais agressivos para menos invasivos, apresentando maior ganho estético, sem afetar os desfechos de cura<sup>37</sup> . A indicação da cirurgia deve incluir exames (clínico e de imagem) e pode ser apoiada pelos seguintes critérios:  
- Tamanho e quantidade de tumores;  
- Volume da mama;  
- Contraindicação para radioterapia;  
- Resultado estético;  
- Escolha da paciente;  
- Recorrência local.  
O tratamento cirúrgico para o câncer de mama pode consistir na excisão do tumor com tecido mamário normal circundante  
(cirurgia conservadora da mama) ou mastectomia, a saber:

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **<u>Cirurgia conservadora (parcial):</u>** -->
A cirurgia conservadora da mama aliada à radioterapia complementar demonstrou eficácia terapêutica igual ou superior à da mastectomia em pacientes candidatas a esta técnica e foi estudado por Veronesi e colaboradores no estudo Milan 1<sup>38</sup> . Diante da redução do volume mamário com as novas técnicas, novos termos foram incorporados como sinônimo de cirurgia conservadora da mama, normalmente quando se retira a pele sobre o tumor damos o nome de quadrantectomia e na situação em que não se retira a pele podemos chamar de ressecção segmentar da mama, segmentectomia, tumorectomia e até mastectomia parcial da mama.  
A maioria das pacientes com câncer de mama em estádios iniciais (I e II) são candidatas à cirurgia conservadora. O tamanho do tumor não é um fator limitante por si só, mas a relação entre o volume da mama e o tamanho do tumor é o fator mais importante. Assim, desde que não haja contraindicações ao procedimento, a cirurgia conservadora deve ser a primeira escolha considerando-se sempre a segurança oncológica com um resultado estético adequado.  
Embora não tenha sido observada diferença na sobrevida livre de doença à distância e na sobrevida global, a taxa de recorrência local foi significativamente maior no grupo tratado com tumorectomia em um seguimento médio de cinco anos (3% versus 8%)<sup>39,40</sup> . Assim, um conceito básico do tratamento conservador é que deve haver a remoção de um volume de tecido mamário sadio suficiente para obter margem cirúrgica livre de neoplasia.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Contraindicações para cirurgia conservadora** -->
Qualquer que seja a técnica escolhida, antes da indicação do procedimento é necessário observar criteriosamente as suas contraindicações. Uma situação importante quando se indica a cirurgia conservadora é a necessidade da radioterapia adjuvante no parênquima residual. Logo, pacientes com contraindicação para receberem radioterapia complementar deverão ser cuidadosamente avaliadas.  
Os estudos que compararam a eficácia da cirurgia conservadora com e sem a adição de radioterapia adjuvante demonstraram taxas de recorrência local maiores no grupo no qual a radioterapia foi omitida sem alteração na sobrevida global<sup>41–</sup> 46.  
Também representam contraindicação os tumores com comprometimento inicial extenso da pele da mama (T4B/T4D), conhecidos como carcinomas inflamatórios, primários ou secundários. Pacientes com múltiplas lesões em diferentes quadrantes das mamas também devem ser considerados não candidatos à cirurgia conservadora. Doenças autoimunes em atividade, como lúpus e esclerose sistêmica, são consideradas contraindicações absolutas ao tratamento conservador, devido à necessidade de radioterapia.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **<u>Cirurgia não conservadora (total)</u>** -->
Também conhecida como mastectomia, é indicada quando o tamanho do tumor é grande em relação ao tamanho da mama ou quando não é possível obter margens cirúrgicas negativas após múltiplas ressecções. Esse procedimento pode envolver a retirada do complexo aréolo-papilar, ressecção de músculos peitorais e linfadenectomia axilar. O tipo mais comum de abordagem cirúrgica total é a mastectomia radical modificada, que compreende a retirada total da mama e o esvaziamento axilar com preservação (mastectomia Madden) ou não (mastectomia Patey) dos músculos<sup>37</sup> .  
A reconstrução de mama pode ser imediata ou tardia. Esse processo decisório deve considerar a vontade da paciente, a disponibilidade da técnica no centro de referência e a necessidade de tratamento local complementar. A cirurgia da mama contralateral pode ser necessária para “simetrização” estética, tendo esta garantia legal, porém dependente de fatores regulatórios locais<sup>1,47</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.1.1.  Avaliação dos linfonodos axilares** -->
O linfonodo sentinela é o primeiro linfonodo que recebe a drenagem linfática proveniente do câncer de mama. A sua detecção tem a finalidade de predizer o estado da axila e evitar o esvaziamento axilar nos pacientes sem comprometimento metastático.  
Após a consolidação da cirurgia conservadora da mama como método terapêutico de escolha nos estádios iniciais, a grande controvérsia atualmente está voltada ao tratamento da axila nesses casos<sup>40</sup> . Ela é a responsável pela maior parte da morbidade associada às cirurgias mamárias: seroma, linfedema, alterações na sensibilidade local, internação prolongada, dor crônica e dificuldade de mobilização do braço são alguns dos seus efeitos diretos<sup>48,49</sup> . Apesar disso, ainda persiste como o principal fator prognóstico no câncer de mama, com importância fundamental para a escolha da terapia adjuvante<sup>50–55</sup> .  
Devido a esses fatos, surgiu uma nova modalidade de diagnóstico, com o objetivo de evitar os esvaziamentos axilares desnecessários, ou seja, nas pacientes com axila negativa. Esse método foi denominado de Linfonodo Sentinela (LS) e consiste na detecção e biópsia cirúrgica do primeiro linfonodo que aparece na drenagem linfática tumoral<sup>56</sup> . A biópsia do linfonodo sentinela é a abordagem apropriada tanto para tumores T1 quanto para T2 com axilas clinicamente negativas. A técnica pode ser empregada nas cirurgias conservadoras e nas mastectomias. As contraindicações absolutas são metástases axilares palpáveis ou  
confirmadas por citologia/histologia. Contraindicações relativas são doença multifocal na mama e cirurgias mamárias ou axilares anteriores de grande porte e radioterapia mamária ou axilar prévias<sup>57</sup> .  
Uma punção por agulha fina (PAAF) guiada por ultrassonografia pode apoiar a indicação de pesquisa do LS, a qual é também indicada em caso de doença não invasiva (CDIS) extensa em que se planeje a mastectomia<sup>37,58–60</sup> .  
Pacientes com recidiva local após cirurgia conservadora ou mastectomia, se clinicamente operáveis, podem se beneficiar de cirurgia de resgate ou salvamento. Já o tratamento da doença local em pacientes com diagnóstico de doença metastática é um foco de intensa discussão. Estudos que avaliaram os benefícios da ressecção do tumor primário em pacientes em estádio IV possuem dados conflitantes. Por isso, atualmente recomenda-se a cirurgia do tumor primário na doença avançada em casos em que há sintomas a serem paliados, como dor, sangramento e ulcerações<sup>61–63</sup> .  
**LS após quimioterapia neoadjuvante:**  
Em pacientes sem comprometimento linfonodal (cN0), as taxas de falso-negativo são semelhantes àquelas encontradas com cirurgia inicial. Algumas revisões sistemáticas com meta-análises relataram taxas gerais de falso-negativo de cerca de 10%, independentemente do uso de traçadores duplos ou do número de gânglios linfáticos removidos<sup>64–66</sup> . Estas taxas são semelhantes às encontrados no estudo NSABP B-32 e são consideradas seguras.  
Três importantes estudos avaliaram pacientes com linfonodos axilares inicialmente positivos  N1/N2 e LS negativo após o tratamento. As taxas gerais de falso-negativo relatadas por esses estudos foram 14,2%, 12,6% e 13,3%, respectivamente. Portanto, embora inferiores a outras taxas relatadas anteriormente, estas ainda foram superiores a 10%, que é o parâmetro especificado como seguro<sup>67–69</sup> .  
Em pacientes com linfonodos axilares inicialmente positivos N1/N2 e LS positivo após o tratamento, ainda não é possível omitir a dissecção axilar. Assim, uma discussão em conjunto com o radio-oncologista e oncologista deve ser realizada em casos selecionados.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.2. Radioterapia** -->
A radioterapia (RT) é parte do tratamento locorregional dos tumores de mama. As indicações de radioterapia variam conforme os diferentes cenários possíveis.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.2.1.  Radioterapia após cirurgia conservadora da mama e estadiamento axilar** -->
As artérias mamárias internas, artéria mamária externa ou a artéria torácica lateral são responsáveis pela maior parte da provisão de sangue para as mamas, apoiadas pela irrigação proveniente de outras artérias e pequenos vasos. Grande parte dos tumores malignos é identificada na localização ductal terminal dos lobos mamários. As axilas são as preferências da drenagem linfática local, seguidas por outras cadeias, a exemplo da cadeia mamária interna e fossa supraclavicular (FSC)<sup>70</sup> .  
A RT adjuvante é indicada com a finalidade de obtenção do controle locorreginal, reduzindo o risco de recidiva local após o tratamento cirúrgico. Deve ser realizada nas pacientes com cT1-4, cN0 ou cN+.  
Vários esquemas de dose e fracionamento de RT são utilizados, reforçando o papel da RT no tratamento do câncer de mama localmente avançado e em outros estádios da doença.  Doses totais de 45 Gy a 50 Gy ou fracionamento padrão (1,8–2,0 Gy/fração) tem sido empregados em grandes centros mundiais e em ensaios randomizados seminais<sup>70,71</sup> .  
Salienta-se que o procedimento de radioterapia de mama disponível no SUS não faz menção a nenhuma técnica ou dose, podendo ser utilizado nas diferentes modalidades mencionadas. Adicionalmente, destaca-se que, caso disponível localmente, a técnica de radioterapia hipofracionada deve ser usada como esquema preferencial, pois foi demonstrado ser segura e efetiva quando comparado ao fracionamento convencional. O hipofracionamento permite propor aos pacientes tratamentos mais curtos, porque inclui esquemas com menor número de frações, maior dose por fração e menor dose total, consistindo em 15 ou 16 frações de aproximadamente 2,7 Gy/dia até doses totais de 40,0 Gy ou 42,5 Gy<sup>72–74</sup> . Esquemas de dose e fracionamento  
convencionais, com 50 Gy em 25 sessões podem ser usados em pacientes selecionadas. Ultra-hipofracionamento, em 5 sessões, pode ser considerado em pacientes selecionadas com T1/T2/N0<sup>75</sup> . Ao adotar esquemas de hipofracionamento, é recomendado o uso de radioterapia conformal 3D, uma técnica que requer o uso de tomografia computadorizada para o planejamento da radioterapia e para minimizar heterogeneidade de dose e exposição aos órgãos adjacentes como o coração e o pulmão<sup>76</sup> .  
Ressalta-se que deve considerar não realizar radioterapia da mama apenas em situações especiais, como pacientes com mais de 70 anos de idade com receptores hormonais positivos, tumores cN0, pT1 que recebam hormonioterapia adjuvante, desde que seja discutido com a própria paciente e em reunião multidisciplinar quanto ao risco aumentado de recidiva local em 10 ou mais anos, levando em consideração a expectativa de vida, sem impacto na sobrevida global<sup>43,77,78</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.2.2.  Radioterapia após mastectomia e estadiamento axilar com ou sem reconstrução** -->
A realização de radioterapia após mastectomia e estadiamento axilar, com ou sem reconstrução deve considerar as seguintes situações, conforme características apresentadas:  
- Linfonodos axilares negativos e tumor ≤ 5 cm e margens ≥ 1 mm, sem necessidade de radioterapia: pode-se considerar radioterapia em subgrupo de pacientes de alto risco, incluindo tumores centrais/mediais, T3 ou maiores ou iguais a 2 cm com menos de 10 linfonodos removidos e pelo menos um dos seguintes: grau 3, RE negativo ou invasão linfovascular;  
- Linfonodos axilares negativos, tumor ≤ 5 cm, mas margem < 1 mm: considerar radioterapia sobre a parede torácica.  
- Linfonodos axilares negativos e tumor maior que 5 cm: considerar radioterapia sobre a parede torácica;  
- Um a 3 linfonodos axilares positivos: considerar radioterapia sobre a parede torácica e drenagem linfática;  
- Quatro ou mais linfonodos axilares positivos: radioterapia sobre a parede torácica e drenagem linfática;  
- Margem comprometida: preferência por reabordagem para obter margens negativas. Caso não seja possível, considerar  
- radioterapia sobre a parede torácica com ou sem drenagem linfática.  
Sugere-se que a quimioterapia adjuvante seja realizada antes da radioterapia, uma vez que pacientes que recebem radioterapia antes da quimioterapia apresentam maior incidência de sepse e neutropenia. Idealmente, o intervalo entre a radioterapia e a cirurgia não deve ultrapassar sete meses.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **8.2.3.  Radioterapia na doença metastática** -->
A radioterapia também pode ser utilizada como método de tratamento para doença metastática em pacientes com câncer de mama (ex. sangramento tumoral, dor, metástase óssea, metástase cerebral, síndrome de compressão medular neoplásica)<sup>79,80</sup> . No subgrupo de pacientes classificadas como oligometastáticas (número limitado de metástases), a radioterapia poderá ser empregada em caráter ablativo, ou seja, utilizada em altas doses, em local focado. Pode ser realizada por meio de técnicas, como a radiocirurgia e a radioterapia estereotáxica fracionada, com baixa morbidade e excelente controle tumoral a longo prazo<sup>18</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.        TRATAMENTO MEDICAMENTOSO** -->
Os tratamentos preconizados neste Protocolo são baseados na literatura científica atual, levando em conta as tecnologias com indicação relacionada ao câncer de mama aprovadas pela Agência Nacional de Vigilância Sanitária (Anvisa) e recomendadados pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec) –  com a exceção de casos excepcionais, para os quais se admitiu o uso _off-label_ , tido como consagrado na prática clínica – e que demonstram impacto na história natural da doença, com o objetivo principal de reduzir a mortalidade pelo câncer de mama.  
Este PCDT abordará os esquemas terapêuticos atualmente disponíveis no Sistema Único de Saúde (SUS). <u>Alguns medicamentos citados no texto não possuem recomendação favorável de incorporação e, portanto, não estão disponíveis como alternativas terapêuticas no SUS. Os esquemas terapêuticos já incorporados ao SUS estão destacados nos quadros de acordo com</u>  
<u>as linhas de tratamento. As novas tecnologias em fase de avaliação ou que serão demandadas para análise pela Conitec serão</u> incluídas nas versões subsequentes para garantir a sua atualização constante.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.1.     Quimioterapia** -->
A quimioterapia é um dos recursos disponíveis na terapêutica do câncer de mama. Ela consiste na aplicação de fármacos antineoplásicos que podem ser administrados por diversas vias (venosa, oral, subcutânea), de forma isolada ou combinada, com os objetivos de impedir ou reduzir o risco da disseminação de células tumorais, reduzir o tamanho do tumor ou impedir seu crescimento.  
Esta terapia não é isenta de efeitos colaterais, devendo estes serem conhecidos pelos médicos prescritores, que deverão saber manejar seus efeitos, avaliando a tolerância de cada paciente.  
A finalidade de emprego nesta neoplasia pode ser neodjuvante, adjuvante ou paliativa.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.2.     Hormonioterapia** -->
A hormonioterapia, também chamada de tratamento hormonal ou terapia endócrina, é um recurso importante quando o tumor expressar positividade na imunohistoquímica, para os receptores hormonais: RE e RP.  
As formas mais comuns de ação consistem no bloqueio da ligação dos hormônios aos receptores, nas células tumorais ou à diminuição da produção destes, pelo organismo. Devem ser considerados fatores, como status menopausal e contraindicações previstas em bula, para a melhor escolha, dentre os esquemas possíveis<sup>81</sup> .  
O estado menopausal é um importante critério para definição da hormonioterapia, sendo a menopausa comumente definida como interrupção permanente da menstruação. Contudo, durante o tratamento do câncer de mama, pode haver uma diminuição profunda e permanente na síntese de estrogênio ovariano, a qual pode ser confundida com menopausa. Assim, para determinar se a paciente está em menopausa, deve-se considerar qualquer um dos critérios definidos pelo _National Comprehensive Cancer Network_ (NCCN)<sup>82</sup> :  
- Ooforectomia bilateral prévia ou ablação OU;  
- Idade maior ou igual a 60 anos OU;  
- Idade menor que 60 anos e amenorreia durante 12 ou mais meses na ausência de quimioterapia, tamoxifeno ou supressão  
- ovariana e hormônio folículo estimulante (FSH) e estradiol na pós-menopausa OU;  
- Para pacientes em uso de tamoxifeno e idade menor 60 anos, nível de estradiol plasmático e de FSH compatíveis com  
- a pós-menopausa.  
Em mulheres pré-menopausa, pode-se optar pela ablação ovariana concomitante à hormonioterapia. Esta ablação pode ser cirúrgica ou com uso de radioterapia, de forma definitiva, ou química, de forma temporária, com o uso de análogos de liberação do hormônio Luteinizante (LHRH). A supressão ovariana é indicada para pacientes com maior risco clínico, como aquelas que receberam quimioterapia adjuvante e as pacientes mais jovens (<35 anos)<sup>83</sup> .  
A resistência endócrina pode ser primária, quando há recorrência do tumor nos dois primeiros anos de tratamento adjuvante ou progressão de doença durante os seis primeiros meses de hormonioterapia de primeira linha no câncer de mama metastático; ou secundária, quando ocorre após os dois primeiros anos de hormonioterapia adjuvante e durante ou no primeiro ano após completar a terapia adjuvante ou, no caso de câncer de mama metastático, ocorra progressão de doença após os seis primeiros meses de hormonioterapia de primeira linha<sup>84</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.3.     Critérios para optar pela neoadjuvância** -->
Para pacientes com doença inicialmente inoperável por cirurgia conservadora, o uso de quimioterapia neoadjuvante é preconizado com o objetivo de converter o quadro para tumor operável. Nestes casos, a quimioterapia neoadjuvante é capaz de  
fornecer um melhor desfecho estético e possivelmente funcional, sem prejuízo em termos de recidiva à distância ou de sobrevida global<sup>85</sup> .  
Sobre a **quimioterapia** neoadjuvante, esta é uma opção conforme a possibilidade de operar o tumor. Deve ser realizada  
por 6 meses para, então, avaliar a indicação da cirurgia. Para pacientes com progressão da doença durante o tratamento neoadjuvante, a cirurgia deve ser indicada.  
**Se tumor operável** , a cirurgia conservadora deve ser a primeira opção de tratamento em tumores operáveis menores que  
- 2 cm, especialmente se RH+. Contudo, a quimioterapia neoadjuvante pode ser discutida nos seguintes casos:  
- Pacientes com tumores T1c HER-2, RH-, mulheres jovens;  
- Tumor primário grande em relação ao tamanho da mama em paciente que deseja conservação da mama;  
- Doença com linfonodo positivo;  
- Quando é necessário tempo para decidir sobre a cirurgia;  
- Tumores operáveis com características biológicas que favoreçam a indicação de quimioterapia (ex: triplo negativo,  
- HER-2 positivo, luminal B).

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Se tumor inoperável** -->
- Tumor inflamatório;  
- Nódulos axilares N2 volumosos ou fundidos;  
- Doença nodal N3, independente do status de RH;  
- Tumores T4.  
A hormonioterapia neoadjuvante é indicada como alternativa à quimioterapia neoadjuvante para pacientes pósmenopausadas com tumores RH positivos sem condição clínica ou com contraindicações para realização de quimioterapia e cujos tumores apresentam alta expressão de receptores hormonais e baixo índice proliferativo<sup>86,87</sup> . Em regra, também deverá ser realizada por 6 meses<sup>88–90</sup> . Caso após 6 meses, o paciente seja considerado inoperável por condições clínicas (idade, performance status, comorbidades, morbidade cirúrgica), a prescrição de hormonoterapia pode ser realizada como doença avançada.  
Em pacientes pré-menopáusicas, a eficácia da hormonioterapia neoadjuvante parece ser inferior à da quimioterapia<sup>91</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.4. Critérios para optar pela adjuvância** -->
O tratamento sistêmico adjuvante é responsável por grande parte da redução da mortalidade por câncer de mama de quase todos os países ocidentais. O benefício da quimioterapia adjuvante é observado não apenas em sobrevida livre de doença, mas também em sobrevida global mesmo após 15 anos de acompanhamento<sup>92</sup> .  
Aspectos específicos relacionados à decisão ou não pela realização da adjuvância, bem como o esquema mais adequado possível, devem considerar o risco baseado no estadiamento, os biomarcadores preditivos (HER-2, RE, RP), a performance do paciente e comorbidades associadas.  
A terapia sistêmica adjuvante está indicada para as pacientes com câncer de mama em estádio inicial e para aquelas com doença localmente avançada submetidas à cirurgia conservadora com ou sem radioterapia.  
A hormonioterapia associada à radioterapia pode ser indicada para pacientes com tumores de baixo risco de recidiva que expressem receptores hormonais, de acordo com o estado menopausal<sup>84</sup> . Além da radioterapia e hormonioterapia, a quimioterapia (adjuvante ou neoadjuvante) pode ser indicada para pacientes com risco de recidiva intermediário ou alto, desde que não haja contraindicação clínica ( **Quadro 6** ).  
A **hormonioterapia** adjuvante é uma opção para pacientes com RH positivo, independente da expressão de HER-2, devendo a escolha do esquema considerar o estado menopausal, as co-morbidades e tolerância da paciente.  
A decisão terapêutica para o tratamento do câncer de mama deve ser baseada em informações integradas pelo oncologista, como idade das pacientes, tamanho do tumor primário, presença e quantidade de linfonodos patológicos, expressão de receptores  
hormonais e HER-2 e índice proliferativo. Estas informações são potenciais fatores prognósticos de recidiva ou mortalidade e  
devem ser, preferencialmente, adicionadas nas calculadoras de risco, para auxílio no direcionamento do tratamento.  
Informações adicionais estão descritas no item Classificação de risco de recidiva.  
A escolha do tratamento sistêmico é apoiada pelos seguintes critérios:  
- Tamanho do tumor primário;  
- Grau do tumor primário;  
- Situação dos linfonodos axilares;  
- Status dos RH;  
- Perfil IHQ (expressão do receptor HER-2);  
- Estado menopausal;  
- Idade;  
- Preferência da paciente.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5. Doença inicial ou localmente avançada (estádios I a III)** -->
Tumores localmente avançados são os que apresentam fixação à parede torácica, envolvimento cutâneo, linfonodos fusionados e/ou envolvimento de fossa supraclavicular episilateral. O tratamento sistêmico das pacientes com tumores iniciais ou localmente avançados compreende o tratamento neoadjuvante, realizado antes da cirurgia do tumor primário e/ou tratamento adjuvante, iniciado após a cirurgia do tumor primário.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.1.1 Tratamento sistêmico neoadjuvante e adjuvante** -->
Os esquemas de quimioterapia neoadjuvante e adjuvante estão descritos no Quadro 7.  
**Quadro 7.** Esquemas terapêuticos para quimioterapia (adjuvante e neoadjuvante) em pacientes com câncer de mama inicial ou localmente avançado hormôniopositivo.  
**Possíveis esquemas** AC (doxorrubicina + ciclofosfamida) seguido por paclitaxel AC-T (doxorrubicina + ciclofosfamida) seguido de docetaxel ou paclitaxel AC em dose densa (doxorrubicina + ciclofosfamida), com ou sem fatores estimuladores de colônias de macrófagos/granulócitos, seguido por paclitaxel (semanal ou a cada 2 semanas) (podendo-se alterar a sequência) FAC (ciclofosfamida + doxorrubicina +5-fluorouracil)<sup>a,b</sup> FEC (ciclofosfamida + epirrubicina + 5-fluorouracil)<sup>a,b</sup> TAC (docetaxel + doxorrubicina + ciclofosfamida)<sup>b</sup> CMF (ciclofosfamida + metotrexato + 5-fluorouracil)<sup>b</sup> TC (docetaxel + ciclofosfamida)<sup>c</sup>  
Legenda: Os esquemas estão descritos no Apêndice 2. a Há evidências de que não apresentam benefício adicional na adjuvância. b Podem ser úteis em casos expecionais. c Utilizado em casos de linfonodos negativos ou com contraindicação à antraciclina. Obs.: Fatores estimuladores de colônia devem ser empregados como profilaxia primária em pacientes que estejam utilizam o esquema AC-T com dose-densa Fonte: Elaboração própria.  
Uma revisão sistemática concluiu que 6 ciclos de ciclofosfamida associada a metotrexato e 5-fluorouracil (CMF) é equivalente a 4 ciclos de doxorrubicina associada à ciclofosfamida (AC). Ambos os esquemas reduziram 20% a 25% da mortalidade das pacientes e reduziram em 30% a recidiva da doença, em oito anos<sup>93</sup> . No geral, esquemas quimioterápicos com dose significativamente mais baixa por ciclo de antraciclinas foram menos efetivos, comparados a doses mais intensas<sup>93</sup> .  
Outra revisão sistemática, que utilizou dados individuais de pacientes, concluiu que aumentar a dose-densidade da quimioterapia adjuvante comparado ao esquema padrão e reduzir o intervalo de tempo entre os ciclos de tratamento; ou administrar medicamentos individuais em sequência, em vez de administrar os mesmos medicamentos simultaneamente reduz moderadamente o risco de recidiva e morte por câncer de mama em 10 anos, sem aumentar a mortalidade por outras causas<sup>94</sup> . Sendo assim, esquemas de quimioterapia além de 4 ciclos de AC, como por exemplo, ciclofosfamida associada à doxorrubicina e 5-fluorouracil (FAC) por 6 ciclos; ou ciclofosfamida associada à epirrubicina e 5-fluorouracil (FEC) por 6 ciclos; ou 4 ciclos de AC associada à taxano resultam em maior benefício com redução adicional de 15% a 20% na mortalidade<sup>94</sup> .  
A associação de taxano de forma sequencial à antraciclina mais ciclofosfamida se mostrou mais eficaz quando comparado com o esquema ACx04, sem aumentar o risco de mortalidade por leucemia ou insuficiência cardíaca, como os esquemas que avaliaram doses maiores de antraciclinas. Diferentes esquemas terapêuticos com taxanos foram avaliados, tendo se mostrado ganho em sobrevida livre de doença e sobrevida global com os esquemas que utilizaram paclitaxel semanal, por 12 semanas, paclitaxel a cada 14 dias, por 4 ciclos, ou docetaxel a cada 3 semanas, por 4 ciclos<sup>95–97</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.1.2 Hormonioterapia neoadjuvante** -->
Os esquemas de hormonioterapia neoadjuvante em pacientes com câncer de mama inicial ou localmente avançado hormônio-positivo estão descritos no Quadro 8.  
**Quadro 8.** Esquemas terapêuticos para hormonioterapia neoadjuvante em pacientes com câncer de mama inicial ou localmente avançado hormônio-positivo.  
|**Esquema**|
|---|
|Inibidor de aromatase por 6 meses|  
Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.1.3 Hormonioterapia adjuvante** -->
A hormonioterapia adjuvante deve ser indicada para pacientes RH+ com qualquer grau de positividade no resultado do exame de IHQ, independentemente da expressão de HER-2, considerando o estado menopausal. Quanto maior o escore de positividade na IHQ, maior é o benefício da hormonioterapia. A escolha do esquema também deve considerar as possíveis comorbidades associadas e o perfil de tolerância da paciente. Ressalta-se que é necessário finalizar o curso de da quimioterapia adjuvante antes de iniciar a hormonioterapia adjuvante. A realização de hormonioterapia concomitantemente à radioterapia pode resultar em uma maior toxicidade, ampliando os eventos adversos associados a ambos os tratamentos.  
Em mulheres que estejam na pré-menopausa no início da quimioterapia adjuvante, a amenorreia não é um indicador confiável do estado menopausal, pois a função ovariana pode ainda estar intacta ou ser retomada apesar da anovulação/amenorreia após a quimioterapia. Portanto, para mulheres com amenorreia induzida por terapia, a ooforectomia ou a dosagem em série de FSH e estradiol são necessárias para definir o estado de pós-menopausa.  
O tratamento recomendado para pacientes na perimenopausa, geralmente, é extrapolado de estudos em mulheres em pré ou pós-menopausa. Uma coorte envolvendo 2.295 mulheres, com idade entre 45 e 50 anos e diagnóstico de câncer de mama RE+, avaliou pacientes que receberam quimioterapia adjuvante seguida de tratamento endócrino. O tratamento endócrino consistiu em tamoxifeno, inibidor de aromatase (IA) ou a associação dos dois medicamentos, sendo que a maioria das pacientes alternou entre as modalidades de tratamento endócrino. Os resultados foram sumarizados de acordo com o tempo do tratamento  
endócrino. No final do acompanhamento de cinco anos, as mulheres que receberam um IA por tempo inferior a 25% da duração do tratamento endócrino experimentaram 29,6% de recidiva da doença em comparação com 10,8% e 12,8% em mulheres tratadas com IA por tempo entre 25% e 75% e IA maior que 75% do tempo de tratamento endócrino, respectivamente<sup>98</sup> .  
A recomendação de IA na perimenopausa precisa ser cautelosa, pois essas mulheres podem estar com amenorreia induzida por quimioterapia. Tanto nos casos de ausência de reserva ovariana quanto de amenorreia induzida por quimioterapia, a menstruação cessará e os níveis de gonadotrofina (hormônio folículo-estimulante, hormônio luteinizante e estradiol) estarão na faixa pós-menopausa. A preocupação é que nos meses a anos após a quimioterapia, a função ovariana possa se recuperar em pacientes com amenorreia induzida por quimioterapia, tornando a terapia de IA ineficaz. Por este motivo, o monitoramento destas pacientes é de extrema importância<sup>99</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Mulheres na pré-menopausa** -->
As opções de tratamento hormonal adjuvante são o tamoxifeno (TMX) na dose de 20 mg por dia, indicado nos casos de mulheres na pré ou pós-menopausa, ou os IA, utilizados apenas em pacientes submetidas à supressão ovariana temporária ou definitiva. Os IA incluem o anastrazol, o letrozol e o exemestano.  
Em pacientes pré-menopáusicas, a supressão da função ovariana concomitante ao uso de tamoxifeno ou IA está associada a um ganho de sobrevida livre de doença. Porém, é necessário avaliar o risco e benefício dessa associação, uma vez que os eventos adversos relacionados com o tratamento aumentam, especialmente se a supressão ovariana for associada ao exemestano<sup>83,100–102</sup> . A supressão ovariana está indicada especificamente para pacientes com até 45 anos e com uso prévio de quimioterapia.  
Caso a paciente entre na menopausa (confirmada por níveis hormonais) durante o tratamento com tamoxifeno, por 2 a 3 anos, este pode ser substituído por IA por mais 2 a 3 anos (até completar 5 anos). No entanto, pacientes sem estado pósmenopausal estabelecido não se beneficiam do uso de IA sem supressão da função ovariana concomitante. Neste caso, o uso isolado de IA está associado ao risco de reativação da função ovariana, que pode se manifestar de forma clínica, como retorno ao ciclo menstrual, ou subclínica, com a variação do FSH e do estradiol, apresentando níveis hormonais incompatíveis com a pós-menopausa. Mesmo que não haja manifestação clínica, a variação bioquímica de reativação ovariana está associada a piores desfechos em uso de IA<sup>103</sup> . Portanto, em pacientes que realizam esta troca, é recomendável que a função ovariana seja monitorada para detectar possíveis reativações.  
O **Quadro 9** descreve alguns dos esquemas de hormonioterapia adjuvante em mulheres na prémenopausa.  
**Quadro 9.** Esquemas terapêuticos para hormonioterapia adjuvante em pacientes com câncer de mama inicial ou localmente avançado hormônio-positivo na prémenopausa.  
|**Possíveis esquemas**|
|---|
|Mulheres na pré-menopausa|
|Tamoxifeno 20 mg/dia por 5 anos|
|Tamoxifeno 20 mg/dia por 5 anos + Tamoxifeno 20 mg/dia por 2 a 3 anos|
|Tamoxifeno 20 mg/dia por 5 anos + Tamoxifeno 20 mg/dia por 5 anos|
|Tamoxifeno 20 mg/dia por 5 anos + IA por 2 a 3 anos, caso paciente entre na menopausa|
|Supressão ovariana em combinação a tamoxifeno 20 mg/dia ou IA por 2 anos<sup>a</sup>|  
Nota:<sup>a</sup> O uso de inibidores de aromatase combinada à supressão ovariana está indicado apenas para pacientes com até 45 anos e com uso prévio de quimioterapia. Legenda: IA: Inibidor de aromatase Fonte: Elaboração própria.  
**Mulheres na pós-menopausa**  
Em pacientes pós-menopáusicas, o uso de tamoxifeno ou IA são possibilidades terapêuticas ( **Quadro 10** ). A troca do tamoxifeno por um IA após dois a três anos de tratamento e seu uso até completar cinco anos, conhecida como _switch_ , demonstrou reduzir o risco de recidiva e de morte em cinco anos comparado ao uso de tamoxifeno continuamente por cinco anos<sup>104,105</sup> . Apesar disso, o tamoxifeno continua sendo eficaz, apresentando redução de risco de recidiva e de morte por câncer de mama não apenas durante cinco anos de uso, como também nos cinco anos posteriores à sua utilização.  
Pacientes com maior risco de recidiva seguem sendo candidatas à hormonioterapia adjuvante estendida, a ser discutida e avaliada individualmente.  
**Quadro 10.** Esquemas terapêuticos para hormonioterapia adjuvante em pacientes com câncer de mama inicial ou localmente avançado hormônio-positivo na pós-menopausa.  
|**Possíveis esquemas**|
|---|
|Mulheres na pós-menopausa|
|IA por 5 anos + IA por 2 anos;|
|IA por 2 a 3 anos seguido por tamoxifeno 20 mg/dia até completar pelo menos 5 anos de hormonioterapia (modalidade de|
|_switch)_|
|Tamoxifeno 20 mg/dia por 5 anos + IA por 5 anos<sup>a</sup>|
|Tamoxifeno 20 mg/dia por 5 anos + Tamoxifeno 20 mg/dia por 5 anos|  
Legenda: IA: Inibidor de aromatase;<sup>a</sup> Opção para pacientes com alto risco de recidiva.  
Fonte: Elaboração própria.  
A duração mínima sugerida para a adjuvância hormonal é de 5 anos, independente do tratamento escolhido (tamoxifeno, IA ou ambos) ou do estado menopausal da mulher. A escolha da terapia estendida deve ser baseada no risco e benefício de cada paciente. Há riscos devido ao aumento de eventos adversos importantes associados à terapia estendida, como também há benefícios, com a redução do percentual de recidiva.  
O câncer de mama está associado a frequentes recidivas após o período de cinco anos e o benefício da extensão da terapia hormonal parece estar associado ao risco de recidiva<sup>106,107</sup> . Pacientes com linfonodos positivos apresentam benefício maior em estudos com adjuvância estendida e maior risco de recidiva após cinco anos. Assim, sugere-se a extensão de tratamento para estas pacientes<sup>107,108</sup> .  
Até o momento, o uso de terapia estendida demonstrou ganho de sobrevida global após cinco anos de uso de tamoxifeno, mas não após cinco anos de uso de IA<sup>106</sup> . Especialmente após o uso de IA, o tamanho do benefício do tratamento após 7 a 8 anos parece ser modesto. Também, os eventos adversos do uso de adjuvância hormonal estendida não são negligenciáveis e devem ser considerados na decisão terapêutica<sup>109</sup> .  
Em candidatas à extensão da adjuvância hormonal que utilizaram tamoxifeno por cinco anos, tanto a continuação de tamoxifeno (por mais cinco anos) quanto a troca por um IA (também por mais 5 anos) são opções terapêuticas razoáveis com demonstração de diminuição de risco de morte. Esta escolha deve ser baseada em eventos adversos e preferência individual<sup>104,110,111</sup> .  
Para candidatas à extensão da adjuvância hormonal que utilizaram IA durante cinco anos, alguns estudos sugerem que haja benefício de sobrevida livre de doença, mas não benefício de sobrevida global, com o uso de tratamento estendido<sup>103,109,112</sup> . Consistentemente, a extensão do tratamento por cinco anos adicionais também está associada a eventos adversos importantes, especialmente ósseos<sup>113</sup> . O uso de IA por dois anos adicionais demonstrou uma sobrevida livre de doença similar, mas com menos eventos adversos ósseos, em comparação à extensão da adjuvância por cinco anos<sup>114</sup> . Portanto, dois anos é o tempo de extensão sugerido após uso de cinco anos de IA<sup>115</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.2.  Câncer de mama HER-2 positivo** -->
O oncogene HER-2 é responsável pela codificação de uma glicoproteína transmembrana com atividade de tirosinoquinase intracelular. Essa codificação é fundamental para a ativação de vias de sinalização associadas à proliferação e diferenciação celular<sup>116,117</sup> . Cerca de 20% das pacientes com câncer de mama invasivo apresentam superexpressão ou amplificação do HER-2. Nestes casos, o trastuzumabe, um anticorpo monoclonal humanizado anti-HER-2, demonstra benefício clínico como adjuvante ou paliativo<sup>113,114,116,118–122</sup> .  
**Caso as pacientes expressem HER-2 e sejam RH+, elas também são candidatas à hormonioterapia (neoadjuvante e adjuvante), descritas no item anterior.**

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.2.1 Tratamento sistêmico neoadjuvante** -->
A quimioterapia neoadjuvante é preferida em relação à adjuvante para pacientes que expressam o receptor HER-2 e, ao ser associada ao trastuzumabe, mostra ainda mais ganhos de sobrevida livre de eventos e de sobrevida global<sup>113</sup> . Em uma análise combinada de dois ensaios clínicos randomizados, foram demonstrados ganho em resposta patológica completa e redução de risco de recidiva do trastuzumabe na quimioterapia neoadjuvante<sup>123</sup> .  
Para pacientes com tumor HER-2 positivo inoperável, é recomendada a neoadjuvância com quimioterapia associada à trastuzumabe, seguida de cirurgia com ou sem radioterapia e trastuzumabe a cada três semanas até completar um ano. Para estas pacientes os esquemas adjuvantes são iguais aos neoadjuvantes. Verifica-se que pode existir benefício da associação de pertuzumabe (neo) adjuvante, ainda não incorporada ao SUS, na diminuição ainda maior do risco de recorrência e/ou morte, devendo a mesma passar pelos ritos de incorporação legalmente vigente. O Quadro 11 elenca os possíveis esquemas de neoadjuvância para estas pacientes.  
A combinação de quimioterapia citotóxica com trastuzumabe após uso de antracíclicos também é eficaz e segura em pacientes com tumores maiores ou iguais a 2 cm ou carcinoma inflamatório e que tenham a superexpressão de HER-2 confirmada<sup>121</sup> . Considera-se aceitável a adaptação de esquemas de quimioterapia para este subgrupo de pacientes para evitar concomitância de trastuzumabe e antraciclina, o uso sequencial de antraciclina e taxano e a concomitância de trastuzumabe e taxano<sup>123</sup> .  
Após o tratamento neoadjuvante, pacientes cN1 que converteram para ycN0 devem ser submetidas à biópsia de linfonodo sentinela. Na presença de linfonodos positivos (ypN1sn), a linfadenectomia axilar radical (mínimo níveis I e II) está indicada.  
**Quadro 11.** Esquemas terapêuticos para quimioterapia neoadjuvante em pacientes com câncer de mama inicial ou localmente avançado HER-2 positivo.  
|**Possíveis esquemas**|
|---|
|AC-TH (doxorrubicina + ciclofosfamida) seguida por paclitaxel + trastuzumabe|
|TH (paclitaxel + trastuzumabe)|
|TCH (docetaxel + carboplatina +trastuzumabe)|
|Fonte: Elaboração própria.|
|Nota 1: Os esquemas estão descritos no Apêndice 2.|
|Nota 2: Ainda que possa existir benefício do uso de pertuzumabe no contexto adjuvante ou neoadjuvante para pacientes com lesão primária ≥ 2 cm ou linfonodo|
|positivo, informa-se que este ainda não está incorporado ao SUS, devendo passar pelos ritos de incorporação legalmente vigentes.|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.2.2 Tratamento sistêmico adjuvante** -->
O tratamento padrão utilizado de maneira adjuvante constitui-se de quimioterapia baseada ou não em antraciclinas seguida de hormonioterapia adjuvante, quando o tumor também for RH positivo.  
Os esquemas de quimioterapia tradicionalmente utilizados para o tratamento adjuvante associado ao trastuzumabe estão centrados no uso de antraciclina seguida de taxanos (AC-TH). Os principais resultados com a associação de trastuzumabe à  
quimioterapia baseada em antraciclina demonstram ganhos de sobrevida livre de doença e sobrevida global<sup>119</sup> . Outro tratamento também eficaz é a associação de trastuzumabe com docetaxel e carboplatina por 6 ciclos, sem a necessidade de uso de antraciclinas (TCH). Ambos os esquemas apresentados (AC-TH e TCH) são eficazes para sobrevida livre de progressão e sobrevida global, após 10 anos de seguimento, mas o esquema AC-TH apresenta maior toxicidade para estas pacientes<sup>114</sup> . Pacientes com câncer de mama localizado HER-2 positivo devem realizar cirurgia conservadora seguida de adjuvância com paclitaxel semanal, durante 12 semanas, e trastuzumabe, a cada três semanas, durante um ano. Esse tratamento é preconizado por apresentar grandes benefícios de sobrevida livre de doença invasiva (93%) e sobrevida global (95%) em três anos de acompanhamento<sup>124</sup> .  
Em pacientes que não apresentam resposta patológica completa, o uso de trastuzumabe-entansina (T-DM1) demonstrou melhor sobrevida livre de doença invasiva e menor risco de recidiva à distância<sup>125</sup> . Na 110ª reunião da Conitec, o Plenário recomendou a incorporação do trastuzumabe entansina para tratamento do câncer de mama HER-2 positivo em pacientes em estádio III com doença residual póstratamento neoadjuvante<sup>126</sup> . A paciente não pode apresentar doença cardíaca sintomática, sendo necessário que a fração de ejeção cardíaca demonstrada no mês anterior ao início da quimioterapia com o medicamento seja igual ou superior a 55% e que eventuais comorbidades da paciente sejam compatíveis com expectativa de vida para além de 5 anos. Quando a paciente apresentar uma dessas condições, uma alternativa é manter o uso de trastuzumabe de forma adjuvante, até completar um ano de tratamento. O **Quadro 12** apresenta os esquemas terapêuticos sugeridos em concomitância com o trastuzumabe.  
**Quadro 12.** Esquemas terapêuticos para quimioterapia adjuvante em pacientes com câncer de mama inicial ou localmente avançado HER-2 positivo.  
|**Possíveis esquemas**|
|---|
|AC-TH (doxorrubicina + ciclofosfamida) seguida por paclitaxel + trastuzumabe<br>TCH (docetaxel + carboplatina +trastuzumabe)|
|Trastuzumabe entansina (apenas estádio III)<br>TH (paclitaxel + trastuzumabe)|
|Trastuzumabe|
|Fonte: Elaboração própria.|
|Nota 1: Os esquemas estão descritos no Apêndice 2.|
|Nota 2: Ainda que possa existir benefício do uso de pertuzumabe no contexto adjuvante ou neoadjuvante para pacientes com lesão primária ≥ 2 cm ou linfonodo<br>positivo, informa-se que este ainda não está incorporado ao SUS, devendo passar pelos ritos de incorporação legalmente vigentes|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.2.3 Casos especiais** -->
Decisões de tratamento em pacientes idosas devem ser tomadas baseadas em funcionalidade e não apenas em idade cronológica, uma vez que os riscos nessa população diluem os benefícios de sobrevida global<sup>78</sup> . No caso de pacientes obesas, deve-se seguir as doses preconizadas com área de superfície corporal real. Estudos com antracíclicos mostram que não há maior incidência de neutropenia febril ou maior mortalidade<sup>127</sup> .  
Outra situação a ser considerada em câncer de mama é seu desenvolvimento durante a gestação. O tratamento deve ser realizado aos moldes do preconizado para pacientes não gestantes, mas necessita algumas modificações para proteção do feto. A cirurgia na gestante também é considerada como tratamento principal, mas há controvérsias em relação à abrangência do procedimento na axila<sup>128–131</sup> .  
A quimioterapia não deve ser realizada no primeiro trimestre devido ao maior risco de anomalias congênitas e cromossômicas, natimortalidade e de malformação fetal. Quando há indicação de quimioterapia, sua dose deve seguir a superfície corporal ao longo do tratamento e sua realização deve ocorrer nos segundo e terceiro trimestres. Os esquemas quimioterápicos  
com maiores fontes de dados de segurança são aqueles que contêm antraciclina. Atenção especial é necessária para evitar o período do nadir próximo ao fim da gestação para minimizar o risco de complicações puerperais e neonatais<sup>128–131</sup> .  
O uso de trastuzumabe durante a gravidez é contraindicado, pois a exposição ao medicamento pode provocar oligoidrâmnio, que em alguns casos pode levar a hipoplasia pulmonar, anormalidades do esqueleto e morte neonatal. O metotrexato deve ser evitado em todas as fases da gestação devido ao seu efeito abortivo e potencial teratogênico.  
Como regra geral, mulheres que estiverem recebendo hormonioterapia ou quimioterapia, com ou sem trastuzumabe, devem evitar a amamentação. Mulheres em idade fértil devem ser orientadas sobre contracepção, caso estejam em tratamento com esses medicamentos<sup>132,133</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.3.1 Tratamento neoadjuvante** -->
A maioria das pacientes com câncer de mama triplo-negativo deve receber tratamento de quimioterapia neoadjuvante, ou seja, aquelas com tumores maiores que 1 cm ou axila positiva. A quimioterapia neoadjuvante permite a determinação _in vivo_ da sensibilidade tumoral ao tratamento quimioterápico. A resposta patológica completa é um importante marcador de bom prognóstico em pacientes cujos tumores são triplo-negativos. Portanto, quando há indicação de tratamento sistêmico, sugere-se que este seja realizado de forma neoadjuvante, especialmente, para estádio II ou III. Para pacientes com tumores em estádio I e tumores maiores do que 1 cm, o uso de quimioterapia neoadjuvante é também favorecido.  
Os esquemas quimioterápicos podem ser baseados em antraciclinas, como AC-T, considerando que o benefício do uso de antraciclinas é proporcional ao risco de recidiva e à agressividade do câncer de mama triplo-negativo<sup>134</sup> . Outra alternativa é o esquema AC a cada 21 dias (por quatro ciclos), seguido de paclitaxel semanal por 12 semanas ou docetaxel a cada 21 dias (por quatro ciclos), realizando cirurgia com ou sem radioterapia na sequência. A utilização de esquema AC dose densa a cada 14 dias, seguido de fator de crescimento de colônias de granulócitos, deve ser considerada pois demonstrou superioridade em relação aos esquemas convencionais, com redução de risco de recidiva, mortalidade câncer-específica e sobrevida global em 10 anos.  
Durante a neoadjuvância, o uso de carboplatina associada ao taxano demonstrou aumento da taxa de resposta, mas ainda há incertezas sobre o benefício desta intervenção em sobrevida livre de doença e sobrevida global<sup>135,136</sup> . A carboplatina pode ser utilizada tanto na posologia a cada três semanas quanto semanal e seu uso parece ser justificado em pacientes com tumores em estádio II e III, com ou sem mutação BRCA<sup>137,138</sup> .  
Embora haja evidências sobre potencial benefício do pembrolizumabe sobre o aumento da resposta patológica nesta população<sup>139,140</sup> , informa-se que este medicamento ainda não se encontra incorporado ao SUS para esta indicação, devendo o mesmo passar pelos ritos de incorporação legalmente vigentes.  
O **Quadro 13** descreve os esquemas possíveis.  
**Quadro 13.** Esquemas terapêuticos para quimioterapia (neoadjuvante e adjuvante) em pacientes com câncer de mama inicial ou localmente avançado triplonegativo.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Possíveis esquemas** -->
AC (doxorrubicina + ciclofosfamida) AC-T (doxorrubicina + ciclofosfamida) seguido de docetaxel ou paclitaxel AC em dose densa (doxorrubicina + ciclofosfamida), com ou sem fatores estimuladores de colônias de macrófagos/granulócito seguido por paclitaxel (semanal ou a cada 2 semanas) (podendo-se alterar a sequência) CMF (ciclofosfamida + metotrexato + 5-fluorouracil) TC (docetaxel + ciclofosfamida) Capecitabina (doença residual)  
T seguido de AC (paclitaxel seguido de doxorrubicina + ciclofosfamida  
CMF (ciclofosfamida associada ao metotrexato + 5-fluorouracil) (pacientes idosas) PCb (paclitaxel associado à carboplatina) Docetaxel + carboplatina  
Nota: Os esquemas estão descritos no Apêndice 2.  
Esquemas com carboplatina devem ser preferenciais para pacientes com axila positiva. Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.3.2 Cirurgia após tratamento sistêmico neoadjuvante** -->
Após o tratamento neoadjuvante de pacientes com câncer de mama triplo negativo, a cirurgia está indicada<sup>141</sup> . A pesquisa de LS realizada no momento da cirurgia definitiva (após a quimioterapia neoadjuvante) resultou em taxas mais baixas de identificação e maior taxa de falso negativo, em comparação com o mesmo procedimento realizado antes da quimioterapia<sup>142</sup> .  
Pacientes cN1 ou cN2, que converteram para ycN0 após quimioterapia neoadjuvante, devem ser submetidas à BLS<sup>67,143</sup> . Na presença de linfonodos positivos (ypN1sn), a linfadenectomia axilar radical (mínimos níveis I e II) está indicada. Porém, há controvérsias na literatura sobre a possibilidade de omitir a linfadenectomia radical em pacientes com linfonodo sentinela positivo pós neoadjuvância. Somente as pacientes sem resposta devem ser submetidas ao esvaziamento axilar.  
Em pacientes com linfonodos axilares classificados como cN1, resposta clínica completa e evidência patológica de doença, o esvaziamento axilar ainda é o tratamento padrão. Apesar disso, a irradiação axilar é uma alternativa, considerando os riscos de uma nova abordagem cirúrgica. Para pacientes candidatas a não realização de esvaziamento axilar, sugere-se que a identificação de ao menos três linfonodos sentinelas, sem presença de doença, seja suficiente para prescindir de tratamento cirúrgico adicional<sup>106</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.3.3 Tratamento adjuvante de pacientes com câncer de mama triplo negativo operadas inicialmente.** -->
Pacientes com tumores iniciais maiores que 1 cm ou linfonodos axilares positivos que foram operadas inicialmente devem utilizar quimioterapia adjuvante com os mesmos esquemas possíveis para a neoadjuvância ( **Quadro 13** ) e realizando radioterapia na sequência.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.5.3.4 Tratamentos adjuvante após quimioterapia neoadjuvante do câncer de mama triplo negativo** -->
A presença de neoplasia residual na peça cirúrgica, após a neoadjuvância, é um marcador desfavorável para o risco de recidiva. Nestes casos, existe evidência que demonstre que o uso de capecitabina de forma adjuvante por oito ciclos aumenta a sobrevida livre de doença e a sobrevida global. Ressalta-se que esta indicação não tem previsão na bula vigente<sup>106,144</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.     Doença metastática – Estádio IV** -->
O câncer de mama metastático é definido como a presença de doença que acomete outros sítios além da mama, da parede torácica e das cadeias regionais homolaterais de drenagem linfática. A disseminação da doença metastática pode ocorrer por meio da via linfática ou hematogênica. Mesmo sem a perspectiva de cura, o câncer de mama metastático é tratável.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.1. Critérios que apoiam a escolha e da terapia sistêmica** -->
A escolha do tratamento para pacientes com câncer de mama metastático depende de diversos fatores, como<sup>145</sup> :  
- Características da paciente e do tumor;  
- Localização de uma ou mais metástases;  
- Agressividade da doença;  
- Resposta às terapias anteriores;  
- Tempo desde a última exposição à quimioterapia ou hormonioterapia;  
- Agentes antineoplásicos usados previamente e as suas doses cumulativas;  
- Preferências individuais da paciente;  
- Possíveis eventos adversos;  
- Adesão ao tratamento;  
- Disponibilidade regional dos medicamentos;  
- Necessidade de internação;  
- Tempo de infusão e via de administração dos medicamentos.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.2.  Quimioterapia e hormonioterapia** -->
Os objetivos do tratamento sistêmico são aumentar a sobrevida, aliviar sintomas e melhorar ou manter a qualidade de vida. No caso de pacientes com recidiva tumoral metastática, a realização de nova biópsia é aconselhada tanto para confirmação diagnóstica, quanto para nova avaliação de receptores hormonais e HER-2. No momento do diagnóstico, as pacientes com câncer de mama recorrente ou estádio IV são inicialmente estratificadas de acordo com a presença de metástases ósseas. Esses dois subconjuntos de pacientes (aqueles com e sem metástases ósseas) são, então, estratificados, principalmente pelo perfil RH do tumor e pelo status de HER-2. Ressalta-se que a discordância na expressão destes marcadores entre lesão primária e metástase pode chegar a até 30%, mas é de grande importância para decisões de tratamento<sup>146</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.3.  Câncer de mama avançado RH positivo** -->
A hormonioterapia combinada com inibidores de quinase dependentes de ciclina 4 e 6 (iCDK4/6), abemaciclibe, ribociclibe e palbociclibe<sup>147</sup> , é o tratamento de escolha inicial em pacientes com câncer de mama RH-positivo avançado e **HER2 negativo** , por ser eficaz e melhor tolerado em comparação com quimioterapia. Estes podem ser usados isoladamente, ou em combinação com a hormonioterapia, em mulheres com pouco volume de doença não visceral e perfil de sensibilidade à hormonioterapia (doença _de novo_ , intervalo longo após hormonioterapia adjuvante, comportamento indolente).  
**As pacientes HER-2 positivo não possuem indicação para o uso dos iCDK4/6, uma vez que estes medicamentos não são aprovados para esta população e a incorporação no SUS também não incluiu estas pacientes.**  
Pacientes com receptor hormonal positivo com crise visceral ou resistência à terapia hormonal devem ser tratadas com quimioterápicos para rápida resposta, conforme quimioterapia preconizada às pacientes com câncer de mama avançado triplo negativo (Quadro 17). Importante ressaltar que crise visceral é definida como uma disfunção orgânica severa na qual a paciente apresenta sinais e sintomas de disfunção de órgãos e alterações em exames que indicam rápida progressão da doença com risco de morte e urgente necessidade de resposta clinica<sup>19,20,27</sup> . Diferentemente, existem situações de acometimento visceral que não se caracterizam como crise visceral, dado que o acometimento não gera uma disfunção do órgão acometido e não existem alterações relevantes em exames que indicam rápida progressão da doença<sup>19–21,82,148,149</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Primeira linha terapêutica** -->
Após avaliação da Conitec, a classe de inibidores de ciclinas (abemaciclibe, palbociclibe e succinato de ribociclibe) foi incorporada ao SUS para o tratamento do câncer de mama avançado ou metastático com RH+ e HER-2 negativo, conforme Portaria SCTIE/MS nº 73/2021.  
Existe evidência que demonstre que a associação de inibidores de ciclina (CDK4/6) com IA é superior ao uso de IA em monoterapia, podendo esta combinação ser priorizada se houver condição clínica ou tolerância<sup>150–152</sup> .  
Até o presente momento, não há uma comparação direta entre os inibidores CDK4/6 comercialmente disponíveis: palbociclibe, ribociclibe e abemaciclibe. Porém, uma revisão sistemática com meta-análise em rede mostrou que não há superioridade de um agente sobre outro em termos de sobrevida livre de progressão<sup>153,154</sup> . Não parece haver superioridade de um agente em relação aos demais IA, portanto, qualquer medicamento desta classe pode ser utilizado em primeira linha terapêutica<sup>155</sup> . A combinação de fulvestranto com os inibidores CDK4/6 ou este em monoterapia, devem ser os esquemas priorizados em pacientes que apresentaram recidiva após uso de inibidor da aromatase adjuvante ou até 12 meses após o término da adjuvância.  
Há possibilidade do uso de tamoxifeno em monoterapia, nesta linha, ressalvando-se de que a associação deste com inibidores de ciclina, até o momento, não tem previsão regulatória.  
Assim, para a primeira linha terapêutica, as opções terapêuticas incluem tratamento hormonal e inibidores de ciclina, conforme **Quadro 14** .  
Pacientes que não tenham realizado tratamento prévio, que tenham realizado hormonioterapia prévia com tamoxifeno ou que tenham utilizado inibidor da aromatase a mais de 12 meses, devem iniciar o tratamento com **inibidor de aromatase + iCDK4/6** . Já em casos de redicivas em pacientes em vigência de uso de inibidor da aromatase adjuvante ou até 12 meses após o término do uso de inibidor de aromatase adjuvante, deve-se optar por **fulvestranto + iCDK4/6** .  
**Quadro 14.** Esquemas terapêuticos de primeira linha para pacientes (pós- menopausa) com câncer de mama avançado (estádio IV) RH positivo e HER-2 negativo.  
**Possíveis esquemas** iCDK 4/6 + IA ou fulvestranto ou IA ou Fulvestranto ou Tamoxifeno Legenda: iCDK 4/6: abemaciclibe (150 mg duas vezes ao dia, sem interrupção), palbociclibe (125 mg uma vez ao dia por 3 semanas e pausa de 1 semana) ou ribociclibe (600 mg por 1x dia por 3 semanas e pausa de 1 semana). IA (anastrozol, letrozol ou exemestano); Fulvestranto (dose mensal de 500 mg por via intramuscular). Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Segunda linha terapêutica** -->
Caso não tenha sido utilizado na primeira linha de tratamento, a opção é o uso de fulvestranto na dose de 250 mg que, apesar de menos eficaz que a dose de 500 mg<sup>156,157</sup> , mostrou ser igualmente eficaz em comparação ao uso de exemestano<sup>156</sup> .  
Na falha de inibidor não esteroidal, como anastrozol ou letrozol, ainda pode ser utilizado um inibidor esteroidal, como exemestano<sup>158</sup> . Os dados de uso de tamoxifeno nesta situação demonstram um benefício restrito à taxa de resposta<sup>159</sup> .  
Na segunda linha terapêutica, os iCDK4/6 demonstraram aumento de sobrevida livre de progressão e melhora da taxa de resposta objetiva quando utilizados em associação ao fulvestranto. Porém, não houve diferenças significativas entre os grupos avaliados<sup>160,161</sup> . Após avaliação da Conitec, a classe de iCDK4/6 (abemaciclibe, palbociclibe e succinato de ribociclibe) foi incorporada ao SUS para o tratamento do câncer de mama avançado ou metastático com RH+ e HER-2 negativo, conforme Portaria SCTIE/MS nº 73/2021, independentemente da linha terapêutica.  
Ainda que possa existir benefício no uso de everolimo e alpelisibe<sup>162,163</sup> , informa-se que os medicamentos não incorporados ao SUS, devendo passar pelos ritos de incorporação legalmente vigentes.  
Assim, as alternativas terapêuticas aceitas para segunda linha que inclui tratamento hormonal, estão apresentadas no Quadro 15.  
**Quadro 15.** Esquemas terapêuticos de segunda linha para pacientes (pós-menopausa) com câncer de mama avançado (estádio IV) RH positivo e HER-2 negativo.  
|**Possíveis esquemas**|
|---|
|-Inibidor CDK 4/6 (se não tiver sido usado na 1ª linha) + fulvestranto|
|- Inibidor CDK 4/6 (se não tiver sido usado na 1ª linha) + IA|
|- Fulvestranto ou|
|- Exemestano ou|
|- IA ou|
|- Tamoxifeno|
|Legenda:|
|Inibidor CDK 4/6: palbociclibe e ribociclibe (ciclo completo de 28 dias, sendo 21 dias consecutivos, seguido por sete dias sem tratamento – esquema 3/1) ou|
|abemaciclibe (em ciclos mensais)|
|Fulvestranto: 500 mg, a cada 28 dias, por via intramuscular.<br>Exemestano: 25 mg/dia em monoterapia.|
|Fonte: Elaboração própria.|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.3.2. Pacientes pré-menopáusicas** -->
Pacientes na pré-menopausa têm as mesmas indicações terapêuticas que as mulheres na pós-menopausa. Contudo, aquelas com indicação de uso de IA ou fulvestranto devem ser submetidas à indução de menopausa temporária ou definitiva com uma de três possíveis estratégias e, a partir de então, estas pacientes são tratadas como pós-menopáusicas<sup>145</sup> :  
- Ooforectomia cirúrgica bilateral;  
- Ooforectomia actínica bilateral;  
- Administração mensal de 3,6 mg análogo de LHRH, preferencialmente com gosserrelina.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.4.  Câncer de mama avançado HER-2 positivo** -->
A via de sinalização HER-2 é extremamente importante no processo da oncogênese tumoral, o que torna terapias direcionadas para o bloqueio da via eficazes. Assim, terapias anti-HER-2 combinadas à quimioterapia são terapia de escolha para esse tipo de câncer também em fase avançada da doença.  
O pertuzumabe é um anticorpo monoclonal recombinante humanizado que se liga em um domínio extracelular distinto do trastuzumabe e previne sua dimerização com HER-3. A adição de pertuzumabe ao esquema de primeira linha em pacientes com câncer de mama metastático tratados com trastuzumabe e docetaxel demonstrou grande benefício de sobrevida global sem maior incidência de insuficiência cardíaca sintomática ou queda da fração de ejeção, em comparação com placebo associado ao trastuzumabe e docetaxel. Estes resultados de eficácia e segurança foram observados também em estudos observacionais<sup>164–166</sup> .  
São candidatas ao duplo bloqueio em 1ª linha pacientes com carcinoma de mama com superexpressão de HER-2 (em exame de IHQ com resultado de duas cruzes confirmado por técnica molecular ou de três cruzes), na ausência de doença cardíaca sintomática, com fração de ejeção cardíaca igual ou superior a 55% demonstrada no mês anterior ao início da quimioterapia com trastuzumabe e com comorbidades compatíveis com expectativa de vida para além de 6 meses<sup>167</sup> .  
Cerca de 10% das pacientes do estudo CLEOPATRA foram previamente expostos ao trastuzumabe e um estudo recente relatou benefícios muito menores da adição de pertuzumabe às pacientes com câncer de mama metastático expostos ao trastuzumabe no tratamento de segunda linha<sup>168</sup> .  
O duplo bloqueio da via HER-2 associado a docetaxel deve ser utilizado em primeira linha terapêutica. Na indisponibilidade de pertuzumabe, o uso de quimioterapia e trastuzumabe é o tratamento de escolha.  
O uso de trastuzumabe e quimioterapia sem pertuzumabe é inferior à quimioterapia associada ao duplo bloqueio da via HER-2. Contudo, há extensa literatura sobre a superioridade do uso de trastuzumabe combinado à quimioterapia em comparação com quimioterapia isolada. Não foi demonstrada evidência científica que embase o uso de trastuzumabe além da progressão<sup>169,170</sup> .  
Os esquemas terapêuticos para estas pacientes estão descritos no **Quadro 16** .  
**Quadro 16.** Esquemas terapêuticos para em pacientes com câncer de mama avançado (estádio IV) HER-2 positivo.  
|**Possíveis esque**|**mas**|
|---|---|
|Trastuzumabe +|pertuzumabe + docetaxel<sup>a</sup>|
|Trastuzumabe +|pertuzumabe + paclitaxel|
|Trastuzumabe +|paclitaxel ± carboplatina|
|Trastuzumabe +|docetaxel|
|Trastuzumabe +|vinorelbina|
|Trastuzumabe +|capecitabina|
|Trastuzumabe||  
Legenda:<sup>a</sup> Mantendo-se o tratamento até que se verifique progressão da doença.  
Nota: Trastuzumabe também pode ser associado a cisplatina, gencitabina, vinorelbina, 5-fluorouracila, doxorrubicina, epirrubicina, ciclofosfamida e metotrexato.  
Fonte: Elaboração própria.  
**Caso as pacientes expressem HER-2 e sejam RH+, elas também são candidatas à hormonioterapia, descritas no item anterior, com exceção dos iCDK4/6, uma vez que esta classe não possui indicação aprovada para uso em câncer de mama HER-2 positivo.**  
Para os casos de progressão tumoral após o uso de trastuzumabe em pacientes com doença metastática ou recidivada, o uso de trastuzumabe-entansina foi avaliado pela Conitec, recebendo recomendação desfavorável à sua incorporação. Assim, conforme Portaria SCTIE/MS nº 99/2022, o medicamento não foi incorporado ao SUS para essa indicação. Ainda, em que pese possa existir potencial benefício do trastuzumabe deruxtecana para tal indicação<sup>171</sup> , este ainda não incorporado ao SUS, devendo passar pelos ritos de incorporação legalmente vigentes. Por fim, acrescenta-se que medicamentos tais como o lapatinibe<sup>172,173</sup> possuem aprovação regulatória esta finalidade, porém também ainda devem ser submetidos aos ritos de incorporação legalmente vigentes. Portanto, **o presente Protocolo não preconiza alternativas terapêuticas específicas para pacientes nestas condições devido à não incorporação de tecnologias que atendam às suas necessidades, mas reforça que os protocolos institucionais dos serviços em que as pacientes são atendidas devem estabelecer condutas aceitáveis até que atualização deste enderece apropriadamente a lacuna.**

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.6.5.  Câncer de mama avançado triplo negativo e linhas subsequentes** -->
Pacientes com câncer de mama triplo-negativo não são candidatas às terapias anti-HER-2 ou hormonal, uma vez que a ausência destes biomarcadores prediz não resposta ao bloqueio da via HER-2 e à hormonioterapia, respectivamente. Portanto, pacientes com tumores triplo-negativos apresentam piores prognósticos, devendo ser tratadas com quimioterápicos para rápida resposta.  
Os fármacos associados à maior efetividade para essas pacientes são os antracíclicos (doxorrubicina ou epirrubicina) e taxanos (paclitaxel, docetaxel). Outros agentes quimioterápicos com atividade em doença metastática são: capecitabina,  
gencitabina, metotrexato, 5-fluorouracil, vinorelbina, vimblastina, mitomicina, etoposido, ciclofosfamida, cisplatina, carboplatina, doxorrubicina lipossomal. Destaca-se que as novas terapias de alto custo como a ixabepilona, a primulina, o paclitaxel ligado à albumina (nabpaclitaxel)<sup>145</sup> , possuem aprovação regulatória, porém ainda não foram submetidos à análise de avaliação de incorporação pela CONITEC.  
Para pacientes com câncer de mama metastático que já utilizaram antraciclinas e taxanos há menos de um ano a capecitabina e a vinorelbina são opções de tratamento adequadas. Destaca-se que novas terapias de alto custo como a eribulina, possuem aprovação regulatória, porém ainda não foram submetidos à análise de avaliação de incorporação pela CONITEC. Pacientes que tenham utilizado antracíclicos e taxanos há mais de um ano podem continuar utilizando esses medicamentos, respeitando-se as toxicidades cumulativas e a dose cumulativa dos antracíclicos. Mesmo em pacientes que nunca realizaram tratamento prévio ( _naive patients_ ), capecitabina e vinorelbina são opções de tratamento eficazes, com a vantagem de serem medicamentos orais e pouco associados à alopécia<sup>145</sup> .  
O uso de esquemas em monoterapia sequenciais é preferencial por prover paliação sintomática similar ao uso de múltiplos quimioterápicos em combinação e apresentar menos eventos adversos. A quimioterapia combinada pode ser útil, mesmo com maior toxicidade, quando houver grande necessidade de resposta, seja por disfunção orgânica ou sintomas. A decisão pela manutenção de tratamento quimioterápico paliativo deve ser compartilhada com a paciente e se basear no benefício e na sua tolerância individual. Uma revisão sistemática mostra que o tratamento com um número de ciclos previamente definido está associado à pior sobrevida quando comparado com a manutenção do tratamento até progressão da doença ou até toxicidade inaceitável<sup>153</sup> .  
O grau de toxicidade deve ser definido, com cada paciente, conforme sua qualidade de vida, objetivos do tratamento paliativo e valores individuais. O tratamento de pacientes com câncer de mama metastático com esquemas em terceira ou quarta linhas é aceito em consensos internacionais com a intenção de paliar sintomas e melhorar a qualidade de vida<sup>145</sup> . Existem outras classes de medicamentos ainda não avaliadas para a incorporação de tratamento do câncer de mama, como a imunoterapia<sup>174–176</sup> , anti-angiogênico e inibidores de PARP<sup>167,177</sup> .  
Os esquemas terapêuticos para esta indicação estão descritos no **Quadro 17** .  
**Quadro 17.** Esquemas terapêuticos para pacientes com câncer de mama avançado (estádio IV) triplo negativo.  
**Possíveis esquemas** <u>Inicial:</u> paclitaxel, docetaxel, doxorrubicina, doxorrubicina lipossomal, epirubicina, capecitabina, gencitabina, carboplatina, cisplatina <u>Se paciente for refratário a antracíclicos:</u> paclitaxel ou docetaxel docetaxel + capecitabina docetaxel + gencitabina paclitaxel + gencitabina ciclofosfamida + metotrexato + 5 fluorouracila <u>Se paciente for refratário a antracíclicos e taxanos:</u> Monoterapia com capecitabina, eribulina, gencitabina, carboplatina, cisplatina ou vinorelbina capecitabina + vinorelbina cisplatina + gencitabina carboplatina + gencitabina ciclofosfamida + metotrexato + 5-fluorouracila  
<u>Podem ser usados:</u> FAC (5-fluorouracil + doxorrubicina/ciclofosfamida) AC (doxorrubicina/ciclofosfamida) carboplatina + paclitaxel  
Nota: Trastuzumabe também pode ser associado a cisplatina, gencitabina, vinorelbina, 5-fluorouracila, doxorrubicina, epirrubicina, ciclofosfamida e metotrexato.  
Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **9.7.     Metástases ósseas** -->
As complicações de metástases ósseas incluem dor, diminuição do status de desempenho e diminuição da qualidade de vida. Também envolve eventos relacionados ao esqueleto, que são definidos como a necessidade de radiação ou cirurgia óssea, fraturas patológicas, compressão da medula espinhal e hipercalcemia de malignidade. Para isso, pacientes com uma ou mais metástases ósseas devem receber o inibidor de osteólise, associado a um efetivo tratamento sistêmico e radioterapia, quando indicada. Os inibidores de osteólise ajudam a reduzir a dor, a incidência de fraturas e hipercalcemia. Entretanto, deve-se atentar para a possibilidade de osteonecrose de mandíbula devido ao uso prolongado de medicamento dessa classe farmacológica<sup>178,179</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **10.1.   Avaliação da resposta terapêutica** -->
Pacientes em uso de quimioterapia ou hormonioterapia neoadjuvante devem ser monitorizadas com exame clínico. Exames de imagem não devem ser feitos de forma rotineira, mas podem ocasionalmente ser úteis para auxiliar a decisão cirúrgica ou para determinar progressão durante o tratamento<sup>180</sup> .  
Pacientes em tratamento paliativo devem ser monitorizados com exames de imagem (preferencialmente TC) para avaliação da resposta terapêutica a cada 6 a 12 semanas de tratamento com quimioterapia ou hormonioterapia. Marcadores tumorais não são preconizados para avaliação de resposta em pacientes com câncer de mama localizado, mas o benefício é incerto para doença metastática<sup>149,181</sup> .  
Pacientes em uso de hormonioterapia como tratamento paliativo devem receber tratamento até a progressão da doença. Para paciente em quimioterapia, embora não haja um número de ciclos, preconizase um total de 6 a 8 ciclos, conforme a sua tolerância ao tratamento, que deve ser mantido até progressão ou toxicidade inaceitável<sup>181</sup> .  
Considerando que a necessidade de ajuste de dose e os eventos adversos ocorrem mais frequentemente no início do  
tratamento com os iCDK 4/6, recomenda-se:  
- Uma avaliação da paciente a cada 2 semanas, nos primeiros dois meses;  
- Uma avaliação mensal entre o terceiro e o sétimo mês de tratamento;  
- A partir do oitavo mês, as avaliações médicas devem ocorrer a cada dois meses, ou conforme prática clínica institucional.  
Os iCDK 4/6 são medicamentos orais e o paciente é acompanhado dentro do fluxo das quimioterapias, ainda que esteja utilizando hormonioterapia associada. O monitoramento da paciente é simples e poucos exames são requeridos, porém são necessários para garantir a segurança da paciente. Estes incluem realização de eletrocardiograma (não de rotina), hemograma e bioquímica (TGO, TGP, bilirrubinas, creatinina, sódio, potássio, magnésio, cálcio e fósforo).

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **10.2. Redução de dose dos iCDK 4/6** -->
Caso as pacientes em uso de iCDK 4/6 apresentem eventos adversos intoleráveis ou toxicidade, pode ser necessária a interrupção ou a redução da dose.  
A redução da dose de abemaciclibe devem ocorrer em 50 mg por vez. Caso as pacientes não tolerem o uso de 50 mg duas vezes ao dia, o uso do medicamento deve ser interrompido.  
Em pacientes em uso de ribociclibe, caso seja necessária a redução da dose do medicamento, esta deve ocorrer em 200 mg por vez. Caso as pacientes não tolerem o uso de 200 mg por dia, o uso do medicamento deve ser interrompido.  
Em relação ao palbociclibe, a redução de dose, se necessária, deve ocorrer em 25 mg por vez. Caso as pacientes não tolerem o uso de 75 mg por dia, o uso do medicamento deve ser interrompido.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **10.3. Critérios de interrupção de tratamento** -->
Pacientes que apresentem qualquer tipo de toxicidade ao tratamento sistêmico graus 3 e 4, de acordo com a quinta versão da _Common Terminology Criteria for Adverse Events_ (CTCAE) apresentam toxicidade considerada grave e usualmente necessitam de redução de dose ou suspensão do tratamento<sup>182</sup> .  
Para pacientes em tratamento paliativo, deve-se considerar a suspensão temporária do tratamento e reinício com redução de dose quando a toxicidade estiver resolvida ou retornar para os graus 1 ou 2. Pacientes com toxicidade inaceitável com tratamento sistêmico, mesmo com doses reduzidas, devem ter o tratamento suspenso. Essa conduta simplificada deve considerar o tratamento utilizado, o evento adverso em questão e o benefício clínico atingido pelo paciente<sup>183</sup> .

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Trastuzumabe** -->
A incidência de toxicidade cardíaca com o uso do trastuzumabe foi baixa nos estudos clínicos prospectivos, variando entre 1% e 4%, sendo comumente reversível se detectada precocemente e apresentar boa resposta ao tratamento clínico. Pacientes que não apresentarem melhora não deverão recomeçar o uso de trastuzumabe. Havendo interrupção do uso de trastuzumabe por intervalo igual ou superior a seis semanas, por qualquer motivo, pode ser repetida a dose inicial<sup>184,185</sup> .  
Em relação à infusão do trastuzumabe, recomenda-se a observação clínica por 30 minutos após a administração das três primeiras doses do medicamento, devido ao risco de reações adversas imediatas por hipersensibilidade. Sintomas como febre e calafrios podem ocorrer em 30% a 40% das pacientes após a primeira administração de trastuzumabe, sendo menos comum nas administrações subsequentes. Podem ocorrer ainda náusea, vômitos, astenia, dor local, cefaleia, tontura, dispneia, hipotensão e erupção cutânea. Recomenda-se o uso de medicamentos sintomáticos (anti-histamínicos e analgésicos) e redução da velocidade de infusão. Reações graves, como dispneia, hipotensão, sibilância, broncoespasmo, taquicardia e hipoxemia, não são frequentes (3 por 1.000 pacientes), mas podem resultar em óbito (4 por 10.000 pacientes). Nesses casos, as pacientes devem interromper imediatamente o uso de trastuzumabe e devem ser adotadas as medidas de suporte clínico apropriadas<sup>183</sup> .  
Em pacientes com Fração de Ejeção (FE) normal, o monitoramento da função cardíaca com ecocardiograma durante o uso de trastuzumabe deve ser realizado a cada 3 meses<sup>186</sup> . Em pacientes com alteração de FE ou FE limítrofe (50% a 55%), a periodicidade de monitoramento ecocardiográfico deve seguir as recomendações da Diretriz Brasileira de Cardio-oncologi<sup>186</sup> . É importante o seguimento das orientações quanto à periodicidade do ecocardiograma, além da avaliação de sinais e sintomas de insuficiência cardíaca<sup>186</sup> .  
A cardiotoxicidade do trastuzumabe é reversível na maioria dos casos e envolve a interrupção do uso do medicamento por cerca de 3 semanas<sup>186,187</sup> . Caso a FE caia de 10 a 15 pontos em relação ao valor inicial ou fique abaixo de 50%, o trastuzumabe pode ser reiniciado. Caso contrário, o tratamento deve ser interrompido definitivamente.  
Caso o tratamento com trastuzumabe seja interrompido por seis semanas ou mais, por qualquer motivo, pode ser repetida a dose inicial. Em caso de duas ou três interrupções sucessivas, ou após a terceira suspensão em qualquer momento, o uso do medicamento deve ser permanentemente interrompido.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Trastuzumabe entansina** -->
O trastuzumabe entansina deve ser administrado por infusão intravenosa (IV) e precisa ser reconstituído e diluído por um profissional de saúde, assim como não deve ser administrado como injeção intravenosa direta ou em bolus. A dose máxima recomendada de T-DM1 é de 3,6 mg/kg a cada 3 semanas (ciclo de 21 dias), sendo que pacientes com câncer de mama inicial devem receber tratamento por um total de 14 ciclos. A dose inicial deve ser administrada na forma de infusão intravenosa durante 90 minutos, de forma que as pacientes devem ser observadas durante a infusão e por, pelo menos, 90 minutos depois da dose inicial para verificar o potencial aparecimento de febre, calafrios ou outras reações relacionadas à infusão. O local de infusão deve ser monitorado cuidadosamente para verificar possível infiltração subcutânea durante a administração do medicamento. Se as primeiras infusões forem bem toleradas, as doses subsequentes podem ser administradas em infusões de 30 minutos e as pacientes devem ser observados durante as infusões e por, pelo menos, 30 minutos depois delas. A velocidade de infusão deve ser diminuída ou interrompida se a paciente desenvolver sintomas relacionados à infusão, assim como deve ser suspensa a administração na presença de reações à infusão potencialmente fatais.  
Tem sido observado nas pacientes com câncer de mama HER-2 positivo um risco maior do que o habitual de desenvolver uma ou mais metástases no SNC, região santuário, não alcançada pela maioria dos medicamentos antineoplásicos usados na quimioterapia adjuvante. Se a paciente desenvolver metástase isolada no SNC durante a quimioterapia adjuvante com trastuzumabe, o tratamento precisa ser substituído por um apropriado (cirurgia ou radioterapia). Se toda a lesão metastática tiver sido ressecada, proporcionando a chance de remissão em longo prazo, a quimioterapia adjuvante deve ser retomada para completar período de uso do trastuzumabe originalmente programado. Se a paciente desenvolver metástase no SNC e em outro órgão, durante a quimioterapia adjuvante com trastuzumabe, o uso deste medicamento deve ser interrompido e não reiniciado.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **10.4.   Acompanhamento pós-tratamento** -->
Pacientes que realizaram o tratamento de câncer de mama localizado devem ser acompanhadas por pelo menos cinco anos. O exame físico deve ser realizado a cada três a seis meses para os primeiros três anos, a cada seis a doze meses para os seguintes dois anos, e depois, anualmente. Ressalva-se que as pacientes com tumores triplo negativos devem ser seguidas com intervalo mais próximo, pelo alto risco de recidiva nos primeiros anos da doença.  
O seguimento destas pacientes deve incluir a mamografia de rastreamento, anualmente, começando um ano após a mamografia inicial. Para as pacientes que realizaram cirurgia conservadora da mama, é necessário aguardar, pelo menos seis meses após a conclusão da radioterapia.  
Não é preconizado o uso de quaisquer exames como hemograma completo, dosagens bioquímicas séricas, cintilografia óssea, radiografia de tórax, ultrassonografia abdominal, TC, RM, PET-CT ou marcadores tumorais para acompanhamento de rotina de um paciente assintomático sem achados específicos que sugiram recidiva da doença na anamnese ou no exame clínico.  
Pacientes pré ou pós-menopáusicas assintomáticas em uso de tamoxifeno não se beneficiam de ecografia transvaginal ou biópsias endometriais de rotina<sup>188</sup> .  
Já pacientes em uso de IA adjuvante estão sob risco de perda de massa óssea significativa, desta forma, a avaliação do risco de fraturas é essencial. Além disso, a densitometria óssea deve ser solicitada para todas as pacientes que apresentam pelo menos um fator de risco adicional para osteoporose e a necessidade de medicamentos para a saúde óssea deve ser decidida de acordo com a densidade mineral óssea. A reavaliação da densidade mineral óssea deve ser realizada em um período entre um e dois anos<sup>189</sup> . Pacientes em uso de IA também apresentam risco aumentado de eventos cardiovasculares, por isso, é aconselhável monitorar presença de dislipidemia medicamentosa e risco cardiovascular<sup>190</sup> .  
Para pacientes na perimenopausa, é muito importante considerar o monitoramento seriado dos níveis de gonadotrofina e estradiol, bem como a avaliação da paciente para o retorno da menstruação se o tratamento com IA for escolhido.  
Ressalta-se que o uso de bifosfonatos parenterais para prevenção de perda óssea em pacientes em hormonioterapia não se encontra incorporado ao SUS.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **11.      GESTÃO E CONTROLE** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Casos de câncer de mama devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, estadiar, tratar e acompanhar os pacientes, femininos ou masculinos. Além da familiaridade que tais hospitais guardam com o estadiamento, o tratamento e controle dos eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e a garantia do atendimento aos pacientes e muito facilita as ações de controle e avaliação. Entre tais ações incluem-se a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES), a autorização prévia dos procedimentos, o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos) e a verificação dos percentuais da frequência dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda e segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou do protocolo adotados no hospital, a regulação do acesso assistencial, a qualidade da autorização, a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses), a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod), a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais e o grau de satisfação dos doentes  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. As exceções atuais e futuras de compras centralizadas pelo Ministério da Saúde estão ou estarão definidas em atos normativos publicados pela União. Os hospitais credenciados pelo SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos (Grupo 03, Subgrupo 01) e cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **12. REFERÊNCIAS** -->
1. Joslyn SA. Patterns of care for immediate and early delayed breast reconstruction following mastectomy. Plast Reconstr Surg. 2005/04/06 ed. 2005;115(5):1289–96. doi:10.1097/01.prs.0000156974.69184.5e  
2. Sung H, Ferlay J, Siegel RL, Laversanne M, Soerjomataram I, Jemal A, et al. Global Cancer Statistics 2020: GLOBOCAN Estimates of Incidence and Mortality Worldwide for 36 Cancers in 185 Countries. CA Cancer J Clin. 2021/02/05 ed. 2021;71(3):209–49. doi:10.3322/caac.21660  
3. Brasil. Ministério da Saúde. Instituto Nacional de Câncer. Estimativa 2023 -  Incidência de Câncer no Brasil [Internet]. 2022 [citado 2 de abril de 2024]. 160 p. Disponível em: https://www.inca.gov.br/sites/ufu.sti.inca.local/files//media/document//estimativa-2023.pdf  
4. Dong G, Wang D, Liang X, Gao H, Wang L, Yu X, et al. Factors related to survival rates for breast cancer patients. Int J Clin Exp Med. 2014/11/25 ed. 2014;7(10):3719–24.  
5. Veronesi U, Boyle P, Goldhirsch A, Orecchia R, Viale G. Breast cancer. Lancet. 2005/05/17 ed. 2005;365(9472):1727–41. doi:10.1016/S0140-6736(05)66546-4  
6. Simon SD, Bines J, Werutsky G, Nunes JS, Pacheco FC, Segalla JG, et al. Characteristics and prognosis of stage I-III breast cancer subtypes in Brazil: The AMAZONA retrospective cohort study. Breast. 2019/02/10 ed. 2019;44:113–9. doi:10.1016/j.breast.2019.01.008  
7. Coates AS, Hurny C, Peterson HF, Bernhard J, Castiglione-Gertsch M, Gelber RD, et al. Quality-of-life scores predict outcome in metastatic but not early breast cancer. International Breast Cancer Study Group. J Clin Oncol. 2000/11/15 ed. 2000;18(22):3768–74. doi:10.1200/JCO.2000.18.22.3768  
8. Ries LAG Kosary CL Hankey BF Miller BA Clegg L Mariotto A Fay MP Feuer EJ Edwards BK (eds) EMP. SEER Cancer Statistics Review, 1975-2000 , National Cancer Institute. Bethesda, MD, https://seer.cancer.gov/csr/1975_2000/, 2003.  
9. Phung MT, Tin Tin S, Elwood JM. Prognostic models for breast cancer: a systematic review. BMC Cancer. 2019/03/16 ed. 2019;19(1):230–230. doi:10.1186/s12885-019-5442-6  
10. Migowski A, Silva GA, Dias MBK, Diz MDPE, Sant’Ana DR, Nadanovsky P. Diretrizes para detecção precoce do câncer de mama no Brasil. II-Novas recomendações nacionais, principais evidências e controvérsias. Cadernos de Saúde Pública. 2018;34:e00074817–e00074817.  
11. Brasil. Ministério da Saúde. Instituto Nacional de Câncer José Alencar Gomes da Silva. Detecção precoce do câncer. 2021;72–72.  
12. Brasil. Ministério da Saúde. Secretaria de Ciência T e IEstratégicosCN de I de T– CONITEC. Mamografia para o rastreamento do câncer de mama em mulheres com idade abaixo dos 50 anos, entre 50 e 69 anos e com mais de 70 anos. 2015.  
13. BRASIL. Lei n<sup>o</sup> 14.355, de 10 de maio de 2022. . Altera a Lei n<sup>o</sup> 11.664, de 29 de abril de 2008, para dispor sobre a atenção integral à mulher na prevenção dos cânceres do colo uterino, de mama e colorretal.  
14. Bevers TB, Helvie M, Bonaccio E, Calhoun KE, Daly MB, Farrar WB, et al. Breast Cancer Screening and Diagnosis, Version 3.2018, NCCN Clinical Practice Guidelines in Oncology. J Natl Compr Canc Netw. 2018/11/18 ed. 2018;16(11):1362–89. doi:10.6004/jnccn.2018.0083  
15. Brasil. Ministério da Saúde. Instituto Nacional de Câncer. Parâmetros técnicos para detecção precoce do câncer de mama [Internet]. [citado 2 de abril de 2024]. 48 p. Disponível em: https://www.inca.gov.br/sites/ufu.sti.inca.local/files/media/document/parametros-tecnicos-deteccao-precoce-cancer-demama.pdf  
16. Liedtke C, Mazouni C, Hess KR, Andre F, Tordai A, Mejia JA, et al. Response to neoadjuvant therapy and long-term survival in patients with triple-negative breast cancer. J Clin Oncol. 2008/02/06 ed. 2008;26(8):1275–81. doi:10.1200/JCO.2007.14.4147  
17. Allison et al. Estrogen and Progesterone Receptor Testing in Breast Cancer: ASCO/CAP Guideline Update. Journal of clinical oncology : official journal of the American Society of Clinical Oncology, 38(12), 1346–1366. doi:https://doi.org/10.1200/JCO.19.02309  
18. Palma DA, Olson R, Harrow S, Gaede S, Louie AV, Haasbeek C, et al. Stereotactic Ablative Radiotherapy for the Comprehensive Treatment of Oligometastatic Cancers: Long-Term Results of the SABR-COMET Phase II Randomized Trial. J Clin Oncol. 2020/06/03 ed. 2020;38(25):2830–8. doi:10.1200/JCO.20.00818  
19. Huang Z, Zhou X, Tong Y, Zhu L, Zhao R, Huang X. Surgery for primary tumor benefits survival for breast cancer patients with bone metastases: a large cohort retrospective study. BMC Cancer. 2021/03/06 ed. 2021;21(1):222–222. doi:10.1186/s12885-021-07964-9  
20. Wang K, Zhu GQ, Shi Y, Li ZY, Zhang X, Li HY. Long-Term Survival Differences Between T1-2 Invasive Lobular Breast Cancer and Corresponding Ductal Carcinoma After Breast-Conserving Surgery: A Propensity-Scored Matched Longitudinal Cohort Study. Clin Breast Cancer. 2018/12/07 ed. 2019;19(1):e101–15. doi:10.1016/j.clbc.2018.10.010  
21. Nielsen TO, Hsu FD, Jensen K, Cheang M, Karaca G, Hu Z, et al. Immunohistochemical and clinical characterization of the basal-like subtype of invasive breast carcinoma. Clin Cancer Res. 2004/08/26 ed. 2004;10(16):5367–74. doi:10.1158/1078-0432.CCR-04-0220  
22. Blows FM, Driver KE, Schmidt MK, Broeks A, van Leeuwen FE, Wesseling J, et al. Subtyping of breast cancer by immunohistochemistry to investigate a relationship between subtype and short and long term survival: a collaborative analysis of data for 10,159 cases from 12 studies. PLoS Med. 2010/06/04 ed. 2010;7(5):e1000279–e1000279. doi:10.1371/journal.pmed.1000279  
23. Cheang MC, Chia SK, Voduc D, Gao D, Leung S, Snider J, et al. Ki67 index, HER2 status, and prognosis of patients with luminal B breast cancer. J Natl Cancer Inst. 2009/05/14 ed. 2009;101(10):736–50. doi:10.1093/jnci/djp082  
24. Bogdanovska-Todorovska M, Petrushevska G, Janevska V, Spasevska L, Kostadinova-Kunovska S. Standardization and optimization of fluorescence in situ hybridization (FISH) for HER-2 assessment in breast cancer: A single center experience. Bosn J Basic Med Sci. 2018/02/02 ed. 2018;18(2):132–40. doi:10.17305/bjbms.2018.2519  
25. Brierley JD, Gospodarowicz MK, Wittekind C. TNM Classification of Malignant Tumours. John Wiley & Sons, 8 edição, 2016.  
26. Amin MB, Greene FL, Edge SB, Compton CC, Gershenwald JE, Brookland RK, et al. The Eighth Edition AJCC Cancer Staging Manual: Continuing to build a bridge from a population-based to a more “personalized” approach to cancer staging. CA Cancer J Clin. 2017/01/18 ed. 2017;67(2):93–9. doi:10.3322/caac.21388  
27. Sociedade Brasileira de Oncologia Clínica. Diretrizes de tratamentos oncológicos recomendados pela Sociedade Brasileira de Oncologia Clínica - MAMA: ESTADIAMENTO. Acesso: 06 de agosto de 2021. Disponível em: https://sboc.org.br/images/25.-Diretrizes-SBOC-2021---Mama-estadiamento-FINAL-2.pdf. 2021.  
28. Kim H, Han W, Moon HG, Min J, Ahn SK, Kim TY, et al. The value of preoperative staging chest computed tomography to detect asymptomatic lung and liver metastasis in patients with primary breast carcinoma. Breast Cancer Res Treat. 2011/02/08 ed. 2011;126(3):637–41. doi:10.1007/s10549-011-1368-7  
29. Myers RE, Johnston M, Pritchard K, Levine M, Oliver T, Breast Cancer Disease Site Group of the Cancer Care Ontario Practice Guidelines I. Baseline staging tests in primary breast cancer: a practice guideline. CMAJ. 2001/06/05 ed. 2001;164(10):1439–44.  
30. Goldhirsch A, Winer EP, Coates AS, Gelber RD, Piccart-Gebhart M, Thurlimann B, et al. Personalizing the treatment of women with early breast cancer: highlights of the St Gallen International Expert Consensus on the Primary Therapy of Early Breast Cancer 2013. Ann Oncol. 2013/08/07 ed. 2013;24(9):2206–23. doi:10.1093/annonc/mdt303  
31. Goldhirsch A, Wood WC, Gelber RD, Coates AS, Thurlimann B, Senn HJ, et al. Progress and promise: highlights of the international expert consensus on the primary therapy of early breast cancer 2007. Ann Oncol. 2007/08/07 ed. 2007;18(7):1133–44. doi:10.1093/annonc/mdm271  
32. de Glas NA, Bastiaannet E, Engels CC, de Craen AJ, Putter H, van de Velde CJ, et al. Validity of the online PREDICT tool in older patients with breast cancer: a population-based study. Br J Cancer. 2016/01/20 ed. 2016;114(4):395– 400. doi:10.1038/bjc.2015.466  
33. Gray E, Marti J, Brewster DH, Wyatt JC, Hall PS, Group SA. Independent validation of the PREDICT breast cancer prognosis prediction tool in 45,789 patients using Scottish Cancer Registry data. Br J Cancer. 2018/09/18 ed. 2018;119(7):808–14. doi:10.1038/s41416-018-0256-x  
34. Wishart GC, Bajdik CD, Dicks E, Provenzano E, Schmidt MK, Sherman M, et al. PREDICT Plus: development and validation of a prognostic model for early breast cancer that includes HER2. Br J Cancer. 2012/08/02 ed. 2012;107(5):800–7. doi:10.1038/bjc.2012.338  
35. Wishart GC, Bajdik CD, Azzato EM, Dicks E, Greenberg DC, Rashbass J, et al. A population-based validation of the prognostic model PREDICT for early breast cancer. Eur J Surg Oncol. 2011/03/05 ed. 2011;37(5):411–7. doi:10.1016/j.ejso.2011.02.001  
36. Wishart GC, Azzato EM, Greenberg DC, Rashbass J, Kearins O, Lawrence G, et al. PREDICT: a new UK prognostic model that predicts survival following surgery for invasive breast cancer. Breast Cancer Res. 2010/01/08 ed. 2010;12(1):R1– R1. doi:10.1186/bcr2464  
37. Clarke M, Collins R, Darby S, Davies C, Elphinstone P, Evans V, et al. Effects of radiotherapy and of differences in the extent of surgery for early breast cancer on local recurrence and 15-year survival: an overview of the randomised trials. Lancet. 2005/12/20 ed. 2005;366(9503):2087–106. doi:10.1016/S0140-6736(05)67887-7  
38. Veronesi U, Zucali R, Luini A. Local control and survival in early breast cancer: the Milan trial. Int J Radiat Oncol Biol Phys . 1986;12(5):717–20. doi:10.1016/0360-3016(86)90027-1  
39. Veronesi U, Volterrani F, Luini A, Saccozzi R, Del Vecchio M, Zucali R, et al. Quadrantectomy versus lumpectomy for small size breast cancer. Eur J Cancer. 1990;26(6):671–3.  
40. Mariani L, Salvadori B, Marubini E, Conti AR, Rovini D, Cusumano F, et al. Ten year results of a randomised trial comparing two conservative treatment strategies for small size breast cancer. Eur J Cancer. 1998;34(8):1156–62. doi:10.1016/s0959-8049(98)00137-3  
41. Veronesi U, Luini A, Del Vecchio M. Radiotherapy after breast-preserving surgery in women with localized cancer of the breast. N Engl J Med. 1993;328(22):1587–91.  
42. Veronesi U, Saccozzi R, Del Vecchio M. Comparing radical mastectomy with quadrantectomy, axillary dissection, and radiotherapy in patients with small cancers of the breast. N Engl J Med. 1981;305(1):6–11.  
43. Hughes KS, Schnaper LA, Berry D, Cirrincione C, McCormick B, Shank B, et al. Lumpectomy plus tamoxifen with or without irradiation in women 70 years of age or older with early breast cancer. N Engl J Med. 2004/09/03 ed. 2004;351(10):971–7. doi:10.1056/NEJMoa040587  
44. Hughes, K S  et al. Lumpectomy plus tamoxifen with or without irradiation in women age 70 years or older with early breast cancer: longterm follow-up of CALGB 9343. J Clin Oncol. 2013;31(19):2382–7.  
45. Liu Y, Wang M, Morris AD, Doney AS, Leese GP, Pearson ER, et al. Glycemic exposure and blood pressure influencing progression and remission of diabetic retinopathy: a longitudinal cohort study in GoDARTS. Diabetes Care. 2013/10/31 ed. 2013. p. 3979–84. Located at: Nlm  
46. Kunkler IH, Williams LJ, Jack W. Breast-conserving surgery with or without irradiation in women aged 65 years or older with early breast cancer (PRIME II): a randomised controlled trial. Lancet Oncol. 2015;16(3):266–73.  
47. Al-Ghazal SK, Sully L, Fallowfield L, Blamey RW. The psychological impact of immediate rather than delayed breast reconstruction. Eur J Surg Oncol. 2000/03/16 ed. 2000;26(1):17–9. doi:10.1053/ejso.1999.0733  
48. Tasmuth T, von Smitten K, Kalso E. Pain and other symptoms during the first year after radical and conservative surgery for breast cancer. Br J Cancer. 1996;74(12):2024–31.  
49. Velanovich V, Szymanski W. Quality of life of breast cancer patients with lymphedema. Am J Surg. 1999;177(3):184–7.  
50. Veronesi U, Galimberti V, Zurrida S et al. Prognostic significance of number and level of axillary node metastases in breast cancer. The Breast. 1993;2(4):224–8.  
51. Lagares-Garcia J, Garguilo G, Kurek S, et al. Axillary lymph node dissection in breast cancer: an evolving question? Am Surg. 2000;66(1):66–72.  
52. Goldhirsch A, Glick J, Gelber RD. Meeting highlights: International Consensus Panel on the Treatment of Primary Breast Cancer. Seventh International Conference on Adjuvant Therapy of Primary Breast Cancer. J Clin Oncol. 2001;19(18):3817–27.  
53. Hortobagyi GN. Treatment of breast cancer. N Engl J Med. 1998;339(14):974–84.  
54. Dent D. Axillary lymphadenectomy for breast cancer. Paradigm shifts and pragmatic surgeons. Arch Surg. 1996;131(11):1125–7.  
55. Greco M, Agresti R, Raselli R. Axillary dissection can be avoided in selected breast cancer patients: analysis of 401 cases. Anticancer Res. 1996;16(6c):3913–7.  
56. Giuliano A, Kirgan D, Guenther JM. Lymphatic mapping and sentinel lymphadenectomy for breast cancer. Ann Surg. 1994;220(3):391–8; discussion 398-401.  
57. McMasters K, Giuliano A, Ross M, et al. Sentinel-lymph-node biopsy for breast cancer--not yet the standard of care. N Engl J Med 1998; 339 (14): 990- 995. N Eng J Med. 1998;339(14):990–5.  
58. Halsted WS. I. The Results of Radical Operations for the Cure of Carcinoma of the Breast. Ann Surg. 1907/07/01 ed. 1907;46(1):1–19. doi:10.1097/00000658-190707000-00001  
59. Veronesi U, Valagussa P. Inefficacy of internal mammary nodes dissection in breast cancer surgery. Cancer. 1981/01/01 ed. 1981;47(1):170–5. doi:10.1002/1097-0142(19810101)47:1<170::aid-cncr2820470128>3.0.co;2-c  
60. Turner L, Swindell R, Bell WG, Hartley RC, Tasker JH, Wilson WW, et al. Radical versus modified radical mastectomy for breast cancer. Ann R Coll Surg Engl. 1981/07/01 ed. 1981;63(4):239–43.  
61. Badwe R, Hawaldar R, Nair N et al. Locoregional treatment versus no treatment of the primary tumour in metastatic breast cancer: an open-label randomised controlled trial. Lancet Oncol 2015;16:1380-1388.  
62. King TA, Lyman J, Gonen M et al. Prognostic Impact of 21-Gene Recurrence Score in Patients With Stage IV Breast Cancer: TBCRC 013. J Clin Oncol 2016;34:2359-2365.  
63. Soran A, Ozmen V, Ozbas S et al. Randomized Trial Comparing Resection of Primary Tumor with No Surgery in Stage IV Breast Cancer at Presentation: Protocol MF07-01. Ann Surg Oncol 2018;25:3141-3149.  
64. Kelly A, Dwamena B, Cronin P, et al. Breast cancer sentinel node identification and classification after neoadjuvant chemotherapy-systematic review and meta analysis. Acad Radiol. 2009;16(5):551–63.  
65. Shirzadi A, Mahmoodzadeh H, Qorbani M. Assessment of sentinel lymph node biopsy after neoadjuvant chemotherapy for breast cancer in two subgroups: Initially node negative and node positive converted to node negative - A systemic review and meta-analysis. J Res Med Sci. 2019;29(1):18.  
66. van Deurzen C, Vriens B, Tjan-Heijnen V, et al. Accuracy of sentinel node biopsy after neoadjuvant chemotherapy in breast cancer patients: a systematic review. Eur J Cancer. 2009;45(18):3124–30.  
67. Kuehn T, Bauerfeind I, Fehm T, Fleige B, Hausschild M, Helms G, et al. Sentinel-lymph-node biopsy in patients with breast cancer before and after neoadjuvant chemotherapy (SENTINA): a prospective, multicentre cohort study. Lancet Oncol. 2013/05/21 ed. 2013;14(7):609–18. doi:10.1016/S1470-2045(13)70166-9  
68. Boughey J, Suman V, Mittendorf E, et al. Sentinel lymph node surgery after neoadjuvant chemotherapy in patients with node-positive breast cancer: the ACOSOG Z1071 (Alliance) clinical trial. JAMA. 2013;310(14):1455–61.  
69. Boileau J, Poirier B, Basik M, et al. Sentinel node biopsy after neoadjuvant chemotherapy in biopsy-proven nodepositive breast cancer: the SN FNAC study. J Clin Oncol. 2015;33(3):258–64.  
70. Silva JCC. Radioterapia adjuvante de mama: e rotina com planejamento e tratamento técnico em (SSD) E (SAD) [Trabalho de Conclusão de Curso.] [Internet]. [Rio de Janeiro]: Instituto Nacional do Câncer; 2019. Disponível em: https://ninho.inca.gov.br/jspui/bitstream/123456789/14623/3/Radioterapia%20adjuvante%20de%20mama%20e%20rotina%20 com%20planejamento%20e%20tratamento%20t%C3%A9cnico%20em%20%28SSD%29%20e%20%28SAD%29.pdf  
71. Shah C, Bauer-Nilsen K, McNulty R, Vicini F. Novel radiation therapy approaches for breast cancer treatment. Semin Oncol. 2020;47(4):209–16. doi:10.1053/j.seminoncol.2020.05.003  
72. Whelan TJ, Pignol JP, Levine MN, Julian JA, MacKenzie R, Parpia S, et al. Long-term results of hypofractionated radiation therapy for breast cancer. N Engl J Med. 2010/02/12 ed. 2010;362(6):513–20. doi:10.1056/NEJMoa0906260  
73. Haviland JS, Owen JR, Dewar JA, Agrawal RK, Barrett J, Barrett-Lee PJ, et al. The UK Standardisation of Breast Radiotherapy (START) trials of radiotherapy hypofractionation for treatment of early breast cancer: 10-year follow-up results of two randomised controlled trials. Lancet Oncol. 2013/09/24 ed. 2013;14(11):1086–94. doi:10.1016/S1470-2045(13)70386-3  
74. Group ST, Bentzen SM, Agrawal RK, Aird EG, Barrett JM, Barrett-Lee PJ, et al. The UK Standardisation of Breast Radiotherapy (START) Trial B of radiotherapy hypofractionation for treatment of early breast cancer: a randomised trial. Lancet. 2008/03/22 ed. 2008;371(9618):1098–107. doi:10.1016/S0140-6736(08)60348-7  
75. Murray Brunt A, Haviland JS, Wheatley DA, Sydenham MA, Alhasso A, Bloomfield DJ, et al. Hypofractionated breast radiotherapy for 1 week versus 3 weeks (FAST-Forward): 5-year efficacy and late normal tissue effects results from a multicentre, non-inferiority, randomised, phase 3 trial. Lancet. 2020/06/26 ed. 2020;395(10237):1613–26. doi:10.1016/S01406736(20)30932-6  
76. SBRT BS of R, Freitas NMA, Rosa AA, Marta GN, Hanna SA, Hanriot RM, et al. Recommendations for hypofractionated whole-breast irradiation. Rev Assoc Med Bras (1992). 2019/01/24 ed. 2018;64(9):770–7. doi:10.1590/18069282.64.09.770  
77. Kunkler IH, Williams LJ, Jack W, Cameron DA, Dixon M. Abstract GS2-03: Prime 2 randomised trial (postoperative radiotherapy in minimum-risk elderly): Wide local excision and adjuvant hormonal therapy +/- whole breast irradiation in women =/> 65 years with early invasive breast cancer: 10 year results. Cancer Research. 2021;81(4_Supplement):GS2-03. doi:10.1158/1538-7445.Sabcs20-gs2-03  
78. Biganzoli L, Wildiers H, Oakman C, Marotti L, Loibl S, Kunkler I, et al. Management of elderly patients with breast cancer: updated recommendations of the International Society of Geriatric Oncology (SIOG) and European Society of Breast Cancer Specialists (EUSOMA). Lancet Oncol. 2012/04/04 ed. 2012;13(4):e148-60. doi:10.1016/S1470-2045(11)70383-7  
79. Yee C, Alayed Y, Drost L, Karam I, Vesprini D, McCann C, et al. Radiotherapy for patients with unresected locally advanced breast cancer. Ann Palliat Med. 2018/09/06 ed. 2018;7(4):373–84. doi:10.21037/apm.2018.05.13  
80. Grewal AS, Freedman GM, Jones JA, Taunk NK. Hypofractionated radiation therapy for durable palliative treatment of bleeding, fungating breast cancers. Pract Radiat Oncol. 2019/01/23 ed. 2019;9(2):73–6. doi:10.1016/j.prro.2018.11.003  
81. Reinbolt RE, Mangini N, Hill JL, Levine LB, Dempsey JL, Singaravelu J, et al. Endocrine therapy in breast cancer: the neoadjuvant, adjuvant, and metastatic approach. Semin Oncol Nurs. 2015/05/09 ed. 2015;31(2):146–55. doi:10.1016/j.soncn.2015.02.002  
82. Gradishar W et al. NCCN Guidelines for Breast Cancer [Internet]. 2024. Disponível em: https://www.nccn.org/professionals/physician_gls/pdf/breast.pdf  
83. Pagani O, Regan MM, Walley BA, Fleming GF, Colleoni M, Lang I, et al. Adjuvant exemestane with ovarian suppression in premenopausal breast cancer. N Engl J Med. 2014/06/03 ed. 2014;371(2):107–18. doi:10.1056/NEJMoa1404037  
84. Hartkopf AD, Grischke EM, Brucker SY. Endocrine-Resistant Breast Cancer: Mechanisms and Treatment. Breast Care (Basel). 2020/09/29 ed. 2020;15(4):347–54. doi:10.1159/000508675  
85. Early Breast Cancer Trialists’ Collaborative G. Long-term outcomes for neoadjuvant versus adjuvant chemotherapy in early breast cancer: meta-analysis of individual patient data from ten randomised trials. Lancet Oncol. 2017/12/16 ed. 2018;19(1):27–39. doi:10.1016/S1470-2045(17)30777-5  
86. Cortazar P, Zhang L, Untch M, Mehta K, Costantino JP, Wolmark N, et al. Pathological complete response and longterm clinical benefit in breast cancer: the CTNeoBC pooled analysis. Lancet. 2014/02/18 ed. 2014;384(9938):164–72. doi:10.1016/S0140-6736(13)62422-8  
87. Guarneri V, Broglio K, Kau SW, Cristofanilli M, Buzdar AU, Valero V, et al. Prognostic value of pathologic complete response after primary chemotherapy in relation to hormone receptor status and other factors. J Clin Oncol. 2006/03/01 ed. 2006;24(7):1037–44. doi:10.1200/JCO.2005.02.6914  
88. Masuda N et al. Neoadjuvant anastrozole versus tamoxifen in patients receiving goserelin for premenopausal breast cancer (STAGE): a double-blind, randomised phase 3 trial. The Lancet Oncology, 13(4), 345–352. doi:https://doi.org/10.1016/S1470-2045(11)70373-4  
89. Fontein D et al. Efficacy of six month neoadjuvant endocrine therapy in postmenopausal, hormone receptor-positive breast cancer patients--a phase II trial. European journal of cancer (Oxford, England : 1990), 50(13), 2190–2200. doi:https://doi.org/10.1016/j.ejca.2014.05.010  
90. Eiermann W, Paepke S, Appfelstaedt J, Llombart-Cussac A, Eremin J, Vinholes J, et al. Preoperative treatment of postmenopausal breast cancer patients with letrozole: A randomized double-blind multicenter study. Ann Oncol. 2002/02/02 ed. 2001;12(11):1527–32. doi:10.1023/a:1013128213451  
91. Alba E, Calvo L, Albanell J, De la Haba JR, Arcusa Lanza A, Chacon JI, et al. Chemotherapy (CT) and hormonotherapy (HT) as neoadjuvant treatment in luminal breast cancer patients: results from the GEICAM/2006-03, a multicenter, randomized, phase-II study. Ann Oncol. 2012/06/08 ed. 2012;23(12):3069–74. doi:10.1093/annonc/mds132  
92. Early Breast Cancer Trialists’ Collaborative G. Effects of chemotherapy and hormonal therapy for early breast cancer on recurrence and 15-year survival: an overview of the randomised trials. Lancet. 2005/05/17 ed. 2005;365(9472):1687–717. doi:10.1016/S0140-6736(05)66544-0  
93. Early Breast Cancer Trialists’ Collaborative G, Peto R, Davies C, Godwin J, Gray R, Pan HC, et al. Comparisons between different polychemotherapy regimens for early breast cancer: meta-analyses of long-term outcome among 100,000 women in 123 randomised trials. Lancet. 2011/12/14 ed. 2012;379(9814):432–44. doi:10.1016/S0140-6736(11)61625-5  
94. Early Breast Cancer Trialists’ Collaborative G. Increasing the dose intensity of chemotherapy by more frequent administration or sequential scheduling: a patient-level meta-analysis of 37 298 women with early breast cancer in 26 randomised trials. Lancet. 2019/02/12 ed. 2019;393(10179):1440–52. doi:10.1016/S0140-6736(18)33137-4  
95. Jones S, Holmes FA, O’Shaughnessy J, Blum JL, Vukelja SJ, McIntyre KJ, et al. Docetaxel With Cyclophosphamide Is Associated With an Overall Survival Benefit Compared With Doxorubicin and Cyclophosphamide: 7-Year Follow-Up of US Oncology Research Trial 9735. J Clin Oncol. 2009/02/11 ed. 2009;27(8):1177–83. doi:10.1200/JCO.2008.18.4028  
96. Ferguson T, Wilcken N, Vagg R, Ghersi D, Nowak AK. Taxanes for adjuvant treatment of early breast cancer. Cochrane Database Syst Rev. 2007/10/19 ed. 2007;(4):CD004421–CD004421. doi:10.1002/14651858.CD004421.pub2  
97. Jones SE, Savin MA, Holmes FA, O’Shaughnessy JA, Blum JL, Vukelja S, et al. Phase III trial comparing doxorubicin plus cyclophosphamide with docetaxel plus cyclophosphamide as adjuvant therapy for operable breast cancer. J Clin Oncol. 2006/12/01 ed. 2006;24(34):5381–7. doi:10.1200/JCO.2006.06.5391  
98. Dackus G, Jozwiak K, Sonke GS, van der Wall E, van Diest PJ, Siesling S, et al. Adjuvant Aromatase Inhibitors or Tamoxifen Following Chemotherapy for Perimenopausal Breast Cancer Patients. J Natl Cancer Inst. 2021/06/09 ed. 2021;113(11):1506–14. doi:10.1093/jnci/djab091  
99. Klar N, Adams S. RE: Adjuvant Aromatase Inhibitors or Tamoxifen Following Chemotherapy for Perimenopausal Breast Cancer Patients. J Natl Cancer Inst. 2021/08/17 ed. 2022;114(1):165–6. doi:10.1093/jnci/djab152  
100. Kim HJ, Noh WC, Nam SJ, Park BW, Lee ES, Im SA, et al. Five-year changes in ovarian function restoration in premenopausal patients with breast cancer taking tamoxifen after chemotherapy: An ASTRRA study report. Eur J Cancer. 2021/05/20 ed. 2021;151:190–200. doi:10.1016/j.ejca.2021.03.017  
101. Tevaarwerk AJ, Wang M, Zhao F, Fetting JH, Cella D, Wagner LI, et al. Phase III comparison of tamoxifen versus tamoxifen plus ovarian function suppression in premenopausal women with node-negative, hormone receptor-positive breast cancer (E-3193, INT-0142): a trial of the Eastern Cooperative Oncology Group. J Clin Oncol. 2014/10/29 ed. 2014;32(35):3948–58. doi:10.1200/JCO.2014.55.6993  
102. Francis PA, Pagani O, Fleming GF, Walley BA, Colleoni M, Lang I, et al. Tailoring Adjuvant Endocrine Therapy for Premenopausal Breast Cancer. N Engl J Med. 2018/06/05 ed. 2018;379(2):122–37. doi:10.1056/NEJMoa1803164  
103. Tjan-Heijnen VCG, van Hellemond IEG, Peer PGM, Swinkels ACP, Smorenburg CH, van der Sangen MJC, et al. Extended adjuvant aromatase inhibition after sequential endocrine therapy (DATA): a randomised, phase 3 trial. Lancet Oncol. 2017/10/17 ed. 2017;18(11):1502–11. doi:10.1016/S1470-2045(17)30600-9  
104. Goss PE, Ingle JN, Martino S, Robert NJ, Muss HB, Piccart MJ, et al. A randomized trial of letrozole in postmenopausal women after five years of tamoxifen therapy for early-stage breast cancer. N Engl J Med. 2003/10/11 ed. 2003;349(19):1793–802. doi:10.1056/NEJMoa032312  
105. Early Breast Cancer Trialists’ Collaborative G. Aromatase inhibitors versus tamoxifen in early breast cancer: patientlevel meta-analysis of the randomised trials. Lancet. 2015/07/28 ed. 2015;386(10001):1341–52. doi:10.1016/S01406736(15)61074-1  
106. Burstein HJ, Curigliano G, Loibl S, Dubsky P, Gnant M, Poortmans P, et al. Estimating the benefits of therapy for early-stage breast cancer: the St. Gallen International Consensus Guidelines for the primary therapy of early breast cancer 2019. Ann Oncol. 2019/08/03 ed. 2019;30(10):1541–57. doi:10.1093/annonc/mdz235  
107. Pan H, Gray R, Braybrooke J, Davies C, Taylor C, McGale P, et al. 20-Year Risks of Breast-Cancer Recurrence after Stopping Endocrine Therapy at 5 Years. N Engl J Med. 2017/11/09 ed. 2017;377(19):1836–46. doi:10.1056/NEJMoa1701830  
108. Laenkholm AV, Jensen MB, Eriksen JO, Rasmussen BB, Knoop AS, Buckingham W, et al. PAM50 Risk of Recurrence Score Predicts 10-Year Distant Recurrence in a Comprehensive Danish Cohort of Postmenopausal Women Allocated to 5 Years of Endocrine Therapy for Hormone Receptor-Positive Early Breast Cancer. J Clin Oncol. 2018/01/26 ed. 2018;36(8):735–40. doi:10.1200/JCO.2017.74.6586  
109. Blok EJ, Kroep JR, Meershoek-Klein Kranenbarg E, Duijm-de Carpentier M, Putter H, Liefers GJ, et al. Treatment decisions and the impact of adverse events before and during extended endocrine therapy in postmenopausal early breast cancer. Eur J Cancer. 2018/04/11 ed. 2018;95:59–67. doi:10.1016/j.ejca.2018.03.014  
110. Davies C, Pan H, Godwin J, Gray R, Arriagada R, Raina V, et al. Long-term effects of continuing adjuvant tamoxifen to 10 years versus stopping at 5 years after diagnosis of oestrogen receptor-positive breast cancer: ATLAS, a randomised trial. Lancet. 2012/12/12 ed. 2013;381(9869):805–16. doi:10.1016/S0140-6736(12)61963-1  
111. Goss PE. Changing clinical practice: extending the benefits of adjuvant endocrine therapy in breast cancer. Semin Oncol. 2005/02/22 ed. 2004;31(6 Suppl 12):15–22. doi:10.1053/j.seminoncol.2004.09.022  
112. Goss PE, Ingle JN, Pritchard KI, Robert NJ, Muss H, Gralow J, et al. Extending Aromatase-Inhibitor Adjuvant Therapy to 10 Years. N Engl J Med. 2016/06/07 ed. 2016;375(3):209–19. doi:10.1056/NEJMoa1604700  
113. Gianni L, Eiermann W, Semiglazov V, Manikhas A, Lluch A, Tjulandin S, et al. Neoadjuvant chemotherapy with trastuzumab followed by adjuvant trastuzumab versus neoadjuvant chemotherapy alone, in patients with HER2-positive locally advanced breast cancer (the NOAH trial): a randomised controlled superiority trial with a parallel HER2-negative cohort. Lancet. 2010/02/02 ed. 2010;375(9712):377–84. doi:10.1016/S0140-6736(09)61964-4  
114. Slamon D, Eiermann W, Robert N, Pienkowski T, Martin M, Press M, et al. Adjuvant trastuzumab in HER2-positive breast cancer. N Engl J Med. 2011/10/14 ed. 2011;365(14):1273–83. doi:10.1056/NEJMoa0910383  
115. Gnant M, Fitzal F, Rinnerthaler G, Steger GG, Greil-Ressler S, Balic M, et al. Duration of Adjuvant AromataseInhibitor Therapy in Postmenopausal Breast Cancer. N Engl J Med. 2021/07/29 ed. 2021;385(5):395–405. doi:10.1056/NEJMoa2104162  
116. Klapper LN, Glathe S, Vaisman N, Hynes NE, Andrews GC, Sela M, et al. The ErbB-2/HER2 oncoprotein of human carcinomas may function solely as a shared coreceptor for multiple stroma-derived growth factors. Proc Natl Acad Sci U S A. 1999/04/29 ed. 1999;96(9):4995–5000. doi:10.1073/pnas.96.9.4995  
117. Petit AM, Rak J, Hung MC, Rockwell P, Goldstein N, Fendly B, et al. Neutralizing antibodies against epidermal growth factor and ErbB-2/neu receptor tyrosine kinases down-regulate vascular endothelial growth factor production by tumor cells in vitro and in vivo: angiogenic implications for signal transduction therapy of solid tumors. Am J Pathol. 1997/12/24 ed. 1997;151(6):1523–30.  
118. Piccart-Gebhart MJ, Procter M, Leyland-Jones B, Goldhirsch A, Untch M, Smith I, et al. Trastuzumab after adjuvant chemotherapy in HER2-positive breast cancer. N Engl J Med. 2005/10/21 ed. 2005;353(16):1659–72. doi:10.1056/NEJMoa052306  
119. Romond EH, Perez EA, Bryant J, Suman VJ, Geyer Jr. CE, Davidson NE, et al. Trastuzumab plus adjuvant chemotherapy for operable HER2-positive breast cancer. N Engl J Med. 2005/10/21 ed. 2005;353(16):1673–84. doi:10.1056/NEJMoa052122  
120. Joensuu H, Kellokumpu-Lehtinen PL, Bono P, Alanko T, Kataja V, Asola R, et al. Adjuvant docetaxel or vinorelbine with or without trastuzumab for breast cancer. N Engl J Med. 2006/02/24 ed. 2006;354(8):809–20. doi:10.1056/NEJMoa053028  
121. Spielmann M, Roche H, Delozier T, Canon JL, Romieu G, Bourgeois H, et al. Trastuzumab for patients with axillarynode-positive breast cancer: results of the FNCLCC-PACS 04 trial. J Clin Oncol. 2009/11/18 ed. 2009;27(36):6129–34. doi:10.1200/JCO.2009.23.0946  
122. Yaziji H, Goldstein LC, Barry TS, Werling R, Hwang H, Ellis GK, et al. HER-2 testing in breast cancer using parallel tissue-based methods. JAMA. 2004/04/29 ed. 2004;291(16):1972–7. doi:10.1001/jama.291.16.1972  
123. Petrelli F, Borgonovo K, Cabiddu M, Ghilardi M, Barni S. Neoadjuvant chemotherapy and concomitant trastuzumab in breast cancer: a pooled analysis of two randomized trials. Anticancer Drugs. 2011/01/11 ed. 2011;22(2):128–35. doi:10.1097/cad.0b013e32834120aa  
124. Tolaney SM, Guo H, Pernas S, Barry WT, Dillon DA, Ritterhouse L, et al. Seven-Year Follow-Up Analysis of Adjuvant Paclitaxel and Trastuzumab Trial for Node-Negative, Human Epidermal Growth Factor Receptor 2-Positive Breast Cancer. J Clin Oncol. 2019/04/03 ed. 2019;37(22):1868–75. doi:10.1200/JCO.19.00066  
125. von Minckwitz G, Huang CS, Mano MS, Loibl S, Mamounas EP, Untch M, et al. Trastuzumab Emtansine for Residual Invasive HER2-Positive Breast Cancer. N Engl J Med. 2018/12/06 ed. 2019;380(7):617–28. doi:10.1056/NEJMoa1814017  
126. Brasil. Ministério da Saúde. Secretaria de Ciência T e IEstratégicosCN de I de T– CONITEC. Trastuzumabe entansina no tratamento adjuvante do câncer de mama HER2-positivo operado em estádio III com doença residual na peça cirúrgica após tratamento neoadjuvante [Internet]. 2022. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220912_relatorio_751_transtuzumabe_entancila.pdf  
127. Griggs JJ, Mangu PB, Anderson H, Balaban EP, Dignam JJ, Hryniuk WM, et al. Appropriate chemotherapy dosing for obese adult patients with cancer: American Society of Clinical Oncology clinical practice guideline. J Clin Oncol. 2012/04/05 ed. 2012;30(13):1553–61. doi:10.1200/JCO.2011.39.9436  
128. Shah AD, Mehta AK, Talati N, Brem R, Margolies LR. Breast tissue markers: Why? What’s out there? How do I choose? Clin Imaging. 2018/07/31 ed. 2018;52:123–36. doi:10.1016/j.clinimag.2018.07.003  
129. Thomassin-Naggara I, Lalonde L, David J, Darai E, Uzan S, Trop I. A plea for the biopsy marker: how, why and why not clipping after breast biopsy? Breast Cancer Res Treat. 2011/11/02 ed. 2012;132(3):881–93. doi:10.1007/s10549-011-1847x  
130. Biganzoli L, Marotti L, Hart CD, Cataliotti L, Cutuli B, Kuhn T, et al. Quality indicators in breast cancer care: An update from the EUSOMA working group. Eur J Cancer. 2017/10/01 ed. 2017;86:59–81. doi:10.1016/j.ejca.2017.08.017  
131. Oh JL, Nguyen G, Whitman GJ, Hunt KK, Yu TK, Woodward WA, et al. Placement of radiopaque clips for tumor localization in patients undergoing neoadjuvant chemotherapy and breast conservation therapy. Cancer. 2007/10/18 ed. 2007;110(11):2420–7. doi:10.1002/cncr.23068  
132. Cardonick E, Iacobucci A. Use of chemotherapy during human pregnancy. Lancet Oncol. 2004/05/04 ed. 2004;5(5):283–91. doi:10.1016/S1470-2045(04)01466-4  
133. Khera SY, Kiluk JV, Hasson DM, Meade TL, Meyers MP, Dupont EL, et al. Pregnancy-associated breast cancer patients can safely undergo lymphatic mapping. Breast J. 2008/05/15 ed. 2008;14(3):250–4. doi:10.1111/j.15244741.2008.00570.x  
134. Blum JL, Flynn PJ, Yothers G, Asmar L, Geyer Jr. CE, Jacobs SA, et al. Anthracyclines in Early Breast Cancer: The ABC Trials-USOR 06-090, NSABP B-46-I/USOR 07132, and NSABP B-49 (NRG Oncology). J Clin Oncol. 2017/04/12 ed. 2017;35(23):2647–55. doi:10.1200/JCO.2016.71.4147  
135. von Minckwitz G, Schneeweiss A, Loibl S, Salat C, Denkert C, Rezai M, et al. Neoadjuvant carboplatin in patients with triple-negative and HER2-positive early breast cancer (GeparSixto; GBG 66): a randomised phase 2 trial. Lancet Oncol. 2014/05/06 ed. 2014;15(7):747–56. doi:10.1016/S1470-2045(14)70160-3  
136. Sikov WM. Assessing the role of platinum agents in aggressive breast cancers. Curr Oncol Rep. 2015/02/11 ed. 2015;17(2):3–3. doi:10.1007/s11912-014-0428-7  
137. Loibl S, Weber KE, Timms KM, Elkin EP, Hahnen E, Fasching PA, et al. Survival analysis of carboplatin added to an anthracycline/taxane-based neoadjuvant chemotherapy and HRD score as predictor of response-final results from GeparSixto. Ann Oncol. 2018/10/20 ed. 2018;29(12):2341–7. doi:10.1093/annonc/mdy460  
138. Hahnen E, Lederer B, Hauke J, Loibl S, Krober S, Schneeweiss A, et al. Germline Mutation Status, Pathological Complete Response, and Disease-Free Survival in Triple-Negative Breast Cancer: Secondary Analysis of the GeparSixto Randomized Clinical Trial. JAMA Oncol. 2017/07/18 ed. 2017;3(10):1378–85. doi:10.1001/jamaoncol.2017.1007  
139. Schmid P, Cortes J, Dent R, Pusztai L, McArthur H, Kummel S, et al. Event-free Survival with Pembrolizumab in Early Triple-Negative Breast Cancer. N Engl J Med. 2022/02/10 ed. 2022;386(6):556–67. doi:10.1056/NEJMoa2112651  
140. Schmid P, Cortes J, Pusztai L, McArthur H, Kummel S, Bergh J, et al. Pembrolizumab for Early Triple-Negative Breast Cancer. N Engl J Med. 2020/02/27 ed. 2020;382(9):810–21. doi:10.1056/NEJMoa1910549  
141. NATIONAL CANCER INSTITUTE (NCI). ClinicalTrials.gov. Bethesda (MD): National Library of Medicine (US), 2000-. Identificador NCT03667262. [Internet]. A Randomized Phase II Trial of De-Escalated Targeted Axillary Therapy in Women With Clinically Node-Positive (cN+) Breast Cancer Who Convert to Node Negative (cN0) After Neoadjuvant Chemotherapy and Are Planned for Breast Conserving Surgery and Radiation (NRG-BR007). Disponível em: https://clinicaltrials.gov/study/NCT04852887  
142. Gralow JR, Burstein HJ, Wood W, Hortobagyi GN, Gianni L, von Minckwitz G, et al. Preoperative therapy in invasive breast cancer: pathologic assessment and systemic therapy issues in operable disease. J Clin Oncol. 2008/02/09 ed. 2008;26(5):814–9. doi:10.1200/JCO.2007.15.3510  
143. Boughey JC, Ballman KV, Le-Petross HT, McCall LM, Mittendorf EA, Ahrendt GM, et al. Identification and Resection of Clipped Node Decreases the False-negative Rate of Sentinel Lymph Node Surgery in Patients Presenting With Node-positive Breast Cancer (T0-T4, N1-N2) Who Receive Neoadjuvant Chemotherapy: Results From ACOSOG Z1071 (Alliance). Ann Surg. 2015/12/10 ed. 2016;263(4):802–7. doi:10.1097/SLA.0000000000001375  
144. Masuda N, Lee SJ, Ohtani S, Im YH, Lee ES, Yokota I, et al. Adjuvant Capecitabine for Breast Cancer after Preoperative Chemotherapy. N Engl J Med. 2017/06/01 ed. 2017;376(22):2147–59. doi:10.1056/NEJMoa1612645  
145. Cardoso F, Wilking N, Bernardini R, Biganzoli L, Espin J, Miikkulainen K, et al. A multi-stakeholder approach in optimising patients’ needs in the benefit assessment process of new metastatic breast cancer treatments. Breast. 2020/05/26 ed. 2020;52:78–87. doi:10.1016/j.breast.2020.04.011  
146. Aurilio G, Disalvatore D, Pruneri G, Bagnardi V, Viale G, Curigliano G, et al. A meta-analysis of oestrogen receptor, progesterone receptor and human epidermal growth factor receptor 2 discordance between primary breast cancer and metastases. Eur J Cancer. 2013/11/26 ed. 2014;50(2):277–89. doi:10.1016/j.ejca.2013.10.004  
147. (Brasil) M da S. Abemaciclibe, palbociclibe e succinato de ribociclibe para o tratamento de pacientes adultas com câncer de mama avançado ou metastático com HR+ e HER2- [Internet]. 2021. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2021/20211207_relatorio_678_abemaciclibe_palbociclibe_ribociclibe_carcinoma_mama_final.pdf  
148. Cardoso F et al. 5th ESO-ESMO international consensus guidelines for advanced breast cancer (ABC 5). Ann Oncol. 2020;31(12):1623–49. doi:10.1016/j.annonc.2020.09.010  
149. SBOC. Diretrizes de tratamentos oncológicos - Mama: doença metastática [Internet]. 2023. Disponível em: https://sboc.org.br/images/diretrizes/diretrizes_pdfs/2023/finalizadas/Diretrizes-SBOC-2023---Mama-avanada-v5-FINAL.pdf  
150. Finn R et al. Palbociclib and Letrozole in Advanced Breast Cancer. New England Journal of Medicine, v 375, n 20, p 1925-1936, 17 nov 2016.  
151. Horton K et al. Ribociclib and letrozole as first-line therapy for hormone receptor–positive, HER2-negative advanced breast cancer: final overall survival analysis of the randomized phase III MONALEESA-2 trial. Annals of Oncology, v 33, n 9, p 891-901, set 2022.  
152. Goyal A et al. Abemaciclib as Initial Therapy for Advanced Breast Cancer. New England Journal of Medicine, v 377, n 21, p 2029-2038, 23 nov 2017.  
153. Gennari A, Stockler M, Puntoni M, Sormani M, Nanni O, Amadori D, et al. Duration of chemotherapy for metastatic breast cancer: a systematic review and meta-analysis of randomized clinical trials. J Clin Oncol. 2011/04/06 ed. 2011;29(16):2144–9. doi:10.1200/JCO.2010.31.5374  
154. Giuliano M, Schettini F, Rognoni C, Milani M, Jerusalem G, Bachelot T, et al. Endocrine treatment versus chemotherapy in postmenopausal women with hormone receptor-positive, HER2-negative, metastatic breast cancer: a systematic review and network meta-analysis. Lancet Oncol. 2019/09/09 ed. 2019;20(10):1360–9. doi:10.1016/S14702045(19)30420-6  
155. Mauri D, Pavlidis N, Polyzos NP, Ioannidis JP. Survival with aromatase inhibitors and inactivators versus standard hormonal therapy in advanced breast cancer: meta-analysis. J Natl Cancer Inst. 2006/09/21 ed. 2006;98(18):1285–91. doi:10.1093/jnci/djj357  
156. Chia S, Gradishar W, Mauriac L, Bines J, Amant F, Federico M, et al. Double-blind, randomized placebo controlled trial of fulvestrant compared with exemestane after prior nonsteroidal aromatase inhibitor therapy in postmenopausal women with hormone receptor-positive, advanced breast cancer: results from EFECT. J Clin Oncol. 2008/03/05 ed. 2008;26(10):1664–70. doi:10.1200/JCO.2007.13.5822  
157. Howell A, Robertson JF, Abram P, Lichinitser MR, Elledge R, Bajetta E, et al. Comparison of fulvestrant versus tamoxifen for the treatment of advanced breast cancer in postmenopausal women previously untreated with endocrine therapy: a multinational, double-blind, randomized trial. J Clin Oncol. 2004/05/01 ed. 2004;22(9):1605–13. doi:10.1200/JCO.2004.02.112  
158. Beresford M, Tumur I, Chakrabarti J, Barden J, Rao N, Makris A. A qualitative systematic review of the evidence base for non-cross-resistance between steroidal and non-steroidal aromatase inhibitors in metastatic breast cancer. Clin Oncol (R Coll Radiol). 2010/12/08 ed. 2011;23(3):209–15. doi:10.1016/j.clon.2010.11.005  
159. Thurlimann B, Robertson JF, Nabholtz JM, Buzdar A, Bonneterre J, Arimidex Study G. Efficacy of tamoxifen following anastrozole ('Arimidex’) compared with anastrozole following tamoxifen as first-line treatment for advanced breast cancer in postmenopausal women. Eur J Cancer. 2003/10/15 ed. 2003;39(16):2310–7. doi:10.1016/s0959-8049(03)00602-6  
160. Malorni L, Curigliano G, Minisini AM, Cinieri S, Tondini CA, D’Hollander K, et al. Palbociclib as single agent or in combination with the endocrine therapy received before disease progression for estrogen receptor-positive, HER2-negative metastatic breast cancer: TREnd trial. Ann Oncol. 2018/06/13 ed. 2018;29(8):1748–54. doi:10.1093/annonc/mdy214  
161. Hamilton E, Cortes J, Dieras V, Ozyilkan O, Chen SC, Petrakova K, et al. NextMONARCH 1: Phase 2 study of abemaciclib plus tamoxifen or abemaciclib alone in HR+, HER2-advanced breast cancer. Cancer Research. 2019;79(4). doi:10.1158/15387445.SABCS18-PD1-11  
162. Andre F, Ciruelos EM, Juric D, Loibl S, Campone M, Mayer IA, et al. Alpelisib plus fulvestrant for PIK3CAmutated, hormone receptor-positive, human epidermal growth factor receptor-2-negative advanced breast cancer: final overall survival results from SOLAR-1. Ann Oncol. 2020/11/28 ed. 2021;32(2):208–17. doi:10.1016/j.annonc.2020.11.011  
163. Andre F, Ciruelos E, Rubovszky G, Campone M, Loibl S, Rugo HS, et al. Alpelisib for PIK3CA-Mutated, Hormone Receptor-Positive Advanced Breast Cancer. N Engl J Med. 2019/05/16 ed. 2019;380(20):1929–40. doi:10.1056/NEJMoa1813904  
164. De Placido S, Giuliano M, Schettini F, Von Arx C, Buono G, Riccardi F, et al. Human epidermal growth factor receptor 2 dual blockade with trastuzumab and pertuzumab in real life: Italian clinical practice versus the CLEOPATRA trial results. Breast. 2017/12/30 ed. 2018;38:86–91. doi:10.1016/j.breast.2017.12.012  
165. Swain SM, Miles D, Kim SB, Im YH, Im SA, Semiglazov V, et al. Pertuzumab, trastuzumab, and docetaxel for HER2-positive metastatic breast cancer (CLEOPATRA): end-of-study results from a double-blind, randomised, placebocontrolled, phase 3 study. Lancet Oncol. 2020/03/17 ed. 2020;21(4):519–30. doi:10.1016/S1470-2045(19)30863-0  
166. Swain SM, Baselga J, Kim SB, Ro J, Semiglazov V, Campone M, et al. Pertuzumab, trastuzumab, and docetaxel in HER2-positive metastatic breast cancer. N Engl J Med. 2015/02/19 ed. 2015;372(8):724–34. doi:10.1056/NEJMoa1413513  
167. Frich L, Hagen G, Brabrand K, Edwin B, Mathisen O, Aaløkken TM, et al. Local tumor progression after radiofrequency ablation of colorectal liver metastases: evaluation of ablative margin and three-dimensional volumetric analysis. J Vasc Interv Radiol. 2007/09/07 ed. 2007;18(9):1134–40. doi:10.1016/j.jvir.2007.06.007  
168. Urruticoechea A, Rizwanullah M, Im SA, Ruiz ACS, Lang I, Tomasello G, et al. Randomized Phase III Trial of Trastuzumab Plus Capecitabine With or Without Pertuzumab in Patients With Human Epidermal Growth Factor Receptor 2- Positive Metastatic Breast Cancer Who Experienced Disease Progression During or After Trastuzumab-Based Therapy. J Clin Oncol. 2017/04/25 ed. 2017;35(26):3030–8. doi:10.1200/JCO.2016.70.6267  
169. Geyer CE, Forster J, Lindquist D, Chan S, Romieu CG, Pienkowski T, et al. Lapatinib plus capecitabine for HER2positive advanced breast cancer. N Engl J Med. 2006/12/29 ed. 2006;355(26):2733–43. doi:10.1056/NEJMoa064320  
170. Balduzzi S, Mantarro S, Guarneri V, Tagliabue L, Pistotti V, Moja L, et al. Trastuzumab-containing regimens for metastatic breast cancer. Cochrane Database Syst Rev. 2014/06/13 ed. 2014;(6):CD006242–CD006242. doi:10.1002/14651858.CD006242.pub2  
171. Cortes J, Kim SB, Chung WP, Im SA, Park YH, Hegg R, et al. Trastuzumab Deruxtecan versus Trastuzumab Emtansine for Breast Cancer. N Engl J Med. 2022/03/24 ed. 2022;386(12):1143–54. doi:10.1056/NEJMoa2115022  
172. Guan Z, Xu B, DeSilvio ML, Shen Z, Arpornwirat W, Tong Z, et al. Randomized trial of lapatinib versus placebo added to paclitaxel in the treatment of human epidermal growth factor receptor 2-overexpressing metastatic breast cancer. J Clin Oncol. 2013/03/20 ed. 2013;31(16):1947–53. doi:10.1200/JCO.2011.40.5241  
173. Di Leo A, Gomez HL, Aziz Z, Zvirbule Z, Bines J, Arbushites MC, et al. Phase III, double-blind, randomized study comparing lapatinib plus paclitaxel with placebo plus paclitaxel as first-line treatment for metastatic breast cancer. J Clin Oncol. 2008/10/29 ed. 2008;26(34):5544–52. doi:10.1200/JCO.2008.16.2578  
174. Tutt A, Tovey H, Cheang MCU, Kernaghan S, Kilburn L, Gazinska P, et al. Carboplatin in BRCA1/2-mutated and triple-negative breast cancer BRCAness subgroups: the TNT Trial. Nat Med. 2018/05/02 ed. 2018;24(5):628–37. doi:10.1038/s41591-018-0009-7  
175. Cortes J, Rugo HS, Cescon DW, Im SA, Yusof MM, Gallardo C, et al. Pembrolizumab plus Chemotherapy in Advanced Triple-Negative Breast Cancer. N Engl J Med. 2022/07/21 ed. 2022;387(3):217–26. doi:10.1056/NEJMoa2202809  
176. Cortes J, Cescon DW, Rugo HS, Nowecki Z, Im SA, Yusof MM, et al. Pembrolizumab plus chemotherapy versus placebo plus chemotherapy for previously untreated locally recurrent inoperable or metastatic triple-negative breast cancer (KEYNOTE-355): a randomised, placebo-controlled, double-blind, phase 3 clinical trial. Lancet. 2020/12/07 ed. 2020;396(10265):1817–28. doi:10.1016/S0140-6736(20)32531-9  
177. Robson M Senkus E Xu B Domchek SM Masuda N Delaloge S Li W Tung N Armstrong A Wu W Goessl C Runswick S Conte P ISA. Olaparib for Metastatic Breast Cancer in Patients with a Germline BRCA Mutation. N Engl J Med. 2017/08/10 ed. 2017;377(17):1700–1700. doi:10.1056/NEJMx170012  
178. Coleman R, Hadji P, Body JJ, Santini D, Chow E, Terpos E, et al. Bone health in cancer: ESMO Clinical Practice Guidelines. Ann Oncol. 2020/08/18 ed. 2020;31(12):1650–63. doi:10.1016/j.annonc.2020.07.019  
179. Coleman RE, Croucher PI, Padhani AR, Clezardin P, Chow E, Fallon M, et al. Bone metastases. Nat Rev Dis Primers. 2020/10/17 ed. 2020;6(1):83–83. doi:10.1038/s41572-020-00216-3  
180. Cain H, Macpherson IR, Beresford M, Pinder SE, Pong J, Dixon JM. Neoadjuvant Therapy in Early Breast Cancer: Treatment Considerations and Common Debates in Practice. Clin Oncol (R Coll Radiol). 2017/07/04 ed. 2017;29(10):642–52. doi:10.1016/j.clon.2017.06.003  
181. Cardoso F, Costa A, Senkus E, Aapro M, Andre F, Barrios CH, et al. 3rd ESO-ESMO international consensus guidelines for Advanced Breast Cancer (ABC 3). Breast. 2016/12/09 ed. 2017;31:244–59. doi:10.1016/j.breast.2016.10.001  
182. Martin M, Esteva FJ, Alba E, Khandheria B, Perez-Isla L, Garcia-Saenz JA, et al. Minimizing cardiotoxicity while optimizing treatment efficacy with trastuzumab: review and expert recommendations. Oncologist. 2009/01/17 ed. 2009;14(1):1–11. doi:10.1634/theoncologist.2008-0137  
183. Moja L, Tagliabue L, Balduzzi S, Parmelli E, Pistotti V, Guarneri V, et al. Trastuzumab containing regimens for early breast cancer. Cochrane Database Syst Rev. 2012/04/20 ed. 2012;(4):CD006243–CD006243. doi:10.1002/14651858.CD006243.pub2  
184. Procter M, Suter TM, de Azambuja E, Dafni U, van Dooren V, Muehlbauer S, et al. Longer-term assessment of trastuzumab-related cardiac adverse events in the Herceptin Adjuvant (HERA) trial. J Clin Oncol. 2010/06/10 ed. 2010;28(21):3422–8. doi:10.1200/JCO.2009.26.0463  
185. Curigliano G, de Azambuja E, Lenihan D, Calabro MG, Cardinale D, Cipolla CM. Prevention, Monitoring, and Management of Cardiac Dysfunction in Patients with Metastatic Breast Cancer. Oncologist. 2019/05/09 ed. 2019;24(11):e1034–43. doi:10.1634/theoncologist.2018-0773  
186. SOCIEDADE BRASILEIRA DE CARDIOLOGIA (SBC) et al. Diretriz Brasileira de Cardio-Oncologia. Arquivos Brasileiros de Cardiologia, São Paulo, v 115, n 4, p 876-901, out 2020 [Internet]. Disponível em: https://abccardiol.org/wpcontent/uploads/2020/09/AOP-diretriz-cardio-oncologia-portugues.x12760.pdf . Acesso em: 03 de dezembro de 2025.  
187. Ewer M, Vooletich M, Durand J et al. Reversibility of trastuzumab-related cardiotoxicity: new insights based on clinical course and response to medical treatment. J Clin Oncol ; 2005;23(31):7820–7826.  
188. Committee on Practice BG. ACOG Practice Bulletin No. 126: Management of gynecologic issues in women with breast cancer. Obstet Gynecol. 2012/02/23 ed. 2012;119(3):666–82. doi:10.1097/AOG.0b013e31824e12ce  
189. Shapiro CL. Osteoporosis: A Long-Term and Late-Effect of Breast Cancer Treatments. Cancers (Basel). 2020/10/30 ed. 2020;12(11). doi:10.3390/cancers12113094  
190. Matthews A, Stanway S, Farmer RE, Strongman H, Thomas S, Lyon AR, et al. Long term adjuvant endocrine therapy and risk of cardiovascular disease in female breast cancer survivors: systematic review. Bmj. 2018/10/10 ed. 2018;363:k3845– k3845. doi:10.1136/bmj.k3845  
**APÊNDICE 1 - METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Alteração pós publicação** -->
Depois da publicação, por meio da Portaria Conjunta SAES/SECTICS/MS nº 17/2024, retificada em 05/12/2024, a Coordenação-Geral de Prevenção e Controle do Câncer (CGCAN/DECAN/SAES/MS) solicitou ajustes no Protocolo Clínico e Diretrizes Terapêuticas do Câncer de Mama, pela necessidade de revisar formatação, corrigir referências e melhorar a redação das recomendações dispostas. Quando necessário, o termo axila foi substituído por linfonodo axilar e o termo cosmético alterado por estético.  
Seguem os ajustes realizados:  
No item 4.1 Rastreamento, foi acrescida a frase “A autopalpação das mamas sem alterações não dispensa a mulher de 50 a 74 anos, de submeter-se à mamografia de rastreamento”.  
No item 4.2.2. Diagnóstico histopatológico e molecular, foi acrescida a frase “Se houver discordância entre a positividade de receptor hormonal entre a biópsia da mama, a peça cirúrgica do tumor primário ou biópsia da metástase, deve-se considerar que a paciente apresenta positividade para receptores hormonais (RH) e deve ser encaminhada para tratamento direcionado. Importante reforçar que a biópsia óssea negativa para receptores hormonais pode se tratar de um falso negativo, portanto, devese priorizar outros sítios de biópsia quando possível”.  
No item 4.4. Avaliação diagnóstica e complementar, a frase “Nos casos de pacientes com FA aumentada, com dores ósseas ou a partir do estádio IIB, recomenda-se realizar também a cintilografia óssea e a ultrassonografia (US) abdominal. A tomografia computadorizada (TC) de tórax e abdômen superior podem ser acrescentadas na avaliação dos pacientes a partir do estádio IIB” foi substituída por “Nos estadios iniciais, a realização de ultrassom de abdome pode ser adicionada para estadiamento. A tomografia computadorizada (TC) de tórax e abdômen superior podem ser acrescentadas na avaliação dos pacientes a partir do estádio IIB. Já a cintilografia óssea está indicada a partir do estádio IIB ou se houver dores ósseas e FA aumentada em pacientes nos estadios iniciais”.  
A frase “A ressonância magnética (RM) não faz parte da rotina de estadiamento, nem de seguimento pós-tratamento. No entanto, em casos específicos, podem ser utilizados para complementar o diagnóstico de doença na síndrome de compressão medular e na metástase cerebral” foi substituída por “A ressonância magnética (RM) da mama não faz parte da rotina de estadiamento, nem de seguimento pós-tratamento. No entanto, pode ser indicada em situações clínicas específicas. A RM pode ser necessária para avaliação de metástases no Sistema nervoso central e para complementar o diagnóstico de doença na síndrome de compressão medular”.  
O trecho que descreve a calculadora de risco PREDICT foi movido da seção 9.3 Critérios para optar pela neoadjuvância para a seção 4.5 Classificação do risco de recidiva.  
No item 8.1.1. Avaliação dos linfonodos axilares, o trecho “Estudos mostraram que a ressecção do tumor primário com margens negativas pode reduzir o risco de morte mesmo para as pacientes com estádio IV. Um estudo retrospectivo, que avaliou 3.956 pacientes com câncer de mama e metástase óssea, corroborou os resultados dos estudos já citados. A sobrevida global no grupo de cirurgia foi de 50 meses versus 31 meses no grupo de não cirurgia18. Porém, esta prática não está preconizada para o tratamento de pacientes com doença metastática, até que estudos prospectivos em curso confirmem estes achados” foi alterado para “Estudos que avaliaram os benefícios da ressecção do tumor primário em pacientes em estádio IV possuem dados conflitantes. Por isso, atualmente recomenda-se a cirurgia do tumor primário na doença avançada em casos em que há sintomas a serem paliados, como dor, sangramento e ulcerações”.  
No item 9.2. Hormonioterapia, foi acrescida a frase “A supressão ovariana é indicada para pacientes com maior risco clínico, como aquelas que receberam quimioterapia adjuvante e as pacientes mais jovens (<35 anos)”.  
No item 9.3. Critérios para optar pela neoadjuvância, a frase “Para pacientes com progressão da doença durante o tratamento neoadjuvante, a cirurgia deve ser considerada” foi alterada para “Para pacientes com progressão da doença durante o tratamento neoadjuvante, a cirurgia deve ser indicada”.  
Além disso, a frase “Em regra, também deverá ser realizada por 6 meses, sendo que justificadas circurstâncias excepcionais podem motivar ampliação do período de neoadjuvância por até 12 meses” foi alterada para “Caso após 6 meses, o paciente seja considerado inoperável por condições clínicas (idade, performance status, comorbidades, morbidade cirúrgica), a prescrição de hormonioterapia pode ser realizada como doença avançada”.  
Em substituição ao trecho sobre a calculadora de risco PREDICT, transferida para a seção 4.5 Classificação de risco de recidiva, foi acrescida a frase “Estas informações são potenciais fatores prognósticos de recidiva ou mortalidade e devem ser, preferencialmente, adicionadas nas calculadoras de risco, para auxílio no direcionamento do tratamento”.  
Ainda no item 9.3, a idade foi acrescida aos critérios que apoiam a escolha do tratamento sistêmico.  
No item 9.5 Doença inicial ou localmente avançada (estádios I a III), a frase “O tratamento sistêmico das pacientes com tumores iniciais ou localmente avançados compreende a quimioterapia e hormonioterapia que podem ser realizadas antes da cirurgia do tumor primário (neoadjuvante) ou após a cirurgia e a radioterapia (adjuvante)” foi alterada para “O tratamento sistêmico das pacientes com tumores iniciais ou localmente avançados compreende o tratamento neoadjuvante, realizado antes da cirurgia do tumor primário e/ou tratamento adjuvante, iniciado após a cirurgia do tumor primário”.  
Foi feito um ajuste nos esquemas descritos nos Quadro 7 e 13, de modo a indicar que o uso de fatores estimulantes de colônias é preconizado nos esquemas que envolvem a dose densa.  
No item 9.5.1.3 Hormonioterapia adjuvante, a frase “A hormonioterapia adjuvante deve ser indicada para pacientes RE+, independente da expressão de HER-2 ou RP RH+, independente da expressão de HER-2, considerando o estado menopausal” foi alterada para “A hormonioterapia adjuvante deve ser indicada para pacientes RH+, com qualquer grau de positividade no resultado do exame de IHQ, independente da expressão de HER-2, considerando o estado menopausal. Quanto maior o escore de positividade na IHQ, maior é o benefício da hormonioterapia”.  
Também foi acrescentada a frase “A Supressão Ovariana está indicada especificamente para pacientes com até 45 anos e com uso prévio de quimioterapia”.  
No Quadro 11, foi excluída a frase da nota 2 “Assim, os esquemas TCHP (durante seis ciclos) ou AC-THP (durante quatro ciclos) de forma neoadjuvante, aos moldes dos tratamentos realizados de forma adjuvante, são esquemas aceitáveis”.  
No item 9.5.2.2. Tratamento sistêmico adjuvante, a frase “O tratamento padrão utilizado de maneira adjuvante constituise de quimioterapia, baseada ou não em antraciclinas, e hormonioterapia adjuvante” foi alterada para “O tratamento padrão utilizado de maneira adjuvante constitui-se de quimioterapia, baseada ou não em antraciclinas, seguido de hormonioterapia adjuvante, quando o tumor também for RH positivo”.  
No item 9.5.3.2. Cirurgia pós tratamento sistêmico neoadjuvante, o trecho “, com tumores maiores que 0,5 cm ou axila positiva” foi excluído da frase “Após o tratamento neoadjuvante de pacientes com câncer de mama triplo negativo, com tumores maiores que 0,5 cm ou axila positiva, a cirurgia está indicada”.  
No Quadro 15, a dose de fulvestranto foi corrigida para 500 mg a cada 28 dias.  
No item 9.6.4 Câncer de mama avançado HER-2 positivo, o trecho “(neoadjuvante e adjuvante)” foi excluído da frase “Caso as pacientes expressem HER-2 e sejam RH+, elas também são candidatas à hormonioterapia (neoadjuvante e adjuvante), descritas no item anterior”.  
No item 10.3. Critérios de interrupção do tratamento, o trecho referente ao monitoramento do trastuzumabe, incluindo a Figura 1, foi substituído por “Em pacientes com Fração de Ejeção (FE) normal, o monitoramento da função cardíaca com ecocardiograma durante o uso de trastuzumabe deve ser realizado a cada 3 meses. Em pacientes com alteração de FE ou FE limítrofe (50% a 55%), a periodicidade de monitoramento ecocardiográfico deve seguir as recomendações da Diretriz Brasileira  
de Cardio-oncologia. É importante o seguimento das orientações quanto à periodicidade do ecocardiograma, além da avaliação de sinais e sintomas de insuficiência cardíaca. A cardiotoxicidade do trastuzumabe é reversível na maioria dos casos e envolve a interrupção do uso do medicamento por cerca de 3 semanas. Caso a FE caia de 10 a 15 pontos em relação ao valor inicial ou fique abaixo de 50%, o trastuzumabe pode ser reiniciado. Caso contrário, o tratamento deve ser interrompido definitivamente”.  
O tema foi apresentado como informe à 135ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, ocorrida em abril de 2026, em que foi aprovado pelos membros presentes.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **1. Escopo e finalidade do Protocolo** -->
A elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Câncer de Mama iniciou-se com a demanda oriunda da Secretaria de Atenção Especializada à Saúde para alteração do formato do documento aprovado pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec), por meio do Relatório de Recomendação nº 789, de novembro de 2022, e para incluir orientações sobre os esquemas quimioterápicos a serem preconizados pelo Sistema Único de Saúde.  
Este PCDT aborda os procedimentos e esquemas terapêuticos atualmente disponíveis no Sistema Único de Saúde (SUS). <u>Alguns medicamentos citados no texto não possuem recomendação favorável de incorporação e, portanto, não estão indicados como alternativas terapêuticas no SUS. Os esquemas terapêuticos já incorporados ao SUS estão destacados nos quadros de acordo com as linhas de tratamento. As novas tecnologias em fase de avaliação ou que serão demandadas para análise pela</u> Conitec serão incluídas nas versões subsequentes para garantir a sua atualização constante.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **2. Equipe de elaboração e partes interessadas** -->
O Grupo Elaborador dessa atualização foi a Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de elaboração do PCDT do Câncer de Mama foi apresentada na 111ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em janeiro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS), Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Saúde Indígena (SESAI). Foram solicitados ajustes textuais. O Protocolo foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4. Consulta Pública** -->
A Consulta Pública nº 04/2024, do Protocolo Clínico e Diretrizes Terapêuticas de Câncer de Mama, foi realizada entre os dias 19/02/2024 a 11/03/2024. Foram recebidas 92 contribuições, que podem ser verificadas em:  
https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/cp-04-2024contribuicoes-da-consulta-publicapcdt-de-cancer-de-mama.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **5. Busca da evidência e recomendações** -->
O objetivo desta atualização rápida foi incluir orientações sobre os esquemas quimioterápicos a serem preconizados pelo Sistema Único de Saúde. Para identificá-los, foi realizado um levantamento do tratamento medicamentoso (quimioterapia) preconizado em três diretrizes clínicas e em três protocolos de unidades prestadoras de serviço ao SUS, quais sejam:  
- Diretrizes da Sociedade Brasileira de Oncologia Clínica (SBOC) 2023;  
- Diretrizes da _European Society for Medical Oncology_ (ESMO) 2019;  
- Diretriz da _National Comprehensive Cancer Network_ (NCCN) 2020;  
- Hospital de Amor (Barretos);  
- Instituto do Câncer do Estado de São Paulo (ICESP); - Instituto Nacional do Câncer (INCA).  
Após o levantamento dos medicamentos preconizados por cada diretriz e seus critérios de uso, os dados foram apresentados a um painel de especialistas convidados, a fim de auxiliar a discussão.  
As reuniões para discussão ocorreram, em caráter virtual, nos dias 10 de outubro de 2023, 07 de novembro de 2023 e 12 de dezembro de 2023. Não foram considerados medicamentos que não possuíam registro válido pela Anvisa, que não foram avaliados pela Conitec para a indicação ou que, após avaliação pela Conitec, receberam recomendação desfavorável à sua incorporação ao SUS.  
Por fim, o texto aprovado pela Conitec, por meio do Relatório de Recomendação nº 789, de novembro de 2022, foi revisado e as informações oriundas da discussão com o painel de especialistas foram incluídas.  
**Atualização das Diretrizes Diagnósticas e Terapêuticas do Carcinoma de Mama – 2022**

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **1. Escopo e finalidade da Diretrizes** -->
A atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) do Carcinoma de Mama iniciou-se com a reunião presencial para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização do referido Protocolo.  
A reunião presencial teve a participação de 10 membros do Grupo Elaborador, sendo cinco especialistas e cinco metodologistas, além de representantes de sociedades médicas e de pacientes e do Comitê Gestor. Os presentes assinaram termos de confidencialidade, sigilo, declaração de conflito de interesses, além da lista de presença. A dinâmica da reunião foi conduzida com base nas DDTs vigentes (Portaria Conjunta SAS-SCTIE/MS nº 5, de 18 de abril de 2019) e na estrutura definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009.  
A relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, revisões sistemáticas e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos nas Diretrizes Diagnósticas e Terapêuticas vigentes à época. Para cada uma das seções definidas, qualquer incerteza clínica ou tecnologias que não estão incorporadas no SUS foram objetos de formulação de questão de pesquisa estruturada (Figura A). Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
R  
<!-- Start of picture text -->
| F | +Populaco ou condi¢ao clinica<br>+Intervengdo, no caso de estudos experimentais<br>+Fatorobservacionaisde exposicdo, em casode estudos<br>-Teste indice, nos casos de estudos de acuracia<br>a diagnéstica<br>*Controle, de acordo com tratamento/niveis de<br>exposicdo do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br>v<br><!-- End of picture text -->  
Ao final dessa dinâmica, três questões de pesquisa foram definidas (Quadro A.).  
**Quadro A** . Perguntas de pesquisa levantadas em reunião de escopo.  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|1|Qual a efetividade, segurança e custo efetividade da mamotomia como biópsia percutânea<br>para mulheres com câncer de mama e indicação de biópsia por estereotaxia, comparado com<br>biópsia cirúrgica?|Diagnóstico|
|2|Qual a necessidade de avaliação do teste genômico Oncotype para estadiamento e<br>classificação de risco comparado com o estadiamento tradicional (TNM) em mulheres com<br>câncer de mama RH+ e HER-2 -, axila negativa para a redução da necessidade de<br>quimioterapia?|Estadiamento|
|3|Qual a efetividade, segurança e custo efetividade dos inibidores de ciclina 4 e 6 (CDK4 /6)<br>+ letrozol ou fulvestranto, TMX e gosserrelina comparado com letrozol ou fulvestranto,<br>TMX e gosserrelina em pacientes com câncer de mama metastático com RH+ e HER-2<br>negativo?|Tratamento|  
A pergunta de pesquisa 1, relacionada ao diagnóstico da doença, não foi desenvolvida. Já a pergunta de pesquisa 2, relacionada ao estadiamento da doença, foi encerrada em reavaliação após reunião de escopo. Assim, a pergunta de pesquisa 3, relacionada ao tratamento da doença, foi desenvolvida e os detalhes metodológicos e resultados encontrados estão apresentados a seguir.  
Ainda, durante a atualização do Protocolo, a Conitec recebeu, por demanda externa, duas solicitações de avaliação de trastuzumabe entansina, para as seguintes indicações:  
- Trastuzumabe entansina em monoterapia para tratamento de pacientes com câncer de mama HER2-positivo metastático  
- ou localmente avançado iressecável, com tratamento prévio de trastuzumabe e um taxano, e;  
- Trastuzumabe entansina no tratamento adjuvante do câncer de mama HER2-positivo operado em estádio III com doença  
- residual na peça cirúrgica após tratamento neoadjuvante.  
Após avaliação das tecnologias, os membros do Plenário da Conitec deliberaram em:  
- Não recomendar a incorporação ao SUS de trastuzumabe entansina em monoterapia para tratamento de pacientes com câncer de mama HER2-positivo metastático ou localmente avançado iressecável, com tratamento prévio de trastuzumabe e um taxano, conforme Relatório de Recomendação nº 752/2022, disponível em:  
https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220912_relatorio_752_t-dm1_metastatico.pdf, e;  
- Recomendar a incorporação ao SUS de trastuzumabe entansina no tratamento adjuvante do câncer de mama HER2positivo operado em estádio III com doença residual na peça cirúrgica após tratamento neoadjuvante, conforme Relatório de Recomendação nº 751/2022, disponível em:  
<u>https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220912_relatorio_751_transtuzumabe_entansina.pdf.</u>  
Esta diretriz adotou as mesmas recomendações. Não foram realizadas buscas adicionais na literatura, uma vez que as buscas foram consideradas recentes, utilizando as sínteses de evidências disponíveis nos respectivos Relatórios de Recomendação.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **2. Equipe de elaboração e partes interessadas** -->
O Grupo Elaborador dessa atualização foi o Hospital Alemão Oswaldo Cruz. Todos os membros do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, os quais foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização das DDT do Carcinoma de Mama foi apresentada na 101ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). As DDT foram aprovadas para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 111ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **4. Consulta pública** -->
A Consulta Pública nº 65/2022, para a atualização das Diretrizes Diagnósticas e Terapêuticas de Carcinoma de Mama, foi realizada entre os dias 20/09/2022 e 10/10/2022. Foram recebidas 75 scontribuições, que podem ser verificadas em :  
<u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2022/CP_CONITEC_065_2022_Atualizao_das_Diretri zes.pdf.</u>

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **5. Busca da evidência e recomendações** -->
O processo de desenvolvimento deste Protocolo seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>223</sup> . Também foram consideradas as evidências presentes no Relatório de Recomendação nº 678/2021, que recomendou a incorporação da classe inibidores de ciclina (abemaciclibe, palbociclibe e succinato de ribociclibe) para o tratamento do câncer de mama avançado ou metastático com RH+ e HER-2 negativo, de acordo com a assistência oncológica no SUS e as Diretrizes Diagnósticas e Terapêuticas do Ministério da Saúde.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Pergunta de pesquisa** -->
Qual a eficácia e segurança do abemaciclibe, palbociclibe ou ribociclibe para o tratamento de câncer de mama avançado  
ou metastático RH+ e HER-2 negativo comparados a exemestano, letrozol, anastrazol ou fulvestranto?  
O acrônimo PICO está detalhado no **Quadro B** .  
**Quadro B** . Acrônimo PICOS  
|**P**|Paciente (_patient_)|Pacientes com câncer de mama avançado ou metastático RH+ e HER-2 negativo em qualquer<br>período menopausal|
|---|---|---|
|**I**|Intervenção<br>(_intervention_)|Abemaciclibe<br>Ribociclibe<br>Palbociclibe|
|**C**|Comparador<br>(_comparator_)|Exemestano<br>Letrozol<br>Anastrozol<br>Fulvestranto|
|**O**|Desfecho (_outcome_)|**Desfechos primários**<br>Sobrevida livre de progressão<br>Sobrevida global<br>Taxa de resposta<br>**Desfechos secundários**<br>Segurança|
|**S**|Tipo de estudo (_study_)|Ensaio clínico randomizado|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Busca em bases de dados** -->
Além das buscas nas bases de dados, foi realizada uma busca manual das referências dos artigos incluídos. As estratégias de busca contemplaram descritores, palavras-chave e sinônimos para população, intervenção, comparadores e tipos de estudos, estruturadas segundo linguagem das respectivas bases de dados. As estratégias de busca estão descritas nos Quadros C e D.  
**Quadro C.** Busca de dados no MEDLINE/PubMed.  
|**Busca**|**Estratégia de busca**|**Registros**|
|---|---|---|
|**#1**|"breast neoplasms"[MeSH Terms] OR ("breast"[All Fields] AND "neoplasms"[All<br>Fields]) OR "breast neoplasms"[All Fields] OR ("breast"[All Fields] AND "cancer"[All Fields])<br>OR "breast cancer"[All Fields]|419.638|
|**#2**|"breast"[Title/Abstract] AND "cancer"[Title/Abstract]|316.310|
|**#3**|"breast"[Title/Abstract] AND "neoplasm"[Title/Abstract]|4.757|
|**#4**|"breast"[Title/Abstract] AND "carcinoma"[Title/Abstract]|61.147|
|**#5**|"breast"[Title/Abstract] AND "tumor"[Title/Abstract]|103.664|
|**#6**|#1 OR #2 OR #3 OR #4 OR #5|424.764|
|**#7**|"Cyclin-Dependent Kinase"[Title/Abstract] OR|17.498|
|**#8**|"cyclin dependent kinase 6"[MeSH Terms] OR "cyclin dependent kinase 6"[ Title/Abstract]|1.510|
|**#9**|"cyclin dependent kinase 4"[MeSH Terms] OR "cyclin dependent kinase<br>4"[Title/Abstract]|4.119|
|**#10**|"fulvestrant"[MeSH Terms] OR "fulvestrant"[Title/Abstract]|3.172|  
|**Busca**|**Estratégia de busca**||**Registros**|
|---|---|---|---|
|**#11**|"anastrozole"[MeSH Terms] OR "anastrozol"[Title/Abstract]||2.244|
|**#12**|"letrozole"[MeSH Terms] OR "letrozole"[ Title/Abstract]||3.366|
|**#13**|"exemestane"[All<br>Fields]<br>OR<br>"exemestane"[Supplementary<br>Concept]<br>"exemestane"[Title/Abstract]|OR|1.503|
|**#14**|"aromatase<br>inhibitors"[Pharmacological<br>Action]  OR<br>"aromatase<br>inhibitors"[MeSH Terms] OR "aromatase inhibitors"[ Title/Abstract]||11.820|
|**#15**|"palbociclib"[Supplementary Concept] OR "palbociclib"[Title/Abstract]||1.018|
|**#16**|"ribociclib"[Supplementary Concept] OR "ribociclib"[Title/Abstract]||384|
|**#17**|"abemaciclib"[Supplementary Concept] OR "abemaciclib"[Title/Abstract]||314|
|**#18**|#7 OR #8 OR #9 OR #10 OR #11 OR #12 OR #13 OR #14 OR #15 OR #16 OR #17||35.494|
|**#19**|"randomized controlled trial"[Publication Type]||516.434|
|**#20**|"controlled clinical trial"[Publication Type]||605.464|
|**#21**|"randomized"[Title/Abstract]||537.825|
|**#22**|"clinical trials"[Title/Abstract]||256.829|
|**#23**|"clinical trial"[Title/Abstract]||152.054|
|**#24**|"randomly"[Title/Abstract]||343.619|
|**#25**|"trial"[Title/Abstract]||618.391|
|**#26**|#19 OR #20 OR #21 OR #22 OR #23 OR #24 OR #25||1.592.150|
|**#27**|#6 AND #18 AND #26||2.796|  
Busca realizada em 20 de outubro de 2020.  
**Quadro D** . Busca de dados no Embase.  
|**Busca**|**Estratégia de busca**|**Registros**|
|---|---|---|
|**#1**|('breast'/exp OR 'breast disease'/exp) AND 'neoplasm'/exp|22,166|
|**#2**|'breast tumor'/de OR 'breast tumor':ti,ab,kw|108.363|
|**#3**|'breast cancer'/de OR 'breast cancer':ti,ab,kw|510.290|
|**#4**|'breast carcinoma'/de OR 'breast carcinoma':ti,ab,kw|83.163|
|**#5**|#1 OR #2 OR #3 OR #4|604.390|
|**#6**|'cyclin dependent kinase'/de OR 'cyclin dependent kinase':ti,ab,kw|11.044|
|**#7**|'cyclin dependent kinase 6'/de OR 'cyclin dependent kinase 6':ti,ab,kw|5.988|
|**#8**|'cyclin dependent kinase 4'/de OR 'cyclin dependent kinase 4':ti,ab,kw|11.210|
|**#9**|'fulvestrant '/de OR 'fulvestrant':ti,ab,kw|9.389|
|**#10**|'anastrozole'/de OR 'anastrozole':ti,ab,kw|3.161|
|**#11**|‘Letrozole’/de OR 'letrozole':ti,ab,kw|12.624|
|**#12**|'exemestane'/de OR 'exemestane':ti,ab,kw|6.482|
|**#13**|'aromatase inhibitor'/de OR 'aromatase inhibitor':ti,ab,kw|17.033|  
|**Busca**|**Estratégia de busca**|**Registros**|
|---|---|---|
|**#14**|'palbociclib'/de OR 'palbociclib':ti,ab,kw|3.797|
|**#15**|'ribociclib'/de OR 'ribociclib':ti,ab,kw|1.396|
|**#16**|'abemaciclib'/de OR 'abemaciclib':ti,ab,kw|1.140|
|**#17**|#6 OR #7 OR #8 OR #9 OR #10 OR #11 OR #12 OR #13 OR #14 OR #15 OR #16|58.289|
|**#18**|'randomized controlled trial (topic)'/exp OR 'randomized controlled trial (topic)'|188.217|
|**#19**|'controlled clinical trial (topic)'/exp OR 'controlled clinical trial (topic)'|195.721|
|**#20**|'randomized':ti,ab,kw|777.645|
|**#21**|'clinical trial':ti,ab,kw|228.814|
|**#22**|randomly':ti,ab,kw|454.121|
|**#23**|'trial':ab,ti|901,599|
|**#24**|(double:ab,ti OR single:ab,ti OR doubly:ab,ti OR singly:ab,ti) AND adj:ab,ti AND (blind:ab,ti<br>OR blinded:ab,ti OR blindly:ab,ti)|46|
|**#25**|#18 OR #19 OR #20 OR #21 OR #22 OR #23 OR #24|1,750,305|
|**#26**|#5 AND #17 AND #25|6.123|
|**#27**|(#26 AND ('human'/exp OR human)) NOT (abstract:it)|3.850|  
Busca realizada em 20 de outubro de 2020.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Seleção das evidências e extração dos dados** -->
A seleção das evidências foi realizada por um metodologista, mediante aplicação dos critérios de elegibilidade. Em situações de dúvida, um segundo metodologista seria consultado. A seleção sumária dos estudos incluídos encontra-se na **Figura B** . Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento e estão apresentados no **Quadro E** .  
**Figura B.** Processo de seleção de estudos  
<!-- Start of picture text -->
Bases de dados Busca manual<br>MEDLINE/PubMed (n = 2.796) (n = 1)<br>Registros após remoção dos duplicados<br>(n = 4.762)<br>Registros rastreados<br>(n = 4.762)<br>Registros excluídos<br>(n = 4.564)<br>Artigos em texto completo avaliados<br>para elegibilidade(n = 198)<br>Artigos em texto completo excluídos,<br>com justificativa<br>(n = 155)<br>Desfecho = 5<br>Artigos incluídos na revisão sistemática<br>(n = 43) População = 110<br>Tipo de estudo = 25<br>Revisões sistemáticas = 15<br><!-- End of picture text -->  
**Quadro E.** Estudos excluídos durante a leitura de texto completo  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Aihara  et<br>al, 2010|Phase III randomized adjuvant study of tamoxifen alone versus sequential<br>tamoxifen and anastrozole i Japanese postmenopausal women with<br>hormone-responsive breast cancer: N-SAS BC03 study|população – pacientes com<br>ER- ou + e HER2+ ou +|
|Al-||população<br>-<br>não<br>foi|
|Mubarak et al, 2013|Fulvestrant for advanced breast cancer: a meta-analysis|apresentado ER ou HER2|
|André et al, 2018|Alpelisib (ALP) + fulvestrant (FUL) for advanced breast cancer (ABC):<br>Results of the phase III SOLAR-1 trial|população - foram incluídos<br>homens|
||Modulation of Rb phosphorylation and antiproliferative response to|população - pacientes com|
|Arnedos et al, 2018|palbociclib: the preoperative-palbociclib (POP) randomized clinical trial|ER- ou + e HER2+ ou +|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Ayyagari et al, 2018|<br>Comparative efficacy of everolimus plus exemestane versus fulvestrant<br>for hormone-receptor-positive advanced breast cancer following<br>progression/recurrence after endocrine therapy: a network meta-analysis|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Bachelot et al, 2014|<br>Comparative efficacy of everolimus plus exemestane versus fulvestrant<br>for hormone-receptor-positive advanced breast cancer following<br>progression/recurrence after endocrine therapy: a network meta-analysis.|<br>População - pacientes com<br>ER- ou + e HER2+ ou +|
|Bajetta  et al, 1999|Double-blind, randomised, multicentre endocrine trial comparing two<br>letrozole doses, in postmenopausal breast cancer patients|população - pacientes com<br>ER- ou +|
|Bardia  et<br>al, 2020|Phase 1b Dose Escalation/Expansion Trial of Ribociclib in Combination<br>With Everolimus and Exemestane in<br>Postmenopausal Women With HR+, HER2- Advanced Breast Cancer|Desfecho - escalação de<br>dose|
|Barnadas<br>et al, 2009|Exemestane as primary treatment of oestrogen receptorpositive breast<br>cancer in postmenopausal women: a phase II trial. British journal of<br>cancer.|População - pacientes com<br>HER2+ ou -|
|Baselga et al, 2009|Phase II randomized study of neoadjuvant everolimus plus letrozole<br>compared with placebo plus letrozole in patients with estrogen receptor-<br>positive breast cancer|população - pacientes com<br>HER2+ ou -|
|Bergh et al, 2012|FACT: an open-label randomized phase III study of fulvestrant and<br>anastrozole in combination compared with anastrozole alone as first-line<br>therapy for patients with receptor-positive postmenopausal breast cancer|<br>população - pacientes com<br>ER- ou + e HER2+ ou +|
||Anastrozole versus tamoxifen as first-line therapy for advanced breast||
|Bonneterre et al,<br>2000|cancer in 668 postmenopausal women: results of the<br>Tamoxifen or Arimidex Randomized Group Efficacy and<br>Tolerability study|população - pacientes com<br>ER- ou +|
|Botrel et al, 2013|Lapatinib plus chemotherapy or endocrine therapy (CET) versus CET<br>alone in the treatment of HER-2-overexpressing locally advanced or<br>metastatic breast cancer: systematic review and meta-analysis|população - pacientes com<br>HER2+|
|Bui<br>et al, 2019|Real-World Effectiveness of Palbociclib Versus Clinical Trial Results in<br>Patients with Advanced/Metastatic Breast Cancer That Progressed on<br>Previous Endocrine Therapy|Tipo de estudo  -<br>retrospectivo|
|Buzdar  et<br>al, 1997|A phase III trial comparing anastrozole (1 and 10 milligrams), a potent<br>and selective aromatase inhibitor, with megestrol acetate in<br>postmenopausal women with advanced breast carcinoma.|população - pacientes com<br>ER- ou + e HER2+<br>ou -|
|Buzdar  et<br>al, 2001|Phase III, multicenter, double-blind, randomized study of letrozole, an<br>aromatase inhibitor, for advanced breast cancer versus megestrol acetate|população - pacientes com<br>HER2+ ou -|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Carlson et al, 2012|A randomized trial of combination anastrozole plus gefitinib and of<br>combination fulvestrant plus gefitinib in the treatment of postmenopausal<br>women with hormone receptor positive metastatic breast cancer|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Cataliotti et al, 2006|<br>Comparison of anastrozole versus tamoxifen as preoperative therapy in<br>postmenopausal women with hormone receptorpositive breast cancer: the<br>Pre-Operative "Arimidex" Compared to Tamoxifen (PROACT) trial.|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Chanchan<br>et<br>al,<br>2018|The efficacy and safety of targeted therapy plus fulvestrant in<br>postmenopausal women with hormone-receptor positive advanced breast<br>cancer: A meta-analysis of randomized-control trials|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Chia et al, 2008|Double-blind, randomized placebo-controlled trial of fulvestrant<br>compared with exemestane after prior nonsteroidal aromatase inhibitor<br>therapy in postmenopausal women with hormone receptor-positive,<br>advanced breast cancer: results from EFECT|população<br>-<br>não<br>foi<br>apresentado HER2|
|Chirila et al, 2017|Comparison of palbociclib in combination with letrozole or fulvestrant<br>with endocrine therapies for advanced/metastatic breast cancer: network<br>meta-analysis|população - pacientes com<br>ER- ou + e HER2+<br>ou -|
|Ciruelos et al, 2020|Palbociclib and Trastuzumab in HER2-Positive Advanced Breast Cancer:<br>Results from the Phase II SOLTI-1303 PATRICIA Trial|população - pacientes com<br>ER- e HER2+|
|Clemons et al, 2014|<br>Randomised, phase II, placebo-controlled, trial of fulvestrant plus<br>vandetanib in postmenopausal women with bone only or bone<br>predominant, hormone-receptor-positive metastatic breast cancer (MBC):<br>the OCOG ZAMBONEY study.|população - pacientes com<br>ER- e HER2+|
|Colleoni et al, 2011|Analyses adjusting for selective crossover show improved overall<br>survival with adjuvant letrozole compared with tamoxifen in the BIG 1-<br>98 study|população - pacientes com<br>HER2+ ou -|
|Cope et al, 2013|Progression-free survival with fulvestrant 500 mg and alternative<br>endocrine therapies as second-line treatment for advanced breast cancer:<br>a network meta-analysis with parametric survival models|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Cope et al, 2014|A process for assessing the feasibility of a network metaanalysis: a case<br>study of everolimus in combination with hormonal therapy versus<br>chemotherapy for advanced breast cancer.|população - pacientes com<br>ER- ou +|
|Corona  et<br>al, 2019|Efficacy of extended aromatase inhibitors for hormonereceptor-positive<br>breast cancer: A literature-based metaanalysis of randomized trials|população<br>-<br>não<br>foi<br>apresentado ER ou HER2|
|Cottu et al, 2018|Letrozole and palbociclib versus chemotherapy as neoadjuvant therapy of<br>high-risk luminal breast cancer|população - câncer não<br>metastático|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Cristofanilli et al,<br>2010|<br>Phase II, randomized trial to compare anastrozole combined with<br>gefitinib or placebo in postmenopausal women with hormone receptor-<br>positive metastatic breast cancer|<br>população - pacientes com<br>ER- ou + e HER2+ ou +|
|D’Avanzo<br>et al, 2019|CDK 4/6 inhibitors plus endocrine therapy in ER positive metastatic<br>breast cancer (MBC): Systematic review and metaanalysis of randomized<br>clinical trials|<br> <br>tipo estudo - apresentação de<br>resumo|
|Decker  et<br>al, 2018|Anti-hormonal maintenance treatment with or without the CDK4/6<br>inhibitor ribociclib after first line chemotherapy in hormone receptor<br>positive/HER2 negative metastatic breast cancer: A phase II trial<br>(AMICA) GBG 97|<br> <br>tipo<br>de<br>estudo -<br>protocolo de pesquisa|
|Dhakal  et<br>al, 2018|Efficacy of Palbociclib Combinations in Hormone ReceptorPositive<br>Metastatic Breast Cancer Patients After Prior Everolimus Treatment|<br>tipo<br>de<br>estudo<br>-<br>retrospectivo|
|Di Leo et al, 2010|Results of the CONFIRM phase III trial comparing fulvestrant 250 mg with<br>fulvestrant 500 mg in postmenopausal women with estrogen receptor-<br>positive advanced breast cancer|<br>população<br>-<br>não<br>apresentado HER2<br>foi|
|Di Leo et al, 2014|Final overall survival: fulvestrant 500 mg vs 250 mg in the randomized<br>CONFIRM trial|<br>população<br>-<br>não<br>apresentado HER2<br>foi|
|Di Leo et al, 2018|First-line vs second line fulvestrant for hormone receptorpositive advanced<br>breast cancer: A post-hoc analysis of the CONFIRM study|<br>população<br>-<br>não<br>apresentado HER2<br>foi|
|Dickler  et al, 2001|The MORE trial: Multiple outcomes for raloxifene evaluation: Breast<br>cancer as a secondary end point: Implications for prevention|<br>população - pacientes com<br>ER- ou +|
|Dickler  et al, 2016|Phase III Trial Evaluating Letrozole as First-Line Endocrine Therapy With<br>or Without Bevacizumab for the Treatment of<br>Postmenopausal Women With Hormone Receptor-Positive<br>Advanced-Stage Breast Cancer: CALGB 40503 (Alliance)|<br>população - pacientes com<br>ER- ou + e HER2+<br>ou -|
|Dixon et al, 2000|The effects of neoadjuvant anastrozole (Arimidex) on tumor volume in<br>postmenopausal women with breast cancer: a<br>randomized, double-blind, single-center study|<br>população<br>-<br>não<br>foi<br>apresentado HER2|
|Dowsett et al, 2010|Meta-analysis of breast cancer outcomes in adjuvant trials of aromatase<br>inhibitors versus tamoxifen|<br>população - pacientes com<br>HER2+ ou -|
|Eiermann<br>et al, 2011|Phase III study of doxorubicin/cyclophosphamide with concomitant versus<br>sequential docetaxel as adjuvant treatment in patients with human<br>epidermal growth factor receptor 2normal, node-positive breast cancer:<br>BCIRG-005 trial|<br> <br> <br>população - pacientes com<br>ER- ou +|
|Eisen et al, 2008|Aromatase inhibitors in adjuvant therapy for hormone receptor positive<br>breast cancer: a systematic review|<br>População - ER desconhecido<br>ou + /<br>HER2 não identificado|  
|**Autor**|**Título**|**Motivo da exclusão**||
|---|---|---|---|
|Ellis et al, 2007|Letrozole in the neoadjuvant setting: the P024 trial|população - pacientes<br>HER2+ ou -|com|
|Ellis et al, 2009|Aromatase expression and outcomes in the P024 neoadjuvant endocrine<br>therapy trial.|população - pacientes<br>HER2+ ou -|com|
||Fulvestrant 500 mg Versus Anastrozole 1 mg for the First-Line Treatment|<br>população<br>-||
|Ellis et al, 2015|of Advanced Breast Cancer: Overall Survival Analysis From the Phase II<br>FIRST Study|não<br>foi<br>apresentado HER2||
||FALCON: A phase III randomised trial of fulvestrant 500 mg vs.|<br>população<br>-||
|Ellis et al, 2016|anastrozole for hormone receptor-positive advanced breast cancer|não<br>foi<br>apresentado HER2||
|Falandry et al, 2009|Celecoxib and exemestane versus placebo and exemestane in<br>postmenopausal metastatic breast cancer patients: a doubleblind phase III<br>GINECO study|população - pacientes<br>HER2+ ou -|com|
|Falkson et al, 1996|A randomised study of CGS 16949A (fadrozole) versus tamoxifen in<br>previously untreated postmenopausal patients with metastatic breast cancer|<br>população - pacientes<br>ER- ou +|com|
||FemZone trial: a randomized phase II trial comparing neoadjuvant|população - pacientes|com|
|Fasching et al, 2014|letrozole and zoledronic acid with letrozole in primary breast cancer<br>patients|ER- ou + e HER2+<br>ou -||
|Finn et al, 2020|Biomarker Analyses of Response to Cyclin-Dependent Kinase 4/6<br>Inhibition and Endocrine Therapy in Women with<br>Treatment-Naive Metastatic Breast Cancer|Desfecho<br>-<br>avaliação<br>biomarcadores||
|Finn et al, 2020|Treatment effect of palbociclib plus endocrine therapy by prognostic and<br>intrinsic subtype and biomarker analysis in patients with bone-only<br>disease: a joint analysis of PALOMA-2 and PALOMA-3 clinical trials|tipo de estudo - a<br>agrupada de 2 ECR|nálise|
|Fontein et al, 2013|Specific adverse events predict survival benefit in patients treated with<br>tamoxifen or aromatase inhibitors: an international tamoxifen exemestane<br>adjuvant multinational trial analysis|população<br>-<br>não<br>foi<br>apresentado HER2||
|Fontein et al, 2017|Specific adverse events are associated with response to exemestane<br>therapy in postmenopausal breast cancer patients: Results from the<br>TEAMIIA study (BOOG2006-04)|População<br>-<br>não<br>apresentado HER2|foi|
|Fountzilas<br>et<br>al,<br>2004|<br>Paclitaxel and epirubicin versus paclitaxel and carboplatin as first-line<br>chemotherapy in patients with advanced breast cancer: a phase III study<br>conducted by the Hellenic Cooperative Oncology Group|população - pacientes<br>ER- ou +|com|
||Comparing duration of response and duration of clinical benefit between|população<br>-||
|Garnett et al, 2013|fulvestrant treatment groups in the CONFIRM trial: application of new<br>methodology|não<br>foi<br>apresentado HER2||  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
||Efficacy and safety of palbociclib plus endocrine therapy in||
|Gelmon et<br>al, 2020|North  American<br>women  with<br>hormone<br>receptor-<br>positive/human epidermal growth factor receptor 2-negative metastatic<br>breast cancer|tipo de estudo - análise<br>agrupada de 2 ECR|
|Generali et al, 2015|A network meta-analysis of everolimus plus exemestane versus<br>chemotherapy in the first- and second-line treatment of estrogen receptor-<br>positive metastatic breast cancer|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Gines<br>Rubio et al,<br>2007<br>Goss et al, 2013|[A meta-analysis of the effectiveness of aromatase inhibitors as adjuvant<br>treatment for postmenopausal patients with breast cancer]<br>Impact of premenopausal status at breast cancer diagnosis in women<br>entered on the placebo-controlled NCIC CTG MA17 trial of extended<br>adjuvant letrozole.|população - pacientes com<br>ER- ou +<br>população - pacientes com<br>HER2+ ou -|
|Guo et al, 2019|Safety and efficacy profile of cyclin-dependent kinases 4/6 inhibitor<br>palbociclib in cancer therapy: A meta-analysis of clinical trials.|população<br>-<br>não<br>foi<br>apresentado ER ou HER2|
|Ham et al, 2020|Palbociclib use with grade 3 neutropenia in hormone receptorpositive<br>metastatic breast cancer|tipo<br>de<br>estudo  -<br>retrospectivo|
|Heinzl, 2019|PALOMA-3 trial in advanced breast cancer: Palbociclib does not<br>significantly prolong overall survival|tipo de estudo - editorial|
|Hortobagyi et al,<br>2018|Ribociclib for the first-line treatment of advanced hormone receptor-<br>positive breast cancer: a review of subgroup analyses from the<br>MONALEESA-2 trial|população<br>-<br>análise<br>de<br>subgrupo do<br>ECR<br>MONALEESA-2|
|Im<br>et al, 2019|Palbociclib Plus Letrozole as First-Line Therapy in Postmenopausal<br>Asian Women With Metastatic Breast Cancer: Results From the Phase<br>III, Randomized PALOMA-2 Study|população<br>-<br>análise<br>de<br>subgrupo do ECR<br>Paloma-2|
|Ingle  et al, 1997|A randomized Phase II trial of two dosage levels of letrozole as third-line<br>hormonal therapy for women with metastatic breast carcinoma.|população - pacientes com<br>ER- ou +|
|Iwata et al, 2017|PALOMA-3: Phase III Trial of Fulvestrant With or Without Palbociclib<br>in Premenopausal and Postmenopausal Women With Hormone Receptor-<br>Positive, Human Epidermal Growth Factor Receptor 2-Negative<br>Metastatic Breast Cancer That Progressed on Prior Endocrine Therapy-<br>Safety and Efficacy in Asian Patients.|população<br>-<br>análise<br>de<br>subgrupo do ECR<br>Paloma-3|
|Jancin et al, 2010|CONFIRM trial: Fulvestrant 500 mg better than standard dosing|população<br>-<br>não<br>foi<br>apresentado HER2|
|Janni et al, 2016|Randomised phase III trial of FEC120 vs EC-docetaxel in patients with<br>high-risk node-positive primary breast cancer: final survival analysis of<br>the ADEBAR study|população - pacientes com<br>HER2+ ou -|  
|**Autor**|**Título**|**Motivo da**|**exclusão**||
|---|---|---|---|---|
|Jeselsohn<br>et<br>al,<br>2016|TransCONFIRM: Identification of a Genetic Signature of<br>Response to Fulvestrant in Advanced Hormone ReceptorPositive Breast<br>Cancer|População<br>apresentado|-<br>não<br>HER2|foi|
|Johnston et al, 2008|<br>A phase II, randomized, blinded study of the farnesyltransferase inhibitor<br>tipifarnib combined with letrozole in the treatment of advanced breast<br>cancer after antiestrogen therapy|população -<br>ER- ou + e<br>ou -|pacientes<br>HER2+|com|
|Johnston et al, 2019|<br>Randomized Phase II Study Evaluating Palbociclib in Addition to<br>Letrozole as Neoadjuvant Therapy in Estrogen ReceptorPositive Early<br>Breast Cancer: PALLET Trial|população<br>metastático|- câncer<br>|não|
|Jones et al, 1999|Multicenter, phase II trial of exemestane as third-line hormonal therapy<br>of postmenopausal women with metastatic breast cancer. Aromasin Study<br>Group|população -<br>ER- ou +|pacientes|com|
|Jordan, 2012|Results of the CONFIRM Phase III Trial Comparing Fulvestrant 250mg<br>With Fulvestrant 500mg in Postmenopausal Women<br>With Estrogen Receptor–Positive Advanced Breast Cancer|População<br>apresentado|-<br>não<br>HER2|foi|
|Kaufman et al, 2009|<br>Trastuzumab plus anastrozole versus anastrozole alone for the treatment<br>of postmenopausal women with human epidermal growth factor receptor<br>2-positive, hormone receptor-positive metastatic breast cancer: results<br>from the randomized phase III TAnDEM study|população -<br>HER2+|pacientes|com|
|Kelly et al, 2010|Aromatase inhibitors alone or in sequence with tamoxifen - clinical<br>evaluation of the BIG 1-98 trial|população -<br>HER2+ ou -|pacientes<br>|com|
||Exemestane versus anastrozole as front-line endocrine therapy in||||
|LlombartCussac  et<br>al, 2012|postmenopausal patients with hormone receptor-positive, advanced<br>breast cancer: final results from the Spanish Breast Cancer Group 2001-<br>03 phase 2 randomized trial|população<br>apresentado|-<br>não<br>HER2|foi|
|Malorni et al, 2014|Efficacy of Fulvestrant According to Duration and Type of Adjuvant<br>Endocrine Treatment, in Metastatic Breast Cancer Patients Enrolled in the<br>Confirm Trial|população<br>apresentado|-<br>não<br>HER2|foi|
|Massarweh<br>et al, 2014|A phase II study of combined fulvestrant and everolimus in patients with<br>metastatic estrogen receptor (ER)-positive breast cancer after aromatase<br>inhibitor (AI) failure|população -<br>HER2+ ou -|pacientes<br>|com|
|Masuda et<br>al, 2012|Neoadjuvant anastrozole versus tamoxifen in patients receiving goserelin<br>for premenopausal breast cancer (STAGE): a doubleblind, randomised<br>phase 3 trial|população<br>metastático|- câncer<br>|não|
||Palbociclib in combination with fulvestrant in patients with hormone|população|-<br>análise|<br>de|
|Masuda et<br>al, 2019|receptor-positive, human epidermal growth factor receptor 2-negative<br>advanced breast cancer: PALOMA-3 subgroup analysis of Japanese<br>patients|subgrupo do<br>Paloma-3|ECR||  
|**Autor**|**Título**|**Motivo da e**|**xclusão**|
|---|---|---|---|
||Randomized<br>Phase  II<br>Trial<br>Comparing|população|-|
|Maung  et<br>al, 2001|Exemestane<br>to<br>Tamoxifen for First-Line Hormonal Therapy of Postmenopausal Patients<br>with Metastatic Breast Cancer|<br>não<br>apresentado|<br> <br>foi<br>HER2|
||Activity of fulvestrant versus exemestane in advanced breast cancer|população|-|
|Mauriac et al, 2009|patients with or without visceral metastases: data from the EFECT trial|não<br>apresentado|<br>foi<br>HER2|
|Mayer et al, 2019|A Phase II Randomized Study of Neoadjuvant Letrozole Plus Alpelisib<br>for Hormone ReceptorPositive, Human Epidermal<br>Growth Factor Receptor 2-Negative Breast Cancer (NEO-ORB)|população<br>metastático|- câncer não<br>|
|Mehta  et<br>al, 2012|Combination anastrozole and fulvestrant in metastatic breast cancer|população -<br>HER2+ ou -|pacientes com<br>|
|Mehta  et<br>al, 2019|Overall Survival with Fulvestrant plus Anastrozole in Metastatic Breast<br>Cancer.|população<br>apresentado|- não foi<br>HER2|
|Migliaccio et al,<br>2014|Prognostic Role of Luminal Subtype in Metastatic Breast Cancer Patients<br>Treated with Fulvestrant in the Confirm Trial|população<br>apresentado|- não foi<br>HER2|
|Mlineritsch et al,<br>2008|Exemestane as primary systemic treatment for hormone receptor positive<br>post-menopausal breast cancer patients: a phase II trial of the Austrian<br>Breast and Colorectal Cancer Study Group (ABCSG-17)|população -<br>HER2+ ou -|pacientes com<br>|
|Monnier et al, 2006|The evolving role of letrozole in the adjuvant setting: first results from<br>the large, phase III, randomized trial BIG 1-98|população -<br>HER2+ ou -|pacientes com<br>|
|Mouridsen et al,<br>2004|Efficacy of first-line letrozole versus tamoxifen as a function of age in<br>postmenopausal women with advanced breast cancer|população -<br>ER- ou + e<br>ou -|pacientes com<br>HER2+|
|Mouridsen et al,<br>2007|Letrozole in advanced breast cancer: the PO25 trial. Breast cancer<br>research and treatment|população<br>apresentado|- não foi<br>HER2|
|Mrozek  et al, 2012|Phase II trial of exemestane in combination with fulvestrant in<br>postmenopausal women with advanced, hormone-responsive breast<br>cancer. Clin Breast Cancer|população -<br>HER2+ ou -|pacientes com<br>|
|Mukai et al, 2019|Palbociclib in combination with letrozole in patients with estrogen<br>receptor-positive, human epidermal growth factor receptor 2-negative<br>advanced breast cancer: PALOMA-2 subgroup analysis of Japanese<br>patients.|população<br>subgrupo do<br>Paloma-2|-<br>análise<br>de<br>ECR|
||Progression-free survival results in postmenopausal Asian women:|||
|Noguchi et al, 2018|<br>subgroup analysis from a phase III randomized trial of fulvestrant 500 mg<br>vs anastrozole 1 mg for hormone receptorpositive advanced breast cancer<br>(FALCON)|população<br>apresentado|- não foi<br>HER2|  
|**Autor**|**Título**|**Motivo da e**|**xclusão**||
|---|---|---|---|---|
|O'Leary et al, 2018|The Genetic Landscape and Clonal Evolution of Breast Cancer<br>Resistance to Palbociclib plus Fulvestrant in the PALOMA-3 Trial|Desfecho<br>genética|-<br>ava|liação|
|Osborne et al, 2011|Gefitinib or placebo in combination with tamoxifen in patients with<br>hormone receptor-positive metastatic breast cancer: a randomized phase<br>II study.|população -<br>HER2+ ou -|pacientes<br>|com|
|O'Shaughn|Ribociclib plus letrozole versus letrozole alone in patients with de novo|população|-<br>anális|e<br>de|
|essy et al, 2018|HR+, HER2- advanced breast cancer in the randomized MONALEESA-<br>2 trial|subgrupo<br>MONALEE|do<br>SA-2|ECR|
|Paridaens  et al,<br>2003|Mature results of a randomized phase II multicenter study of exemestane<br>versus tamoxifen as first-line hormone therapy for postmenopausal<br>women with metastatic breast cancer|população -<br>ER- ou +|pacientes|com|
|Paridaens<br>et<br>al,<br>2008|Phase III study comparing exemestane with tamoxifen as firstline<br>hormonal treatment of metastatic breast cancer in postmenopausal<br>women: the European Organisation for Research and Treatment of<br>Cancer Breast Cancer Cooperative Group|população -<br>ER- ou +|pacientes|com|
|Paul et al, 2019|Randomized phase-II evaluation of letrozole plus dasatinib in hormone<br>receptor positive metastatic breast cancer patients|tipo<br>de<br> <br>comparativo|estudo<br>-<br>|não|
|Paul Goss<br>et al,<br>2007|Phase III, Double-Blind, Controlled Trial of Atamestane Plus Toremifene<br>Compared With Letrozole in Postmenopausal Women With Advanced<br>Receptor-Positive Breast Cancer|população<br>apresentado|- nã<br>HER2|o foi|
|Perrone et al, 2019|Adjuvant zoledronic acid and letrozole plus ovarian function suppression<br>in premenopausal breast cancer: HOBOE phase 3 randomised trial|população<br>metastático|- câncer<br>|não|
|Prat et al, 2020|Ribociclib plus letrozole versus chemotherapy for postmenopausal<br>women with hormone receptor-positive, HER2-negative, luminal B<br>breast cancer (CORALLEEN): an<br>open-label, multicentre, randomised, phase 2 trial|população<br>metastático|- câncer<br>|não|
|Regan et al, 2011|Assessment of letrozole and tamoxifen alone and in sequence for<br>postmenopausal women with steroid hormone receptorpositive breast<br>cancer: the BIG 1-98 randomised clinical trial at 8·1 years median follow-<br>|população -<br>HER2+ ou -|pacientes<br>|com|
||up||||
|Robertson<br>et al,<br>2009|Activity of fulvestrant 500 mg versus anastrozole 1 mg as firstline<br>treatment for advanced breast cancer: results from the FIRST study|população -<br>ER- ou + e<br>ou -|pacientes<br>HER2+|com|
|Robertson<br>et<br>al,<br>2016|Fulvestrant 500 mg versus anastrozole 1 mg for hormone receptor-<br>positive advanced breast cancer (FALCON): an international,<br>randomised, double-blind, phase 3 trial|população<br>apresentado|- nã<br>HER2|o foi|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Robertson<br>et<br>al,<br>2018|Health-related quality of life from the FALCON phase III randomised<br>trial of fulvestrant 500 mg versus anastrozole for hormone receptor-<br>positive advanced breast cancer|população<br>- não foi<br>apresentado HER2|
|Rossi et al, 2018|Managing advanced HR-positive, HER2-negative breast cancer with<br>CDK4/6 inhibitors in post-menopausal patients: is there a best sequence?|<br>tipo de estudo - revisão de<br>literatura|
|Rossi et al, 2019|Should All Patients With HR-Positive HER2-Negative Metastatic Breast<br>Cancer Receive CDK 4/6 Inhibitor As First-Line Based<br>Therapy? A Network Meta-Analysis of Data from the PALOMA 2,<br>MONALEESA 2, MONALEESA 7, MONARCH 3, FALCON, SWOG<br>and FACT Trials|população - pacientes com<br>HER2+ ou -|
|Royce et al, 2016|BOLERO-4: Phase 2 trial of first-line everolimus (EVE) plus letrozole<br>(LET) in estrogen receptor–positive (ER+), human epidermal growth<br>factor receptor 2–negative (HER2-) advanced breast cancer (BC)|tipo de estudo - abstract|
||Breast Cancer Management with Melanie E Royce: BOLERO-4 Phase II||
|Royce et al, 2016|trial of first-line everolimus plus letrozole in ER+, HER2- advanced<br>breast cancer|tipo de estudo - editorial|
|Rugo et al, 2017|A randomized phase II trial of ridaforolimus, dalotuzumab, and<br>exemestane compared with ridaforolimus and exemestane in patients with<br>advanced breast cancer|população<br>- não foi<br>apresentado ER|
|Rugo<br>ET<br>AL, 2018|Palbociclib plus endocrine therapy in older women with HR+/HER2-<br>advanced breast cancer: a pooled analysis of randomised PALOMA<br>clinical studies|tipo de estudo - análise<br>agrupada de 3 ECR|
|Rugo et al, 2020|Predictors of efficacy in patients (pts) with hormone<br>receptor– positive/ human epidermal growth factor<br>receptor<br>2–negative<br>advanced<br>breast<br>cancer<br>(HR+/HER2− ABC): Subgroup analyses of PALOMA-3|tipo de estudo - abstract|
|Rugo et al, 2020|Real-world survival outcomes of heavily pretreated patients with<br>refractory HR+, HER2-metastatic breast cancer receiving single-agent<br>chemotherapy-a comparison with MONARCH 1|tipo<br>de<br>estudo -<br>retrospectivo|
|Ruhstaller<br>et<br>al,<br>2019|Adjuvant<br>letrozole<br>and<br>tamoxifen<br>alone<br>or<br>sequentially<br>for<br>postmenopausal women with hormone receptor-positive breast cancer:<br>Long-term follow-up of the BiG 1-98 trial|população - pacientes com<br>ER+<br>e<br>câncer<br>não<br>metastático|
|Saura et al, 2019|Neoadjuvant letrozole plus taselisib versus letrozole plus placebo in<br>postmenopausal women with oestrogen receptorpositive, HER2-<br>negative, early-stage breast cancer (LORELEI): a multicentre,<br>randomised, double-blind, placebo-controlled, phase 2 trial|população - câncer não<br>metastático|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Schiff et al, 2018|Is ctDNA the Road Map to the Landscape of the Clonal Mutational<br>Evolution in Drug Resistance? Lessons from the PALOMA-3 Study and<br>Implications for Precision Medicine|tipo de estudo - opinião de<br>especialistas|
|Shah et al, 2020|Hormone Receptor-Positive/Human Epidermal Growth Receptor 2-<br>Negative Metastatic Breast Cancer in Young Women: Emerging Data in<br>the Era of Molecularly Targeted Agents|tipo de estudo - revisão de<br>literatura|
|Sobhani et al, 2019|Updates on the CDK4/6 Inhibitory Strategy and Combinations in Breast<br>Cancer|tipo de estudo - revisão de<br>literatura|
||Ribociclib with letrozole vs letrozole alone in elderly patients with|população<br>-<br>análise<br>de|
|Sonke et al, 2018|hormone receptor-positive, HER2-negative breast cancer in the<br>randomized MONALEESA-2 trial|subgrupo<br>do<br>ECR<br>MONALEESA-2|
|Spazzapan<br>et al, 2017|Updated results from MONALEESA-2, a phase 3 trial of first-line<br>ribociclib + letrozole in hormone receptor-positive (HR+), HER2negative<br>(HER2–) advanced breast cancer (ABC)|tipo de estudo - abstract|
|Tanguy  et<br>al, 2018|Cdk4/6 inhibitors and overall survival: power of first-line trials in<br>metastatic breast cancer|tipo de estudo - modelagem<br>de<br>sobrevida|
|Thomas et<br>al, 2007|Phase II clinical trial of ixabepilone (BMS-247550), an epothilone B<br>analog, in patients with taxane-resistant metastatic breast cancer|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Thurlimann et al,<br>1996|First-line fadrozole HCI (CGS 16949A) versus tamoxifen in<br>postmenopausal women with advanced breast cancer. Prospective<br>randomised trial of the Swiss Group for Clinical Cancer Research SAKK<br>20/88|população - pacientes com<br>ER- ou +|
|Tolaney et al, 2020<br>Tolaney et al, 2020|Phase Ib Study of Ribociclib plus Fulvestrant and Ribociclib plus<br>Fulvestrant plus PI3K Inhibitor (Alpelisib or Buparlisib) for HR(+)<br>Advanced Breast Cancer<br>Abemaciclib plus trastuzumab with or without fulvestrant versus<br>trastuzumab plus standard-of-care chemotherapy in women with<br>hormone receptor-positive, HER2-positive advanced breast cancer<br>(monarcHER): a randomised, openlabel, phase 2 trial|Desfecho - escalação de<br>dose<br>população - pacientes com<br>HER2+|
|Tominaga<br>et<br>al,<br>2003|Double-blind randomised trial comparing the non-steroidal aromatase<br>inhibitors letrozole and fadrozole in postmenopausal women with<br>advanced breast cancer|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Tremblay<br>et al, 2018|Matching-adjusted indirect treatment comparison of ribociclib and<br>palbociclib in HR+, HER2- advanced breast cancer|tipo de estudo - análise<br>agrupada de 3 ECR|
|Turner  et<br>al, 2018|Clinical considerations of the role of palbociclib in the management of<br>advanced breast cancer patients with and without visceral metastases|tipo de estudo - análise<br>agrupada de 2 ECR|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
|Turner  et<br>al, 2019|Cyclin E1 Expression and Palbociclib Efficacy in Previously Treated<br>Hormone Receptor-Positive Metastatic Breast Cancer|Desfecho<br>-<br>avaliação<br>genética|
|Villanueva et al,<br>2013|Phase II study assessing lapatinib added to letrozole in patients with<br>progressive disease under aromatase inhibitor in metastatic breast cancer-<br>Study BES 06|população - pacientes com<br>HER2+|
|Vorobiof et al, 1999|<br>A randomized, open, parallel-group trial to compare the endocrine effects<br>of oral anastrozole (Arimidex) with intramuscular formestane in<br>postmenopausal women with advanced breast cancer|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Wolff et al, 2013|Randomized phase III placebo-controlled trial of letrozole plus oral<br>temsirolimus as first-line endocrine therapy in postmenopausal women<br>with locally advanced or metastatic breast cancer|população - pacientes com<br>HER2+ ou -|
|Wu et al, 2017|Neoadjuvant everolimus plus letrozole versus fluorouracil, epirubicin and<br>cyclophosphamide for ER-positive, HER2negative breast cancer: study<br>protocol for a randomized pilot trial|tipo<br>de<br>estudo  -<br>protocolo de pesquisa|
|xu<br>et<br>al, 2011|Fulvestrant 250 mg versus anastrozole for Chinese patients with advanced<br>breast cancer: results of a multicentre, double-blind, randomised phase III<br>trial|população<br>- não foi<br>apresentado HER2|
|Yam et al , 2019|Efficacy and safety of the combination of metformin, everolimus and<br>exemestane in overweight and obese postmenopausal patients with<br>metastatic, hormone receptor-positive, HER2negative breast cancer: a<br>phase II study|tipo de estudo - braço único|
|Yardley et al, 2013|Randomized phase II, double-blind, placebo-controlled study of<br>exemestane with or without entinostat in postmenopausal women with<br>locally recurrent or metastatic estrogen receptorpositive breast cancer<br>progressing on treatment with a nonsteroidal aromatase inhibitor|população<br>- não foi<br>apresentado HER2|
|Yardley et al, 2015|Paclitaxel, bevacizumab, and everolimus/placebo as first-line treatment<br>for patients with metastatic HER2-negative breast cancer: a randomized<br>placebo-controlled phase II trial of the Sarah Cannon Research Institute|população - pacientes com<br>ER- ou + e HER2+ ou +|
|Yardley et al, 2019|Efficacy and Safety of Ribociclib With Letrozole in US Patients Enrolled<br>in the MONALEESA-2 Study|população<br>-<br>análise<br>de<br>subgrupo<br>do<br>ECR<br>MONALEESA-2|
|Yardley et al, 2019|MONALEESA clinical program: a review of ribociclib use in different<br>clinical settings|tipo de estudo - revisão de<br>literatura|
|Zhang  et<br>al, 2016<br>Revisões sistemática|Fulvestrant 500 mg vs 250 mg in postmenopausal women with estrogen<br>receptor-positive advanced breast cancer: a randomized, double-blind<br>registrational trial in China.<br>s excluídas|população<br>- não foi<br>apresentado HER2|  
|**Autor**|**Título**|**Motivo d**|**a exclusão**|
|---|---|---|---|
|Bottcher et al, 2019|<br>Treatment of advanced HR+/HER2- breast cancer with new targeted<br>agents in combination with endocrine therapy: a review of efficacy and<br>tolerability based on available randomized trials on everolimus,<br>ribociclib, palbociclib and abemaciclib|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Brandao et al, 2020|Endocrine therapy-based treatments in hormone receptorpositive/HER2-<br>negative advanced breast cancer: systematic review and network meta-<br>analysis|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Deng et al, 2018|CDK4/6 Inhibitors in Combination With Hormone Therapy for<br>HR(+)/HER2(-) Advanced Breast Cancer: A Systematic Review<br>and Meta-analysis of Randomized Controlled Trials|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Desnoyers et al,<br>2020|Comparison of treatment-related adverse events of different Cyclin-<br>dependent kinase 4/6 inhibitors in metastatic breast cancer: A network<br>meta-analysis|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|||Revisão s|istemática com os|
|Ding et al, 2018<br>Giuliano et al, 2019|The CDK4/6 inhibitor in HR-positive advanced breast cancer: A<br>systematic review and meta-analysis<br> <br>Endocrine treatment versus chemotherapy in postmenopausal women<br>with hormone receptor-positive, HER2-negative, metastatic breast<br>cancer: a systematic review and network meta-analysis|estudos<br>evitando<br>dados.<br>Revisão s<br>estudos<br>evitando<br>dados.|já<br>incluídos,<br>a duplicidade de<br>istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Han et al, 2020|Comparative efficacy and safety of CDK4/6 and PI3K/AKT/mTOR<br>inhibitors in women with hormone receptorpositive, HER2-negative<br>metastatic breast cancer: a systematic review and network meta-analysis|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|PattersonLomba  et<br>al, 2019|<br>Systematic literature review of clinical trials of endocrine therapies for<br>premenopausal women with metastatic HR+ HER2- breast cancer|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Piezzo  et<br>al, 2020|Progression-Free Survival and Overall Survival of CDK 4/6 Inhibitors<br>Plus Endocrine Therapy in Metastatic Breast Cancer: A Systematic<br>Review and Meta-Analysis|Revisão s<br>estudos<br>evitando<br>dados.|istemática com os<br>já<br>incluídos,<br>a duplicidade de|
|Ramos-<br>Esquivel et al, 2020|<br>Cyclindependent kinase 4/6 inhibitors in combination with fulvestrant for<br>previously treated metastatic hormone receptorpositive breast cancer|Revisão s<br>estudos|istemática com os<br>já<br>incluídos,|  
|**Autor**|**Título**|**Motivo da exclusão**|
|---|---|---|
||patients: A systematic review and metaanalysis of randomized clinical<br>trials|evitando a duplicidade de<br>dados.|
|Schettini et al, 2020|<br>Overall survival of CDK4/6-inhibitors-based treatments in clinically<br>relevant subgroups of metastatic breast cancer: systematic review and<br>meta-analysis|Revisão sistemática com os<br>estudos<br>já<br>incluídos,<br>evitando a duplicidade de<br>dados.|
|Shimoi  et<br>al, 2020|First-line endocrine therapy for postmenopausal patients with hormone<br>receptor-positive, HER2-negative metastatic breast<br>cancer: a systematic review and meta-analysis|Revisão sistemática com os<br>estudos<br>já<br>incluídos,<br>evitando a duplicidade de<br>dados.|
|||Revisão sistemática com os|
|Shohdy et<br>al, 2017|Gastrointestinal adverse effects of cyclin-dependent kinase 4 and 6<br>inhibitors in breast cancer patients: a systematic review and meta-analysis|<br>estudos<br>já<br>incluídos,<br>evitando a duplicidade de<br>dados.|
||Systematic review and network meta-analysis comparing palbociclib|Revisão sistemática com os|
|Wilson  et<br>al, 2017|with chemotherapy agents for the treatment of postmenopausal women<br>with HR-positive and HER2-negative advanced/metastatic breast cancer|estudos<br>já<br>incluídos,<br>evitando a duplicidade de<br>dados.|
||Combination cyclin-dependent kinase 4/6 inhibitors and endocrine|Revisão sistemática com os|
|Zheng  et|therapy versus endocrine monotherapy for hormonal receptor-positive,|estudos<br>já<br>incluídos,|
|al, 2020|human epidermal growth factor receptor 2negative advanced breast<br>cancer: A systematic review and meta-analysis|evitando a duplicidade de<br>dados.|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Descrição dos estudos e resultados** -->
Foram incluídas 43 referências de ECR, fase II ou III, provenientes de 13 de estudos, elencados no **Quadro F** . A população total inicial foi de 5.812 participantes do sexo feminino. As características basais dos participantes de cada estudo podem ser vistas no Quadro G. Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. Os dados dos estudos incluídos foram extraídos em planilhas no Microsoft Office Excel® por um único revisor.  
**Quadro F** . Relação entre estudos e artigos incluídos.  
|**Estudo**|**Artigos**|
|---|---|
|**PALOMA 1**|Finn et al, 2020<sup>239</sup>|
||Finn et al, 2016<sup>240</sup>|
||Finn et al, 2015<sup>241</sup>|
||Bell et al, 2016<sup>242</sup>|
|**Next MONARCH 1**|Hamilton et al, 2019<sup>197</sup>|
||Hamilton et al, 2020<sup>243</sup>|  
|**Estudo**|**Artigos**|
|---|---|
|**MONALEESA 2**|Hortobagyi et al, 2018<sup>244</sup>|
||Hortobagyi et al, 2016<sup>245</sup>|
||Janni et al, 2018<sup>246</sup>|
||Verma et al, 2018<sup>247</sup>|
|**neoMONARCH**|Hurvitz et al, 2020<sup>248</sup>|
|**MONALEESA 7**|Im et al, 2019<sup>200</sup>|
||Harbeck et al, 2020<sup>249</sup>|
||Tripathy et al, 2018<sup>250</sup>|
|**MONARCH 3**|Johnston et al, 2019<sup>251</sup>|
||Goetz et al, 2020<sup>252</sup>|
||Goetz et al, 2017<sup>185</sup>|
|**TREnd**|Malorni et al, 2018<sup>196</sup><br>Rossi et al, 2019<sup>253</sup>|
||McCartney et al, 2020<sup>254</sup>|
|**Sem nome**|Park et al, 2019<sup>255</sup>|
|**PALOMA 2**|Rugo et al, 2020<sup>256</sup>|
||Rugo et al, 2019<sup>257</sup>|
||Rugo et al, 2018<sup>258</sup>|
||Finn et al, 2016<sup>259</sup>|
||Durairaj et al, 2018<sup>260</sup>|
||Dieras et al, 2019<sup>261</sup>|
|**MONALEESA 3**|Slamon et al, 2020<sup>262</sup>|
||Slamon et al, 2018<sup>263</sup>|
||Fasching et al, 2020<sup>264</sup>|
|**MONARCH 2**|Sledge et al, 2019<sup>265</sup>|
||Sledge et al, 2017<sup>266</sup>|
||Kaufman et al, 2020<sup>267</sup>|
|**PALOMA 3**|Turner et al, 2018<sup>268</sup>|
||Cristofanilli et al, 2018<sup>269</sup>|
||Cristofanilli et al, 2016<sup>270</sup>|
||Harbeck et al, 2016<sup>271</sup>|
||Loibl et al, 2017<sup>183</sup>|
||Turner et al, 2015<sup>272</sup>|
||Verma et al, 2016<sup>273</sup>|
|**MONARCH plus**|Zhang et al, 2020<sup>274</sup>|  
**Quadro G.** Característica dos estudos incluídos.  
|**Referência**|**Registro****_clinica_**|**_l trials_**|**Estado**<br>**menopausal**|**Estudo**|**Comparadores**|**Resultados**|
|---|---|---|---|---|---|---|
|Finn<br>et al,<br>2020<sup>239</sup>|NCT<br>00721409|PALOMA 1|Pós menopausa|1ª linha|Palbociclibe<br>+<br>letrozo<br>Letrozol<br>l|Os pacientes que realizaram tratamento com palbociclibe<br>associado a letrozol apresentaram uma SLP de 20,2 meses e<br>com letrozol foi de 10,2 meses.<br>Os pacientes que realizaram tratamento com palbociclibe<br>associado<br>ao<br>letrozol<br>apresentaram<br>uma SG de 37,5 meses e o letrozol foi de 33,3 meses.|
|Hamilton et<br>al, 2019<sup>197</sup>|NCT<br>02747004|Next<br>MONARCH 1|Pós menopausa|2ª linha|Abemaciclibe Tamoxifeno<br>Abemaciclibe<br>Abemaciclibe<br>Loperamida<br>+<br>+|<br> <br>Os pacientes que realizaram tratamento abemaciclibe em<br>monoterapia apresentaram uma SLP 6,48 meses, com<br>abemaciclibe associado a loperamida foi 7,43 meses e com<br>abemaciclibe associado a tamoxifeno foi 9,07 meses.<br>Os pacientes que realizaram tratamento abemaciclibe<br>apresentaram uma SG 20,8 meses, com abemaciclibe<br>associado à loperamida foi 17 meses e com abemaciclibe<br>associado a tamoxifeno foi 24,2 meses.|
|Hortobagyi et<br>2018<sup>184</sup>|al,<br>NCT<br>01958021|MONALEESA 2|Pós menopausa|1ª linha|Ribociclibe<br>+<br>letrozol<br>Letrozol|<br>Os pacientes que realizaram tratamento com ribociclibe<br>associado a letrozol apresentaram uma SLP de 25,3 meses e<br>com letrozol foi de 16 meses.<br>Os pacientes que realizaram tratamento com letrozol<br>apresentaram uma SG de 33 meses e o ribociclibe associado<br>ao letrozol não foi estimado.|  
|**Referência**|**Registro****_clinical t_**|**_rials_**|**Estado**<br>**menopausal**|**Estudo**|**Comparadores**|**Resultados**|
|---|---|---|---|---|---|---|
|**Im**<br>**et al,**<br>**2019**<sup>**200**</sup>|NCT<br>02278120|MONALEESA 7|Pré<br>ou<br>peri<br>menopausa|<br>1ª ou 2ª linha|Ribociclibe + (letrozol ou<br>anastrozol ou tamoxifeno) +<br>gosserrelina<br>(letrozol ou anastrozol ou<br>tamoxifeno) +<br>gosserrelina|<br> <br>Os pacientes que realizaram tratamento com ribociclibe<br>associado a gosserrelina e letrozol ou anastrozol ou<br>tamoxifeno apresentaram uma SLP de 23,8 meses e com<br>gosserrelina associado a letrozol ou anastrozol ou<br>tamoxifeno foi de 13 meses.|
|**Johnston et**<br>**al, 2019**<sup>**251**</sup>|NCT02246621|MONARCH 3|Pós menopausa|1ª linha|Abemaciclibe<br>+<br>anastrozol<br>ou<br>letrozol<br>Anastrozol + letrozol|<br>Os pacientes que realizaram tratamento com abemaciclibe<br>associado a anastrozol ou letrozol apresentaram uma SLP<br>28,18 meses e com anastrozol ou letrozol foi de foi 14,73<br>meses.|
|**Malorni et**<br>**2018**<sup>**196**</sup>|**al,**NCT<br>02549430|TREnd|Pós menopausa|2ª linha|Palbociclibe Palbociclibe<br>(Anastrozol<br>Letrozol<br>Exemestano<br>Fulvestranto)<br>+<br>ou<br>ou<br>ou|Os pacientes que realizaram tratamento com palbociclibe<br>apresentaram uma SLP de 6,5 meses e com palbociclibe<br>associado a anastrozol ou letrozol ou exemestano ou<br>fulvestranto foi de 10,8 meses.|
|**Park**<br>**et**<br>**2019**<sup>**255**</sup>|**al,**NCT<br>02592746|Sem nome|Pré menopausa|2ª linha|Palbociclibe<br>Exemestano<br>Capecitabina<br>+|Os pacientes que realizaram tratamento com palbociclibe<br>associado a exemestano apresentaram SLP de 20,1 meses e<br>com capecitabina foi de 14,4 meses.|
|**Finn**<br>**et**<br>**2016**<sup>**259**</sup>|**al,**NCT<br>01740427|PALOMA 2|Pós menopausa|1ª linha|Palbociclibe<br>+<br>letrozol<br>Letrozol|<br>Os pacientes que realizaram tratamento com palbociclibe<br>associado a letrozol apresentaram uma SLP de e 24,8 meses<br>e com letrozol foi de e 14,5 meses.|
|**Slamon et al,**<br>**2020**<sup>**262**</sup>|NCT<br>02422615|MONALEESA3|Pós menopausa|1ª ou 2ª linha|Ribociclibe<br>+<br>fulvestranto Fulvestranto|Os pacientes que realizaram tratamento com ribociclibe<br>associado a fulvestranto apresentaram uma SLP de 20,5<br>meses e com fulvestranto foi de 12,8 meses.|  
|**Referência**|**Registro****_clinic_**|**_al trials_**|**Estado**<br>**menopausal**|**Estudo**|**Comparadores**|**Resultados**|
|---|---|---|---|---|---|---|
|**Sledge et al,**<br>**2019**<sup>**265**</sup>|NCT<br>02107703|MONARCH 2|Pré, peri e pós<br>menopausa|<br>1ª ou 2ª linha|Abemaciclibe<br>fulvestranto<br>Fulvestranto|+  Os<br>pacientes<br>que<br>realizaram<br>tratamento<br>com<br>abemaciclibe associado a fulvestranto apresentaram<br>uma SLP média de 16,4 meses e com fulvestranto em<br>monoterapia foi de 9,3 meses.|
|**Turner et al,**<br>**2015**<sup>**268**</sup>|NCT<br>01942135|PALOMA 3|Pré, peri e pós<br>menopausa|<br>2ª linha|Palbociclibe<br>Fulvestranto<br>Fulvestranto|+  Os<br>pacientes<br>que<br>realizaram<br>tratamento<br>com<br>palbociclibe associado a fulvestranto apresentaram<br>uma SLP de 9,2 meses e com fulvestranto foi de 3,8<br>meses.<br>Os<br>pacientes<br>que<br>realizaram<br>tratamento<br>com<br>palbociclibe associado a fulvestranto apresentaram<br>uma SG de 34,9 meses e com<br>fulvestranto foi de 28,0 meses|
|**Zhang et al,**<br>**2020**<sup>**274**</sup>|NCT<br>02763566|MONARCH plus|Pós menopausa|1ª ou 2ª linha|Abemaciclibe<br>+<br>inibidor de aromatase<br>IA<br>Abemaciclibe<br>+<br>Fulvestranto<br>Fulvestranto|Os<br>pacientes<br>que<br>realizaram<br>tratamento<br>com<br>abemaciclibe associado a anastrozol ou letrozol<br>apresentaram SLP não estimada; com anastrozol ou<br>letrozol foi de 14,73 meses, com abemaciclibe<br>associado a fulvestranto foi de 11,47 meses e com<br>fulvestranto foi de 5,59 meses.|  
Os resultados de efetividade foram sumarizados e apresentados a seguir. Os estudos incluídos avaliaram os seguintes medicamentos: abemaciclibe, anastrozol, capecitabina, exemestano, fulvestranto, letrozol, loperamida, palbociclibe, ribociclibe e tamoxifeno. A apresentação dos resultados dos estudos foi realizada de forma descritiva e por meio dos resultados de _Network Meta-analisys_ (NMA).

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: ● **Sobrevida livre de progressão** -->
- Pacientes em pós-menopausa e em primeira linha de tratamento: o abemaciclibe associado ao anastrozol ou letrozol possui uma diferença média superior de 13,450 (Intervalo de Confiança [IC] 95%: 10,028 – 16,872) meses quando comparado ao letrozol; palbociclibe associado ao letrozol possui uma diferença média superior de 10,223 (IC 95%: 6,536 – 13,911) meses quando comparado ao letrozol; ribociclibe associado ao letrozol possui uma diferença média superior de 9,300 (IC 95%: 5,152 – 13,448) meses quando comparado ao letrozol.  
- Pacientes em pré, peri ou pós-menopausa e em primeira ou segunda linha de tratamento: abemaciclibe associado ao fulvestranto possui uma diferença média superior de 7,100 (IC 95%: 4,097 – 10,103) meses quando comparado ao fulvestranto; palbociclibe associado ao fulvestranto possui uma diferença média superior de 5,400 (IC 95%: 3,880 – 6,920) meses quando comparado ao abemaciclibe associado ao fulvestranto; não foram observadas diferenças entre os grupos abemaciclibe associado a fulvestranto vs. Palbociclibe associado a fulvestranto (diferença média = 1,70 (IC 95%: -1,666 – 5,066).  
- Pacientes em pós-menopausa e em segunda linha de tratamento: abemaciclibe associado ao anastrozol ou letrozol possui uma diferença média superior de 11,530 (IC 95%: 2,713 – 20,347) meses quando comparado ao abemaciclibe associado ao fulvestranto; abemaciclibe associado ao anastrozol ou letrozol possui uma diferença média superior de 8,27 (IC 95%: 2,810 – 13,730) meses quando ao anastrozol ou letrozol; abemaciclibe associado ao anastrozol ou letrozol possui uma diferença média superior de 17,41 (IC 95%: 12,908 – 21,912) meses quando comparado ao fulvestranto; abemaciclibe associado ao anastrozol ou letrozol possui uma diferença média superior de 9,71 (IC 95%: 4,011 – 15,409) meses quando comparado ribociclibe associado ao fulvestranto; anastrozol ou letrozol possui uma diferença média superior de 9,14 (IC 95%: 5,029 – 13,251) meses quando comparado ao fulvestranto.  
● **Taxa de resposta objetiva e controle da doença**  
- Pacientes pós-menopausa e em primeira linha de tratamento: abemaciclibe associado a anastrozol ou letrozol possui um risco relativo (RR) maior (RR: 1,344; IC95%: 1,071 – 1,1687) de apresentar resposta objetiva comparado ao letrozol; palbociclibe associado a letrozol possui um risco relativo maior (RR: 1,226; IC95%: 1,030 – 1,460) de apresentar resposta objetiva comparado ao letrozol; ribociclibe associado ao letrozol possui um risco relativo maior (RR: 1,467; IC95%: 1,181 – 1,824)  de apresentar resposta objetiva comparado ao letrozol.  
- Pacientes pré, peri ou pós-menopausa e em primeira ou segunda linha de tratamento:  
abemaciclibe associado fulvestranto possui um risco relativo maior (RR: 2,181; IC95%: 1,576 – 3,017) de apresentar resposta objetiva comparado ao fulvestranto.  
- Pacientes pós-menopausa e em segunda linha de tratamento: palbociclibe associado a letrozol possui um risco relativo maior (RR: 1,225; IC95%: 1,105 – 1,426) de apresentar resposta objetiva e controle da doença comparado ao letrozol; palbociclibe associado a letrozol possui um risco relativo maior (RR: 1,226; IC95%: 1,030 – 1,1687) de apresentar resposta objetiva e controle da doença comparado ao abemaciclibe associado a anastrozol ou letrozol; ribociclibe associado ao letrozol possui um risco relativo maior de apresentar resposta objetiva e controle da doença comparado ao letrozol; ribociclibe associado ao letrozol possui um risco relativo maior (RR: 1,445; IC95%: 1,094 – 1,908) de apresentar resposta objetiva e controle da doença comparado ao abemaciclibe associado a anastrozol ou letrozol.  
- Pacientes pós-menopausa e em primeira ou segunda linha: abemaciclibe associado a anastrozol ou letrozol possui um risco relativo maior (RR: 1,308; IC95%: 1,090 – 1,569) de apresentar taxa de resposta completa e controle da doença comparado ao fulvestranto; abemaciclibe associado a fulvestranto possui um risco relativo maior (RR: 1,114; IC95%: 1,003 – 1,238) de  
apresentar taxa de resposta completa e controle da doença comparado ao anastrozol ou letrozol; abemaciclibe associado a fulvestranto possui um risco relativo maior (RR: 1,322; IC95%: 1,098 – 1,592) de apresentar taxa de resposta completa e controle da doença comparado ao fulvestranto; fulvestranto possui um risco relativo menor (RR: 0,851; IC95%: 0,748 – 0,968) de apresentar taxa de resposta completa e controle da doença comparado ao ribociclibe associado ao fulvestranto.  
- **Eventos adversos**  
- Pacientes pós-menopausa e em primeira linha de tratamento: abemaciclibe possui um risco relativo maior (RR: 1,842; IC95%: 1,185 – 2,864) de apresentar eventos adversos gerais comparado ao letrozol ou anastrozol; abemaciclibe associado ao anastrozol possui um risco relativo maior (RR: 1,648; IC95%: 1,209 – 2,246) de apresentar eventos adversos gerais comparado ao letrozol ou anastrozol.  
- Pacientes pré, peri ou pós-menopausa em primeira ou segunda linha: abemaciclibe associado fulvestranto possui um risco relativo maior (RR: 1,168; IC95%: 1,101 – 1,239) de apresentar eventos adversos comparado fulvestranto; fulvestranto possui um risco relativo menor (RR: 0,911 IC95%: 0,862 – 0,962) de apresentar eventos adversos comparado palbociclibe associado ao fulvestranto.  
- Pacientes pós-menopausa em primeira ou segunda linha: abemaciclibe associado a anastrozol ou letrozol possui um risco relativo maior (RR: 1,159; IC95%: 1,069 – 1,256) de apresentar eventos adversos gerais comparado ao anastrozol ou letrozol; abemaciclibe associado a anastrozol ou letrozol possui um risco relativo maior (RR: 1,352; IC95%: 1,151 – 1,589) de apresentar eventos adversos gerais comparado ao fulvestranto; abemaciclibe associado a anastrozol ou letrozol possui um risco relativo maior (RR: 1,225; IC95%: 1,062 – 1,483) de apresentar eventos adversos gerais comparado ao ribociclibe associado ao fulvestranto; abemaciclibe associado a fulvestranto possui um risco relativo maior (RR: 1,153; IC95%: 1,063 – 1,252)  de apresentar eventos adversos gerais comparado ao anastrozol ou letrozol; abemaciclibe associado a fulvestranto possui um risco relativo maior (RR: 1,346; IC95%: 1,144 – 1,583) de apresentar eventos adversos gerais comparado ao fulvestranto; abemaciclibe associado a fulvestranto possui um risco relativo maior (RR: 1,249; IC95%: 1,056 – 1,477) de apresentar eventos adversos gerais comparado ao ribociclibe associado ao fulvestranto; Ribociclibe associado ao fulvestranto possui um risco relativo maior (RR: 1,078; IC95%: 1,033 – 1,124) de apresentar eventos adversos gerais comparado ao fulvestranto.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: ● **Eventos adversos graves** -->
- Pacientes pós-menopausa em primeira linha: letrozol associado ao anastrozol possui um risco relativo menor (RR: 0,504; IC95%: 0,285 – 0,890) de apresentar eventos adversos graves comparado ao palbociclibe associado ao letrozol.  
- Pacientes pré, peri ou pós-menopausa em primeira ou segunda linha: abemaciclibe associado fulvestranto possui um risco relativo maior (RR: 2,086; IC95%: 1,376 – 3,161) de apresentar eventos adversos graves comparado com fulvestranto; abemaciclibe associado fulvestranto possui um risco relativo maior (RR: 3,043; IC95%: 1,597 – 5,799) de apresentar eventos adversos graves comparado ao palbociclibe associado ao fulvestranto.  
- Pacientes pós-menopausa e em segunda linha: abemaciclibe associado a anastrozol ou letrozol possui um risco relativo maior (RR: 2,146; IC95%: 1,085 – 4,246) de eventos adversos graves comparado ao anastrozol ou letrozol.  
Algumas linhas de tratamento e períodos de menopausa não foram apresentadas devido à impossibilidade de gerar a rede de análise. Os dados dos estudos incluídos, as figuras, gráficos e demais análises estão detalhadas nos resultados no Relatório de Recomendação nº 678/2021 _,_ assim como as NMA que não apresentaram diferença significativa entre os medicamentos avaliados.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Qualidade Metodológica** -->
A avaliação do risco de viés dos ECR foi conduzida utilizando-se os critérios de risco de viés sugeridos pela _Revised Cochrane risk of bias tool for randomized trials_ (RoB 2.0)<sup>275</sup> . O risco de viés foi avaliado por desfecho e por linha de tratamento. Se o estudo apresentasse baixo risco de viés, não haveria comprometimento do domínio avaliado pela respectiva ferramenta. Porém, nenhum estudo apresentou baixo risco de viés. No geral, o risco de viés foi moderado. **Todos os estudos apresentaram**  
**classificação satisfatória no que tange ao** **_Evidência Indireta_** e, por isso, não houve a necessidade de apresentar todas as figuras  
de _Evidência Indireta_ . Informações adicionais estão descritas no Relatório de Recomendação nº 678 _._  
A avaliação de riscos de viés para cada um dos desfechos está descrita nas **Figuras C** a **G** .  
F **igura C** . Risco de viés dos estudos na NMA de sobrevida livre de progressão.  
Figura C1 - Tratamento de primeira linha pós-menopausa. Figura C2 - Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa. FiguraC3 - Tratamento de primeira ou segunda linha – pós-menopausa. <u>C1. Tratamento de primeira linha pós-menopausa.</u>  
<!-- Start of picture text -->
L<br>Pe tn a<br>0 10 20 30 40 50, 60 70 80 90 100<br><!-- End of picture text -->  
- <u>C2. Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
<!-- Start of picture text -->
occ  a A<br>ee |<br>rte Te<br><!-- End of picture text -->  
<u>C3. Tratamento de primeira ou segunda linha – pós-menopausa</u>  
<!-- Start of picture text -->
so eo A<br>Pe<br>mt si<br>0 10 20 30 40 50 60 70 80 90 100<br><!-- End of picture text -->  
**Figura D** . Risco de viés dos estudos na NMA de **taxa de resposta objetiva** .  
Figura D1 - Tratamento de primeira linha – pós-menopausa.  
Figura D2 -Tratamento de primeira ou segunda linha – pré, peri ou pósmenopausa  
<u>D1. Tratamento de primeira linha  pós-menopausa</u>  
<!-- Start of picture text -->
ee _ ___<br>crc<br>arse at<br>sewmascne-earantcu<br>reanacene hmrectotc arcorcecn  et  [<br>Prsciteostroncist I<br><!-- End of picture text -->  
<u>D2. Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
<!-- Start of picture text -->
sa ee A ,<br>te:<br>sen Ct IE,<br>° 10 2» 20 0 50 60 70 20 90 100<br><!-- End of picture text -->  
**Figura E** . Risco de viés dos estudos na NMA de taxa de resposta objetiva e controle da doença.  
Figura E1 - Tratamento de primeira linha – pós menopausa. Figura E2 - Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa. Figura E3 - Tratamento de primeira ou segunda linha – pós-menopausa.  
<!-- Start of picture text -->
E1. Tratamento de primeira linha  pós-menopausa<br>Ce<br>etree<br>Larsen<br>aaa]<br>manent tometerPost rstessesi8 ° 0 20 20 40 500 70 20 9 100<br><!-- End of picture text -->  
- <u>E2. Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
<!-- Start of picture text -->
oe a<br>Cece A<br>seat e<br>° 10 2 20 40 50 60 7 a 0 100<br><!-- End of picture text -->  
- <u>E3. Tratamento de primeira ou segunda linha – pós-menopausa.</u>  
<!-- Start of picture text -->
ee<br>poem Ponca enc)<br>Abemacicibe + (Anastrozol ou Letrozol:Abemacicibe + fulvestranto |<br>‘Abemacicibe + (Anastrozol ou Letrazol)-Fulvestranto |<br>seman<br>pres tne<br>FuvesranirReoctlbe «testario<br>rome - mtnematest tame I eT<br>teense<br>toni ee I<br>om » © 5 6 7m 0 9% 10<br><!-- End of picture text -->  
**Figura F.** Risco de viés dos estudos na NMA de **eventos adversos gerais** . Figura F1 - Tratamento de primeira linha – pós-menopausa. Figura F2 -Tratamento de primeira ou segunda linha – pré, peri ou pósmenopausa. Figura F3 - Tratamento de primeira ou segunda linha – pós-menopausa.  
<u>F1. Tratamento de primeira linha  pós-menopausa.</u>  
<!-- Start of picture text -->
a rt i)<br>smn iti<br>:<br>i<br>i<br>t<br>Pmt mt.<br>fi<br>i<br>temacnt i<br>t<br>recontc<br>ee ee ee ee ee ee ee ee<br><!-- End of picture text -->  
<u>F2. Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
<!-- Start of picture text -->
ee<br>Penance<br><!-- End of picture text -->  
<u>F3. Tratamento de primeira ou segunda linha – pós-menopausa</u>  
<!-- Start of picture text -->
|<br>Avene<br>ents ou steve<br>Acemectoe-hivestata Aneto)<br>(oats Lesa nection vee, |<br>Atenas tiverato ocine -vestano,|<br>6 1020 3040 50 ery 90 100<br><!-- End of picture text -->  
**Figura G** . Risco de viés dos estudos na NMA de **eventos adversos graves** .  
Figura G1 - Tratamento de primeira linha – pós-menopausa. Figura G2 -Tratamento de primeira ou segunda linha – pré, peri ou pósmenopausa. Figura G3 - Tratamento de primeira ou segunda linha – pós-menopausa  
<u>G1. Tratamento de primeira linha  pós-menopausa.</u> ‘Abomacietbe = (Anastrozol ou Letrezob:Letrezol ou anastrazo! ee AemactbeAnomacie «acts ou ater ES Leora. ovaneraztaoctbot i Leverotovanerat recsct Avemactton «(aerosol ou Levon Paton ct <mark>|</mark> Avemactin«naetontcu Levon ricci eet | LE Aremacitbe Paes tes ee ____t Aeemactom oc laos LT Faiostoe-oeabosbe + oso LST ES <u>G2. Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u> css <mark>some</mark> 0 10 20 30 40 50 60 70 80 90 <u>G3. Tratamento de primeira ou segunda linha – pós-menopausa.</u>  
<!-- Start of picture text -->
Avemecttne ~(naeroc! ou Leva ianestec! ou t o),<br>Asemectne reat Anat)<br>Avemacenefoomecttoe ~anserortes-tmecransLeveznRocRosine - vevestsSS SS Oe<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Qualidade geral da evidência** -->
Avaliação da qualidade geral da evidência foi feita seguindo recomendações do _webapp_ CINeMA ( _Confidence in Network Meta-Analysis_ )<sup>276</sup> . A análise do CINeMA demonstrou que a evidência da metaanálises em rede foi de muito baixa para sobrevida livre de progressão, taxa de resposta clínica, taxa de resposta objetiva, taxa de resposta objetiva e controle da doença, eventos adversos gerais, eventos adversos graves. A qualidade da evidência não foi avaliada para o desfecho sobrevida global devido à impossibilidade de realizar a rede de meta-análise. Informações adicionais estão descritas no Relatório de Recomendação nº 678 _._ A avaliação da qualidade geral da evidência para cada um dos desfechos está descrita nos Quadros H a L.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: Quadro H. Avaliação geral da evidência sobrevida livre de progressão -->
**<u>Quadro H1.</u>** <u>Tratamento de primeira linha pós-menopausa.</u>  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe + (Anastrozol|1|Algumas|Não detectado|Sem preocupações|Sem preocupações|Sem preocupações|Grande|Muito|
|ou<br>Letrozol):Letrozol||preocupações|||||preocupação|Baixo|
|Letrozol: Palbociclibe<br>+ letrozol|2|Grande<br>preocupação|Não detectado|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|
|Letrozol:<br>ribociclibe<br>+<br>letrozol|1|Algumas<br>preocupações|Não detectado|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe + (Anastrozol|0|Algumas|Não detectado|Sem preocupações|Sem preocupações|Sem preocupações|Grande|Muito|
|ou<br>Letrozol):Palbociclibe<br>+ letrozol||preocupações|||||preocupação|Baixo|
|Abemaciclibe + (Anastrozol|0|Algumas|Não detectado|Sem preocupações|Sem preocupações|Algumas preocupações|Grande|Muito|
|ou<br>Letrozol):ribociclibe<br>+<br>letrozol||preocupações|||||preocupação|Baixo|
|Palbociclibe<br>+<br>letrozol:|0|Algumas|Não detectado|Sem preocupações|Sem preocupações|Sem preocupações|Grande|Muito|
|ribociclibe + letrozol||preocupações|||||preocupação|Baixo|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: Quadro H. Avaliação geral da evidência sobrevida livre de progressão -->
|**Comparações**|**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência Indireta**|<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>fulvestranto: Fulvestranto<br>+|<br>1|Algumas preocupações|Não detectado|Sem preocupações|Algumas<br>preocupações|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Fulvestranto: Palbociclibe<br>Fulvestranto<br>+|1|Algumas preocupações|Não detectado|Sem preocupações|Sem preocupações|Algumas preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+|||||||||
|fulvestranto: Palbociclibe<br>Fulvestranto<br>+|<br>0|Algumas preocupações|Não detectado|Sem preocupações|Algumas<br>preocupações|Sem preocupações|Grande<br>preocupação|Muito Baixo|  
**<u>Quadro H3</u>** <u>. Tratamento de primeira ou segunda linha – pós-menopausa.</u>  
|**Comparações**|**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência Indireta**|<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe fulvestranto:<br>Fulvestranto<br>+|<br>1|Algumas preocupações|Suspeito|Sem preocupações|Algumas<br>preocupações|Algumas preocupações|Grande<br>preocupação|Muito Baixo|
|Fulvestranto: Palbociclibe<br>Fulvestranto<br>+|1|Algumas preocupações|Suspeito|Sem preocupações|Sem preocupações|Algumas preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+|||||||||
|fulvestranto: Palbociclibe<br>Fulvestranto<br>+|<br>0|Algumas preocupações|Suspeito|Sem preocupações|Algumas<br>preocupações|Algumas preocupações|Grande<br>preocupação|Muito Baixo|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Quadro I** . Avaliação geral da evidência taxa de resposta objetiva. -->
**<u>Quadro I1</u>** <u>. Tratamento de primeira linha pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Letrozol<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Letrozol:<br>Palbociclibe<br>+ letrozol<br>2|Grande<br>preocupação|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Letrozol:<br>ribociclibe<br>+<br>letrozol<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Palbociclibe + letrozol<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):ribociclibe + letrozol<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Palbociclibe<br>+<br>letrozol:<br>ribociclibe + letrozol<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|  
**<u>Quadro I2</u>** <u>. Tratamento primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência Indireta**|<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe fulvestranto:<br>+  1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande preocupação|Muito Baixo|
|Fulvestranto|preocupações|||||||
|Fulvestranto:<br>Palbociclibe<br>+  1|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande preocupação|Sem preocupações|Grande preocupação|Muito Baixo|
|Fulvestranto||||||||
|Abemaciclibe<br>+||||||||
|fulvestranto: Palbociclibe<br>+  0|Algumas|Suspeito|Sem preocupações|Grande preocupação|Sem preocupações|Grande preocupação|Muito Baixo|
|Fulvestranto|preocupações|||||||  
**Quadro J** . Avaliação geral da evidência de resposta objetiva e controle da doença.  
**<u>Quadro J1.</u>** <u>Tratamento de primeira linha – pós-menopausa</u>  
|**Comparações**|**n**|**Viés do estudo**|**Viés de**<br>**publicação**|**Evidência Indireta**|<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe|+<br>1|Algumas|Suspeito|Sem preocupações|Grande preocupação|Sem preocupações|Grande|Muito Baixo|
|(Anastrozol ou||preocupações|||||preocupação||
|Letrozol):Letrozol|||||||||
|Letrozol: Palbociclibe|+<br>2|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito Baixo|
|letrozol||preocupações|||||preocupação||
|Letrozol:<br>ribociclibe|+<br>1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito Baixo|
|letrozol||preocupações|||||preocupação||  
|**Comparações**|**n**|**Viés do estudo**|**Viés de**<br>**publicação**|**Evidência Indireta**|<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>(Anastrozol ou<br>Letrozol):Palbociclibe|+<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|+ letrozol|||||||||
|Abemaciclibe|+<br>0|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito Baixo|
|(Anastrozol ou||preocupações|||||preocupação||
|Letrozol):ribociclibe|+||||||||
|letrozol|||||||||
|Palbociclibe<br>+|0|Algumas|Suspeito|Sem preocupações|Grande preocupação|Sem preocupações|Grande|Muito Baixo|
|letrozol:<br>ribociclibe<br>letrozol|+|preocupações|||||preocupação||  
**<u>Quadro J2.</u>** <u>Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
|**Comparações**<br>|**n**<br>**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>fulvestranto:<br>+|1<br>Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande preocupaçã|o  Muito|
|Fulvestranto|preocupações||||||Baixo|
|Fulvestranto: Palbociclibe<br>+|1<br>Algumas|Suspeito|Sem preocupações|Grande preocupação|Grande preocupação|Grande preocupaçã|o  Muito|
|Fulvestranto|preocupações||||||Baixo|
|Abemaciclibe<br>+||||||||
|fulvestranto: Palbociclibe<br>+|0<br>Algumas|Suspeito|Sem preocupações|Grande preocupação|Grande preocupação|Grande preocupaçã|o  Muito|
|Fulvestranto|preocupações||||||Baixo|  
**<u>Quadro J3.</u>** <u>Tratamento de primeira ou segunda linha – pós-menopausa.</u>  
|**Comparações**<br>|**n**|**Viés do estudo**|**Viés**<br>**de**|**Evidência**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**|
|---|---|---|---|---|---|---|---|---|
||||**publicação**|**Indireta**||||**Final**|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Anastrozol ou<br>Letrozol)<br>|1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe<br>+<br>|1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|fulvestranto:(Anastrozol<br>ou<br>Letrozol)||preocupações|||||preocupação|Baixo|
|(Anastrozol<br>ou<br>|1|Algumas|Suspeito|Sem preocupações|Grande|Grande preocupação|Grande|Muito|
|Letrozol):Fulvestranto||preocupações|||preocupação||preocupação|Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Abemaciclibe<br>+ fulvestranto<br>|1|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe + (Anastrozol ou<br>|1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|Letrozol):Fulvestranto||preocupações|||||preocupação|Baixo|
|Abemaciclibe<br>+<br>|1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|fulvestranto: Fulvestranto||preocupações|||||preocupação|Baixo|
|Fulvestranto: Ribociclibe<br>+<br>|1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|fulvestranto||preocupações|||||preocupação|Baixo|  
|**Comparações**|**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|(Anastrozol<br>ou|0|Algumas|Suspeito|Sem preocupações|Grande|Grande preocupação|Grande|Muito|
|Letrozol):Ribociclibe<br>+||preocupações|||preocupação||preocupação|Baixo|
|fulvestranto|||||||||
|Abemaciclibe + (Anastrozol ou|<br>0|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|Letrozol):Ribociclibe<br>+||preocupações|||||preocupação|Baixo|
|fulvestranto|||||||||
|Abemaciclibe<br>+|0|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande|Muito|
|fulvestranto:<br>Ribociclibe<br>+<br>fulvestranto||preocupações|||||preocupação|Baixo|

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **Quadro K** . Avaliação geral da evidência de eventos adversos gerais. -->
**<u>Quadro K1.</u>** <u>Tratamento de primeira linha – pós-menopausa.</u>  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Abemaciclibe: Abemaciclibe +|1|Grande|Suspeito|Sem|Grande|Sem preocupações|Grande|Muito|
|(Anastrozol ou Letrozol)||preocupação||preocupações|preocupação||preocupação|Baixo|
|Abemaciclibe:<br>Letrozol<br>ou<br>anastrozol|1|Grande<br>preocupação|Suspeito|Sem<br>preocupações|Sem<br>preocupações|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Letrozol<br>ou<br>anastrozol|2|Algumas<br>preocupações|Suspeito|Sem<br>preocupações|Sem<br>preocupações|Grande preocupação|Grande<br>preocupação|Muito<br>Baixo|  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Letrozol<br>ou anastrozol:|2|Algumas|Suspeito|Sem|Grande|Sem preocupações|Grande|Muito|
|Palbociclibe + letrozol||preocupações||preocupações|preocupação||preocupação|Baixo|
|Letrozol<br>ou anastrozol:|1|Algumas|Suspeito|Sem|Grande|Sem preocupações|Grande|Muito|
|ribociclibe + letrozol||preocupações||preocupações|preocupação||preocupação|Baixo|
|Abemaciclibe: Palbociclibe + letrozol|0|Grande<br>preocupação|Suspeito|Sem<br>preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe:<br>ribociclibe + letrozol|0|Algumas<br>preocupações|Suspeito|Sem<br>preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Palbociclibe +<br>letrozol|0|Algumas<br>preocupações|Suspeito|Sem<br>preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito<br>Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):ribociclibe + letrozol|0|Algumas<br>preocupações|Suspeito|Sem<br>preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito<br>Baixo|
|Palbociclibe<br>+ letrozol:|0|Algumas|Suspeito|Sem|Grande|Sem preocupações|Grande|Muito|
|ribociclibe + letrozol||preocupações||preocupações|preocupação||preocupação|Baixo|  
**<u>Quadro K2.</u>** <u>Tratamento de primeira ou segunda linha – pré, peri ou pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>fulvestranto:<br>+  1|Algumas|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande preocupação|Muito|
|Fulvestranto|preocupações||||||Baixo|
|Fulvestranto:<br>+  1|Algumas|Suspeito|Sem preocupações|Grande preocupação|Grande preocupação|Grande preocupação|Muito|
|Palbociclibe|preocupações||||||Baixo|
|Fulvestranto||||||||
|Abemaciclibe<br>+||||||||
|fulvestranto: Palbociclibe<br>+  0|Algumas|Suspeito|Sem preocupações|Grande preocupação|Sem preocupações|Grande preocupação|Muito|
|Fulvestranto|preocupações||||||Baixo|  
**<u>Quadro K3.</u>** <u>Tratamento de primeira ou segunda linha – pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):(Anastrozol ou Letrozol)<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:(Anastrozol ou Letrozol)<sup>1</sup>|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|(Anastrozol<br>ou<br>Letrozol):Fulvestranto<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|  
|**Comparações**<br>**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Abemaciclibe<br>+<br>fulvestranto<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Fulvestranto<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:<br>Fulvestranto<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Fulvestranto:<br>Ribociclibe<br>+<br>fulvestranto<br>1|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|(Anastrozol<br>ou<br>Letrozol):Ribociclibe<br>+<br>fulvestranto<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Ribociclibe + fulvestranto<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:<br>Ribociclibe + fulvestranto<br>0|Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|  
**Quadro L.** Avaliação geral da evidência de eventos adversos graves.  
**<u>Quadro L1.</u>** <u>Tratamento de primeira linha – pós-menopausa.</u>  
|**Comparações**|**n**<br>**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe:<br>Abemaciclibe + (Anastrozol ou<br>Letrozol)|1<br>Grande<br>preocupação|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Abemaciclibe:<br>Letrozol<br>ou<br>anastrozol|1<br>Grande<br>preocupação|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Letrozol<br>ou<br>anastrozol|2<br>Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Letrozol ou anastrozol: Palbociclibe<br>+ letrozol|2<br>Grande<br>preocupação|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Sem preocupações|Muito Baixo|
|Letrozol<br>ou anastrozol:<br>ribociclibe + letrozol|1<br>Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Abemaciclibe:<br>Palbociclibe<br>+<br>letrozol|0<br>Grande<br>preocupação|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Abemaciclibe: ribociclibe + letrozol|0<br>Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|
|Abemaciclibe + (Anastrozol ou<br>Letrozol):Palbociclibe<br>+<br>letrozol|0<br>Algumas<br>preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Sem preocupações|Muito Baixo|  
|**Comparações**|**n**<br>**Viés**<br>**do**|**Viés**<br>**de**|**Evidência**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**|
|---|---|---|---|---|---|---|---|
||**estudo**|**publicação**|**Indireta**||||**Final**|
|Abemaciclibe + (Anastrozol ou|0<br>Algumas|Suspeito|Sem preocupações|Grande|Sem preocupações|Sem preocupações|Muito Baixo|
|Letrozol): ribociclibe +|preocupações|||preocupação||||
|letrozol||||||||
|Palbociclibe<br>+<br>letrozol:|0<br>Algumas|Suspeito|Sem preocupações|Grande|Sem preocupações|Sem preocupações|Muito Baixo|
|ribociclibe + letrozol|preocupações|||preocupação||||  
**<u>Quadro L2.</u>** <u>Tratamento de primeira linha pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés do estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>fulvestranto:<br>Fulvestranto<br>+<br>1|Algumas<br>preocupações|Suspeito|Não detectado|Sem preocupações|Grande preocupação|Grande preocupação|Muito Baixo|
|Fulvestranto:<br>Palbociclibe<br>Fulvestranto<br>+  1|Algumas<br>preocupações|Suspeito|Não detectado|Grande preocupação|Sem preocupações|Grande preocupação|Muito Baixo|
|Abemaciclibe<br>+||||||||
|fulvestranto: Palbociclibe<br>Fulvestranto<br>+<br>0|Algumas<br>preocupações|Suspeito|Não detectado|Sem preocupações|Grande preocupação|Grande preocupação|Muito Baixo|  
**<u>Quadro L3.</u>** <u>Tratamento de primeira linha pós-menopausa.</u>  
|**Comparações**<br>**n**|**Viés do  estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**Indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):(Anastrozol ou Letrozol)<br>1|Sem preocupações|Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:(Anastrozol  ou<br>Letrozol)<br>1|Sem preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|(Anastrozol<br>ou<br>Letrozol):Fulvestranto<br>1|Sem preocupações|<br>Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Abemaciclibe + fulvestranto<sup>1</sup>|Sem preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Fulvestranto<br>1|Sem preocupações|<br>Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:<br>Fulvestranto<br>1|Sem preocupações|<br>Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Fulvestranto:<br>Ribociclibe<br>+<br>fulvestranto<br>1|Sem preocupações|<br>Suspeito|Sem preocupações|Sem preocupações|Grande preocupação|Grande<br>preocupação|Muito Baixo|
|(Anastrozol<br>ou<br>Letrozol):Ribociclibe<br>+<br>fulvestranto<br>0|Sem preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>(Anastrozol<br>ou<br>Letrozol):Ribociclibe + fulvestranto<br>0|Sem preocupações|Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|
|Abemaciclibe<br>+<br>fulvestranto:<br>Ribociclibe + fulvestranto<br>0|Sem preocupações|<br>Suspeito|Sem preocupações|Grande<br>preocupação|Sem preocupações|Grande<br>preocupação|Muito Baixo|  
**APÊNDICE 2 - PROTOCOLOS DE QUIMIOTERAPIA**  
|**Protocolo**<br>T|**Descrição**<br>Paclitaxel 80 mg/m<sup>2</sup>, semanalmente, por 12 semanas|
|---|---|
|Tdd|Paclitaxel 175 mg/m<sup>2</sup>com suporte de fatores estimuladores de colônias de macrófagos/granulócitos<br>(G-CSF), quando disponível, a cada 2 semanas, por 4 ciclos|
|TC ou CT|Docetaxel 75 mg/m² associado à ciclofosfamida 600 mg/m² a cada 21 dias, por 4 a 6 ciclos.|
|AC|Doxorrubicina 60 mg/m², associado à ciclofosfamida 600 mg/m² a cada 21 dias, por 4 ciclos OU a<br>cada 14 dias com suporte de fatores estimuladores de colônias de macrófagos/granulócitos (G-CSF),<br>quando disponível|
|AC-T:|Doxorrubicina 60 mg/m², associado à ciclofosfamida 600 mg/m² a cada 21 dias, por 4 ciclos OU a<br>cada 14 dias com suporte de fatores estimuladores de colônias de macrófagos/granulócitos (G-CSF),<br>quando disponível; seguido de docetaxel 100 mg/m² a cada 21 dias por 4 ciclos OU paclitaxel 175<br>mg/m² a cada 14 dias (considerar risco de neutropenia febril e possível necessidade de suporte de G-<br>CSF, quando disponível) por 4 ciclos OU paclitaxel 80 mg/m² semanal por 12 semanas.<br>Atentar que paclitaxel 175 mg/m² a cada 3 semanas é inferior ao esquema de paclitaxel 80 mg/m²<br>semanal.|
|CMF|Ciclofosfamida 100 mg/m² (D1 a D14) associada ao metotrexato 40 mg/m² (D1 e D8) mais<br>5fluorouracil 600 mg/m² (D1 e D8) a cada 28 dias, por 6 ciclos.|
|FAC|Doxorrubicina 50 mg/m² associado à ciclofosfamida 500 mg/m² associado à fluoruracila 500 mg/m²<br>IV no D1, a cada 21 dias, por 6 ciclos.|
|FEC|Ciclofosfamida 500 mg/m² associado à fluoruracila 500 mg/m² no D1 e D4 associado à epirrubicina<br>75 mg/m² IV no D1. Repetir a cada 21 dias, por 4 ciclos|
|AC-T (paclitaxel a<br>cada 2 semanas)|Doxorrubicina 60 mg/m² associado à ciclofosfamida 600 mg/m², a cada 14 dias, por 4 ciclos, seguido<br>de paclitaxel: 175 mg/m² a cada 14 dias por 4 ciclos. Associar filgrastim 300 mcg do<br>D3 ao D10|
|AC-T<br>(paclitaxel<br>semanal)|Doxorrubicina 60 mg/m² associado à ciclofosfamida 600 mg/m², a cada 14 dias, por 4 ciclos, seguido<br>de paclitaxel 80 mg/m² semanalmente por 12 semanas. Associar filgrastim 300 mcg do D3 ao D10|
|EC|Epirrubicina 90 mg/m² a cada 21 dias associado à ciclofosfamida 600 mg/m² a cada 21 dias por 4<br>ciclos.|
|TAC|Doxorrubicina 50 mg/m² associado à docetaxel 75 mg/m² associado à ciclofosfamida 500 mg/m².<br>Associar filgrastim 300 mcg SC do D2 ao D14 e ciprofloxacino 500 mg VO 12/12h do D5 ao D14.<br>Repetir o ciclo a cada 21 dias, por 6 ciclos|
|AC-TH|Esquema AC-T com a associação de trastuzumabe dose inicial de 8 mg/Kg, IV, em 1 hora e doses<br>subsequentes de 6 mg/Kg, IV, em 30 minutos, a cada 3 semanas até completar um ano de tratamento,<br>iniciando concomitantemente com o taxano. Neste caso, pela facilidade posológica, paclitaxel semanal<br>ou docetaxel a cada 21 dias são preferidos|  
|**Protocolo**|**Descrição**|
|---|---|
|TCH|Docetaxel 75 mg/m² associado à carboplatina AUC<sup>[1]</sup>6 e ao trastuzumabe dose inicial de 8 mg/Kg,<br>IV, em 1 hora e doses subsequentes de 6 mg/Kg, IV, em 30 minutos, a cada 21 dias, por 6 ciclos.<br>Após, o trastuzumabe deve ser continuado a cada 3 semanas até completar um ano de tratamento.|
|T-DM1|Dose máxima recomendada de 3,6 mg/kg, administrada em infusão intravenosa, a cada 3 semanas<br>(ciclo de 21 dias). Pacientes com câncer de mama inicial devem receber tratamento por um total de 14<br>ciclos. Nos casos de redução de dose: primeira redução de dose de 3 mg/kg; segunda redução de dose<br>de 2,4 mg/kg; e se necessidade de nova redução de dose deve descontinuar o tratamento.|
|TH|Paclitaxel 80 mg/m<sup>2</sup>semanalmente por 12 semanas + trastuzumabe a cada 3 semanas, por 6 ciclos,<br>sendo 8 mg/kg na dose de ataque) e 6 mg/kg nas doses seguintes|
|Acdd seguido de T|Doxorrubicina 60 mg/m² associado à ciclofosfamida 600 mg/m², a cada 14 dias, por 4 ciclos. Associar<br>filgrastim: 300 mcg SC do D3 ao D10, seguido de: paclitaxel: 175 mg/m² IV no D1 a cada 14 dias por<br>4 ciclos ou paclitaxel: 80 mg/m² IV semanalmente por 12 semanas.|
|CaT|Paclitaxel 80 mg/m<sup>2</sup>, associado à carboplatina AUC 2, semanalmente, por 12 semanas.|
|PCb|Paclitaxel 80 mg/m<sup>2</sup>D1, D8 e D15, associado à carboplatina AUC 2 D1, D8 e D15, a cada 28 dias,<br>por 6 ciclos.|
|Capecitabina|Capecitabina 1.000–1.250 mg/m<sup>2</sup>VO duas vezes ao dia nos dias 1–14, a cada 21 dias, por 6 a 8 ciclos|
|Pertuzumabe/<br>Trastuzumabe<br>e<br>docetaxel|Pertuzumabe: uma dose inicial de 840 mg, IV, seguida de 420 mg IV a cada 3 semanas, até a<br>progressão de doença ou toxicidade inaceitável;<br>Trastuzumabe: uma dose inicial de 4 mg/kg IV seguida de 2 mg/kg semanal ou uma dose inicial de 8<br>mg/kg seguida de 6 mg/kg a cada 3 semanas, até a progressão de doença ou toxicidade inaceitável; e<br>Docetaxel – 75 mg/m<sup>2</sup>a cada 3 semanas por 4 a 6 ciclos.|
|Trastuzumabe|Um dos dois esquemas terapêuticos:|
|(mono<br>ou<br>poliquimioterapia<br>paliativa de 1ª linha)|Uma dose inicial de 4 mg/kg seguida de 2 mg/kg semanal; ou<br>Uma dose inicial de 8 mg/kg seguida de 6 mg/kg a cada 3 semanas, mantendo- se o tratamento até que<br>se verifique progressão da doença ou toxicidade inaceitável.|  
> <u>[1]</u> Para calcular a dosagem total de carboplatina para atingir uma determinada AUC (Área Abaixo da Curva de concentração plasmática de carboplatina livre versus curva de tempo) usase o método Calvert, levando em consideração a função renal. A dose máxima de carboplatina em AUC 6 é de 900g, enquanto AUC 5 é de 750g.

---

<!-- METADADOS: doenca: PCDT - Câncer de mama | secao: **APÊNDICE 3 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>**Relatório da diretriz**||**Tecnologias avaliad**|**as pela Conitec**|
|---|---|---|---|
|<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório<br>de<br>Recomendação nº 896, de<br>abril de 2024|Ajustes na redação do PCDT<br>para<br>melhorar<br>a<br>sua<br>compreensão|<br> <br>-|-|
||Alteração do formato do<br>documento para PCDT|<br>-|-|
|Relatório<br>de<br>Recomendação nº 789, de<br>novembro de 2022|Inclusão dos medicamentos<br>trastuzumabe entansina e dos<br>inibidores de ciclina|<br> <br>Trastuzumabe<br>entansina<br>no<br>tratamento adjuvante do câncer de<br>mama HER2-positivo operado em<br>estádio III com doença residual na<br>peça cirúrgica após tratamento<br>neoadjuvante<br>[Relatório<br>de<br>Recomendação<br>nº<br>751/2022;<br>Portaria SCTIE/MS nº 98/2022]<br>Abemaciclibe,<br>palbociclibe<br>e<br>succinato de ribociclibe para o<br>tratamento de pacientes adultas com<br>câncer de mama avançado ou<br>metastático com HR+ e HER2-<br>[Relatório de Recomendação nº<br>678/2021; Portaria SCTIE/MS nº<br>73/2021]|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>Trastuzumabe<br>entansina<br>em<br>monoterapia para tratamento de<br>pacientes com câncer de mama<br>HER2-positivo metastático ou<br>localmente<br>avançado<br>iressecável,<br>com<br>tratamento<br>prévio de trastuzumabe e um<br>taxano<br>[Relatório<br>de<br>Recomendação nº 752/2022;<br>Portaria SCTIE/MS nº 99/2022]|
|Portaria Conjunta SAS-<br>SCTIE/MS nº 05, de 18<br>de<br>abril<br>de<br>2019<br>[Relatório<br>de<br>Recomendação<br>nº<br>439/2019]|Alteração das descrições de<br>procedimentos da Tabela de<br>Procedimentos,<br>Medicamentos,<br>Órteses,<br>Próteses<br>e<br>Materiais<br>Especiais do SUS (Portaria<br>SAS/MS nº 523/2019)|<br> <br> <br> <br> <br>Dispensa da obrigatoriedade da<br>realização de exame molecular para<br>confirmação de HER2 quando o<br>resultado do exame de imuno-<br>histoquímica for de 3 cruzes<br>[Registro<br>de<br>Deliberação<br>nº<br>428/2019]|<br> <br> <br> <br>|
|Portaria Conjunta SAS-<br>SCTIE/MS nº 19, de 03<br>de julho de 2018|Inclusão do duplo bloqueio<br>HER2|<br>Pertuzumabe para o tratamento do<br>câncer de mama HER2-positivo<br>metastático em primeira linha de<br>tratamento<br>associado<br>ao|<br> <br> <br>|  
|**Número do**<br>**Relatório da diretriz**||**Tecnologias avaliad**|**as pela Conitec**|
|---|---|---|---|
|<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|||trastuzumabe e docetaxel [Relatório<br>de Recomendação nº 319/2017;<br>Portaria SCTIE/MS nº 57/2017]||
|Portaria Conjunta SAS-<br>SCTIE/MS nº 04, de 23<br>de janeiro de 2018|Inclusão do trastuzumabe<br>para tratamento de câncer de<br>mama<br>HER2-positivo<br>metastático<br>em<br>primeira<br>linha de tratamento|<br> <br> <br> <br>Trastuzumabe para o tratamento do<br>câncer de mama HER2-positivo<br>metastático em primeira linha de<br>tratamento<br>[Relatório<br>de<br>Recomendação<br>nº<br>287/2017;<br>Portaria SCTIE/MS nº 29/2017]|<br> <br> <br> <br> <br>Radioterapia Intraoperatória de<br>Tumores de Mama [Relatório<br>de Recomendação nº 228/2016;<br>Portaria SCTIE/MS nº 32/2016]<br>Mamografia<br>para<br>o<br>rastreamento do câncer de<br>mama<br>em<br>mulheres<br>assintomáticas<br>com<br>risco<br>habitual fora da faixa etária<br>atualmente recomendada<br>(50 a 69 anos) [Relatório de<br>Recomendação nº 178/2015;<br>Portaria SCTIE/MS nº 61/2015]|
|Portaria<br>SAS/MS<br>nº<br>1.008, de 30 de setembro<br>de 2015|Modificação do formato do<br>documento para<br>Diretrizes Diagnósticas e<br>Terapêuticas|<br>Hormonioterapia<br>prévia<br>(préoperatório, neoadjuvante) do<br>câncer de mama [Relatório de<br>Recomendação nº 116/2014;<br>Portaria SCTIE/MS nº 22/2014]|<br> <br> <br>Everolimo para tratamento do<br>câncer de mama avançado na<br>pós-menopausa [Relatório de<br>Recomendação<br>nº<br>91/2013;<br>Portaria SCTIE/MS nº 04/2014]|
|Portaria SAS/MS nº 73,<br>de 30 de janeiro de 2013|Primeira<br>versão<br>do<br>documento - Protocolo de<br>Uso de Trastuzumabe da<br>Quimioterapia do CA de<br>Mama receptor tipo 2 do<br>fator<br>de<br>crescimento<br>epidérmico humano (HER-2)<br>Positivo|<br> <br> <br> <br> <br> <br> <br>Trastuzumabe para tratamento do<br>câncer de mama inicial [Relatório de<br>Recomendação nº 07/2013; Portaria<br>SCTIE/MS nº 19/2012]<br>Trastuzumabe para tratamento do<br>câncer<br>de<br>mama<br>avançado<br>[Relatório de Recomendação nº<br>08/2013; Portaria SCTIE/MS nº<br>18/2012]|<br> <br> <br> <br> <br> <br>|

---

