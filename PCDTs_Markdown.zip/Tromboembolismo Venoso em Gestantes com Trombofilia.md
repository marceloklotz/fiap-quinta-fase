<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: Geral -->
<!-- Start of picture text -->
ee<br>ey<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 23, DE 21 DE DEZEMBRO DE 2021 (*).  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia, no âmbito do SUS.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a prevenção de tromboembolismo venoso em gestantes com trombofilia no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta condição;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 677/2021 e o Relatório de Recomendação ~~n~~<sup><u>o</u></sup> 681 – Novembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da trombofilia na gestação, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-ediretrizes-terapeuticas-pcdt , é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados,</u> do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para a prevenção de tromboembolismo venoso em gestantes com trombofilia.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa condição em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria Conjunta  nº 04/SAES e SCTIE/MS, de 12 de fevereiro de 2020, publicada no Diário Oficial da União (DOU) nº 32, de 14 de fevereiro de 2020, seção 1, página 101.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: HÉLIO ANGOTTI NETO -->
(*) Republicada por ter saído com incorreção no Diário Oficial da União (DOU) nº 245, de 29 de dezembro de 2021, seção 1, página nº 172.  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA A PREVENÇÃO DE TROMBOEMBOLISMO VENOSO EM GESTANTES COM TROMBOFILIA

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **1. INTRODUÇÃO** -->
Trombofilia é a propensão ao desenvolvimento de eventos tromboembólicos, devido a anormalidades do sistema de coagulação, que predispõem à formação de coágulos no sistema circulatório. O Tromboembolismo Venoso (TEV) é a manifestação mais comum da trombofilia. O TEV é uma das principais causas de morbimortalidade materna e pode apresentar como complicações a Trombose Venosa Profunda (TVP) e o Tromboembolismo Pulmonar (TEP).<sup>1</sup>  
As gestantes são 4 a 5 vezes mais propensas a desenvolver TEV do que as mulheres não grávidas. Durante a gravidez normal, há a presença dos três componentes da tríade de Virchow:  
- a) Estase venosa pela diminuição do tônus venoso e obstrução do fluxo venoso pelo aumento do útero;  
b) estado de hipercoagulabilidade com o aumento da geração de fibrina, diminuição da atividade fibrinolítica e aumento dos fatores de coagulação II, VII, VIII e X. Além disso, há uma queda progressiva nos níveis de proteína S e resistência adquirida à proteína C ativada; e  
- c) lesão endotelial, devido à nidação, remodelamento vascular das artérias uteroespiraladas, com o parto e  
- com a dequitação.<sup>2,3</sup>  
O estado de hipercoagulabilidade da gravidez protege a gestante de sangramentos excessivos durante o aborto e o parto. Apesar disso, a maioria das gestantes não precisa de anticoagulação, pois o risco de evento adverso com a anticoagulação supera o benefício.<sup>3–5</sup>  
Estima-se que a incidência global de TEV esteja entre 0,76 a 1,72 por 1.000 gravidezes. O tromboembolismo venoso é responsável por 9,3% das mortes maternas nos Estado Unidos.<sup>6</sup> Em 2019, no Brasil, 8,3% dos óbitos maternos por causas obstétricas indiretas foram decorrentes de doenças do aparelho circulatório.<sup>7</sup>  
O risco de TEV na gravidez é aumentado, devido à presença de trombofilias adquiridas e hereditárias. A trombofilia adquirida, mais relevante, responsável pelo aumento de risco de TEV na gravidez, é a Síndrome Antifosfolipídeo (SAF), que pode cursar com manifestações venosas e arteriais. As trombofilias hereditárias são responsáveis por 50% dos casos de TEV associada à gravidez e têm maior relação com manifestações venosas. As formas de trombofilia hereditária em ordem de relevância na gravidez são: mutações genéticas no fator V de Leiden; mutação no gene da protrombina; e deficiências de antitrombina, de proteína C e de proteína S.<sup>8</sup>  
A mutação da Metileno tetrahidrofolato redutase (MTHFR) não é mais considerada uma trombofilia e, assim, não se contempla neste Protocolo.<sup>9</sup>  
As complicações na gravidez relacionadas à trombose variam desde edema e alterações cutâneas até o desprendimento placentário, pré-eclâmpsia, restrição do crescimento fetal, parto prematuro e aborto espontâneo de repetição.<sup>10,11</sup>  
A identificação precoce de gestantes com risco aumentado para um evento tromboembólico e o encaminhamento ágil e adequado para o atendimento especializado, além da coordenação do cuidado da  
gestante, dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos, minimizando desfechos negativos relacionados à trombofilia.<sup>3</sup>  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos para a prevenção de tromboembolismo venoso em gestantes com trombofilia. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 2** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- D68.8 Outros defeitos especificados da coagulação  
- I82.0 Síndrome de Budd-Chiari  
- I82.1 Tromboflebite migratória  
- I82.2 Embolia e trombose de veia cava  
- I82.3 Embolia e trombose de veia renal  
- I82.8 Embolia e trombose de outras veias especificadas  
- O22.3 Flebotrombose profunda na gravidez  
- O22.5 Trombose venosa cerebral na gravidez  
**NOTA:** Para fins deste Protocolo, os códigos acima especificados são aplicáveis a casos de gestantes.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3. DIAGNÓSTICO** -->
_Adianta-se que a investigação laboratorial (rastreamento) de trombofilias para todas as gestantes não_  
_está indicada._<sup>12</sup>  
A avaliação laboratorial deve ser efetuada apenas em casos de:  
a) Mulheres com história pessoal de TEV, com ou sem fator de risco recorrente e sem teste de trombofilia  
prévio;  
b) mulheres com história familiar de trombofilia hereditária em parentes de primeiro grau (apenas investigar trombofilias hereditárias); ou  
c) mulheres com história clínica compatível com Síndrome Antifosfolipídeo, conforme os critérios apresentados no item 3.2. Diagnóstico de Síndrome Antifosfolipídeo – SAF).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3.1. Diagnóstico de Trombofilia Hereditária** -->
Nesses casos, o diagnóstico deve ser feito com os seguintes exames: Fator V de Leiden, mutação G20210A no gene da protrombina, dosagem de antitrombina III, dosagem de proteína C funcional e dosagem de proteína S livre ou dosagem de proteína S funcional<sup>13</sup> . Idealmente, esses exames devem ser solicitados em pacientes antes da gravidez, que não estão em uso de anticoagulantes nem de terapia hormonal<sup>4</sup> , devendo ser evitada a investigação de TEV na fase aguda da trombose, principalmente com os exames de proteína C, S e antitrombina III<sup>14</sup> .  
As trombofilias hereditárias são divididas em:  
ALTO RISCO: Caracterizada pela mutação homozigótica para o fator V de Leiden; mutação homozigótica para o gene da protrombina; deficiência da antitrombina III; mutações heterozigóticas para o fator V de Leiden e do gene da protrombina associadas, Síndrome Antifosfolipídeo (SAF); e  
BAIXO RISCO: Caracterizada pela mutação heterozigótica para o fator V de Leiden; mutação heterozigótica para o gene da protrombina; deficiência da proteína C ou da proteína S.<sup>6</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3.2. Diagnóstico de Síndrome Antifosfolipídeo – SAF** -->
A Síndrome Antifosfolipídeo (SAF) é diagnosticada pela presença de, pelo menos, um critério clínico associado a, pelo menos, um critério laboratorial, conforme abaixo:

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3.2.1. Critérios clínicos** -->
a) Um ou mais episódios de trombose venosa ou arterial (exame de imagem ou evidência histológica sem  
sinal de vasculite);  
b) histórico de, pelo menos, três abortamentos precoces (com menos de 10 semanas) sem causa aparente;  
c) histórico de óbito fetal com mais de dez semanas com produto morfologicamente normal e sem causa  
aparente; ou  
d) histórico de parto prematuro antes de 34 semanas com pré-eclâmpsia grave, eclampsia ou insuficiência placentária.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3.2.2. Critérios Laboratoriais** -->
Deve estar presente em duas ou mais ocasiões com intervalo mínimo de 12 semanas, um dos seguintes:  
a) Anticoagulante lúpico detectado de acordo com as recomendações da Sociedade Internacional de Trombose e Hemostasia (ISTH), por ser um teste de complexa execução, uma vez que o anticoagulante lúpico é um antifosfolipídeo que prolonga os testes de coagulação _in vitro_ (efeito anticoagulante), mas que, _in vivo_ , associa-se a um efeito coagulante<sup>15</sup> ;  
b) anticardiolipinas IgG ou IgM em títulos moderados (>40 unidades de GPL/MPL) a altos (>80 unidades  
de GPL/MPL) mensurados por teste ELISA padronizado; ou  
c) anti-beta2glicoproteína1 IgG ou IgM acima do percentil 99 mensurada por teste ELISA padronizado.<sup>15</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídas neste Protocolo as gestantes e puérperas com trombofilia e:  
a) História pessoal de TEV;  
b) diagnóstico de SAF comprovado clínico e laboratorialmente;  
c) história familiar (parente de 1º grau) de trombofilia hereditária de alto risco; ou  
d) história familiar (parente de 1º grau) de trombofilia hereditária de baixo risco com TEV.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídas deste Protocolo as gestantes com:  
a) Hipersensibilidade à enoxaparina sódica, à heparina e seus derivados, inclusive outras heparinas de baixo peso molecular;  
b) hemorragia ativa de grande porte e condições com alto risco de desenvolvimento de hemorragia incontrolável; ou  
c) história de acidente vascular cerebral hemorrágico recente.<sup>16</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6. TRATAMENTO** -->
_Adianta-se que as mulheres portadoras de anticorpos antifosfolipídeos sem eventos clínicos (trombóticos_  
_ou obstétricos) deverão ser tratadas de forma similar às pacientes com trombofilia hereditária de baixo risco._

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.1. Anticoagulação Profilática** -->
Sendo as trombofilias condições que predispõem ao desenvolvimento de eventos tromboembólicos, este  
Protocolo baseia-se em esquemas de anticoagulação com vistas à prevenção de tais eventos durante o período gestacional, nas doses especificadas na **Tabela 1** .

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.1.1. Anticoagulação durante o pré-natal e por até seis semanas no pós-parto** -->
Indica-se a profilaxia de complicações da trombofilia nos casos de gestante com:  
a) História pessoal de TEV e moderado a alto risco de recorrência (único episódio não provocado; TEV  
relacionado a gravidez ou anticoncepção hormonal contendo estrogênio; ou múltiplos TEV prévios não provocados);  
b) diagnóstico de SAF comprovado clínico e laboratorialmente; ou  
c) trombofilia de alto risco e história de TEV em parente de 1º grau.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.1.2. Anticoagulação apenas por até seis semanas no pós-parto** -->
No pós-parto, indica-se a anticoagulação profilática nos casos de gestante com:  
a) trombofilia de alto risco e sem história pessoal ou familiar de TEV;  
b) trombofilia de baixo risco e com TEV em parente de primeiro grau; ou  
c) histórico pessoal de TEV com baixo risco de recorrência (trauma, imobilização, cirurgia de longa  
duração, sem relação com anticoncepcional hormonal ou gravidez).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.2. Anticoagulação Plena** -->
Em casos de gestante com diagnóstico de SAF e trombose vascular ou com dois ou mais episódios de  
TEV é recomendada a anticoagulação plena, aqui entendida como a heparinização nas doses especificadas na **Tabela 2** .

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.3. Fármacos** -->
Neste Protocolo, são preconizadas as seguintes apresentações dos medicamentos:  
- Enoxaparina sódica - solução injetável de 40 mg/0,4 mL e de 60 mg/0,6 mL; e  
- Ácido acetilsalicílico (AAS) – comprimidos de 100 mg.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Enoxaparina** -->
A enoxaparina sódica é uma heparina de baixo peso molecular obtida pela despolimerização alcalina do éster-benzil-heparina derivado da mucosa intestinal suína. Apresenta alta atividade anti-Xa (aproximadamente 100 UI/mg) e baixa atividade anti-IIa ou antitrombina (aproximadamente 28 UI/mg).  
Essas atividades anticoagulantes são mediadas por antitrombina III (ATIII), resultando em atividade antitrombótica em humanos. Além da sua atividade anti-Xa/IIa, as propriedades antitrombótica e antiinflamatória da enoxaparina foram identificadas em indivíduos saudáveis e em pacientes, bem como em modelos não clínicos. Estes incluem inibição ATIII-dependente de outros fatores de coagulação, como o fator VIIa, indução da liberação do inibidor da Via do Fator Tecidual endógeno, assim como uma liberação reduzida de fator de von Willebrand do endotélio vascular para a circulação sanguínea. Estes fatores são conhecidos por contribuir para o efeito antitrombótico global da enoxaparina.  
A enoxaparina sódica é um fármaco de baixa depuração, com média de clearance plasmático anti-Xa de 0,74 L/h após infusão intravenosa de 1,5 mg/kg em 6 horas. A eliminação parece ser monofásica, com meia-vida de aproximadamente 4 horas após uma dose subcutânea única e até aproximadamente 7 horas após doses repetidas. A depuração ( _clearance_ ) renal dos fragmentos ativos representa aproximadamente 10% da dose administrada e a excreção renal total dos fragmentos ativos e não-ativos é de 40% da dose.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Ácido acetilsalicílico** -->
O AAS inibe a agregação plaquetária bloqueando a síntese do tromboxano A2 nas plaquetas. Seu mecanismo de ação baseia-se na inibição irreversível da ciclooxigenase (COX-1). Esse efeito inibitório é especialmente acentuado nas plaquetas porque elas não são capazes de sintetizar novamente essa enzima. Acredita-se que o AAS tenha outros efeitos inibitórios sobre as plaquetas. Por essa razão é usado para várias indicações relacionadas com o sistema vascular.  
Após a administração oral, o AAS é rápida e completamente absorvido pelo trato gastrintestinal. Durante e após a absorção, o AAS é convertido em ácido salicílico, seu principal metabólito ativo. Os níveis plasmáticos máximos de AAS são atingidos após 10 a 20 minutos e os de ácido salicílico após 0,3 a 2 horas. Tanto o ácido acetilsalicílico como o ácido salicílico ligam-se amplamente às proteínas plasmáticas e são rapidamente distribuídos por todas as partes do organismo.  
O ácido salicílico passa para o leite materno e atravessa a placenta. O ácido salicílico é eliminado principalmente por metabolismo hepático; os metabólitos incluem o ácido salicilúrico, o glicuronídeo salicilfenólico, o glicuronídeo salicilacílico, o ácido gentísico e o ácido gentisúrico. A cinética da eliminação do ácido salicílico é dependente da dose, uma vez que o metabolismo é limitado pela capacidade das enzimas hepáticas. Desse modo, a meia-vida de eliminação varia de 2 a 3 horas após doses baixas até cerca de 15 horas com doses altas. O ácido salicílico e seus metabólitos são excretados principalmente por via urinária.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.4. Posologia** -->
**Anticoagulação profilática**  
- Enoxaparina sódica: Dose única diária de 40 mg ou 60 mg (a depender do peso corporal da paciente) por via subcutânea, durante a gestação e até no máximo 6 semanas de pós-parto.<sup>6,9,17,18</sup> ( **Tabela 1** )  
**Tabela 1** - Dose profilática de enoxaparina sódica por peso da gestante  
|**Peso da gestante**|**Dose profilática de enoxaparina sódica**|
|---|---|
|Até 89 kg<br>Acima de90 kg|40 mg/dia<br>60 mg/dia|  
- AAS: 100 mg, uma vez ao dia, por via oral, associado à enoxaparina sódica, nos casos de gestante com diagnóstico de SAF.  
O AAS pode ser suspenso, a critério médico, a partir da 36ª semana de gestação.<sup>19,20</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Anticoagulação plena** -->
- Enoxaparina sódica: dose de 60 mg ou 80 mg, por via subcutânea a cada 12 horas, não podendo ultrapassar 160 mg/dia.<sup>6,9,17,18,21</sup> ( **Tabela 2** )  
**Tabela 2** - Dose plena de enoxaparina sódica por peso da gestante  
|**Peso da gestante**|**Dose plena de enoxaparina sódica**|
|---|---|
|Até 69 kg|60 mg de 12 em 12 horas|
|Acima de 70 kg|80 mgde 12 em 12 horas*|  
* A dose de 80 mg pode ser administrada com duas seringas de 40 mg.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.5. Via de administração** -->
A enoxaparina sódica deve ser administrada, exclusivamente, por via subcutânea, conforme as orientações contidas na bula do fabricante.  
O ácido acetilsalicílico deve ser administrado, exclusivamente, por via oral.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.6. Preparo do local para administração da enoxaparina** -->
O local recomendado para injeção é na gordura da parte inferior do abdômen a, pelo menos, 5 centímetros de distância do umbigo para fora e em ambos os lados. Antes da injeção, deve-se lavar as mãos e limpar (não esfregar) com álcool 70% o local selecionado para a injeção. Selecionar um local diferente do abdômen inferior a cada aplicação, alternando o lado direito com o lado esquerdo e evitando áreas com presença de equimose (mancha na pele de coloração arroxeada que indica extravasamento de sangue).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Enoxaparina** -->
- Hipersensibilidade à enoxaparina sódica, à heparina e seus derivados, inclusive outras heparinas de  
- baixo peso molecular;  
- história de trombocitopenia induzida por heparina mediada por imunidade (HIT) nos últimos 100 dias  
- ou na presença de anticorpos circulantes; ou  
**-** hemorragias ativas de grande porte e condições com alto risco de desenvolvimento de hemorragia incontrolável, incluindo acidente vascular cerebral hemorrágico recente.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Ácido acetilsalicílico** -->
- Hipersensibilidade ao AAS, a outros salicilatos ou a qualquer outro componente do produto;  
- histórico de asma induzida pela administração de salicilatos ou substâncias com ação similar,  
principalmente fármacos anti-inflamatórios não-esteroidais;  
- úlceras gastrintestinais agudas;  
- diátese hemorrágica (hemorragia por defeito da coagulação, congênito ou adquirido);  
- insuficiência renal grave;  
- insuficiência hepática grave; ou  
- insuficiência cardíaca grave.  
O fluxograma para a profilaxia de TEV em gestantes com trombofilia está detalhado na **Figura 1** .  
<!-- Start of picture text -->
Apresenta histéria pessoal<br>de TEV? *<br>SIM NAO<br>SindromeApresenta diagnésticode<br>ou Antifosfolipideo Apresenta diagnéstico de<br>2 ou mais Gales de | Sindrome Antifosfolipideo?<br>NAO TEV: | NAO sim<br>| SIM<br>Baixo risco Alto risco Anticoagulacao plena ; Anticoagulacao<br>de de no pré-natal e até 6 Trombofilia Trombofilia profiltica + AAS<br>cen EpE recorencians) semanas no pés-parto de baixo risco? * de alto risco? * no pré-natal e pés-parto<br>TEVem TEVem<br>parente de parente de<br>Anticoagulacdo profildtica eeearbalie 12 grau? L [ 12 grau? am]<br>no pés-parto semanascn) eee no to sim | Nko NAo 1M<br>Anticoagulagao profilatica<br>Anticoagulacao profilatica Vigilancia Anticoagulacao profilatica no pré-natal e até 6<br>no pés-parto Clinica no pés-parto semanas no pés-parto<br>1deTrauma,longa duracdo,imobilizacao,ansem cirurgiarelacao iy#peer TEV Gnicoideisre episédioGene)a ndio-provocado;Galaeycn Leiden;OGda protrombina;(TEEDOMe heterozigoticadeficiénciaei POOda para REAICSproteinao geneC **Leiden;protrombina;Mutagaomutacdohomozigéticadeficléndahomozigéticadeparaantitrombinaparao Fatoro geneV deillda<br>com anticoncepcional hormonal estrogénio; ou miiltiplos TEV prévios ou da proteina S e presenca de anticorpo mutagées heterozigéticas para o Fator V de<br>ou gravidez. oi falasdiinicos. pan na auséncia de eventos Teraratioveene’da trotonsinatesenciacios<br><!-- End of picture text -->  
**Figura 1 -** Fluxograma do tratamento para prevenção de tromboembolismo venoso em gestantes com trombofilia

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.8. Tempo de Tratamento - Critérios de Interrupção** -->
A profilaxia no período pré-natal, quando indicada, deve ser realizada precocemente desde o primeiro trimestre e o medicamento deve ser interrompido na fase latente do trabalho de parto, devendo ser reiniciado 6 a 12 horas após o parto vaginal.  
Nos casos de cesariana eletiva, os medicamentos devem ser interrompidos antes da intervenção.<sup>20</sup> _Se a dose for profilática, a suspensão deverá ser feita 12 horas antes e, se dose plena, 24 horas antes. A reintrodução deve ocorrer de 6 a 8 horas após a raquianestesia peridural ou a retirada do cateter peridural._  
A profilaxia no período pós-parto deve ser interrompida após 6 semanas do parto.<sup>6</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Enoxaparina** -->
Assim como qualquer outra terapia anticoagulante, a enoxaparina deve ser utilizada com cautela em condições com alto risco de hemorragia, tais como: alterações na hemostasia; histórico de úlcera péptica; acidente vascular cerebral isquêmico recente; hipertensão arterial grave não controlada; retinopatia diabética; neurocirurgia ou cirurgia oftálmica recente; e uso concomitante de medicamentos que afetem a hemostasia.  
_Não administrar enoxaparina por via intramuscular_ .<sup>19</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Ácido acetilsalicílico** -->
O AAS deve ser usado com cautela nos seguintes casos: hipersensibilidade a analgésicos, anti-inflamatórios ou antirreumáticos; histórico de úlceras gastrintestinais, incluindo úlcera crônica ou recidivante ou histórico de sangramentos gastrintestinais. Também deve-se ter cautela com o uso concomitante de AAS e anticoagulantes, como cumarina e heparina, pois aumenta o risco de sangramento.  
Além disso, deve-se ter atenção com pacientes com insuficiência renal ou pacientes com insuficiência cardiovascular, uma vez que o AAS pode aumentar o risco de dano renal ou insuficiência renal aguda. Em pacientes que sofrem com deficiência de G6PD (glicose-6-fosfato desidrogenase), doença hereditária que afeta as células vermelhas do sangue, o uso do AAS também pode induzir a hemólise (destruição das células sanguíneas) ou anemia hemolítica, com risco aumentado nos casos de dose alta, febre ou infecções agudas.  
O uso concomitante de AAS e metotrexato em doses iguais ou maiores que 15 mg/semana de metotrexato é contraindicado.  
O AAS pode desencadear broncoespasmo e induzir ataques de asma ou outras reações de hipersensibilidade. Em doses baixas, o ácido acetilsalicílico reduz a excreção do ácido úrico. Essa redução pode desencadear crises de gota em pacientes predispostos.  
Produtos que contêm AAS não devem ser utilizados por crianças e adolescentes para quadros de infecções virais com ou sem febre, sem antes consultar um médico. Em certas doenças virais, especialmente as causadas por varicela e vírus influenza A e B, há risco da Síndrome de Reye, uma doença muito rara, mas com potencial risco para a vida do paciente, que requer ação médica imediata. O risco pode aumentar quando o AAS é administrado concomitantemente na vigência desta doença embora a relação causal não tenha sido comprovada. Vômitos persistentes na vigência destas doenças podem ser um sinal de Síndrome de Reye.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.10. Eventos adversos** -->
Assim como com todos os anticoagulantes, a hemorragia é o principal evento adverso (EA) da anticoagulação, podendo ocorrer em qualquer local e principalmente na presença de fatores de risco associados, como lesões orgânicas suscetíveis a sangramento, procedimentos invasivos ou uso de associações medicamentosas que afetam a coagulação.  
Outros eventos adversos menos comumente relatados em ensaios clínicos foram: trombocitose, trombocitopenia, hematoma, dor local, urticária, prurido, eritema, reação alérgica e aumento das enzimas hepáticas.  
O AAS provoca efeitos gastrintestinais, como dor abdominal, azia, náusea, vômito, úlcera e perfuração gastroduodenal, e; hemorragia gastrintestinal oculta ou evidente (hematêmese, melena) que pode causar anemia por deficiência de ferro. Esse tipo de sangramento é mais comum quando a posologia é maior.  
Também podem-se manifestar efeitos deletérios sobre o sistema nervoso central, como tontura e zumbido, que geralmente indicam superdose. Da mesma forma, podem ocorrer efeitos hemorrágicos, pois, devido ao efeito sobre a agregação plaquetária, o AAS pode ser associado com aumento do risco de sangramento. Reações de hipersensibilidade, por exemplo, urticária, reações cutâneas, reações anafiláticas, asma e edema de Quincke podem ser observadas.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.11. Interações** -->
Interações podem ocorrer entre medicamentos e entre medicamento e exame laboratorial:

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Enoxaparina** -->
Recomenda-se a interrupção do uso de medicamentos que afetam a hemostasia antes do início do tratamento com enoxaparina, a menos que seu uso seja estritamente indicado. Tais medicamentos incluem: salicilatos sistêmicos, AAS e outros AINEs, incluindo o cetorolaco; dextrana 40, ticlopidina e clopidogrel; glicocorticoides sistêmicos; agentes trombolíticos e anticoagulantes; e outros agentes antiplaquetários, incluindo os antagonistas de glicoproteína IIb/IIIa. Em caso de indicação do uso de qualquer uma destas associações, deve-se utilizar enoxaparina sob cuidadoso monitoramento clínico e laboratorial.<sup>19</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Ácido acetilsalicílico** -->
<u>Anticoagulantes, trombolíticos/outros inibidores da agregação plaquetária/hemostase: Aumento do risco de</u> sangramento.  
<u>Outros anti-inflamatórios não esteroidais com salicilatos em doses elevadas: Aumento do risco de úlceras e</u>  
sangramento gastrintestinal devido ao efeito sinérgico.  
<u>Inibidores seletivos da recaptação de serotonina (SSRIs): Aumento do risco de sangramento gastrintestinal superior,</u> possivelmente em razão do efeito sinérgico.  
<u>Digoxina: Aumento das concentrações plasmáticas de digoxina em função da diminuição da excreção renal.</u>  
<u>Antidiabéticos (como insulina e sulfonilureias): Aumento do efeito hipoglicêmico por altas doses do AAS pela ação</u> hipoglicêmica do AAS e deslocamento da sulfonilureia de sua ligação nas proteínas plasmáticas.  
<u>Diuréticos em combinação com AAS em altas doses: Diminuição da filtração glomerular por diminuição da síntese</u> renal de prostaglandina.  
<u>Glicocorticoides sistêmicos, exceto hidrocortisona usada como terapia de reposição na doença de Addison:</u> Diminuição dos níveis de salicilato plasmático durante o tratamento com corticosteroide e risco de superdose de salicilato após interrupção do tratamento, devido ao aumento da eliminação de salicilatos pelos corticosteroides.  
<u>Inibidores da enzima conversora de angiotensina (ECA) em combinação com o AAS em altas doses: Diminuição da</u> filtração glomerular por inibição das prostaglandinas vasodilatadoras. Além de diminuição do efeito anti- hipertensivo.  
<u>Ácido valproico: Aumento da toxicidade do ácido valproico devido ao deslocamento dos sítios de ligação com as</u> proteínas.  
<u>Álcool: Aumento do dano à mucosa gastrintestinal e prolongamento do tempo de sangramento devido aos efeitos</u> aditivos do AAS e do álcool;  
<u>Uricosúricos</u> (como benzbromarona e probenecida): Diminuição do efeito uricosúrico (competição na eliminação renal tubular do ácido úrico).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.11.2. Medicamento-exame laboratorial** -->
Nas doses utilizadas para a profilaxia do tromboembolismo venoso, a enoxaparina não influencia significativamente o tempo de sangramento e os testes de coagulação sanguínea global nem afeta a agregação plaquetária ou a ligação do fibrinogênio às plaquetas. Pode ocorrer aumento do tempo de tromboplastina parcial ativada (TTPa) e do tempo de coagulação ativada (TCA) com a administração de doses mais altas. Aumentos no TTPa e TCA não estão linearmente correlacionados ao aumento da atividade antitrombótica de enoxaparina, sendo, portanto, inadequados e inseguros para o monitoramento da atividade do medicamento.<sup>19</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.12. Antídoto em caso de hemorragias** -->
Em caso de hemorragia, com perda de quantidade significativa de sangue e instabilidade hemodinâmica, a gestante em uso de enoxaparina deve ser encaminhada para unidades de urgência e emergência obstétricas, para avaliação e tratamento. Os efeitos anticoagulantes podem ser, em grande parte, neutralizados pela administração intravenosa lenta de protamina em ambiente hospitalar.<sup>19</sup>  
A dose de protamina depende da dose de enoxaparina administrada, ou seja, 1 mg de protamina neutraliza parcialmente o efeito anticoagulante de 1 mg de enoxaparina, nas primeiras 8 horas após a administração.  
Caso seja necessária uma segunda dose de protamina (após 8 horas da primeira administração), é indicada a infusão de 0,5 mg de protamina para 1 mg de enoxaparina.  
Após 12 horas da injeção de enoxaparina, a administração da protamina pode não ser necessária. Entretanto, mesmo com doses elevadas de protamina, a atividade anti-Xa de enoxaparina nunca é completamente neutralizada, pois alcança-se no máximo 60%, aproximadamente.  
_Para pacientes com SAF, orienta-se cautela no uso de protamina, devido ao risco aumentado de ocorrer trombose._

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **6.13. Pacientes em uso de outros anticoagulantes previamente à gestação** -->
Pacientes que engravidaram em uso de anticoagulantes orais, como varfarina, rivaroxabana ou dabigatrana,  
deverão trocar estes medicamentos por enoxaparina, e a dose a ser recomendada será prescrita de acordo com o fluxograma terapêutico preconizado neste Protocolo ( **Figura 1** ).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **7. MONITORAMENTO** -->
O risco de trombocitopenia induzida por heparina (reação mediada por anticorpos) também existe com heparinas de baixo peso molecular. Pode ocorrer trombocitopenia, geralmente entre o 5º e 21º dia após o início do tratamento com enoxaparina, com diminuição significativa da contagem plaquetária (50% do valor inicial), podendo apresentar trombose ou outra sequela clínica e sem outras causas que justifiquem a trombocitopenia. Portanto, recomenda-se a realização do hemograma completo antes do início do tratamento<sup>19</sup> e deve ser solicitado a cada 3 meses, após o início do anticoagulante. A contagem de plaquetas deve ser solicitada sempre que houver suspeita de trombose durante a terapia.<sup>16</sup> A creatinina sérica deve ser solicitada em todos as gestantes em uso de anticoagulantes. Em pacientes com taxa de filtração glomerular abaixo de 30 mL/min, reavaliar o uso da enoxaparina.<sup>22</sup>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
As gestantes com risco aumentado para trombofilia devem ser encaminhadas para a Atenção Especializada para o devido tratamento do quadro, a fim de que morbidades sejam minimizadas e mortalidade materna, fetal e perinatal seja evitada.<sup>6,22</sup> As gestantes que tiveram o diagnóstico de trombofilia antes do início da gestação, já utilizando ou não medicamentos, também devem ser acompanhadas em serviço especializado.  
Gestantes em uso de anticoagulante, prescrito antes da vigência deste Protocolo, deverão ser reavaliadas quanto aos critérios de sua inclusão nele estabelecidos.  
A gestante que for encaminhada deve manter o acompanhamento concomitante com a equipe da Atenção Primária para garantir um cuidado adequado e integral. A troca de informações entre a Atenção Primária e serviços especializados por meio de instrumentos de “referência e contra referência” é essencial para definir a qualidade do cuidado ofertado.  
Gestantes sob uso de anticoagulante durante o pré-natal devem ter o parto assistido em unidade hospitalar. Considerando que o parto cesáreo tem risco de TEV quatro vezes maior que o parto vaginal, recomenda-se que a via de parto deverá seguir os critérios obstétricos.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizados os dados referentes aos registros de estoque, distribuição, dispensação e administração da enoxaparina e encaminhá-los ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.<sup>23</sup>  
As orientações para a Assistência Farmacêutica no SUS dispensar os medicamentos preconizados neste Protocolo encontram-se no **Apêndice 1** .

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se cientificar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **10. REFERÊNCIAS** -->
1. Previtali E, Bucciarelli P, Passamonti SM, Martinelli I. Risk factors for venous and arterial thrombosis. Blood Transfus [Internet]. 2011 [cited 2021 Jul 12];9(2):120. Available from: /pmc/articles/PMC3096855/  
2. Oliveira ALML de, Marques MA. Profilaxia de tromboembolismo venoso na gestação. J Vasc Bras [Internet]. 2016 Oct 1 [cited 2021 Jul 12];15(4):293. Available from: /pmc/articles/PMC5829728/  
3. Devis P, Knuttinen MG. Deep venous thrombosis in pregnancy: Incidence, pathogenesis and endovascular management. Cardiovasc Diagn Ther. 2017 Dec 1;7:S300–19.  
4. Ginsberg JS, Kowalchuk G, Hirsh J, Brill-Edwards P, Burrows R. Heparin Therapy During Pregnancy: Risks to the Fetus and Mother. Arch Intern Med [Internet]. 1989 Oct 1 [cited 2021 Jul 12];149(10):2233–6. Available from: https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/612322  
5. A K. Postpartum venous thromboembolism prophylaxis may cause more harm than benefit: a critical analysis of international guidelines through an evidence-based lens. BJOG [Internet]. 2018 Aug 1 [cited 2021 Jul 12];125(9):1109–16. Available from: https://pubmed.ncbi.nlm.nih.gov/29512316/  
6. American College of Obstetricians and Gynecologists’ Committee on Practice Bulletins—Obstetrics. ACOG Practice Bulletin No. 196: Thromboembolism in Pregnancy. Obstet Gynecol [Internet]. 2018 Jul 1 [cited 2021 Jul 12];132(1):e1–17. Available from: https://pubmed.ncbi.nlm.nih.gov/29939938/  
7. Ministério da Saúde S de V em S. Mortalidade proporcional por grupos de causas em mulheres no Brasil em 2010 e 2019. 2021 [cited 2021 Dec 17]; Available from: https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/boletins/boletins-epidemiologicos/2021/boletim_epidemiologico_svs_29.pdf  
8. Battinelli EM, Marshall A, Connors JM. The Role of Thrombophilia in Pregnancy. 2013 [cited 2021 Jul 12];2013. Available from: http://dx.  
9. American College of Obstetricians and Gynecologists’ Committee on Practice Bulletins—Obstetrics. ACOG Practice Bulletin No. 197: Inherited Thrombophilias in Pregnancy. Obstet Gynecol [Internet]. 2018 Jul 1 [cited 2021 Jul 12];132(1):e18–34. Available from: https://pubmed.ncbi.nlm.nih.gov/29939939/  
10. D’Amico EA. Trombofilia: quando suspeitar e como investigar? Rev Assoc Med Bras [Internet]. 2003 Jan [cited 2021 Jul 12];49(1):7–8. Available from: http://www.scielo.br/j/ramb/a/rJKwdntDYZ9pXttgtxBJwKH/?lang=pt  
11. James AH, Jamison MG, Brancazio LR, Myers ER. Venous thromboembolism during pregnancy and the postpartum period: Incidence, risk factors, and mortality. Am J Obstet Gynecol. 2006 May 1;194(5):1311–5.  
12. Chan WS, Rey E, Kent NE, Corbett T, David M, Douglas MJ, et al. Venous Thromboembolism and Antithrombotic Therapy in Pregnancy. J Obstet Gynaecol Canada. 2014 Jun 1;36(6):527–53.  
13. Middeldorp S. Inherited thrombophilia: a double-edged sword. Hematol Am Soc Hematol Educ Progr [Internet]. 2016 [cited 2021 Jul 12];2016(1):1–9. Available from: https://pubmed.ncbi.nlm.nih.gov/27913455/  
14. Nascimento CMDB, Machado AMN, Guerra JC de C, Zlotnik E, Campêlo DHC, Kauffman P, et al. Consensus on the investigation of thrombophilia in women and clinical management. Einstein (Sao Paulo). 2019 Aug 19;17(3):eAE4510.  
15. Danowski A, Rego J, Kakehasi AM, Funke A, de Carvalho JF, Lima IVS, et al. Guidelines for the treatment of antiphospholipid syndrome. Rev Bras Reumatol (English Ed. 2013 Mar 1;53(2):184–92.  
16. Gernsheimer T, James AH, Stasi R. How I treat thrombocytopenia in pregnancy. Blood [Internet]. 2013 Jan 3 [cited 2021 Jul 12];121(1):38–47. Available from: http://ashpublications.org/blood/articlepdf/121/1/38/1363464/zh800113000038.pdf  
17. Royal College of Obstetricians and Gynaecologists. Reducing the Risk of Venous Thromboembolism during Pregnancy and the Puerperium. RCOG Green-top Guideline No. 37a. 2015.  
18. Bates SM, Greer A, Middeldorp S, Veenstra DL, Prabulos AM, Vandvik PO. VTE, Thrombophilia, Antithrombotic Therapy, and Pregnancy: Antithrombotic Therapy and Prevention of Thrombosis, 9th ed: American College of Chest Physicians Evidence-Based Clinical Practice Guidelines. Chest. 2012 Feb 1;141(2):e691S-e736S.  
19. Sanofi Medley Farmacêutica Ltda. Clexane ® (enoxaparina sódica) Bula do profissional de saúde. 2020;1–30. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
20. Trajano AJB, Monteiro DLM, Jesús NR de. Série Rotinas Hospitalares: Obstetrícia, Hospital Universitário Pedro Ernesto - HUPE [Internet]. 2<sup>a</sup> . Rio de Janeiro: EdUERJ - Editora da Universidade do Estado do Rio de Janeiro; 2017 [cited 2021 Jul 12]. 276 p. Available from: https://eduerj.com/eng/?product=hupe-serie-rotinas-hospitalaresobstetricia-2a-edicao  
21. Rey E, Kent NE, Corbett T, Ab E, David M, Douglas MJ, et al. Venous Thromboembolism and Antithrombotic Therapy in Pregnancy. J Obstet Gynaecol Canada. 2014;36(308):527–53.  
22. Silveira EO da. Estudo de marcadores trombofílicos associados à gravidez de alto risco. Universidade do Estado do Amazonas-UEA. Fundação Hospitalar de Hematologia e Hemoterapia do Amazonas - FHEMOAM. Programa de Pós graduação em Hematologia. Universidade do Estado do Amazonas - UEA; 2016.  
23. Brasil. Portaria de Consolidação n.o 1, de 28 de setembro de 2017 [Internet]. 2017. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0001_03_10_2017.html

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: ENOXAPARINA SÓDICA E ÁCIDO ACETILSALICÍLICO. -->
Eu, _____________________________________________ (nome da paciente), declaro ter sido informada claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso da enoxaparina sódica e do ácido acetilsalicílico (AAS), indicados para a prevenção de tromboembolismo venoso em gestantes com trombofilia.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico _____________________ _________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer a melhora dos sintomas e redução das complicações. E que também fui claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Evento adverso mais comum: hemorragia podendo ocorrer em qualquer local do corpo, principalmente na presença de fatores de risco associados, como lesões orgânicas suscetíveis a sangramento, procedimentos invasivos ou uso de associações medicamentosas que afetam a coagulação.  
- Outros eventos adversos menos comumente relatados em ensaios clínicos foram: trombocitose, trombocitopenia, hematoma, dor local, aumento das enzimas hepáticas, urticária, prurido, eritema e reação alérgica.  
Fui também claramente informada que devo comunicar a qualquer profissional de saúde, que faço uso de terapia anticoagulante, principalmente no caso de realização de procedimentos que haja risco de hemorragia (ex: procedimentos odontológicos ou médico-cirúrgicos).  
Estou ciente de que o(s) medicamento(s) somente pode(m) ser utilizado(s) para a prevenção de tromboembolismo venoso em gestante com trombofilia, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei (a gestante continuará) a ser atendida, inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.      (   ) Sim            (   ) Não  
Meu tratamento constará do seguinte medicamento:  
- ( ) Enoxaparina sódica – solução injetável de 40 mg/0,4 mL  
- ( ) Enoxaparina sódica – solução injetável de 60 mg/0,6 mL  
- ( ) Ácido acetilsalicílico (AAS) – comprimidos de 100 mg  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da  
Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**  
ORIENTAÇÕES PARA A ASSISTÊNCIA FARMACÊUTICA NO SUS DISPENSAR MEDICAMENTOS PARA A PREVENÇÃO DO TROMBOEMBOLISMO VENOSO EM GESTANTES COM TROMBOFILIA

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **<mark>CRITÉRIOS DE USO:</mark>** -->
( ) **História pessoal de tromboembolismo venoso (TEV)**  
(Anexar exame de imagem – ultrassonografia doppler colorido de vasos ou tomografia computadorizada ou ressonância magnética).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: ( ) **Síndrome Antifosfolipídeo (SAF)** -->
(Anexar laudo laboratorial: anticoagulante lúpico, anticardiolipina IgG e IgM ou Antibeta-2-glicoproteína I IgG e IgM).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: ( ) **Trombofilia hereditária de alto risco** -->
(Anexar laudo laboratorial: mutação homozigótica para o fator V de Leiden; mutação homozigótica para o gene da protrombina; deficiência da antitrombina III; mutações heterozigóticas para o fator V de Leiden e do gene da protrombina associadas).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: ( ) **Trombofilia hereditária de baixo risco** -->
(Anexar laudo laboratorial: mutação heterozigótica para o fator V de Leiden; mutação heterozigótica para o gene da protrombina; deficiência da proteína C ou da proteína S e presença de anticorpo antifosfolipídeo na ausência de eventos clínicos).

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **<mark>TERAPIA INDICADA:</mark>** -->
- ( ) Anticoagulação profilática durante a gravidez e até seis semanas pós-parto.  
- Enoxaparina sódica injetável em dose única diária de 40 mg/dia ou 60 mg/dia, dependendo do peso corporal da paciente.  
- ( ) Anticoagulação profilática no pós-parto.  
- Enoxaparina sódica injetável em dose única diária de 40 mg ou 60 mg dependendo do peso corporal da paciente.  
- ( ) Anticoagulação profilática durante a gravidez e até seis semanas pós-parto + AAS  
- Enoxaparina sódica injetável 40 mg/dia ou 60 mg/dia dependendo do peso corporal da paciente + AAS comprimido 100 mg/dia.  
- ( ) Anticoagulação plena durante a gravidez e até seis semanas pós-parto.  
- Enoxaparina sódica injetável de 60 mg ou 80 mg dependendo do peso corporal da paciente, a cada 12h, não podendo ultrapassar 160 mg/dia.  
-  
**NOTA** : Em casos de gestante com diagnóstico de síndrome do anticorpo fosfolipídeo (SAF) e trombose vascular ou com dois ou mais episódios de TEV é recomendada a anticoagulação plena de de 60 mg a 80 mg dependendo do peso corporal da paciente , a cada 12h, não podendo ultrapassar 160 mg/dia.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Observações:** -->
- 1) Para todas as gestantes, no **ato da primeira dispensação** deve ser apresentado e anexado ao processo o laudo de pelo menos um dos exames de comprovação do estado gestacional: dosagem de B-hCG urinário, dosagem de B- hGC sérico ou ultrassonografia transvaginal ou pélvica; posteriormente, **a cada 3 meses,** deverá ser apresentado laudo de médico assistente ou ginecologista responsável pelo pré-natal da gestante atestando sua condição clínica e **necessidade** de uso de enoxaparina.  
- 2) No **laudo médico** devem constar as seguintes informações: nome da paciente, número de identidade, idade gestacional, descrição da condição clínica (informações sobre o diagnóstico da trombofilia) e justificativa da necessidade de anticoagulação, nome do médico responsável e data de emissão do laudo.  
- 3) Este documento não substitui o Laudo de Solicitação, Avaliação e Autorização de Medicamentos do Componente Especializado da Assistência Farmacêutica (LME).  
**APÊNDICE 2**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA  
**Atualização do Protocolo Clinico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia após a incorporação da enoxaparina sódica 60 mg/0,6 mL - 2021**

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **1. Escopo e finalidade da Diretriz** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia foi motivada pela incorporação no SUS do medicamento enoxaparina sódica 60 mg/0,6 mL, por meio da Portaria SCTIE/MS nº 35, de 6 de julho de 2021 (Relatório de Recomendação Nº 627, de junho de 2021).  
A partir da publicação do PCDT para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia em 2020 (Portaria Conjunta SAES/SCTIE nº 04, de 12 de fevereiro de 2020), foi observada dificuldade dos gestores locais na implementação do Protocolo quanto ao esquema de anticoagulação plena, que consiste na administração de enoxaparina sódica na dose de 1 mg/Kg da paciente, por via subcutânea, a cada 12h, desde que a dose diária de 160 mg não seja ultrapassada. O medicamento enoxaparina sódica solução injetável de 40 mg/0,4 mL, alocado no grupo 1A do Componente Especializado da Assistência Farmacêutica (CEAF). No entanto, a seringa atualmente disponibilizada no SUS não é graduada e não é possível direcionar a compra desse produto via pregão. Assim, há dificuldade de determinar o volume exato de medicamento a ser administrado nas gestantes que necessitam utilizar doses intermediárias de medicamento (41 a 79 mg; 81 a 119mg; 121 a 139, etc.).  
Essa questão foi comunicada ao Ministério da Saúde e subsidiou a elaboração de nova proposta de texto, apresentado inicialmente à 83ª Reunião da Subcomissão Técnica de Avaliação de PCDT, ocorrida em 20 de outubro de 2020 e, novamente à 84ª Reunião da Subcomissão Técnica de Avaliação de PCDT, em 25 de novembro de 2020. Foram avaliadas as quatro apresentações disponíveis no mercado (20 mg/0,2 mL; 40 mg/0,4 mL; 60 mg/0,6 mL; 80 mg/0,8 mL) e as doses recomendadas pelas principais associações que estudam a temática são conforme indicado nos **quadros A e B** :  
**Quadro A** - Dose profilática  
|**Guideline**|**Dose Mínima**|**Dose (pacientes com obesidade)**|
|---|---|---|
|SFMF(2020)|40 mg/dia|40 mgde 12/12h|
|ACOG(2018)|40 mg/dia|_Pode ser necessário alterar a dose_|
|SOGC(2014)|40 mg/dia|60 mg/dia|
|ACCP(2012)|40 mg/dia|_Pode ser necessário alterar a dose_|
|RCOG (2015)|20 mg/dia (peso menor que 50 kg)<br>40 mg/dia(peso entre 50 e90 kg)|60 mg/dia (peso entre 91 e 130 kg)<br>80 mg/dia(peso entre 131 e 170 kg)|
|Proposta do<br>especialista(CPCDT)|40 mg/dia (peso até 90 kg)|60 mg/dia (peso acima de 90 kg)|  
**Quadro B** - Dose plena  
|**Guideline**|**Dose**|
|---|---|
|ACOG(2018)|1 mg/kgde 12/12h|
|SOGC(2014)|1 mg/kgou 1,5 mg/kgde 12/12h|
|ACCP(2012)|1 mg/kg (ou 75%)de 12/12h|
|RCOG (2015)|40 mg/dia ou 60 mg de 12/12 h (peso menor que 50 kg)<br>60 mg de 12/12 h (peso entre 50 e 69 kg)<br>80 mgde 12/12 h(peso entre 70 e 89kg)|
|Proposta do especialista (CPCDT)|60 mg de 12/12 h (peso até 70 kg)<br>80 mgde 12/12 h(peso acima de 70 kg)|  
Considerando que as doses recomendadas para anticoagulação profilática e plena incluem as de 40 mg, 60 mg e 80 mg, sugeriu-se a aquisição de seringas de 40 mg e 60 mg, as quais contemplariam todas as posologias recomendadas. A dose de 80 mg, de 12 em 12 horas, poderia ser administrada com duas seringas de 40 mg duas vezes ao dia e, para as outras doses, seria necessária apenas a administração de uma seringa nos intervalos descritos. Assim, seguiu-se com a proposta de alteração do esquema posológico com enoxaparina (a depender do peso corporal da paciente) para:  
- ANTICOAGULAÇÃO PROFILÁTICA: dose única diária de 40 mg ou 60 mg;  
- ANTICOAGULAÇÃO PLENA: 60 mg ou 80 mg de 12 em 12 horas.  
De forma a viabilizar essa alteração, foi submetida à Conitec a proposta de incorporação da enoxaparina 60 mg/0,6 mL, com parecer favorável pelo Plenário (Relatório de Recomendação nº 627, de junho de 2021) e, posteriormente, houve a incorporação pelo Ministério da Saúde (Portaria SCTIE/MS nº 35, de 6 de julho de 2021).  
Adicionalmente, à 83ª Reunião da Subcomissão Técnica de Avaliação de PCDT, foi retomada a discussão sobre os exames necessários para a dispensação de enoxaparina, com a alteração de Observação 1 do Apêndice 1.  
Assim, onde se lê: “ _Para todas as gestantes, no ato da dispensação deve ser apresentado e anexado ao processo o laudo de pelo menos um dos exames de comprovação do estado gestacional: dosagem de B-hCG urinário, dosagem de B- hGC sérico ou ultrassonografia transvaginal ou pélvica_ ”; leia-se: “ _Para todas as gestantes, no ato da primeira dispensação deve ser apresentado e anexado ao processo o laudo de pelo menos um dos exames de comprovação do estado gestacional: dosagem de B-hCG urinário, dosagem de B-hGC sérico ou ultrassonografia transvaginal ou pélvica; posteriormente, a cada 3 meses deverá ser apresentado laudo de médico assistente ou ginecologista responsável pelo prénatal da gestante atestando sua condição clínica e necessidade de uso de enoxaparina_ ”.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) com a revisão externa de especialista da área.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **<u>Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
A proposta de atualização do PCDT de Prevenção de tromboembolismo venoso em gestantes com trombofilia foi apresentada à 92ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em agosto de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 94ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **<u>Consulta pública</u>** -->
A Consulta Pública nº 80/2021 foi realizada entre os dias 21 de setembro de 2021 e 11 de outubro de 2021. Foram recebidas 15 contribuições, que podem ser verificadas em:  
<u>http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20211013_CP_CONITEC_80_2021_PCDT_Preveno.pdf</u>

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **<u>Deliberação Final</u>** -->
Os membros da Conitec presentes à 103ª Reunião Ordinária, realizada nos dias 10 e 11 de novembro de 2021, deliberaram, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia. O tema será encaminhado para a decisão do Secretário da SCTIE. Foi assinado o Registro de Deliberação nº 677/2021.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **3. Busca da evidência e recomendações** -->
O processo de atualização deste documento utilizou como base a versão do Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia, no âmbito do SUS, publicada por meio da Portaria Conjunta SAES-SCTIE/MS nº 4, de 12 de fevereiro de 2020 e manteve sua estrutura metodológica, razões pelas quais se mantém o registro da atualização do PCDT em 2020, adiante.  
A Portaria SCTIE/MS nº 35, de 6 de julho de 2021 tornou pública a decisão de incorporar a enoxaparina 60 mg/0,6 mL para a prevenção de tromboembolismo venoso em gestantes com trombofilia no âmbito do SUS. Deste modo, o medicamento é preconizado no presente PCDT. Neste sentido, foram utilizadas as buscas de evidência, resultados e referências do Relatório de Recomendação nº 627, de junho de 2021, disponível em: <u>http://conitec.gov.br/images/Relatorios/2021/20210708_Relatorio_627_Enoxaparina_trombofilia_P35.pdf.</u>  
Por fim, foram consideradas diretrizes nacionais e internacionais sobre a temática para a atualização das informações pertinentes.

---

<!-- METADADOS: doenca: Tromboembolismo Venoso em Gestantes com Trombofilia | secao: **Atualização do Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção de Tromboembolismo Venoso em Gestantes com Trombofilia após a incorporação da enoxaparina sódica 40 mg/0,4 mL- 2020** -->
O processo de desenvolvimento deste Protocolo utilizou como base a Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde 37. A Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) foram consultados para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas no SUS para o tratamento profilático de trombofilia em gestantes.  
A Portaria nº 10/SCTIE/MS, de 25 de janeiro de 2018, tornou pública a decisão de incorporar a enoxaparina para o tratamento profilático de gestantes com trombofilia no âmbito do SUS e, deste modo, o medicamento encontra-se incluso neste PCDT. Neste sentido, este PCDT utilizou as buscas de evidência, resultados e referências do Relatório de Recomendação nº 335/2018, enoxaparina para gestantes com trombofilia, disponível em: http://conitec.gov.br/images/Relatorios/2018/Relatorio_Enoxaparina_Gestantes_Trombofilia.pdf.  
Para elaboração dos demais itens deste documento foram utilizados diretrizes internacionais e nacionais.

---

