<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 04, DE 01 DE MARÇO DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Leucemia Mieloide Crônica do Adulto.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a leucemia mieloide crônica no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 520/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 528 – Junho de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Leucemia Mieloide Crônica do Adulto.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral de leucemia mieloide crônica do adulto, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u><mark>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticaspcdt</mark></u> , é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia mieloide crônica.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.219/SAS/MS, de 04 de novembro de 2013, publicada no Diário Oficial da União nº215, de 05 de março de 2013, seção 1, páginas 45 a 52.  
LUIZ OTAVIO FRANCO DUARTE  
HÉLIO ANGOTTI NETO

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
A leucemia mieloide crônica (LMC) corresponde a 15% de todas as leucemias em pacientes adultos com mediana de idade de 67 anos. Nos Estados Unidos foram estimados 8.950 novos casos diagnosticados e cerca 1.080 mortes relacionadas à doença em 2017<sup>1</sup> . No Brasil, o Instituto Nacional de Câncer – INCA/MS estimou, para 2020-2022, 10.810 novos casos de leucemias, por ano<sup>2</sup> , e, destes, a deduzir de dados históricos anuais no SUS, a LMC deve representar 10%. Em 2019, foram registrados 127.134 procedimentos de quimioterapia de LMC do adulto, no Sistema de Informações Ambulatoriais do SUS (SIASUS), apontando para uma prevalência de cerca de 15.892 casos desta doença no Brasil.  
A LMC é uma neoplasia mieloproliferativa caracterizada pela proliferação excessiva de granulócitos maduros e em amadurecimento e pela presença do cromossomo Philadelphia (Ph+), que resulta da translocação recíproca entre os braços longos dos cromossomos 9 e 22, t (9;22) (q34; q11.2), levando à fusão do gene BCR ( _breakpoint cluster region protein_ ) com o gene ABL1 ( _Abelson murine leukemia viral oncogene homolog 1_ ). Este gene de fusão, BCR-ABL1, resulta na expressão de uma proteína, que é uma tirosinoquinase, com papel central na patogênese da LMC<sup>3</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da leucemia mieloide crônica do adulto. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
- C92.1 Leucemia Mieloide Crônica

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
A LMC ocorre em três fases distintas: crônica (FC), de transformação ou acelerada (FT) e blástica ou aguda (FB). Atualmente a classificação das neoplasias mieloides e leucemias agudas da Organização Mundial da Saúde (OMS) de 2017<sup>4</sup> é o sistema mais aceito para o diagnóstico e classificação da LMC.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
A LMC-C apresenta-se com leucocitose (12-1.000x10⁹/L, com mediana de 100x10⁹/L). Não se observa displasia significativa da medula óssea. Os blastos geralmente estão abaixo de 2% da leucometria global. Observa-se basofilia absoluta e a eosinofilia é comum. Monocitose absoluta pode estar presente, porém com os monócitos abaixo de 3%, exceto nos raros casos associados com BCR-ABL1 p190, em que a LMC pode ser confundida com a leucemia mielomonocítica crônica. A plaquetometria varia entre normal e valores acima de 1.000 x 10⁹/L. A trombocitopenia não é comum. Ao exame da medula óssea, a celularidade está aumentada devido ao padrão de maturação semelhante ao do sangue periférico, com os blastos, geralmente, abaixo de 5% das células da medula óssea; se estão em 10% ou mais é um indicativo de progressão da doença. Embora os megacariócitos possam estar normais ou discretamente diminuídos em número, 40%-50% dos pacientes apresentam moderada a intensa hiperplasia megacariocítica. A biópsia inicial da medula óssea mostra moderada a marcada fibrose  
reticulínica em aproximadamente 30% dos casos, que é correlacionada com um número aumentado de megacariócitos, aumento do volume do baço e um pior prognóstico.  
A fase crônica, cujo diagnóstico usualmente é realizado em pacientes não tratados, progride para uma fase mais avançada em 3 a 5 anos.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
A LMC-T é caracterizada por:  
- a) Aumento persistente da leucometria (> 10 x 10⁹/L) ou de esplenomegalia não responsiva à terapia;  
- b) trombocitose (> 1.000 x 10⁹ /L) não responsiva à terapia;  
- c) trombocitopenia persistente (< 100 x 10⁹ /L) e não devida à terapia;  
- d) evolução citogenética clonal observada após a cariotipagem diagnóstica;  
- e) 20% ou mais de basófilos no sangue periférico;  
f) 10%-19% de blastos no sangue periférico ou na medula óssea;  
- g) anormalidades cromossômicas adicionais nas células Ph+ (duplo Ph, trissomia 8, isocromossomo17q, trissomia 19),  
cariótipo complexo ou anormalidades do 3q26.2, ao diagnóstico; ou  
h) qualquer anormalidade cromossômica nas células Ph+ adquirida durante a terapia.  
Os critérios de a a d estão mais associados à transição de LMC-C para LMC-T, enquanto os critérios <u>e e f</u> são mais indicativos de uma transição entre as LMC-T e a LMC-B. Embora modificações e novas sugestões desses critérios venham sendo sugeridos, recomenda-se que eles sejam tomados como indicativos de progressão de doença.  
A LMC-T normalmente se apresenta resistente ao tratamento medicamentoso.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
A LMC-B, **também chamada de crise blástica** , é diagnosticada quando:  
a) A quantidade de blastos é igual ou maior do que 20% no sangue periférico ou, na medula óssea, se encontrar ≥ 20% de  
blastos entre as células nucleadas da medula óssea; ou  
b) quando há proliferação blástica extramedular, podendo haver formação tumoral (cloroma).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
O escore de Sokal, publicado em 1984, deriva de uma análise multivariada de sobrevida de 813 pacientes com LMC em fase crônica, avaliados entre 1962 e 1981. A maioria dos pacientes foi tratada com quimioterapia com agente único, tipicamente O bussulfano. O volume do baço e a porcentagem de blastos foram mais fortemente associados a menor sobrevida<sup>5</sup> .  
O escore de Hasford (ou Euro) deriva da análise multivariada da sobrevida de 981 pacientes com LMC precoce, que iniciaram o tratamento entre 1983 e 1994. Todos foram tratados com alfa-interferona isolada ou em combinação com outra terapia<sup>6</sup> .  
A análise de risco EUTOS foi avaliada em estudo europeu quanto ao tratamento e desfecho em casos de LMC. Foi derivada de análise multivariada de 2.060 pacientes tratados com imatinibe entre os anos de 2002 e 2006<sup>7</sup> .  
As fórmulas para cálculo e a classificação de risco com base nesses critérios de estratificação encontram-se resumidas no **Quadro1** .  
**Quadro 1 -** Determinação do risco pelos escores de Sokal, Hasford e EUTOS<sup>5-7</sup> .  
|**Critério**|**Fórmula de cálculo**|**Definição de risco**|
|---|---|---|
|**Sokal et al.**<br>**1984**<sup>**5**</sup>|exp [0,0116 x idade (em anos) - 43,4] + [0,0345 x tamanho do<br>baço (em cm) - 7,51] + [0,188 x (plaquetas (109/L)/700)² -<br>0,563)] + [0,0887 x blastos (em %) – 2,10)]|**Baixo risco:**<br><0,8<br>**Risco intermediário:**<br>0,8 - 1,2<br>**Alto risco:**<br>> 1,2|
||[0,6666 x idade (0 quando idade <50 anos; 1 caso contrário)] +<br>[0,0420 x tamanho do baço (em cm)] + [0,0584 x blastos (em|**Baixo risco:**<br>≤ 780|
|**Hasford et al.**<br>**1998**<sup>**6**</sup>|%)] + [0,0413 x eosinófilos (em %)] + [0,2039 x basófilos (0<br>quando basófilos <3%; 1 caso contrário)] + [1,0956 x<br>contagem de plaquetas (0 quando plaquetas <1.500 x 109/ L; 1<br>caso contrário)] x 1.000]|**Risco intermediário:**<br>781-1.480<br>**Alto risco:**<br>>1.480|
|**EUTOS**<sup>**7**</sup>|[7 x basófilos (em %)] + [4 x baço (em cm)]<br>O escore EUTOS avalia a probabilidade de não se atingir<br>remissão molecular completa aos 18 meses: exp [-2,1007 +<br>0,0700 × basófilos + 0,0402 × tamanho do baço (em cm)/[1 +<br>exp (-2,1007 + 0,0700 + basófilos + 0,0402 × tamanho do baço<br>(em cm)]|**Baixo risco**(pontuação <87) e<br>**alto risco**(pontuação ≥ 87)|  
Exp: expoente. O risco pelo Sokal pode ser calculado _on-line_ por meio do link:  
_https://www.leukemianet.org/content/leukemias/cml/euro__and_sokal_score/index_eng.html_<sup>8</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
- Serão incluídos neste Protocolo pacientes com idade ≥19 anos com diagnóstico confirmado de LMC.  
- <mark>Devem ser observados os critérios estabelecidos no Regulamento Técnico do Sistema Nacional de Transplantes (SNT) para a indicação de transplante de células-tronco hematopoéticas (TCTH) alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, devendo todos os potenciais receptores estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS.</mark>  
**Nota** : Doentes de LMC com menos de 19 anos de idade devem ser incluídos no protocolo específico estabelecido pelo Ministério da Saúde.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
Serão excluídos aqueles pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento  
adverso) ou contraindicação absoluta ao uso do respectivo medicamento ou a procedimento, inclusive o TCTH, preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
O tratamento medicamentoso da LMC deve ser feito observando-se a fase da doença, os critérios objetivos de segurança, eficácia e efetividade dos medicamentos, a finalidade do tratamento e o(s) medicamento(s) previamente utilizado(s).  
A despeito da disponibilidade dos inibidores de tirosinoquinase (ITQ), medicamentos que alteraram sobremaneira a evolução da LMC e os resultados do seu tratamento, o <mark>TCTH alogênico continua a ser uma alternativa terapêutica dessa leucemia,</mark>  
<mark>mandatória em alguns casos. Daí, d</mark> eve-se proceder à tipagem HLA dos pacientes e sua inclusão no <mark>REREME/INCA/MS,</mark> para uma eventual busca de seus potenciais doadores.  
A hidroxiureia deve ser utilizada somente para reduzir o número de leucócitos, enquanto os resultados dos exames que confirmem o diagnóstico de LMC estão sendo aguardados<sup>9</sup> .  
Confirmado o diagnóstico, o mesilato de imatinibe é primeira linha de tratamento dos casos de LMC.  
As fases crônica, de transformação e blástica da LMC podem assim se apresentar ao primeiro diagnóstico; como evolutivas de fase anteriormente diagnosticada e tratada (ou seja, de FC para FT, de FC para FB ou de FT para FB); ou como regressivas pelo efeito terapêutico (ou seja, de FB para FT, de FB para FC e de FT para FC). Assim, a sequência de medicamentos varia conforme esse _status_ .  
No caso de o efeito terapêutico do ITQ ter feito regredir a fase leucêmica para uma anterior (de FB para FT ou FC; de FT para FC) não se modifica nem o medicamento nem a dose já em uso.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: Geral -->
O tratamento de 1ª linha de pacientes com LMC em fase crônica é o inibidor da tirosinoquinase (ITQ) mesilato de imatinibe. Estudos que avaliaram outros inibidores de ITQ para a 1ª linha terapêutica (nilotinibe e dasatinibe) mostraram que eles promovem uma taxa maior de resposta precoce, porém sem impacto na sobrevida global dos doentes. Os estudos de seguimento de longo prazo, mais adequados, investigaram e comprovaram a segurança apenas para o imatinibe<sup>10,11</sup> .  
A conduta terapêutica inicial não é alterada pela classificação de risco do paciente. Essa classificação importa para predizer a resposta terapêutica, durante o tratamento do paciente. Dessa forma, na ocorrência de toxicidade insuperável ou de falha terapêutica observada no curso do tratamento, é necessário trocar o ITQ, e a escolha do próximo ITQ a ser utilizado pelo paciente deverá levar em consideração o perfil clínico de cada indivíduo e as contraindicação e toxicidade de cada fármaco (ver a **Tabela 1** – Controle da toxicidade).  
A avaliação da resposta terapêutica pode seguir recomendação já estabelecida na literatura científica, como a disponibilizada pela _Leukemianet_<sup>8,10</sup> ( **Quadro 2** ).  
**Quadro 2 -** Avaliação da resposta terapêutica<sup>8, 10</sup> **.**  
|**Tempo**|**Resposta ótima**|**Alerta**|**Falha terapêutica**|
|---|---|---|---|
|**Antes do**<br>**tratamento**<br>**(linha de base)**||Alto risco<br>Principal via AAC/Ph+||
|**3 meses**|BCR-ABL<sup>IS</sup>≤10%*<br>Ph ≤35% (RCC)|BCR-ABL<sup>IS</sup>>10%*<br>Ph+ 36%-95%|Não RHC*<br>Ph+ >95%|
|**6 meses**|BCR-ABL<sup>IS</sup>≤1%*<br>Ph +0% (RCC)|BCR-ABL<sup>IS</sup>1%-10%*<br>Ph+ 1%-35% (RCP)|BCR-ABL<sup>IS</sup>>10%*<br>Ph+ >35%|
|**12 meses**|BCR-ABL<sup>IS</sup>≤0,1%*<br>(RMM)|BCR-ABL<sup>IS</sup>0,1%-1%*|BCR-ABL<sup>IS</sup>>1%*<br>Ph+ >0%|
|**A qualquer**<br>**tempo acima de**<br>**12 meses.**|RMM<br>ou resultado melhor|AAC/Ph- (-7, ou 7q)|Perda de RHC<br>Perda de RCC<br>Perda de RMM<br>(confirmar)**<br>Mutações<br>AAC/Ph+|  
Ph: cromossomo Philadelphia,  
AAC/Ph+: alterações adicionais em células com cromossomo Philadelphia positivo.  
IS: BCR-ABL na Escala Internacional. BCR: gene _breakpoint cluster region protein_ ; ABL: gene _Abelson murine leukemia viral oncogene homolog_ . RCC: resposta citogenética completa. RHC: resposta hematológica completa. RCP: resposta citogenética parcial. RMM: resposta molecular maior. AAC/Ph-: alterações adicionais em células com cromossomo Philadelphia negativo.  
* Um ou os dois; ** em dois exames consecutivos, dos quais um ≥ 1%.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.1. Falha terapêutica** -->
Caso seja detectada falha terapêutica, deve-se proceder a novos exames:  
- a) Mielograma: para determinar a fase da doença;  
- b) cariótipo: para avaliação da evolução clonal; e  
c) pesquisa de mutações de ponto no gene BCR-ABL.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.2. Esquema terapêutico** -->
O tratamento da LMC em fase crônica se faz em sequência de linhas terapêuticas, conforme a resposta obtida.  
No caso de a LMC-C ser resultante do efeito terapêutico que fez regredir a FT ou FB para a FC, não se modifica nem o medicamento nem a dose já em uso.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.2. Esquema terapêutico** -->
A dose do mesilato de imatinibe preconizada é de 400mg/dia, tomada com água logo após a maior refeição do dia. Em caso de toxicidade, ver a **Tabela 1** .  
Estudos que avaliaram doses mais elevadas (600-800mg/dia) não comprovaram benefício a longo prazo. Os estudos TOPS<sup>11</sup> e CML4<sup>12</sup> mostraram que os pacientes que usaram 800mg/dia tinham resposta citogenética e molecular mais precoce, porém com maior toxicidade e suspensão do tratamento comparativamente ao grupo que usou dose maior. Também não se observou benefício em termos de sobrevida global com doses mais elevadas.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.2. Esquema terapêutico** -->
Em caso de falha terapêutica ou de toxicidade insuperável ao mesilato de imatinibe, preconiza-se o dasatinibe ou o nilotinibe, a depender da mutação da LMC e da segurança do medicamento especificamente para o paciente.  
A dose do **dasatinibe** preconizada é de 100mg/dia, uma vez ao dia, durante ou não uma refeição, pela manhã ou à noite.  
A dose do **nilotinibe** preconizada é de 800mg/dia (400mg duas vezes ao dia, com água), pelo menos duas horas após ter ingerido algum alimento, esperando pelo menos uma hora para ingerir novamente algum alimento.  
Em caso de toxicidade, ver as **tabelas 2** (dasatinibe) e **3** (nilotinibe).  
O **Quadro 3** exibe o perfil de sensibilidade aos ITQ para o tratamento de segunda linha da LMC na presença de mutações:  
**Quadro 3 -** Tratamento da LMC com inibidores de tirosinoquinase de acordo com a presença de mutações<sup>13, 14</sup> .  
|**Mutação**|**Medicamento**|
|---|---|
|Y253H, E255K/V ou F359V/C/1|Dasatinibe|
|F317L/V/I/C, T315A ou V299L|Nilotinibe|  
Não tendo sido detectada nenhuma das mutações, pode-se optar pelo dasatinibe como o ITQ de 2ª linha, vez que o nilotinibe cursa com menor adesão, por ser administrado em duas tomadas e longe das refeições.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.2. Esquema terapêutico** -->
Indicada em caso de falha terapêutica ou toxicidade insuperável ao tratamento de 2ª linha.  
O tratamento de 3ª linha da LMC é de prerrogativa e responsabilidade dos hospitais habilitados no SUS como Unidade de Assistência de Alta Complexidade em Oncologia (UNACON) ou Centro de Assistência de Alta Complexidade em Oncologia (CACON).  
A 3ª linha terapêutica da LMC-C deve levar em consideração o ITQ de 2ª linha utilizado e o perfil de resistência observado ou considerar o transplante de células-tronco hematopoéticas (TCTH) alogênico, preferencialmente de medula óssea (TMO).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.1.2. Esquema terapêutico** -->
As fases de transformação e blástica da LMC podem assim se apresentar ao primeiro diagnóstico (casos recémdiagnosticados) ou como evolutivas de fase anteriormente diagnosticada e tratada (ou seja, FC para FT, de FC para FB ou de FT para FB) ou como regressivas pelo efeito terapêutico (ou seja, de FB para FT).  
O uso de ITQ no tratamento da LMC em fase de transformação e em crise blástica apresenta resultados inferiores àqueles obtidos quando na fase crônica. Ademais, os estudos que avaliaram o uso de ITQ de segunda linha mostraram taxas de resposta citogenética baixas<sup>16-20</sup> .  
O tratamento da LMC em fase de transformação e blástica depende do(s) tratamento(s) prévio(s) a que o paciente se submeteu. Em geral, as opções são semelhantes às dos pacientes com LMC de fase crônica, mas os pacientes com LMC em fase de transformação e blástica são menos propensos a obter uma resposta de longo prazo a qualquer dos medicamentos<sup>21</sup> . O tratamento também vai depender da elegibilidade do paciente e da disponibilidade de doador para o TCTH<sup>22</sup> .  
É importante ressaltar que a fase blástica da LMC pode evoluir para leucemia mieloide aguda ou leucemia linfoblástica aguda. Nesta eventualidade, deve-se observar os respectivos protocolos e diretrizes estabelecidos pelo Ministério da Saúde.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
O tratamento da LMC em fases de transformação e blástica se faz em sequência de linhas terapêuticas, conforme os tratamentos anteriores e a resposta obtida.  
No caso de o efeito terapêutico ter feito regredir a fase leucêmica para uma anterior (de FB para FT ou FC; de FT para FC) não se modifica o esquema terapêutico nem a dose já em uso, ou seja, o tratamento continuará a ser, conforme o caso, o da fase de transformação ou da fase blástica.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Ao primeiro diagnóstico, a dose recomendada para o tratamento da LMC em fase de transformação é de 600mg/dia. Na crise blástica, essa dose pode ser elevada até 800 mg/dia. O medicamento deve ser tomado logo após a maior refeição do dia.  
Se o caso é de FT ou FB evolutiva de LMC já tratada, há de se verificar o(s) ITQ já utilizado(s), não podendo ser repetido(s), impondo-se o TCTH alogênico tão logo seja viável.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Em caso de falha terapêutica ou toxicidade insuperável ao mesilato de imatinibe, preconiza-se o dasatinibe ou o nilotinibe, a depender da fase (se FT ou FB) e da mutação (ver o **Quadro 3** ) da LMC, da segurança do medicamento especificamente para o paciente e do(s) ITQ já utilizado(s), não podendo ser repetido(s), impondo-se o TCTH alogênico tão logo seja viável.  
A dose recomendada do dasatinibe para o tratamento da LMC nas fases de transformação e blástica é de 140 mg/dia.  Na crise blástica, essa dose pode ser elevada até 180 mg/dia. O medicamento pode ser ingerido em jejum ou com alimentos, uma vez ao dia, logo após a maior refeição do dia.  
O nilotinibe somente é indicado para a LMC em fase de transformação (400 mg duas vezes ao dia), pois não existem dados quanto à sua utilização em fase blástica.  
Apesar da falta de uma definição concreta<sup>23-28</sup> , pacientes podem apresentar pior adesão ao nilotinibe, devido ao uso em mais de uma tomada por dia e fora do horários das refeições<sup>27, 28</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
O tratamento de 3ª linha da LMC em fase de transformação é de prerrogativa e responsabilidade dos hospitais habilitados no SUS como Unidade de Assistência de Alta Complexidade em Oncologia (UNACON) ou Centro de Assistência de Alta Complexidade em Oncologia (CACON).  
Para os pacientes com LMC em fase de transformação que não se beneficiaram dos tratamentos de 1ª e 2ª linhas e que são candidatos ao TCTH alogênico, recomenda-se como terapia um ITQ (não utilizado na 2ª linha), seguido do TCTH alogênico, preferencialmente o TMO, em vez de se proceder imediatamente ao transplante.  
Para os pacientes com LMC em fase de transformação evolutiva de fase crônica ou regressiva de fase blástica que são candidatos ao TCTH alogênico, preferencialmente o TMO, preconiza-se como terapia um ITQ (a depender dos medicamentos já utilizados), seguido do TCTH alogênico, preferencialmente o TMO, em vez de se proceder imediatamente ao transplante.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
O tratamento de 3ª linha da LMC em fase blástica é de prerrogativa e responsabilidade dos hospitais habilitados no SUS como Unidade de Assistência de Alta Complexidade em Oncologia (UNACON) ou Centro de Assistência de Alta Complexidade em Oncologia (CACON).  
O transplante não é indicado para caso de LMC em crise blástica, a menos que ela regrida, pelo efeito de poliquimioterapia, a uma fase anterior (FT ou FC). Volta-se a ressaltar que a fase blástica da LMC pode evoluir para leucemia mieloide aguda ou leucemia linfoblástica aguda. Nesta eventualidade, deve-se observar os respectivos protocolos e diretrizes estabelecidos pelo Ministério da Saúde.  
Apesar dos riscos de morbidade e mortalidade a curto prazo, o TMO alogênico é potencialmente curativo em fase de transformação e blástica. Portanto, a conduta inicial de um paciente com LMC em fase de transformação ou blástica inclui tanto a pesquisa de um doador quanto o tratamento com um ITQ<sup>29, 30</sup> .  
Procede-se ao TCTH alogênico, preferencialmente o TMO, uma vez que uma resposta máxima a um tratamento prévio tenha sido obtida. O raciocínio para esta conduta é que o sucesso do TCTH é mais provável em pacientes com doença relativamente controlada.  
Porém, se o doente é elegível para o TCTH alogênico e há doador disponível, o transplante se impõe e, até à realização do transplante, o doente deverá ser mantido sob tratamento (ITQ ou quimioterapia).  
Nos casos inelegíveis para TCTH, os doentes devem ser tratados paliativamente, para controle de sintomas e sinais, inclusive das manifestações hematológicas.  
O **Quadro 4** resume o tratamento da LMC, conforme anteriormente preconizado, lembrando que, no caso de o efeito terapêutico do ITQ ter feito regredir a fase leucêmica para uma anterior (de FB para FT ou FC; de FT para FC) não se modifica nem o medicamento nem a dose já em uso.  
**Quadro 4** - Tratamento da Leucemia Mieloide Crônica do Adulto  
|FASE|LINHA|MEDICAMENT<br>O|DOSE||OBSERVAÇÃO|
|---|---|---|---|---|---|
|Todas|NA|Hidroxiureia|Inicial|Manutençã<br>o|Para citorredução<br>(controle da leucocitose ou<br>trombocitose).|
||||2g/dia|1-2g/dia|Dose inicial de 3-4g/dia<br>se necessário, mas por curto tempo.|
|||Imatinibe|400mg/dia|NA|Dose mínima = 300 mg/dia.<br>Sem benefício dose > 400 mg/dia.|
||1<sup>a</sup>|Interferona|5<br>milhõesUI/m2/d<br>ia|NA|Alternativa ao Imatinibe.<br>Máximo de 9 milhões UI/dia.|
|Crônica|2<sup>a</sup>|Dasatinibe|100mg/dia|NA|Alternativa ao Nilotinibe.<br>Dose máxima de 140mg/dia. (*)|
|||Nilotinibe|800mg/dia|NA|Alternativa ao Dasatinibe.<br>Dose máxima de 800mg/dia. (*)|
||3<sup>a</sup>|Padronizado<br>pelo hospital.|NA|NA|Conduta e fornecimento<br>da responsabilidade do hospital.<br>Considerar o TCTH-alogênico.|
||1<sup>a</sup>|Imatinibe|600mg/dia|NA|Dose mínima de<br>300mg/dia e máxima de 800mg/dia. (*)|
|||Dasatinibe|140mg/dia|NA|Alternativa ao Nilotinibe.<br>Dose máxima de 140mg/dia. (*)|
|Transformaçã|2<sup>a</sup>||||Alternativa ao Dasatinibe.|
|o (acelerada)||Nilotinibe|800mg/dia|NA|Dose mínima de 600mg/dia e máxima de<br>800mg/dia. (*)|
||3<sup>a</sup>|Padronizado|NA|NA|Conduta e fornecimento<br>da responsabilidade do hospital.|
|||pelo hospital.|||Considerar o TCTH-alogênico.|
||1<sup>a</sup>|Imatinibe|600mg/dia|NA|Dose diária mínima de<br>300mg/dia e máxima de 800mg/dia. (*)|
|Blástica|2<sup>a</sup>|Dasatinibe|140mg/dia|NA|Dose máxima de 180mg/dia. (*)|
|(aguda)|3<sup>a</sup>|Padronizado<br>pelo hospital.|NA|NA|Conduta e fornecimento<br>da responsabilidade do hospital.<br>Poliquimioterapia.<br>Considerar o TCTH alogênico.|  
NA = não se aplica  
TCTH = transplante de células-tronco hematopoéticas.  
(*) Dependendo da resposta terapêutica e dos eventos adversos observados, a dose poderá ser ajustada (aumento, redução ou suspensão temporária).  
**Nota:** No caso de o efeito terapêutico ter feito regredir a fase leucêmica para uma anterior (de blástica para de  
transformação ou crônica; de transformação para crônica) não se modifica nem o medicamento nem a dose já em uso.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
O tratamento da LMC durante a gestação dependerá do momento do tratamento em que a paciente se encontra. Pacientes recém-diagnosticadas com LMC durante ou juntamente com a gestação muitas vezes poderão submeter-se, no primeiro trimestre da gestação, apenas a sessões de leucocitoafereses para controle da hiperleucocitose. Pacientes em uso de ITQ e que engravidam devem ser orientadas a interromper o uso desses medicamentos de imediato, vez que são contraindicados durante a gravidez.  
A alfa-interferona poderá ser utilizada em gestantes a partir do segundo trimestre da gestação, sempre levando em consideração uma análise dos riscos frente aos benefícios.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Em caso de LMC com mutação T315 em fase crônica e de transformação, os pacientes podem ser tratados com alfainterferona até a realização do TCTH alogênico, preferencialmente o de medula óssea (TMO). Neste caso, deverá ser utilizado adicionalmente citarabina na dose de 10 mg/m<sup>2</sup> de 12/12 h.  
Como já dito anteriormente, o transplante não é indicado para caso de LMC em crise blástica, a menos que ela regrida, pelo efeito de poliquimioterapia, a uma fase anterior (FT ou FC). Volta-se a ressaltar que a fase blástica da LMC pode evoluir para leucemia mieloide aguda ou leucemia linfoblástica aguda. Nesta eventualidade, deve-se observar os respectivos protocolos e diretrizes estabelecidos pelo Ministério da Saúde.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
As principais interações medicamentosas do imatinibe estão descritas no **Quadro 5**<sup>31</sup> .  
**Quadro 5** **_-_** Interações medicamentosas do imatinibe<sup>31</sup>  
|**Aumenta os níveis**|**plasmáticos do imatinibe**|**Diminui os níveis plasm**|**áticos do imatinibe**|
|---|---|---|---|
|Cetoconazol<br>Ciclosporina<br>Claritromicina|Eritromicina, Itraconazol<br>Toranja (grapefruit)|Carbamazepina<br>Dexametasona<br>Erva de São João|Fenobarbital<br>Fenitoína<br>Rifampicina<br>Rifabutina|  
No **Quadro 6** são apresentadas as principais interações medicamentosas do dasatinibe<sup>32</sup> .  
**Quadro 6 -** Interações medicamentosas do dasatinibe<sup>32</sup>  
|**Aumenta os níveis plasmáticos do dasatinibe**|**Diminui os níveis plasmáticos do dasatinibe**|
|---|---|
|Amiodarona, atanazavir||
|Cetoconazol, ciclosporina||
|Cimetidina, ciprofloxacina|Carbamazepina, dexametasona|
|Claritromicina, cloranfenicol|Erva de São João, fenobarbital|
|Diltiazem, eritromicina|Fenitoína, rifabutina|
|Indinavir, isoniazida|Rifampicina.|
|Itraconazol, gestodeno||
|Nelfinavir, norfloxacina||  
|**Aumenta os níveis plasmáticos do dasatinibe**|**Diminui os níveis plasmáticos do dasatinibe**|
|---|---|
|Ritonavir, saquinavir||
|Toranja (grapefruit), voriconazol||  
No **Quadro 7** estão descritas as interações medicamentosas do nilotinibe<sup>33</sup> .  
**Quadro 7 -** Interações medicamentosas do nilotinibe<sup>33</sup>  
|**Aumenta os níveis plasmáticos do nilotinibe**|**Diminui os níveis plasmáticos do nilotinibe**|
|---|---|
|Amiodarona, atanazavir||
|Cetoconazol, ciclosporina||
|Cimetidina, ciprofloxacina||
|Claritromicina, cloranfenicol|Carbamazepina, dexametasona|
|Diltiazem, eritromicina|Erva de São João, fenobarbital|
|Gestodeno, indinavir|Fenitoína, rifabutina|
|Isoniazida, itraconazol|Rifampicina|
|Nelfinavir, norfloxacina||
|Ritonavir, saquinavir||
|Toranja (grapefruit), voriconazol||  
Deve-se evitar o uso concomitante do nilotinibe com medicamentos com potencial de alargamento do intervalo QT no  
eletrocardiograma. Ver a lista de medicamentos com potencial de alargamento do intervalo QT disponível em http://www.azcert.org/medical-pros/drug-lists/drug-lists.cfm .  
As principais interações medicamentosas com hidroxiureia foram descritas no **Quadro 8**<sup>34</sup> .  
**Quadro 8 -** Interações medicamentosas hidroxiureia<sup>34</sup>  
|**Considere trocar a terapia**|**Evitar a combinação**|**Monitorar a Terapia**|
|---|---|---|
|Fingolimode<br>Leflunomida<br>Lenograstima<br>Nivolumabe|BCG intravesical<br>Deferiprona<br>Natalizumabe|Anfotericina B<br>Clozapina<br>Denosumabe<br>Ocrelizumabe|
|Palifermina||Promazina|
|Vacinas vivas||Trastuzumabe|  
No **Quadro 9** foram apresentadas as principais interações medicamentosas da α-interferona<sup>35</sup> .  
**Quadro 9 -** Interações medicamentosas da alfa-interferona<sup>35</sup>  
|**Aumenta os níveis plasmáticos dos**<br>**medicamentos**|**Podem aumentar toxicidade**|**Pode reduzir eficácia**|
|---|---|---|
|Metadona<br>Teofilina|Aldesleukin: risco renal e cardíaco<br>Deferiprona: mielotoxicidade|BCG intravesical|  
|**Aumenta os níveis plasmáticos dos**<br>**medicamentos**|**Podem aumentar toxicidade**|**Pode reduzir eficácia**|
|---|---|---|
|Zidovudina|Tramadol: risco crises convulsivas||

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
A monitorização laboratorial da LMC pode ser procedida conforme especificado no **Quadro 10** .  
O tratamento deve ser mantido enquanto não se observar falha, progressão ou toxicidade grau 3 ou 4, nas respectivas linhas terapêuticas. Não se indica a interrupção do tratamento fora de estudos clínicos.<sup>9</sup>  
**Quadro 10 -** Monitoramento laboratorial do tratamento da leucemia mieloide crônica com o imatinibe  
||**MONITORAMENTO**|
|---|---|
|**Ao diagnóstico**|Cariótipo (com mínimo 20 metáfases PH+) na MO ou<br>PCR qualitativo para definir tipo de transcrito no SP.|
|**Durante o tratamento**|PCR quantitativo a cada 3 meses até RMM, após a cada 3 a 6 meses no SP.<br>Cariótipo aos 3, 6 e 12 meses até RCC, após a cada 12 meses na MO|
|**Na falha terapêutica ou**<br>**progressão leucêmica**|PCR quantitativo, análise de mutação e cariótipo.<br>Imunofenotipagem em caso de crise blástica no SP ou na MO.|
|**Alerta**|Repetir análise molecular e citogenética mais frequentemente.<br>Cariótipo na MO em caso de alterações mielodisplásicas ou alterações citogenéticas<br>adicionais em células Ph negativas.|  
Adaptado de _Leukemianet_ 2013<sup>15</sup> .  
MO: medula óssea; PCR: reação em cadeia da polimerase; SP: sangue periférico; RMM: resposta molecular maior; RCC: Resposta Citogenética Completa.  
Na **Tabela 1** estão descritas as condutas em caso de toxicidade do imatinibe.  
**Tabela 1 –** Controle da toxicidade do mesilato de imatinibe  
|**Fase**|**Conduta**|
|---|---|
||**Hematológica**|
|**Fase crônica**||
|Neutrófilos < 1.000/mm<sup>3</sup>(no<br>início do tratamento.  É tolerado<br>até 500/mm<sup>3</sup>, caso o paciente<br>permaneça afebril) ou plaquetas<br>< 50.000/mm<sup>3</sup>)|Suspender o medicamento até que a contagem de neutrófilos > 1.500/mm<sup>3</sup>ou de<br>plaquetas ≥ 75.000/mm<sup>3</sup>e reintroduzir o medicamento na mesma dose. Se se<br>observar recorrência da toxicidade, suspender o medicamento até que a<br>contagem de neutrófilos > 1.500/mm<sup>3</sup>ou de plaquetas ≥ 75.000/mm<sup>3</sup>e<br>reintroduzir o medicamento na dose de 300 mg/dia. Considerar posterior<br>escalonamento da dose.<br>Em caso de múltiplas recorrências da toxicidade, considerar a troca para o<br>dasatinibe ou o nilotinibe.|
||Suporte transfusional. Ajustar a dose do medicamento somente nos casos|
|Hemoglobina < 8,0 g/dl|recorrentes de anemia sintomáticos ou com necessidade transfusional crônica<br>(não ajustar na anemia aguda).|
|**Fase de transformação e crise bl**|**ástica**|  
|**Fase**|**Conduta**|
|---|---|
|Neutrófilos < 500/mm<sup>3</sup>ou<br>plaquetas < 10.000/mm<sup>3</sup>sem<br>sangramento|Se a contagem das células sanguíneas for relacionada à doença, manter a dose do<br>medicamento ou considerar o aumento da dose (máximo de 800 mg/dia).<br>Se não relacionada à doença, reduzir a dose 1 nível de alteração de dose (ver<br>adiante). Se a toxicidade persistir por 2 semanas, apesar da redução da dose,<br>reduzir a dose do medicamento 2 níveis abaixo (ver adiante). Se persistir por<br>mais 4 semanas, mesmo com a nova dose, suspender o medicamento até que a<br>contagem de neutrófilos esteja > 1.000/mm<sup>3</sup>ou de plaquetas > 20.000/mm<sup>3</sup>e<br>reintroduzir o medicamento na dose de 300 mg/dia. Considerar posterior<br>escalonamento da dose.<br>Em caso de múltiplas recorrências de toxicidade, considerar a troca para o<br>dasatinibe ou o nilotinibe.<br>Avaliar a necessidade de transfusão de plaquetas.|
|Hemoglobina < 8,0 g/dl|Suporte transfusional. Ajustar a dose do medicamento somente nos casos de<br>toxicidade recorrente sintomática ou com necessidade transfusional crônica (não<br>ajustar a dose do medicamento em caso de anemia aguda).|
||**Não hematológica (condutas gerais)**|
|**Grau 3**|Utilizar as medidas específicas listadas abaixo. Se a toxicidade for persistente,<br>tratar como grau 4.|
|**Grau 4**|Interromper o imatinibe até toxicidade grau 1. Reintroduzir numa dose com 1<br>nível de alteração de dose (não menos que 300 mg/dia). Considerar troca pelo<br>nilotinibe ou o dasatinibe.|
||**Não hematológica (condutas específicas)**|
|**Sintomas específicos**||
|Diarreia|Terapia de suporte.|
|Edema|Terapia de suporte e diurético.|
||Considerar ecocardiograma para avaliar a função ventricular.|
|Derrame pleural ou pericárdico|Terapia de suporte; diurético; redução ou interrupção temporária ou definitiva do<br>imatinibe.|
|Intolerância gástrica|Tomar o imatinibe com alimentos e água.|
|Câimbras, artralgias ou mialgias.|Tratamento sintomático; reposição de cálcio ou magnésio.|
|Exantema (_rash cutâneo)_Graus 1<br>e 2|Tratamento tópico e anti-histamínico oral.|
|Exantema (_rash cutâneo_) Graus 3<br>e 4:<br>Erupção macular, papular ou<br>vesicular generalizada;<br>descamação cobrindo ≥ 50% da|Interromper o imatinibe e iniciar corticoterapia (prednisona 1 mg/Kg).<br>Reintroduzir o imatinibe gradualmente (100 mg/semana).|  
|**Fase**<br>**Conduta**|
|---|  
superfície corpórea; dermatite  
bolhosa ou ulcerativa.  
|**Hepática**|
|---|  
**Grau 2** Elevação da aspartato aminotransferase/transaminase glutâmico-oxalacética [AST Interromper todos as outros medicamentos com potencial de hepatotoxicidade e (TGO)] ou da alanina o consumo de álcool; manter a dose do imatinibe ou reduzir a dose de acordo aminotransferase/ transaminase com a situação clínica (ver o nível 1 de alteração de dose, abaixo). glutâmico-pirúvica [ALT (TGP)] >2,5x LSN; bilirrubina total > 1,5x LSN **≥ Grau 3** Interromper todos os outros medicamentos com potencial de hepatotoxicidade e Elevação da AST ou ALT > 5x o consumo de álcool; interromper o imatinibe até que a dosagem de AST ou LSN; bilirrubina total > 3x LSN ALT esteja ≤ 2,5x LSN ou de bilirrubina total esteja ≤ 1,5 x LSN. Reintroduzir o medicamento com redução da dose (nível 1 de alteração de dose).  
|**Níveis de altera**|**ção da dose do mesilato imatinibe**|
|---|---|
|**Fase crônica**||
|Fase crônica 0|Nível de dose do imatinibe: 400 mg/dia|
|Fase crônica -1|Nível de dose do imatinibe: 300 mg/dia|
|**Fase de transformação e crise blástica**||
|Fase de transformação/crise<br>blástica 0|Nível de dose do imatinibe: 12/12h|
|Fase de transformação/crise<br>blástica -1|Nível de dose do imatinibe: 600 mg/dia|
|Fase de transformação/crise<br>blástica -2|Nível de dose do imatinibe: 400 mg/dia|
|Fase de transformação/crise<br>blástica -3|Nível de dose do imatinibe: 300 mg/dia|  
LSN: limite superior da normalidade.  
Adaptado de _National Comprehensive Cancer Network Clinical Practice Guidelines in Oncology_<sup>_TM_</sup> - _Chronic myelogenous leukemia_<sup>_36_</sup> .  
Na **Tabela 2** estão descritas as condutas em caso de toxicidade do dasatinibe  
**Tabela 2 –** Controle da toxicidade do dasatinibe  
|**Fase**|**Conduta**|
|---|---|
||**Hematológica**|
|**Fase crônica**||
|Neutrófilos < 500/mm<sup>3</sup>ou<br>plaquetas < 50.000/mm<sup>3</sup>|Suspender o medicamento até que a contagem de neutrófilos esteja ><br>1.000/mm<sup>3</sup>ou de plaquetas ≥ 50.000/mm<sup>3</sup>. Se tempo para recuperação for ≤<br>7dias, reintroduzir o medicamento na mesma dose, e se > 7 dias, reduzir a dose<br>em 1 nível de alteração. Considerar posterior escalonamento da dose.<br>Em caso de múltiplas recorrências de toxicidade, considerar a troca pelo<br>nilotinibe.|
|Hemoglobina < 8,0 g/dl|Suporte transfusional. Ajustar a dose do medicamento somente nos casos de<br>toxicidade sintomática recorrente ou com necessidade transfusional crônica<br>(não ajustar a dose do medicamento em caso de anemia aguda).|
|**Fase de transformação e crise bl**<br>Neutrófilos <500/mm<sup>3</sup>ou<br>plaquetas <10.000/mm<sup>3</sup>sem<br>sangramento|**ástica**<br>Se as contagens forem relacionadas à doença, manter dose do medicamento ou<br>aumentar a dose (máximo de 180 mg/dia).<br>Se não relacionadas à doença, suspender o medicamento até que a contagem de<br>neutrófilos esteja > 500/mm3 ou de plaquetas ≥ 20.000/mm<sup>3</sup>. Reintroduzir o<br>medicamento com a mesma dose anterior. Se houver recorrência da toxicidade,<br>reduzir a dose do medicamento em 1 nível de alteração de dose. Em caso de<br>nova recorrência, suspender o medicamento e reintroduzi-lo com 2 níveis de<br>alteração dose (ver abaixo). Considerar posterior escalonamento da dose.<br>Em caso de múltiplas recorrências de toxicidade, considerar a troca para o<br>nilotinibe.<br>Avaliar a necessidade de transfusão de plaquetas.|
|Hemoglobina < 8,0 g/dl|Suporte transfusional. Ajustar a dose do medicamento somente nos casos de<br>toxicidade sintomática recorrente ou com necessidade transfusional crônica<br>(não ajustar a dose do medicamento em caso de anemia aguda).|
||**Não hematológica (condutas gerais)**|
|**Grau 3**||
||Utilizar medidas específicas listadas abaixo. Se a toxicidade for persistente,<br>tratar como grau 4.|
|**Grau 4**||
||Interromper o dasatinibe até toxicidade grau 1. Reintroduzi-lo com uma dose<br>menor a depender da gravidade da toxicidade ou trocar para o nilotinibe.|
||**Não hematológica (condutas específicas)**|
|**Sintomas específicos**||
|Diarreia|Terapia de suporte.|
|Edema|Terapia de suporte, diuréticos.|
|Derrame pleural ou pericárdico|Considerar ecocardiograma para avaliar a função ventricular.|  
|**Fase**|**Conduta**|
|---|---|
||Diuréticos, toracocentese de alívio, pericardiocentese.|
|Derrame pleural ou pericárdico<br>Grau 2<br>Sintomas apesar do uso de|Suspender o dasatinibe até melhora dos sintomas e reintroduzi-lo na mesma<br>dose. Se houver recorrência da toxicidade, suspender o dasatinibe até melhora|
|diuréticos e ≤ 2 toracocenteses de<br>alívio.|e reintroduzir o medicamento numa dose menor.|
|Derrame pleural ou pericárdico<br>Grau 3<br>Necessidade de suplementação de<br>oxigênio, ≥ 3 toracocenteses de<br>alívio, pleurodese ou drenagem<br>torácica; derrame pericárdico<br>sintomático.|Suspender o dasatinibe até melhora dos sintomas e prescrever corticoterapia de<br>curta duração (prednisona 20 mg/dia durante 3 dias). Reintroduzir o dasatibe<br>numa dose menor. Se houver recorrência da toxicidade, reduzir novamente a<br>dose do dasatinibe após a resolução dos sintomas ou trocá-lo pelo nilotinibe.|
|Intolerância gástrica|Tomar o medicamento durante uma refeição e água (mínimo 300mL). Evitar o<br>uso de bloqueador H2 e dos bloqueadores de bomba de prótons. Se necessário,<br>utilizar antiácido 2 horas antes ou 2 horas depois da tomada do dasatinibe.|
|Câimbras, artralgias ou mialgias|Tratamento sintomático; reposição de cálcio ou magnésio.|
|Exantema (_rash_cutâneo) Grau 1 e<br>2|Tratamento tópico e anti-histamínico oral.|
|Exantema (_rash cutâneo_) Grau 3 e<br>4||
|Erupção macular, papular ou<br>vesicular generalizada;|Interromper o dasatinibe e iniciar corticoterapia (prednisona 1 mg/Kg).<br>Reintroduzir o dasatinibe gradualmente (20 mg/semana). Considerar a troca|
|descamação cobrindo ≥ 50% da<br>superfície corpórea; dermatite<br>bolhosa ou ulcerativa.|pelo nilotinibe.|
||**Níveis de dose do dasatinibe**|
|**Fase crônica**||
|Fase crônica 0|Nível de dose do dasatinibe: 100 mg/dia|
|Fase crônica -1|Nível de dose do dasatinibe: 80 mg/dia|
||**Fase de transformação e crise blástica**|
|Fase de transformação/crise<br>blástica 0|Nível de dose do dasatinibe: 140 mg/dia|
|Fase de transformação/crise<br>blástica -1|Nível de dose do dasatinibe: 100 mg/dia|
|Fase de transformação/crise<br>blástica -2|Nível de dose do dasatinibe: 80 mg/dia|  
Em todos os casos de toxicidade grau 4 e nos casos de graus 1 e 2 que acarretam piora considerável da qualidade de vida do paciente, considerar a troca do dasatinibe pelo nilotinibe.  
Adaptado de _National Comprehensive Cancer Network Clinical Practice Guidelines in Oncology_<sup>_TM_</sup> - _Chronic myelogenous leukemia_<sup>_36_</sup> .  
Na **Tabela 3** estão descritas as condutas em caso de toxicidade do nilotinibe.  
**Tabela 3 –** Controle da toxicidade do nilotinibe  
|**Fase**|**Conduta**|
|---|---|
||**Hematológica**|
|**Fase crônica**||
|Neutrófilos < 1.000/mm<sup>3</sup>ou<br>plaquetas < 50.000/mm<sup>3</sup>|Suspender o medicamento até que a contagem de neutrófilos seja ≥ 1.000/mm3<br>ou de plaquetas ≥ 50.000/mm<sup>3</sup>. Se tempo para recuperação for < 14 dias,<br>reintroduzir o medicamento na mesma dose e se for ≥ 14 dias, reduzir a dose<br>do medicamento em 1 nível de alteração de dose. Considerar posterior<br>escalonamento da dose.<br>Em caso de múltiplas recorrências de toxicidade, considerar a troca pelo<br>dasatinibe.|
|Hemoglobina < 8,0 g/dl|Suporte transfusional. Ajustar a dose do medicamento somente nos casos de<br>toxicidade sintomática recorrente ou com necessidade transfusional crônica<br>(não ajustar a dose em caso de anemia aguda).|
|**Fase de transformação e crise blá**|**stica**|
|Neutrófilos < 500/mm<sup>3</sup>ou<br>plaquetas < 20.000/mm<sup>3</sup>sem<br>sangramento|Se a contagem for relacionada à doença, manter a dose do medicamento.<br>Se não relacionada à doença, suspender até a contagem seja de neutrófilos ><br>1.000/mm<sup>3</sup>ou de plaquetas ≥ 20.000/mm<sup>3</sup>. Se tempo para recuperação for < 14<br>dias, reintroduzir o medicamento na mesma dose e se for ≥14 dias, reduzir a<br>dose do medicamento em 1 nível de alteração. Considerar posterior<br>escalonamento da dose.<br>Em caso de múltiplas recorrências, considerar a troca pelo dasatinibe.<br>Avaliar a necessidade de transfusão de plaquetas.|
|Hemoglobina < 8,0 g/dl|Suporte transfusional. Ajustar a dose do medocamento somente nos casos de<br>toxicidade sintomática recorrente ou com necessidade transfusional crônica<br>(não ajustar em caso de anemia aguda).|
||**Não hematológica (condutas gerais)**|
|**Grau 3**||
||Utilizar medidas as específicas listadas abaixo. Se a toxicidade for persistente,<br>tratar como grau 4.|
|**Grau 4**||
||Interromper o nilotinibe até a toxicidade seja classificada como grau 1.<br>Reintroduzir o medicamento com redução da dose. Considerar troca pelo<br>dasatinibe.|
||**Não hematológica (condutas específicas)**|
|**Sintomas específicos**||
|Diarreia|Terapia de suporte.|
|Câimbras, artralgias ou mialgias.|Tratamento sintomático; reposição de cálcio ou magnésio.|  
|**Fase**|**Conduta**|
|---|---|
|_Exantema (rash cutâneo_) Grau 1 e<br>2|Tratamento tópico e anti-histamínico oral.|
|_Exantema (rash cutâneo_) Grau 3 e<br>4||
|Erupção macular, papular ou<br>vesicular generalizada;|Interromper o imatinibe e iniciar corticoterapia (prednisona 1 mg/Kg).<br>Reintroduzir o nilotinibe gradualmente (200 mg/semana). Considerar troca|
|descamação cobrindo ≥ 50% da<br>superfície corpórea; dermatite<br>bolhosa ou ulcerativa.|pelo dasatinibe.|
||**Hepática** **e pancreática**|
|Grau 2<br>Elevação da AST (TGO) ou<br>ALT (TGP) >2,5x LSN; bilirrubina<br>total > 1,5x LSN|Interromper todos os outros medicamentos com potencial de hepatotoxicidade<br>e o consumo de álcool; manter a dose do medicamento ou reduzi-la de acordo<br>com a situação clínica.|
|≥Grau 3|Interromper todos os outros medicamentos com potencial de hepatotoxicidade|
|Elevação da AST ou ALT >|e o consumo de álcool; interromper o nilotinibe até que a dosagem de AST ou|
|5x LSN; bilirrubina total > 3x|ALT  seja ≤ 2,5x LSN, de bilirrubina total ≤ 1,5 x LSN, de amilase ≤ 1,5 x|
|LSN; amilase > 2x LSN; lipase ><br>2x LSN|LSN ou de lípase ≤ 1,5 x LSN. Reintroduzir o medicamento com redução de 1<br>nível  de alteração da dose.|  
ECG com QTcF > 480 ms  
|**Cardíaca - Intervalo QT**|
|---|
|Suspender o nilotinibe e outros medicamentos com potencial de alargamento|
|do intervalo QT. Dosar magnésio e potássio e, caso estejam abaixo do LSN,|
|proceder à correção dos níveis séricos. Após 2 semanas, se o QTcF estiver <<br>450 ms e até 20 ms do ECG basal, retornar com a mesma dose do|
|medicamenro; mas se o QTcF estiver 450 - 480 ms ou > 20 ms do ECG basal,|
|reduzir a dose do medicamento em 1 nível de alteração. Se houver recorrência|
|da toxicidade, considerar a troca pelo dasatinibe ou suspender o nilotinibe por<br>2 semanas e reintroduzi-lo com redução de 2 níveis de alteração.|  
||**Níveis de dose do nilotinibe**|
|---|---|
|0|Nível de dose do nilotinibe: 400 mg 12/12h|
|-1|Nível de dose do nilotinibe: 400 mg/dia|
|-2|Nível de dose do nilotinibe: 200 mg/dia|  
LSN: limite superior da normalidade.  
Adaptado de _National Comprehensive Cancer Network Clinical Practice Guidelines in Oncology_<sup>_TM_</sup> - _Chronic myelogenous leukemia_<sup>_36_</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Pacientes com diagnóstico de leucemia mieloide crônica devem ser atendidos em hospitais habilitados em Oncologia e  
com porte tecnológico suficiente para diagnosticar, tratar e acompanhar clínica e laboratorialmente os pacientes.  
Além da familiaridade que tais hospitais guardam com a avaliação diagnóstica, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos); a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem decrescente - primeira linha maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica), entre outras. Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
<mark>Para a autorização do TCTH alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.</mark>  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
**NOTA 1 -** O mesilato de imatinibe (para uso em 1ª linha), além do dasatinibe e do nilotinibe (para uso em 2ª linha), padronizados neste PCDT, são, hoje, adquiridos pelo Ministério da Saúde e fornecidos pelas Secretarias de Saúde para os hospitais e, por esses, aos usuários do Sistema Único de Saúde (SUS). Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Assim, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de outros medicamentos contra a LMC, observando o presente PCDT, que eles, livremente, padronizem, adquiram e forneçam, cabendo-lhes codificar e registrar conforme o respectivo procedimento, inclusive aqueles de 1ª e de 2ª linhas terapêuticas, compatíveis, respectivamente, com o mesilato de imatinibe e o dasatinibe ou nilotinibe, seja o hospital público ou privado, com ou sem fins lucrativos.  
**NOTA 2 –** A aquisição pelo Ministério da Saúde e o fornecimento pelas Secretarias de Saúde não anulam a obrigatoriedade da solicitação, autorização e registros dos respectivos procedimentos em APAC.  
**NOTA 3 –** Os seguintes procedimentos se encontram no Sistema de Informações Ambulatoriais do SUS - SIA-SUS, e são autorizados por APAC para a quimioterapia da LMC do adulto:  
- 03.04.03.007-4 Quimioterapia da Leucemia Mieloide Crônica - Qualquer Fase - Controle Sanguíneo  
- 03.04.03.011-2 Quimioterapia da Leucemia Mieloide Crônica em Fase Crônica – 1ª linha  
- 03.04.03.022-8 Quimioterapia da Leucemia Mieloide Crônica em Fase Crônica – 2ª linha  
- 03.04.03.012-0 Quimioterapia da Leucemia Mieloide Crônica em Fase Crônica – 3ª linha  
- 03.04.03.015-5 Quimioterapia da Leucemia Mieloide Crônica em Fase de Transformação – 1ª linha  
- 03.04.03.014-7 Quimioterapia da Leucemia Mieloide Crônica em Fase de Transformação – 2ª linha  
- 03.04.03.013-9 Quimioterapia da Leucemia Mieloide Crônica em Fase de Transformação – 3ª linha  
- 03.04.03.009-0 Quimioterapia da Leucemia Mieloide Crônica em Fase Blástica – 1ª linha  
- 03.04.03.008-2 Quimioterapia da Leucemia Mieloide Crônica em Fase Blástica – 2ª linha  
- 03.04.03.010-4 Quimioterapia da Leucemia Mieloide Crônica em Fase Blástica – 3ª linha  
- **NOTA 4 –** Quando o mesilato de imatinibe é associado a outros antineoplásicos do esquema terapêutico da LMC em fase  
- blástica, o seu fornecimento pode ser concomitante à autorização de APAC para o respectivo procedimento de quimioterapia. **NOTA 5 –** No caso de o efeito terapêutico ter feito regredir a fase leucêmica para uma anterior (de FB para FT ou FC;  
- de FT para FC) não se modifica nem o medicamento nem a dose já em uso, mantendo-se o registro do mesmo procedimento.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no respectivo Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
1. Jabbour E, Kantarjian H. Chronic myeloid leukemia: 2016 update on diagnosis, therapy, and monitoring. Am J Hematol. 2016;91(2):252-65.  
2. Instituto Nacional de Câncer José Alencar Gomes da Silva. Estimativa biênio 2016-2017 - Incidência de câncer no Brasil 2016 [Available from: http://www.inca.gov.br/estimativa/2016/.  
3. Hehlmann R, Hochhaus A, Baccarani M, European L. Chronic myeloid leukaemia. Lancet. 2007;370(9584):342-50.  
4. WHO. World Health Organization. WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues WHO Classification of Tumours. WHO; 2017 [4th [Available from: http://publications.iarc.fr/Book-And-Report-Series/Who-IarcClassification-Of-Tumours/Who-Classification-Of-Tumours-Of-Haematopoietic-And-Lymphoid-Tissues-2017.  
5. Sokal J, Cox E, Baccarani M, Tura S, Gomez G, Robertson J, et al. Prognostic discrimination in" good-risk" chronic granulocytic leukemia. Blood. 1984;63(4):789-99.  
6. Hasford J, Pfirrmann M, Hehlmann R, Allan N, Baccarani M, Kluin-Nelemans J, et al. A new prognostic score for survival of patients with chronic myeloid leukemia treated with interferon alfa Writing Committee for the Collaborative CML Prognostic Factors Project Group. JNCI: Journal of the National Cancer Institute. 1998;90(11):850-9.  
7. Hasford J, Baccarani M, Hoffmann V, Guilhot J, Saussele S, Rosti G, et al. Predicting complete cytogenetic response and subsequent progression-free survival in 2060 patients with CML on imatinib treatment: the EUTOS score. Blood. 2011;118(3):686-92.  
8. Baccarani (Project 4). Calculation of Relative Risk of CML Patients. https://www.leukemianet.org/content/leukemias/cml/euro__and_sokal_score/index_eng.html: Leukemianet; 2017 [updated 26/10/2015.  
9. Hochhaus A, Saussele S, Rosti G, Mahon FX, Janssen J, Hjorth-Hansen H, et al. Chronic myeloid leukaemia: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2017;28(suppl_4):iv41-iv51.  
10. Cross NC, White HE, Colomer D, Ehrencrona H, Foroni L, Gottardi E, et al. Laboratory recommendations for scoring deep molecular responses following treatment for chronic myeloid leukemia. Leukemia. 2015;29(5):999-1003.  
11. Baccarani M, Druker BJ, Branford S, Kim DW, Pane F, Mongay L, et al. Long-term response to imatinib is not affected by the initial dose in patients with Philadelphia chromosome-positive chronic myeloid leukemia in chronic phase: final update from the Tyrosine Kinase Inhibitor Optimization and Selectivity (TOPS) study. Int J Hematol. 2014;99(5):616-24.  
12. Hehlmann R, Lauseker M, Saussele S, Pfirrmann M, Krause S, Kolb HJ, et al. Assessment of imatinib as first-line treatment of chronic myeloid leukemia: 10-year survival results of the randomized CML study IV and impact of non-CML determinants. Leukemia. 2017;31(11):2398-406.  
13. National Comprehensive Cancer Network Foundation. NCCN Guidelines for Patients: Chronic Myeloid Leukemia. Fort Washington, USA: The National Comprehensive Cancer Network, Inc; 2018.  
14. Soverini S, De Benedittis C, Mancini M, Martinelli G. Best Practices in Chronic Myeloid Leukemia Monitoring and Management. Oncologist. 2016;21(5):626-33.  
15. Baccarani M, Deininger MW, Rosti G, Hochhaus A, Soverini S, Apperley JF, et al. European LeukemiaNet recommendations for the management of chronic myeloid leukemia: 2013. Blood. 2013;122(6):872-84.  
16. Druker BJ, Sawyers CL, Kantarjian H, Resta DJ, Reese SF, Ford JM, et al. Activity of a specific inhibitor of the BCRABL tyrosine kinase in the blast crisis of chronic myeloid leukemia and acute lymphoblastic leukemia with the Philadelphia chromosome. N Engl J Med. 2001;344(14):1038-42.  
17. Palandri F, Castagnetti F, Testoni N, Luatti S, Marzocchi G, Bassi S, et al. Chronic myeloid leukemia in blast crisis treated with imatinib 600 mg: outcome of the patients alive after a 6-year follow-up. Haematologica. 2008;93(12):1792-6.  
18. Talpaz M, Silver RT, Druker BJ, Goldman JM, Gambacorti-Passerini C, Guilhot F, et al. Imatinib induces durable hematologic and cytogenetic responses in patients with accelerated phase chronic myeloid leukemia: results of a phase 2 study. Blood. 2002;99(6):1928-37.  
19. Apperley JF, Cortes JE, Kim DW, Roy L, Roboz GJ, Rosti G, et al. Dasatinib in the treatment of chronic myeloid leukemia in accelerated phase after imatinib failure: the START a trial. J Clin Oncol. 2009;27(21):3472-9.  
20. Kantarjian H, Cortes J, Kim DW, Dorlhiac-Llacer P, Pasquini R, DiPersio J, et al. Phase 3 study of dasatinib 140 mg once daily versus 70 mg twice daily in patients with chronic myeloid leukemia in accelerated phase resistant or intolerant to imatinib: 15-month median follow-up. Blood. 2009;113(25):6322-9.  
21. The American Cancer Society medical and editorial content team. Treating Chronic Myeloid Leukemia by Phase.: The American Cancer Society; 2017 [Available from: https://www.cancer.org/cancer/chronic-myeloidleukemia/treating/treating-by-phase.html.  
22. Jain P, Kantarjian HM, Ghorab A, Sasaki K, Jabbour EJ, Nogueras Gonzalez G, et al. Prognostic factors and survival outcomes in patients with chronic myeloid leukemia in blast phase in the tyrosine kinase inhibitor era: Cohort study of 477 patients. Cancer. 2017;123(22):4391-402.  
23. Boons C, Harbers L, Timmers L, de Jong J, Swart EL, Harry Hendrikse N, et al. Needs for information and reasons for (non)adherence in chronic myeloid leukaemia: Be aware of social activities disturbing daily routines. European journal of haematology. 2018.  
24. Huguet F, Cayuela JM, Cambier N, Carpentier N, Tindel M, Violet I, et al. Nilotinib efficacy, safety, adherence and impact on quality of life in newly diagnosed patients with chronic myeloid leukaemia in chronic phase: a prospective observational study in daily clinical practice. Br J Haematol. 2019;187(5):615-26.  
25. Sacha T, Gora-Tybor J, Wasak-Szulkowska E, Kyrcz-Krzemien S, Medras E, Becht R, et al. Quality of Life and Adherence to Therapy in Patients With Chronic Myeloid Leukemia Treated With Nilotinib as a Second-Line Therapy: A Multicenter Prospective Observational Study. Clinical lymphoma, myeloma & leukemia. 2017;17(5):283-95.  
26. Santoleri F, Sorice P, Lasala R, Rizzo RC, Costantini A. Patient adherence and persistence with Imatinib, Nilotinib, Dasatinib in clinical practice. PloS one. 2013;8(2):e56813.  
27. Trivedi D, Landsman-Blumberg P, Darkow T, Smith D, McMorrow D, Mullins CD. Adherence and persistence among chronic myeloid leukemia patients during second-line tyrosine kinase inhibitor treatment. Journal of managed care & specialty pharmacy. 2014;20(10):1006-15.  
28. Yood MU, Oliveria SA, Cziraky M, Hirji I, Hamdan M, Davis C. Adherence to treatment with second-line therapies, dasatinib and nilotinib, in patients with chronic myeloid leukemia. Current medical research and opinion. 2012;28(2):213-9.  
29. Negrin RS, Schiffer CA, Larson RA, Rosmarin AG. Treatment of chronic myeloid leukemia in accelerated phase. Waltham, MA: UpToDate Inc.; 2017 [Available from: https://www.uptodate.com/contents/treatment-of-chronic-myeloidleukemia-in-accelerated-phase.  
30. Negrin RS, Schiffer CA, Larson RA, Rosmarin AG. Treatment of chronic myeloid leukemia in blast crisis Waltham, MA: UpToDate Inc.; 2016 [Available from: https://www.uptodate.com/contents/treatment-of-chronic-myeloid-leukemia-inblast-crisis.  
31. Mesilato de Imatinibe [package insert]. São Paulo, BR: EUROFARMA LABORATÓRIOS S.A.; 2015.  
32. Sprycel (Dasatinibe) [package insert]. São Paulo, BR: AstraZeneca Pharmaceuticals LP 2016.  
33. Tasigna (Nilotinibe) [package insert]. São Paulo, BR: Novartis Pharma Stein AG; 2015.  
34. Hydrea (Hidroxiureia) [package insert]. São Paulo, BR: Corden Pharma Latina S.p.A; 2015.  
35. Roferon-A (alfainterferona 2a) [package insert]. Rio de Janeiro, BR: La Roche Ltd; 2015.  
36. O'Brien S, Berman E, Borghaei H, Deangelo DJ, Devetten MP, Devine S, et al. NCCN clinical practice guidelines in  
oncology: chronic myelogenous leukemia. J Natl Compr Canc Netw. 2009;7(9):984-1023.  
HIDROXIUREIA

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Eu,_______________________________________________(nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de HIDROXIUREIA para o tratamento da leucemia mieloide crônica.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ___________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição temporária das contagens de glóbulos brancos no sangue;  
- melhora temporária da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- não se sabe ainda ao certo os riscos do uso de hidroxiureia na gravidez; portanto, caso engravide, devo avisar  
- imediatamente o médico;  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com  
- hidroxiureia;  
- a hidroxiureia é excretada no leite humano. Pelo o potencial de causar reações adversas sérias em lactentes, deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe;  
- efeitos adversos da hidroxiureia - depressão da medula óssea (leucopenia, anemia e trombocitopenia); estomatite, anorexia, náusea, vômitos, diarreia e constipação; erupções maculopapulares, eritema facial e periférico, ulceração da pele, hiperpigmentação, eritema, atrofia da pele e unhas, descamação, pápulas violáceas e alopécia em alguns pacientes após vários anos de terapia de manutenção diária (longa duração) com a hidroxiureia; câncer de pele tem sido raramente observado; letargia, raros casos de cefaleia, tontura, desorientação, alucinações e convulsões; elevação dos níveis séricos de ácido úrico, ureia e creatinina; Febre, calafrios, mal-estar, astenia e elevação de enzimas hepáticas; raramente pode ocorrer reações pulmonares agudas (infiltrados pulmonares difusos, fibrose e dispneia).  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não  
queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim   (    ) Não  
Local e Data:  
Nome do paciente: Número do Cartão Nacional de Saúde do paciente: Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal: Médico responsável, CRM/UF: Assinatura e carimbo do médico responsável:

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Eu,_______________________________________________(nome do(a) paciente), declaro ter sido informado(a)  
claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de INTERFERONA ALFA para o tratamento da LEUCEMIA MIELOIDE CRÔNICA.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
___________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição das contagens de glóbulos brancos no sangue;  
- chance de controle da doença por longo prazo.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do  
uso do medicamento:  
- não se sabe ainda ao certo os riscos do uso de interferona alfa na gravidez; portanto, caso engravide, devo avisar imediatamente o médico. No entanto, o interferona alfa pode ser a opção mais segura de tratamento caso ocorra gravidez, em comparação com os medicamentos antineoplásicos alternativos.  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com interferona alfa;  
- não existem dados sobre a excreção do interferona alfa no leite humano. Como muitos medicamentos são excretados no leite humano e pelo o potencial de causar reações adversas sérias em lactentes, deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe;  
- efeitos adversos da alfa-interferona - Sintomas gerais: a maioria dos pacientes apresenta sintomas semelhantes aos de gripe, tais como: fadiga, febre, calafrios, anorexia, mialgia, cefaleia, artralgias e sudorese. Estes sintomas são geralmente reduzidos ou eliminados pelo uso do paracetamol e tendem a diminuir com a continuação do tratamento, embora esta possa levar à letargia, fraqueza e fadiga. Trato gastrintestinal: anorexia, náusea, vômitos, alterações do paladar, boca seca, perda de peso, diarreia e dor abdominal leve a moderada, constipação, flatulência; foram relatados casos isolados de reativação de úlcera péptica e sangramento gastrintestinal sem risco de vida para o paciente; alterações das funções hepáticas, caracterizadas por elevação de transaminases/transferases, fosfatase alcalina, desidrogenase lática e bilirrubina. Sistema nervoso: parestesia, tontura, vertigem, distúrbios visuais, diminuição da capacidade mental, esquecimento, depressão, sonolência, confusão, distúrbios de comportamento, como ansiedade e nervosismo, e distúrbios do sono; complicações raras incluem comportamento suicida, sonolência profunda, convulsões, coma, reações adversas cerebrovasculares, impotência transitória e retinopatia isquêmica. Sistemas cardiovascular e pulmonar: episódios de hipotensão e hipertensivos passageiros, edema, cianose, arritmias, palpitações e dor no peito; tosse e dispneia de caráter moderado raramente foram observadas. Pele, mucosas e anexos: reações cutâneas no local da administração, reagravamento de herpes labial, exantema, prurido, ressecamento cutâneo e das mucosas, rinorreia, epistaxe e alopécia. Raramente observou-se diminuição da função renal, elevações dos níveis séricos de ureia, creatinina e ácido úrico. Pode ocorrer leucopenia transitória, trombocitopenia e anemia.  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim              (    ) Não Local e Data: Nome do paciente: Número do Cartão Nacional de Saúde do paciente: Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal: Médico responsável, CRM/UF: Assinatura e carimbo do médico responsável:

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Eu,_______________________________________________(nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de MESILATO DE IMATINIBE para o tratamento da leucemia mieloide crônica (LMC).  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
___________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição das contagens de glóbulos brancos no sangue;  
- chance de controle da doença por longo prazo;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do  
uso do medicamento:  
- o mesilato de imatinibe é utilizado para o tratamento da LMC em fases crônica, de transformação e blástica;  
- o mesilato de imatinibe não pode ser usado durante a gravidez pelo risco de má-formação do feto;  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com mesilato  
- de imatinibe;  
- o mesilato de imatinibe é excretado no leite humano. Devido à incerteza sobre a segurança do medicamento em lactentes, deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe.  
As seguintes situações podem ser sinais de efeitos secundários graves e devem ser imediatamente comunicadas ao meu médico:  
- efeitos adversos: astenia, cefaleia, tontura, alterações no paladar, parestesia, insônia, náusea, vômitos, diarreia, mialgia, cãibras musculares, artralgia, erupção cutânea, edemas superficiais periorbitários ou dos membros inferiores, alopecia, conjuntivite, hiperlacrimação, dispneia, epistaxe, neutropenia, trombocitopenia e anemia são frequentes. Raramente ocorrem derrame pleural, ascite, edema pulmonar e aumento rápido de peso com ou sem edema superficial, desidratação, hiperuricemia, hipocalemia, gota, hipofosfatemia, hipercalemia, hiponatremia, depressão, ansiedade, diminuição da libido, confusão mental, hemorragia cerebral, síncope, neuropatia periférica, hipoestesia, sonolência, enxaqueca, comprometimento da memória, edema macular, papiledema, hemorragia retiniana, hemorragia vítrea, glaucoma, vertigem, zumbido, insuficiência cardíaca, edema pulmonar, taquicardia, pericardite, tamponamento cardíaco, hematoma, hipertensão, hipotensão, rubor, extremidades frias, tromboembolismo, fibrose pulmonar, pneumonite intersticial, hemorragia gastrintestinal, melena, ascite, úlcera gástrica, gastrite, eructação, boca seca, colite, diverticulite, obstrução intestinal, pancreatite, icterícia, hepatite, hiperbilirrubinemia, insuficiência hepática, petéquias, sufusão, aumento da sudorese, urticária, onicoclase, reações de fotossensibilidade, púrpura, hipotricose, queilite, hiperpigmentação da pele, hipopigmentação da pele, psoríase, dermatite esfoliativa, erupções bolhosas, angioedema, erupção cutânea vesicular, síndrome de Stevens-Johnson, dermatose neutrofílica febril aguda (síndrome de Sweet), dor ciática, rigidez articular e muscular, necrose avascular, osteonecrose de quadril, insuficiência renal, dor renal, polaciúria, hematúria, ginecomastia, edema escrotal, menorragia, dor no mamilo e disfunção sexual.  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Devo informar ao meu médico qualquer uso de medicamentos, suplementos nutricionais ou produtos naturais durante o uso do mesilato de imatinibe.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim            (    ) Não Local e Data:  
Nome do paciente:  
Número do Cartão Nacional de Saúde do paciente:  
Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal:  
Médico responsável, CRM/UF:  
Assinatura e carimbo do médico responsável:

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Eu,_______________________________________________(nome do(a) paciente), declaro ter sido informado(a)  
claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de DASATINIBE para o tratamento da leucemia mieloide crônica (LMC).  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
___________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição das contagens de glóbulos brancos no sangue;  
- chance de controle da doença por longo prazo;  
- melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- o dasatinibe é utilizado para o tratamento da LMC em fases crônica, de transformação e blástica;  
- o dasatinibe não pode ser usado durante a gravidez pelo risco de má-formação do feto;  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com  
- dasatinibe;  
- o dasatinibe pode ser excretado no leite humano. Devido à incerteza sobre a segurança do medicamento em lactentes, deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe.  
As seguintes situações podem ser sinais de efeitos secundários graves e devem ser imediatamente comunicadas ao meu médico:  
- dor no peito, dificuldade em respirar, tosse e desmaio; hemorragias inesperadas ou formação de manchas arroxeadas na pele sem ter tido uma lesão; presença de sangue no vômito, nas fezes ou na urina; fezes enegrecidas; sinais de infeção, como febre ou calafrios.  
- efeitos adversos muito frequentes (afetam mais de 1 doente em cada 10): Infeções, incluindo infecção bacteriana, viral e fúngica; Coração e pulmões: falta de ar, tosse; Problemas digestivos: diarreia, náusea e vômitos; Pele, cabelo, olhos e sintomas gerais: erupção na pele, febre, inchaço em volta das mãos e dos pés, dores de cabeça, sensação de cansaço ou fraqueza, hemorragia; Dor: dores musculares, dor abdominal (barriga); Os exames podem mostrar: baixo número de plaquetas, baixo de número de glóbulos brancos (neutropenia), anemia, líquido em volta dos pulmões;  
- efeitos adversos frequentes (afetam 1 a 10 doentes em cada 100): Infeções: pneumonia, infeção viral por herpes, infeção das vias respiratórias superiores, infeção grave do sangue ou dos tecidos (incluindo desfechos fatais); Coração e pulmões: palpitações, insuficiência cardíaca congestiva, disfunção cardíaca, pressão arterial elevada, pressão sanguínea aumentada nas artérias que fornecem sangue aos pulmões; Problemas digestivos: perda do apetite, alteração do paladar, acúmulo de líquido no abdome, inflamação do cólon (intestinos), prisão de ventre, azia, ulceração na boca, gastrite; Pele, cabelo, olhos e sintomas gerais: aumento de peso por retenção de líquidos, inchaço (edema) generalizado, perda de peso, sensação de formigamento, prurido, pele seca, acne, inflamação da pele, ruído persistente nos ouvidos, queda de cabelo, transpiração excessiva, alterações da visão (incluindo visão turva e visão distorcida), secura ocular, hematomas (manchas arroxeadas), depressão, insônia, vermelhidão, tonturas, sonolência; Dor: dor nas articulações , fraqueza muscular, dor no peito,  
dor em volta das mãos e dos pés, arrepios, rigidez nos músculos e nas articulações, espasmos musculares; Os exames podem  
mostrar: líquido em volta do coração, líquido nos pulmões, arritmia, neutropenia febril, alterações em todas as células sanguíneas, hemorragia gastrointestinal, níveis elevados de ácido úrico no sangue.  
- efeitos secundários pouco frequentes (afetam 1 a 10 doentes em cada 1.000): Coração e pulmões: ataque cardíaco (incluindo desfechos fatais), inflamação da membrana que reveste o coração (pericardite), ritmo cardíaco irregular, dor no peito por falta de fornecimento de sangue ao coração (angina), pressão arterial baixa, estreitamento das vias respiratórias que pode provocar dificuldades em respirar, asma; Problemas digestivos: inflamação do pâncreas, úlcera péptica, inflamação do tubo digestivo, abdome (barriga) inchado, fissura na pele do canal anal, dificuldade em engolir, inflamação da vesícula biliar, bloqueio dos ductos biliares; Pele, cabelo, olhos e sintomas gerais: reações alérgicas, incluíndo nódulos vermelhos e moles na pele (eritema nodoso), ansiedade, confusão, alterações do humor, diminuição do desejo sexual, desmaios, tremor, inflamação do olho que provoca vermelhidão ou dor, uma doença na pele caracterizada por placas vermelhas, moles e bem definidas, acompanhadas de febre de início rápido e elevação do número de células brancas no sangue (dermatose neutrofílica febril aguda), sensibilidade à luz, alteração na coloração da pele, inflamação do tecido subcutâneo, úlceras na pele, bolhas na pele, alterações nas unhas, alterações nos pés e mãos, insuficiência renal, aumento da frequência em urinar, aumento das mamas nos homens, menstruações irregulares, desconforto e fraqueza geral, intolerância à temperatura; Dor: inflamação das veias que pode provocar vermelhidão, sensibilidade ao toque e inchaço, inflamação do tendão; Cérebro: perda de memória; Os exames podem mostrar: resultados anormais nos testes sanguíneos e possível diminuição da função dos rins, pela destruição rápida de células tumorais (síndrome de lise tumoral), níveis baixos de albumina no sangue, hemorragia no cérebro, atividade elétrica irregular do coração, aumento do coração, inflamação do fígado, presença de proteínas na urina, creatinafosfoquinase aumentada (uma enzima normalmente encontrada no coração, no cérebro e nos músculos esqueléticos).  
- efeitos adversos raros (afetam 1 a 10 doentes em cada 10.000): Coração e pulmões: aumento do ventrículo direito no coração, inflamação do músculo do coração, conjunto de condições que resultam na interrupção do fornecimento de sangue ao músculo cardíaco (síndrome coronariana aguda); Problemas digestivos: obstrução do intestino; Pele, cabelo, olhos e sintomas gerais: convulsões, inflamação do nervo ótico que pode provocar perda total ou parcial da visão, diminuição da visão, manchas azul-arroxeadas na pele; Cérebro: AVC (acidente cerebrovascular), episódio temporário de disfunção neurológica provocado por perda de fluxo sanguíneo, paralisia do nervo facial; Os exames podem mostrar: produção insuficiente de células vermelhas do sangue.  
- outros efeitos adversos que foram comunicados (frequência desconhecida) incluem: inflamação dos pulmões,  
- alterações nos vasos sanguíneos que fornecem sangue aos pulmões e coágulos de sangue nos vasos sanguíneos (trombose).  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Devo informar ao meu médico qualquer uso de medicamentos, suplementos nutricionais ou produtos naturais durante o uso do dasatinibe.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
SIM  (    )            NÃO   (    )  
Local e Data:  
Nome do paciente:  
Número do Cartão Nacional de Saúde do paciente: Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal: Médico responsável, CRM/UF: Assinatura e carimbo do médico responsável:

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Eu,_______________________________________________(nome do(a) paciente), declaro ter sido informado(a)  
claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de NILOTINIBE para o tratamento da leucemia mieloide crônica (LMC).  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
_________________________________________________________  (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição das contagens de glóbulos brancos no sangue;  
- chance de controle da doença por longo prazo;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do  
uso do medicamento:  
- o nilotinibe é utilizado para o tratamento da LMC em fases crônica e de transformação, mas não em fase blástica;  
- o nilotinibe não pode ser usado durante a gravidez pelo risco de má-formação do feto;  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com  
- nilotinibe;  
- o nilotinibe pode ser excretado no leite humano. Devido à incerteza sobre a segurança do medicamento em lactentes, deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe.  
As seguintes situações podem ser sinais de efeitos secundários graves e devem ser imediatamente comunicadas ao meu médico:  
- aumento de peso rápido, inchaço das mãos, tornozelos, pés ou face; dor no peito, pressão arterial elevada, ritmo cardíaco irregular, coloração azul nos lábios, língua ou pele; dificuldade em respirar, tosse, chiado no peito, inchaço dos pés ou pernas; hemorragias inesperadas ou formação de manchas arroxeadas na pele sem ter tido uma lesão; presença de sangue no vômito, nas fezes ou na urina; fezes enegrecidas; sinais de infeção, como febre ou calafrios; visão turva, perda de visão; dor abdominal, náusea, obstipação, abdome distendido; pele e olhos amarelos,  urina de cor escura; sede excessiva, elevado volume urinário, aumento do apetite com perda de peso, cansaço; dor, desconforto, fraqueza ou cãibras nos músculos das pernas, úlceras nas pernas ou braços que cicatrizam lentamente ou que não cicatrizam, e mudanças visíveis de cor (azulada ou palidez) ou diminuição da temperatura afetando todo um membro (perna ou braço) ou sua extremidade (dedos dos pés e das mãos).  
- efeitos adversos muito frequentes (podem afetar mais de 1 em cada 10 doentes): dores de cabeça; cansaço; dor muscular; prurido, eritema, urticária; náusea; nível elevado de bilirubina no sangue (disfunção hepática); nível elevado de lipase no sangue (disfunção pancreática).  
- efeitos adversos frequentes (podem afetar até 1 em 10 doentes): diarreia, vômitos, desconforto abdominal, desconforto gástrico após as refeições, flatulência, inchaço ou distensão do abdome; dor óssea, dor nas articulações, espasmos musculares, dor nas extremidades, dor nas costas, dor ou desconforto num lado do corpo; irritação, inchaço, secreção, prurido ou vermelhidão nos olhos, olhos secos; vermelhidão da pele, pele seca, acne, verrugas, diminuição da sensibilidade da pele; perda de apetite, alterações do paladar, aumento de peso; perda de cabelo; tontura, insônia, ansiedade; suores noturnos, sudorese excessiva; palpitações (sensação de batimento cardíaco rápido).  
- efeitos adversos pouco frequentes (podem afetar até 1 em 100 doentes): lesões dolorosas na pele; inchaço nas pálpebras; sangramento do nariz; sintomas gripais; sensação de formigamento ou adormecimento na pele; alterações visuais; sensação de alteração de temperatura do corpo (incluindo sensação de calor e sensação de frio); placas espessadas da pele vermelhas e descamação.  
- outros efeitos adversos que foram comunicados (frequência desconhecida) incluem: perda de memória, humor alterado ou depressivo, perda de energia, sensação geral de mal-estar; infeção bacteriana da pele; monilíase bucal; bolhas, quistos na pele, pele oleosa, adelgaçamento da pele, manchas escuras da pele, descoloração da pele; sensibilidade aumentada da pele; sensibilidade dentária, hemorragia (sangramento), sensibilidade e aumento do tamanho das gengivas; boca seca, garganta inflamada e aftas; tremores; dor e inchaço de articulações (gota); fraqueza muscular; inconsciência; dificuldade e dor ao urinar, sensação exagerada de necessidade de urinar; produção de urina frequente, cor anormal da urina; sensação de endurecimento do peito, períodos menstruais extensos, inchaço dos mamilos; dores de cabeça graves, acompanhadas por náusea, vômitos e sensibilidade à luz; azia; desenvolvimento mamário nos homens; síndrome das pernas inquietas (uma vontade irresistível de mover uma parte do corpo, normalmente as pernas, acompanhada por sensações desconfortáveis).  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Devo informar ao meu médico qualquer uso de medicamentos, suplementos nutricionais ou produtos naturais durante o uso do nilotinibe.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) SIM                (    ) NÃO  
Local e Data:  
Nome do paciente:  
Número do Cartão Nacional de Saúde do paciente: Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal: Médico responsável, CRM/UF: Assinatura e carimbo do médico responsável:

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Leucemia Mieloide Crônica do Adulto iniciou-se com a reunião presencial para delimitação do escopo, cujo objetivo foi a discussão da atualização do referido PCDT.  
A reunião contou com a presença de cinco membros do Grupo Elaborador, sendo três especialistas e dois metodologistas, além de dois representantes do Comitê Gestor.  
Inicialmente, a macroestrutura do PCDT foi estabelecida com base na Portaria N° 375/SAS/MS, de 10 de novembro de 2009<sup>37</sup> , que estabelece o roteiro para elaboração dos PCDT, definindo-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), a elaboração deste Protocolo contou com médicos hematologistas da Faculdade de Medicina de Ribeirão Preto da Universidade de São Paulo, do Instituto Nacional de Câncer e do Hospital Alemão Oswaldo Cruz (HAOC), além de colaboradores e metodologistas do HAOC.  
Todos os participantes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
O PCDT foi avaliado pela Subcomissão Técnica de PCDT em sua 73º reunião (outubro/2019) e contou com representantes das áreas técnicas do MS (DAF, DECIT e DGITIS/SCTIE e da SAES). Entre os principais pontos levantados estavam as linhas terapêuticas e algoritmo de tratamento e denominação do documento (DDT ou PCDT).  
Após a revisão dos pontos discutidos na 73º reunião, foi apresentado um informe do PCDT por ocasião da 75º reunião (dezembro/2019) da subcomissão técnica, quando estavam presentes representantes das áreas técnicas da SCTIE e SAES. O texto do PCDT foi aprovado para ser avaliado pela Conitec.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Após a apresentação à 85ª Reunião Ordinária da Conitec, o PCDT da Leucemia Mieloide Crônica do Adulto foi encaminhado à consulta pública com recomendação preliminar positiva à sua aprovação. A Consulta Pública nº 02/2020 esteve disponível na página eletrônica da Conitec de 21/02/2020 a 17/03/2020, tendo recebido 343 contribuições, sendo 334 de pessoa física e nove de pessoa jurídica. As contribuições foram analisadas de modo quantitativo e qualitativo, e foram apresentadas à 88º Reunião da Conitec, em 04 de junho de 2020.  
O conteúdo integral das contribuições se encontra disponível na página da CONITEC em:  
<u>http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_02_2020_PCDT_Leucemia_Mieloide_Crnica_do_ Adulto.pdf  .</u>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
Os médicos especialistas do tema do presente PCDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada tecnologia não incorporada no SUS ou em casos de quaisquer incertezas científicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou de acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Ao final, quatro questões de pesquisa foram definidas para o presente PCDT ( **Quadro A** ).  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
<!-- Start of picture text -->
aaa *Populagdo ou condi¢ao clinica<br>+Intervengdo, no caso de estudos experimentais<br>+Fatorde exposi¢ao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagnostica<br>*Controle, de acordo com tratamento/niveis de<br>exposigao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
**Quadro A -** Questões de pesquisa elencadas  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Qual a eficácia e segurança do dasatinibe e do nilotinibe como<br>primeira linha de tratamento da LMC em adultos?|Tratamento|
|**2**|Qual o nível de resposta do nilotinibe e do dasatinibe, em relação ao<br>imatinibe, estratificados por risco (SOKAL, Hasford ou Eurorisk)?|Tratamento|
|**3**|Qual a eficácia e segurança dos inibidores de tirosina quinases<br>(imatinibe, dasatinibe e nilotinibe) como tratamento na fase de<br>transformação da LMC em adultos?|Tratamento|
|**4**|Qual a acurácia diagnóstica dos exames FISH, RT-PCR (BCR-<br>ABL), Cariotipagem e pesquisa de mutação na monitorização e no<br>diagnóstico da LMC em adultos?|Diagnóstico|  
LMC: leucemia mieloide crônica.  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de  
pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo das publicações, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clínico-demográficas e desfechos de eficácia e segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, elas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos, feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>38</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>39</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>40</sup> e os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2)<sup>41</sup> . Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas _a priori_ como de alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ )<sup>42</sup> , de forma qualitativa, durante a reunião de consenso sobre as recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
**Questão de pesquisa 1:** Qual a eficácia e segurança do dasatinibe e do nilotinibe como primeira linha de tratamento da LMC em adultos?

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND (("aged"[MeSH Terms] OR "adult"[MeSH Terms:noexp] OR "adult"[MeSH Terms] OR of age OR middle age))) AND (("Dasatinib"[Mesh] OR Sprycel OR BMS 354825) OR ("4-methyl-N-(3-(4-methylimidazol-1-yl)-5-(trifluoromethyl)phenyl)-3-((4-pyridin-3-ylpyrimidin-2yl)amino)benzamide" [Supplementary Concept] OR nilotinib OR Tasigna OR AMN107)) Filters: Randomized Controlled Trial; Systematic Reviews</mark>  
<mark>Total: 44 referências</mark>  
<mark>Data do acesso: 09/02/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>('chronic myeloid leukemia'/mj) OR ('leukemia'/mj AND myelogenous AND chronic AND [embase]/lim) OR (chronic AND myelocytic AND 'leukemia'/mj AND [embase]/lim)</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>[('dasatinib'/mj AND [embase]/lim) OR ('sprycel'/mj AND [embase]/lim) OR (bms AND 354825 AND [embase]/lim)] OR [('nilotinib'/mj AND [embase]/lim) OR ('tasigna'/mj AND [embase]/lim) OR ('amn107'/mj AND [embase]/lim)]</mark>  
<mark>AND</mark>  
<mark>([cochrane review]/lim OR [systematic review]/lim OR [meta analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND [embase]/lim</mark>  
<mark>Total= 145 referências</mark>  
<mark>Data do acesso: 06/03/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 189 referências (44 no MEDLINE e 145 no Embase). Destas, 14 foram excluídas por estarem duplicadas. Cento e setenta e cinco referências foram triadas por meio da leitura de título e resumos, das quais 33 tiveram seus textos completos avaliados para confirmação da elegibilidade.</mark>  
<mark>As citações potencialmente elegíveis foram agrupadas de acordo com o desenho de estudo e a molécula avaliada. Treze citações representaram estudos de eficácia e segurança de ambas as moléculas, dasatinibe e nilotinibe, sendo dois estudos primários e 11 revisões sistemáticas. Das revisões sistemáticas, 10 foram excluídas devido às seguintes razões: as revisões publicadas por dois estudos foram excluídas por avaliarem os desfechos mediante agrupamento de todas as moléculas de inibidores da tirosinoquinase na meta-análise. As revisões publicadas por dois estudos foram excluídas por considerarem estudos</mark>  
<mark>que incluíram populações resistentes ao imatinibe. Ainda, seis citações correspondentes a quatro revisões sistemáticas e metaanálises de comparações indiretas foram excluídas por terem gerado as estimativas de efeito com base apenas nos estudos centrais que avaliaram cada molécula</mark> _<mark>versus</mark>_ <mark>imatinibe. Desta forma, foi incluída apenas a revisão sistemática e meta-análise de comparação indireta publicada por Firwana et al. em 2015</mark><sup>43</sup> <mark>, por considerar os estudos centrais e demais estudos que abordavam a mesma questão de pesquisa. Dos estudos primários que compararam diretamente várias moléculas de inibidores da tirosinoquinase, um estudo publicado foi excluído por apresentar os resultados por classe, sem especificar o tipo de molécula. O estudo conduzido por Hu et al. foi incluído</mark><sup>44</sup> <mark>, apesar de ter sido publicado apenas como resumo apresentado em congresso.</mark>  
<mark>Em relação aos estudos de eficácia e segurança do dasatinibe como tratamento de primeira linha, uma revisão sistemática não foi incluída por estar publicada em chinês. Três citações foram excluídas por se tratarem de análises de subgrupos de estudos elegíveis. Quatro publicações referentes ao estudo DASISION foram incluídas</mark><sup>45-48</sup> <mark>. Adicionalmente, quatro estudos primários foram considerados elegíveis</mark><sup>49-52</sup> <mark>sendo que um deles</mark><sup>52</sup> <mark>, publicado em chinês, teve seus dados extraídos apenas do resumo.</mark>  
<mark>Em relação aos estudos de eficácia e segurança do nilotinibe como tratamento de primeira linha, três citações foram excluídas por se tratar de análises de subgrupos de estudos elegíveis. Uma revisão descritiva do estudo ENESTnd também foi excluída. Adicionalmente, um resumo apresentado em congresso foi excluído por avaliar a manutenção de resposta molecular após a suspensão do nilotinibe em pacientes que receberam previamente imatinibe ou nilotinibe, sem apresentar os resultados do tratamento de primeira linha. Três publicações referentes a um estudo original que avaliou o nilotinibe como primeira linha de tratamento foram incluídas</mark><sup>53-55</sup> <mark>, além de um estudo de fase II</mark><sup>56</sup> <mark>.</mark>  
<mark>Em relação aos estudos de eficácia e segurança do nilotinibe como tratamento de primeira linha, três citações foram excluídas por se tratar de análises de subgrupos de estudos elegíveis. Uma revisão descritiva do estudo ENESTnd também foi excluída. Adicionalmente, um resumo apresentado em congresso foi excluído por avaliar a manutenção de resposta molecular após suspensão do nilotinibe em caso de pacientes que receberam previamente imatinibe ou nilotinibe, sem apresentar os resultados do tratamento de primeira linha. Três publicações referentes a um estudo original que avaliou o nilotinibe como primeira linha de tratamento foram incluídas</mark><sup>53-55</sup> <mark>, além de um estudo de fase II</mark><sup>56</sup> <mark>.</mark>  
<mark>Durante a seleção de estudos elegíveis para a Questão 2 envolvendo pacientes adultos com LMC, encontrou-se mais um estudo observacional comparando diretamente nilotinibe e dasatinibe e que foi posteriormente incluído</mark><sup>57</sup> <mark>. Ao final, quinze publicações referentes a dez estudos foram incluídas</mark><sup>43-57</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>Os estudos serão apresentados de acordo com o tipo de comparação. A descrição sumária dos estudos que comparam diretamente dasatinibe e nilotinibe encontra-se na</mark> **<mark>Tabela A</mark>** <mark>. As características dos pacientes incluídos encontram-se na</mark> **<mark>Tabela B</mark>** <mark>e os dados de desfechos, na</mark> **<mark>Tabela C</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela D</mark>** <mark>apresenta a descrição sumária da revisão sistemática com meta-análise em rede para as comparações mistas entre dasatinibe e nilotinibe. As características dos pacientes deste estudo encontram-se na</mark> **<mark>Tabela E</mark>** <mark>. A</mark> **<mark>Tabela F</mark>** <mark>apresenta os dados de desfechos.</mark>  
<mark>A</mark> **<mark>Tabela G</mark>** <mark>apresenta as descrições sumárias dos estudos que avaliaram a eficácia e segurança do dasatinibe como tratamento de primeira linha. A</mark> **<mark>Tabela H</mark>** <mark>apresenta as características desses estudos. A</mark> **<mark>Tabela I</mark>** <mark>apresenta os dados de desfechos de eficácia enquanto a</mark> **<mark>Tabela J</mark>** <mark>apresenta os dados de segurança;</mark>  
<mark>A</mark> **<mark>Tabela K</mark>** <mark>apresenta as descrições sumárias dos estudos que avaliaram a eficácia e segurança do nilotinibe como tratamento de primeira linha. A</mark> **<mark>Tabela L</mark>** <mark>apresenta as características desses estudos, a</mark> **<mark>Tabela M</mark>** <mark>apresenta os dados de desfechos de eficácia e a</mark> **<mark>Tabela N</mark>** <mark>os dados de segurança.</mark>  
**Tabela A -** Características dos estudos de comparação direta entre dasatinibe e nilotinibe  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hu et al. 2016**<sup>**44**</sup>|Estudo comparativo não<br>randomizado (não é possível<br>inferir sobre a natureza<br>prospectiva ou retrospectiva<br>das análises)|Avaliar os desfechos de sobrevida em<br>pacientes adultos com LMC e resposta MR4,5<br>sustentada ≤2 anos tratados com diferentes<br>moléculas de iTQ (imatinibe 400mg, imatinibe<br>800mg, nilotinibe, dasatinibe, posatinibe)|Pacientes com LMC em<br>resposta MR4,5sustentada<br>≤2 anos tratados com<br>diferentes moléculas de iTQ|Nilotinibe|Dasatinibe|Alto: resumo de congresso,<br>com ausência de<br>informações importantes<br>para julgamento|
|**Jabbour et al.**<br>**2012**<sup>**57**</sup>|Estudo observacional de<br>coorte (análise de banco de<br>dados de estudos<br>observacionais prospectivos<br>consecutivos e ECRs<br>conduzidos em uma<br>instituição de referência)|Avaliar respostas molecular e citogenética em<br>curto prazo e seu impacto na sobrevida de<br>pacientes tratados com diferentes moléculas de<br>iTQ (imatinibe 400mg, imatinibe 800mg,<br>nilotinibe e dasatinibe)|Pacientes com LMC em<br>fase crônica, tratados com<br>diferentes moléculas de iTQ|Nilotinibe<br>400mg 2x/dia|Dasatinibe<br>100mg 1x/dia|Alto: estudo comparativo<br>não randomizado|  
LMC: leucemia mieloide crônica; MR4,5: resposta molecular decréscimo de 4,5 log; iTQ: inibidores da tirosino-quinase; mg: miligramas.  
**Tabela B -** Características dos pacientes dos estudos de comparação direta entre dasatinibe e nilotinibe  
|**Autor, ano**|**N**<br>**Nilotinibe**|**N**<br>**Dasatinibe**|**Idade**<br>**Nilotinibe**|**Idade**<br>**Dasatinibe**|**% sexo**<br>**masculino**<br>**Nilotinibe**|**% sexo**<br>**masculino**<br>**Dasatinibe**|**Tempo de**<br>**tratamento**|**Suspensão n/N**<br>**(%)**|**Razão para**<br>**suspensão**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Hu et al. 2016**|121|113|NR|NR|NR|NR|NR|NR|NR|106,9 meses (17-177,9) (toda<br>a coorte)|
|**Jabbour et al. 2012**|105|102|50 (17-86)|48 (18-82)|58% (tod|a a coorte)|NR|NR|NR|Nilotinibe: 30 meses (3-77);<br>Dasatinibe: 36 meses (2-73)|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela C -** Desfechos de eficácia dos estudos de comparação direta entre dasatinibe e nilotinibe  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**Nilotinibe**|**Mortalidade/Sobrevida**<br>**Dasatinibe**|**p para comparação**|**Resposta Nilotinibe**|**Resposta Dasatinibe**|**p para**<br>**comparaçã**<br>**o**|**Tempo até**<br>**resposta**<br>Resposta MR4,5|
|---|---|---|---|---|---|---|---|
|**Hu et al.**<br>**2016**|NR|NR|NA|Incidência de resposta<br>MR4,5 sustentada:<br>75/121 (62)|Incidência de resposta<br>MR4,5 sustentada:<br>73/113 (65)|NR|sustentada (toda<br>a coorte): 17,6<br>meses (2,7-<br>107,8)|  
||**SLE em 3 anos:**|**SLE em 3 anos:**||||||
|---|---|---|---|---|---|---|---|
||Pacientes com RCC aos 3<br>meses: 79/83 (97)<br>Pacientes com RCP aos 3<br>meses: 12/13 (92)<br>Pacientes com RCMe aos|Pacientes com RCC aos 3<br>meses: 78/79 (99)<br>Pacientes com RCP aos 3<br>meses: 13/14 (91)<br>Pacientes com RCMe aos 3|**SLE em 3 anos:**<br>RCC: p=0,706<br>RCP: p=0,832<br>RCMe: p=0,749|**Em 3 meses:**<br>RCM: 97%<br>PCR≤1%: 82%|**Em 3 meses:**<br>RCM: 95%<br>PCR≤1%: 79%|||
|**Jabbour et**|3 meses: 3/4 (67)|meses: 5/6 (75)||**Em qualquer**|**Em qualquer**|NR|NR|
|**al. 2012**|**SG em 3 anos:**<br>Pacientes com RCC aos 3<br>|**SG em 3 anos:**<br>Pacientes com RCC aos 3<br>|**SG em 3 anos:**|**momento:**<br>RCP: 2%<br>RCC: 88%|**momento:**<br>RCP: 2%<br>RCC: 90%|||
||meses: 74/83 (99)<br>Pacientes com RCP aos 3<br>meses: 12/12 (100)<br>Pacientes com RCMe aos|meses: 78/79 (98)<br>Pacientes com RCP aos 3<br>meses: 13/13 (100)<br>Pacientes com RCMe aos 3|RCC: p=0,665<br>RCP: p=0,565<br>RCMe: p=0,759|RMM: 83%<br>RMC: 63%|RMM: 81%<br>RMC: 64%|||
||3 meses: 3/3 (100)|meses: 5/5 (100)||||||  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; MR4,5: resposta molecular decréscimo 4,5 log; NR: não reportado; NA: não se aplica; SLE: sobrevida livre de eventos; RCC: resposta citogenética</mark>  
<mark>completa; RCP: resposta citogenética parcial; RCMe: resposta citogenética menor; SG: sobrevida global; RCM: resposta citogenética maior; PCR: reação em cadeia da polimerase (</mark> _<mark>Polymerase Chain Reaction</mark>_ <mark>); RMM: resposta molecular maior; RMC: resposta molecular completa. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N(%).</mark>  
**Tabela D -** Características da revisão sistemática com meta-análise em rede para comparações indiretas entre dasatinibe e nilotinibe  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**N de estudos e total da**<br>**população**<br>**(nilotinibe + imatinibe)**|**N de estudos e total da**<br>**população**<br>**(dasatinibe + imatinibe)**|**Detalhes da**<br>**intervenção**<br>**(nilotinibe)**|**Detalhes da**<br>**intervenção**<br>**(dasatinibe)**|**Risco de**<br>**viés**|
|---|---|---|---|---|---|---|---|---|
|**Firwana et**<br>**al. 2016**<sup>**43**</sup>|RS e MA em<br>rede de<br>comparações<br>mistas de ECR|Sumarizar as evidências de<br>eficácia dos iTQ em pacientes<br>recém diagnosticados com<br>LMC, comparando a segunda<br>linha terapêutica dos iTQ,<br>diretamente e indiretamente,<br>tendo como referência a<br>comparação de cada molécula<br>com o imatinibe|Estudos que incluíram<br>pacientes adultos<br>recém-diagnosticados<br>com LMC tratados<br>com imatinibe,<br>dasatinibe, nilotinibe<br>ou ponatinibe como<br>primeira linha|5 publicações referentes<br>ao estudo ENESTnd<br>(n=846)|6 publicações referentes ao<br>estudo DASISION (n=519)<br>2 publicações referentes ao<br>estudo S0325 (n=246)<br>1 estudo primário em Chinês<br>(n=37)<br>Total 802 participantes|Nilotinibe<br>300mg<br>2x/dia<br>Nilotinibe<br>400mg<br>2x/dia|Dasatinibe<br>100mg 1x/dia|Baixo|  
N: número de estudos; n: número de pacientes; RS: revisão sistemática; MA: meta-análise; ECR: ensaio clínico randomizado; iTQ: inibidores da tirosino-quinase; LMC: leucemia mieloide crônica; mg: miligrama.  
**Tabela E -** Características dos participantes dos estudos incluídos na revisão sistemática com meta-análise em rede  
|**Autor, ano**|**Idade Nilotinibe**|**Idade Dasatinibe**|**% sexo masculino Nilotinibe**|**% sexo masculino Dasatinibe**|**Tempo de seguimento**|
|---|---|---|---|---|---|
|**Firwana et**<br>**al. 2016**|Mediana 47 anos|Variação da mediana<br>44-46 anos|56%|Variação 56%-77%|5 anos para ambos os<br>tratamentos|  
**Tabela F** - Desfechos de eficácia da revisão sistemática com meta-análise em rede para as comparações indiretas entre dasatinibe e nilotinibe  
|**Autor, ano**|**Diferença absoluta das proporções e IC95%**<br>|**p para comparação**|**Diferença absoluta das proporções e IC95%**<br>|**p para comparação**|
|---|---|---|---|---|
||**(nilotinibe 300mg****_versus_dasatinibe)**||**(nilotinibe 400mg****_versus_dasatinibe)**||
||RMM em 60 meses: 0,21 (-0,32; 0,74)|RMM em 60 meses: p=NS|RMM em 60 meses: 0,21 (-0,32; 0,74)|RMM em 60 meses: p=NS|
|**Firwana et**|RMM4,5 em 60 meses: 0,57 (0,07; 1,06)|RMM4,5 em 60 meses: p<0,05|RMM4,5 em 60 meses: 0,52 (0,02; 1,02)|RMM4,5 em 60 meses: p<0,0|
|**al. 2016**<sup>**2**</sup>|SLP em 60 meses: 0,20 (-0,69; 1,09)|SLP em 60 meses: p=NS|SLP em 60 meses: 1,56 (0,54; 2,68)|SLP em 60 meses: p<0,05|
||SG em 60 meses: 0,90 (0,01; 1,81)|SG em 60 meses: p<0,05|SG em 60 meses: 0,67 (-0,28; 1,64)|SG em 60 meses: p=NS|  
IC95%: Intervalos de Credibilidade de 95%; RMM: resposta molecular maior; RMM4,5: resposta molecular maior decréscimo 4,5 log; SLP: sobrevida livre de progressão; SG: sobrevida global; NS: não significante. Os resultados apresentados referem-se às estimativas de comparação do nilotinibe _versus_ dasatinibe com base em comparações indiretas.  
**Tabela G -** Características dos estudos que avaliaram eficácia e segurança do dasatinibe como tratamento de primeira linha  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**DASISION,**<br>**2010**<sup>**45-48**</sup>|ECR fase III,<br>multicêntrico (108<br>centros),<br>internacional,<br>estratificado por<br>categoria de risco<br>Hasford|Avaliar eficácia e<br>segurança do dasatinibe<br>vs imatinibe como<br>tratamento de primeira<br>linha em pacientes com<br>LMC em fase crônica|Pacientes com LMC Ph+ em fase<br>crônica diagnosticada em até 3<br>meses antes da inclusão no estudo,<br>virgens de tratamento (permitido uso<br>prévio de anagrelida ou hidroxiureia)|Dasatinibe 100mg VO<br>1x/dia|Imatinibe 400mg<br>VO 1x/dia|Moderado-baixo: estudo<br>aberto, aparentemente<br>sem outras limitações<br>metodológicas|
|**Cortes et**<br>**al. 2010**<sup>**49**</sup>|ECR fase II|Avaliar eficácia e<br>segurança do dasatinibe<br>1x/dia ou 2x/dia como<br>terapia de primeira linha<br>de pacientes com LMC<br>em fase crônica|Pacientes com LMC em fase crônica<br>diagnosticada em até 6 meses antes<br>de iniciar o tratamento do estudo|Dasatinibe 100mg<br>1x/dia|Dasatinibe 50mg<br>2x/dia|Alto: não há descrição da<br>linha terapêutica da lista<br>de randomização e do<br>sigilo da alocação, estudo<br>aberto e com grande<br>proporção de exclusões<br>pós-randomização|
|**Hjorth-**<br>**Hansen et**<br>**al. 2015**<sup>**50**</sup>|ECR fase II,<br>multicêntrico (10<br>centros), internacional<br>(países nórdicos)|Avaliar eficácia e<br>segurança do dasatinibe<br>vs imatinibe em pacientes<br>com LMC em fase<br>crônica|Pacientes com LMC Ph+ em fase<br>crônica diagnosticada em até 3<br>meses antes da inclusão no estudo,<br>sem uso prévio de iTQs. Permitido<br>uso prévio de hidroxiureia por até 60<br>dias|Dasatinibe 100mg<br>1x/dia|Imatinibe 400mg<br>1x/dia|Alto: não há descrição da<br>linha terapêutica da lista<br>de randomização e do<br>sigilo da alocação, estudo<br>aberto|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||Avaliar eficácia e||||Alto: não há descrição da|
|**Radich et**<br>**al. 2012**<sup>**51**</sup>|ECR, estratificado<br>por categoria de risco<br>Hasford|segurança do dasatinibe<br>como tratamento de<br>primeira linha de<br>pacientes com LMC|Pacientes com LMC diagnosticados<br>em até 6 meses antes do estudo|Dasatinibe 100mg<br>1x/dia|Imatinibe 400mg|linha terapêutica da lista<br>de randomização e do<br>sigilo da alocação, estudo<br>aberto|
|||Avaliar eficácia e|||||
|**Zhou et al.**<br>**2013**<sup>**52**</sup>|ECR|segurança do dasatinibe<br>vs imatinibe em pacientes<br>com LMC em fase<br>crônica|Pacientes com diagnóstico novo de<br>LMC em fase crônica|Dasatinibe 100mg<br>1x/dia|Imatinibe 400mg<br>1x/dia|Incerto: sem informações<br>suficientes para avaliação|  
<mark>ECR: Ensaio Clínico Randomizado; LMC: Leucemia mieloide crônica; Ph+: cromossomo Filadelphia positivo; mg: miligrama; VO: Via oral; iTQs: Inibidores da tirosino-quinase.</mark>  
**Tabela H** - Características dos pacientes incluídos nos estudos que avaliaram eficácia e segurança do dasatinibe como tratamento de primeira linha  
|**Autor, ano**|**N**<br>**Dasa**|**N**<br>**Imatini**<br>**be**|**Idade**<br>**Dasa**|**Idade**<br>**Imatini**<br>**be**|**Sexo**<br>**masculino**<br>**Dasa**|**Sexo**<br>**masculino**<br>**Imatinibe**|**Tempo de**<br>**tratamento**|**Suspensão n/N (%)**|**Razão para suspensão**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**DASISOIN**<br>**(Kantarjia**<br>**n et al.**<br>**2010)**|||||||Dasa: 14 meses<br>(0,03-24,1)<br>Imatinibe: 14,3<br>meses<br>(0,3-25,8)|Dasa: 40/258 (15,5)<br>Imatinibe: 48/258 (18,6)<br>3 pacientes não<br>receberam a medicação<br>alocada|EA relacionado à medicação (13 vs.<br>11)<br>EA não relacionado à medicação (3 vs.<br>1) Progressão da doença (11 vs. 14)<br>Falha do tratamento (6 vs. 10)|12 meses|
||||||||||EA relacionado à medicação (18 vs.||
|**DASISOIN**|||||||||12)||
|**(Kantarjia**<br>**n et al.**<br>**2012)**|||46|49|144/259|163/260|NR|Dasa: 59/258 (23)<br>Imatinibe: 64/258 (25)|EA não relacionado à medicação (5 vs.<br>1) Progressão da doença (14 vs. 17)<br>Falha do tratamento (8 vs. 11)<br>Outros (14 vs. 23)|24 meses|
|**DASISION**<br>**(Jabbour et**<br>**al. 2014)**|259|260|<br>(18-84)|<br>(18-78)|<br>(56)|<br>(63)|Dasa: 36,8 meses<br>(0,03-49,7)<br>Imatinibe: 36,8<br>meses (0,3-49,7)|Dasa: 75/258 (29)<br>Imatinibe: 79/258 (31)|EA relacionado à medicação (27 vs.<br>16)<br>EA não relacionado à medicação (6 vs.<br>2) Progressão da doença (17 vs. 18)<br>Falha do tratamento (8 vs. 12)<br>Outros (17 vs. 27)|36 meses|
|**DASISION**<br>**(Cortes et**<br>**al. 2016)**|||||||NR|Dasa: 100/258 (49)<br>Imatinibe: 96/259 (47)|EA não relacionado à medicação (12<br>vs. 4)<br>Progressão da doença ou falha do<br>tratamento (28 vs. 36)<br>Intolerância (42 vs. 17)<br>Outros (18 vs. 38)|5 anos|  
|**Autor, ano**|**N**<br>**Dasa**|**N**<br>**Imatini**<br>**be**|**Idade**<br>**Dasa**|**Idade**<br>**Imatini**<br>**be**|**Sexo**<br>**masculino**<br>**Dasa**|**Sexo**<br>**masculino**<br>**Imatinibe**|**Tempo de**<br>**tratamento**|**Suspensão n/N (%)**|**Razão para suspensão**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Cortes et**<br>**al. 2010**|31|31|46<br>(18-70)|47<br>(22-76)|NR|NR|NR|12/62 (19,3) em ambos<br>os grupos|Motivos pessoais (1); foram seguidos<br>por tempo <3 meses (11)|24 meses<br>(1-39)|
|**Hjorth-**<br>**Hansen et**<br>**al. 2015**|22|24|53<br>(29-71)|53<br>(38-78)|7/22 (32)|15/24<br>(62,5)|NR|Dasa: 8/22 (36)<br>Imatinibe: 7/24 (29)|EA relacionado à medicação (5 vs 3);<br>Outros (3 vs 4)|36 meses|
|**Radich et**<br>**al. 2012**|123|123|47<br>(18-90)|47<br>(18-90)|74/123<br>(60)|72/123<br>(59)|NR|Dasa: 45/123 (36,6)<br>Imatinibe: 32/123 (26)|NR|36 meses|
|**Zhou et al.**<br>**2013**|18|19|NR|NR|NR|NR|NR|NR|NR|38 meses|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; Dasa: Dasatinibe; EA: Evento Adverso; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor</mark>  
<mark>máximo) ou n/N (%).</mark>  
**Tabela I -** Desfechos de eficácia dos estudos que avaliaram dasatinibe como tratamento de primeira linha  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Dasa**|**Mortalidade ou**<br>**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**|**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**Tempo**<br>**até**<br>**resposta**<br>**Dasa**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|||||RCC em 3 meses: 139/259 (54)<br>RCC em 6 meses: 189/259 (73)<br>RCC em 9 meses: 202/259 (78)<br>RCC confirmada em 12 meses:<br>199/259 (77); IC 95% 71-82<br>RCC em 12 meses: 216/259<br>(83); IC 95% 78-88|RCC em 3 meses: 80/260 (31)<br>RCC em 6 meses: 153/260 (59)<br>RCC em 9 meses: 173/269 (67)<br>RCC confirmada em 12 meses:<br>172/260 (66); IC95% 60-72<br>RCC em 12 meses: 186/260 (72);|RCC<br>confirmada em<br>12 meses:<br>0007|||
|**DASISOI**<br>**N**<br>**(Kantarji**<br>**l**|SG em 12 meses:<br>251/260 (97)|SG em 12 meses:<br>257/260 (99)||RCC observada em pelo menos<br>uma avaliação até 12 meses:<br>21/259 (83)<br>RMM em 3 meses: 20/259 (8)|IC95% 66-77<br>RCC observada em pelo menos<br>uma avaliação até 12 meses:<br>187/259 (72)|p=,<br>RCC em 12<br>meses: p=0,001<br>RCC em pelo<br>|HR para at|ingir|
|**an et a.**<br>**2010)**<br>**Seguimen**<br>**to 12**<br>**meses**|SLP em 12<br>meses: 248/260<br>(96)|SLP em 12<br>meses: 252/260<br>(97)|NR|RMM em 6 meses: 69/259 (27)<br>RMM em 9 meses: 101/259<br>(39)<br>RMM em 12 meses: 119/258<br>(46); IC 95% 40-52<br>RMM observada em pelo<br>menos uma avaliação até 12<br>meses: 135/258 (52); IC95%<br>46-58|RMM em 3 meses: 1/260 (0,4)<br>RMM em 6 meses: 10/260 (8)<br>RMM em 9 meses: 47/260 (18)<br>RMM em 12 meses: 73/260 (28);<br>IC95% 23-34<br>RMM observada em pelo menos<br>uma avaliação até 12 meses:<br>88/260 (34); IC95% 28-40<br>Progressão para fase de|menos uma<br>avaliação:<br>p=0,001<br>RMM em 12<br>meses: p<0,001<br>RMM em pelo<br>menos uma<br>avaliação:<br>p<0,001|RCC=1,5;<br>HR para at<br>RMM=2,0|p<0,001<br>ingir<br>; p<0,001|
|||||Progressão para fase de<br>transformação ou blástica:<br>5/259 (1,9)|transformação ou blástica: 9/260<br>(3,5)||||  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Dasa**|**Mortalidade ou**<br>**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**|**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**Tempo**<br>**até**<br>**resposta**<br>**Dasa**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|**DASISOI**<br>**N**<br>**(Kantarji**<br>**an et al.**<br>**2012)**<br>**Seguimen**<br>**to 24**<br>**meses**|SLP em 24<br>meses: 242/260<br>(93,7)<br>SG em 24 meses:<br>246/260 (95,3)|SLP em 24<br>meses: 92,1%<br>SG em 24 meses:<br>95,2%|NR|RCC em 24 meses: 223/259<br>(86); IC95% 81-90<br>RCC confirmada em 24 meses:<br>208/259 (80) IC95% 75-85<br>RMM: 165/259 (64); IC95%<br>58-70<br>Redução de BCR-ABL para<br>≤0,0032% (4,5 log): 44/259<br>(17); IC95% 13-22<br>Conversão para fase de<br>transformação ou blástica:<br>6/259 (2,3)|RCC em 24 meses: 213/260 (82);<br>IC95% 77-86<br>RCC confirmada em 24 meses:<br>193/260 (74); IC95% 68-79<br>RMM: 120/260 (46); IC95% 40-<br>52<br>Redução de BCR-ABL para<br>≤0,0032% (4,5 log): 22/260 (8);<br>IC95% 5-13<br>Conversão para fase de<br>transformação ou blástica:<br>13/260 (5)|NR|Até RCC:<br>3,2 meses|Até RCC:<br>6 meses|
|**DASISIO**<br>**N**<br>**(Jabbour**<br>**et al.**<br>**2014)**<br>**Seguimen**<br>**to 36**<br>**meses**|Mortalidade em<br>36 meses: 17/259<br>(6,5)<br>SLP em 36<br>meses: 235/259<br>(91)<br>Sobrevida sem<br>transformação<br>para AP/BP:<br>244/259 (94,1)|Mortalidade em<br>36 meses: 20/260<br>(7,7)<br>SLP em 36<br>meses: 236<br>(90,9)<br>Sobrevida sem<br>transformação<br>para AP/BP:<br>243/260 (93,5)|NR|RCC observada em pelo menos<br>uma avaliação em até 36<br>meses: 225/259 (87)<br>RMM em 36 meses: 178/259<br>(69)|RCC observada em pelo menos<br>uma avaliação em até 36 meses:<br>215/260 (83)<br>RMM em 36 meses: 143/260<br>(55)|RCC observada<br>em pelo menos<br>uma avaliação:<br>p=0,23<br>HR para RMM:<br>1,2; p<0,001|Até RCC:<br>3,1 meses<br>(IC95% 3-<br>3,1)|Até RCC:<br>5,8 meses<br>(IC95%<br>5,6-6,0)|  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Dasa**|**Mortalidade ou**<br>**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**|**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**Tempo**<br>**até**<br>**resposta**<br>**Dasa**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|**DASISIO**|SG em 5 anos:|SG em 5 anos:|SG: HR 1,01<br>(IC95% 0,58-<br>173)|RMM cumulativa em 5 anos:<br>196/259 (76)|RMM cumulativa em 5 anos:<br>166/260 (64)||||
|**N C**|235/259 (91)|234/260 (90)|,<br>Mlidd|RMM em 5 anos: 200/259 (52)|RMM em 5 anos: 127/260 (49)||||
|**(ortes**<br>**et al**|Mortalidade|Mortalidade|ortaae<br>relacionada à|RCC confirmada em 5 anos:|RCC confirmada em 5 anos:|RMM|||
|**.**<br>**2016)**<br>**Si**|relacionada à<br>LMC em 5 anos:|relacionada à<br>LMC em 5 anos:|<br>LMC: HR 0,53<br>(IC95% 024|72/259 (28)<br>BRC1/ABL ≤10% em 3 meses:|67/260 (26)<br>BRC1/ABL ≤10% em 3 meses:|cumulativa em<br>5 anos:|NR|NR|
|**egumen**<br>**to 5 anos**|9/259 (3,4)<br>SLP em 5 anos:|17/260 (6,5)<br>SLP em 5 anos:|,-<br>1,19; p=0,1192)<br>SLP: HR 106|217/259 (84)<br>Progressão para fase de|166/260 (64)<br>Progressão para fase de|p=0,002|||
||220/260 (85)|223/260 (86)|,<br>(IC95% 0,68-<br>1,66)|transformação ou blástica:<br>12/259 (4,6)|transformação ou blástica:<br>19/260 (7,3)||||
|||||RCC em 6 meses: 92%|RCC em 6 meses: 96%||Resultados|agregados|
||Resultados agrega|dos para ambos os||RCC em 12 meses: 100%|RCC em 12 meses: 95%||para ambo|s os grupos:|
||grupos:|||RCC em 18 meses: 94%|RCC em 18 meses: 83%||Até RCC:|3 meses (3-|
|**Cortes et**<br>**l 2010**|SLP em 24 meses|: 54/62 (88)|NR|RMM em 6 meses: 62%|RMM em 6 meses: 60%|NR|9)||
|**a.**|Mortalidade em 24|meses: 0/50 (0)||RMM em 12 meses: 71%|RMM em 12 meses: 71%||Até RMM|: 6 meses|
|||||RMM em 18 meses: 82%|RMM em 18 meses: 76%||(3-18)||
|||||Resultados agregado|s para ambos os grupos:||||  
||**Mortalidade ou**|**Mortalidade ou**||||**Tempo**<br>|**Tempo**<br>|
|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Sobrevida**<br>**Dasa**|**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**<br>**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**até**<br>**resposta**<br>**Dasa**|**até**<br>**resposta**<br>**Imatinibe**|
|||||RCM em 3 meses: 48/50 (96)<br>RCM em 6 meses: 48/49 (98)<br>RCM em 12 meses: 41/42||||
|||||(98)||||
|||||RCM em 18 meses: 32/35||||
|||||(91)||||
|||||RCM em 24 meses: 27/31||||
|||||(87)||||
|||||RCM em 30 meses: 19/23||||
|||||(83)||||
|||||RCC em 3 meses: 41/50 (82)||||
|||||RCC em 6 meses: 46/49 (94)||||
|||||RCC em 12 meses: 41/42||||
|||||(98)||||
|||||RCC em 18 meses: 31/35||||
|||||(89)||||
|||||RCC em 24 meses: 26/31||||
|||||(84)||||
|||||RCC em 30 meses: 19/23||||
|||||(83)||||
|||||RMM em 3 meses: 12/50||||
|||||(24)||||
|||||RMM em 6 meses: 31/49||||  
||**Mortalidade ou**|**Mortalidade ou**|||||**Tempo**<br>|**Tempo**<br>|
|---|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Sobrevida**<br>**Dasa**|**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%**|**)**<br>**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**até**<br>**resposta**<br>**Dasa**|**até**<br>**resposta**<br>**Imatinibe**|
|||||(63)<br>RMM e<br>(71)|m 12 meses: 29/42||||
|||||RMM e|m 18 meses: 27/34||||
|||||(79)|||||
|||||RMM e|m 24 meses: 27/31||||
|||||(87)|||||
|||||RMM e|m 30 meses: 17/21||||
|||||(81)|||||
|||||RMC e|m 3 meses: 0/50 (0)||||
|||||RMC e|m 6 meses: 0/49 (0)||||
|||||RMC e|m 12 meses: 3/42 (7)||||
|||||RMC e|m 18 meses: 2/34 (6)||||
|||||RMC e|m 24 meses: 18/31 (6)||||
|||||RMC e|m 30 meses: 0/21 (0)||||
|||||RCC em 3 meses: 14/17|RCC em 3 meses: 8/18 (42)|RCC em 3|||
|||||(82)|RCC em 6 meses: 15/17(88)|meses: p=0,02|||
|**Hth**||Mrtlidd m||RCC em 6 meses: 17/19|RCC em 12 meses: 21/22 (95)|RCC em 6|||
|**jor-**<br>**Hansen et**|<br>Mortalidade em|oaae e<br>36 meses: 1/24|NR|(89)|RMM em 3 meses: 2/24 (8)|meses: p=0,91|NR|NR|
|<br>|<br>36 meses: 0|<br>||RCC em 12 meses: 20/20|RMM em 6 meses: 4/24 (17)|RCC em 12|||
|**al. 2015**||(4)||(100)|RMM em 12 meses: 11/24 (46)|meses: p=0,33|||
|||||RMM em 3 meses: 8/22|RMM em 18 meses: 15/23 (65)|RMM 3 meses:|||
|||||(36)|RMM em 36 meses: 5/23 (21)|p=0,02|||  
||**Mortalidade ou**|**Mortalidade ou**|||||**Tempo**<br>|**Tempo**<br>|
|---|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Sobrevida**<br>**Dasa**|**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**|<br>**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**até**<br>**resposta**<br>**Dasa**|<br>**até**<br>**resposta**<br>**Imatinibe**|
|||||RMM em 6 meses: 13/22<br>(68)<br>RMM em 12 meses: 17/21|Progressão para fase blástica: 1/24<br>(4,1)<br>BCR-ABL1 ≤10% em 3 meses:|RM 12 meses:<br>p=0,02<br>RMM 36|||
|||||(81)|17/24 (71)|meses: p<0,05|||
|||||RMM em 18 meses: 16/22<br>(73)<br>RMM em 36 meses: 13/21<br>(61)<br>Progressão para fase<br>blástica: 0<br>BCR-ABL1 ≤10% em 3<br>meses: 21/22 (95)||RMM 18<br>meses: p=NS|||
||Mortalidade:<br>7/123 (5,7)<br>SG em 3 anos:<br>97% (IC95 91%-|Mortalidade:<br>4/123 (3,6)<br>SG em 3 anos:<br>97% (IC95%||RHC confirmada: 100/123<br>(81); IC95% 73-88<br>RHC: 107/123 (87); IC95%<br>80-92|RHC confirmada: 101/123 (82);<br>IC95%: 74-88<br>RHC: 113/123 (87); IC95% 86-96<br>RCC: 42/61 (69); IC95% 56-80|RHC<br>confirmada:<br>p=1,0<br>RHC: p=0,30|||
||99%)|90%-99%)||<br>|<br>|RCC: p=0,04|||
|**Radich et**<br>**al. 2012**|SLP em 3 anos:<br>93% (IC95%|SLP em 3 anos:<br>90% (IC95%|NR|RCC: 59/70 (84); IC95%<br>74-92<br>RM3 em 1 ano: 58/99 (59)|RM3 em 1 ano: 40/91 (44); IC95%<br>34-55<br>RM4 em 1 ano: 19/91 (21) IC95%|RM3 em 1 ano:<br>p=0,059|NR|NR|
||86%-96%)<br>SLR em 3 anos:|82%-95%)<br>SLR em 3 anos:||;<br>IC95% 48-68<br>|;<br>13-31<br>|RM4 em 1 ano:<br>p=0,32|||
||91% (IC95%<br>82%-95%)|88% (IC95%<br>78%-94%)||RM4 em 1 ano: 27/99 (27);<br>IC95% 19-37|RM4,5 em 1 ano: 14/91 (15); IC95%<br>9-24|RM4,5 em 1<br>ano: p=0,35|||  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Dasa**|**Mortalidade ou**<br>**Sobrevida**<br>**Imatinibe**|**HR ou p para**<br>**comparação**|**Resposta Dasa, n/N (%)**|**Resposta Imatinibe, n/N (%)**|**HR ou p para**<br>**comparação**|**Tempo**<br>**até**<br>**resposta**<br>**Dasa**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
||Recorrência de<br>RHC: 6/123 (5)|Recorrência de<br>RHC: 9/123 (7,3)||RM4,5 em 1 ano: 21/99<br>(21); IC95%: 14-31|||||
|**Zhou et**<br>**al. 2013**|NR|NR|NR|RCC em 12 meses: 89%<br>Incidência cumulativa de<br>RCC em 36 meses: 89%<br>RMM em 18 meses: 76%<br>Incidência cumulativa de<br>RMM em 36 meses: 82%|RCC em 12 meses: 68%<br>Incidência cumulativa de RCC em<br>36 meses: 89%<br>RMM em 18 meses: 37%<br>Incidência cumulativa de RMM em<br>36 meses: 68%|RCC em 12<br>meses: p=0,232<br>RMM em 18<br>meses: p=0,017<br>Incidência<br>cumulativa de<br>RMM em 36<br>meses: p=0,694|Até RCC:<br>3 meses<br>Até<br>RMM: 14<br>meses|<br> <br>Até RCC:<br>6 meses<br>Até<br>RMM: 34<br>meses|  
<mark>Dasa: Dasatinibe; HR:</mark> _<mark>Hazard Ratio</mark>_ <mark>; N: número de pacientes; n: número de pacientes que apresentaram o evento; S</mark> G: Sobrevida global; SLP: Sobrevida livre de progressão; <mark>NR: não reportado;</mark> RCC: Resposta citogenética completa; RMM: Resposta molecular maior; IC95%: Intervalo de Confiança de 95%; LMC: Leucemia mieloide crônica; RMM: Resposta molecular maior; RCM: Resposta citogenética maior; SLR: Sobrevida livre de recorrência; RHC: Resposta hematológica completa; RM3: Resposta Molecular com 3log de redução de BCR-ABL; RM4: Resposta Molecular com 4log de redução de BCR-ABL; RM4,5: Resposta Molecular com 4,5log de redução de BCR-ABL. <mark>Quando não especificado, dados foram apresentados como mediana em meses (mínimo-máximo) ou n/N (%).</mark>  
**Tabela J -** Eventos adversos apresentados nos estudos que avaliaram dasatinibe como tratamento de primeira linha  
|||||**Au**|**tor, ano**||||||
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos adversos**|**DASISION (12, 2**|**4 meses e 5 anos)**|**Cortes et**|**al. 2010**|**Hjorth-Hans**|**en et al. 2015**|**Radich et**|**al. 2012**|**Zhou et**|**al. 2013**|
||||**Dasatinibe**|**Dasatinibe**|||||<br>|<br>|
|**(Grau 3-4)**|||||**Dasatinibe**|**Imatinibe**|**Dasatinibe**|**Imatinibe**|<br>**Dasatinibe**|<br>**Imatinibe**|
||**Dasatinibe 100mg**|**Imatinibe 400mg**|**100mg**<br>**1x/dia**|**50mg**<br>**2x/dia**|**100mg**|**400mg**|**100mg**|**400mg**|**100mg***|**400mg****|
|Abcesso perianal|NR|NR|NR|NR|0|2/24 (8)|NR|NR|NR|NR|
|Alopécia|NR|NR|0|0|NR|NR|NR|NR|NR|NR|
|Anemia|12 meses: 26/258<br>(10)<br>5 anos: 33/258 (13)|12 meses: 18/258 (7)<br>5 anos: 23/258 (9)|2/31 (6)|3/31 (9,6)|0|0|12/122<br>(10)|5/123(4)|NR|NR|
|Anorexia|NR|NR|NR|NR|NR|NR|0|0|NR|NR|
|Cefaleia|12 meses: 0|12 meses: 0|2/31 (6)|0|NR|NR|3/122 (2)|3/123 (2)|NR|NR|
|Colecistite|NR|NR|NR|NR|0|1/24 (4)|||NR|NR|
|Derrame pericárdico|NR|NR|NR|NR|1/22 (5)|0|0|3/122 (2)|NR|NR|
|Derrame Pleural|24 meses: 2/258 (1)<br>5 anos: 72/258 (28)|24 meses: 0<br>5 anos: 2/258 (0,8)|1/31 (3)|0|2/22 (9)|0|3/122 (2)|1/123 (1)|NR|NR|
|Diarreia|12 meses: 1/258 (<1)|<br>12 meses: 1/258 (<1)|1/31 (3)|0|NR|NR|6/122 (5)|2/123 (2)|NR|NR|
|Dispneia|NR|NR|2/31 (6)|1/31 (3)|NR|NR|NR|NR|NR|NR|
|Dor<br>musculoesquelética/Artralgia|12 meses: 0|12 meses: 1/258 (<1)|2/31 (6)|2/31 (6)|NR|NR|3/122 (2)|2/123 (2)|NR|NR|
|Edema generalizado|NR|NR|0|0|NR|NR|1/122 (1)|3/123(2)|NR|NR|
|Edema superficial|24 meses: 0|24 meses: 1/258 (<1)|NR|NR|NR|NR|NR|NR|NR|NR|
|Elevação de enzimas<br>hepaticas|NR|NR|0|0|0|1/24 (4)|NR|NR|NR|NR|  
|||||**Au**|**tor, ano**||||||
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos adversos**|**DASISION (12, 2**|**4 meses e 5 anos)**|**Cortes et**|**al. 2010**|**Hjorth-Hans**|**en et al. 2015**|**Radich et**|**al. 2012**|**Zhou et**|**al. 2013**|
|<br>**(Grau 3-4)**|||**Dasatinibe**<br>|**Dasatinibe**<br>|**Dasatinibe**|**Imatinibe**|**Dasatinibe**|**Imatinibe**|**Dasatinibe**|<br>**Imatinibe**|
||**Dasatinibe 100mg**|**Imatinibe 400mg**|**100mg**<br>**1x/dia**|**50mg**<br>**2x/dia**|**100mg**|**400mg**|**100mg**|**400mg**|**100mg***|**400mg****|
|Fadiga|12 meses: 1/258 (<1)<br>24 meses: 1/258 (<1)|12 meses: 0<br>24 meses: 0|4/31 (13)|0|NR|NR|1/122 (1)|1/123 (1)|NR|NR|
|Febre|NR|NR|NR|NR|1/22 (5)|0|NR|NR|NR|NR|
|Hipoalbuminemia|NR|NR|NR|NR|0|1/24 (4)|NR|NR|NR|NR|
|Hipocalemia|NR|NR|0|1/31 (3)|0|3/24 (13)|NR|NR|NR|NR|
|Infarto do miocárdio|NR|NR|NR|NR|1/22 (5)|0|NR|NR|NR|NR|
|Inflamação muscular|12 meses: 0|12 meses: 1/258 (<1)|NR|NR|NR|NR|NR|NR|NR|NR|
|Mialgia|12 meses: 0|12 meses: 0|NR|NR|NR|NR|NR|NR|NR|NR|
|Náusea|12 meses: 0|12 meses: 0|0|0|0|1/24 (4)|0|1/123 (1)|NR|NR|
|Neuropatia|NR|NR|1/31 (3)|2/31 (6)|NR|NR|NR|NR|NR|NR|
||12 meses: 54/258|12 meses: 52/258|||||15/123|18/122|||
|Neutropenia|(21)<br>5 anos: 75/258 (29)|(20)<br>5 anos: 62/258 (24)|8/31 (26)|5/31 (16)|3/22 (14)|5/24 (22)|<br>(12)|<br>(15)|NR|NR|
|Neutropenia febril|NR|NR|NR|NR|NR|NR|3/122 (2)|0|NR|NR|
|Prurido|NR|NR|0|1/31 (3)|NR|NR|NR|NR|NR|NR|
|Rash|12 meses: 0<br>24 meses: 0|12 meses: 3/258 (1)<br>24 meses: 3/258 (1)|NR|NR|0|0|0|2/123 (2)|NR|NR|
|Segundo câncer|NR|NR|NR|NR|1/22 (5)|3/24 (13)|NR|NR|NR|NR|
||12 meses: 49/258|12 meses: 28/258|||||||||
|Trombocitopenia|(19)<br>5 anos: 56/258 (22)|(10)<br>5 anos: 36/258 (14)|2/31 (6)|4/31 (13)|3/22 (14)|1/24 (4)|NR|NR|NR|NR|
|Vômito|12 meses: 0|12 meses: 0|0|0|0|1/24 (4)|1/122 (1)|0|NR|NR|  
<mark>NR: não reportado. Dados foram apresentados em n/N (%).</mark>  
*Aumento de TGP, derrame pleural e trombocitopenia foram mais frequentes no grupo dasatinibe.  
**Hipocalemia, edema e neutropenia foram mais frequentes no grupo imatinibe.  
**Tabela K -** Características dos estudos que avaliaram eficácia e segurança do nilotinibe como tratamento de primeira linha  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**ENESTnd,**<br>**2010**<sup>**53-55**</sup>|ECR, fase III,<br>multicêntrico,<br>aberto|Avaliar a eficácia e<br>segurança do nilotinibe300<br>e 400mg em relação ao<br>imatinibe 400mg|Pacientes adultos recém-<br>diagnosticados com LMC,<br>estratificados pelo score de risco<br>Sokal|Nilotinibe 300mg 2x/dia<br>Nilotinibe 400mg 2x/dia|Imatinibe 400mg<br>1x/dia|Moderado: não houve<br>esquema de cegamento no<br>estudo|
|**Cortes et**<br>**al. 2010b**<sup>**56**</sup>|Estudo<br>experimental não<br>comparativo,<br>fase II|Avaliar eficácia e segurança<br>do nilotinibe como<br>tratamento de primeira<br>linha em pacientes com<br>LMC|Pacientes adultos recém-<br>diagnosticados com LMC|Nilotinibe 400mg<br>2x/dia, podendo ser<br>reduzida para 200mg 2<br>ou 1x/dia em caso de<br>toxicidade não<br>hematológica|NA|Alto: série de casos para<br>inferir eficácia e segurança|  
LMC: leucemia mieloide crônica; mg: miligrama; NA: não se aplica.  
**Tabela L -** Características dos pacientes incluídos nos estudos que avaliaram eficácia e segurança do nilotinibe como tratamento de primeira linha  
|**Autor, ano**|**N**<br>**Nilo**|**N**<br>**Imatinib**<br>**e**|**Idade Nilo**|**Idade**<br>**Imatinib**<br>**e**|**Sexo masculino**<br>**Nilo**|**Sexo**<br>**masculino**<br>**Imatinibe**|**Tempo de tratamento**|**Suspensão n/N (%)**|**Razão para suspensão (n**<br>**pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**ENESTnd**<br>**(Saglio et al.**<br>**2010)**|**Nilo 300mg:**<br>282|<br>283|**Nilo 300mg:**<br>47 (18–85)|46<br>(18–80)|**Nilo 300mg:**<br>158/282 (56)|158/283<br>(56)|Mediana<br>14 meses|Até 12<br>meses:13/846 (1,5)|Falha do tratamento (7)<br>Progressão da doença (3)|≥12 meses|  
|**Autor, ano**|**N**<br>|**N**<br>**Imatinib**|**Idade Nilo**|**Idade**<br>**Imatinib**|**Sexo masculino**<br>|**Sexo**<br>**masculino**|**Tempo de tratamento**|**Suspensão n/N (%)**|**Razão para suspensão (n**<br>|**Tempo de**<br>|
|---|---|---|---|---|---|---|---|---|---|---|
||**Nilo**|**e**||**e**|**Nilo**|**Imatinibe**|||**pacientes)**|**seguimento**|
||**Nilo 400mg:**||**Nilo 400mg:**||**Nilo 400mg:**||||Resposta subótima (1)||
||281||47 (18–81)||175/281 (62)||||Outros (2)||
||||||||**Nilo 300mg:**||||
|**ENESTnd**<br>**(Kantarjian**<br>**et al. 2011)**|||||||25 meses (22,1-27,8)<br>**Nilo 400mg:**<br>25,7 meses (22,3-28,2)<br>**Imatinibe:**<br>24,7 meses (19,1-28,4)|Entre 12 e 24 meses:<br>69/846 (8)|Progressão doença: 3%<br>Resposta subótima ou<br>falha do tratamento: 72%<br>Outros: 25%|>24 meses|
|**ENESTnd**<br>**(Larson et**<br>**al. 2012)**|||||||**Nilo 300mg:**<br>36,4 meses (0,1-46,7)<br>**Nilo 400mg:**<br>36,6 meses (0,2-46)<br>**Imatinibe:**<br>35,5 meses (0,0-46,5)|Entre 24 e 36 meses:<br>59/846 (7)|Resposta sub-ótima ou<br>falha do tratamento: 100%|Mediana<br>37,6|
|**Cortes et al.**<br>**2010b**|61|NA|46 (19-86)|NA|NR|NA|NR|NR|NR|17,3 (1-43)|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento;</mark> Nilo: Nilotinibe; mg: miligrama; NR: não reportado. <mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou</mark>  
<mark>n/N (%).</mark>  
**Tabela M -** Desfechos de eficácia dos estudos que avaliaram nilotinibe como tratamento de primeira linha  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Nilo**|**Mortalidade**<br>**ou Sobrevida**<br>**Imatinibe**|**p para**<br>**comparaçã**<br>**o**|**Resposta Nilo, n/N (%)**|**Resposta Imatinibe, n/N**<br>**(%)**|**p para**<br>**comparação**|**Tempo até**<br>**resposta**<br>**Nilo**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|||||**Nilo 300mg:**<br>RMM em 12 meses: 44%|||||
|**ENESTn**||||RMM RQ-PCR em 12 meses: 51%<br>RMM em qualquer momento: 57%<br>Níveis de transcripto BCR-ABL ≤0,0032%:<br>13%<br>RCC em 12 meses: 80%|RMM em 12 meses: 22%<br>RMM RQ-PCR em 12<br>meses: 27%<br>RMM  l|**Nilo 300mg:**<br>RMM em<br>12meses:<br>p<0,001<br>RCC  12|**Nilo**<br>**300mg:**<br>RMM:||
|**d (Saglio**<br>**et al.**<br>**2010**||||RCC confirmada em 12 meses: 93%<br>Progressão da doença: 2/282 (0,7)|em quaquer<br>momento: 30%<br>Níveis de transcripto|em<br>meses: p<0,001|mediana 8,6<br>meses|RMM:<br>mediana|
|**)**<br>**Seguimen**<br>**to 12**<br>**meses**|NR|NR|NA|**Nilo 400mg:**<br>RMM em 12 meses: 43%<br>RMM RQ-PCRem 12 meses: 50%<br>RMM em qualquer momento: 54%<br>Níveis de transcripto BCR-ABL ≤0,0032%:<br>12%|BCR-ABL ≤0,0032%: 4%<br>RCC em 12 meses: 65%<br>RCC confirmada em 12<br>meses: 76%<br>Progressão da doença:<br>4/283 (11)|**Nilo 400mg:**<br>RMM em<br>12meses:<br>p<0,001<br>RCC em 12<br>meses: p<0,001|**Nilo**<br>**400mg:**<br>RMM:<br>mediana 11<br>meses|não<br>alcançada|
|||||RCC em 12 meses: 78%<br>RCC confirmada em 12 meses: 93%<br>Progressão da doença: 1/281 (0,35)||Demais: NR|||  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Nilo**|**Mortalidade**<br>**ou Sobrevida**<br>**Imatinibe**|**p para**<br>**comparaçã**<br>**o**|**Resposta Nilo, n/N (%)**|**Resposta Imatinibe, n/N**<br>**(%)**|**p para**<br>**comparação**|**Tempo até**<br>**resposta**<br>**Nilo**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|||||||**Nilo 300mg:**<br>RMM em 24|||
|||||**Nilo 300mg:**||meses:|||
||||**Nilo**|RMM em 24 meses: 201/283 (71%)||p<0,0001|||
||||**300mg:**|Proporção pacientes em RMM 12 até 24||RMC4:|||
||**Nilo 300mg:**||SLE:|meses: 118/127 (93%)|RMM em 24 meses:|p<0,0001|**Nilo**||
||SLE: 96,4%||p=0,12|RMC4: 124/282 (44%)|<br>124/281 (44%)|RMC4,5:|**300mg:**||
|**ENESTn**|SLP: 98%||SLP: p=0,07|RMC4,5: 74/282 (26%)|<br>Proorão acientes em|p<0,0001|RMM:||
|**d**|SG: 97,4%||SG: p=0,64|RCC em 24 meses: 245/282 (87%)|pç p<br>RMM 12 até 24 meses:|RCC 24 meses:|mediana 8,3||
|<br>|Mortalidade:||Mortalidade|Progressão para fase de transformação ou|<br>|p=0,0018|meses||
|**(Kantarji**<br>**an et al.**<br>**2011)**<br>**Seuimen**|9/282 (3,2)<br>**Nilo 400mg:**|SLE: 93,6%<br>SLP: 95,2%|: NR<br>**Nilo**|blástica: 2/282 (0,71%)<br>**Nilo 400mg:**|58/63 (92%)<br>RMC4: 58/281 (20%)<br>RMC4,5: 28/281 (10%)<br>RCC em 24 meses:|**Nilo 400mg:**<br>RMM em 24|(95%IC 5,8-<br>8,3)|RMM:<br>mediana<br>111|
|**g**<br>|SLE: 97,8%|SG: 96,3%|**400mg:**|RMM em 24 meses: 187/279 (67%)|<br>|meses:|**Nilo**|,<br>|
|**to 24**<br>|SLP: 97,7%|Mortalidade:|SLE:|Proporção pacientes em RMM 12 até 24|218/281 (77%)<br>Pã  f d|p<0,0001|**400mg:**|meses<br>95% IC|
|**meses**|SG: 97,8%|11/283 (3,9)|p=0,01|meses: 110/121 (91%)|rogresso para ase e<br>transformaão ou blástica:|RMC4:|RMM:|( :<br>85-136)|
||Mortalidade:||SLP: p=0,04|RMC4: 101/281 (36%)|ç<br>12/283 (42%)|p<0,0001|mediana 8,3|,,|
||6/281 (2,1)||SG: p=0,21|RMC4,5: 59/281 (21%)|,|RMC4,5:|meses||
||||Mortalidade|RCC em 24 meses: 238/281 (85%)||p=0,0004|(95%IC 6,0-||
||||: NR|Progressão para fase de transformação ou||RCC 24 meses:|8,5)||
|||||blástica: 3/281 (1,1%)||p=0,016<br>Demais: NR|||  
|**Autor,**|**Mortalidade ou**<br>**Sobrevida**|**Mortalidade**<br>**ou Sobrevida**|**p para**<br>**comparaçã**|**Resposta Nilo, n/N (%)**|**Resposta Imatinibe, n/N**<br>|**p para**<br>|**Tempo até**<br>**resposta**|**Tempo**<br>**até**<br>|
|---|---|---|---|---|---|---|---|---|
|**ano**|**Nilo**|**Imatinibe**|**o**||**(%)**|**comparação**|**Nilo**|**resposta**<br>**Imatinibe**|
|||||**Nilo 300 mg:**||**Nilo 300 mg:**|||
||||**Nilo**|RMM em 36 meses: 206/282 (73)||RMM 36|||
||||**300mg:**|RMM RQ-PCR em 36 meses: 165/195 (85)||meses:|||
||**Nilo 300mg:**||SLE:|Perda de RMM em qualquer momento: 9/282|RMM em 36 meses:|p<0,0001|||
||SLE: 95,3%||p=0,13|(3,2)|<br>150/283 (53%)|RMC4:|||
||SLP: 96,9%||SLP: p=0,08|RMC4em 36 meses: 50%|<br>|p<0,0001|||
|**ENESTn**|SG: 95,1%||SG: p=0,44|RMC4,5em 36 meses: 32%|RMM RQ-PCR em 36<br>meses: 109/171 (64%)|RMC4,5:|||
|**d (Larson**|Mortalidade:||Mortalidade|Progressão para AP/BC em tratamento: 2/282|<br>Perda de RMM em|p<0,0001|||
|**et al.**|13/282 (4,6)||: NR|(0,5)|<br>||||
|**2012)**||SLE: 93,1%|||qualquer momento: 14/283<br>(49)|**Nilo 400mg:**|NR|NR|
|**Seguimen**|**Nilo 400mg:**|SLP: 94,7%|**Nilo**|**Nilo 400mg:**|,<br>RMCem 36 meses: 26%|RMM 36|||
|**to 36**|SLE: 97,4%|SG: 94%|**400mg:**|RMM em 36 meses: 197/281 (70)|4 <br>RMCem 36 meses: 15%|meses:|||
|**meses**|SLP: 98,3%|Mortalidade:|SLE:|RMM RQ-PCR em 36 meses: 161/203 (79)|4,5 <br>A|p<0,0001|||
||SG: 97%|17/283 (6)|p=0,01|Perda de RMM em qualquer momento: 11/281|Progressão para P/BC<br>12/283|RMC4:|||
||Mortalidade:||SLP: p=0,02|(3,9)|em tratamento:<br>(42%)|p<0,0001|||
||8/281 (2,8)||SG: p=0,06|RMC4 em 36 meses: 44%|,|RMC4,5:|||
||||Mortalidade|RMC4,5 em 36 meses: 28%||p<0,0001|||
||||NR|Progressão para AP/BC em tratamento: 3/281|||||
|||||(1,1)||Demais: NR|||
||SLE em 24|||**Em qualquer momento**<br>**Em 12 meses:**|||RHC: 3||
|**Cortes et**|meses: 90%|NA|NA|**durante o estudo:**<br>RCM: 36/37|NA|NA|semanas|NA|
|**al. 2010b**|SLP em 24|||RHC: 47/48 (98%)<br>(97%)|||(0,6-12)||
||meses: 98%|||RCC: 50/51 (98%)<br>RCC: 36/37|||RCC: 3||  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Nilo**|**Mortalidade**<br>**ou Sobrevida**<br>**Imatinibe**|**p para**<br>**comparaçã**<br>**o**|**Resposta Nil**|**o, n/N (%)**|**Resposta Imatinibe, n/N**<br>**(%)**|**p para**<br>**comparação**|**Tempo até**<br>**resposta**<br>**Nilo**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|---|
||SG em 24 meses:|||RMM: 39/51 (76%)|(97%)|||meses (3-6)||
||100%|||RMC: 12/51 (24%)|RMM: 31/38|||RMM: 3||
||||||(81%)|||meses: (3-||
||||||RMC: 4/38|||18)||
||||||(11%)|||||
|||||**Em 3 meses:**||||||
|||||RCM: 49/50 (98%)|**Em 18 meses:**|||||
|||||RCC: 45/50 (90%)|RCM: 27/28|||||
|||||RMM: 20/50 (40%)|(96%)|||||
|||||RMC: 1/50 (2%)|RCC: 26/28|||||
||||||(93%)|||||
||||||RMM: 23/29|||||
||||||(79%)|||||
||||||RMC: 6/29|||||
|||||**Em 6 meses:**|(21%)|||||
|||||RCM: 44/45 (98%)||||||
|||||RCC: 43/45 (96%)|**Em 24 meses:**|||||
|||||RMM: 33/46 (71%)|RCM: 13/14|||||
|||||RMC: 2/46 (4%)|(93%)|||||
||||||RCC: 13/14<br>(93%)|||||
||||||RMM: 12/15|||||
||||||(79%)|||||  
|**Autor,**<br>**ano**|**Mortalidade ou**<br>**Sobrevida**<br>**Nilo**|**Mortalidade**<br>**ou Sobrevida**<br>**Imatinibe**|**p para**<br>**comparaçã**<br>**o**|**Resposta Nilo, n/N (%)**|**Resposta Imatinibe, n/N**<br>**(%)**|**p para**<br>**comparação**|**Tempo até**<br>**resposta**<br>**Nilo**|**Tempo**<br>**até**<br>**resposta**<br>**Imatinibe**|
|---|---|---|---|---|---|---|---|---|
|||||RMC: 3/15|||||
|||||(20%)|||||
|||||**Em 30 meses:**|||||
|||||RCM: 11/12|||||
|||||(92%)|||||
|||||RCC: 11/12|||||
|||||(92%)|||||
|||||RMM: 10/13|||||
|||||(75%)|||||
|||||RMC: 2/13|||||
|||||(15%)|||||  
Nilo: Nilotinibe; <mark>N: número de pacientes; n: número de pacientes que apresentaram o evento;</mark> RMM: resposta molecular maior; RCC: Resposta citológica completa; SLE: sobrevida livre de eventos; SLP: sobrevida livre de  
progressão; SG: sobrevida global; NR: Não reportado; RM4: Resposta Molecular com 4log de redução de BCR-ABL; RM4,5: Resposta Molecular com 4,5log de redução de BCR-ABL; RMC: resposta hematológica completa; RCM: Resposta citológica maior; RMC: Resposta molecular completa; NA: Não se aplica. <mark>Quando não especificado, dados foram apresentados como mediana em meses (mínimo-máximo) ou n/N (%)</mark>  
**Tabela N -** Eventos adversos apresentados nos estudos que avaliaram nilotinibe como tratamento de primeira linha  
|**Eventos adversos**||**Autor,**|**ano**||
|---|---|---|---|---|
|<br>**(Grau 3-4)**|**E**|**NESTnd (12 e 24 meses)**||**Cortes et al. 2010b**|
||**Nilotinibe 300mg**|**Nilotinibe 400mg**|**Imatinibe**|**Nilotinibe 400mg**|
|Alopécia|0|0|0|NR|
|Anemia|12 meses: 9/279(3)<br>24 meses: 10/279 (4)|12 meses: 9/277(3)<br>24 meses: 11/277 (4)|12 meses: 14/280<br>(5)<br>24 meses: 14/280<br>(5)|3/61 (5)|
|Anorexia|NR|NR|NR|1/61 (2)|
|Cefaleia|3/279 (1)|3/277 (1)|0|NR|
|Diarreia|2/279(1)|0|3/280(1)|NR|
|Dispneia|NR|NR|NR|1/61 (2)|
|Dor musculoesquelética|NR|NR|NR|2/61 (3)|
|Edema periorbital|0|0|0|NR|
|Espasmo muscular|0|2/277(1)|2/280 (1)|NR|
|Fadiga|0|2/277 (1)|1/280(<1)|2/61 (3)|
|Febre|NR|NR|NR|3/61 (5)|
|Mialgia|1/279 (<1)|0|0|NR|
|Náusea|1/279 (<1)|3/277 (1)|0|NR|
|Neuropatia|NR|NR|NR|1/61 (2)|
||12 meses: 33/279||12 meses:||
|Neutropenia|(12)<br>24 meses: 33/279|12 meses: 27/277(10)<br>24 meses: 30/277 (11)|56/280(20)<br>24 meses: 59/280|8/61 (12)|
||(12)||(21)||
|Prurido|1/279 (<1)|1/277(<1)|0|NR|
|Rash|1/279 (<1)|7/277 (3)|4/280(1)|1/61 (2)|
||12 meses:||12 meses:||
||28/279(10)|12 meses: 33/277(12)|24/280(9)||
|Trombocitopenia|24 meses: 29/279|24 meses: 34/277 (12)|24 meses: 24/280|7/61 (11)|
||(10)||(9)||
|Vômito|0|3/277(1)|0|NR|  
<mark>NR: não reportado. Dados foram apresentados em n/N (%).</mark>  
**Questão de Pesquisa 2:** Qual o nível de resposta do nilotinibe e do dasatinibe, em relação ao imatinibe, estratificados por risco (SOKAL, Hasford ou Eurorisk)?

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic</mark>  
<mark>Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ("Dasatinib"[Mesh] OR Sprycel OR BMS 354825 OR "4-methyl-N-(3-(4-methylimidazol-1-yl)-5-(trifluoromethyl)phenyl)-3-((4-pyridin-3-ylpyrimidin-2yl)amino)benzamide" [Supplementary Concept] OR nilotinib OR Tasigna OR AMN107)) AND ("Imatinib Mesylate"[Mesh] OR Imatinib OR Mesylate, Imatinib OR Imatinib Methanesulfonate OR STI-571 OR Gleevec OR Glivec)) AND (Hasford OR Sokal OR Eutos OR Euro OR Risk OR Score)</mark>  
Total: 162 referências  
Data de acesso: 09/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>('chronic myeloid leukemia'/mj) OR ('leukemia'/mj AND myelogenous AND chronic AND [embase]/lim) OR (chronic AND myelocytic AND 'leukemia'/mj AND [embase]/lim)</mark>  
<mark>AND</mark>  
<mark>[('dasatinib'/mj AND [embase]/lim) OR ('sprycel'/mj AND [embase]/lim) OR (bms AND 354825 AND [embase]/lim)] OR [('nilotinib'/mj AND [embase]/lim) OR ('tasigna'/mj AND [embase]/lim) OR ('amn107'/mj AND [embase]/lim)] AND</mark>  
<mark>(hasford OR sokal OR eutos OR euro OR risk OR score AND [embase]/lim) AND</mark>  
<mark>([cochrane review]/lim OR [systematic review]/lim OR [meta analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND [embase]/lim</mark>  
<mark>Total: 51 referências</mark>  
<mark>Data de acesso: 06/3/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 213 referências (162 no MEDLINE e 51 no Embase). Destas, 40 foram excluídas por estarem duplicadas. Cento e setenta e três referências foram triadas por meio da leitura de título e resumos das publicações, das quais 14 tiveram seus textos completos avaliados para confirmação da elegibilidade. Três estudos foram excluídos: uma revisão sistemática com meta-análise, por apresentar os desfechos de todas as diferentes moléculas de inibidores da tirosinoquinase na mesma estimativa sumária; um estudo foi excluído por não estratificar os desfechos por nível de risco e, por fim, uma revisão narrativa sobre as principais publicações do estudo ENESTnd, que já foram considerados na presente análise. Onze publicações correspondentes a 5 estudos foram incluídas</mark><sup>47, 58-67</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>Os estudos serão apresentados de acordo com as comparações realizadas. A descrição sumária dos estudos que compararam diretamente dasatinibe, nilotinibe e imatinibe nas doses de 400 e 800mg encontra-se na</mark> **<mark>Tabela O</mark>** <mark>. As características dos pacientes para esses estudos encontram-se na</mark> **<mark>Tabela P</mark>** <mark>e os dados de desfechos, na</mark> **<mark>Tabela Q</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela R</mark>** <mark>apresenta as descrições sumárias dos estudos que avaliaram a eficácia do dasatinibe estratificada por categoria de risco. A</mark> **<mark>Tabela S</mark>** <mark>apresenta as características dos participantes dos estudos. A</mark> **<mark>Tabela T</mark>** <mark>apresenta os dados de desfechos de eficácia.</mark>  
<mark>A</mark> **<mark>Tabela U</mark>** <mark>apresenta as descrições sumárias dos estudos que avaliaram a eficácia do nilotinibe estratificada por categoria de risco. A</mark> **<mark>Tabela V</mark>** <mark>apresenta as características dos participantes dos estudos e a</mark> **<mark>Tabela W</mark>** <mark>apresenta os dados de desfechos de eficácia.</mark>  
<mark>A</mark> **<mark>Tabela X</mark>** <mark>apresenta a descrição sumária do estudo e das características dos participantes que avaliou a eficácia do imatinibe estratificada por categoria de risco. A</mark> **<mark>Tabela Y</mark>** <mark>apresenta os desfechos de eficácia.</mark>  
**Tabela O -** Características dos estudos de comparação direta entre imatinibe, dasatinibe e nilotinibe para eficácia estratificada por risco  
|**Autor,**|**Desenho de**<br>|**Objetivo do estudo**|**População**|**Deta**<br>|**lhes da Intervenç**|**ão**|**Detalhes do**<br>**controle**<br>|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**ano**|**estudo**|||**Imatinibe**<br>**800mg**|**Dasatinibe**|**Nilotinibe**|**Imatinibe**<br>**400mg**||
|**Jabbour**<br>**et al.**<br>**2012**<sup>**58**</sup>|Estudo de<br>coorte<br>retrospectivo|Validar o escore EUTOS em<br>uma coorte independente de<br>pacientes adultos recém-<br>diagnosticados com LMC e<br>tratados com iTQs|Pacientes adultos<br>recém-<br>diagnosticados com<br>LMC e tratados com<br>iTQs - provenientes<br>de estudos de fase II|Imatinibe<br>800mg/dia|Dasatinibe<br>100 mg/dia|<br>Nilotinibe<br>400mg/dia|Imatibibe<br>400mg/dia|Alto: estudo não<br>randomizado, dados<br>retrospectivos e não foram<br>realizadas análises<br>ajustadas por variáveis de<br>base|
|**Jain et**<br>**l 2013**|Estudo de<br>coorte|Avaliar desfechos de eficácia<br>em pacientes com LMC|Pacientes adultos<br>recém -|Imatinibe|Dasatinibe|<br>Nilotinibe|Imatibibe|Alto: estudo não<br>randomizado e natureza|
|**a.**<br>**59**|<br>retrospectivo|tratados em um serviço de<br>oncologia|diagnosticados com<br>LMC|800mg/dia|100mg/dia|400mg/dia|400mg/dia|<br>retrospectiva dos dados|  
LMC: leucemia mieloide crônica; iTQs: inibidores da tirosino-quinase; mg: miligramas.  
**Tabela P -** Características dos pacientes incluídos nos estudos de comparação direta entre imatinibe, dasatinibe e nilotinibe  
|**Autor,**|**N**<br>|**N**<br>|**N**<br>|**N**<br>||**Sexo**||**N por estra**|**to de risco**||**Tempo de seguimento,**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**ano**|**imatinib**<br>**e 800mg**|**dasatinib**<br>**e**|**nilotinib**<br>**e**|**imatinib**<br>**e 400mg**|**Idade**|**masculino**|**Imatinibe**<br>**800mg**|**Dasatinibe**|**Nilotinibe**|**Imatinibe**<br>**400mg**|**mediana em meses (mín-máx)**|
|**Jabbour**<br>**et al.**<br>**2012**<sup>**58**</sup>|<br>208|88|98|71|Toda<br>coorte: 47<br>(15-85)|NR|**EUTOS**<br>**Baixo:**<br>189/208 (91)<br>**Alto:**19/208<br>(9)|**EUTOS**(Da<br>nilotin<br>**Baixo:**171<br>**Alto:**15/|satinibe +<br>ibe)<br>/186 (92)<br>186 (8)|**EUTOS**<br>**Baixo:**<br>67/71 (94,4)<br>**Alto:**4/71 (5,6)|Imatinibe 400mg: 117 (16-130)<br>Imatinibe 800mg: 88 (4-118)<br>Dasatinibe + nilotinbe: 30 (3-<br>69)|  
|**Autor,**|**N**<br>|**N**<br>|**N**<br>|**N**<br>||**Sexo**||**N por estra**|**to de risco**||**Tempo de seguimento,**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**ano**|**imatinib**<br>**e 800mg**|**dasatinib**<br>**e**|**nilotinib**<br>**e**|**imatinib**<br>**e 400mg**|**Idade**|**masculino**|**Imatinibe**<br>**800mg**|**Dasatinibe**|**Nilotinibe**|**Imatinibe**<br>**400mg**|**mediana em meses (mín-máx)**|
|**Jain et**<br>**al. 2013**<br>**59**|199|102|105|71|Toda<br>coorte: 48<br>(15-86)|Toda<br>coorte:<br>277/477<br>(58)|**SOKAL**<br>**Baixo:**<br>107/199 (54)<br>**Intermediário:**<br>60/199 (30)<br>**Alto:**22/199<br>(11)|**SOKAL**<br>**Baixo:**<br>66/102 (65)<br>**Intermediário:**<br>28/102 (27)<br>**Alto:**5/102 (5)|**SOKAL**<br>**Baixo:**<br>63/105 (60)<br>**Intermediári**<br>**o:**32/105 (30)<br>**Alto:**8/105<br>(8)|**SOKAL**<br>**Baixo:**<br>46/71 (65)<br>**Intermediário:**<br>21/71 (30)<br>**Alto:**3/71 (4)|Toda coorte: 72 (2-136)<br>Imatinibe 400mg: 123 (16-136)<br>Imatinibe 800mg: 97 (4-129)<br>Dasatinibe: 36 (2-73)<br>Nilotinibe: 30 (3-77)|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; mg: miligrama; EUTOS: European Treatment and Outcome Study. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor</mark>  
<mark>máximo) ou n/N (%).</mark>  
**Tabela Q** -Desfechos de eficácia estratificados por risco dos estudos de comparação direta entre imatinibe, dasatinibe e nilotinibe  
|**Autor ano**|**Desfechos de eficácia estrato de risco**|**Desfechos de eficácia estrato de risco**|**Valor de p para comparação**|
|---|---|---|---|
|**,**|**ALTO**|**BAIXO**||
||**Escore EUTOS**|**Escore EUTOS**|**EUTOS alto****_versus_ baixo**|
||**RCC:**|**RCC:**|**RCC:**|
||Imatinibe 400mg: 100%|Imatinibe 400mg: 86%|Imatinibe 400mg: p=1,0|
||Imatinibe 800mg: 79%|Imatinibe 800mg: 92%|Imatinibe 800mg: p=0,08|
||Dasatinibe + nilotinibe: 80%|Dasatinibe + nilotinibe: 96%|Dasatinibe + nilotinibe: p=0,03|
||**RMM:**|**RMM:**|**RMM:**|
||Imatinibe 400mg: 100%|Imatinibe 400mg: 77%|Imatinibe 400mg: p=1,0|
||Imatinibe 800mg: 79%|Imatinibe 800mg: 87%|Imatinibe 800mg: p=0,3|
||Dasatinibe + nilotinibe: 80%|Dasatinibe + nilotinibe: 86%|Dasatinibe + nilotinibe: p=0,46|
|**Jabbour et al.**|**SLE em 3 anos:**|**SLE em 3 anos:**|**SLE em 3 anos:**|
|**2012**<sup>**58**</sup>|Imatinibe 400mg: 50%|Imatinibe 400mg: 81%|Imatinibe 400mg: p=0,34|
||Imatinibe 800mg: 83%|Imatinibe 800mg: 85%|Imatinibe 800mg: p=0,29|
||Dasatinibe + nilotinibe: 100%|Dasatinibe + nilotinibe: 90%|Dasatinibe + nilotinibe: p=0,16|
||**SLP em 3 anos:**|**SLP em 3 anos:**|**SLP em 3 anos:**|
||Imatinibe 400mg: 67%|Imatinibe 400mg: 90%|Imatinibe 400mg: p=0,47|
||Imatinibe 800mg: 100%|Imatinibe 800mg: 95%|Imatinibe 800mg: p=0,46|
||Dasatinibe + nilotinibe: 100%|Dasatinibe + nilotinibe: 99%|Dasatinibe + nilotinibe: p=0,53|
||**SG em 3 anos:**|**SG em 3 anos:**|**SG em 3 anos:**|
||Imatinibe 400mg: 100%|Imatinibe 400mg: 92%|Imatinibe 400mg: p=0,34|
||Imatinibe 800mg:100%|Imatinibe 800mg: 97%|Imatinibe 800mg: p=0,32|
||Dasatinibe + nilotinibe: 100%|Dasatinibe + nilotinibe: 97%|Dasatinibe + nilotinibe: p=0,64|
|**Jain et al.**|**Sokal estrato intermediário +**|**alto****_versus_baixo (referência)**|< 00001|
|**2013**<sup>**59**</sup>|||p ,|
||RC pobre (Ph> 35%) em 3 mes|es: OR 2,88 (IC95% 1,65-5,01)||  
<mark>RCC: resposta citogenética completa; RMM: resposta molecular maior; SLE: sobrevida livre de eventos; SLP: sobrevida livre de progressão; SG: sobrevida global; RC: resposta citogenética; Ph: cromossomo P</mark> hiladelphia <mark>positivo; OR:</mark> _<mark>Odds Ratio</mark>_ <mark>; IC95%: intervalo de confiança em 95%.</mark>  
**Tabela R -** Características dos estudos que avaliaram a eficácia do dasatinibe estratificada por risco  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**DASISION,**<br>**2010**<sup>**47, 60-62**</sup>|ECR fase III,<br>multicêntrico (108<br>centros), internacional,<br>estratificado por<br>categoria de risco<br>Hasford|Avaliar eficácia e<br>segurança do dasatinibe<br>vs imatinibe como<br>tratamento de primeira<br>linha em pacientes com<br>LMC em fase crônica|Pacientes com LMC Ph+ em fase<br>crônica diagnosticada em até 3<br>meses antes da inclusão no estudo,<br>virgens de tratamento (permitido uso<br>prévio de anagrelida ou hidroxiureia)|Dasatinibe 100mg VO<br>1x/dia|Imatinibe 400mg VO<br>1x/dia|Moderado-baixo:<br>estudo aberto,<br>aparentemente sem<br>outras limitações<br>metodológicas|  
<mark>ECR: Ensaio Clínico Randomizado; LMC: Leucemia mieloide crônica; Ph+: cromossomo Filadelphia positivo; VO: Via oral.</mark>  
**Tabela S -** Características dos pacientes dos estudos que avaliaram a eficácia do dasatinibe estratificada por risco  
|Autor, ano|N por estrato<br>de risco<br>Hasford<br>intervenção|N por<br>estrato de<br>risco<br>Hasford<br>controle|Idade<br>intervenção|Idade<br>controle|Sexo<br>masculino<br>intervenção|Sexo<br>masculino<br>controle|Tempo de<br>tratamento<br>, meses|Suspensão<br>n/N (%)|Razão para suspensão<br>(n pacientes)|Tempo de<br>seguimento|
|---|---|---|---|---|---|---|---|---|---|---|
|**DASISOI**<br>**N**<br>**(Kantarjia**<br>**n et al.**<br>**2010)**<sup>**47, 60**</sup>|Total: 259<br>**Baixo:**<br>86/259 (33)<br>**Intermediári**|Total 260<br>**Baixo:**<br>87/260<br>(33)|46 (18-84)|49 (18-<br>78)|144/259<br>(56)|163/260<br>(63)|Dasa: 14<br>(0,03-24,1)<br>Imatinibe:<br>14,3 (0,3-|Dasa: 40/258<br>(15,5)<br>Imatinibe: 48/258<br>(18,6) - 3 pacientes<br>não receberam a<br>medicação alocada|EA relacionado à medicação (13 vs.<br>11); EA não relacionado à medicação<br>(3 vs. 1); Progressão da doença (11<br>vs. 14); Falha do tratamento (6 vs. 10)|12 meses|
|**DASISOI**|**o:**124/259||||||25,8)|Dasa: 59/258 (23)|EA relacionado à medicação (18 vs.||
|**N**|(48)|**Intermedi**||||||Imatinibe: 64/258|12); EA não relacionado à medicação|2 anos|
|**(Kantarjia**||**ário:**||||||(25)|(5 vs. 1); Progressão da doença (14||  
|Autor, ano|N por estrato<br>de risco<br>Hasford<br>intervenção|N por<br>estrato de<br>risco<br>Hasford<br>controle|Idade<br>intervenção|Idade<br>controle|Sexo<br>masculino<br>intervenção|Sexo<br>masculino<br>controle|Tempo de<br>tratamento<br>, meses|Suspensão<br>n/N (%)|Razão para suspensão<br>(n pacientes)|Tempo de<br>seguimento|
|---|---|---|---|---|---|---|---|---|---|---|
|**n et al.**|**Alto:**|123/260|||||||vs. 17); Falha do tratamento (8 vs.||
|**2011)**<sup>**61**</sup>|49/259 (19)|(47)|||||||11); Outros (14 vs. 23)||
|**DASISIO**<br>**N (Cortes**<br>**et al. 2016)**<br>**62**||**Alto:**<br>50/260<br>(19)||||||Dasa: 100/258 (49)<br>Imatinibe: 96/259<br>(47)|EA não relacionado à medicação (12<br>vs. 4); Progressão da doença ou falha<br>do tratamento (28 vs. 36);<br>Intolerância (42 vs. 17); Outros (18<br>vs. 38)|<br>5 anos|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; Dasa: Dasatinibe; EA: Evento Adverso; mg: miligrama. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo)</mark>  
<mark>ou n/N (%).</mark>  
**Tabela T** - Desfechos de eficácia estratificados por risco dos estudos que avaliaram a eficácia do dasatinibe  
|**Autor, ano**|**Desfechos de eficácia por estrato de**<br>**risco Hasford no grupo Intervenção**|**Desfechos de eficácia**<br>**por estrato de risco**<br>**Hasford no grupo**<br>**Controle**|**Valor de p para**<br>**comparação**|
|---|---|---|---|
||**RCC em 12 meses:**<br>Baixo: 80/86 (94)<br>Moderado: 96/124 (78)|**RCC em 12 meses:**<br>Baixo:66 /87 (76)<br>Moderado: 88/123 (72)||
|**DASISOIN**|Alto: 38/49 (78)|Alto: 32/50 (64)||
|**(Kantarjian et al.**|||NR|
|**2010)**<sup>**47, 60**</sup>|**RMM em 12 meses:**|**RMM em 12 meses:**||
||Baixo: 48/86 (56)|Baixo: 31/87 (36)||
||Moderado: 56/124 (45)<br>Alto: 15/49 (31)|Moderado: 34/123 (28)<br>Alto: 8/50 (16)||
|**DASISOIN**<br>**(Kantarjian et al.**<br>**2011)**<sup>**61**</sup>|**RMM em 2 anos:**<br>Baixo: 63/86 (73)<br>Moderado: 76/124 (61)<br>Alto: 28/49 (57)|**RMM em 24 meses:**<br>Baixo: 493/87 (56)<br>Moderado: 62/123 (50)<br>Alto: 19/50 (38)|NR|
|**DASISION**|**RMM em 5 anos:**|**RMM em 5 anos:**|**RMM em 5 anos:**|
|<br>**(Cortes et al.**<br>**2016)**<sup>**62**</sup>|Baixo: 77/86 (90)<br>Moderado: 88/124 (71)<br>Alto: 32/49 (67)|Baixo: 60/87 (69)<br>Moderado: 79/123 (65)<br>Alto: 27/50 (54)|Baixo: p<0,001<br>Moderado: p=0,3252<br>Alto: p=0,1904|  
RMM: resposta molecular maior; RCC: resposta citogenética completa. D <mark>ados foram apresentados em n/N (%).</mark>  
**Tabela U** - Características dos estudos que avaliaram a eficácia do nilotinibe estratificada por risco  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**ENESTnd,**<br>**2010**<sup>**63-65**</sup>|ECR, fase III,<br>multicêntrico,<br>aberto|Avaliar a eficácia e segurança<br>do nilotinibe300 e 400mg em<br>relação ao imatinibe 400mg|Pacientes adultos recém-<br>diagnosticados com LMC,<br>estratificados pelo score de risco<br>Sokal|Nilotinibe 300mg 2x/dia<br>Nilotinibe 400mg 2x/dia|Imatinibe 400mg<br>1x/dia|Moderado: não houve<br>esquema de cegamento<br>no estudo|  
LMC: leucemia mieloide crônica; mg: miligramas.  
**Tabela V** - Características dos pacientes dos estudos que avaliaram a eficácia do nilotinibe estratificada por risco  
|**Autor, ano**|**N por estrato de**<br>**risco Sokal**<br>**Nilotinibe**|**N por estrato de**<br>**risco Sokal Imatinibe**|**Idade Nilo**|**Idade**<br>**Imatinib**<br>**e**|**Sexo**<br>**masculino**<br>**Nilo**|**Sexo**<br>**masculino**<br>**Imatinibe**|**Tempo de**<br>**tratamento,**<br>**meses**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**ENESTnd**<br>**(Saglio et al.**<br>**2010)**<sup>**63**</sup>|**Total Nilo 300mg:**<br>282<br>**Baixo:**103/282 (37)<br>**Intermediário:**||**Nilo**||**Nilo**<br>**300mg:**||Mediana 14|Até 12<br>meses:13/846<br>(1,5)|Falha do tratamento (7);<br>Progressão da doença<br>(3); Resposta subótima<br>(1); Outros (2)|≥12 meses|
||101/282 (36)|Total: 283|**300mg:**||158/282||**Nilo 300mg:**||||
|**ENESTnd**<br>**(Kantarjian et**<br>**al. 2011b)**<sup>**65**</sup>|**Alto**: 78/282 (28)<br>**Total Nilo 400mg:**<br>281<br>**Baixo:**103/281(37)|**Baixo:**104/283 (37)<br>**Intermediário:**<br>101/283(36)<br>**Alto:**78/283 (28)|47 (18–85)<br>**Nilo**<br>**400mg:**<br>47 (18–81)|46<br>(18–80)|(56)<br>**Nilo**<br>**400mg:**<br>175/281|158/283<br>(56)|25 (22,1-27,8)<br>**Nilo 400mg:**<br>25,7 (22,3-28,2)<br>**Imatinibe:**<br>24,7 19,1-28,4)|Entre 12 e 24<br>meses: 69/846<br>(8)|Progressão da doença:<br>3%; Resposta subotima<br>ou falha do tratamento:<br>72%; Outros: 25%|>24 meses|
|**ENESTnd**|**Intermediário:**||||(62)||**Nilo 300mg:**|Entre 24 e 36|Resposta subótima ou|Mdi|
|**(Larson et al.**|100/281(36)||||||36,4 (0,1-46,7)|meses: 59/846|falha do tratamento:|eana<br>|
|**2012)**<sup>**64**</sup>|**Alto:**78/281(28)||||||**Nilo 400mg:**|(7)|100%|37,6|  
|**Autor, ano**|**N por estrato de**<br>**risco Sokal**<br>**Nilotinibe**|**N por estrato de**<br>**risco Sokal Imatinibe**|**Idade Nilo**|**Idade**<br>**Imatinib**<br>**e**|**Sexo**<br>**masculino**<br>**Nilo**|**Sexo**<br>**masculino**<br>**Imatinibe**|**Tempo de**<br>**tratamento,**<br>**meses**|**Suspensão n/N**<br>**(%)**|**Razão para suspensão**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||36,6 (0,2-46)||||
||||||||**Imatinibe:**||||
||||||||35,5 (0,0-46,5)||||  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento;</mark> Nilo: nilotinibe; mg: miligramas. <mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela W** - Desfechos de eficácia estratificados por risco dos estudos que avaliaram a eficácia do nilotinibe  
|Autor, ano|Desfec<br>**Inter**|hos de eficácia por estrato de risco<br>**venção**|Sokal<br>**Controle**|Valor de p par<br>comaraão|
|---|---|---|---|---|
||**Nilotinibe 300mg**|**Nilotinibe 400mg**|**Imatinibe**|pç|
||**RMM em 12 meses:**|**RMM em 12 meses:**|**RMM em 12 meses:**||
|**ENESTnd**|Alto: 41%|Alto: 32%|Alto: 17%||
|**(Saglio et al.**||||NR|
|**2010)**<sup>**63**</sup>|**RCC em 12 meses:**<br>Alto: 74%|**RCC em 12 meses:**<br>Alto: 63%|**RCC em 12 meses:**<br>Alto: 49%||
||**RMM em 24 meses:**|**RMM em 24 meses:**|**RMM em 24 meses:**||
||Baixo: 73%|Baixo: 74%|Baixo: 53%||
||Intermediário: 74%|Intermediário: 67%|Intermediário: 44%||
||Alto: 65%|Alto: 56%|Alto: 32%||
|**ENESTnd**|**RMM4,5 qualquer momento:**|**RMM4,5 qualquer momento:**|**RMM4,5 qualquer momento:**||
|<br>**Ki**|Baixo: 24%|Baixo:  29%|Baixo: 10%|NR|
|**(antarjan et**<br>**l 2011b**<sup>**65**</sup>|Intermediário: 33%|Intermediário: 13%|Intermediário: 15%||
|**a. )**|Alto: 21%|Alto: 21%|Alto: 5%||
||**RCC em 24 meses:**|**RCC em 24 meses:**|**RCC em 24 meses:**||
||Baixo: 91%|Baixo: 94%|Baixo: 90%||
||Intermediário: 87%|Intermediário: 85%|Intermediário: 77%||
||Alto: 81%|Alto: 56%|Alto: 59%||
||**RMM em 36 meses:**|**RMM em 36 meses:**|**RMM em 36 meses:**||
||Baixo: 79/103 (76,7)|Baixo: 79/103 (76,7)|Baixo: 65/104 (62,5)||
||Intermediário: 76/101 (75,2)|Intermediário: 69/100 (69)|Intermediário: 55/101 (54,5)||
|||Alto: 50/78 (64,1)|Alto: 30/78 (38,5)||
||Alto: 52/78 (66,7)||||
|**EEST**|**RMC4 em 36 meses:**|**RMC4 em 36 meses:**|**RMC4 em 36 meses:**||
|**Nnd**<br>|Baixo: 52/103 (50,5)|Baixo: 53/103 (51,1)|Baixo: 35/104 (33,7)||
|**(Larson et al.**<br>**2012**<sup>**64**</sup>|Intermediário: 56/101 (55,4)|Intermediário: 40/100 (40)|Intermediário: 25/101 (24,8)|NR|
|**)**|Alto: 33/78 (42,3)|Alto: 30/78 (38,5)|Alto: 14/78 (17,9)||
||**RMC4,5 em 36 meses:**|**RMC4,5 em 36 meses:**|**RMC4,5 em 36 meses:**||
||Baixo: 31/103 (30,1)|Baixo: 35/103 (34)|Baixo: 19/104 (18,3)||
||Intermediário: 40/101 (39,6)|Intermediário: 22/100 (22)|Intermediário: 17/101 (16,8)||
||Alto: 19/78 (24,4)|Alto: 21/78 (26,9)|Alto: 7/78 (9)||
|RM|M: resposta molecular maior; RCC: resposta|citogenética completa; RMC: resposta molec|ular completa. Dados foram apresentados em|n/N (%).|  
**Tabela X** - Características do estudo e dos participantes que avaliou a eficácia do imatinibe estratificada por risco  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**N intervenção**|**N por estrato de risco**<br>**Sokal**|**Idad**<br>**e**|**Sexo**<br>**masculino**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|**Whitele**<br>**y et al.**<br>**2015**<sup>**67**</sup>|Estudo<br>observacion<br>al<br>retrospectivo|Avaliar eficácia do iTQ na prática<br>clínica. Os desfechos relatados<br>referem-se apenas aos estratificados<br>por risco Sokal, de acordo com o<br>modelo de regressão multivariada<br>(variáveis consideradas no modelo:<br>sexo, idade, país de origem,<br>empregado, tratamento prévio, dose|Pacientes<br>adultos com<br>LMC|Imatinibe<br>400mg/dia|681, sendo que<br>apenas 387 foram<br>incluídos nos modelos<br>de regressão para<br>estratificação por<br>risco|Baixo: 274/681 (40,2)<br>Intermediário: 192/681<br>(28,2)<br>Alto: 54/681 (7,9)|58<br>(NR)|403/681<br>(59,2)|Alto: 43% dos<br>pacientes excluídos<br>das análises por<br>conta de dados<br>faltantes|
|||inicial, tempo de início de<br>tratamento, escores de risco, EAs)||||Sem dados: 161/681 (23,6)||||  
LMC: leucemia mieloide crônica; iTQ: inibidor da tirosino-quinase; mg: miligramas; EAs: eventos adversos; NR: Não reportado. <mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou</mark>  
<mark>n/N (%).</mark>  
**Tabela Y -** Desfechos de eficácia estratificados por risco do estudo que avaliou a eficácia do imatinibe  
|**Autor, ano**|**Desfechos de eficácia por estrato de risco Sokal**|
|---|---|
||**Modelo 1: Variável dependente: RHC em 3 meses**<br>_Referência: risco intermediário_<br>Baixo risco: ORajut 2,04 (IC 95%: 1,20 - 3,49; p= 0,0086)<br>Alto risco: ORajust 1,36 (IC95%: 0,57 - 3,25; p= 0,4880)|
||**Modelo 2: Variável dependente: RCC em 12 meses**<br>_Referência: risco intermediário_<br>Baixo risco: ORajust 1,17 (IC95%: 0,75 - 1,84; p= 0,4872)<br>Alto risco: ORajust 0,47 (IC95%: 0,23 - 0,98; p= 0,0427)|
||**Modelo 3: Variável dependente: RCC por 12 meses**|
|**Whiteley et al. 2015**<sup>**67**</sup>|_Referência: risco intermediário_<br>Baixo risco: ORajust 1,07 (IC95%: 0,68 - 1,68; p= 0,7647)<br>Alto risco: ORajust 0,40 (IC95%: 0,19 - 0,84; p= 0,0157)|
||**Modelo 4: Variável dependente: RMC/RMM em 18 meses**<br>_Referência: risco intermediário_<br>Baixo risco: ORajust 2,12 (IC95% 1,33 - 3,38; p= 0,0015)<br>Alto risco: ORajust 1,03 (IC95%: 0,51 - 2,09; p= 0,9375)|
||**Modelo 5: Variável dependente: RMC/RMM por 18 meses**<br>_Referência: risco intermediário_|
||Baixo risco: ORajust 1,52 (IC95%:0,90 - 2,55; p= 0,1170)|
||Alto risco: ORajust 1,05 (IC95% 0,48 - 2,28; p= 0,9099)|  
OR ajust: _Odds ratio_ (razão de chances) ajustado; IC95%: intervalo de confiança em 95%; RHC: resposta hematológica completa; RMC: resposta molecular completa; RMM: resposta molecular maior; RCC: resposta citogenética completa.  
**Questão de Pesquisa 3:** Qual a eficácia e segurança dos ITQs (imatinibe, dasatinibe e nilotinibe) como tratamento na fase de transformação da LMC em adultos?

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>(("Leukemia, Myeloid, Accelerated Phase"[Mesh] OR Leukemia, Myelogenous, Accelerated Phase OR Leukemia, Myelogenous, Aggressive Phase OR Leukemia, Myeloid, Accelerated Phase OR Leukemia, Myeloid, Aggressive Phase OR Myeloid Leukemia, Chronic, Accelerated Phase OR Myeloid Leukemia, Chronic, Aggressive Phase)) AND ("Imatinib Mesylate"[Mesh] OR Imatinib OR Mesylate, Imatinib OR Imatinib Methanesulfonate OR STI-571 OR Gleevec OR Glivec OR "Dasatinib"[Mesh] OR Sprycel OR BMS 354825 OR "4-methyl-N-(3-(4-methylimidazol-1-yl)-5-(trifluoromethyl)phenyl)-3((4-pyridin-3-ylpyrimidin-2-yl)amino)benzamide" [Supplementary Concept] OR nilotinib OR Tasigna OR AMN107) Filters: Randomized Controlled Trial; Systematic Reviews</mark>  
<mark>Total: 37 referências</mark>  
<mark>Data do acesso: 09/02/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>[('imatinib'/mj AND [embase]/lim) OR ('gleevec'/mj AND [embase]/lim) OR ('gleevec'/mj AND [embase]/lim) OR ('sti 571'/mj AND [embase]/lim)]</mark>  
<mark>OR</mark>  
<mark>[('dasatinib'/mj AND [embase]/lim) OR ('sprycel'/mj AND [embase]/lim) OR (bms AND 354825 AND [embase]/lim)] OR</mark>  
<mark>[('nilotinib'/mj AND [embase]/lim) OR ('tasigna'/mj AND [embase]/lim) OR ('amn107'/mj AND [embase]/lim)] AND</mark>  
<mark>('acute leukemia'/exp OR 'acute leukemia') OR (myeloid AND ('leukemia'/exp OR leukemia) AND accelerated AND phase AND [embase]/lim)</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>([cochrane review]/lim OR [systematic review]/lim OR [meta analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND [embase]/lim</mark>  
<mark>('adult'/exp OR 'adult' AND [embase]/lim) OR ('aged'/exp OR 'aged' AND [embase]/lim)</mark>  
<mark>Total: 109 referências</mark>  
<mark>Data do acesso: 06/03/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 146 referências (37 no MEDLINE e 153 no Embase). Destas, 15 foram excluídas por estarem duplicadas. Cento e trinta e uma referências foram triadas por meio da leitura de título e resumos das publicações, das quais 12 tiveram seus textos completos avaliados para confirmação da elegibilidade. Três estudos foram excluídos nessa etapa: uma revisão sistemática com meta-análise, por apresentar dados inconsistentes com a conclusão e limitações metodológicas relevantes (por exemplo, não descreveu se os estudos incluídos eram ou não randomizados e utilizou como fonte de dados uma revisão narrativa). Os estudos incluídos nessa revisão sistemática que preencheram o critério de elegibilidade da questão de pesquisa foram avaliados individualmente. Um estudo foi excluído por ser uma revisão narrativa. Adicionalmente, outro estudo apresentou os resultados de pacientes com LMC em fase de transformação e fase blástica de forma conjunta.</mark>  
<mark>Nove referências correspondentes a oito estudos foram selecionadas</mark><sup>20, 68-75</sup> <mark>, dos quais cinco avaliaram desfechos de tratamento com imatinibe</mark><sup>68-72</sup> <mark>e três avaliaram desfechos de tratamento com dasatinibe como segunda linha de tratamento após resistência ou toxicidade do imatinibe</mark><sup>20, 73-75</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>Os estudos estão apresentados de acordo com o tipo de tratamento. A descrição sumária dos estudos que avaliaram a eficácia e segurança do imatinibe em pacientes com LMC em fase de transformação encontra-se na</mark> **<mark>Tabela A1</mark>** <mark>. As características dos pacientes desses estudos encontram-se na</mark> **<mark>Tabela B1</mark>** <mark>e os desfechos de eficácia, na</mark> **<mark>Tabela C1</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela D1</mark>** <mark>apresenta as descrições sumárias dos estudos que avaliaram a eficácia do dasatinibe em pacientes com LMC em fase de transformação previamente tratados com imatinibe. A</mark> **<mark>Tabela E1</mark>** <mark>apresenta as características dos participantes dos estudos. A</mark> **<mark>Tabela F1</mark>** <mark>apresenta os desfechos de eficácia.</mark>  
<mark>A</mark> **<mark>Tabela G1</mark>** <mark>apresenta os desfechos de segurança dos estudos que os relataram. Um estudo não teve os dados de segurança coletados, pois se trata de um estudo de fase I no qual a dose de dasatinibe variou de 15 a 240 mg e não há dados de média ou mediana de dose administrada</mark><sup>75</sup> <mark>. Como a dose atualmente utilizada é de 100 mg, a grande incidência de desfechos poderia levar a interpretações superestimadas de toxicidade.</mark>  
<mark>Ainda, em relação ao estudo START-A, reportado em duas publicações</mark><sup>20, 73</sup> <mark>, apenas os eventos adversos referidos na publicação que considerou o seguimento mais longo foram extraídos. Três estudos não reportaram desfechos de segurança</mark><sup>68, 69,</sup> 71.  
**Tabela A1 -** Características dos estudos que avaliaram as eficácia e segurança do imatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Jiang et al. 2011**<br>**68**|Estudo<br>comparativo não<br>randomizado,<br>prospectivo|Avaliar os desfechos de eficácia<br>entre o tratamento com imatinibe<br>_versus_transplante alogênico de<br>medula óssea em pacientes com<br>LMC em FA|Pacientes adultos < 60 anos<br>com LMC em FA|Imatinibe dose inicial<br>de 600mg ou 400mg<br>diariamente|Imatinibe 400mg <3meses<br>ou dose aumentada de<br>hidroxiureia ± INF-a ou<br>combinação de<br>quimioterapia + transplante<br>alogênico de doador|Alto: intervenções<br>alocadas de acordo<br>com preferência dos<br>participantes|
||||||aparentado compatível||
|**Palandri et al.**<br>**2009**<sup>**69**</sup>|Estudo<br>experimental não<br>controlado (série<br>de casos), fase II|Avaliar os desfechos de longo<br>prazo do imatinibe em pacientes<br>com LMC em FA confirmada|Pacientes adultos com LMC<br>em FA confirmada|Imatinibe 600mg/dia|NA|Alto: série de casos<br>para inferir eficácia|
|**Lahaye et al.**<br>**2005**<sup>**70**</sup>|Estudo<br>experimental não<br>controlado (série<br>de casos),<br>prospectivo|Avaliar desfechos de eficácia e<br>segurança de longo prazo do<br>imatinibe em pacientes com LMC,<br>LMC em FA, LMC em FB e LLA.<br>Apenas os resultados nos<br>pacientes com LMC em FA serão<br>apresentados|Pacientes adultos com LMC<br>em FA|Imatinibe 600mg/dia|NA|Alto: série de casos<br>para inferir eficácia,<br>sem análises<br>ajustadas|
|**Olavarria et al.**<br>**2003**<sup>**71**</sup>|Estudo<br>observacional não<br>controlado (série<br>de casos)<br>retrospectivo|Avaliar a eficácia do imatinibe na<br>recorrência de LMC Ph+<br>confirmado no pós-transplante<br>alogênico de medula óssea|Pacientes com LMC<br>transplantados de medula óssea<br>que apresentaram recorrência<br>de LMC e LMC em FA.<br>Apenas os dados referentes à|Imatinibe 600mg/dia|NA|Alto: Série de casos<br>para inferir eficácia,<br>dados obtidos de<br>forma retrospectiva<br>por meio de<br>questionários|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||população com LMC em FA<br>foram apresentados||||
|**Talpaz et al. 2002**<br>**72**|Estudo<br>experimental não<br>controlado,<br>multicêntrico,<br>prospectivo, fase<br>II|Avaliar desfechos de eficácia e<br>segurança do imatinibe em<br>pacientes com LMC em FA|Pacientes adultos com LMC<br>Ph+ confirmada em FA|Dose inicial de<br>imatinibe de 400mg,<br>que foi aumentada<br>para 600mg após<br>emenda de protocolo|NA|Moderado: Série de<br>casos para inferir<br>eficácia, mas com<br>análises ajustadas|  
<mark>LMC: leucemia mieloide crônica; FA: fase de transformação; mg: miligramas; FB: fase blástica; LLA: leucemia linfoblástica aguda; Ph+: cromossomo P</mark> hiladelphia <mark>; NA: Não se aplica.</mark>  
**Tabela B1 -** Características dos participantes dos estudos que avaliaram as eficácia e segurança do imatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção**|**Idade**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**|**Suspensão**|**Razão para**<br>**suspensão**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||Imatinibe:|
|**Jiang et al.**<br>**2011**|87|45|44 (22-60)|34 (10-59)|51/87 (58,6)|30/45 (66,7)|NR|NR|NR|32 meses (1-108);<br>Transplante:<br>51 meses (1,7-108)|
||||||||||EA: 7/90 (6);||
|**Palandri et**<br>**al. 2009**|111|NA|58 (26-82)|NA|70/111 (63)|NA|NR|90/111 (81)|Perda ou ausência de<br>resposta RHC ou<br>RCC 80/90 (72)|82 meses (73-87)|
|**Lahaye et al.**<br>**2005**|80|NA|60,9 (30,9–81,8)|NA|53/80 (66)|NA|24 meses<br>(0,4-50)|6/80 (7,5)|EA 6/6 (100)|28 meses (0,4-50)|
||128, sendo 31||||||||||
|**Olavarria et**<br>**al. 2003**|com<br>recorrência de<br>LMC em FA|NA|Toda a coorte:<br>42 (15–64)|NA|Toda a coorte:<br>80/128 (62,5)|NR|NR|NR|NR|9 meses<br>(2-34)|
|**Talpaz et al.**<br>**2002**|181|NA|57 (22-86)|NA|92/181 (51)|NA|11 meses<br>(0,2-15)|100/235 (42,5)|Progressão de<br>doença 73/100 (73),<br>EA 14/100(14);<br>óbito (7); outros<br>6/100 (6)|Pelo menos 3<br>meses, até óbito|  
<mark>N: número de participantes no grupo; n: número/proporção entre o grupo; NR: não reportado; NA: não se aplica; EA: eventos adversos; RHC: resposta hematológica completa; RCC: resposta citogenética completa; LMC: leucemia mieloide crônica; FA: fase de transformação. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela C1 -** Desfechos de eficácia dos estudos que avaliaram as eficácia e segurança do imatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**Grupo**|**Mortalidade/Sobrevida**|**Resposta**||**Tempo até resposta**|**Duração da resposta**<br>**intervenção**|
|---|---|---|---|---|---|---|
||Intervenção|Mortalidade: 34/87 (39,1)<br>SLE em 6 anos:<br>39,2% (IC95% 32,7%-45,7%)<br>SG em 6 anos:<br>51,4% (IC95% 44,3%-|Toda a coorte (entre<br>sobreviventes e não<br>sobreviventes):<br>RHC: 74/87 (85,1)<br>RCM: 43/87 (49,4)<br>RCC: 41/87 (471)|Desfechos entre os<br>sobreviventes:<br>RHC: 36/39 (92,3)<br>RCM: 33/39 (84,6)|Recorrência FA:<br>10 meses (25-68)|NR|
|||58,5%)<br>SLP em 6 anos:|,<br>RMM: 30/87 (34,5)<br>RMC: 16/87 (184)|RCC: 33/39 (84,6)<br>RMM: 29/39 (74,4)|,||
|**Jiang et al**||48,3% (IC95% 41,8%-<br>54,8%)|,<br>Perda de RHC: 16/87 (18,4)<br>Recorrência de FA: 25/87 (28,7)|RMC: 16/39 (41)|||
|**.**<br>**2011**||Mortalidade relacionada ao<br>transplante: 5/45 (11,1)|Toda a coorte (entre||||
|||Mortalidade total: 7/45 (15,6)<br>SLE em 6 anos:|sobreviventes e não<br>sobreviventes):|Desfechos entre os<br>|||
|||71,8% (IC 95% 64,8%-|RMC entre 3-6 meses: 41/43|sobreviventes:<br>RHC: 38/38 (100)|Recorrência molecular:||
||Controle|78,8%)<br>SG em 6 anos:|(95,3)<br>Recorrência molecular: 5/44|<br>RCM: 38/38 (100)<br>RCC:  38/38 (100)|13 meses (12-24)<br>Mortalidade:|NR|
|||83,3% (IC 95% 77,4%-<br>89,2%)<br>SLP em 6 anos:|(11,4)<br>Recorrência de FA: 2/45 (4,4)<br>RCC: 38/38 (100)|<br>RMM:  38/38 (100)<br>RMC: 37/38 (97,4)|16 meses (1,7-41)||
|||95,2% (IC 95% 91,9%-<br>98,5%)|RMC: 37/38 (97,4)||||  
|**Autor, ano**|**Grupo**|**Mortalidade/Sobrevida**|**Resposta**|**Tempo até resposta**|**Duração da resposta**<br>**intervenção**|
|---|---|---|---|---|---|
|||Mortalidade: NR|Entre sobreviventes:<br>RHC: p=0,24|||
||p para<br>comparação|SLE: p=0,008<br>SG: p=0,023|Toda a coorte: NR<br>RCM: p=0,025<br>RCC: p=0,025|NR|NA|
|||SLP: p<0,001|RMM: p=0,001|||
||||RMC: p<0,0001|||
|||Mortalidade: 70/111 (63)<br>SG em 7 anos:|RHC: 79/111 (71)<br>Perda da RHC: 43/79 (54)|||
|**Pldi t l**||43% (IC95% 33%-53%)|RCC: 23/111 (20,7)|RHC: 2 meses (1-7)||
|**aanr e a.**<br>**2009**|Intervenção|SLP em 7 anos:<br>36,5% (IC95% 27%-45%)|RCP: 10/111 (9)<br>RCMenor: 6/111 (5,4)|RCC: 6 meses (1-42)<br>Perda RCC: 10 (3-36)|RCC: 66 meses (41-75)|
|||SLE em 7 anos:|RCMin: 14/111(12,6)|||
|||15% (IC95% 27%-45%)|Perda RCC: 6/23 (26)|||
||||RCM: 25/80 (31)|||
|**Lahaye et al.**<br>**2005**|Intervenção|Mortalidade: 31/80 (39)<br>SG pós início do tratamento:<br>44 meses (0,4-50)|RCC: 21/80 (26)<br>RCP: 4/80 (5)<br>RCMin: 29/80 (36)<br>RMBCR-ABL/ABL  0,1%: 9/80 (11)<br>RHC: 49/80 (61)|NR|RH: 38 meses (1-49)<br>RCM: 38 meses (2-36)|
||||Recorrência hematológica: 26/80 (32)|||
||||Progressão para fase blástica: 15/36 (42)|||
|**Olavarria et**<br>**al. 2003**|Intervenção|Mortalidade: 6/31 (19,4)<br>SG em 2 anos: 86%|RHC: 24/29 (83)<br>RHP: 3/29 (10)<br>RCC: 13/27 (48)<br>RCP: 5/27 (19)|NR|NR|  
|**Autor, ano**|**Grupo**|**Mortalidade/Sobrevida**|**Resposta**|**Tempo até resposta**|**Duração da resposta**<br>**intervenção**|
|---|---|---|---|---|---|
||||RMC: 8/24 (33)|||
||||RCM: 43/181 (24; IC 95% 17,8-30,6)|||
|**Talpaz et al.**<br>**2002**|Intervenção|SG em 12 meses: 74% (IC<br>95% 68%-81%)|RCC: 30/181 (17)<br>RCP: 13/181 (7)<br>RCMin: 31/181 (17)|RH: 1 mês (NR)<br>RC: 2,4 meses (NR)<br>Progressão: 8,8 meses (NR)|RH ≤ 4 meses: 13,4 meses (NR)<br>RC: 9 meses em 64% (IC 95%<br>48%-80%) dos pacientes|
||||RH sustentada por ≤ 4 meses: 69%, sendo 34% RHC|||  
<mark>SLE: sobrevida livre de eventos; SG: sobrevida global; SLP: sobrevida livre de progressão; RHC: resposta hematológica completa; RCM: resposta citigenética maior; RCC: resposta citogenética completa; RMM: resposta molecular maior; RMC: resposta molecular completa; FA: fase de transformação; RHM: resposta hematológica maior; RCP: resposta citogenética parcial; RCMenor: resposta citogenética menor; RCMin: resposta citogenética mínima; RH: resposta hematológica; RC: resposta citogenética, NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela D1** - Características dos estudos que avaliaram as eficácia e segurança do dasatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Kantarjian et**<br>**al. 2009**<sup>**20**</sup>|Ensaio clínico<br>randomizado,<br>multicêntrico|Avaliar desfechos de eficácia e segurança<br>do dasatinibe 140mg 1x/dia e 70mg<br>2x/dia em pacientes com LMC em FA<br>resistentes ou intolerantes ao imatinibe|Pacientes adultos com LMC<br>em FA resistentes ou<br>intolerantes ao imatinibe|Dasatinibe 140mg<br>1x/dia|Dasatinibe 70mg<br>2x/dia|Alto: não há descrição da<br>randomização e sigilo da<br>alocação, estudo aberto|
|**START A,**<br>**2009**<sup>**73, 74**</sup>|Estudo experimental<br>não comparativo (série<br>de casos), fase II|Avaliar desfechos de eficácia e segurança<br>do dasatinibe 70mg 2x/dia em pacientes<br>com LMC em FA resistentes ou<br>intolerantes ao imatinibe|Pacientes adultos com LMC<br>em FA resistentes ou<br>intolerantes ao imatinibe|Dasatinibe 70mg<br>2x/dia|NA|Alto: série de casos para<br>inferir eficácia, sem<br>análises ajustadas|
|**Talpaz et al.**<br>**2006**<sup>**75**</sup>|Estudo experimental<br>não comparativo (série<br>de casos) fase I,<br>multicêntrico,<br>internacional|Avaliar desfechos de eficácia e segurança<br>do dasatinibe 70mg 2x/dia em pacientes<br>com LMC em FA resistentes ou<br>intolerantes ao imatinibe|Pacientes adultos com LMC<br>em FA resistentes ou<br>intolerantes ao imatinibe|Dasatinibe 15mg a<br>240mg|NA|Alto risco: série de casos<br>para inferir eficácia sem<br>análises ajustadas|  
<mark>LMC: leucemia mieloide crônica; FA: fase de transformação; mg: miligramas; NA: Não se aplica.</mark>  
**Tabela E1 -** Características dos participantes dos estudos que avaliaram as eficácia e segurança do dasatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**N intervenção**|**N**<br>**controle**|**Idade**<br>**intervenção**|**Idade**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**|**Suspensão**|**Razão para suspensão**<br>**(n)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Kantarjian et**<br>**al. 2009**|157|159|56,0<br>(17,0-81,0)|56,0<br>(19,0-84,0)|88/158 (56)|94/159 (59)|1x/dia: 15,4<br>meses (0,03-<br>31,15)<br>2x/dia: 12 meses<br>(0,39-28,8)|1x/dia:<br>100/157 (64)<br>2x/dia:<br>117 (74)|1x/dia: Progressão<br>doença (39); Toxicidade<br>(32); EA (9); Outros<br>(23)<br>2x/dia: Progressão<br>doença: (32);<br>Toxicidade (39); EA (7);<br>Outros (25)|15 meses<br>(0,16-34,5)|
|**START A**<br>**(Apperley et**<br>**al. 2009)**|174|NA|57 (22-86)|NA|96/174 (55)|NA|13,5 meses<br>(0,1-21,7)|NR|NR|Mediana 14,1<br>meses|
|**START A**<br>**(Guilhot et al.**<br>**2007)**|107|NA|57 (23-86)|NA|51/107<br>(47,7)|NA|8,3 meses<br>(0,2-12,9)|NR|NR|Mínimo 8<br>meses|
||O estudo incluiu||||||||||
|**Talpaz et al.**<br>**2006**|84 pacientes,<br>mas apenas 11<br>com LMC em<br>FA|NA|63 (40-73)|NA|3/11 (27)|NA|NR|NR|NR|Mediana >5<br>meses|  
<mark>N: número de participantes no grupo; n: número/proporção entre o grupo; NA: não se aplica; NR: não reportado; LMC: leucemia mieloide crônica; FA: fase de transformação. Quando não especificado, dados foram apresentados em</mark>  
<mark>mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela F1** - Desfechos de eficácia dos estudos que avaliaram as eficácia e segurança do dasatinibe em pacientes com LMC em fase de transformação  
|**Autor, ano**|**Grupo**|**Mortalidade/Sobrevida**|**Resposta**|**Tempo até resposta**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|
|||SLP em 12 meses: 68% (IC95% 61%-<br>76%)<br>SLP em 24 meses: 51% (IC95% 42%-|RHM: 66% (IC95% 59%-74%)<br>RHC: 47% (IC95% 40%-56%)<br>RHM sustentada em 12 meses: 85%|RHM: 1,9 meses||
||Intervenção|<br>60%)<br>|RHM sustentada em 24 meses: 65%<br>RCM: 39% (IC95% 31%-47%)|(NR)<br>RCM: 2,8 meses|SLP: 25,1 (NR)<br>SG: não alcançado|
|||SG em 12 meses: 78% (IC95% 71%-84%)<br>SG em 24 meses: 63% (IC95% 56%-71%)<br>Mortalidade por progressão doença: 52%|RCC: 32% (NR)<br>RCM sustentada em 12 meses: 91%<br>RCM sustentada em 24 meses: 63%|(IC95% 2,1-5,6)||
|||SLP em 12 meses: 69% (IC 95% 61%-<br>77%)|RHM: 68% (IC95% 60%-75%)|||
|**Kantarjian et**<br>**al. 2009**|Controle|<br>SLP em 24 meses: 55% (IC 95% 46%-<br>64%)<br>SG em 12 meses: 84% (IC 95% 79%-|RHC: 52% (IC95% 44%-60%)<br>RHM sustentada em 12 meses: 82%<br>RHM sustentada em 24 meses: 60%|RHM: 1,9 meses<br>(NR)|SLP: 26,0 (NR)|
|||<br>90%)<br>SG em 24 meses: 72% (IC 95% 65%-<br>79%)<br>Mortalidade por progressão doença: 43%|RCM: 43% (IC95% 35%-51%)<br>RCC: 33% (NR)<br>RCM sustentada em 12 meses: 82%<br>RCM sustentada em 24 meses: 75%|RCM: 2,5 meses<br>(IC95% 1,9-3,0)|SG: 30,7 (NR)|
|||SLP em 12 meses: NR||||
||p para<br>comparação|SLP em 24 meses: p=0,566<br>SG em 12 meses: p=0,140<br>SG em 24 meses: p=0,435<br>Mortalidade por progressão doença: NR|NR|NR|NR|  
|**Autor, ano**|**Grupo**|**Mortalidade/Sobrevida**|**Resp**|**osta**|**Tempo até resposta**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|---|
|**START A**<br>**(Apperley et**<br>**al. 2009)**|Intervenção|SLP em 12 meses: 66%<br>SG em 12 meses: 82%<br>Mortalidade: 31/174 (17,8)|RHM: 111/174 (64%)<br>RHC: 78/174 (45%<br>RCM: 67/174 (39%);<br>RCC: 55/174 (32%<br>Perda RHM:<br>Perda RCM|; IC95% 56,2%-70,9%<br>); IC95% 37%-53%<br>IC95% 31,2%-46,2%<br>); IC95% 25%-39%<br>18/111 (16,2)<br>: 9/67 (13,4)|RHM: 64 dias<br>(IC95% 57-83)<br>RCM: 58 dias<br>(IC95% 57-85)|NR|
||||**Em 6 meses**:|**Em 8 meses:**|||
||||RHC: 35/107 (33)|RHM: 69/107 (64)|||
|**START A**<br>**(Guilhot et al.**|Intervenção|SLP em 8 meses: 76%<br>Mlidd 14/107 13|RHM: 63/107 (59)<br>RHmin: 23/107 (22)|RHC: 42/107 (39)<br>RHmin: 18/107 (17)|RHM: 58 dias (26-<br>256|NR|
|**2007)**||ortaae:  ()|RCC: 23/107 (22)|RCC: 26/107 (24)|)||
||||RCM: 33/107 (31)|RCM: 35/107 (33)|||
||||RCmin: 19/107 (18)|RCmin: 20/107 (19)|||
||||RHM: 9<br>RHC: 5|/11(82)<br>/11 (45)|||
|**Talpaz et al.**<br>**2006**|Intervenção|NR|RH<br>RCM: 3<br>RCC: 2<br>RCP: 1|Me: 0<br>/11 (27)<br>/11 (18)<br>/11 (9)|NR|NR|
||||RCmin:|1/11 (9)|||  
<mark>SLP: sobrevida livre de progressão, SG: sobrevida global; RHM: resposta hematológica maior; RHC: resposta hematológica completa; RCM: resposta citogenética maior; NR: não reportado; RCC: resposta citogenética completa; RHmin: resposta hematológica mínima; RCmin: resposta citogenética mínima; RHMe: resposta hematológica menor; RCP: resposta citogenética parcial. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela G1 -** Eventos adversos de graus 3-5  
|**Eventos adversos (Grau 3-**|**Lahaye et al. 2005**|**Talpaz et al. 2002**|**Autor, ano**<br>**Kantarjian**|**et al. 2009**|**Apperley et al. 200**|
|---|---|---|---|---|---|
|**5)**|**Imatinibe**|**Imatinibe**|**Dasatinibe**|**Dasatinibe**|**Dasatinibe**|
||**600mg**|**400/600mg**|**140mg 1x/dia**|**70mg 2x/dia**|**70mg 2x/dia**|
|Anemia|31/80 (39)|92/235 (39)|74/155 (48)|68/159 (43)|120/174 (69)|
|Anorexia|NR|3/235 (1)|NR|NR|1/174 (<1)|
|Artralgia|NR|7/235 (3)|0|2/159 (1)|0|
|Cefaleia|NR|3/235 (1)|2/157 (1)|1/159 (1)|1/174 (<1)|
|Derrame Pleural|NR|NR|11/157 (7)|10/159 6)|8/174 (5)|
|Diarreia|NR|1/235 (0,4)|4/157 (3)|5/159 (3)|13/174 (8)|
|Dispneia|NR|NR|5/157 (3)|11/159 (7)|7/174 (4)|
|Dor nas extremidades|NR|2/235 (0,9)|0|3/159 (2)|0|
|Dor abdominal|NR|1/235 (0,4)|NR|NR|0|
|Edema|NR|6/235 (3)|NR|NR|NR|
|Edema periférico|NR|NR|NR|NR|1/174 (<1)|
|Edema superficial|NR|NR|1/157 (1)|0|NR|
|Fadiga|NR|6/235 (3)|3/157 (2)|5/159 3)|7/174 (4)|
|Infecção|NR|NR|9/157 (6)|3/159 (2)|NR|
|Mialgia|NR|3/235 (1)|1/157 (1)|3/159 (2)|1/174 (<1)|
|Mucosite|NR|NR|NR|NR|NR|
|Náusea|NR|8/235 (3)|1/157 (1)|3/159 (2)|1/174 (<1)|
|Neutropenia|38/80 (48)|137/235 (58)|91/155 (59)|109/159 (69)|131/174 (76)|
|Neutropenia febril|NR|NR|6/157(4)|16/159 (10)|NR|
|Rash|NR|NR|0|1/159 (1)|2/174 (1)|
|Sangramento gastrointestinal|NR|NR|9/157 (6)|10/159 (6)|NR|
|Trombocitopenia|32/80(40)|102/235 (33)|99/155 (64)|107/159 (67)|141/174 (82)|
|Vômito|NR|3/235 (1)|1/157 (1)|2/159 (1)|4/174 (2)|  
<mark>NR: não reportado. Dados foram apresentados como n/N (%).</mark>  
**<mark>Questão de pesquisa 4:</mark>** <mark>Qual a acurácia diagnóstica dos exames FISH, RT-PCR (BCR-ABL), Cariotipagem e pesquisa de mutação na monitorização e no diagnóstico da LMC em adultos?</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>(((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ((((("Reverse Transcriptase Polymerase Chain Reaction"[Mesh] OR Polymerase Chain Reaction, Reverse Transcriptase OR Reverse Transcriptase PCR OR PCR,</mark>  
<mark>Reverse Transcriptase OR Transcriptase PCR, Reverse)) OR ("In Situ Hybridization, Fluorescence"[Mesh] OR Fluorescent in Situ</mark>  
<mark>Hybridization OR FISH Technic OR FISH Technics OR FISH Technique OR FISH Techniques))) AND ("Sensitivity and Specificity"[Mesh] OR Sensitivity OR Specificity)))) AND ((("aged"[MeSH Terms] OR "adult"[MeSH Terms:noexp] OR "adult"[MeSH Terms] OR of age OR middle age)</mark>  
<mark>Total: 107 referências</mark>  
<mark>Data do acesso: 08/03/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>('reverse transcription polymerase chain reaction'/mj AND [embase]/lim) OR ('rt pcr'/mj AND [embase]/lim) OR</mark>  
<mark>('fluorescence in situ hybridization'/mj AND [embase]/lim) OR (fluorescent AND in AND situ AND 'hybridization'/mj AND [embase]/lim)</mark>  
<mark>AND</mark>  
<mark>'sensitivity and specificity'/exp OR 'sensitivity and specificity' AND [embase]/lim</mark>  
<mark>AND</mark>  
<mark>('chronic myeloid leukemia'/mj) OR ('leukemia'/mj AND myelogenous AND chronic AND [embase]/lim) OR (chronic AND myelocytic AND 'leukemia'/mj AND [embase]/lim)</mark>  
<mark>AND</mark>  
<mark>('adult'/exp OR 'adult' AND [embase]/lim) OR ('aged'/exp OR 'aged' AND [embase]/lim) Total: 65 referências</mark>  
<mark>Data do acesso: 08/03/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 172 referências (37 no MEDLINE e 153 no Embase). Destas, 24 foram excluídas por estarem duplicadas. Cento e setenta e seis referências foram triadas por meio da leitura de título e resumos, das quais 36 tiveram seus textos completos avaliados, quando disponíveis, para confirmação da elegibilidade.</mark>  
<mark>Não foram localizados os textos completos em versão eletrônica correspondentes a três citações. Adicionalmente, oito estudos foram publicados no idioma chinês e um em japonês. A avaliação da elegibilidade desses estudos foi realizada somente por meio das informações disponíveis nos resumos.</mark>  
<mark>Vinte e nove estudos foram excluídos por não apresentarem dados de sensibilidade, especificidade ou acurácia dos testes de interesse. Adicionalmente, quatro estudos foram excluídos por abordarem pacientes com diagnósticos de outras condições de saúde. Por fim, três estudos foram considerados elegíveis</mark><sup>76-78</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica do Adulto | secao: **6.2.1. Esquema terapêutico** -->
<mark>A</mark> **<mark>Tabela H1</mark>** <mark>apresenta as características dos estudos e resultados de sensibilidade, especificidade e acurácia diagnóstica.</mark>  
**Tabela H1** _-_ Características dos estudos e resultados de sensibilidade, especificidade e acurácia diagnóstica  
|**Autor,**<br>**ano**|**Populaçã**<br>**o**|**Tamanho de**<br>**amostra**|**Idade**|**Teste**<br>**avaliado**|**Teste**<br>**referênci**<br>**a**|**Sensibilidade**|**Especificidade**|**Acurácia**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|||24 pacientes||||RT-PCR multiplex vs. FISH:|RT-PCR multiplex vs. FISH:|||
|||(17 em fase||||85%|81%||Alto: Nem todas|
|**Raanani**|Pacientes|crônica, 4 em|51|RT-PCR||RT-PCR quantitativo vs.|RT-PCR quantitativo vs.||as amostras|
|**et al. 2004**<br>**76**|com<br>LMC|fase de<br>transformaçã|(23–<br>72)|<br>multiplex|FISH|FISH: não determinado pois<br>não foram realizados ambos|FISH: não determinado pois<br>não foram realizados ambos|NR|foram<br>submetidas aos|
|||o e 3 em crise||||os testes nas mesmas|os testes nas mesmas||dois testes|
|||blástica)||||amostras|amostras|||
||Pacientes|||||||FISH (referência<br>RT-PCR): 0,578<br>(p=0,118)|Alto: Dados|
|**Savasoglu**<br>**et al. 2015**<br>**77**|adultos<br>(>18anos)<br>com<br>LMC|177 amostras|NR|FISH e<br>cariotipage<br>m|RT-PCR<br>quantitati<br>vo|FISH vs. RT-PCR: 22,5%<br>(p=0,064)<br>Cariotipagem vs. RT-PCR:<br>17,6% (p=0,118)|FISH vs. RT-PCR: 96%<br>(p>0,05)<br>Cariotipagem vs. RT-PCR:<br>98% (p>0,05)|Cariotipagem<br>(referência RT-<br>PCR):  0,593<br>(p=0,064)<br>Cariotipagem<br>(referência FISH):<br>0,856 (p<0,001)|registrados em<br>banco de dados<br>(aberto),<br>diagnóstico<br>conhecido|
|**Tashfeen**<br>**et al. 2014**<br>**78**|Pacientes<br>com<br>LMC|40 pacientes|37<br>(16-<br>73)|Citogenétic<br>a<br>convencion<br>al|RT-PCR|Citogenética convencional vs.<br>RT-PCR: 75,7%|Citogenética convencional vs.<br>RT-PCR: 100%|NR|Baixo: Todas as<br>amostras foram<br>analisadas para<br>ambos os testes.<br>Todos os<br>pacientes tinham|  
|**Autor,**<br>**ano**|**Populaçã**<br>**o**|**Tamanho de**<br>**amostra**|**Idade**|**Teste**<br>**avaliado**|**Teste**<br>**referênci**<br>**a**|**Sensibilidade**|**Especificidade**|**Acurácia**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
||||||||||diagnóstico de|
||||||||||LMC, mas o|
||||||||||status de Ph+ era|
||||||||||desconhecido.|  
<mark>LMC: Leucemia mieloide crônica; RT-PCR:</mark> _<mark>reverse transcription polimerase chain reaction</mark>_ <mark>; FISH:</mark> _<mark>Fluorescence in situ hybridization</mark>_ <mark>; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).</mark>  
**REFERÊNCIAS**  
1. Jabbour E, Kantarjian H. Chronic myeloid leukemia: 2016 update on diagnosis, therapy, and monitoring. Am J Hematol. 2016;91(2):252-65.  
2. Instituto Nacional de Câncer José Alencar Gomes da Silva. Estimativa biênio 2016-2017 - Incidência de câncer no Brasil 2016 [Available from: http://www.inca.gov.br/estimativa/2016/.  
3. Hehlmann R, Hochhaus A, Baccarani M, European L. Chronic myeloid leukaemia. Lancet. 2007;370(9584):342-50.  
4. WHO. World Health Organization. WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues WHO Classification of Tumours,  : WHO; 2017 [4th [Available from: <u>http://publications.iarc.fr/Book-And-Report-Series/Who-IarcClassification-Of-Tumours/Who-Classification-Of-Tumours-Of-Haematopoietic-And-Lymphoid-Tissues-2017.</u>  
5. Sokal J, Cox E, Baccarani M, Tura S, Gomez G, Robertson J, et al. Prognostic discrimination in" good-risk" chronic granulocytic leukemia. Blood. 1984;63(4):789-99.  
6. Hasford J, Pfirrmann M, Hehlmann R, Allan N, Baccarani M, Kluin-Nelemans J, et al. A new prognostic score for survival of patients with chronic myeloid leukemia treated with interferon alfa Writing Committee for the Collaborative CML Prognostic Factors Project Group. JNCI: Journal of the National Cancer Institute. 1998;90(11):850-9.  
7. Hasford J, Baccarani M, Hoffmann V, Guilhot J, Saussele S, Rosti G, et al. Predicting complete cytogenetic response and subsequent progression-free survival in 2060 patients with CML on imatinib treatment: the EUTOS score. Blood. 2011;118(3):686-92.  
8. Baccarani (Project 4). Calculation of Relative Risk of CML Patients. <u>https://www.leukemianet.org/content/leukemias/cml/euro__and_sokal_score/index_eng.html: Leukemianet; 2017 [updated 26/10/2015.</u>  
9. Hochhaus A, Saussele S, Rosti G, Mahon FX, Janssen J, Hjorth-Hansen H, et al. Chronic myeloid leukaemia: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2017;28(suppl_4):iv41-iv51.  
10. Cross NC, White HE, Colomer D, Ehrencrona H, Foroni L, Gottardi E, et al. Laboratory recommendations for scoring deep molecular responses following treatment for chronic myeloid leukemia. Leukemia. 2015;29(5):999-1003.  
11. Baccarani M, Druker BJ, Branford S, Kim DW, Pane F, Mongay L, et al. Long-term response to imatinib is not affected by the initial dose in patients with Philadelphia chromosome-positive chronic myeloid leukemia in chronic phase: final update from the Tyrosine Kinase Inhibitor Optimization and Selectivity (TOPS) study. Int J Hematol. 2014;99(5):616-24.  
12. Hehlmann R, Lauseker M, Saussele S, Pfirrmann M, Krause S, Kolb HJ, et al. Assessment of imatinib as first-line treatment of chronic myeloid leukemia: 10-year survival results of the randomized CML study IV and impact of non-CML determinants. Leukemia. 2017;31(11):2398-406.  
13. National Comprehensive Cancer Network Foundation. NCCN Guidelines for Patients: Chronic Myeloid Leukemia. Fort Washington, USA: The National Comprehensive Cancer Network, Inc; 2018.  
14. Soverini S, De Benedittis C, Mancini M, Martinelli G. Best Practices in Chronic Myeloid Leukemia Monitoring and Management. Oncologist. 2016;21(5):626-33.  
15. Baccarani M, Deininger MW, Rosti G, Hochhaus A, Soverini S, Apperley JF, et al. European LeukemiaNet recommendations for the management of chronic myeloid leukemia: 2013. Blood. 2013;122(6):872-84.  
16. Druker BJ, Sawyers CL, Kantarjian H, Resta DJ, Reese SF, Ford JM, et al. Activity of a specific inhibitor of the BCRABL tyrosine kinase in the blast crisis of chronic myeloid leukemia and acute lymphoblastic leukemia with the Philadelphia chromosome. N Engl J Med. 2001;344(14):1038-42.  
17. Palandri F, Castagnetti F, Testoni N, Luatti S, Marzocchi G, Bassi S, et al. Chronic myeloid leukemia in blast crisis treated with imatinib 600 mg: outcome of the patients alive after a 6-year follow-up. Haematologica. 2008;93(12):1792-6.  
18. Talpaz M, Silver RT, Druker BJ, Goldman JM, Gambacorti-Passerini C, Guilhot F, et al. Imatinib induces durable hematologic and cytogenetic responses in patients with accelerated phase chronic myeloid leukemia: results of a phase 2 study. Blood. 2002;99(6):1928-37.  
19. Apperley JF, Cortes JE, Kim DW, Roy L, Roboz GJ, Rosti G, et al. Dasatinib in the treatment of chronic myeloid leukemia in accelerated phase after imatinib failure: the START a trial. J Clin Oncol. 2009;27(21):3472-9.  
20. Kantarjian H, Cortes J, Kim DW, Dorlhiac-Llacer P, Pasquini R, DiPersio J, et al. Phase 3 study of dasatinib 140 mg once daily versus 70 mg twice daily in patients with chronic myeloid leukemia in accelerated phase resistant or intolerant to imatinib: 15-month median follow-up. Blood. 2009;113(25):6322-9.  
21. The American Cancer Society medical and editorial content team. Treating Chronic Myeloid Leukemia by Phase.: The American Cancer Society; 2017 [Available from: <u>https://www.cancer.org/cancer/chronic-myeloid-leukemia/treating/treatingby-phase.html.</u>  
22. Jain P, Kantarjian HM, Ghorab A, Sasaki K, Jabbour EJ, Nogueras Gonzalez G, et al. Prognostic factors and survival outcomes in patients with chronic myeloid leukemia in blast phase in the tyrosine kinase inhibitor era: Cohort study of 477 patients. Cancer. 2017;123(22):4391-402.  
23. Boons C, Harbers L, Timmers L, de Jong J, Swart EL, Harry Hendrikse N, et al. Needs for information and reasons for (non)adherence in chronic myeloid leukaemia: Be aware of social activities disturbing daily routines. European journal of haematology. 2018.  
24. Huguet F, Cayuela JM, Cambier N, Carpentier N, Tindel M, Violet I, et al. Nilotinib efficacy, safety, adherence and impact on quality of life in newly diagnosed patients with chronic myeloid leukaemia in chronic phase: a prospective observational study in daily clinical practice. British journal of haematology. 2019;187(5):615-26.  
25. Sacha T, Gora-Tybor J, Wasak-Szulkowska E, Kyrcz-Krzemien S, Medras E, Becht R, et al. Quality of Life and Adherence to Therapy in Patients With Chronic Myeloid Leukemia Treated With Nilotinib as a Second-Line Therapy: A Multicenter Prospective Observational Study. Clin Lymphoma Myeloma Leuk. 2017;17(5):283-95.  
26. Santoleri F, Sorice P, Lasala R, Rizzo RC, Costantini A. Patient adherence and persistence with Imatinib, Nilotinib, Dasatinib in clinical practice. PloS one. 2013;8(2):e56813.  
27. Trivedi D, Landsman-Blumberg P, Darkow T, Smith D, McMorrow D, Mullins CD. Adherence and persistence among chronic myeloid leukemia patients during second-line tyrosine kinase inhibitor treatment. Journal of managed care & specialty pharmacy. 2014;20(10):1006-15.  
28. Yood MU, Oliveria SA, Cziraky M, Hirji I, Hamdan M, Davis C. Adherence to treatment with second-line therapies, dasatinib and nilotinib, in patients with chronic myeloid leukemia. Current medical research and opinion. 2012;28(2):213-9.  
29. Negrin RS, Schiffer CA, Larson RA, Rosmarin AG. Treatment of chronic myeloid leukemia in accelerated phase. Waltham, MA: UpToDate Inc.; 2017 [Available from: <u>https://www.uptodate.com/contents/treatment-of-chronic-myeloidleukemia-in-accelerated-phase.</u>  
30. Negrin RS, Schiffer CA, Larson RA, Rosmarin AG. Treatment of chronic myeloid leukemia in blast crisis Waltham, MA: UpToDate Inc. ; 2016 [Available from: <u>https://www.uptodate.com/contents/treatment-of-chronic-myeloid-leukemia-inblast-crisis.</u>  
31. Mesilato de Imatinibe [package insert]. São Paulo, BR: EUROFARMA LABORATÓRIOS S.A.; 2015.  
32. Sprycel (Dasatinibe) [package insert]. São Paulo, BR: AstraZeneca Pharmaceuticals LP 2016.  
33. Tasigna (Nilotinibe) [package insert]. São Paulo, BR: Novartis Pharma Stein AG; 2015.  
34. Hydrea (Hidroxiureia) [package insert]. São Paulo, BR: Corden Pharma Latina S.p.A; 2015.  
35. Roferon-A (alfainterferona 2a) [package insert]. Rio de Janeiro, BR: La Roche Ltd; 2015.  
36. O'Brien S, Berman E, Borghaei H, Deangelo DJ, Devetten MP, Devine S, et al. NCCN clinical practice guidelines in oncology: chronic myelogenous leukemia. J Natl Compr Canc Netw. 2009;7(9):984-1023.  
37. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília2009.  
38. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008.  
39. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011.  
40. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
41. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36.  
42. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
43. Firwana B, Sonbol MB, Diab M, Raza S, Hasan R, Yousef I, et al. Tyrosine kinase inhibitors as a first-line treatment in patients with newly diagnosed chronic myeloid leukemia in chronic phase: A mixed-treatment comparison. International journal of cancer. 2016;138(6):1545-53.  
44. Hu B, Kantarjian HM, Ravandi F, Borthakur G, Kadia TM, Ferrajoli A, et al. Survival outcomes of sustained MR4.5 in patients with chronic myeloid leukemia (CML) treated with various tyrosine kinase inhibitors (TKI). Journal of Clinical Oncology. 2016;34 Supplement 15.  
45. Cortes JE, Saglio G, Kantarjian HM, Baccarani M, Mayer J, Boqué C, et al. Final 5-year study results of DASISION: The dasatinib versus imatinib study in treatment-Naïve chronic myeloid leukemia patients trial. Journal of Clinical Oncology. 2016;34(20):2333-40.  
46. Jabbour E, Kantarjian HM, Saglio G, Steegmann JL, Shah NP, Boque C, et al. Early response with dasatinib or imatinib in chronic myeloid leukemia: 3-year follow-up from a randomized phase 3 trial (DASISION). Blood. 2014;123(4):494-500.  
47. Kantarjian H, Shah NP, Hochhaus A, Cortes J, Shah S, Ayala M, et al. Dasatinib versus imatinib in newly diagnosed chronic-phase chronic myeloid leukemia. The New England journal of medicine. 2010;362(24):2260-70. 48. Kantarjian HM, Shah NP, Cortes JE, Baccarani M, Agarwal MB, Undurraga MS, et al. Dasatinib or imatinib in newly diagnosed chronic-phase chronic myeloid leukemia: 2-year follow-up from a randomized phase 3 trial (DASISION). Blood. 2012;119(5):1123-9.  
49. Cortes JE JD, O'Brien S, Jabbour E, Ravandi F, Koller C, Borthakur G, Walker B, Zhao W, Shan J, Kantarjian H. Results of Dasatinib Therapy in Patients With Early Chronic-Phase Chronic Myeloid Leukemia. Journal of Clinical Oncology. 2010;28(3):398-404.  
50. Hjorth-Hansen H, Stenke L, Soderlund S, Dreimane A, Ehrencrona H, Gedde-Dahl T, et al. Dasatinib induces fast and deep responses in newly diagnosed chronic myeloid leukaemia patients in chronic phase: clinical results from a randomised phase-2 study (NordCML006). European journal of haematology. 2015;94(3):243-50.  
51. Radich JP, Kopecky KJ, Appelbaum FR, Kamel-Reid S, Stock W, Malnassy G, et al. A randomized trial of dasatinib 100 mg versus imatinib 400 mg in newly diagnosed chronic-phase chronic myeloid leukemia. Blood. 2012;120(19):3898-905.  
52. Zhou L, Wang JX, Huang XJ, Hu JD, Shen ZX. [Preliminary comparison of efficacy and safety of dasatinib and imatinib in newly diagnosed chronic myeloid leukemia]. Zhonghua xue ye xue za zhi = Zhonghua xueyexue zazhi. 2013;34(2):93-7.  
53. Kantarjian HM, Hochhaus A, Saglio G, Souza CD, Flinn IW, Stenke L, et al. Nilotinib versus imatinib for the treatment of patients with newly diagnosed chronic phase, Philadelphia chromosome-positive, chronic myeloid leukaemia: 24-month minimum follow-up of the phase 3 randomised ENESTnd trial. The Lancet Oncology. 2011;12(9):841-51.  
54. Larson RA, Hochhaus A, Hughes TP, Clark RE, Etienne G, Kim DW, et al. Nilotinib vs imatinib in patients with newly diagnosed Philadelphia chromosome-positive chronic myeloid leukemia in chronic phase: ENESTnd 3-year follow-up. Leukemia. 2012;26(10):2197-203.  
55. Saglio G, Kim DW, Issaragrisil S, le Coutre P, Etienne G, Lobo C, et al. Nilotinib versus imatinib for newly diagnosed chronic myeloid leukemia. N Engl J Med. 2010;362(24):2251-9.  
56. Cortes JE JD, O'Brien S, Jabbour E, Konopleva M, Ferrajoli A, Kadia T, Borthakur G, Stigliano D, Shan J, Kantarjian H. Nilotinib As Front-Line Treatment for Patients With Chronic Myeloid Leukemia in Early Chronic Phase. Journal of Clinical Oncology. 2010b;28(3):393-7.  
57. Jabbour E CJ, Nazha A, O'Brien S, Quintas-Cardama A, Pierce S, Garcia-Manero G, Kantarjian H. EUTOS score is not predictive for survival and outcome in patients with early chronic phase chronic myeloid leukemia treated with tyrosine kinase inhibitors: a single institution experience. Blood. 2012;119(19):4524-26.  
58. Jabbour E, Cortes J, Nazha A, O'Brien S, Quintas-Cardama A, Pierce S, et al. EUTOS score is not predictive for survival and outcome in patients with early chronic phase chronic myeloid leukemia treated with tyrosine kinase inhibitors: a single institution experience. Blood. 2012;119:4524-6.  
59. Jain P, Kantarjian H, Nazha A, O'Brien S, Jabbour E, Romo CG, et al. Early responses predict better outcomes in patients with newly diagnosed chronic myeloid leukemia: results with four tyrosine kinase inhibitor modalities. Blood. 2013;121:4867-74.  
60. Stegelmann F, Shah NP, Saglio G, Hochhaus A, Bilmes R, Li L, et al. The predictive value of early molecular response by relative risk in patients (pts) with chronic myeloid leukemia in chronic phase (CML-CP) treated with dasatinib (DAS) or imatinib (IM) from the phase 3 DASISION trial. Oncology Research and Treatment. 2016;39 Supplement 3:40.  
61. Kantarjian HM, Shah NP, Cortes JE, Baccarani M, Agarwal MB, Undurraga MS, et al. Dasatinib or imatinib in newly diagnosed chronic-phase chronic myeloid leukemia: 2-year follow-up from a randomized phase 3 trial (DASISION). Blood. 2011;119:1123-9.  
62. Cortes JE, Saglio G, Kantarjian HM, Baccarani M, Mayer J, Boque C, et al. Final 5-Year Study Results of DASISION: The Dasatinib Versus Imatinib Study in Treatment-Naive Chronic Myeloid Leukemia Patients Trial. J Clin Oncol. 2016;34:233340.  
63. Saglio G, Kim DW, Issaragrisil S, le Coutre P, Etienne G, Lobo C, et al. Nilotinib versus imatinib for newly diagnosed chronic myeloid leukemia. The New England journal of medicine. 2010;362:2251-9.  
64. Larson RA, Hochhaus A, Hughes TP, Clark RE, Etienne G, Kim DW, et al. Nilotinib vs imatinib in patients with newly diagnosed Philadelphia chromosome-positive chronic myeloid leukemia in chronic phase: ENESTnd 3-year follow-up. Leukemia. 2012;26:2197-203.  
65. Kantarjian HM, Hochhaus A, Saglio G, De Souza C, Flinn IW, Stenke L, et al. Nilotinib versus imatinib for the treatment of patients with newly diagnosed chronic phase, Philadelphia chromosome-positive, chronic myeloid leukaemia: 24-month minimum follow-up of the phase 3 randomised ENESTnd trial. The Lancet Oncology. 2011b;12:841-51.  
66. Shah NP, Saglio G, Hochhaus A, Bilmes R, Li L, Cortes JE, et al. Early molecular response in patients (pts) with chronic myeloid leukemia in chronic phase (CML-CP) treated with dasatinib (DAS) or imatinib (IM) from DASISION. Journal of Clinical Oncology. 2016;34 Supplement 15.  
67. Whiteley J, Iyer S, Candrilli SD, Kaye JA. Treatment patterns and prognostic indicators of response to therapy among patients with chronic myeloid leukemia in Australia, Canada, and South Korea. Current medical research and opinion. 2015;31:299-314.  
68. Jiang Q, Xu LP, Liu DH, Liu KY, Chen SS, Jiang B, et al. Imatinib mesylate versus allogeneic hematopoietic stem cell transplantation for patients with chronic myelogenous leukemia in the accelerated phase. Blood. 2011;117(11):3032-40.  
69. Palandri F, Castagnetti F, Alimena G, Testoni N, Breccia M, Luatti S, et al. The long-term durability of cytogenetic responses in patients with accelerated phase chronic myeloid leukemia treated with imatinib 600 mg: The GIMEMA CML Working Party experience after a 7-year follow-up. Haematologica. 2009;94(2):205-12.  
70. Lahaye T, Riehm B, Berger U, Paschka P, Müller MC, Kreil S, et al. Response and resistance in 300 patients with BCRABL-positive leukemias treated with imatinib in a single center: A 4.5-year follow-up. Cancer. 2005;103(8):1659-69.  
71. Olavarria E, Ottmann OG, Deininger M, Clark RE, Bandini G, Byrne G, et al. Response to imatinib in patients who relapse after allogeneic stem cell transplantation for chronic myeloid leukemia. Leukemia. 2003;17(9):1707-12.  
72. Talpaz M, Silver RT, Druker BJ, Goldman JM, Gambacorti-Passerini C, Guilhot F, et al. Imatinib induces durable hematologic and cytogenetic responses in patients with accelerated phase chronic myeloid leukemia: Results of a phase 2 study. Blood. 2002;99(6):1928-37.  
73. Apperley JF, Cortes JE, Kim DW, Roy L, Roboz GJ, Rosti G, et al. Dasatinib in the treatment of chronic myeloid leukemia in accelerated phase after imatinib failure: The START a trial. Journal of Clinical Oncology. 2009;27(21):3472-9.  
74. Guilhot F, Apperley J, Kim DW, Bullorsky EO, Baccarani M, Roboz GJ, et al. Dasatinib induces significant hematologic and cytogenetic responses in patients with imatinib-resistant or -intolerant chronic myeloid leukemia in accelerated phase. Blood. 2007;109(10):4143-50.  
75. Talpaz M, Shah NP, Kantarjian H, Donato N, Nicoll J, Paquette R, et al. Dasatinib in imatinib-resistant Philadelphia chromosome-positive leukemias. N Engl J Med. 2006;354(24):2531-41.  
76. Raanani P BBI, Gan S, Trakhtenbrot L, Mark Z, Ashur‐Fabian O, Itskovich S, Brok‐Simoni F, Rechavi G, Amariglio N, Nagler A. Assessment of the response to imatinib in chronic myeloid leukemia patients–comparison between the FISH, multiplex and RT‐PCR methods. European journal of haematology. 2004;73(4):243-50.  
77. Savasoglu K PK, Ozdemirkiran F, Berber B. Effectiveness of Quantitative Real Time PCR in Long-Term Follow-up of Chronic Myeloid Leukemia Patients. Journal of the College of Physicians and Surgeons Pakistan. 2015;25(8):568-72.  
78. Tashfeen S AS, Bhatti FA, Ali N. Real time polymerase chain reaction in diagnosis of chronic myeloid leukemia. J Coll Physicians Surg Pak. 2014;24(3):190-3.

---

