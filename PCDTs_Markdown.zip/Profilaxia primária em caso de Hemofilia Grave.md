<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 6, DE 05 DE ABRIL DE 2022.  
Aprova o Protocolo de Uso de fatores de coagulação para a profilaxia primária em caso de hemofilia grave.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas  atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a hemofilia no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 683/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 687 – Dezembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo de Uso de fatores de coagulação para a profilaxia primária em caso de hemofilia grave. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da hemofilia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hemofilia.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS  n<sup>o</sup> 364, de 6 de maio de 2014, publicada no Diário Oficial da União nº 85, de 7 de maio de 2014, seção 1, páginas 46-51.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO  
SANDRA DE CASTRO BARROS  
ANEXO

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: PROTOCOLO DE USO -->
FATORES DE COAGULAÇÃO PARA A PROFILAXIA PRIMÁRIA EM CASO DE HEMOFILIA GRAVE

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **1. INTRODUÇÃO** -->
A hemofilia é uma doença hemorrágica, de herança genética ligada ao cromossomo X. Ela se caracteriza pela deficiência do fator da coagulação VIII (hemofilia A) ou do fator da coagulação IX (hemofilia B). As hemofilias A e B ocorrem em cerca de 1:10.000 e 1:40.000 nascimentos de crianças do sexo masculino, respectivamente, não apresentando variação racial ou étnica<sup>1</sup> . Do ponto de vista clínico, as hemofilias A e B são semelhantes. O diagnóstico diferencial entre elas é feito por exames laboratoriais de dosagens específicas da atividade de fator VIII e de fator IX<sup>2</sup> .  
A hemofilia é classificada de acordo com o nível plasmático de atividade coagulante do fator deficiente, podendo ser leve [quando os níveis de atividade do fator são de  5% a 40% (equivalente a  > 0,05 a 0,40 UI/ml)], moderada [nível de atividade de fator  de 1% a 5% (ou 0,01 a 0,05 UI/ml)] ou grave [nível de atividade de fator inferior a 1% (ou < 0,01 UI/ml)]<sup>3</sup> . A manifestação clínica mais frequente nos pacientes com hemofilia grave são as hemorragias músculo-esqueléticas, principalmente as hemartroses. Hemartroses de repetição em uma mesma articulação (“articulação-alvo”) podem levar à degeneração articular progressiva, denominada artropatia hemofílica. A prevenção ou o tratamento das hemartroses e outros episódios hemorrágicos observados nos casos de hemofilia envolvem a infusão intravenosa do fator de coagulação deficiente, que pode ser feita em ambiente hospitalar, ambulatorial ou domiciliar<sup>4</sup> .  
Atualmente, existem duas modalidades de tratamento com concentrado de fatores de coagulação: tratamento sob demanda e o tratamento profilático.  
O tratamento sob demanda, ou episódico, refere-se à infusão do concentrado do fator de coagulação após o episódio hemorrágico. Neste caso, a reposição deve ser repetida diariamente até que os sinais e sintomas cessem.  
O tratamento profilático se subdivide em três modalidades, a saber<sup>4</sup> :  
1. profilaxia primária: profilaxia contínua e regular iniciada na ausência de doença articular documentada, determinada  
pelo exame físico ou exames de imagem e antes do segundo sangramento articular clinicamente evidente e dos 3 anos de idade.  
2. profilaxia secundária: profilaxia contínua e regular iniciada após dois ou mais sangramentos articulares, mas antes do  
início da doença articular, em caso de pacientes com 3 ou mais anos de idade; e  
3. profilaxia terciária: profilaxia contínua e regular iniciada após o início da doença articular documentada, constituindo-  
se normalmente na profilaxia iniciada na idade adulta.  
A profilaxia primária vem sendo utilizada em países desenvolvidos desde a década de 1960. Inexiste consenso na literatura com relação a alguns aspectos do tratamento e, por isso, diferentes esquemas são utilizados<sup>5-8</sup> . Os principais pontos de divergência são o número de doses e de unidades de concentrado de fator VIII ou IX utilizados e os intervalos entre as doses; a idade de início da profilaxia primária; a idade de suspensão dessa profilaxia; e o acesso venoso<sup>7</sup> .  
Idealmente, recomenda-se que a profilaxia primária seja iniciada no caso dos pacientes com hemofilia grave precocemente durante a infância, na ausência de doença articular, antes da segunda hemartrose e antes dos 3 anos de idade<sup>9</sup> . O início da profilaxia após a segunda hematrose é justificado pela baixa frequência dessa manifestação (10%-15%) em alguns pacientes com hemofilia grave<sup>10</sup> . Assim, em uma parte dos pacientes, a profilaxia pode ser iniciada mais tarde. A profilaxia secundária, iniciada após dois ou mais episódios de hemartrose, porém antes do início da doença articular, também é eficiente na redução das hemorragias e hospitalização e na melhora da qualidade de vida<sup>3, 4, 11, 12</sup> .  
Esquema com doses tão baixas quanto 10 UI por quilograma de peso duas vezes por semana foi eficiente na redução de  
hemartroses quando comparado ao tratamento sob demanda<sup>13, 14</sup> . Entretanto, para a prevenção da artropatia hemofílica e de sangramentos graves e para propiciar uma boa qualidade de vida a crianças e adultos, doses maiores (entre 20 UI a 40 UI por quilograma de peso) e infusões mais frequentes são necessárias<sup>7,15,16</sup> .  
A intensidade da profilaxia é classificada em três tipos ( **Tabela 1** ).  
**Tabela 1 -** Profilaxia em casos de hemofilias A e B conforme a intensidade de reposição  
|**Intensidade**|**Hemofilia A**|**Hemofilia B**|
|---|---|---|
|Altas doses|25-40 UI FVIII/kg a cada 2 dias|40-60 UI FIX/kg 2 vezes por semana|
||(>4.000 UI/kg por ano)|(>4.000 UI/kg por ano)|
|Doses intermediárias|15-25 UI FVIII/kg 3 dias por semana|20-40 IU FIX/kg 2 vezes por semana|
||(1.500-4.000 UI/kg por ano)|(2.000-4.000 UI/kg por ano)|
|Baixas doses (com escalonamento de dose|10-15 UI FVIII/kg 2-3 dias por semana|10-15 IU FIX/kg 2 dias por semana|
|se necessário)|(1.000-1.500 UI/kg por ano)|(1.000-1.500 UI/kg por ano)|  
FIX: fator IX; FVIII: fator VIII; UI: unidades internationais; kg: quilograma.  
Extraído de Srivastava A, Brewer AK, Mauser-Bunschoten EP, Key NS, Kitchen S, Llinas A, Ludlam CA, Mahlangu JN, Mulder K, Poon MC<sup>4</sup> .  
O uso de fatores de coagulação para a profilaxia primária em caso de hemofilia grave tem como objetivo o tratamento profilático primário de crianças com idade até 3 anos (36 meses incompletos) acometidas por hemofilia A ou B grave, com doses escalonadas do fator de coagulação deficiente, para prevenir o desenvolvimento da artropatia hemofílica, reduzir outros sangramentos e melhorar a qualidade de vida dos pacientes. A literatura mostra que benefícios semelhantes podem ser obtidos pela profilaxia secundária.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **2. CRITÉRIOS DE INCLUSÃO** -->
São incluídos neste Protocolo os pacientes com:  
- Diagnóstico confirmado de hemofilia A ou B grave ou com  nível de atividade de fator VIII ou IX inferior a 2%; e  
- idade menor de 3 anos e ter apresentado hemartrose em qualquer articulação ou  sangramento grave; e  
- pesquisa de inibidor negativa ou quantificação de inibidor inferior a 0,6 UB/mL ml (unidades Bethesda por mL) em  
- teste realizado imediatamente antes da inclusão;  
**Nota:** Os pacientes com hemofilia A ou B grave (isto é, com nível de atividade de fator VIII ou IX inferior a 2%) que não preencherem critérios de inclusão na profilaxia primária (isto é, que tenham 3 ou mais anos de idade ou que já tenham apresentado duas ou mais hemartroses) deverão ser incluídos na profilaxia secundária, defininida no Manual de Hemofilia do Ministério da Saúde.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **3. CRITÉRIOS DE EXCLUSÃO** -->
São excluídos neste Protocolo os pacientes com:  
- pico histórico de inibidor superior a 5 UB/ml (unidades Bethesda por mL, mensurado em ensaio específico) confirmado  
- em pelo menos duas ocasiões com intervalo de 2 a 4 semanas entre as quantificações; e  
- idade igual ou superior a 3 anos.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **4. CASOS ESPECIAIS** -->
Algumas situações demandarão da equipe de tratamento uma avaliação individualizada quanto à indicação da profilaxia:  
1. Casos com fenótipo hemorrágico, em que não haverá prejuízo para a criança, caso a profilaxia seja iniciada após os 36 meses de idade. Excepcionalmente, pacientes com nível de atividade de fator inferior a 2% podem apresentar fenótipo hemorrágico mais leve que o usual. A identificação destes casos não é trivial, mas acredita-se que esta variabilidade possa decorrer na coexistência de traços genéticos que desloquem o balanço hemostático para um pólo protrombótico, e de alguma forma compensem parcialmente a deficiência de fator. Por ser uma excepcionalidade, a profilaxia não deve ser omitida na expectativa de que pacientes que já tenham apresentado hemartroses evoluam desta forma. No entanto, caso a avaliação criteriosa da clínica do paciente indique um fenótipo menos grave, e haja limitações para o início da profilaxia como por exemplo a questão do acesso venoso, pode ser razoável o adiamento de seu início sem prejuízo para o paciente. Esta situação deve ser continuamente reavaliada, em particular caso ocorra algum sangramento.  
2. Casos com tendência hemorrágica mais frequente (mesmo não articular)  
Embora os critérios de inclusão na profilaxia primária sejam baseados na ocorrência de sangramentos articulares, ou graves, a ocorrência de sangramentos repetidos em outros sítios, em particular musculares, também pode sinalizar um fenótipo hemorrágico mais grave e consequentemente servir de base para justificativa da inclusão em programas de profilaxia.  
3. Maior risco de trauma, que justifique iniciar antes mesmo da primeira hemartrose.  
4. Pacientes com título de inibidor histórico máximo inferior a 5 UB/mL poderão ser incluídos, desde que a quantificação de inibidor seja negativa (inferior a 0,6 UB/mL imediatamente antes da inclusão e não haja resposta anamnéstica, ou reação alérgica ao fator VIII ou IX. A detecção de inibidores transitórios de baixo título (até 5 UB/mL) pode ocorrer, e não deve excluir o paciente da profilaxia, desde que os títulos imediatamente anteriores ao início da profilaxia sejam inferiores a 0,6 UB/mL, e não haja evidência de resposta anamnéstica ou de reação alérgica ao fator.  
5. Pacientes que apresentam título de inibidor entre 0,6 UB/mL e 5 UB/mL, que apresentam resposta hemostática ao concentrado de fator VIII ou IX (sem histórico de reação alérgica) e que não necessitam de produtos _bypassing._ Este grupo de pacientes, com inbidores de baixo título (até 5 UB/mL), mas com resposta hemostática satisfatória a concentrados de FVIII ou IX (neste caso, sem reação alérgica), e que não necessitam de agentes de _bypassing_ para tratamento de sangramentos podem se beneficiar da profilaxia com os concentrados de fator VIII ou IX, já que os mesmos são capazes de induzir hemostasia eficaz. Preconiza-se, nesse caso, iniciar com a dose mínima regular de 25 UI/kg duas vezes por semana, com ajuste da dose  para que esta seja capaz de prevenir de forma eficaz os episódios hemorrágicos. Essa avaliação deve ser feita de maneira individualizada, considerando os parâmetros clínicos, associado à avaliação laboratorial da quantificação do fator (incluindo recuperação e nível de vale do fator), sobretudo quando persistirem os sangramentos, além da monitorização frequente e periódica dos títulos do inibidor. Caso o paciente evolua com títulos superiores a 5 UB/mL ou passe a não responder adequadamente ao concentrado do fator deficiente, necessitando de produtos _bypassing_ , o paciente deve ser considerado para imunotolerância<sup>17</sup> .

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5. TRATAMENTO** -->
Os pacientes incluídos deverão ser registrados e acompanhados regularmente em um Centro de Tratamento de Hemofilia (CTH) e ter assinado o seu Termo de Esclarecimento e Responsabilidade ( **Apêndice 1** ).  
Todos deverão ser submetidos à avaliação médica, de enfermagem ( **apêndices 2 e 2A** ), psicossocial ( **apêndices 3 e 3A e 4 e 4A** )  e musculoesquelética ( **Apêndice 5** ), devendo, para sua inclusão, obter aprovação, no mínimo, dos profissionais médico e de enfermagem. Na ausência da equipe completa, os profissionais médicos e de enfermagem ficarão responsáveis pelas avaliações dos demais profissionais.  
Preconiza-se a avaliação musculoesquelética antes da inclusão e, pelo menos, a cada 12 meses durante todo o tratamento. Esta avaliação deverá ser realizada idealmente por fisioterapeuta ou fisiatra, mas, na sua indisponibilidade, o pode ser por profissional médico qualificado.  
As avaliações médica, de enfermagem, psicossocial e musculoesquelética realizadas pela equipe multiprofissional do CTH devem ser aprovadas pelo médico responsável pelo tratamento em cada CTH ( **Apêndice 6** ).  
Os pacientes que atendem os critérios de inclusão deverão iniciar o tratamento imediatamente ou logo após a ocorrência da primeira hemartrose ou sangramento grave, sejam estes espontâneos ou pós-traumáticos. [Entende-se como sangramento grave aquele que ocorre em sítios nobres e com critérios de gravidade (como, por exemplo, sangramento no sistema nervoso central e outros sangramentos internos, incluindo grandes hematomas e síndrome de compartimento muscular)].  
Os CTH se responsabilizarão pela inclusão e adesão dos pacientes ao Protocolo e pela inclusão dos dados do paciente no Sistema Hemovida _Web_ Coagulopatias. O formulário IVb deverá ser preenchido, datado e assinado por todos os membros da equipe multiprofissional e enviado para a Coordenação-Geral de Sangue e Hemoderivados – CGSH/DAET/SAES, do Ministério da Saúde no momento da inclusão do paciente. Além disso, para a rastreabilidade das informações sobre a infusão e intercorrências, o paciente ou seu responsável legal deverá registrar todas as infusões em planilha própria (ver o **Apêndice 7** – Planilha de infusão domiciliar ou em documento similar (desde que contenha todas as informações deste Apêndice 7).  
O cronograma de tratamento ( **Apêndice 8** ) e a agenda de seguimento ( **Apêndice 9** ) devem ser observados.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.1 Fármacos** -->
- Concentrado de Fator VIII da coagulação (para caso de hemofilia A).  
- Concentrado de Fator IX da coagulação (para caso de hemofilia B).

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.2. Doses e administração da profilaxia primária** -->
O tratamento deve ser iniciado com uma a duas doses semanais de 250 UI (ou seja, aproximadamente 25 UI/kg para um paciente de 10 kg) de concentrado de fator VIII, ou com uma a duas doses semanais de 250 a 500 UI (ou seja, aproximadamente 25 a 40 UI/kg) de concentrado de fator IX. Para orientação da dose inicial, podem ser usadas as doses de 25 UI/kg para a hemofilia A grave e de 40 UI/kg para a hemofilia B grave. Esta dose deve ser adequada para a apresentação mais próxima (por exemplo, se a dose calculada for de 290 UI, arrendonda-se para 1 frasco de 250 UI; se for de 450 UI, arredonda-se para 1 frasco de 500 UI).  
Se, devido à dificuldade de acesso venoso, a opção for por uma dose semanal, deve-se tentar, tão logo seja possível, o esquema mínimo de duas doses semanais, mesmo na ausência de sangramento. As crianças que já estão em uso da dose mínima de 25 UI/kg duas vezes por semana e, mesmo assim, apresentem hemartrose ou outro sangramento clinicamente significativo, devem ter sua dose escalonada para 25 UI/kg três vezes por semana. A partir do esquema de 25 UI/kg três vezes por semana, quando ocorrerem sangramentos os casos devem ser avaliados individualmente, considerando, inicialmente, o aumento da frequência das doses (para dias alternados), e o aumento progressivo da dose (em torno de 5 UI/kg/dose, sendo a dose máxima 50 UI/kg), até que o esquema esteja adequado para prevenir os episódios hemorrágicos. Neste caso, deve-se também proceder à pesquisa de inibidor.  
A pesquisa de inibidor deve ser periódica: quantificação de inibidor a cada 5 a 10 dias de exposição [DE] ao fator deficiente até completar 50 DE, assim quando se observar sangramento grave ou situação clínica que sugira a ineficácia do tratamento de reposição com o fator deficiente.  
Se houver histórico de qualquer sangramento grave antes do início da profilaxia (por exemplo, sangramento de sistema nervoso central, hematoma extenso, síndrome de compartimento muscular ou sangramento interno), o paciente não deverá iniciar seu tratamento com dose escalonada, mas já iniciar com três doses na semana (se caso de hemofilia A) ou duas doses na semana (se caso de hemofilia B).  
Deve-se evitar a administração de doses mais altas de concentrado de fator VIII, pelo menos nos primeiros 20 dias de exposição, devido ao aumento no risco de desenvolvimento de inibidores<sup>18, 19</sup> . Além disso, iniciar-se com esquema de profilaxia  
três vezes por semana demanda uso de cateter venoso na maioria dos pacientes. Assim, deve-se almejar a menor dose e na menor periodicidade necessárias para coibir quaisquer eventos hemorrágicos. Para tal, o paciente deve ser acompanhado periodicamente, e a profilaxia deve ser individualizada.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.2.1. Eventos adversos e riscos da profilaxia primária** -->
Os eventos adversos e riscos da profilaxia primária (PP) são os mesmos inerentes ao tratamento episódico (infusão do fator de coagulação deficiente após um sangramento): possibilidade de desenvolvimento de inibidor, possibilidade de contaminação com agentes infecciosos transmissíveis pelos concentrados de fator de coagulação de origem plasmática (embora não haja relato de contaminação há mais de 20 anos), reação alérgica ao produto infundido e formação de hematomas e equimoses em local de punção venosa para infusão do concentrado de fator. Ainda, devido às infusões frequentes, o paciente pode necessitar da instalação de cateter venoso central, caso o acesso de veias periféricas fique dificultado.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.2.2.  Precauções e cuidados** -->
Os pais e responsáveis devem seguir as orientações médicas do CTH e observar o acompanhamento tal como recomendado. Deve-se atentar para o horário adequado de se infundir o fator (preferencialmente pela manhã). Se o paciente praticar algum esporte, a família deverá informar o médico para que orientação individualizada seja fornecida. Mediante a ocorrência de sangramentos mais frequentes ou refratários à infusão do fator deficiente ou de qualquer reação alérgica após o uso do fator, deve-se entrar em comtato com o CTH.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.2.3. Duração do tratamento** -->
O paciente deverá ser estimulado a manter a profilaxia até pelo menos alcançar a maturidade física, o que ocorre, na maior parte dos casos, aos 18 anos de idade.  
Alguns estudos indicam que, após atingir a maturidade, o paciente com hemofilia apresenta redução dos sangramentos, alguns podendo, inclusive, retornar ao tratamento sob demanda<sup>20, 21</sup> . A decisão sobre a manutenção da profilaxia ou o retorno ao esquema de tratamento sob demanda deverá ser compartilhada entre a equipe multiprofissional e o paciente ou seu responsável legal, levando-se em conta a preferência deste(s), o fenótipo hemorrágico do paciente e a adesão ao tratamento. Se, no caso dos pacientes que optaram pela interrupção da profilaxia, houver recorrência de hemartroses ou outros sangramentos, que, em especial, interfiram no seu trabalho ou educação, a profilaxia deve ser reinstituída para evitar danos articulares e para manter a qualidade de vida.<sup>20, 21.</sup>

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.3. Tratamento dos episódios hemorrágicos e profilaxia para procedimentos invasivos** -->
O tratamento dos episódios hemorrágicos ou em caso de procedimentos cirúrgicos invasivos, mesmo que minimamente invasivos, devem seguir as recomendações do Manual de Hemofilias do Ministério da Saúde<sup>22</sup> .  
Em caso de hemartrose, é essencial que seja feito o tratamento precoce. Os pacientes com hemofilia A devem ser tratados com infusão de concentrado de fator VIII na dose de 15-25 UI/kg e aqueles com hemofilia B, com a infusão de concentrado de fator IX na dose de 30-50 UI/kg. Normalmente, o tratamento será de um a três dias, de acordo com a evolução clínica do paciente. Lembrando que, caso a dose profilática coincida com a dose de um dia de tratamento, recomenda-se manter a dose de tratamento, retornando-se ao esquema profilático tão logo se tenha considerado que o tratamento foi completado.  
Ressalta-se que a recorrência de sangramentos durante a profilaxia, sobretudo de episódios espontâneos ou tramáticos graves, requer reavaliação do esquema profilático e dosagem do nível de vale do fator, sendo o objetivo esperado do tratamento que o mesmo seja  superior a 1%. Caso o nível de vale seja inferior a 1%, a dose ou a frequência deve ser majorada. Além disso, caso persistam as hemorragias durante a profilaxia, apesar do escalonamento para o esquema de três vezes por semana, troca de  
produto ou manutenção de nível de fator superior a 1% na ausência de inibidor, os estudos de meia-vida (farmacocinética) podem ser úteis para ajudar a determinar a profilaxia mais apropriada, ajustar a dose e melhorar a relação custo-benefício<sup>23</sup> . Entretanto, a determinação da farmacocinética não substitui e nem é superior à avaliação clínica,  sendo complementar à mesma. Além disso, a farmacocinética pode ser difícil de se proceder em caso de crianças pequenas, devido às dificuldades de acesso venoso.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.4. Acesso venoso e uso de cateter** -->
Caso haja dificuldade de acesso venoso, em qualquer momento do tratamento deverá ser avaliada a necessidade de implantação de cateter venoso central. Deve-se dar preferência para cateter com extremidade de abertura lateral, tipo fenda, que proporciona segurança contra o refluxo de sangue e embolia gasosa no sistema _port_ , por pressão positiva ou negativa, e que possa ser mantido com solução salina, não sendo necessário o uso de heparina. Os CTH serão responsáveis por providenciar junto à rede de serviços do seu município, estado ou no Distrito Federal a implantação de cateter que deverá ser realizada por equipe experiente e capacitada, sendo necessário o preparo prévio da criança e família pela equipe multiprofissional.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5.4.1. Esquema de reposição de concentrado de fator VIII para a implantação do cateter** -->
- Pré-procedimento: 50 UI/Kg imediatamente antes do procedimento.  
- Iniciar, 12 h após o procedimento, concentrado de fator VIII na dose de 20 UI/Kg a cada 12 h até o final do terceiro  
- dia.  
- Após, manter 25 UI/Kg ao dia até completar 7 dias do procedimento.  
- **5.4.2. Esquema de reposição de concentrado de fator IX para a implantação do cateter**  
- Pré-procedimento: 100 UI/Kg imediatamente antes do procedimento.  
- Iniciar, 12 h após o procedimento, concentrado de fator IX na dose de 40 UI/Kg a cada 12 h até o final  do terceiro  
- dia.  
- Após, manter 50 UI/Kg ao dia até completar 7 dias do procedimento.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **6. AVALIAÇÃO E ACOMPANHAMENTO DO PACIENTE SOB PROFILAXIA PRIMÁRIA** -->
A avaliação deve ser procedida conforme a seguir:  
- Pré-avaliação pelos profissionais médicos, de enfermagem, serviço social, psicologia e fisioterapeuta (com avaliação musculoesquelética). Nos CTH que não tiverem, no seu quadro de pessoal, todos esses profissionais, o acompanhamento e respectivas avaliações devem ser realizados por profissional médico e de enfermagem.  
- Avaliação multiprofissional periódica individualizada de acordo com a evolução do paciente, com revisão cuidadosa dos eventos hemorrágicos e reavaliação musculoesquelética, no mínimo anual.  
Durante o tratamento, o paciente deverá ser acompanhado pela equipe multiprofissional minimamente constituída por profissional médico e de enfermagem e deverá se submeter aos exames descritos a seguir. Além disso, o paciente ou seu responsável deverá preencher a planilha de infusão domiciliar ( **Apêndice 7** ) ou similar que contenha todas as informações constantes neste Apêndice 7, mediante toda e qualquer infusão, seja por motivo da profilaxia primária ou para tratamento de evento hemorrágico. Esta planilha deverá ser trazida ao CTH periodicamente (sugere-se no máximo bimensalmente), para transcrição dos dados no Sistema Hemovida _Web_ Coagulopatias. Uma nova liberação de concentrado de fator somente poderá ser feita mediante apresentação da planilha completamente preenchida.  
**Observação:** O CTH poderá dispensar o concentrado de fator VIII ou IX suficiente para, no máximo, 2 meses de tratamento. Após este período, uma nova avaliação e prescrição médica se farão necessárias. Cada nova liberação de  
concentrado de fator somente poderá ser feita mediante apresentação da planilha completamente preenchida.  
São os exames laboratoriais gerais: de função hepática (transaminases – AST/TGO, ALT/TGP e tempo de protrombina) e de função renal creatinina sérica).  
São os exames sorológicos: HBsAg, anti-HBs, anti-HBc, anti-HAV, anti-HCV e anti-HIV (pré-avaliação) e anualmente - anti-HBs, anti-HCV e anti-HIV (após imunização).  
Deve-se proceder à quantificação de inibidor a cada 5 a 10 dias de exposição (DE), até que a criança complete 50 DE. Deve-se ainda realizar a quantificação de inibidor toda vez que a criança apresentar sangramento grave ou situação clínica que sugira a ineficácia do tratamento de reposição com o fator deficiente.  
O **Apêndice 10** traz os exames preconizados para a avaliação pré-tratamento e seguimento dos pacientes sob profilaxia primária em caso de hemogilia grave:  
- <u>Pré-avaliação: exames gerais e sorológicos, hemograma com contagem de plaquetas e quantificação de inibidor.</u>  
- - Acompanhamento:  
<u>Ao final do primeiro ano de tratamento: Exames gerais e sorológicos, hemograma com contagem de plaquetas e</u> quantificação de inibidor.  
<u>Do 1º ao 5º ano de tratamento:</u>  
- A cada 6 meses: hemograma, quantificação de inibidor e avaliação multiprofissional.  
- Anualmente, exames sorológicos, avaliação musculo-esqueletica e avaliação multiprofissional.  
- <u>Após o 5º ano de tratamento:</u>  
- A cada 12 meses: hemograma, quantificação de inibidor, exames sorológicos, avaliação musculoesquelética e  
avaliação multiprofissional.  
Preconiza-se que a avaliação musculoesquelética seja realizada pelo menos a cada 12 meses, utilizando o escore _Hemophilia Joint Health Score_<sup>_24_</sup> ( **Apêndice 5** ), que deverá ser realizada idealmente por fisioterapeuta/fisiatra ou, alternativamente, pelo médico assistente.  
A pesquisa e quantificação do inibidor contra os fatores VIII e IX deverão ser realizadas de acordo com a conduta preconizada pelo Manual de Hemofilias, Ministério da Saúde<sup>22</sup> : imediatamente antes da inclusão; a cada 5 a 10 dias até o 50º DE ao fator deficiente; a cada 3 meses do 51º até 100º DE; a cada 6 meses do 101º DE até 5 anos de idade; a cada 12 meses após 5 anos de idade; previamente a cirurgias ou procedimentos invasivos, mesmo que minimamente invasivos; em qualquer ocasião, naqueles pacientes que passaram a não responder à terapia de reposição ou que apresentam aumento da frequência ou gravidade de sangramentos; em pacientes que tenham recebido infusão contínua ou tratamento intensivo (> 50 UI/kg/dia) com fator deficiente por mais de cinco dias consecutivos. Nestes casos, recomenda-se pesquisar o inibidor a partir do quinto dia e, em seguida, pelo menos semanalmente, enquanto o paciente estiver sob terapia de reposição. Caso a avaliação da presença de inibidor tenha sido realizada através de testes de triagem (mistura), a sua quantificação é imprescindível, devendo ser utilizado o método Bethesda ou, preferencialmente, o Bethesda modificado (Nijmegen)<sup>25-26</sup> . O teste de triagem não substitui a quantificação do inibidor, e a quantificação deve ser obrigatoriamente realizada se há suspeita de presença de inibidor.  
Todos os resultados de exames devem ser registrados no Sistema Hemovida _Web_ Coagulopatias.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **6.1. Conduta em caso de desenvolvimento de inibidor durante a  profilaxia** -->
Na vigência de ocorrência de inibidor detectável (> 0,6 UB/mL) durante o tratamento de profilaxia primária:  
- Se título < 5UB/mL: o tratamento profilático poderá ser mantido, desde que clinicamente haja resposta hemostática ao fator deficiente e não haja história de reação alérgica. Nesse caso, o inibidor deverá ser quantificado a cada 30 dias por um período de três meses. Ao final de três meses, se confirmado que o inibidor é de baixa resposta, deve-se retornar o monitoramento do inibidor tal como recomendado acima para pesquisa e quantificação do inibidor.  
- Se título >5 UB/mL, a profilaxia deverá ser interrompida e o paciente deverá ser avaliado para sua inclusão no Protocolo de imunotolerância.  
O tratamento do sangramento agudo no paciente com inibidor deverá ser realizado conforme recomendações do Manual de diagnóstico de inibidor e tratamento de hemorragias em pacientes com hemofilia congênita e inibidor<sup>27</sup> .

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **7. ORIENTAÇÕES AOS PAIS OU RESPONSÁVEIS** -->
Os pais ou responsáveis deverão passar por entrevista de avaliação pela equipe multiprofissional, e deverão assinar o Termo de Esclarecimento e Responsabilidade, seja para aceitar, seja para recusar a profilaxia primária. Este documento deverá ser assinado em duas vias, sendo que uma ficará com a família e a outra será arquivada no prontuário do paciente. Uma cópia deverá ser _escaneada_ e encaminhada à Coordenação-Geral de Sangue e Hemoderivados – CGSH/DAET/SAES/MS.  
Os pais ou responsáveis que aceitarem a profilaxia primária deverão preencher a Planilha de infusão domiciliar ( **Apêndice 7** ) e retorná-la ao CTH sempre antes da dispensação de novas doses de concentrado de fator de coagulação.  
Assim, à inclusão na PP, os pais ou responsáveis deverão receber: cópia do Termo de Esclarecimento e Responsabilidade ( **Apêndice 1** ), Planilha de infusão domiciliar ( **Apêndice 7** ), agenda de seguimento ( **Apêndice 9** ) e cartilha do Paciente e Família ( **Apêndice 11** ).

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **8. REFERÊNCIAS** -->
1. Bolton-Maggs PH, Pasi KJ. Haemophilias A and B. Lancet. 2003; 361:1801-9.  
2. Mannucci PM, Tuddenham EG. The hemophilias - from royal genes to gene therapy. N Engl J Med. 2001;      344:17739.  
3. Blanchette VS, Key NS, Ljung LR, Manco-Johnson MJ, Van Den Berg HM, Srivastava A. Definitions in hemophilia: communication from the SSC of the ISTH. J Thromb Haemost. 2014;12:1935-1939.  
4. Srivastava A, Brewer AK, Mauser-Bunschoten EP, Key NS, Kitchen S, Llinas A, Ludlam CA, Mahlangu JN, Mulder K, Poon MC, Street A and Treatment Guidelines Working Group on behalf of the WFH. The WFH guidelines for the management of hemophilia. Haemophilia 2013, 19(1); e1-47.  
5. Richards M, Williams M, Chalmers E, Liesner R, Collins P, Vidler V, Hanley J Writing group: on behalf of the Paediatric Working Party of the United Kingdom Haemophilia Doctors’ Organisation. A United Kingdom Haemophilia Centre Doctors’ Organization guideline approved by the British Committee for Standards in Haematology: guideline on the use of prophylactic factor VIII concentrate in children and adults with severe haemophilia A. British Journal of Haematology, 2010; 149, 498–507  
6. Manco-Johnson M et al. Prophylaxis versus Episodic Treatment to Prevent Joint Disease in Boys with Severe Hemophilia. NEJM, 2007; 357(6): 535-544.  
7. Ljung R. Prophylactic therapy in haemophilia. Blood Reviews, 2009; 23: 267–274.  
8. Blanchette VS. Prophylaxis in the haemophilia population. Haemophilia, 2010: 16 (Suppl. 5): 181–188.  
9. Oldenburg J. Optimal treatment strategies for hemophilia: achievements and limitations of current prophylactic regimens. Blood. 2015; 125: 2038 – 2044  
10. Aledort LM, Haschmeyer RH, Pettersson H. A longitudinal study of orthopaedic outcomes for severe factor-VIIIdeficient haemophiliacs. The Orthopaedic Outcome Study Group. Journal of Internal Medicine, 1994; 236, 391–399.  
11. Collins P, Faradji A, Morfini M, Enriquez MM, Schwartz L. Efficacy and safety of secondary prophylactic vs. on-demand sucrose- formulated recombinant factor VIII treatment in adults with se-vere hemophilia A: results from a 13-month crossover study. J Thromb Haemost. 2010;83-89.  
12. Gupta S, Siddiqi A-E-A, Soucie JM, et al. The effect of second-ary prophylaxis versus episodic treatment on the range of mo-tion of target joints in patients with haemophilia. Br J Haematol. 2013;161:424-433.  
13. Verma SP, Dutta TK, Mahadevan S, Nalini P, Basu D, Biswal N, et al. A randomized study of very low-dose factor VIII prophylaxis in severe haemophilia—a success story from a resource limited country. Haemophilia. 2016;22(3):342 -8.  
14. Tang L, Wu R, Sun J, Zhang X, Feng X, Zhang X, et al. Shortterm low-dose secondary prophylaxis for severe/moderate haemophilia A children is beneficial to reduce bleed and improve daily activity, but there are obstacle in its execution: a multi-centre pilot study in China. Haemophilia. 2013;19(1):27–34.  
15. Fischer K, Ljung R. Primary prophylaxis in haemophilia care: guideline update 2016. Blood Cells Mol Dis. 2017. https ://doi. org/10.1016/j.bcmd.2017.03.009  
16. Fischer K, Collins PW, Ozelo MC, Srivastava A, Young G, Blanchette VS. When and how to start prophylaxis in boys with severe hemophilia without inhibitors: communication from the SSC of the ISTH. J Thromb Haemost. 2016; 14: 1105 – 1109.  
17. DiMichele D. Inhibitors: resolving diagnostic and therapeutic dilemmas. Haemophilia. 2002;8(3):280-7.  
18. Gouw SC, van der Bom JG, Marijke van den Berg H. Treatment-related risk factors of inhibitor development in previously untreated patients with hemophilia A: the CANAL cohort study. Blood 2007; 109: 4648–54.  
19. Iorio A, Halimeh S, Holzhauer S, Goldenberg N, Marchesini E, Marcucci M, Young G, Bidlingmaier C, Brandao LR, Ettingshausen CE, Gringeri A, Kenet G, Knofler R, Kreuz W, Kurnik K, Manner D, Santagostino E, Mannucci PM, Nowak-Gottl U. Rate of inhibitor development in previously untreated hemophilia A patients treated with plasma-derived or recombinant factor VIII concentrates: a systematic review. J Thromb Haemost 2010; 8: 1256–65.  
20. Fischer K, Van Der Bom JG, Prejs R, et al. Discontinuation of prophylactic therapy in severe haemophilia: incidence and effects on outcome. Haemophilia 2001;7(6):544-50.  
21. Fischer K, Pouw ME, Lewandowski D, Janssen MP, van den Berg HM, and van Hout BA. A modeling approach to evaluate long-term outcome of prophylactic and on demand treatment strategies for severe hemophilia A. Haematologica 2011;96(5):738-743.  
22. Ministério da Saúde. Manual de hemofilias. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada. Brasília: Editora do Ministério da Saúde, 2015.  
23. Delavenne X, Dargaud Y. Pharmacokinetics for haemophilia treaters: Meaning of PK parameters, interpretation pitfalls, and use in the clinic. Thromb Res. 2020;192:52-60.  
24. Ribeiro T, Abad A, Feldman BM. Developing a new scoring scheme for the Hemophilia Joint Health Score 2.1. Res Pract Thromb Haemost. 2019; 20;3(3):405-411.  
25. Ministério da Saúde. Manual de Diagnóstico Laboratorial das Coagulopatias Hereditárias e Plaquetopatias. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada. Brasília: Editora do Ministério da Saúde, 2016.  
26. Verbruggen, B; Novakova, I; Wessels, H; Boezeman, J; van Den Berg, M; Mauser-Bunschoten, E. The Nijmegen modification of the Bethesda assay for factor VIII:C inhibitors: improved specificity and reliability. Thromb Haemost.;73:247-51, 1995.  
27. Ministério da Saúde. Manual de diagnóstico de inibidor e tratamento de hemorragias em pacientes com hemofilia congênita e inibidor, 2008.  
**APÊNDICE 1**  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE PROFILAXIA PRIMÁRIA EM CASO DE HEMOFILIA GRAVE  
Centro de Hemofilia:_______________________________________________________________________________ Nome completo do paciente:_________________________________________________________________________ Data de nascimento: <u>/ / ; Idade: (</u> ) meses; Hemofilia: (  ) A  (  ) B Número do registro no Hemovidaweb Coagulopatias:______________________________________________________ Endereço:________________________________________________________________________________________ ________________________________________________________________________________________________ Fone (fixo e celular)/fax/e-mail:_______________________________________________________________________ Nome da mãe:_____________________________________________________________________________________ Nome do pai:_____________________________________________________________________________________

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **1. O que é profilaxia primária em hemofilia?** -->
A profilaxia primária (PP) em hemofilia é o nome que se dá ao tratamento que é realizado para pacientes com hemofilia A ou B **<u>grave</u>** de forma profilática, isto é, independentemente de o paciente apresentar sangramento e por tempo prolongado e ininterrupto, isto é, por mais de 45 semanas ao ano. É desejável que a PP se inicie precocemente antes da segunda hemartrose. A PP é recomendada e reconhecida pela Organização Mundial da Saúde e Federação Mundial de Hemofilia como o tratamento de eleição para a **<u>forma grave da hemofilia A e B.</u>**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **2. Em que consiste a profilaxia primária em hemofilia?** -->
A PP consiste na infusão de concentrado de fator VIII (para hemofilia A grave) ou fator IX (para hemofilia B grave) antes da ocorrência do sangramento. O paciente recebe a infusão do concentrado do fator 1 a 2 vezes por semana para hemofilia B e 1 a 3 vezes por semana para hemofilia A.  
O esquema utilizado será de doses escalonadas, onde o paciente começa recebendo infusão do concentrado de fator 1-2 vezes por semana, podendo chegar a 3 vezes por semana no caso da hemofilia A e 2 vezes por semana na hemofilia B. Este escalonamento levará em conta a ocorrência de sangramento. Para tal, o acompanhamento médico e o preechimento da planilha domiciliar será fundamental na definição da dose e frequência semanal.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: Poderão participar da PP os pacientes com **<u>hemofilia A ou B, forma grave ou com atividade de fator inferior a 2%</u>** <u>,</u> -->
com idade inferior a 3 anos incompletos . Pacientes com inibidor de alto título (superior a 5 UB/mL) não poderão ser incluídos porque não respondem a infusão do concentrado do fator deficiente. A inclusão dos pacientes será feita pelo médico do Centro de Tratamento de Hemofilia (CTH). Os pacientes com hemofilia A e B grave ou com dosagem de fator menor que 2% com 3 ou mais anos, ou com antecedente de duas ou mais hemartroses devem ser incluídos no programa de profilaxia secundária. Neste caso, estes pacientes receberão o mesmo tratamento que os pacientes recebem na PP descrito neste Protocolo. Isso vale tanto para os pacientes com hemofilia A como para hemofilia B, assim como situações especiais descritas no protocolo de PP.  
Para ser incluído, o paciente deve ter avaliação favorável da equipe multidisciplinar do CTH (composta pelo menos por médico e enfermeira). Ainda, será necessário treinamento para infusão do concentrado de fator de coagulação que poderá ser infundido em casa (em veia periférica ou por cateter venoso central).

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **4. Como será feito o acompanhamento do tratamento?** -->
O paciente deverá ser avaliado periodicamente pela equipe do CTH para avaliar se o tratamento está adequado. Durante o tratamento de PP, o teste de dosagem do inibidor deverá ser realizado com frequência, de acordo com as recomendações vigentes do Ministério da Saúde. As consultas e orientações devem ser rigorosamente seguidas pelo paciente e responsável.  
A cada visita médica, o paciente deverá trazer a ficha de uso do fator de coagulação devidamente preenchida com todas as informações solicitadas. Caso o tratamento seja realizado na casa do paciente, ele deverá retornar ao centro os frascos vazios dos concentrados de fator, assim como equipo, agulhas e seringas usadas para descarte em lixo hospitalar.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5. Quais são as vantagens da profilaxia primária?** -->
A PP, quando seguida da forma recomendada, reduz o risco de complicações da doença que ocorrem devido aos sangramentos de repetição, principalmente da artropatia hemofílica (decorrente do sangramento repetido para dentro das juntas) que pode levar a deformidades e sequelas irreversíveis. A PP permite ao paciente a realização de atividades físicas e esportivas com menos restrição e proporciona maior permanência da criança na escola e nas demais atividades sociais.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **6. O que deve ser feito para o bom andamento do tratamento?** -->
Para que o tratamento tenha sucesso, o paciente deverá ter acompanhamento médico frequente, devendo comparecer a todas as consultas agendadas e realizar os testes solicitados. O paciente e seus familiares devem seguir rigorosamente todas as orientações dadas por seu médico e equipe multiprofissional.  
É essencial a participação e envolvimento do paciente e de sua família. Em caso de qualquer dúvida, deve-se contatar o  
CTH.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **7. Quais são os riscos da profilaxia primária para o paciente?** -->
Os riscos da PP são os mesmos do tratamento da hemofilia sob demanda (infusão do fator após um sangramento) já oferecida aos pacientes com hemofilia. Estes são: possibilidade de desenvolvimento de inibidor, possibilidade de contaminação com agentes infecciosos transmissíveis pelos concentrados de fator de coagulação (embora não haja relato de contaminação há mais de 20 anos) e reação alérgica ao produto infundido. Ainda, devido à frequência de infusões, o paciente pode necessitar da instalação de cateter venoso central, caso o acesso de veias periféricas fique dificultado.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **8. O que acontece se o responsável se recusar a fazer o tratamento?** -->
O paciente continuará a ser atendido normalmente no CTH, independentemente da concordância ou não de participar da PP. Entretanto, o responsável deverá estar ciente de que ele(a) está recusando o tratamento mais recomendado para o tratamento da hemofilia grave, evitando que sua criança tenha complicações futuras que não ocorreriam se tivesse iniciado a PP precocemente. Ainda, o(a) responsável deve estar ciente de que a chance de participar foi ofertada a sua criança e por ele recusada, não cabendo ao Ministério da Saúde nem ao CTH ser responsabilizado pela recusa no futuro.  
É importante saber que este tratamento não faz parte de um projeto de pesquisa. Ao assinar este documento, o paciente/responsável declara que:  
- **a.** Foi devidamente orientado e compreendeu o que é PP e a qual sua função;  
- **b.** Está ciente dos benefícios, das potenciais complicações do tratamento e de sua responsabilidade quanto à PP;  
- **c.** Está ciente que a suspensão do tratamento pode ocorrer aos 18 anos de idade, mediante avaliação da equipe  
- multiprofissional.  
Ao assinar este documento, o paciente/responsável se compromete a:  
Cumprir todas as regras do tratamento, incluindo comparecer às consultas agendadas, coletar sangue para exames,  
devolver ao centro todo material das infusões domiciliares (frascos, seringas e agulhas), preencher planilha com dados de infusão  
domiciliar e devolvê-la ao CTH e não suspender o tratamento sem recomendação médica.  
( ) Sim, aceito participar.  
( ) Não, não aceito (se não, preencher o motivo da recusa)  
Motivo da recusa: ________________________________________________________________________________ Local e data: ,     / <u>/____</u> Nome legível do paciente ou responsável:_______________________________________________________________  
Assinatura:_______________________________________________________________________________________ Testemunhas:  
Nome legível e assinatura: ___________________________________________________________________________  
Nome legível e assinatura: ___________________________________________________________________________

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **1. Identificação** -->
Nome:__________________________________________________________________________________________ Data: ___ /___/_____ Nome do acompanhante/cuidador(a) (grau de parentesco): _________________________________________________  
________________________________________________________________________________________________ Cadastro no Hemovida Web Coagulopatias:_____________________________________________________________ Data nascimento: <u>/ /</u> Reg no CTH: Hemofilia ( ) A ( ) B Peso: <u>Altura:</u>  
Paciente orientado quanto ao diagnóstico?  
( ) SIM ( ) NÃO ( ) NÃO SE APLICA  
Cuidador(a) orientado quanto ao diagnóstico?  
( ) SIM ( ) NÃO ( ) NÃO SE APLICA

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **2. Acesso venoso periférico** -->
Avaliação  
||**Mão**||**Membro**|**superior**|**Antebr**|**aço**|**Pé**||
|---|---|---|---|---|---|---|---|---|
||**Dir**|**Esq**|**Dir**|**Esq**|**Dir**|**Esq**|**Dir**|**Esq**|
|**Péssimo**|||||||||
|**Regular**|||||||||
|**Bom**|||||||||
|**Ótimo**|||||||||

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **3. Infusão domiciliar** -->
- Paciente/cuidador está treinado para infusão domiciliar?  
- ( ) SIM Quem está?____________________________________________________________________________________  
- ( ) NÃO  
Quem quer ser treinado? ___________________________________________________________________________  
- Pode vir ao Centro pelo menos uma vez por semana? ( ) SIM ( ) NÃO  
**4. Avaliação psicológica**  
- Paciente faz acompanhamento psicológico?  
- ( ) SIM ( ) NÃO  
- ( ) NÃO SE APLICA  
- Cuidador faz acompanhamento psicológico?  
19  
||(<br>) SIM<br>(<br>) NÃO|
|---|---|
||Necessário o encaminhamento para atendimento psicológico?|
|**5. **|(<br>) SIM<br>(<br>) NÃO<br>**Transporte e armazenamento do fator**|
||Tem bolsa térmica para transporte?|
||(<br>) SIM<br>(<br>) NÃO|
||Tem geladeira para armazenamento do fator?|
||(<br>) SIM<br>(<br>) NÃO|
||A geladeira está em condições de uso (limpa e funcionando)?|
||(<br>) SIM<br>(<br>) NÃO|
|**6. **|**Recursos da comunidade próximo à residência**|
||Unidade básica de saúde|
||(<br>) SIM<br>(<br>) NÃO|
||Nome:___________________________________________________________________________________________|
||Endereço: ________________________________________________________________________________________|
||Nome do contato: __________________________________________________________________________________|
||Pronto Socorro|
||(    ) SIM<br>(    ) NÃO|
||Nome: ___________________________________________________________________________________________|
||Endereço: ________________________________________________________________________________________|
||Fone: ____________________________________________________________________________________________|
||Nome do contato: ____________________________________________________________________________________|
|**7. **<br>|**Visita domiciliar**<br>Foi feita visita domiciliar?<br>(     ) SIM|
||Quem participou da visita? ______________________________________________________________________________|
|____<br>____|_____________________________________________________________________________________________________<br>Considerações sobre a habitação: ______________________________________________________________________<br>__________________________________________________________________________________________________|
|____<br>____<br>____|__________________________________________________________________________________________________<br>(      ) NÃO – Por que?<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________|  
**8. Escolha do acesso venoso**  
- Após avaliação e discussão com grupo multidisciplinar, optou-se por acesso:  
- ( ) Periférico ( ) Central  
20

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **9. Conduta** -->
______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ Nome: ___________________________________________________________________________________________ Data: <u>/ /</u>  
21  
**APÊNDICE 2A**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: FORMULÁRIO DE ACOMPANHAMENTO DE ENFERMAGEM -->
||Nome: ___________________________________________________________________________________________<br>Registro:<br>Data:___/___/_____Peso:______________Altura: ________|
|---|---|
|<br>___|Condições atuais do acesso:<br>(<br>) Periférico<br>(<br>) Central<br>________________________________________________________________________________________________<br>__________________________________________________________________________________________________|
|___<br>___<br><br>____|__________________________________________________________________________________________________<br>__________________________________________________________________________________________________<br>Técnica desenvolvida pelo cuidador<br>________________________________________________________________________________________________<br>__________________________________________________________________________________________________|
|____<br>____<br><br>____<br>____|__________________________________________________________________________________________________<br>__________________________________________________________________________________________________<br>Dificuldades?<br>(<br>) NÃO<br>(<br>) SIM – descreva:  _______________________________________________________<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________|
|____<br><br>____<br>____|__________________________________________________________________________________________________<br>Uso correto do material?<br>(<br>) SIM<br>(<br>) NÃO – descreva: _________________________________________________________<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________|
|____<br><br>____<br>____|__________________________________________________________________________________________________<br>Técnica correta do procedimento?<br>(<br>) SIM<br>(<br>) NÃO – descreva: _________________________________________________________<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________|
|____<br><br>____<br>____<br>____|__________________________________________________________________________________________________<br>Avaliação e conduta:<br>________________________________________________________________________________________________<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________<br>__________________________________________________________________________________________________<br>Nome:<br>Data:<br>/<br>/|  
22

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **1. Identificação** -->
Nome:__________________________________________________________________________________________ Data:__/___/_____ Nome do acompanhante/cuidador(a) (grau de parentesco): _________________________________ ________________________________________________________________________________________________ Cadastro no HEMOVIDAWEB Coagulopatias: ___________________________________________________________ Hemofilia (     ) A  (     ) B Fone :________________________________________  cel: **2. Contexto sócio-familiar**  Pessoas que residem com o paciente (enumerar) ( ) pai( ) mãe ( ) irmãos ( ) avô ( ) avó ( ) tios ( ) primos ( ) outros: especificar:  Tem irmão(s) com hemofilia? (       ) NÃO ( ) SIM – quantos?  A família tem conhecimento sobre a hemofilia? (        ) SIM ( ) NÃO  A família se envolve no tratamento? ( ) SIM – como? ______________________________________________________________________________________________________ ( ) NÃO – descrever: ______________________________________________________________________________________________________  Cuidador comparece às consultas agendadas? ( ) SIM ( ) NÃO – nº faltas / 6 meses e motivos: ______________________________________________________________________________________________________  A quem recorre quando enfrenta dificuldades?  ___________________________________________________________  Em que circunstâncias? ______________________________________________________________________________________________________ **3. Meio de transporte** ( ) próprio ( ) ônibus ( ) trem ( ) metrô ( ) outros:  _____________________________ _________________________________________________________________________________________________________ • Possui Passe Livre? ( ) Sim ( ) Não  
**4. Moradia**  
- Foi feita visita domiciliar? ( ) SIM ( ) NÃO Se não por que?  
- A moradia é:  
- ( ) própria   (     ) alugada    (     ) alvenaria    (    ) outros: ___________________________________________________  
23  
- Quantos cômodos têm a casa?  _______________________________________________________________________  
- Infraestrutura básica:  
Água encanada:  (     ) SIM ( ) NÃO – descreva: ______________________________________________________ Esgoto: (     )SIM      (     ) NÃO – descreva: ______________________________________________________________ Eletricidade:  (     ) SIM     (     ) NÃO – descreva: __________________________________________________________ Outros: ________________________________________________________________________________________  
**5. Atitude da família / cuidador frente ao programa**  
(  ) interessada   (   ) ansiosa  ( ) dependente (  ) agressiva (  ) apática (  ) proativa  
**6. Trabalho e renda familiar**  
- O paciente: ( ) Trabalha( ) Estuda ( ) não se aplica  
- Renda familiar:  
( ) 1 a 3 salários mínimos ( ) 4 a 6 salários mínimos ( ) Acima de 6 salários mínimos  
- A família possui algum benefício social?  
- ( ) Bolsa Família ( ) BPC ( ) Aposentadoria por invalidez ( ) ( ) Não  
Outro(s):  
**7. Problemas identificados**  
**________________________________________________________________________________________________ ______________________________________________________________________________________________________**  
**______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **8. Conduta** -->
**________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________**  
Nome: Data: <u>/ /</u>  
24

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: FORMULÁRIO DE EVOLUÇÃO DO SERVIÇO SOCIAL -->
|Nome:<br>Registro:|Data: ___/___/____|
|---|---|
|<br>Problemas relacionados na última avaliação foram solucionados?<br>(<br>) SIM<br>(<br>) NÃO – por que?<br>________________________________________________________________________<br>________________________________________________________________________<br>_______________________________________________________________________<br>________________________________________________________________________<br>________________________________________________________________________<br>________________________________________________________________________<br>________________________________________________________________________<br>_______________________________________________________________________|______________________________<br>______________________________<br>_______________________________<br>______________________________<br>______________________________<br>______________________________<br>______________________________<br>_______________________________|  
 Novos problemas foram identificados? ( ) NÃO ( ) SIM – descreva: ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________  Avaliação e conduta ____________________________________________________________________________________________ ____________________________________________________________________________________________ ____________________________________________________________________________________________  
____________________________________________________________________________________________ ____________________________________________________________________________________________ ____________________________________________________________________________________________ ____________________________________________________________________________________________ ____________________________________________________________________________________________  
Nome: Data: <u>/ /</u>  
25  
**APÊNDICE 4**  
FORMULÁRIO DE AVALIAÇÃO INICIAL DA PSICOLOGIA  
 **Identificação** Nome:___________________________________________________________________________________________ Data nascimento: ____/____/______  Reg:____________________________  Hemofilia (   ) A    (   )B  Dados familiares: Cuidador: (    ) mãe  (    ) pai (    ) outro (especificar) __________________________________________________  Mãe: Nome:____________________________________________________________________________________________ Data nascimento: <u>/ /</u> Escolaridade: Profissão: Local trabalho: Telefone:  Pai: Nome: ___________________________________________________________________________________________ Data nascimento: <u>/ /</u> Escolaridade: Profissão: Local trabalho: Telefone:  Religião da família:  Situação civil dos pais: ( ) Casados ( ) Separados ( ) Viúvo(a) ( ) Outra:  Tem outro familiar com hemofilia? ( ) NÃO ( ) SIM – quantos / quem ? ______________________________________________________________________________________________________  História da mãe: A gravidez foi:   ( ) planejada ( ) inesperada : como reagiu? ______________________________________________________________________________________________________ Apresentou problemas de saúde durante a gravidez? ( ) NÃO ( ) SIM – qual?  **Antecedentes pessoais**  Criança frequenta escola? ( ) NÃO ( ) SIM – série: _____ Escola: ________________________________________________________ Reação / adaptação:______________________________________________________________________________________  Criança tem crescimento / desenvolvimento normal? ( ) SIM ( ) NÃO – comentar: ______________________________________________________________________________________________________  Criança já ficou internada? ( ) NÃO ( ) SIM – quantas vezes/por quanto tempo/ motivo: ______________________________________________________________________________________________________  
______________________________________________________________________________________________________ ______________________________________________________________________________________________________  
- **Diagnóstico / tratamento da hemofilia**  
- Pais / cuidador e familiares  
Com que idade foi feito o diagnóstico da hemofilia?  
O que entenderam sobre a hemofilia e suas complicações:  
______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________  
- Infusão de concentrado de fator / coleta de exames  
Como é a reação da criança?  
( ) Chora ( ) Tem medo ( ) Tranquila ( ) Outra Comente: _________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ Como é a reação dos pais / cuidadores?  
( ) Tranquilos ( ) Ansiosos     ( ) Tem medo    (    ) Colaboram   (    ) Outra Comente:  
______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________  
- **História psicológica dos pais/cuidadores**  
- Faz tratamento de algum distúrbio psicológico (ex: depressão, medos exagerados, crise de  ansiedade...)  
- ( ) NÃO ( ) SIM – Há quanto tempo?  
- Faz uso de algum medicamento que o deixe sonolento, cansado, irritado?  
- ( ) NÃO ( ) SIM – Qual?  
- Faz uso de bebida alcoólica?  
- ( ) NÃO (        ) SIM– especificar tipo e quantidade:  
______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________  
 Faz uso de drogas?  
( ) NÃO ( ) SIM – especificar:  
- Algum outro familiar faz uso de bebida alcoólica ou drogas?  
( ) NÃO ( ) SIM – especificar:  
 Qual foi a última situação estressante pela qual passaram como pais? Foi relacionada à hemofilia? Como reagiram? O que fizeram para amenizar a dor, o sofrimento ou o estresse?  
______________________________________________________________________________________________________  **Perguntas relacionadas à participação no Programa de Profilaxia**  
- Já ouviu falar sobre profilaxia?  
( ) NÃO (     ) SIM – comente o que sabe e suas dúvidas:  
- ______________________________________________________________________________________________________  Tem interesse em aprender a preparar o fator e puncionar a veia do seu filho?  
( ) SIM (      ) NÃO – por que?  
 Cateter (somente para as crianças com indicação de implantação de cateter).  
Já ouviu falar sobre cateter?  
( ) NÃO (     ) SIM – comente o que sabe e suas dúvidas:  
Como pais / cuidador você fala sobre o cateter que está inserido no corpo do seu filho?  
( ) SIM ( ) NÃO  
Você explica sobre a importância / necessidade do cateter? ( ) SIM ( ) NÃO  
- Você precisa de algum esclarecimento adicional ou suporte para lidar com o tratamento profilático do  seu filho? ( ) NÃO ( ) SIM – comente:  
______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________  **Conduta**  
- **______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________ ______________________________________________________________________________________________________**  
Nome:___________________________________________________________________________________________ Data: <u>/ /</u>  
**APÊNDICE 4 A**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: FORMULÁRIO DE EVOLUÇÃO DA PSICOLOGIA -->
|Nome: ___________________________________________________________________________________________<br>Registro:<br>Data:<br>/<br>/|
|---|
|<br>Problemas detectados na última avaliação foram solucionados?<br>(<br>) SIM<br>(<br>) NÃO – por que?<br>_____________________________________________________________________________________________________<br>_____________________________________________________________________________________________________<br>_____________________________________________________________________________________________________<br>_____________________________________________________________________________________________________|
|_____________________________________________________________________________________________________<br>_____________________________________________________________________________________________________<br>_____________________________________________________________________________________________________<br><br>Novos problemas foram identificados?<br>(<br>) NÃO<br>(      ) SIM– descreva:<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________|
|______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br><br>Avaliação e conduta<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________|
|______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>______________________________________________________________________________________________________<br>Nome:________________________________________________________________________________________________<br>Data:<br>/<br>/|  
Versão 2.1 Hemophilia Joint Health Score *

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **Planilha de resumo da pontuação** -->
|**Característica**|**TE**|**TD**|**CE**|**CD**|**JE**|**JD**|
|---|---|---|---|---|---|---|
|Edema|||||||
|Duração do edema|||||||
|Atrofia muscular|||||||
|Alinhamento axial|||||||
|Crepitação à movimentação|||||||
|Perda de flexão|||||||
|Perda de extensão|||||||
|Instabilidade|||||||
|Dor articular|||||||
|Força|||||||
|**Total das articulações**|||||||  
TE (tornozelo esquerdo); TD (tornozelo direito); CE (cotovelo esquerdo);  
CD (cotovelo direito); JE (joelho esquerdo); JD (joelho direito).  
Escore total = Soma do total das articulações + pontuação da marcha global  
- Edema: 0 = sem edema; 1 = leve; 2 = moderado; 3 = grave  
- Duração do edema: 0 = sem edema ou < 6 meses; 1 = > 6 meses  
- Atrofia muscular: 0 = nenhuma; 1 = leve; 2 = grave  
- Alinhamento axial (medida somente em joelho e tornozelo): 0 = dentro dos limites normais; 2 = fora dos limites normais  
- Crepitação à movimentação: 0 = nenhuma; 1 = leve; 3 = grave  
- Perda de flexão: 0 = < 5; 1 = 5-10; 2 = 11-20; 3 = > 20  
- Perda de extensão: 0 = < 5; 1 = 5-10; 2 = 11-20; 3 = > 20  
- Instabilidade: 0 = nenhuma; 1 = significativa  
- Dor articular: 0 = nenhuma dor na movimentação ativa; 1 = nenhuma dor na movimentação ativa; dor somente a suave  
- pressão ou na palpação; 2 = dor à movimentação ativa  
- Força: de acordo com a escala de Daniels & Worthingham (medida durante a Amplitude de Movimento – ADM -  
possível).  
- 0 = sustenta a posição de teste contra a gravidade, com máxima resistência (grau 5)  
- 1 = sustenta a posição de teste contra a gravidade, com resistência moderada (mas falha quando aplicada resistência  
- máxima) (grau 4)  
- 2 = sustenta a posição de teste contra a gravidade, com resistência mínima (grau 3+), ou contra a gravidade (grau 3)  
- 3 = capaz de completar parcialmente a ADM contra a gravidade (grau 3-/2+), ou capaz de completar a ADM, quando a  
gravidade é eliminada (grau 2), ou completa parcialmente a ADM quando a gravidade é eliminada  
- 4 = traço de contração muscular (grau 1) ou ausência de contração muscular (grau 0)  
- Marcha (caminhar, subir e descer escada, correr e pular com uma perna):  
0 = todas as habilidades estão nos limites da normalidade; 1 = Uma habilidade está fora dos limites da normalidade; 2 = Duas habilidades estão fora dos limites da normalidade; 3 = Três habilidades estão fora dos limites da normalidade; 4 = Nenhuma habilidade está nos limites da normalidade (caminhar, subir e descer degraus, correr e saltar)  
* Fonte: https://www.ipsg.ca

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: FORMULÁRIO DE APROVAÇÃO DA PROFILAXIA PRIMÁRIA -->
(Este formulário deve ser assinado pela equipe multiprofissional e encaminhado ao Ministério da Saúde juntamente com o  
TER, Apêndice 1)

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **Identificação** -->
Nome:________________________________________________________________________________________________ Data nascimento: ___/___/______ Nome da mãe: __________________________________________________________________________________________ Registro:______________Hemofilia (     ) A (     ) B Inscrição Hemovida _web_ Coagulopatias:_____________________________________ Cartão SUS: ______________________ Data de inclusão: __/___/_______  
A equipe abaixo discriminada está de acordo com a inclusão do paciente acima no programa de profilaxia primária.  
Nome legível do(a)  médico(a) e CRM: ______________________________________________________________________ Assinatura: ____________________________________________________________________________________________ Nome legível do(a) enfermeiro(a): __________________________________________________________________________ Assinatura: ____________________________________________________________________________________________ Nome legível do(a) assistente social: ________________________________________________________________________ Assinatura: ____________________________________________________________________________________________ Nome legível do(a) psicólogo(a): ___________________________________________________________________________ Assinatura: ____________________________________________________________________________________________ Nome legível do(a) fisioterapeuta(a)/fisiatra/ortopedista: ________________________________________________________ Assinatura: ____________________________________________________________________________________________

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: PLANILHA DE INFUSÃO DOMICILIAR -->
(Esta planilha deverá ser preenchida pelos pais ou responsáveis e retornada ao Centro de Hemofilia **SEMPRE** antes da dispensação de novas dose de concentrado de fator)  
Nome:  
Registro Centro de Tratamento:

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: Registro Hemovida: -->
Data nascimento: / /

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: Centro de tratamento: -->
|Dados ger|ais||Produto|||Motivo da|infusão||||Hemorragi|a||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||Hemorr|agia*||Conti-||||
|Data|Hora|Peso|Nome comercial|Lote|Nº<br>UI|Profi-<br>laxia|artic|musc|out|nuidade|Local<sup>#</sup>|Lado<sup>&</sup>|Assinatura|
|Dados ger|ais||Produto|||Motivo da|infusão||||Hemorragi|a||
||||||||Hemorr|agia*||Conti-||||
|Data|Hora|Peso|Nome comercial|Lote|Nº<br>UI|Profi-<br>laxia|artic|musc|out|nuidade|Local<sup>#</sup>|Lado<sup>&</sup>|Assinatura|  
***** Hemorragia: art=articular; musc=muscular; out=outros.  
> # Local: **articular:** joelho=J; cotovelo=C; tornozelo=T; ombro=O; punho=P; quadril=Q; outros. **Muscular:** panturrilha=pant.; antebraço=anteb.; coxa; perna; glúteo; mão; pé; outros. **Outros:** sistema nervoso central=SNC; cavidade oral=CO; outros  
> **&** Lado: direito=D; esquerdo=E; não sabe ou não se aplica=N

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **APÊNDICE 8** -->
CRONOGRAMA DO PROTOCOLO BRASILEIRO DE PROFILAXIA PRIMÁRIA EM CASO DE HEMOFILIA GRAVE  
|**Nome do Paciente:**||||||||**DN:**|||
|---|---|---|---|---|---|---|---|---|---|---|
|**Centro de Hemofilia:**||||||||**Registr**|**o Centro:**||
|**Médico responsável:**||||||**Tel. Co**|**ntato do Serv**|**iço/Médico:**|||
|**Registro HEMOVIDA:**|||||||||||
|**Nome da Mãe:**|||||||||||
|**Acesso periférico: Sim ( ) Não (   )**|||||||||||
|**Cateter: Sim ( ) Não (   )**|**Tipo de cateter:**||||||**Data implan**|**tação catete**|**r:**||
|**Dias Sequenciais do Protocolo**|**Aval. de inclusão**|**Semana Zero**|**Sem 1-5**|**6a.Sem**|**Sem 7-13**|**14a.Sem**|**Sem 15-20**|**21a. Sem**|**27a. Sem 2**|**8a.Semana**|
|**Data**|||||||||||
|**Infusão de Fator (Dose A, B, C)**||**INÍCIO**|||||||||
|**Explicação e entrega do Termo de Esclarecimento e**<br>**Responsabilidade**|||||||||||
|**Avaliação Critérios Inclusão**|||||||||||
|**Avaliação Clínica (Médica)**|||||||||||
|**Avaliação Serviço Social**|||||||||||
|**Avaliação Psicologia**|||||||||||
|**Avaliação Enfermeira**|||||||||||
|**Avaliação Musculoesquelética**|||||||||||
|**Avaliação Imagem**|||||||||||
|**Recolhimento Termo de Esclarecimento e**<br>**Responsabilidade assinado**|||||||||||
|**Visita inicial / Entrega formulários ao responsável**|||||||||||
|**Quantificação de Inibidor**|||||||||||
|**Hemograma**|||||||||||
|**Exames gerais**|||||||||||
|**Sorologia**|||||||||||
|**CRONOGRAMA DO PROTOCOLO BRASILEIRO**<br>|**DE PROFILAXIA P**|**RIMÁRIA EM C**|**ASO DE H**|**EMOFILI**|**A GRAVE**||||||
|**Dias Sequenciais do Protocolo**|**Sem 29-33**<br>**34a.**|**Sem**<br>**Sem 35-39**|<br>**40a.Se**|**m**<br>**Sem**|**41-45**<br>**4**|**6a.Sem**|**Sem 47-51**|**52a.Sem**|**18 meses**|**24 meses**|
|**Data**|||||||||||
|**Infusão de Fator (Dose escalonamento A, B, C)**|||||||||||
|**Avaliação Clínica (Médica)**|||||||||||  
|**Avaliação Serviço Social**||||||||||
|---|---|---|---|---|---|---|---|---|---|
|**Avaliação Psicologia**||||||||||
|**Avaliação Enfermeira**||||||||||
|**Avaliação Musculoesquelética**||||||||||
|**Avaliação Imagem**||||||||||
|**Quantificação de Inibidor**||||||||||
|**Hemograma**||||||||||
|**Exames gerais**||||||||||
|**Sorologia**||||||||||
|**Dias Sequenciais do Protocolo**|**30 meses**|**36 meses**|**42 meses**|**48 meses**|**54 meses**|**60 meses**|**72 meses**|**84 meses**|**96 meses**<br>**108 meses**|
|**Data**||||||||||
|**Infusão de Fator (Dose escalonamento A, B, C)**||||||||||
|**Avaliação Clínica (Médica)**||||||||||
|**Avaliação Serviço Social**||||||||||
|**Avaliação Psicologia**||||||||||
|**Avaliação Enfermeira**||||||||||
|**Avaliação Musculoesquelética**||||||||||
|**Avaliação Imagem**||||||||||
|**Quantificação de Inibidor**||||||||||
|**Hemograma**||||||||||
|**Exames gerais**||||||||||
|**Sorologia**||||||||||

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **APÊNDICE 8** -->
|**Dias Sequenciais do Protocolo**|**120 meses**|**132 meses**|**144 meses**|**156 meses**|**168 meses**|**180 meses**|**192 meses**<br>**204 meses**|**216 meses**|
|---|---|---|---|---|---|---|---|---|
|**Data**|||||||||
|**Infusão de Fator (Dose escalonamento A, B, C)**|||||||||
|**Avaliação Clínica (Médica)**|||||||||
|**Avaliação Serviço Social**|||||||||
|**Avaliação Psicologia**|||||||||
|**Avaliação Enfermeira**|||||||||
|**Avaliação Musculoesquelética**|||||||||
|**Avaliação Imagem**|||||||||
|**Quantificação de Inibidor**|||||||||  
|**Hemograma**|
|---|
|**Exames gerais**|
|**Sorologia**|  
Determinar dose em uso:  
UI ( UI/kg) x/semana        UI (   UI/kg)      x/semana UI ( UI/kg) x/semana        UI (   UI/kg)      x/semana  
Pesquisa de Inibidor:  
- A quantificação de inibidor deverá ser mais frequente no caso da necessidade de tratamentos de reposição ou alteração do escalonamento.  
- Incluir a quantificação de inibidor a cada 5 a 10 dias de exposição ( **DE** ) até o 50° DE, a cada 3 meses até o 100º **DE** e a cada 6 meses até 5 anos de idade; após 5 anos, 1x ao ano.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **APÊNDICE 9** -->
AGENDA DE SEGUIMENTO DO PROTOCOLO BRASILEIRO DE PROFILAXIA PRIMÁRIA EM CASO DE HEMOFILIA GRAVE  
|**Nome do Paciente:**|||||||||**DN:**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Centro de Hemofilia:**|||||||||**Registro Centro**||||
|**Médico responsável:**|||||||||||||
|**TEL. Contato do Serviço/Médico:**|||||||||**No. registro HEMOVIDA:**||||
|**Nome da Mãe:**|||||||||||||
|**Acesso periférico: Sim ( ) Não (   )**|||||||||||||
|**Cateter: Sim ( ) Não (   )**||**Tipo d**|**e cateter:**|||||**Data im**|**plantação cateter:**||||
|**DIAS de tratamento**|**1o.**|**7o.**|**14o.**|**21o.**|**28o.**|**35o.**|**42o.**|**49o.**|**56o.**|**63o.**|**70o.**|**77o.**|
|**DATA:**|||||||||||||
|**Visita médica /exame**|||||||||||||
|**Revisão Cateter**|||||||||||||
|**DOSE:**<br>**UI/X semana**|||||||||||||
|**PROFILAXIA**|||||||||||||
|**HEMORRAGIA**|||||||||||||
|Local hemorragia|||||||||||||
|Dias de tratamento|||||||||||||
|**DIAS de tratamento**|**84o.**|**91o.**|**98o.**|**105o.**|**112o.**|**119o.**|**126o.**|**133o.**|**140o.**|**147o.**|**154o.**|**161o.**|
|**DATA:**|||||||||||||
|**Visita médica /exame**|||||||||||||
|**Revisão Cateter**|||||||||||||
|**DOSE: UI/X**<br>**semana**|||||||||||||
|**PROFILAXIA**|||||||||||||
|**HEMORRAGIA**|||||||||||||
|Local hemorragia|||||||||||||
|Dias de tratamento<br>**AGENDA DE SEGUIMENTO DO PROTOCOL**<br>|**O BRASILEIR**<br>|**O DE PR**<br>|**OFILAX**<br>|**IA PRIM**<br>|**ÁRIA E**<br>|**M CASO**<br>|**DE HE**<br>|**MOFILI**<br>|**A GRAVE**<br>||||
|**DIAS de tratamento**|**168o.**|**175o.**|**182o.**|**189o.**|**196o.**|**203o.**|**210o.**|**217o.**|**224o.**|**231o.**|**238o.**|**245o.**|
|**DATA:**|||||||||||||

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **APÊNDICE 9** -->
|**DOSE:**<br>**UI/X**<br>**semana**|
|---|
|**PROFILAXIA**|
|**HEMORRAGIA**|
|Local hemorragia|
|Dias de tratamento|

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **APÊNDICE 9** -->
|**JD**|**JOELHO DIREITO**|
|---|---|
|**JE**|**JOELHO ESQUERDO**|
|**TD**|**TORNOZELO DIREITO**|
|**TE**|**TORNOZELO ESQUERDO**|
|**CD**|**COTOVELO DIREITO**|
|**CE**|**COTOVELO ESQUERDO**|  
**APÊNDICE 10**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: RESULTADO DE EXAMES -->
|**AGENDA DE SEGUIMENT**<br>**Nome do Paciente:**|**O DO PRO**|**TOCOLO**|**BRASILEIR**|**O DE PRO**|**FILAXIA P**|**RIMÁRIA E**|**M CASO D**|**E HEMOFI**<br>**DN:**|**LIA GRAVE**|
|---|---|---|---|---|---|---|---|---|---|
|**Centro de Hemofilia:**||||||**No. regist**|**ro HEMOV**|**IDA:**||
|**Médico responsável:**<br>**Dias**<br>**Sequencial**<br>**do**|**Aval. de**|||||**Tel. Cont**|**ato do Serviç**|**o/Médico:**||
|<br>**Protocolo**|**inclusão**|**6ª sem**|**14ª sem**|**21ªsem**|**28ª sem**|**34ª sem**|**40ª sem**|**46ª sem**|**52ª sem**|
|**Data**||||||||||
|**Coagulação**||||||||||
|**FVIII:C**||||||||||
|**Pesquisa de Inibidor**||||||||||
|**Quantificação**<br>**de**||||||||||
|**Inibidor**||||||||||
|**TP (AP)**||||||||||
|**Hemograma**||||||||||
|**Hb**||||||||||
|**Ht**||||||||||
|**Leucócitos**||||||||||
|**Plaquetas**||||||||||
|**Função hepática**||||||||||
|**AST/TGO**||||||||||
|**ALT/TGP**||||||||||
|**Função renal**||||||||||
|**Creatinina sérica**||||||||||
|**Sorologias**||||||||||
|**anti-HIV**||||||||||
|**anti-HCV**||||||||||
|**HBS:Ag**||||||||||
|**anti-HBs**||||||||||
|**anti-HBc**||||||||||
|**anti-HAV**||||||||||
|**Dias**<br>**Sequencial**<br>**do**|**18**|**24**|**30**|**36**|**42**|**48**|**54**|**60**|**72**|
|**Protocolo**|**meses**|**meses**|**meses**|**meses**|**meses**|**meses**|**meses**|**meses**|**meses**|
|**Data**||||||||||
|**Coagulação**||||||||||
|**FVIII:C**||||||||||
|**Pesquisa de Inibidor**||||||||||
|**Quantificação**<br>**de**||||||||||
|<br>**Inibidor**||||||||||
|**TP (AP)**||||||||||
|**Hemograma**||||||||||
|**Hb**||||||||||
|**Ht**||||||||||
|**Leucócitos**||||||||||
|**Plaquetas**||||||||||  
|**Função hepática**||||||||||
|---|---|---|---|---|---|---|---|---|---|
|**AST/TGO**||||||||||
|**ALT/TGP**||||||||||
|**Função renal**||||||||||
|**Creatinina sérica**||||||||||
|**Sorologias**||||||||||
|**anti-HIV**||||||||||
|**anti-HCV**||||||||||
|**HBS:Ag**||||||||||
|**anti-HBs**||||||||||
|**anti-HBc**||||||||||
|**anti-HAV**||||||||||
|**Dias Sequencial do**<br>**Protocolo**|**84**<br>**meses**|**96**<br>**meses**|**108**<br>**meses**|**120**<br>**meses**|**132**<br>**meses**|**144**<br>**meses**|**156**<br>**meses**|**168**<br>**meses**|**180**<br>**meses**|
|**Data**||||||||||
|**Coagulação**||||||||||
|**FVIII:C**||||||||||
|**Pesquisa de Inibidor**||||||||||
|**Quantificação**<br>**de**||||||||||
|**Inibidor**||||||||||
|**TP (AP)**||||||||||
|**Hemograma**||||||||||
|**Hb**||||||||||
|**Ht**||||||||||
|**Leucócitos**||||||||||
|**Plaquetas**||||||||||
|**Função hepática**||||||||||
|**AST/TGO**||||||||||
|**ALT/TGP**||||||||||
|**Função renal**||||||||||
|**Creatinina sérica**||||||||||
|**Sorologias**||||||||||
|**anti-HIV**||||||||||
|**anti-HCV**||||||||||
|**HBS:Ag**||||||||||
|**anti-HBs**||||||||||
|**anti-HBc**||||||||||
|**anti-HAV**||||||||||
|**Dias Sequencial do**|**192**|**204**|**216**|||||||
|**Protocolo**|**meses**|**meses**|**meses**|||||||
|**Data**||||||||||
|**Coagulação**||||||||||
|**FVIII:C**||||||||||
|**Pesquisa de Inibidor**||||||||||
|**Quantificação**<br>**de**||||||||||
|**Inibidor**||||||||||
|**TP (AP)**||||||||||  
|**Hemograma**|
|---|
|**Hb**|
|**Ht**|
|**Leucócitos**|
|**Plaquetas**<br>|
|**Função hepática**|
|**AST/TGO**|
|**ALT/TGP**|
|**Função renal**|
|**Creatinina sérica**|
|**Sorologias**|
|**anti-HIV**|
|**anti-HCV**|
|**HBS:Ag**|
|**anti-HBs**|
|**anti-HBc**|
|**anti-HAV**|  
**APÊNDICE 11**  
CARTILHA PARA O PACIENTE E FAMÍLIA  
**1. O que é profilaxia primária em hemofilia?**  
A profilaxia primária em hemofilia refere-se ao tratamento de reposição com concentrado de fator VIII (para hemofilia A grave) ou IX (para hemofilia B grave) de forma frequente e de longo prazo. A PP deve ser iniciada imediatamente após ocorrência da primeira hemartrose ou hemorragia grave e antes dos 3 anos de idade.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **2. Quais são as vantagens da profilaxia primária?** -->
As principais vantagens da profilaxia primária são: (a) prevenir o desenvolvimento das complicações musculares e articulares da hemofilia, que podem levar a deformidades físicas muitas vezes definitivas; (b) reduzir outros sangramentos e (c) melhorar a qualidade de vida dos pacientes.  
A profilaxia primária é reconhecida e recomendada pela Organização Mundial da Saúde e  Federação Mundial de Hemofilia como o tratamento de eleição para a **<u>forma grave da hemofilia A e B.</u>**

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **3. Quem pode participar da profilaxia primária?** -->
Somente poderão participar da profilaxia primária os pacientes com **<u>hemofilia A ou B com a forma grave da doença (aqui consideramos como graves os pacientes com dosagem de fator VIII ou IX inferior a 2%)</u>** , com idade inferior a 3 anos incompletos. Pacientes com inibidor, que não estão respondendo ao concentrado de fator VIII ou fator IX, ou que apresentem reações alérgicas ao fator, não poderão participar, devido a contraindicação da profilaxia primária nestes pacientes.  
Os pacientes com hemofilia A e B grave com mais de 3 anos e com duas ou mais hemartroses devem ser incluídos na profilaxia secundária, que segue as mesmas orientações da profilaxia primária (converse com o médico do seu centro).  
Para que a criança seja incluída no tratamento de PP será necessário avaliação favorável da equipe multiprofissional do Centro de Tratamento de Hemofilia (médico, enfermeira, assistente social e psicóloga). Ainda, será necessário treinamento para infusão do concentrado de fator de coagulação que pode ser infundido em casa (em veia periférica ou por cateter venoso central).

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **4. Em que consiste o tratamento da profilaxia primária?** -->
Consiste na infusão do concentrado de fator VIII (para hemofilia A grave) ou IX (para hemofilia  B grave) profilaticamente, isto é, independentemente de o paciente ter tido qualquer sangramento. Inicialmente, todos os pacientes receberão o concentrado de fator VIII ou IX uma a duas vezes na semana. Esta frequência poderá ser aumentada, na dependência da frequência da ocorrência de sangramentos. Por isso, é fundamental o acompanhamento do médico do centro, especialmente nos primeiros meses após início da PP.

---

<!-- METADADOS: doenca: Profilaxia primária em caso de Hemofilia Grave | secao: **5. Como será feito o acompanhamento do tratamento?** -->
O paciente em tratamento de profilaxia primária deverá ser avaliado frequentemente pela equipe multiprofissional do Centro de Tratamento de Hemofilia (CTH), em especial nos primeiros meses do início da PP. Durante a PP, alguns testes deverão ser realizados com freqüência, em especial o teste de dosagem do inibidor. As consultas e orientações devem ser rigorosamente seguidas pelo paciente/responsável.  
O paciente/responsável deverá preencher uma ficha de uso do concentrado de fator de coagulação  mediante infusão do produto em casa. A cada visita médica, o paciente deverá trazer a ficha devidamente preenchida com todas as informações solicitadas. Caso o tratamento seja realizado na casa do paciente, ele deverá retornar ao Centro de Tratamento de Hemofilia  
os frascos vazios dos concentrados de fator, assim como equipo, agulhas e seringas usadas.  
**6. O que deve ser feito para o sucesso do tratamento?**  
Para que o tratamento tenha sucesso, o paciente deverá seguir o tratamento tal como recomendado pela equipe multiprofissional, ter acompanhamento médico frequente, comparecer a todas as consultas agendadas e realizar os testes solicitados. O paciente e seus familiares devem seguir rigorosamente todas as orientações dadas por seu médico e equipe multiprofissional.  
É essencial a participação e envolvimento do paciente e de sua família. Em caso de dúvida deve-se contatar o Centro de Tratamento de Hemofilia.  
**7. Quais são os riscos da profilaxia primária para o paciente?**  
Os riscos da profilaxia primária são os mesmos do tratamento sob demanda (que é a infusão do concentrado após o sangramento) já oferecido aos pacientes com hemofilia. Estes são: possibilidade de desenvolvimento de inibidor, possibilidade de contaminação com agentes infecciosos transmissíveis pelos concentrados de fator de coagulação (embora não exista relato de contaminação pelos concentrados nos últimos 20 anos) e reação alérgica ao produto infundido. Ainda, devido a frequência de infusões, o paciente pode necessitar da instalação de cateter venoso central caso o acesso de veias periféricas fique dificultado.Em caso de dúvida converse com seu médico do Centro de Tratamento de Hemofilia.

---

