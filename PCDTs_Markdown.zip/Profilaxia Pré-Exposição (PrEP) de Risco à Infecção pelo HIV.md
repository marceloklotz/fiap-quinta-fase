<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: Geral -->
<!-- Start of picture text -->
x<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **PORTARIA SECTICS/MS Nº 55, DE 14 DE NOVEMBRO DE 2024** -->
Torna pública a decisão de atualizar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia PréExposição (PrEP) Oral à Infecção pelo HIV.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica atualizado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) Oral à Infecção pelo HIV.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 3º Fica revogada a Portaria SCTIE/MS nº 90, de 25 de agosto de 2022, publicada no Diário Oficial da União nº 165, de 30 de agosto de 2022, Seção 1, pág. 258.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **INTRODUÇÃO** -->
A Profilaxia Pré-Exposição (PrEP, do inglês _Pre-Exposure Prophylaxis)_ atualmente disponível no Sistema Único de Saúde (SUS) consiste no uso oral de antirretrovirais em dose fixa combinada (tenofovir/entricitabina) para reduzir o risco da transmissão do vírus da imunodeficiência adquirida (HIV).  
No Brasil, dados epidemiológicos indicam que os novos casos de aids se concentram, majoritariamente, entre a população jovem (15 a 24 anos). Verifica-se também o aumento das notificações da infecção pelo HIV entre pessoas pretas e pardas, que representam mais da metade dos casos registrados a partir de 2015, demonstrando a importância de ações específicas para essas populações. Nesse contexto, este documento atualiza recomendações clínicas sobre a PrEP oral, com vistas a qualificar o cuidado e ampliar a oferta da profilaxia no país.  
A expansão da oferta de PrEP tem como objetivo reduzir a transmissão do HIV e contribuir para o alcance da meta do Ministério da Saúde (MS) de eliminar a epidemia de aids como um problema de saúde pública até 2030. Para alcançá-la, é necessário, dentre outras medidas, ampliar de forma equitativa o acesso aos serviços de saúde pelas populações em contexto de vulnerabilidade acrescida para aquisição do HIV.  
Neste sentido, a atualização e as revisões clínicas deste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) também visam a simplificar o cuidado em PrEP e sua expansão no contexto do SUS. Ademais, o MS tem orientado a rede de serviços a diversificar as modalidades de oferta da profilaxia, de modo a incluir a Atenção Primária à Saúde (APS), os serviços de teleatendimento (“TelePrEP”), a oferta da profilaxia em ações extramuros, dentre outras iniciativas que venham a ser organizadas e propostas pela gestão local.  
As principais atualizações deste PCDT são (Material Suplementar):  
- Possibilidade de utilização do autoteste de HIV para seguimento clínico da PrEP e início de PrEP por meio de teleatendimento;  
- Disponibilização pelo SUS e indicação da vacina contra papilomavírus humano (HPV) para usuários de PrEP;  
- Dosagem de creatinina para início e manutenção da PrEP;  
- Tempo necessário para proteção segura da PrEP;  
- Oferta da modalidade “sob demanda” da PrEP oral para grupos específicos;  
- Tempo necessário para interrupção segura de PrEP;  
- Ampliação entre os intervalos das consultas para até 120 dias.  
Ressalta-se que, desde a versão publicada em 2022, o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de PrEP preconiza que a profilaxia não tem indicação restrita às populações chave. Assim, a PreP pode ser indicada para todas as pessoas a partir de 15 anos, com peso corporal igual ou superior a 35 kg e que estejam em contexto de vulnerabilidade para a aquisição da infecção pelo HIV. Para que essa estratégia seja efetiva, é necessário que a rede de saúde remova as barreiras de acesso a essas populações, de modo a acolhê-las na sua integralidade e individualidade, na garantia de seus direitos à saúde de qualidade.  
Este documento respalda a prescrição da PrEP exclusivamente por profissional médico no âmbito do sistema de saúde privada e, no âmbito do SUS, por todos os profissionais de saúde legalmente habilitados à prescrição de medicamentos.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **METODOLOGIA** -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as  
2  
tecnologias que se encontram disponíveis no SUS para a PrEP oral. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: 3. **PREVENÇÃO COMBINADA** -->
O termo “prevenção combinada” remete à conjugação de diferentes ações de prevenção às Infecções Sexualmente Transmissíveis (IST), ao HIV e às hepatites virais e seus fatores associados<sup>1,2</sup> . Como o próprio nome sugere, a prevenção combinada envolve o uso “combinado” de métodos preventivos, de acordo com as possibilidades e escolhas de cada indivíduo, sem excluir ou sobrepor um método ao outro.  
A PrEP é uma das formas de prevenir a infecção pelo HIV no contexto das estratégias de prevenção combinada disponíveis no SUS. Dentro do conjunto de ferramentas da prevenção combinada às IST, ao HIV e às hepatites virais, também se inserem:  
- Testagem regular para a infecção pelo HIV e outras IST;  
- Profilaxia Pós-Exposição ao HIV (PEP);  
- Uso de preservativos e gel lubrificante;  
- Diagnóstico oportuno e tratamento adequado da sífilis e outras IST;  
- Redução de danos;  
- Gerenciamento de risco e vulnerabilidades;  
- Terapia Antirretroviral para todas as pessoas vivendo com HIV/aids (PVHA):  
- Indetectável = Risco zero de transmissão do HIV<sup>3</sup> ;  
- Imunizações (vacinas para hepatite A, hepatite B e papilomavírus humano);  
- Prevenção da transmissão vertical do HIV, da sífilis, da hepatite B e do HTLV;  
- Testagem de HPV oncogênico para o rastreamento do câncer de colo de útero.  
A oferta das estratégias de prevenção combinada deve ser centrada nas pessoas, levando em consideração seus contextos sociais.  
A **Figura** 1 representa a combinação e a ideia de movimento de algumas das diferentes estratégias de prevenção.  
<!-- Start of picture text -->
ae<br>oe<br>o8ee AVE. x<br>sss? cl &<br>oft! fy + we<br>a ,<br>&.22%2 BEM](ESM PREvencioCOMBINADA : 523i<br>‘<br>% °<br>ay Reducio. Aa<br><!-- End of picture text -->  
Figura 1: Mandala da Prevenção Combinada Fonte: DATHI/SVSA/MS.  
3  
Para mais informações sobre as estratégias de prevenção combinada, consultar:  
|**“Prevenção Combinada do HIV: Bases**<br>**trabalhadores**<br>**e**<br>**gestores**|**concei**<br>**de**|**tuais para**<br>**saúde”**<sup>2</sup>|
|---|---|---|
|https://www.gov.br/aids/pt-br/centrais-de-<br>conteudo/publicacoes/2017/prevencao_combinada_-<br>_bases_conceituais_web.pdf/view|||  
<!-- Start of picture text -->
OR ate O)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: 4, **PrEP 4.1. Eficácia e segurança da PrEP** -->
A eficácia e a segurança da PrEP já foram demonstradas em diversos estudos clínicos e segmentos populacionais, bem como em estudos demonstrativos<sup>3–8</sup> .  
O estudo iPrEx avaliou a PrEP oral diária em homens cisgênero que fazem sexo com homens (HSH) e mulheres trans e concluiu que, com seu uso, houve uma redução de 44% no risco de aquisição de HIV, podendo alcançar uma redução de 95% na incidência do HIV em participantes com boa adesão.<sup>3</sup> Entre pessoas cisgênero heterossexuais, a eficácia geral da PrEP foi de 62% no estudo TDF2, sendo de 49% entre as mulheres e 80% entre os homens incluídos<sup>4</sup> . Recente revisão sistemática que avaliou a relação entre adesão e efetividade da PrEP em mulheres cis demonstrou que ,com adesão consistente (7 comprimidos/semana), não houve casos de HIV; para adesão consistentemente alta (4 a 6 doses/semana), a incidência de HIV foi apenas 13% mais alta.<sup>9</sup> Entre usuários de drogas injetáveis (UDI), o estudo Bangkok Tenofovir mostrou uma redução de 49% no risco de infecção pelo HIV.<sup>6</sup>  
No estudo PROUD, que avaliou o uso aberto de PrEP em HSH com risco de infecção pelo HIV, observou-se 86% de eficácia da intervenção.<sup>10</sup>  
A eficácia e segurança da PrEP sob demanda também foram avaliadas no estudo IPERGAY, isto é, com uso do medicamento antes e após a exposição, em vez do tradicional esquema de uso diário/contínuo. Nesse cenário, observou-se redução de 86% no risco de aquisição do HIV, mesmo com uso de menor quantidade mensal de comprimidos.<sup>11</sup>  
Em pessoas com infecção crônica pelo vírus da hepatite B (HBV), os estudos realizados até o momento indicam que a PrEP pode ser utilizada com segurança<sup>12</sup> . Não foi observada recidiva clínica nos ensaios que incluíram pessoas com infecção crônica por hepatite B<sup>3,13</sup> . Para usuários com HBV crônica e sem indicação de tratamento antiviral, o uso e a interrupção da PrEP apresentam um baixo risco de reativação inflamatória hepática grave (hepatite fulminante). Nesses casos, para prescrição da PrEP, recomenda-se ponderar a chance de o paciente adquirir o HIV e o fato de o risco de ocorrer hepatite fulminante ser baixo.<sup>14,15</sup>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **4.2. Critérios de indicação 4.2.1. Epidemiologia do HIV** -->
A taxa de detecção de aids em jovens de 20 a 24 anos e de 25 a 29 anos apresentou crescimento entre os anos de 2012 a 2022<sup>17</sup> . Desde 2017, os indivíduos entre 25 a 29 anos vêm apresentando as maiores taxas de detecção de aids, tendo atingido o patamar de 54,4 casos para cada 100 mil. Em 2022, a ocorrência de novas infecções pelo HIV em mulheres em idade reprodutiva, de 15 a 49 anos, representou 78,3% do total do sexo feminino, sendo importante o planejamento reprodutivo, a oferta da testagem, de profilaxia ou tratamento precoce<sup>16</sup> . Quando avaliada a variável raça/cor, observa-se que, a partir de 2015, a infecção pelo HIV em pessoas pretas e pardas passou a representar mais da metade dos casos.  
Estudos nacionais demonstram que alguns grupos populacionais são desproporcionalmente mais atingidos, quando comparados à população brasileira geral. A taxa de prevalência de HIV entre mulheres cis profissionais do sexo é de 5,3%<sup>17</sup> , entre pessoas que usam drogas (exceto álcool e maconha)<sup>18</sup> de 5,9%, entre gays e HSH, de 18,4%<sup>19</sup> e de 31,2%, entre mulheres trans e travestis<sup>20</sup> . Ainda, em um estudo representativo para o país com pessoas que  
4  
usam crack e similares, foi verificada uma prevalência de 5% de infecção pelo HIV. Entretanto, no recorte entre mulheres e homens desse mesmo estudo, constataram-se prevalências de 8% e 4%, respectivamente<sup>21</sup> .Esses grupos, por vezes, demonstram vulnerabilidades específicas acrescidas, que são influenciadas por processos históricos de estigmatização e marginalização social. Diante das diversas realidades sociais, existem barreiras no acesso ao serviço de saúde com a finalidade de obter a prevenção, testagem e tratamento, resultando na exclusão desses grupos do direito à saúde.  
Assim, esses dados demonstram a importância de políticas públicas intersetoriais direcionadas às pessoas em situação de maior vulnerabilidade para a infecção pelo HIV, buscando romper barreiras de acesso relacionadas, principalmente, ao estigma e a discriminação.  
**Contextos de vulnerabilidade acrescida para a aquisição da infecção pelo HIV**  
O simples pertencimento a um dos segmentos populacionais-chave que apresentam maior prevalência de HIV em relação à população geral – homens cis gays, mulheres trans e travestis, trabalhadores(as) do sexo e pessoas que usam drogas – não é suficiente para caracterizar indivíduos em situação de maior vulnerabilidade ao HIV.  
A prevalência de HIV é também fortemente determinada por fatores sociais, como por exemplo, a vivência de situações de homofobia, transfobia, racismo, sexismo e outras formas de violência e vulnerabilização social<sup>22,23</sup> . De maneira ampla, os determinantes sociais da saúde contemplam **elementos demográficos, etários, econômicos, educacionais e culturais**<sup>24</sup> . Assim, por uma sinergia de diversos fatores que levam à “invisibilidade” ou à marginalização social, esses grupos populacionais encontram diversos obstáculos para acessar ações e serviços de saúde para prevenção, diagnóstico e tratamento do HIV, contribuindo ainda mais a sua situação de vulnerabilidade.  
No contexto das vulnerabilidades sociais acima destacadas, algumas práticas sexuais apresentam maior chance para a aquisição do vírus. O **Quadro 1** indica a probabilidade estimada da infecção pelo HIV segundo o tipo de exposição.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: Quadro 1: Exposição ao HIV <u>e probabilidade de infecção pelo HIV</u> -->
||**Exposição**|**Probabilidade**<br>**por 10.000**<br>**exposições**|
|---|---|---|
|Sexual|Sexo anal receptivo (ser penetrado(a) no<br>ânus)|138|
||Sexoanal insertivo (penetraroânus)|11|
||Sexo vaginal receptivo (ser penetrada na<br>vagina)|8|
||Sexo vaginal insertivo(penetrar a vagina)|4|
||Sexo oral (receptivo ou insertivo)|Baixa<br>probabilidade|
|Outras|Mordedura, saliva, compartilhamento de<br>fluidos corporais e de brinquedos sexuais|Baixa<br>probabilidade|
|Parenteral|Compartilhamento de agulha contaminada<br>(usuários de drogas injetáveis)|63|  
Fonte: Adaptado de PATEL et al., 2014.<sup>25</sup>  
As práticas sexuais consideradas como de baixa probabilidade para a infecção pelo HIV, quando repetidas frequentemente, podem apresentar maior probabilidade de aquisição da infecção.<sup>25</sup>  
Da mesma forma, pessoas que buscam a **profilaxia pós-exposição (PEP) de maneira repetida (mais de uma vez nos últimos doze meses) sinalizam exposição ao vírus do HIV** e a procura por uma estratégia de profilaxia biomédica, sendo uma oportunidade para a oferta de PrEP.  
5  
A avaliação da elegibilidade para o uso da PrEP deve considerar práticas e parcerias sexuais, dinâmica social e os contextos específicos que podem colocar o indivíduo em situação de maior vulnerabilidade para infecção pelo HIV.  
A **presença de outras IST também pode indicar maior vulnerabilidade** para a transmissão do HIV. Estudos demonstram que pessoas com IST e infecções não ulcerativas do trato geniturinário têm um risco aumentado em três a dez vezes para a infecção pelo HIV, com incremento de 18 vezes na presença de úlceras genitais<sup>26</sup> .  
O consumo de álcool e outras drogas no contexto sexual frequentemente tem impacto na utilização de medidas preventivas no momento da prática sexual e estão associados ao aumento do risco de infecção por HIV. Também conhecido como **“sexo químico” (chemsex), a prática sexual sob a influência de drogas psicoativas** (metanfetaminas, gama-hidroxibutirato – GHB, MDMA, cocaína, poppers) tem sido usada com a finalidade de melhorar ou facilitar as experiências sexuais e é um indicativo de vulnerabilidade para o HIV<sup>27,28</sup> _._  
É importante destacar que PVHA e que mantém carga viral do **HIV INDETECTÁVEL** , ou menor que 200 cópias/mL há mais de 6 meses, **apresentam risco zero de transmissão do HIV por via sexual**<sup>29</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **CRITÉRIOS DE ELIGIBILIDADE 5.1. Critérios de inclusão** -->
A PrEP pode ser indicada para pessoas a partir de 15 anos, com peso corporal igual ou superior a 35 kg, sexualmente ativas e que apresentem contextos de vulnerabilidade acrescida para a aquisição da infecção pelo HIV.  
Para essa indicação, a avaliação de exposições ao HIV deve ser individualizada e considerar as práticas e parcerias sexuais da pessoa, a sua dinâmica social e os contextos específicos associados a maior vulnerabilidade.  
Assim, devem também ser considerados os seguintes indicativos:  
- Solicitação ou desejo de usar PrEP;  
- Repetição de práticas sexuais anais ou vaginais com penetração sem uso ou com  
- uso inconsistente de preservativo;  
- Frequência de relações sexuais com parcerias eventuais;  
- Quantidade e diversidade de parcerias sexuais;  
- Histórico de episódios de IST;  
- Busca repetida por PEP;  
- Parceiro (a)(s) vivendo com HIV com carga viral detectável;  
- Contextos de relações sexuais em troca de dinheiro, objetos de valor, drogas,  
- moradia, dentre outros;  
- Sexo químico _(chemsex)_ ;  
- Compartilhamento de agulhas, seringas ou outros equipamentos para injetar  
- drogas;  
- Parcerias com situação desconhecida sobre o HIV-1 e que apresente qualquer um  
- dos fatores acima.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **5.1.2. PrEP para adolescentes** -->
Para os adolescentes com mais de 15 anos, deve-se garantir o acesso aos serviços, orientações e consultas de saúde sem a necessidade de presença ou autorização de pais ou responsáveis, com direito à privacidade e sigilo, salvo em situações de necessidade de internação ou de risco de vida, conforme o Estatuto da Criança e Adolescente<sup>30</sup> . Para mais informações sobre o tema, consultar a Nota **Técnica vigente.**  
Ressalta-se que o código de ética médica, em seu capítulo IX (sigilo profissional), artigo 103, estabelece que é vedado ao médico: “Revelar segredo profissional referente a paciente menor  
6  
de idade, inclusive a seus pais ou responsáveis legais, desde que o menor tenha capacidade de avaliar seu problema e de conduzir-se por seus próprios meios para solucioná-lo, salvo quando a não revelação possa acarretar danos ao paciente”.<sup>31</sup>  
A PrEP oral pode ser indicada para pessoas acima de 15 anos e 35 kg ou mais e não é necessário o consentimento dos pais e/ou responsáveis, desde que a pessoa tenha compreensão da profilaxia e seu acompanhamento. Para os(as) usuários(as) com indicação de PrEP sob demanda, deve-se verificar a capacidade de compreensão de uso do esquema.  
Saliente-se alguns aspectos importantes a serem abordados no acompanhamento de adolescentes<sup>32</sup> :  
- Avaliar a necessidade de consultas de acompanhamento mais frequentes e  
- utilização de meios remotos de acompanhamento (lembretes por mensagens de celular ou teleatendimento);  
- Horário de atendimento flexível;  
- Profissionais de saúde acessíveis e abordagem sem julgamento;  
- Informações sobre dúvidas e receios sobre a experiência sexual;  
- Acesso a serviços adicionais, como testes de gravidez, contracepção, saúde  
- mental, uso de substâncias e apoio social.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **5.1.3. PrEP durante a concepção, gestação e aleitamento** -->
Estudos demonstram que mulheres HIV negativas, com desejo de engravidar de parceiro vivendo com HIV ou com frequentes situações de potencial exposição ao HIV, podem se beneficiar do uso de PrEP de forma segura, ao longo da gravidez e amamentação, para proteger a si mesmas e ao bebê.<sup>33</sup>  
Em estudos clínicos com casais heterossexuais adultos, a PrEP se mostrou segura e eficaz em reduzir a infecção pelo HIV<sup>4,5</sup> . Durante esses ensaios, nenhum problema de saúde foi observado em mulheres em uso de PrEP no início da gestação ou em recém-nascidos.  
Sabe-se que o risco da infecção pelo HIV aumenta durante a gestação<sup>34</sup> , assim como também é maior o risco de transmissão vertical do HIV quando a infecção pelo HIV acontece durante a gravidez ou aleitamento<sup>35</sup> . Portanto, a PrEP pode ser indicada como uma estratégia de prevenção para gestantes sob alto risco de infecção pelo HIV.  
Recomenda-se que, para casais sorodiferentes, a PVHA esteja em tratamento antirretroviral e com carga viral indetectável durante o período de planejamento reprodutivo. Nos casos de parcerias com carga viral detectável acima de 200 cópias/mL<sup>36</sup> , desconhecida ou não documentada, a PrEP está recomendada<sup>37</sup> .  
Para mais informações, consultar o “PCDT para a Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais”<sup>1</sup> (PCDT-TV), disponível em <u>https://www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts,</u> https://www.gov.br/conitec/pt-br/assuntos/avaliacao-detecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas e https://www.gov.br/saude/pt-br/assuntos/pcdt.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **5.2. Critérios de exclusão** -->
Serão excluídas da possibilidade de uso da PrEP as pessoas que apresentarem as seguintes contraindicações ao se uso:  
- Resultado de teste de HIV reagente;  
- _Clearance_ de creatinina (ClCr) estimado abaixo de 60 mL/minuto.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **AVALIAÇÃO CLÍNICA E LABORATORIAL INICIAL** -->
A análise dos critérios de elegibilidade para PrEP deve ocorrer dentro de uma relação de vínculo e confiança entre a pessoa e o profissional de saúde, que permita compreender as  
7  
vulnerabilidades envolvidas nas práticas sexuais, assim como as condições objetivas de adesão ao uso do medicamento.  
Na consulta inicial, os profissionais devem abordar e avaliar:  
- Aspectos sobre o gerenciamento de risco e vulnerabilidades;Entendimento e  
- motivação para o início da PrEP;  
- Indicação de PEP, se houve exposição de risco nas últimas 72 horas;  
- Sinais e sintomas para exclusão da infecção aguda pelo HIV;  
- Histórico e fatores de risco para doença renal;  
- Testagem e tratamento de outras IST.  
Além disso, na primeira consulta, deve-se realizar os procedimentos e exames elencados no **Quadro 2** .  
<u>Quadro 2: Elementos da primeira consulta.</u>  
|**Exames**|**Método**|
|---|---|
|Teste para HIV|Pesquisa de anticorpos anti-HIV [Imunoensaio laboratorial ou teste<br>rápido(TR), preferencialmente] <sup>(a,b)</sup>|
|Teste para sífilis|Pesquisa de anticorpos treponêmicos (ex.: imunoensaio laboratorial<br>ou TR, preferencialmente,) ou não treponêmicos (ex.: VDRL, RPR,<br>TRUST) <sup>(c)</sup>|
|Identificação de outras<br>IST<br>(clamídia<br>e<br>gonococo)|Pesquisa do material genético em amostra de urina, secreção genital,<br>anorretal ou orofaríngea (escolher amostra de acordo com prática<br>sexual e metodologia disponível na rede local) <sup>(c)</sup>|
|Teste para hepatite B<sup>(b)</sup>|Pesquisa de HBsAg (ex.:Imunoensaio laboratorial ou TR,<br>preferencialmente)e anti-HBcT|
|Teste para hepatite C|Pesquisa de anticorpos anti-HCV (ex.:Imunoensaio laboratorial ou<br>TR, preferencialmente)|
|Função renal<br>**Outrosprocedimentos**|Dosagem de creatinina sérica e ClCr,conforme faixa etária|
|Vacinaçãopara hepatite|B<sup>(e)</sup>,hepatite A e HPV|
|Avaliação do histórico d|e fraturaspatológicas|  
**Fonte** : DATHI/SVSA/MS  
**Legenda** : TR: teste rápido, VDRL: _Venereal Disease Research Laboratory_ RPR: _Rapid Plasm Reagin_ , TRUST: _Toluidine Red Unheated Serum Test_ ; IST: Infecção Sexualmente Transmissível; HBsAg: antígeno de superfície da Hepatite B; anti-HBcT: anticorpos totais contra o “core” (núcleo) do vírus da Hepatite B;  HCV: vírus da hepatite C, HPV: Papilomavírus Humano, Clearance de creatinina (ClCr) a Para teleatendimento, o autoteste de HIV pode ser utilizado. Para mais informações, consultar **NT vigente.**  
b O teste deve ser realizado utilizando amostra de sangue total, soro ou plasma.  
c Em pessoas com diagnóstico prévio de sífilis, a investigação diagnóstica deve ocorrer com teste não treponêmico.  
d Para mais informações, consultar o Informe técnico sobre a Rede Nacional de Laboratórios de <u>Biologia Molecular para Detecção de Clamídia e Gonococo no SUS.</u><sup>38</sup>  
e Nas pessoas vacinadas para HBV, avaliar a soroconversão (Anti-HBs) na consulta de retorno. Na presença de anti-HBs ≥ 10 UI/mL, não há necessidade de repetir os exames para hepatite B.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.1. Abordagem de gestão de risco e vulnerabilidades** -->
A partir do conhecimento das alternativas de estratégias de prevenção, deve-se conversar com o indivíduo sobre a possibilidade de **realizar o gerenciamento de risco de acordo com suas práticas sexuais e contextos de vida** . Tal abordagem reconhece que as escolhas são feitas a partir de diferentes pertencimentos culturais, inserções comunitárias e histórias de vida, que influenciarão a adoção dos métodos de prevenção. É papel do profissional de saúde oferecer orientações centradas na pessoa e em suas práticas sexuais, com o intuito de ajudá-la a reconhecer  
8  
e escolher a forma de prevenção que considerar mais apropriada para sua saúde sexual e seu momento de vida.  
Para auxiliar no reconhecimento e no gerenciamento do risco, os profissionais de saúde devem praticar a escuta ativa e a promoção de um ambiente favorável ao diálogo sobre sexualidade, desejos e prazer sem preconceitos ou julgamentos pessoais, possibilitando que a própria pessoa encontre soluções para suas questões. Essa abordagem favorece o vínculo e facilita a adesão à prevenção combinada. O diálogo deve considerar a experiência do usuário com outros métodos de prevenção, suas práticas sexuais, tipo e frequência das parcerias sexuais, histórico de saúde sexual e reprodutiva e contextos de vulnerabilidade e de exposição ao HIV e outras IST.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.2. Avaliação do entendimento e motivação para o início da PrEP** -->
A pessoa candidata ao uso da PrEP deve compreender a estratégia e como ela se insere no contexto do gerenciamento de risco e vulnerabilidades. Também deve ser explicado a ela que a PrEP é um método seguro e eficaz na prevenção do HIV, com raros eventos adversos, os quais, quando ocorrem, são transitórios e podem ser controlados clinicamente<sup>11,35</sup> .  
A efetividade da PrEP está diretamente relacionada ao grau de adesão à profilaxia. O uso conforme prescrição do medicamento é fundamental para a proteção contra o HIV<sup>7,39</sup> . Portanto, o usuário deve ser orientado a usar os medicamentos conforme a prescrição, assegurando assim a efetividade da prevenção.  
A consulta para oferta de PrEP também deve ser uma oportunidade para que os usuários possam se beneficiar de outras ações em saúde, como vacinação para hepatite B, hepatite A e HPV e para prevenção e tratamento precoce, quando necessário, da sífilis e demais IST.  
Deve-se enfatizar que o uso de PrEP não previne a sífilis e demais IST ou as hepatites virais, sendo necessário, portanto, orientar a pessoa sobre outras formas de prevenção, tais como: higienização das mãos, genitália, períneo e região anal antes e depois das relações sexuais, uso de preservativos durante as práticas sexuais oral, vaginal e anal; uso de luvas de látex para dedilhado ou “ _fisting_ ”; higienização de vibradores, _plugs_ anais e vaginais e outros acessórios.  
Estudos demonstrativos indicam que a PrEP é significativamente mais protetora quanto menor o tempo de espera do usuário para início da profilaxia<sup>10,40</sup> . Portanto, orienta-se que os profissionais de saúde prescritores não percam a oportunidade de ofertar a profilaxia no mesmo dia da consulta e da realização da testagem.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.3. Testagem para HIV** -->
Para a indicação do uso da PrEP, deve-se excluir a presença da infecção pelo HIV, por meio da avaliação clínica do usuário e da realização de testagem. Recomenda-se, preferencialmente, a realização de teste rápido (TR1) anti-HIV, utilizando amostra de sangue total, obtida por punção digital ou por punção venosa, soro ou plasma (de acordo com a indicação na instrução de uso do teste utilizado).  
A testagem deverá seguir um dos fluxogramas definidos no “Manual Técnico para o Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>41</sup> , disponível em: https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-para-diagnostico. Caso o TR anti-HIV seja reagente, deve-se realizar um segundo teste rápido (TR2) diferente do primeiro, de acordo com o fluxograma do “Manual Técnico para o Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>41</sup> . Se o TR2 também for reagente, a amostra deve ser considerada como “reagente para HIV” e, nesse caso, a PrEP não está indicada.  
Nos casos em que os TR1 e TR2 apresentarem resultados discordantes, deve-se repetir o fluxograma completo de diagnóstico com os mesmos conjuntos diagnósticos já utilizados e na mesma ordem. Persistindo a discordância entre os resultados, uma amostra deve ser colhida por punção venosa e enviada ao laboratório para ser submetida a um dos fluxogramas de diagnóstico definidos para laboratório no “Manual Técnico para Diagnóstico da Infecção pelo HIV em Adultos e Crianças”. Nesse caso, será necessário aguardar o resultado da análise laboratorial para indicação da PrEP ou da terapia antirretroviral (TARV)<sup>41</sup> .  
9  
Caso os testes rápidos realizados com amostras de sangue total, soro ou plasma não estejam disponíveis, poderão ser utilizados exames laboratoriais para o rastreamento da infecção pelo HIV.  
Além disso, o autoteste de HIV (fluido oral ou sangue) pode ser utilizado para a primeira dispensação da PrEP oral para usuários no contexto do teleatendimento.<sup>93</sup>  
No atendimento presencial em ações extramuros, o autoteste de HIV também pode ser utilizado para oferta da profilaxia<sup>93,94</sup> , facilitando o acesso de populações em situação de maior vulnerabilidade.  
O usuário tem até 7 dias após realização do teste anti-HIV para retirar a PrEP na Unidade Dispensadora de Medicamento (UDM), preferencialmente o mais breve possível. Nos casos em que o usuário chegar à UDM após esse prazo ou sem o resultado do exame preenchido no formulário, a testagem de HIV precisará ser refeita, podendo ser utilizado o autoteste de HIV nessa situação, com o objetivo de não atrasar a dispensação da PrEP.  
A janela imunológica para imunoensaios que detectam anticorpos contra o HIV pode variar entre 30 a 120 dias contados a partir do momento da infecção, a depender da metodologia e de condições imunológicas inerentes aos indivíduos testados. O autoteste de HIV apresenta as mesmas características quanto à capacidade de detecção da infecção aguda, quando comparado ao uso de testes rápidos executados por profissionais de saúde ou em ambiente laboratorial.  
Os autotestes de HIV são capazes de detectar a presença de anticorpos anti-HIV em amostras de sangue total ou fluido oral e apresentam sensibilidade e especificidade similares em relação aos testes rápidos de HIV executados por profissionais da saúde no âmbito do SUS<sup>42–44</sup> .  
Em caso de resultado reagente em um autoteste de HIV, deve-se utilizar o fluxograma completo (dois ou mais testes) para diagnóstico da infecção pelo HIV, conforme preconizado no “Manual Técnico para Diagnóstico da Infecção pelo HIV em Adultos e Crianças”, não sendo o autoteste considerado como parte do fluxograma do diagnóstico.  
Para mais detalhes sobre métodos diagnósticos de infecção pelo HIV, consultar:  
“Manual Técnico para o Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>41</sup> , disponível em: <u>https://www.gov.br/aids/pt-br/central-deconteudo/manuais-tecnicos-para-diagnostico</u>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.4. Exclusão de infecção viral aguda pelo HIV** -->
Em paralelo à investigação por meio da testagem para HIV, recomenda-se avaliar ativamente, em todas as consultas de PrEP, a ocorrência de exposição de risco prévia e/ou a presença ou relato das últimas quatro semanas de sinais e sintomas inespecíficos de infecção viral, que podem ser indicativos de infecção viral aguda pelo HIV.  
Após a transmissão do HIV, alguns indivíduos costumam apresentar quadro clínico semelhante a uma síndrome de mononucleose infecciosa ou a uma síndrome gripal, geralmente entre a segunda e a quarta semana após a exposição. Os sinais e sintomas descritos no **Quadro 3** costumam ser autolimitados e a maior parte desaparece entre três a quatro semanas.  
10  
**Quadro 3** . Sinais e sintomas da infecção agudam pelo HIV  
|Febre|
|---|
|Mal-estar|
|Cefaleia|
|Fadiga|
|Faringite|
|Exantema|
|Linfadenopatia cervical/submandibular/axilar|
|Mialgias ou artralgias|
|Ulcerações mucocutâneas|
|Hepatoesplenomegalia|  
Fonte: DATHI/SVSA/MS.  
Na suspeita clínica da infecção aguda pelo HIV, com ausência de marcadores imunológicos, deve-se realizar o exame de carga viral do HIV, a fim de reduzir o período de janela diagnóstica. Nesse caso, o início da PrEP deve ser postergado até a definição diagnóstica.  
Pessoas com exposição de risco recente, sobretudo nos últimos 30 dias, devem ser orientadas quanto à possibilidade de infecção, mesmo com resultado não reagente nos testes realizados<sup>45,46</sup> .  
Caso seja confirmada a infecção pelo HIV, a PrEP não está mais indicada. Nesse caso, a TARV deverá ser iniciada **.**  
Os indivíduos que tiveram uma exposição recente de risco, fora da janela de 72 horas para o início de PEP, e que se apresentam durante a avaliação inicial sem sinais e sintomas de infecção pelo HIV e com TR não reagente para HIV podem iniciar imediatamente a PrEP. A espera pela garantia de que essas pessoas estejam fora do período da janela imunológica pode levar a exposições adicionais e atraso no início da profilaxia. Sugere-se orientar o usuário a retornar à unidade de saúde caso haja presença de sinais e/ou sintomas de infecção aguda pelo HIV.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.5. Avaliação da indicação de PEP** -->
Para os usuários que buscarem a PrEP e que tenham relatado potencial exposição ao HIV dentro das últimas 72 horas, recomenda-se a avaliação para início imediato da PEP, de acordo com o disponível em:  
<!-- Start of picture text -->
Protocolo Clínico e Diretrizes Terapêuticas para<br>Profilaxia Pós Exposição (PEP) de risco à infecção<br>pelo HIV, IST e Hepatites Virais”<br>Disponível em: https://www.gov.br/aids/pt-<br>br/central-de-conteudo/pcdts<br><!-- End of picture text -->  
<!-- Start of picture text -->
OREO<br>dears!<br>Genie<br><!-- End of picture text -->  
As PEP ao HIV, hepatites virais, sífilis e outras IST consistem no uso de medicamentos para reduzir o risco de adquirir essas infecções, após potencial exposição de risco.  
Pessoas que repetidamente procuram a PEP também devem ser avaliadas para o uso da PrEP. Nesse contexto, a PrEP pode ser iniciada logo após a conclusão dos 28 dias da PEP, evitando uma lacuna desnecessária entre a PEP e a PrEP. Deve-se realizar um teste rápido ou sorologia para HIV (sangue) nessa transição, assim como os demais exames laboratoriais indicados no início da PrEP ( **Quadro 2** ), caso ainda não tenham sido realizados durante o ciclo da PEP.  
11  
Indivíduos com indicação momentânea de PEP podem ser futuros candidatos à PrEP.  
Usuários com boa adesão ao esquema de PrEP diária, com uso regular dos comprimidos, após alcançados os níveis protetores do medicamento, não necessitam de PEP após uma exposição sexual de risco ao HIV. Já para aqueles que relatam o uso esporádico ou irregular da PrEP, com adesão repetidamente abaixo do ideal, que acabe comprometendo a sua segurança e a eficácia do medicamento, a prescrição de PEP pode ser indicada se houver relato de exposição sexual nas últimas 72 horas<sup>47</sup> . A adesão inadequada e que pode levar à indicação da PEP é definida como:  
- Para mulheres cis e qualquer pessoa em uso de hormônios à base de estradiol: uso  
- igual ou inferior a 5 doses nos 7 dias antes da exposição.  
- Para homens cis, pessoas não binárias designadas como do sexo masculino ao  
- nascer, e travestis e mulheres transexuais, que não estejam em uso de hormônios à base de estradiol: uso igual ou inferior a 3 doses nos 7 dias antes da exposição, se PrEP oral diária.  
Ao término do curso de 28 dias de PEP, e após a exclusão de infecção pelo HIV, a PrEP pode ser reiniciada, com ênfase na identificação das barreiras enfrentadas pelo indivíduo para a adesão adequada ao esquema de PrEP, além de apoio e orientações para saná-las.  
No momento de assistência a pessoas que procuram a PEP para prevenção da infecção ao HIV, é necessário também realizar o rastreamento da sífilis e demais IST e, em caso de violência sexual, oferecer profilaxia às IST. Além disso, toda situação de exposição deve também ser avaliada quanto ao risco de exposição às hepatites virais, no qual pode haver indicação de vacinação e imunoglobulina.  
Para mais informações, consultar:  
|Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia|
|---|
|Pós-Exposição (PEP) de risco à infecção pelo HIV, IST e<br>hepatites virais|
|Disponível em:https://www.gov.br/aids/pt-br/central-de-<br>conteudo/pcdts|  
<!-- Start of picture text -->
Baaee<br>Pepataert sete<br>oeaeaeee<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.6. Testagem e Tratamento das outras IST** -->
Indivíduos elegíveis para PrEP apresentam maior chance para a aquisição de outras IST, uma vez que essas infecções compartilham as mesmas vias de transmissão do HIV. Assim, a testagem para IST deve ser estabelecida na rotina do cuidado das pessoas em PrEP, sendo que a investigação e o tratamento das IST não devem ser impeditivos para o início da PrEP.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: Recomenda-se testagem para: -->
- Sífilis: preferencialmente por teste rápido, instituindo-se o tratamento quando  
- indicado. No caso de usuário com histórico prévio de sífilis, deve-se indicar o início da investigação com um teste não treponêmico (como o VDRL ou RPR).  
- Clamídia e gonococo por biologia molecular: realizar pesquisa de acordo com a  
- prática sexual: urina (uretral), amostras endocervicais, secreção genital, amostras extragenitais (anais e faríngeas). Para mais informações, consultar o Informe técnico sobre a Rede Nacional de Laboratórios de Biologia Molecular para Detecção de Clamídia e Gonococo no SUS.<sup>38</sup>  
12  
Para mais informações sobre diagnóstico e tratamento das IST, consultar:  
|Protocolo Clínico e Diretrizes Terapêuticas para Atenção<br>Integral às Pessoas com Infecções Sexualmente<br>Transmissíveis (IST).|
|---|
|Disponível em:https://www.gov.br/aids/pt-br/central-de-<br>conteudo/pcdts|  
<!-- Start of picture text -->
Tee a ty<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Hepatites B e C** -->
Indivíduos sexualmente ativos (especialmente homens cis gays ou outros HSH) ou que usam drogas apresentam maior risco de infecção de hepatite pelo vírus B (HBV)<sup>48</sup> e hepatite pelo vírus C (HCV)<sup>49</sup> . Recomenda-se a investigação inicial das hepatites virais B e C utilizando, preferencialmente, testes rápidos.  
A testagem deverá seguir os fluxogramas definidos no “Manual Técnico para o Diagnóstico das Hepatites Virais”<sup>50</sup> , disponível em <u>https://www.gov.br/aids/pt-br/centrais-deconteudo/manuais-tecnicos-para-diagnostico .</u>  
O perfil imunológico para as hepatites virais B (HBsAg, anti-HBs e anti-HBc – total e IgM) e C (anti-HCV) deve ser documentado em todas as pessoas com indicação de PrEP, com exames solicitados e/ou coletados na consulta inicial.  
A infecção pelo HBV ou pelo HCV não é contraindicação para o uso de PrEP oral diária. Ainda que os resultados não estejam disponíveis no momento ou que haja diagnóstico de HBV, a PrEP com posologia diária pode ser iniciada.<sup>14</sup>  
As pessoas candidatas à PrEP com diagnóstico de hepatite viral B crônica devem ser referenciadas para avaliação e acompanhamento específico, com o objetivo de investigar a presença de atividade da doença, estágio de fibrose hepática, segurança do uso concomitante de tenofovir/entricitabina (TDF/FTC), avaliação de tratamento e monitoramento de função hepática na interrupção da PrEP.  
No caso de TR anti-HCV reagente, o candidato à PrEP deve ser encaminhado para realização de exames complementares para a conclusão diagnóstica e avaliação clínica adicional – investigação de infecção ativa pelo HCV, podendo a PrEP ser iniciada antes mesmo que os resultados dos exames estejam disponíveis.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Hepatite A** -->
Considerando que o principal meio de transmissão do vírus da hepatite A (HAV) é a via fecal-oral, o que inclui a transmissão sexual anal-oral, recomenda-se avaliar o usuário de PrEP para um eventual episódio de infecção aguda pelo vírus da HAV.  
No momento da consulta, também se deve instruir os usuários de PrEP quanto às medidas de prevenção à infecção pelo HAV, que são: a higienização das mãos, genitália, períneo e região anal antes e após as relações sexuais, bem como a higienização de vibradores e _plugs_ anais e vaginais.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.8. Vacinação** -->
A prescrição de vacinas para usuários de PrEP poderá ser realizada pelos prescritores de PrEP dos serviços públicos e privados, por meio do formulário “Prescrição de Imunizantes” disponível na aba “documentos” do sistema SICLOM gerencial (http://azt.aids.gov.br/documentos/lista_doc.php).  
O usuário, munido da “Prescrição de Imunizantes”, deverá buscar a sala de vacina do Serviço de Atendimento Especializado (SAE) ou do Centro de Testagem e Aconselhamento. Caso os serviços de saúde não tenham sala de vacina, o usuário deverá ser encaminhado para uma Unidade Básica de Saúde na APS para realizar a vacinação.  
13

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Vacinação para Hepatite B** -->
A vacinação para a hepatite B é recomendada para todas as pessoas, em qualquer faixa etária. Os segmentos populacionais com indicação de PrEP também são prioritários para receber o esquema vacinal completo (geralmente de três doses). A vacina para a hepatite B é indicada independentemente da disponibilidade do exame anti-HBs.  
Nas pessoas vacinadas para HBV, avaliar a soroconversão (Anti-HBs) na consulta de retorno. Na presença de anti-HBs ≥ 10 UI/mL, não há necessidade de repetir os exames para hepatite B.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Vacinação para Hepatite A** -->
É necessário verificar a susceptibilidade do usuário de PrEP por meio da pesquisa de exame sorológico específico (anti-HAV IgG ou anti-HAV total). Caso a pesquisa dos anticorpos (anti-HAV IgG e anti-HAV total) seja não reagente, deve-se recomendar a vacinação da pessoa suscetível.  
As indicações de vacinação para hepatite A em caso de susceptibilidade podem ser encontradas no Manual dos Crie, em https://www.gov.br/saude/pt-br/vacinacao/arquivos/manual- <u>dos-centros-de-referencia-para-imunobiologicos-especiais_6a-edicao_2023.pdf</u>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Vacinação para Papilomavírus humano (HPV)** -->
Considerando que o HPV é uma infecção sexualmente transmissível muito comum e que usuários de PrEP apresentam risco desproporcionalmente aumentado da aquisição da infecção pelo HPV, recomenda-se a ampliação da vacinação contra o HPV para **usuários de PrEP entre 15 a 45 anos** , conforme as orientações abaixo:  
- **NÃO** vacinados contra o HPV:  
- Administrar 3 (três) doses: 0 – 2 – 6 meses (segunda dose dois meses após a primeira e terceira 6 meses após a primeira dose)  
- **VACINADOS** contra o HPV:  
- Esquema completo para a faixa etária ou situação especial: não vacinar.  
- Esquema incompleto: completar o esquema com 3 doses.  
A vacina HPV é contraindicada para gestantes, devendo-se, nesses casos, aguardar o puerpério para a imunização.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.9. Avaliação da função renal** -->
A avaliação da função renal é realizada por meio da dosagem de creatinina sérica e do cálculo do ClCr. Recomenda-se, na consulta inicial, avaliar o histórico e fatores de risco para doença renal, como presença de hipertensão arterial sistêmica (HAS) e diabetes, uso concomitante de medicamentos com potencial nefrotóxico e história conhecida de insuficiência renal ou lesão renal.  
14  
Indica-se a dosagem da creatinina na avaliação inicial, conforme a faixa etária e histórico do usuário<sup>14</sup> :  
 Idade menor que 30 anos e sem fatores de risco para redução da função renal: opcional.  
 Idade igual ou maior que 30 anos ou presença de fatores de risco para redução da função renal: solicitar na primeira consulta.  
A solicitação e a coleta do exame de função renal podem ser feitas no dia da primeira dispensação de PrEP e seu resultado avaliado dentro do prazo do primeiro retorno do usuário em 30 dias, sem prejuízo para a primeira dispensação da profilaxia.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Para pessoas sem histórico de doença renal ou fator de risco, o resultado do exame não deve atrasar o início da PrEP.** -->
Para o cálculo do ClCr estimado, podem ser utilizadas as fórmulas de Cockcroft–Gault ou o CK-EPI atualizada. Ressalta-se que o CK-EPI é considerado mais acurado que o CockroftGault e mais fácil de calcular, não sendo necessário informação do peso corporal, bastando inserir idade, sexo e cor da pele.  
Alguns estudos destacam as limitações do uso de cálculos de _clearance_ de creatinina comuns na estimativa da função renal, particularmente em pacientes com variações fisiológicas não contabilizadas na fórmula original de Cockcroft-Gault. Variáveis como massa muscular e uso de medicamentos, relevantes para pacientes transgêneros, podem alterar a forma como a equação de Cockcroft-Gault é interpretada.  
Sugere-se utilizar a Calculadora Virtual de CICr, preferencialmente CKD-EPI, disponível em: https://www.sbn.org.br/profissional/utilidades/calculadoras-nefrologicas.  
**Para qualquer indivíduo com um ClCr estimado igual ou maior a 60 mL/minuto, pode-se prescrever com segurança a PrEP oral contendo tenofovir.**  
Embora o uso do tenofovir possa levar a uma perda progressiva da função renal, ocorrendo em raros casos relatos de insuficiência renal aguda e síndrome de Fanconi associados ao medicamento, não foi observado comprometimento clinicamente significativo da função renal nos ensaios clínicos e estudos de demonstração realizados com a PrEP oral contendo TDF/FTC 51–54. Nesses casos, não é raro que ocorra uma discreta alteração no ClCr, totalmente reversível com a interrupção do uso do medicamento.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Dada a potencial toxicidade renal de TDF, a PrEP não está indicada para indivíduos com ClCr abaixo de 60 mL/minuto.** -->
Ainda, durante o seguimento do usuário, caso o _clearance_ de creatinina estimado esteja abaixo de 60 mL/minuto, recomenda-se repetir o exame em um outro dia antes de interromper o uso da PrEP oral contendo tenofovir. Destaca-se que alguns fatores podem alterar a função renal e devem ser avaliados antes da interrupção da PrEP, dentre eles: dieta (grande ingestão de proteínas), massa muscular, comorbidades, uso de outros medicamentos e suplementação com creatina.  
O ClCr geralmente retorna aos níveis normais de um a três meses após a interrupção da PrEP, e o medicamento pode ser reiniciado se o _clearance_ for confirmado como acima de 60 mL/minuto. Caso o ClCr não retorne aos níveis normais após a interrupção da PrEP, o usuário deve ser encaminhado para investigação clínica e laboratorial adicional de outras causas de insuficiência renal, como diabetes e hipertensão.  
15

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **6.10. Avaliação do histórico de fraturas patológicas** -->
Nos estudos clínicos sobre PrEP, as diminuições na densidade mineral óssea (DMO) observadas durante o uso da PrEP foram revertidas quando da interrupção do medicamento<sup>55,56</sup> , apesar do tenofovir ser conhecido por diminuir a massa óssea quando usado para o tratamento ou prevenção da infecção pelo HIV. Da mesma forma, os estudos clínicos e projetos de demonstração de PrEP não evidenciaram nenhum aumento da incidência de fraturas patológicas no intervalo de um a três anos de observação<sup>7</sup> .  
Portanto, não está indicada a realização rotineira de densitometria óssea ou outra avaliação de massa óssea para início de PrEP ou para o monitoramento de indivíduos em uso da profilaxia. Entretanto, recomenda-se que os candidatos à PrEP com histórico de fratura óssea por fragilidade patológica ou fatores de risco significativos para osteoporose sejam encaminhados para avaliação e acompanhamento médico e laboratorial específico, não sendo este um motivo para atrasar o início da PrEP.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **INDICAÇÃO DE PrEP ORAL** -->
O esquema disponível para PrEP é a associação em dose fixa combinada dos antirretrovirais fumarato de tenofovir desoproxila (TDF) 300 mg e entricitabina (FTC) 200 mg. Atualmente, existem duas modalidades de PrEP oral: a diária e a sob demanda.  
Recomenda-se que, para os candidatos elegíveis à PrEP, o início da profilaxia seja o mais próximo do dia da realização do teste para HIV, preferencialmente no mesmo dia da testagem, até um máximo de sete dias após o teste. O início da PrEP no mesmo dia reduz a exposição ao HIV<sup>57,58</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.1. Tempo necessário para início de proteção segura da PrEP** -->
O tempo para início da proteção da PrEP no organismo depende da concentração do medicamento no sangue e em outros tecidos. Esse período apresenta variações relacionadas à identidade de gênero, ao tipo de exposição e à presença de hormônios à base de estradiol<sup>11,14,59–</sup> 62, sendo necessária a orientação da utilização de medidas adicionais de prevenção antes da proteção.  
Assim, <u>o tempo necessário de uso inicial para proteção, considerando as variações é:</u>  
|**População**|**Tempo para**<br>**efeito seguro**|
|---|---|
|Mulheres cis equalquerpessoa em uso de hormônio à base de estradiol|7 dias|
|Homens cis, pessoas não binárias designadas como do sexo masculino<br>ao nascer, e travestis e mulheres transexuais, que**não**estejam em uso|2 horas|
|de hormônios à base de estradiol||  
Não há contraindicação para PrEP oral diária por pessoas que fazem uso de terapia hormonal feminilizante ou masculinizante.  
16

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.2. Modalidades para PrEP oral 7.2.1. PrEP oral diária** -->
A PrEP oral diária pode ser recomendada para qualquer pessoa maior de 15 anos e com mais de 35 kg.  
A posologia indicada é de:  
- 2 comprimidos de TDF/FTC no primeiro dia, seguido de 1 comprimido de  
- TDF/FTC diariamente.  
<!-- Start of picture text -->
PrEP oral diaria<br>Primeiro dia<br><!-- End of picture text -->  
Figura 2. Esquema para a PrEP oral diária  
A PrEP oral diária deve ser a modalidade de escolha para pessoas com hepatite B crônica (com e sem indicação de antiviral) pela possibilidade de indução de resistência do vírus da Hepatite B ao tenofovir, decorrente do uso intermitente do medicamento.  
Nos casos de HBV sem indicação de antiviral e que se tenha prescrito a PrEP, reitera-se a importância de avaliar a indicação de tratamento para Hepatite B quando se aventar a possibilidade de interrupção de PrEP, com monitoramento e uma possível reativação do HBV e crises hepáticas. Os usuários de PrEP com HBV crônica devem ser orientados a não interromper a PrEP por conta própria e, caso isso ocorra, a buscar um serviço de saúde em caso de sintomas sugestivos de reativação da hepatite.<sup>14,15</sup>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.2.2. PrEP oral sob demanda** -->
Diante de evidências que demonstram eficácia e segurança da PrEP sob demanda<sup>11,39,63,64</sup> , este PCDT recomenda a possibilidade de utilização dessa modalidade de PrEP, também conhecida como “orientada para eventos (ED-PrEP)”, esquema "2+1+1".  
Os grupos elegíveis para PrEP sob demanda são:  homens cisgêneros heterossexuais, bissexuais, gays e outros HSH, pessoas não binárias designadas como do sexo masculino ao nascer, e travestis e mulheres transexuais - que não estejam em uso de hormônios à base de estradiol.  
17  
Além do pertencimento ao grupo elegível, para poder fazer uso da PrEP sob demanda é necessário que os usuários:  
- Tenham habitualmente relação sexual com frequência menor do que 2 (duas)  
- vezes por semana, e  
 Consigam planejar o uso do esquema com, pelo menos, duas horas de antecedência da relação sexual.  
Para indivíduos das populações que possuem indicação para PrEP sob demanda, mas que tenham práticas sexuais mais frequentes, segue sendo recomendado o uso de PrEP oral diária.  
Aos usuários de PrEP sob demanda que passem a ter relações sexuais mais frequentes, recomenda-se que haja mudança para a modalidade de PrEP oral diária.  
A posologia da PrEP sob demanda é:  
- Dose inicial de 2 (dois) comprimidos de 2 a 24 horas antes da relação sexual +  
- 1 (um) comprimido 24 horas após a dose inicial de dois comprimidos +  
- 1 (um) comprimido 24 horas após a segunda dose.  
<!-- Start of picture text -->
PrEP sob demanda<br>2a 24 horas at ores . ne 24 horas ve<br>{ rer J<br>2a 24 horas 24 horas 24 horas<br>a a a [sintes do se popds dose Inicle| a p s asegunda dpse|@<br><!-- End of picture text -->  
**Figura 3** : Esquema PrEP oral sob oral sob demanda  
Caso uma nova relação sexual ocorra no dia consecutivo após completar as doses 2+1+1, é necessário que o usuário tome 1 (um) comprimido por dia até 48 horas após o último evento sexual. Se ocorrer um intervalo de mais de um dia entre o último comprimido e o próximo evento sexual, recomenda-se que usuários da PrEP sob demanda reiniciem o esquema 2+1+1.  
Ressalta-se que os estudos de PrEP sob demanda não apresentam evidências de proteção para relações sexuais neovaginal receptivas. Portanto, sua indicação seria para relações sexuais anais (insertiva e/ou receptiva) e vaginais insertivas.  
18  
A regularidade de consultas e exames laboratoriais é a mesma para as duas modalidades.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.3. Alternância entre as modalidades de PrEP oral** -->
A escolha da modalidade de PrEP, se diária ou sob demanda, poderá variar conforme as circunstâncias e estilo de vida de cada indivíduo, considerando a frequência, a previsibilidade e possibilidade de planejamento do uso do esquema.  
- A alternância poderá acontecer da seguinte forma<sup>64</sup> :  
- Usuário de PrEP sob demanda com relação sexual nos dias subsequentes da  
- realização do esquema 2+1+1: deve ser orientado a permanecer em uso de um comprimido por dia enquanto estiver mantendo relações sexuais e parar de tomar o medicamento apenas 2 dias após o último ato sexual;  
- Usuário de PrEP oral diária que passe a ter relações sexuais menos frequentes ou  
- relações sexuais previsíveis: o esquema da PrEP sob demanda (2+1+1) pode ser usado em seu lugar, conforme preconizado.  
O **Quadro 4** resume as modalidades de PrEP oral.  
19

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Quadro 4** : Resumo com as informações sobre as modalidades de PrEP oral -->
|**PrEP oral**|**Para quem**|**Dose Inicial**|**Doses**<br>**subsequentes**|**Tempo para efeito seguro**|**Interrupção segura**|
|---|---|---|---|---|---|
|Diária|Todas as pessoas com indicação de<br>PrEP|Tomar 2 (dois)<br>comprimidos no<br>primeiro dia|Tomar<br>1<br>(um)<br>comprimido<br>por<br>dia.|Mulher cis e qualquer pessoa em<br>uso de hormônio à base de<br>estradiol: 7 dias<br>Homens cis, pessoas não binárias<br>designadas<br>como<br>do<br>sexo<br>masculino ao nascer, e travestis e<br>mulheres transexuais, que não<br>estejam em uso de hormônios à<br>base de estradiol: 2 horas|Mulher cis e qualquer pessoa em uso de<br>hormônio à base de estradiol: Tomar 1 (um)<br>comprimido por dia por 7 dias, após a última<br>prática sexual.<br>Homens cis, pessoas não binárias designadas<br>como do sexo masculino ao nascer, e travestis<br>e mulheres transexuais, que não estejam em<br>uso de hormônios à base de estradiol: Tomar 1<br>(um) comprimido por dia por 2 (dois) dias,<br>apósaúltimapráticasexual.|
|Sob demanda|Homens cis, pessoas não binárias<br>designadas como do sexo masculino<br>ao nascer, e travestis e mulheres<br>transexuais, que não estejam em uso<br>de hormônios à base de estradiol<br>E<br>Relação sexual com frequência<br>menor do que duas vezes por<br>semana e planejamento ou previsão<br>das relações sexuais (pelo menos 2<br>horas de antecedência).|Tomar 2 (dois)<br>comprimidos (de<br>2 a 24 horas)<br>antes da relação<br>sexual.|Tomar<br>1<br>(um)<br>comprimido<br>24<br>horas<br>após<br>dose<br>inicial e mais 1 (um)<br>comprimido<br>24<br>horas<br>após<br>a<br>segunda dose.|2 horas|Tomar 1 (um) comprimido por dia por 2 (dois)<br>dias, após a última prática sexual.|  
20

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.4. Efeitos adversos** -->
As pessoas em uso de PrEP devem ser informadas sobre a possibilidade de efeitos adversos decorrentes do uso dos antirretrovirais (ARV). Nos ensaios clínicos disponíveis, os efeitos adversos foram semelhantes no grupo de intervenção e no grupo placebo, e boa parte deles se resolveu após os primeiros meses de uso<sup>39,65</sup> .  
O profissional de saúde deve informar ao usuário que **os efeitos adversos esperados (náusea, cefaleia, flatulência, amolecimento das fezes/diarreia e edemas) são transitórios e que há possibilidade de uso de medicamentos sintomáticos para a resolução dos sintomas.**

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.5. Critérios para interrupção da PrEP** -->
A PrEP deverá ser interrompida nos seguintes casos:  
- Diagnóstico de infecção pelo HIV;  
- Desejo de interromper a utilização do medicamento;  
- Persistência ou ocorrência de eventos adversos relevantes  
- Baixa adesão à PrEP, mesmo após abordagem individualizada de adesão.  
Para usuários que tenham mudança no contexto de vida, com importante diminuição da frequência de práticas sexuais com potencial risco de infecção, o esquema da PrEP sob demanda pode ser uma opção, que deve ser avaliada entre usuário e profissional, antes de interromper o uso da PrEP.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **7.5.1. Tempo necessário para interrupção segura da PrEP** -->
É importante que o usuário seja orientado a conversar com a equipe de saúde sobre a descontinuidade da PrEP. Caso tenha havido relações sexuais com potencial risco de infecção pelo HIV, recomenda-se, antes da interrupção da PrEP, que o usuário, a contar da data do potencial exposição de risco, mantenha o uso da profilaxia pelo período indicado a seguir<sup>14,73</sup> :  
|**População**|**Manutenção daprevenção**|
|---|---|
|Mulheres cis e qualquer pessoa em uso de hormônio à base<br>de estradiol|Por mais 7 dias após a última<br>prática sexual|
|Homens cis, pessoas não binárias designadas como do sexo<br>masculino ao nascer, e travestis e mulheres transexuais, que<br>**não**estejam em uso de hormônios à base de estradiol|Por mais 2 dias após a última<br>prática sexual|  
Na suspeita de infecção aguda pelo HIV, a suspensão da PrEP deve ser avaliada por critérios epidemiológicos e clínicos e na adesão da pessoa, até a confirmação ou exclusão do diagnóstico.  
Indivíduos vivendo com hepatite B em uso de PrEP necessitam de avaliação médica antes de interromperem a profilaxia. A suspensão da PrEP em pessoas com doença hepática pelo HBV pode levar à exacerbação, ou “ _flare_ ”, das enzimas hepáticas e à descompensação hepática e óbito em pacientes cirróticos.  
Deve-se esclarecer, também, a importância de o usuário utilizar outros métodos preventivos e se testar regularmente para HIV e outras IST, além da possibilidade de retomar o  
21  
uso da PrEP, caso ainda ocorram ou voltem a ocorrer situações de maior chance de exposição ao HIV ou de utilização da PEP em situações de exposições pontuais.  
**Para reiniciar a PrEP, após um período de interrupção e/ou descontinuidade (item 9.3), o profissional deve realizar a testagem para HIV e proceder conforme a avaliação inicial (item 6), realizando a dispensa de medicamentos para 30 dias. Após o retorno, há possibilidade de seguimento quadrimestral, devendo-se considerar todas as questões que levaram o usuário a descontinuar o da PrEP.**

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: 8. **AVALIAÇÃO DE INTERAÇÕES MEDICAMENTOSAS** -->
Os profissionais devem questionar sobre o uso de medicamentos concomitantes à PrEP. Para verificar possíveis interações medicamentosas, consultar o site abaixo:  
Possíveis interações medicamentosas entre a PrEP e outros medicamentos, consulte: <u>https://interacoeshiv.huesped.org.ar/</u>  
<!-- Start of picture text -->
sampap rt Spree<br>are safe<br>sede es<br>Ps erie<br>® toreSUGee oeTS asea Ee<br><!-- End of picture text -->  
**A PrEP não afeta a eficácia dos contraceptivos e repositores hormonais**<sup>34</sup> **, assim como os contraceptivos e repositores hormonais não afetam a eficácia da PrEP**<sup>66</sup> . Os medicamentos da PrEP são processados nos rins, enquanto os hormônios anticoncepcionais são processados no fígado, não havendo interações medicamentosas conhecidas também com hormônios sexuais<sup>67</sup> .  
Quanto à hormonização feminilizante, em uma análise _post hoc_ sobre infecção pelo HIV do estudo iPrEX em mulheres trans em uso de PrEP oral diária, não se observou infecção pelo HIV quando detectados níveis sanguíneos dos medicamentos compatíveis com a ingestão de quatro ou mais doses de PrEP semanais<sup>68</sup> . Estudos menores e mais recentes vêm demonstrando a manutenção da eficácia da PrEP mesmo em uso de terapias hormonais de afirmação de gênero diversas<sup>69–71</sup> . **Os dados corroboram com a segurança do uso da PrEP em mulheres e homens trans, destacando a importância da adesão.**  
**O uso de álcool e outras drogas recreativas, como cocaína e metanfetaminas, não reduzem a eficácia da PrEP, mas podem prejudicar a adesão**<sup>72</sup> . <mark>Tais condições devem ser detalhadas com usuários no intuito de não postergar início ou manutenção da PrEP.</mark>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: 9. **SEGUIMENTO DO USUÁRIO DE PrEP 9.1. Acompanhamento clínico e laboratorial** -->
Uma vez que a PrEP é iniciada, a primeira dispensação deverá ser feita para 30 dias e, uma vez caracterizada a adesão do indivíduo à estratégia, o seguimento clínico será quadrimestral (a cada 120 dias) e as dispensações subsequentes ocorrerão de acordo com a capacidade de fornecimento da UDM.  
Usuários que, por ventura, não recebam o quantitativo integral da PrEP para o tempo de profilaxia solicitados pelo profissional de saúde, poderão receber em outro momento, sem a necessidade de um novo TR de HIV, desde que não ultrapassada a validade do formulário, para complementar o tempo indicado da profilaxia.  
22  
A realização do teste de HIV a cada consulta é obrigatória, preferencialmente, por teste  
rápido.  
Durante o acompanhamento clínico, deve-se atentar para a possibilidade de infecção aguda pelo HIV, alertando os usuários quanto aos principais sinais e sintomas e orientando-os a procurar imediatamente o serviço de saúde na suspeita de infecção. Em caso de suspeita de infecção aguda pelo HIV, deve-se realizar o exame de carga viral do HIV.  
As avaliações de eventos adversos, continuidade e adesão, interrupção da PrEP e outras orientações sobre prevenção do HIV e outras IST, além da testagem e tratamento de IST, devem fazer parte de todas as consultas de seguimento.  
O **Quadro 5** apresenta a periodicidade das atividades relacionadas ao seguimento do indivíduo em uso de PrEP.  
**<u>Quadro 5</u>** <u>: Seguimento clínico e laboratorial de pessoas em uso de PrEP</u>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **<mark>SEGUIMENTO DE USUÁRIOS DE PrEP</mark>** -->
|**Avaliações**|**Periodicidade**|
|---|---|
|Avaliação de sinais e sintomas de infecção aguda||
|Peso dopaciente(emquilogramas)||
|Avaliação de eventos adversos à PrEP||
|Avaliação da adesão|Quadrimestral|
|Avaliação de exposições de risco||
|Dispensação de ARV após aprescrição<sup>a</sup>||
|Avaliação da continuidade de PrEP||  
|**Exames**|**Método**|**Periodicidade**|
|---|---|---|
|Teste para HIV|Sorologia ou TR para HIV, utilizando<br>amostra de sangue total, soro ou plasma.<br>Autoteste (sangue oufluido oral).|Após um mês do início da<br>PrEP e a seguir quadrimestral<br>(todaconsultadePrEP)|
|Teste para sífilis|Teste treponêmico de sífilis (ex.: teste<br>rápido ou ELISA) ou não treponêmico<br>(ex.: VDRLouRPRouTRUST)|Quadrimestral|
|Identificação<br>de<br>outras IST (clamídia<br>egonococo)|Testagem por biologia molecular em<br>urina, secreção genital e/ou extragenital<br>(pesquisa de acordo comprática sexual)|Semestral (ou mais frequente<br>em caso de sintomatologia)|
|Teste para hepatite<br>B<sup>b</sup>|Pesquisa de HBsAg (ex.: TR) e anti-HBs|Anual, conforme avaliação<br>inicial<sup>b</sup>|
|Teste para hepatite<br>C<sup>c</sup>|Pesquisa de anti-HCV (ex.: TR)|Quadrimestral,<br>conforme<br>avaliação inicial<sup>c</sup>|
|Monitoramento<br>da<br>função renal<sup>d</sup>|_Clearance_de creatinina e dosagem de<br>creatinina sérica|A cada 6 ou 12 meses<br>(descrito a seguir)|
|Teste de gravidez||Quadrimestral (ou quando<br>necessário)|  
**Fonte** : DATHI/SVSA/MS.  
**Notas:**<sup>a</sup> 1<sup>a</sup> dispensação para 30 dias e, em seguida, trimestral (a cada 90 dias) ou quadrimestral (a cada 120 dias).  
23  
b Em caso de resultado não reagente em teste rápido (HBsAg) anterior e ausência de imunidade natural ou adquirida para a infecção. Nos pacientes vacinados para HBV, avaliar a soroconversão (anti-HBs) na consulta de retorno. Após a soroconversão, não há necessidade de repetir o teste rápido para hepatite B. c Solicitar anti-HCV em caso de resultado não reagente em exame anterior.  
A reavaliação da função renal deve ser realizada conforme a faixa etária do usuário e avaliação inicial da função renal<sup>14</sup> :  
- Indivíduos com idade inferior a 50 anos, sem comorbidades, avaliação inicial da  
- função renal normal (ClCr ≥ 90 mL/minutos): a cada 12 meses.  
- Indivíduos com idade superior a 50 anos OU com história de comorbidades, tais  
- como HAS e diabetes, OU com estimativa inicial do ClCr menor que 90 mL/minutos: a cada 6 meses.  
Para pessoas com TR ou sorologia não reagente para HCV na consulta inicial, o mesmo exame deve ser repetido a cada três meses no acompanhamento da PrEP. O seguimento dos indivíduos que já realizaram o tratamento para hepatite C e que obtiveram a resposta virológica sustentada (RVS) deve ser realizado por meio da dosagem semestral de alanina aminotransferase (ALT) e coleta de amostra para realização de carga viral (HCV-RNA), este último nas seguintes situações:  
i) desse houver alteração de ALT;  
ii) a cada 12 meses, mesmo que não haja alteração de ALT;  
iii) em situações de exposição de risco à infecção pelo HCV.  
Para usuários de PrEP com adesão regular e que estejam em uso de PrEP há, no mínimo, 1 ano, sem histórico de descontinuidade, o seguimento clínico poderá ser ampliado para 6 meses. Nesses casos, a dispensa também poderá ser ampliada, a depender da disponibilidade do estoque local. Os usuários devem ser orientados que, durante esse intervalo, caso apresentem sinais e/ou sintomas sugestivos de IST deverão retornar ao serviço de saúde.<sup>74–77</sup>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **9.2. Avaliação de efeitos adversos** -->
A presença de efeitos adversos deve ser monitorada e questionada em todas as consultas. Caso sejam identificados, medicamentos para os sinais e sintomas podem ser prescritos conforme necessário. Importante informar o usuário que os efeitos adversos, quando presentes, costumam ser leves e com duração limitada.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **9.3. Adesão e continuidade em PrEP** -->
Estudos<sup>59,68</sup> demonstraram que, para evitar infecção pelo HIV em uso de PrEP, o usuário deve utilizar uma quantidade mínima de comprimidos por semana para estar protegido:  
|**População**|**Quantidade de comprimidos**|
|---|---|
|Mulheres cis e qualquer pessoa em uso de hormônio à<br>base de estradiol|Devem ingerir, pelo menos, 6 (seis)<br>comprimidospor semana.|
|Homens cis, pessoas não binárias designadas como do<br>sexo masculino ao nascer, e travestis e mulheres<br>transexuais, que**não**estejam em uso de hormônios à<br>base de estradiol|Devem tomar, pelo menos, 4<br>(quatro) comprimidos por semana.|  
24  
A adesão é fundamental para efetividade da PrEP e deve ser abordada em todas as consultas e dispensações de medicamentos, a partir de uma via de comunicação simples e aberta. Algumas atitudes do profissional e orientações podem facilitar a adesão do usuário, tais como:  
- Identificar barreiras e facilitadores da adesão para cada usuário, evitando  
- julgamentos ou juízos de valor.  
- Reforçar a informação sobre a relação entre boa adesão e efetividade da PrEP.  
- Sugerir associar ouso do medicamento aos eventos que façam parte da rotina diária do indivíduo.  
- Sugerir o uso de possíveis mecanismos de alerta para o uso do medicamento,  
- como despertadores e aplicativos.  
- Esclarecer que não existe rigidez de horário e que, em caso de esquecimento,  
- deve-se tomar o medicamento assim que lembrar.  
- Utilização de dados da farmácia ou do Sistema de Controle Logístico de  
- Medicamentos (Siclom) para avaliar o histórico de dispensação do medicamento no período entre as consultas e contagem de comprimidos a cada dispensação.  
- Avaliação e tratamento de eventos adversos.  
- Enfatizar que não se deve deixar de tomar PrEP em caso de ingestão de álcool,  
- uso de drogas ou de hormônios e que não há interação medicamentosa entre eles.  
- Pode-se também propor contatos intermediários por mensagem ou intervalos  
- mais frequentes para o retorno, especialmente na fase inicial de uso, para auxiliar na adesão.  
Estudos demonstrativos<sup>32,58,78</sup> evidenciam que a baixa adesão à PrEP pode ser preditora da interrupção do uso da profilaxia e, portanto, deve ser abordada como forma de se evitar a descontinuidade da profilaxia, principalmente nos 6 meses iniciais de uso. Dados nacionais<sup>79</sup> indicam maior descontinuidade no seguimento de PrEP por usuários jovens, pessoas com menor escolaridade e mulheres trans/travestis.  
O maior desafio no acompanhamento de PrEP é manter a continuidade dos usuários e sua persistência no seguimento. Os fatores de descontinuidade são múltiplos e interligados, e podem estar relacionados ao tempo de experiência com PrEP, necessidade de ajustes da vida cotidiana, questões relacionadas à saúde mental e dificuldades relacionadas ao acesso e ao acolhimento nos serviços de saúde.  
Usuários de PrEP que descontinuaram o uso da profilaxia e, posteriormente, se infectaram pelo HIV são alertas para os programas de prevenção, uma vez que são indivíduos que em algum momento acessaram o serviço de saúde, fizeram o uso da profilaxia, porém, descontinuaram o cuidado, caracterizando uma perda de oportunidade de prevenção. Esse grupo representou 1,2% dos usuários de PrEP, entre os anos de 2018 a 2023, e é composto, majoritariamente, por pessoas jovens, trans, com menor escolaridade e pretas/pardas.  
É importante que os profissionais envolvidos no cuidado tenham ciência da maior vulnerabilidade desses grupos populacionais e mantenham uma postura livre de julgamentos, respeitem as questões relacionada a identidade de gênero e orientação sexual, e busquem a compreensão do estilo de vida e do contexto social de cada usuário, possibilitando realizar orientações especificas para cada contexto.<sup>80,81</sup>

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **9.4. Soroconversão em uso de PrEP** -->
O usuário com suspeita de soroconversão para o HIV deve ser encaminhado a um serviço de referência, realizar exames de carga viral, contagem de linfócitos T-CD4 e genotipagem e, após a coleta desses exames, iniciar TARV o mais brevemente possível, mesmo que de maneira preemptiva, até a conclusão diagnóstica e de acordo com esquemas recomendados no “PCDT para Manejo da Infecção pelo HIV em Adultos”, disponível em <u>https://www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts,</u> https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-  
25  
e  
tecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas https://www.gov.br/saude/pt-br/assuntos/pcdt..  
O uso da terapia preemptiva, ou seja, pela suspeita de soroconversão para o HIV, mas ainda sem a respectiva conclusão diagnóstica, é instituído após a coleta de carga viral e genotipagem, no intuito de minimizar o risco de indução de resistência e de interrupção de medicamentos no caso de soroconversão, visto que a transição da PrEP para a TARV sem intervalo pode evitar o risco de ressurgimento da carga viral e transmissões secundárias<sup>49</sup> . Em caso de terapia preemptiva, é importante esclarecer ao usuário que o diagnóstico não foi confirmado e explicar os motivos da indicação dessa terapia.  
A avaliação da testagem para a infecção pelo HIV deve seguir os fluxogramas de diagnóstico laboratorial presentes no “Manual Técnico para Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>5</sup> .  
Após a análise dos resultados dos exames, se a infecção pelo HIV for descartada, o usuário deve reiniciar a PrEP (se indicada). Caso se confirme a infecção pelo HIV, o usuário deve manter o uso da TARV, sendo importante avaliar o resultado da genotipagem para verificar a necessidade de adequação do esquema.  
Para os casos de resultados inconclusivos, indeterminados e carga viral indetectável, recomenda-se manter o tratamento preemptivo e avaliar o caso.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **PrEP E A TESTAGEM FOCALIZADA** -->
Várias estratégias têm sido implementadas em todo o mundo no sentido de focalizar a oferta de testagem de HIV para populações em situação de maior vulnerabilidade para infecção pelo HIV e menor acesso aos serviços de saúde.  
O “Guia Rápido de Testagem Focalizada para o HIV”<sup>82</sup> é um documento que apresenta uma proposta de construção de estratégias focalizadas de testagem. O detalhamento da proposta pode ser consultado em: <u>https://www.gov.br/aids/pt-br/centrais-deconteudo/publicacoes/2020/guia-rapido-de-testagem-focalizada-para-o-hiv/view .</u>  
Uma dessas estratégias é a oferta de testagem a pares e parcerias de usuários em PrEP. Durante as consultas de rotina nos serviços de saúde que realizam PrEP, o profissional pode ofertar autotestes de HIV ao usuário de PrEP, para que ele os distribua entre seus pares ou parcerias.  
Alternativamente, pode-se orientar o usuário de PrEP a conversar com seus pares ou parcerias sobre a importância da testagem e a sugerir que procurem um serviço de saúde para fazer o teste, caso o usuário não deseje levar os autotestes para seus pares ou parcerias.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **REFERÊNCIAS** -->
1. Brasil. Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis – IST. Brasília: Ministério da Saúde; 2022.  
2. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. Prevenção Combinada do HIV/Bases conceituais para profissionais, trabalhadores(as) e gestores(as) de saúde. Brasília: Ministério da Saúde; 2017.  
3. Grant RM, Lama JR, Anderson PL, McMahan V, Liu AY, Vargas L, et al. Preexposure Chemoprophylaxis for HIV Prevention in Men Who Have Sex with Men. New England Journal of Medicine. 2010;363(27).  
26  
4. Thigpen MC, Kebaabetswe PM, Paxton LA, Smith DK, Rose CE, Segolodi TM, et al. Antiretroviral Preexposure Prophylaxis for Heterosexual HIV Transmission in Botswana. New England Journal of Medicine. 2012;367(5).  
5. Baeten JM, Donnell D, Ndase P, Mugo NR, Campbell JD, Wangisi J, et al. Antiretroviral Prophylaxis for HIV Prevention in Heterosexual Men and Women. New England Journal of Medicine. 2012;367(5).  
6. Choopanya K, Martin M, Suntharasamai P, Sangkum U, Mock PA, Leethochawalit M, et al. Antiretroviral prophylaxis for HIV infection in injecting drug users in Bangkok, Thailand (the Bangkok Tenofovir Study): A randomised, double-blind, placebo-controlled phase 3 trial. The Lancet. 2013;381(9883).  
7. Fonner VA, Dalglish SL, Kennedy CE, Baggaley R, O’reilly KR, Koechlin FM, et al. Effectiveness and safety of oral HIV pre-exposure prophylaxis (PrEP) for all populations: A systematic review and meta-analysis. AIDS. 2016;30.  
8. Marrazzo JM, Ramjee G, Richardson BA, Gomez K, Mgodi N, Nair G, et al. TenofovirBased Preexposure Prophylaxis for HIV Infection among African Women. New England Journal of Medicine. 2015;372(6).  
9. Marrazzo J, Tao L, Becker M, Leech AA, Taylor AW, Ussery F, et al. HIV Preexposure Prophylaxis With Emtricitabine and Tenofovir Disoproxil Fumarate Among Cisgender Women. JAMA [Internet]. 2024 Mar 19;331(11):930–7. Available from: https://doi.org/10.1001/jama.2024.0464  
10. McCormack S, Dunn DT, Desai M, Dolling DI, Gafos M, Gilson R, et al. Pre-exposure prophylaxis to prevent the acquisition of HIV-1 infection (PROUD): Effectiveness results from the pilot phase of a pragmatic open-label randomised trial. The Lancet. 2016;387(10013).  
11. Molina JM, Capitant C, Spire B, Pialoux G, Cotte L, Charreau I, et al. On-Demand Preexposure Prophylaxis in Men at High Risk for HIV-1 Infection. New England Journal of Medicine. 2015;373(23).  
12. Solomon MM, Schechter M, Liu AY, McManhan VM, Guanira J V., Hance RJ, et al. The safety of tenofovir-emtricitabine for HIV pre-exposure prophylaxis (PrEP) in individuals with active hepatitis B. J Acquir Immune Defic Syndr (1988). 2016;71(3).  
13. Peterson L, Taylor D, Roddy R, Belai G, Phillips P, Nanda K, et al. Tenofovir disoproxil fumarate for prevention of HIV infection in women: A phase 2, double-blind, randomized, placebo-controlled trial. PLoS Clin Trials. 2007;2(5).  
14. WHO. Differentiated and Simplified Pre-Exposure Prophylaxis for HIV Prevention. Update to WHO Implementation Guidance. World Health Organisation Library. 2022;14(3).  
15. Mohareb AM, Larmarange J, Kim AY, Coffie PA, Kouamé MG, Boyd A, et al. Risks and benefits of oral HIV pre-exposure prophylaxis for people with chronic hepatitis B. Vol. 9, The Lancet HIV. 2022.  
16. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente Departamento de HIV, Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis. Boletim Epidemiológico - HIV e Aids 2023.  
17. Szwarcwald CL, Damacena GN, De Souza-Junior PRB, Guimarães MDC, De Almeida WDS, De Souza Ferreira AP, et al. Factors associated with HIV infection among female sex workers in Brazil. Medicine (United States). 2018;97(1S).  
18. Bastos FL, Malta M, Albuquerque EM. Taxas de infecção de HIV e sífilis e inventário de conhecimento, atitudes e práticas de risco relacionadas às infecções sexualmente transmissíveis entre usuários de drogas em 10 municípios brasileiros. 2009.  
19. Kerr L, Kendall C, Guimarães MDC, Mota RS, Veras MA, Dourado I, et al. HIV prevalence among men who have sex with men in Brazil: Results of the 2nd national survey using respondent-driven sampling. Medicine (United States). 2018;97(1S).  
20. Monica Siqueira Malta, Francisco Inácio Pinkusfeld Monteiro Bastos, Carolina Fausto de Souza Coutinho. Estudo de abrangência nacional de comportamentos, atitudes, práticas e  
27  
prevalência para o HIV, sífilis, hepatite B e C entre travestis em 12 municípios brasileiros. Rio de Janeiro; 2018.  
21. Bastos FI, Bertoni N. Pesquisa Nacional sobre o uso de crack: quem são os usuários de crack e/ou similares do Brasil? quantos são nas capitais brasileiras? Igarss 2014. 2014.  
22. Lua I, Silva AF, Guimarães NS, Magno L, Pescarini J, Anderle RVR, et al. The effects of social determinants of health on acquired immune deficiency syndrome in a low-income population of Brazil: a retrospective cohort study of 28.3 million individuals. The Lancet Regional Health - Americas. 2023;24.  
23. Dourado I, Magno L, Greco DB, Zucchi EM, Ferraz D, Westin MR, et al. Interdisciplinarity in HIV prevention research: the experience of the PrEP1519 study protocol among adolescent MSM and TGW in Brazil. Cad Saude Publica. 2023;39.  
24. Health Organization W. Operational framework for monitoring the social determinants of health equity [Internet]. 2024. Available from: https://iris.who.int/.  
25. Patel P, Borkowf CB, Brooks JT, Lasry A, Lansky A, Mermin J. Estimating per-act HIV transmission risk: A systematic review. AIDS. 2014;28(10).  
26. Baggaley RF, White RG, Boily MC. HIV transmission risk through anal intercourse: Systematic review, meta-analysis and implications for HIV prevention. Int J Epidemiol. 2010;39(4).  
27. Ottaway Z, Finnerty F, Buckingham T, Richardson D. Increasing rates of reported chemsex/sexualised recreational drug use in men who have sex with men attending for postexposure prophylaxis for sexual exposure. Vol. 93, Sexually Transmitted Infections. 2017.  
28. Tomkins A, George R, Kliner M. Sexualised drug taking among men who have sex with men: a systematic review. Vol. 139, Perspectives in Public Health. 2019.  
29. THE ROLE OF HIV VIRAL SUPPRESSION IN IMPROVING INDIVIDUAL HEALTH AND REDUCING TRANSMISSION POLICY BRIEF.  
30. Estatuto da Criança e do Adolescente. Lei 8.069/90. São Paulo: Atlas; 1991. (Diário Oficial da União).  
31. Conselho Federal de Medicina. Resolução CFM nº 2217 de 27/09/2018 - Código de Ética Médica.  
32. Dourado I, Soares F, Magno L, Amorim L, Eustorgio Filho M, Leite B, et al. Adherence, Safety, and Feasibility of HIV Pre-Exposure Prophylaxis Among Adolescent Men Who Have Sex With Men and Transgender Women in Brazil (PrEP1519 Study). Journal of Adolescent Health. 2023;73(6).  
33. Mofenson LM, Baggaley RC, Mameletzis I. Tenofovir disoproxil fumarate safety for women and their infants during pregnancy and breastfeeding. AIDS. 2017;31(2).  
34. Mugo NR, Hong T, Celum C, Donnell D, Bukusi EA, John-Stewart G, et al. Pregnancy incidence and outcomes among women receiving preexposure prophylaxis for HIV prevention: A randomized clinical trial. JAMA. 2014;312(4).  
35. Johnson LF, Stinson K, Newell ML, Bland RM, Moultrie H, Davies MA, et al. The contribution of maternal HIV seroconversion during late pregnancy and breastfeeding to mother-to-child transmission of HIV. J Acquir Immune Defic Syndr (1988). 2012;59(4).  
36. World Health Organization policy brief. The role of HIV viral suppression in improving individual health and reducing transmission: policy brief. Geneva: World Health Organization; 2023. Who. 2023;(ISBN 978-92-4-005517-9 (electronic version)).  
37. Hoffman RM, Jaycocks A, Vardavas R, Wagner G, Lake JE, Mindry D, et al. Benefits of PrEP as an adjunctive method of HIV prevention during attempted conception between HIV-uninfected women and hivinfected male partners. Journal of Infectious Diseases. 2015;212(10).  
38. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Departamento de HIV/AIDS, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis. Coordenação-Geral de Vigilância do HIV e das Hepatites Virais. Nota Técnica No 26/2023-CGAHV/DATHI/SVSA/MS. Brasília; 2023.  
28  
39. O Murchu E, Marshall L, Teljeur C, Harrington P, Hayes C, Moran P, et al. Oral preexposure prophylaxis (PrEP) to prevent HIV: a systematic review and meta-analysis of clinical effectiveness, safety, adherence and risk compensation in all populations. BMJ Open. 2022;12(5).  
40. Grohskopf LA, Chillag KL, Gvetadze R, Liu AY, Thompson M, Mayer KH, et al. Randomized trial of clinical safety of daily oral tenofovir disoproxil fumarate among HIVuninfected men who have sex with men in the United States. J Acquir Immune Defic Syndr (1988). 2013;64(1).  
41. Brasil. Ministério da Saúde. Diagnóstico da Infecção pelo HIV em Adultos e Crianças. Brasília. 2018.  
42. Figueroa C, Johnson C, Ford N, Sands A, Dalal S, Meurant R, et al. Reliability of HIV rapid diagnostic tests for self-testing compared with testing by health-care workers: a systematic review and meta-analysis. Lancet HIV [Internet]. 2018 Jun 1 [cited 2023 Dec 14];5(6):e277. Available from: /pmc/articles/PMC5986793/  
43. Organização Mundial da Saúde (OMS). WHO recommends optimizing HIV testing services, 2023. Disponível em: <u>https://www.who.int/news/item/22-07-2023-whorecommends-optimizing-hiv-testing-services.</u>  
44. Witzel TC, Eshun-Wilson I, Jamil MS, Tilouche N, Figueroa C, Johnson CC, et al. Comparing the effects of HIV self-testing to standard HIV testing for key populations: a systematic review and meta-analysis. BMC Med. 2020 Dec 1;18(1).  
45. Doran TI, Parra E. False-positive and indeterminate human immunodeficiency virus test results in pregnant women. Vol. 9, Archives of Family Medicine. 2000.  
46. García T, Tormo N, Gimeno C, De Lomas JG, Navarro D. Performance of an automated human immunodeficiency virus (HIV) antigen/antibody combined assay for prenatal screening for HIV infection in pregnant women. Vol. 58, Journal of Medical Microbiology. 2009.  
47. WHO. Guidelines for HIV post-exposure prophylaxis. Geneva: World Health Organization; 2024. Licence: CC BY-NCSA 3.0 IGO.  
48. Wolitski RJ, Fenton KA. Sexual health, HIV and sexually transmitted infections among gay, bisexual and other men who have sex with men in the United States. AIDS Behav. 2011;15(SUPPL. 1).  
49. Van Der Helm JJ, Prins M, Del Amo J, Bucher HC, Chêne G, Dorrucci M, et al. The hepatitis C epidemic among HIV-positive MSM: Incidence estimates from 1990 to 2007. AIDS. 2011;25(8).  
50. Brasil. Manual Técnico para o Diagnóstico das Hepatites Virais. Ministério da Saúde. 2018;2.  
51. Mugwanya KK, Wyatt C, Celum C, Donnell D, Mugo NR, Tappero J, et al. Changes in glomerular kidney function among hiv-1- uninfected men andwomen receiving emtricitabine- tenofovir disoproxil fumarate preexposure prophylaxis a randomized clinical trial. JAMA Intern Med. 2015;175(2).  
52. Mugwanya KK, Wyatt C, Celum C, Donnell D, Kiarie J, Ronald A, et al. Reversibility of glomerular renal function decline in HIV-uninfected men and women discontinuing emtricitabine-tenofovir disoproxil fumarate pre-exposure prophylaxis. In: Journal of Acquired Immune Deficiency Syndromes. 2016.  
53. Petruccelli KCS, Baía-da-Silva DC, Val F, Valões MS, Cubas-Vega N, Silva-Neto AV, et al. Kidney function and daily emtricitabine/tenofovir disoproxil fumarate pre-exposure prophylaxis against HIV: results from the real-life multicentric demonstrative project PrEP Brazil. AIDS Res Ther. 2022;19(1).  
54. Schaefer R, Amparo da Costa Leite PH, Silva R, Abdool Karim Q, Akolo C, Cáceres CF, et al. Kidney function in tenofovir disoproxil fumarate-based oral pre-exposure prophylaxis users: a systematic review and meta-analysis of published literature and a multi-country meta-analysis of individual participant data. Lancet HIV. 2022;9(4).  
29  
55. Kasonde M, Niska RW, Rose C, Henderson FL, Segolodi TM, Turner K, et al. Bone mineral density changes among HIV-uninfected young adults in a randomised trial of preexposure prophylaxis with tenofovir-emtricitabine or placebo in Botswana. PLoS One. 2014;9(3).  
56. Glidden DV, Mulligan K, McMahan V, Anderson PL, Guanira J, Chariyalertsak S, Buchbinder SP, Bekker LG, Schechter M, Grinsztejn B, Grant RM. Recovery of Bone Mineral Density After Discontinuation of Tenofovir-Based HIV Pre-exposure Prophylaxis.J Acquir Immune Defic Syndr. 2017;76(2):177–182.  
57. Mikati T, Jamison K, Daskalakis DC. Immediate prep initiation at New York City sexual health clinics. Top Antivir Med. 2019;27(SUPPL 1).  
58. Veloso VG, Cáceres CF, Hoagland B, Moreira RI, Vega-Ramírez H, Konda KA, et al. Same-day initiation of oral pre-exposure prophylaxis among gay, bisexual, and other cisgender men who have sex with men and transgender women in Brazil, Mexico, and Peru (ImPrEP): a prospective, single-arm, open-label, multicentre implementation study. Lancet HIV. 2023;10(2).  
59. Grant RM, Anderson PL, McMahan V, Liu A, Amico KR, Mehrotra M, et al. Uptake of pre-exposure prophylaxis, sexual practices, and HIV incidence in men and transgender women who have sex with men: A cohort study. Lancet Infect Dis. 2014;14(9).  
60. Grant RM, Liegler T, Defechereux P, Kashuba ADM, Taylor D, Abdel-Mohsen M, et al. Drug resistance and plasma viral RNA level after ineffective use of oral pre-exposure prophylaxis in women. AIDS. 2014;29(3).  
61. Seifert SM, Glidden D V., Meditz AL, Castillo-Mancilla JR, Gardner EM, Predhomme JA, et al. Dose response for starting and stopping HIV preexposure prophylaxis for men who have sex with men. Clinical Infectious Diseases. 2015;60(5).  
62. Cottrell ML, Yang KH, Prince HMA, Sykes C, White N, Malone S, et al. A Translational Pharmacology Approach to Predicting Outcomes of Preexposure Prophylaxis Against HIV in Men and Women Using Tenofovir Disoproxil Fumarate with or Without Emtricitabine. In: Journal of Infectious Diseases. 2016.  
63. Molina JM, Charreau I, Spire B, Cotte L, Chas J, Capitant C, et al. Efficacy, safety, and effect on sexual behaviour of on-demand pre-exposure prophylaxis for HIV in men who have sex with men: an observational cohort study. Lancet HIV. 2017;4(9).  
64. WHAT’S THE 2+1+1? EVENT-DRIVEN ORAL PRE-EXPOSURE PROPHYLAXIS TO PREVENT HIV FOR MEN WHO HAVE SEX WITH MEN: UPDATE TO WHO’S RECOMMENDATION ON ORAL PREP [Internet]. 2019. Available from: http://apps.  
65. Pereira M, Castro CT de, Magno L, Oliveira T de A, Gomes FS, Neves FMF, et al. Adverse effects of daily oral pre-exposure prophylaxis in men who have sex with men and transgender women: A systematic review and meta-analysis. Vol. 39, Cadernos de Saude Publica. 2023.  
66. Murnane PM, Celum C, Mugo N, Campbell JD, Donnell D, Bukusi E, et al. Efficacy of preexposure prophylaxis for HIV-1 prevention among high-risk heterosexuals: Subgroup analyses from a randomized trial. AIDS. 2013;27(13).  
67. Nanda K, Stuart GS, Robinson J, Gray AL, Tepper NK, Gaffield ME. Drug interactions between hormonal contraceptives and antiretrovirals. Vol. 31, AIDS. 2017.  
68. Deutsch MB, Glidden D V., Sevelius J, Keatley J, McMahan V, Guanira J, et al. HIV preexposure prophylaxis in transgender women: A subgroup analysis of the iPrEx trial. Lancet HIV. 2015;2(12).  
69. Krakower DS. Human Immunodeficiency Virus Preexposure Prophylaxis: Meeting the Needs of Transgender Populations. Vol. 73, Clinical Infectious Diseases. 2021.  
70. Cattani VB, Jalil EM, Eksterman L, Torres T, Cardoso SW, Castro CRV, et al. Impact of feminizing hormone therapy on tenofovir and emtricitabine plasma pharmacokinetics: A nested drug-drug interaction study in a cohort of Brazilian transgender women using HIV pre-exposure prophylaxis. Journal of Antimicrobial Chemotherapy. 2022;77(10).  
71. Cespedes MS, Das M, Yager J, Prins M, Krznaric I, de Jong J, et al. Gender Affirming Hormones Do Not Affect the Exposure and Efficacy of F/TDF or F/TAF for HIV  
30  
Preexposure Prophylaxis: A Subgroup Analysis from the DISCOVER Trial. Transgend Health. 2022;  
72. Shuper PA, Joharchi N, Bogoch II, Loutfy M, Crouzat F, El-Helou P, et al. Alcohol consumption, substance use, and depression in relation to HIV Pre-Exposure Prophylaxis (PrEP) nonadherence among gay, bisexual, and other men-who-have-sex-with-men. BMC Public Health. 2020;20(1).  
73. Rutstein SE, Smith DK, Dalal S, Baggaley RC, Cohen MS. Initiation, discontinuation, and restarting HIV pre-exposure prophylaxis: ongoing implementation strategies. Vol. 7, The Lancet HIV. 2020.  
74. Aguirrebengoa OA, Coll P, Aguas V, Cortés R, Corma A, Ángel G, et al. 2 Recomendaciones sobre la profilaxis pre-exposición para la prevención de la infección por VIH en España Coordinadores Comité de redacción.  
75. Ayerdi O, Orviz E, Valls Carbó A, Fernández Piñeiro N, Vera García M, Puerta López T, et al. Incidence of sexually transmitted infections and screening models among preexposure prophylaxis users. Enferm Infecc Microbiol Clin. 2024;  
76. Kim C mill, Zhao V, Brito De Mello M, Baggaley R, Johnson CC, Spielman E, et al. Determining the screening frequency for sexually transmitted infections for people who use HIV pre-exposure prophylaxis: a systematic review and meta-analysis. International Journal of Infectious Diseases. 2023;129.  
77. EACS European AIDS Clinical Society 1 EACS Guidelines 12.0.  
78. Jalil EM, Torres TS, Luz PM, Monteiro L, Moreira RI, de Castro CRV, et al. Low PrEP adherence despite high retention among transgender women in Brazil: the PrEParadas study. J Int AIDS Soc. 2022;25(3).  
79. Ministério da Saúde B. Painel PrEP. 2024. Disponível em: <u>https://www.gov.br/aids/ptbr/assuntos/prevencao-combinada/prep-profilaxia-pre-exposicao/painel-prep</u>  
80. Garrison LE, Haberer JE. Pre-exposure Prophylaxis Uptake, Adherence, and Persistence: A Narrative Review of Interventions in the U.S. Am J Prev Med. 2021;61(5).  
81. Bruxvoort K, Portugal C, Munis M, Pak K, Hechter R. Understanding Barriers and Facilitators of Pre-exposure Prophylaxis (PrEP) Among Transgender and Gender Diverse Adults in an Integrated Health Care System. AIDS Behav. 2023;27(8).  
82. Ministério da Saúde. Guia Rápido de Testagem Focalizada para o HIV, 2018.  
31

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Material Suplementar - Atualizações propostas para o PCDT PrEP 2024** -->
|**Tema**|**Versão 2022**|**Versão 2024 (acréscimo/mudança)**||**Fonte**|
|---|---|---|---|---|
|Testagem para HIV|Teste rápido, sorologia para HIV|Teste<br>rápido,<br>sorologia<br>para<br>HIV:<br>a) Autoteste para início da PrEP no contexto do teleatendimento<br>b)Autotestepara seguimento|Nota Técni<br>CGAHV/.DA|ca Nº 26/2024-<br>THI/SVSA/MS<br>|
|Vacinas|Hepatite A, Hepatite B|HPV|NOTA<br>CONJUNTA<br>CGICI/DPNI|TÉCNICA<br> <br>Nº<br>101/2024-<br>/SVSA/MS|
|Dosagem<br>de<br>Creatinina|Indicada para todas as pessoas, independentemente da<br>idade.|Para menores de 30 anos e sem fator de risco passa a ser opcional para<br>início e acompanhamento|Atualização|PCDT|
|Tempo para proteção|Mulheres cis, pessoas trans designadas do sexo<br>feminino ao nascer e qualquer pessoa em uso de<br>hormônio à base de estradiol: 20 dias<br>Homens cisgêneros, pessoas não binárias designadas<br>como do sexo masculino ao nascer, e travestis e<br>mulheres transexuais - que não estejam em uso de<br>hormônios à base de estradiol: 2 horas|Mulheres cis, pessoas trans designadas do sexo feminino ao nascer e<br>qualquer pessoa em uso de hormônio à base de estradiol: 7 dias<br>Homens cisgêneros, pessoas não binárias designadas como do sexo<br>masculino ao nascer, e travestis e mulheres transexuais - que não<br>estejam em uso de hormônios à base de estradiol: 2 horas|Nota<br> <br>08/2023/CG<br>/MS<br>Brasil. Mini<br>Secretaria|Técnica<br>n°<br>AHV/.DCCI/SVS<br>stério da Saúde.<br>de<br>Ciência,|
|PrEP sob demanda|-|População elegível: Homens cisgêneros, pessoas não binárias<br>designadas como do sexo masculino ao nascer, e travestis e mulheres<br>transexuais - que não estejam em uso de hormônios à base de estradiol.<br>Posologia: 2+1+1(2 horas antes do sexo,24 horas|Tecnologia<br>Complexo<br>Industrial<br>Departament|e Inovação e do<br>Econômico<br>da<br>Saúde.<br>o de Ciência e|
|Tempo<br>para<br>interrupção|Caso tenha havido relações sexuais com potencial<br>risco de infecção pelo HIV, recomenda-se, antes da<br>interrupção da PrEP, que o usuário mantenha o uso da<br>profilaxia por um período de 28 dias, a contar da data<br>da potencial exposição de risco. Apenas no caso de<br>usuário HSH cis pode-se diminuir esse período, com<br>manutenção do uso da PrEP por 2 (dois) dias após a<br>última exposição,conforme recomendação daOMS|Mulheres cis, pessoas trans designadas do sexo feminino ao nascer e<br>qualquer pessoa em uso de hormônio à base de estradiol: por mais 7<br>dias após a última prática sexual.<br>Homens cisgêneros, pessoas não binárias designadas como do sexo<br>masculino ao nascer, e travestis e mulheres transexuais - que não<br>estejam em uso de hormônios à base de estradiol: por mais 2 dias após<br>a última prática sexual.|Tecnologia.<br>Geral de Evi<br>Revisão Sis<br>Segurança,<br>efetividade d<br>exposição s<br>prevenção d<br>Ministério da|Coordenação-<br>dências em Saúde.<br>temática Rápida:<br>eficácia<br>e<br>a profilaxia pré-<br>ob demanda na<br>o HIV. Brasília:<br>Saúde,2024.|
|Intervalos entre as<br>consultas|90 dias|120 dias<br>180 dias para usuários com adesão regular, sem histórico de<br>interrupção,hápelo menos um ano.|Atualização|PCDT.|  
32

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Profilaxia Pré-Exposição (PrEP) Oral à Infecção pelo HIV, contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O público-alvo deste documento é composto por profissionais da saúde e gestores que realizam o cuidado de pessoas candidatas e usuárias de PrEP.  
A atualização teve início em agosto de 2023. A reunião com o painel de especialistas ocorreu em 17/06/2024.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Equipe de elaboração** -->
O grupo elaborador deste PCDT foi composto pela equipe técnica da Coordenação Geral de Vigilância de HIV/aids e de especialistas sob coordenação do DATHI.  
O levantamento de evidências resultante das buscas na literatura científica foi utilizado para a elaboração da proposta preliminar de atualização. Previamente, os especialistas receberam a proposta elaborada pela Área Técnica, que elencava os pontos-chave para a atualização do PCDT.  
O painel de especialistas é composto por médicos infectologistas, médicos da família e comunidade, representante da Sociedade Brasileira de Infectologia e da sociedade civil organizada e foi responsável pelo julgamento das atualizações identificadas em resposta às questões deste Protocolo e das suas respectivas recomendações, além de revisão do documento final. Todos os participantes externos ao Ministério da Saúde assinaram um formulário **de Declaração de Conflitos de Interesse e confidencialidade** .  
Durante o encontro, foi apresentada a síntese dos resultados dos estudos visando a buscar o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura. Após a reunião, as decisões foram incorporadas ao texto do documento, o qual foi compartilhado com o Comitê Técnico Assessor para a definição da versão final. As sugestões adicionais foram consolidadas pela equipe da Área Técnica.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT para Profilaxia Pré-Exposição (PrEP) Oral à Infecção pelo HIV foi apresentada na 117ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo EconômicoIndustrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 19ª Reunião Extraordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Consulta pública** -->
A Consulta Pública nº 53/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) Oral à Infecção pelo HIV, foi realizada entre os dias 30/08/2024 a 18/08/2024. Foram recebidas 15 contribuições, que podem ser verificadas  
33  
em: publicas/encerradas.  
https://www.gov.br/conitec/pt-br/assuntos/participacao-social/consultas-

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Busca da evidência e recomendações** -->
O processo de revisão inicial deste documento foi realizado pela equipe técnica da Coordenação Geral de Vigilância do HIV/aids (CGHA/DATHI/SVSA/MS). Nesta proposta, foram estabelecidos os seguintes pontos que demandavam atualização:  
- a) Recomendação de uso de autoteste de HIV para início e seguimento da PrEP.  
- b) Indicação de vacinação de HPV para usuários de PrEP.  
- c) Atualização sobre o intervalo de tempo seguro para início da proteção e interrupção da PrEP.  
- d) Indicação de PrEP sob demanda, como nova posologia.  
- e) Ampliação do intervalo de retorno entre as consultas.  
Para cada um dos assuntos, foi realizada uma busca estruturada da literatura científica. A seleção dos estudos considerou as revisões sistemáticas (RS) com e sem meta-análises, ensaios clínicos randomizados (ECR), protocolos clínicos e diretrizes internacionais, além de anais de congresso nacionais e internacionais.  
As recomendações alteradas ou incluídas foram sintetizadas no Material Suplementar deste Protocolo.  
Estratégias de busca, de acordo com a base de pesquisa, para identificação dos principais pontos de atualização neste PCDT.  
Considerando as estratégias de busca descritas no **Quadro A** , foram realizadas buscas na literatura referentes ao uso do autoteste de HIV.  
**<u>Quadro A.</u>** Estratégia de busca sobre autoteste de HIV  
|**Base de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Pubmed e LILACS|((Self-Testing) AND (accuracy) AND<br>(rapidtest)AND(HIV))|36|  
Fonte: Elaboração própria.  
A etapa de seleção, incluindo a resolução de duplicatas, foi realizada por meio do software Rayyan, de forma independente por dois pesquisadores. Foram selecionados 16 artigos para leitura em pares e extração dos dados de sensibilidade e especificidade do autoteste de HIV. Os estudos foram descritos no **Quadro B** . Foram excluídos artigos de autoteste de outros agravos com finalidade diversa do HIV, como por exemplo, Covid-19 dentre outros.  
Identificadas a sensibilidade e especificidade, buscou-se analisar as vantagens e desvantagens relacionadas ao autoteste de HIV no contexto da PrEP, sintetizadas na <u>NOTA TÉCNICA Nº 26/2024-CGAHV/.DATHI/SVSA/MS.</u>  
34

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **<u>Quadro B</u>** <u>. Síntese das evidências sobre autoteste de HIV</u> -->
|**Publicação**|<br>**Autoria**|**Tipo de estudo**|<br>**País**|**Amo**<br>**HIV-**|**stra**<br>**HIV+**|**Tipo de teste**|**Comparador**|**Sensibilidade**|**IC**|**Especificidade**|<br>**IC**|**Acurácia**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|01/01/2012|Ng et al.|Transversal|Singapura|794|200|Autoteste/FO|TR/FO|97,40%|95%: 95,1% a<br>99,7%|99,90%|95%: 99,6 a<br>100%||
|01/01/2011|<sup>Choko</sup><br>et<br>al.|<br>Transversal|Malaui|283|53|Autoteste/FO|TR/Sangue|||||99,20%|
|01/01/2016|Kurth et al.|Tranversal|Quênia|203|30|Autoteste/FO|TR/Sangue|89,70%|95%;73-98%|98%|95%; 89-<br>99%||
|01/01/2015|<sup>Choko</sup><br>et<br>al.|<br>Prospectivo|Malaui|14.004|1.257|Autoteste/FO|TR/Sangue|93,60%|95%; 88,2%-<br>97%|99,90%|95% CI<br>99.6%–<br>100%||
|01/01/2016|Sarkar et al.|Transversal|India|200|2|Autoteste/FO|TR/Sangue|100%||100%|||
|01/01/2015|Wang et al.|Intervencional|China|510|NC|Autoteste/FO|ELISA + WB|86%|95%; 81·09–<br>95·62|98%|97·88–<br>98·52||
|01/01/2019|Belete et al.|Transversal|Etiópia|200|200|Autoteste/FO|TR/Sangue|99,50%|95%; 97,26-<br>99,99|100%|95%; 98,18-<br>100||
|01/01/2022|<sup>Neuman et</sup><br>al.|<br>Transversal|Zambia|2566||Autoteste/FO|Imunoensaio<br>Ag/Ab|87,50%|95%;82,7-91,3|99,70%|95%; 99,4-<br>99,7||
|01/01/2014|<sup>Jaspard et</sup><br>al.|<br>Comparativo|França|60|179|Autoteste/FO<br>Autoteste/sangue|-<br>Imunoensaio<br>lab|87,2%;<br>88,3%||98,3%;100%|||
|01/01/2019|<sup>Devillé</sup><br>et<br>al.|<br>Observacional|África do Sul|1241|102|Autoteste/FO|TR/FO|99,02|95%; 93,88-<br>99,95|100%|95%; 99.62-<br>100||
|01/01/2016|<sup>Martínez et</sup><br>al.|<br>Implementação|África do Sul|2198||Autoteste/FO|TR/FO|98,70%|95%;96,8-99,6|100%|95%; 99,8-<br>100||
|01/01/2018|Rasmi et al.|Transversal|Tailândia|321|208|Autoteste/FO|TR/Sangue|90,14%|95%; 80,74-95-<br>94|99%|95%; 97,78-<br>99,76|97,92%|
|01/01/2021|<sup>Majam</sup><br>et<br>al.|<br>Transversal|África do Sul||507|Autoteste/FO|Imunoensaio<br>lab|98,20%|95%;96,8-99,3|99,80%|95%; 99,4-<br>100||
|01/01/2012|Pai et al.|Revisão<br>sistemática||||Autoteste/FO|TR/Sangue|98,03%||100%|||
|01/01/2016|<sup>Martínez et</sup><br>al.|<br>Transversal|África do Sul|2198||Autoteste/FO|TR/Sangue|98,70%|95%;96,8-99,6|100%|95%-99,8-<br>100||
|01/01/2021|<sup>Majam</sup><br>et<br>al.|<br>Transversal|Senegal e África do<br>Sul|2152||Autoteste/FO|TR/Sangue|99,80%||100%|||  
Fonte: Elaboração própria.  
35  
Para a recomendação acerca da ampliação da vacina do HPV, incluindo usuários de PrEP, após busca estruturada da literatura científica (NOTA TÉCNICA CONJUNTA Nº 101/2024- <u>CGICI/DPNI/SVSA/MS), os resultados foram apresentados à 1ª Reunião da Câmara Técnica de</u> Assessoramento em Imunizações (CTAI), do Departamento do Programa Nacional de Imunizações (DPNI) ocorrida em 15 de março de 2024 para definição do número de doses e operacionalização da vacinação. Posteriormente, a recomendação foi pactuada no Grupo de Trabalho de Vigilância em Saúde no dia 13 de junho 2024.  
Em relação à recomendação sobre a oferta da PrEP oral na modalidade “sob demanda”, ressalta-se que esta consiste no uso de antirretrovirais (tenofovir/emtricitabina) de maneira planejada, seguindo o esquema “2+1+1”, ou seja, toma-se 2 comprimidos entre 2 e 24h antes da exposição de risco, um comprimido 24h após a dose dupla inicial e mais um comprimido 24h após a segunda dose. Para tal, foi elaborada a seguinte pergunta de pesquisa:  
**Questão:** A PrEP sob demanda é segura e eficaz/efetiva na prevenção de infecção por HIV quando comparada a PrEP de uso diário ou placebo?  
|População de<br>Interesse|Pessoas com idade ≥ 15 anos, sem infecção por HIV|
|---|---|
|Intervenção|PrEP sob demanda (antirretroviral de uso oral)|
|Comparador|Placebo, nenhum comparador, PrEP diária de uso oral ou qualquer outro<br>esquema posológico alternativo de PrEP|
|Desfecho|Segurança, eficácia e/ou efetividade na prevenção de infecção pelo HIV;<br>Grupos populacionais que usaram essa modalidade.|
|Tipos<br>de<br>Estudos|Revisão sistemática, ensaios clínicos e estudos observacionais (coorte)|

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Critérios de elegibilidade** -->
Foram incluídos revisões sistemáticas, ensaios clínicos randomizados ou não randomizados e estudos observacionais (coorte), que avaliassem parâmetros relacionados à segurança, eficácia e/ou efetividade da PrEP sob demanda, na modalidade de uso oral, para prevenção de infecção pelo HIV. Foram incluídos estudos publicados em português, inglês e espanhol, sem restrição quanto à data ou status da publicação.  
Foram excluídos os estudos que:  
- Não individualizaram os resultados para pessoas HIV-negativa e positiva ao final  
- do estudo;  
- Avaliaram segurança, eficácia e/ou efetividade apenas da PrEP de uso diário;  
- Avaliaram segurança, eficácia e/ou efetividade da PrEP em diferentes  
- modalidades, sem individualizar os resultados para PrEP sob demanda de uso oral;  
- Avaliaram apenas PrEP sob demanda injetável ou tópica;  
- Foram publicados apenas como resumos de congresso e opinião de especialistas;  
- Não relataram informações suficientes;  
- Não estavamdisponíveis para leitura na íntegra.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Estratégia de Busca** -->
A estratégia de busca foi construída no PubMed, utilizando a estrutura do acrônimo PICOS (População, Intervenção, Comparador, Desfecho e Tipo de estudo) e, posteriormente, adaptada para as demais bases.  
Foram utilizados os vocabulários controlados DeCS/MeSH/EMTREE e sinônimos para os termos "HIV”, “Pre-Exposure Prophylaxis” e “on-demand” ( **Quadro C** ). As buscas foram realizadas nas seguintes bases de dados em 28 de junho de 2024: PubMed, EMBASE e Cochrane Library.  
36  
**Quadro C** . Estratégia de busca para PrEP sob demanda em cada base de dados  
|**Fontes**<br>PubMed|**Termos**<br>("HIV Infections"[MeSH Terms] OR "HIV"[MeSH Terms] OR<br>"HIV Infections"[All Fields] OR "HIV"[All Fields] OR "hiv<br>infect*"[All Fields] OR "human immunodeficiency virus"[All<br>Fields] OR "human immunedeficiency virus"[All Fields] OR<br>"human immuno-deficiency virus"[All Fields] OR "human<br>immune-deficiency virus"[All Fields] OR "human immun*<br>deficiency virus"[All Fields] OR "acquired immunodeficiency<br>syndrome"[All<br>Fields]<br>OR<br>"acquired<br>immunedeficiency<br>syndrome"[All<br>Fields]<br>OR<br>"acquired<br>immuno-deficiency<br>syndrome"[All<br>Fields]<br>OR<br>"acquired<br>immune-deficiency<br>syndrome"[All<br>Fields]<br>OR<br>"acquired<br>immun*<br>deficiency<br>syndrome"[All Fields]) AND ("Pre-Exposure Prophylaxis"[MeSH<br>Terms]<br>OR<br>"Pre-Exposure<br>Prophylaxis"[All<br>Fields]<br>OR<br>"prophylaxis pre exposure"[All Fields] OR "PrEP"[All Fields] OR<br>"Tenofovir"[MeSH Terms] OR "Tenofovir"[All Fields] OR<br>"tenofovir disoproxil fumarate/emtricitabine"[All Fields] OR<br>"tenofovir/emtricitabine"[All Fields] OR "TDF/FTC"[All Fields]<br>OR<br>"antiretroviral<br>chemoprophylaxis"[All<br>Fields]<br>OR<br>"chemoprevention"[All Fields]) AND ("on-demand"[All Fields]<br>OR "event driven"[All Fields] OR "Non-daily"[All Fields] OR<br>"event-based"[All Fields] OR "intermittent"[All Fields] OR "2-1-<br>1"[All Fields] OR "sex driven"[All Fields] OR "time driven"[All<br>Fields] OR "pericoital"[All Fields])|**Total**<br>413|
|---|---|---|
|Embase|('hiv' OR 'hiv infections' OR 'hiv infect*' OR 'human<br>immunodeficiency virus' OR 'human immunedeficiency virus' OR<br>'human immuno-deficiency virus' OR 'human immune-deficiency<br>virus' OR 'human immun* deficiency virus' OR 'acquired<br>immunodeficiency syndrome' OR 'acquired immunedeficiency<br>syndrome' OR 'acquired immuno-deficiency syndrome' OR<br>'acquired immune-deficiency syndrome' OR 'acquired immun*<br>deficiency syndrome') AND ('pre-exposure prophylaxis' OR<br>'prophylaxis pre exposure' OR 'prep' OR 'tenofovir' OR 'tenofovir<br>disoproxil fumarate/emtricitabine' OR 'tenofovir/emtricitabine' OR<br>'tdf/ftc'<br>OR<br>'antiretroviral<br>chemoprophylaxis'<br>OR<br>'chemoprevention') AND ('on-demand' OR 'event driven' OR 'non-<br>daily' OR 'event-based' OR 'intermittent' OR '2-1-1' OR 'sex driven'<br>OR 'time driven' OR 'pericoital') AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim)|382|
|Cochrane<br>Library|(“HIV Infections” OR “HIV” OR “HIV Infections” OR “HIV” OR<br>“hiv infect*” OR “human immunodeficiency virus” OR “human<br>immunedeficiency virus” OR “human immuno-deficiency virus”<br>OR “human immune-deficiency virus” OR “human immun*<br>deficiency virus” OR “acquired immunodeficiency syndrome” OR<br>“acquired immunedeficiency syndrome” OR “acquired immuno-<br>deficiency<br>syndrome”<br>OR<br>“acquired<br>immune-deficiency<br>syndrome” OR “acquired immun* deficiency syndrome”) AND|177|  
37  
|**Fontes**|<br>**Termos**|**Total**|
|---|---|---|
||("Pre-Exposure Prophylaxis" OR "Tenovofir" OR "Pre-Exposure<br>Prophylaxis" OR "prophylaxis pre exposure" OR "PrEP" OR<br>"tenofovir<br>disoproxil<br>fumarate/emtricitabine"<br>OR<br>"tenofovir/emtricitabine" OR "TDF/FTC" OR "antiretroviral<br>chemoprophylaxis" OR "chemoprevention") AND ("on-demand"<br>OR "event driven" OR "Non-daily" OR "event-based" OR<br>"intermittent" OR "2-1-1" OR "sex driven" OR "time driven" OR<br>"pericoital")||
||TOTAL:  972||

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Triagem e seleção dos artigos** -->
Para o gerenciamento de referências, a triagem e a seleção dos estudos obtidos a partir das bases de dados, foi utilizada a plataforma Rayyan. Após a remoção dos registros duplicados, dois autores executaram a triagem de títulos e resumos, conforme os critérios de elegibilidade previamente definidos. Em seguida, os autores realizaram a leitura de texto completo, registrando os motivos de exclusão dos estudos que não atenderam aos critérios de elegibilidade. No caso de conflitos, esses foram resolvidos por consenso entre os autores.  
Após a etapa de triagem, 3 estudos e uma revisão sistemática descritos foram selecionados:

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Estudo clínico IPERGAY (Intervention Préventive de l’Exposition aux Risques avec et pour les Gays)**<sup>11</sup> -->
Em 2015, Molina e colaboradores publicaram os resultados iniciais do ensaio clínico randomizado (ECR) conhecido como IPERGAY, que foi realizado na França e no Canadá. Quatrocentos pacientes HSH cis foram randomizados para um regime posológico sob demanda que envolvia: 1) 2 comprimidos (TDF/FTC ou placebo) entre 2 e 24 horas antes do sexo, 2) 1 comprimido 24 horas após a primeira dose, 3) 1 comprimido 48 horas após a primeira dose, 4) comprimidos diários contínuos se a atividade sexual continuasse até 48 horas após a última relação sexual. As visitas do estudo foram programadas para 4 e 8 semanas após a inclusão, e depois a cada 8 semanas.  
Nessas visitas, os participantes completaram uma entrevista assistida por computador, fizeram uma coleta de sangue, receberam aconselhamento sobre adesão e redução de risco, receberam diagnóstico e tratamento de ISTs como indicado, e tiveram uma contagem de comprimidos e um novo fornecimento do medicamento. Após uma análise interina pelo conselho de monitoramento de dados e segurança na qual a eficácia foi determinada, o braço placebo foi interrompido e a todos os participantes do estudo foram oferecidos TDF/FTC. Na fase cega do ensaio, os resultados demonstraram uma redução relativa de 86% no risco de infecção pelo HIV, em comparação com aqueles recebendo placebo cuja eficácia foi de 86% (intenção de tratar; IC 95%: 40-98%, P=0,002).  
A população estudada pelo IPERGAY apresentava um risco particularmente alto para infecção por HIV, tendo frequentes atos sexuais desprotegidos. Os participantes relataram ter utilizado uma média de 15 comprimidos de TDF/FTC ou placebo por mês, e a análise das concentrações plasmáticas dos medicamentos, em um subconjunto daqueles randomizados para TDF/FTC, indicou que 86% apresentavam concentrações de tenofovir consistentes comparado a ter tomado o medicamento durante e a semana anterior. Em contraste, no estudo iPrEx (estudo pivotal referente a dose diária), apenas 50% dos participantes do braço intervenção apresentaram níveis detectáveis dos fármacos após a randomização para o uso diário<sup>3</sup> .  
Duas infecções pelo HIV ocorreram no braço TDF/FTC, ambas após a PrEP ter sido interrompida por um a três meses. Com base no protocolo do estudo, se ocorresse uma pausa de mais de uma semana desde a última dose, a reiniciação deveria ocorrer com uma dose de 2 comprimidos antes da relação sexual; se ocorresse um intervalo de menos de uma semana, o  
38  
reinício previa um comprimido antes da relação sexual. Entretanto, para simplificar as recomendações de dose entre as pessoas que param e reiniciam a PrEP, e prezando pela cautela, o programa da PrEP sob demanda na França e a OMS sugerem, atualmente, que todas os reinícios comecem com uma dose dupla (2 comprimidos).  
À época dos primeiros resultados do IPERGAY em 2015, era incerto se a estratégia de dose da PrEP sob demanda também funcionaria para HSH com relações sexuais pouco frequentes. Em 2017, uma análise de subgrupo do estudo IPERGAY, representando 134 pessoas/ano de acompanhamento, sendo que 269 indivíduos relataram sexo menos frequente e uso de PrEP sob demanda. Nesta análise, os participantes relataram ter uma mediana de cinco (IQR: 2 a 10) relações sexuais por mês, o que se traduziu em uma mediana de 9,5 (IQR: 6 a 13) comprimidos por mês. Todas as seis infecções relatadas ocorreram no braço placebo do estudo, com uma redução relativa da incidência de infecção por HIV de 100% no braço da intervenção (95% IC: 20-100). Isto demostrou que a PrEP sob demanda é eficaz entre Homens que fazem sexo com Homens (HSH), mesmo quando o sexo é pouco frequente.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Estudo Aberto de Extensão - IPERGAY** -->
Foram relatados resultados de estudo aberto de extensão do IPERGAY que recrutou 361 participantes do estudo original. A todos os participantes do estudo aberto foi fornecida a PrEP sob demanda como no estudo original. Após um tempo médio de acompanhamento de 18,4 meses (IQR: 17,7-19,1), a incidência de infecção por HIV observada foi de 0,19 por 100 pessoas/ano, a qual, comparada à incidência no grupo placebo do ensaio original (6,60 por 100 pessoas/ano), representou uma redução relativa de 97% (95% IC: 81-100) na infecção por HIV. O único participante que foi infectado pelo HIV não havia tomado a PrEP nos 30 dias anteriores ao teste de HIV e estava em um relacionamento contínuo com um parceiro HIV positivo.  
Dos 336 participantes com níveis plasmáticos do fármaco avaliados na visita de 6 meses, 71% tiveram detectada a presença de tenofovir. Por autorrelato, a PrEP foi utilizada na posologia prescrita para as relações sexuais mais recentes por 50% dos participantes, com dosagem subótima por 24%, e não foi usado por 26%. O sexo anal sem preservativo relatado na relação sexual mais recente aumentou de 77% no início do estudo para 86% na visita de acompanhamento de 18 meses (p=0,0004). A incidência de uma primeira infecção sexualmente transmissível (IST) bacteriana no estudo observacional (59,0 por 100 pessoas/ano) não foi maior que a observada no ensaio clínico randomizado (49,1 por 100 pessoas/ano) (p=0,11).

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Estudo de implementação: PREVENIR** -->
A França, uma das primeiras a adotar a PrEP globalmente, tem atualmente cerca de 10.400 usuários em PrEP, e suas diretrizes PrEP recomendam tanto a dose diária quanto a PrEP sob demanda para HSH cis. Prevenir é um estudo observacional em andamento, patrocinado pela agência de pesquisa francesa, _l'Agence Nationale de Récherche sur le Sida_ (ANRS), e lançado em maio de 2017. Foi planejado para demonstrar uma redução de 15% em novas infecções pelo HIV entre os participantes, utilizando a dose diária ou PrEP sob demanda. O estudo “Previnir” teve como objetivo recrutar 3.000 indivíduos HIV negativos, principalmente HSH cis, mas incluindo homens e mulheres transgêneros, homens e mulheres heterossexuais, trabalhadores do sexo e migrantes, na região de Paris. Juntamente com o estudo _Impact_ no Reino Unido e o estudo EPIC-New South Wales na Austrália, “Previnir” é um dos maiores projetos de demonstração/implementação de PrEP oral desde que a OMS recomendou a dose diária de PrEP para qualquer pessoa com alto risco de infecção pelo HIV.  
Uma análise interina apresentada em julho de 2019 na Conferência Internacional de AIDS relatou apenas duas infecções por HIV entre 3.057 participantes do estudo Prevenir utilizando a PrEP sob demanda ou dose diária. Entre os participantes, 51% receberam PrEP em dose diária e 49% escolheram PrEP sob demanda. Houve duas infecções pelo HIV no grupo PrEP sob demanda nos participantes que haviam interrompido a PrEP, e nenhuma infecção pelo HIV no grupo de uso diário. Apenas 3 participantes interromperam a PrEP devido aos eventos adversos relacionados ao medicamento, apoiando assim a segurança deste esquema posológico. Entre os participantes da PrEP sob demanda, 18% não usaram a PrEP sob demanda em suas últimas relações sexuais, mas quando a PrEP foi usada, a adesão foi alta (79%), refletindo que os  
39  
participantes eram capazes de prever quando fariam sexo e usariam esse esquema posológico. Uma observação importante na análise interina do estudo Prevenir foi que 20% dos participantes, em geral, também utilizavam preservativos, independentemente da estratégia de dose<sup>88</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Revisão sistemática com meta-análise de Eamon O Murchu e colaboradores**<sup>39</sup> -->
De forma complementar, uma revisão sistemática com metanálise publicada em 2022 avaliou 73 ensaios clínicos randomizados sobre a eficácia e segurança da PrEP em prevenir infecções por HIV, sendo que 15 cumpriram os critérios de inclusão e foram incluídos na metaanálise. Desses 15 estudos, três ensaios controlados por placebo investigaram a PrEP não diária, incluindo a PrEP sob demanda, e outros 3 estudos a PrEP de uso diário. Segundo a revisão, de um modo geral, a PrEP é particularmente eficaz em HSH, com uma redução da taxa de infecção pelo HIV em 75% considerando todos os estudos clínicos analisados (total de seis), subindo para 86% em estudos com alta adesão. Apenas um ensaio clínico randomizado investigou a eficácia da PrEP sob demanda. Este estudo relatou uma redução da taxa de infecção pelo HIV em 86%, idêntica ao único estudo comparável entre usuários da PrEP diária (ambos os ensaios recrutaram uma grande amostra de HSH e atingiram altos níveis de adesão). Seis estudos foram realizados com HSH, sendo que três foram classificados como de alta adesão (≥ 80%) e três deles de baixa adesão (< 80%). Uma meta-análise de todos os estudos resultou em um RR (risco relativo) de 0,25 (IC 95% 0,1 a 0,61), indicando uma redução de 75% na taxa de infecção pelo HIV. A diferença absoluta de taxa (RD) estimada foi de -0,03 (IC 95% -0,01 a -0,05), indicando que os usuários de PrEP tiveram uma diferença absoluta de taxa 3% menor de infecção por HIV por pessoa/ano de seguimento. Quando estratificada pela adesão (≥80% vs <80%), a heterogeneidade estatística (I<sup>2</sup> ) foi eliminada (I<sup>2</sup> reduzido de 52% para 0%). Segundo o Cochrane Handbook I<sup>2</sup> acima de 75% representa uma elevada heterogeneidade estatística entre os estudos analisados na metanálise.  
A PrEP foi mais eficaz em estudos com alta adesão ao medicamento (≥80%), como esperado, em que a taxa de infecção por HIV foi reduzida em 86% (RR 0,14, IC 95% 0,06 a 0,35; RD -0,06, IC 95% -0,04 a -0,09; I2 =0%, n=3 estudos).  
Dos três estudos com alta adesão, um estudo foi pequeno e relatou descobertas não significativas devido ao tamanho pequeno da amostra e aos poucos eventos observados. Dos dois estudos restantes, um estudo investigou o uso diário da PrEP e outro investigou a PrEP sob demanda. Ambos os estudos demonstraram eficácia idêntica (PROUD: RR 0,14, IC 95% 0,04 a 0,47; IPERGAY: RR 0,14, IC 95% 0,03 a 0,6). Quando a adesão era inferior a 80%, a taxa de infecção por HIV foi reduzida em 45% (RR 0,55, IC 95% 0,37 a 0,81; RD -0,01, IC 95% -0,00 a -0,02; I<sup>2</sup> =0%, n=3 estudos).  
Segundo a revisão sistemática, a graduação da certeza no conjunto final da evidência foi avaliada utilizando a abordagem de Grading of Recommendations Assessment, Development and Evaluation (GRADE), que incluiu uma avaliação de outros vieses, tais como o viés de publicação. A avaliação indicou que a qualidade no conjunto final da evidência foi considerada alta tanto nos estudos clínicos de HSH com alta adesão (>80%) (n=3) como nos de baixa adesão (<80%) (n=3).

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Recomendação de guias internacionais** -->
Segundo o guia estadunidense sobre PrEP dos _Centers of Disease Control and Prevention_ (CDC), o esquema posológico “2+1+1” (também chamado de orientado a eventos, intermitente ou “sob demanda”) é uma modalidade de PrEP de uso não diário que considera as doses orais de TDF/FTC antes e após as relações sexuais. Embora esse esquema posológico ainda seja um regime de uso não aprovado em bula pelas principais agências regulatórias, dois ensaios clínicos, IPERGAY e o subsequente estudo aberto Prevenir conduzido em Paris, demonstraram a eficácia na prevenção contra a infecção pelo HIV no esquema 2+1+1 apenas com TDF/FTC (exceto associação com TAF) e apenas para a população de HSH.  
A posologia foi planejada e testada principalmente para atender às necessidades de homens que tiveram sexo anal pouco frequente e, portanto, para quem a dose diária poderia não ser necessária. No entanto, nesses estudos, os homens tomaram em média 3 a 4 doses por semana, o que tem sido associado a altos níveis de proteção em homens com prescrição diária de TDF/FTC.  
40  
Atualmente, dada a eficácia demonstrada nos ensaios clínicos IPERGAY e Prevenir, a _International Antiviral Society_ -USA _Panel_<sup>89,90</sup> recomenda o regime posológico "2+1+1" como um esquema opcional, embora não aprovado em bula, alternativo à dosagem diária para HSH, assim como as diretrizes de outros países que também a recomendaram para esse grupo populacional<sup>91</sup> .  
Desde 2019, a OMS recomenda o uso da PrEP sob demanda como um esquema posológico alternativo para HSH por meio do documento técnico que atualiza as recomendações da OMS para a PrEP oral.  
Segundo documento técnico com a atualização do guia de PrEP da OMS, publicado em julho de 2022, apesar das evidências atualmente disponíveis da PrEP sob demanda serem para HSH, é razoável extrapolar que o risco de HIV associado com homens cisgêneros que fazem sexo com homens cisgêneros não deve ser inferior ao de homens cisgêneros que fazem sexo com indivíduos de outras populações. De forma similar, em pessoas não binárias designadas como do sexo masculino ao nascer e travestis e mulheres transexuais - que não façam uso de hormônios à base de estradiol - o risco de infecção pelo HIV pelo sexo anal deve ser semelhante ao dos HSH cisgêneros<sup>14</sup> . Da mesma forma, o guia europeu da _European AIDS Clinical Society_ (EACS) o guia de PrEP da Associação Britânica de HIV (BHIVA)<sup>92</sup> recomendam as duas modalidades de PrEP oral.  
Por fim, outros países como Austrália<sup>16</sup> , Canadá<sup>17</sup> e França<sup>18</sup> também recomendam o uso da PrEP sob demanda para homens cisgêneros e para pessoas não binárias designadas como do sexo masculino ao nascer, para travestis e mulheres transexuais - desde que não estejam em uso de hormônios à base de estradiol - como opção alternativa ao esquema posológico de uso diário, com base nas mesmas evidências científicas já apresentadas.

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **Referências** -->
1.  Molina JM, Capitant C, Spire B, Pialoux G, Cotte L, Charreau I, et al. On-Demand Preexposure Prophylaxis in Men at High Risk for HIV-1 Infection. New England Journal of Medicine. 2015;373(23).  
2.  Grant RM, Lama JR, Anderson PL, McMahan V, Liu AY, Vargas L, et al. Preexposure Chemoprophylaxis for HIV Prevention in Men Who Have Sex with Men. New England Journal of Medicine. 2010;363(27).  
3.  WHAT’S THE 2+1+1? EVENT-DRIVEN ORAL PRE-EXPOSURE PROPHYLAXIS TO PREVENT HIV FOR MEN WHO HAVE SEX WITH MEN: UPDATE TO WHO’S RECOMMENDATION ON ORAL PREP [Internet]. 2019. Available from: http://apps.  
4.  Antoni G, Tremblay C, Delaugerre C, Charreau I, Cua E, Rojas Castro D, et al. On-demand pre-exposure prophylaxis with tenofovir disoproxil fumarate plus emtricitabine among men who have sex with men with less frequent sexual intercourse: a post-hoc analysis of the ANRS IPERGAY trial. Lancet HIV [Internet]. 2020 Feb 1 [cited 2024 Jun 23];7(2):e113– 20. Available from: https://pubmed.ncbi.nlm.nih.gov/31784343/  
5.  Molina JM, Charreau I, Spire B, Cotte L, Chas J, Capitant C, et al. Efficacy, safety, and effect on sexual behaviour of on-demand pre-exposure prophylaxis for HIV in men who have sex with men: an observational cohort study. Lancet HIV. 2017;4(9).  
6.  National Agency for Research on AIDS and Viral Hepatitis (ANRS). Medical care of people living with HIV–prevention and screening (April 2018). Paris: French National AIDS & Viral Hepatitis Council (CNS); 2018. Disponível em: https://cns.sante.fr/wp-content/ uploads/2018/04/experts-vih_prevention-depistage.pdf.  
7.  Grulich AE, Guy R, Amin J, Jin F, Selvey C, Holden J, et al. Population-level effectiveness of rapid, targeted, high-coverage roll-out of HIV pre-exposure prophylaxis in men who have sex with men: the EPIC-NSW prospective cohort study. Lancet HIV. 2018;5(11).  
8.  Sullivan A. TRIAL PROTOCOL Protocol Title: PrEP Impact Trial: A pragmatic health technology assessment of PrEP and implementation Short Title: PrEP Impact Trial Protocol Number SSCR104 Synopsis Title: PrEP Impact Trial: A pragmatic health technology assessment of PREP and implementation Short title: PrEP Impact Trial. Protocol Number | SSCR104 PrEP Impact Trial.  
41  
9.  INCIDENCE OF HIV INFECTION WITH DAILY OR ON-DEMAND ORAL PrEP WITH TDF/FTC IN FRANCE - CROI Conference [Internet]. [cited 2024 Jun 23]. Available from: https://www.croiconference.org/abstract/incidence-of-hiv-infection-with-daily-or-ondemand-oral-prep-with-tdf-ftc-in-france/  
10.  O Murchu E, Marshall L, Teljeur C, Harrington P, Hayes C, Moran P, et al. Oral preexposure prophylaxis (PrEP) to prevent HIV: a systematic review and meta-analysis of clinical effectiveness, safety, adherence and risk compensation in all populations. BMJ Open. 2022;12(5).  
11.  Saag MS, Gandhi RT, Hoy JF, Landovitz RJ, Thompson MA, Sax PE, et al. Antiretroviral Drugs for Treatment and Prevention of HIV Infection in Adults: 2020 Recommendations of the International Antiviral Society-USA Panel. JAMA - Journal of the American Medical Association. 2020 Oct 27;324(16):1651–69.  
12.  Gandhi RT, Bedimo R, Hoy JF, Landovitz RJ, Smith DM, Eaton EF, et al. Antiretroviral Drugs for Treatment and Prevention of HIV Infection in Adults: 2022 Recommendations of the International Antiviral Society–USA Panel. JAMA [Internet]. 2023 Jan 3 [cited 2024 Jun 23];329(1):63–84. Available from: https://jamanetwork.com/journals/jama/fullarticle/2799240  
13.  CDC. US Public Health Service: PREEXPOSURE PROPHYLAXIS FOR THE PREVENTION OF HIV INFECTION IN THE UNITED STATES – 2021 UPDATE, A CLINICAL PRACTICE GUIDELINE. 2021.  
14.  WHO. Differentiated and Simplified Pre-Exposure Prophylaxis for HIV Prevention. Update to WHO Implementation Guidance. World Health Organisation Library. 2022;14(3).  
15.  BHIVA/BASHH guidelines on the use of HIV pre-exposure prophylaxis (PrEP) 2018 [Internet]. [cited 2024 Jun 23]. Available from: https://www.bhiva.org/PrEP-guidelines  
16.         The Australasian Society for HIV, Viral Hepatitis and Sexual Health Medicine (ASHM). PrEP Guidelines Update for New Zealand. Prevent HIV by Prescribing PrEP. Auckland, 2021. Disponível em: <u>https://ashm.org.au/wpcontent/uploads/2022/04/ASHM_PrEP_NZ_guidelines_FINAL_Sep t2021.pdf</u>  
17.         Canadian Medical Association Journal (CMAJ). Canadian guideline on HIV pre-exposure prophylaxis and nonoccupational postexposure prophylaxis, CMAJ 2017 November 27;189:E1448-58. Disponível em: https://www.cmaj.ca/content/cmaj/189/47/E1448.full.pdf  
18.          Haute Autorité de Santé (HAS). Réponses rapides dans le cadre de la COVID-19 - Prophylaxie (PrEP) du VIH par ténofovir disoproxil / emtricitabine dans le cadre de l’urgence sanitaire. France, 2021. Disponível em: <u>https://www.hassante.fr/upload/docs/application/pdf/202104/reco_435__reponse_rapide_prep_au_vih_150421_cd_vudoc_am_pg_vd_mel_v0.pdf</u>  
42

---

<!-- METADADOS: doenca: Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV | secao: **APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>**Relatório da**||**Tecnologias avaliadas**|**pela Conitec**<br>**Não**|
|---|---|---|---|
|**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou**<br>**alteração do uso no**<br>**SUS**|**incorporação**<br>**ou não**<br>**alteração no**<br>**SUS**|
||Alteração pós-publicação: correção da ordem<br>das seções_Efeitos adversos, Critérios para_<br>_interrupção da PrEP, Tempo necessário para_<br>_interrupção segura da PrEP_.|||
|Portaria<br>SECTICS/MS<br>nº<br>55/2024; Relatório<br>de Recomendação<br>nº 939/2024.|Mudança no título do PCDT, contemplando<br>apenas PrEP oral; Recomendação de uso de<br>autoteste de HIV para início e seguimento da<br>PrEP; Indicação de vacinação de HPV para<br>usuários de PrEP; Atualização sobre o<br>intervalo de tempo seguro para início da<br>proteção e interrupção da PrEP; Indicação de<br>PrEP sob demanda, como nova posologia;<br>Ampliação do intervalo de retorno entre as<br>consultas.|-|-|
||Recomendação da profilaxia a todos os adultos<br>e adolescentes sexualmente ativos sob risco<br>|||
|Portaria<br>SCTIE/MS<br>nº<br>90/2022; Relatório<br>de Recomendação<br>nº 739/2022.|aumentado der infecção pelo HIV; Mudança na<br>posologia inicial do medicamento com a<br>inclusão<br>da<br>dose<br>de<br>ataque<br>de<br>dois<br>comprimidos<br>de<br>fumarato<br>de<br>tenofovir<br>desoproxila/entricitabina<br>(TDF/FTC)<br>no<br>primeiro dia de uso, seguido de um<br>comprimido<br>diário;<br>Modificações<br>no<br>seguimento laboratorial.|-|-|
|Portaria<br>SCTIE/MS<br>nº<br>22/2017; Relatório<br>de Recomendação<br>nº 274/2017.|Primeira versão do documento.|Tenofovir associado à<br>entricitabina (TDF/ FTC<br>300/200mg)<br>como<br>profilaxia pré-exposição<br>(PrEP) para populações<br>sob<br>maior<br>risco<br>de<br>adquirir<br>o<br>vírus<br>da<br>imunodeficiência humana<br>(HIV), no âmbito do<br>Sistema Único de Saúde –<br>SUS [Portaria SCTIE/MS<br>nº 21/ 2017; Relatório de<br>Recomendação<br>nº<br>273/2017]|-|  
43

---

