<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: Geral -->
<!-- Start of picture text -->
x<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE -->
PORTARIA Nº 834, DE 05 DE SETEMBRO DE 2014  
Aprova as Diretrizes Diagnósticas e Terapêuticas da Leucemia Mieloide Aguda do Adulto.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a leucemia mieloide aguda do adulto no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que as diretrizes diagnósticas e terapêuticas são resultado de consenso técnico-científico e são formuladas dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública n<sup>o</sup> 13/SAS/MS, de 3 de julho de 2014;  
e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC) e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo a esta Portaria, as Diretrizes Diagnósticas e Terapêuticas - Leucemia Mieloide Aguda do Adulto.  
Parágrafo único.  As Diretrizes de que trata este artigo, que contêm o conceito geral da leucemia mieloide aguda do adulto, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia mieloide aguda do adulto.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: FAUSTO PEREIRA DOS SANTOS -->
ANEXO

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 1- METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA -->
Considerando a heterogeneidade das entidades patológicas que se descrevem como leucemia mieloide aguda (LMA), a vasta literatura sobre esta neoplasia maligna e seu predominante caráter de pesquisa, básica, translacional e clínica, nos âmbitos diagnóstico e terapêutico; os vários esquemas quimioterápicos e protocolos terapêuticos igualmente validados; e as altas complexidade e relevância do papel dos recursos humanos, materiais e de infraestrutura para o adequado atendimento dos doentes e a obtenção de bons resultados terapêuticos, aqui se apresentam diretrizes com o objetivo basicamente orientador e baseadas na experiência de grandes serviços nacionais e internacionais e em bibliografia selecionada.  
Assim, uma busca ampla da literatura foi realizada, e o caráter de restrição à inclusão dos artigos utilizado baseou-se na experiência dos autores.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 2- INTRODUÇÃO -->
As leucemias agudas resultam de uma transformação maligna das células hematopoéticas primitivas, seguida de uma proliferação clonal e consequente acúmulo dessas células transformadas. A Leucemia Mieloide Aguda (LMA) sofre, caracteristicamente, uma parada maturativa celular na fase de blastos ou promielócitos, levando à redução dos elementos normais no sangue periférico. As células apresentam marcadores mieloides específicos, incluindo bastões de Auer (grânulos aberrantes), alteração citoquímica (negro de Sudan, mieloperoxidase ou esterase não específica) e antígenos de superfície específicos. (1) O evento inicial que determina a proliferação neoplásica é desconhecido, mas é resultante de mutação somática e ocorre na célula-tronco _(stem cell)_ comprometendo a maturação mieloide (2).  
A incidência da LMA ajustada por idade é de 3,6 casos novos por 100.000 habitantes por ano, com uma idade mediana ao diagnóstico de 66 anos (3).  
As deficiências da hematopoese na medula óssea, com a substituição das células normais por células imaturas que nela se acumulam, resultam numa insuficiência funcional da medula óssea que, em consequência, se expressa clinicamente por anemia, sangramento, infecções e síndrome de hiperviscosidade. A medula óssea e o sangue periférico são principalmente caracterizados por leucocitose com predomínio de células imaturas, mormente os blastos.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
3- CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- C92.0 Leucemia mieloide aguda - Exclui: exacerbação aguda de leucemia mieloide crônica (C92.1)  
- C92.3 Sarcoma mieloide (Cloroma, Sarcoma granulocítico)  
- C92.4 Leucemia promielocítica aguda  
- C92.5 Leucemia mielomonocítica aguda  
- C92.7 Outras leucemias mieloides  
- C93.0 Leucemia monocítica aguda - Exclui: exacerbação aguda de leucemia monocítica crônica (C93.1)  
- C93.7 Outras leucemias monocíticas  
- C94.0 Eritremia e eritroleucemia agudas (Doença de Di Guglielmo)  
- C94.2 Leucemia megacarioblástica aguda - megacarioblástica (aguda),  megacariocítica (aguda)  
- C94.3 Leucemia de mastócitos  
4- CLASSIFICAÇÃO DA ORGANIZAÇÃO MUNDIAL DA SAÚDE DA LEUCEMIA MIELOBLÁSTICA AGUDA (4,5)  
A primeira tentativa para classificar a LMA foi feita pelo Grupo FAB (Franco-Americano-Britânico), com base apenas na porcentagem dos blastos, na morfologia e no grau de diferenciação da linhagem celular. O grau de diferenciação dos sub-tipos FAB M0 – FAB M7 era realizado inicialmente pela citoquímica e posteriormente pela imunofenotipagem das células imaturas. A classificação FAB é baseada essencialmente no conteúdo granular e nos aspectos nucleares dos blastos.  
Já a nova classificação da Organização Mundial da Saúde (5), baseada nas anormalidades citogenéticas ou na citogenética molecular, subdivide a LMA em diversas entidades genético-clínico-patológicas:  
LMA com anormalidades genéticas recorrentes:  
- LMA com t(8;21)(q22;q22); AML 1/ETO  
- LMA com inv(16)(p13;q22); ou t(16;16)(p13;q22);CBFBeta/MYH11  
- Leucemia promielocítica aguda com t(15;17)(q22;q12);PML/RARAlfa  - LMA com anomalia 11q23; rearranjos MLL/XX  
LMA com displasia de multilinhagens  
- LMA sem síndrome mielodisplásica (MDS) anterior  
- LMA após MDS  
LMA e MDS associada a terapia  
- LMA após terapia com alquilante  
- LMA após inibidor da topoisomerase  
- Outros tipos  
LMA não classificáveis nos grupos acima  
- LMA com mínima diferenciação (FAB M0)  
- LMA sem maturação (FAB M1)  
- LMA com maturação (FAB M2)  
- Leucemia Promielocítica aguda (FAB M3) e variante (FAB M3v)  
- Leucemia Mielomonocítica Aguda (FAB M4)  
- Leucemia Mielomonocítica Aguda com eosinofilia (FAB M4Eo)  
- Leucemia Monoblástica Aguda (FAB M5a)  
- Leucemia Monocítica Aguda (FAB M5b)  
- Leucemia Eritroide Aguda (FAB M6)  
- Leucemia Megacarioblástica Aguda (FAB M7)  
- Leucemia Basofílica Aguda (FAB M2 baso)  
- Panmielose aguda com mielofibrose  
Sarcoma mieloide  
Proliferações mieloides relacionadas com síndrome de Down  
Neoplasia de células dendríticas blástica plasmocitoide  
Leucemias agudas de linhagem ambígua  
- Leucemia Aguda Indiferenciada  
- Leucemia Aguda de Fenótipo Misto com t(9;22)(q34;q11.2); BCR-ABL 1  
- Leucemia Aguda de Fenótipo Misto com t(v;11q23); rearranjo MLL  
- Leucemia Aguda de Fenótipo Misto, B/mieloide, NOS  
- Leucemia Aguda de Fenótipo Misto, T/mieloide, NOS  
- Leucemia Aguda de Fenótipo Misto, NOS – tipos raros  
- Outras leucemias de linhagem ambígua  
5- DIAGNÓSTICO (1,2,5,6) E AVALIAÇÃO PRÉ-TRATAMENTO  
Os seguintes exames são a base do diagnóstico clínico:  
- hemograma completo com contagem diferencial;  
- citomorfologia das células blásticas, por microscopia ótica do sangue periférico (SP), medula óssea (MO) e líquor (LCR);  
- citoquímica (mieloperoxidase, negro de Sudam e esterase inespecífica) das células blásticas, como auxiliares ao diagnóstico;  
- biópsia de medula óssea no caso de aspirado medular “seco”;  
- imunofenotipagem das células blásticas do SP ou da MO;  
- avaliação citogenética convencional com um mínimo de 20 metáfases analisadas ou citogenética molecular com hibridização _in situ_ por fluorescência (FISH); e  
- avaliação por biologia molecular preferencialmente da medula óssea.  
A porcentagem de blastos exigida para o diagnóstico de LMA é 20% ou mais de mieloblastos ou monoblastos/promonócitos ou megacarioblastos no SP ou na MO. Havendo menos do que 20% de blastos no SP ou na MO, o diagnóstico de LMA também pode ser feito quando há t(8;21)(q22;q22), inv(16)(p13.1q22), t(16;16)(p13.1;q22) ou t(15;17)(q22;q12). O diagnóstico de leucemia eritroide aguda é feito nos casos com 50% ou mais de precursores eritroides na MO, associado a 20% ou mais de blastos de células não eritroides da MO. Mieloblastos, monoblastos e megacarioblastos são incluídos na contagem dos blastos. Na LMA com diferenciação monocítica ou mielomonocítica, os monoblastos e promonócitos, mas não os monócitos anormais, são considerados e contados como blastos. Eritroblastos não são contados como blastos, exceto no caso da leucemia eritroide pura.  
Por sua vez, os seguintes itens visam a determinar a invasão leucêmica extramedular e as condições clínicas do doente:  
- anamnese e exame físico;  
- exames de coagulação, incluindo a dosagem de fibrinogênio;  
- dosagem bioquímica sérica: glicose, sódio, potássio, cálcio, creatinina, dosagens das transferases/transaminases, fosfatase alcalina, DHL, bilirrubinas, ureia, proteína total, ácido úrico, colesterol total, triglicerídios, creatinofosfoquinase e enzimas pancreáticas;  
- punção lombar, se clinicamente indicada;  
- exames bacteriológicos de secreções e líquidos orgânicos, se clinicamente indicada;  
- testes sorológicos para hepatites A, B e C e para HIV;  
- exame de fezes;  
- exame de urina;  
- eletrocardiograma e ecocardiograma; e  
- radiografia simples de tórax em PA e perfil.  
- 6- CRITÉRIOS DE INCLUSÃO  
- Doentes com 19 ou mais anos de idade; e  
- observância dos critérios mínimos para o diagnóstico de LMA.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 7 - CRITÉRIOS DE EXCLUSÃO -->
Para os doentes com menos de 19 anos de idade, dever-se-ão observar as Diretrizes Diagnósticas e Terapêuticas da Leucemia Mieloide Aguda de Crianças e Adolescentes.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 8- FATORES PROGNÓSTICOS (1,6,7) -->
Aspectos clínicos (características do pacientes e sua condição de saúde), morfologia celular, marcadores de superfície e a citogenética são fatores que, em LMA, vão predizer a mortalidade relacionada ao tratamento (MRT).  
Ainda entre os aspectos clínicos faz-se necessário citar: idade do doente, capacidade funcional ( _performance status_ ), história prévia de doença medular (p.ex., síndrome mielodisplásica) e exposição a agentes quimioterápicos. Indivíduos jovens têm melhor prognóstico que os idosos. A exposição a agentes quimioterápicos também diferencia o prognóstico conforme o antineoplásico usado. A contagem de glóbulos brancos maior do que 20.000/mm3 ou desidrogenase lática (DHL) elevada, ao diagnóstico, são fatores desfavoráveis.  
O cariótipo das células leucêmicas, entretanto, é o fator mais importante para se prognosticar a resposta à quimioterapia de indução e a sobrevida global do paciente. O sistema Europeu de Prognóstico _Leukemia Net_ (ELN) categoriza o paciente adulto jovem em quatro grupos de risco: favorável, intermediário-1, intermediário-2 e adverso. O impacto das lesões genéticas secundárias, associadas a translocações ou inversões necessitam de mais investigação, com exceção da trissomia do 22 na LMA com inv(16) ou t(16;16), que tem sido associada a uma melhor sobrevida livre de recaída (SLR). Define-se o cariótipo complexo na presença de 3 ou mais (em alguns estudos, 5 ou mais) anormalidades cromossômicas. O cariótipo complexo, que ocorre em 10% a 12% dos pacientes, quando não associado a t(8;21), inv(16) ou t(16;16) e t(15;17) deve ser considerado de prognóstico adverso. As anormalidades citogenéticas de prognóstico desfavorável aumentam com a idade. Com isso, algumas classificações de risco, baseadas no estudo citogenético, têm sido propostas para a população idosa com LMA.  
Pacientes com citogenética normal e historicamente considerados de prognóstico intermediário são agora divididos em subgrupos moleculares com significativa implicação prognóstica (Tabela 1). Por exemplo, a presença da duplicação interna em _tandem_ (ITD) do gene FLT3 (FLT3-ITD) tem sido associada a doença agressiva e de mau prognóstico. Em contraste, pacientes com o gene CEBPA e NPM1 (nucleofosmina1) sem mutações concomitantes com o FLT3 têm um prognóstico significativamente favorável ao tratamento. Algumas mutações, como por exemplo o gene KIT (receptor tirosinoquinase classe III) associado a t(8;21), podem afastar a classificação inicial “favorável” da LMA.  
TABELA 1 – Sistema Europeu de Prognóstico _Leukemia Net_ (ELN) (7)  
|GRUPO GENÉTICO|SUBGRUPOS|
|---|---|  
|Favorável|t(8;21)(q22q22); RUNX1-RUNX1T1<br>inv(16)(p13;1q22) ou t(16;16)(p13.1;q22) CBFB-MYH11,|
|---|---|
||mutação NPM1 sem FLT3-ITD (cariótipo normal),<br>mutação CEBPA (cariótipo normal)|
|Intermediário-1 (*)|mutação NPM1 e FLT3-ITD (cariótipo normal)<br>wild-type NPM1 e FLT3-ITD (cariótipo|
||normal)<br>wild-type NPM1 sem FLT3-ITD (cariótipo normal)|
|Intermediário-2|t(9;11)(p22q23); MLLT3-MLL<br>anorm. citogenéticas outras que não favorável ou adversa<br>(**)|
|Adverso|Inv(3)(q21q26.2) ou t(3;3)(q21;q26.2); RPN1-EV11,<br>t(6;9)(p23;q34); DEK-NUP214;|
||t(v;11)(v;q23); re-arranjo MLL;<br>-5 ou del(5q); -7; anl(17p); cariótipo complexo (***)|  
(*) Inclui todas as leucemias mieloides agudas com cariótipo normal, exceto aquelas incluídas no subgrupo favorável; a maioria dos casos está associada com pobre prognóstico, mas eles devem ser relatados separadamente em virtude da potencial resposta diferente ao tratamento.  
(**) Para a maioria das anormalidades, números adequados não foram estudados para tirar conclusões com relação ao seu significado prognóstico.  
(***) Três ou mais anormalidades cromossômicas na ausência de uma das translocações recorrentes ou inversões designadas pela OMS, isto é, t(15;17), t(8;21), inv(16) ou t(16;16), t(9;11), t(v;11)(v;q23), t(6;9), inv(3) ou t(3;3); indicam quantos casos de cariótipos complexos têm envolvimento dos braços dos cromossomas 5q, 7q e 17p.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 9- TRATAMENTO (1,2,4,6,7,8,9,10,11,12,13) -->
O tratamento da LMA exige uma quimioterapia inicial de indução de remissão, com o objetivo de atingir remissão completa (RC) da doença e consequente restauração das células sanguíneas normais. Esta fase é seguida por uma terapia de pós-remissão para erradicar a doença residual mínima (DRM). Depois, dois a quatro cursos de “consolidação” com ou sem tratamento prolongado de “manutenção”.  
A cura da LMA ocorre ainda numa minoria de pacientes adultos que se submetem aos diversos protocolos de quimioterapia e, nos casos de prognóstico intermediário ou desfavorável, apesar do elevado potencial de morbidade, os resultados do transplante de células-tronco hematopoéticas alogênico (alo-TCTH) ou autólogo (auto-TCTH) são melhores do que os obtidos com a quimioterapia padrão, sendo que o auto-TCTH é reservado para o paciente que atingiu resposta molecular após recaída da leucemia do subtipo promielocítica aguda (LPMA).  
As indicações de TCTH devem observar os critérios do Regulamento Técnico do Sistema Nacional de Transplantes.  
Existem dois obstáculos para a cura: a mortalidade relacionada ao tratamento (MRT) e a resistência à quimioterapia. Com isso, os protocolos terapêuticos atuais distinguem os pacientes jovens dos pacientes idosos (idade igual ou maior de 60 anos), pois o idoso está associado a índice de capacidade funcional mais alto (ou seja, pior) e a anormalidade no exame citogenético. Independentemente da idade, o objetivo inicial do tratamento da LMA é atingir a RC (medula óssea com menos de 5% de mieloblastos e, no sangue periférico, neutrófilos acima de 1.000/mm3 e plaquetas acima de 100.000/mm3) para o controle da hematopoese. Para ser considerado potencialmente curado, os pacientes devem permanecer em RC por 2 a 3 anos, quando, então, o risco de recaída da LMA diminui seguramente para menos de 10%.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 9.1. MODALIDADES TERAPÊUTICAS -->
Terapia de Indução – Três dias de antraciclina (ou daunorrubicina ou idarrubinia ou mitoxantrona) e 7 dias de citosina arabinosídio  (protocolo “7 + 3”) continua sendo o tratamento padrão para a indução de remissão da LMA do adulto. Este tratamento ocasiona um período de pancitopenia grave durante 3 a 4 semanas, necessitando-se de tratamento de suporte e por vezes com internação em Unidade de Tratamento Intensivo. A maioria dos protocolos de tratamento preconiza o exame de medula óssea uma semana após o término do esquema quimioterápico e, se houver células leucêmicas residuais, administra-se um segundo curso de quimioterapia com outros antineoplásicos e doses mais intensas. O índice de remissão completa é de 60% a 80% no grupo de pacientes jovens.  
Terapia de Consolidação – Cerca de 30% dos pacientes de LMA recidivam nos primeiros 6 meses e mais de 50% no primeiro ano. Com o objetivo de retardar ou prevenir a recidiva do paciente jovem, tem-se preconizado a terapia pós-remissão, que consiste em ciclos repetitivos (pelo menos 3 ciclos) de citosina arabinosídio em altas doses (HiDAC, sigla em Inglês). O uso de consolidação intensiva prolongada ou de poliquimioterapia não parece ser superior a HiDAC isolada.  
Terapia de Manutenção – Exceto nos casos de leucemia promielocítica aguda (LPMA), o tratamento de manutenção não deve ser administrado rotineiramente no adulto com LMA.  
Transplante de células-tronco hematopoéticas – Apesar do elevado potencial de morbidade, talvez seja a terapia anti-LMA mais efetiva para os casos de prognóstico intermediário ou desfavorável. Essa morbidade, entretanto, assim como a mortalidade vêm declinando com a melhora da terapia antimicrobiana e com o controle da doença do enxerto contra o hospedeiro. Além disso, o número de doadores não aparentados e a doação de sangue de cordão umbilical vêm se expandindo, aumentando progressivamente a chance de identificação de doadores compatíveis.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 9.2. SITUAÇÕES ESPECIAIS -->
Terapia do idoso – Na avaliação inicial do paciente idoso com LMA, deve-se, mesmo antes de realizar exames invasivos, ponderar, de modo criterioso, sobre os parâmetros clínicos, econômicos, sociais e psicológicos para uma determinação precisa do planejamento terapêutico. Pacientes com idade entre 60 e 74 anos e com _performance status_ abaixo do índice 2 de Zubrod e sem comorbidades podem ser tratados como o adulto jovem, resultando em uma taxa de 50% de RC e de morte pelo tratamento abaixo de 15%. As doses, entretanto, precisam ser individualizadas. Para o subtipo com citogenética de mau prognóstico, a taxa de RC é de apenas 30%, com SG abaixo de 5%.  Já para o paciente muito idoso (75 ou mais anos), a alternativa é a utilização da citarabina subcutânea em baixas doses, que é associada a uma sobrevida maior quando comparada a hidroxiureia oral.  
Sarcoma mieloide – O sarcoma mieloide (que tem como sinônimos tumor mieloide extramedular, sarcoma granulocítico e  cloroma) é uma massa tumoral extramedular constituído de blastos mieloides e situado principalmente na pele, linfonodo, trato gastrointestinal, osso, tecido conectivo e testículo. O sarcoma mieloide pode preceder a LMA, estar a ela associado ou ser uma transformação de uma mielodisplasia ou de uma síndrome mieloproliferativa. Seu diagnóstico é dado pela citoquímica ou pela imuno-histoquímica, e a morfologia é, em geral, mielomonocítica ou monoblástica. É ainda associado com hiperleucocitose, t(8;21) e positividade para CD56. O sarcoma mieloide _de novo_ (ou seja, sem ser por evolução de outro tipo de hemopatia de linhagem mieloide) deve ser tratado como LMA. Dados sobre o impacto no prognóstico é limitado: enquanto alguns estudos relatam um impacto negativo, outros sugerem que a quimioterapia padrão seguida de transplante de células-tronco hematopoéticas não é inferior aos resultados da terapia da LMA do adulto. O tumor é sensível à radioterapia.  
Acometimento do sistema nervoso central – A invasão do sistema nervoso (SNC) na LMA ocorre em menos de 5% dos pacientes adultos. Inexiste indicação para profilaxia com quimioterapia intratecal nos pacientes sem sintomas do SNC, embora possa ela ser considerada em situações especiais, como, por exemplo, na hiperleucocitose. Nos pacientes com acometimento do SNC, 40mg a 50mg de citarabina devem ser administradas intratecalmente, 2 a 3 vezes por semana, até o desaparecimento das células blásticas do líquor, seguidas por mais 3 injeções deste mesmo medicamento.  
Recidiva da LMA – A maioria das recidivas ocorre dentro dos 3 anos do diagnóstico, tornando as opções de tratamento insatisfatórias. Sobrevida longa dependerá do sucesso da indução de remissão com esquemas diferentes da primeira indução (mitoxantrona, vepesido ou fludarabina) e da possibilidade de consolidação com TCTH. O prognóstico do paciente que recai é determinado por fatores como idade, duração da primeira remissão e cariótipo.  
Leucemia promielocítica aguda – Há 50 anos, a leucemia promielocítica aguda (LPMA) tem sido identificada como uma entidade clínica separada, por ter uma fisiopatologia única e por merecer cuidados especiais no início do tratamento. Em mais de 95% dos casos a LPMA resulta da translocação cromossômica t(15;17), detectável pela citogenética convencional, pelo FISH ou RT-PCR. O rearranjo dos genes PML/RARA pode ser detectado por técnicas moleculares, tais como FISH ou RT-PCR. Embora seja caracterizada por uma morfologia típica, com grânulos anormais e múltiplos bastões de Auer, existe uma variante microgranular que faz pensar em LPMA quando houver distúrbio de coagulação associado. A LPMA, comparada com outros tipos de LMA do jovem, ocorre com mais frequência nos hispânicos e nos obesos. A LPMA é sensível à daunorrubicina e à idarrubicina e é especialmente sensível ao ácido transretinoico (ATRA) que age induzindo a maturação das células blásticas, levando à remissão completa e à resolução do distúrbio de coagulação. O principal fator prognóstico da LPMA é a leucometria inicial. Pacientes com leucometria abaixo de 10.000/mm3 terão taxas de RC maior do que 90% com idarrubicina associada ao ATRA, enquanto leucometria acima de 10.000/mm3 implica em taxa de RC entre 70% e 85%. Uma vez em remissão, o paciente recebe terapia de consolidação com 3 cursos de idarrubicina e ATRA. Seguem-se vários tipos de consolidação e manutenção com ATRA, sendo o melhor para a escolha do protocolo a monitoração do PML/RARA com PCR para detectar a remissão molecular. Recidiva de doença é rara, principalmente nos pacientes de baixo risco. O trióxido de arsênico (ATO) tem se mostrado eficaz nesses casos e tem sido alvo de vários protocolos de pesquisa; e, até o momento, não há evidência da superioridade do arsênico, comparado com a combinação do ATRA com antraciclina, na primeira indução de remissão, bem na associação com citarabina e antraciclina na recaída que envolve o SNC.  
9.3. TRATAMENTO DE SUPORTE  
Antibioticoterapia – No período da granulocitopenia, o paciente permanece em alto risco de infecção bacteriana, necessitando de vigilância constante e pronta ação a qualquer processo febril, para evitar septicemia. A detecção do foco infeccioso é fundamental na orientação terapêutica, sendo preconizadas coletas de hemo- e uroculturas, além de avaliação rigorosa da pele, mucosas e pulmão. A lavagem das mãos, a higiene pessoal e o cuidado dentário são ações essenciais na prevenção das infecções.  
Fatores de Crescimento – Os fatores estimuladores de colônias de granulócitos (G-CSF) ou de granulócitos e macrófagos (GM-CSF), que contribuem para a recuperação dos granulócitos, podem ser usados em protocolos específicos, particularmente em idosos ou na infecção grave.  
Hemoterapia – A anemia deve ser corrigida com concentrado de hemácias. A transfusão de plaquetas reduziu dramaticamente a morte por hemorragia nos casos de LMA. A transfusão de plaquetas deve ser instituída quando a contagem for menor que 10.000/mm3 em paciente estável, ou menor que 50.000/mm3 em paciente com sangramento ou que necessite de procedimento invasivo, que deve ser evitado tanto pelo risco hemorrágico, quanto pelo risco de circulação bacteriana e sepse. Além do número de plaquetas, a indicação de transfusão deve ser considerada nos casos de sangramento de mucosa, infecção, mucosite grave e febre. Os hemocomponentes devem ser irradiados, em vista do risco de doença do enxerto _versus_ hospedeiro transfusional. Inexiste evidência para a indicação de transfusão de granulócitos no paciente com LMA.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 9.4. MONITORIZAÇÃO -->
Para a monitorização laboratorial, devem ser realizados os exames previstos na conduta ou protocolo utilizados no hospital, incluindo as avaliações do mielograma, da imunofenotipagem, dos achados citogenéticos e determinação quantitativa da DRM na medula óssea. Controles periódicos do líquor serão realizados por ocasião das injeções intratecais.  
A investigação de DRM tornou-se um relevante meio para documentar a rapidez da remissão e para monitorar o resultado do tratamento. As técnicas mais usadas são o RT-PCR, FISH e citometria de fluxo. No entanto, exceto na LPMA e na LMA com o oncogene BCR-ABL, precisam ainda ser mais bem definidos alguns aspectos, a partir dos quais uma intervenção terapêutica deveria ser efetuada.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 10 - REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Doentes com 19 ou mais anos e diagnóstico de Leucemia Mieloide Aguda devem ser atendidos em hospitais habilitados em oncologia com serviço de hematologia e com porte tecnológico suficiente para diagnosticar, tratar e realizar seu monitoramento laboratorial.  
Além da familiaridade que esses hospitais guardam com o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional, de laboratórios e de apoio social necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
O hospital deve ter em suas próprias dependências o atendimento ambulatorial diário, com atendimento emergencial 24h/dia nos 7 dias da semana.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por  
exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
NOTA 1 - Exceto pelo Mesilato de Imatinibe (para a quimioterapia da leucemia mieloide crônica, da leucemia linfoblástica aguda cromossoma Philadelphia positivo e do tumor do estroma gastrointestinal) e, até que se regularize o abastecimento do mercado, pela L-asparaginase (para a quimioterapia da leucemia e linfoma linfoblásticos), o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. [O Mesilato de Imatinibe e a L-asparaginase são comprados pelo Ministério da Saúde e dispensados aos hospitais habilitados em oncologia no SUS pela Assistência Farmacêutica das secretarias estaduais de saúde.] Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do(s) medicamento(s) antineoplásico(s) é desse hospital, seja ele público ou privado, com ou sem fins lucrativos. NOTA 2 - Os seguintes procedimentos da tabela do SUS são compatíveis com a quimioterapia de neoplasias do adulto, inclusive a Leucemia Mieloide Aguda:  
03.04.06.007-0 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 1ª linha 03.04.06.008-9 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 2ª linha 03.04.06.009-7– Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 3ª linha 03.04.06.010-0 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 4ª linha.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda do Adulto - Diretrizes Diagnósticas e Terapêuticas | secao: 11- TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER -->
É obrigatória a informação ao paciente ou a seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados aos medicamentos e procedimentos utilizados para o diagnóstico e tratamento da leucemia mieloide aguda.  
12 - REFERÊNCIAS  
1. Kebriaei P, Champlin R, Lima M, Estey E. Management of Acute Leukemias, _In_ : VT de Vita Jr. et al. Cancer: Principles Practice of Oncology, 9th ed. Philadelphia: Lippincott Williams&Wilkins, 2011, Chap. 131, p. 1928–1954.  
2. Chauffaille MLLF. Leucemia Mielocítica Aguda, In: AC Lopes et al. Tratado de Clínica Médica, Ed. Roca, 2006, Cap. 165, p.2026 – 2039.  
3. Szer J. The prevelant predicament of relapsed acute myeloid leukemia. In: HEMATOLOGY American Society of Hematology Education Program Book p. 42-48, December 2012.  
4. Faderl S, Kantarjian HM. Clinical Manifestations and Treatment of Acute Myeloid Leukemia. In: Hoffman, R. et al. Hematology: Basic Principles and Practice. 6th ed. Churchill Livingstone: 2013, Chap. 58, p. 863-881.  
5. Vardiman JW, Brunning RD, Arber DA et al. Introduction and overview of the classification of the myeloid neoplasm – In:  WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues, 4th ed SH Swerdlow et al, Intern. Agency for Research on Cancer, Lyon, France: IARC Press; 2008, Chap.1, p.18-30.  
6. Döhner H, Estey EH, Amadori S et al. Diagnosis and management of acute myeloid leukemia in adults: recommendations from an international expert panel, on behalf of the European LeukemiaNet – Blood 2010; 115:453-474.  
7. Roboz GJ. Novel Approaches to the Treatment of Acute Myeloid Leukemia In: HEMATOLOGY American Society of Hematology Education Program Book p.43 – 50, December 2011.  
8. Paietta E. Minimal residual disease in acute myeloid leukemia: coming of age – In: HEMATOLOGY American Society of Hematology Education Program Book p. 35-42, December 2012.  
9. Dombret H. Optimal acute myeloid leukemia therapy in 2012 In: Hematology Education: the education programme for the annual congress of the European Hematology association 2012: 6(1) p.41-48.  
10. Patel JP, Levine RL.How do novel molecular genetic markers influence treatment decisions in acute myeloid leukemia. In: HEMATOLOGY American Society of Hematology Education Program Book p.2834, December 2012.  
11. Amadori S, Breccia M, Stasi R. Acute myeloid leukemia in older patients: conventional and new therapies – In: Hematology Education: the education programme for the annual congress of the European Hematology association 2013: 7(1) p. 41-48.  
12. Blain JA, Lalleman-Breittenbach V, Thé H. PML/RARA as the master driver of acute promyelocytic leukemia pathogenesis and basis for therapy response - In: Hematology Education: the education programme for the annual congress of the European Hematology association 2013: 7(1) p. 49-56.  
13. Pagnano KBB, Rego EM, Rohr S et al. Guidelines on the diagnosis na treatment for acute promyelocytic leukemia: Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular Guidelines . Project Associação Médica Brasileira 2013 – Rev Bras Hematol Hemoter 2014:36(1):71-92.

---

