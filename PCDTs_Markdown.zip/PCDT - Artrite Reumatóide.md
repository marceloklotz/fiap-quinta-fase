<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: Geral -->
<!-- Start of picture text -->
» OE<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SCTIE Nº 33, DE 19 DE JANEIRO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reumatoide.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem:  
Considerando a necessidade de se atualizarem os parâmetros sobre a Artrite Reumatoide no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1019/2025 e o Relatório de Recomendação n° 1021/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Artrite Reumatoide.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral de artrite reumatoide, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (eventos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da artrite reumatoide.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES-SCTIE/MS nº 16, de 3 de setembro de 2021, publicada no Diário Oficial da União (DOU) nº 172, de 10 de setembro de 2021, seção 1, página 107.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A artrite reumatoide (AR) é uma doença inflamatória crônica de etiologia desconhecida. Ela causa destruição articular irreversível pela proliferação de macrófagos e fibroblastos na membrana sinovial após estímulo possivelmente autoimune ou infeccioso1. Além das manifestações articulares, a AR pode cursar com alterações de múltiplos órgãos e reduzir a expectativa de vida, sendo o aumento de mortalidade consequente a doenças cardiovasculares, infecções e neoplasias2. As consequências da AR são: piora da qualidade de vida, incapacidade funcional, perda de produtividade e altos custos para a sociedade3–7.  
Há poucos estudos de prevalência de AR na América Latina. No México, um estudo revelou a prevalência geral de 1,6%, com maior frequência entre as mulheres8. No Brasil, um estudo realizado em Minas Gerais encontrou prevalência de 0,46%7. A AR é mais frequente em mulheres e na faixa etária de 30 a 50 anos, com pico de incidência na quinta década de vida9. Todavia, o histórico familiar de AR aumenta o risco de desenvolvimento da doença de 3 a 5 vezes10. Estudos genéticos demonstraram a importância do HLA-DRB 1, HLA-B e HLA-DPB1, JAK-STAT, NF-kB e sinalizadores de receptores de células T na regulação imunonológica11.  
Nas duas últimas décadas, avanços significativos em estudos moleculares e celulares têm elucidado o processo inflamatório da AR, como a identificação de citocinas que direcionam a inflamação sinovial crônica (por exemplo, TNF-α, IL-1 e IL-6). Consequentemente, inúmeras terapias biológicas direcionadas para alvos específicos têm adicionado mais opções terapêuticas para os pacientes que se tornam refratários a tratamentos anteriores12.  
Além disso, avanços no diagnóstico e no monitoramento da atividade da doença favoreceram a identificação precoce e o tratamento oportuno nas suas fases iniciais, reduzindo a destruição articular e melhorando os resultados terapêuticos13,14. Na prática médica, o tratamento visando, principalmente, à remissão ou baixa atividade da doença em pacientes com AR de início recente (menos de 6 meses de sintomas) tem melhorado significativamente esses resultados15.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da artrite reumatoide, e sua elaboração seguiu as recomendações das Diretrizes Metodológicas para Elaboração de Diretrizes Clínicas, do Ministério da Saúde16, que preconiza o uso do sistema GRADE (Grading of Recommendations Assessment, Developmentand Evaluation), que, por sua vez, classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)17,18.  
O GRADE-Adolopment18 foi usado para adaptar as diretrizes do American College of Reumathology ao contexto brasileiro19. Neste processo, foram priorizadas as questões referentes ao tratamento medicamentoso da AR de início recente e da AR estabelecida. Os desfechos de interesse foram: atividade e progressão da doença; qualidade de vida; incapacidade funcional; eventos adversos gastrointestinais; eventos adversos graves; infecções graves; e hepatotoxicidade.  
Os estudos selecionados foram sumarizados em tabelas de evidências na plataforma GRADEpro20. A partir disso, o grupo elaborador do PCDT, composto por metodologistas e especialistas no tema, elaborou recomendações a favor ou contra cada intervenção.  
2

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
- M05.0 Síndrome de Felty  
- M05.1 Doença reumatoide do pulmão  
- M05.2 Vasculite reumatoide  
- M05.3 Artrite reumatoide com comprometimento de outros órgãos e sistemas  
- M05.8 Outras artrites reumatoides soropositivas  
- M06.0 Artrite reumatoide soronegativa  
- M06.8 Outras artrites reumatoides especificadas

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Serão incluídos neste PCDT pacientes de ambos os sexos, com diagnóstico de AR, seja em forma de início recente ou estabelecida, independentemente da atividade da doença.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Serão excluídos para o uso de algum medicamento preconizado neste Protocolo os pacientes que, respectivamente, apresentarem contraindicação absoluta, independentemente de faixa etária ou condição clínica, conforme as contraindicações discriminadas no item 6. TRATAMENTO.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O diagnóstico de AR deve ser feito com base em achados clínicos e exames complementares. Entre eles, considerar o tempo de evolução da artrite, a presença de autoanticorpos (quando disponível a sua determinação), a elevação de provas de atividade inflamatória e as alterações compatíveis em exames de imagem. Nenhum exame isolado, seja laboratorial, de imagem ou histopatológico, confirma o diagnóstico. Critérios de classificação como aqueles estabelecidos pelo American College of Rheumatology - ACR 1987 e pela ACR/European League Against Rheumatism – ACR/EULAR 2010 auxiliam no processo diagnóstico.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os critérios do ACR de 1987 podem orientar o diagnóstico de AR na prática médica. Ele é composto por sete critérios:  
- 1) rigidez matinal;  
- 2) artrite de três ou mais áreas articulares;  
- 3) artrite de mãos;  
- 4) artrites simétricas;  
- 5) nódulos reumatoides;  
- 6) fator reumatoide positivo e  
- 7) alterações radiográficas21.  
3  
A presença de quatro ou mais critérios por um período maior ou igual a 6 semanas é sugestivo de AR. Contudo, os critérios de 1987 vinham sendo questionados por não se aplicarem nas fases iniciais da doença, o que retardava o início de tratamento em momento mais oportuno. Ou seja, uma parcela dos pacientes com AR possuía menos de quatro critérios presentes, tendo frequentemente o tratamento postergado. Dessa forma, em 2010, foram publicados novos critérios de classificação.  
Os critérios do ACR/EULAR de 2010 (Quadro 1) se baseiam em um sistema de pontuação com base em um escore de soma direta. As manifestações são divididas em quatro grupos:  
- 1) acometimento articular;  
- 2) sorologia;  
- 3) provas de atividade inflamatória e  
- 4) duração dos sintomas  
Em caso de dúvida, a contagem de articulações acometidas pode usar métodos de imagem (ultrassonografia ou ressonância magnética). Uma pontuação maior ou igual a 6 classifica um paciente como tendo AR. Cabe ressaltar que os critérios do ACR 1987 e os novos critérios de 2010 não são diagnósticos, mas, sim, classificatórios. Esses critérios foram desenvolvidos com o objetivo de definir populações homogêneas para a finalidade de pesquisa; porém, podem ser úteis para auxiliar no diagnóstico clínico. Em comparação com os critérios do ACR de 1987, essa classificação aumenta a sensibilidade do diagnóstico e permite identificar os casos mais precocemente. É importante salientar que os critérios de 2010 têm por objetivo classificar pacientes com manifestações recentes da doença. Pacientes com doença erosiva típica de AR e história compatível com preenchimento prévio dos critérios de 2010 devem ser classificados como tendo AR. Pacientes com doença de longa duração, mesmo com doença inativa (com ou sem tratamento), com base em dados retrospectivos e que preencheriam os critérios de 2010 devem ser classificados como tendo AR. Embora pacientes com uma pontuação < 6/10 articulações não possam ser classificados como com AR, eles devem ser reavaliados, e os critérios podem ser preenchidos cumulativamente ao longo do tempo. O diagnóstico diferencial varia em apresentações diferentes dos pacientes, mas devem incluir lúpus eritematoso sistêmico, artrite psoriásica e gota. Caso permaneça a incerteza diagnóstica, um reumatologista deve ser consultado.  
**Quadro 1 - Critérios 2010 ACR-EULAR para classificação de artrite reumatoide22**  
|Grupo|Pontuação|
|---|---|
|Acometimento articular*||
|1 grande articulação†|0|
|2-10 grandes articulações|1|
|1-3 pequenas articulações (com ou sem acometimento de grandes articulações)‡|2|
|4-10 pequenas articulações (com ou sem acometimento de grandes articulações)|3|
|> 10 articulações (pelo menos uma pequena articulação)§|5|
|Sorologia (pelo menos um resultado é necessário)||||
|Fator Reumatoide (FR) e anticorpos antipeptídeos citrulinados cíclicos (anti-CCP)|0|
|Fator reumatoide ou anti-CCP em baixos títulos|2|
|Fator reumatoide ou anti-CCP em altos títulos|3|
|Provas de atividades inflamatórias (pelo menos 1 resultado é necessário)¶||
|VHS e PCR normais|0|
|VHS ou PCR alterados|1|
|Duração dos sintomas||  
4  
|Grupo|Pontuação|
|---|---|
|Duração dos sintomas < 6 semanas**|0|
|Duração dos sintomas ≥ 6 semanas|1|  
Legenda: Anti-CCP: anticorpos antipeptídeos citrulinados cíclicos; ACR: American College of Rheumatology; EULAR: European League Against Rheumatism; PCR: proteína C reativa; VHS: velocidade de hemossedimentação.  
*Acometimento articular se refere a qualquer articulação edemaciada ou dolorosa ao exame físico, podendo ser confirmado por evidências de sinovite detectadas por um exame de imagem”. Interfalangianas distais, primeiras carpo-metacarpiana e primeiras metatarsofalangiana são excluídas da avaliação. As categorias de distribuição articular são classificadas de acordo com a localização e a quantidade de articulações acometidas, com o posicionamento na mais alta categoria baseada no padrão de acometimento articular.  
†Grandes articulações: ombros, cotovelos, quadris, joelhos e tornozelos.  
‡Pequenas articulações: metacarpofalangianas, interfalangianas proximais, 2as–5asmetatarsofalangianas, interfalangianas dos polegares e punhos.  
§Nessa categoria, pelo menos uma articulação envolvida deve ser pequena, as outras podem envolver qualquer combinação de grandes e pequenas articulações adicionais, bem como outras articulações (temporomandibular, acromioclavicular, esternoclavicular etc.).  
||Teste negativo se refere a valores de UI menores ou iguais ao limite superior da normalidade (LSN) do laboratório e teste. Testes positivos baixos se referem a valores de UI maiores que o LSN e ≤ 3 vezes o LSN para o laboratório e teste. Testes positivos altos se referem a valores que são > 3 vezes o LSN para o laboratório e teste. Quando o resultado do fator reumatoide for somente positivo ou negativo, considera-se o resultado positivo como sendo de baixos títulos de fator reumatoide.  
¶Normal/anormal de acordo com os padrões do laboratório.  
- ** A duração dos sintomas deve ser baseada no relato de sinais e sintomas pelo paciente (dor, aumento de volume) das articulações acometidas  
- clinicamente na avaliação, independentemente do tratamento.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Clinicamente, identificam-se poliartrite simétrica e aditiva, artralgia, rigidez matinal e exames laboratoriais de atividade inflamatória aumentados (velocidade de hemossedimentação e proteína C reativa). Em fases tardias, surgem deformidades, como desvio ulnar dos dedos ou “dedos em ventania”, deformidades em “pescoço de cisne” [hiperextensão das articulações interfalangianas proximais (IFP) e flexão das interfalangianas distais (IFD)], deformidades em “botoeira” (flexão das IFP e hiperextensão das IFD), “mãos em dorso de camelo” [aumento de volume do punho e das articulações metacarpofalangianas (MCF) com atrofia interóssea dorsal], joelhos valgos (desvio medial), tornozelos valgos (eversão da articulação subtalar), hálux valgo (desvio lateral do hálux), “dedos em martelo” [hiperextensão das articulações metatarsofalangianas (MTF) e extensão das IFD], “dedos em crista de galo” (deslocamento dorsal das falanges proximais com exposição da cabeça dos metatarsianos) e pés planos (arco longitudinal achatado)23. O acometimento da coluna cervical (C1-C2) com subluxação atlantoaxial geralmente se manifesta por meio de dor irradiada para a região occipital, perda da lordose fisiológica cervical e resistência à movimentação passiva. Quando surgem sintomas neurológicos, como parestesias periféricas ou perda do controle esfincteriano, a mortalidade é de 50% em 1 ano. A suspeita clínica pode ser comprovada por radiografia de coluna cervical funcional, em que a distância entre o processo odontoide e o arco anterior de C1 acima de 3 mm (ou entre o processo odontoide e o arco posterior de C1 abaixo de 14 mm) indica aumento de risco de compressão medular24,25. As manifestações extra-articulares (nódulos reumatoides, vasculite, derrame pleural, episclerite e escleromalacia perfurante, entre outras) se correlacionam com pior prognóstico. Além da perda de capacidade funcional, pode haver aumento também da mortalidade, o que demonstra a gravidade da doença24.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Na avaliação complementar dos pacientes com AR, a titulação de autoanticorpos como fator reumatoide (FR) (sensibilidade de 75% e especificidade de 85%) e anticorpos contra peptídeos citrulinados cíclicos (anti-CCP) (sensibilidade de 75% e especificidade de 95%) têm importância diagnóstica e prognóstica. A dosagem de anti-CCP não é um exame obrigatório, mas pode auxiliar em casos de dúvida diagnóstica, geralmente sendo reservada para casos em que o FR é negativo.  
5  
Os exames de imagem são complementares ao diagnóstico e ao monitoramento da atividade da AR. As radiografias simples têm baixo custo e são acessíveis. Além disso, existem métodos de avaliação e pontuação de alterações radiográficas que permitem avaliações longitudinais. As desvantagens das radiografias simples são a radiação ionizante e a falta de sensibilidade para identificar inflamação de partes moles e alterações ósseas iniciais da AR26,27.  
A ressonância magnética é mais sensível que o exame clínico e a radiografia simples para detectar alterações inflamatórias e destruição articular nas fases iniciais da AR. Ela contribui para a avaliação de todas as estruturas acometidas na AR (membrana e líquido sinovial, cartilagem, osso, ligamentos, tendões e suas bainhas). No entanto, seu custo é alto, envolve grande quantidade de tempo e, algumas vezes, não é tolerada pelos pacientes26.  
A ultrassonografia apresenta excelente resolução para tecidos moles, permitindo o delineamento das alterações inflamatórias e estruturais na AR. O doppler permite avaliar em tempo real a neovascularização das articulações que apresentam correlação com alterações histopatológicas. Várias regiões podem ser avaliadas e comparadas em curto período. Como não há penetração óssea do ultrassom, algumas áreas não podem ser avaliadas. Os resultados são altamente dependentes do operador (treinamento e habilidades)28.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Uma série de doenças deve ser considerada no diagnóstico diferencial de artrite reumatoide. Entre elas, podem ser citadas a osteoartrose, a fibromialgia, algumas doenças sistêmicas autoimunes e outras doenças sistêmicas que podem apresentar dores articulares.  
Em pacientes com poliartrite há menos de 6 semanas, deve-se considerar a possibilidade de infecção viral, particularmente se houver febre e exantema. Os vírus mais comumente associados à poliartrite são: parvovírus B19, vírus da Chikungunya, vírus da rubéola, vírus da imunodeficiência humana (HIV), vírus das hepatites B e C. Síndrome de Sjögren e lúpus eritematoso podem ser confundidos com AR, especialmente se o fator reumatoide for positivo. Em pacientes idosos que apresentam poliartrite, deve ser considerado o diagnóstico de polimialgia reumática ou a manifestação paraneoplásica29.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Alguns aspectos clínicos e laboratoriais da AR estão relacionados à progressão mais rápida da destruição articular e devem ser identificados desde o momento do diagnóstico. Os fatores de mau prognóstico são: sexo feminino, tabagismo, baixo nível socioeconômico, início da doença em idade mais precoce, FR ou anti-CCP em títulos elevados, níveis elevados de proteína C reativa ou da velocidade de hemossedimentação, grande número de articulações edemaciadas, manifestações extra-articulares, elevada atividade inflamatória da doença, presença precoce de erosões na evolução da doença e presença do epítopo compartilhado,  (exame não usado na rotina assistencial23. A presença de alguns desses fatores pode requerer acompanhamento e reavaliação mais frequentes.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A AR pode ser classificada quanto à sua atividade de acordo com os sinais e sintomas articulares apresentados pelo paciente, a avaliação global do paciente quanto à atividade da sua doença, a avaliação da atividade de doença atual pelo examinador, e, quando presente, um marcador laboratorial de inflamação (VHS/PCR, sendo estes os parâmetros necessários para compor os diferentes indices compostos de atividade de doença (ICADS). A avaliação da atividade da doença é fundamental, uma vez que define a conduta terapêutica e prognóstica e o sucesso do tratamento. A atividade é classificada em quatro níveis: alta, moderada, baixa e em remissão. O objetivo terapêutico é atingir o nível baixo de atividade ou, preferencialmente, a remissão da doença.  
Uma comissão conjunta do ACR e da EULAR definiu a remissão da AR com base no número de articulações dolorosas, número de articulações edemaciadas, níveis da proteína C reativa (mg/dl) e avaliação global do paciente (≤ 1 cada); ou SDAI - Simplified Disease Activity Index (≤ 3,3, uma de seis medidas de atividade da doença aprovadas pelo ACR)19.  
6  
Há diferentes instrumentos para classificação da atividade da doença, sendo os mais usados o SDAI (Simplified Disease Activity Index), CDAI (Clinical Disease Activity Index) e DAS-28 (Disease Activity Score 28). A avaliação da atividade deve ser feita, preferencialmente, em todas as consultas em caso de pacientes com artrite reumatoide. Esses três instrumentos são validados e internacionalmente empregados. A escolha fica a critério do profissional da saúde, contudo, para um mesmo paciente deve ser empregado o mesmo instrumento para permitir a comparabilidade dos resultados. Os pontos de corte para a definição da atividade estão apresentados no **Quadro 2** . Os instrumentos estão apresentados em detalhes no **Material Suplementar** .  
A avaliação da capacidade funcional do paciente, usando um questionário padronizado e validado (ex. HAQ-DI - Health Assesmente Questionnaire Disability Index), deve ser realizada rotineiramente para pacientes com AR, pelo menos uma vez por ano, e com maior frequência se a doença estiver ativa. O instrumento está apresentado em detalhes no **Material Suplementar** .  
**Quadro 2 - Escores usados para avaliação da atividade da doença**  
|Índice|Estado da atividade da doença|Pontos de corte|
|---|---|---|
||Remissão|≤ 3,3|
||Baixa|> 3,3–11|
|SDAI|Moderada|> 11–> 26|
||Alta|> 26|
||Remissão|≤ 2,8|
|A|Baixa|> 2,8–10|
|CDI|Moderada|> 10–22|
||Alta|> 22|
||Remissão|≤ 2,6|
||Baixa|> 2,6–3,2|
|DAS-28|Moderada|> 3,2–5,1|
||Alta|> 5,1|  
Legenda: CDAI: índice clínico de atividade de doença; DAS-28: índice de atividade de doença (28 articulações); SDAI: índice simplificado de atividade de doença.  
Fonte: Smolen et al., 201830; Aletaha& Smolen, 201531.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
As condutas terapêuticas preconizadas neste PCDT estão alinhadas com publicações do Ministério da Saúde sobre o tema e com as diretrizes de tratamento da artrite reumatoide de sociedade de especialistas32,33.  
Em qualquer das etapas discriminadas a seguir para o tratamento dos pacientes com AR e independentemente da fase da doença, o paciente deve, preferencialmente, ser também acompanhado por equipe multidisciplinar (enfermeiro, fisioterapeuta, terapeuta ocupacional, psicólogo e nutricionista), com suporte de médico reumatologista, se disponível. O paciente deve receber orientações para melhorar seus hábitos de vida (parar de fumar, reduzir a ingestão de bebidas alcoólicas, reduzir o peso e praticar atividade física). Tratar e monitorar as comorbidades (hipertensão arterial sistêmica, diabete melito, dislipidemia e osteoporose) são medidas essenciais. É recomendado que a cobertura vacinal seja atualizada. E o uso de meios contraceptivos deve ser orientado nos casos de pacientes em fase reprodutiva e candidatos a usar medicamentos modificadores do curso da doença (MMCD).  
7  
O uso da metaterapêutica (treat to target) é recomendado em pacientes com AR, independentemente do nível de atividade da doença. O princípio do tratamento por meta terapêutica é estabelecer uma meta para o controle dos sintomas, levando em consideração a decisão compartilhada entre o paciente e o profissional da saúde, podendo ser repactuada ao longo do seguimento. O paciente deve expressar suas preferências (por exemplo: vias de administração, intervalos de aplicação e aspectos relacionados à tolerabilidade e possíveis eventoseventos adversos) para garantir sua aderência. Deve-se observar sempre o balanço entre custos e benefícios, facilidade de acesso, disponibilidade de medicamentos, condições de armazenamento, existência de centros de infusão e educação do paciente.  
O objetivo do tratamento geralmente é a remissão da atividade da doença, sendo aceitável a baixa atividade em casos específicos. Como já mencionado, a atividade da AR pode ser medida por meio de índices combinados de atividade de doença (ICAD) e algum instrumento de medida da capacidade funcional, como o Health Assessment Questionnaire (HAQ).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O tratamento não medicamentoso de AR inclui a educação do paciente e de sua família, terapia ocupacional, exercícios, fisioterapia, apoio psicossocial e cirurgia. As evidências de tratamento não medicamentoso são escassas, mas acredita-se que tenha papel importante na melhora clínica e funcional dos pacientes34–43.  
Exercícios contra resistência são seguros e eficazes na AR, melhorando a força muscular e o tempo de deslocamento44,45. Exercícios aeróbicos parecem melhorar de forma discreta a qualidade de vida, a capacidade funcional e a dor em pacientes com AR estável46–50.  
A fisioterapia pode propiciar benefício, havendo ainda grande heterogeneidade de métodos entre os trabalhos disponíveis51–55. Intervenções psicológicas são eficazes no tratamento a curto prazo da AR, especialmente promovendo a atividade física e reduzindo a ansiedade e a depressão56,57.  
O benefício trazido por modificações nutricionais ainda é incerto, devendo ser considerados seus possíveis eventos adversos, tal como o emagrecimento, que contribuem para o grande número de perdas de acompanhamento nos estudos58.  
Em resumo, para pacientes com AR, inclusive os casos especiais, recomendam-se exercício físico regular, terapia ocupacional, fisioterapia, e terapia psicológica de forma individualizada e o uso de órteses em casos avançados que couber a indicação.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O tratamento medicamentoso de AR inclui o uso de anti-inflamatórios não esteroidais (AINE), glicocorticoides, imunossupressores e medicamentos modificadores do curso da doença (MMCD) – sintéticos e biológicos. O uso seguro desses fármacos exige o conhecimento de suas contraindicações absolutas. As seguintes etapas e linhas terapêuticas são preconizadas para o tratamento medicamentoso da artrite reumatoide:

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
MEDICAMENTOS MODIFICADORES DO CURSO DA DOENÇA SINTÉTICOS (MMCDs): Metotrexato, leflunomida, sulfassalazina, cloroquina e hidroxicloroquina.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O metotrexato (MTX) em monoterapia deve ser a primeira escolha terapêutica. Em casos de toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ao MTX oral, deve-se tentar dividir a administração por via oral, em pelo menos duas tomadas no mesmo dia, ou empregar o MTX injetável. Na impossibilidade de uso do MTX por toxicidade, deve-se usar, preferencialmente em monoterapia, a leflunomida (LEF) ou sulfassalazina (SSZ), sendo a terapia isolada com hidroxicloroquina  
8  
(HCQ)/cloroquina pouco efetiva. O MTX está associado a alta taxa de toxicidade hepática e gastrointestinal, podendo levar à suspensão do tratamento em aproximadamente 30% dos casos. Para diminuir o risco de toxicidade, deve-se fazer uso de ácido fólico, sendo preconizada a dose de 5 mg, uma vez por semana, 36 horas após o tratamento com MTX. Sempre que possível, a HCQ deve ser usada preferencialmente à cloroquina, uma vez que possui melhor perfil de eficácia e segurança.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Em caso de falha da monoterapia inicial (MTX, LEF, SSZ, HCQ/cloroquina), isto é, de persistência da atividade de doença (de acordo com a meta terapêutica) após 3 meses de tratamento otimizado (dose máxima tolerada e adesão adequada) do medicamento usado na 1ª linha, passa-se para troca simples de MMCDs ou a terapia com a combinação dupla ou tripla de MMCDs. As associações de medicamentos MMCDs mais comumente recomendadas são MTX ou LEF com HCQ/cloroquina ou MTX ou LEF com SSZ. A tripla terapia pode ser realizada com a combinação de metotrexato com HCQ/cloroquina e sulfassalazina.  
O uso de medicamentos modificadores do curso da doença biológicos (MMCDbio) e o uso de medicamentos modificadores do curso da doença alvo específico (MMCDsae) na primeira etapa de tratamento medicamentoso da AR não é preconizado neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
MEDICAMENTOS MODIFICADORES DO CURSO DA DOENÇA BIOLÓGICOS (MMCDbio) - Abatacepte, adalimumabe, certolizumabe pegol, etanercepte, golimumabe, infliximabe, rituximabe e tocilizumabe;  
MEDICAMENTOS MODIFICADORES DO CURSO DA DOENÇA SINTÉTICOS ALVO ESPECÍFICO (MMCDsae) – Baricitinibe, tofacitinibe e upadacitinibe.  
Após o uso de pelo menos dois esquemas terapêuticos na primeira etapa por no mínimo 3 meses cada um e havendo persistência da atividade da doença conforme avaliação por meio do ICAD, utiliza-se um MMCDbio, ou um MMCDsae (baricitinibe, tofacitinibe ou upadacitinibe).  
O MMCDbio deve ser usado em associação com o MTX, exceto no caso de contraindicação; neste caso, pode ser considerada a associação com outro MMCDs (LEF eSSZ). Os MMCDbio que podem ser usados são os antifator de necrose tumoral - anti-TNF (certolizumabe pegol, golimumabe, infliximabe, etanercepte e adalimumabe) e os não anti-TNF (abatacepte e tocilizumabe). O uso do rituximabe na segunda etapa de tratamento deve ser reservado aos indivíduos com contraindicação absoluta aos MMCDbio e MMCDsae recomendados no Protocolo. Esses medicamentos possuem perfis de eficácia e segurança semelhantes, não havendo, em geral, predileção por uma alternativa frente às demais. Para os casos de pacientes já em tratamento com MMCDbio e com resposta adequada, o uso do mesmo fármaco deve ser mantido, não sendo preconizada sua troca por outro MMCDbio.  
O baricitinibe, tofacitinibe e upadacitinibe têm como vantagens a possibilidade de serem usados por via oral e não necessitar de refrigeração para armazenamento. Tanto o tofacitinibe como o upadacitinibe podem ser usados como monoterapia ou em combinação com metotrexato ou outros MMCDs. O baricitinibe pode ser usado em monoterapia ou em associação com o MTX.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
MEDICAMENTOS MODIFICADORES DO CURSO DA DOENÇA BIOLÓGICOS (MMCDbio) - Abatacepte, adalimumabe, certolizumabe pegol, etanercepte, golimumabe, infliximabe, rituximabe e tocilizumabe;  
MEDICAMENTOS MODIFICADORES DO CURSO DA DOENÇA SINTÉTICOS ALVO ESPECÍFICO (MMCDsae) – Baricitinibe, tofacitinibe e upadacitinibe.  
9  
Após pelo menos 3 meses da segunda etapa terapêutica, e havendo persistência da atividade da doença conforme avaliação por meio do ICAD, ou toxicidade inaceitável ao medicamento utilizado nessa etapa, pode-se prescrever outro MMCDbio (antiTNF ou não anti-TNF) ou MMCDsae (baricitinibe, tofacitinibe ou upadacitinibe), desde que o medicamento selecionado não tenha sido usado anteriormente. Se possível, o medicamento selecionado deve ser associado a um MMCDs (preferencialmente o MTX). O uso do rituximabe na terceira etapa de tratamento deve ser reservado aos indivíduos com contraindicação absoluta, toxicidade ou falha terapêutica aos MMCDbio e MMCDsae recomendados no Protocolo.  
O tofacitinibe e o upadacitinibe podem ser usados como monoterapia ou em combinação com metotrexato ou outros MMCDs. O baricitinibe pode ser usado em monoterapia ou em associação com o MTX.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Historicamente, os imunossupressores como a azatioprina e a ciclosporina são usados no tratamento de manutenção da artrite reumatoide. Esses medicamentos são efetivos na modificação do curso natural da doença, mas estão associados a significante incidência de eventos adversos, em especial devido à imunossupressão.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Em qualquer das etapas e linhas discriminadas para o tratamento dos pacientes com AR, glicocorticoides ou antiinflamatórios não esteroidais (AINE) podem ser prescritos para o controle sintomático, tendo sempre em mente o uso da menor dose pelo menor tempo possível.  
Os AINE incluídos neste Protocolo são o ibuprofeno e naproxeno. O uso crônico desses medicamentos indica que a atividade da AR não está adequadamente controlada com os MMCD sintéticos ou biológicos sendo assim, é preciso reavaliar o tratamento. Esses medicamentos estão associados a sintomas do trato gastrointestinal, incluindo náusea, gastrite e dispepsia, podendo-se também observar hemorragia digestiva com seu uso prolongado. Pacientes idosos podem ter risco aumentado de apresentar eventos indesejados. Seu uso deve ser reservado para alívio sintomático enquanto são aguardados os eventos dos MMCD sintéticos ou biológicos.  Esses dois AINE possuem perfil de eficácia e segurança semelhante, com a vantagem do naproxeno possuir meia vida mais longa, permitindo uma posologia mais conveniente59.  
Em pacientes com AR de início recente de moderada ou alta atividade, podem ser empregados AINE e glicocorticoide em baixas doses (≤ 10 mg/dia) por curtos períodos (< 3 meses) como “ponte” para o início do efeito do(s) MMCDs durante o tratamento. Não se deve adicionar glicocorticoide por longos períodos quando em tratamento com MMCDs. Quanto ao uso de glicocorticoide, tanto a prednisona quanto a prednisolona podem ser usadas. Geralmente, usa-se a prednisona devido à sua apresentação em comprimidos. A prednisolona está disponível em solução oral e é preferível em caso de pacientes com disfunção hepática, uma vez que não é metabolizada no fígado.  
Em pacientes com AR estabelecida de moderada ou alta atividade e em surto agudo da doença, pode ser empregado glicocorticoide na menor dose e no menor período possível devido ao risco alto de eventos adversos. O uso de corticoide em baixas doses durante período prolongado em situações nas quais o paciente permanece sintomático durante a fase de ajuste do MMCD estaria indicado em casos particulares por decisão compartilhada entre o médico e o paciente. Evitar adicionar glicocorticoides em altas doses, exceto em manifestações extra-articulares que trazem risco à vida ou perda de função orgânica (por exemplo: vasculite, neurite, pneumonite). Nesses casos, é necessária a atenção hospitalar especializada, com o tratamento geralmente sendo a pulsoterapia com metilprednisolona por via intravenosa; em alguns casos, podendo ser necessária a individualização de terapia, com o uso de imunossupressores como ciclofosfamida, azatioprina ou ciclosporina.  
O algoritmo de decisão terapêutica está apresentado na **Figura 1** , conforme recomendações, e a **Figura 2** traz o Fluxograma para tratamento de artrite reumatoide.  
10  
Detalhes adicionais sobre as recomendações, assim como seu nível de evidência, grau de recomendação e referências  
usadas, encontram-se no **Material Suplementar.**  
**Figura 1- Algoritmo de decisão terapêutica da artrite reumatoide**  
<!-- Start of picture text -->
Atividade baixa da Atividade moderada a alta<br>doenca, da doenca<br>©<br>3<br>3<br>Falna ao tratamento* Em todas as fases, se<br>—8 roca poroutromMcosou |__| €otticoide (prednisona<br>eg Terapia combinada com MMCDs? ou prednisolona) para<br>3 5 controle da atividade<br>$ g MMCDbio (Anti-TNF ou ndo anti-<br>Sy) TNF) 2MTX wn] Tratamento deve ser<br>2 ou ‘sintomatico, se<br>3 MMCDsae (bariclinibe ou tofacitinibe necessario usar:<br>§s Suu ADEE Analgésicos<br>Nao‘Outro TNF2MTX Antiou TNF(diferente sMTX [one<br>mecanismo)<br>‘ou<br>MMCDsae (baricitinibe ou tofacitinibe<br><!-- End of picture text -->  
1 A suspensão do tratamento pode se dar por eventos adversos intoleráveis ou por falha terapêutica (não atingimento de meta terapêutica). Para avaliar a eficácia, deve-se aguardar pelo menos 3 meses do tratamento vigente, não devendo ser trocada de linha ou etapa terapêutica em intervalo de tempo inferior.  
2 Considerar o uso de MTX injetável nas combinações de terapias duplas ou triplas.  
3 O tofacitinibe, baricitinibe e upadacitinibe têm como vantagens a possibilidade de serem usados por via oral e não necessitarem de refrigeração para  
armazenamento.  
4 O tofacitinibe e o upadacitinibe podem ser usados como monoterapia ou em combinação com outros MMCDs (preferencialmente MTX). Baricitinibe pode ser usado em monoterapia ou em associação com o MTX.  
Observação: Na segunda etapa de tratamento, o uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação aos MMCDbio e MMCDsae.  
Na terceira etapa de tratamento, o uso de rituximabe deve ser reservado somente aos indivíduos com contraindicação, toxicidade ou falha terapêutica aos MMCDbio e MMCDsae  
11  
**Figura 2- Fluxograma para tratamento de artrite reumatoide**  
<!-- Start of picture text -->
Pacientes com AR com atividade baixa, moderads ou altads | __ Em todas 3s fases, se<br>, equivalente)<br>para controle<br>(TX) moncterapia ae SounnesTratamentod e venoe ser<br>SS ==<br>ao tratamento? 2 "AINE<br>N3o Sim<br>reavaliar periodicamente° = Teeee<br>MMCDs*<br>30 tratamento??<br>N3o Sim<br>Continuar o tratamento MMCDbio (Anti-TNF ou no anti-<br>reavalisr periodicamente TNF) MTX<br>MMCDsae (baricitinibeou  ou<br>tofacitinibe<br>ou upsdacitinibe)<br>monoterapiaou + MTX +<br>20 tratamento??<br>N3o Sim<br>' |<br>Continuar o tratamento € ‘Trocar para outro anti-TNF£MTX<br>reavaliat periodicamente ou<br>no ant-TNF2MTX<br>(diferente mecanismo)<br>MMCDsaeupadacitinibe) (baricitinibe monoterapiaou ou tofacitinibeou +MTX* ou<br><!-- End of picture text -->  
1 Tratamento com meta terapêutica: remissão ou baixa atividade da doença (reavaliar periodicamente).  
2 A suspensão do tratamento pode se dar por eventos adversos intoleráveis ou por falha terapêutica (não atingimento de meta terapêutica). Para avaliar a eficácia, deve-se aguardar pelo menos 3 meses do tratamento vigente, não devendo ser trocada de linha ou etapa terapêutica em intervalo de tempo inferior. 3Considerar o uso de MTX injetável nas combinações de terapias duplas ou triplas. 4 O tofacitinibe e o upadacitinibe podem ser usados como monoterapia ou em combinação com outros MMCDs (preferencialmente MTX). Baricitinibe pode ser usado em monoterapia ou em associação com o MTX. Observação: Na segunda etapa de tratamento, o uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação aos MMCDbio e MMCDsae. Na terceira etapa de tratamento, o uso de rituximabe deve ser reservado somente aos indivíduos com contraindicação, toxicidade ou falha terapêutica aos MMCDbio e MMCDsae.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis eventos adversos. A integração  
12  
do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os medicamentos incluídos neste Protocolo para o tratamento da artrite reumatoide são:  
<u>Anti-inflamatórios não esteroidais (AINE)</u>  
- Ibuprofeno: comprimidos de 200, 300 e 600 mg; suspensão oral de 50 mg/mL.  
- Naproxeno: comprimidos de 250 e 500 mg.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
- Acetato de metilprednisolona (intra-articular): pó para solução injetável de 40 mg/2 mL  
- Succinato sódico de metilprednisolona (intravenoso) pó para solução injetável de 40 mg, 125 mg, 500 mg ou 1.000 mg  
- Prednisona: comprimidos de 5 e 20 mg.  
- Fosfato sódico de prednisolona: solução oral de 1 e 3 mg/mL.  
<u>Medicamentos modificadores do curso da doença – sintéticos</u>  
- Metotrexato: comprimidos de 2,5 mg; solução injetável de 25 mg/mL.  
- Sulfassalazina: comprimidos de 500 mg.  
- Leflunomida: comprimidos de 20 mg.  
- Sulfato de hidroxicloroquina: comprimidos de 400 mg.  
- Difosfato de cloroquina: comprimidos de 150 mg.  
<u>Medicamentos modificadores do curso da doença – imunobiológicos</u>  
- Adalimumabe: solução injetável de 40 mg.  
- Certolizumabe pegol: solução injetável de 200 mg.  
- Etanercepte: solução injetável de 25 e 50 mg.  
- Infliximabe: pó para solução injetável de 100 mg/10 ml.  
- Golimumabe: solução injetável de 50 mg.  
- Abatacepte: solução injetável de 125 mg/mL.  
- Rituximabe: solução injetável de 10 mg/mL.  
- Tocilizumabe: solução injetável de 20 mg/mL.  
<u>Medicamentos modificadores do curso da doença – inibidores da Janus Associated Kinases (JAK)</u>  
- Tofacitinibe: comprimidos de 5 mg.  
- Baricitinibe: comprimidos de 2 e 4 mg.  
- Upadacitinibe: comprimidos de 15 mg.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
- Azatioprina: comprimidos de 50 mg.  
- Ciclofosfamida: pó para solução injetável de 200 ou 1.000 mg.  
- Ciclosporina: cápsulas de 10, 25, 50 e 100 mg; solução oral de 100 mg/mL em frascos de 50 mL.  
Nota 1: A apresentação de abatacepte pó para solução injetável 250 mg está excluída deste Protocolo devido à  
descontinuação temporária da fabricação do medicamento, conforme petição protocolada em 15 de março de 2022 junto à Anvisa. No entanto, até a presente data, a empresa não realizou qualquer alteração na solicitação de descontinuação do abatacepte junto à Anvisa. Essa exclusão poderá ser revisada posteriormente, conforme a regularização do fornecimento do medicamento ao Ministério da Saúde.  
13  
Nota 2: Os medicamentos ciclofosfamida e metilprednisolona estão contemplados em procedimentos de pulsoterapia, sendo seu fornecimento de responsabilidade do serviço, não sendo dispensados no âmbito da Assistência Farmacêutica.  
Nota 3: A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
O **Quadro 3** resume a descrição dos fármacos por categorias.  
**Quadro 3 - Descrição das categorias dos medicamentos**  
|Categoria de medicamentos|Descrições|
|---|---|
|MMCDs|Medicamentos modificadores do curso da doença sintéticos:<br>hidroxicloroquina, cloroquina, leflunomida, metotrexato ou sulfassalazina.|
|MMCDsae – baricitinibe, tofacitinibe<br>ou upadacitinibe|Medicamento modificador do curso da doença sintético alvo-específico.|
|Monoterapia MMCDs|Frequentemente definida com o uso de monoterapia MTX, mas também<br>pode ser LEF, SSZ, HCQ/cloroquina.|
|Terapia combinada dupla MMCDs|MTX + HCQ, MTX + SSZ, SSZ + HCQ ou combinações com LEF<br>(LEF + MTX, LEF + HCQ, LEF + SSZ).|
|Terapia combinada tripla MMCDs|MTX + SSZ + HCQ.|
|MMCDbio|Medicamentos modificadores do curso da doença biológicos incluindo<br>anti-TNF ou não anti-TNF.|
|Biológicos anti-TNF|Adalimumabe, certolizumabe pegol, etanercepte, golimumabe e<br>infliximabe.|
|Biológicos não anti-TNF|Abatacepte, rituximabe e tocilizumabe.|
|Glicocorticoides orais em doses baixas|≤ 10 mg/dia de prednisona (ou equivalente).|
|Glicocorticoides orais em doses altas|> 10 mg/dia a ≤ 60 mg/dia de prednisona (ou equivalente) com redução<br>rápida da dose.|
|Glicocorticoide em curto prazo|< 3 meses de tratamento.|
|Glicocorticoide intravenoso|Metilprednisolona.|
|Imunossupressores|Azatioprina, ciclosporina e ciclofosfamida|
|AINE|Anti-inflamatórios não esteroidais (AINE): naproxeno e ibuprofeno|
|Analgésicos|Paracetamol e dipirona.|  
Legenda: HCQ, hidroxicloroquina; LEF, leflunomida; MTX, metotrexato; SSZ, sulfassalazina; TNF, fator de necrose tumoral.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**Prednisona, prednisolona, metilprednisolona (acetato) e metilprednisolona (succinato):** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento.  
**Naproxeno e Ibuprofeno** : hipersensibilidade conhecida ao medicamento, classe ou componentes; sangramento gastrointestinal não controlado; elevação de aminotransferases/transaminases (ALT/TGP e AST/TGO) igual ou três vezes acima do limite superior da normalidade; taxa de depuração de creatinina inferior a 30 mL/min/1,73 m2 de superfície corporal na ausência de terapia dialítica crônica.  
14  
**Metotrexato:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; gestação, amamentação e concepção (homens e mulheres); elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade; taxa de depuração de creatinina inferior a 30 mL/min/1,73m2 de superfície corporal na ausência de terapia dialítica crônica.  
**Sulfassalazina:** hipersensibilidade conhecida ao medicamento, classe ou componentes; porfiria; tuberculose sem tratamento; hepatites B ou C agudas; artrite idiopática juvenil, forma sistêmica; elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade.  
**Leflunomida:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; gestação, amamentação e concepção (homens e mulheres); elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade; taxa de depuração de creatinina inferior a 30 mL/min/1,73 m2 de superfície corporal na ausência de terapia dialítica crônica.  
**Hidroxicloroquina:** hipersensibilidade conhecida ao medicamento, classe ou componentes; retinopatia.  
**Cloroquina:** hipersensibilidade conhecida ao medicamento, classe ou componentes; retinopatia.  
**Azatioprina:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas.  
**Ciclosporina:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; hipertensão arterial sistêmica grave não controlada.  
**Ciclofosfamida:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento, infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; cistite hemorrágica.  
**Adalimumabe, certolizumabe pegol, etanercepte, infliximabe e golimumabe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; neoplasias nos últimos 5 anos; insuficiência cardíaca congestiva classes III ou IV; doença neurológica desmielinizante, esclerose múltipla.  
**Abatacepte:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas, gestação e amamentação.  
**Rituximabe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; leucoencefalopatia multifocal progressiva; hepatites B ou C agudas.  
**Tocilizumabe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; elevação de aminotransferases/transaminases igual ou 3 vezes acima do limite superior da normalidade; contagem total de neutrófilos inferior a 1.000/mm3; contagem total de plaquetas inferior a 50.000/mm3; risco iminente de perfuração intestinal.  
**Baricitinibe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; infecção ativa, recorrente ou crônica; tuberculose ativa; infecção por herpes zoster e herpes simples ativa; hepatites B ou C agudas. Baricitinibe deve ser usado  
15  
com cautela em pacientes com fatores de risco para trombose venosa profunda (TVP) e embolia pulmonar (EP), tais como idosos, obesidade, histórico de TVP/EP prévias ou pacientes que serão operados e ficarão imobilizados.  
**Tofacitinibe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas. É recomendada a avaliação dos pacientes quanto a fatores de risco para tromboembolismo venoso antes do início do tratamento e periodicamente durante o tratamento. Tofacinibe deve ser usado com cautela em pacientes nos quais os fatores de risco são identificados.  
**Upadacitinibe:** hipersensibilidade conhecida ao medicamento, classe ou componentes; insuficiência hepática grave; infecção grave ativa, incluindo infecções localizadas; infecção por herpes zoster; tuberculose ativa.  Os riscos e benefícios do tratamento devem ser considerados antes de iniciar o uso de upadacitinibe em pacientes: com infecção crônica ou recorrente; que foram expostos à tuberculose; com histórico de infecção grave ou oportunista; que residiram em áreas de tuberculose endêmica ou micoses endêmicas ou viajaram para tais áreas; ou com condições subjacentes que podem predispô-los à infecção. O upadacitinibe deve ser usado com cautela em pacientes com alto risco de trombose venosa profunda e embolia pulmonar.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os MMCDs (metotrexato e leflunomida) e o imunossupressor (ciclofosfamida) são contraindicados na gravidez e lactação. Já os MMCDs (hidroxicloroquina e sulfassalazina), MMCDbioanti-TNF (certolizumabe pegol, adalimumabe, etanercepte, golimumabe e infliximabe), MMCDbio não anti-TNF (rituximabe e abatacepte), baricitinibe, tocilizumabe, tofacitinibe, upadacitinibe, imunossupressores (azatioprina e ciclosporina), glicocorticoides (prednisona e prednisolona), e AINE (naproxeno e ibuprofeno), não devem ser usados na gravidez e lactação, exceto sob orientação médica.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os esquemas de administração dos fármacos usados no tratamento da AR encontram-se discriminados no Quadro 4.  
**Quadro 4 - Medicamentos para o tratamento de AR**  
|Classe|Medicamento|Via<br>de<br>administração|<br>Posologia|
|---|---|---|---|
|Medicamentos<br>modificadores do curso da doença|Metotrexato (MTX)|VO, SC ou<br>IM|7,5 a 25 mg, 1x/semana|
|sintéticos (MMCDs)|Hidroxicloroquina|VO|400 mg, 1x/dia|
||Cloroquina|VO|4 mg/kg/dia|
||Sulfassalazina|VO|500 mg, 1-3 g/dia|
||Leflunomida|VO|20 mg, 1x/dia|
|MMCDs alvo-específico|Baricitinibe|VO|4 mg, 1x/dia.<br>Redução de dose para 2 mg/dia<br>para pacientes com idade acima de 75<br>anos, com insuficiência renal ou em<br>pacientes com controle prolongado da<br>atividade da doença e elegíveis para<br>redução de dose.|
||Tofacitinibe|VO|5 mg, 2x/dia|  
16  
|Classe|Medicamento|Via<br>administração|de<br>Posologia|
|---|---|---|---|
||Upadacitinibe|VO|15 mg, 1x/dia|
|Medicamentos|Adalimumabe|SC|40 mg a cada 2 semanas|
|modificadores do curso da doença|||400 mg nas semanas 0, 2 e 4.|
|biológicos anti-TNF (MMCDbio<br>anti-TNF)|Certolizumabe pegol|SC|Após manter 200 mg a cada 2 semanas<br>ou 400 mg a cada 4 semanas.|
||Etanercepte|SC|50 mg, 1x/semana|
||Golimumabe|SC|50 mg, 1x/ a cada 4 semanas|
||Infliximabe|IV|3 mg/kg/dose nas semanas 0, 2,<br>6. Depois de manter a mesma dose, a<br>cada 8 semanas|
|Medicamentos|||1.000 mg nos dias 0 e 14 (dose|
|modificadores do curso da doença|||total de 2.000mg por ciclo). Após a|
|biológicos não anti-TNF<br>(MMCDbio não anti-TNF)|Rituximabe|IV|administração inicial de duas doses de<br>1.000 mg cada, com intervalo de 14<br>dias, ciclos semelhantes podem ser<br>repetidos a cada seis meses, totalizando<br>2000 mg por ciclo (mantendo-se 2.000<br>mg por ciclo com intervalo de 14 dias a<br>cada dose de 1.000 mg). A manutenção<br>com 1.000 mg pode ser considerada no<br>cenário de boa resposta clínica†|
||Tocilizumabe|IV|IV: 8 mg/kg/dose (dose máxima<br>de 800 mg) 1x/ a cada 4 semanas.|
||Abatacepte|SC|SC: 125 mg, 1x/semana|
|Imunossupressores|Azatioprina|VO|Iniciar com 1 mg/kg/dia, 1 a 2x<br>dia, e, em caso de não resposta,<br>aumentar 0,5 mg/kg/dia a cada mês até<br>2,5 mg/kg/dia (dose máxima).|
||Ciclofosfamida|IV|600 mg/m2 em pulsoterapia<br>mensal por 3 a 6 meses|
||Ciclosporina|VO|Iniciar com 2,5 mg/kg/dia em<br>duas administrações e aumentar de 0,5 a<br>0,75 mg/kg/dia a cada 2 ou 3 meses. Em<br>caso de falha terapêutica, aumentar até<br>4 mg/kg/dia|
|Glicocorticoides|Prednisona|VO|Alta dose: > 60 mg/dia<br>Baixa dose: ≤ 5 mg/dia|
||Prednisolona|VO|Solução oral de 1 e 3 mg/mL|  
17  
|Classe|Medicamento|Via<br>administração|d|e<br>Posologia|
|---|---|---|---|---|
||Metilprednisolona<br>(succinato)|IV||20 a 30 mg/kg/dia por 1 a 3 dias<br>consecutivos, seguidos por doses de 2<br>mg/kg/dia de 2 a 4 vezes por dia. Dose<br>máxima de 60 mg|
||Metilprednisolona<br>(acetato)|Intra-<br>articular ou<br>periarticular||4 a 80 mg a cada 3 a 4 meses,<br>por via, a depender do tamanho da<br>articulação:<br>Grande: 20 a 80 mg;<br>Média: 10 a 40 mg;<br>Pequena: 4 a 10 mg|
|Anti-inflamatórios não<br>esteroidais (AINE)|Naproxeno|VO||500 a 1.000 mg/dia, 2x/dia (usar<br>a menor dose pelo menor tempo<br>possível)|
||Ibuprofeno|VO||600 a 2.700 mg/dia, 3x/dia.|  
Legenda: VO: Via oral; IM: intramuscular; SC: subcutânea; IV: intravenosa, †Conforme avaliação de atividade de doença pelo ICAD.  
Nota 1: A apresentação de abatacepte em pó para solução injetável 250 mg está excluída deste Protocolo devido à descontinuação temporária da fabricação do medicamento, conforme petição protocolada em 15 de março de 2022 junto à Anvisa. No entanto, até a presente data, a empresa não realizou qualquer alteração na solicitação de descontinuação do abatacepte junto à Anvisa. Essa exclusão poderá ser revisada posteriormente, conforme a regularização do fornecimento do medicamento ao Ministério da Saúde.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O tratamento do paciente com AR deve ser multidisciplinar, incluindo promoção da saúde, reabilitação, controle de comorbidades e imunizações. É importante instruir e verificar com o paciente as condições de armazenamento e de administração dos medicamentos, em especial naqueles em uso de MMCDbio, os quais requerem refrigeração e uso parenteral. Mesmo os pacientes atendidos em serviços de atenção especializada devem ser também acompanhados na atenção primária à saúde (APS).  
Alguns medicamentos recomendados para o tratamento da artrite reumatoide podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo Mycobacterium tuberculosis (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de MMCDbio ou MMCDsae e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas:  
 Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
 Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa, independente de sinais e sintomas.  
 Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
 Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo  
18  
com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
 Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de MMCDbio ou MMCDsae após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, a critério da equipe de saúde assistente, o início de uso de MMCDbio ou MMCDsae pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
 Nos casos de troca do MMCDbio ou MMCDsae, não é necessário repetir as condutas preconizadas para início de tratamento.  
Durante o acompanhamento da pessoa em uso de MMCDbio ou MMCDsae, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
 Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
 Para que o uso dos MMCDbio ou MMCDsae não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com MMCDbio ou MMCDsae devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com MMCDbio ou MMCDsae devem manter o monitoramento com o IGRA.  
 Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
 Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
 Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.  
Revisões periódicas para a avaliação de eficácia e segurança do tratamento devem fazer parte do tratamento dos pacientes com AR62. Inicialmente, os pacientes devem ser avaliados em intervalos menores (1 a 3 meses). Uma vez atingido o objetivo do tratamento (remissão para AR mais recente e atividade baixa de doença para AR de anos de evolução), podem ser considerados intervalos maiores (6 a 12 meses). No entanto, mesmo sem a necessidade de visitas mais frequentes para a avaliação de eficácia, a monitorização de segurança deve ser observada, ou seja, os intervalos dos exames laboratoriais para monitorização dos possíveis eventos adversos de medicamentos devem ser respeitados. Em cada consulta é importante a avaliação sistemática da apresentação clínica do paciente. Nesse contexto, a atividade da AR pode ser medida por meio de índices combinados de atividade de doença (ICAD) e algum instrumento de medida da capacidade funcional, como o Health Assessment Questionnaire (HAQ). Essa avaliação rotineira permite a objetividade no acompanhamento da evolução do paciente.  
Entre os eventos adversos mais comuns estão a anemia, leucopenia, trombocitopenia e disfunção renal e hepática, comum entre a maioria dos medicamentos, em especial os MMCDs. Dessa forma, sugere-se a realização de hemograma, creatinina sérica e aminotransferases/transaminases, conforme sugerido no Quadro 5, devendo ser mais frequente no início do tratamento, quando ocorre a maioria dos eventos adversos. Pacientes que usarem MMCDbio ou MMCDsae devem ser avaliados quanto à presença de infecções graves ativas, insuficiência cardíaca moderada ou grave, esclerose múltipla, neurite óptica, hipersensibilidade prévia a MMCDbio, malignidade ou linfoma, imunodeficiência adquirida ou congênita. Contudo, a presença dessas comorbidades não  
19  
é critério definitivo para contraindicação de MMCDbio. Em relação ao MMCDsae, ele está associado a maior incidência de herpes zóster, devendo o paciente e a equipe assistente estarem atentos para o surgimento de lesões compatíveis.  
**Quadro 5 - Periodicidade de monitoramento laboratorial de pacientes em uso de MMCD (hemograma, aminotransferases/transaminases, creatinina)* conforme duração da terapia**  
|Medicamento|Até 3 meses|3 a 6 meses|Após 6<br>meses|
|---|---|---|---|
|Hidroxicloroquina/<br>Cloroquina|Nenhum após avaliação inicial|Nenhum|Nenhu<br>m|
|Leflunomida|2-4 semanas|8-12<br>semanas|12<br>semanas|
|Metotrexato|2-4 semanas|8-12<br>semanas|12<br>semanas|
|Sulfassalazina|2-4 semanas|8-12<br>semanas|12<br>semanas|
|MMCDsae|2-4 semanas|8-12<br>semanas|12<br>semanas|
|MMCDbio anti-TNF|2-4 semanas|8-12<br>semanas|12<br>semanas|
|MMCDbio não anti-TNF|2-4 semanas|8-12<br>semanas|12<br>semanas|  
*Monitoramento mais frequente nos 3 primeiros meses de terapia ou após aumento de dose. Pacientes com morbidades, exames anormais e múltiplas terapias podem requerer monitoramento mais frequente do que o apresentado neste Quadro.  
Podem ser necessárias redução de dose, interrupção do tratamento ou substituição de medicamento(s) frente a eventos adversos, podendo variar caso a caso, conforme o medicamento usado e a apresentação clínica do caso. Apesar de as condutas deverem ser individualizadas, no Material Suplementar são apresentadas particularidades do monitoramento de acordo com cada medicamento, além de condutas diante de eventos adversos. É importante salientar que é preferível a substituição do medicamento no caso de eventos adversos intoleráveis do que a sua manutenção com menor dose.  
A AR é uma doença crônica e, em geral, seu tratamento é para a vida toda. Inexistem evidências sobre a melhor forma de interrupção de medicamentos para AR, em especial os MMCDbio. Quando ocorre resposta terapêutica completa, isto é, remissão pelos índices compostos de atividade de doença, e sustentada, ou seja, por mais de 6 a 12 meses, pode-se tentar a retirada gradual do MMCDbio ou do tofacitinibe, mantendo-se o uso de MMCDs. A retirada de medicamentos deve ser individualizada, compartilhada com o paciente e, preferencialmente, com o apoio de especialistas. Caso haja piora de atividade de doença, devese reiniciar o esquema terapêutico anterior e seguir as recomendações de dose inicial e de ajuste de doses e troca de medicamentos indicadas neste Protocolo. Nos raros casos de remissão após interrupção de tratamento, revisões anuais podem ser adotadas. Nessas consultas, além da história e do exame físico, exames como velocidade de hemossedimentação e proteína C reativa podem ser solicitados. Na confirmação de reativação da doença, as recomendações deste Protocolo voltam a ser aplicáveis  
20

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos.  
O tratamento de AR deve ser realizado em serviços especializados, para fins de diagnóstico e de seguimento, que contemplem equipes multiprofissionais para acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige familiaridade com manifestações clínicas próprias, o médico responsável pelo tratamento deve ter experiência e ser treinado nessa atividade, devendo ser, preferencialmente, um reumatologista. Contudo, o tratamento com MTX pode ser iniciado na APS, em circunstâncias especiais em que há evidências sobre o diagnóstico, enquanto o paciente aguarda atendimento em serviços especializados. Os atendimentos correspondentes aos níveis de atenção estão sugeridos no Quadro 6.  
**Quadro 6 - Níveis de atenção à saúde e encaminhamento para serviço especializado para pacientes com artrite reumatoide**  
|Nível de atenção|Orientações|
|---|---|
|Atenção Primária|O médico da atenção primária pode iniciar o tratamento com MTX enquanto o paciente|
|à Saúde (APS)|aguarda atendimento prioritário com o reumatologista. Entretanto, não é recomendado o início na<br>APS no caso de pessoas com citopenias isoladas (anemia, leucopenia ou trombocitopenias) ou<br>bicitopenias; ou aminotransferases/transaminases acima do limite superior de normalidade; ou<br>doença renal crônica (TFG entre 30 e 60 ml/min/1,73 m2).|
|Atenção|Em caso de falha da monoterapia inicial, sugere-se que a substituição do MMCDs por outro|
|Especializada à Saúde|MMCDs em monoterapia ou associação de dois MMCDs seja feita no serviço especializado com<br>experiência em acompanhamento de pacientes com AR.|
||Sugere-se o encaminhamento para o serviço especializado em reumatologia dos pacientes<br>com: diagnóstico de artrite reumatoide (estabelecido com pontuação ≥ 6 pelos critérios<br>classificatórios); ou alta suspeita de artrite reumatoide, definida por presença de artrite<br>(sinovite/edema identificado pelo médico) de três ou mais articulações associadas a rigidez matinal<br>por mais de 30 minutos; ou teste do aperto (teste do squeeze) positivo.|  
Nota: Teste do squeeze: Teste com elevada sensibilidade para avaliar a dor de maneira mais objetiva, sendo referida após o examinador comprimir as articulações metacarpofalangianas ou metatarsofalangianas. Fonte: TelessaúdeRS63.  
No início de tratamento e nas substituições terapêuticas, exceto em casos em que haja contraindicação, não há preferência por um MMCDbio frente a outro ou MMCDsae (baricitinibe, tofacitinibe ou upadacitinibe), uma vez que todos possuem efetividade clínica semelhante. A administração dos MMCDbio deverá ser procedida preferencialmente em centros de referência para aplicação, com vistas à maior racionalidade do uso e ao monitoramento da efetividade desses medicamentos. A troca de um MMCDbio por outro MMCDbio em paciente que vem respondendo adequadamente à terapia deve ser realizada de acordo com o fluxo de tratamento deste PCDT.  
A prescrição de medicamentos biológicos dependerá da disponibilidade dos medicamentos da Assistência Farmacêutica no âmbito do SUS.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
21  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde ia Base Nacional e Dados e Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúdde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
1. Lee DM, Weinblatt ME. Rheumatoid arthritis. Lancet. 2001.  
2. Rupp I, Boshuizen HC, Jacobi CE, Dinant HJ, Van Den Bos GAM. Comorbidity in Patients with Rheumatoid Arthritis: Effect on Health-Related Quality of Life. J Rheumatol. 2004;  
3. Ledingham J, Snowden N, Ide Z. Diagnosis and early management of inflammatory arthritis. BMJ. 2017;  
4. Boonen A, Severens JL. The burden of illness of rheumatoid arthritis. Clinical Rheumatology. 2011.  
5. Mould-Quevedo J, Peláez-Ballestas I, Vázquez-Mellado J, Terán-Estrada L, Esquivel-Valerio J, Ventura-Ríos L, et al. [Social costs of the most common inflammatory rheumatic diseases in Mexico from the  patient’s perspective]. Gac Med Mex. 2008;144(3):225–31.  
6. Álvarez-Hernández E, Peláez-Ballestas I, Boonen A, Vázquez-Mellado J, Hernández-Garduño A, Rivera FC, et al. Catastrophic health expenses and impoverishment of households of patients with rheumatoid arthritis. Reumatol Clin. 2012;  
7. Chermont GC, Kowalski SC, Ciconelli RM, Ferraz MB. Resource utilization and the cost of rheumatoid arthritis in Brazil. Clin Exp Rheumatol. 2008;  
8. Peláez-Ballestas I, Sanin LH, Moreno-Montoya J, Alvarez-Nemegyei J, Burgos-Vargas R, Garza-Elizondo M, et al. Epidemiology of the rheumatic diseases in Mexico. A study of 5 regions based on the COPCORD methodology. J Rheumatol. 2011;  
9. Alamanos Y, Drosos AA. Epidemiology of adult rheumatoid arthritis. Autoimmunity Reviews. 2005.  
10. Jiang X, Frisell T, Askling J, Karlson EW, Klareskog L, Alfredsson L, et al. To what extent is the familial risk of rheumatoid arthritis explained by established rheumatoid arthritis risk factors? Arthritis Rheumatol. 2015;  
11. Knevel R, Huizinga TWJ, Kurreeman F. Genomic Influences on Susceptibility and Severity of Rheumatoid Arthritis. Rheumatic Disease Clinics of North America. 2017.  
12. Kay J, Upchurch KS. ACR/EULAR 2010 rheumatoid arthritis classification criteria. Rheumatol (United Kingdom). 2012;  
13. De Azevedo ABC, Ferraz MB, Ciconelli RM. Indirect costs of rheumatoid arthritis in Brazil. Value Heal. 2008;  
14. Nell VPK, Machold KP, Eberl G, Stamm TA, Uffmann M, Smolen JS. Benefit of very early referral and very early therapy with disease-modifying anti-rheumatic drugs in patients with early rheumatoid arthritis. Rheumatology. 2004;  
15. Monti S, Montecucco C, Bugatti S, Caporali R. Rheumatoid arthritis treatment: The earlier the better to prevent joint damage. RMD Open. 2015.  
16. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.  
17. Grading of Recommendations Assessment, Development and Evaluation (GRADE). 2019; Available from: http://gradeworkinggroup.org/#  
22  
18. Schünemann HJ, Wiercioch W, Brozek J, Etxeandia-Ikobaltzeta I, Mustafa RA, Manja V, et al. GRADE Evidence to Decision (EtD) frameworks for adoption, adaptation, and de novo development of trustworthy recommendations: GRADEADOLOPMENT. J Clin Epidemiol. 2017;  
19. Singh JA, Saag KG, Bridges SL, Akl EA, Bannuru RR, Sullivan MC, et al. 2015 American College of Rheumatology Guideline for the Treatment of Rheumatoid Arthritis. Arthritis Care Res (Hoboken). 2016;  
20. Grading of Recommendations Assessment, Development and Evaluation (GRADE). 2019; Available from: https://gradepro.org/  
21. Arnett FC, Edworthy SM, Bloch DA, Mcshane DJ, Fries JF, Cooper NS, et al. The american rheumatism association 1987 revised criteria for the classification of rheumatoid arthritis. Arthritis Rheum. 1988;  
22. Aletaha D, Neogi T, Silman AJ, Funovits J, Felson DT, Bingham CO, et al. 2010 Rheumatoid arthritis classification criteria: An American College of Rheumatology/European League Against Rheumatism collaborative initiative. Arthritis and Rheumatism. 2010.  
23. Venables PJ. Clinical manifestations of rheumatoid arthritis. UpToDate. 2019;  
24. Matteson EL DJ. Overview of the systemic and nonarticular manifestations of rheumatoid arthritis. UpToDate [Internet].  
- 2019; Available from: https://www.uptodate.com/contents/overview-of-the-systemic-and-nonarticular-manifestations-of-  
rheumatoid-arthritis  
25. Currier BL CJ. Cervical subluxation in rheumatoid arthritis. UpToDate [Internet]. 2019; Available from: https://www.uptodate.com/contents/cervical-subluxation-in-rheumatoid-arthritis  
26. Teh J, Østergaard M. What the Rheumatologist Is Looking for and What the Radiologist Should Know in Imaging for Rheumatoid Arthritis. Radiologic Clinics of North America. 2017.  
27. Van der Heijde DMFM. Plain X-rays in rheumatoid arthritis: Overview of scoring methods, their reliability and applicability. Baillieres Clin Rheumatol. 1996;  
28. Walther M, Harms H, Krenn V, Radke S, Faehndrich TP, Gohlke F. Correlation of power Doppler sonography with vascularity of the synovial tissue of the knee joint in patients with osteoarthritis and rheumatoid arthritis. Arthritis Rheum. 2001;  
29. JF MN. Livro da Sociedade de Reumatologia. Barueri, São Paulo: Manole; 2018.  
30. Smolen JS, Aletaha D, Barton A, Burmester GR, Emery P, Firestein GS, et al. Rheumatoid arthritis. Nat Rev Dis Prim. 2018 Feb;4:18001.  
31. Aletaha D, Smolen J. The Simplified Disease Activity Index (SDAI) and the Clinical Disease Activity Index  (CDAI): a review of their usefulness and validity in rheumatoid arthritis. Clin Exp Rheumatol. 2005;23(5 Suppl 39):S100-8.  
32. BRASIL. Ministério da Saúde. Secretaria de Atenção Especializada à Saúde. Secretaria de Ciência, Tecnologia I e IE em S. Portaria Conjunta no 5, de 16 de março de 2020. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reumatoide  
e Artrite Idiopática Juvenil. 2020; Available from: http://conitec.gov.br/images/Relatorios/Portaria/2020/PortariaConjunta_SCTIE_SAES_05_2020.pdf  
33. da Mota LMH, Kakehasi AM, Gomides APM, Duarte ALBP, Cruz BA, Brenol CV, et al. 2017 recommendations of the Brazilian Society of Rheumatology for the pharmacological treatment of rheumatoid arthritis. Adv Rheumatol. 2018;  
34. Vliet Vlieland TPM, van den Ende CH. Nonpharmacological treatment of rheumatoid arthritis. Curr Opin Rheumatol. 2011 May;23(3):259–64.  
35. Silva KN, Mizusaki Imoto A, Almeida GJ, Atallah ÁN, Peccin MS, Fernandes Moça Trevisani V. Balance training (proprioceptive training) for patients with rheumatoid arthritis. Cochrane Database Syst Rev. 2010;  
36. Forestier R, André-Vert J, Guillez P, Coudeyre E, Lefevre-Colau MM, Combe B, et al. Non-drug treatment (excluding surgery) in rheumatoid arthritis: Clinical practice guidelines. Jt Bone Spine. 2009;  
23  
37. Falagas ME, Zarkadoulia E, Rafailidis PI. The therapeutic effect of balneotherapy: Evaluation of the evidence from randomised controlled trials. Int J Clin Pract. 2009;  
38. Stucki G, Cieza A, Geyh S, Battistella L, Lloyd J, Symmons D, et al. ICF Core Sets for rheumatoid arthritis. Journal of Rehabilitation Medicine, Supplement. 2004.  
39. Riemsma RP, Kirwan JR, Taal E, Rasker HJ. Patient education for adults with rheumatoid arthritis. Cochrane Database Syst Rev. 2003;  
40. Macfarlane GJ, Paudyal P, Doherty M, Ernst E, Lewith G, Macpherson H, et al. A systematic review of evidence for the effectiveness of practitioner-based complementary and alternative therapies in the management of rheumatic diseases: Rheumatoid arthritis. Rheumatol (United Kingdom). 2012;  
41. Takken T, Van Brussel M, Engelbert RHH, Van Der Net J, Kuis W, Helders PJM. Exercise therapy in juvenile idiopathic arthritis: A Cochrane Review. Eur J Phys Rehabil Med. 2008;  
42. Takken T, Van Brussel M, Engelbert RHH, Van Der Net J, Kuis W, Helders PJM. Exercise therapy in juvenile idiopathic arthritis. Cochrane Database of Systematic Reviews. 2008.  
43. Epps H, Ginnelly L, Utley M, Southwood T, Gallivan S, Sculpher M, et al. Is hydrotherapy cost-effective? A randomised controlled trial of combined hydrotherapy programmes compared with physiotherapy land techniques in children with juvenile idiopathic arthritis. Health Technol Assess (Rockv). 2005;  
44. Baillet A, Vaillant M, Guinot M, Juvin R, Gaudin P. Efficacy of resistance exercises in rheumatoid arthritis: Meta-analysis of randomized controlled trials. Rheumatology. 2012;  
45. J W. The effectiveness of hand exercises for persons with rheumatoid arthritis: a systematic review. J Hand Ther. 2004;  
46. Baillet A, Zeboulon N, Gossec L, Combescure C, Bodin LA, Juvin R, et al. Efficacy of cardiorespiratory aerobic exercise in rheumatoid arthritis: Meta-analysis of randomized controlled trials. Arthritis Care Res. 2010;  
47. Hurkmans E, van der Giesen FJ, Vliet Vlieland TPM, Schoones J, Van den Ende E. Home‐based exercise therapy for rheumatoid arthritis. Cochrane Database Syst Rev [Internet]. 2009;(2). Available from:  
https://doi.org//10.1002/14651858.CD007829  
48. Hurkmans E, van der Giesen FJ, Vliet Vlieland TP, Schoones J, Van den Ende ECHM. Dynamic exercise programs (aerobic capacity and/or muscle strength training) in  patients with rheumatoid arthritis. Cochrane database Syst Rev. 2009 Oct;2009(4):CD006853.  
49. Cairns AP, McVeigh JG. A systematic review of the effects of dynamic exercise in rheumatoid arthritis. Rheumatology International. 2009.  
50. Conn VS, Hafdahl AR, Mehr DR. Interventions to increase physical activity among healthy adults: meta-analysis of outcomes. Am J Public Health. 2011;  
51. Hurkmans EJ, Jones A, Li LC, Vlieland TPMV. Quality appraisal of clinical practice guidelines on the use of physiotherapy in rheumatoid arthritis: A systematic review. Rheumatology. 2011;  
52. Greene B, Lim SS. The role of physical therapy in management of patients with osteoarthritis and rheumatoid arthritis. Bulletin on the Rheumatic Diseases. 2003.  
53. Brosseau L, Yonge K, Welch V, Marchand S, Judd M, Wells GA, et al. Transcutaneous electrical nerve stimulation (TENS) for the treatment of rheumatoid arthritis in the hand. Cochrane Database Syst Rev. 2003;  
54. Welch V, Brosseau L, Casimiro L, Judd M, Shea B, Tugwell P, et al. Thermotherapy for treating rheumatoid arthritis. Cochrane Database Syst Rev. 2002;  
55. Casimiro L, Brosseau L, Welch V, Milne S, Judd M, Wells GA, et al. Therapeutic ultrasound for the treatment of rheumatoid arthritis. Cochrane Database Syst Rev. 2002;  
24  
56. Knittle K, Maes S, De Gucht V. Psychological interventions for rheumatoid arthritis: Examining the role of self-regulation with a systematic review and meta-analysis of randomized controlled trials. Arthritis Care Res. 2010;  
57. Dissanayake RK, Bertouch J V. Psychosocial interventions as adjunct therapy for patients with rheumatoid arthritis: A systematic review. International Journal of Rheumatic Diseases. 2010.  
58. Hagen KB, Byfuglien MG, Falzon L, Olsen SU, Smedslund G. Dietary interventions for rheumatoid arthritis. Cochrane Database of Systematic Reviews. 2009.  
59. Nissen SE, Yeomans ND, Solomon DH, Lüscher TF, Libby P, Husni ME, et al. Cardiovascular safety of celecoxib, naproxen, or ibuprofen for arthritis. N Engl J Med. 2016;  
60. Mota LMH da, Cruz BA, Brenol CV, Pereira IA, Rezende-Fronza LS, Bertolo MB, et al. Guidelines for the drug treatment of rheumatoid arthritis. Rev Bras Reumatol. 2013 Apr;53(2):158–83.  
61. Brasil. Manual de recomendações para o Controle da Tuberculose no Brasil. Ministério da Saúde. 2019.  
62. Katchamart W, Bombardier C. Systematic monitoring of disease activity using an outcome measure improves outcomes in rheumatoid arthritis. Journal of Rheumatology. 2010.  
63. Universidade Federal do Rio Grande do Sul. TelessaúdeRE. Available from: https://www.ufrgs.br/telessauders/nossos-  
servicos/teleconsultoria/regulasus/  
25

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Eu, _______________________________________________________________________________________ (nome  
do(a) responsável), responsável legal pelo paciente ). Nome do(a) paciente, ______________________________________  
__________________________________________________________ declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de abatacepte, adalimumabe, azatioprina, baricitinibe, certolizumabe pegol, ciclosporina, ciclofosfamida, cloroquina, etanercepte, golimumabe, hidroxicloroquina, ibuprofeno, infliximabe, leflunomida, metilprednisolona, metotrexato, naproxeno, prednisolona,  prednisona, rituximabe, sulfassalazina, tocilizumabe e tofacitinibe indicados para o tratamento da artrite reumatoide.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)___________________  
________________________________________________________________________________________________ (nome  
do(a) médico que prescreve). Expresso também minha concordância e espontânea vontade em submeter-me ao referido  
tratamento, assumindo a responsabilidade e os riscos pelos eventuais eventos indesejáveis.  
Assim, declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber pode(m) trazer os seguintes benefícios:  
- prevenção das complicações da doença;  
- controle da atividade da doença;  
- melhora da capacidade de realizar atividades funcionais;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- os riscos na gestação e na amamentação já são conhecidos; portanto, caso engravide, devo avisar imediatamente o médico;  
- medicamentos classificados na gestação como categoria B (estudos em animais não mostraram anormalidades nos descendentes, porém não há estudos em humanos; risco para o bebê muito improvável): infliximabe, etanercepte, adalimumabe, golimumabe, certolizumabe pegol e sulfassalazina (no primeiro trimestre);  
- medicamentos classificados na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos): baricitinibe, cloroquina, hidroxicloroquina, ciclosporina, metilprednisolona, abatacepte, rituximabe, tocilizumabe, tofacitinibe e naproxeno (este último, nos primeiro e segundo trimestres de gestação);  
- medicamentos classificados na gestação como categoria D (há evidências de riscos ao feto, mas um benefício potencial pode ser maior do que os riscos) sulfassalazina (no terceiro trimestre de gestação), ciclofosfamida e azatioprina. Naproxeno e demais antiinflamatórios não esteroidais também se apresentam nesta categoria quando utilizados no terceiro trimestre de gestação ou próximo ao parto.  
- medicamentos classificados na gestação como categoria X (estudos em animais ou em humanos claramente mostraram risco para o bebê que suplantam quaisquer potenciais benefícios, sendo contraindicados na gestação): leflunomida, e metotrexato;  
26  
- eventos adversos do ibuprofeno: cólicas abdominais, gastralgia ou desconforto gástrico, indigestão, náusea ou vômito. Sangramento gastrointestinal com ou sem ulceração, assim como o aparecimento de erupções cutâneas;  
- eventos adversos do naproxeno: dor abdominal, sede, constipação, diarreia, dispneia, náusea, estomatite, azia, sonolência, vertigens, enxaquecas, tontura, erupções cutâneas, prurido, sudorese, ocorrência de distúrbios auditivos e visuais, palpitações, edemas, dispepsia e púrpura;  
- eventos adversos da azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
- eventos adversos de hidroxicloroquina: distúrbios visuais com visão borrada e fotofobia, edema macular, pigmentação anormal, retinopatia, atrofia do disco óptico, escotomas, diminuição da acuidade visual e nistagmo; outras reações: problemas emocionais, dores de cabeça, tonturas, movimentos involuntários, cansaço, branqueamento e queda de cabelos, mudanças da cor da pele e alergias leves a graves, náusea, vômitos, perda de apetite, desconforto abdominal, diarreia, parada na produção de sangue pela medula óssea (anemia aplásica), parada na produção de células brancas pela medula óssea (agranulocitose), diminuição de células brancas do sangue e de plaquetas, destruição das células do sangue (hemólise); reações raras: miopatia, paralisia, zumbido e surdez;  
- eventos adversos da sulfassalazina: dores de cabeça, aumento da sensibilidade aos raios solares, alergias de pele graves, dores abdominais, náusea, vômitos, perda de apetite, diarreia, hepatite, dificuldade para engolir, diminuição do número dos glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos do sangue (anemia hemolítica), diminuição do número de plaquetas no sangue, falta de ar associada a tosse e febre (pneumonite intersticial), dores articulares, cansaço e reações alérgicas;  
- eventos adversos da ciclosporina: disfunção renal, tremores, aumento da quantidade de pelos no corpo, pressão alta, hipertrofia gengival, aumento dos níveis de colesterol e triglicerídios, formigamentos, dor no peito, infarto do miocárdio, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, gastrite, úlcera péptica, soluços, inflamação na boca, dificuldade para engolir, hemorragias, inflamação do pâncreas, prisão de ventre, desconforto abdominal, síndrome hemolíticourêmica, diminuição das células brancas do sangue, linfoma, calorões, hiperpotassemia, hipomagnesemia, hiperuricemia, toxicidade para os músculos, disfunção respiratória, sensibilidade aumentada a temperatura e reações alérgicas, toxicidade renal e hepática e ginecomastia (aumento das mamas no homem);  
- eventos adversos da metilprednisolona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, e manifestação de diabete mélito;  
- eventos adversos da prednisona e da prednisolona: aumento do apetite, úlcera gástrica com possível perfuração e sangramento, inflamação do pâncreas, cansaço, insônia, catarata, aumento da pressão dentro do olho, glaucoma, olhos inchados, aumento da ocorrência de infecção do olhos por fungos e vírus. Pode surgir também diabetes e aumento dos valores de colesterol.  
- eventos adversos do metotrexato: convulsões, encefalopatia, febre, calafrios, sonolência, queda de cabelo, espinhas, furúnculos, alergias de pele leves a graves, sensibilidade à luz, alterações da pigmentação da pele e de mucosas, náusea, vômitos, perda de apetite, inflamação da boca, úlceras de trato gastrointestinal, hepatite, cirrose e necrose hepática, diminuição das células brancas do sangue e das plaquetas, insuficiência renal, fibrose pulmonar e diminuição das defesas imunológicas do organismo com ocorrência de infecções;  
27  
- eventos adversos de adalimumabe, etanercepte e infliximabe: reações no local da aplicação da injeção como dor e coceiras, dor de cabeça, tosse, náusea, vômitos, febre, cansaço, alteração na pressão arterial; reações mais graves: infecções oportunísticas fúngicas e bacterianas do trato respiratório superior, como faringite, rinite, laringite, tuberculose, histoplasmose, aspergilose e nocardiose, podendo, em casos raros, ser fatal;  
- eventos adversos de abatacepte: reações no local da aplicação da injeção ou reações alérgicas durante ou após a infusão, dor de cabeça, nasofaringite, enjoos e risco aumentado a uma variedade de infecções, como herpes-zóster, infecção urinária, gripe, pneumonia, bronquite e infecção localizada. A tuberculose pode ser reativada ou iniciada com o uso do medicamento e aumento de risco para alguns tipos de câncer (abatacepte). O vírus da hepatite B pode ser reativado (abatacepte);  
- eventos adversos do certolizumabe pegol: Infecção bacteriana (incluindo tuberculose (pulmonar, extrapulmonar e disseminada) e abscessos), infecções virais (incluindo herpes, papilomavirus, influenza), desordens eosinofilicas, leucopenia (incluindo linfopenia e neutropenia), dor de cabeça (incluindo enxaqueca), anormalidade sensorial, náusea e vômito, hepatite (incluindo aumento das enzimas hepáticas), pirexia, dor (em qualquer local), astenia, prurido (em qualquer local), reação no local de injeção.  
- eventos adversos do difosfato de cloroquina: cardiomiopatia; hipotensão; alteração eletrocardiográfica, como inversão ou depressão da onda T comalargamento do complexo QRS; eritema multiforme; anemia hemolítica (pode ocorrer em pacientes com deficiência de glicose-6-fosfato desidrogenase (G6PD); neutropenia; pancitopenia; trombocitopenia; agranulocitose reversível.  
- eventos adversos do golimumabe: infecções bacterianas (incluindo septicemia e pneumonia), micobacterianas (tuberculose), fúngicas invasivas e oportunistas, reativação do vírus da hepatite B, insuficiência cardíaca congestiva, distúrbios desmielinizantes do sistema nervoso central, pancitopenia, leucopenia, neutropenia, agranulocitose e trombocitopenia.  
- eventos adversos da leflunomida: diarreia, náusea, vômitos, anorexia, distúrbios da mucosa oral (por exemplo: estomatite aftosa, ulcerações na boca), dor abdominal, elevação dos parâmetros laboratoriais hepáticos (por exemplo: transaminases, menos frequentemente gama-GT, fosfatase alcalina, bilirrubina), colite incluindo colite microscópica; elevação da pressão sanguínea. Leucopenia com contagem de leucócitos > 2 x 109/L (>2 g/L); anemia, trombocitopenia com contagem de plaquetas <100 x 109/L (<100 g/L). Cefaleia, vertigem e parestesia; distúrbios do paladar e ansiedade. Reações alérgicas leves (incluindo exantema maculopapular e outros), prurido, eczema, pele ressecada, aumento da perda de cabelo. Urticária; perda de peso e astenia; hipopotassemia.  
- eventos adversos do rituximabe: infecção do trato respiratório superior, infecções do trato urinário; bronquite, sinusite, gastroenterite, pé-de-atleta; neutropenia; reações relacionadas à infusão (hipertensão, náusea, erupção cutânea, pirexia, prurido, urticária, irritação na garganta, rubor quente, hipotensão, rinite, tremores, taquicardia, fadiga, dor orofaríngea, edema periférico, eritema; edema generalizado, broncoespasmo, sibilo, edema na laringe, edema angioneurótico, prurido generalizado, anafilaxia, reação anafilactoide); hipercolesterolemia; cefaleia; parestesia; enxaqueca, tontura, ciática; alopecia; depressão, ansiedade; dispepsia, diarreia, refluxo gastresofágico, úlcera oral, dor abdominal superior; artralgia/dor; musculoesquelética, osteoartrite, bursite; níveis reduzidos de IgM; níveis reduzidos de IgG. Foi observada a ocorrência de condições cardíacas isquêmicas preexistentes que se tornam sintomáticas, como angina pectoris, bem como fibrilação e flutter atrial. Portanto, os pacientes com histórico de cardiopatia deverão ser monitorados atentamente.  
- eventos adversos do tocilizumabe: reações no local da aplicação da injeção e durante a infusão, alergias, coceira, urticária, dor de cabeça, tonturas, aumento da pressão sanguínea, tosse, falta de ar, feridas na boca, aftas, dor abdominal e risco aumentado a uma variedade de infecções, como infecções de vias aéreas superiores, celulite, herpes simples e herpes zoster, alterações nos exames laboratoriais (aumento das enzimas do fígado, bilirrubinas, aumento do colesterol e triglicerídios);  
28  
- eventos adversos do baricitinibe: aumento da taxa de infecções, neutropenia, linfopenia, reativação viral, diminuições dos níveis de hemoglobina, aumentos nos parâmetros de lipídeos, aumento de aminotransferases, trombose venosa profunda, embolia pulmonar, perfuração gastrointestinal. O perfil de segurança em longo prazo do baricitinibe ainda não está bem estabelecido;  
- eventos adversos do tofacitinibe: aumento da taxa de infecções, reativação viral, trombose venosa profunda, malignidade e distúrbio linfoproliferativo, perfurações gastrintestinais, hipersensibilidade, linfopenia, neutropenia, diminuição dos níveis de hemoglobina, aumento nos parâmetros lipídicos, elevação das enzimas hepáticas. O perfil de segurança em longo prazo do tofacitinibe ainda não está bem estabelecido.  
- eventos adversos do upadacitinibe: aumento da taxa de infecções; reativação viral; neutropenia; linfopenia; anemia; aumentos nos parâmetros lipídicos; elevações de enzimas hepáticas; tromboembolismo venoso. O perfil de segurança em longo prazo do upadacitinibe ainda não está bem estabelecido.  
- alguns medicamentos biológicos aumentam o risco de tuberculose, devendo ser realizada antes do início do tratamento pesquisa de infecção ativa ou de tuberculose latente, para tratamento apropriado; - medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula;  
- o risco de ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvêlo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a) inclusive em caso de desistência do uso do(s) medicamento(s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (    ) Sim      (    ) Não  
Meu tratamento constará de um ou mais dos seguintes medicamentos:  
- (    ) abatacepte (    ) adalimumabe (    ) azatioprina (    ) baricitinibe (    ) certolizumabe pegol  (    ) ciclofosfamida (    ) ciclosporina (    ) cloroquina  
- (    ) cloroquina  
- (    ) etanercepte (    ) golimumabe  
- (    ) hidroxicloroquina  
- (    ) ibuprofeno  
- (    ) infliximabe  
- (    ) leflunomida  
- (    ) metilprednisolona  
- (    ) metotrexato  
- (    ) prednisolona  
- (    ) prednisona  
- (    ) rituximabe  
- (    ) naproxeno (    ) prednisolona (    ) prednisona (    ) rituximabe (    ) sulfassalazina (    ) tocilizumabe (    ) tofacitinibe (    ) upadacitinibe  
29  
<!-- Start of picture text -->
Local:                                                                                               Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
NOTA 3 - A administração intravenosa de ciclofosfamida é compatível com o procedimento 03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS. Nota 4: A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
30

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
CLASSIFICAÇÃO DA ATIVIDADE DA DOENÇA, AVALIAÇÃO DA CAPACIDADE FUNCIONAL E MONITORAMENTO DE EVENTOS ADVERSOS.  
**Quadro S1 - Classificação da atividade da doença**  
|Índices<br>compostos da<br>atividade de<br>doença (ICAD)|Descrição|
|---|---|
|DAS-28: Disease<br>Activity Score, 28<br>joints (0,49 a<br>9,07).|O DAS-28 é um ICAD calculado a partir de quatro variáveis: (1) número de articulações dolorosas<br>entre 28 pré-estabelecidas: interfalangianas proximais, metacarpofalangianas, punhos, cotovelos,<br>ombros e joelhos), (2) número de articulações edemaciadas entre 28 pré-estabelecidas (interfalangianas<br>proximais, metacarpofalangianas, punhos, cotovelos, ombros e joelhos), (3) velocidade de<br>hemossedimentação (VHS) ou velocidade de sedimentação globular VSG em mm/h e (4) Escala visual<br>analógica de saúde global segundo o paciente (EVAp: 0 a 100 mm). A fórmula do DAS-28 é: 0,56 x<br>raiz quadrada(dolorosas28) + 0,28 x raiz quadrada (edemaciadas28) + 0,70 x ln (VHS) + 0,014 x<br>EVAp.|
|SDAI: Simplified<br>Disease Activity<br>Score (0,1 a 86)|O SDAI é um ICAD calculado a partir de cinco variáveis: (1) número de articulações dolorosas entre<br>28 pré-estabelecidas (interfalangianas proximais, metacarpofalangianas, punhos, cotovelos, ombros e<br>joelhos), (2) número de articulações edemaciadas entre 28 pré-estabelecidas (interfalangianas<br>proximais, metacarpofalangianas, punhos, cotovelos, ombros e joelhos), (3) proteína C reativa (PCR de<br>0,1 a 10 mg/dL), (4) Escala visual analógica de atividade de doença segundo o paciente (EVAp: 0 a 10<br>cm) e (5) Escala visual analógica de atividade de doença segundo o médico (EVAm: 0 a 10 cm). A<br>fórmula do SDAI é: dolorosas28 + edemaciadas28 + PCR + EVAp + EVAm.|
|CDAI: Clinical<br>Disease Activity<br>Score (0 a 76)|O CDAI é um ICAD calculado a partir de quatro variáveis: (1) número de articulações dolorosas entre<br>28 pré-estabelecidas (interfalangianas proximais, metacarpofalangianas, punhos, cotovelos, ombros e<br>joelhos), (2) número de articulações edemaciadas entre 28 pré-estabelecidas (interfalangianas<br>proximais, metacarpofalangianas, punhos, cotovelos, ombros e joelhos), (3) Escala visual analógica de<br>atividade de doença segundo o paciente (EVAp: 0 a 10 cm) e (4) Escala Visual Analógica de atividade<br>de doença segundo o médico (EVAm: 0 a 10 cm). A fórmula do CDAI é: dolorosas28 +<br>edemaciadas28 + EVAp + EVAm.|  
Fonte: Secretaria de Atenção à Saúde, Ministério da Saúde. Portaria Conjunta SAS/SCTIE/MS nº 15, de 11 de dezembro de 2017. Protocolo Clínico e Diretrizes Terapêuticas - Artrite Reumatoide.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|Nº|Atividade|Sem<br>dificuldade|Com alguma<br>dificuldade|Com muita<br>dificuldade|Incapaz de fazer|
|---|---|---|---|---|---|
|01|Vestir-se, inclusive amarrar os cordões|||||
||dos seus sapatos, abotoar as suas roupas?|||||
|02|Lavar a cabeça e os cabelos?|||||  
31  
|03|Levantar-se de uma maneira ereta de<br>uma cadeira de encosto reto e sem<br>braços?|
|---|---|
|04|Deitar-se e levantar-se da cama?|
|05|Cortar um pedaço de carne?|
|06|Levar à boca um copo ou uma xícara<br>cheia de café, leite ou água?|
|07|Abrir um saco de leite comum?|
|08|Caminhar em lugares planos?|
|09|Subir cinco degraus?|
|10|Lavar o corpo inteiro e secá-lo após o<br>banho?|
|11|Tomar um banho de chuveiro?|
|12|Sentar-se e levantar-se de um vaso<br>sanitário?|
|13|Levantar os braços e pegar um objeto de<br>mais ou menos 2,5 quilos, que está<br>posicionado um pouco acima de sua<br>cabeça?|
|14|Curvar-se para pegar as roupas no chão?|
|15|Segurar-se em pé no ônibus ou no metrô?|
|16|Abrir potes ou vidros de conserva que<br>tenham sido previamente abertos?|
|17|Abrir e fechar torneiras?|
|18|Fazer compras na redondeza onde mora?|
|19|Entrar e sair de um ônibus?|
|20|Realizar tarefas como usar a vassoura<br>para varrer e o rodo para puxar água?|

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|Componentes|Perguntas|Maior escore|
|---|---|---|
|Componente 1 (vestir-se).|Perguntas 1 e 2||
|Componente 2 (levantar-se).|Perguntas 3 e 4||
|Componente 3 (alimentar-se).|Perguntas 5, 6 e 7||
|Componente 4 (caminhar).|Perguntas 8 e 9||
|Componente 5 (higiene pessoal).|Perguntas 10, 11 e 12||
|Componente 6 (alcançar objetos).|Perguntas 13 e 14||
|Componente 7 (apreender objetos).|Perguntas 15, 16 e 17||
|Componente 8 (outras atividades)|Perguntas 18, 19 e 20||  
32  
Fonte: Secretaria de Atenção à Saúde, Ministério da Saúde. Portaria Conjunta SAS/SCTIE/MS nº 15, de 11 de dezembro de 2017. Protocolo Clínico e Diretrizes Terapêuticas - Artrite Reumatoide.  
**Quadro S4 - Monitoramento de eventos adversos no tratamento da Artrite Reumatoide**  
|MEDICAMENTO<br>ANTI-INFLAMATÓRI|AVALIAÇÃO<br>OS NÃO ESTEROIDAIS (A|CONDUTA FRENTE A ALTERAÇÕES<br>INEs)|
|---|---|---|
|Ibuprofeno e naproxeno.|Hemograma,<br>creatinina,<br>AST/ TGO e ALT/TGP: a<br>cada 1 a 3 meses.|– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o LSN:<br>reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o LSN:<br>suspender o uso do medicamento até AST/TGO e ALT/TGP<br>entre 1 e 3 vezes o LSN e reiniciar com 50% da dose.<br>– Elevação de TGO/TGP acima de 5 vezes o LSN: interromper<br>o uso do medicamento.|
|Prednisona,<br>succinato<br>de<br>metilprednisolona, acetato de<br>metilprednisolona,<br>prednisolona.|Hemograma,<br>creatinina,<br>glicemia: a cada 1 a 3<br>meses.<br>Controle<br>da<br>pressão arterial|– Avaliar a redução da dose ou interromper o tratamento frente<br>a taxas alteradas.<br>– Monitorar eventos adversos do uso de corticosteroides.|
|MMCDs|||
|Metotrexato|Hemograma,<br>creatinina,<br>AST/ TGO e ALT/TGP: a<br>cada 1 a 3 meses.|–Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o LSN:<br>reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o LSN:<br>suspender o uso do medicamento até AST/TGO e ALT/TGP<br>entre 1 e 3 vezes o LSN e reiniciar com 50% da dose.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.<br>– Depuração de creatinina endógena entre 10 e 50 ml/minuto:<br>administrar 50% da dose.<br>– Depuração de creatinina endógena abaixo de 10 ml/minuto:<br>evitar uso.|
|Sulfassalazina|Hemograma, AST/TGO e<br>ALT/ TGP: a cada 1 a 3<br>meses.|– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.|  
33  
|MEDICAMENTO|AVALIAÇÃO|CONDUTA FRENTE A ALTERAÇÕES|
|---|---|---|
|||– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>– Elevação de TGO/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.|
|Leflunomida|Hemograma,<br>creatinina, AST/ TGO e<br>ALT/TGP: a cada 1 a 3<br>meses.|– Anemia, leucopenia ou trombocitopenia novas ou<br>mais acentuadas: reduzir a dose em 25% a 50%; interromper o<br>uso do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes<br>o LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes<br>o LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes<br>o LSN: interromper o uso do medicamento.<br>– Depuração de creatinina endógena abaixo de 50<br>ml/minuto: administrar 50% da dose ou suspender, em caso de<br>toxicidade.|
|Antimaláricos|Avaliação|– Maculopatia por esses medicamentos: interromper o|
|(cloroquina e<br>hidroxicloroquina)|oftalmológica inicial e<br>anual após 5 anos (ou<br>anualmente se houver<br>fatores de risco para<br>maculopatia, como<br>insuficiências renal ou<br>hepática e doses<br>eventualmente usadas<br>acima da dose máxima,<br>que não devem ser<br>usadas). Hemograma,<br>AST/TGO e ALT/ TGP: a<br>cada 1 a 3 meses.|uso do medicamento.<br>– Anemia, leucopenia ou trombocitopenia novas ou<br>mais acentuadas: reduzir a dose em 25% a 50%; interromper o<br>uso do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes<br>o LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes<br>o LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>– Elevação de TGO/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.|
|MMCDsae|||
|Baricitinibe|Avaliação de<br>tuberculose latente ou<br>ativa antes do início do<br>tratamento (anamnese,|– Tratar tuberculose latente por no mínimo 1 mês antes<br>do início do uso desses medicamentos.|  
34  
|MEDICAMENTO|AVALIAÇÃO|CONDUTA FRENTE A ALTERAÇÕES|
|---|---|---|
||exame físico, radiografia<br>de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/TGP: a cada 1 a 3<br>meses.<br>Avaliar os<br>parâmetros lipídicos<br>aproximadamente 12<br>semanas após o início da<br>terapia com baricitinibe.|– Anemia, leucopenia ou trombocitopenia novas ou<br>mais acentuadas: reduzir a dose em 25% a 50%; interromper o<br>uso do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes<br>o LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes<br>o LSN: suspender o uso do medicamento até TGO/TGP entre<br>1 e 3 vezes o LSN e reiniciar com 50% da dose.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes<br>o LSN: interromper o uso do medicamento.<br>- Os pacientes com dislipidemia devem ser tratados de<br>acordo com o PCDT de Dislipidemia para a Prevenção de<br>Eventos Cardiovasculares e Pancreatite.|
|Tofacitinibe|Avaliação de tuberculose<br>latente ou ativa antes do<br>início do tratamento<br>(anamnese, exame físico,<br>radiografia de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/TGP: a cada 1 a 3<br>meses.<br>A avaliação dos<br>parâmetros lipídicos<br>devem ser realizada<br>aproximadamente 4 a 8<br>semanas após o início da<br>terapia com baricitinibe.|– Tratar tuberculose latente por no mínimo 1 mês antes do<br>início do uso desses medicamentos.<br>– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até TGO/TGP entre 1<br>e 3 vezes o LSN e reiniciar com 50% da dose.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes o<br>LSN: interromper o uso do medicamento.<br>- Os pacientes com dislipidemia devem ser tratados de acordo<br>com o PCDT de Dislipidemia para a Prevenção de Eventos<br>Cardiovasculares e Pancreatite.|
|MMCDbio|||
|Anti-TNF|Avaliação de tuberculose<br>latente ou ativa antes do<br>início do tratamento<br>(anamnese, exame físico,<br>radiografia de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/ TGP: a cada 1 a 3<br>meses.|– Tratar tuberculose latente por no mínimo 1 mês antes do<br>início do uso desses medicamentos.<br>– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.|  
35  
|MEDICAMENTO|AVALIAÇÃO|CONDUTA FRENTE A ALTERAÇÕES|
|---|---|---|
|||– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até TGO/TGP entre 1<br>e 3 vezes o LSN e reiniciar com 50% da dose.<br>–Elevação de AST/TGO e ALT/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.|
|Abatacepte|Avaliação de tuberculose<br>latente ou ativa antes do<br>início do tratamento<br>(anamnese, exame físico,<br>radiografia de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/TGP: a cada 1 a 3<br>meses.|–Tratar tuberculose latente por no mínimo 1 mês antes do<br>início do uso desse medicamento.<br>– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes o<br>LSN: interromper o uso do medicamento.|
|Rituximabe|Avaliação de tuberculose<br>latente ou ativa antes do<br>início do tratamento<br>(anamnese, exame físico,<br>radiografia de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/TGP: a cada 1 a 3<br>meses.|– Tratar tuberculose latente por no mínimo 1 mês antes do<br>início do uso desse medicamento.<br>– Anemia, leucopenia ou trombocitopenia novas ou mais<br>acentuadas: reduzir a dose em 25% a 50%; interromper o uso<br>do medicamento se persistirem as alterações.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>– Elevação de TGO/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento|
|Tocilizumabe|Avaliação de tuberculose<br>latente ou ativa antes do<br>início do tratamento<br>(anamnese, exame físico,<br>radiografia de tórax e teste<br>tuberculínico).<br>Hemograma, AST/TGO e<br>ALT/TGP: a cada 1 a 3|– Tratar tuberculose latente por no mínimo 1 mês antes do<br>início do uso desse medicamento.<br>– Neutrófilos entre 500 e 1.000/mm3: suspender o uso do<br>medicamento até neutrófilos acima de 1.000/mm3 e reiniciar<br>com 4 mg/kg.<br>– Neutrófilos abaixo de 500/mm3: interromper o uso do<br>medicamento.|  
36  
|MEDICAMENTO|AVALIAÇÃO|CONDUTA FRENTE A ALTERAÇÕES|
|---|---|---|
||meses. Colesterol total,<br>HDL, LDL, triglicerídeos:<br>a cada 6 a 12 meses.<br>Em pacientes tratados<br>com tocilizumabe, os<br>níveis de lipídios devem<br>ser monitorados de quatro<br>a oito<br>Semanas após o início do<br>tratamento com<br>tocilizumabe.|– Plaquetas entre 50.000 e 100.000/mm3: suspender o uso do<br>medicamento até plaquetas acima de 100.000/mm3 e reiniciar<br>com 4 mg/kg.<br>– Plaquetas abaixo de 50.000/mm3: interromper o uso do<br>medicamento.<br>– Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose para 4 mg/kg.<br>– Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 4 mg/kg.<br>– Elevação de AST/TGO e ALT/TGP acima de 5 vezes o<br>LSN: interromper o uso do medicamento.<br>– Elevações de colesterol total, HDL, LDL ou triglicerídeos:<br>seguir o Protocolo Clínico e Diretrizes Terapêuticas de<br>Dislipidemia, do Ministério da Saúde.<br>– Os pacientes com dislipidemia devem ser tratados de acordo<br>com o PCDT de Dislipidemia para a Prevenção de Eventos<br>Cardiovasculares e Pancreatite.|  
Legenda: ALT/TGP, alanina aminotransferase/transaminase glutâmico-pirúvica (AST/TGO), aspartato-aminotransferase/transaminase  
glutâmicooxalacética (ALT/TGP); HDL, lipoproteína de densidade alta; LDL, lipoproteína de densidade baixa; LSN, limite superior da normalidade; MMCD, medicamentos modificadores do curso de doença.  
Fonte: Secretaria de Atenção à Saúde, Ministério da Saúde. Portaria Conjunta SAS/SCTIE/MS nº 15, de 11 de dezembro de 2017. Protocolo Clínico e Diretrizes Terapêuticas - Artrite Reumatoide.  
37

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 33/2026, identificou-se a necessidade de ajuste do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reumatoide, especificamente no Termo de Esclarecimento e Responsabilidade, com a inclusão dos medicamentos ausentes no campo destinado à indicação do tratamento da doença.  
O tema foi apresentado como informe à 136ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 19 de maio de 2026.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Reumatoide foi excluir provisoriamente a apresentação de abatacepte 250 mg pó para solução injetável devido à sua descontinuação temporária junto à Agência Nacional de Vigilância Sanitária (Anvisa), conforme petição protocolada em 15 de março de 2022. Contudo, destacase que poderá ocorrer alterações posteriores conforme regularização e continuidade no fornecimento do medicamento ao Ministério da Saúde. Além disso, destaca-se que a recomendação de uso da apresentação subcutânea de abatacepte 125 mg permanece vigente neste Protocolo. Ressalta-se que esta demanda foi oriunda de solicitação do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS).  
Considerando a versão do PCDT da Artrite Reumatoide, aprovada por meio do Relatório de Recomendação nº 654/2021, esta atualização rápida focou na exclusão da apresentação intravenosa de abatacepte 250 mg no âmbito do SUS.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A atualização rápida do Protocolo foi realizada pela Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SCTIE/MS).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A proposta de atualização do PCDT da Artrite Reumatoide foi apresentada na 123ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 11 de março de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em  Saúde (SCTIE); Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Saúde Indígena (SESAI) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).  
38

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A Consulta Pública nº 24/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reumatoide, foi realizada entre os dias 07/05/2025 e 27/05/2025. Foram recebidas cinco contribuições, que podem ser verificadas em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-da-cp-24-2025-pcdt-da-artrite-reumatoide

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Considerando a versão do PCDT da Artrite Reumatoide, aprovado por meio do Relatório de Recomendação nº 654/2021, esta atualização rápida focou na exclusão da apresentação intravenosa de abatacepte 250 mg.  
**ATUALIZAÇÃO DO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA ARTRITE REUMATOIDE APÓS INCORPORAÇÃO DO UPADACITINIBE NO SUS - versão 2021**

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O objetivo da atualização do PCDT foi a disponibilização de novo tratamento no SUS, upadacitinibe (Rinvoq®), o qual não constava no momento de elaboração da versão anterior do PCDT de AR (PORTARIA CONJUNTA Nº 14, DE 31 DE AGOSTO DE 2020), Relatório de Recomendação nº 551 - PCDT - Artrite Reumatoide – Agosto de 2020, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
A decisão da Conitec conforme Relatório nº 592 – Upadacitinibe para o tratamento de pacientes adultos com artrite reumatoide ativa moderada a grave (PORTARIA SCTIE/MS Nº 4, DE 19 DE FEVEREIRO DE 2021), relacionada à avaliação do upadacitinibe, foi: “recomendar o upadacitinibe para o tratamento de pacientes adultos com artrite reumatoide ativa moderada a grave que não responderam adequadamente ou que foram intolerantes a um ou mais medicamentos modificadores do curso da doença (DMARD)”.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Não houve atualização das questões números 1 a 17, e 22 a 25 do documento de trabalho publicado no Relatório nº 460 - PCDT da Artrite Reumatoide.  
Houve atualizações nas questões do documento acima citado, das questões números 18, 19, 20 e 21, que se referia ao uso do medicamento tofacitinibe:  
Nesse caso, foi substituída, nas questões 18 a 21, a intervenção “Tofacitinibe” por MMCDsae (medicamentos modificadores do curso da doença sintéticos alvo-específico), que compreende o tofacitinibe, baricitinibe e upadacitinibe.  
A premissa considerada foi que o upadacitinibe consiste em alternativa ao tofacitinibe e baricitinibe para o tratamento de pacientes com artrite reumatoide, assim como estabelecido no Relatório de Recomendação no 592.  
Foi utilizada a síntese de evidência realizada para upadacitinibe de acordo com o apresentado no Relatório de Recomendação da Conitec n0 592 - Upadacitinibe para o tratamento de pacientes adultos com artrite reumatoide ativa moderada a grave.  
Não foi atualizada busca complementar para tofacitinibe, haja vista que há desconhecimento de evidências recentes que possam modificar força ou direção da recomendação frente ao apresentado na versão anterior do Relatório nº 551 - PCDT - Artrite Reumatoide – agosto de 2020.  
39  
Não houve painel de recomendações para a diretriz, sendo realizada a atualização pela Coordenação de Protocolos Clínicos e Diretrizes Terapêuticas do PCDT de AR, conforme decisão da Conitec frente ao uso do upadacitinibe, sendo revisadas as recomendações internamente pelo Comitê Gestor.  
|Questão|Recomendação|
|---|---|
|QUESTÃO 18: Devemos utilizar MMCDsae + MTX ao|Recomendação 18: Sugerimos utilizar MMCDsae + MTX ao|
|invés de outro MMCDbio anti-TNF + MTX em pacientes|invés de MMCDbio antiTNF + MTX em pacientes com AR|
|com artrite reumatoide estabelecida de moderada ou alta|estabelecida de moderada ou alta atividade da doença, que|
|atividade da doença, que apresentaram falha à terapia com<br>múltiplos MMCDbio anti-TNF?|falharam à terapia aos múltiplos MMCDbio anti-TNF<br>(qualidade de evidência moderada, recomendação fraca).|
|QUESTÃO 19: Devemos utilizar MMCDsae ao invés de|Recomendação 19: Sugerimos utilizar MMCDsae em vez de|
|outro MMCDbio anti-TNF em pacientes com artrite|MMCDbio anti-TNF em pacientes com AR estabelecida de|
|reumatoide estabelecida de moderada ou alta atividade da|moderada ou alta atividade da doença, que falharam à terapia|
|doença, que apresentaram falha à terapia com múltiplos|aos múltiplos MMCDbio anti-TNF (qualidade de evidência|
|MMCDbio anti-TNF?|moderada, recomendação fraca).|
|QUESTÃO 20: Devemos utilizar MMCDsae + MTX ao|Recomendação 20: Sugerimos utilizar MMCDsae + MTX ao|
|invés de outro MMCDbio anti-TNF + MTX em pacientes|invés de MMCDbioantiTNF + MTX em pacientes com AR|
|com artrite reumatoide estabelecida de moderada ou alta<br>atividade da doença , que apresentaram falha à terapia|estabelecida de moderada ou alta atividade da doença, que<br>falharam à terapia aos MMCDbio anti-TNF e MMCDbio não|
|com MMCDbio anti-TNF e MMCDbio não anti-TNF?|anti-TNF (qualidade de evidência moderada, recomendação<br>fraca).|
|QUESTÃO 21: Devemos utilizar MMCDsae ao invés de<br>outro MMCDbio anti-TNF em pacientes com artrite|Recomendação 21: Sugerimos utilizar MMCDsae em vez de<br>MMCDbio anti-TNF em pacientes com AR estabelecida de|
|reumatoide estabelecida de moderada ou alta atividade da|moderada ou alta atividade da doença, que falharam à terapia|
|doença, que apresentaram falha à terapia com MMCDbio|aos MMCDbio anti-TNF e MMCDbio não anti-TNF|
|anti-TNF e MMCDbio não anti-TNF?|(qualidade de evidência moderada, recomendação fraca).|  
**Resumo da evidência adicional identificada (comum às questões 18 a 21 para o uso de baricitinibe):** a evidência clínica de eficácia e segurança do upadacitinibe para pacientes com AR ativa moderada a grave é baseada em um ensaio clínico randomizado duplo cego, com acompanhamento por até 48 semanas e de oito revisões sistemáticas com metanálise, conforme apresentado no Anexo 2 do Relatório de Recomendação da Conitec nº 592 - Upadacitinibe para o tratamento de pacientes adultos com artrite reumatoide ativa moderada a grave.  
No estudo clínico, tanto em comparação ao placebo + MMCDs como comparado ao adalimumabe +MMCDs, upadacitinibe trouxe melhoras significativas na incapacidade física mensurada pelo HAQ-DI, na dor, na fadiga, na rigidez matinal e na qualidade de vida mensurada pelo SF-36. Observou-se também que o upadacitinibe inibe a progressão radiográfica de forma significativa em relação ao placebo e de forma semelhante ao efeito de adalimumabe vs. placebo, apontando que é igualmente capaz de limitar o dano estrutural decorrente da progressão da AR. Nas revisões sistemáticas com metanálise, foi possível observar tendências semelhantes relacionada à remissão clínica, tendo o upadacitinibe maior taxa de remissão, mesmo que não seja significativa em relação ao tofacitinibe e baricitinibe (2 e 4 mg), comparações entre o adalimumabe e os inibidores  
40  
da JAK apresentaram resultados favoráveis para o upadacitinibe em relação a ACR20, ACR50, ACR70, em especial a ACR 50 e 70 e valores de SUCRA, quando comparado a baricitinibe. Com relação a eventos adversos, as revisões sistemáticas com metanálise não demonstram superioridade significativa quando comparados aos outros inibidores da JAK.  
**Considerações terapêuticas adicionais:** o upadacitinibe demonstrou eficácia no tratamento de AR e, assim como baricitinibe e tofacitinibe, possui tratamento de menor custo comparado aos MMCDbio disponíveis no PCDT para Artrite Reumatoide. Portanto, no upadacitinibe é recomendado para o tratamento de pacientes adultos com artrite reumatoide ativa moderada a grave que não responderam adequadamente ou que foram intolerantes a um ou mais medicamentos modificadores do curso da doença (MMCD).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A proposta de atualização do PCDT da Artrite Reumatoide foi apresentada na 89º Reunião da Subcomissão Técnica de PCDT, realizada em maio de 2021. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias emSaúde (DGITIS/SCTIE), Departamento de Ciência e Tecnologia (DECIT/SCTIE), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE), Secretaria de Vigilância em Saúde (SVS) e Secretaria de Atenção Especializada à Saúde (SAES). Após a subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 98ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
**ATUALIZAÇÃO DO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA ARTRITE REUMATOIDE APÓS INCORPORAÇÃO DO BARACITINIBE NO SUS - versão 2020**

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O objetivo da atualização do PCDT foi a disponibilização de novo tratamento no SUS, baricitinibe (Olumiant®), o qual não constava no momento de elaboração da versão anterior do PCDT de AR (PORTARIA CONJUNTA SAES-SCTIE/MS Nº 16, DE 05 DE NOVEMBRO DE 2019), Relatório de Recomendaçãonº 460 - PCDT - Artrite Reumatoide – junho de 2019, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
A decisão da Conitec conforme relatório de Relatório nº 510 - Baricitinibe para pacientes com Artrite Reumatoide ativa, moderada a grave (PORTARIA SCTIE/MS Nº 8, DE 10 DE MARÇO DE 2020), relacionada à avaliação do baricitinibe, foi: “recomendar a incorporação no SUS do baricitinibe (Olumiant®) para o tratamento de pacientes com artrite reumatoide estabelecida, moderada ou grave, com resposta insuficiente ou toxicidade (intolerância, hipersensibilidade ou outro evento adverso) de um ou mais medicamentos modificadores do curso da doença não biológicos e biológicos, condicionada a reavaliação do conjunto de medicamentos disponíveis nas mesmas etapas de tratamento com base em avaliação econômica”.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Não houve atualização das questões números 1 a 17, e 22 a 25 do documento de trabalho publicado no Relatório nº 460 - PCDT - Artrite Reumatoide.  
Houve atualizações nas questões do documento acima citado, das questões números 18, 19, 20 e 21, que se referia ao uso do medicamento tofacitinibe:  
41  
- Nesse caso, foi substituída, nas questões 18 a 21, a intervenção “tofacitinibe” por MMCDsae (medicamentos  
- modificadores do curso da doença sintéticos alvo-específico), que compreende tanto o tofacitinibe quanto o baricitinibe.  
- A premissa considerada foi que o baricitinibe consiste em alternativa ao tofacitinibe para o tratamento de pacientes com  
- artrite reumatoide, assim como estabelecido no relatório de recomendação no 510.  
- Foi utilizada a síntese de evidência realizada para baricitinibe de acordo com o apresentado no relatório de recomendação  
- da Conitec n0 510 - Baricitinibe para pacientes com Artrite Reumatoide ativa, moderada a grave.  
- Não foi atualizada busca complementar para tofacitinibe, haja vista que há desconhecimento de evidências recentes que  
- possam modificar força ou direção da recomendação frente ao apresentado na versão anterior do Relatório nº 460 - PCDT - Artrite Reumatoide – junho de 2019.  
- Não houve painel de diretriz, sendo realizada a atualização pela Coordenação de Protocolos Clínicos e Diretrizes  
- Terapêuticas do PCDT de AR, conforme decisão da Plenária frente ao uso do baricitinibe, sendo revisadas as recomendações internamente pelo comitê gestor e com a colaboração de alguns participantes do Grupo Elaborador. Houve mudança no nível de evidência, mas não na direção ou força da recomendação.  
|Questão|Recomendação|
|---|---|
|QUESTÃO 18: Devemos utilizar MMCDsae + MTX ao<br>invés de outro MMCDbio anti-TNF + MTX em<br>pacientes com artrite reumatoide estabelecida de<br>moderada ou alta que apresentaram falha aos múltiplos|Recomendação 18: Sugerimos utilizar MMCDsae + MTX ao<br>invés de MMCDbio antiTNF + MTX em pacientes com AR<br>estabelecida de moderada ou alta atividade da doença, que<br>falharam à terapia aos múltiplos MMCDbio anti-TNF (qualidade|
|MMCDbio anti-TNF?|de evidência moderada, recomendação fraca).|
|QUESTÃO 19: Devemos utilizar MMCDsae ao invés|Recomendação 19: Sugerimos utilizar MMCDsae em vez de|
|de outro MMCDbio anti-TNF em pacientes com artrite<br>reumatoide estabelecida de moderada ou alta atividade e<br>que apresentaram falha aos múltiplos MMCDbio anti-<br>TNF?|MMCDbio anti-TNF em pacientes com AR estabelecida de<br>moderada ou alta atividade da doença, que falharam à terapia aos<br>múltiplos MMCDbio anti-TNF (qualidade de evidência<br>moderada, recomendação fraca).|
|QUESTÃO 20: Devemos utilizar MMCDsae + MTX ao<br>invés de  MMCDbio anti-TNF + MTX em pacientes|Recomendação 20: Sugerimos utilizar MMCDsae + MTX ao<br>invés de MMCDbioantiTNF + MTX em pacientes com AR|
|com artrite reumatoide estabelecida de moderada ou alta<br>atividade e que apresentaram falha aos MMCDbio anti-<br>TNF E MMCDbio não anti-TNF?|estabelecida de moderada ou alta atividade da doença, que<br>falharam à terapia aos MMCDbio anti-TNF e MMCDbio não<br>anti-TNF (qualidade de evidência moderada, recomendação<br>fraca).|
|QUESTÃO 21: Devemos utilizar MMCDsae ao invés<br>de outro MMCDbio anti-TNF pacientes com artrite|Recomendação 21: Sugerimos utilizar MMCDsae em vez de<br>MMCDbio anti-TNF em pacientes com AR estabelecida de|
|reumatoide estabelecida de moderada ou alta atividade e<br>que apresentaram falha aos MMCDbio anti-TNF e<br>MMCDbio não anti-TNF?|moderada ou alta atividade da doença, que falharam à terapia aos<br>MMCDbio anti-TNF e MMCDbio não anti-TNF (qualidade de<br>evidência moderada, recomendação fraca).|  
**Resumo da evidência adicional identificada (comum às questões 18 a 21 para o uso de baricitinibe):** um ensaio  
clínico randomizado avaliando 817 pacientes comparou baricitinibe ao adalimumabe em pacientes com AR estabelecida ou  
42  
grave, com falha a metotrexato, obtendo melhora não estatisticamente significativa em relação à resposta ao ACR50 (48,9% vs. 42,1%; RR 1,16; IC95% 0,99 a 1,35), e melhora estatisticamente significativa em dor (-5,1; IC 95% -1,33 a -8,87; VAS de 0 a 100) e avaliação global para o paciente  (-4,6; IC 95% -1,09 a -8,11; VAS de 0 a 100), mas de magnitude pequena e significância clínica incerta. A incidência de eventos adversos graves foi maior com a baricitinibe (7,8% vs. 3,9%; RR 2,49; IC95% 1,35 a 4,59). Em metanálise de comparação indireta, o baricitinibe performou de forma semelhante ao tofacitinibe em relação à resposta no ACR20 (OR 1,21; ICr 95% 0,75 - 2,02) e em relação à incidência de eventos adversos (OR 0,71; ICr 95% 0,30 - 1,84).  
**Considerações terapêuticas adicionais:** o baricitinibe parece ser uma alternativa válida ao tofacitinibe em pacientes com AR moderada a grave, com falha a MMCDbio. Mostrou benefício semelhante a MMCDbio em segunda linha terapêutica, contudo devido a considerações relacionadas a maior incidência de eventos adversos e maiores incertezas em relação ao efeito em longo prazo, assim como o tofacitinibe, deve ser considerado preferencialmente como terceira linha terapêutica, após falha a MMCDbio. Contudo, como consiste em medicamentos orais, podem ser considerados como segunda linha terapêutica naqueles pacientes que houver necessidade dessa forma de administração (por exemplo, dificuldades na administração e/ou armazenamento de MMCDbio).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Reumatoide (AR), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão).  
O presente documento de trabalho teve como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A reunião presencial para definição do escopo do Protocolo Clínico e Diretriz Terapêutica (PCDT) foi conduzida com a presença de membros do Grupo Elaborador. Todos os participantes preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Esse PCDT contou com a participação de Andreas Funke (Universidade Federal do Paraná, Curitiba/PR); Max Victor Carioca Freitas (Universidade Federal do Ceará, Fortaleza/CE); Sergio Kowalski (Universidade Federal do Paraná, Curitiba/PR); Karina Gatz Capobianco (Hospital Moinhos de Vento, Porto Alegre/RS); Licia Motta (Coordenadora da Comissão de Artrite Reumatoide da Sociedade Brasileira de Reumatologia, Universidade de Brasília, Brasília/DF); Tamara Mucenic (Hospital Moinhos de Vento, Porto Alegre/RS); Priscilla Torres (EncontrAR/Grupar) e do Departamento de Assistência Farmacêutica e Insumos Estratégicos  da Secretaria de Ciência, Tecnologia e Insumos Estratégico do Ministério da Saúde (DAF/SCTIE/MS). Todos os atores envolvidos na elaboração deste protocolo encontram-se descritos a seguir.  
43  
|**Nome Painelistas**|**Instituição**|
|---|---|
|Andreas Funke|Universidade Federal do Paraná, Curitiba/PR|
|Max Victor Carioca Freitas|Universidade Federal do Ceará, Fortaleza/CE|
|Sergio Kowalski|Universidade Federal do Paraná, Curitiba/PR|
|Karina Gatz Capobianco|Hospital Moinhos de Vento, Porto Alegre/RS|
|Licia Motta|Coordenadora da Comissão de Artrite Reumatoide da Sociedade Brasileira de<br>Reumatologia<br>Universidade de Brasília, Brasília/DF|
|Tamara Mucenic|Hospital Moinhos de Vento, Porto Alegre/RS|
|Priscilla Torres|EncontrAR/Grupar|
|**Nome metodologistas**|**Instituição**|
|Cinara Stein|Hospital Moinhos de Vento, Porto Alegre/RS|
|Celina Borges Migliavaca|Hospital Moinhos de Vento, Porto Alegre/RS|
|Elie Akl|American University of Beirut, Beirute/Líbano|
|Lara Kahale|American University of Beirut, Beirute/Líbano|
|Maicon Falavigna|Hospital Moinhos de Vento, Porto Alegre/RS|
|Verônica Colpani|Hospital Moinhos de Vento, Porto Alegre/RS|

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O PCDT tem como público-alvo os profissionais de saúde envolvidos no atendimento de pacientes adultos com AR, em especial, médicos reumatologistas, médicos internistas e médicos de família e de comunidade que atuem na atenção primária e no atendimento especializado ambulatorial do Sistema Único de Saúde (SUS). Os indivíduos portadores de AR, seja em forma de início recente ou estabelecida, independentemente da atividade da doença, são a população-alvo destas recomendações. Não foram feitas considerações específicas para subgrupos de interesse (por exemplo, populações especiais como: pacientes com insuficiência cardíaca, hepatite B e C, neoplasias e infecções graves), contudo, as considerações aqui contidas são aplicáveis em linhas gerais nessas populações. O presente documento não avalia intervenções não medicamentosas e vacinação.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O Hospital Moinhos de Vento, de Porto Alegre (RS), coordenou o trabalho de elaboração deste PCDT, produzido em parceria com o Departamento de Gestão e Incorporação de Tecnologias e Inovaçãoem Saúde, da Secretaria de Ciência, Tecnologia e Insumos estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O projeto foi financiado pelo Programa de Apoio ao Desenvolvimento Institucional do SUS (PROADI-SUS).  
O grupo elaborador deste PCDT foi composto por um painel de especialistas sob coordenação do DGITIS/SCTIE/MS. O painel de especialistas incluiu médicos especialistas em AR e representantes do Ministério da Saúde e dos pacientes. O grupo coordenador foi composto por metodologistas do Hospital Moinhos de Vento, com consultores da American University of Beirute que participaram da elaboração dasdiretrizes do American College of Rheumatology (ACR).  
44  
A elaboração deste PCDT seguiu o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde1 e pelas Diretrizes Metodológicas para Elaboração de Diretrizes Clínicas do Ministério da Saúde2. O PCDT foi desenvolvido com base na metodologia GRADE (Grading of Recommendations Assessment, Development and Evaluation), seguindo os passos descritos no GIN-McMaster Guideline Development Checklist)3.  
Foi usada a metodologia GRADE-ADOLOPMENT4 para adaptar as diretrizes para tratamento de AR elaborada pelo ACR5. Foram abordadas questões relacionadas ao tratamento medicamentoso de artrite reumatoide de início recente e estabelecida.  
Foram discutidas 24 questões clínicas. Os desfechos de interesse foram: atividade e progressão da doença, qualidade de vida, incapacidade funcional, efeitos adversos gastrointestinais, efeitos adversos graves, infecções graves e hepatotoxicidade. Os componentes das questões clínicas estão sumarizados no **Quadro A** .

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Adultos (> 18 anos) atendendo aos critérios de classificação da AR da ACR.  
Pacientes com AR de início recente (sintomas <6 meses) e AR estabelecida (sintomas ≥ 6 meses).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Uso dos seguintes medicamentos:  
- Medicamentos modificadores do curso da doença (MMCDs): metotrexato, hidroxicloroquina, sulfassalazina, leflunomida  
- MMCD biológicos anti-TNF: adalimumabe, certolizumabe pegol, etanercepte, golimumabe, Infliximabe.  
- MMCD biológicos não anti-TNF: rituximabe (anti-CD20), tocilizumabe (anti-IL6), abatacepte (anti-CTL4Ig).  
- MMCD sintético alvo-específico: tofacitinibe  
- Glicocorticoides: prednisona, prednisolona

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Tratamento com os medicamentos acima.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Escore da atividade de doença (DAS);  
Melhora da resposta aos critérios do Colégio Americano de Reumatologia (ACR) 20, 50 e 70;  
Questionário de avaliação de saúde (HAQ); Índice da incapacidade do questionário de avaliação em saúde (HAQ-DI); Porcentagem de pacientes com progressão radiográfica detectável (escore de Sharp); Descontinuação por efeitos adversos; Efeitos adversos graves; Infecções; Eventos adversos gastrintestinais; Hepatotoxicidade; Hipertensão; Infecções e infestações; Colesterol.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
45  
Para elaborar este PCDT, as evidências para as questões 1, 2, 3, 4, 5, 6, 9, 14, 15, 16, 17, 22 e 23 (Quadro B) foram obtidas a partir da atualização das diretrizes do ACR 20155. A atualização envolveu uma busca realizada nas bases de dados Medline, Cochrane, Embase e Epistemonikos, acrescida de filtros para desenhos de estudo primário e revisões sistemáticas (fevereiro de 2016). A atualização foi realizada em colaboração com o grupo elaborador das diretrizes de AR da região do Leste Mediterrâneo. A estratégia pode ser acessada pelo artigo de Darzi et al., 20176.  
Para as questões 7, 8, 10, 11, 12, 13, 18, 19, 20, 21 e 24 **(Quadro B),** foi realizada uma atualização das diretrizes do ACR 2015. A atualização envolveu uma busca realizada nas bases de dados Medline, Cochrane, Embase e Epistemonikos, acrescida de filtros para desenhos de estudo primário e revisões sistemáticas (novembro de 2017). A atualização foi realizada em colaboração com o grupo desenvolvedor das diretrizes de AR da região do Leste Mediterrâneo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
1. Devemos usar terapia combinada dupla com MMCDsem vez da monoterapia MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença, sem tratamento prévio com MMCDs?  
2. Devemos usar terapia combinada tripla com MMCDsem vez da monoterapia com MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença, sem tratamento prévio com MMCDs?  
3. Devemos adicionar glicocorticoides em doses baixas por longos períodos aosMMCDsem vez de sem glicocorticoides em pacientes com AR recente de moderada ou alta atividade da doença?  
4. Devemos usar MMCDbioanti-TNF + metotrexato (MTX) em vez da terapia combinada tripla com MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?  
5. Devemos usar MMCDbio não anti-TNF + MTX em vez dos MMCDbioanti-TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?  
6. Devemos usar MMCDbio não anti-TNFem vez dos MMCDbioanti-TNF em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?  
7. Devemos usar tofacitinibe oral + MTX em vez dos MMCDbioanti-TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?  
8. Devemos usar tofacitinibe oral em vez dos MMCDbioanti-TNF para pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?  
9. Devemos usar MMCDbioanti-TNF + MTX em vez de terapia tripla com MMCDs em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam aos MMCDs?  
10. Devemos usar MMCDbioanti-TNF + MTX em vez de MMCDbio não anti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs? 11. Devemos usar MMCDbioanti-TNF em vez de MMCDbio não anti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs? 12. Devemos usar MMCDbioanti-TNF + MTX em vez de tofacitinibe + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs? 13. Devemos usar MMCD bioanti-TNF em vez de tofacitinibe em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs?  
46  
14. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-TNF? 15. Devemos usar MMCDbio não anti-TNFem vez de outro MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-TNF?  
16. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbioantiTNF?  
17. Devemos usar MMCDbio não anti-TNF em vez de outro MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbioanti-TNF?  
18. Devemos usar tofacitinibe + MTX em vez de outro MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbioanti-TNF?  
19. Devemos usar tofacitinibe em vez de outro MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbioanti-TNF?  
20. Devemos usar tofacitinibe + MTX em vez de outro MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-TNF e MMCDbio não anti-TNF?  
21. Devemos usar tofacitinibe em vez de outro MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-TNF e MMCDbio não anti-TNF?  
22. Devemos adicionar glicocorticoides em altas doses por curto prazo aos MMCDcs em pacientes com artrite  
reumatoide estabelecida de moderada ou alta atividade da doença em surto agudo da doença?  
23. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos MMCDcs em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença?  
24. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença?  
Em 29 de janeiro de 2019, realizamos uma busca em sumários clínicos estruturados, baseados em evidência, com a finalidade de identificar referências novas e relevantes publicadas após a realização da busca ou informações que pudessem modificar as recomendações. Realizaram-se buscas no Uptodate, BMJ Best Practice e Dynamed. Os seguintes tópicos foram revisados, com revisão do texto e da lista das referências bibliográficas:  
- Uptodate – “Initial treatment of rheumatoid arthritis in adults” (tópico com a busca atualizada em dezembro de 2018)  
- Uptodate – “General principles of management of rheumatoid arthritis in adults” (tópico com a busca atualizada em  
- dezembro de 2018)  
- Dynamed– “Rheumatoid arthritis” (RA) (tópico com a busca atualizada em novembro de 2018)  
- BMJ Best Practice– “Rheumatoid arthritis” (tópico com a busca atualizada dezembro de 2018)  
Os tópicos avaliados eram relativamente recentes, datando de novembro a dezembro de 2018. Apesar de não poder assegurar que tenha sido feita uma busca sistemática pelas informações, o uso de três sumários eletrônicos distintos de alta qualidade nos sugere que as informações relevantes provavelmente teriam sido captadas por ao menos um deles. Não foram identificadas informações ou referências relevantes que pudessem vir a modificar a informação e as conclusões contidas neste PCDT.  
47  
Além da busca por sumários clínicos estruturados descrita acima, foi realizada uma busca sistemática na base de dados PubMed usando termos como “Arthritis, Rheumatoid” e “randomized controlled trial”. A estratégia de busca completa é apresentada na **Tabela A.** Os critérios de inclusão que envolvem nossa questão PICO foram os mesmos apresentados no **Quadro A** . A data da busca foi limitada a janeiro de 2017 até março de 2019. Os estudos que não atenderam aos critérios de acordo com os títulos ou resumos foram excluídos.  
A seleção dos estudos foi conduzida em duas etapas: primeiramente, os resultados da busca foram avaliados por meio de títulos e resumos, e os artigos potencialmente elegíveis foram então lidos na íntegra. A extração dos dados foi feita de maneira narrativa, e os resultados serão descritos abaixo. A seleção dos estudos e a extração dos dados foi realizada por um pesquisador (CS).  
**A Figura A** apresenta o fluxo de seleção dos estudos. Das 1.061 referências encontradas, 16 foram selecionadas para avaliação dos textos completo, e 5 artigos foram incluídos na revisão.  
48

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
||1.045 referências excluídas<br>1.061 referências encontradas em<br>bases<br>de<br>dados<br>(PubMed)<br>e<br>revisadas por título e resumo|
|---|---|
|**abela A - Estratégia de busca**|16 artigos avaliados por texto<br>completo<br>5 artigos incluídos na revisão<br>11 referências excluídas<br>5 estudos com outro método de<br>intervenção<br>4<br>estudos<br>com<br>outro<br>delineamento<br>2 por desfechos|
|Identificador|Estratégia|
|PubMed||
|#1 AR|“Arthritis, Rheumatoid”[Mesh] OR “Arthritis, Rheumatoid” OR (rheumatoid AND<br>arthrit*)|
|#2 Tofacitinibe|“tofacitinib” [Supplementary Concept] OR “tofacitinib” OR “tasocitinib” OR<br>“cp690550” OR “cp 690550” OR “cp 690 550”|
|#3 CertolizumabePegol|“Certolizumab Pegol”[Mesh] OR “Certolizumab Pegol” OR “Cimzia” OR “CDP870”<br>OR “CDP 870”|
|#4 Etanercepte|“Etanercept”[Mesh] OR “Etanercept” OR “TNFR-Fc Fusion Protein” OR OR “Fusion<br>Protein, TNFR-Fc” OR “TNFR Fc Fusion Protein” OR “TNR 001” OR “TNT Receptor<br>Fusion Protein” OR “TNTR-Fc” OR “TNR-001” OR “TNR001” OR “TNF Receptor<br>Type II-IgG Fusion Protein” OR “TNF Receptor Type II IgG Fusion Protein” OR<br>“Erelzi” OR “Recombinant Human Dimeric TNF Receptor Type II-IgG Fusion Protein”<br>OR “Recombinant Human Dimeric TNF Receptor Type II IgG Fusion Protein” OR<br>“Enbrel”|
|#5 Golimumabe|“golimumab” [Supplementary Concept] OR “golimumab” OR “Simponi”|
|#6 Infliximabe|“Infliximab”[Mesh] OR “Infliximab” OR “Monoclonal Antibody cA2” OR “cA2,<br>Monoclonal Antibody” OR “Mab cA2” OR “Infliximab-abda” OR “Renflexis” OR<br>“Infliximab-dyyb” OR “Inflectra” OR “Remicade”|
|#7 Abatacepte|“Abatacept”[Mesh] OR “Abatacept” OR “LEA29Y” OR “BMS224818” OR “BMS-<br>224818” OR “BMS 224818” OR “Belatacept” OR “Orencia” OR “BMS 188667” OR|
||“BMS-188667” OR “BMS188667” OR “CTLA-4-Ig” OR “Cytotoxic T Lymphocyte-|

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
49  
|Identificador|Estratégia|
|---|---|
||Associated Antigen 4-Immunoglobulin” OR “Cytotoxic T Lymphocyte Associated<br>Antigen 4 Immunoglobulin” OR “CTLA4-Ig” OR “CTLA4-Ig Immunoconjugate” OR<br>“CTLA4 Ig Immunoconjugate” OR “Immunoconjugate, CTLA4-Ig” OR “CTLA4-Fc”<br>OR “Nulojix”|
|#8 Rituximabe|“Rituximab”[Mesh] OR “Rituximab” OR “CD20 Antibody, Rituximab” OR “Rituximab<br>CD20 Antibody” OR “Mabthera” OR “IDEC-C2B8 Antibody” OR “IDEC C2B8<br>Antibody” OR “IDEC-C2B8” OR “IDEC C2B8” OR “GP2013” OR “Rituxan”|
|#9 Tocilizumabe|“tocilizumab” [Supplementary Concept] OR “tocilizumab” OR “atlizumab” OR<br>“monoclonal antibody, MRA” OR “Actemra”|
|#10 Hydroxychloroquine|“Hydroxychloroquine” [mesh] OR “Hydroxychloroquine” OR “Oxychlorochin” OR<br>“Oxychloroquine” OR “Hydroxychlorochin” OR “Plaquenil” OR “Hydroxychloroquine<br>Sulfate” OR “Hydroxychloroquine Sulfate (1:1) Salt”|
|#11 Methotrexate|“Methotrexate” [mesh] OR “Methotrexate” OR “Amethopterin” OR “Methotrexate, (D)-<br>Isomer” OR “Methotrexate, (DL)-Isomer” OR “Mexate” OR “Methotrexate Sodium” OR<br>“Sodium, Methotrexate” OR “Methotrexate, Sodium Salt” OR “Methotrexate, Disodium<br>Salt” OR “Methotrexate Hydrate” OR “Hydrate, Methotrexate” OR “Methotrexate,<br>Dicesium Salt” OR “Dicesium Salt Methotrexate”|
|#12 Sulfasalazine|“Sulfasalazine” [mesh] OR “Sulfasalazine” OR “Salicylazosulfapyridine” OR<br>“Sulphasalazine” OR “Salazosulfapyridine” OR “Pyralin EN” OR “Azulfadine” OR<br>“Azulfidine EM” OR “Azulfidine” OR “Asulfidine” OR “Colo-Pleon” OR “Colo Pleon”<br>OR “Pleon” OR “Ulcol” OR “Sulfasalazinmedac” OR “Sulfasalazin-Heyl” OR<br>“SulfasalazinHeyl” OR “Sulfasalazine FNA” OR “Ucine” OR “Salazopyrin” OR “ratio-<br>Sulfasalazine” OR “ratio Sulfasalazine”|
|#13 Leflunomide|“Leflunomide” [mesh] OR “Leflunomide” OR “N-(4-Trifluoromethyphenyl)-5-<br>methylisoxazole-4-carboxamide” OR “HWA 486” OR “HWA-486” OR “HWA486” OR<br>“SU101” OR “Arava”|
|#14 Adalimumab|“Adalimumab” [mesh] OR “Adalimumab” OR “Humira” OR “Adalimumab-adbm” OR<br>“Amjevita” OR “Adalimumab-atto” OR “Cyltezo” OR “D2E7 Antibody” OR “Antibody,<br>D2E7”|
|#15 Chloroquine|“Chloroquine” [mesh] OR “Chloroquine” OR “Chlorochin” OR “Chingamin” OR<br>“Khingamin” OR “Nivaquine” OR “Chloroquine Sulfate” OR “Sulfate, Chloroquine”<br>OR “Chloroquine Sulphate” OR “Sulphate, Chloroquine” OR “Aralen” OR “Arequin”<br>OR “Arechine”|
|#16 Intervenções|#2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11 OR #12 OR #13<br>OR #14 OR #15|
|#17 ECR|(randomized controlled trial [pt] OR controlled clinical trial [pt] OR randomized<br>controlled trials [mh] OR random allocation [mh] OR double-blind method [mh] OR<br>single-blind method [mh] OR clinical trial [pt] OR clinical trials [mh] OR (“clinical|  
50  
|Identificador|Estratégia|
|---|---|
||trial”[tw]) OR ((singl*[tw] OR doubl*[tw] OR trebl*[tw] OR tripl*[tw]) AND|
||(mask*[tw] OR blind*[tw])) OR (“latin square”[tw]) OR placebos [mh] OR|
||placebo*[tw] OR random*[tw] OR research design [mh: noexp] OR comparative study|
||[mh] OR evaluation studies [mh] OR follow-up studies [mh] OR prospective studies|
||[mh] ORcrossover studies [mh] OR control*[tw] OR prospectiv*[tw] OR|
||volunteer*[tw]) NOT (animal [mh] NOT human [mh])|
|#18|#1 AND #16 AND #17|
|#19|#19, Filtro para data de publicação a partir de 01/01/2017|  
A descrição dos estudos incluídos na busca sistemática encontra-se a seguir.  
**Atsumi, 2017: Clinical benefit of 1-year certolizumab pegol (CZP) add-on therapy to methotrexate treatment in patients with early rheumatoid arthritis was observed following CZP discontinuation: 2-year results of the C-OPERA study, a phase IIIrandomised trial**  
Ensaio clínico randomizado, multicêntrico, duplo-cego, controlado por placebo, que avaliou a eficácia e segurança do uso da certolizumabepegol associado a MTX em pacientes com AR de início recente sem tratamento prévio com MTX. Os desfechos avaliados foram escore de Sharp modificado, SDAI, DAS-28, remissão booliana e eventos adversos em 104 semanas de tratamento.  
Foram incluídos 316 pacientes adultos (> 18 anos), de ambos os sexos, com AR de início recente, sendo que 159 pacientes receberam certolizumabepegol (subcutâneo, 400 mg nas semanas 0, 2 e 4; após, 200 mg a cada 2 semanas) associado a MTX (8 mg por semana) e 157 pacientes placebo e MTX por 52 semanas. Após esse período, os pacientes receberam apenasMTX por mais 52 semanas. Dos 316 pacientes que foram randomizados, 179 entraram no período pós-tratamento (tratamento apenas com MTX), e 131 pacientes completaram o estudo. As características dos pacientes eram similares entre os grupos.  
O escore de Sharp modificado até a 52 semana em relação ao basal foi menor no grupo certolizumabe em comparação ao grupo placebo (0,36 ± 2,70 vs. 1,58 ± 4,86, p < 0,001. Durante o período pós-tratamento até a semana 104, as alterações da linha de base (média ± DP) para o escore de Sharp modificado se mantiveram menor no grupo certolizumabe (0,66 ± 5,38 vs. 3,01 ± 9,66 (p = 0,001). As taxas de remissão, no final da semana 52, foram significativamente maiores no grupo certolizumabe em comparação ao grupo placebo. A Figura B apresenta as taxas de remissão nas semanas 52 e 104.  
51  
**Figura B - Principais desfechos de eficácia do estudo de Atsumi (2017).**  
<!-- Start of picture text -->
A > PBO+MTX—+MIX(n=157) —@- CZP+MTX-+MTX (n=159)<br>PBO or CZP +MTX MTX alone<br>100 <_<»,(DB Period) (PT Period)<br>=2s 80 p<0.001iI i;<br>2° p=0.026i<br>40 i |<br>220 i H ;<br>5 i i<br>alt H SDAI remission<br>0 10 20 30 40 50 60 70 80 90 100<br>B Week :<br>100 i i<br>2% j i<br>ES p=0.002 H<br>260 i aad<br>r i<br>B40<br>Bn§ }<br>2Pi Boolean remission<br>0 10 20 30 40 50 60 70 80 90 100<br>c Week i<br>100 i H<br>280 point i<br>i fj i<br>260 T rom<br>-<br>°F HHHH |<br>a ae Ht<br>20 i j<br>2<br>P| __DASZ8(ESR) remission<br>0 10 20 30 40 50 60 70 8 90 100<br>Week<br><!-- End of picture text -->  
Adaptado de Atsumi, 2017.  
A incidência de eventos adversos gerais foi similar entre grupos. A Tabela B apresenta um sumário dos eventos adversos entre os grupos nas semanas 52 e 104.  
52  
**Tabela B - Sumários dos eventos adversos nos grupos intervenção e controle. (Adaptado de Atsumi, 2017.)**  
<!-- Start of picture text -->
Table 2. Summary of treatment-emergent adverse events (TEAE)<br>(CZP+MTX+MTX PBO+MTX—MTX<br>Week 0-52 Week 52-104 Week 0-104 Week 0-52 Week 52-104 Week 0-104<br>(CZPAMTX MIX (CZP+MTX—=MTX PBO+MTX MIX PBO+MTX—MTX<br>n=159 n=108 n=159 n=157 n=71 n=157<br>Patient years 1362 877 2236 1160 63.4 1794<br>‘AE summmaryt 1 (%) n (%) 1 (%) 11 (%) n (6) 1 (%)<br>‘Any AEs 153 (962) 85 (78.7) 154 (96.9) 148 (943) 57 (803) 150 (955)<br>Event rate” 542.0 286.1 442.4 548.2 250.7 4443<br>Serious AES 13 6.2) 4a7 17(10.7) 146.9 46.6) 18 (115)<br>Event rate” 11.0 68 94 129 63 106<br>Deaths 0 0 0 0 0 o<br>Afs of interest 1 (%) 1 (%) n(%) n (%) 1 (%) n(%)<br>Infections and infestations 97 61.9) 45 (41.7) 114 (71.7) 87 (55.4) 30 (423) 93 (592)<br>Serious infections 5.1) 0 5@.1) 7(45) 1(14) 865.1)<br>Pneumonia 74.4) 19) 86.0 865.1) 228) 10 (64)<br>Tuberculosis o 0 o o 0 o<br>Interstitial lung disease 56.1) 2 (1.9) 7(4.4 1 (0.6) 0 10.6<br>Malignancies 1 0.6 1 (0.9)¢ 201.3 0 0 o<br>Hepatic disorders§ 68 (12.8) 1241.) 7 (459) 69 (439) 9 (12.7) 73 (465)<br>“Number of events per 100 patient-years.<br>‘tnenumber of subjects reporting at least one TEAE within System Organ ClassPreferred Term.<br>+$Cervix carcinoma.<br>Sincluding following preferred terms: alanine aminotransferase increased, aspartate aminotransferase increased, y-glutamyltransferase increased, hepatic function abnormal, hepatic<br>enzyme increased, hepatic steatosis, hyperbiirubinaemia, liver disorder, liver function test abnormal; MedDRA V.14.1<br>AE, adverse events; CZP, crtolizumab pegol; MTX, methotrexate; PBO, placebo.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os resultados do primeiro ano do estudo demonstraram o benefício clínico da adição de certolizumabe pegol associado ao MTX em relação às taxas de remissão, e esse efeito permaneceu após a interrupção da terapia com certolizumabe pegol, quando a dose de MTX permaneceu otimizada.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Ensaio clínico randomizado, multicêntrico, duplo-cego, controlado por placebo, que avaliou a eficácia e segurança do uso da certolizumabepegol associado a MTX em pacientes com AR ativa com resposta inadequada ao MTX. O desfecho primário foi a resposta do ACR 20 no final da semana 24.  
Os pacientes incluídos foram randomizados (3:1) para certolizumabe pegol (subcutâneo, 400 mg nas semanas 0, 2 e 4; após, 200 mg a cada duas semanas) e MTX ou placebo e MTX.  
Foram incluídos 430 pacientes, 316 no grupo certolizumabe e 114 no grupo placebo; 186 pacientes (58,9%) no grupo certolizumabe e 38 (33,3%) pacientes no grupo placebo completaram as 24 semanas de seguimento. As características dos pacientes eram similares entre os grupos.  
Ao fim do estudo, 54,8% dos pacientes do grupo certolizumabe e 23,9% do grupo placebo atingiram remissão com o escore ACR 20. Os pacientes com o grupo certolizumabe também obtiveram melhora nas respostas dos desfechos HAQ-DI, ACR 50/70 e DAS-28 **(Figura C).** Efeitos adversos graves foram relatados por 6,3% dos pacientes do grupo certolizumabe e por 2,7% dos pacientes do grupo placebo.  
53  
**Figura C - Principais desfechos de eficácia do estudo de Bi 2019**  
<!-- Start of picture text -->
Aro, 30m B oo<br>Sere<br>80 95% 238, 638 pcooo. Peet<br>¢ sae REDE IS gaa<br>so be 725 =-03 0.17<br>A = 365 sewn 222.79 B08<br>é3 04 3 Pt167 “05,<br>* fs 27 i 06 0.53<br>° 307 pa<br>500<br>© ‘ACR20 ‘ACRSO ACR7O 08 (Sinan ewe 035<br>z5 80<br>5°<br>§ 0 115<br>3 2» 0.0<br>o<br><!-- End of picture text -->  
Fonte:Adaptado de Bi, 2019.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O tratamento com certolizumabe pegol em combinação ao MTX mostrou um perfil de segurança aceitável e redução dos sinais e sintomas dos pacientes com AR ativa com resposta inadequada ao MTX.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Ensaio clínico randomizado, multicêntrico, aberto, de não inferioridade, que avaliou a eficácia e segurança do uso do MMCDbioanti-TNF alternativo (etanercepte) ou abatacepte em pacientes com AR que tiveram resposta inadequada ao tratamento inicial com MMCDbio associado ao MTX quando comparado ao rituximabe. O desfecho primário foi a resposta do DAS-28 no final da semana 24.  
Os pacientes incluídos foram randomizados (1:1:1) para MMCDbioanti-TNF alternativo e MTX, abatacepte e MTX ou rituximabe e MTX.  
Foram incluídos 149 pacientes, dos quais 122 foram randomizados para tratamento (MMCDbioanti-TNF alternativo, n = 41; abatacepte, n = 41; rituximabe, n = 40). As características dos pacientes eram similares entre os grupos.  
Comparando MMCDbioanti-TNF alternativo com rituximabe, a diferença na redução média no DAS-28 em 24 semanas após a randomização foi de 0,3 (IC95% -0,45 a 1,05). Os resultados correspondentes para a comparação de abatacepte e rituximabe foram de 0,04 (IC95% -0,72 a 0,79). Para o desfecho HAQ-DI, não foram encontradas diferenças entre os grupos.  
Em relação aos efeitos adversos graves, dez eventos foram relatados em nove pacientes, dos quais três eventos em três pacientes foram considerados relacionados aos medicamentos em estudo. Houve duas mortes, ambas após o desenvolvimento de eventos adversos com os medicamentos rituximabe e abatacepte. Dez pacientes apresentaram toxicidade, resultando uma cessação permanente do tratamento (quatro pacientes usando MMCDbioanti-TNF, dois usando abatacepte e quatro usando rituximabe).  
54

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
O uso do MMCDbio anti-TNF alternativo (etanercepte) ou abatacepte em pacientes com AR que tiveram resposta inadequada ao tratamento inicial com MMCDbio associado ao MTX quando comparado ao tratamento com rituximabe não mostrou diferença. A questão clínica de se o MMCDbio anti-TNF alternativo (etanercepte) ou abatacepte e rituximabe é ou não comparável em relação à eficácia e à segurança permanece não definida.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Ensaio clínico randomizado, duplo-cego, controlado por placebo, que avaliou a eficácia e segurança do uso do tocilizumabe em pacientes com AR de início recente. Os desfechos avaliados foram DAS-28, ACR 20/50/70, escore de Sharp modificado, CDAI, remissão booliana e eventos adversos em 52 semanas de tratamento.  
Os pacientes incluídos foram randomizados (1:1:1:1) para tocilizumabe (8 mg/kg) e MTX, tocilizumabe (4 mg/kg) e MTX, tocilizumabe (8 mg/kg) e placebo e MTX e placebo. Foram incluídos 1.162 pacientes, 291 no grupo tocilizumabe (8 mg/kg) e MTX, 290 no grupo tocilizumabe (4 mg/kg) e MTX, 292 no grupo tocilizumabe (8 mg/kg) e placebo e, 289 no grupo MTX e placebo. As características clínicas e demográficas estavam equilibradas entre os grupos na linha de base.  
Na semana 52, 49,3% (143/290) dos pacientes do grupo tocilizumabe (8 mg/kg) e MTX atingiram a remissão por meio do escore DAS-28-ESR e 57,9% (168/290) por meio do escore DAS-28-ESR LDA. As respostas para os desfechos ACR 20, ACR 50 e ACR 70 foram semelhantes para os grupos tocilizumabe (8 mg/kg) e MTX e tocilizumabe (8 mg/kg) e placebo. Proporções similares de pacientes designados para os tratamentos iniciais alcançaram remissão de acordo com os critérios CDAI e remissão booliana na semana 52 **(Figura D).** A inibição da progressão radiográfica foi mantida por ambos grupos tocilizumabe (8 mg/kg) e MTX e tocilizumabe (8 mg/kg) e placebo.  
Oitenta e três eventos adversos graves foram relatados no grupo tocilizumabe (8 mg/kg) e MTX em comparação a 67, 58 e 31 para os grupos tocilizumabe (8 mg/kg) e placebo, tocilizumabe (4 mg/kg) e MTX e placebo, respectivamente. Os eventos adversos mais comuns foram infecções. Ocorreram 14 mortes durante o estudo.  
55  
**Figura D - Principais desfechos de eficácia do estudo de Burmester 2017.**  
<!-- Start of picture text -->
A ‘'=Placebo + MTX (n=287) 4 mglkg TCZ + MTX (n=288)<br>20 18 mgkkg TOZ + MTX (n=290) = 8 mglkg TCZ + placebo (n=292)<br>‘sPlacebo + MTX post-escape (n=142) m4 mglkg TCZ + MTX post-escape (n=85)<br>70 wae<br>* 60 bald 585<br>£505 “93 ao, S14 aro? 31<br>Boj os 32<br>oss b05 300]<br>so x ma<br>20 | 1 23<br>‘0 | I |<br>Week 52 Week 104 Week 52 Week 104<br>‘DAS28-ESR remission (DAS2B <2.6) DAS28-ESR LDA (DAS28 $3.2)<br>B Placebo + MTX (n=267)<br>14 mg/kg TCZ + MTX (n=268)<br>cy)701 sef"heu a Placebo19418=B mg/kg mghkg mg/kg  TCZTCZTCZ+ MTX + ++ MTXplacebo (n=292)postescapeMTX (0=290) post-escape(n=142) (n=05)<br>1<br>60458. sasit2 ore<br>£50 sor re “8<br>£0 eo | a ned wiles ea<br>& asd so an<br>bd 6 2<br>a) ss oa ||<br>10 2<br>° Week 52 Week 104 |  Week52 Week 104 | © WeekS2 Week 104<br>‘ACR20 ACRSO ACRTO<br>c Placebo + MTX (n=287)<br>0 148 mghkgmgikg TCZ TCZ ++ MTX MTX (7=290)(n=288)<br>* 18 mghkg TCZ+ placebo (n=292)<br>60<br>50<br>¥<br>540<br>j 30 wa sr928 aa<br>2538.0 onl oso 312<br>27 . con 24 n3yy2o 240)<br>vom, 70'S? a7 1<br>to 122) 104<br>° Week 52 Week 104 | Wook 52 Week 104 | Week52 Wook 104<br><!-- End of picture text -->  
Fonte: adaptado de Burmester, 2017.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Em ambos os grupos tocilizumabe (8 mg/kg), houve melhora nos desfechos remissão do DAS-28-ESR e LDA, respostas ACR 20/50/70 e progressão radiográfica. As melhores respostas foram consistentemente observadas no grupo tocilizumabe (8 mg/kg) e MTX, particularmente para os parâmetros radiográficos.  
56

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Ensaio clínico randomizado, duplo-cego, multicêntrico. Foram incluídos pacientes com artrite reumatoide ativa diagnosticada há menos de um ano e virgens de tratamento com MMCDs ou MMCDbio. Os desfechos avaliados foram DAS28, ACR 50, HAQ-DI e escore de Sharp modificado (van der Heijde) em 52 semanas de tratamento.  
Os pacientes incluídos foram randomizados (3:1) para certolizumabe pegol (subcutâneo, 400 mg nas semanas 0, 2 e 4 e, após, 200 mg a cada 2 semanas) e metotrexato (de 15 a 25 mg por semana) ou placebo e MTX.  
Foram incluídos 879 pacientes, 660 no grupo certolizumabe e 219 no grupo placebo; 500 pacientes (75,8%) no grupo certolizumabe e 143 (65,3%) pacientes no grupo placebo completaram as 52 semanas de seguimento. As características clínicas e demográficas estavam equilibradas entre os grupos na linha de base. A média de idade dos pacientes incluídos foi de 50,4 (13,6) no grupo certolizumabe e de 51,2 (13) no grupo placebo; 75,9% dos pacientes no grupo certolizumabe e 79,8% dos pacientes no grupo placebo eram do sexo feminino; o tempo médio de diagnóstico de AR era de 2,9 (4,6) no grupo certolizumabe e 2,9 (2,9) no grupo placebo.  
Ao fim do estudo, 28,9% dos pacientes no grupo certolizumabe e 15% no grupo placebo atingiram remissão (sREM– escore DAS-28 < 2,6 nas semanas 40 e 52); e 28,6% dos pacientes no grupo certolizumabe e 43,8% no grupo placebo atingiram baixa atividade da doença (sLDA– escore DAS-28 ≤ 32 nas semanas 40 e 52). Quando a remissão foi avaliada de acordo com outros critérios, também foi observada diferença significativa entre os grupos, com mais pacientes no grupo certolizumabe atingindo o desfecho. O desfecho ACR 50 foi atingido por 61,8% dos pacientes no grupo certolizumabe e por 52,6% no grupo placebo. A inibição da progressão radiográfica foi significativamente maior no grupo certolizumabe: em relação ao escore de Sharpe modificado, houve um aumento de 0,2 no grupo certolizumabe e de 1,8 no grupo placebo (p < 0,001); maior percentual de pacientes sem progressão, de acordo com o escore de Sharpe modificado (49,7% no grupo certolizumabe e 70,3% no grupo placebo, p < 0,001). Houve uma melhora da capacidade funcional, avaliada pelo HAQ-DI (certolizumabe: -1,0; placebo: -0,82; p < 0,002), com mais pacientes atingindo o que é considerado como normal no grupo certolizumabe (48,1%) do que no grupo placebo (37,5%). Os principais desfechos de efetividade são apresentados na **Figura E** .  
A incidência geral de eventos adversos e os efeitos adversos graves foram semelhantes entre os grupos (para efeitos adversos graves, 10,6% no grupo certolizumabe e 9,2% no grupo placebo). Os principais eventos adversos reportados por pacientes do grupo certolizumabe foram náusea, infecção do trato respiratório superior, infecção do trato urinário, nasofaringite, cefaleia e aumento dos níveis de alanina transferase. No grupo certolizumabe, 8,6% dos pacientes descontinuaram o tratamento, em comparação a 9,2% no grupo placebo.  
Em relação às infecções, a taxa foi maior no grupo certolizumabe (71,8/100 pacientes-ano) em comparação ao grupo placebo (52,7/100 pacientes-ano). Entretanto, para infecções graves, não houve diferenças entre os grupos (certolizumabe: 3,3/100 pacientes-ano; placebo: 3,7/100 pacientes-ano). No grupo certolizumabe, a taxa de infecções oportunistas foi de 0,2/100 pacientes-ano; no grupo placebo, nenhum caso foi reportado.  
57  
**Figura E - Principais desfechos de eficácia do estudo de Emery 2016**  
<!-- Start of picture text -->
A PBO+MTX (n=213)<br>100) CZP4MTX (n'=655) 0<br>90 4<br>25% —C1 |<br>2 804<br>5 70 \<br>5 | o596 C1 14,28 cia<br>3eae 607.0823 526<br>= 504 438<br>23<br>2%= 40 4 289 286<br>5° 304<br>=2 204 15.0<br>10 4<br>sREM sLDA ACR5O<br><!-- End of picture text -->  
<!-- Start of picture text -->
100 * PBO+MTX (n=213)<br>0 * CZP+MTX (n=655)<br>80<br>zr<br>=<br>2© 60<br>8 as 9 389<br>2 40<br>(=2 304 28 = 263 249<br>20 2<br>10<br>0<br><!-- End of picture text -->  
<!-- Start of picture text -->
25 PBO+MTX (n=163)<br>8 C2P+MTX (n=528)<br>v 297 18<br>515<br>E<br>& 10<br>“<br>02 ; 4<br>of me<br>mISS Erosion score Joint space<br><!-- End of picture text -->  
Fonte: adaptado de Emery, 2016.  
Foram reportados três óbitos durante o estudo, dois em pacientes do grupo certolizumabe e um no grupo placebo. Entre os dois pacientes do grupo certolizumabe, um deles veio a óbito devido a acidente vascular cerebral, considerado não relacionado ao tratamento; o outro óbito foi associado a infecção disseminada por Mycobacterium, considerada relacionada ao tratamento. O óbito no grupo placebo foi causado por falência respiratória e foi considerado não relacionado ao estudo.  
Conclusão  
O grupo tratado com certolizumabe pegol teve resultados melhores nos desfechos avaliados em comparação ao grupo placebo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A busca por valores e preferências dos pacientes com AR se baseou nas diretrizes do ACR5 e em sua adaptação para a região do Leste Mediterrâneo, publicada em 20176. Os desfechos considerados se basearam nas medidas de qualidade de vida e de utilidade. Adicionalmente, realizou-se uma busca não estruturada nas bases de dados Google e Medline por valores e preferências referentes à realidade brasileira, usando termos como “rheumatoid arthritis” AND “quality of life”, além de contato com os especialistas do painel.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
58  
Para a avaliação da qualidade da evidência, foi usado o sistema GRADE7. Foram desenvolvidas tabelas de evidências na plataforma GRADEpro8 para cada questão PICO, sendo considerados os domínios da avaliação risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferentes dos da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos), efeito relativo e absoluto de cada questão **(Quadro C).**  
**Quadro C - Níveis de evidências de acordo com o sistema GRADE**  
|Nível|Definição|Implicações|
|---|---|---|
|Alto|Há forte confiança de que o verdadeiro efeito|É improvável que trabalhos adicionais irão|
||esteja próximo daquele estimado.|modificar a confiança na estimativa do efeito.|
|Moderado|Há confiança moderada no efeito estimado.|Trabalhos futuros poderão modificar a confiança<br>na estimativa de efeito, podendo, inclusive,<br>modificar a estimativa.|
|Baixo|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de<br>efeito.|
|Muito baixo|A confiança na estimativa de efeito é muito<br>limitada. Há importante grau de incerteza nos<br>achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde/Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou fraca, de acordo com o sistema GRADE **(Quadro D).**  
**Quadro D - Implicação da força da recomendação para profissionais, pacientes e gestores em saúde**  
|Público alvo|Forte|Fraca (condicional)|
|---|---|---|
|Gestores|A recomendação deve ser adotada como<br>política de saúde na maioria das situações.|É necessário haver um debate substancial e o<br>envolvimento das partes interessadas.|
|Pacientes|A maioria dos indivíduos desejaria que a|Grande parte dos indivíduos desejaria que a|
||intervenção fosse indicada, e apenas um|intervenção fosse indicada; contudo, um número|
||pequeno número não aceitaria essa<br>recomendação.|considerável não aceitaria essa recomendação.|  
59  
|Profissionais da saúde|A maioria dos pacientes deve receber a|O profissional deve reconhecer que diferentes|
|---|---|---|
||intervenção recomendada.|escolhas serão apropriadas para cada paciente|
|||para definir uma decisão consistente com os<br>seus valores e preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde/Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para a elaboração das recomendações, foram levados em consideração os riscos e os benefícios das condutas propostas, o nível de evidências para os mesmos, além de custos, uso de recursos, aceitabilidade pelos profissionais e demais barreiras para implementação. A recomendação pode ser a favor ou contra a intervenção proposta e pode ser considerada forte (o grupo está bastante confiante que os benefícios superam os riscos) ou fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco).  
Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou esclarecimentos sobre elas estão documentadas ao longo do texto. A direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião presencial de elaboração das recomendações. O grupo elaborador do PCDT recebeu as tabelas GRADE de cada questão PICO. Após a apresentação das evidências (riscos e benefícios da intervenção proposta, custos e valores e preferências dos pacientes), iniciaram-se as discussões. Os domínios foram debatidos separadamente, de modo estruturado, seguindo a metodologia preconizada pelo GRADE. Buscou-se um consenso em relação às recomendações e, na impossibilidade de obtê-lo, realizou-se votação **(Quadro E).**  
**Quadro E -Consenso do grupo elaborador para as recomendações do PCDT**  
|**Questões**|**Considerações sobre a**<br>**decisão/justificativa**|
|---|---|
|1. Devemos usar terapia combinada dupla com MMCDs em vez da monoterapia|Houve consenso entre o grupo.|
|MMCDs em pacientes com AR de início recente de moderada ou alta atividade da||
|doença e sem tratamento prévio com MMCDs?||
|2. Devemos usar terapia combinada tripla com MMCDs em vez da monoterapia|Houve consenso entre o grupo.|
|com MMCDs em pacientes com AR de início recente de moderada ou alta<br>atividade da doença e sem tratamento prévio com MMCDs?||
|3. Devemos adicionar glicocorticoides em doses baixas por longos períodos a|Houve consenso entre o grupo.|
|MMCDs em vez de MMCDs sem glicocorticoides em pacientes com AR recente||
|de moderada ou alta atividade da doença?||
|4. Devemos usar MMCDbioanti-TNF + Metotrexato (MTX) em vez da terapia<br>combinada tripla com MMCDs em pacientes com AR de início recente de<br>moderada ou alta atividade da doença que falharam aos MMCDs?|Houve consenso entre o grupo.|
|5. Devemos usar MMCDbio não anti-TNF + MTX em vez dos MMCDbioanti-|Houve consenso entre o grupo.|
|TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade<br>da doença que falharam aos MMCDs?||  
60  
|**Questões**|**Considerações sobre a**<br>**decisão/justificativa**|
|---|---|
|6. Devemos usar MMCDbio não anti-TNF em vez dos MMCDbioanti-TNF em|Houve consenso entre o grupo.|
|pacientes com AR de início recente de moderada ou alta atividade da doença que<br>falharam aos MMCDs?||
|7. Devemos usar tofacitinibe oral + MTX em vez dosMMCDbioanti-TNF + MTX<br>em pacientes com AR de início recente de moderada ou alta atividade da doença<br>que falharam aos MMCDs?|Houve consenso entre o grupo.|
|8. Devemos usar tofacitinibe oral em vez dos MMCDbioanti-TNF para pacientes<br>com AR de início recente de moderada ou alta atividade da doença que falharam<br>aos MMCDs?|Houve consenso entre o grupo.|
|9. Devemos usar MMCDbioanti-TNF + MTX em vez de terapia tripla com|Houve consenso entre o grupo.|
|MMCDs em pacientes com artrite reumatoide estabelecida de moderada ou alta<br>atividade da doença que falharam aos MMCDs?||
|10. Devemos usar MMCDbioanti-TNF + MTX em vez de MMCDbio não anti-|Houve consenso entre o grupo.|
|TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta<br>atividade da doença que falharam à terapia aos MMCDs?||
|11. Devemos usar MMCDbioanti-TNF em vez de MMCDbio não anti-TNF em<br>pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da<br>doença que falharam à terapia aos MMCDs?|Houve consenso entre o grupo.|
|12. Devemos usar MMCDbioanti-TNF + MTX em vez detofacitinibe + MTX em<br>pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da|Houve consenso entre o grupo.|
|doença quefalharam à terapia aos MMCDs?||
|13. Devemos usar MMCDbioanti-TNF em vez detofacitinibe em pacientes com<br>artrite reumatoide estabelecida de moderada ou alta atividade da doença que|Houve consenso entre o grupo.|
|falharam à terapia aos MMCDs?||
|14. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro|Houve consenso entre o grupo.|
|MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de<br>moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-||
|TNF?||
|15. Devemos usar MMCDbio não anti-TNF em vez de outro MMCDbioanti-TNF<br>em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da<br>doença que falharam à terapia aos MMCDbioanti-TNF?|Houve consenso entre o grupo.|
|16. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro|Houve consenso entre o grupo.|
|MMCDbioanti-TNF + MTX em pacientes com artrite reumatoide estabelecida de<br>moderada ou alta atividade da doença que falharam à terapia aos múltiplos<br>MMCDbioanti-TNF?||  
61  
|**Questões**|**Considerações sobre a**<br>**decisão/justificativa**|
|---|---|
|17. Devemos usar MMCDbio não anti-TNF em vez de outro MMCDbioanti-TNF<br>em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da|Houve consenso entre o grupo.|
|doença que falharam à terapia aos múltiplos MMCDbioanti-TNF?||
|18. Devemos usar tofacitinibe + MTX em vez de outro MMCDbioanti-TNF +|Houve consenso entre o grupo.|
|MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta||
|atividade da doença que falharam à terapia aos múltiplos MMCDbioanti-TNF?||
|19. Devemos usar tofacitinibe em vez de outro MMCDbioanti-TNF em pacientes|Houve consenso entre o grupo.|
|com artrite reumatoide estabelecida de moderada ou alta atividade da doença que<br>falharam à terapia aos múltiplos MMCDbioanti-TNF?||
|20. Devemos usar tofacitinibe + MTX em vez de outro MMCDbioanti-TNF +|Houve consenso entre o grupo.|
|MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta<br>atividade da doença que falharam à terapia aos MMCDbioanti-TNF e MMCDbio<br>não anti-TNF?||
|21. Devemos usar tofacitinibe em vez de outro MMCDbioanti-TNF em pacientes|Houve consenso entre o grupo.|
|com artrite reumatoide estabelecida de moderada ou alta atividade da doença que<br>falharam à terapia aos MMCDbioanti-TNF e MMCDbio não anti-TNF?||
|22. Devemos adicionar glicocorticoides em altas doses por curto prazo aos|Houve consenso entre o grupo.|
|MMCDcs em pacientes com artrite reumatoide estabelecida de moderada ou alta||
|atividade da doença em surto agudo da doença?||
|23. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos|Houve consenso entre o grupo.|
|MMCDcs em pacientes com artrite reumatoide estabelecida de moderada ou alta<br>atividade da doença?||
|24. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos|Houve consenso entre o grupo.|
|MMCDbioanti-TNF em pacientes com artrite reumatoide estabelecida de moderada<br>ou alta atividade da doença?||

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
A declaração de conflitos de interesse foi baseada nos princípios do G-I-N e The Instituteof Medicine (IOM). Todos os membros do grupo declararam os seus potenciais conflitos de interesse usando o questionário “Declaração de conflito de interesses -diretrizes clínico-assistenciais” (Tabela C). Participantes que declarassem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da discussão das questões específicas, sem impedimento de participar da discussão das demais questões, incluindo votações, caso não seja obtido consenso. Os principais interesses declarados pelos participantes do PCDT se referem à Questão 1 (vínculo empregatício com instituições que apresentam interesse no escopo), Questão 2 (honorários pagos nos últimos 3 anos) e Questão 3 (benefícios não monetários obtidos de entidades com interesse no escopo) do formulário usado.  
62  
**Tabela C - Questionário sobre Conflito de Interesse Diretrizes Clínico-assistenciais**  
|**QUESTÃO**|**RE**|**SPOSTA**|
|---|---|---|
|1. Nos últimos 3 anos, você ou pessoas próximas a você* tiveram vínculo empregatício ou|||
|participação no conselho de administração de alguma entidade, instituição comercial ou outra|() SIM|() NÃO|
|organização que tivesse interesse no escopo deste PCDT?|||
|2. Nos últimos 3 anos, você ou pessoas próximas a você* tiveram alguma relação com alguma<br>entidade, instituição comercial ou outra organização que tivesse interesse no escopo deste PCDT<br>(como honorários por palestras, atividades de ensino, consultorias, pareceres técnicos ou perícias|() SIM|() NÃO|
|judiciais), equivalente a um valor de R$ 1.000,00 ou mais (por atividade ou por entidade, instituição<br>ou organização)?|||
|3. Nos últimos 3 anos, você ou pessoas próximas a você* receberam de uma entidade, instituição ou<br>outro órgão com interesse no escopo deste PCDT benefícios financeiros não monetários (como<br>pagamento de inscrições em congressos, despesas de viagem, presentes, participação em eventos<br>recreativos, tais como shows, jantares, etc.), equivalente a um valor de R$ 1.000,00 ou mais?|() SIM|() NÃO|
|4. Atualmente, você, pessoas próximas a você* ou a instituição ao qual você está ligado possuem<br>propriedade intelectual ou interesse financeiro conflitante que possa ser afetado pelos resultados|() SIM|() NÃO|
|deste PCDT, tais como ações, royalties ou patente, independentemente do valor?|||
|5. Nos últimos 3 anos, você, pessoas próximas a você* ou a instituição ao qual você está ligado<br>receberam algum apoio de uma entidade, instituição ou outro órgão com interesse no escopo deste|||
|PCDT (como financiamento para fomento de projetos de pesquisa, de extensão ou de ensino,<br>equipamentos e insumos, tais como reagentes, livros, equipamentos específicos, apoio para|() SIM|() NÃO|
|publicação ou editoração de artigo, tradução, pagamento de taxas de publicação, etc.) com valor<br>superior a R$ 5.000,00?|||
|6. A sua expertise ou convicção acadêmica/profissional em algum aspecto relacionado ao escopo do|||
|PCDT poderia comprometer a sua imparcialidade de julgamento (como ter publicações sobre um<br>determinado assunto que o tornaria mais propenso a dar recomendações favoráveis a determinada|() SIM|() NÃO|
|intervenção)?|||
|7. Você possui vínculo com alguém ou com alguma instituição cujos interesses acadêmicos possam<br>ser afetados pelas recomendações resultantes deste PCDT?|() SIM|() NÃO|
|8. Você participa, direta ou indiretamente, de algum grupo, como organizações governamentais ou|||
|não governamentais, sociedades de profissionais ou especialistas, associação de pacientes, cujos|() SIM|() NÃO|
|interesses possam ser afetados pelas recomendações resultantes deste PCDT?|||
|9. Você considera que as recomendações decorrentes deste PCDT podem gerar benefícios|||
|acadêmicos futuros a você, a pessoas próximas a você* ou à instituição a qual você está ligado<br>(como aumento de publicações ou citações em trabalhos científicos, participação em congresso,|() SIM|() NÃO|
|etc.)?|||
|10.1. Você possui convicção religiosa, política, étnica ou outras crenças que podem comprometer sua<br>capacidade de julgamento neste PCDT?|<br>() SIM|() NÃO|  
63  
|**QUESTÃO**|**RE**|**SPOSTA**|
|---|---|---|
|10.2. Caso sim para a Questão 10.1, você concorda em declarar ao grupo organizador do PCDT?|() SIM|() NÃO|
|10.3. Caso sim para a Questão 10.2, você concorda que essa informação seja tornada pública?|() SIM|() NÃO|
|11. Há algum outro fato ou situação que possa interferir sua capacidade imparcial de julgamento<br>neste PCDT?|() SIM|() NÃO|  
* Pessoa com a qual tenha laços familiares ou outra relação próxima.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Assim como nas diretrizes originais do ACR 2015, este PCDT enfocou os seguintes princípios:  
1. As recomendações são direcionadas às situações clínicas comuns ao paciente com AR de início recente e estabelecida,  
e não a casos especiais.  
2. Os custos para a aquisição de medicamentos foram levados em consideração na elaboração deste PCDT, porém não foi realizada uma análise de custo-efetividade.  
3. A avaliação da atividade da doença usando instrumentos validados e internacionalmente empregados, como DAS-28,  
SDAI e CDAI, deve ser realizada preferencialmente em todas as consultas com pacientes com artrite reumatoide.  
4. A avaliação da capacidade funcional do paciente usando um questionário padronizado e validado, como Health Assessment Questionnaire (HAQ) e Health Assessment Questionnaire II, deve ser realizada rotineiramente para pacientes com AR, pelo menos uma vez por ano, e com maior frequência se a doença estiver ativa.  
5. Em pacientes com AR de baixa atividade ou remissão clínica, a substituição de uma terapia por outra deve ser  
considerada a critério do médico assistente em consulta com o paciente.  
6. Em recomendações fracas/condicionais, a indicação preferencial de um medicamento sobre outro prioriza a escolha. No entanto, a opção secundária não é contraindicada para uso naquela situação, podendo ser empregada em situações específicas, definidas neste PCDT.  
A definição dos principais termos usados, a descrição dos fármacos tratados e a descrição das categorias dos fármacos usados no processo de elaboração deste PCDT são mostrados nas **tabelas D, E e F** .  
**Tabela D - Principais termos usados**  
|**Termo**|**Definições**|
|---|---|
|Paciente adulto com AR|Adultos (> 18 anos), atendendo aos critérios de classificação da AR da ACR9,10.|
|Benefícios e danos à saúde|Eficácia e segurança dos tratamentos, incluindo desfechos desejáveis e não desejáveis.|
|AR de início recente|AR com duração da doença/sintomas < 6 meses, em que a “duração” denota o período|
||de tempo em que o paciente apresentou sintomas, não o tempo desde o diagnóstico da<br>AR.|
|AR estabelecida|AR com duração da doença/sintomas > 6 meses.|
|Atividade da doença|Classificada como baixa, moderada ou alta, de acordo com escalas validadas<br>(DAS-28, SDAI e CDAI). As atividades da doença moderada e alta foram<br>combinadas com base nas opiniões dos panelistas, assim como foi feito<br>nasdiretrizessobre a AR da ACR de 2012.|  
64  
|**Termo**|**Definições**|
|---|---|
|Remissão da AR|Uma comissão conjunta da ACR e EULAR definiu a remissão da AR como número<br>de articulações dolorosas, número de articulações edemaciadas, níveis da proteína C<br>reativa (mg/dl) e avaliação global do paciente ≤ 1 cada; ou DAS Simplificado (SDAI<br>(Simplified Disease Activity Index)≤ 3,3, uma de seis medidas de atividade da doença<br>aprovadas pela ACR*.|
|Dose ideal|1) Dose necessária para atingir um alvo terapêutico definido entre o médico e o<br>paciente a partir das prioridades do paciente; 2) administrada por pelo menos 3 meses<br>antes do aumento da dose ou troca da terapia.|
|Falha terapêutica a MMCDs|Falha terapêutica a MMCDs devido a efeitos colaterais ou à falta de eficácia.|
|Falha terapêutica a MMCDbio|Falha terapêutica a MMCDbio devido a efeitos colaterais ou à falta de eficácia.|
|Legenda: AR, artrite reumatoide; ACR, Colé<br>atividade de doença; MMCDbio, medicame<br>sintéticas.|gio Americano de Reumatologia; EULAR, Liga Europeia Contra o Reumatismo; DAS, Escore (ou pontuação) da<br>ntos modificadores do curso da doença biológicos; MMCDs, medicamentos modificadores do curso da doença|  
* Qualquer das medidas de atividade de doença recomendadas pela ACR pode ser escolhida.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|**Classe**|**Medicamento**|**Via de**<br>**administração**|**Posologia**|
|---|---|---|---|
|Medicamentos modificadores|Metotrexato (MTX)|VO ou IM|7,5–25 mg, 1x/semana|
|do curso da doença sintéticos|Hidroxicloroquina|VO|400 mg, 1x/dia|
|convencionais (MMCDs)|Sulfassalazina|VO|500 mg, 1–3 g/dia|
||Leflunomida|VO|20 mg, 1x/dia|
|Medicamentos modificadores|Adalimumabe|SC|40 mg a cada 2 semanas|
|do curso da doença|Certolizumabepegol||400 mg nas semanas 0, 2 e 4. Depois de|
|imunobiológicos anti-TNF||SC|manter 200 mg a cada 2 semanas ou 400|
|(MMCDbioanti-TNF)|||mg a cada 4 semanas.|
||Etanercepte|SC|50 mg, 1x/semana|
||Golimumabe|SC|50 mg, 1x/ a cada 4 semanas|
||Infliximabe|IV|3 mg/kg/dose nas semanas 0, 2, 6. Depois<br>demanter a mesma dose a cada 8 semanas.|
|Medicamentos modificadores|Rituximabe|IV|1.000 mg nos dias 0 e 14. Após, a cada 6|
|do curso da doença|||ou mais meses†|
|imunobiológicos não anti-TNF|Tocilizumabe|IV|IV: 8 mg/kg/dose (dose máxima de 800|
|(MMCDbio não anti-TNF)|||mg) 1x/a cada 4 semanas.|
||Abatacepte||IV: 500 mg (pacientes com menos de 60|
|||IV ou SC|kg); 750 mg (entre 60 e 100 kg) e 1.000<br>mg (acima de 100 kg) nas semanas 0, 2 e|  
65  
|**Classe**|**Medicamento**|**Via de**<br>**administraçã**|**o**<br>**Posologia**|
|---|---|---|---|
||||4. Depois demanter a mesma dose 1x/a<br>cada 4 semanas.|
||||SC:125 mg 1x/semana|
|Medicamentos modificadores|Tofacitinibe||5 mg, 2x/dia|
|do curso da doença sintético||VO||
|alvo-específico||||
|Imunossupressores|Azatioprina||Iniciar com 1 mg/kg/dia, 1 a 2x/dia, e, em|
|||VO|caso de não resposta, aumentar 0,5<br>mg/kg/dia a cada mês até 2,5 mg/kg/dia<br>(dose máxima).|
||Ciclofosfamida|IV|600 mg/m2 em pulsoterapia mensal por 3<br>a 6 meses|
||Ciclosporina||Iniciar com 2,5 mg/kg/dia em duas<br>administrações e aumentar a 0,5–0,75|
|||VO|mg/kg/dia a cada 2 ou 3 meses. Em caso<br>de falha terapêutica, aumentar até 4<br>mg/kg/dia|
|Glicocorticoides|Prednisona|VO|Alta dose: > 10 mg/dia<br>Baixa dose: ≤ 10 mg/dia|
||Prednisolona|VO|Solução oral de 1 e 3 mg/mL|
|AINEs|Naproxeno|VO|500 a 1.000 mg/dia, 2x/dia (usar a menor<br>dose pelo menor tempo possível)|
||Ibuprofeno|VO|600 a 2.700 mg/dia, 3x/dia.|  
*Ou fármacos equivalentes.  
†Conforme avaliação de atividade de doença pelo ICAD.  
66  
**Tabela F - Descrição das categorias dos medicamentos**  
|**Categoria de medicamentos**|**Descrições**|
|---|---|
|MMCDs|Medicamentos modificadores do curso da doença sintéticos convencionais,<br>incluindo HCQ, LEF, MTX ou SSZ (excluindo azatioprina, ciclosporina,<br>minociclina e sais de ouro); não inclui tofacitinibe, que será considerado<br>separadamente.|
|Monoterapia MMCDs|Frequentemente definido com o uso de monoterapia MTX, mas também pode ser<br>SSZ, HCQ ou LEF.|
|Terapia combinada dupla MMCDs|MTX + HCQ, MTX + SSZ, SSZ + HCQ ou combinações com LEF (LEF +<br>MTX, LEF + HCQ, LEF + SSZ).|
|Terapia combinada tripla MMCDs|MTX + SSZ + HCQ.|
|Terapia combinada com MMCDs|Terapia dupla ou tripla com MMCDs convencionais.|
|Tofacitinibe (MMCDsae)|Medicamentos modificadores do curso da doença sintéticos alvo-específicos.|
|MMCDbio|Medicamentos modificadores do curso da doença biológicos incluindo anti-TNF<br>ou biológicos não anti-TNF (excluindo anakinra).|
|Biológicos anti-TNF|Adalimumabe, certolizumabepegol, etanercepte, golimumabe ou infliximabe.|
|Biológicos não anti-TNF|Abatacepte, rituximabe ou tocilizumabe (excluindo anakinra).|
|Glicocorticoides em doses baixas|≤ 10 mg/dia de prednisona (ou equivalente).|
|Glicocorticoides em doses altas|> 10 mg/dia a ≤ 60 mg/dia de prednisona (ou equivalente) com redução rápida da<br>dose.|
|Glicocorticoides em curto prazo|< 3 meses de tratamento|  
HCQ, hidroxicloroquina; LEF, leflunomida; MMCDs, medicamentos modificadores do curso da doença sintéticos convencionais; MTX, metotrexato; SSZ, sulfassalazina; TNF, fator de necrose tumoral.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Os aspectos econômicos foram considerados na elaboração deste PCDT, sendo usada a obtenção do custo direto das intervenções com o tratamento medicamentoso de acordo com os valores praticados pelo Ministério da Saúde **(Tabela G)** e pelas Secretarias Estaduais e Municipais de Saúde.  
**Tabela G - Relação de preços referentes à AR**  
|**Medicamento**|**Preço unitário**|
|---|---|
|Metotrexato 25 mg/mL (solução injetável)*|R$ 7,73|
|Metotrexato 2,5 mg (comprimido)*|R$ 0,29|
|Sulfassalazina 500 mg*|R$ 0,26|
|Sulfato de hidroxicloroquina 400 mg*|R$ 1,29|
|Leflunomida 20 mg*|R$ 4,07|
|Adalimumabe 40 mg|R$ 659,68|
|Etanercepte 25 mg|R$ 165,43|
|Etanercepte 50 mg|R$ 330,85|
|Golimumabe 50 mg|R$ 1.276,98|  
67  
|**Medicamento**|||||**Preço unitário**||
|---|---|---|---|---|---|---|
|Tocilizumabe 80 mg|||||R$ 175,40||
|Abatacepte 250 mg|||||R$ 390,30||
|Abatacepte 125 mg|||||R$ 352,68||
|Infliximabe 100 mg|||||R$ 901,95||
|Certolizumabe 200 mg|||||R$ 459,10||
|Rituximabe 500 mg|||||R$ 1798,15||
|Tofacitinibe 5 mg (†)|||||R$ 52,24||
|(*)<br>Medicamentos<br>não<br>adquiridos<br>centralizadamente|pelo|Ministério|da|Saúde|no<br>momento<br>do<br>levantamento|de<br>preços|  
(http://paineldeprecos.planejamento.gov.br/).  
(†) Até o momento do levantamento de preços, o medicamento tofacitinibe ainda não tinha compra contratada pelo Ministério da Saúde.  
Para os medicamentos adquiridos pelo Ministério da Saúde, foram considerados os preços dos contratos vigentes em 2018, conforme publicado no Diário Oficial da União.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Durante a fase de escopo, considerou-se que há poucas dúvidas sobre o uso dessa estratégia sobre o tratamento sem meta terapêutica. Assim, essa recomendação foi adotada conforme apresentada nas diretrizes do ACR 2015, e o painel considerou que tecer comentários sobre estratégia com metaterapêutica era importante para a implementação das demais recomendações.  
A recomendação das diretrizes do ACR 2015 consiste em:

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
<u>Considerações terapêuticas: O objetivo do tratamento deve ser sempre a remissão da atividade da doença, sendo aceitável</u> baixa atividade. A atividade da AR pode ser medida por meio de índices combinados de atividade de doença (ICAD) e algum instrumento de medida da capacidade funcional, como o Health Assessment Questionnaire (HAQ).

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
As recomendações para o tratamento medicamentoso da AR de início recente (duração < 6 meses) estão descritas abaixo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
As diretrizes originais do ACR incluíam duas questões sobre o tratamento de AR recente com baixa atividade da doença. Essas recomendações foram adotadas conforme apresentadas nas diretrizes do ACR 2015, e o painel considerou importante para implementação das demais recomendações tecer comentários sobre o tratamento da AR recente com baixa atividade da doença. As recomendações das diretrizes originais consistem em:  
**Recomendamos usar monoterapia com MMCDs em vez de terapia combinada dupla com MMCDs em pacientes com AR de início recente de baixa atividade da doença sem tratamento prévio com MMCDs (qualidade da evidência baixa, recomendação forte, ACR 2015, Questão A.2).**  
68

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
<u>Considerações terapêuticas: Em pacientes com AR recente, com baixa atividade da doença e sem tratamento prévio com</u> MMCDs, a monoterapia com MMCDs é mais aceitável que a terapia combinada (dupla ou tripla) devido à facilidade de administração e possível melhor tolerância. O metotrexato (MTX) deve ser o MMCDs preferencial para iniciar o tratamento. Em casos de intolerância ao MTX oral, deve-se tentar dividir a administração por via oral ou empregar metotrexato injetável. Na impossibilidade do MTX, por falha ou toxicidade, usar preferencialmente leflunomida ou sulfassalazina.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**QUESTÃO 1. DEVEMOS USAR TERAPIA COMBINADA DUPLA COM MMCDs EM VEZ DE MONOTERAPIA COM MMCDs EM PACIENTES COM AR DE INÍCIO RECENTE COM MODERADA OU ALTA ATIVIDADE DA DOENÇA SEM TRATAMENTO PRÉVIO COM MMCDs?**  
**<u>Recomendação 1: Sugerimos usar monoterapia com MMCDs em vez de terapia combinada dupla com MMCDs</u> em pacientes com AR de início recente de moderada ou alta atividade da doença sem tratamento prévio com MMCDs (qualidade da evidência moderada, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foram incluídos dois estudos para analisar o desfecho Escore da atividade de doença (DAS), dois estudos para o desfecho melhora da resposta aos critérios ACR 20, ACR 50 e ACR 70, três estudos para o desfecho questionário de avaliação de saúde (HAQ), um estudo para o desfecho progressão radiográfica detectável (Escore Sharp), e três estudos foram incluídos para analisar o desfecho descontinuação do tratamento por efeitos colaterais. A combinação de terapia combinada dupla com MMCDs aumentou o número de pacientes aos critérios ACR 20 e ACR 70 em 126% (aumento de 229 para cada 1.000 pacientes, qualidade de evidência moderada) e 271% (aumento de 58 para cada 1.000 pacientes, qualidade de evidência baixa), respectivamente. A combinação não melhorou a resposta aos critérios ACR 50 [Risco Relativo (RR) 2,80, IC95% 0,97 a 8,07, qualidade de evidência baixa], não modificou a média da DAS [diferença de médias (DM -0,05, IC95% - 0,38 a 0,28, qualidade de evidência moderada)], a média do HAQ (DM -0,08, IC95% -0,46 a 0,3, qualidade de evidência moderada), escore Sharp (RR 0,55, IC95% 0,22 a 1,41, qualidade de evidência moderada) e a descontinuação por efeitos colaterais (RR 1,67, IC95% 0,96 a 2,92, qualidade de evidência moderada). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR recente, com moderada ou alta atividade da doença e sem tratamento</u> prévio com MMCDs, a monoterapia com MMCDs é mais aceitável que a terapia dupla pela facilidade de administração e possível melhor tolerância. O MTX deve ser o MMCDs preferencial para iniciar o tratamento. Em casos de intolerância ao MTX oral, deve-se tentar dividir a administração por via oral ou empregar metotrexato injetável. Na impossibilidade do MTX, por falha ou toxicidade, usar preferencialmente leflunomida ou sulfassalazina.  
1.  Capell HA, Madhok R, Porter DR, Munro RA, McInnes IB, Hunter JA, et al. Combination therapy with sulfasalazine and methotrexate is more effective than either drug alone in patients with rheumatoid arthritis with a suboptimal response to sulfasalazine: results from the double-blind placebo-controlled MASCOT study. Ann Rheumatic Dis. 2007;66(2):235-41.  
2. Dougados M, Combe B, Cantagrel A, Goupille P, Olive P, Schattenkirchner M, et al. Combination therapy in early rheumatoid arthritis: a randomised, controlled, double blind 52 week clinical trial of sulphasalazine and methotrexate compared with the single components. Annals Rheumatic Dis. 1999;58(4):220-5.  
69  
3. Haagsma CJ, van Riel PL, de Jong AJ, van de Putte LB. Combination of sulphasalazine and methotrexate versus the single components in early rheumatoid arthritis: a randomized, controlled, double-blind, 52 week clinical trial. British J Rheumatology. 1997;36(10):1082-8.  
**QUESTÃO 2. DEVEMOS USAR TERAPIA COMBINADA TRIPLA COM MMCDs EM VEZ DA MONOTERAPIA COM MMCDs EM PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA SEM TRATAMENTO PRÉVIO COM MMCDs?**  
**<u>Recomendação 2: Sugerimos usar monoterapia com MMCDs em vez da terapia combinada tripla com MMCDs</u> em pacientes com AR de início recente de moderada ou alta atividade da doença sem tratamento prévio com MMCDs (qualidade da evidência moderada, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foram incluídos três estudos para analisar o desfecho Escore da atividade de doença(DAS-28), dois estudos para o desfecho melhora da resposta aos critérios do ACR 50, um estudo para o desfecho questionário de avaliação de saúde (HAQ), quatro estudos para o desfecho efeitos colaterais graves, três estudos para o desfecho infecção, quatro estudos para o desfecho efeitos colaterais gastrointestinais e três estudos para o desfecho hepatotoxicidade. A terapia combinada tripla com MMCDs aumentou o número de pacientes com ACR 50 em 41% (aumento de 109 para cada 1.000 pacientes, qualidade de evidência alta), porém, não modificou a média do DAS-28 (DM -0,27, IC95% -0,62 a 0,08, qualidade de evidência baixa), a média do HAQ (DM -0,12, IC95% -0,29 a 0,05, qualidade de evidência baixa), não apresentou riscos para efeitos colaterais graves (RR 1,04, IC95% 0,69 a 1,57, qualidade de evidência moderada), os riscos para infecções (RR 1,03, IC95% 0,78 a 1,36, qualidade de evidência moderada), os sintomas gastrointestinais (RR 1,48, IC95% 0,82 a 2,67, qualidade de evidência moderada) e o risco de hepatotoxicidade (RR 0,68, IC95% 0,45 a 1,03, qualidade de evidência moderada). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR recente, com moderada ou alta atividade da doença, e sem tratamento</u> prévio com MMCDs, a monoterapia com MMCDs é mais aceitável que a terapia tripla pela facilidade de administração e possível melhor tolerância. O metotrexato (MTX) deve ser o MMCDs preferencial para iniciar o tratamento. Em casos de intolerância ao MTX oral, deve-se tentar dividir a administração por via oral ou empregar metotrexato injetável. Na impossibilidade do MTX, por falha ou toxicidade, usar preferencialmente leflunomida ou sulfassalazina.  
1. tREACHtrial:  
a) DE JONG, P. H. et al. Induction therapy with a combination of DMARDs is better than methotrexate monotherapy: first results of the tREACH trial. **Annals of the rheumatic diseases** , v.72, n. 1, p. 72‐78, 2013. (Follow-up time 3 months)  
b) DE JONG, P. H. et al. Randomised comparison of initial triple DMARD therapy with methotrexate monotherapy in combination with low-dose glucocorticoid bridging therapy; 1-year data of the tREACH trial. **Annals of the rheumatic diseases** , v. 73, n. 7, p. 1331-1339, 2014. (Follow-up time 12 months)  
2. MORELAND L. W. et al. A randomized comparative effectiveness study of oral triple therapy versus etanercept plus methotrexate in early aggressive rheumatoid arthritis: the treatment of Early Aggressive Rheumatoid Arthritis Trial. **ArthritisRheum,** v. 64, n. 9, p. 2824‐2835, 2012.  
3. SAUNDERS S. A. et al. Triple therapy in early active rheumatoid arthritis: a randomized, single‐blind, controlled trial comparing step‐up and parallel treatment strategies. **Arthritis Rheum** , v. 58, n. 5, p. 1310‐1317, 2008.  
4. MOTTONEN T. et al. Comparison of combination therapy with single‐drug therapy in early rheumatoid arthritis: a randomised trial. FIN‐RACo trial group. **Lancet,** v.353, n. 9164, p. 1568‐1573, 1999.  
70  
**QUESTÃO 3. DEVEMOS ADICIONAR GLICOCORTICOIDES EM DOSES BAIXAS E POR LONGOS PERÍODOS AOS MMCDs, EM VEZ DO USO DE MMCDs SEM GLICOCORTICOIDES EM PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA?**  
**<u>Recomendação 3: Sugerimos não adicionar glicocorticoides em doses baixas por longos períodos aos MMCDs em</u> pacientes com AR de início recente de moderada ou alta atividade da doença (qualidade da evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foram incluídos sete estudos que avaliaram o desfecho Escore da atividade de doença (DAS28), seis estudos avaliaram o Escore de remissão da atividade de doença (DAS-28), sete estudos avaliaram o questionário de avaliação de saúde (HAQ), quatro estudos avaliaram a progressão radiográfica detectável (Escore de Sharp), cinco estudos avaliaram efeitos colaterais graves, três estudos avaliaram infecções graves e três estudos avaliaram hipertensão arterial sistêmica. A adição de glicocorticoides em doses baixas por longos períodos a MMCDs reduziu a média da progressão radiográfica detectável em -4,36 (IC95% -7,75 a -0,98, qualidade de evidência moderada), não modificou a média do DAS-28 (DM -0,34, IC95% -0,82 a 0,14, qualidade de evidência baixa), não modificou o risco do Escore de Remissão DAS-28 (RR 1,29, IC95% 0,98 a 1,68, qualidade de evidência baixa), não modificou a média do HAQ (DM -0,04, IC95% -0,02 a 0,12, qualidade de evidência moderada), não apresentou diferença no risco de efeitos colaterais graves (RR 0,94, IC95% 0,68 a 1,30, qualidade de evidência baixa), risco de infecções graves (RR 0,52, IC95% 0,18 a 1,50, qualidade de evidência muito baixa), risco de hipertensão arterial sistêmica (RR 2,04, IC95% 0,40 a 10,40, qualidade de evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Durante o tratamento, anti-inflamatórios não esteroides e glicocorticoides em baixas doses</u> (≤ 10 mg/dia) por curtos períodos de tempo (< 3 meses) como “ponte” para início do efeito da MMCDs podem ser empregados.  
1. VERSCHUEREN, P.; DE COCK, D.; CORLUE, L. Patients lacking classical poor prognostic markers might also benefit from a step-down glucocorticoid bridging scheme in early rheumatoid arthritis: week 16 results from the randomized multicenter CareRA trial. Arthritis Res Ther, v. 17, n. 1, p. 97, 2015. (Follow-up time: after 16 weeks)  
2. MENON, N. et al. Comparison of intra-articular glucocorticoid injections with DMARDs versus DMARDs alone in rheumatoid arthritis. The Journal of the Association of Physicians of India, v. 62, n. 8, p. 673-676, 2014.  
3. De Cock, D. et al. Two-year clinical and radiologic follow-up of early RA patients treated with initial step up monotherapy or initial step-down therapy with glucocorticoids, followed by a tight control approach: lessons from a cohort study in daily practice. Clinical rheumatology, v. 33, n. 1, p. 125-130, 2014.  
4. BAKKER M. F. et al. Low‐dose prednisone inclusion in a methotrexate‐based, tight control strategy for early rheumatoid arthritis: a randomized trial. Ann Intern Med, v. 156, n. 5, p. 329‐339, 2012.  
5. MONTECUCCO C. et al. Low‐dose oral prednisone improves clinical and ultrasonographic remission rates in early rheumatoid arthritis: results of a 12‐month open‐label randomised study. Arthritis research & therapy, v. 14, n. 3, p. R112, 2012.  
6. TODOERTI M. et al.Early disease control by low‐dose prednisone comedication may affect the quality of remission in patients with early rheumatoid arthritis. Annals of the New York Academy of Sciences, v. 1193, p. 139‐145, 2010.  
7. CHOY E. H. et al. Factorial randomised controlled trial of glucocorticoids and combination disease modifying drugs in early rheumatoid arthritis. Ann Rheum Dis, v. 67, n. 5, p. 656‐663, 2008.  
8. SVENSSON B. et al. Low‐dose prednisolone in addition to the initial disease modifying antirheumatic drug in patients with early active rheumatoid arthritis reduces joint destruction and increases the remission rate: a two‐year randomized trial. Arthritis Rheum, v. 52, n. 11, p. 3360‐3370, 2005.  
71  
9. WASSENBERG S. et al. Verylow‐dose prednisolone in early rheumatoid arthritis retards radiographic progression over two years: a multicenter, double‐blind, placebo‐controlled trial. Arthritis Rheum, v. 52, n. 11, p. 3371‐3380, 2005.  
10. CAPELL H. A. Lack of radiological and clinical benefit over two years of low dose prednisolone for rheumatoid arthritis: results of a randomised controlled trial. Ann RheumDis, v. 63, n. 7, p. 797‐803., 2004.  
11. Fedorenko E, Lukina GV, Sigidin YA. Remission as the main goal of treatment in early rheumatoid arthritis patients: comparative efficacy of four treatment regimens. Ann RheumDis 2011;70 (Suppl 3):598  
12. Machold KP, Landewé R, Smolen JS, et al. The Stop Arthritis Very Early (SAVE) trial, an international multicentre, randomised, double-blind, placebo-controlled trial on glucocorticoids in very early arthritis. Ann RheumDis 2010; 69:495–502.  
**QUESTÃO 4. DEVEMOS USAR MMCDbio ANTI-TNF + METOTREXATO EM VEZ DA TERAPIA COMBINADA TRIPLA COM MMCDs EM PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM AOS MMCDs?**  
**<u>Recomendação 4: Sugerimos usar terapia combinada tripla com MMCD em vez da terapia com MMCDbio anti-</u> TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs (qualidade da evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foi incluído um estudo que avaliou a melhora da resposta aos critérios do ACR 20, ACR 50 e ACR 70, um estudo avaliou a progressão radiográfica detectável (Escore Sharp), um estudo avaliou os efeitos colaterais graves, dois estudos avaliaram infeções e infestações e um estudo avaliou hepatotoxicidade. A combinação dos MMCDbioanti-TNFi + MTX modificou o escore Sharp (DM -3,23, IC95% -6,03 a -0,43, qualidade de evidência baixa), não melhorou a resposta aos critérios ACR 20 (RR 1,20, IC95% 0,87 a 1,76, qualidade de evidência baixa), ACR 50 (RR 1,38, IC95% 0,90 a 2,10, qualidade de evidência baixa) e ACR 70 (RR 1,18, IC95% 0,66 a2,12, qualidade de evidência baixa);também não apresentou risco para efeitos colaterais graves (RR 2,03, IC95% 0,19 a 22,12, qualidade de evidência muito baixa), para infecções e infestações (RR 1,54, IC95% 0,99 a 2,41, qualidade de evidência baixa), hepatotoxicidade (RR 3,55, IC95% 0,75 a 16,79, qualidade de evidência muito baixa). Além das evidências acima, levamos em consideração para tomada de decisão uma metanálise em rede 11 que objetivou comparar MTX e combinações dos MMCDbio + MTX em pacientes com AR sem tratamento prévio com MMCDs ou que falharam ao MTX. Foram encontradas evidências de moderada a alta qualidade que a terapia combinada tripla ou MTX + MMCDbio ou tofacitinibe foram igualmente eficazes no controle da atividade da doença e, geralmente, são bem toleradas em pacientes sem tratamento prévio com MMCDs ou que falharam ao MTX. A terapia combinada tripla foi superior ao MTX na prevenção do dano articular em pacientes sem tratamento prévio, mas a magnitude desses efeitos foi pequena ao longo de um ano. Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: A terapia tripla deve ser tentada antes dos MMCDbio anti-TNF + MTX em pacientes com</u> AR recente de moderada ou alta atividade que falharam aos MMCDs. No caso de terapia tripla, ela geralmente consiste em MTX + sulfassalazina + hidroxicloroquina, com a leflunomida podendo ser substituta em casos de intolerância, em especial MTX12,13. Considerar falha dos MMCDs: a) após emprego de sua dose terapêutica ideal e com aderência e persistência adequadas no tratamento por um período mínimo de 3 meses, b) interrupção do tratamento por efeitosadversos5.  
1. LEVITSKY, A. et al. Serum survivin predicts responses to treatment in active rheumatoid arthritis: a post hoc analysis from the SWEFOT trial. BMC medicine, v. 13, n. 1, p. 1, 2015.  
2. HEIMANS, L. A two-step treatment strategy trial in patients with early arthritis aimed at achieving remission: the IMPROVED study. Annalsoftherheumaticdiseases, v. 73, n. 7, p. 1356-61, 2014.  
72  
3. VAN VOLLENHOVEN R. F. Conventional combination treatment versus biological treatment in methotrexate‐ refractory early rheumatoid arthritis: 2-year follow‐up of the randomised, non‐blinded, parallel‐group Swefot trial. Lancet, v. 379, n. 9827, p. 1712‐1720, 2012.  
**QUESTÃO 5. DEVEMOS USAR MMCDbio NÃO ANTI-TNF + MTX EM VEZ DOS MMCDbio ANTI-TNF + MTX EM PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM AOS MMCDs?**  
**<u>Recomendação 5:</u> Sugerimos usar os MMCDbio não anti-TNF + MTX OU MMCDbio anti-TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs (qualidade da evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foi incluído um estudo que avaliou o Escore da atividade de doença (DAS-28), 1 estudo avaliou a melhora da resposta aos critérios do ACR50, 1 estudo avaliou o questionário de avaliação de saúde (HAQ), um estudo avaliou a progressão radiográfica detectável (escore de Sharp), um estudo avaliou efeitos adversos graves, um estudo avaliou infecções graves e um estudo avaliou as reações no local da injeção. Os MMCDbioanti-TNF + MTX não modificaram a média do DAS28 (DM -0,03, IC95% -0,25 a 0,19, qualidade de evidência baixa), o número de pacientes com ACR 50 (RR 1,00, IC95% 0,85 a 1,19, qualidade de evidência baixa), a média do HAQ (DM 0, IC95% -0,08 a 0,08, qualidade de evidência baixa), a média da progressão radiográfica detectável em 0,02 (IC95% -0,49 a 0,89, qualidade de evidência baixa), não alterou risco para os efeitosadversos graves (RR 1,10, IC95% 0,69 a 1,77, qualidade de evidência muito baixa) e as infecções graves (RR 0,78, IC95% 0,29 a 2,06, qualidade de evidência baixa). O risco para reações no local da injeção diminuiu em 59% (diminuição de 54 reações para cada 1.000 pacientes, de 71 a menos para 19 a menos, qualidade de evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR recente de moderada ou alta atividade que apresentaram falha a todas</u> as opções de MMCDs, suas combinações e trocas, pode-se empregar MMCDbio anti-TNF + MTX ou MMCDbio não anti-TNF + MTX (ou ambos em monoterapia). Quando os MMCDbio são associados ao MTX, não há diferença de escolha entre MMCDbio não anti-TNF ou MMCDbio anti-TNF. A eficácia e a segurança foram semelhantes entre as intervenções. O uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação absoluta a todos os MMCDbio anti-TNF e também ao abatacepte e tocilizumabe.  
1. WEINBLATT M. E. Head‐to‐head comparison of subcutaneous abatacept versus adalimumab for rheumatoid arthritis: findings of a phase IIIb, multinational, prospective, randomized study. ArthritisRheum, v. 65, n. 1, p. 28‐38, 2013.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 6:</u> Sugerimos usar MMCDbio não anti-TNF ou MMCDbio anti-TNF em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs (qualidade da evidência moderada, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foi incluído um estudo que avaliou o Escore da atividade de doença (DAS-28), um estudo avaliou a melhora da resposta aos critérios do ACR 50, um estudo avaliou o questionário de avaliação de saúde (HAQ), um estudo avaliou efeitos colaterais graves, um estudo avaliou infecções graves, um estudo avaliou neoplasias, um estudo avaliou hepatotoxicidade e um estudo avaliou o nível de colesterol. Os MMCDbio anti-TNF modificou a média da DAS-28 (DM -1,5,  
73  
IC95% -1,8 a -1,1, qualidade de evidência moderada), reduziu o número de pacientes com ACR 50 em 41% (diminui de 114 para cada 1.000 pacientes, qualidade de evidência moderada), não modificou a média do HAQ (DM -0,02, IC95% -0,3 a 0, qualidade de evidência moderada); também não apresentou risco para efeitos adversos graves (RR 0,91, IC95% 0,53 a 1,58, qualidade de evidência baixa), para infecções graves (RR 1,17, IC95% 0,40 a 3,40, qualidade de evidência baixa), neoplasias (RR 1,00, IC95% 0,06 a 15,85, qualidade de evidência baixa), hepatotoxicidade (RR 0,45, IC95% 0,16 a 1,28, qualidade de evidência baixa) e colesterol (RR 1,00, IC95% 0,14 a 7,01, qualidade de evidência baixa).Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: No emprego de MMCDbio geralmente se associa o MTX. Na impossibilidade de usar MTX,</u> a monoterapia com MMCDbio pode ser empregada, havendo limitada evidência de que o tocilizumabe é mais eficaz por apresentar melhora da dor e atividade da doença autorrelatada comparado aosMMCDbio anti-TNF, não sendo suficiente para categorizá-lo obrigatoriamente como primeira escolha terapêutica. Na impossibilidade de usar MMCDbio não anti-TNF (tocilizumabe), sugere-se usar outro MMCDbio, não havendo predileção por nenhuma classe ou medicamento específico para o tratamento em monoterapia. O uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação absoluta a todos os MMCDbio anti-TNF e também ao abatacepte e tocilizumabe.  
1. GABAY C. et al. Tocilizumab monotherapy versus adalimumab monotherapy for treatment of rheumatoid arthritis (ADACTA): a randomised, double-blind, controlled phase 4 trial. Lancet, v. 381, p. 1541–50, 2013.  
**QUESTÃO 7. DEVEMOS USAR TOFACITINIBE ORAL + MTX EM VEZ DOS MMCDbio ANTI-TNF + MTX EM PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM AOS MMCDs?**  
**<u>Recomendação 7: Sugerimos usar MMCDbio anti-TNF + MTXem vez de tofacitinibe + MTX em pacientes com</u> AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs (qualidade da evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foi incluído um estudo que avaliou o Escore da atividade de doença (DAS-28), um estudo avaliou a melhora da resposta aos critérios do ACR 20, um estudo avaliou o questionário de avaliação de saúde (HAQ-DI), um estudo avaliou efeitos colaterais graves, um estudo avaliou infecções graves e um estudo avaliou a hepatotoxicidade. A terapia combinada tofacitinibe + MTX modificou a média do HAQ-DI (DM -0,06, IC95% -0,07 a -0,05, qualidade de evidência moderada), não modificou o risco do DAS-28 (RR 0,92, IC95% 0,42 a 2,03, qualidade de evidência baixa), não modificou o número de pacientes com ACR 20 (RR 1,09, IC95% 0,89 a 1,33, qualidade de evidência baixa), não alterou risco para os efeitos adversos graves (RR 1,43, IC95% 0,55 a 3,68, qualidade de evidência baixa), infecções graves (RR 2,00, IC95% 0,18 a 21,88, qualidade de evidência moderada) e hepatotoxicidade (RR 1,67, IC95% 0,49 a 5,67, qualidade de evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR recente de moderada ou alta atividade que apresentaram falha a todas</u> as opções de MMCDs, suas combinações e trocas, pode-se empregar MMCDbio anti-TNF + MTX ou MMCDbio não anti-TNF + MTX. O tofacitinibe possui menor experiência de uso, havendo a necessidade de monitoramento de seus efeitos adversos e eficácia, pois o perfil de segurança em longo prazo ainda não está bem estabelecido, sendo mais associado a herpes zóster. O tofacitinibe pode ser uma alternativa para locais de difícil acesso a centros de infusões ou com dificuldades para armazenamento de MMCDbio.  
74  
1. VAN VOLLENHOVEN R. F. Conventional combination treatment versus biological treatment in methotrexate‐ refractory early rheumatoid arthritis: 2-year follow‐up of the randomised, non‐blinded, parallel‐group Swefot trial. Lancet, v. 379, n. 9827, p. 1712‐1720, 2012.  
**QUESTÃO 8. DEVEMOS USAR TOFACITINIBE ORAL EM VEZ DOS MMCDbio ANTI-TNF PARA PACIENTES COM AR DE INÍCIO RECENTE DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM AOS MMCDs?**  
**<u>Recomendação 8: Sugerimos usar MMCDbio anti-TNF em vez de tofacitinibe oral para pacientes com AR de início</u> recente de moderada ou alta atividade da doença que falharam aos MMCDs (qualidade da evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Foram incluídos um estudo que avaliou o Escore da atividade de doença (DAS-28), um estudo que avaliou a melhora da resposta aos critérios do ACR 20, ACR 50 e ACR 70, um estudo que avaliou o questionário de avaliação de saúde (HAQ-DI), um queestudo avaliou efeitos colaterais graves, um queestudo avaliou infecções graves e um estudo que avaliou a hepatotoxicidade. A terapia com tofacitinibe aumentou o número de pacientes com ACR 20 em 65% (aumento de 233 para cada 1.000 pacientes, qualidade de evidência baixa), não modificou o risco do DAS-28 (RR 1,62, IC95% 0,28 a 9,30, qualidade de evidência baixa), o número de pacientes com ACR 50 (RR 1,95, IC95% 1,00 a 3,80, qualidade de evidência baixa) e ACR 70 (RR 3,24, IC95% 0,69 a 15,33, qualidade de evidência baixa), a média do HAQ-DI (DM -0,19, IC95% -0,49 a 0,11, qualidade de evidência baixa) não alterou risco para os efeitos colaterais graves (RR 0,36, IC95% 0,02 a 8,63, qualidade de evidência baixa), infecções graves (RR 0,36, IC95% 0,02 a 8,63, qualidade de evidência baixa) e hepatotoxicidade (RR 0,36, IC95% 0,02 a 8,63, qualidade de evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Na segunda linha de tratamento, o MTX geralmente deve ser associado. Na impossibilidade</u> de usar o MTX (por efeitos adversos), a monoterapia com MMCDbio é preferencial, podendo o tofacitinibe ser uma opção terapêutica. O tofacitinibe possui menor experiência de uso, havendo a necessidade de monitoramento de seus efeitos adversos e eficácia, pois o perfil de segurança em longo prazo ainda não está bem estabelecido, sendo mais associado a herpes zóster.Otofacitinibe pode ser uma alternativa para locais de difícil acesso a centros de infusões ou com dificuldades para armazenamento de MMCDbio.  
1. FLEISCHMANN R. et al. Phase IIb Dose-Ranging Study of the Oral JAK Inhibitor Tofacitinib (CP-690,550) or Adalimumab MonotherapyVersus Placebo in Patients with Active Rheumatoid Arthritis with an Inadequate Response to DiseaseModifying Antirheumatic Drugs Placebo-controlled trial of tofacitinib monotherapy in rheumatoid arthritis. Arthritis&Rheumatism, v.64, p .617–629, 2012.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
As recomendações para o tratamento medicamentoso da AR estabelecida (duração > 6 meses) estão descritas abaixo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
75

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Resumo das evidências:</u>** Dois estudos avaliaram o Escore da atividade de doença (DAS-28), um estudo avaliou a melhora das respostas aos critérios do ACR 50, um estudo avaliou a progressão radiográfica de Sharp (modificação de Van der Heijde), dois estudos avaliaram os efeitos adversos graves e dois estudos avaliaram infecções graves. Em comparação à terapia tripla com MMCDs, os MMCDbio anti-TNF + MTX não modificarama média de DAS-28 (DM -0,11, IC95% -0,29 a 0,06, qualidade da evidência baixa), não melhoraram a resposta aos critérios ACR 50 (RR 1,20, IC95% 0,91 a 1,59, qualidade da evidência muito baixa), não modificaram o escore de Sharp (modificação de Van der Heijde) (DM -0,25, IC95% -0,86 a 0,36, qualidade da evidência baixa), aumentaram o risco de efeitos adversos graves em 52% (RR 1,52, IC95% 1,03 a 2,23, qualidade da evidência muito baixa) e aumentaram o risco de infecções graves em 90% (RR 1,90, IC95% 1,35 a 2,68, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: A terapia tripla deve ser tentada antes dos MMCDbio anti-TNF+ MTX em pacientes com</u> AR estabelecida de moderada ou alta atividade que falharam a monoterapia com MMCDs. No caso de terapia tripla, ela geralmente consiste em MTX + sulfassalazina + hidroxicloroquina, com a leflunomida podendo ser substituta em casos de intolerância, em especial ao MTX12,13. Considerar falha dos MMCDs: a) após emprego de sua dose terapêutica ideal e com aderência e persistência adequadas no tratamento por um período mínimo de 3 meses, b) a interrupção do tratamento por efeitos adversos5.  
Em casos selecionados (pior prognóstico, retornos prolongados), a terapia combinada (dupla ou tripla) pode ser empregada como estratégia inicial. Casos de pior prognóstico incluem fator reumatoide > 200 u/L ou anti-CCP em títulos ≥ 3x o limite superior da normalidade, alta atividade da doença, presença inicial de erosões, limitação funcional e manifestações extraarticulares.  
1. O’DELL J.R. et al. Therapies for active rheumatoid arthritis after methotrexate failure. N Engl J Med, v. 369, p. 307– 18, 2013.  
2. SCOTT D.L. et al. Tumour necrosis factor inhibitors versus combination intensivetherapy with conventional disease modifying anti-rheumatic drugs in established rheumatoid arthritis: TACIT non-inferiority randomised controlled trial. BMJ, v. 350: h1046.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 10: Sugerimos usar MMCDbio anti-TNF + MTX ou MMCDbio não anti-TNF + MTX em pacientes</u> com AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs (qualidade de evidência moderada, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Dois estudos avaliaram o Escore da atividade de doença (DAS-28), dois estudos avaliaram a melhora das respostas aos critérios do ACR 50, um estudo avaliou a progressão radiográfica de Sharp, dois estudos avaliaram os efeitos adversos graves, dois estudos avaliaram infecções graves, dois estudos avaliaram neoplasias, um estudo avaliou os efeitos adversos gastrointestinais e dois estudos avaliaram as reações de infusão/no local da injeção. Em comparação com MMCDbio não anti-TNF + MTX,MMCDbio anti-TNF + MTX não modificou a média de DAS-28 (DM 0,32, IC95% -0,10 a 0,74, qualidade da evidência alta), não melhorou a resposta aos critérios ACR 50 (RR 0,93, IC95% 0,72 a 1,21, qualidade da evidência  
76  
moderada), não modificou o escore de Sharp (DM -0,36, IC95% -6,41 a 5,69, qualidade da evidência baixa), ocorreu um aumento dos efeitos adversos e de infecções graves porém sem significância estatística (RR 1,42, IC95% 0,91 a 2,20, qualidade da evidência alta e RR 2,30, IC95% 0,83 a 6,35, qualidade da evidência alta), não aumentou o risco de neoplasias (RR 1,08, IC95% 0,42 a 2,79, qualidade da evidência baixa), não aumentou o risco de efeitos adversos gastrointestinais (RR 0,97, IC95% 0,06 a 15,43, qualidade da evidência baixa) e aumentou o risco de reações infusionais/no local da injeção em 194% (RR 2,94, IC95% 1,87 a 4,62, qualidade da evidência alta). Destaca-se aqui que os estudos avaliaram a comparação de medicamentos com vias de administração diferentes, sendo um a comparação de uso do abatacepte intravenoso versus infliximabe intravenoso e o outro abatacepte subcutâneo versus adalimumabe subcutâneo. Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR estabelecida de moderada ou alta atividade que apresentaram falha a</u> todas as opções de MMCDs, suas combinações e trocas, pode-se empregar MMCDbio anti-TNF + MTX ou MMCDbio não antiTNF + MTX. Quando os MMCDbio são associados ao MTX, não há diferença de escolha entre MMCDbio não anti-TNF ou MMCDbio anti-TNF. A eficácia e a segurança foram semelhantes entre as intervenções. O uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação absoluta a todos os MMCDbio anti-TNF e também ao abatacepte e tocilizumabe.  
1. SCHIFF M. et al. Head-to-head comparison of subcutaneous abatacept versus adalimumab for rheumatoid arthritis: two-year efficacy and safety findings from AMPLE trial. Ann Rheum Dis, v. 73, p. 86–94, 2014.  
2. SCHIFF M. et al. Efficacy and safety of abatacept or infliximab vs placebo in ATTEST: a phase III, multi-centre, randomised, double-blind, placebo-controlled study in patients with rheumatoid arthritis and an inadequate response to methotrexate. Ann RheumDis, v. 67, p. 1096–103, 2008.  
**QUESTÃO 11: DEVEMOS USAR MMCDbio anti-TNF EM VEZ DE MMCDbio não anti-TNF EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MMCDs?**

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Resumo das evidências:</u>** Um estudo avaliou o Escore da atividade de doença (DAS-28), o questionário de avaliação de saúde (HAQ), a melhora das respostas aos critérios do ACR 50, os efeitos adversos graves, as infecções graves, câncer e toxicidade cardiovascular. Em comparação com MMCDbio não anti-TNF, MMCDbio anti-TNF aumentou a média de DAS-28 (DM 1,4, IC95% 1,2 a 1,6, qualidade da evidência moderada), aumentou a média do HAQ (DM 0,2, IC95% 0,07 a 0,33, qualidade da evidência moderada), diminuiu a resposta aos critérios ACR 50 em 41% (RR 0,59, IC95% 0,44 a 0,79, qualidade da evidência moderada), não alterou o risco de efeitos adversos graves (RR 0,91, IC95% 0,53 a 1,58, qualidade da evidência baixa), houve um aumento de risco na medida pontual de risco de infecções graves, porém sem significância estatística (RR 1,17, IC95% 0,40 a 3,40, qualidade da evidência baixa), não aumentou o risco de câncer (RR 1,00, IC95% 0,06 a 15,85, qualidade da evidência baixa) e não aumento o risco de toxicidade cardiovascular (RR 1,00, IC95% 0,14 a 7,01, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: No emprego de MMCDbio, geralmente se associa o MTX. Na impossibilidade de usar MTX,</u> a monoterapia com MMCDbio pode ser empregada, havendo limitada evidência de que o tocilizumabeé mais eficaz por apresentar melhora da dor e atividade da doença autorrelatada em comparação aos MMCDbio anti-TNF, não sendo suficiente para categorizá-lo obrigatoriamente como primeira escolha terapêutica. Na impossibilidade de usar MMCDbio não anti-TNF  
77  
(tocilizumabe), sugere-se usar outro MMCDbio, não havendo predileção por nenhuma classe ou medicamento específico para o tratamento em monoterapia. O uso do rituximabe deve ser reservado somente aos indivíduos com contraindicação absoluta a todos os MMCDbio anti-TNF e também ao abatacepte e tocilizumabe.  
1.  GABAY C. et al. Tocilizumab monotherapy versus adalimumab monotherapy for treatment of rheumatoid arthritis (ADACTA): a randomised, double-blind, controlled phase 4 trial. Lancet, v. 381, p. 1541–50, 2013.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 12: Sugerimos usar MMCDbio anti-TNF + MTX em vez de tofacitinibe + MTX em pacientes com</u> AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Dois estudos avaliaram o Escore da atividade de doença (DAS-28) em 6 meses e um em 12 meses, dois estudos avaliaram a melhora das respostas aos critérios do ACR 20 em 6 meses e um em 12 meses, um estudo avaliou a melhora das respostas aos critérios do ACR 50 em 12 meses, um estudo avaliou a melhora das respostas aos critérios do ACR 70 em 12 meses, dois estudos avaliaram o questionário de avaliação de saúde (HAQ-DI), dois estudos avaliaram os efeitos adversos graves, dois estudos avaliaram infecções graves, dois estudos avaliaram hepatotoxicidade e um estudo avaliou neoplasias. Em comparação com tofacitinibe + MTX, MMCDbio anti-TNF + MTX não alterou o número de pacientes com DAS28 < 2,6 em 6 meses (RR 1,05, IC95% 0,74 a 1,48, qualidade da evidência muito baixa) ou em 12 meses (RR 1,17, IC95% 0,84 a 1,62, qualidade da evidência muito baixa), não alterou a resposta aos critérios ACR 20 em 6 meses (RR 0,96, IC95% 0,89 a 1,04, qualidade da evidência baixa) ou em 12 meses (RR 0,96, IC95% 0,88 a 1,06, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 50 (RR 0,96, IC95% 0,83 a 1,12, qualidade da evidência baixa), não alterou a resposta aos critériosAC R 70 (RR 0,89, IC95% 0,71 a 1,13, qualidade da evidência baixa), não alterou a média do HAQ-DI (DM 0,04, IC95% -0,04 a 0,11, qualidade da evidência muito baixa), não alterou o risco de efeitos adversos graves (RR 0,82, IC95% 0,52 a 1,31, qualidade da evidência muito baixa), não alterou o risco de infecções graves (RR 0,57, IC95% 0,23 a 1,44, qualidade da evidência muito baixa), não alterou o risco de hepatotoxicidade (RR 0,86, IC95% 0,54 a 1,36 , qualidade da evidência muito baixa) e não alterou o risco de neoplasias (sem eventos em ambos os grupos, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR estabelecida de moderada ou alta atividade que apresentaram falha a</u> todas as opções de MMCDs, suas combinações e trocas, pode-se empregar MMCDbio anti-TNF + MTX ou MMCDbio não antiTNF + MTX. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento.  
1. VAN VOLLENHOVEN R. F. et al. Conventional combination treatment versus biological treatment in methotrexate‐ refractory early rheumatoid arthritis: 2-year follow‐up of the randomised, non‐blinded, parallel‐group Swefot trial. Lancet, v. 379, n. 9827, p. 1712‐1720, 2012.  
2. FLEISCHMANN R. et al.Efficacy and safety of tofacitinib monotherapy, tofacitinib with methotrexate, and adalimumab with methotrexate in patients with rheumatoid arthritis (ORAL Strategy): a phase 3b/4, double-blind, head-to-head, randomised controlled trial.Lancet , v.17, p .457-468, 2017.  
78

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 13: Sugerimos usar MMCDbio anti-TNF em vez de tofacitinibe em pacientes com AR estabelecida</u> de moderada ou alta atividade da doença que falharam à terapia aos MMCDs (qualidade de evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Um estudo avaliou a resposta aos critérios do ACR 20, resposta aos critérios do ACR 50, resposta aos critérios do ACR 70, o questionário de avaliação de saúde (HAQ-DI), efeitos adversos graves, infecções sérias e hepatotoxicidade. Em comparação com tofacitinibe, MMCDbio anti-TNF diminuiu a resposta aos critérios ACR 20 (RR 0,61, IC95% 0,39 a 0,93, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 50 (RR 0,51, IC95% 0,26 a 1,00, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 70 (RR 0,31, IC95% 0,07 a 1,46, qualidade da evidência baixa), aumentou a média do HAQ-DI (DM 0,19, IC95% 0,15 a 0,23, qualidade da evidência baixa), não alterou o risco de efeitos adversos graves (RR 2,78, IC95% 0,12 a 66,62, qualidade da evidência baixa), não alterou o risco de infecções graves (sem eventos em ambos os grupos, qualidade da evidência baixa) e não alterou o risco de hepatotoxicidade (RR 0,31, IC95% 0,01 a 7,40, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Na segunda linha de tratamento, o MTX geralmente deve ser associado. Na impossibilidade</u> de usar o MTX (por efeitos adversos), a monoterapia com MMCDbio é preferencial, podendo o tofacitinibe ser uma opção terapêutica. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento.  
1. FLEISCHMANN R. et al. Phase IIb Dose-Ranging Study of the Oral JAK Inhibitor Tofacitinib (CP-690,550) or Adalimumab MonotherapyVersus Placebo in Patients With Active Rheumatoid Arthritis With an Inadequate Response to Disease-Modifying Antirheumatic Drugs Placebo-controlled trial of tofacitinib monotherapy in rheumatoid arthritis. Arthritis&Rheumatism , v.64, p .617–629, 2012  
**QUESTÃO 14: DEVEMOS USAR MMCDbio não anti-TNF + MTX EM VEZ DE OUTRO MMCDbio anti-TNF + MTX EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MMCDbio anti-TNF?**  
**<u>Recomendação 14: Sugerimos usar MMCDbio anti-TNF + MTX ou MMCDbio não anti-TNF + MTX em pacientes</u> com AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbio anti-TNF (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Quatro estudos observacionais e um ensaio clínico randomizado (ECR) avaliaram o Escore da atividade de doença (DAS-28), um estudo observacional e um ECR avaliaram o questionário de avaliação de saúde (HAQ), um estudo observacional e um ECR avaliaram efeitos adversos graves, dois estudos observacionais avaliaram reações no local da injeção e um estudo observacional e um ECR avaliaram infecções graves. Em comparação com MMCDbio anti-TNF + MTX, MMCDbio não anti-TNF + MTX diminuiu a média de DAS-28 (estudos observacionais: DM -0,37, IC95% -0,52 a -0,21, qualidade da evidência muito baixa; ECR: DM -0,38, IC95% -0,69 a -0,08, qualidade da evidência baixa), aumentou a média do HAQ em estudos observacionais (DM 0,36, IC95% 0,08 a 0,64, qualidade da evidência muito baixa), porém, não alterou no ECR (DM -0,02, IC95% -0,13 a 0,09, qualidade da evidência baixa), não alterou de forma significativa o risco de efeitos adversos graves (estudo observacional: RR 1,23, IC95% 0,89 a 1,69, qualidade da evidência muito baixa; ECR: RR 2,00, IC95% 0,88 a 4,53, qualidade da evidência muito baixa), não alterou o risco de reações de infusão/no local da injeção (RR 0,75, IC95% 0,04 a  
79  
13,86, qualidade da evidência muito baixa) e não alterou o risco de infecções graves(observacional: RR 2,15, IC95% 1,00 a 4,59, qualidade da evidência muito baixa; ECR: RR 1,03, IC95% 0,22 a 4,78, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes que falharam a um MMCDbio anti-TNF, é aceitável a sua substituição por um</u> outro MMCDbio anti-TNF ou então por um MMCDbio não anti-TNF, dada a eficácia e segurança semelhantes destas classes. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível.  
1. KEKOW J, MUELLER-LADNER U, SCHULZE-KOOPS H. Rituximab is more effective than second anti-TNF therapy in rheumatoid arthritis patients and previous TNF a blocker failure. Biologics, v. 6, p. 191–9, 2012.  
2. WAKABAYASHI H. et al. Which subgroup of rheumatoid arthritis patients benefits from switching to tocilizumab versus etanercept after previous infliximab failure? A retrospective study. Mod Rheumatol. v. 22, p. 116–21, 2012.  
3. FINCKH A. et al. on behalf of the physicians of the Swiss ClinicalQuality Management Program for Rheumatoid Arthritis. B cell depletion may be more effective than switching to an alternative anti–tumor necrosis factor agent in rheumatoid arthritis patients with inadequate response to anti–tumor necrosis factor agents. Arthritis Rheum, v. 56, p.1417–23, 2007.  
4. EMERY P. et al. Sustained remission with etanercept tapering in early rheumatoid arthritis. N Engl J Med, v. 371, p.1781–92, 2014.  
5. Gottenberg J. et al. Non–TNF-Targeted Biologic vs a Second Anti-TNF Drug to Treat Rheumatoid Arthritis in Patients With Insufficient Response to a First Anti-TNF Drug A Randomized Clinical Trial. JAMA, v. 316, p. 1172-1180, 2016.  
**QUESTÃO 15: DEVEMOS USAR MMCDbio não anti-TNF EM VEZ DE OUTRO MMCDbio anti-TNF EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MMCDbio anti-TNF?**  
**<u>Recomendação 15:</u> Sugerimos usar MMCDbio anti-TNF ou MMCDbio não anti-TNF em pacientes com AR estabelecida de moderada ou alta atividade da doença quefalharam à terapia aos MMCDbio anti-TNF e não toleram MMCDs (efeitos adversos ou toxicidade) (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Três estudos observacionais e um ensaio clínico randomizado (ECR) avaliaram o Escore da atividade de doença (DAS-28), três estudos observacionais avaliaram o questionário de avaliação de saúde (HAQ) e um estudo observacional avaliou efeitos adversos graves e mortalidade. Em comparação com MMCDbio anti-TNF, MMCDbio não antiTNF não alterou a média de DAS-28 (estudos observacionais: DM 0,02, IC95% -0,16 a 0,2, qualidade da evidência muito baixa; ECR: DM 0,09, IC95% -0,3 a 0,49, qualidade da evidência baixa), não alterou a média do HAQ (DMP 0,3, IC95%-0,02 a 0,63, qualidade da evidência muito baixa) e não alterou o risco de efeitos adversos graves e mortalidade (sem evento em ambos os grupos, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes que falharam a um MMCDbio anti-TNF, é aceitável a sua substituição por um</u> outro MMCDbio anti-TNF ou então por um MMCDbio não anti-TNF, dada a eficácia e segurança semelhantes destas classes. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente nos pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
1. KEKOW J, MUELLER-LADNER U, SCHULZE-KOOPS H. Rituximab is more effective than second anti-TNF therapy in rheumatoid arthritis patients and previous TNF a blocker failure. Biologics, v. 6, p. 191–9, 2012.  
2. CHATZIDIONYSIOU K, VAN VOLLENHOVEN RF. Rituximab versus anti-TNF in patients who previously failed one TNF inhibitor in an observational cohort. Scand J Rheumatol, v. 42, p. 190–5, 2013.  
80  
3. SOLIMAN M. M. et al. Rituximab or a second anti–tumor necrosis factor therapy for rheumatoid arthritis patients who have failed their first anti–tumor necrosis factor therapy? Comparative analysis from the British Society for Rheumatology Biologics Register. Arthritis Care Res (Hoboken), v. 64, p. 1108–15, 2012.  
4. MANDERS H.M.M. et al. Cost-effectiveness of abatacept, rituximab, and TNFi treatment after previous failure with TNFi treatment in rheumatoid arthritis: a pragmatic multi-centrerandomised trial. ArthritisResearch&Therapy, v. 17, p.134, 2015.  
**QUESTÃO 16: DEVEMOS USAR MMCDbio não anti-TNF + MTX EM VEZ DE OUTRO MMCDbio anti-TNF + MTX EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MÚLTIPLOS MMCDbio anti-TNF?**  
**<u>Recomendação 16: sugerimos usar MMCDbio não anti-TNF + MTX em vez de MMCDbio anti-TNF + MTX em</u> pacientes com AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio anti-TNF (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Um estudo observacional avaliou o Escore da atividade de doença (DAS-28) e dois estudos observacionais avaliaram infecções graves. Em comparação com MMCDbio anti-TNF + MTX, MMCDbio não anti-TNF + MTX não alterou a média de DAS-28 (DM 0,35, IC95% -0,1 a 0,8, qualidade da evidência muito baixa) e não alterou o risco de infecções graves (RR 0,94, IC95% 0,76 a 1,15, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Nos pacientes com múltiplas falhas (pelo menos duas) a MMCDbio anti-TNF + MTX, pode-</u> se substituir o MMCDbio anti-TNF por um medicamento com mecanismo de ação diferente (por exemplo: MMCDbio não antiTNF + MTX). O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento, conforme discutido na recomendação 18.  
1. FINCKH A. et al. Which subgroup of patients with rheumatoid arthritis benefits from switching to rituximab versus alternative anti-tumour necrosis factor (TNF) agents after previous failure of an anti-TNF agent? Ann Rheum Dis, v. 69, p. 387– 393, 2010.  
2. JOHNSTON S.S. et al. Risk of infections in rheumatoid arthritis patients switching from anti-TNF agents to rituximab, abatacept, or another anti-TNF agent: a retrospective administrative claims analysis. Semin Arthritis Rheum, v. 43, p. 39–47, 2013.  
3. HARROLD L.R. et al. Comparative effectiveness and safety of rituximab versus subsequent anti–tumor necrosis factor therapy in patients with rheumatoid arthritis with prior exposure to anti–tumor necrosis factor therapies in the United States Corrona registry. ArthritisResearch&Therapy, v. 17, p. 256-266, 2015  
**QUESTÃO 17. DEVEMOS USAR MMCDbio não anti-TNF EM VEZ DE OUTRO MMCDbio anti-TNF EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MÚLTIPLOS MMCDbio anti-TNF?**  
**<u>Recomendação 17: Sugerimos usar MMCDbio não anti-TNF em vez de MMCDbio anti-TNF em pacientes com</u> AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio anti-TNF (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Dois estudos observacionais avaliaram o Escore da atividade de doença (DAS-28), um estudo avaliou a boa resposta ao EULAR e um estudo avaliou o risco de infecções graves. Em comparação com MMCDbioanti-TNF, 81  
MMCDbio não anti-TNF diminuiu a média de DAS-28 (DM -0,3, IC95% -0,56 a -0,03, qualidade da evidência muito baixa), alterou o número de pacientes com boa resposta ao EULAR em 60% (RR 1,60, IC95% 1,23 a 2,10, qualidade da evidência muito baixa) e não alterou o risco de infecções graves (RR 0,95, IC95% 0,77 a 1,17, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Nos pacientes com múltiplas falhas (pelo menos duas) a MMCDbio anti-TNF monoterapia,</u> pode-se substituir o MMCDbio anti-TNF por um medicamento com mecanismo de ação diferente (por exemplo: MMCDbio não anti-TNF). O tofacitinibe é outra alternativa terapêutica nesses casos, conforme discutido na Recomendação 19. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente nos pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
1. JOHNSTON S.S. et al. Risk of infections in rheumatoid arthritis patients switching from anti-TNF agents to rituximab, abatacept, or another anti-TNF agent: a retrospective administrative claims analysis. SeminArthritisRheum, v. 43, p. 39–47, 2013.  
2. GOMEZ-REINO J.J. et al. Comparative effectiveness of switching to alternative tumour necrosis factor (TNF) antagonists versus switching to rituximab in patients with rheumatoid arthritis who failed previous TNF antagonists: the MIRAR Study. Ann RheumDis; v. 71, p. 1861–4, 2012.  
**QUESTÃO 18: DEVEMOS USAR TOFACITINIBE + MTX EM VEZ DE OUTRO MMCDbio anti-TNF + MTX EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MÚLTIPLOS MMCDbio anti-TNF?**  
**<u>Recomendação 18: Sugerimos usar tofacitinibe + MTX em vez de MMCDbio anti-TNF + MTX em pacientes com</u> AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio anti-TNF (qualidade de evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Para a avaliação dessa questão, foram usadas evidências indiretas de um estudo que incluiu pacientes que falharam ao uso de MMCD sintéticos, e não falha a terapia com MMCDbio anti-TNF. Esse estudo avaliou o Escore da atividade de doença (DAS-28), a resposta aos critérios do ACR 20, o questionário de avaliação de saúde (HAQ), os efeitos adversos graves, as infecções graves e a hepatotoxicidade. Em comparação com MMCDbio anti-TNF + MTX, tofacitinibe + MTX não alterou o número de pacientes com DAS-28 < 2,6 (RR 0,92, IC95% 0,42 a 2,03, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 20 (RR 1,09, IC95% 0,89 a 1,33, qualidade da evidência baixa), diminuiu a média do HAQ (DM -0,06, IC95% -0,07 a -0,05, qualidade da evidência baixa), não alterou o risco de efeitos adversos graves (RR 1,43, IC95% 0,55 a 3,68, qualidade da evidência baixa), não alterou o risco de infecções graves (RR 2,00, IC95% 0,18 a 21, 88, qualidade da evidência baixa) e não alterou o risco de hepatotoxicidade medido por TGO > 3x o limite superior da normalidade (RR 3,01, IC95% 0,12 a 73,57, qualidade da evidência baixa) ou por TGP > 3x o limite superior da normalidade (RR 5,02, IC95% 0,24 a 104,01, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Nos pacientes com múltiplas falhas (pelo menos duas) a MMCDbio anti-TNF + MTX, pode-</u> se substituir o MMCDbio por um medicamento com mecanismo de ação diferente. Nesses casos, o tofacitinibe e os MMCDbio não anti-TNF (recomendação 16) podem ser usados. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente em pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
82  
1. VAN VOLLENHOVEN R. F. Conventional combination treatment versus biological treatment in methotrexate‐ refractory early rheumatoid arthritis: 2-year follow‐up of the randomised, non‐blinded, parallel‐group Swefot trial. Lancet, v. 379, n. 9827, p. 1712‐1720, 2012.  
**QUESTÃO 19: DEVEMOS USAR TOFACITINIBE EM VEZ DE OUTRO MMCDbio anti-TNF EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MÚLTIPLOS MMCDbio anti-TNF?**  
**<u>Recomendação 19: Sugerimos usar tofacitinibe em vez de MMCDbio anti-TNF em pacientes com AR estabelecida</u> de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio anti-TNF (qualidade de evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Para a avaliação dessa questão, foram usadas evidências indiretas de um estudo que incluiu pacientes que falharam ao uso de MMCD sintéticos e não falha a terapia com MMCDbio anti-TNF. Esse estudo avaliou a resposta aos critérios do ACR 20, a resposta aos critérios do ACR 50, a resposta aos critérios do ACR 70, o questionário de avaliação de saúde (HAQ), efeitos adversos graves, infecções graves e hepatotoxicidade. Em comparação com MMCDbio anti-TNF, tofacitinibe aumentou a resposta aos critérios ACR 20 (RR 1,65, IC95% 1,08 a 2,53, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 50 (RR 1,95, IC95% 1,00 a 3,80, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 70 (RR 3,24, IC95% 0,69 a 15,33, qualidade da evidência baixa), não alterou a média do HAQ (DM -0,19, IC95% -0,49 a 0,11, qualidade da evidência baixa), não alterou o risco de efeitos adversos graves (RR 0,36, IC95% 0,02 a 8,63, qualidade da evidência muito baixa), não alterou o risco de infecções graves (sem eventos em ambos os grupos, qualidade da evidência muito baixa) e não alterou o risco de hepatotoxicidade (RR 0,36, IC95% 0,02 a 8,63, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Nos pacientes com múltiplas falhas (pelo menos duas) a MMCDbio anti-TNF, pode-se</u> substituí-lo por um medicamento com mecanismo de ação diferente. Nesses casos, o tofacitinibe e os MMCDbio não anti-TNF (recomendação 17) podem ser usados. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente em pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
1. FLEISCHMANN R. et al. Placebo-controlled trial of tofacitinib monotherapy in rheumatoid arthritis. N Engl J Med, v.367, p .495–507, 2012.  
**QUESTÃO 20: DEVEMOS USAR TOFACITINIBE + MTX EM VEZ DE OUTRO MMCDbio anti-TNF + MTX EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MMCDbio anti-TNF E MMCDbio não anti-TNF?**  
**<u>Recomendação 20: Sugerimos usar tofacitinibe + MTX em vez de MMCDbio anti-TNF + MTX em pacientes com</u> AR estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbio anti-TNF e MMCDbio não anti-TNF (qualidade de evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Para a avaliação dessa questão, foram usadas evidências indiretas. Dois estudos avaliaram o Escore da atividade de doença (DAS-28) em 6 meses e um em 12 meses, dois estudos avaliaram a melhora das respostas aos critérios do ACR 20 em 6 meses e um em 12 meses, um estudo avaliou a melhora das respostas aos critérios do ACR 50 em 12 meses, um estudo avaliou a melhora das respostas aos critérios do ACR 70 em 12 meses, dois estudos avaliaram o questionário  
83  
de avaliação de saúde (HAQ), dois estudos avaliaram os efeitos adversos graves, dois estudos avaliaram infecções graves, dois estudos avaliaram hepatotoxicidade e um estudo avaliou neoplasias. Em comparação com tofacitinibe + MTX, MMCDbio antiTNF + MTX não alterou o número de pacientes com DAS-28 < 2,6 em 6 meses (RR 1,05, IC95% 0,74 a 1,48, qualidade da evidência muito baixa) ou em 12 meses (RR 1.17, IC95% 0,84 a 1,62, qualidade da evidência muito baixa), não alterou a resposta aos critérios ACR 20 em 6 meses (RR 0,96, IC95% 0,89 a 1,04, qualidade da evidência muito baixa) ou em 12 meses (RR 0,96, IC95% 0,88 a 1,06, qualidade da evidência muito baixa), não alterou a resposta aos critérios ACR 50 (RR 0,96, IC95% 0,83 a 1,12, qualidade da evidência muito baixa), não alterou a resposta aos critériosACR 70 (RR 0,89, IC95% 0,71 a 1,13, qualidade da evidência muito baixa), não alterou a média do HAQ-DI (DM 0,04, IC95% -0,04 a 0,11, qualidade da evidência muito baixa), não alterou o risco de efeitos adversos graves (RR 0,82, IC95% 0,52 a 1,31, qualidade da evidência muito baixa), não alterou o risco de infecções graves (RR 0,57, IC95% 0,23 a 1,44, qualidade da evidência muito baixa), não alterou o risco de hepatotoxicidade (RR 0,86, IC95% 0,54 a 1,36 , qualidade da evidência muito baixa) e não alterou o risco de neoplasias (sem eventos em ambos os grupos, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Nos pacientes com falhas tanto a MMCDbio anti-TNF + MTX quanto a MMCDbio não TNF</u> + MTX, o MMCDbio pode ser substituído pelo tofacitinibe + MTX, uma vez que apresenta mecanismo de ação diferente. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente em pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
1. VAN VOLLENHOVEN R. F. Conventional combination treatment versus biological treatment in methotrexate‐ refractory early rheumatoid arthritis: 2-year follow‐up of the randomised, non‐blinded, parallel‐group Swefot trial. Lancet, v. 379, n. 9827, p. 1712‐1720, 2012.  
2. FLEISCHMANN R. et al.Efficacy and safety of tofacitinib monotherapy, tofacitinib with methotrexate, and adalimumab with methotrexate in patients with rheumatoid arthritis (ORAL Strategy): a phase 3b/4, double-blind, head-to-head, randomised controlled trial.Lancet, v.17, p .31618-5, 2017.  
**QUESTÃO 21: DEVEMOS USAR TOFACITINIBE EM VEZ DE OUTRO MMCDbio anti-TNF EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA QUE FALHARAM À TERAPIA AOS MMCDbioanti-TNF e MMCDbio não anti-TNF?**  
**<u>Recomendação 21: Sugerimos usar tofacitinibe em vez de MMCDbio anti-TNF em pacientes com AR estabelecida</u> de moderada ou alta atividade da doença que falharam à terapia aos MMCDbioanti-TNF e MMCDbio não anti-TNF (qualidade de evidência baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Para a avaliação dessa questão, foram usadas evidências indiretas. Um estudo avaliou a resposta aos critérios do ACR 20, a resposta aos critérios do ACR 50, a resposta aos critérios do ACR 70, o questionário de avaliação de saúde (HAQ-DI), os efeitos adversos graves, as infecções graves e a hepatotoxicidade. Em comparação com MMCDbio antiTNF, tofacitinibe aumentou a resposta aos critérios ACR 20 (RR 1,65, IC95% 1,08 a 2,53, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 50 (RR 1,95, IC95% 1,00 a 3,80, qualidade da evidência baixa), não alterou a resposta aos critérios ACR 70 (RR 3,24, IC95% 0,69 a 15,33, qualidade da evidência baixa), não alterou a média do HAQ-DI (DM -0,19, IC95% -0,49 a 0,11, qualidade da evidência baixa), não alterou o risco de efeitos adversos graves (RR 0,36, IC95% 0,02 a 8,63, qualidade da evidência muito baixa), não alterou o risco de infecções graves (sem eventos em ambos os grupos, qualidade da  
84  
evidência muito baixa) e não alterou o risco de hepatotoxicidade (RR 0,36, IC95% 0,02 a 8,63, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com falhas tanto a MMCDbio anti-TNF quanto a MMCDbio não TNF, o</u> MMCDbio pode ser substituído pelo tofacitinibe, uma vez que apresenta mecanismo de ação diferente. O tofacitinibe é mais associado a herpes zóster. O tofacitinibe tem como vantagens a possibilidade de ser usado por via oral e não necessitar de refrigeração para armazenamento. Esses medicamentos devem ser associados a MMCDs, preferencialmente ao MTX, sempre que possível. Usar monoterapia somente em pacientes que apresentam intolerância ou toxicidade aos MMCDs.  
1. FLEISCHMANN R. et al. Placebo-controlled trial of tofacitinib monotherapy in rheumatoid arthritis. N Engl J Med , v.367, p .495–507, 2012.  
**QUESTÃO 22: DEVEMOS ADICIONAR GLICOCORTICOIDES EM ALTAS DOSES POR CURTO PRAZO AOS MMCDs EM PACIENTES COM ARTRITE REUMATOIDE ESTABELECIDA DE MODERADA OU ALTA ATIVIDADE DA DOENÇA EM SURTO AGUDO DA DOENÇA?**  
**<u>Recomendação 22:</u> Sugerimos não adicionar glicocorticoides em altas doses por curto prazo aos MMCDs em pacientes com AR estabelecida de moderada ou alta atividade da doença em surto agudo da doença (qualidade da evidência muito baixa, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Dois estudos avaliaram o Escore da atividade de doença (DAS-28), três estudos avaliaram o questionário de avaliação de saúde (HAQ), um estudo avaliou a melhora das respostas aos critérios do ACR 20, um estudo avaliou a melhora das respostas aos critérios do ACR 50, um estudo avaliou a melhora das respostas aos critérios do ACR 70, um estudo avaliou a progressão radiográfica pelo escore Larsen e dois estudos avaliaram efeitos adversos graves. A adição de glicocorticoides em alta dose por curto período não alterou a média do DAS-28 (DM -0,37, IC95% -0,89 a 0,15, qualidade da evidência baixa), não alterou a média do HAQ (DM -0,12, IC95% -0,37 a 0,12, qualidade da evidência muito baixa), não alterou a resposta aos critérios do ACR 20 (RR 1,71, IC95% 0,94 a 3,14, qualidade da evidência muito baixa), não alterou a resposta aos critérios do ACR 50 (RR 1,54, IC95% 0,71 a 3,35, qualidade da evidência muito baixa), não alterou a resposta aos critérios do ACR 70 (RR 3,43, IC95% 0,89 a 13,15, qualidade da evidência muito baixa), diminui o escore de Larsen em média 20,59 pontos (em comparação, placebo reduziu em média 2,77 pontos, qualidade da evidência muito baixa) e não alterou o risco de efeitos adversos graves (RR 2,05, IC95% 0,49 a 8,51, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR estabelecida de moderada ou alta atividade e em surto agudo da</u> doença, glicocorticoides podem ser empregados na menor dose e no menor período de tempo possível, devido ao risco de efeitos adversos. Sugerimos não adicionar glicocorticoides em altas doses, exceto em manifestações extra-articulares que levam a risco de vida ou perda de função/órgão (por exemplo: vasculite, neurite, pneumonite).  
1. CHOY E.H. et al. A two year randomised controlled trial of intramuscular depot steroids in patients with established rheumatoid arthritis who have shown an incomplete response to disease modifying antirheumatic drugs. Ann Rheum Dis, v. 64, p. 1288–93, 2005.  
2. DUREZ P. et al. Treatment of early rheumatoid arthritis: a randomized magnetic resonance imaging study comparing the effects of methotrexate alone, methotrexate in combination with infliximab, and methotrexate in combination with intravenous pulse methylprednisolone. Arthritis Rheum, v. 56, p. 3919–27, 2007.  
3. CICONELLI R.M. et al. A randomized double-blind controlled trial of sulphasalazine combined with pulses of methylprednisolone or placebo in the treatment of rheumatoid arthritis. Br J Rheumatol, v. 35, p. 150–4, 1996.  
85

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 23: Sugerimos não adicionar glicocorticoides em baixas doses por longo prazo aos MMCDs em</u> pacientes com AR estabelecida de moderada ou alta atividade da doença (qualidade da evidência moderada, recomendação fraca).**  
**<u>Resumo das evidências:</u>** Dois estudos avaliaram o Escore da atividade de doença (DAS-28), um estudo avaliou a melhora das respostas aos critérios do ACR 20, três estudos avaliaram o questionário de avaliação de saúde (HAQ), um estudo avaliou o componente físico do SF-36, um estudo avaliou o componente mental do SF-36, dois estudos avaliaram os efeitos adversos graves, dois estudos avaliaram efeitos adversos cardiovasculares (principalmente hipertensão) e um estudo avaliou osteoporose. A adição de glicocorticoides em baixas doses por longo prazo diminui a média do DAS-28 (DM -0,49, IC95% -0,73 a -0,35, qualidade da evidência alta), aumentou a resposta aos critérios do ACR 20 em 59% (RR 1,59, IC95% 1,17 a 2,15, qualidade da evidência alta), diminui a média do HAQ (DM -0,32, IC95% -0,36 a -0,29, qualidade da evidência alta), aumentou a média do componente físico do SF-36 (DM 2,4, IC95% 0,74 a 4,06, qualidade da evidência moderada), não alterou a média do componente mental do SF-36 (DM 1,00, IC95% -0,94 a 2,94, qualidade da evidência baixa), não alterou o risco de efeitos adversos graves (RR 0,87, IC95% 0,13 a 5,93, qualidade da evidência muito baixa), não alterou o risco de efeitos adversos cardiovasculares (RR 2,81, IC95% 0,62 a 12,69, qualidade da evidência baixa) e não alterou o risco de osteoporose (RR 4,49, IC95% 0,22 a 90,99, qualidade da evidência baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR estabelecida não se sugere o uso de glicocorticoides devido ao perfil</u> de eventos adversos. O uso de corticoide em baixas doses em longo prazo estaria indicado em casos particulares por decisão compartilhada entre médico e paciente, com o objetivo de promover melhor controle sintomático, em especial quando não se obtém controle adequado com MMCDs. Nesse caso, é importante salientar que a necessidade de glicocorticoides em associação aos MMCDspara controle sintomático é sugestivo de falha terapêutica, devendo ser considerado o início de MMCDbio.  
1. BUTTGEREIT F. et al. Low-dose prednisone chronotherapy for rheumatoid arthritis: a randomised clinical trial (CAPRA-2). Ann Rheum Dis, v. 72, p. 204–10, 2013.  
2. CHOY E.H. et al. A two year randomised controlled trial of intramuscular depot steroids in patients with established rheumatoid arthritis who have shown an incomplete response to disease modifying antirheumatic drugs. Ann Rheum Dis, v. 64, p. 1288–93, 2005.  
3. HANSEN M.et al. A randomised trial of differentiated prednisolone treatment in active rheumatoid arthritis: clinical benefits and skeletal side effects. Ann RheumDis, v. 58, p. 713–8, 1999.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**<u>Recomendação 24: Sugerimos não adicionar glicocorticoides em baixas doses por longo prazo aos MMCDbio anti-</u> TNF em pacientes com AR estabelecida de moderada ou alta atividade da doença (qualidade da evidência muito baixa, recomendação fraca).**  
**<u>Resumo da evidência:</u>** <u>Um estudo avaliou o Escore da atividade de doença (DAS-28) com ponto de corte para remissão</u> de < 1,6. A adição de glicocorticoide em baixas doses em longo prazo não alterou o número de pacientes com DAS-28 < 1,6  
86  
(RR 1,31, IC95% 0,90 a 1,90, qualidade da evidência muito baixa). Mais detalhes podem ser encontrados nos Perfis de evidência no final deste arquivo.  
<u>Considerações terapêuticas: Em pacientes com AR estabelecida não se sugere o uso de glicocorticoides devido ao perfil</u> de eventos adversos. O uso de corticoide em baixas doses em longo prazo estaria indicado em casos particulares por decisão compartilhada entre médico e paciente, com o objetivo de promover melhor controle sintomático, em especial quando não se obtém controle adequado com MMCDs.  
1. TODOERTI M. et al. Early disease control by low-dose prednisone comedication may affect the quality of remission in patients with early rheumatoid arthritis. Ann N Y AcadSci, v. 1193, p. 139–45, 2010.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
Muito se desconhece ainda da epidemiologia local da AR. Estudos atuais de prevalência da Artrite Reumatoide na zona urbana, mas particularmente em áreas remotas e em populações específicas (zona rural e indígenas) são importantes para o planejamento a nível de saúde pública. Nesse contexto, salienta-se iniciativas como coorte prospectiva nacionalmente representativa que descreve características demográficas, socioeconômicas e clínicas de 1.125 pacientes das 5 regiões do Brasil14.  
Também é indispensável a manutenção de registros de pacientes com AR, como o BIOBADABRASIL (Registro Brasileiro de Monitorização de Terapias Biológicas em Doenças Reumáticas), estudo observacional prospectivo de duração indeterminada para se analisar as características dos pacientes e efeitos adversos dos tratamentos, fundamentando ações de condutas clínicas baseadas na realidade brasileira.  
Adicionalmente, não restrito ao contexto brasileiro, há questões relevantes relacionadas à terapia com os MMCDs. É necessário o desenvolvimento de pesquisa, assim como a periódica revisão da literatura científica internacional em busca de avanços nas seguintes frentes:  
- Avaliação da efetividade e segurança da combinação de metotrexato e leflunomida;  
- Avaliação da efetividade de biossimilares;  
- Critérios para permitir switch entre MMCDbio e biossimilares, e switch de biossimilares entre si;  
- Critérios para espaçar administração ou retirar MMCDbio;  
- Avaliação de segurança de MMCD para concepção, na gestação e amamentação;  
Estudos longitudinais de farmacovigilância e uso de registros para monitorar efeitos adversos no tratamento de AR e efetividade do tratamento.  
87

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
**Questão 1. Devemos usar terapia combinada dupla com MMCDs em vez da monoterapia MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença sem tratamento prévio com MMCDs?**  
|№ de<br>Risco de||Avaliação da<br>Evidência|qualidade||Qualidade geral|<br>Taxas de eve<br>(%)|<br>ntos do estudo|Sumário de resu<br>Efeito|ltados<br>Efeitos abso<br>potenciais|lutos<br>Ri|
|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)<br>viés<br>Escore (ou pontua<br>105<br>(2 ECRs)<br>Não grave<br>Melhora da respos|Inconsistência<br>ção) da atividade d<br>Não grave<br>ta ACR 20 (ativida|indireta<br>e doença (DAS) (ma<br>Não grave<br>de da doença AR)|Imprecisão<br>ior pontuação i<br>Gravea|Outros<br>ndica atividade de<br>Nenhumb|<br>da evidência<br>doença mais grave<br>⨁⨁⨁◯<br>MODERADA|<br>Risco com<br>monoterapia<br>MMCD<br>); DMI = -1,17<br>69|Risco com<br>terapia dupla<br>MMCD<br>(Escala de: 0 p<br>36|relativo(IC95%<br>)<br>ara 9,4)<br>-|Risco com<br>monoterapi<br>a MMCD<br>A média da<br>DAS foi 0|sco com<br>terapia<br>dupla<br>MMCD<br>DM 0,05<br>menor<br>(0,38 menor<br>para 0,28<br>maior)|
|373<br>(2 ECRs)<br>Não grave<br>Melhora da respos|Não grave<br>ta ACR 50 (ativida|Gravec<br>de da doença AR)|Não grave|Nenhumb|⨁⨁⨁◯<br>MODERADA|34/187<br>(18,2%)|76/186<br>(40,9%)|RR 2,26<br>(1,60 para<br>3,21)|182 por<br>1.000|229 mais<br>por 1.000<br>(109 mais<br>para 402<br>mais)|  
88  
|№ de|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade geral|<br>Taxas de even<br>(%)|<br>tos do estudo|Sumário de result<br>Efeito|ados<br>Efeitos abso<br>potenciais|lutos<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)|<br>viés|Inconsistência|<br>indireta|Imprecisão|Outros|<br>da evidência|<br>Risco com<br>monoterapia<br>MMCD|Risco com<br>terapia dupla<br>MMCD|relativo(IC95%<br>)|Risco com<br>monoterapi<br>a MMCD|Risco com<br>terapia<br>dupla<br>MMCD|
|373<br>(2 ECRs)<br>Mel|Não grave<br>hora da respos|Não grave<br>ta ACR 70 (atividad|Gravec<br>e da doença AR)|Graved|Nenhumb|⨁⨁◯◯<br>BAIXA|12/187<br>(6,4%)|40/186<br>(21,5%)|RR 2,80<br>(0,97 para<br>8,07)|64 por<br>1.000|116 mais<br>por 1.000<br>(2 menos<br>para 454<br>mais)|
|373<br>(2 ECRs)<br>Que|Não grave<br>stionário de a|Não grave<br>valiação de saúde (H|Gravec<br>AQ) (maior pontua|Graved<br>ção indica ativi|Nenhumb<br>dade de doença m|⨁⨁◯◯<br>BAIXA<br>ais grave) DMI = -0|4/187 (2,1%)<br>,2 (Escala de: 0|15/186<br>(8,1%)<br>para 3)|RR 3,71<br>(1,24 para<br>11,08)|21 por<br>1.000|58 mais por<br>1.000<br>(5 mais<br>para 216<br>mais)|  
89  
|№ de|Risco de||Avaliação d<br>Evidência|a qualidade||Qualidade geral|<br>Taxas de eve<br>(%)|S<br>ntos do estudo|umário de result<br>Efeito|ados<br>Efeitos abso<br>potenciais|lutos<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)|<br>viés|Inconsistência|<br>indireta|Imprecisão|Outros|<br>da evidência|<br>Risco com<br>monoterapia<br>MMCD|Risco com<br>terapia dupla<br>MMCD|relativo(IC95%<br>)|Risco com<br>monoterapi<br>a MMCD|Risco com<br>terapia<br>dupla<br>MMCD|
|368<br>(3 ECRs)<br>Porc<br>137<br>(1 ECR)<br>Desc|Não grave<br>entagem de p<br>Não grave<br>ontinuação p|Não grave<br>acientes com progres<br>Não grave<br>or efeitos adversos|Não grave<br>são radiográfica<br>Não grave|Gravea<br>detectável (Escor<br>Gravee|Nenhumb<br>e Sharp) (tempo d<br>Nenhumb|⨁⨁⨁◯<br>MODERADA<br>e seguimento: 12 m<br>⨁⨁⨁◯<br>MODERADA|202<br>eses)<br>11/69<br>(15,9%)|166<br>6/68 (8,8%)|-<br>RR 0,55<br>(0,22 para<br>1,41)|A média do<br>HAQ; DMI<br>= -0,2 foi 0<br>159 por<br>1.000|<br>DM 0,08<br>menor<br>(0,46 menor<br>para 0,3<br>maior)<br>72 menos<br>por 1.000<br>(124 menos<br>para 65<br>mais)|  
90  
|№ de<br>participante<br>s (estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade geral<br>da evidência|<br>Taxas de eve<br>(%)<br>Risco com<br>monoterapia<br>MMCD|S<br>ntos do estudo<br>Risco com<br>terapia dupla<br>MMCD|umário de result<br>Efeito<br>relativo(IC95%<br>)|ados<br>Efeitos abso<br>potenciais<br>Risco com<br>monoterapi<br>a MMCD|lutos<br>Risco com<br>terapia<br>dupla<br>MMCD|
|---|---|---|---|---|---|---|---|---|---|---|---|
|471<br>(3 ECRs)|Não grave|Não grave|Não grave|Gravef|Nenhumb|⨁⨁⨁◯<br>MODERADA|18/237<br>(7,6%)|30/234<br>(12,8%)|RR 1,67<br>(0,96 para<br>2,92)|76 por<br>1.000|51 mais por<br>1.000<br>(3 menos<br>para 146<br>mais)|  
AR, artrite reumatoide; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Intervalos de confiança amplos em torno da estimativa do efeito devido ao pequeno tamanho da amostra15.  
b. Número insuficiente de estudos para avaliar o Outros.  
c. Evidência indireta: esse PICO aborda pacientes com AR recente e nenhuma falha prévia de fármacos antirreumáticos modificadores da doença (DMARD), no entanto, os pacientes neste estudo tinham previamente administrados monoterapia com sulfasalazina e não conseguiram atingir um índice DAS inferior a 2,416.  
d. Intervalos de confiança amplos em torno da estimativa do efeito devido ao pequeno tamanho da amostra16.  
e. Intervalos de confiança amplos em torno da estimativa do efeito devido ao pequeno tamanho da amostra17.  
f. Intervalos de confiança amplos em torno da estimativa do efeito devido ao pequeno tamanho da amostra17,15.  
91  
**Questão 2. Devemos usar terapia combinada tripla com MMCDs em vez da monoterapia com MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença, sem tratamento prévio com MMCDs?**  
|№ de|Risco de||Avaliação d<br>Evidência|a qualidade||Qualidade geral|Taxas de even<br>(%)|S<br>tos do estudo|umário de result<br>Efeito|ados<br>Efeitos abso<br>potenciais|lutos<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)<br>Esco<br>481<br>(3 ECRs)<br>Melh<br>689<br>(2 ECRs)<br>Ques|viés<br>re (ou pontua<br>Grave a<br>ora da respos<br>Não grave<br>tionário de a|Inconsistência<br>ção) da atividade de<br>Grave b<br>ta ACR 50 (atividad<br>Não grave<br>valiação de saúde (H|indireta<br>doença (DAS-28<br>Não grave<br>e da doença AR)<br>Não grave<br>AQ) (maior pont|Imprecisão<br>); DMI = -1,17 (te<br>Não grave<br>(tempo de seguim<br>Não grave<br>uação indica ativi|Outros<br>mpo de seguim<br>Nenhum<br>ento: variação 6<br>Nenhum<br>dade de doença|<br>da evidência<br>ento: variação 3-24<br>⨁⨁◯◯<br>BAIXA<br>-24 meses)<br>⨁⨁⨁⨁<br>ALTA<br>mais grave) DM = -|Risco com<br>monoterapia<br>MMCD<br>meses)<br>242<br>125/470<br>(26,6%)<br>0,375|Risco com<br>terapia tripla<br>MMCD<br>239<br>107/219<br>(48,9%)|relativo(IC95%<br>)<br>-<br>RR 1,41<br>(1,18 para<br>1,69)|Risco com<br>monoterapi<br>a MMCD<br>A média do<br>DAS-28foi<br>0<br>266 por<br>1.000|Risco com<br>terapia<br>tripla<br>MMCD<br> <br>DM 0,27<br>menor<br>(0,62 menor<br>para 0,08<br>maior)<br>109 mais<br>por 1.000<br>(48 mais<br>para 184<br>mais)|  
92  
|№ de|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade geral|<br>Taxas de even<br>(%)|S<br>tos do estudo|umário de result<br>Efeito|ados<br>Efeitos abso<br>potenciais|lutos<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)|<br>viés|Inconsistência|<br>indireta|Imprecisão|Outros|<br>da evidência|<br>Risco com<br>monoterapia<br>MMCD|Risco com<br>terapia tripla<br>MMCD|relativo(IC95%<br>)|Risco com<br>monoterapi<br>a MMCD|Risco com<br>terapia<br>tripla<br>MMCD|
|160<br>(1 ECR)<br>Efeit<br>992<br>(4 ECRs)<br>Infec|Grave c<br>os adversos g<br>Não grave<br>ções (tempo|Não grave<br>raves (tempo de seg<br>Não grave<br>de seguimento: varia|Não grave<br>uimento: variaçã<br>Não grave<br>ção 3 meses para|Grave d<br>o 3-24 meses)<br>Grave e<br>6 meses)|Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>⨁⨁⨁◯<br>MODERADA|82<br>63/621<br>(10,1%)|78<br>33/371 (8,9%)|-<br> <br>RR 1,04<br>(0,69 para<br>1,57)|A média do<br>HAQ foi 0<br>101 por<br>1.000|<br>DM 0,12<br>menor<br>(0,29 menor<br>para 0,05<br>maior)<br>4 mais por<br>1.000<br>(31 menos<br>para 58<br>mais)|  
93  
|№ de|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade geral|<br>Taxas de even<br>(%)|S<br>tos do estudo|umário de result<br>Efeito|ados<br>Efeitos abso<br>potenciais|lutos<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)|<br>viés|Inconsistência|<br>indireta|Imprecisão|Outros|<br>da evidência|<br>Risco com<br>monoterapia<br>MMCD|Risco com<br>terapia tripla<br>MMCD|relativo(IC95%<br>)|Risco com<br>monoterapi<br>a MMCD|Risco com<br>terapia<br>tripla<br>MMCD|
|797<br>(3 ECRs)<br>Efeit<br>992<br>(4 ECRs)<br>Hepa|Não grave<br>os adversos g<br>Não grave<br>totoxicidade|Não grave<br>astrointestinais (tem<br>Não grave<br>(ALT acima de 2 ve|Não grave<br>po de seguimento<br>Não grave<br>zes o limite supe|Grave e<br>: variação 3-24 m<br>Grave e<br>rior do valor norm|Nenhum<br>eses)<br>Nenhum<br>al) (tempo de se|⨁⨁⨁◯<br>MODERADA<br>⨁⨁⨁◯<br>MODERADA<br>guimento: variação|59/523<br>(11,3%)<br>119/621<br>(19,2%)<br>3-24 meses)|54/274<br>(19,7%)<br>145/371<br>(39,1%)|RR 1,03<br>(0,78 para<br>1,36)<br>RR 1,48<br>(0,82 para<br>2,67)|113 por<br>1.000<br>192 por<br>1.000|3 mais por<br>1.000<br>(25 menos<br>para 41<br>mais)<br>92 mais por<br>1.000<br>(34 menos<br>para 320<br>mais)|  
94  
|№ de<br>participante<br>s (estudos)|Risco de<br>viés|Inconsistência|Avaliação d<br>Evidência<br>indireta|a qualidade<br>Imprecisão|Outros|Qualidade geral<br>da evidência|<br>Taxas de event<br>(%)<br>Risco com<br>monoterapia<br>MMCD|S<br>os do estudo<br>Risco com<br>terapia tripla<br>MMCD|umário de result<br>Efeito<br>relativo(IC95%<br>)|ados<br>Efeitos abso<br>potenciais<br>Risco com<br>monoterapi<br>a MMCD|lutos<br>Risco com<br>terapia<br>tripla<br>MMCD|
|---|---|---|---|---|---|---|---|---|---|---|---|
|481<br>(3 ECRs)|Não grave|Não grave|Não grave|Grave e|Nenhum|⨁⨁⨁◯<br>MODERADA|47/242<br>(19,4%)|31/239<br>(13,0%)|RR 0,68<br>(0,45 para<br>1,03)|194 por<br>1.000|62 menos<br>por 1.000<br>(107 menos<br>para 6<br>mais)|  
ALT, alanina aminotransferase; AR, artrite reumatoide; DM, diferença média; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
a. Dois 18,19 (de Jong et al., 2014; Saunders et al., 2008) de três estudos incluídos não foram blindados.  
b. I²= 74%.  
c. Apenas um estudo com tamanho amostral moderado (N = 162) incluído na análise.  
- d. Estudo simples cego.  
e. Grande intervalo de confiança, que inclui danos potenciais e benefícios.  
95  
**Questão 3. Devemos adicionar glicocorticoides em doses baixas por longos períodos aos MMCDs em vez de MMCDs sem glicocorticoides em pacientes com AR recente de moderada ou alta atividade da doença?**  
<!-- Start of picture text -->
Avalição da qualidade  Sumário de resultados<br>Taxas de eventos do estudo<br>Efeitos absolutos potenciais<br>(%)<br>№ de  Risco em  Risco  em<br>Qualidade  adicionar  Efeito  adicionar<br>participant Evidência  Risco com  Risco com<br>Risco de viés  Inconsistência  Imprecisão  Outros  geral da  relativo<br>es  indireta  glicocorticoid glicocorticoid<br>MMCD sem  MMCD sem<br>evidência  (IC95%)<br>es por longos  es por longos<br>(estudos)<br>glicocorticoid glicocorticoid<br>períodos em  períodos  em<br>es  es<br>doses baixas  doses baixas<br>aos MMCD  aos MMCD<br>Escore (ou pontuação) da atividade de doença (DAS-28); DMI = -1,17<br>DM 0,34<br>menor<br>1.118  ⨁⨁◯◯ A média do<br>Gravea  Graveb  Não grave  Não grave  Nenhumc  571  547  -  (0,82 menor<br>(7 ECRs)  BAIXA  DAS-28 foi 0<br>para 0,14<br>maior)<br>Remissão DAS-28<br>89 mais por<br>RR 1,29<br>1.012  ⨁⨁◯◯ 154/504  188/508  1.000<br>Gravea,d  Não grave  Não grave  Gravee  Nenhumc  (0,98 para  306 por 1.000<br>(6 ECRs)  BAIXA  (30,6%)  (37,0%)  (6 menos para<br>1,69)<br>211 mais)<br><!-- End of picture text -->  
96  
<!-- Start of picture text -->
Avalição da qualidade  Sumário de resultados<br>Taxas de eventos do estudo<br>Efeitos absolutos potenciais<br>(%)<br>№ de  Risco em  Risco  em<br>Qualidade  adicionar  Efeito  adicionar<br>participant Evidência  Risco com  Risco com<br>Risco de viés  Inconsistência  Imprecisão  Outros  geral da  relativo<br>es  indireta  glicocorticoid glicocorticoid<br>MMCD sem  MMCD sem<br>evidência  (IC95%)<br>es por longos  es por longos<br>(estudos)<br>glicocorticoid glicocorticoid<br>períodos em  períodos  em<br>es  es<br>doses baixas  doses baixas<br>aos MMCD  aos MMCD<br>Questionário de avaliação de saúde (HAQ) (maior pontuação indica atividade de doença mais grave) DM = -0,375<br>DM 0,04<br>menor<br>1.099  ⨁⨁⨁◯ A média do<br>Gravea  Não grave  Não grave  Não grave  Nenhumc  564  535  -  (0,2 menor<br>(7 ECRs)  MODERADA  HAQ foi 0<br>para 0,12<br>maior)<br>Porcentagem de pacientes com progressão radiográfica detectável (Escore Sharp) DMI = 5<br>DM 4,36<br>A média do  menor<br>607  ⨁⨁⨁◯<br>Gravea  Não grave  Não grave  Não grave  Nenhumc  317  290  -  Escore Sharp  (7,75 menor<br>(4 ECRs)  MODERADA<br>foi 0  para 0,98<br>menor)<br><!-- End of picture text -->  
97  
|№ de<br>participant<br>es<br>(estudos)<br>Efei<br>1.130<br>(5 ECRs)<br>Infe<br>558<br>(3 ECRs)<br>Hip|Risco de viés<br>tos adversos gra<br>Gravea<br>cções graves<br>Gravea<br>ertensão|Inconsistência<br>ves<br>Não grave<br>Não grave|Avalição da<br>Evidência<br>indireta<br>Não grave<br>Não grave|qualidade<br>Imprecisão<br>Gravee<br>Muitogravee|Outros<br>Nenhumc<br>Nenhumc|Qualidade<br>geral da<br>evidência<br>⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|Taxas de event<br>(%)<br>Risco com<br>MMCD sem<br>glicocorticoid<br>es<br>64/564<br>(11,3%)<br>9/283 (3,2%)|S<br>os do estudo<br>Risco em<br>adicionar<br>glicocorticoid<br>es por longos<br>períodos em<br>doses baixas<br>aos MMCD<br>60/566<br>(10,6%)<br>4/275 (1,5%)|umário de r<br>Efeito<br>relativo<br>(IC95%)<br>RR 0,94<br>(0,68 para<br>1,30)<br>RR 0,52<br>(0,18 para<br>1,50)|esultados<br>Efeitos absolu<br>Risco com<br>MMCD sem<br>glicocorticoid<br>es<br>113 por 1.000<br>32 por 1.000|tos potenciais<br>Risco<br>em<br>adicionar<br>glicocorticoid<br>es por longos<br>períodos<br>em<br>doses baixas<br>aos MMCD<br> <br>7 menos por<br>1.000<br>(36 menos<br>para 34 mais)<br>15 menos por<br>1.000<br>(26 menos<br>para 16 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
98  
|№ de<br>participant<br>es<br>(estudos)|Risco de viés|Inconsistência|Avalição da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros<br>Qualidade<br>geral da<br>evidência|Taxas de event<br>(%)<br>Risco com<br>MMCD sem<br>glicocorticoid<br>es|S<br>os do estudo<br>Risco em<br>adicionar<br>glicocorticoid<br>es por longos<br>períodos em<br>doses baixas<br>aos MMCD|umário de r<br>Efeito<br>relativo<br>(IC95%)|esultados<br>Efeitos absolu<br>Risco com<br>MMCD sem<br>glicocorticoid<br>es|tos potenciais<br>Risco<br>em<br>adicionar<br>glicocorticoid<br>es por longos<br>períodos<br>em<br>doses baixas<br>aos MMCD|
|---|---|---|---|---|---|---|---|---|---|---|
|657<br>(3 ECRs)|Gravea|Não grave|Não grave|Muitogravee|Nenhumc<br>⨁◯◯◯<br>MUITO<br>BAIXA|21/332 (6,3%)|25/325 (7,7%)|<br>RR 2,04<br>(0,40 para<br>10,40)|63 por 1.000|66 mais por<br>1.000<br>(38 menos<br>para 595<br>mais)|  
AR, artrite reumatoide; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Não está claro se os participantes e avaliadores foram cegados no estudo clínico randomizado (ECR)20,21.  
b. I2 = 86%.  
c. Número insuficiente de estudos para avaliar risco de viés.  
d. Participantes e avaliadores não foram cegados nos dois ECRs que contribuíram para essa análise22-25.  
e. O tamanho total da amostra é pequeno, e o número total de eventos é < 30022,23,20,21.  
99  
**Questão 4. Devemos usar MMCDbio anti-TNF + Metotrexato (MTX) em vez da terapia combinada tripla com MMCDs em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|№ de||Avaliação da q<br>|ualidade||Qualidade|Taxas de even|Su<br>tos do estudo (%)|mário de res<br>Efeito|ultados<br>Efeitos absol|utos potenciais<br>Risco<br>com|
|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>Risco de vi<br>Melhora da respos<br>258<br>(1 ECR)<br>Gravea<br>Melhora da respos<br>258<br>(1 ECR)<br>Gravea<br>Melhora da respos|és<br>Inconsistência<br>ta ACR 20 (atividad<br>Não grave<br>ta ACR 50 (atividad<br>NãoGrave<br>ta ACR 70 (atividad|Evidência<br>indireta<br>e da doença AR)<br>Não grave<br>e da doença AR)<br>Não grave<br>e da doença AR)|Imprecisão<br> <br>Graveb<br> <br>Graveb<br>|Outros<br>Nenhumc<br>Nenhumc|geral da<br>evidência<br>⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA|Risco com<br>terapia tripla<br>MMCD<br>43/130<br>(33,1%)<br>28/130<br>(21,5%)|Risco com<br>MMCDbio<br>anti-TNF + MTX<br>51/128 (39,8%)<br>38/128 (29,7%)|relativo<br>(IC95%)<br>RR 1,20<br>(0,87 para<br>1,67)<br>RR 1,38<br>(0,90 para<br>2,10)|Risco com<br>terapia tripla<br>MMCD<br>331 por<br>1.000<br>215 por<br>1.000|MMCDbio<br>anti-TNF<br>+<br>MTX<br>66 mais por<br>1.000<br>(43 menos para<br>222 mais)<br>82 mais por<br>1.000<br>(22 menos para<br>237 mais)|  
100  
|№ de||Avaliação da<br>Eidêi|qualidade||Qualidade|Taxas de even|Su<br>tos do estudo (%)|mário de res<br>Efeito|ultados<br>Efeitos absol|utos potenciais<br>Risco<br>com|
|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>Risco de viés|Inconsistência|vnca<br>indireta|Imprecisão|Outros|geral da<br>evidência|Risco com<br>terapia tripla<br>MMCD|Risco com<br>MMCDbio<br>anti-TNF + MTX|relativo<br>(IC95%)|Risco com<br>terapia tripla<br>MMCD|<br>MMCDbio<br>anti-TNF<br>+<br>MTX|
|258<br>(1 ECR)<br>Gravea<br>Porcentagem de pacie<br>258<br>(1 ECR)<br>Gravea<br>Efeitos adversos grav<br>258<br>(1 ECR)<br>Gravea<br>Infecções e infestaçõ|Não grave<br>ntes com progres<br>Não grave<br>es<br>Não grave<br>es|Não grave<br>são radiográfic<br>Não grave<br>Não grave|Graveb<br>a detectável (Esco<br>Graveb<br>Muitograveb|Nenhumc<br>re Sharp) DMI<br>Nenhumc<br>Nenhumc|⨁⨁◯◯<br>BAIXA<br>= 5<br>⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|18/130<br>(13,8%)<br>130<br>1/130 (0,8%)|21/128 (16,4%)<br>128<br>2/128 (1,6%)|RR 1,18<br>(0,66 para<br>2,12)<br>-<br>RR 2,03<br>(0,19 para<br>22,12)|138 por<br>1.000<br>A média do<br>escore<br>Sharp; DMI<br>= 5 foi 0<br>8 por 1.000|25 mais por<br>1.000<br>(47 menos para<br>155 mais)<br>DM 3,23 menor<br>(6,03 menor<br>para 0,43<br>menor)<br>8 mais por<br>1.000<br>(6 menos para<br>162 mais)|  
101  
||||Avaliação da|qualidade|||Taxas de even|Su<br>tos do estudo (%)|mário de res|ultados<br>Efeitos absol|utos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|№ de<br>participantes<br>(estudos)|<br>Risco de viés|<br>Inconsistência|Evidência<br>indireta|Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Risco com<br>terapia tripla<br>MMCD|Risco com<br>MMCDbio<br>anti-TNF + MTX|Efeito<br>relativo<br>(IC95%)|Risco com<br>terapia tripla<br>MMCD|Risco<br>com<br>MMCDbio<br>anti-TNF<br>+<br>MTX|
|419<br>(2 ECRs)|Gravea,d|Não grave|Não grave|Graveb|Nenhumc|⨁⨁◯◯<br>BAIXA|24/213<br>(11,3%)|35/206 (17,0%)|RR 1,54<br>(0,99 para<br>2,41)|113 por<br>1.000|61 mais por<br>1.000<br>(1 menos para<br>159 mais)|
|Hepat|otoxicidade|||||||||||
|258<br>(1 ECR)|Gravea|Não grave|Não grave|Muitograveb|Nenhumc|⨁◯◯◯<br>MUITO<br>BAIXA|2/130 (1,5%)|7/128 (5,5%)|RR 3,55<br>(0,75 para<br>16,79)|15 por 1.000|39 mais por<br>1.000<br>(4 menos para<br>243 mais)|  
AR, artrite reumatoide; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
a. O ECR examinado não foi cegado, aumentando o risco de viés de expectativa potencial, e não descreveu adequadamente os procedimentos de alocação26.  
b. O tamanho total da amostra é pequeno, e o número total de eventos é < 300 (a thresholdrule-of-thumb value)26,27.  
c. Número insuficiente de estudos para avaliar o risco de viés.  
d. Não está claro se os participantes foram cegados27.  
Nota: além das evidências acima, levamos em consideração uma metanálise em rede11para a tomada de decisão que objetivou comparar MTX e combinações dos MMCDbio + MTX em pacientes com AR sem tratamento prévio com MMCDs ou que falharam ao MTX. Foram encontradas evidências de moderada a alta qualidade de que a terapia combinada tripla ou MTX + MMCDbio ou tofacitinibe foram igualmente eficazes no controle da atividade da doença e, geralmente, são bem toleradas em pacientes sem tratamento prévio com MMCDs ou que falharam ao MTX. A terapia combinada tripla foi superior ao MTX na prevenção do dano articular em pacientes sem tratamento prévio, mas a magnitude desses efeitos foi pequena ao longo de um ano.  
102  
**Questão 5. Devemos usar MMCDbio não anti-TNF + MTX em vez dos MMCDbio anti-TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|Aval<br>№<br>de<br>participant|ição da qua<br>|lidade|Evidência|||Qualidade geral|Sumário<br> <br>Taxas de even<br>(%)|de resultados<br>tos do estudo<br>C|Efeito|Efeitos absolut|os potenciais<br>Dif<br>d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)<br>Esco<br>646<br>(1 ECR)<br>Melh<br>646<br>(1 ECR)<br>Ques|Risco de vi<br>re (ou pontu<br>Gravea<br>ora da resp<br>Gravea<br>tionário de|és<br>Inconsistência<br>ação) da atividade de<br>Nãograve<br>osta ACR 50 (ativida<br>Nãograve<br>avaliação de saúde (H|indireta<br>doença (DAS-2<br>Graveb<br>de da doença AR<br>Graveb<br>AQ); DMI = -0|Imprecisão<br>8); DMI = -1,17 (<br>Nãograve<br>; tempo de segui<br>Nãograve<br>,375 (tempo de se|Outros<br>tempo de seguim<br>Nenhum<br>mento: 12 meses)<br>Nenhum<br>guimento: 12 mes|<br>da evidência<br>ento: 12 meses)<br>⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA<br>es)|<br>Com<br>MMCDbioTN<br>Fi + MTX<br>328<br>151/328<br>(46,0%)|om<br>MMCDbio<br>não TNFi +<br>MTX<br>318<br>147/318<br>(46,2%)|relativo<br>(IC95%)<br>-<br>RR<br>1,00<br>(0,85<br>para<br>1,19)|Risco<br>com<br>MMCDbioTN<br>Fi + MTX<br>A média DAS-<br>28 foi 0<br> <br> <br>460 por 1.000|<br>erença<br>e<br>risco<br>com<br>MMCDbio não<br>TNFi + MTX<br>DM<br>0,03<br>menor<br>(0,25<br>menor<br>para<br>0,19<br>maior)<br>0 menos por<br>1.000<br>(69 menos para<br>87 mais)|  
103  
|Ava<br>№<br>de<br>participant|lição da qual<br>|idade|Evidência|||Qualidade era|Sumário<br>l<br>Taxas de even<br>(%)|de resultados<br>tos do estudo<br>|<br>Efeito|Efeitos absolut|os potenci<br>|ais<br> <br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)|Risco de vi|és<br>Inconsistência|<br>indireta|Imprecisão|Outros|g<br>da evidência|<br>Com<br>MMCDbioTN<br>Fi + MTX|Com<br>MMCDbio<br>não TNFi +<br>MTX|relativo<br>(IC95%)<br>|Risco<br>com<br>MMCDbioTN<br>Fi + MTX|<br>Diferenç<br>risco<br>MMCDb<br>TNFi + M|a<br>de<br>com<br>io não<br>TX|
|646<br>(1 ECR)<br>Porc<br>579<br>(1 ECR)<br>Efei<br>646<br>(1 ECR)|Gravea<br>entagem de<br>Gravea<br>tos adversos<br>Gravea|Nãograve<br>pacientes com progre<br>Nãograve<br>graves (tempo de seg<br>Nãograve|Graveb<br>ssão radiográfic<br>Graveb<br>uimento: 12 me<br>Graveb|Nãograve<br>a detectável (Esco<br>Nãograve<br>ses)<br>Gravea|Nenhum<br>re Sharp) DMI<br>Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>= 5 (tempo de seg<br>⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|328<br>uimento: 12 mese<br>289<br>30/328 (9,1%)|318<br>s)<br>290<br>32/318<br>(10,1%)|-<br>-<br>RR<br>1,10<br>(0,69<br>para<br>1,77)|A média do<br>HAQ foi 0<br>A média do<br>escore<br>de<br>Sharp foi 0<br> <br> <br>91 por 1.000|<br>DM<br>(0,08<br>para<br>maior)<br> <br> <br>DM0,2<br>alto<br>(0,49<br>para<br>maior)<br>9<br>mais<br>1.000<br>(28 meno<br>70 mais)|0<br>menor<br>0,08<br>mais<br>menor<br>0,89<br> <br>por<br>s para<br>|  
104  
|Aval<br>№<br>de<br>participant|ição da quali<br>|dade|Evidência|||Qualidade geral|Sumário<br> <br>Taxas de even<br>(%)|de resultados<br>tos do estudo<br> <br>|Efeito|Efeitos absolut|os potenciais<br> <br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)<br>Infec<br>646<br>(1 ECR)<br>Reaç<br>646<br>(1 ECR)|Risco de vié<br>ções graves<br>Gravea<br>ões no local<br>Gravea|s<br>Inconsistência<br>(tempo de seguiment<br>Nãograve<br>da injeção (tempo de<br>Nãograve|<br>indireta<br>o: 12 meses)<br>Graveb<br>seguimento: 12<br>Graveb|Imprecisão<br>Nãograve<br>meses)<br>Gravea|Outros<br>Nenhum<br>Nenhum|<br>da evidência<br>⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|<br>Com<br>MMCDbioTN<br>Fi + MTX<br>9/328 (2,7%)<br>30/328 (9,1%)|<br> <br>Com<br>MMCDbio<br>não TNFi +<br>MTX<br>7/318 (2,2%)<br> <br> <br> <br>12/318<br>(3,8%)<br> <br> <br>|relativo<br>(IC95%)<br>RR 0,78<br>(0,29 para<br>2,06)<br>RR 0,41<br>(0,22 para<br>0,79)|Risco<br>com<br>MMCDbioTN<br>Fi + MTX<br>27 por 1.000<br>91 por 1.000|<br>Diferença<br>de<br>risco<br>com<br>MMCDbio não<br>TNFi + MTX<br>6 menos por<br>1.000<br>(19 menos para<br>29 mais)<br>54 menos por<br>1.000<br>(71 menos para<br>19 menos)|  
AR, artrite reumatoide; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC:, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Grande intervalo de confiança, o qual inclui danos e benefícios potenciais.  
b. Evidência indireta da população com AR estabelecida.  
105  
**Questão 6. Devemos usar MMCDbio não anti-TNFem vez dos MMCDbio anti-TNF em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|№ de<br>articiantes|||Avalição da q<br>Evidência|ualidade||Qualidade eral|Taxas de eventos<br>|<br>do estudo (%)<br> <br>|Sumário de resu<br>Efeito|ltados<br>Efeitos absol<br>|utos potenciais<br>Diferença de|
|---|---|---|---|---|---|---|---|---|---|---|---|
|pp<br>(estudos)<br>Escore<br>|Risco de viés<br>(ou pontuação) da|Inconsistência<br>atividade de doença|<br>indireta<br>(DAS-28)|Imprecisão|Outros|g<br>da evidência<br>|Com<br>MMCDbioanti-<br>TNF|<br> <br>Com<br>MMCDbio<br>não anti-TNF|<br>relativo(IC95%)|Risco com<br>MMCDbio<br>anti-TNF<br>A<br>média|risco com<br>MMCDbio não<br>anti-TNF<br> <br>DM 1,5 menor|
|325<br>(1 ECR)<br>Melho<br>|Nãograve<br>ra da resposta AC|Nãograve<br>R 50 (atividade da do|Gravea<br>ença AR)|Nãograve|Nenhum|⨁⨁⨁◯<br>MODERADA<br>|163|162<br> <br>|-<br>|DAS-28 foi<br>0<br> <br>|<br>(1,8 menor para<br>1,1 menor)<br>114 menos por<br>|
|325<br>(1 ECR)<br>Questi<br>325<br>(1 ECR)<br>Efeito|Nãograve<br>onário de avaliaçã<br>Nãograve<br>s adversos graves|Nãograve<br>o de saúde (HAQ)<br>Nãograve|Gravea<br>Gravea|Nãograve<br>Nãograve|Nenhum<br>Nenhum|⨁⨁⨁◯<br>MODERADA<br>⨁⨁⨁◯<br>MODERADA|45/162 (27,8%)<br>162|77/163<br>(47,2%)<br> <br> <br>163<br>|RR<br>0,59<br>(0,44 para 0,79)<br>-|<br>278<br>por<br>1.000<br>A média do<br>HAQ foi 0|<br>1.000<br>(156 menos para<br>58 menos)<br> <br>DM 0,2 menor<br>(0,3 menor para<br>0)|  
106  
|№ de<br>ii|||Avalição da q<br>Eidêi|ualidade||lidd l|Taxas de eventos|do estudo (%)<br>|Sumário de resu<br>Efi|ltados<br>Efeitos absol|utos potenciais<br>Diferença de|
|---|---|---|---|---|---|---|---|---|---|---|---|
|partcpantes<br>(estudos)|Risco de viés|Inconsistência|vnca<br>indireta|Imprecisão|Outros|Quaae gera<br>da evidência|Com<br>MMCDbioanti-<br>TNF|<br> <br>Com<br>MMCDbio<br>não anti-TNF|eto<br>relativo(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|<br>risco com<br>MMCDbio não<br>anti-TNF|
|324<br>(1 ECR)<br>Infecç<br>324<br>(1 ECR)|Nãograve<br>ões graves<br>Não grave|Nãograve<br>Não grave|Grave A<br>Gravea|Grave B<br>Graveb|Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA|21/162 (13,0%)<br>7/162 (4,3%)|23/162<br>(14,2%)<br> <br> <br>6/162 (3,7%)<br> <br>|RR 0,91<br>(0,53 para 1,58)<br>RR 1,17<br>(0,40 para 3,40)|130 por<br>1.000<br>43 por 1.000|12 menos por<br>1.000<br>(61 menos para<br>75 mais)<br> <br>7 mais por 1.000<br>(26 menos para<br>104 mais)|
|Neopla<br>324<br>(1 ECR)<br>Hepato|sias<br>Não grave<br>toxicidade (ALT|Não grave<br>acima de 2,5 vezes o|Gravea<br>limite superior d|Graveb<br>o valor normal)|Nenhum|⨁⨁◯◯<br>BAIXA|1/162 (0,6%)|1/162 (0,6%)<br> <br>|RR 1,00<br>(0,06 para 15,85)|6 por 1.000|<br>0 menos por<br>1.000<br>(6 menos para 92<br>mais)|  
107  
|№ de<br>participantes<br>(estudos)|Risco de viés|Inconsistência|Avalição da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade geral<br>da evidência|Taxas de evento<br>Com<br>MMCDbioanti-<br>TNF|<br>s do estudo (%)<br> <br> <br>Com<br>MMCDbio<br>não anti-TNF|Sumário de resu<br>Efeito<br>relativo(IC95%)|ltados<br>Efeitos absol<br>Risco com<br>MMCDbio<br>anti-TNF|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio não<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|324<br>(1 ECR)|Não grave|Não grave|Gravea|Graveb|Nenhum|⨁⨁◯◯<br>BAIXA|5/162 (3,1%)|11/162<br>(6,8%)<br> <br>|RR 0,45<br>(0,16 para 1,28)|31 por 1.000|<br>17 menos por<br>1.000<br>(26 menos para 9<br>mais)|
|Colest|erol|||||||||||
|324<br>(1 ECR)|Não grave|Não grave|Gravea|Graveb|Nenhum|⨁⨁◯◯<br>BAIXA|2/162 (1,2%)|2/162 (1,2%)<br> <br>|RR 1,00<br>(0,14 para 7,01)|12 por 1.000|<br>0 menos por<br>1.000<br>(11 menos para<br>74 mais)|  
ALT, alanina aminotransferase; AR, artrite reumatoide; DM, diferença média; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo. Explicações: a. Evidência indireta da população com AR estabelecida28.b. Grande intervalo de confiança, que inclui danos e benefícios potenciais.  
108  
**Questão 7. Devemos usar tofacitinibe oral + MTX em vez deMMCDbio anti-TNF + MTX em pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|№ de<br>participante<br>s (estudos)<br>Escor<br>355<br>(1 ECR)<br>Melh|Risco de<br>viés<br>e (ou pontua<br>Não grave<br>ora da respos|Inconsistência<br>ção) da atividade de<br>Não grave<br>ta ACR 20 (tempo d|Avaliação<br>Evidência<br>indireta<br>doença (DAS-28<br>Gravea<br>e seguimento: 6|da qualidade<br>Imprecisão<br>< 2,6; tempo de se<br>Graveb<br>meses)|Outros<br>guimento: 6 mes<br>Nenhum|Qualidade geral<br>da evidência<br>es; avaliado com: por<br>⨁⨁◯◯<br>BAIXA|Taxas de eve<br>(%)<br>Risco com<br>MMCDbio<br>anti-TNF +<br>MTX<br>centagem de<br>12/178<br>(6.,%)|S<br>ntos do estudo<br>Risco com<br>tofacitinibe<br>oral + MTX<br>participantes qu<br>11/177 (6.,%)|umário de res<br>Efeito<br>relativo<br>(IC95%)<br>e alcançam a r<br>RR 0,92<br>(0,42 para<br>2,03)|ultados<br>Efeitos abso<br>potenciais<br>Risco com<br>MMCDbio<br>anti-TNF +<br>MTX<br>emissão DAS<br>67 por<br>1.000|lutos<br>Risco com<br>tofacitinibe<br>oral + MTX<br>-28)<br>5 menos por<br>1.000<br>(39 menos<br>para 69<br>mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|
|395<br>(1 ECR)<br>Índice|Não grave<br>da incapaci|Não grave<br>dade do questionário|Gravea<br>de avaliação em|Grave<br>saúde (HAQ-DI) (|Nenhum<br>maior pontuação|⨁⨁◯◯<br>BAIXA<br>indica atividade de d|94/199<br>(47,2%)<br>oença mais g|101/196<br>(51,5%)<br>rave); DMI = −0|RR 1,09<br>(0,89 para<br>1,33)<br>,375 (tempo d|472 por<br>1.000<br>e seguimento|43 mais por<br>1.000<br>(52 menos<br>para 156<br>mais)<br>: 3 meses)|  
109  
|№ de|Risco de||Avaliação<br>Evidência|da qualidade||Qualidade geral|Taxas de eve<br>(%)<br>|S<br>ntos do estudo|umário de res<br>Efeito|ultados<br>Efeitos abso<br>potenciais<br>|lutos|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participante<br>s (estudos)|<br>viés|Inconsistência|<br>indireta|Imprecisão|Outros|<br>da evidência|Risco com<br>MMCDbio<br>anti-TNF +<br>MTX|Risco com<br>tofacitinibe<br>oral + MTX|relativo<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF +<br>MTX|Risco com<br>tofacitinibe<br>oral + MTX|
|378<br>(1 ECR)<br>Efeito<br>408<br>(1 ECR)<br>Infecç|Não grave<br>s adversos g<br>Não grave<br>ões graves (|Não grave<br>raves (tempo de segu<br>Não grave<br>tempo de seguimento|Gravea<br>imento: 12 mes<br>Gravea<br>: 12 meses)|Não grave<br>es)<br>Graveb|Nenhum<br>Nenhum|⨁⨁⨁◯<br>MODERADA<br>⨁⨁◯◯<br>BAIXA|190<br>7/204 (3,4%)|188<br>10/204 (4,9%)|-<br> <br>RR 1,43<br>(0,55 para<br>3,68)|A média do<br>HAQ-DI foi<br>0<br>34 por<br>1.000|<br>DM 0,06<br>menor<br>(0,07 menor<br>para 0,05<br>menor)<br>15 mais por<br>1.000<br>(15 menos<br>para 92<br>mais)|  
110  
|№ de<br>participante<br>s (estudos)|Risco de<br>viés|Inconsistência|Avaliação<br>Evidência<br>indireta|da qualidade<br>Imprecisão|Outros|Qualidade geral<br>da evidência|Su<br>Taxas de eventos do estudo<br>(%)<br>Risco com<br>MMCDbio<br>anti-TNF +<br>MTX<br>Risco com<br>tofacitinibe<br>oral + MTX|mário de res<br>Efeito<br>relativo<br>(IC95%)|ultados<br>Efeitos abso<br>potenciais<br>Risco com<br>MMCDbio<br>anti-TNF +<br>MTX|lutos<br>Risco com<br>tofacitinibe<br>oral + MTX|
|---|---|---|---|---|---|---|---|---|---|---|
|408<br>(1 ECR)<br>Hepat<br>28<br>(1 ECR)|Não grave<br>otoxicidade<br>Não grave|Não grave<br>(ALT acima de 3 ve<br>Não grave|Gravea<br>zes o limite super<br>Gravea|Não grave<br>ior do valor normal)<br>Muitogravec|Nenhum<br>(tempo de segu<br>Nenhum|⨁⨁⨁◯<br>MODERADA<br>imento: 12 meses)<br>⨁◯◯◯<br>MUITO BAIXA|1/204 (0,5%) 2/204 (1,0%)<br>3/14 (21,4%) 5/14 (35,7%)|RR 2,00<br>(0,18 para<br>21,88)<br>RR 1,67<br>(0,49 para<br>5,67)|5 por 1.000<br>214 por<br>1.000|5 mais por<br>1.000<br>(4 menos<br>para 102<br>mais)<br>144 mais<br>por 1.000<br>(109 menos<br>para 1.001<br>mais)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Evidência indireta: esse PICO aborda pacientes com AR recente, enquanto o ECR usado incluiu participantes com AR estabelecida26.  
b. Grande intervalo de confiança, que inclui danos e benefícios potenciais.  
c. Intervalos de confiança amplos em torno do tamanho do efeito devido ao pequeno tamanho amostral26.  
111  
**Questão 8. Devemos usar tofacitinibe oral em vez dos MMCDbio anti-TNF para pacientes com AR de início recente de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|№ de<br>tiit|<br>Risco de|Iitêi|Avaliação da<br>Evidência|qualidade<br>Iiã|Ot|Qualidade geral|Taxas de<br>estud<br>|<br>eventos do<br>o (%)<br>|Sumário de re<br>Efeito<br>lti|sultados<br>Efeitos<br>pote<br>|absolutos<br>nciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|parcpanes<br>(estudos)<br>Escor<br>102<br>(1 ECR)<br>Melho|<br>viés<br>e (ou pontuaç<br>Não grave<br>ra da respost|nconssnca<br>ão) da atividade de do<br>Não grave<br>a ACR 20 (tempo de s|indireta<br>ença (DAS-28 <<br>Gravea<br>eguimento: 12 se|mprecso<br>2,6); (tempo de seg<br>Graveb<br>manas)|uros<br>uimento: 12 sem<br>Nenhum|da evidência<br>anas)<br>⨁⨁◯◯<br>BAIXA<br>|Risco com<br>MMCDbio<br>anti-TNF<br>2/53 (3,8%)|Risco com<br>tofacitinibe<br>oral<br>3/49 (6,1%)|reavo<br>(IC95%)<br>RR 1,62<br>(0,28 para<br>9,30)|Risco com<br>MMCDbio<br>anti-TNF<br>38 por 1.000|Risco com<br>tofacitinibe<br>oral<br> <br>23 mais por<br>1.000<br>(27 menos<br>para 313<br>mais)|
|102<br>(1 ECR)<br>Melho|Não grave<br>ra da respost|Não grave<br>a ACR 50 (tempo de s|Gravea<br>eguimento: 12 se|Graveb<br>manas)|Nenhum|⨁⨁◯◯<br>BAIXA<br> <br>|19/53<br>(35,8%)|29/49<br>(59,2%)|RR 1,65<br>(1,08 para<br>2,53)|358 por<br>1.000|233 mais<br>por 1.000<br>(29 mais<br>para 548<br>mais)|  
112  
|№ de<br>participantes|<br>Risco de|Inconsistência|Avaliação da<br>Evidência|qualidade<br>Imprecisão|Outros|Qualidade geral|Taxas de e<br>estud<br>|<br>ventos do<br>o (%)<br>|Sumário de re<br>Efeito<br>relativo|sultados<br>Efeitos<br>pote<br>|absolutos<br>nciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|<br>(estudos)|<br>viés||indireta|||da evidência|Risco com<br>MMCDbio<br>anti-TNF|Risco com<br>tofacitinibe<br>oral|<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|Risco com<br>tofacitinibe<br>oral|
|102<br>(1 ECR)<br>Melho<br>102<br>(1 ECR)<br>Índice|Não grave<br>ra da respost<br>Não grave<br>da incapacid|Não grave<br>a ACR 70 (tempo de<br>Não grave<br>ade do questionário d|Gravea<br>seguimento: 12 se<br>Gravea<br>e avaliação em saú|Graveb<br>manas)<br>Graveb<br>de (HAQ-DI) (mai|Nenhum<br>Nenhum<br>or pontuação in|⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA<br>dica atividade de doe|10/53<br>(18,9%)<br>2/53 (3,8%)<br>nça mais grav|18/49<br>(36,7%)<br>6/49<br>(12,2%)<br>e); DMI = −0|RR 1,95<br>(1,00 para<br>3,80)<br>RR 3,24<br>(0,69 para<br>15,33)<br>,375 (tempo|189 por<br>1.000<br>38 por 1.000<br>de seguimento|179 mais<br>por 1.000<br>(0 menos<br>para 528<br>mais)<br> <br>85 mais por<br>1.000<br>(12 menos<br>para 541<br>mais)<br>: 12 semanas)|  
113  
|№ de<br>ii|<br>Risco de|Iiêi|Avaliação da q<br>Evidência|ualidade<br>Ii|O|Qualidade geral|Taxas de e<br>estud|<br>ventos do<br>o (%)|Sumário de re<br>Efeito<br>li|sultados<br>Efeitos<br>pote|absolutos<br>nciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|partcpantes<br>(estudos)|<br>viés|nconsstnca|indireta|mprecsão|utros|da evidência|Risco com<br>MMCDbio<br>anti-TNF|Risco com<br>tofacitinibe<br>oral|reatvo<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|<br>Risco com<br>tofacitinibe<br>oral|
|92<br>(1 ECR)<br>Efeito<br>102<br>(1 ECR)<br>Infecç|Não grave<br>s adversos gr<br>Não grave<br>ões graves (t|Não grave<br>aves (tempo de seguim<br>Não grave<br>empo de seguimento:|Gravea<br>ento: 24 semanas<br>Gravea<br>24 semanas)|Graveb<br>)<br>Graveb|Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br> <br>⨁⨁◯◯<br>BAIXA<br>|46<br>1/53 (1,9%)|46<br>0/49 (0,0%)|-<br>RR 0,36<br>(0,02 para<br>8,63)|A média do<br>HAQ-DI foi<br>0<br>19 por 1.000|<br>DM 0,19<br>menor<br>(0,49 menor<br>para 0,11<br>maior)<br> <br>12 menos<br>por 1.000<br>(18 menos<br>para 144<br>mais)|  
114  
|№ de<br>articiantes|<br>Risco de|Inconsistência|Avaliação da<br>Evidência|qualidade<br>Imrecisão|Outros|Qualidade geral|Taxas de e<br>estud<br>|<br>ventos do<br>o (%)<br>|Sumário de re<br>Efeito<br>relativo|sultados<br>Efeitos<br>pote<br>|absolutos<br>nciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|pp<br>(estudos)|<br>viés||indireta|p||da evidência|Risco com<br>MMCDbio<br>anti-TNF|Risco com<br>tofacitinibe<br>oral|<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|<br>Risco com<br>tofacitinibe<br>oral|
|102<br>(1 ECR)<br>Hepat<br>102<br>(1 ECR)|Não grave<br>otoxicidade (<br>Não grave|Não grave<br>ALT acima de 3 vezes<br>Não grave|Gravea<br>o limite superior<br>Gravea|Graveb<br>do valor normal) (t<br>Graveb|Nenhum<br>empo de seguim<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>ento: 24 semanas)<br>⨁⨁◯◯<br>BAIXA|1/53 (1,9%)<br>1/53 (1,9%)|0/49 (0,0%)<br>0/49 (0,0%)|RR 0,36<br>(0,02 para<br>8,63)<br>RR 0,36<br>(0,02 para<br>8,63)|19 por 1.000<br>19 por 1.000|<br>12 menos<br>por 1.000<br>(18 menos<br>para 144<br>mais)<br> <br>12 menos<br>por 1.000<br>(18 menos<br>para 144<br>mais)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Evidência indireta: esse PICO aborda a AR recente, porém a evidência disponível mais próxima foi um ECR de participantes com AR estabelecida 29.  
b. Intervalos de confiança amplos em torno do tamanho do efeito devido ao pequeno tamanho amostral 29.  
115  
**Questão 9. Devemos usar MMCDbio anti-TNF + MTX em vez de terapia tripla com MMCDs em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam aos MMCDs?**  
|Ava<br>№ de<br>participant<br>es<br>(estudos)<br>Esco<br>moderado –<br>514<br>(2 ECRs)<br>Mel|liação da quali<br>Risco de<br>viés<br>re (ou pontua<br>DMP = 0,5; e<br>Muito<br>gravea,b<br>hora da respos|dade<br>Inconsistência<br>ção) da atividade de<br>feito grande –DMP =<br>Não grave<br>ta ACR 50 (seguimen|Evidência<br>indireta<br>doença (DAS-28<br>0,8) (seguimento<br>Não grave<br>to: 48 semanas)|Imprecisão<br>) (Interpretação d<br>: 48 semanas; mai<br>Não grave|Outros<br>a diferença de<br>or pontuação in<br>Nenhum|Qualidade<br>geral da<br>evidência<br>média padronizada<br>dica atividade de<br>⨁⨁◯◯<br>BAIXA|Sumá<br>Taxas de<br>estud<br>Com<br>terapia<br>tripla com<br>MMCD<br>de acordo co<br>doença mais gr<br>258|rio de resultado<br>eventos do<br>o (%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX<br>m a diretriz de<br>ave)<br>256|s<br>Efeito<br>relativo<br>(IC95%)<br>Cohen: efeit<br>-|Efeitos abs<br>Risco com<br>terapia<br>tripla com<br>MMCD<br>o pequeno –D<br>-|olutos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF +<br>MTX<br>MP = 0,2; efeito<br>DMP0,11<br>menor<br>(0,29 menor<br>para 0,06<br>maior)|
|---|---|---|---|---|---|---|---|---|---|---|---|
|310<br>(1 ECR)|Muito<br>gravea|Não grave|Não grave|Gravec|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|55/155<br>(35,5%)|66/155<br>(42,6%)|RR 1,20<br>(0,91 para<br>1,59)|População<br>355 por<br>1.000|do estudo<br>71 mais por<br>1.000<br>(32 menos<br>para 209 mais)|  
116  
|Avali<br>№ de<br>|ação da qualid<br>|ade||||Qualidade|Sumár<br>Taxas de<br>estud|io de resultados<br>eventos do<br>o (%)|<br>Efeito|Efeitos abs|olutos potenciais<br>Diferena de|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outros|geral da<br>evidência|Com<br>terapia<br>tripla com<br>MMCD|Com<br>MMCDbio<br>anti-TNF +<br>MTX|relativo<br>(IC95%)|Risco com<br>terapia<br>tripla com<br>MMCD|<br>ç<br>risco com<br>MMCDbio<br>anti-TNF +<br>MTX|
|||||||||||Baix|o risco|
|||||||||||200<br>por 1.000|40 mais<br>por<br>1.000<br>(18 menos para<br>118 mais)|  
Progressão radiográfica detectável (modificação de Van der Heijde do Escore Sharp); DMI = 5 (seguimento: 48 semanas; maior pontuação indica doença mais extensa; escala de: 0 para 448)  
117  
|Ava<br>№ de<br>participant<br>es<br>(estudos)|liação da quali<br>Risco de<br>viés|dade<br>Inconsistência|Evidência<br>indireta|Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Sumá<br>Taxas de<br>estud<br>Com<br>terapia<br>tripla com<br>MMCD|rio de resultado<br>eventos do<br>o (%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX|s<br>Efeito<br>relativo<br>(IC95%)|Efeitos abs<br>Risco com<br>terapia<br>tripla com<br>MMCD|olutos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF +<br>MTX|
|---|---|---|---|---|---|---|---|---|---|---|---|
|304<br>(1 ECR)<br>Efei<br>646<br>(2 ECRs)|Muito<br>gravea<br>tos adversos gr<br>Muito<br>graveb,d|Não grave<br>aves (seguimento: 48<br>Muito gravee|Não grave<br>semanas)<br>Não grave|Não grave<br>Gravec|Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|151<br>37/326<br>(11,3%)|153<br>55/320<br>(17,2%)|-<br>RR 1,52<br>(1,03 para<br>2,23)|A média da<br>progressão<br>radiográfic<br>a detectável<br>(modificaç<br>ão de Van<br>der Heijde<br>do Escore<br>Sharp) foi<br>0<br>113 por<br>1.000|<br>DM0,25<br>menor<br>(0,86 menor<br>para 0,36<br>maior)<br>59 mais por<br>1.000<br>(3 mais para<br>140 mais)|  
118  
|Aval<br>№ de<br>participant<br>es<br>(estudos)<br>Infec|iação da quali<br>Risco de<br>viés<br>ções graves (s|dade<br>Inconsistência<br>eguimento: 48 sema|Evidência<br>indireta<br>nas)|Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Sumá<br>Taxas de<br>estud<br>Com<br>terapia<br>tripla com<br>MMCD|rio de resultado<br>eventos do<br>o (%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX|s<br>Efeito<br>relativo<br>(IC95%)|Efeitos abs<br>Risco com<br>terapia<br>tripla com<br>MMCD|olutos potenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF +<br>MTX|
|---|---|---|---|---|---|---|---|---|---|---|---|
|646<br>(2 ECRs)|Muito<br>graveb,d|Não grave|Não grave|Não grave|Nenhum|⨁⨁◯◯<br>BAIXA|34/326<br>(10,4%)|63/320<br>(19,7%)|RR 1,90<br>(1,35 para<br>2,68)|104 por<br>1.000|94 mais por<br>1.000<br>(37 mais para<br>175 mais)|  
DM, diferença média; DMP, diferença média padronizada; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR: risco relativo.  
a. Dados para essa questão foram obtidos de um ECR duplo-cego (n = 353)30. Depois de 24 semanas, os pacientes de cada grupo podiam trocar para o grupo oposto caso não tivessem obtido resposta terapêutica adequada. Os desfechos primários em 48 semanas só incluíram os pacientes que continuaram no grupo original. Por isso, eles estão sujeitos a viés de atrito.  
b. Scott et al. (2015)31: sem alocação sigilosa e cegamento apropriados.  
c. Intervalo de confiança amplo ao redor da estimativa de efeito devido ao pequeno tamanho amostral30 para todos os desfechos e para os desfechos efeitos adversos graves, infecções graves, efeitos adversos gastrointestinais e mortalidade31.  
d. Dados para essa questão foram obtidos de um ECR duplo-cego (n = 353)30. Depois de 24 semanas, os pacientes de cada grupo podiam trocar para o grupo oposto caso não tivessem obtido resposta terapêutica adequada. Os pacientes que trocaram de tratamento foram contabilizados no N de ambos os grupos para a análise de segurança. Os efeitos adversos foram atribuídos à terapia atual do paciente no momento da sua ocorrência, o que pode, incorretamente, atribuir efeitos adversos que aconteceram devido a terapia anterior.  
e. Alta heterogeneidade, I2 = 83%30,31.  
119  
**Questão 10. Devemos usarMMCDbio anti-TNF + MTX em vez de MMCDbio não anti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs?**  
|№ de<br>participant<br>es<br>(estudos)<br>Esco<br>grave)|Risco de<br>viés<br>re (ou pontua|Inconsistência<br>ção) da atividade de|Avaliação da<br>Evidência<br>indireta<br>doença (DAS-2|qualidade<br>Imprecisão<br>8); DMI = -1,17 (s|Outros<br>eguimento: vari|Qualidade<br>geral da<br>evidência<br>ação 1 anos para|Taxas de even<br>(<br>Com<br>MMCDbio<br>não anti-<br>TNF + MTX<br>2 anos; avaliad|S<br>tos do estudo<br>%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX<br>o com: maior po|umário de re<br>Efeito<br>relativo<br>(IC95%)<br>ntuação ind|sultados<br>Efeitos abs<br>Risco com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX<br>ica atividade|olutos potenciais<br> <br> <br>Diferença<br>de<br>risco<br>com<br>MMCDbio<br>anti-TNF<br>+<br>MTX<br>de doença mais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|967<br>(2 ECRs)|Não gravea|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁⨁<br>ALTA|474|493|-|A média<br>do Escore<br>(ou<br>pontuação)<br>da<br>atividade<br>de doença<br>(DAS-28)<br>foi 0|<br>DM0,32 maior<br>(0,1 menor<br>para 0,74<br>maior)|  
Melhora da resposta ACR 50 (seguimento: variação 1 para 2 anos)  
120  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Com<br>MMCDbio<br>não anti-<br>TNF + MTX|S<br>ntos do estudo<br>%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX|umário de re<br>Efeito<br>relativo<br>(IC95%)|sultados<br>Efeitos abs<br>Risco com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|olutos potenciais<br> <br>Diferença<br>de<br>risco<br>com<br>MMCDbio<br>anti-TNF<br>+<br>MTX|
|---|---|---|---|---|---|---|---|---|---|---|---|
|967<br>(2 ECRs)|Não gravea|Não grave|Não grave|Graveb|Nenhum|⨁⨁⨁◯<br>MODERADA|213/474<br>(44,9%)|213/493<br>(43,2%)|RR 0,93<br>(0,72 para<br>1,21)|449 por<br>1.000|31 menos por<br>1.000<br>(126 menos<br>para 94 mais)|  
Progressão radiográfica detectável (Escore Sharp); DMI = 3 (seguimento: variação 1 anos para 2 anos; avaliado com: maior pontuação indica progressão mais grave da doença  
|517<br>(1 ECR)|Gravec|Não grave|Não grave|Graveb|Nenhum<br>⨁⨁◯◯<br>BAIXA|257<br>260|-<br>A média<br>da<br>progressão<br>radiográfic<br>a<br>detectável<br>(Escore<br>Sharp) foi<br>0|DM0,36<br>menor<br>(6,41 menor<br>para 5,69<br>maior)|
|---|---|---|---|---|---|---|---|---|  
121  
|№ de<br>participant<br>es<br>(estudos)<br>Efei<br>967<br>(2 ECRs)<br>Infe<br>967<br>(2 ECRs)<br>Neo|Risco de<br>viés<br>tos adversos gr<br>Não gravea<br>cções graves (s<br>Não gravea<br>plasias (seguim|Inconsistência<br>aves (seguimento: v<br>Não grave<br>eguimento: variação<br>Não grave<br>ento: variação 1 par|Avaliação da<br>Evidência<br>indireta<br>ariação 1 para 2<br>Não grave<br>1 para 2 anos)<br>Não grave<br>a 2 anos)|qualidade<br>Imprecisão<br>anos)<br>Não grave<br>Não grave|Outros<br>Nenhum<br>Nenhum|Qualidade<br>geral da<br>evidência<br>⨁⨁⨁⨁<br>ALTA<br>⨁⨁⨁⨁<br>ALTA|Taxas de eve<br>(<br>Com<br>MMCDbio<br>não anti-<br>TNF + MTX<br>59/474<br>(12,4%)<br>15/474<br>(3,2%)|S<br>ntos do estudo<br>%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX<br>84/493<br>(17,0%)<br>33/493<br>(6,7%)|umário de re<br>Efeito<br>relativo<br>(IC95%)<br>RR 1,42<br>(0,91 para<br>2,20)<br>RR 2,30<br>(0,83 para<br>6,35)|sultados<br>Efeitos abs<br>Risco com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX<br>124 por<br>1.000<br>32 por<br>1.000|olutos potenciais<br> <br> <br>Diferença<br>de<br>risco<br>com<br>MMCDbio<br>anti-TNF<br>+<br>MTX<br>52 mais por<br>1.000<br>(11 menos<br>para 149 mais)<br>41 mais por<br>1.000<br>(5 menos para<br>169 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
122  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Com<br>MMCDbio<br>não anti-<br>TNF + MTX|S<br>ntos do estudo<br>%)<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX|umário de re<br>Efeito<br>relativo<br>(IC95%)|sultados<br>Efeitos abs<br>Risco com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|olutos potenciais<br> <br> <br>Diferença<br>de<br>risco<br>com<br>MMCDbio<br>anti-TNF<br>+<br>MTX|
|---|---|---|---|---|---|---|---|---|---|---|---|
|967<br>(2 ECRs)<br>Efei<br>646<br>(1 ECR)<br>Rea<br>967<br>(2 ECRs)|Não gravea<br>tos adversos ga<br>Gravec<br>ções infusionai<br>Não gravea|Não grave<br>strointestinais (segu<br>Não grave<br>s/reações no local da<br>Não grave|Não grave<br>imento: variação<br>Não grave<br>injeção (seguim<br>Não grave|Muitograved<br>1 para 2 anos)<br>Muito graved<br>ento: variação 1 p<br>Não grave|Nenhum<br>Nenhum<br>ara 2 anos)<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>⨁⨁⨁⨁<br>ALTA|8/474 (1,7%)<br>1/318 (0,3%)<br>23/474<br>(4,9%)|9/493 (1,8%)<br>1/328 (0,3%)<br>17/493<br>(3,4%)|RR 1,08<br>(0,42 para<br>2,79)<br>RR 0,97<br>(0,06 para<br>15,43)<br>RR 2,94<br>(1,87 para<br>4,62)|17 por<br>1.000<br>3 por<br>1.000<br>49 por<br>1.000|1 mais por<br>1.000<br>(10 menos<br>para 30 mais)<br>0 menos por<br>1.000<br>(3 menos para<br>45 mais)<br>94 mais por<br>1.000<br>(42 mais para<br>176 mais)|  
123  
DM, diferença média; DMI, diferença minimamente importante;ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
a. Contribuíram para essas análises dois ECRs, um duplo-cego32 e um em que os pacientes não eram cegados33.  
b. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
c. No estudo que contribuiu para essa análise, os pacientes não eram cegados33.  
d. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos; taxa de eventos muito baixa.  
124  
**Questão 11. Devemos usar MMCDbio anti-TNFem vez de MMCDbio não anti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs?**  
|№ de|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade geral|Taxas de eve<br>(|ntos do estudo<br>%)|Sumário de r<br>Efeito|esultados<br>Efeitos abs<br>Ri|olutos potenciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>Esco<br>325<br>(1 ECR)<br>Que<br>325<br>(1 ECR)<br>Mel|<br>viés<br>re (ou pontua<br>Não grave<br>stionário de a<br>Não grave<br>hora da respo|Inconsistência<br>ção) da atividade de<br>Não grave<br>valiação em saúde (H<br>Não grave<br>sta ACR 50 (seguime|indireta<br>doença (DAS-28<br>Não grave<br>AQ) (qualidade<br>Não grave<br>nto: 6 meses)|Imprecisão<br>); DMI = -1,17 (seg<br>Gravea<br>de vida); DMI = −0<br>Gravea|Outros<br>uimento: 6 mes<br>Nenhum<br>,375 (seguimen<br>Nenhum|<br>da evidência<br>es)<br>⨁⨁⨁◯<br>MODERADA<br>to: 6 meses)<br>⨁⨁⨁◯<br>MODERADA|Com<br>MMCDbio<br>não anti-TNF<br>163<br>163|Com<br>MMCDbio<br>anti-TNF<br>162<br>162|relativo<br>(IC95%)<br>-<br>-|sco com<br>MMCDbio<br>não anti-<br>TNF<br>A média do<br>Escore (ou<br>pontuação)<br>da<br>atividade<br>de doença<br>(DAS-28)<br>foi 0<br>A média<br>do HAQ<br>foi 0|erença e<br>risco com<br>MMCDbio anti-<br>TNF<br> <br> <br> <br>DM1,4 maior<br>(1,2 maior para<br>1,6 maior)<br>DM0,2 maior<br>(0,.07 maior<br>para 0,33<br>maior)|  
125  
|№ de|Risco de|Avaliação da<br>Evidência|qualidade||Qualidade geral|Taxas de eve<br>(|ntos do estudo<br>%)|Sumário de r<br>Efeito|esultados<br>Efeitos abs<br>|olutos potenciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|<br>viés<br>Inconsistência|indireta|Imprecisão|Outros|<br>da evidência|Com<br>MMCDbio<br>não anti-TNF|Com<br>MMCDbio<br>anti-TNF|relativo<br>(IC95%)|Risco com<br>MMCDbio<br>não anti-<br>TNF|Diferença de<br>risco com<br>MMCDbio anti-<br>TNF|
|325<br>(1 ECR)<br>Efeit<br>324<br>(1 ECR)<br>Infec<br>324<br>(1 ECR)|Não grave<br>Não grave<br>os adversos graves (seguimento: 6<br>Não grave<br>Não grave<br>ções graves (seguimento: 6 meses<br>Não grave<br>Não grave|Não grave<br>meses)<br>Não grave<br>)<br>Não grave|Gravea<br>Muitograveb<br>Muitograveb|Nenhum<br>Nenhum<br>Nenhum|⨁⨁⨁◯<br>MODERADA<br>⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA|77/163<br>(47,2%)<br>23/162<br>(14,2%)<br>6/162<br>(3,7%)|45/162<br>(27,8%)<br>21/162<br>(13,0%)<br>7/162<br>(4,3%)|RR 0,59<br>(0,44 para<br>0,79)<br>RR 0,91<br>(0,53 para<br>1,58)<br>RR 1,17<br>(0,40 para<br>3,40)|472 por<br>1.000<br>142 por<br>1.000<br>37 por<br>1.000|194 menos por<br>1.000<br>(265 menos<br>para 99<br>menos)<br>13 menos por<br>1.000<br>(67 menos<br>para 82 mais)<br>6 mais por<br>1.000<br>(22 menos<br>para 89 mais)|  
126  
|№ de<br>participantes<br>(estudos)<br>Cân|<br>Risco de<br>viés<br>cer (seguimen|Inconsistência<br>to: 6 meses)|Avaliação d<br>Evidência<br>indireta|a qualidade<br>Imprecisão|Outros|Qualidade geral<br>da evidência|Taxas de eve<br>(<br>Com<br>MMCDbio<br>não anti-TNF|ntos do estudo<br>%)<br>Com<br>MMCDbio<br>anti-TNF|Sumário de r<br>Efeito<br>relativo<br>(IC95%)|esultados<br>Efeitos abs<br>Risco com<br>MMCDbio<br>não anti-<br>TNF|olutos potenciais<br>Diferença de<br>risco com<br>MMCDbio anti-<br>TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|324<br>(1 ECR)|Não grave|Não grave|Não grave|Muitograveb|Nenhum|⨁⨁◯◯<br>BAIXA|1/162<br>(0,6%)|1/162<br>(0,6%)|RR 1,00<br>(0,06 para<br>15,85)|6 por 1.000|<br>0 menos por<br>1.000<br>(6 menos para<br>92 mais)|
|Toxi|cidade cardio|vascular||||||||||
|324<br>(1 ECR)|Não grave|Não grave|Não grave|Muitograveb|Nenhum|⨁⨁◯◯<br>BAIXA|2/162<br>(1,2%)|2/162<br>(1,2%)|RR 1,00<br>(0,14 para<br>7,01)|12 por<br>1.000|0 menos por<br>1.000<br>(11 menos<br>para 74 mais)|  
DM,diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança;RR, risco relativo. Explicações  
a. Pequeno tamanho amostral.  
b. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos. Taxa de eventos muito baixa.  
127  
**Questão 12. Devemos usar MMCDbio anti-TNF + MTX em vezdetofacitinibe + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs?**  
|№ de<br>participan|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade|Taxas de eventos d|Su<br>o estudo (%)|mário de resulta<br>Efeito|dos<br>Efeito<br>po|s absolutos<br>tenciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|tes<br>(estudos)<br>Esc<br>1.117<br>(2 ECRs)<br>Pac<br>762<br>(1 ECR)<br>Mel|viés<br>ore (ou pontu<br>Gravea<br>ientes com es<br>Gravec<br>hora da respo|Inconsistência<br>ação) da atividade d<br>Não grave<br>core (ou pontuação)<br>Não grave<br>sta ACR 20 (seguim|indireta<br>e doença (DAS-<br>Não grave<br>da atividade de<br>Não grave<br>ento: 6 meses)|Imprecisão<br>28) < 2,6 (seguim<br>Muitograveb<br>doença (DAS-28)<br>Muitograveb|Outros<br>ento: 6 meses)<br>Nenhum<br>< 2,6 (seguime<br>Nenhum|geral da<br>evidência<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>nto: 12 meses)<br>⨁◯◯◯<br>MUITO<br>BAIXA|Comtofacitinibe +<br>MTX<br>56/553 (10,1%)<br>55/376 (14,6%)|Com<br>MMCDbio<br>anti-TNF<br>60/564<br>(10,6%)<br>66/386<br>(17,1%)|relativo(IC95<br>%)<br>RR 1,05<br>(0,74 para<br>1,48)<br>RR 1,17<br>(0,84 para<br>1,62)|Risco com<br>tofacitinib<br>e + MTX<br>101 por<br>1.000<br>146 por<br>1.000|<br>erença e<br>risco com<br>MMCDbio<br>anti-TNF<br>5 mais por<br>1.000<br>(26 menos<br>para 49 mais)<br>25 mais por<br>1.000<br>(23 menos<br>para 91 mais)|  
128  
|№ de<br>participan<br>tes<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos d<br>Comtofacitinibe +<br>MTX|Su<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|mário de result<br>Efeito<br>relativo(IC95<br>%)|ados<br>Efeito<br>po<br>Risco com<br>tofacitinib<br>e + MTX|s absolutos<br>tenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1.157<br>(2 ECRs)<br>Mel<br>762<br>(1 ECR)<br>Mel<br>762<br>(1 ECR)|Gravea<br>hora da respo<br>Gravec<br>hora da respo<br>Gravec|Não grave<br>sta ACR 20 (seguim<br>Não grave<br>sta ACR 50 (seguim<br>Não grave|Não grave<br>ento: 12 meses<br>Não grave<br>ento: 12 meses<br>Não grave|Graved<br>)<br>Graved<br>)<br>Graved|Nenhum<br>Nenhum<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA<br>⨁⨁◯◯<br>BAIXA|376/572 (65,7%)<br>264/376 (70,2%)<br>179/376 (47,6%)|368/585<br>(62,9%)<br>261/386<br>(67,6%)<br>177/386<br>(45,9%)|RR 0,96<br>(0,89 para<br>1,04)<br>RR 0,96<br>(0,88 para<br>1,06)<br>RR 0,96<br>(0,83 para<br>1,12)|657 por<br>1.000<br>702 por<br>1.000<br>476 por<br>1.000|26 menos por<br>1.000<br>(72 menos<br>para 26 mais)<br>28 menos por<br>1.000<br>(84 menos<br>para 42 mais)<br>19 menos por<br>1.000<br>(81 menos<br>para 57 mais)|  
129  
|№ de<br>participan<br>tes<br>(estudos)<br>Mel<br>762<br>(1 ECR)<br>Índi|Risco de<br>viés<br>hora da respo<br>Gravec<br>ce da incapac|Inconsistência<br>sta ACR 70 (seguim<br>Não grave<br>idade do questionár|Avaliação da<br>Evidência<br>indireta<br>ento: 12 meses<br>Não grave<br>io de avaliação|qualidade<br>Imprecisão<br>)<br>Graved<br>em saúde (HAQ-D|Outros<br>Nenhum<br>I); DMI = −0,|Qualidade<br>geral da<br>evidência<br>⨁⨁◯◯<br>BAIXA<br>375 (seguimento:|Taxas de eventos d<br>Comtofacitinibe +<br>MTX<br>109/376 (29,0%)<br>3 meses)|Su<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF<br>100/386<br>(25,9%)|mário de resulta<br>Efeito<br>relativo(IC95<br>%)<br>RR 0,89<br>(0,71 para<br>1,13)|dos<br>Efeito<br>po<br>Risco com<br>tofacitinib<br>e + MTX<br>290 por<br>1.000|s absolutos<br>tenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF<br>32 menos por<br>1.000<br>(84 menos<br>para 38 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
130  
|№ de<br>participan<br>tes<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos d<br>Comtofacitinibe +<br>MTX|Su<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|mário de resulta<br>Efeito<br>relativo(IC95<br>%)|dos<br>Efeito<br>po<br>Risco com<br>tofacitinib<br>e + MTX|s absolutos<br>tenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1.140<br>(2 ECRs)<br>Efei<br>1.170<br>(2 ECRs)|Gravea<br>tos adversos<br>Gravea|Gravee<br>graves (seguimento:<br>Não grave|Não grave<br>12 meses)<br>Não grave|Graved<br>Muitograveb|Nenhum<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|564<br>37/580 (6,4%)|576<br>31/590<br>(5,3%)|-<br>RR 0,82<br>(0,52 para<br>1,31)|A média<br>do índice<br>de<br>incapacida<br>de do<br>questionár<br>io de<br>avaliação<br>em saúde<br>foi 0<br>64 por<br>1.000|DM0,04<br>maior<br>(0,04 menor<br>para 0,11<br>maior)<br>11 menos por<br>1.000<br>(31 menos<br>para 20 mais)|  
131  
|№ de<br>participan|Risco de||Avaliação da<br>Evidência|qualidade||Qualidade|Taxas de eventos d|Su<br>o estudo (%)|mário de result<br>Efeito|ados<br>Efeito<br>pot|s absolutos<br>enciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|tes<br>(estudos)<br>Infe<br>1.170<br>(2 ECRs)<br>Hep<br>789<br>(2 ECRs)<br>Neo|viés<br>cções graves<br>Gravea<br>atotoxicidade<br>Gravea<br>plasias|Inconsistência<br>(seguimento: 12 me<br>Não grave<br>(ALT acima de 3 v<br>Não grave|indireta<br>ses)<br>Não grave<br>ezes o limite su<br>Não grave|Imprecisão<br>Muito graveb<br>perior do valor no<br>Muito grave|Outros<br>Nenhum<br>rmal) (seguime<br>Nenhum|geral da<br>evidência<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>nto: 12 meses)<br>⨁◯◯◯<br>MUITO<br>BAIXA|Comtofacitinibe +<br>MTX<br>12/580 (2,1%)<br>34/390 (8,7%)|Com<br>MMCDbio<br>anti-TNF<br>7/590<br>(1,2%)<br>30/399<br>(7,5%)|relativo(IC95<br>%)<br>RR 0,57<br>(0,23 para<br>1,44)<br>RR 0,86<br>(0,54 para<br>1,36)|Risco com<br>tofacitinib<br>e + MTX<br>21 por<br>1.000<br>87 por<br>1.000|<br>erença e<br>risco com<br>MMCDbio<br>anti-TNF<br>9 menos por<br>1.000<br>(16 menos<br>para 9 mais)<br>12 menos por<br>1.000<br>(40 menos<br>para 31 mais)|  
132  
|№ de<br>participan<br>tes<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da<br>Evidência<br>indireta|qualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos d<br>Comtofacitinibe +<br>MTX|Su<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|mário de resulta<br>Efeito<br>relativo(IC95<br>%)|dos<br>Efeito<br>po<br>Risco com<br>tofacitinib<br>e + MTX|s absolutos<br>tenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|762<br>(1 ECR)|Gravec|Não grave|Não grave|Muito gravef|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|0/376 (0,0%)|0/386<br>(0,0%)|Não<br>estimável|0 por<br>1.000|0 menos por<br>1.000<br>(0 menos<br>para 0<br>menos)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado;IC,intervalo de confiança; RR, risco relativo.  
a. Alocação sigilosa e cegamento não foram descritos apropriadamente no estudo de van Vollenhoven et al. (2012)26. O estudo de Fleischmann et al. (2017)29 apresentou problemas relacionados a dados incompletos de desfecho.  
b. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos. Baixa taxa de eventos.  
c. O estudo de Fleischmann et al. (2012)29 apresentou problemas relacionados a dados incompletos de desfecho.  
d. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
e. Alta heterogeneidade não explicada (I2 93%).  
f. Taxa de eventos muito baixa.  
133  
**Questão 13. Devemos usar MMCDbio anti-TNF em vez de tofacitinibe em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDs?**  
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|A<br> <br>Inconsistên<br>cia|valiação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão<br>|Outros<br>Melhora da|Qualidade<br>geral da<br>evidência<br>resposta ACR<br>|Taxas de evento<br>Comtofacitinibe<br>20 (seguimento: 1|s do estudo (%)<br>Com<br>MMCDbio<br>anti-TNF<br>2 semanas)|Sumário de res<br>Efeito<br>relativo(IC95%)|ultados<br>Efeitos abs<br>Risco<br>comtofacitinibe|olutos potenciais<br>Diferença de risco<br>com MMCDbio anti-<br>TNF<br>231 menos por 1.000|
|---|---|---|---|---|---|---|---|---|---|---|---|
|102<br>(1 ECR)<br>102<br>(1 ECR)<br>102<br>(1 ECR)|Não<br>grave<br>Não<br>grave<br>Não<br>grave|Não grave<br>Não grave<br>Não grave<br>Índice|Não<br>grave<br>Não<br>grave<br>Não<br>grave<br>da incapaci|Muitogravea<br> <br>Muitogravea<br> <br>Muitograveb<br>dade física do|Nenhum<br>Melhora da<br>Nenhum<br>Melhora da<br>Nenhum<br>questionário|⨁⨁◯◯<br>BAIXA<br>resposta ACR<br>⨁⨁◯◯<br>BAIXA<br>resposta ACR<br>⨁⨁◯◯<br>BAIXA<br>de avaliação|29/49 (59,2%)<br>50 (seguimento: 1<br>18/49 (36,7%)<br>70 (seguimento: 1<br>6/49 (12,2%)<br>em saúde (HAQ-D|19/53 (35,8%)<br>2 semanas)<br>10/53 (18,9%)<br>2 semanas)<br>2/53 (3,8%)<br>I) DMI = −0,375|RR 0,61<br>(0,39 para 0,93)<br>RR 0,51<br>(0,26 para 1,00)<br>RR 0,31<br>(0,07 para 1,46)<br>(seguimento: 12 se|592 por 1.000<br>367 por 1.000<br>122 por 1.000<br>manas)|<br>(361 menos para 41<br>menos)<br>180 menos por 1.000<br>(272 menos para 0<br>menos)<br>84 menos por 1.000<br>(114 menos para 56<br>mais)|  
134  
|№ de<br>|Risco de|A<br> <br>Inconsistên|valiação da q<br>Evidência|ualidade<br>||Qualidade<br>|Taxas de eventos|do estudo (%)<br>Com|Sumário de re<br>Efeito|sultados<br>Efeitos abs|olutos potenciais<br>Diferença de risco|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|viés|cia|indireta|Imprecisão|Outros|geral da<br>evidência|Comtofacitinibe|<br>MMCDbio<br>anti-TNF|relativo(IC95%)|Risco<br>comtofacitinibe|<br>com MMCDbio anti-<br>TNF|
|92<br>(1 ECR)|Não<br>grave|Não grave|Não<br>grave|Gravea|Nenhum<br>Efeitos ad|⨁⨁⨁◯<br>MODERA<br>DA<br>versos graves|46<br>(seguimento: 24 se|46<br>manas)|-<br>RR 2,78|A média do<br>índice de<br>incapacidade<br>física do<br>questionário de<br>avaliação em<br>saúde foi 0|DM0,19 maior<br>(0,15 maior para 0,23<br>maior)<br>0 menos por 1.000|
|102<br>(1 ECR)<br>|Não<br>grave<br>|Não grave|Não<br>grave<br>|Muito<br>gravec|Nenhum<br>Infecç|⨁⨁◯◯<br>BAIXA<br>ões graves (se<br>|0/49 (0,0%)<br>guimento: 24 sema|1/53 (1,9%)<br>nas)|<br>(0,12 para<br>66,62)|0 por 1.000|<br>(0 menos para 0<br>menos)|
|102<br>(1 ECR)|Não<br>grave|Não grave|Não<br>grave<br>Hepatoto|Muito grave<br>xicidade (ALT|Nenhum<br>acima de 3|⨁⨁◯◯<br>BAIXA<br>vezes o limite|0/49 (0,0%)<br>superior do valor n|0/53 (0,0%)<br>ormal) (seguime|Não combinado<br>nto: 24 semanas)|Não combinado|Não combinado|  
135  
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|Av<br>Inconsistên<br>cia|aliação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos<br>Comtofacitinibe|do estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|Sumário de re<br>Efeito<br>relativo(IC95%)|sultados<br>Efeitos abs<br>Risco<br>comtofacitinibe|olutos potenciais<br>Diferença de risco<br>com MMCDbio anti-<br>TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|102<br>(1 ECR)|Não<br>grave|Não grave|Não<br>grave|Muito<br>graveb|Nenhum|⨁⨁◯◯<br>BAIXA|1/49 (2,0%)|0/53 (0,0%)|RR 0,31<br>(0,01 para 7,40)|20 por 1.000|14 menos por 1.000<br>(20 menos para 131<br>mais)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Apenas um estudo com pequeno tamanho de amostra e baixa taxa de eventos.  
b. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos. Taxa de eventos muito baixa.  
c. Taxa de eventos muito baixa.  
136  
**Questão 14. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro MMCDbio anti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbio anti-TNF?**  
|№ de<br>participantes<br>(estudos)<br>Escore (ou<br>1.079<br>(4 estudos<br>observacionais<br>)a|Risco de<br>viés<br>pontuação) da<br>Graveb|A<br>Inconsistência<br>atividade de doença<br>Não grave|valiação da qua<br>Evidência<br>indireta<br>(DAS-28) – Est<br>Gravec|lidade<br>Imprecisão<br>udos observacion<br>Não grave|Outros<br>ais; DMI = 1,1<br>Nenhum|Qualidade<br>geral da<br>evidência<br>7 (seguimento: 6<br>⨁◯◯◯<br>MUITO<br>BAIXA|Taxas de e<br>estud<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX<br>-31 meses; mai<br>511|<br>ventos do<br>o (%)<br>Com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX<br>or pontuação i<br>568|Sumário de<br>Efeito<br>relativo<br>(IC95%)<br>ndica ativid<br>-|resultados<br>Efeitos absol<br>Risco com<br>MMCDbioan<br>ti-TNF +<br>MTX<br>ade de doença m<br>A média do<br>escore (ou<br>pontuação)<br>da atividade<br>de doença<br>(DAS-28) foi<br>0|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX<br>ais grave)<br>DM0,37<br>menor<br>(0,52 menor<br>para 0,21<br>menor)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
Escore (ou pontuação) da atividade de doença (DAS-28) – ECR; DMI = -1,17 (seguimento: 13 meses)  
137  
|№ de||A|valiação da qua|lidade||Qualidade|Taxas de e<br>estud|ventos do<br>o (%)<br>|Sumário de<br>Efeito|resultados<br>Efeitos absol|utos potenciais<br>if d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|Risco de<br>viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outros|<br>geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF +<br>MTX|Com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|relativo<br>(IC95%)|Risco com<br>MMCDbioan<br>ti-TNF +<br>MTX|Derença e<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX|
|292<br>(1 ECR)d|Gravee|Não grave|Gravef|Não grave|Nenhum|⨁⨁◯◯<br>BAIXA|146|146|-|A média do<br>escore (ou<br>pontuação)<br>da atividade<br>de doença<br>(DAS-28) foi<br>0|DM0,38<br>menor<br>(0,69 menor<br>para 0,08<br>menor)|  
Questionário de avaliação em saúde (HAQ) (qualidade de vida) – Estudos observacionais; DMI = -0,375 (seguimento: 6 meses; escala de: 0 para 3)  
|47<br>(1 estudo<br>observacional)<br>g|Graveh|Não grave|Gravei|Grave|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|21<br>26|-|A média do<br>questionário<br>de avaliação<br>em saúde foi<br>0|DM0,36<br>maior<br>(0,08 maior<br>para 0,64<br>maior)|
|---|---|---|---|---|---|---|---|---|---|---|
|||Questionário de avali|ação em saúde (|HAQ) (qualidad|e de vida) – ECR|; DMI = -0,375 (s|eguimento: 13 meses; escala|de: 0 para 3|)||  
138  
|№ de||A|valiação da qua|lidade||Qualidade|Taxas de e<br>estud|ventos do<br>o (%)<br>Cm|Sumário de<br>Efeito|resultados<br>Efeitos absol|utos potenciais<br>Difrn d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|Risco de<br>viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outros|geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF +<br>MTX|o<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|relativo<br>(IC95%)|Risco com<br>MMCDbioan<br>ti-TNF +<br>MTX|eeça e<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX|
|292<br>(1 ECR)d<br>1.111<br>(1 estudo<br>observacional)<br>j|Gravee<br>Não grave|Não grave<br>Não grave|Gravef<br>Efeitos a<br>Gravek|Não grave<br>dversos graves - E<br>Gravel|Nenhum<br>studos observa<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>cionais (seguim<br>⨁◯◯◯<br>MUITO<br>BAIXA|146<br>ento: 6 meses)<br>56/507<br>(11,0%)|146<br> <br>82/604<br>(13,6%)|-<br>RR 1,23<br>(0,89 para<br>1,69)|A média do<br>questionário<br>de avaliação<br>em saúde foi<br>0<br>110 por<br>1.000|DM0,02<br>menor<br>(0,13 menor<br>para 0,09<br>maior)<br>25 mais por<br>1.000<br>(12 menos<br>para 76 mais)|  
Efeitos adversos graves - ECR (seguimento: 13 meses)  
139  
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|A<br>Inconsistência|valiação da qua<br>Evidência<br>indireta|lidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de e<br>estud<br>Com<br>MMCDbio<br>anti-TNF +<br>MTX|ventos do<br>o (%)<br>Com<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|Sumário de<br>Efeito<br>relativo<br>(IC95%)|resultados<br>Efeitos absol<br>Risco com<br>MMCDbioan<br>ti-TNF +<br>MTX|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX|
|---|---|---|---|---|---|---|---|---|---|---|---|
|292<br>(1 ECR)d<br>1.227<br>(2 estudos<br>observacionais<br>)m|Gravee<br>Não grave|Não grave<br>Não grave|Gravef<br>Reações<br>Gravef<br>Infec|Gravel<br>infusionais/reaçõ<br>Gravel<br>ções graves – Estu|Nenhum<br>es no local da i<br>Nenhum<br>dos observacio|⨁◯◯◯<br>MUITO<br>BAIXA<br>njeção (seguime<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>nais (seguiment|8/146<br>(5,5%)<br>nto: 6 meses)<br>29/573<br>(5,1%)<br>o: 6 meses)|16/146<br>(11,0%)<br>67/654<br>(10,2%)|RR 2,00<br>(0,88 para<br>4,53)<br>RR 0,75<br>(0,04 para<br>13,86)|55 por 1.000<br>51 por 1.000|55 mais por<br>1.000<br>(7 menos para<br>193 mais)<br>13 menos por<br>1.000<br>(49 menos<br>para 651<br>mais)|  
140  
|№ de||A|valiação da qual|idade||Qualidade|Taxas de e<br>estud|ventos do<br>o (%)<br>C|Sumário de<br>Efeito|resultados<br>Efeitos absol|utos potenciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|Risco de<br>viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outros|<br>geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF +<br>MTX|om<br>MMCDbio<br>não anti-<br>TNF +<br>MTX|relativo<br>(IC95%)|Risco com<br>MMCDbioan<br>ti-TNF +<br>MTX|erença e<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX|
|1.111<br>(1 estudo<br>observacional)<br>j<br>292<br>(1 ECR)d|Não grave<br>Gravee|Não grave<br>Não grave|Gravek<br>Gravef|Gravel<br>Infecções grav<br>Gravel|Nenhum<br>es - ECR (segu<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>imento: 13 mes<br>⨁◯◯◯<br>MUITO<br>BAIXA|9/507<br>(1,8%)<br>es)<br>10/146<br>(6,8%)|23/604<br>(3,8%)<br>7/146<br>(4,8%)|RR 2,15<br>(1,00 para<br>4,59)<br>RR 1,03<br>(0,22 para<br>4,78)|18 por 1.000<br>68 por 1.000|20 mais por<br>1.000<br>(0 menos para<br>64 mais)<br>2 mais por<br>1.000<br>(53 menos<br>para 259<br>mais)|  
DM,diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Kekow et al. (2012)34; Wakabayashi et al. (2012)35; Finckh et al. (2007)36.  
b. Alto risco de viés de confusão; medidas para ajustar para variáveis confundidoras não foram descritas em três estudos (Kekow et al., 201234; Wakabayashi et al., 201235; Finckh et al. 200736).  
c. Nem todos os pacientes receberam MTX concomitantemente: aproximadamente 52%, 50%, 85% e 66% no estudo de Emery et al.(2014)37, Kekow et al. (2012)34; Wakabayashi et al. (2012)35; e Finckh et al. (2007)36, respectivamente. d. Gottenberg et al. (2016)38.  
141  
- e. Risco de viés grave devido ao não cegamento.  
- f. Nem todos os pacientes receberam MTX concomitantemente: 65% no grupo MMCDbio não anti-TNF e 60% no grupo MMCDbio anti-TNF (Gottenberg et al. 2016 38)  
- g. Kekow et al. (2012)34  
- h. Alto risco de viés de confusão; medidas para ajustar para variáveis confundidoras não foram descritas.  
- i. Nem todos os pacientes receberam MTX concomitantemente: aproximadamente 50% (Kekow, 201234).  
- j. Emery et al. (2014)37.  
- k. Nem todos os pacientes receberam MTX concomitantemente: aproximadamente 52% (Emery et al., 201437).  
- l. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos. Baixo tamanho amostral e taxa de eventos.  
- m. Finckh et al. (2007)36; Emery et al. (2014)37.  
142

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|Aval<br>Inconsistência|iação da qualida<br>Evidência<br>indireta|de<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de e<br>estudo<br>Com<br>MMCDbioan<br>ti-TNF|Su<br>ventos do<br>(%)<br>Com<br>MMCDbi<br>o não<br>anti-TNF|mário de res<br>Efeito<br>relativo(<br>IC95%)|ultados<br>Efeitos absol<br>Risco com<br>MMCDbioan<br>ti-TNF|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|  
Escore (ou pontuação) da atividade de doença (DAS-28) (Interpretação da diferença de média padronizada de acordo com a diretriz de Cohen: efeito pequeno –DMP = 0,2; efeito moderado  
- DMP = 0,5; efeito grande –DMP = 0,8) (seguimento: 6 meses; maior pontuação indica atividade de doença mais grave)  
|1.740<br>(3 estudos<br>observacionai<br>s)a|Não grave|Não grave|Graveb|Gravec|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|1.212|528|-|-|DMP0,02<br>maior<br>(0,16 menor<br>para 0,2<br>maior)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
Escore (ou pontuação) da atividade de doença (DAS-28); DMI = -1,17 (seguimento: 12 meses)  
143  
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|Aval<br>Inconsistência|iação da qualida<br>Evidência<br>indireta|de<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de e<br>estudo<br>Com<br>MMCDbioan<br>ti-TNF|Su<br>ventos do<br>(%)<br>Com<br>MMCDbi<br>o não<br>anti-TNF|mário de res<br>Efeito<br>relativo(<br>IC95%)|ultados<br>Efeitos absol<br>Risco com<br>MMCDbioan<br>ti-TNF|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|195<br>(1 ECR)d|Gravee|Não grave|Não grave|Gravef|Nenhum|⨁⨁◯◯<br>BAIXA|102|93|-|A média do<br>escore (ou<br>pontuação)<br>da atividade<br>de doença<br>(DAS-28) foi<br>0|DM0,09<br>maior<br>(0,3 menor<br>para 0,49<br>maior)|  
Questionário de avaliação em saúde (HAQ) (qualidade de vida) (Interpretação da diferença de média padronizada de acordo com a diretriz de Cohen: efeito pequeno –DMP = 0,2; efeito moderado –DMP = 0,5; efeito grande - DMP = 0,8) (seguimento: 6 meses; escala de: 0 para 3)  
|1.198<br>(3 estudos<br>observacionai<br>s)a|Não grave|Não grave|Graveb|Graveg<br>Morte|Nenhum<br>ou efeitos adve|⨁◯◯◯<br>MUITO<br>BAIXA<br>rsos graves|881|317|-|-|DMP0,3<br>maior<br>(0,02 menor<br>para 0,63<br>maior)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
144  
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|Aval<br>Inconsistência|iação da qualida<br>Evidência<br>indireta|de<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de ev<br>estudo<br>Com<br>MMCDbioan<br>ti-TNF|Su<br>entos do<br>(%)<br>Com<br>MMCDbi<br>o não<br>anti-TNF|mário de res<br>Efeito<br>relativo(<br>IC95%)|ultados<br>Efeitos absol<br>Risco com<br>MMCDbioan<br>ti-TNF|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|196<br>(1 estudo<br>observacional<br>)h|Não grave|Não grave|Não grave|Não grave|Nenhum|⨁⨁◯◯<br>BAIXA|Nenhu|ma morte ou|efeito adver|so grave foram r|elatados.|  
DM, diferença média; DMP, diferença média padronizada; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Chatzidionysiou et al. (2013)39; Kekow et al. (2012)34; Soliman et al. (2012)40.  
b. Mais de 50% dos participantes recebiam MTX.  
c. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
d. Manders et al. (2015)41.  
- e. Manders et al. (2015)41: sem sigilo de alocação e cegamento.  
f. Apenas um estudo com pequeno tamanho amostral.  
- g. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
- h. Kekow et. al. (2012)34.  
145  
**Questão 16. Devemos usar MMCDbio não anti-TNF + MTX em vez de outro MMCDbio anti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio anti-TNF?**  
|№ de<br>participantes<br>(estudos)<br> <br>108(1 estudo|Risco de<br>viés<br>Escore (ou pon|Ava<br>Inconsistência<br>tuação) da atividad|liação da qualid<br>Evidência<br>indireta<br>e de doença (D|ade<br>Imprecisão<br>AS-28); DMI = -1|Outros<br>,17 (seguiment|Qualidade<br>geral da<br>evidência<br>o: mediana 11<br>⨁◯◯◯|Taxas de eventos<br>Com<br>MMCDbioanti-T<br>NF + MTX<br>meses; maior pontua|Sumário<br>do estudo (%)<br>Com<br>MMCDbio<br>não anti-TNF<br>+ MTX<br>ção indica ativid|de resultad<br>Efeito<br>relativo<br>(IC95%)<br>ade de doenç|os<br>Efeito<br>po<br>Risco com<br>MMCDbi<br>o<br>anti-TNF<br>+ MTX<br>a mais grav<br>A média<br>do escore<br>(ou<br>pontuação|s absolutos<br>tenciais<br> <br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX<br>e)<br>DM0,35<br>maior|
|---|---|---|---|---|---|---|---|---|---|---|---|
|observacional<br>)a|Não grave|Não grave|Graveb|Gravec|Nenhum|MUITO<br>BAIXA|19|89|-|) da<br>atividade<br>de doença<br>(DAS-28)<br>foi 0|(0,1 menor<br>para 0,8<br>maior)|  
Infecções graves  
146  
|||Ava|liação da qualid|ade|||Taxas de evento|Sumári<br>s do estudo (%)|o de resultado|s<br>Efeito<br>po|s absolutos<br>tenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|№ de<br>participantes<br>(estudos)|Risco de<br>viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Com<br>MMCDbioanti-T<br>NF + MTX|Com<br>MMCDbio<br>não anti-TNF<br>+ MTX|Efeito<br>relativo<br>(IC95%)|Risco com<br>MMCDbi<br>o<br>anti-TNF<br>+ MTX|<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF<br>+ MTX|
|5.334(2<br>estudos<br>observacionai<br>s)d|Não grave|Não grave|Gravee|Gravef|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|297/3.790<br>(7,8%)|116/1.544<br>(7,5%)|RR 0,94<br>(0,76 para<br>1,15)|78 por<br>1.000|5 menos por<br>1.000<br>(19 menos<br>para 12 mais)|  
DM, diferença média; DMI, diferença minimamente importante; IC, intervalo de confiança; RR, risco relativo.  
Explicações  
a. Finck et al. (2010)42.  
b. Evidência indireta: a maioria dos pacientes desse estudo, mas não todos, estava tomando MMCD sintéticos com os MMCDbio (Finckh et al., 201042).  
c. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral (N = 108) (Finckh et al., 201042).  
d. Johnston et al. (2013)43 e Harrold et al. (2015)44.  
eEvidência indireta: a maioria dos pacientes desse estudo, mas não todos, estava tomando MMCD sintéticos com os MMCDbio (Johnston et al., 201343).  
f. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
147

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|№ de<br>|Risco de|Ava<br>|liação da qualid<br>Evidência|ade<br>||Qualidade<br>|Taxas de eve<br>(|Sum<br>ntos do estudo<br>%)|ário de resulta<br>Efeito<br>|dos<br>Efeitos absol|utos potenciais<br>Diferença de|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>513<br>(2 estudos<br>observaciona<br>is)<br>303<br>(1 estudo<br>observaciona<br>l)|viés<br>Gravea<br>Gravea|Inconsistência<br>Escore<br>Não grave<br>Não grave|indireta<br>(ou pontuação)<br>Não grave<br>Boa resp<br>Não grave|Imprecisão<br>da atividade de d<br>Não grave<br>osta ao critério E<br>Não grave|Outros<br>oença (DAS-28<br>Nenhum<br>ULAR (atividad<br>Nenhum|geral da<br>evidência<br>); DMI = -1,17<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>e da doença) (s<br>⨁◯◯◯<br>MUITO<br>BAIXA|Com<br>MMCDbioant<br>i-TNF<br>(seguimento: me<br>265<br>eguimento: 12 m<br>60/182<br>(33,0%)|Com<br>MMCDbio<br>não anti-TNF<br>diana 11-12 mes<br>248<br>eses)<br>64/121<br>(52,9%)|relativo<br>(IC95%)<br>es)<br>-<br>RR 1,60<br>(1,23 para<br>2,10)|Risco com<br>MMCDbioa<br>nti-TNF<br>A média do<br>escore (ou<br>pontuação)<br>da atividade<br>de doença<br>(DAS-28)<br>foi 0<br>330 por<br>1.000|<br>risco com<br>MMCDbio<br>não anti-TNF<br>DM0,3 menor<br>(0,56 menor<br>para 0,03<br>menor)<br>198 mais por<br>1.000<br>(76 mais para<br>363 mais)|  
148  
|№ de<br>participantes<br>(estudos)<br>4.332<br>(1 estudo<br>observaciona<br>l)|Risco de<br>viés<br>Não grave|Ava<br>Inconsistência<br>Não grave|liação da qualid<br>Evidência<br>indireta<br>Graveb|ade<br>Imprecisão<br>Infecçõ<br>Gravec|Outros<br>es graves (segu<br>Nenhum|Qualidade<br>geral da<br>evidência<br>imento: 12 mes<br>⨁◯◯◯<br>MUITO<br>BAIXA|Taxas de eve<br>(<br>Com<br>MMCDbioant<br>i-TNF<br>es)<br>283/3.053<br>(9,3%)|Sum<br>ntos do estudo<br>%)<br>Com<br>MMCDbio<br>não anti-TNF<br>113/1.279<br>(8,8%)|ário de result<br>Efeito<br>relativo<br>(IC95%)<br>RR 0,95<br>(0,77 para<br>1,17)|ados<br>Efeitos absol<br>Risco com<br>MMCDbioa<br>nti-TNF<br>93 por 1.000|utos potenciais<br>Diferença de<br>risco com<br>MMCDbio<br>não anti-TNF<br>5 menos por<br>1.000<br>(21 menos<br>para 16 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
DM, diferença média; DMI, diferença minimamente importante; IC, intervalo de confiança; RR, risco relativo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
a. Alto risco de viés de seleção: os pacientes do grupo que recebeu rituximabe tinham uma atividade da doença maior e haviam apresentado mais falhas terapêuticas prévias (Gomez-Reino et al., 201245).  
b. Evidência indireta: a maioria dos pacientes desse estudo, mas não todos, estava tomando MMCD sintéticos com os MMCDbio (Johnston et al., 201343).  
c. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
149

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|№ de|||Avaliação da qua|lidade|||Taxas de event<br>Com|<br>os do estudo (%)|Sumário de res<br>|ultados<br>Efeitos ab<br>Risco com|solutos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>355<br>(1 ECR)<br>395<br>(1 ECR)|Risco de viés<br>Não grave<br>Não grave|Inconsistência<br>Não grave<br>Não grave|Evidência indireta<br>Escore (ou po<br>Gravea<br>Gravea<br>Questionário|Imprecisão<br>ntuação) da ativ<br>Graveb<br>ACR 2<br>Graveb<br>de avaliação e|Outros<br>idade de doença<br>Nenhum<br>0 response (segu<br>Nenhum<br>m saúde (HAQ)|Qualidade geral da<br>evidência<br>(DAS-28) < 2,6 (s<br>⨁⨁◯◯<br>BAIXA<br>imento: 6 meses)<br>⨁⨁◯◯<br>BAIXA<br>; DMI = -0,375 (se|<br>MMCDbio<br>anti-TNF +<br>MTX<br>eguimento: 6<br>12/178<br>(6,7%)<br>94/199<br>(47,2%)<br>guimento: 3 m|Com oral<br>tofacitinibe +<br>MTX<br>meses)<br>11/177<br>(6,2%)<br>101/196<br>(51,5%)<br>eses)|Efeito relativo<br>(IC95%)<br>RR 0,92<br>(0,42 para<br>2,03)<br>RR 1,09<br>(0,89 para<br>1,33)|<br>MMCDbio<br>anti-TNF +<br>MTX<br>67 por<br>1.000<br>472 por<br>1.000|Diferença de risco<br>com tofacitinibe +<br>MTX<br>5 menos por<br>1.000<br>(39 menos<br>para 69 mais)<br>43 mais por<br>1.000<br>(52 menos<br>para 156 mais)|  
150  
|№ de|||Avaliação da qua|lidade||Qualidade geral da|Taxas de even<br>Com|S<br>tos do estudo (%)<br>|umário de re<br>Efeito relativo|sultados<br>Efeitos abs<br>Risco com|olutos potenciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|Risco de viés|Inconsistência|Evidência indireta|Imprecisão|Outros|<br>evidência|MMCDbio<br>anti-TNF +<br>MTX|Com oral<br>tofacitinibe +<br>MTX|(IC95%)|MMCDbio<br>anti-TNF +<br>MTX|Diferença de risco<br>com tofacitinibe +<br>MTX|
|378<br>(1 ECR)<br>408<br>(1 ECR)<br>408<br>(1 ECR)|Não grave<br>Não grave<br>Não grave|Não grave<br>Não grave<br>Não grave|Gravea<br>Gravea<br>Gravea|Graveb<br>Efeitos adv<br>Graveb<br>Infecçõ<br>Graveb|Nenhum<br>ersos graves (se<br>Nenhum<br>es graves (segui<br>Nenhum|⨁⨁◯◯<br>BAIXA<br>guimento: 12 mese<br>⨁⨁◯◯<br>BAIXA<br>mento: 12 meses)<br>⨁⨁◯◯<br>BAIXA|190<br>s)<br>7/204<br>(3,4%)<br>1/204<br>(0,5%)|188<br>10/204<br>(4,9%)<br>2/204 (1,0%)|-<br>RR 1,43<br>(0,55 para<br>3,68)<br>RR 2,00<br>(0,18 para<br>21,88)|A média<br>Questionár<br>io de<br>avaliação<br>em saúde<br>(HAQ) foi<br>0<br>34 por<br>1.000<br>5 por 1.000|DM0,06<br>menor<br>(0,07 menor<br>para 0,05<br>menor)<br>15 mais por<br>1.000<br>(15 menos<br>para 92 mais)<br>5 mais por<br>1.000<br>(4 menos para<br>102 mais)|  
151  
|№ de|||Avaliação da qua|lidade|||Taxas de even<br>Com|S<br>tos do estudo (%)|umário de re<br>|sultados<br>Efeitos abs<br>Risco com|olutos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)<br>407<br>(1 ECR)<br>407<br>(1 ECR)|Risco de viés<br>Não grave<br>Não grave|Inconsistência<br> <br>Não grave<br> <br>Não grave|Evidência indireta<br>Hepatotoxicidade (A<br>Gravea<br>Hepatotoxicidade (A<br>Gravea|Imprecisão<br>ST acima de 3 v<br>Graveb<br>LT acima de 3 v<br>Graveb|Outros<br>ezes o limite su<br>Nenhum<br>ezes o limite su<br>Nenhum|Qualidade geral da<br>evidência<br>perior do valor nor<br>⨁⨁◯◯<br>BAIXA<br>perior do valor nor<br>⨁⨁◯◯<br>BAIXA|<br>MMCDbio<br>anti-TNF +<br>MTX<br>mal) (seguim<br>0/204<br>(0,0%)<br>mal) (seguim<br>0/204<br>(0,0%)|Com oral<br>tofacitinibe +<br>MTX<br>ento: 3 meses)<br>1/203 (0,5%)<br>ento: 3 meses)<br>2/203 (1,0%)|Efeito relativo<br>(IC95%)<br>RR 3,01<br>(0,12 para<br>73,57)<br>RR 5,02<br>(0,24 para<br>104,01)|<br>MMCDbio<br>anti-TNF +<br>MTX<br>0 por 1.000<br>0 por 1.000|Diferença de risco<br>com tofacitinibe +<br>MTX<br> <br>0 menos por<br>1.000<br>(0 menos para<br>0 menos)<br> <br>0 menos por<br>1.000<br>(0 menos para<br>0 menos)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
a. Essa questão foi indiretamente avaliada por um ECR comparando tofacitinibe + MTX com adalimumabe + MTX em pacientes que haviam falhado previamente à monoterapia com MTX, e não necessariamente com MMCDbio antiTNF (Van vollenhoven et al., 201226).  
b. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral e baixa taxa de eventos (Van vollenhoven et al., 201226).  
152  
**Questão 19. Devemos usar tofacitinibe em vez de outro MMCDbio anti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos múltiplos MMCDbio antiTNF?**  
|№ de<br>articiantes|Risco de viés|Inconsistência|Avaliação da qu<br>Evidência indireta|alidade<br>Imrecisão|Outros|Qualidade geral da|Taxas de eve<br>(|ntos do estudo<br>%)|Sumário de<br>Efeito relativo|resultados<br>Efeitos ab|solutos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|pp<br>(estudos)<br>102<br>(1 ECR)<br>102<br>(1 ECR)<br>102<br>(1 ECR)|<br>Não grave<br>Não grave<br>Não grave|<br>Não grave<br>Não grave<br>Não grave|<br>Gravea<br>Gravea<br>Gravea|p<br>Mel<br>Graveb<br>Mel<br>Gravec<br>Mel<br>Muito gravec|<br>hora da respost<br>Nenhum<br>hora da respost<br>Nenhum<br>hora da respost<br>Nenhum|evidência<br>a ACR 20<br>⨁⨁◯◯<br>BAIXA<br>a ACR 50<br>⨁⨁◯◯<br>BAIXA<br>a ACR 70<br>⨁◯◯◯<br>MUITO<br>BAIXA|Com<br>MMCDbio<br>anti-TNF<br>19/53<br>(35,8%)<br>10/53<br>(18,9%)<br>2/53<br>(3,8%)|Com<br>tofacitinibe<br>29/49<br>(59,2%)<br>18/49<br>(36,7%)<br>6/49<br>(12,2%)|(IC95%)<br>RR 1,65<br>(1,08 para<br>2,53)<br>RR 1,95<br>(1,00 para<br>3,80)<br>RR 3,24<br>(0,69 para<br>15,33)|Risco com<br>MMCDbio<br>anti-TNF<br>358 por<br>1.000<br>189 por<br>1.000<br>38 por<br>1.000|153<br>Diferença de risco<br>com tofacitinibe<br>233 mais por<br>1.000<br>(29 mais para<br>548 mais)<br>179 mais por<br>1.000<br>(0 menos para<br>528 mais)<br>85 mais por<br>1.000<br>(12 menos para<br>541 mais)|  
|№ de<br>participantes|Risco de viés|Inconsistência|Avaliação da q<br>Evidência indireta|ualidade<br>Imprecisão|Outros|Qualidade geral da|Taxas de eve<br>(<br>|ntos do estudo<br>%)|Sumário de<br>Efeito relativo|resultados<br>Efeitos abs<br>|olutos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|<br>(estudos)<br>92<br>(1 ECR)<br>102<br>(1 ECR)|<br>Não grave<br>Não grave|<br>Não grave<br>Não grave|<br>Índice da i<br>Gravea<br>Gravea|<br>ncapacidade física<br>Gravec<br>E<br>Muito graved|<br>do questionári<br>Nenhum<br>feitos adversos<br>Nenhum<br>Infecções gr|evidência<br>o de avaliação em s<br>⨁⨁◯◯<br>BAIXA<br>graves<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>aves|Com<br>MMCDbio<br>anti-TNF<br>aúde (HAQ-<br>46<br>1/53<br>(1,9%)|Com<br>tofacitinibe<br>DI)<br>46<br>0/49<br>(0,0%)|(IC95%)<br>-<br>RR 0,36<br>(0,02 para<br>8,63)|Risco com<br>MMCDbio<br>anti-TNF<br>A média do<br>índice de<br>incapacidad<br>e física do<br>questionári<br>o de<br>avaliação<br>em saúde<br>foi 0<br>19 por<br>1.000|Diferença de risco<br>com tofacitinibe<br>DM0,19 menor<br>(0,49 menor<br>para 0,11<br>maior)<br>12 menos por<br>1.000<br>(18 menos para<br>144 mais)|  
154  
|№ de<br>articiantes|Risco de viés|Inconsistência|Avaliação da qu<br>Evidência indireta|alidade<br>Imrecisão|Outros|Qualidade geral da|Taxas de eve<br>(|ntos do estudo<br>%)|Sumário de<br>Efeito relativo|resultados<br>Efeitos abs|olutos potenciais|
|---|---|---|---|---|---|---|---|---|---|---|---|
|pp<br>(estudos)||||p||evidência|Com<br>MMCDbio<br>anti-TNF|Com<br>tofacitinibe|(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|Diferença de risco<br>com tofacitinibe|
|102<br>(1 ECR)<br>102<br>(1 ECR)|Não grave<br>Não grave|Não grave<br>Não grave|Gravea<br>Hepatoto<br>Gravea|Muito graved<br>xicidade (ALT aci<br>Muito graved|Nenhum<br>ma de 3 vezes<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>o limite superior d<br>⨁◯◯◯<br>MUITO<br>BAIXA|0/53<br>(0,0%)<br>o valor norma<br>1/53<br>(1,9%)|0/49<br>(0,0%)<br>l)<br>0/49<br>(0,0%)|Não<br>estimável<br>RR 0,36<br>(0,02 para<br>8,63)|0 por 1.000<br>19 por<br>1.000|<br>0 menos por<br>1.000<br>(0 menos para<br>0 menos)<br>12 menos por<br>1.000<br>(18 menos para<br>144 mais)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Evidência indireta: os pacientes randomizados haviam falhado à terapia com MMCD sintéticos, mas a falha a MMCDbio não era um critério de inclusão (Fleischmann et al., 201229).  
b. Pequeno tamanho amostral (Fleischman et al., 201229).  
c. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral (Fleischmann et al., 201229).  
d. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral e taxa de eventos muito baixa (Fleischmann et al., 201229).  
155  
**Questão 20. Devemos usar tofacitinibe + MTX em vez de outro MMCDbio anti-TNF + MTX em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbio anti-TNF e MMCDbio não anti-TNF?**  
|№ de<br>participant|Risco de||Avaliação da q<br>Evidência|ualidade||Qualidade|Taxas de eventos d|Sum<br>o estudo (%)|ário de result<br>Efeito|ados<br>Efeito<br>pot|s absolutos<br>enciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)<br>1.117<br>(2 ECRs)<br>762<br>(1 ECR)|viés<br>Gravea<br>Graved|Inconsistência<br>Não grave<br>Pa<br>Não grave|indireta<br>Escore (o<br>Graveb<br>cientes com esc<br>Graveb|Imprecisão<br>u pontuação) da ati<br>Muito gravec<br>ore (ou pontuação<br>Muito gravec<br>Melhora da|Outros<br>vidade de doe<br>Nenhum<br>) da atividade<br>Nenhum<br>resposta ACR|geral da<br>evidência<br>nça (DAS-28) <<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>de doença (DAS<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>20 (seguimento|Comtofacitinibe +<br>MTX<br>2,6 (seguimento: 6 m<br>56/553 (10,1%)<br>-28) < 2,6 (seguiment<br>55/376 (14,6%)<br>: 6 meses)|Com<br>MMCDbio<br>anti-TNF<br>eses)<br>60/564<br>(10,6%)<br>o: 12 meses)<br>66/386<br>(17,1%)|relativo<br>(IC95%)<br>RR 1,05<br>(0,74 para<br>1,48)<br>RR 1,17<br>(0,84 para<br>1,62)|Risco com<br>tofacitinib<br>e + MTX<br>101 por<br>1.000<br>146 por<br>1.000|erença e<br>risco com<br>MMCDbio<br>anti-TNF<br>5 mais por<br>1.000<br>(26 menos<br>para 49 mais)<br>25 mais por<br>1.000<br>(23 menos<br>para 91 mais)|  
156  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos d<br>Comtofacitinibe +<br>MTX|Sum<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|ário de result<br>Efeito<br>relativo<br>(IC95%)|ados<br>Efeito<br>pot<br>Risco com<br>tofacitinib<br>e + MTX|s absolutos<br>enciais<br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1.157<br>(2 ECRs)<br>762<br>(1 ECR)<br>762<br>(1 ECR)|Gravea<br>Graved<br>Graved|Não grave<br>Não grave<br>Não grave|Graveb<br>Graveb<br>Graveb|Graved<br>Melhora da<br>Gravee<br>Melhora da<br>Gravee|Nenhum<br>resposta ACR<br>Nenhum<br>resposta ACR<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>20 (seguimento:<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>50 (seguimento:<br>⨁◯◯◯<br>MUITO<br>BAIXA|376/572 (65,7%)<br>12 meses)<br>264/376 (70,2%)<br>12 meses)<br>179/376 (47,6%)|368/585<br>(62,9%)<br>261/386<br>(67,6%)<br>177/386<br>(45,9%)|RR 0,96<br>(0,89 para<br>1,04)<br>RR 0,96<br>(0,88 para<br>1,06)<br>RR 0,96<br>(0,83 para<br>1,12)|657 por<br>1.000<br>702 por<br>1.000<br>476 por<br>1.000|26 menos por<br>1.000<br>(72 menos<br>para 26 mais)<br>28 menos por<br>1.000<br>(84 menos<br>para 42 mais)<br>19 menos por<br>1.000<br>(81 menos<br>para 57 mais)|  
157  
|№ de<br>participant<br>es<br>(estudos)<br>762<br>(1 ECR)|Risco de<br>viés<br>Graved|Inconsistência<br>Não grave<br>Índice d|Avaliação da q<br>Evidência<br>indireta<br>Graveb<br>a incapacidade|ualidade<br>Imprecisão<br>Melhora da<br>Gravee<br>do questionário d|Outros<br>resposta ACR<br>Nenhum<br>e avaliação em|Qualidade<br>geral da<br>evidência<br>70 (seguimento:<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>saúde (HAQ-DI|Taxas de eventos d<br>Comtofacitinibe +<br>MTX<br>12 meses)<br>109/376 (29,0%)<br>); DMI = −0,375 (segu|Sum<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF<br>100/386<br>(25,9%)<br>imento: 3 mes|ário de result<br>Efeito<br>relativo<br>(IC95%)<br>RR 0,89<br>(0,71 para<br>1,13)<br>es)|ados<br>Efeito<br>pot<br>Risco com<br>tofacitinib<br>e + MTX<br>290 por<br>1.000|s absolutos<br>enciais<br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF<br>32 menos por<br>1.000<br>(84 menos<br>para 38 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
158  
|№ de<br>participant|Risco de||Avaliação da q<br>Evidência|ualidade<br>||Qualidade<br>|Taxas de eventos d|Sum<br>o estudo (%)|ário de result<br>Efeito<br>|ados<br>Efeito<br>pot|s absolutos<br>enciais<br>Diferença de|
|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)|viés|Inconsistência|indireta|Imprecisão|Outros|geral da<br>evidência|Comtofacitinibe +<br>MTX|Com<br>MMCDbio<br>anti-TNF|relativo<br>(IC95%)|Risco com<br>tofacitinib<br>e + MTX|<br>risco com<br>MMCDbio<br>anti-TNF|
|1.140<br>(2 ECRs)<br>1.170<br>(2 ECRs)|Gravea<br>Gravea|Gravef<br>Não grave|Graveb<br>Graveb|Gravee<br>Efeitos ad<br>Muito gravee|Nenhum<br>versos graves<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>(seguimento: 1<br>⨁◯◯◯<br>MUITO<br>BAIXA|564<br>2 meses)<br>37/580 (6,4%)|576<br>31/590<br>(5,3%)|-<br>RR 0,82<br>(0,52 para<br>1,31)|A média<br>do índice<br>de<br>incapacida<br>de do<br>questionár<br>io de<br>avaliação<br>em saúde<br>foi 0<br>64 por<br>1.000|DM0,04<br>maior<br>(0,04 menor<br>para 0,11<br>maior)<br>11 menos por<br>1.000<br>(31 menos<br>para 20 mais)|  
159  
|№ de<br>participant|Risco de||Avaliação da q<br>Evidência|ualidade||Qualidade|Taxas de eventos d|Sum<br>o estudo (%)|ário de result<br>Efeito|ados<br>Efeito<br>pot|s absolutos<br>enciais<br>Dif d|
|---|---|---|---|---|---|---|---|---|---|---|---|
|es<br>(estudos)<br>1.170<br>(2 ECRs)<br>789<br>(2 ECRs)|viés<br>Gravea<br>Gravea|Inconsistência<br>Não grave<br>H<br>Não grave|indireta<br>Graveb<br>epatotoxicidade<br>Graveb|Imprecisão<br>Infecç<br>Muito gravec<br>(ALT acima de 3<br>Muito gravec|Outros<br>ões graves (se<br>Nenhum<br>vezes o limite<br>Nenhum<br>Neop|geral da<br>evidência<br>guimento: 12 m<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>superior do val<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>lasias|Comtofacitinibe +<br>MTX<br>eses)<br>12/580 (2,1%)<br>or normal) (seguimento<br>34/390 (8,7%)|Com<br>MMCDbio<br>anti-TNF<br>7/590<br>(1,2%)<br>: 12 meses)<br>30/399<br>(7,5%)|relativo<br>(IC95%)<br>RR 0,57<br>(0,23 para<br>1,44)<br>RR 0,86<br>(0,54 para<br>1,36)|Risco com<br>tofacitinib<br>e + MTX<br>21 por<br>1.000<br>87 por<br>1.000|erença e<br>risco com<br>MMCDbio<br>anti-TNF<br>9 menos por<br>1.000<br>(16 menos<br>para 9 mais)<br>12 menos por<br>1.000<br>(40 menos<br>para 31 mais)|  
160  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eventos d<br>Comtofacitinibe +<br>MTX|Sum<br>o estudo (%)<br>Com<br>MMCDbio<br>anti-TNF|ário de result<br>Efeito<br>relativo<br>(IC95%)|ados<br>Efeito<br>pot<br>Risco com<br>tofacitinib<br>e + MTX|s absolutos<br>enciais<br>Diferença de<br>risco com<br>MMCDbio<br>anti-TNF|
|---|---|---|---|---|---|---|---|---|---|---|---|
|762<br>(1 ECR)|Graved|Não grave|Graveb|Muito graveg|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|0/376 (0,0%)|0/386<br>(0,0%)|Não<br>estimável|0 por<br>1.000|0 menos por<br>1.000<br>(0 menos para<br>0 menos)|  
ALT, alanina aminotransferase; DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Alocação sigilosa e cegamento não foram descritos apropriadamente no estudo de van Vollenhoven et al. (2012)26. O estudo de Fleischmann et al.(2017)46 apresentou problemas relacionados a dados incompletos de desfecho.  
b. Evidência indireta: os pacientes randomizados haviam falhado à terapia com MMCD sintéticos.  
c. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos. Baixa taxa de eventos.  
d. O estudo de Fleischmannet al. (2017)46 apresentou problemas relacionados a dados incompletos de desfecho.  
e. Intervalo de confiança amplo, que inclui potenciais benefícios e riscos.  
f. Alta heterogeneidade, não explicada (I2 93%).  
g. Taxa de eventos muito baixa.  
161  
**Questão 21. Devemos usar tofacitinibeem vez de outro MMCDbio anti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença que falharam à terapia aos MMCDbio anti-TNF e MMCDbio não anti-TNF?**  
|№ de|Risco de|Avali<br>Inconsistên|ação da quali<br>Evidência|dade||Qualidade|Taxas de evento<br>|Su<br>s do estudo (%)|mário de resul<br>Efeito|tados<br>Efeitos abso<br>i|lutos potenciais<br>if|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|viés|cia|indireta|Imprecisão|Outros|geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF|Com<br>tofacitinibe|relativo<br>(IC95%)|Rsco com<br>MMCDbio<br>anti-TNF|Derença de<br>risco com<br>tofacitinibe|
|102<br>(1 ECR)<br>102<br>(1 ECR)<br>102<br>(1 ECR)|Não<br>grave<br>Não<br>grave<br>Não<br>grave|Não grave<br>Não grave<br>Não grave|Gravea<br>Gravea<br>Gravea|Graveb<br>Graveb<br>Graveb|Melhora<br>Nenhum<br>Melhora<br>Nenhum<br>Melhora<br>Nenhum|da resposta A<br>⨁⨁◯◯<br>BAIXA<br>da resposta A<br>⨁⨁◯◯<br>BAIXA<br>da resposta A<br>⨁⨁◯◯<br>BAIXA|CR 20<br>19/53 (35,8%)<br>CR 50<br>10/53 (18,9%)<br>CR 70<br>2/53 (3,8%)|29/49 (59,2%)<br>18/49 (36,7%)<br>6/49 (12,2%)|RR 1,65<br>(1,08 para<br>2,53)<br>RR 1,95<br>(1,00 para<br>3,80)<br>RR 3,24<br>(0,69 para<br>15,33)|358 por 1.000<br>189 por 1.000<br>38 por 1.000|233 mais por<br>1.000<br>(29 mais para 548<br>mais)<br>179 mais por<br>1.000<br>(0 menos para<br>528 mais)<br>85 mais por 1.000<br>(12 menos para<br>541 mais)|  
162  
|№ de|Risco de|Avali<br>Inconsistên|ação da qualid<br>Evidência|ade||Qualidade|Taxas de evento<br>|Su<br>s do estudo (%)|mário de resul<br>Efeito|tados<br>Efeitos abso<br>|lutos potenciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|<br>viés|cia|<br>indireta|Imprecisão|Outros|geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF|Com<br>tofacitinibe|relativo<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|Diferença de<br>risco com<br>tofacitinibe|
|92<br>(1 ECR)<br>102<br>(1 ECR)|Não<br>grave<br>Não<br>grave|Não grave<br>Não grave|Índi<br>Gravea<br>Gravea|ce da incapacid<br>Graveb<br>Muito<br>gravec|ade física do<br>Nenhum<br>Efeit<br>Nenhum<br>In|questionário de<br>⨁⨁◯◯<br>BAIXA<br>os adversos gra<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>fecções graves|avaliação em saú<br>46<br>ves<br>1/53 (1,9%)<br>|de (HAQ-DI)<br>46<br>0/49 (0,0%)|-<br>RR 0,36<br>(0,02 para<br>8,63)|A média do<br>índice de<br>incapacidade<br>física do<br>questionário de<br>avaliação em<br>saúde foi 0<br>19 por 1.000|DM0,19 menor<br>(0,49 menor para<br>0,11 maior)<br>12 menos por<br>1.000<br>(18 menos para<br>144 mais)|  
163  
|№ de|Risco de|Aval<br>Inconsistên|iação da qualid<br>Evidência|ade||Qualidade|Taxas de evento<br>|Su<br>s do estudo (%)|mário de resul<br>Efeito|tados<br>Efeitos abso<br>|lutos potenciais<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|participantes<br>(estudos)|<br>viés|cia|<br>indireta|Imprecisão|Outros|geral da<br>evidência|Com<br>MMCDbio<br>anti-TNF|Com<br>tofacitinibe|relativo<br>(IC95%)|Risco com<br>MMCDbio<br>anti-TNF|Diferença de<br>risco com<br>tofacitinibe|
|102<br>(1 ECR)<br>102<br>(1 ECR)|Não<br>grave<br>Não<br>grave|Não grave<br>Não grave|Gravea<br>He<br>Gravea|Muito<br>gravec<br>patotoxicidade<br>Muito<br>gravec|Nenhum<br>(ALT acima<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>de 3 vezes o li<br>⨁◯◯◯<br>MUITO<br>BAIXA|0/53 (0,0%)<br>mite superior do v<br>1/53 (1,9%)|0/49 (0,0%)<br>alor normal)<br>0/49 (0,0%)|Não<br>estimável<br>RR 0,36<br>(0,02 para<br>8,63)|0 por 1.000<br>19 por 1.000|0 menos por<br>1.000<br>(0 menos para 0<br>menos)<br>12 menos por<br>1.000<br>(18 menos para<br>144 mais)|  
ALT, alanina aminotransferase;DM,diferençamédia; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Evidência indireta: os pacientes randomizados haviam falhado à terapia com MMCD sintéticos, mas a falha a MMCDbio não era um critério de inclusão (Fleischmann et al., 201229).  
b. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral (Fleischmann et al., 201229).  
c. Intervalo de confiança amplo ao redor da estimativa de efeito devido a pequeno tamanho amostral e taxa de eventos muito baixa (Fleischmann et al., 201229).  
164  
**Questão 22. Devemos adicionar glicocorticoides em altas doses por curto prazo aos MMCDcs em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença em surto agudo da doença?**  
|№ de<br>participante<br>s<br>(estudos)<br>86<br>(2 ECRs)a,b<br>115<br>(3 ECRs)e|Risco de viés<br>Não grave<br>Não grave|<br>Inconsistência<br>Escore (<br>Não grave<br>Gravef|Avaliação da quali<br>Evidência<br>indireta<br>ou pontuação) da<br>Gravec<br>Question<br>Gravec|dade<br>Imprecisão<br>atividade de doença (D<br>Graved<br>ário de avaliação em s<br>Muito graveg|Outros<br>AS-28); DMI =<br>Nenhum<br>aúde (HAQ); D<br>Nenhum|Qualidade geral<br>da evidência<br>-1,17 (seguimento: v<br>⨁⨁◯◯<br>BAIXA<br>MI = -0,375 (seguim<br>⨁◯◯◯<br>MUITO BAIXA|Taxas de e<br>Sem<br>adição<br>ariação 12<br>38<br>ento: 12 mes<br>52|Su<br>ventos do estudo<br>(%)<br>Com adição de<br>glicocorticoide<br>s em altas<br>doses<br>meses para 24 meses<br>48<br>es)<br>63|mário de resu<br>Efeito<br>relativo<br>(IC95%)<br>)<br>-<br>-|ltados<br>Efeitos abs<br>Risco sem<br>adição<br>A média do<br>escore (ou<br>pontuação)<br>da atividade<br>de doença<br>(DAS-28)<br>foi 0<br>A média<br>Questionári<br>o de<br>avaliação<br>em saúde<br>(HAQ) foi 0|olutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoides<br>em altas doses<br>DM0,37 menor<br>(0,89 menor<br>para 0,15 maior)<br>DM0,12 menor<br>(0,37 menor<br>para 0,12 maior)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
165  
|№ de<br>participante<br>s<br>(estudos)<br>26<br>(1 ECR)b<br>26<br>(1 ECR)b<br>26<br>(1 ECR)b|Risco de viés<br>Graveh<br>Graveh<br>Graveh|<br>Inconsistência<br>Não grave<br>Não grave<br>Não grave|Avaliação da quali<br>Evidência<br>indireta<br>Gravec<br>Gravec<br>Gravec|dade<br>Imprecisão<br>Melhora da resp<br>Muito graved<br>Melhora da resp<br>Muitograved<br>Melhora da resp<br>Muito graved|Outros<br>osta ACR 20 (s<br>Nenhum<br>osta ACR 50 (s<br>Nenhum<br>osta ACR 70 (s<br>Nenhum|Qualidade geral<br>da evidência<br>eguimento: 12 meses)<br>⨁◯◯◯<br>MUITO BAIXA<br>eguimento: 12 meses)<br>⨁◯◯◯<br>MUITO BAIXA<br>eguimento: 12 meses)<br>⨁◯◯◯<br>MUITO BAIXA|Taxas de e<br>Sem<br>adição<br> <br>6/12<br>(50,0%)<br> <br>5/12<br>(41,7%)<br> <br>2/12<br>(16,7%)|Su<br>ventos do estudo<br>(%)<br>Com adição de<br>glicocorticoide<br>s em altas<br>doses<br>12/14 (85,7%)<br>9/14 (64,3%)<br>8/14 (57,1%)|mário de result<br>Efeito<br>relativo<br>(IC95%)<br>RR 1,71<br>(0,94 para<br>3,14)<br>RR 1,54<br>(0,71 para<br>3,35)<br>RR 3,43<br>(0,89 para<br>13,15)|ados<br>Efeitos abs<br>Risco sem<br>adição<br>500 por<br>1.000<br>417 por<br>1.000<br>167 por<br>1.000|olutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoides<br>em altas doses<br>355 mais por<br>1.000<br>(30 menos para<br>1.070 mais)<br>225 mais por<br>1.000<br>(121 menos para<br>979 mais)<br>405 mais por<br>1.000<br>(18 menos para<br>2.025 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
166  
|№ de<br>participante<br>s<br>(estudos)<br>91<br>(1 ECR)b<br>89<br>(2 ECRs)a,b|Risco de viés<br>Graveh<br>Graveh|<br>Inconsistência<br>Não grave<br>Não grave|Avaliação da quali<br>Evidência<br>indireta<br>Progr<br>Gravec<br>Gravec|dade<br>Imprecisão<br>essão radiográfica pel<br>Muito graved<br> <br>Muito graved|Outros<br>o escore de Lars<br>Nenhum<br>Efeitos adversos<br>Nenhum|Qualidade geral<br>da evidência<br>en; DMI = 4,6; escal<br>⨁◯◯◯<br>MUITO BAIXA<br>graves<br>⨁◯◯◯<br>MUITO BAIXA|Taxas de e<br>Sem<br>adição<br>a de 0 a 448<br>A diferenç<br>intramuscu<br>3/40<br>(7,5%)|Su<br>ventos do estudo<br>(%)<br>Com adição de<br>glicocorticoide<br>s em altas<br>doses<br>a média no escore<br>lar foi 20,59 (medi<br>7/49 (14,3%)|mário de resul<br>Efeito<br>relativo<br>(IC95%)<br>de Larsen em 1<br>ana 0,00) com<br>com placebo<br>RR 2,05<br>(0,49 para<br>8,51)|tados<br>Efeitos abso<br>Risco sem<br>adição<br>2 meses com m<br>parada com 2,7<br>.<br>75 por 1.000|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoides<br>em altas doses<br>etilprednisolona<br>7 (mediana 0,00)<br>79 mais por<br>1.000<br>(38 menos para<br>563 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
Explicações  
a. Choy et al.(2005)47  
b. Durez et al. (2007)48  
c. Evidência indireta: os pacientes randomizados tinham AR recente e não estabelecida com surto agudo (Durez et al., 200748; Choy et al., 200547).  
d. Intervalo de confiança amplo ao redor da estimativa de efeito, com tamanho amostral muito pequeno (Durez et al., 200748; Choy et al., 200547).  
e. Durezet al.(2007)48; Choy et al. (2005)47; Ciconelli et al. (1996)49.  
f. Alta heterogeneidade (I2 = 54%) (Durez et al., 200748; Choy et al., 200547; Ciconelli et al., 199649). g. Intervalo de confiança amplo ao redor da estimativa de efeito devido ao tamanho amostral muito pequeno (Durez et al., 200748; Choy et al., 200547; Ciconelli et al., 199649).  h. Durez et al. (2007)48 é um ECR sem cegamento, portanto, há risco de viés de expectativa.  
167  
**Questão 23. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos MMCDcs em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença?**  
|№ de<br>participant<br>es<br>(estudos)<br>350<br>(2 ECRs)|Risco de<br>viés<br>Não grave|Inconsistência<br>Não grave|Avaliação da qu<br>Evidência<br>indireta<br>Escor<br>Não grave|alidade<br>Imprecisão<br>e (ou pontuação)<br>Não grave<br>Melhora da re|Outros<br>da atividade de<br>Nenhum<br>sposta ACR 20|Qualidade<br>geral da<br>evidência<br>doença (DAS-28<br>⨁⨁⨁⨁<br>ALTA<br>(seguimento: 3 m|Taxas de eve<br>(<br>Sem adição<br>); DMI = -1,17<br>119<br>eses)|S<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses<br> <br>231|umário de r<br>Efeito<br>relativo<br>(IC95%)<br>-|esultados<br>Efeitos abso<br>Risco sem<br>adição<br>A média<br>do escore<br>(ou<br>pontuação)<br>da<br>atividade<br>de doença<br>(DAS-28)<br>foi 0|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses<br>DM0,49<br>menor<br>(0,73 menor<br>para 0,35<br>menor)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
168  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da qu<br>Evidência<br>indireta|alidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Sem adição|S<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses|umário de re<br>Efeito<br>relativo<br>(IC95%)|sultados<br>Efeitos abso<br>Risco sem<br>adição|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses|
|---|---|---|---|---|---|---|---|---|---|---|---|
|348<br>(1 ECR)<br>486<br>(3 ECRs)|Não grave<br>Não grave|Não grave<br>Não grave|Não grave<br>Não grave|Não grave<br>Questionário de a<br>Não grave|Nenhum<br>valiação em saú<br>Nenhum|⨁⨁⨁⨁<br>ALTA<br>de (HAQ); DMI<br>⨁⨁⨁⨁<br>ALTA|36/119<br>(30,3%)<br>= -0,375<br>179|111/229<br>(48,5%)<br>307|RR 1,59<br>(1,17 para<br>2,15)<br>-|303 por<br>1.000<br>A média<br>Questionár<br>io de<br>avaliação<br>em saúde<br>(HAQ) foi<br>0|178 mais por<br>1.000<br>(51 mais para<br>348 mais)<br>DM0,32<br>menor<br>(0,36 menor<br>para 0,29<br>menor)|  
SF-36 (Componente físico) (seguimento: 3 meses; escores menores indicam maior incapacidade)  
169  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da qu<br>Evidência<br>indireta|alidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Sem adição|S<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses|umário de r<br>Efeito<br>relativo<br>(IC95%)|esultados<br>Efeitos abso<br>Risco sem<br>adição|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses|
|---|---|---|---|---|---|---|---|---|---|---|---|
|348<br>(1 ECR)<br>348<br>(1 ECR)|Gravea<br>Gravea|Não grave<br>SF<br>Não grave|Não grave<br>-36 (Component<br>Não grave|Não grave<br>e mental) (seguim<br>Graveb<br>Efeitos adv|Nenhum<br>ento: 3 meses;<br>Nenhum<br>ersos graves (s|⨁⨁⨁◯<br>MODERADA<br>escores menores in<br>⨁⨁◯◯<br>BAIXA<br>eguimento: 3 mese|119<br>dicam maior<br>119<br>s)|229<br>incapacidade)<br>229|-<br>-|A média<br>do<br>component<br>e físico do<br>SF-36 foi 0<br>A média<br>SF-36 do<br>component<br>e mental<br>do SF-36<br>foi 0|DM2,4 maior<br>(0,74 maior<br>para 4,06<br>maior)<br>DM1 maior<br>(0,94 menor<br>para 2,94<br>maior)|  
170  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Sem adição|S<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses|umário de re<br>Efeito<br>relativo<br>(IC95%)|sultados<br>Efeitos abs<br>Risco sem<br>adição|olutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses|
|---|---|---|---|---|---|---|---|---|---|---|---|
|410<br>(2 ECRs)<br>410<br>(2 ECRs)|Não grave<br>Não grave<br>Não grave|Gravec<br>Não grave<br>Não grave|Não grave<br>Efeito<br>Não grave<br>Não grave|Muito graveb<br>s adversos cardiova<br>Muito graveb<br>Muito graveb|Nenhum<br>sculares (hipot<br>Nenhum<br>Osteoporo<br>Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA<br>ensão) (seguime<br>⨁⨁◯◯<br>BAIXA<br>se|4/145<br>(2,8%)<br>nto: 3-24 meses<br>2/145<br>(1,4%)<br>0/43 (0,0%)|6/265 (2,3%)<br>)<br>9/265 (3,4%)<br>2/48 (4,2%)|RR 0,87<br>(0,13 para<br>5,93)<br>RR 2,81<br>(0,62 para<br>12,69)|28 por<br>1.000<br>14 por<br>1.000<br>Bai|4 menos por<br>1.000<br>(24 menos<br>para 136 mais)<br>25 mais por<br>1.000<br>(5 menos para<br>161 mais)<br>xo risco|  
171  
|№ de<br>participant<br>es<br>(estudos)|Risco de<br>viés|Inconsistência|Avaliação da q<br>Evidência<br>indireta|ualidade<br>Imprecisão|Outros|Qualidade<br>geral da<br>evidência|Taxas de eve<br>(<br>Sem adição|S<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses|umário de re<br>Efeito<br>relativo<br>(IC95%)|sultados<br>Efeitos abso<br>Risco sem<br>adição|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses|
|---|---|---|---|---|---|---|---|---|---|---|---|
|91<br>(1 ECR)||||||⨁⨁◯◯<br>BAIXA|||RR 4,49<br>(0,22 para<br>90,99)|0 por 1.000|0 menos por<br>1.000<br>(0 menos para<br>9 mais)|  
DM, diferença média; DMI, diferença minimamente importante; ECR, estudo clínico randomizado; IC,intervalo de confiança; RR, risco relativo.  
a. Os dados foram obtidos de um ensaio que não descreveu adequadamente os processos de randomização e cegamento (Buttgereit et al., 201350).  
b. Intervalo de confiança amplo, que inclui benefícios e riscos potenciais.  
c. I2 =47%.  
172  
**Questão 24. Devemos adicionar glicocorticoides em baixas doses por longo prazo aos MMCDbio anti-TNF em pacientes com artrite reumatoide estabelecida de moderada ou alta atividade da doença?**  
|№ de<br>participant<br>es<br>(estudos)<br>210<br>(1 ECR)|Risco de<br>viés<br>Gravea|Av<br>Inconsistência<br>Remi<br>Não grave|aliação da quali<br>Evidência<br>indireta<br>ssão pelo escore<br>Graveb|dade<br>Imprecisão<br>(ou pontuação) da<br>Gravec|Outros<br>atividade de d<br>Nenhum|Qualidade<br>geral da<br>evidência<br>oença (DAS-28)<br>⨁◯◯◯<br>MUITO<br>BAIXA|Taxas de eve<br>(<br>Sem adição<br>(< 1,6) (seguim<br>32/105<br>(30,5%)|Sum<br>ntos do estudo<br>%)<br>Com adição<br>de<br>glicocorticoid<br>es em baixas<br>doses<br>ento: 12 meses)<br>42/105<br>(40,0%)|ário de result<br>Efeito<br>relativo<br>(IC95%)<br> <br>RR 1,31<br>(0,90 para<br>1,90)|ados<br>Efeitos abso<br>Risco sem<br>adição<br>305 por<br>1.000|lutos potenciais<br>Diferença de<br>risco com<br>adição de<br>glicocorticoide<br>s em baixas<br>doses<br>94 mais por<br>1.000<br>(30 menos<br>para 274 mais)|
|---|---|---|---|---|---|---|---|---|---|---|---|  
ECR, estudo clínico randomizado; IC, intervalo de confiança; RR, risco relativo.  
a. Todoerti et al. (2010)25 é um ECR sem cegamento, portanto, há risco de viés de expectativa.  
b. Evidência indireta: os pacientes randomizados tinham AR recente e não estabelecida (Todoerti et al., 201025).  
c. Intervalo de confiança amplo ao redor da estimativa de efeito devido ao pequeno tamanho amostral (Todoerti et al., 2010 25).  
173

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
1. World Health Organization. WHO handbook for guideline development. 2. ed. 2014 [acesso em 26 nov 2018].  
Disponível em: http://www.who.int/iris/handle/10665/145714.  
2. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. Brasília: O Ministério; 2016.  
3. Schünemann HJ, Wiercioch W, Etxeandia I, Falavigna M, Santesso N, Mustafa R, et al. Guidelines 2.0: systematic  
development of a comprehensive checklist for a successful guideline enterprise. CMAJ2014;186:E123-42.  
4. Schünemann HJ, Wiercioch W, Brozek J, Etxeandia-Ikobaltzeta I, Mustafa RA, Manja V, et al. GRADE Evidence  
to Decision (EtD) frameworks for adoption, adaptation, and de novo development of trustworthy recommendations: GRADEADOLOPMENT. J Clin Epidemiol2017;81:101-10.  
5. Singh JA, Saag KG, Bridges SL Jr, Akl EA, Bannuru RR, Sullivan MC, et al. 2015 American College of  
Rheumatology Guideline for the Treatment of Rheumatoid Arthritis. Arthritis Care Res 2016;68:1-25.  
6. Darzi A, Harfouche M, Arayssi T, Alemadi S, Alnagbi KA, Badsha H, et al. Adaptation of the 2015 American  
College of Rheumatology treatment guideline for rheumatoid arthritis for the Eastern Mediterranean Region: an exemplar of the GRADE Adolopment. Health Qual Life Outcomes2017;15:183.  
7. Grading of Recommendations Assessment D and Evaluation (GRADE). 2000 [acesso em 26 nov 2018].  
Disponível em: http://gradeworkinggroup.org/#.  
8. GRADEpro GDT [homepage na Internet]. 2015 [acesso em 26 nov 2018]. Disponível em: https://gradepro.org/.  
9. Arnett FC, Edworthy SM, Bloch DA, McShane DJ, Fries JF, Cooper NS, et al. The American Rheumatism  
Association 1987 revised criteria for the classification of rheumatoid arthritis. Arthritis Rheum 1988;31:315-24.  
10. Aletaha D, Neogi T, Silman AJ, Funovits J, Felson DT, Bingham CO 3rd, et al. 2010 rheumatoid arthritis  
classification criteria: an American College of Rheumatology/European League Against Rheumatism collaborative initiative. Ann Rheum Dis2010;69:1580-8.  
11. Hazlewood GS, Barnabe C, Tomlinson G, Marshall D, Devoe D, Bombardier C. Methotrexate monotherapy and methotrexate combination therapy with traditional and biologic disease modifying antirheumatic drugs for rheumatoid arthritis: abridged Cochrane systematic review and network meta-analysis. BMJ 2016;353:i1777.  
12. Atsumi T, Yamamoto K, Takeuchi T, Yamanaka H, Ishiguro N, Tanaka Y, et al. The first double-blind,  
randomised, parallel-group certolizumab pegol study in methotrexate-naive early rheumatoid arthritis patients with poor prognostic factors, C-OPERA, shows inhibition of radiographic progression. Ann Rheum Dis 2016;75:75-83.  
13. Markusse IM, de Vries-Bouwstra JK, Han KH, van der Lubbe PA, Schouffoer AA, Kerstens PJ, et al. Feasibility  
of tailored treatment based on risk stratification in patients with early rheumatoid arthritis. Arthritis Res Ther 2014;16:430.  
14. Castelar-Pinheiro G, Vargas-Santos AB, Albuquerque C, Amorim R, Giorgi R, Radominski S, et al. Rheumatoid  
arthritis in brazil - the "real" study: a nationwide prospective study. Ann Rheum Dis 2017;76:1160-1.  
15. Haagsma CJ, van Riel PL, de Jong AJ, van de Putte LB. Combination of sulphasalazine and methotrexate versus  
the single components in early rheumatoid arthritis: a randomized, controlled, double-blind, 52 week clinical trial. BrJ Rheumatol 1997;36:1082-8.  
16. Capell HA, Madhok R, Porter DR, Munro RA, McInnes IB, Hunter JA, et al. Combination therapy with sulfasalazine and methotrexate is more effective than either drug alone in patients with rheumatoid arthritis with a suboptimal response to sulfasalazine: results from the double-blind placebo-controlled MASCOT study. Ann Rheum Dis 2007;66:235-41.  
17. Dougados M, Combe B, Cantagrel A, Goupille P, Olive P, Schattenkirchner M, et al. Combination therapy in early rheumatoid arthritis: a randomised, controlled, double blind 52 week clinical trial of sulphasalazine and methotrexate compared with the single components. Ann Rheum Dis1999;58:220-5.  
174  
18. de Jong PH, Hazes JM, Han HK, Huisman M, van Zeben D, van der Lubbe PA, et al. Randomised comparison of initial triple DMARD therapy with methotrexate monotherapy in combination with low-dose glucocorticoid bridging therapy; 1-year data of the tREACH trial. Ann Rheum Dis 2014;73:1331-9.  
19. Saunders SA, Capell HA, Stirling A, Vallance R, Kincaid W, McMahon AD, et al. Triple therapy in early active rheumatoid arthritis: a randomized, single-blind, controlled trial comparing step-up and parallel treatment strategies. Arthritis Rheum 2008;58:1310-17.  
20. Menon N, Kothari SY, Gogna A, Sharma R. Comparison of intra-articular glucocorticoid injections with DMARDs versus DMARDs alone in rheumatoid arthritis. J Assoc Physicians India2014;62:673-76.  
21. Fedorenko E, Lukina G, Sigidin Y. A8.3 Remission as the main target of therapy in early rheumatoid arthritis (RA) patients: comparative efficacy of four treatment regimens. Ann Rheum Dis2015;74(Suppl 1).  
22. De Cock D, Vanderschueren G, Meyfroidt S, Joly J, Westhovens R, Verschueren P. Two-year clinical and radiologic follow-up of early RA patients treated with initial step up monotherapy or initial step down therapy with glucocorticoids, followed by a tight control approach: lessons from a cohort study in daily practice. Clin Rheumatol 2014;33:12530.  
23. Verschueren P, De Cock D, Corluy L, Joos R, Langenaken C, Taelman V, et al. Patients lacking classical poor prognostic markers might also benefit from a step-down glucocorticoid bridging scheme in early rheumatoid arthritis: week 16 results from the randomized multicenter CareRA trial. Arthritis Res Ther2015;17:97.  
24. Montecucco C, Todoerti M, Sakellariou G, Scire CA, Caporali R. Low-dose oral prednisone improves clinical and ultrasonographic remission rates in early rheumatoid arthritis: results of a 12-month open-label randomised study. Arthritis Res Ther 2012;14:R112.  
25. Todoerti M, Scirè CA, Boffini N, Bugatti S, Montecucco C, Caporali R. Early disease control by low-dose prednisone comedication may affect the quality of remission in patients with early rheumatoid arthritis. Ann N Y Acad Sci 2010;1193:139-45.  
26. van Vollenhoven RF, Geborek P, Forslind K, Albertsson K, Ernestam S, Petersson IF, et al. Conventional combination treatment versus biological treatment in methotrexate-refractory early rheumatoid arthritis: 2 year follow-up of the randomised, non-blinded, parallel-group Swefot trial. Lancet2012;379:1712-20.  
27. Heimans L, Wevers-de Boer KV, Visser K, Goekoop RJ, van Oosterhout M, Harbers JB, et al. A two-step treatment strategy trial in patients with early arthritis aimed at achieving remission: the IMPROVED study. Ann Rheum Dis 2014;73:1356-61.  
28. Gabay C, Emery P, van Vollenhoven R, Dikranian A, Alten R, Pavelka K, et al. Tocilizumab monotherapy versus adalimumab monotherapy for treatment of rheumatoid arthritis (ADACTA): a randomised, double-blind, controlled phase 4 trial. Lancet 2013;381:1541-50.  
29. Fleischmann R, Cutolo M, Genovese MC, Lee EB, Kanik KS, Sadis S, et al. Phase IIb dose-ranging study of the oral JAK inhibitor tofacitinib (CP-690,550) or adalimumab monotherapy versus placebo in patients with active rheumatoid arthritis with an inadequate response to disease-modifying antirheumatic drugs. Arthritis Rheum2012;64:617-29.  
30. O'Dell JR, Mikuls TR, Taylor TH, Ahluwalia V, Brophy M, Warren SR, et al. Therapies for active rheumatoid arthritis after methotrexate failure. N Engl J Med2013;369:307-18.  
31. Scott DL, Ibrahim F, Farewell V, O'Keeffe AG, Walker D, Kelly C, et al. Tumour necrosis factor inhibitors versus combination intensive therapy with conventional disease modifying anti-rheumatic drugs in established rheumatoid arthritis: TACIT non-inferiority randomised controlled trial. BMJ 2015;350:h1046.  
175  
32. Schiff M, Keiserman M, Codding C, Songcharoen S, Berman A, Nayiager S, et al. Efficacy and safety of abatacept or infliximab vs placebo in ATTEST: a phase III, multi-centre, randomised, double-blind, placebo-controlled study in patients with rheumatoid arthritis and an inadequate response to methotrexate. Ann Rheum Dis 2008;67:1096-103.  
33. Schiff M, Weinblatt ME, Valente R, van der Heijde D, Citera G, Elegbe A, et al. Head-to-head comparison of subcutaneous abatacept versus adalimumab for rheumatoid arthritis: two-year efficacy and safety findings from AMPLE trial. Ann Rheum Dis 2014;73:86-94.  
34. Kekow J, Mueller-Ladner U, Schulze-Koops H. Rituximab is more effective than second anti-TNF therapy in rheumatoid arthritis patients and previous TNFalpha blocker failure. Biologics2012;6:191-9.  
35. Wakabayashi H, Hasegawa M, Nishioka Y, Sudo A, Nishioka K. Which subgroup of rheumatoid arthritis patients benefits from switching to tocilizumab versus etanercept after previous infliximab failure? A retrospective study. Mod Rheumatol 2012;22:116-21.  
36. Finckh A, Ciurea A, Brulhart L, Kyburz D, Möller B, Dehler S, et al. B cell depletion may be more effective than switching to an alternative anti-tumor necrosis factor agent in rheumatoid arthritis patients with inadequate response to antitumor necrosis factor agents. Arthritis Rheum2007;56:1417-23.  
37. Emery P, Hammoudeh M, FitzGerald O, Combe B, Martin-Mola E, Buch MH, et al. Sustained remission with etanercept tapering in early rheumatoid arthritis. N Engl J Med 2014;371:1781-92.  
38. Gottenberg JE, Brocq O, Perdriger A, Lassoued S, Berthelot JM, Wendling D, et al. Non-TNF-Targeted Biologic vs a Second Anti-TNF Drug to Treat Rheumatoid Arthritis in Patients With Insufficient Response to a First Anti-TNF Drug: A Randomized Clinical Trial. JAMA 2016;316:1172-80.  
39. Chatzidionysiou K, van Vollenhoven RF. Rituximab versus anti-TNF in patients who previously failed one TNF inhibitor in an observational cohort. Scand J Rheumatol 2013;42:190-5.  
40. Soliman MM, Hyrich KL, Lunt M, Watson KD, Symmons DP, Ashcroft DM, et al. Rituximab or a second antitumor necrosis factor therapy for rheumatoid arthritis patients who have failed their first anti-tumor necrosis factor therapy? Comparative analysis from the British Society for Rheumatology Biologics Register. Arthritis Care Res 2012;64:1108-15.  
41. Manders SH, Kievit W, Adang E, Brus HL, Moens HJ, Hartkamp A, et al. Cost-effectiveness of abatacept, rituximab, and TNFi treatment after previous failure with TNFi treatment in rheumatoid arthritis: a pragmatic multi-centre randomised trial. Arthritis Res Ther 2015;17:134.  
42. Finckh A, Ciurea A, Brulhart L, Möller B, Walker UA, Courvoisier D, et al. Which subgroup of patients with rheumatoid arthritis benefits from switching to rituximab versus alternative anti-tumour necrosis factor (TNF) agents after previous failure of an anti-TNF agent? Ann Rheum Dis 2010;69:387-93.  
43. Johnston SS, Turpcu A, Shi N, Fowler R, Chu BC, Alexander K. Risk of infections in rheumatoid arthritis patients switching from anti-TNF agents to rituximab, abatacept, or another anti-TNF agent, a retrospective administrative claims analysis. Semin Arthritis Rheum2013;43:39-47.  
44. Harrold LR, Reed GW, Magner R, Shewade A, John A, Greenberg JD, et al. Comparative effectiveness and safety of rituximab versus subsequent anti-tumor necrosis factor therapy in patients with rheumatoid arthritis with prior exposure to anti-tumor necrosis factor therapies in the United States Corrona registry. Arthritis Res Ther2015;17:256.  
45. Gomez-Reino JJ, Maneiro JR, Ruiz J, Roselló R, Sanmarti R, Romero AB, et al. Comparative effectiveness of switching to alternative tumour necrosis factor (TNF) antagonists versus switching to rituximab in patients with rheumatoid arthritis who failed previous TNF antagonists: the MIRAR Study. Ann Rheum Dis2012;71:1861-4.  
46. Fleischmann R, Mysler E, Hall S, Kivitz AJ, Moots RJ, Luo Z, et al. Efficacy and safety of tofacitinib monotherapy, tofacitinib with methotrexate, and adalimumab with methotrexate in patients with rheumatoid arthritis (ORAL Strategy): a phase 3b/4, double-blind, head-to-head, randomised controlled trial. Lancet 2017;390:457-68.  
176  
47. Choy EH, Kingsley GH, Khoshaba B, Pipitone N, Scott DL, Intramuscular Methylprednisolone Study Group. A two year randomised controlled trial of intramuscular depot steroids in patients with established rheumatoid arthritis who have shown an incomplete response to disease modifying antirheumatic drugs. Ann Rheum Dis2005;64:1288-93.  
48. Durez P, Malghem J, Nzeusseu Toukap A, Depresseux G, Lauwerys BR, Westhovens R, et al. Treatment of early rheumatoid arthritis: a randomized magnetic resonance imaging study comparing the effects of methotrexate alone, methotrexate in combination with infliximab, and methotrexate in combination with intravenous pulse methylprednisolone. Arthritis Rheum 2007;56:3919-27.  
49. Ciconelli RM, Ferraz MB, Visioni RA, Oliveira LM, Atra E. A randomized double-blind controlled trial of sulphasalazine combined with pulses of methylprednisolone or placebo in the treatment of rheumatoid arthritis. Br J Rheumatol1996;35:150-4.  
50. Buttgereit F, Mehta D, Kirwan J, Szechinski J, Boers M, Alten RE, et al. Low-dose prednisone chronotherapy for rheumatoid arthritis: a randomised clinical trial (CAPRA-2). Ann Rheum Dis2013;72:204-10.  
177

---

<!-- METADADOS: doenca: PCDT - Artrite Reumatóide | secao: FERNANDA DE NEGRI -->
|Número do Relatório da<br>diretriz clínica (Conitec)||Tecnologias avaliada|s pela Conitec|
|---|---|---|---|
|<br>ou Portaria de<br>Publicação|Principais alterações|Incorporação ou alteração do uso<br>no SUS|Não incorporação ou não<br>alteração no SUS|
|Relatório de<br>Recomendação nº<br>1021/2025|Ajuste no Termo de<br>Esclarecimento e<br>Responsabilidade, com<br>inclusão dos<br>medicamentos ausentes no<br>campo destinado à<br>indicação do tratamento<br>da doença|-|-|
||Exclusão temporária de<br>abatacepte solução<br>injetável 250 mg|**-**|**-**|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>16/2021 [Relatório de<br>Recomendação nº<br>654/2021]|Inclusão de orientações<br>sobre upadacitinibe|Upadacitinibe para o tratamento de<br>pacientes adultos com artrite<br>reumatoide ativa moderada a grave<br>[Portaria SCTIE/MS nº 04/2021;<br>Relatório de Recomendação nº<br>592/2021]|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>14/2020 [Relatório de<br>Recomendação nº<br>551/2020]|Inclusão de orientações<br>sobre baracitinibe|Baricitinibe para pacientes com<br>Artrite Reumatoide ativa,<br>moderada a grave [Portaria<br>SCTIE/MS nº 08/2020; Relatório<br>de Recomendação nº 510/2020]|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>05/2020 [Relatório de<br>Recomendação nº<br>460/2020]|Ajustes textuais<br>Migração dos pacientes<br>com AIJ para PCDT<br>específico|-|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>16/2019 [Relatório de<br>Recomendação nº<br>460/2019]|Inclusão de orientações<br>sobre tofacitinibe|Tofacitinibe para o tratamento de<br>pacientes adultos com artrite<br>reumatoide ativa moderada a grave<br>com resposta inadequada a um ou<br>mais medicamentos modificadores<br>do curso da doença [Portaria<br>SCTIE/MS nº 08/2017; Relatório<br>de Recomendação nº 241/2019]|-|  
178  
|Número do Relatório da<br>diti líi Cit||Tecnologias avalia|das pela Conitec|
|---|---|---|---|
|rerz cnca (onec)<br>ou Portaria de<br>Publicação|Principais alterações|Incorporação ou alteração do uso<br>no SUS|Não incorporação ou não<br>alteração no SUS|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>15/2017 [Relatório de<br>Recomendação nº<br>177/2017]|Republicação em 2018<br>por incorreção|-|Abatacepte para o tratamento da<br>Artrite Reumatoide Moderada a<br>Grave após falha aos MMCDs<br>sintéticos [Portaria SCTIE/MS<br>nº 38/2016; Relatório de<br>Recomendação nº 234/2016]<br>Tocilizumabe em monoterapia<br>na segunda etapa de tratamento<br>da artrite reumatoide moderada a<br>grave [Portaria SCTIE/MS nº<br>34/2016; Relatório de<br>Recomendação nº 223/2016]|
|Portaria SAS/MS nº<br>996/2015|Inclusão de abatacepte<br>subcutâneo|Abatacepte subcutâneo para o<br>tratamento da artrite reumatoide<br>moderada a grave [Portaria<br>SCTIE/MS nº 7/2015; Relatório de<br>Recomendação nº 133/2015]<br>Naproxeno para Artrite reumatoide<br>[Portaria SCTIE/MS nº 12/2014;<br>Relatório de Recomendação nº<br>86/2014]<br>Azatioprina para Artrite<br>reumatoide [Portaria SCTIE/MS nº<br>10/2014; Relatório de<br>Recomendação nº 85/2014]|Abatacepte subcutâneo para o<br>tratamento da segunda etapa<br>(primeira etapa de biológicos)<br>do tratamento da artrite<br>reumatoide moderada a grave<br>[Portaria SCTIE/MS nº 14/2015;<br>Relatório de Recomendação nº<br>136/2015]<br>Tocilizumabe para o tratamento<br>da artrite reumatoide - 1ª linha<br>de tratamento com biológicos<br>após falha a MMCDs sintéticos<br>[Portaria SCTIE/MS nº 07/2015;<br>Relatório de Recomendação nº<br>133/2015|
|Portaria SAS/MS nº<br>710/2013|Inclusão de medicamentos<br>biológicos|Golimumabe, certolizumabe pegol,<br>rituximabe, abatacepte,<br>tocilizumabe, infliximabe,<br>adalimumabe e etanercepte -<br>Medicamentos biológicos para<br>tratamento da artrite reumatoide<br>[Portaria SCTIE/MS nº 24/2012;<br>Relatório de Recomendação nº<br>12/2012]|Medicamentos biológicos<br>(Adalimumabe, Certolizumabe<br>pegol, Etanercepte, Infliximabe,<br>Golimumabe, Rituximabe,<br>Abatacepte e Tocilizumabe) para<br>Doença Reumatoide do Pulmão<br>e Vasculite Reumatoide<br>[Portaria SCTIE/MS nº 60/2013;|  
179  
|Número do Relatório da<br>diretriz clínica (Conitec)||Tecnologias avalia|das pela Conitec|
|---|---|---|---|
|<br>ou Portaria de<br>Publicação|Principais alterações|Incorporação ou alteração do uso<br>no SUS|Não incorporação ou não<br>alteração no SUS|
||||Relatório de Recomendação nº<br>89/2013]<br>Leflunomida, Cloroquina,<br>Hidroxicloroquina, Metotrexato<br>e Sulfassalazina para Doença<br>Reumatoide do Pulmão (CID<br>M051) e Vasculite Reumatoide<br>(CID M052) [Portaria<br>SCTIE/MS nº 59/2013;<br>Relatório de Recomendação nº<br>87/2013]<br>Ciclosporina no tratamento de<br>Síndrome de Felty (CID M050),<br>Artrite reumatoide com<br>comprometimento de outros<br>órgãos e sistemas (M053), outras<br>artrites reumatoides<br>soropositivas (M058), Artrite<br>reumatoide soronegativa (M060)<br>e outras artrites reumatoides<br>especificadas (M068) [Portaria<br>SCTIE/MS nº 58/2013;<br>Relatório de Recomendação nº<br>88/2013]|
|Portaria SCTIE/MS nº<br>66/2006|Alterada em 2008 pela<br>Portaria SAS/MS nº<br>411/2008|-|-|
|Portaria SAS/MS nº<br>865/2002|Primeira versão do PCDT|-|-|  
180

---

