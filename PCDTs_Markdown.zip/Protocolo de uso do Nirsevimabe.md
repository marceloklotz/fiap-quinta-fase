<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: Geral -->
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo de Uso do Nirsevimabe para Prevenção de Infecção do Trato Respiratório Inferior Associado ao Vírus Sincicial Respiratório para Bebês Prematuros ou com Comorbidades.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe confere o art. 68 do Decreto nº 11.798, de 28 de novembro de 2023, e o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo de Uso do Nirsevimabe para Prevenção de Infecção do Trato Respiratório Inferior Associado ao Vírus Sincicial Respiratório para Bebês Prematuros ou com Comorbidades.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/ptbr.  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: Geral -->
1

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: ANEXO -->
PROTOCOLO DE USO DO NIRSEVIMABE PARA PREVENÇÃO DE INFECÇÃO DO TRATO RESPIRATÓRIO INFERIOR ASSOCIADO AO VÍRUS SINCICIAL RESPIRATÓRIO PARA BEBÊS PREMATUROS OU COM COMORBIDADES

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 1. INTRODUÇÃO -->
O vírus sincicial respiratório (VSR) é um vírus de ácido ribonucleico (RNA) que pertence à família Pneumoviridae<sup>1</sup> . Globalmente, é uma das principais causas de infecção do trato respiratório inferior (ITRI) em todas as idades<sup>2</sup> . Em bebês e crianças pequenas, especialmente aqueles com menos de seis meses de idade, a primeira infecção pode causar bronquiolite grave e, em alguns casos, ser fatal<sup>3</sup> .  
Semelhante a outros vírus respiratórios, a transmissão do VSR ocorre por meio da inoculação de gotículas nas mucosas dos olhos, nariz ou boca, seja pelo contato direto com um indivíduo infectado, seja por meio do contato com superfícies, objetos ou pele contaminados, nos quais o vírus pode permanecer ativo e potencialmente infectante por períodos prolongados<sup>2,3</sup> .  
Anualmente, ocorrem cerca de 3,6 milhões de hospitalizações relacionadas ao VSR em todo o mundo, além de aproximadamente 100 mil mortes em crianças menores de cinco anos, das quais metade ocorre em bebês com menos de seis meses<sup>4</sup> .  
No Brasil, dados do Ministério da Saúde indicam que o VSR é responsável por cerca de 80% dos casos de bronquiolite e até 60% das pneumonias em crianças menores de dois anos. Entre 2018 e 2024, foram registradas 83.740 internações de bebês prematuros (menos de 37 semanas) devido a complicações relacionadas ao vírus<sup>5</sup> . Em 2024, dos 82.005 casos de síndrome respiratória aguda grave (SRAG) atribuídos a vírus respiratórios, 32% (26.034 casos) foram causados pelo VSR. Dentre esses, a faixa etária mais acometida foi a de crianças com menos de 1 ano de idade, que representaram 72,1% dos casos (18.759) e 42% do total de óbitos (168 de 403 óbitos totais)<sup>6</sup> .  
Os principais grupos de risco para desenvolver infecção respiratória grave causada pelo VSR incluem lactentes com menos de seis meses de idade, em especial os prematuros, crianças com doença pulmonar crônica da prematuridade e aquelas com cardiopatias congênitas. A maior suscetibilidade nesses pacientes pode ser atribuída a diversos fatores, como imaturidade do sistema imunológico, transferência reduzida de anticorpos maternos, menor calibre das vias aéreas, além de baixa reserva energética, desmame precoce, anemia, infecções respiratórias recorrentes e uso prévio de corticoides<sup>7</sup> .  
Assim como outros vírus respiratórios, o VSR apresenta maior propagação em determinados períodos do ano<sup>8</sup> . Esse padrão de sazonalidade varia entre as diferentes regiões do Brasil, sendo mais evidente naquelas com estações climáticas bem definidas<sup>8</sup> . Nessas áreas, a maior incidência ocorre nos meses mais frios, com aumento esperado de casos durante o outono e o inverno<sup>6,8</sup> , impactando principalmente as regiões com invernos mais rigorosos, como o Sul e o Sudeste<sup>6</sup> .  
2  
Devido às diversidades geográficas e climáticas do Brasil, a circulação do VSR pode ocorrer em diferentes períodos do ano<sup>8</sup> , podendo a atividade viral iniciar-se mais precocemente ou persistir por mais tempo em determinadas regiões<sup>9</sup> .  
As manifestações clínicas da ITRI por VSR em bebês podem incluir febre baixa, coriza, tosse com sibilância, taquipneia, desconforto respiratório e presença de retrações subcostais e intercostais<sup>10</sup> . O diagnóstico é clínico e baseia-se nos sinais e sintomas da doença<sup>7,10</sup> . Em pacientes imunocomprometidos ou em casos graves, o diagnóstico específico, com detecção etiológica, pode ser importante. Isso pode ser feito por meio de métodos de isolamento viral, detecção de antígeno ou testes moleculares<sup>10</sup> .  
Quanto ao tratamento, até o momento, inexiste medicamento ou terapia específica que reduza o curso da doença ou que acelere a resolução das manifestações da ITRI por VSR. A recomendação é adotar medidas de suporte ventilatório e de manutenção do estado geral, quando necessárias<sup>7,8,10,11</sup> .  
Nesse cenário, as medidas preventivas para o desenvolvimento de ITRI em crianças e lactentes são primordiais e incluem abordagens não medicamentosas e medicamentosas<sup>8,11</sup> . As estratégias não farmacológicas visam à redução da transmissibilidade do VSR e de outros vírus respiratórios relevantes em saúde pública<sup>8</sup> .  
<mark>Entre essas medidas, destacam-se: o distanciamento físico</mark><sup>8</sup> <mark>; a adoção da etiqueta respiratória (como cobrir a boca e o nariz ao tossir ou espirrar)</mark><sup>8</sup> <mark>; a higienização frequente das mãos</mark><sup>7,8,12</sup> <mark>; a não exposição ao tabagismo passivo</mark><sup>7,8,11,12</sup> <mark>; o cuidado para não tocar olhos, boca ou nariz sem higienização prévia das mãos, além da lavagem nasal; ambientes livres de poeira a fim de promover que as vias aéreas estejam pérvias e não sobrecarregar o sistema respiratório com possíveis processos alérgicos respiratórios;  a limpeza e desinfecção regular de objetos e ambientes</mark><sup>8</sup> <mark>; e a restrição do contato de crianças com indivíduos sintomáticos</mark><sup>7,8,11</sup> <mark>. Adicionalmente, recomenda-se evitar ambientes fechados e com aglomeração</mark><sup>7,8,11</sup> <mark>, especialmente durante os períodos de maior circulação viral. O aleitamento materno deve ser incentivado</mark><sup>7,12</sup> <mark>até os dois anos ou mais, sendo exclusivo até os seis meses de idade</mark><sup>13</sup> <mark>e, sempre que possível, crianças com sintomas respiratórios devem ser afastadas de ambientes coletivos, como creches e escolas, conforme orientação do profissional de saúde</mark><sup>7,8,11</sup> <mark>.</mark>  
A prevenção em ambientes hospitalares deve incluir a adoção de medidas para evitar a transmissão intra-hospitalar, direcionadas a pacientes, profissionais de saúde e visitantes. As medidas devem incluir o uso de luvas durante o cuidado do paciente, além de avental, máscara e proteção ocular sempre que houver contato direto com o paciente ou com secreções<sup>7</sup> . É imprescindível higienizar as mãos antes e depois de entrar em contato com os pacientes ou manusear equipamentos próximos a eles<sup>12</sup> .  
Já as abordagens medicamentosas para a prevenção de IRTI por VSR incluem imunização passiva, pela administração de anticorpos monoclonais em lactentes e crianças<sup>7,10,12,14–25</sup> e/ou imunização passiva por meio da vacinação de gestantes, permitindo a transferência transplacentária de anticorpos maternos ao feto<sup>14–19</sup> .  
No âmbito do Sistema Único de Saúde (SUS), o palivizumabe foi o primeiro anticorpo monoclonal incorporado (2012)<sup>26</sup> para a prevenção de infecção pelo VSR em crianças prematuras com idade gestacional menor ou igual a 28 semanas, com idade inferior a um ano; e crianças com idade inferior a dois anos com doença pulmonar crônica da prematuridade, displasia broncopulmonar ou doença cardíaca congênita com repercussão hemodinâmica demonstrada<sup>25</sup> .  
Em 2025, após recomendação favorável da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec), o Ministério da Saúde incorporou duas novas tecnologias para prevenção de ITRI associada ao VSR em crianças: 1) vacina recombinante contra o vírus sincicial respiratório A e B em gestantes – destinada à prevenção em recém-nascidos<sup>27,28</sup> ;  
3  
e 2) nirsevimabe – indicado para prevenção em bebês prematuros menores que 37 semanas de gestação e em crianças com até dois anos de idade que sejam imunocomprometidas ou apresentem comorbidades<sup>29,30</sup> .  
A incorporação do nirsevimabe no SUS amplia a cobertura de uso de anticorpo monoclonal para todos os prematuros, visto que a cobertura do palivizumabe contempla apenas recém-nascidos prematuros com idade gestacional menor ou igual a 28 semanas. Além disso, inclui outras comorbidades como critério para uso em crianças menores de dois anos. O nirsevimabe também apresenta vantagens quanto a sua posologia, pois é administrado em uma dose única na temporada, definida de acordo com a faixa de peso da criança. Já o palivizumabe, requer cálculo individual da dose conforme o peso e a aplicação de cinco doses mensais subsequentes na mesma temporada<sup>29–32</sup> .  
Informações complementares e detalhadas sobre a estratégia de imunização contra o VSR em crianças prematuras e com comorbidades, por meio do uso de anticorpo monoclonal, podem ser obtidas no documento **“Estratégia de Imunização contra o Vírus Sincicial Respiratório para Crianças Prematuras e com Comorbidades – Anticorpo Monoclonal”** , publicado pelo Ministério da Saúde<sup>33</sup> .

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 2. INDICAÇÕES PARA O USO DO NIRSEVIMABE -->
- Prematuros (menores que 37 semanas de gestação);  
- Doença cardíaca congênita hemodinamicamente significativa (DCC);  
- Doença pulmonar crônica da prematuridade (DPCP);  
- Imunocomprometimento grave - inato ou adquirido;  
- Fibrose cística;  
- Doença neuromuscular;  
- Anomalias congênitas das vias aéreas;  
- Síndrome de Down.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. CRITÉRIOS DE INCLUSÃO -->
Devem ser incluídos nesse Protocolo os pacientes que preencham um dos seguintes critérios:  
- Crianças nascidas com idade gestacional inferior a 37 semanas, com qualquer peso corpóreo **, independentemente do histórico de vacinação materna contra o VSR** ;  
- Crianças com até 24 meses de idade, com qualquer peso corpóreo, **independentemente do histórico de vacinação materna contra o VSR** , que apresentem pelo menos uma das seguintes comorbidades:  
- Cardiopatia congênita; ou  
- Broncodisplasia; ou  
- Imunocomprometidos graves (inato ou adquirido); ou  
- Síndrome de Down; ou  
- Fibrose cística; ou  
- Doença neuromuscular; ou  
4  
Anomalias congênitas das vias aéreas.  
A administração do nirsevimabe na segunda temporada do VSR é recomendada exclusivamente para as crianças com as comorbidades especificadas nos critérios de inclusão e detalhadas abaixo, não se estendendo às crianças nascidas prematuras sem comorbidades. Nota 1: O nirsevimabe deve ser administrado ainda na maternidade ou durante internação neonatal, desde que o recém-nascido esteja clinicamente estável (sem instabilidade cardiorrespiratória ou necessidade de suporte intensivo imediato); não apresente contraindicações, como reação alérgica grave a nirsevimabe ou a seus excipientes; e não possua distúrbios hemorrágicos significativos que impeçam aplicação intramuscular (a bula recomenda cautela nesses casos).  
Nota 2: A administração de nirsevimabe em crianças nascidas com idade gestacional inferior a 37 semanas deverá ocorrer independentemente da vacinação contra o vírus sincicial respiratório (VSR) em gestantes. Essa medida integra a estratégia combinada do Ministério da Saúde para a prevenção de infecções do trato respiratório inferior (ITRI) associadas ao VSR em crianças, considerando que essa população apresenta maior risco de infecção em razão da redução da transferência transplacentária de anticorpos maternos para o feto nascido prematuro.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.1. Cardiopatia congênita -->
As crianças com até 12 meses de idade, com diagnóstico de doença cardíaca congênita (DCC) com repercussão hemodinâmica significativa, são as que mais se beneficiam da imunoprofilaxia com nirsevimabe, apresentando redução importante nas taxas de hospitalização. O nirsevimabe está indicado para crianças com cardiopatia congênita com uso de medicamentos para insuficiência cardíaca e indicação cirúrgica, bem como crianças com hipertensão pulmonar moderada a grave.  
Crianças com cardiopatia congênita segundo os critérios acima e que permanecem com repercussão clínica da doença e necessidade de uso de medicamentos específicos deverão utilizar nirsevimabe na segunda sazonalidade.  
O seguinte grupo de crianças com cardiopatia não apresenta risco elevado de infecção pelo VSR e, portanto, não há indicação de imunoprofilaxia com nirsevimabe:  
a) recém-nascidos e lactentes com doença cardíaca sem repercussão hemodinâmica, como, por exemplo: defeito do septo atrial tipo ostium secundum, pequeno defeito do septo ventricular, estenose pulmonar, estenose aórtica não complicada, coarctação leve da aorta e persistência do ducto arterial;  
b) crianças com lesão cardíaca corrigida cirurgicamente, exceto aquelas que ainda necessitam de medicamentos para insuficiência cardíaca;  
c) lactentes com cardiopatia leve, sem uso de medicamentos para essa condição. No segundo ano de vida, a profilaxia com nirsevimabe não está recomendada com base apenas na história de prematuridade isolada.  
5

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.2. Broncodisplasia -->
O nirsevimabe está recomendado para crianças que atendem aos critérios de doença pulmonar crônica da prematuridade (displasia broncopulmonar – DPCP), caracterizada pela dependência de oxigênio em prematuros a partir de 28 dias de vida associada a alterações radiográficas pulmonares típicas, ou pela necessidade de oxigenoterapia às 36 semanas de idade gestacional corrigida, especialmente em prematuros extremos. Incluem-se nesse grupo aquelas crianças que permanecem necessitando de suporte terapêutico, como corticoterapia crônica, terapia diurética ou suplementação de oxigênio, em qualquer momento nos seis meses que antecedem o início da segunda sazonalidade do VSR.  
Crianças que preenchem o critério de DPCP e continuam necessitando de tratamento de suporte como o uso de corticoide para doença pulmonar crônica, diurético ou suplemento de oxigênio durante os seis últimos meses, antes do início da segunda sazonalidade do VSR; Portanto, a profilaxia com nirsevimabe não está recomendada para crianças com doença pulmonar crônica da prematuridade que não necessitaram tratamento de suporte no segundo ano de vida.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.3. Imunocomprometidos graves (inato ou adquirido) -->
O uso de nirsevimabe está indicado em crianças com imunocomprometimento grave com menos de 12 meses de idade que apresentem contagem de linfócitos T CD4+ igual ou inferior a 750 células/mm³, e crianças entre 12 e 24 meses com contagem de linfócitos T CD4+ igual ou inferior a 500 células/mm³. Também devem ser incluídos os casos de erro inato da imunidade grave (imunodeficiências primárias), crianças em uso de corticoides em doses elevadas (equivalentes à prednisona de 2 mg/kg/dia para aquelas com até 10 kg ou de 20 mg/dia ou mais para indivíduos acima de 10 kg) por período superior a duas semanas, bem como crianças transplantadas de órgãos sólidos ou de células-progenitoras hematopoiéticas (TCPH).  
Além disso, a imunoprofilaxia é recomendada para pacientes com doenças oncológicas que estejam em tratamento ou acompanhamento após quimioterapia ou radioterapia, e para aquelas com neoplasias hematológicas.  
6

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.4. Fibrose Cística -->
Todas as crianças com idade inferior a 24 meses com diagnóstico confirmado de fibrose cística terão indicação para o uso do nirsevimabe, independentemente de histórico de hospitalizações prévias, achados radiológicos ou percentil de peso/estatura, visando à prevenção primária de danos pulmonares irreversíveis

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.5. Doença neuromuscular -->
Crianças com doenças neuromusculares apresentam fraqueza dos músculos respiratórios, ineficiência na tosse e dificuldade de eliminação de secreções, o que as torna altamente vulneráveis a infecções do trato respiratório inferior, especialmente pelo VSR, que podem evoluir rapidamente para insuficiência respiratória aguda. O nirsevimabe está indicado para crianças com as seguintes doenças neuromusculares: Atrofia Muscular Espinhal (AME) Tipos 0/1; SMARD1 (Atrofia Muscular Espinhal com Disautonomia Respiratória); Neuropatia Congênita Hipomielinizante; Síndrome de Dejerine-Sottas; Distrofia Miotônica Congênita (DM1); Distrofia Muscular Congênita por Deficiência de Merosina (LAMA2); Distrofia Muscular Congênita relacionada ao FKRP; Distroglinopatias (síndromes Walker-Warburg, MEB); Distrofia Muscular Congênita de Fukuyama; Distrofia Muscular Congênita de Ullrich; Miopatia Miotubular Ligada ao X (XLMTM); Miopatia Centronuclear Autossômica; Miopatia Nemalínica (Neonatal Grave); Doença de Pompe (forma infantil); Miopatias Mitocondriais (Síndrome de Leigh); Miopatia Multiminicore ; Miopatia Centra Core; Miopatia Centronuclear (formas graves) e Desproporção Congênita de Tipos de Fibras<sup>34,35</sup> .

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.6. Síndrome de Down -->
Todas as crianças com até 24 meses de idade com Síndrome de Down têm indicação para imunoprofilaxia com nirsevimabe.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3.7. Anomalias congênitas das vias aéreas -->
As crianças com até 24 meses de idade, com anomalias congênitas das vias aéreas ou doenças pulmonares graves que comprometam a ventilação ou a depuração de secreções, apresentam maior risco de infecção grave pelo VSR e, portanto, se beneficiam da imunoprofilaxia com nirsevimabe. As anomalias congênitas das vias aéreas com indicação de nirsevimabe são: agenesia ou hipoplasia pulmonar, lobação pulmonar anômala com aprisionamento aéreo, cistos broncogênicos ou sequestro pulmonar, malformações do anel traqueal, traqueomalácia grave, estenose traqueal significativa, anéis ou malformações vasculares compressivas da traqueia, atresia ou estenose brônquica, bem como síndromes com comprometimento estrutural das vias aéreas, como Pierre Robin e Apert<sup>10,25,36,37</sup> .  
A indicação da imunoprofilaxia deve considerar o impacto funcional da alteração, especialmente em crianças que necessitam de oxigenoterapia ou suporte ventilatório, apresentam internações respiratórias recorrentes ou comprometimento relevante da depuração de secreções.  
7

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 4. CRITÉRIOS DE EXCLUSÃO -->
Devem ser excluídos deste Protocolo os pacientes com histórico de reações de hipersensibilidade graves, incluindo anafilaxia à substância ativa ou a qualquer um dos excipientes da tecnologia.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 5. SAZONALIDADE DO VÍRUS SINCICIAL RESPIRATÓRIO NO BRASIL -->
O nirsevimabe será disponibilizado durante todo o ano para bebês prematuros com idade gestacional menor que 37 semanas, independentemente da sazonalidade do VSR ( **Quadro 1** ).  
Para crianças com comorbidades até 2 anos de idade, a administração do nirsevimabe seguirá um período de sazonalidade definido, baseado na maior circulação do VSR no Brasil. Com base em dados do Sistema de Informação da Vigilância Sentinela de Influenza e outros Vírus Respiratórios (SIVEP-GRIPE) referentes a 2019 e de 2022 a 2024, a atividade do VSR é mais intensa entre as semanas epidemiológicas 8 e 32, aproximadamente de fevereiro a agosto. Portanto, para este grupo, a aplicação do medicamento deverá ocorrer dentro desse intervalo.  
Para as crianças com comorbidades nascidas fora do período sazonal, recomenda-se a administração do nirsevimabe antes do início da próxima temporada de maior circulação do VSR<sup>10,14,21,31</sup> .  
Dados farmacocinéticos indicam que o nirsevimabe atinge a concentração plasmática média em cerca de seis dias, com variação entre 1 e 28 dias<sup>31</sup> .  
**Quadro 1.** Períodos recomendados para a administração do nirsevimabe  
|**Grupo**|**Período de Administração do nirsevimabe**|
|---|---|
|Bebêsprematuros < 37 semanas|Durante todo o ano|
|Crianças até 2 anos com comorbidades|Período sazonal: Fevereiro a Agosto|  
**Fonte:** DPNI/SVSA/MS

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6. MEDICAMENTO -->
- Nirsevimabe: solução injetável de 100 mg/mL.  
Nota: O medicamento está disponível em seringa preenchida contendo 0,5 mL ou 1 mL de solução.  
8

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.1. Esquema de administração -->
Para recém-nascidos prematuros nascidos durante o ano todo, a administração do nirsevimabe deve ser realizada por via intramuscular logo após o nascimento (ou assim que o recém-nascido estiver clinicamente estável)<sup>10,14,16,17,19–21,23,24,31</sup> , ainda na maternidade. A dose do nirsevimabe é única, variando apenas conforme a faixa de peso do paciente<sup>31</sup> :  
- Recém-nascidos e bebês com peso corporal menor que 5 kg: dose única de 50 mg (seringa preenchida contendo 0,5 mL de solução)<sup>10,12,14,17–21,24,31</sup> ;  
- Bebês com peso corporal maior ou igual a 5 kg: dose única de 100 mg (seringa preenchida contendo 1 mL de solução)<sup>10,12,14,17–21,24,31</sup> .  
- Para crianças com até 24 meses de idade que apresentem comorbidades e permaneçam vulneráveis na segunda temporada do VSR, recomenda-se uma dose única de 200 mg, independente do peso, administrada em duas injeções de 100 mg cada (seringa preenchida contendo 1 mL de solução), aplicadas em locais distintos, totalizando 2 mL de solução<sup>10,12,14,19,24,31</sup> .  
A **Figura 1** apresenta um fluxograma para auxiliar na administração do nirsevimabe, de acordo com as recomendações de dose e critérios de elegibilidade, seguindo o período estabelecido.  
<!-- Start of picture text -->
Nascido vivo<br>Sim Eelegivel E elegivel ou<br>Dee soe nirsevimabeao uso de na Nao / _elegivel permaneceao uso de sim<br>cannes Dae 1° sazonalidade nifsevimabe na<br>doVER!2) P sazonalidade<br>do VSR??<br>Nao.<br>| Menos que 5 kg y | 5 kg ou mais Administrar<br>No jecomentado nirsevimabe 200 mg<br>ouso de (duas injecdes de 100 mg)<br>‘Administrar dose tinica de Administrar dose tinica de nirsevimabe<br>nirsevimabe 50 mg nirsevimabe 100 mg<br>1 Critérios de elegibilidade para uso de nirsevimabe na primeira temporada do VSR:<br>Prematuros até 36 semanas e 6 dias, durante todo 0 ano, ou<br>\Comorbidades, durante 0 periodo sazonal (fevereiro a agosto): cardiopatia congénita, broncodisplasia, condico de imunocomprometimento,<br>lsindrome de Down, fibrose cistica, doenca neuromuscular e anomalias congénitas das vias aéreas<br>#2 Bebé no deve ter recebido dose prévia de nirsevimabe.<br>* Critérios de elegibilidade para uso de nirsevimabe na segunda temporada do VSR:<br>|Comorbidades: cardiopatia congénita, broncodisplasia, condicao de imunocomprometimento, sindrome de Down, fibrose cistica, doenca<br>neuromuscular e anomalias congénitas das vias aéreas.<br><!-- End of picture text -->  
**Figura 1.** Fluxograma para auxiliar na administração do nirsevimabe. Nota: VSR – Vírus Sincicial Respiratório. Fonte: adaptado de _American Academy of Pediatrics_ , 2024<sup>38</sup> .

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.2. Via de administração e manuseio -->
O nirsevimabe deve ser administrado por via intramuscular, logo após a preparação da seringa, sendo sua aplicação realizada por profissional de saúde habilitado<sup>31</sup> .  
9  
Recomenda-se, preferencialmente, a aplicação no músculo da face anterolateral da coxa, devendo-se evitar o músculo glúteo devido ao risco de lesão do nervo ciático. Nos casos em que seja necessário aplicar duas injeções, devem ser utilizados locais de aplicação distintos<sup>31</sup> .  
No momento da administração, o profissional de saúde precisa selecionar o tamanho da agulha mais apropriado, considerando as características individuais da criança, como tamanho e gordura corporal<sup>31</sup> .  
Adicionalmente, deve-se inspecionar visualmente o medicamento antes de sua administração. O nirsevimabe apresenta-se como uma solução límpida a opalescente (transparente a levemente translúcida), com coloração que varia do incolor ao amarelo. Caso a solução apresente qualquer sinal de alteração, como turvação excessiva, coloração diferente do espectro incolor-amarelo, ou presença de partículas visíveis, o nirsevimabe não deve ser administrado e deve ser descartado adequadamente<sup>31</sup> , em caixa de perfurocortante, para posterior destino final, conforme Plano de Gerenciamento de Resíduos Sólidos em Saúde local, seguindo as recomendações da RDC da Anvisa nº 222/2018<sup>39</sup> e Resolução CONAMA nº 358/2005<sup>40</sup> .  
Desvio de qualidade e queixas técnicas devem ser notificado para Anvisa por meio do Notivisa: <u>https://www.gov.br/anvisa/pt-br/assuntos/fiscalizacao-emonitoramento/notificacoes/medicamentos-e-vacinas</u>  
**Considerando que há mais de uma apresentação do nirsevimabe, o profissional deve certificar-se que selecionou a apresentação recomendada, por meio da seringa preenchida com 0,5 mL ou 1 mL de solução injetável, conforme necessário**<sup>31</sup> .  
A seringa preenchida do nirsevimabe é composta pela haste do êmbolo, flange, rolha de retenção, corpo, _luer lock_ (conector com ponta de rosca) e tampa ( **Figura 2** )<sup>31</sup> . Para a administrálo, recomenda-se seguir as etapas 1 a 5, conforme apresentado no **Quadro 2** .  
<!-- Start of picture text -->
Flange | Rolhade retenca Tampa dajseringa<br>]<br>yL T J |<br>Haste do émbolo Como da serinzs Luer Lock<br><!-- End of picture text -->  
**Figura 2.** Componentes da seringa preenchida **Fonte:** reprodução de Anvisa, 2024<sup>31</sup> .  
**Quadro 2.** Orientações para administração do nirsevimabe.  
|**Etapa**||**Orientações**|
|---|---|---|
| **Seleção**<br>**agulha**|**da**|<br>Selecione o tamanho da agulha apropriado, considerando as<br>características individuais da criança.|
| **Preparo**<br>**seringa**|**da**|<br>Segure o bico_luer lock_com uma mão, evitando segurar a haste do<br>êmbolo ou o corpo da seringa;<br><br>Retire a tampa da seringa com a outra mão, girando no sentido anti-<br>horário.|
| **Conexão**<br>**agulha**|**da**|<br>Conecte a agulha selecionada na seringa, girando suavemente no sentido<br>horário, até sentir uma leve resistência;<br><br>Segure o corpo da seringa com uma mão;|  
10  
|**Etapa**|**Orientações**|
|---|---|
||<br>Com a outra mão, remova cuidadosamente a tampa protetora da agulha;<br>**Atenção:**<br>- Não segure a haste do êmbolo após remover a tampa da agulha, pois a rolha de<br>retenção pode se mover;<br>- Não toque na agulha;<br>- Não permita que a agulha toque em qualquer superfície;<br>- Não recoloque a tampa na agulha;<br>- Não remova a agulha da seringa.|
| **Administração**<br>**do medicamento**|<br>Via: intramuscular<br><br>Local preferencial: face anterolateral da coxa;<br><br>Dose: todo o conteúdo da seringapreenchida|
| **Descarte**<br>**do**<br>**medicamento**|<br>Descarte imediatamente a seringa usada, junto com a agulha, em caixa<br>de perfurocortante, para posterior destino final, conforme Plano de<br>Gerenciamento de Resíduos Sólidos em Saúde local.<br>**Nota:**<br>Quando necessárias duas injeções, repita as etapas 1 a 5, administrando a segunda<br>injeção em um local anatômico distinto.|  
**Fonte:** adaptado de Anvisa, 2024<sup>31</sup>  
A adoção de medidas voltadas à redução da dor durante a administração de imunizantes, como o nirsevimabe, constitui uma prática essencial para ampliar a adesão à imunização e minimizar experiências traumáticas, configurando-se como uma ação fundamental de humanização do cuidado. Nesse sentido, para orientações detalhadas sobre estratégias de alívio da dor, recomenda-se a consulta ao _Manual de normas e procedimentos para vacinação_ , do Ministério da Saúde (2024)<sup>41</sup> .

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.3. Eventos adversos e interações medicamentosas -->
Os eventos adversos do nirsevimabe são considerados incomuns (frequência entre ≥ 0,1 e < 1%) e podem incluir **erupção cutânea** (com aparecimento dentro de 14 dias após a dose), **reação no local da injeção** e **febre** (ambos dentro de 7 dias após aplicação). **Reações de hipersensibilidade grave** , incluindo anafilaxia, também foram relatadas (casos de anafilaxia foram observados com outros anticorpos monoclonais da classe Imunoglobulina G1 humana). No entanto, até o momento, não foi possível estabelecer a frequência dessas reações de hipersensibilidade, nem sua relação causal com o uso do nirsevimabe.<sup>31</sup> .  
O nível de segurança também foi avaliado em lactentes com risco mais elevado de doença grave pelo VSR na sua primeira temporada. O estudo MEDLEY avaliou a segurança em 918 lactentes com risco mais elevado de doença grave por VSR, incluindo 196 lactentes extremamente prematuros (idade gestacional menor que 29 semanas) e 306 lactentes com doença pulmonar crónica por prematuridade, ou doença cardíaca congênita com repercussão hemodinâmica a entrar na sua primeira temporada do VSR, que receberam nirsevimabe (n=614) ou palivizumabe (n=304). O perfil de segurança de nirsevimabe em lactentes que receberam nirsevimabe na sua primeira temporada do VSR foi comparável ao comparador palivizumabe e consistente com o perfil de segurança de nirsevimabe em lactentes a termo e pré-termo com idade gestacional igual ou maior que 29 semanas<sup>31</sup> .  
Em lactentes que permanecem vulneráveis à doença grave pelo VSR em sua segunda temporada, o estudo MEDLEY avaliou a segurança em 220 crianças com doença pulmonar  
11  
crónica da prematuridade ou com doença cardíaca congênita hemodinamicamente significativa que receberam nirsevimabe ou palivizumabe na primeira temporada do VSR e que continuaram a receber nirsevimabe na sua segunda temporada do VSR. O perfil de segurança de nirsevimabe em crianças que receberam nirsevimabe na sua segunda temporada do VSR foi consistente com o perfil de segurança de nirsevimabe em lactentes de termo e pré-termo com idade gestacional igual ou maior que 29 semanas<sup>31</sup> .  
O estudo MUSIC, um ensaio em regime aberto, não controlado, avaliou desfechos de segurança em 100 lactentes e crianças imunocomprometidos com idade menor ou igual a 24 meses que receberam nirsevimabe na sua primeira ou segunda temporada do VSR. Foram incluídos participantes com pelo menos uma das seguintes condições: imunodeficiência (combinada, anticorpos ou outra etiologia) (n=33); em uso de corticoterapia sistêmica de dose elevada (n=29); transplante de órgão ou de medula óssea (n=16); em tratamento com quimioterapia imunossupressora (n=20) ou outra terapia imunossupressora (n=15) e infecção por HIV (n=8)<sup>31</sup> . O perfil de segurança de nirsevimabe foi consistente com o esperado para uma população de crianças imunocomprometidas e com o perfil de segurança de nirsevimabe em lactentes a termo e pré-termo com idade gestacional igual ou maior que 29 semanas. Ainda, o perfil de segurança de nirsevimabe em crianças durante a sua segunda temporada do VSR foi consistente com o perfil de segurança de nirsevimabe observado durante a sua primeira temporada do VSR<sup>31</sup> .  
Os únicos estudos relevantes que consideraram dados de mundo real foram o HARMONIE<sup>42</sup> e coortes da Itália<sup>43</sup> e da França<sup>44</sup> . O estudo HARMONIE foi um estudo multicêntrico conduzido na Alemanha, França e Reino Unido, que envolveu 8.058 bebês que nasceram com idade gestacional superior a 29 semanas e que estavam entrando em sua primeira temporada de VSR. De acordo com os resultados do estudo, eventos adversos relacionados ao tratamento foram observados em 2,1% dos bebês no grupo nirsevimabe. Quatro bebês apresentaram eventos adversos específicos de interesse, que foram categorizados como gravidade grau 1 ou grau 2. Além disso, um bebê desenvolveu um evento adverso grau 3 (espasmos infantis, também conhecido como síndrome de West) 23 dias após receber nirsevimabe. Este evento não pôde ser definitivamente descartado como potencialmente relacionado ao tratamento do estudo. Em consonância com os resultados dos ensaios clínicos, eventos adversos com atendimento médico ocorreram em taxas semelhantes nos grupos nirsevimabe e controle, e nenhuma fatalidade foi relatada<sup>42</sup> .  
Em um estudo de coorte italiano, 484 indivíduos participaram, dos quais 292 (65%) receberam profilaxia com nirsevimabe. Os eventos adversos geralmente apareceram em até 48 horas após o tratamento, e esses efeitos foram predominantemente leves e de curta duração, geralmente resolvendo-se em 1 a 2 dias. Os eventos adversos relatados incluíram febre (6,5 % dos participantes), reações locais no local da injeção (4%) e choro persistente (0,4 %). Nenhum dos eventos adversos exigiu atenção de um profissional de saúde adicional e nenhum evento adverso grave foi relatado<sup>43</sup> . Em um estudo de coorte longitudinal, prospectivo e unicêntrico francês com 1.730 crianças, 9,4% dos pacientes do grupo nirsevimabe apresentaram pelo menos um evento adverso grave. No grupo controle, essa proporção foi de 10,3 % dos pacientes. Não houve relato de eventos relacionados ao tratamento em nenhum dos grupos<sup>44</sup> .  
Inexistem estudos acerca das interações medicamentosas mediadas pelo nirsevimabe. Contudo, elas são pouco prováveis, pois o alvo terapêutico é um vírus exógeno, sua farmacocinética não afeta diretamente as enzimas do citocromo P450 e o fármaco não é um substrato de transportadores hepáticos ou renais. Além disso, o nirsevimabe não interfere com a reação em cadeia da polimerase (RT-PCR) via transcriptase reversa, nem com ensaios de diagnóstico rápido de detecção de antígeno do VSR que utilizam anticorpos comercialmente disponíveis direcionados para o local antigênico I, II ou IV da proteína de fusão (F) do VSR<sup>31</sup> .  
12  
Embora a experiência concomitante de nirsevimabe e vacinas ainda seja limitada, não há evidências de que ocorra interferência na resposta imune ativa às vacinas. Em ensaios clínicos, quando o nirsevimabe foi administrado com vacinas pediátricas de rotina, o perfil de segurança e reatogenicidade da vacinação concomitante foi semelhante ao observado com a administração das vacinas. **Assim, a administração de nirsevimabe pode ocorrer simultaneamente a de outras vacinas infantis** , desde que não sejam administrados na mesma seringa e sejam aplicados em locais distintos<sup>31</sup> .  
A farmacovigilância do nirsevimabe visa a identificar e avaliar eventos adversos, interações medicamentosas, problemas de qualidade e segurança do produto, e promover o uso seguro e adequado do medicamento. Ainda que os estudos clínicos tenham indicado o cumprimento desses requisitos, é importante destacar que o nirsevimabe é uma tecnologia recente e, mesmo quando utilizado corretamente, pode estar associado à ocorrência de eventos adversos imprevisíveis ou ainda desconhecidos<sup>31</sup> . Sendo assim, é fundamental que qualquer evento supostamente atribuível a vacinação ou imunização (ESAVI)  a notificação **deve ser realizada exclusivamente no sistema oficial do Ministério da Saúde, o e-SUS Notifica (módulo ESAVI), disponível em: https://notifica.saude.gov.br.**

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.4. Armazenamento e descarte -->
O nirsevimabe deve ser armazenado sob refrigeração, em temperatura entre 2 ºC e 8 ºC. A seringa não deve ser congelada, agitada ou exposta ao calor, devendo ser mantida ao abrigo da luz. Quando necessário, poderá ser mantido em temperatura ambiente (30 ºC) por um período máximo de 8 horas. Nessas situações, o medicamento não deve retornar para a refrigeração e dever ser descartado imediatamente<sup>31</sup> .  
A seringa preenchida do nirsevimabe é de uso único e deve ser descartada, juntamente com a agulha, após sua utilização<sup>31</sup> . O descarte deve ser realizado em caixa de perfurocortante, conforme Plano de Gerenciamento de Resíduos Sólidos em Saúde local.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.5. Critérios de interrupção do tratamento -->
A administração do nirsevimabe é contraindicada em lactentes e crianças com histórico de reações de hipersensibilidade grave, incluindo anafilaxia, à substância ativa ou a qualquer um dos excipientes da formulação<sup>12,14,18–20,31</sup> . Caso ocorram sinais ou sintomas sugestivos de anafilaxia, ou outras reações clinicamente relevantes, a administração deve ser imediatamente interrompida e instituído tratamento adequado para suporte, conforme necessário<sup>31</sup> .  
As crianças devem ficar em observação entre 15 e 30 min após a administração para a detecção oportuna e manejo adequado de possíveis reações de hipersensibilidade grave.  
Considerando sua administração por via intramuscular, o nirsevimabe deve ser administrado com cautela em crianças com trombocitopenia, distúrbios de coagulação ou em uso de anticoagulantes, devido ao risco potencial de sangramento<sup>24,31</sup> .  
Além disso, em crianças com condições de perda de proteínas pode haver aumento da eliminação do nirsevimabe. Essa situação foi observada em estudos clínicos, sugerindo que a proteção conferida pode ser menor em casos de perdas proteicas significativas<sup>31</sup> .  
13  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso do anticorpo monoclonal preconizado neste Protocolo para que alcancem os resultados positivos em relação à efetividade da prevenção e à detecção de problemas relacionados à segurança.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 6.6. Intercambiabilidade entre nirsevimabe e palivizumabe -->
A intercambialidade entre o nirsevimabe e o palivizumabe ainda não está bem definida. Algumas diretrizes indicam que uma dose de nirsevimabe pode substituir as doses remanescentes de palivizumabe durante a temporada de VSR<sup>14</sup> . Por outro lado, há recomendações que orientam a continuidade do uso do palivizumabe ao longo de toda a temporada para os pacientes que já iniciaram o uso dessa tecnologia<sup>17</sup> .  
No que se refere à intercambialidade entre a 1ª e a 2ª temporada, a evidência disponível também é limitada. Um dos estudos apresentados para a aprovação regulatória do nirsevimabe no Brasil avaliou, em um pequeno grupo de crianças com cardiopatia congênita ou broncodisplasia, a segurança da troca entre o palivizumabe e o nirsevimabe entre temporadas. O estudo comparou a sequência palivizumabe-nirsevimabe com os esquemas nirsevimabe-nirsevimabe e palivizumabe-palivizumabe. Embora tenham sido observados alguns eventos adversos, estes estavam relacionados principalmente a infecções ou comorbidades preexistentes, sem indicação de risco adicional associado à troca entre os medicamentos<sup>45</sup> .  
Considerando as limitações das evidências disponíveis, este Protocolo não recomenda a intercambialidade entre palivizumabe e nirsevimabe dentro de uma mesma temporada.  
É fundamental que as crianças que receberam palivizumabe durante a sazonalidade de 2025, conforme o protocolo de uso do Ministério da Saúde, concluam a quimioprofilaxia com o mesmo anticorpo durante a sazonalidade de 2026.  
Considerando o exposto, crianças prematuras com idade gestacional ≤28 semanas e idade inferior a 12 meses que receberam palivizumabe na sazonalidade 2025 devem completar o esquema com o mesmo anticorpo na sazonalidade 2026. E ainda, crianças com idade inferior a 24 meses, que tenham doença pulmonar crônica da prematuridade ou doença cardíaca congênita com repercussão hemodinâmica demonstrada, que receberam palivizumabe na sazonalidade de 2025, devem concluir o tratamento com o mesmo anticorpo na sazonalidade 2026.  
Crianças nascidas após o término da sazonalidade de 2025 e até o final de janeiro de 2026, que se enquadrem nos critérios do protocolo de uso do palivizumabe, deverão receber o nirsevimabe durante a sazonalidade de 2026, desde que permaneçam elegíveis.  
Para as crianças nascidas após o período de sazonalidade de 2025, que se enquadrem nos critérios do protocolo de uso do nirsevimabe, será realizada a estratégia de resgate com uso do nirsevimabe, visando a garantir a proteção contra o VSR durante a sua primeira sazonalidade.  
Crianças prematuras com idade gestacional inferior a 37 semanas e crianças até 24 meses com as comorbidades descritas neste Protocolo de Uso, nascidas a partir de fevereiro de 2026, iniciarão a quimioprofilaxia com nirsevimabe.  
14  
7. RESPONSABILIDADE DE ATENDIMENTO E ENCAMINHAMENTOS  
A Rede de Imunobiológicos para Pessoas com Situações Especiais (RIE) organiza o acesso a vacinas, soros e imunoglobulinas para pessoas com condições clínicas específicas, fortalecendo os princípios da universalidade e da equidade do SUS. Essa rede foi instituída pela Portaria GM/MS nº 6.623, de 14 de fevereiro de 2025<sup>46</sup> .  
A RIE é composta pelos Centros de Referência em Imunobiológicos Especiais (CRIE), pelos Centros Intermediários de Imunobiológicos Especiais (CIIE) e as salas de vacina do SUS, centros de vacinação do SUS e clínicas de saúde do SUS, integradas à Atenção Primária, Urgência e Emergência e, na Atenção Especializada.  
Os bebês prematuros com menos de 37 semanas de gestação e crianças menores de 2 anos com comorbidades serão contemplados com o nirsevimabe como parte de uma estratégia especial de imunização. Este imunobiológico será ofertado exclusivamente pela RIE, no âmbito do SUS.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 8. REGISTRO DE DOSES APLICADAS E DISSEMINAÇÃO DE INFORMAÇÃO -->
O registro das doses aplicadas de nirsevimabe 0,5ml e 1,0ml deve ser realizado obrigatoriamente nos seguintes sistemas de informação:  
- SI-PNI – Sistema de Informação do Programa Nacional de Imunizações;  
- e-SUS APS PEC – Prontuário Eletrônico do Cidadão;  
- Sistemas próprios ou de terceiros, desde que integrados à Rede Nacional de Dados em Saúde (RNDS).  
O **Quadro 3** apresenta o resumo da regra de entrada de doses aplicadas do nirsevimabe.  
**Quadro 3** - Resumo da regra de entrada de doses aplicadas do Anticorpo Monoclonal nirsevimabe 0,5mL e 1,00mL  
|**Tipo de**<br>**imunobiológico**|**Nome**<br>**Comum do**<br>**Imunobiológico**<br>**(****_Definition_)**|**Sigla do**<br>**imunobiológico**<br>**(Display)**|**Código**<br>**Estratégia**|**Estratégia**|**Código**<br>**do**<br>**imunobiológico**|**Descrição**<br>**Dose**|**Sigla**<br>**Dose**|**Faixa**<br>**Etária**|
|---|---|---|---|---|---|---|---|---|
|Anticorpo<br>Monoclonal|Nirsevimabe<br>0,5mL|NIRSEVIMABE<br>0,5mL|2|Especial|115|Profilaxia/<br>Tratamento<br>com 1<br>unidade|P/T1|≤ 24M|
|Anticorpo<br>Monoclonal|Nirsevimabe<br>1,0mL|NIRSEVIMABE<br>1,0mL|2|Especial|116|Profilaxia/<br>Tratamento<br>com 1<br>unidade|P/T1|≤ 24M|
|Anticorpo<br>Monoclonal|Nirsevimabe<br>1,00mL|NIRSEVIMABE<br>1,00mL|2|Especial|116|Profilaxia/<br>Tratamento<br>com 2<br>unidades|P/T2|≤ 24M|
||**Fonte:**DPNI/S|VSA/MS|||||||  
15

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 9. GESTÃO DO MEDICAMENTO -->
A distribuição das doses será operacionalizada por meio de pautas automáticas, elaboradas proporcionalmente ao público-alvo alinhada à estratégia, de acordo com os quantitativos fornecidos pelo fabricante.  
O acompanhamento dos quantitativos, dos lotes e das validades dos imunobiológicos poderá ser realizado via Sistema de Informação de Insumos Estratégicos (SIES), e a entrega ocorrerá conforme agendamento com a transportadora logística. O Ministério da Saúde disponibiliza este sistema e recomenda a sua utilização nas unidades que fazem a distribuição, dispensação e administração dos imunobiológicos.  
Importante ressaltar a utilização do SIES pelos profissionais de saúde nos municípios e nas unidades de saúde para a movimentação dos imunobiológicos, bem como para o registro das doses perdidas, seja por avarias que aconteçam antes da abertura da embalagem primária (perdas físicas), ou as que podem ocorrer após manipulação do imunobiológico (perdas técnicas), essas informações contribuem para o planejamento de aquisições mais assertivas.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 10. REFERÊNCIAS -->
1. Rima B, Collins P, Easton A, Fouchier R, Kurath G, Lamb RA, et al. ICTV virus taxonomy profile: Pneumoviridae. Journal of General Virology [Internet]. 2017 Dec 1 [cited 2025 May 28];98(12):2912–3. Available from: https://pubmed.ncbi.nlm.nih.gov/29087278/  
2. Kaler J, Hussain A, Patel K, Hernandez T, Ray S. Respiratory Syncytial Virus: A Comprehensive Review of Transmission, Pathophysiology, and Manifestation. Cureus [Internet]. 2023 Mar 19 [cited 2025 May 28];15(3). Available from: https://pubmed.ncbi.nlm.nih.gov/37082497/  
3. World Health Organization. Respiratory syncytial virus (RSV) [Internet]. 2025 [cited 2025 May 28]. Available from: https://www.who.int/news-room/fact-sheets/detail/respiratory-syncytialvirus-(rsv)  
4. Li Y, Wang X, Blau DM, Caballero MT, Feikin DR, Gill CJ, et al. Global, regional, and national disease burden estimates of acute lower respiratory infections due to respiratory syncytial virus in children younger than 5 years in 2019: a systematic analysis. The Lancet [Internet]. 2022 May 28 [cited 2025 May 28];399(10340):2047–64. Available from: https://pubmed.ncbi.nlm.nih.gov/35598608/  
5. Brasil, Ministério da Saúde. Conitec recomenda incorporação de tecnologias para proteger gestantes e bebês do Vírus Sincicial Respiratório — Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - CONITEC [Internet]. 2025 [cited 2025 May 29]. Available from: https://www.gov.br/conitec/pt-br/assuntos/noticias/2025/fevereiro/conitecrecomenda-incorporacao-de-tecnologias-para-proteger-gestantes-e-bebes-do-virus-sincicialrespiratorio  
6. Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde e Ambiente. Boletim Epidemiológico. 2025 May 13;56(6).  
7. Sociedade Brasileira de Pediatria. Diretrizes para o manejo da infecção causada pelo vírus sincicial respiratório (VSR) - 2017 [Internet]. 2017 [cited 2025 May 28]. Available from: https://www.sbp.com.br/fileadmin/user_upload/Diretrizes_manejo_infeccao_causada_VSR2017 .pdf  
16  
8. Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde e Ambiente. Nota Técnica n<sup>o</sup> 30/2023 -CGVDI/DPNI/SVSA/MS [Internet]. 2023 [cited 2025 May 28]. Available from: https://www.gov.br/saude/pt-br/centrais-de-conteudo/publicacoes/notas-tecnicas/2023/notatecnica-no-30-2023-cgvdi-dpni-svsa-ms/view  
9. Brasil, Ministério da Saúde, Secretaria de Atenção a Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Secretaria de Vigilância em Saúde. Nota Técnica Conjunta n<sup>o</sup> 05/2015. Estabelecer a sazonalidade do vírus sincicial respiratório no Brasil e oferecer esclarecimentos referentes ao protocolo de palivizumabe. 2015;  
10. Sociedade Brasileira de Pediatria, Sociedade Brasileira de Imunizações. Imunização passiva com Nirsevimabe para prevenção da doença pelo Vírus Sincicial Respiratório (VSR) em crianças. Vol. 129, N<sup>o</sup> . 2024 Jan.  
11. Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde e Ambiente. Guia de vigilância integrada da covid-19, influenza e outros vírus respiratórios de importância em saúde pública [Internet]. Brasília; 2024 [cited 2025 May 28]. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/guia_vigilancia_integrada_covid19_Influenza.pdf  
12. Lee PI, Huang YC, Chen CJ, Chiu CH, Chen PY, Lu CY, et al. Recommendation for immune prophylaxis of respiratory syncytial virus infection in children. Journal of Microbiology, Immunology and Infection. Elsevier Ltd; 2025.  
13. NASCIMENTO AS DO, ROSSATO DG, NASCIMENTO RCL. O IMPACTO DA AMAMENTAÇÃO NA INCIDÊNCIA E GRAVIDADE DA BRONQUIOLITE: UMA REVISÃO SISTEMÁTICA. Brazilian Journal of Implantology and Health Sciences  [Internet]. 2024 Sep 13 [cited 2025 Nov 25];6(9):2354–68. Available from: https://bjihs.emnuvens.com.br/bjihs/article/view/3508  
14. Australian Governement, Department of Health and Aged Care. Respiratory syncytial virus (RSV). In: The Australian Immunisation Handbook [Internet]. 2025 [cited 2025 May 16]. Available from: Respiratory syncytial virus (RSV) Information about respiratory syncytial virus (RSV) disease, vaccines and recommendations for vaccination from the Australian Immunisation Handbook.  
15. Debbag R, Ávila-Agüero ML, Brea J, Brenes-Chacon H, Colomé M, de Antonio R, et al. Confronting the challenge: a regional perspective by the Latin American pediatric infectious diseases society (SLIPE) expert group on respiratory syncytial virus—tackling the burden of disease and implementing preventive solutions. Front Pediatr. 2024;12.  
16. Ortiz Ibarra FJ, González Saldaña N, Arias de la Garza E, Castillo Bejarano JI, Gutiérrez Tobar IF, Laris González A, et al. Consenso de la Asociación Mexicana de Infectología Pediátrica (AMIP): prevención de la infección por virus sincitial respiratorio en México, 2024. Revista Latinoamericana de Infectología Pediátrica [Internet]. 2024;37(S1):s6-28. Available from: https://www.medigraphic.com/cgi-bin/new/resumen.cgi?IDARTICULO=118344  
17. UK Health Security Agency. Respiratory syncytial virus: the green book, chapter 27a. In: Green Book [Internet]. UK Health Security Agency; 2025 [cited 2025 May 16]. Available from: https://www.gov.uk/government/publications/respiratory-syncytial-virus-the-green-bookchapter-27a  
18. Canada, Public Health Agency, An Advisory Committee Statement, National Advisory Committee on Immunization. Statement on the prevention of respiratory syncytial virus (RSV) disease in infants. EDITIONS UNIVERSITAIRES E; 2024 May.  
19. Centers for Disease Control and Prevention. RSV Immunization Guidance for Infants and Young Children [Internet]. 2024 Aug. Available from: https://www.cdc.gov/rsv/hcp/vaccine-clinical-  
17  
guidance/infants-young-children.html#cdc_cg_special_populations_test_screen-additionalconsiderations  
20. Pédiatrie Suisse/Pädiatrie Schweiz/Pediatria Svizzera, Kinderärzte Schweiz, Pediatric Infectious disease Group of Switzerland (PIGS), Swiss Society of Neonatology, Swiss Society of Pediatric Pneumology, Swiss Society of Pediatric Cardiology, et al. Consensus statement / recommendation on the prevention of respiratory syncytial virus (RSV) infections with the monoclonal antibody Nirsevimab (Beyfortus®) [Internet]. 2024 Sep [cited 2025 May 16]. Available from: https://www.sggg.ch/news/detail/consensus-statement-recommendation-on-the-prevention-ofrespiratory-syncytial-virus-rsv-infections-with-the-monoclonal-antibody-nirsevimab-beyfortusr  
21. Simões EAF, Madhi SA, Muller WJ, Atanasova V, Bosheva M, Cabañas F, et al. Grading of Recommendations, Assessment, Development, and Evaluation (GRADE): Nirsevimab, Season 1. Lancet Child Adolesc Health. 2023 Mar 1;7(3):180–9.  
22. Francisco L, Cruz-Cañete M, Pérez C, Couceiro JA, Otheo E, Launes C, et al. Nirsevimab for the prevention of respiratory syncytial virus disease in children: Statement of the Spanish Society of Paediatric Infectious Disease (SEIP). An Pediatr (Engl Ed). 2023 Oct 1;99(4):257–63.  
23. Sociedad Latinoamericana de Infectología Pediátrica. Rol de nirsevimab en la prevención de la infección por virus respiratorio sincitial en pediatría. 2024 Jul 1 [cited 2025 May 16]; Available from: https://slipe.org/web/wp-content/uploads/2024/07/SLIPE-rol-de-nirsevimab-en-laprevencion.pdf  
24. Jones JM, Fleming-Dutra KE, Prill MM, Roper LE, Brooks ; Oliver, Sánchez PJ, et al. Use of Nirsevimab for the Prevention of Respiratory Syncytial Virus Disease Among Infants and Young Children: Recommendations of the Advisory Committee on Immunization Practices — United States, 2023 [Internet]. Vol. 72, Centers for Disease Control and Prevention | MMWR. 2023 [cited 2025 Jul 4]. Available from: https://pubmed.ncbi.nlm.nih.gov/37616235/  
25. Brasil, Ministério da Saúde, Secretaria de Atenção à Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Protocolo de uso de palivizumabe para prevenção da infecção pelo vírus sincicial respiratório [Internet]. 2018 Oct [cited 2025 Jul 4]. Available from: https://www.gov.br/conitec/ptbr/midias/protocolos/protocolo_uso/protocolouso_palivizumabe.pdf  
26. Brasil, Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Palivizumabe para a prevenção da infecção pelo vírus sincicial respiratório. Relatório de Recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS – CONITEC – 16 [Internet]. 2012. Available from: www.saude.gov.br/sctie  
27. Brasil, Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde. Relatório de recomendação n<sup>o</sup> 975: Vacina vírus sincicial respiratório (VSR) A e B (recombinante) em gestantes com 32 a 36 semanas para prevenção da doença do trato respiratório inferior causada pelo vírus sincicial respiratório (VSR) em crianças até os 6 meses de idade. 2025;  
28. Brasil, Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação do Complexo Econômico-Industrial da Saúde. Portaria SECTICS/MS n<sup>o</sup> 14, de 24 de fevereiro de 2025 que torna pública a decisão de incorporar, no âmbito do Sistema Único de Saúde - SUS, a vacina VSR A e B (recombinante) em gestantes para prevenção da doença do trato respiratório inferior causado pelo VSR em recém-nascidos, conforme estratégia do Programa Nacional de Imunizações. Diário Oficial da União: Ministério da Saúde. 2025;  
29. Brasil, Ministério da Saúde, Secretaria de Ciência Tecnologia Inovação e Complexo da Saúde. Relatório de Recomendação n<sup>o</sup> 974: Nirsevimabe para a prevenção de infecção do trato respiratório inferior associado ao Vírus Sincicial Respiratório para bebês prematuros ou portadores de comorbidades [Internet]. Brasília, DF; 2025 Feb [cited 2025 May 28]. Available  
18  
from: https://www.gov.br/conitec/ptbr/midias/relatorios/2025/relatorio_974_nirvesimabe_virus_sincicial_respiratorio.pdf  
30. Brasil, Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação do Complexo Econômico-Industrial da Saúde. Portaria SECTICS/MS n<sup>o</sup> 15, de 28 de fevereiro de 2025 que torna pública a decisão de incorporar, no âmbito do Sistema Único de Saúde- SUS, o nirsevimabe para a prevenção de infecção do trato respiratório inferior associado ao vírus sincicial respiratório para os bebês prematuros menores que 37 semanas e crianças menores de 2 anos portadores de comorbidades, conforme Protocolo Clínico do Ministério da Saúde. Diário Oficial da União: Ministério da Saúde. 2025;  
31. Agência Nacional de Vigilância Sanitária. Beyfortus®. Nirsevimabe [Bula] [Internet]. 2024 Nov [cited 2025 May 28]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/3584120?numeroProcesso=2535163839520228 2  
32. Agência Nacional de Vigilância Sanitária. Synagis®. Palivizumabe [Bula]. 2023 Sep 28;  
33. Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde e Ambiente, Departamento do Programa Nacional de Imunizações. ESTRATÉGIA DE IMUNIZAÇÃO CONTRA O VÍRUS SINCICIAL RESPIRATÓRIO PARA CRIANÇAS PREMATURAS E COM COMORBIDADE [Internet]. 2026. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/estrategia_imunizacao_virus_sincicial_respiratorio. pdf  
34. Borrelli M, Terrone G, Evangelisti R, Fedele F, Corcione A, Santamaria F. Respiratory phenotypes of neuromuscular diseases: A challenging issue for pediatricians. Pediatr Neonatol [Internet]. 2023 Mar 1 [cited 2025 Nov 5];64(2):109–18. Available from: https://pubmed.ncbi.nlm.nih.gov/36682912/  
35. Hayes LH, Darras BT. Neuromuscular problems of the critically Ill neonate and child. Semin Pediatr Neurol [Internet]. 2024 Apr 1 [cited 2025 Nov 5];49. Available from: https://pubmed.ncbi.nlm.nih.gov/38677802/  
36. Agência Nacional de Vigilância Sanitária. Anvisa aprova medicamento para prevenção do vírus sincicial respiratório (VSR) [Internet]. [cited 2025 Nov 5]. Available from: https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa/2023/anvisa-aprova-medicamentopara-prevencao-do-virus-sincicial-respiratorio-vsr  
37. Sociedade Brasileira de Pediatria. Vírus sincicial respiratório (VSR) - Pediatria para Famílias [Internet]. 2024 [cited 2025 Nov 5]. Available from: https://www.sbp.com.br/pediatria-parafamilias/vacinas/virus-sincicial-respiratorio-vsr/  
38. American Academy of Pediatrics. Nirsevimab Administration Visual Guide [Internet]. 2024 [cited 2025 Jun 9]. Available from: https://downloads.aap.org/AAP/PDF/Nirsevemab-VisualGuide.pdf  
39. Brasil, Ministério da Saúde, Agência Nacional de Vigilância Sanitária. Resolução da Diretoria Colegiada - RDC n<sup>o</sup> 222, de 28 de março de 2018. Regulamenta as Boas Práticas de Gerenciamento dos Resíduos de Serviços de Saúde e dá outras providências. 2018 Mar 28 [cited 2025 Nov 5]; Available from: https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2018/rdc0222_28_03_2018.pdf  
40. Brasil, Ministério do Meio Ambiente, Conselho Nacional do Meio Ambiente. Resolução n° 358 de 29 de abril de 2005. Dispõe sobre o tratamento e a disposição final dos resíduos dos serviços de saúde e dá outras providências. 2005 Apr 29 [cited 2025 Nov 5]; Available from: https://www.ibama.gov.br/sophia/cnia/legislacao/MMA/RE0358-290405.PDF  
19  
41. Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde e Ambiente, Departamento do Programa Nacional de Imunizações. Manual de normas e procedimentos para vacinação [Internet]. 2<sup>a</sup> edição revisada. Brasília; 2024. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/manual_normas_procedimentos_2edrev.pdf  
42. Drysdale SB, Cathie K, Flamein F, Knuf M, Collins AM, Hill HC, et al. Nirsevimab for Prevention of Hospitalizations Due to RSV in Infants. New England Journal of Medicine [Internet]. 2023 Dec 28 [cited 2025 Jul 4];389(26):2425–35. Available from: https://www.nejm.org/doi/pdf/10.1056/NEJMoa2309189  
43. Consolati A, Farinelli M, Serravalle P, Rollandin C, Apprato L, Esposito S, et al. Safety and Efficacy of Nirsevimab in a Universal Prevention Program of Respiratory Syncytial Virus Bronchiolitis in Newborns and Infants in the First Year of Life in the Valle d’Aosta Region, Italy, in the 2023–2024 Epidemic Season. Vaccines (Basel) [Internet]. 2024 May 1 [cited 2025 Jul 4];12(5). Available from: https://pubmed.ncbi.nlm.nih.gov/38793800/  
44. Ocana de Sentuary C, Testard C, Lagrée M, Leroy M, Gasnier L, Enes-Dias A, et al. Acceptance and safety of the RSV-preventive treatment of newborns with nirsevimab in the maternity department: a prospective longitudinal cohort study in France. EClinicalMedicine [Internet]. 2025 Jan 1 [cited 2025 Jul 4];79. Available from: https://pubmed.ncbi.nlm.nih.gov/39726670/  
45. Domachowske JB, Chang Y, Atanasova V, Cabañas F, Furuno K, Nguyen KA, et al. Safety of Re-dosing Nirsevimab Prior to RSV Season 2 in Children with Heart or Lung Disease. J Pediatric Infect Dis Soc [Internet]. 2023 Aug 1 [cited 2025 Jun 16];12(8):477–80. Available from: https://pubmed.ncbi.nlm.nih.gov/37466917/  
46. Brasil, Ministério da Saúde. Portaria GM/MS N<sup>o</sup> 6.623, d 14 de fevereiro de 2025. Institui a Rede de Imunobiológicos para Pessoas com Situações Especiais - RIE [Internet]. 2025 [cited 2025 Jul 4]. Available from: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2025/prt6623_19_02_2025.html</u>

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 1. Escopo e finalidade -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo de uso do nirsevimabe para prevenção de infecção do trato respiratório inferior associado ao vírus sincicial respiratório para bebês prematuros ou com comorbidades, contendo a descrição da metodologia de busca de evidências científicas. O documento tem como objetivo embasar o texto do Protocolo de uso, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e potenciais interessados.  
O documento foi elaborado sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Inovação em Saúde do Ministério da Saúde (DGITS/SCTIE/MS), de acordo com as evidências disponíveis. Todos os participantes do processo de elaboração preencheram o formulário de Declaração de Conflitos de Interesse.  
20

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 2. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas -->
A proposta de elaboração do Protocolo de Uso do nirsevimabe para prevenção de infecção do trato respiratório inferior associado ao vírus sincicial respiratório para bebês prematuros ou com comorbidades foi apresentada na 130ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em novembro de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES)Secretaria de Vigilância em Saúde e Ambiente (SVSA) e Secretaria de Atenção Primária à Saúde (SAPS). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 147ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
O processo de elaboração do Protocolo de uso de nirsevimabe para prevenção de infecção do trato respiratório inferior associado ao vírus sincicial respiratório para bebês prematuros ou com comorbidades, iniciou-se a partir da recomendação favorável à incorporação da tecnologia pela Conitec, de acordo com o Relatório de Recomendação nº 974, de fevereiro de 2025<sup>1</sup> .  
Para a elaboração do documento, foi realizada busca sistemática por diretrizes clínicas nacionais e internacionais sobre a utilização de nirsevimabe para a prevenção de infecção do trato respiratório inferior associado ao Vírus Sincicial Respiratório (VSR) em bebês prematuros ou com comorbidades. A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR (população, intervenção, comparador, atributos das diretrizes clínicas e recomendações) está descrita no **Quadro A** .  
**Quadro A.** Pergunta PICAR (população, intervenção, comparador, atributos das diretrizes clínicas e recomendações).  
|**População**|Bebêsprematuros  ou com comorbidades|
|---|---|
|**Intervenção**|Nirsevimabe para a prevenção de infecção do trato respiratório inferior<br>associada ao VSR|
|**Comparador**|Nenhuma intervenção, placebo oupalivizumabe|
|**Atributos das diretrizes**|Diretrizes clínicas elaboradas com base em revisão sistemática,<br>disponíveis em inglês, espanhol ou português, desde que incluíssem<br>recomendações sobre nirsevimabe|
|**Recomendações**|Recomendações sobre a utilização de nirsevimabe para a prevenção de<br>infecção do trato respiratório inferior associado ao Vírus Sincicial<br>Respiratório(VSR)em bebêsprematuros ou com comorbidades|  
Fonte: autoria própria

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
Com base na pergunta PICAR definida, foi realizada a busca nas seguintes bases de dados: MEDLINE (via Pubmed), Embase, LILACS (via BVS) e Scielo. As estratégias de busca para cada base estão descritas no **Quadro B** . Todas as buscas foram conduzidas em 16/03/2025.  
21  
**Quadro B.** Estratégia de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre o uso de nirsevimabe.  
|**Base**|**Estratégia(16/03/2025)**|**Resultados**|
|---|---|---|
|MEDLINE<br>(via<br>Pubmed)|((("Respiratory Syncytial Virus" OR "Syncytial Virus, Respiratory" OR<br>"Virus,<br>Respiratory<br>Syncytial"<br>OR<br>Orthopneumovirus<br>OR<br>Orthopneumoviruses OR RSV OR "Chimpanzee Coryza Agent") OR<br>(("Respiratory Syncytial Virus Infections"[Mesh]) OR ("Respiratory<br>Syncytial Virus Infection" OR "Infections, Respiratory Syncytial Virus"<br>OR "RSV Infection" OR "Infection, RSV" OR "RSV Infections"))) OR<br>(("Respiratory Syncytial Virus, Human"[Mesh]) OR ("Human respiratory<br>syncytial virus" OR "HRSV Human respiratory syncytial virus" OR<br>"human<br>RSV"<br>OR<br>"RSV,<br>human")))<br>AND<br>(("nirsevimab"<br>[Supplementary Concept]) OR (nirsevimab OR MED-18897 OR<br>MED18897 OR beyfortus)) AND ("Guideline" [Publication Type] OR<br>"Guidelines as Topic"[Mesh] OR Guidelines as Topic OR "Practice<br>Guideline" [Publication Type] OR Practice Guideline OR "Health<br>Planning Guidelines"[Mesh] OR Health Planning Guidelines OR<br>Guidelines as Topics OR Clinical Practice Guideline OR "Clinical<br>Protocols"[Mesh] OR Protocol, Clinical OR Clinical Protocol OR<br>Protocols, Clinical OR Treatment Protocols OR Treatment Protocol OR<br>Protocols, Treatment OR Clinical Research Protocol OR Research<br>Protocols, Clinical OR Protocols, Clinical Research OR Research<br>Protocol, Clinical OR Clinical Research Protocols OR Protocol, Clinical<br>Research OR "Consensus"[Mesh] OR Consensus OR "Consensus<br>Development Conference, NIH" [Publication Type] OR "Consensus<br>Development<br>Conference"<br>[Publication<br>Type]<br>OR<br>"Consensus<br>Development Conferences, NIH as Topic"[Mesh] OR "Consensus<br>Development Conferences as Topic"[Mesh] OR "Standard of<br>Care"[Mesh] OR Standard of Care OR Care Standard OR Care Standards<br>OR Standards of Care))|26|
|Embase|('human respiratory syncytial virus'/exp OR 'human orthopneumovirus'<br>OR 'human respiratory syncytial virus' OR 'rs virus (lung)' OR 'rs virus<br>(pulmonary)' OR 'rsv (lung)' OR 'respiratory syncytial pneumovirus' OR<br>'respiratory syncytial virus' OR 'syncytial virus' OR 'chimpanzee coryza<br>agent' OR 'respiratory chimpanzee coryza agent' OR 'respiratory syncitial<br>virus' OR 'respiratory syncytial virus, human' OR 'respirosyncytial virus'<br>OR 'syncytial respiratory virus' OR 'virus, respiratory syncytial') AND<br>('nirsevimab'/exp OR 'beyfortus' OR 'medi 8897' OR 'medi8897' OR<br>'nirsevimab' OR 'nirsevimab alip' OR 'nirsevimab-alip' OR 'nirsevumab'<br>OR 'sp 0232' OR 'sp 232' OR 'sp0232' OR 'sp232') AND ('practice<br>guideline'/exp OR 'guidelines' OR 'guidelines as topic' OR 'practice<br>guideline' OR 'practice guidelines' OR 'practice guidelines as topic')|21|
|LILACS (via<br>BVS)|(mh:("Infecções por Vírus Respiratório Sincicial" OR "Respiratory<br>Syncytial Virus Infections" OR "Infecciones por Virus Sincitial<br>Respiratorio" OR "Vírus Sincicial Respiratório Humano" OR<br>"Respiratory Syncytial Virus, Human" OR "Virus Sincitial Respiratorio<br>Humano" OR "Vírus Sinciciais Respiratórios" OR "Respiratory Syncytial<br>Viruses" OR "Virus Sincitiales Respiratórios")) OR ("Infecção pelo Vírus<br>Respiratório Sincicial" OR "Infecção pelo Vírus Sincicial Respiratório"<br>OR "Infecção por RSV" OR "Infecções por Vírus Sincicial Respiratório"<br>OR "Agente da Coriza do Chimpanzé" OR orthopneumovirus OR "Vírus<br>Sincicial Respiratório") AND (nirsevimabe OR nirsevimab) AND<br>db:("IBECS" OR "BIGG" OR "BRISA") AND instance:"regional"|11|
|Scielo|("Respiratory Syncytial Virus" OR "Syncytial Virus, Respiratory" OR<br>"Virus,<br>Respiratory<br>Syncytial"<br>OR<br>Orthopneumovirus<br>OR|6|  
22  
|**Base**|**Estratégia(16/03/2025)**|**Resultados**|
|---|---|---|
||Orthopneumoviruses OR RSV OR "Chimpanzee Coryza Agent" OR<br>"Respiratory Syncytial Virus Infections" OR "Respiratory Syncytial Virus||
||Infection" OR "Infections, Respiratory Syncytial Virus" OR "RSV<br>Infection" OR "Infection, RSV" OR "RSV Infections" OR "Respiratory||
||Syncytial Virus, Human" OR "Human respiratory syncytial virus" OR<br>"HRSV Human respiratory syncytial virus" OR "human RSV" OR "RSV,<br>human") AND (nirsevimab OR MED-18897 OR MED18897 OR<br>beyfortus)||  
Fonte: autoria própria  
A elegibilidade foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan®<sup>2</sup> . Na segunda etapa, realizou-se a leitura de texto completo, mantendo-se diretrizes clínicas que abordassem a utilização de nirsevimabe para prevenção de infecção do trato respiratório inferior associado ao vírus sincicial respiratório para bebês prematuros ou com comorbidades. As divergências, quando necessário, foram discutidas até chegar a um consenso ou discutidas com um terceiro pesquisador.  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
- Diretrizes que abordam a prevenção da infecção do trato respiratório inferior associada ao VSR em bebês prematuros ou com comorbidades;  
- Diretrizes que incluem recomendações sobre o uso de nirsevimabe para a prevenção de infecção pelo VSR;  
- Diretrizes que consideram nenhuma intervenção, placebo ou palivizumabe como comparador;  
- Diretrizes clínicas elaboradas com base em revisão sistemática da literatura e que explicitem a metodologia utilizada;  
- Disponíveis em inglês, espanhol ou português.  
**Exclusão:**  
- Diretrizes cujos textos não estejam disponíveis publicamente ou que requerem acesso pago, caso não sejam obtidas por outros meios oficiais.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
Foram identificadas 64 publicações. Após o processo de exclusão de duplicatas e de elegibilidade por título e resumo, 19 referências foram selecionadas para avaliação por texto completo. Após a leitura completa dos textos, foram incluídas nesta avaliação três publicações. A **Figura A,** adaptada do modelo de fluxograma disponibilizado pela plataforma PRISMA<sup>3</sup> , resume os resultados do processo de elegibilidade e o **Quadro C** apresenta as referências excluídas na elegibilidade por leitura de texto completo com os seus respectivos motivos de exclusão.  
23  
<!-- Start of picture text -->
Referéncias identificadas em:<br>Bases de dados Referéncias removidas antes do<br>MEDLINE (n =26) 4<br>Embase (n =21) er lic rane<br>LILACS (n =11) Uuplicatas (n =2)<br>Scielo (n =6)<br>Referéncias avaliadas por titulo Referéncias excluidas<br>eresumo (n =43)<br>(n =62 )<br>Referéncias incluidas para Referéncias cujo texto completo<br>avaliacdo por texto completo ————+|_ nao foi identificado<br>(n=19) (n =3)<br>Referéncias avaliadas por texto Referéncias excluidas: (n =13 )<br>completo —>| Tipo de publicacao (n =3 )<br>(n =16) NAo inclui recomendacdes<br>(n=2)<br>Nao é baseado em revisdo<br>sistematica (n =7 )<br>Escopo (n =1)<br>Estudos incluidos na reviséo<br>(n=3)<br><!-- End of picture text -->  
**Figura A.** Fluxograma de seleção de diretrizes clínicas sobre o nirsevimabe. Fonte: adaptado de Page et al. (2021)<sup>3</sup> .  
Considerando a particularidade dos achados na literatura, realizou-se também uma busca manual complementar com o objetivo de identificar materiais não localizados. Assim, foram incluídas 43 referências adicionais.  
**Quadro C.** Estudos excluídos na fase de elegibilidade por leitura de texto completo e motivo da exclusão.  
|**Recomendação não baseada em revisão sistemática**|
|---|
|Alharbi AS, Al-Hindi MY, Alqwaiee M, Al-Shamrani A, Alharbi S, Yousef A, et al. Saudi Initiative of<br>Bronchiolitis Diagnosis, Management, and Prevention 2024 updated consensus on the prevention of<br>respiratorysyncytial virus. Ann Thorac Med. 2024;19(3):190–200.|
|Australian Prescriber. Nirsevimab for prevention of respiratory syncytial virus (RSV) lower respiratory<br>tract disease in neonates and infants. Vol. 47, Australian Prescriber. Therapeutic Guidelines Ltd; 2024. p.<br>102–3.|
|Manti S, Baraldi E. Learn from international recommendations and experiences of countries that have<br>successfully implemented monoclonal antibody prophylaxis for prevention of RSV infection. Vol. 51,<br>Italian Journal of Pediatrics. BioMed Central Ltd;2025.|  
24

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
Martínez de Cuellar C, Campuzano de Rolón A, Giménez E, Weber E, Lovera D, Rolón R, et al. Prevención de Infecciones Respiratorias por VSR: Consenso Interinstitucional. Pediatría (Asunción). 2024 Aug 31;51(2):146–57.  
Paes B, Brown V, Courtney E, Fleischer E, Guy F, Lau E, et al. Optimal implementation of an Ontario nirsevimab program for respiratory syncytial virus (RSV) prophylaxis: Recommendations from a <u>provincial RSV expert panel. Hum Vaccin Immunother. 2024;20(1).</u>  
Riccò M, Abu-Raya B, Icardi G, Spoulou V, Greenberg D, Pecurariu OF, et al. Respiratory Syncytial Virus: A WAidid Consensus Document on New Preventive Options. Vol. 12, Vaccines. Multidisciplinary Digital Publishing Institute (MDPI); 2024.  
Zepeda GF, Díaz PA, Ortiz PF, Angélica Palomino MM, Tapia LF, Puppo HG, et al. Bronquiolitis viral. Recomendaciones sobre su manejo en Chile 2024 a,b ACTUALIZACIONES.  
**<u><mark>Recomendações embasadas em evidências indiretas</mark></u>**  
<mark>Centers for Disease Control and Prevention, Advisory Committee on Immunization Practices. Grading</mark> of Recommendations, Assessment, Development, and Evaluation (GRADE): Nirsevimab, Season 2 <u>[Internet]. 2024 Sep.</u>

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
Sangrador CO, Dios JG, Santamaría AB, Páez EO, Moneo BP, Arias MM. Evidentia praxis: nirsevimab <u>y prevención de bronquiolitis en lactantes nacidos a término. Rev Pediatr Aten Primaria. 2023;25:301–8.</u>

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
<mark>Arce Al, García FJA. Nirsevimab y otras estrategias para la prevención de la infección por VRS. An</mark> Pediatr (Engl Ed). 2023 Oct 1;99(4):257–63.  
López CM, Malfaz FC, Sánchez MG. Recommendations of the Spanish Society of Pediatric Cardiology and Congenital Heart Diseases for the prevention of respiratory syncytial virus infections with nirsevimab in pediatric cardiology. An Pediatr (Engl Ed). 2024 Feb 1;100(2):148–50.  
Luna MS, Colomer BF, Pico MLC. Recommendations of the Spanish Society of Neonatology for the prevention of severe respiratory syncytial virus infections with nirsevimab, for the 2023–2024 season. An Pediatr (Engl Ed). 2023 Oct 1;99(4):264–5.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 3. Processo de elaboração do Protocolo de Uso de nirsevimabe -->
Fleming-Dutra KE, Jones JM, Roper LE, Prill MM, Ortega-Sanchez IR, Moulia DL, et al. Morbidity and Mortality Weekly Report Use of the Pfizer Respiratory Syncytial Virus Vaccine During Pregnancy for the Prevention of Respiratory Syncytial Virus-Associated Lower Respiratory Tract Disease in Infants: Recommendations of the Advisory Committee on Immunization Practices-United States, 2023 [Internet]. Vol. 72. 2023.  
Fonte: autoria própria.

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: Colaboração externa -->
O protocolo foi elaborado pelo Instituto Vértice da Universidade Federal de São Paulo.  
Os membros do Grupo Elaborador e os participantes das reuniões de elaboração do referido PCDT estão descritos no **Quadro D** .  
**Quadro D.** Membros do Grupo Elaborador e participantes das reuniões de elaboração.  
**Participantes**  
25  
|Ana Catarina Melo de Araujo|
|---|
|Ana Karolina Barreto Berselli Marinho|
|Brígida Dias Fernandes|
|Bruna Bento dos Santos*|
|Cecília de Oliveira Carvalho Faria*|
|Daniela Oliveira de Melo*|
|Débora Reis de Araújo|
|Eder Gatti Fernandes|
|Elder Marcos de Morais|
|Flávia Avelino Goursand|
|Jadher Percio|
|Juliana Soprani*|
|Kamila Fernanda Vieira Carrero|
|Lorena de Castro Pacheco Barros Diniz|
|Márcia Vieira Leite|
|Marta da Cunha Lobo Souto Maior|
|Petra Santos Castro Rangel|
|Sirlene de Fátima Pereira|
|Stéfani Sousa Borges*|
|Thayssa Neiva da Fonseca Victer|  
*Metodologistas.  
Declaração e Manejo de Conflitos de Interesse  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro E** ).  
**Quadro E.** Questionário de conflitos de interesse das diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar fi<br>algum dos benefícios abaixo?|nanceiramente|
|---|---|
|Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>( ) Não|
|Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>( ) Não|
|Financiamento para redação de artigos ou editorias|(   ) Sim<br>( ) Não|
|Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>( )Não|
|Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>( ) Não|
|Algum outro benefício financeiro|(   ) Sim<br>( ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma<br>forma ser beneficiada ouprejudicada com as recomendações da diretriz?|(   ) Sim<br>( ) Não|  
26  
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>( ) Não|
|---|---|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cu<br>possam ser afetadospela sua atividade na elaboração ou revisão da diretriz?|jos interesses|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>( ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>( ) Não|
|d) Partido político|(   ) Sim<br>( ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>( ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>( ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>( ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos<br>interessespossam ser afetados?|(   ) Sim<br>( ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer<br>oque você irá escrever eque deveria ser do conhecimentopúblico?|(   ) Sim<br>( ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja<br>relacionado acima, quepossa afetar sua objetividade ou imparcialidade?|(   ) Sim<br>( ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?|(   ) Sim<br>( ) Não|  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração está na **Quadro F.**  
27  
**Quadro F.** Declaração de conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração.  
|**Participante**|**C**<br>**Questã**|**onflitos de interesses declarados**<br>**o**<br>**Descrição geral**|**Decisão**<br>**tomada**|
|---|---|---|---|
|Bruna Bento dos Santos|-|-|Declarar e<br>participar|
|Ana Catarina Melo de Araujo|-|-|Declarar e<br>participar|
|Ana Karolina Barreto Berselli<br>Marinho|-|-|Declarar e<br>participar<br>|
|Brígida Dias Fernandes|-|-|Declarar e<br>participar|
|Bruna Bento dos Santos*|-|-|Declarar e<br>participar|
|Cecília de Oliveira Carvalho<br>Faria*|-|-|Declarar e<br>participar|
|Daniela Oliveira de Melo*|-|-|Declarar e<br>participar|
|Débora Reis de Araújo|-|-|Declarar e<br>participar|
|Eder Gatti Fernandes|-|-|Declarar e<br>participar|
|Elder Marcos de Morais|-|-|Declarar e<br>participar|
|Flávia Avelino Goursand|-|-|Declarar e<br>participar|
|Jadher Percio|5e|Integrante<br>dos<br>respectivos<br>comitês, sociedades ou grupos de<br>trabalhos:<br>Comitê<br>Interinstitucional<br>de<br>Farmacovigilância de Vacinas e<br>outros Imunobiológicos (CIFAVI)<br>e<br>2-<br>Câmara<br>Técnica<br>de<br>Farmacovigilância<br>(CT-FARM)<br>da Agência Nacional de Vigilância<br>Sanitária(Anvisa)|Declarar e<br>participar|
|Juliana Soprani*|-|-|Declarar e<br>participar|
|Kamila Fernanda Vieira<br>|-|-|Declarar e<br>|
|Carrero|||participar|
|Lorena de Castro Pacheco<br>Barros Diniz|-|-|Declarar e<br>participar<br>|
|Márcia Vieira Leite|-|-|Declarar e<br>participar|
|Marta da Cunha Lobo Souto<br>Maior|-|-|Declarar e<br>participar|
|Petra Santos Castro Rangel|-|-|Declarar e<br>participar|
|Sirlene de Fátima Pereira|-|-|Declarar e<br>participar|
|Stéfani Sousa Borges*|-|-<br> <br>|Declarar e<br>participar|
|Thayssa Neiva da Fonseca<br>Victer|5e|Integrante<br>dos<br>respectivos<br>comitês, sociedades ou grupos de<br>trabalhos: Comissão Consultiva|Declarar e<br>participar|  
28  
|**Participante**|**Con**<br>|**flitos de interesses declarados**<br>|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descrição geral**|**tomada**|
|||Permanente para o Complexo<br>Econômico-Industrial da Saúde<br>(CPCEIS - Portaria GM/MS nº<br>1.178, de 28 de agosto de 2023),<br>Comissão Permanente de Gestão<br>dos Insumos Estratégicos para a<br>Saúde (CPGEIS - Portaria GM nº<br>594 de 10 de maio de 2023) e<br>Comitê Técnico Assessor do<br>Complexo Econômico-Industrial<br>da Saúde (CEIS - Art. 4º do<br>Decreto nº 11.714, de 26 de<br>setembro de 2023).||  
29

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: 5. Referências -->
- Brasil, Ministério da Saúde, Secretaria de Ciência Tecnologia Inovação e Complexo da Saúde. Relatório de Recomendação n<sup>o</sup> 974: Nirsevimabe para a prevenção de infecção do trato respiratório inferior associado ao Vírus Sincicial Respiratório para bebês prematuros ou portadores de comorbidades [Internet]. Brasília, DF; 2025 fev [citado 28 de maio de 2025]. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2025/relatorio_974_nirvesimabe_virus_sincicial_respiratorio.pdf  
- Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Vol. 5, Systematic Reviews. 2016. p. 210.  
- Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ [Internet]. 29 de março de 2021 [citado 8 de julho de 2025];372. Disponível em: https://www.bmj.com/content/372/bmj.n71  
30  
APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO

---

<!-- METADADOS: doenca: Protocolo de uso do Nirsevimabe | secao: PROTOCOLO -->
|**Número do**<br>||**Tec**|**nologias avaliadasp**|**ela Conitec**|
|---|---|---|---|---|
|**Relatório da**<br>**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporaçã**<br>**uso**|**o ou alteração do**<br>**no SUS**|**Não incorporação**<br>**ou não alteração no**<br>**SUS**|
|Relatório<br>de<br>Recomendação nº<br>1083/2026|Primeira<br>versão<br>da<br>diretriz|Nirsevimabe p<br>infecção do<br>inferior<br>asso<br>sincicial respir<br>prematuros<br> <br>semanas e cria<br>anos<br>ou<br>comorbidades<br>SECTICS/MS<br>Relatório de<br>974/2025]|ara a prevenção de<br>trato respiratório<br>ciado<br>ao<br>vírus<br>atório para os bebês<br>menores<br>que<br>37<br>nças menores de 2<br>portadores<br>de<br> <br>[Portaria<br> <br>nº<br>15/2025;<br>Recomendação nº|-|  
31  
32

---

