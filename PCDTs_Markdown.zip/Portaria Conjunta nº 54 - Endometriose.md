<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE ATENÇÃO PRIMÁRIA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SAPS/SCTIE Nº 54, DE 02 DE JUNHO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Endometriose.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE, A SECRETÁRIA DE ATENÇÃO PRIMÁRIA**  
**À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Endometriose.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Endometriose, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Endometriose.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS nº 879, de 12 de julho de 2016, publicada no Diário Oficial da União nº 135, de 15 de julho de 2016, seção 1, pág. 53.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: ANA LUIZA FERREIRA RODRIGUES CALDAS -->
FERNANDA DE NEGRI  
1  
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA ENDOMETRIOSE**

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **1. INTRODUÇÃO** -->
A endometriose é uma doença ginecológica definida pelo desenvolvimento e crescimento de tecido semelhante ao endométrio e/ou estroma fora da cavidade uterina, o que resulta numa reação inflamatória crônica<sup>1,2</sup> . As localizações mais comumente envolvidas são os órgãos pélvicos como os ovários, tubas uterinas e ligamentos uterinos. Contudo, pode acometer também parede lateral pélvica (peritônio), ligamentos útero-sacros, bexiga, ureter, intestino, cólon sigmoide, apêndice, ligamentos redondos e reto<sup>3</sup> .  
Diversas teorias sobre a patogênese da endometriose apontam para um processo multicausal, envolvendo fatores genéticos, anormalidades imunológicas e disfunção endometrial<sup>3</sup> . Na teoria da implantação, o tecido endometrial, por meio da menstruação retrógrada, teria acesso a estruturas pélvicas através das tubas uterinas, implantando-se na superfície peritonial, estabelecendo fluxo sanguíneo e gerando resposta inflamatória<sup>4</sup> . A teoria da metaplasia celômica propõe que células indiferenciadas do peritônio pélvico teriam capacidade de se diferenciar em tecido endometrial. A teoria do transplante direto explicaria o desenvolvimento de endometriose em episiotomia, cicatriz de cesariana e em outras cicatrizes cirúrgicas. A disseminação de células ou tecido endometriais por meio de vasos sanguíneos e linfáticos explicaria as localizações fora da cavidade pélvica<sup>5</sup> .  
As apresentações clínicas mais comuns são infertilidade e dor pélvica (cíclica ou acíclica), com dismenorreia e dispareunia<sup>6,7</sup> . Outros sintomas incluem aumento gradual da dor pré-menstrual, menstruação irregular abundante, dor na região sacral da coluna, ovulação dolorosa, dor ao urinar, disquezia, inchaço abdominal, constipação ou diarreia, náuseas, dores de estômago, fadiga e tumorações abdominais<sup>2,8</sup> . Também podem ocorrer sintomas relacionados às localizações atípicas do tecido endometrial, como a dor pleurítica, pneumotórax, hemotórax, hemoptise, cefaleias ou convulsões, lesões em cicatrizes cirúrgicas com dor, edema e sangramento local<sup>9,10</sup> .  
Embora nem todas as pessoas com endometriose sejam sintomáticas, a dor e a infertilidade associadas à doença são características clínicas que afetam não apenas os indivíduos, mas também seus parceiros e familiares1. A endometriose tem impacto na qualidade de vida e na função reprodutiva dos indivíduos. A dor pode repercutir no funcionamento físico, nas atividades cotidianas, laborais e educacionais, na vida social, na intimidade e no bem-estar emocional<sup>11</sup> .  
A endometriose pode influenciar a fertilidade de várias maneiras, sejam elas: anatomia distorcida da pelve, aderências, tubas uterinas cicatrizadas, inflamação das estruturas pélvicas, alterações no funcionamento do sistema imunológico, alterações no ambiente hormonal dos óvulos, implantação prejudicada de uma gravidez e qualidade alterada do óvulo. Muitas vezes, a infertilidade permanece inexplicada devido ao atraso no diagnóstico, causando níveis significativos de estresse<sup>12</sup> .  
Na maior parte das pessoas acometidas por endometriose o exame físico apresenta achados discretos, e não há alteração patognomônica da doença. Dor à palpação de fundo de saco e de ligamentos uterossacros, palpação de nódulos ou massas anexiais, útero ou anexos fixos em posição retrovertida podem ser alguns dos achados ao exame físico<sup>13</sup> . Dada à inespecificidade de muitos sintomas, existe uma lacuna diagnóstica entre o início dos sintomas e o diagnóstico acurado, com média de 8 a 12 anos<sup>14</sup> .  
Há um esforço em tornar o seu diagnóstico mais simples e fundamentá-lo em critérios clínicos, tais como dispareunia, dismenorreia ou dor pélvica crônica com piora progressiva. História familiar de endometriose ou dificuldade para engravidar também podem auxiliar no estabelecimento do diagnóstico<sup>12</sup> .  
2  
A melhor forma de se realizar o estadiamento seria a apresentação fenotípica da doença, uma vez que nenhuma forma de estadiamento conseguiu correlacionar os achados cirúrgicos com a apresentação clínica ou progressão da endometriose<sup>15</sup> . Desta forma, a endometriose pode ser classificada como: i) peritoneal ou superficial; ii) profunda, quando os implantes acometem mais do que 5 mm de profundidade); ou iii) ovariana, quando existe endometrioma (tumor relacionado com penetração e crescimento de tecido endometrial no parênquima ovariano)<sup>8,14</sup> .  
A doença é diagnosticada em pessoas do sexo feminino, majoritariamente em idade reprodutiva, e o pico da incidência ocorre entre 25 e 34 anos de idade<sup>16,</sup> uma vez que o desenvolvimento do tecido endometriótico é dependente de estrogênio. Pessoas do sexo feminino pós-menopáusicas representam somente 2% a 4% de todos os casos submetidos à laparoscopia por suspeita de endometriose<sup>17.</sup>  
O risco de endometriose está relacionado à etnia, sendo que pessoas asiáticas têm maior risco (aumentado em 9 vezes) que brancas18, além de caucasianas apresentarem maior risco que negras8. Em 7% dos casos, a condição está associada à predisposição genética familiar<sup>8</sup> . Outros fatores de risco envolvem: menarca precoce (antes dos 11 anos), ciclos menstruais inferiores a 27 dias, idade entre 25 e 29 anos e tabagismo<sup>8</sup> . O consumo regular/moderado de álcool e exposição a produtos químicos desreguladores endócrinos também representam potenciais fatores de risco para endometriose<sup>19</sup> . Há aumento na incidência de endometriose em obesas em comparação a mulheres com peso corporal normal<sup>20</sup> .  
A prevalência da endometriose varia amplamente na literatura (entre 0,05% e 37,1%) e é especialmente influenciada pelo delineamento dos estudos e a origem dos dados. Entretanto, estima-se uma prevalência combinada de 6,82%, considerando estudos baseados em dados clínicos<sup>16</sup> . No Brasil, a prevalência foi de 6,4% entre mulheres em idade reprodutiva, podendo chegar a 34,2% em mulheres sintomáticas, de acordo com estudo conduzido entre 2017 e 2021 em um ambulatório público<sup>21,22</sup> . Além disso, a condição representa um dos achados ginecológicos mais comuns nos atendimentos em emergência (37%), e estima-se que a infertilidade pode acometer até 6,5 vezes mais mulheres diagnosticadas com endometriose<sup>16,22</sup> . Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da endometriose. A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
N80.0 Endometriose do útero N80.1 Endometriose do ovário N80.2 Endometriose da trompa de Falópio  
N80.3 Endometriose do peritônio pélvico  
N80.4 Endometriose do septo retovaginal e da vagina  
N80.5 Endometriose do intestino N80.8 Outra endometriose

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **3. DIAGNÓSTICO** -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, de raça, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
3  
A laparoscopia com inspeção direta da cavidade e visualização dos implantes já foi considerada como padrão ouro para diagnóstico da endometriose<sup>1,13,15</sup> . Entretanto, considerando as dificuldades de acesso ao procedimento e o atraso no diagnóstico, discute-se a possibilidade de iniciar o tratamento baseado na história clínica e exame físico. O tratamento empírico pode ser vantajoso do ponto de vista clínico, com potencial de melhorar a qualidade de vida das pacientes, já que não há benefício em atrasá-lo esperando por um achado confirmatório cirúrgico<sup>14</sup> .  
Assim, recomenda-se que o diagnóstico de endometriose seja considerado na presença de dismenorreia, dispareunia profunda, disúria, disquezia, sangramento retal doloroso ou hematúria, dor na ponta dos ombros, pneumotórax catamenial, tosse cíclica/hemoptise/dor no peito, inchaço e dor cíclica da cicatriz, fadiga e infertilidade1. Recomenda-se ainda que, ao considerar um diagnóstico presuntivo de endometriose, a opção de confirmação diagnóstica adicional ou de início de tratamento empírico seja discutida entre médico e paciente, uma vez que não há evidência de superioridade entre as abordagens<sup>1</sup> .  
Exames de imagem, como ultrassom transvaginal com preparo intestinal ou ressonância magnética, também podem ser utilizados para confirmação diagnóstica, ou planejamento cirúrgico. Entretanto, não são capazes de excluir o diagnóstico, já que cerca de 70% dos casos apresentam endometriose peritoneal ou superficial, lesões nem sempre visualizadas nos exames de imagem.<sup>14,24,25</sup> .  
Diante da alta correlação entre achados laparoscópicos e histológicos (97% a 99%)<sup>26</sup> , a comprovação histológica mediante biópsia onera de maneira desnecessária a investigação, ao passo que a biópsia negativa não exclui o diagnóstico da doença e, por isso, não é recomendada. Pacientes com peritônio visualmente normal podem ter o diagnóstico descartado.  
As evidências demonstram que o uso de marcadores séricos, como o CA-125 deve ser abandonado<sup>14</sup> .  
**A Figura 1** apresenta o fluxograma para investigação diagnóstica da endometriose.  
4  
**Figura 1** . Fluxo para investigação diagnóstica da endometriose.  
<!-- Start of picture text -->
Pessoas com suspeita clinica de endometriose’<br>Iniciar tratamento empirico e/ou investigacao<br>por exames de imagem<br>(ultrassonografia ou ressonancia magnética)?<br>Avaliar resultado do Avaliar resultado dos<br>tratamento empirico exames de imagem<br>Tratamento [ered Resultado Resultado<br>Encaminhar para acompanhamento na<br>atencao especializada<br>Realizar laparoscopia, conforme<br>avaliacao da equipe*<br>(ESTED Resultado positivo (i.e.,<br>visualizac&o dos implantes)<br>‘Seguir com investigacao Manter tratamento da<br>para outras causas endometriose<br>" Dismenorreia, dispareunia profunda, distiria, disquezia, sangramento retal doloroso ou hematuria<br>ldor na ponta dos ombros, pneumotorax, catamenial, tosse/hemoptise/dor no peito ciclicos, inchaco|<br>le dor ciclica da cicatriz, fadiga e infertilidade.<br>|? A critério do médico e da pessoa com suspeita clinica de endometriose.<br>* O especialista devera avaliar a necessidade de realizacdo de laparoscopia.<br><!-- End of picture text -->  
Fonte: elaboração própria

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo indivíduos com diagnóstico confirmado de endometriose. Ainda, para tratamento empírico com COC, progestágenos (desogestrel, acetato de medroxiprogesterona ou dispositivo intrauterino liberador de levonorgestrel), poderão ser incluídas pacientes que apresentarem os seguintes critérios:  
- Dispareunia ou dismenorreia progressivas por mais de 6 meses em idade reprodutiva (entre menarca e menopausa), sem causa orgânica aparente e sem resposta ao uso de analgesia usual (anti-inflamatórios não esteroides, AINES); OU  
- Dor pélvica crônica como manifestação clínica a ser tratada, com exame de imagem ou exame físico compatíveis com  
- endometriose, ou excluindo-se outras doenças que possam acarretar dor pélvica crônica.  
5  
Adicionalmente, para tratamento com dispositivo intrauterino liberador de levonorgestrel (DIU-LNG), a paciente deve apresentar contraindicação ou não adesão ao contraceptivo oral combinado - COC (etinilestradiol + levonorgestrel) a;  
Para tratamento com danazol ou análogos do hormônio liberador de gonadotrofina (GnRH), a paciente deve apresentar diagnóstico confirmado de endometriose por achados laparoscópicos e histológicos, e um dos seguintes critérios:  
- Tratamento prévio por 6 meses com COC (etinilestradiol + levonorgestrel) ou contraceptivos de progestágenos  
- (desogestrel ou acetato de medroxiprogesterona), sem resposta ao tratamento; OU  
- Recidiva de dor relacionada à endometriose após o tratamento com COC (etinilestradiol + levonorgestrel) ou  
- contraceptivos de progestágenos (desogestrel ou acetato de medroxiprogesterona).  
Nota: A população-alvo deste Protocolo são pessoas do sexo feminino, com foco na menstruação. Contudo, existem indivíduos transgêneres vivendo com endometriose, que não menstruam, não possuem útero ou não se identificam com os termos utilizados na literatura. Assim, ressalta-se que não se pretende isolar, excluir ou diminuir a experiência de qualquer indivíduo nem discriminar grupos de pacientes.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentarem intolerância, hipersensibilidade ou contraindicações às condutas preconizadas neste Protocolo estarão excluídas da respectiva conduta.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6. TRATAMENTO** -->
O objetivo principal do tratamento da endometriose é a remissão dos sintomas dolorosos (dor pélvica crônica, dismenorreia e dispareunia) com consequente melhora da qualidade de vida e, quando desejado, a preservação ou restauração da fertilidade. O tratamento pode ser medicamentoso (hormonal ou não hormonal), cirúrgico ou a combinação de ambos.  
A escolha do tratamento deve considerar a gravidade dos sintomas, a extensão e localização da doença, o desejo de gravidez, a idade da paciente, os eventos adversos aos medicamentos, as taxas de complicações cirúrgicas e os custos<sup>27</sup> .  
A anemia por deficiência de ferro pode estar relacionada à endometriose por meio da perda excessiva de sangue menstrual (menorragia) ou da inflamação sistêmica crônica<sup>28</sup> . Nestes casos, o tratamento da deficiência de ferro deverá seguir as orientações do **<u>Protocolo Clínico e Diretrizes Terapêuticas da Anemia por Deficiência de Ferro</u>** vigente, do Ministério da Saúde.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado das pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração  
a A ultrassonografia transvaginal não é obrigatória antes da inserção do DIU-LNG, mas pode ser indicada quando houver suspeita de alterações anatômicas, como malformações uterinas, miomas submucosos, sinéquias ou dúvidas sobre o tamanho e a posição uterina, a fim de garantir a segurança do procedimento. Ressalta-se que esse tipo de ultrassonografia não é utilizado para confirmar o diagnóstico de endometriose.  
6  
do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos estabelecimentos de saúde e polos do Programa Academia da Saúde na APS, além de fortalecer algumas atividades, como as Práticas Integrativas e Complementares em Saúde (PICS).  
As PICS, sempre que disponíveis nos serviços de saúde, devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos, complementando o tratamento da equipe multiprofissional. A Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC) orienta que estados, distrito federal e municípios instituam suas próprias normativas trazendo para o SUS práticas que atendam as necessidades regionais<sup>1</sup> . As PICS podem ser consideradas de forma complementar ao tratamento, devido aos possíveis benefícios aos pacientes com endometriose. Contudo, ressalta-se que as PICS não substituem os demais tratamentos preconizados pelo Protocolo e que o tratamento medicamentoso não pode ser interrompido sem orientação médica.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.1      Tratamento não medicamentoso** -->
Diversas estratégias não medicamentosas têm sido propostas para o tratamento da dor e da qualidade de vida em mulheres com endometriose, incluindo acupuntura, fisioterapia, eletroterapia, exercícios físicos, intervenções nutricionais, medicina tradicional chinesa e abordagens psicológicas. No entanto, as evidências disponíveis são limitadas, com resultados inconclusivos e grande heterogeneidade metodológica. Há necessidade de estudos adicionais com rigor metodológico para avaliar o papel dessas intervenções no tratamento da endometriose. Dessa forma, não é possível recomendar nenhuma dessas intervenções de forma específica para alívio da dor ou melhora da qualidade de vida em mulheres com endometriose<sup>1,2</sup> .  
Ainda assim, recomenda-se que os profissionais de saúde discutam com as pacientes o uso complementar de estratégias não medicamentosas, considerando as preferências individuais e os potenciais impactos psicossociais da doença. O incentivo a um estilo de vida saudável, incluindo a prática de atividade física, pode ser considerado como medida geral de promoção da saúde, embora sua eficácia específica para endometriose ainda careça de comprovação.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2      Tratamento medicamentoso** -->
O tratamento medicamentoso da endometriose pode ser hormonal ou não hormonal. Para o tratamento não hormonal, estão disponíveis anti-inflamatórios não esteroides (AINES) e outros analgésicos, e seu uso deverá seguir as orientações do

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **<u>Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica</u>** vigente do Ministério da Saúde. -->
O tratamento hormonal tem como objetivo produzir uma anovulação crônica, criando um ambiente inadequado para o crescimento e manutenção dos implantes da endometriose8, com exceção do dispositivo intrauterino liberador de levonorgestrel. Os tratamentos hormonais reduzem a dor atribuída à endometriose, quando comparados ao placebo, e as evidências parecem sugerir que estes são igualmente efetivos quando comparados entre si<sup>29</sup> .  
Os tratamentos hormonais disponíveis no SUS são os COC (etinilestradiol 0,03 mg + levonorgestrel 0,15 mg), progestágenos (acetato de medroxiprogesterona, desogestrel e dispositivo intrauterino liberador de levonorgestrel), danazol e análogos do GnRH (gosserrelina, leuprorrelina, triptorrelina).  
Os COC e os progestágenos são considerados como primeira linha para mulheres com endometriose, com sintomas e exame físico sugestivos, nas quais foram descartadas outras doenças relacionadas à dor pélvica.  
Já os análogos do GnRH são considerados medicamentos de segunda linha no tratamento de pessoas com dor relacionada à endometriose nas quais não foi obtida remissão dos sintomas após o tratamento de primeira linha.  
7  
Ressalta-se que a escolha do tratamento medicamentoso deve considerar o desejo de gravidez, uma vez que determinadas  
terapias podem estar contraindicadas em casos de intenção de gestação.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **_Contraceptivo oral combinado (COC) - etinilestradiol 0,03 mg + levonorgestrel 0,15 mg_** -->
Os COC consistem numa associação de estrogênio e progestágeno que suprimem as gonadotrofinas (hormônio luteinizante, LH, e do hormônio folículo-estimulante, FSH), inibindo a ovulação. O uso de COC visa a remissão ou controle dos sintomas e, embora haja evidência conflitante sobre o tema, alguns estudos apontam que seu uso estabiliza a progressão da doença. Por isso, deve ser considerado em pacientes que necessitam de medidas contraceptivas, por apresentar um perfil de poucos eventos adversos e serem adequados para uso durante um longo prazo<sup>30</sup> .  
O etinilestradiol 0,03 mg + levonorgestrel 0,15 mg é o COC disponível no SUS.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **_Contraceptivos de progestágeno isolado - acetato de medroxiprogesterona e desogestrel_** -->
Os progestágenos (também conhecidos como progestagênios ou progestinas) são formas sintéticas do hormônio progesterona que atuam inibindo a secreção dos hormônios produzidos pela hipófise. As pílulas de progestágeno atuam impedindo a ovulação e reduzindo a espessura do endométrio. Evidências disponíveis até o momento sugerem que os progestágenos apresentam eficácias semelhantes entre si no alívio da dor, são superiores ao placebo e semelhantes aos COC e aos análogos de GnRH no controle de sintomas<sup>31</sup> .  
Mulheres com contraindicação aos COC podem se beneficiar do uso de progestágenos, uma vez que as evidências sugerem que a ausência de estrogênio na sua formulação parece conferir menor risco de eventos cardiovasculares. Ao contrário dos COC, os contraceptivos de progestágenos podem ser indicados para uso em lactantes, pessoas com obesidade, tabagistas, hipertensos, com histórico ou fatores de risco para doença cardiovascular e histórico ou fatores de risco para trombose venosa profunda ou embolia pulmonar<sup>31</sup> . Todavia, o médico deve permanecer alerta às manifestações iniciais de qualquer doença grave e interromper o tratamento quando apropriado, uma vez que a relação entre contraceptivos de progestágenos isolados e seus riscos não está completamente definida<sup>32</sup> .  
Assim como os COC, os progestágenos não são indicados antes da menarca. O uso de progestágenos reduz os níveis de estrógeno sérico em mulheres na pré-menopausa e está associado à alteração transitória da densidade mineral óssea. A relação risco-benefício do seu uso por mulheres com fatores de risco para osteoporose deve ser avaliada<sup>33</sup> . A avaliação e acompanhamento da densidade mineral óssea e do risco de osteoporose deverá seguir as orientações do **<u>Protocolo Clínico e Diretrizes Terapêuticas de Osteoporose</u>** <u>vigente do Ministério da Saúde.</u>  
O acetato de medroxiprogesterona, administrado por vias intramuscular e oral, e o desogestrel oral são os progestágenos disponíveis no SUS.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **_Dispositivo intrauterino de levonorgestrel (DIU-LNG)_** -->
O levonorgestrel é um progestágeno com atividade antiestrogênica, utilizado principalmente para contracepção. O DIULNG permite que baixas doses diárias do progestágeno sejam liberadas diretamente no órgão-alvo, e por isso, o DIU-LNG apresenta efeitos principalmente locais, mantendo seu efeito contraceptivo e a sua efetividade a longo prazo. No Brasil, estão disponíveis dispositivos que podem ser implantados por 3 ou 5 anos e deve-se orientar a paciente sobre qual é o tempo máximo de uso do dispositivo implantado.  
8

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2.2   Segunda linha de tratamento hormonal** -->
**_Análogos do GnRH – gosserrelina, leuprorrelina e triptorrelina_**  
Os análogos do hormônio liberador de gonadotrofinas (GnRH, do inglês _Gonadotropin-Releasing Hormone_ ) estimulam a produção das gonadotrofinas, LH e FSH, ao ocupar os receptores do GnRH endógeno na hipófise. Como consequência, há a supressão da função ovariana, reduzindo os níveis de estrogênio e progesterona, e gerando hipogonadismo hipogonadotrófico, amenorreia e anovulação reversível. Estes fatores resultam na diminuição do tecido endometrial e redução dos sintomas da endometriose<sup>34</sup> .  
Os análogos do GnRH apresentam eficácia e efetividade similares e têm indicação de uso na endometriose com sintomas em pessoas que não obtiveram melhora da dor com progestágenos e COC. Essa classe de medicamentos mimetiza os sintomas da menopausa ao interromper temporariamente a produção de hormônios ovarianos. Por isso, seu uso por longos períodos pode levar à diminuição na densidade mineral óssea. Além disso, os análogos de GnRH são contraindicados para mulheres que estejam amamentando.  
Estão disponíveis no SUS a leuprorrelina, gosserrelina e a triptorrelina nas apresentações de injeção subcutânea (SC) mensal e trimestral.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **_Terapia de Adição Hormonal_** -->
O uso de análogos do GnRH associado ao tratamento hormonal (progestágenos, estrógenos ou ambos) é denominado de Terapia de Adição Hormonal (add-back therapy) e tem por objetivo minimizar os eventos adversos dos análogos do GnRH.  
Ensaios clínicos testaram várias combinações e a maioria identificou redução dos sintomas de hipoestrogenismo (fogachos, sintomas vasomotores, secura vaginal, alteração de libido), menor perda de massa óssea, melhor tolerabilidade e melhor qualidade de vida com o uso dessa terapia em relação ao uso isolado de análogos do GnRH<sup>35</sup> .  
A Terapia de Adição Hormonal também é recomendada para pacientes em uso dos análogos do GnRH, independentemente dos seus eventos adversos, por prevenir a perda de massa óssea ocasionada pelo estado hormonal que mimetiza a pós-menopausa<sup>35</sup> .

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **_Danazol_** -->
O danazol apresenta eficácia na remissão dos sintomas de maneira semelhante aos COC, aos progestágenos e aos agonistas do GnRH. Entretanto, seu uso pode ocasionar eventos adversos masculinizantes, por vezes irreversíveis, como crescimento de pelos, engrossamento de voz, alopecia e aumento de gordura abdominal. Assim, esse medicamento tem sido cada vez menos utilizado na prática clínica, sendo reservado em situação de falha aos demais tratamentos medicamentosos<sup>36</sup> .

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2.3   Medicamentos** -->
- acetato de medroxiprogesterona: comprimidos de 10 mg; suspensão injetável de 50 mg/mL e 150 mg/mL;  
- danazol: cápsulas de 100 e 200 mg;  
- desogestrel: comprimido de 0,075 mg;  
- etinilestradiol + levonorgestrel: comprimidos de 0,03 mg + 0,15 mg;  
- gosserrelina: implante subcutâneo de 3,6 mg ou 10,8 mg;  
- leuprorrelina: pó para suspensão injetável de 3,75 mg ou 11,25 mg;  
- levonorgestrel:  dispositivo intrauterino liberador contendo 52 mg de levonorgestrel;  
- triptorrelina: pó para solução injetável de liberação prolongada de 3,75 mg ou 11,25 mg.  
Nota: O uso de analgésicos deverá seguir as orientações do Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica vigente, do Ministério da Saúde. Se necessária, a reposição de ferro deverá seguir as orientações do Protocolo Clínico e Diretrizes Terapêuticas da Anemia por Deficiência de Ferro vigente, do Ministério da Saúde.  
9

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2.4   Esquemas de administração** -->
Os esquemas de administração para tratamento da endometriose então descritos no Quadro 1.  
**Quadro 1** . Esquemas de administração dos tratamentos de crianças, adolescentes e adultos.  
|**Medicamentos**|**Esquemas**|
|---|---|
|**Tratamento de primeira linha**||
||Um comprimido por via oral uma vez ao dia no mesmo horário por 21 dias. Nos casos<br>em que a paciente não tenha utilizado contraceptivo hormonal no mês anterior, a|
|Etinilestradiol<br>0,03<br>mg<br>+<br>levonorgestrel 0,15 mg|administração deve ser iniciada no 1º dia do ciclo (1º dia de sangramento menstrual).<br>Para os casos em que a paciente já esteja em uso do medicamento, deve haver um<br>intervalo de 7 dias sem a ingestão dos comprimidos, antes de iniciar a próxima cartela,<br>ou seja, no 8º dia após o término da cartela anterior.|
|Acetato de medroxiprogesterona,<br>(comprimido)|Um comprimido (10 mg) por via oral três vezes ao dia. O uso é contínuo sem intervalos.|
|Acetato de medroxiprogesterona,<br>(suspensão injetável)|<br>Por via intramuscular, utilizar 150 mg, iniciando a primeira injeção até o 5º dia do ciclo<br>menstrual e as injeções subsequentes com intervalo de 12 a 13 semanas (intervalo<br>máximo entre as aplicações é de 91 dias). O uso é contínuo sem intervalos.|
|Desogestrel|Um comprimido por via oral uma vez ao dia, preferencialmente no mesmo horário, na<br>ordem indicada pelas setas impressas na cartela. Deve-se tomar um comprimido ao dia<br>durante 28 dias consecutivos. Cada cartela subsequente deve ser iniciada imediatamente<br>após o término da anterior, sem intervalos.|
|DIU-LNG|Inserir uma unidade do dispositivo contendo 52 mg de levonorgestrel na cavidade<br>uterina. Cada inserção possui eficácia por três ou  cinco anos, conforme dispositivo.|
|**Tratamento de segunda linha**||
|Gosserrelina|3,6 mg por via subcutânea, mensalmente; ou 10,8 mg por via subcutânea a cada 3 meses.|
|Leuprorrelina|3,75 mg por via intramuscular, mensalmente; ou 11,25 mg intramuscular a cada 3 meses.|
|Triptorrelina|3,75 mg por via intramuscular, mensalmente ou 11,25 mg intramuscular a cada 3 meses.|
|Danazol|400 mg, por via oral, divididos em duas administrações diárias, podendo-se aumentar<br>para 800 mg, por via oral, divididos em duas administrações diárias.|  
**Legenda** : DIU-LNG, dispositivo intrauterino liberador de levonorgestrel.  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2.5   Critérios de interrupção** -->
Considerando os potenciais eventos adversos relacionados aos análogos de GnRH (sintomas vasomotores e perda óssea acelerada), recomenda-se que o tempo de tratamento com estes medicamentos seja limitado a seis meses. Pacientes que já fizeram uso de análogos do GnRH por 6 meses, e que permanecerem sintomáticas ou com recidiva de dor relacionada à endometriose, devem ser encaminhadas aos serviços especializados para a avaliação de retratamento. A escolha de prolongar o tratamento deve considerar os riscos e benefícios para a paciente, e a utilização de tratamentos complementares, como o uso da Terapia de Adição Hormonal<sup>37</sup> . O laudo médico deverá descrever a sintomatologia, atestando a ausência de resposta terapêutica.  
10

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.2.6   Contraindicações** -->
Os medicamentos incluídos neste PCDT são contraindicados a pessoas com hipersensibilidade aos princípios ativos ou quaisquer componentes das fórmulas. Demais contraindicações estão apresentadas no **Quadro 2** e foram obtidas das respectivas bulas dos medicamentos.  
**Quadro 2.** Contraindicações dos medicamentos para tratamento da endometriose.  
|**Medicamentos**|**Contraindicações**|
|---|---|
||-<br>Mulheres que estejam amamentando;<br>-<br>Trombose venosa profunda (história anterior ou atual);<br>-<br>Tromboembolismo (história anterior ou atual);<br>-<br>Doença vascular cerebral ou arterial coronariana;<br>-<br>Valvulopatias trombogênicas;<br>-<br>Distúrbios do ritmo cardíaco trombogênico;<br>-<br>Trombofilias hereditárias ou adquiridas;<br>-<br>Cefaleia com sintomas neurológicos focais tais como aura;<br>-<br>Diabetes com envolvimento vascular;<br>-<br>Hipertensão não controlada;<br>-<br>Carcinoma da mama conhecido ou suspeito ou outra neoplasia estrogênio-dependente<br>conhecida ou suspeita;<br>-<br>Adenomas ou carcinomas hepáticos, ou doença hepática ativa, onde a função hepática não<br>tenha retornado ao normal;|
|COCs (etinilestradiol<br>+ levonorgestrel)<sup>30</sup>|-<br>Sangramento vaginal de etiologia a esclarecer;<br>-<br>Pancreatite associada à hipertrigliceridemia severa (história anterior ou atual);<br>-<br>Uso concomitante com certos medicamentos antivirais contra o vírus da hepatite C (HCV),<br>como ombitasvir, paritaprevir, ritonavir e dasabuvir.<br>Os COC não são indicados antes da menarca ou em mulheres lactantes durante todo o período de<br>amamentação. Seu uso não deve começar antes do 28º dia após o parto em mulheres não lactantes<br>ou após aborto no segundo trimestre. Além disso, pacientes com as seguintes condições<br>predisponentes para tromboembolismo devem evitar o uso de COC<sup>30</sup>:<br>-<br>Pacientes tabagistas com mais de 35 anos de idade;<br>-<br>Obesidade;<br>-<br>Cirurgia ou trauma com risco aumentado de trombose;<br>-<br>Parto recente ou aborto no segundo trimestre;<br>-<br>Imobilização prolongada; e<br>-<br>Idade avançada.|
|Acetato<br>de<br>medroxiprogesterona|-<br>Mulheres grávidas ou com suspeita de gravidez;<br>-<br>Sangramento vaginal anormal não diagnosticado;<br>-<br>Suspeita de neoplasia mamária ou neoplasia mamária comprovada;|  
11  
|**Medicamentos**|**Contraindicações**|
|---|---|
||-<br>Disfunção hepática grave;<br>-<br>Tromboflebite ativa ou história atual ou pregressa de distúrbios tromboembólicos ou<br>cerebrovasculares;<br>-<br>História de aborto retido.|
|Desogestrel|-<br>Distúrbio tromboembólico venoso ativo.<br>-<br>Presença ou história de doença hepática grave, enquanto os valores dos testes de função<br>hepática não retornarem ao normal.<br>-<br>Doença maligna sensível a esteroides sexuais conhecida ou suspeita.<br>-<br>Sangramento vaginal anormal não diagnosticado.|
||-<br>Suspeita ou diagnóstico de gravidez;<br>-<br>Doença inflamatória pélvica atual ou recorrente;<br>-<br>Infecção do trato genital inferior;<br>-<br>Endometrite pós-parto;<br>-<br>Aborto infectado durante os últimos três meses;<br>-<br>Cervicite;|
|DIU-LNG|-<br>Displasia cervical;<br>-<br>Tumor maligno uterino ou cervical;<br>-<br>Tumores progestógeno-dependentes;<br>-<br>Sangramento uterino anormal não-diagnosticado;<br>-<br>Anomalia uterina congênita ou adquirida, incluindo leiomiomas, quando estes causarem<br>deformação da cavidade uterina;<br>-<br>Condições associadas ao aumento de susceptibilidade a infecções;<br>-<br>Doença hepática aguda ou tumor hepático;|
|Análogos de GnRH|-<br>Mulheres grávidas ou que possam ficar grávidas durante o tratamento, ou que estejam<br>amamentando;<br>-<br>Sangramento vaginal de causa desconhecida|
|Danazol|-<br>Mulheres grávidas ou que possam ficar grávidas durante o tratamento;<br>-<br>Mulheres que estejam amamentando (aleitamento ou doação de leite);<br>-<br>Insuficiência hepática, renal ou cardíaca graves;<br>-<br>Porfiria;<br>-<br>Tumor androgênio-dependente;<br>-<br>Sangramento vaginal anormal não diagnosticado;<br>-<br>Trombose ativa ou doença tromboembólica, ou histórico de ambos os eventos;<br>-<br>Uso concomitante com sinvastatina.|  
**Legenda** : DIU-LNG, dispositivo intrauterino liberador de levonorgestrel.  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.3      Tratamento cirúrgico** -->
O tratamento cirúrgico é indicado quando os sintomas são graves, incapacitantes e em casos de<sup>5,38</sup> :  
- Ausência de resposta com tratamento empírico com COC ou progestágenos;  
12  
- Endometriomas em crescimento ou maiores que 4 cm;  
- Distorção da anatomia das estruturas pélvicas:  
- Presença de sinais de suboclusão intestinal ou obstrução do trato intestinal, principalmente quando localizada em  
- intestino delgado;  
- Lesões ureterais com dilatação;  
- Infertilidade associada a endometriose.  
A cirurgia para tratamento da endometriose pode ser classificada como conservadora ou definitiva.  
Na cirurgia conservadora, todas as lesões focos de endometriose são removidas, com restauração da anatomia pélvica. Ocorre significativa redução da dor em 6 meses nas pacientes submetidas à laparoscopia terapêutica, em comparação àquelas que são apenas acompanhadas em relação aos sintomas, sem intervenção tanto para endometriose mínima, leve ou moderada<sup>39</sup> .  
A laparoscopia é importante ferramenta terapêutica e, quando indicada, deve promover a excisão de todos os focos de endometriose bem como o restabelecimento da arquitetura pélvica<sup>40</sup> .  
Já a cirurgia definitiva envolve histerectomia com ou sem ooforectomia (de acordo com a idade da paciente e desejo da paciente). A histerectomia com salpingooforectomia bilateral com excisão de todos os focos de endometriose mostrou taxas de cura de 90% (estudos não controlados. A cirurgia definitiva é indicada em casos de doença grave, persistência de sintomas incapacitantes após terapia medicamentosa ou cirurgia conservadora, presença de outras doenças pélvicas com indicação de histerectomia e quando não há mais o desejo de gestação<sup>1,5</sup> .  
Para o grupo de mulheres com infertilidade, não se justifica o tratamento hormonal com supressão da ovulação. Nesses casos, quando a infertilidade é secundária à endometriose em estágios I e II, o tratamento cirúrgico, com exérese dos focos, mostrou-se eficaz<sup>41</sup> . Entretanto, deve-se considerar outros parâmetros relacionados à fertilidade como idade materna, permeabilidade tubária, presença ou não de dor pélvica associada e qualidade do sêmen do parceiro. Em casos de doença avançada, nos estádios III e IV, a cirurgia deve ser considerada como opção<sup>42</sup> . Após a exérese dos focos, o tratamento da infertilidade poderá continuar, sem utilizar o uso de hormônios com supressão de ovulação.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **6.4      Tratamento medicamentoso-cirúrgico** -->
O tratamento medicamentoso pode ser associado ao cirúrgico, antes ou após o procedimento.  
A supressão hormonal com uso do análogo de GnRH prévia à cirurgia pode diminuir o tamanho dos implantes de endometriose. No entanto, inexistem evidências que essa estratégia diminua a extensão da dissecção cirúrgica, prolongue o tempo sem dor, aumente as taxas de fertilidade ou reduza as taxas de recorrência<sup>40</sup> .  
Por outro lado, evidências sugerem que o uso de COC após a cirurgia conservadora reduz a taxa de recorrência e aumenta a taxa de remissão em relação à cirurgia isolada, além de apresentar menos eventos adversos em relação aos outros tratamentos hormonais<sup>1,43</sup> . De forma semelhante, estudos sugerem que o tratamento hormonal pós-operatório com análogos do GnRH, progestágenos, COC ou DIU-LNG diminui a chance de recidiva, quando comparado a placebo ou tratamento expectante no pósoperatório<sup>1,44</sup> . O uso pós-operatório de análogo de GnRH por seis meses também esteve associado à menor chance de recidiva enquanto o tratamento por 3 meses não resultou em diferença significativa na prevenção da recorrência da endometriose<sup>45</sup> .  
Frente a estas evidências, recomenda-se o tratamento hormonal para bloqueio do eixo hipotálamo-hipófise-ovário por seis meses com agonistas do GnRH. Após este período, recomenda-se que o bloqueio seja mantido com COC ou progestágenos por período indefinido até que haja desejo de gestação.  
13

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **7. MONITORAMENTO** -->
Recomenda-se o acompanhamento regular das pacientes quanto à evolução dos sintomas e à qualidade de vida, podendo ser utilizado, quando disponível, o questionário _Endometriosis Health Profile-30_ (EHP-30), validado para o português para a população brasileira<sup>46</sup> . Ressalta-se que essa avaliação tem caráter complementar e visa a auxiliar a conduta médica, de modo que a paciente deve ter acesso ao tratamento adequado, mesmo que esse instrumento não seja aplicado.  
Para o início do tratamento com qualquer um dos medicamentos preconizados por este PCDT, deverão ser apresentados a anamnese, incluindo avaliação do histórico clínico e familiar e exame físico.  
Pacientes em uso de danazol devem ser monitorados pela contagem de plaquetas e testes de função renal e hepática a cada 4 a 6 meses. Na presença de alterações importantes, o medicamento deve ser suspenso. Recomenda-se avaliar o risco de interações medicamentosas com uso de anticonvulsivantes, anticoagulantes, imunossupressores, hipolipemiantes e outros.  
Pacientes em uso dos análogos do GnRH, acetato de medroxiprogesterona e desogestrel por período maior que 12 meses devem ser avaliadas quanto ao risco de alteração da densidade mineral óssea. Caso necessário, devem ser acompanhadas de acordo com o **<u>Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose</u>** vigente.  
**O Quadro 3** descreve as avaliações que devem ser realizadas durante o monitoramento.  
**Quadro 3** . Avaliações recomendadas durante o monitoramento.  
|**Avaliação**|**Medicamento**|**Avaliação antes do**<br>**início do tratamento**|**Monitorização**<br>**e**<br>**periodicidade**|
|---|---|---|---|
|Anamnese|Todos|Sim|Não|
|Laparoscopia com biopsia e<br>laudo histopatológico|Danazol e análogos de GnRH|Sim|Não|
|Ultrassonografia<br>transvaginal|DIU-LNG|Não<sup>a</sup>|Não|
|Plaquetometria, dosagem<br>sérica de TGO/AST,|Danazol|Sim|Sim, a cada 04 meses|
|TGP/ALT e creatinina||||
||Análogos do GnRH, acetato||Apenas se necessário, conforme|
|Densitometria óssea|de medroxiprogesterona e<br>desogestrel|Não|avaliação clínica, após 12 meses<br>de tratamento|  
**Fonte:** Elaboração própria.  
**Notas:** a. A ultrassonografia transvaginal **não é obrigatória para todos os pacientes** antes da inserção do DIU-LNG, mas **pode** ser indicada pelo médico prescritor nos casos de suspeita de alterações anatômicas, como malformações uterinas, miomas submucosos, sinéquias ou dúvidas sobre o tamanho e a posição uterina.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pessoas com endometriose devem ser atendidas e acompanhadas na atenção primária e,  
14  
em casos específicos, devem ser encaminhadas aos serviços especializados em ginecologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com endometriose devem ser avaliadas periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Como parte da rede de Atenção Primária à Saúde, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar a paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **10. REFERÊNCIAS** -->
1. ESHRE Endometriosis Guideline Development Group. Endometriosis. Guideline of European Society of Human Reproduction and Embryology – 2022. _Reproductive Endocrinology_ . 2022;8–19.  
2. As-Sanie S, Mackenzie SC, Morrison L, Schrepf A, Zondervan KT, Horne AW, et al. Endometriosis: A Review. _JAMA_ [Internet]. 2025 [citado 4 de junho de 2025]; Disponível em: https://jamanetwork.com/journals/jama/fullarticle/2833561  
3. Cano-Herrera G, Salmun Nehmad S, Ruiz de Chávez Gascón J, Méndez Vionet A, van Tienhoven XA, Osorio Martínez MF, et al. Endometriosis: A Comprehensive Analysis of the Pathophysiology, Treatment, and Nutritional Aspects, and Its Repercussions on the Quality of Life of Patients. _Biomedicines 2024, Vol 12, Page_  
15  
_1476_ [Internet]. 2024 [citado 4 de junho de 2025];12:1476. Disponível em: https://www.mdpi.com/22279059/12/7/1476/htm  
4. Lamceva J, Uljanovs R, Strumfa I. The Main Theories on the Pathogenesis of Endometriosis. _Int J Mol Sci_ [Internet]. 2023 [citado 4 de junho de 2025];24:4254. Disponível em: https://www.mdpi.com/14220067/24/5/4254  
5. Schenken R. Endometriosis: Pathogenesis, epidemiology, and clinical impact - UpToDate [Internet]. [citado 15 de setembro de 2023]. Disponível em: https://www.uptodate.com/contents/endometriosis-pathogenesisepidemiology-and-clinical-impact  
6. Santulli P, Bourdon M, Desportes C, Maignien C, Pocate-Cheriet K, Patrat C, et al. Assessment of the Pelvic Pain Experienced by Infertile Women is of Prime Importance for Diagnosing Endometriosis. _J Minim Invasive Gynecol_ [Internet]. 2024 [citado 4 de junho de 2025];31:943-950.e1. Disponível em:  
https://linkinghub.elsevier.com/retrieve/pii/S1553465024003157  
7. Skorupskaite K, Bhandari HM. Endometriosis and fertility. _Obstet Gynaecol Reprod Med_ [Internet]. 2024 [citado 4 de junho de 2025];34:319–25. Disponível em: https://linkinghub.elsevier.com/retrieve/pii/S1751721424001386  
8. Smolarz B, Szyłło K, Romanowicz H. Endometriosis: Epidemiology, classification, pathogenesis, treatment and genetics (review of literature). _Int J Mol Sci_ . 2021;22.  
9. Nezhat C, Lindheim SR, Backhus L, Vu M, Vang N, Nezhat A, et al. Thoracic Endometriosis Syndrome: A Review of Diagnosis and Management. _JSLS_ [Internet]. 2019 [citado 4 de junho de 2025];23:e2019.00029. Disponível em: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6684338/  
10. Elefante C, Brancati GE, Oragvelidze E, Lattanzi L, Maremmani I, Perugi G. Psychiatric Symptoms in Patients with Cerebral Endometriosis: A Case Report and Literature Review. _J Clin Med_ [Internet]. 2022 [citado 4 de junho de 2025];11:7212. Disponível em: https://pmc.ncbi.nlm.nih.gov/articles/PMC9738496/  
11. Culley L, Law C, Hudson N, Denny E, Mitchell H, Baumgarten M, et al. The social and psychological impact of endometriosis on women’s lives: a critical narrative review. _Hum Reprod Update_ . 2013;19:625–39.  
12. Agarwal SK, Chapron C, Giudice LC, Laufer MR, Leyland N, Missmer SA, et al. Clinical diagnosis of endometriosis: a call to action. _Am J Obstet Gynecol_ . 2019;220:354.e1-354.e12.  
13. Dunselman GAJ, Vermeulen N, Becker C, Calhaz-Jorge C, D’Hooghe T, De Bie B, et al. ESHRE guideline: management of women with endometriosis. _Human Reproduction_ . 2014;29:400–12.  
14. Becker CM, Bokor A, Heikinheimo O, Horne A, Jansen F, Kiesel L, et al. ESHRE guideline: endometriosis. _Hum Reprod Open_ . 2022;2022.  
15. Lee S-Y, Koo Y-J, Lee D-H. Classification of endometriosis. _Yeungnam Univ J Med_ [Internet]. 2021 [citado 4 de junho de 2025];38:10–8. Disponível em: http://e-yujm.org/journal/view.php?doi=10.12701/yujm.2020.00444  
16. Harder C, Velho RV, Brandes I, Sehouli J, Mechsner S. Assessing the true prevalence of endometriosis: A narrative review of literature data. _International Journal of Gynecology & Obstetrics_ . 2024;167:883–900.  
17. Dave D, Page HE, Carrubba AR. Clinical Management of Endometriosis in Menopause: A Narrative Review. _Medicina (B Aires)_ [Internet]. 2024 [citado 4 de junho de 2025];60:1341. Disponível em: https://www.mdpi.com/1648-9144/60/8/1341  
18. Arafah M, Rashid S, Akhtar M. Endometriosis: A Comprehensive Review. _Adv Anat Pathol_ . 2021;28:30–43.  
19. Zhang Y, Ma N-Y. Environmental Risk Factors for Endometriosis: An Umbrella Review of a Meta-Analysis of 354 Observational Studies With Over 5 Million Populations. _Front Med (Lausanne)_ . 2021;8.  
16  
20. Tang Y, Zhao M, Lin L, Gao Y, Chen GQ, Chen S, et al. Is body mass index associated with the incidence of endometriosis and the severity of dysmenorrhoea: a case–control study in China? _BMJ Open_ . 2020;10:e037095.  
21. Szylit NA, Raiza LCP, Leal AAS, Podgaec S. Epidemiology with real-world data: deep endometriosis in women of reproductive age. _einstein (São Paulo)_ . 2025;23.  
22. Cardoso JV, Machado DE, Silva MC da, Berardo PT, Ferrari R, Abrão MS, et al. Epidemiological profile of women with endometriosis: a retrospective descriptive study. _Revista Brasileira de Saúde Materno Infantil_ . 2020;20:1057–67.  
23. Ministério da Saúde/Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas [Internet]. Brasília - DF; 2023. Disponível em:  
https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_metodologicas_elaboracao_metodologicas_1ed.pdf  
24. Byrne D, Curnow T, Smith P, Cutner A, Saridogan E, Clark TJ. Laparoscopic excision of deep rectovaginal endometriosis in BSGE endometriosis centres: a multicentre prospective cohort study. _BMJ Open_ . 2018;8:e018924.  
25. Bafort C, Beebeejaun Y, Tomassetti C, Bosteels J, Duffy JM. Laparoscopic surgery for endometriosis. _Cochrane Database of Systematic Reviews_ . 2020;2020.  
26. Walter AJ, Hentz JG, Magtibay PM, Cornella JL, Magrina JF. Endometriosis: Correlation between histologic and visual findings at laparoscopy. _Am J Obstet Gynecol_ . 2001;184:1407–13.  
27. Schenken RS. Endometriosis: Treatment of pelvic pain - UpToDate [Internet]. 2023 [citado 21 de setembro de 2023]. Disponível em: https://www.uptodate.com/contents/endometriosis-treatment-of-pelvic-pain  
28. Gete DG, Doust J, Mortlock S, Montgomery G, Mishra GD. Risk of Iron Deficiency in Women With Endometriosis: A Population-Based Prospective Cohort Study. _Women’s Health Issues_ . 2024;34:317–24.  
29. Brown J, Farquhar C. Endometriosis: an overview of Cochrane Reviews. _Cochrane Database of Systematic Reviews_ . 2014;2014.  
30. Biolab Sanus Farmacêutica Ltda. Bula do medicamento levonorgestrel + etinilestradiol. 2021.  
31. Vercellini P, Buggio L, Berlanda N, Barbara G, Somigliana E, Bosari S. Estrogen-progestins and progestins for the management of endometriosis. _Fertil Steril_ . 2016;106:1552-1571.e2.  
32. Biolab Sanus Farmacêutica Ltda. Bula do medicamento noretisterona [Internet]. 2021 [citado 27 de outubro de 2023]. Disponível em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=NORETISTERONA  
33. União Química Farmacêutica Nacional S.A. Bula do medicamento DEMEDROX® (acetato de medroxiprogesterona) [Internet]. 2020 [citado 25 de setembro de 2023]. Disponível em: https://www.genom.com.br/wp-content/uploads/2020/02/Demedrox_Bula_Profissional.pdf  
34. Veth VB, van de Kar MM, Duffy JM, van Wely M, Mijatovic V, Maas JW. Gonadotropin-releasing hormone analogues for endometriosis. _Cochrane Database of Systematic Reviews_ . 2023;2023.  
35. Wu D, Hu M, Hong L, Hong S, Ding W, Min J, et al. Clinical efficacy of add-back therapy in treatment of endometriosis: a meta-analysis. _Arch Gynecol Obstet_ . 2014;290:513–23.  
36. Ferrero S, Alessandri F, Racca A, Leone Roberti Maggiore U. Treatment of pain associated with deep endometriosis: alternatives and evidence. _Fertil Steril_ . 2015;104:771–92.  
37. Mark D Hornstein, William E Gibbons. Endometriosis: Long-term treatment with gonadotropin-releasing hormone agonists [Internet]. UpToDate. 2023 [citado 21 de setembro de 2023]. Disponível em:  
17  
https://www.uptodate.com/contents/endometriosis-long-term-treatment-with-gonadotropin-releasing-hormoneagonists  
38. Bafort C, Beebeejaun Y, Tomassetti C, Bosteels J, Duffy JM. Laparoscopic surgery for endometriosis. _Cochrane Database of Systematic Reviews_ . 2020;2020.  
39. Frishman GN, Salak JR. Conservative surgical management of endometriosis in women with pelvic pain. _J Minim Invasive Gynecol_ . 2006;13:546–58.  
40. Dan I Lebovic. Endometriosis: Surgical management of pelvic pain [Internet]. UpToDate. 2023 [citado 21 de setembro de 2023]. Disponível em: https://www.uptodate.com/contents/endometriosis-surgical-management-ofpelvic-pain  
41. Hodgson RM, Lee HL, Wang R, Mol BW, Johnson N. Interventions for endometriosis-related infertility: a systematic review and network meta-analysis. _Fertil Steril_ . 2020;113:374-382.e2.  
42. Spencer S, Lazaridis A, Grammatis A, Hirsch M. The treatment of endometriosis-associated infertility. _Curr Opin Obstet Gynecol_ . 2022;34:300–14.  
43. Wu L, Wu Q, Liu L. Oral contraceptive pills for endometriosis after conservative surgery: a systematic review and meta-analysis. _Gynecological Endocrinology_ . 2013;29:883–90.  
44. Zakhari A, Delpero E, McKeown S, Tomlinson G, Bougie O, Murji A. Endometriosis recurrence following postoperative hormonal suppression: a systematic review and meta-analysis. _Hum Reprod Update_ . 2021;27:96–107.  
45. Zheng Q, Mao H, Xu Y, Zhao J, Wei X, Liu P. Can postoperative GnRH agonist treatment prevent endometriosis recurrence? A meta-analysis. _Arch Gynecol Obstet_ . 2016;294:201–7.  
46. Mengarda CV, Passos EP, Picon P, Costa AF, Picon PD. Validação de versão para o português de questionário sobre qualidade de vida para mulher com endometriose (Endometriosis Health Profile Questionnaire - EHP-30). _Revista Brasileira de Ginecologia e Obstetrícia_ . 2008;30.  
18

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE ETINILESTRADIOL + LEVONORGESTREL, ACETADO DE MEDROXIPROGESTERONA, DESOGESTREL, DISPOSITIVO INTRAUTERINO LIBERADOR DE LEVONORGESTREL, GOSSERRELINA, LEUPRORRELINA, TRIPTORRELINA E DANAZOL** -->
Eu, _______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso do(s) medicamento(s) **etinilestradiol + levonorgestrel, acetado de medroxiprogesterona, desogestrel, dispositivo intrauterino liberador de levonorgestrel, gosserrelina, leuprorrelina, triptorrelina e danazol** , indicados para o tratamento da endometriose.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a) _______________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- diminuição da dor;  
- redução dos nódulos endometrióticos.  
Fui também claramente informada a respeito das seguintes contraindicações, potenciais efeitos colaterais e riscos:  
- medicamentos contraindicados em gestantes ou em mulheres planejando engravidar;  
- medicamentos contraindicados em mulheres que estão amamentando (lactantes);  
- os eventos colaterais já relatados são:  
`o` **etinilestradiol + levonorgestrel:** <u>muito comum – cefaleia (e.g. enxaqueca), náuseas, vômitos, dor abdominal, acne,</u> sangramento de escape/spotting; comum – vaginite, (e.g. candidíase), alterações de humor (e.g. depressão), alterações de libido, nervosismo, tontura, dismenorreia, alteração do fluxo menstrual, alteração da secreção e ectrópio cervical, amenorreia, retenção hídrica/edema, alterações de peso e dor, sensibilidade ou aumento, secreção das mamas.  
▪ O uso de COC, como o **etinilestradiol + levonorgestrel,** tem sido associado a maior risco de eventos tromboembólicos e trombóticos arteriais e venosos, incluindo infarto do miocárdio, acidente vascular cerebral, trombose venosa e embolia pulmonar; maior risco de neoplasia cervical intra-epitelial e câncer cervical; maior risco de câncer de mama.  
`o` **acetado de medroxiprogesterona:** <u>muito comum – nervosismo, dor de cabeça, dor abdominal, desconforto abdominal,</u> aumento de peso, redução de peso; <u>comum</u> – alterações de humor, incluindo depressão, redução da libido, tontura, náusea, distensão abdominal, alopecia, acne (espinhas), rash (erupção cutânea), dor nas costas, corrimento vaginal, sensibilidade das mamas, retenção de fluido, astenia.  
`o` **desogestrel** : comum – dor de cabeça, náusea, acne, alteração de humor, diminuição da libido, menstruação irregular, amenorreia, sensibilidade das mamas.  
▪ **desogestrel e acetato de medroxiprogesterona** são contraceptivos de progestágeno isolados e, portanto, não contém estrógenos. A relação entre os riscos à saúde que têm sido associados ao componente estrogênico dos COC e os contraceptivos de progestágeno isolados não está completamente definida.  
`o` **dispositivo intrauterino liberador de levonorgestrel:** <u>muito comum –dor de cabeça, dor abdominal/pélvica, alterações</u> no sangramento menstrual incluindo gotejamento e amenorreia.  
`o` **gosserrelina** : frequentes – calorões, distúrbios menstruais; menos frequentes – visão borrada, diminuição da libido, cansaço, dor de cabeça, náusea, vômitos, dificuldade para dormir, ganho de peso, vaginite; raros – angina ou infarto do miocárdio, tromboflebites.  
19  
`o` **leuprorrelina** : frequentes – calorões, diarreia, distúrbios menstruais; menos frequentes – arritmias cardíacas, palpitações; raros – boca seca, sede, alterações do apetite, ansiedade, náusea, vômitos, desordens de personalidade, desordens da memória, diminuição da libido, ganho de peso, dificuldades para dormir, delírios, dor no corpo, perda de cabelo e distúrbios oftalmológicos.  
`o` **triptorrelina** : frequentes – calorões, dores nos ossos, impotência, dor no local da injeção, hipertensão, dores de cabeça; menos frequentes – dores nas pernas, fadiga, vômitos, insônia; raros – tonturas, diarreia, retenção urinária, infecção do trato urinário, anemia, prurido.  
`o` **danazol** : frequentes – distúrbios da menstruação, ganho de peso, calorões; menos frequentes – inchaço, escurecimento da urina, cansaço, sonolência, acne, aumento da oleosidade do cabelo e pele, perda de cabelo, alteração da voz, crescimento do clitóris ou atrofia testicular; raros – adenoma, catarata, eosinofilia, disfunção hepática, pancreatite, hipertensão intracraniana manifestada por dor de cabeça, náusea e vômitos, leucocitose, pancreatite, rash cutâneo, síndrome de Stevens-Johnson, trombocitopenia, fotossensibilidade.  
- medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos;  
- o risco de ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que esse(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvêlo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser assistida, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- ( ) Sim ( ) Não  
O meu tratamento constará do seguinte medicamento:  
- ( ) etinilestradiol + levonorgestrel ( ) noretisterona ( ) gosserrelina ( ) leuprorrelina ( ) triptorrelina ( ) danazol  
- ( ) acetado de medroxiprogesterona  
|Local:                                                             Data:|
|---|
|Nome da paciente:|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|  
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|---|---|---|
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||  
|Data:____________________|
|---|  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
20  
**APÊNDICE 1**  
**METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria Conjunta SAES-SAPS-SCTIE/MS n `º` 54/2026, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Endometriose, pela necessidade de se incluir orientações sobre a diferença do tempo de implante do DIU de levonorgestrel de diferentes fabricantes. A orientação de que o dispositivo poderia ser utilizado por até cinco anos foi substituída pelo uso por até 3 ou 5 anos, conforme o dispositivo.  
O tema foi apresentado como informe à 138 `ª` reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 18/08/2026.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **1. Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas da Endometriose, contendo a descrição da metodologia de busca de evidências científicas e as recomendações constantes em seu texto.  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas, além de metodologistas. Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Este Protocolo tem como público-alvo os profissionais da saúde envolvidos na atenção da paciente com endometriose, em especial médicos e enfermeiros que atuam na Atenção Primária e na Atenção Especializada, ambulatorial, no Sistema Único de Saúde (SUS).  
Pessoas do sexo feminino com diagnóstico de endometriose são a população-alvo destas recomendações.  
O escopo do documento foi discutido na reunião de escopo, ocorrida em julho de 2022. A reunião contou com a presença de 17 participantes entre metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS, SAPS, SAES e SVSA, representantes de pacientes, de sociedades médicas e especialistas convidados.  
A dinâmica da reunião foi conduzida com base no PCDT publicado por meio da Portaria Conjunta SAES-SCTIE/MS nº 879 de 12 de julho de 2016, e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foram elaboradas perguntas PICO para as dúvidas clínicas e tecnologias que necessitariam de avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Após levantamento inicial das evidências pelo Grupo Elaborador, elas foram apresentadas em reunião ocorrida em outubro de 2022, com a presença de metodologistas e especialistas do Grupo Elaborador e representantes da SECTICS, SAPS, SAES e SVSA. A partir das evidências encontradas, três perguntas de pesquisa a serem respondidas foram priorizadas e validadas.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
A relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.  
21

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **2. Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo UATS do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos b|enefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim|  
22  
||(   ) Não|
|---|---|
|f) Outro grupo de interesse|(   ) Sim|
||(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim|
||(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim|
||(   ) Não|

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Endometriose foi apresentada na 126ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em junho de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria de Atenção Primária à Saúde (SAPS). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 142ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **4. Buscas na literatura para atualização do PCDT** -->
O processo de atualização desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO **(Figura A)** .  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO/PIRO.  
<!-- Start of picture text -->
f P| «Popa ou cond clic<br>‘intervencio, no caso de estudos experimentais<br>*Fator de exposicio, em caso de estudos observacionais<br>‘Teste indice, nos casos de estudos de acurdcia diagnéstica<br>*Controle, de acordo com tratamento/niveis de exposico do fator/exames<br>disponiveis no SUS<br>‘*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
**Questão 1 – O dispositivo intrauterino liberador de levonorgestrel é eficaz, efetivo e seguro comparado ao acetato de medroxiprogesterona para o tratamento de pacientes com endometriose e contraindicação ou não adesão aos COC?**  
23  
**Recomendação** : Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS do dispositivo intrauterino liberador de levonorgestrel para pacientes com endometriose com contraindicação ou não adesão aos contraceptivos orais combinados, conforme Relatório de Recomendação nº 1002/2025, disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2025/relatorio-de-recomendacao-no-1002-dispositivo-intrauterino-liberador-de-levonorgestrel  
A estrutura PICOS para esta pergunta foi:  
**População:** Mulheres com diagnóstico de endometriose com contraindicação aos contraceptivos orais combinados (COC)  
a  
**Intervenção:** Dispositivo intrauterino liberador de levonorgestrel (DIU-LNG)  
**Comparadores** : Acetato de medroxiprogesterona  
**Desfechos** : Primários - Dor (dismenorreia, dispareunia profunda, dor pélvica não menstrual e disquezia); Densidade  
mineral óssea.  
Secundários: Qualidade de vida; Redução dos implantes de endometriose; sangramento irregular; adesão ao tratamento; eventos adversos gerais  
**Desenhos de estudo** : Revisão sistemática, ensaios clínicos randomizados ou quasi-randomizados, estudos de coorte prospectivos e caso controle (com grupo comparador)<sup>b</sup>  
Notas: a - Independente de procedimento cirúrgico. Se evidência vazia for identificada para a população específica priorizada, também serão consideradas pacientes com endometriose independentemente de contraindicação aos COC.  
**Métodos e resultados da busca:**  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 1002 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Questão 2 - Para mulheres com diagnóstico de endometriose, um progestágeno é eficaz, efetivo, custo-efetivo e viável economicamente comparado a etinilestradiol + levonorgestrel, acetado de medroxiprogesterona?** -->
**Recomendação:** Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de desogestrel e de não incorporação de acetato de noretisterona (10 mg) e dienogeste, conforme Relatório de Recomendação nº 1003/2025, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de-recomensacao-no-1003-progestageno-oral-  
endometriose.  
A estrutura PICOS para esta pergunta foi:  
**População:** Pacientes com diagnóstico de endometriose  
**Intervenção:** Progestágenos orais<sup>a</sup>  
**Comparadores** : Etinilestradiol + levonorgestrel, acetato de medroxiprogesterona<sup>b</sup>  
**Desfechos** : Primários - Dor (dismenorreia, dispareunia profunda, dor pélvica não menstrual e disquezia); Recorrência pós-operatória de endometriose;  
Secundários: Qualidade de vida, redução dos implantes de endometriose; eventos adversos gerais  
**Desenhos de estudo** : Revisão sistemática, ensaios clínicos randomizados ou quasi-randomizados, estudos de coorte prospectivos e caso controle (com grupo comparador)  
Notas:<sup>a</sup> - Considerou-se os progestágenos orais com registro válido na Anvisa: desogestrel 75 µg, dienogeste 2 mg, didrogesterona 10 mg, acetato de noretisterona 10 mg.<sup>b</sup> – Uma vez que foi planejada uma meta-análise em rede, foram considerados esses comparadores como o conjunto de decisão, mas outros comparadores (como placebo ou manejo expectante)  
24  
foram incluídos em conjunto suplementar para melhorar a conectividade da rede, considerando a disponibilidade das evidências frente a estes comparadores.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Métodos e resultados da busca:** -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 1003 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Questão 3 - Para pacientes com endometriose na pós-menopausa, os inibidores de aromatase são eficazes, efetivos e seguros, comparado a ausência de tratamento ou cuidado padrão?** -->
**Recomendação:** Não foi identificada evidência comparativa de inibidores de aromatase para pessoas em pós-menopausa.  
Assim, verificou-se que não havia elementos para uma avaliação pela Conitec.  
A estrutura PICOS para esta pergunta foi:  
**População:** Pacientes com diagnóstico de endometriose na pós-menopausa independentemente de procedimento  
cirúrgico<sup>a</sup>  
**Intervenção:** Inibidor de aromatase; Inbidor de aromatase + gosserrelina; Inibidores de aromatase + cuidado padrão. **Comparadores** : Ausência de tratamento ou cuidado padrão  
**Desfechos** : Primários: Dor (dismenorreia, dispareunia, dor pélvica não menstrual e disquezia).  
Secundário: Qualidade de vida relacionada à saúde; Redução dos implantes de endometriose; desfechos relatados pelas  
pacientes; número de pacientes com eventos adversos gerais.  
**Desenhos de estudo** : Revisão sistemática, ensaios clínicos randomizados ou estudos observacionais<sup>b</sup>  
Notas:<sup>a</sup> - Não sendo identificada evidência para essa população, critérios mais amplos foram usados (p.ex. pacientes com diagnóstico de endometriose apenas) e a qualidade da evidência rebaixada por evidência indireta.<sup>b</sup> – Considerando a disponibilidade de revisão sistemática conduzida no contexto das diretrizes da ESHE para pergunta semelhante, foi acordado que a busca seria atualizada para inclusão de novos estudos.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Métodos e resultado da busca** -->
A população é composta por pacientes com diagnóstico de endometriose na pós-menopausa independentemente de procedimento cirúrgico. O diagnóstico da endometriose pode ser clínico, cirúrgico (por meio de achados da laparoscopia/laparotomia e histológicos) e por exames de imagem (1,2). Não sendo identificada evidência para essa população, critérios mais amplos foram usados (p.ex. pacientes com diagnóstico de endometriose apenas) e a qualidade da evidência rebaixada por evidência indireta.  
As intervenções são os inibidores de aromatase ou inibidores de aromatase + cuidado padrão. Os inibidores da aromatase são uma classe de medicamentos que bloqueiam a enzima aromatase, enzima do grupo do citocromo P450 que converte os andrógenos em estrogênio. Os inibidores da aromatase são usados no tratamento do câncer de mama para reduzir os níveis de estrogênio circulante. São incapazes de impedir que os ovários produzam estrogênio, o que significa que os inibidores da aromatase são usados apenas em mulheres na pós-menopausa (3–5).  
No Brasil, existem três inibidores da aromatase com registro na Agência Nacional de Vigilância Sanitária (Anvisa): anastrozol, exemestano e letrozol (6).  
Foram considerados como comparadores a ausência de tratamento ou o cuidado padrão com tratamento medicamentoso já disponível no SUS (anticoncepcional oral combinado - AOC: etinilestradiol + levonorgestrel; acetato de medroxiprogesterona; danazol; gosserrelina; leuprorrelina e triptorrelina), com o objetivo de propiciar melhora da dor (2).  
25  
Em reunião de escopo realizada entre grupo gestor, elaborador e especialistas foram priorizados os desfechos relativos à dor (dor relacionada à endometriose como dismenorreia, dispareunia, dor pélvica não menstrual e disquezia), qualidade de vida, redução dos implantes de endometriose, desfechos relatados pelas pacientes e eventos adversos gerais (7–10):

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Primários:** -->
- Dismenorreia: indica a presença de cólicas dolorosas de origem uterina que ocorrem durante a menstruação e representa  
uma das causas mais comuns de dor pélvica, distúrbio menstrual e endometriose.  
- Dispareunia: dor sentida dentro do canal vaginal, ao nível do colo do útero, na região pélvica/uterina/abdominal, dor na  
- região vulvar e/ou introito vaginal durante a relação sexual.  
- Dor pélvica não menstrual: dor que ocorre na parte inferior do abdômen (região pélvica) que não ocorra no período  
- menstrual.  
- Disquezia: dor hipogástrica ou na região lombossacral, ou desconforto pélvico associado ao ato de defecar.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Secundários** <u>:</u> -->
- Qualidade de vida relacionada à saúde: percepção do indivíduo sobre a condição de sua vida diante da enfermidade e  
as consequências e os tratamentos associados, medida por escalas que consideram múltiplas dimensões.  
- Redução dos implantes de endometriose: diminuição do número de cistos de endometriose (endometriomas).  
- Desfechos relatados pelas pacientes: medida de desfecho relatada pelas pacientes sobre o impacto da condição de saúde  
- no seu bem-estar.  
- Número de pacientes com eventos adversos: qualquer ocorrência médica que ocorre pela primeira vez ou piora em  
- gravidade a qualquer momento após o procedimento do estudo e que não necessariamente tem que ter uma relação causal com a intervenção, número de pacientes para cada desfecho específico.  
Foram considerados para inclusão revisões sistemáticas, com ou sem meta-análises, ECR ou quasi-randomizados, estudos de coorte prospectivos e caso-controle. Foi feita restrição para data de publicação da busca realizada no _Guideline da European Society of Human Reproduction and Embryology_ (ESHRE) (1). Não foram realizadas restrições quanto ao idioma, fase do ensaio clínico ou número de participantes ou tempo de acompanhamento. Entretanto, revisões sistemáticas que excluíram estudos relevantes por restrição do ano de publicação, ou ainda revisões sistemáticas desatualizadas, foram excluídas. Adicionalmente, foram excluídos estudos relatados apenas em resumo de congresso.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Fontes de informações e estratégias de busca** -->
Com base na pergunta PICO estruturada acima, foi realizada uma busca no dia 06 de dezembro de 2022 nas plataformas PubMed (Medline), Cochrane library e Embase. Para validação da estratégia de busca, uma busca no Epistemonikos foi realizada visando à identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões. O **Quadro B** detalha as estratégias de busca efetuadas em cada plataforma.  
**Quadro B.** Estratégia de busca nas plataformas consultadas dia 06 de dezembro de 2022.  
|**Plataforma**|**Estratégia de busca**|
|---|---|
|PubMed*|("Endometriosis"[Mesh] OR "Endometriosis"[TITLE/ABSTRACT] OR|
||"endometriotic"[TITLE/ABSTRACT] OR "endometrioma"[TITLE/ABSTRACT]) AND|
||("Progestins"[Mesh] OR Progestin[TITLE/ABSTRACT] OR Progestagen[TITLE/ABSTRACT] OR|
||Progestogen[TITLE/ABSTRACT] OR Norethisterone[TITLE/ABSTRACT] OR|
||Norethindrone[TITLE/ABSTRACT] OR "Norethindrone"[Mesh] OR "medroxy progesterone<br>acetate"[TITLE/ABSTRACT] OR "medroxyprogesterone acetate"[TITLE/ABSTRACT] OR|  
26  
|**Plataforma**|**Estratégia de busca**|
|---|---|
||"Medroxyprogesterone Acetate"[Mesh] OR dydrogesterone[TITLE/ABSTRACT] OR<br>"Dydrogesterone"[Mesh] OR dienogest[TITLE/ABSTRACT] OR<br>Levonorgestrel[TITLE/ABSTRACT] OR "Levonorgestrel"[Mesh] OR "Mirena Coil"<br>[TITLE/ABSTRACT] OR Norgestrel[TITLE/ABSTRACT] OR "Norgestrel"[Mesh] OR<br>desogestrel[TITLE/ABSTRACT] OR "Desogestrel"[Mesh] OR "cyproterone acetate"<br>[TITLE/ABSTRACT] OR "Cyproterone Acetate"[Mesh] OR "levonorgestrel-releasing intrauterine<br>system"[TITLE/ABSTRACT] OR "levonorgestrel-releasing intrauterine<br>device"[TITLE/ABSTRACT] OR "Aromatase Inhibitors"[Mesh] OR "aromatase<br>inhibitor"[TITLE/ABSTRACT] OR Anastrozole[TITLE/ABSTRACT] OR<br>letrozole[TITLE/ABSTRACT] OR exemestane[TITLE/ABSTRACT]) Filters: from 2020 - 2022|
|Cochrane library*|(Endometriosis OR endometriotic OR endometrioma) (Word variations have been searched) AND<br>("levonorgestrel-releasing intrauterine system" OR "levonorgestrel-releasing intrauterine device" OR<br>Progestin OR "Progestins" OR Progestagen OR Progestogen OR Norethisterone OR Norethindrone<br>OR “medroxy progesterone acetate” OR “medroxyprogesterone acetate” OR dydrogesterone OR<br>dienogest OR Levonorgestrel OR Mirena Coil OR Norgestrel OR desogestrel OR cyproterone acetate<br>OR "Aromatase Inhibitors" OR "aromatase inhibitor" OR Anastrozole OR letrozole OR exemestane)<br>(Word variations have been searched)<br>Filters: date Between Jan 2020 and Dec 2022, in Cochrane Reviews|
|Embase|('endometriosis'/exp OR 'endometriosis') AND ('progesterone'/exp OR 'progesterone' OR<br>'levonorgestrel releasing intrauterine system'/exp OR 'levonorgestrel releasing intrauterine system'<br>OR 'levonorgestrel-releasing intrauterine system' OR 'lng-ius' OR 'aromatase inhibitor'/exp OR<br>'aromatase inhibitors' OR anastrozole OR letrozole OR exemestane) AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim) AND [2020-2022]/py|  
**Fonte:** elaboração própria.  
*Adaptado da estratégia de busca das diretrizes da ESHRE, 2022 (1), a partir de 2020, incluindo os termos referente à população e intervenção de acordo com a pergunta definida.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Seleção de estudos** -->
As referências identificadas nas bases de dados foram importadas para o Rayyan (11), em seguida as duplicatas foram removidas. Os registros foram selecionados por um único avaliador e um segundo avaliador foi consultado caso houvesse dúvidas, tanto na triagem (leitura de títulos e resumos), quanto na elegibilidade (leitura de textos completos).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Extração de dados** -->
A extração de dados foi realizada por um único avaliador, usando planilhas do software Microsoft Office Excel®. Os seguintes dados foram extraídos:  
i) Características dos estudos, intervenções e participantes: autor, ano; país; desenho do estudo; características gerais da população; número de participantes; idade média; alternativas comparadas e critérios de inclusão.  
ii) Desfechos e resultados: Para desfechos contínuos (por exemplo, escore de dor, qualidade de vida) foram extraídos a média, desvio-padrão (DP), n e valor de p; e para desfechos dicotômicos (por exemplo, número de implantes de endometriose e pacientes com eventos adversos gerais): n com evento, n com a alternativa, _odds ratio_ (OR), risco relativo (RR), intervalo de  
27  
confiança (IC) ou valor de p. Para obtenção desses parâmetros, em alguns casos, foi necessário recalcular os dados ou converter as medidas (i.e. conversão de IC em DP, cálculo do DP da diferença a partir dos DP de início e final de tratamento).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Avaliação do risco de viés** -->
Para a avaliação do risco de viés dos ensaios clínicos foi utilizada a ferramenta ROB 2.0 (12) e para os estudos observacionais a ferramenta ROBINS-I (13). Já para a avaliação crítica das revisões sistemáticas foi utilizada a ferramenta AMSTAR-2 (14).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Síntese e análise dos dados** -->
A síntese e análise dos dados foi feita por representação individual dos estudos em tabelas. As características do estudo, características dos participantes, resultados individuais e avaliação da qualidade dos estudos incluídos foram apresentadas de forma narrativa e a estatística descritiva (frequência absoluta e intervalo de confiança 95% [IC 95%] dos desfechos de interesse). Não foi possível agrupar os dados devido ao pequeno número de estudos incluídos e diferentes comparações. Assim, os _forest plots_ foram apresentados com os resultados individuais dos estudos, sem agrupar os dados.  
O banco de dados _Core Outcome Measures in Effectiveness Trials_ (COMET) (15) foi pesquisado para identificar a diferença mínima clinicamente importante (DMCI) para os desfechos relevantes para esta pergunta de pesquisa. A DMCI validada empiricamente para dor pélvica associada à endometriose medida em uma Escala Visual Analógica (EVA) de 0 a 100 é de 10 pontos. Este DMCI também pode ser usado para definir uma margem de não inferioridade para uma comparação direta de dois tratamentos ativos. Portanto, para uma EVA de 0 a 10, uma diferença de 1 ponto é considerada significante (16). Para os demais desfechos, nenhuma DMCI relevante foi encontrada e para estes apenas a linha de nenhum efeito (i.e., ausência de diferença com significância estatística) foi considerada.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Avaliação da certeza da evidência** -->
A certeza da evidência foi avaliada considerando o sistema GRADE (18). Desfechos relevantes para paciente ou gestores foram graduados em alta, moderada, baixa e muito baixa confiança, considerando os critérios de rebaixamento da evidência (limitações metodológicas, evidência indireta, inconsistência, imprecisão de estimativa de efeito e risco de viés de publicação). Os dados dos ECR foram inicialmente classificados como de alta certeza e os de estudos observacionais como de baixa certeza; em seguida, a certeza da evidência para cada resultado foi rebaixada ou não a partir deste ponto inicial.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Estudos selecionados** -->
Foram recuperadas 586 publicações nas bases de dados consultadas, restando 558 após a remoção de duplicatas identificadas eletronicamente. Durante a seleção, 59 publicações foram incluídas na etapa de leitura na íntegra, as quais respondiam às três perguntas priorizadas (progestágenos, inibidores de aromatase e dispositivo intrauterino liberador de levonorgestrel). Destas, 14 estudos eram relacionados à pergunta dos inibidores de aromatase. Ao final, quatro ECR foram incluídos na análise (19–22) ( **Figura B** ), sendo um deles proveniente do _guideline_ da ESHRE (1). Os outros dois estudos incluídos no _guideline_ da ESHRE foram excluídos por não preencherem os critérios de elegibilidade pré-definidos. Estudos excluídos na elegibilidade, com os motivos, são apresentados no **Quadro C** .  
**Figura B.** Fluxograma de seleção dos estudos.  
28  
<!-- Start of picture text -->
Identificacto de estudos va bases de dados ereastros Identificaco de estudos nor outros métodos<br>A Regisros identficados de<br>| teostordeineadoe Registros removidos antes da | | werstes neo)<br>& | Pubmed (n = 206) triagem: Organizagdes (n=0)<br>G) | Embeeto= an Registros duplicados removidos Pesquisa de citagBes (n=0)<br>Cochrane (n = 363) eletronicamente (n=28) Guideline ESHRE (n=3)<br>g (r558) ( 02543) )<br>2<br>BS| | recuperacioegistros procurados(n=15) para Registro:(n=1)  nfo recuperados recuperagaopeplstros procurados(re3) para Regisrosrecuperados(n=0)no<br>E |<br>elegibildade (n=14) fegistrosexcluidos (n=11) Registros avaliados para Registros excluidos<br>Intervencdo (n=8) elegibilidade (n=3) (n=2)<br>Comparador (n=1) Comparacao (n=1)<br>Jg | estudos incuidos no prc Tipo de estudo (n=2) Tipo de estudo (n=1)<br>z (n=4)<br><!-- End of picture text -->  
**Legenda:** ESHRE: European Society of Human Reproduction and Embryology.  
**Fonte:** Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma- <u>statement.org/</u>  
**Quadro C** . Estudos excluídos na elegibilidade com os motivos.  
|**Estudo**|**Motivo de exclusão**|
|---|---|
|AAcién, 2021 (23)|Tipo de intervenção: Anastrazol mais dispositivo de liberação intrauterina.|
|Agarwal and Foster, 2015 (24)|Duplicado, já incluso na ESHRE.<br>Tipo de comparação: Letrozol mais noretisterona (não tem no SUS). Não tem grupo<br>comparador.|
|Chiu, 2022 (25)|Revisão Sistemática.<br>Tipo de intervenção: não incluiu inibidores de aromatase.|
|Ferrero, 2009 (26)|Tipo de intervenção: tipo de intervenção, noretisterona não tem no SUS, compara<br>letrozol + noretisterona vs. noretisterona sozinha.|
|Ferrero, 2011a (27)|Tipo de intervenção: tipo de intervenção, noretisterona não tem no SUS, compara<br>letrozol + noretisterona vs.  letrozol + triptorrelina.|
|Ferrero, 2011b (28)|Duplicado, já incluso na ESHRE.<br>Revisão Sistemática.<br>Tipo de estudo: estudos incluídos foram conferidos, a maioria deles possui um<br>comparador que não está disponível no SUS.|
|Leite, 2022 (29)|Artigo não recuperado.|
|Samy and Taher, 2021 (30)|Revisão Sistemática.<br>Tipo de intervenção: não incluiu Inibidores de aromatase.|
|Wattanayingcharoenchai, 2021 (31)|Revisão Sistemática.<br>Tipo de intervenção: não incluiu Inibidores de aromatase.|  
29  
|**Estudo**|**Motivo de exclusão**|
|---|---|
|Zajec, 2022 (32)|Revisão Sistemática.|
||Tipo de estudo: estudos incluídos foram conferidos.|
|Zhang, 2022 (33)|Tipo de intervenção: Letrozol mais noretisterona (não tem no SUS).|
|Zhao, 2021 (34)|Tipo de intervenção: Letrozol mais um AOC que não está disponível no SUS.|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Caracterização dos estudos incluídos** -->
Foram identificados quatro ECR (19–22), publicados entre 2004 e 2014. Todos os estudos foram realizados em pacientes com diagnóstico de endometriose por laparoscopia ou laparotomia. Nenhum dos estudos identificados foi avaliado em pacientes na pós-menopausa ( **Quadro D** ).  
Foram incluídas 380 pacientes, com idades médias variando de 29 a 32 anos. As alternativas comparadas foram: letrozol vs. triptorrelina vs. nenhum tratamento (19); letrozol mais AOC vs. AOC sozinho (20); letrozol vs. danazol vs. placebo (22) e anastrozol mais gosserrelina vs. placebo + gosserrelina (21). O tempo de tratamento variou de dois a seis meses, e o período de acompanhamento de cinco a 24 meses.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: <u>Letrozol vs. triptorrelina vs. nenhum tratamento</u> -->
Um ECR incluiu 144 mulheres inférteis em idade reprodutiva após a laparoscopia (cuja endometriose foi confirmada por laparoscopia prévia) e que foram divididas em 3 grupos: grupo 1 (47 casos) que recebeu letrozol por 2 meses, grupo 2 (40 pacientes) que recebeu triptorrelina por 2 meses e grupo 3 (57 pacientes) que não recebeu tratamento. As 144 mulheres foram acompanhadas por pelo menos 12 meses (19).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: <u>Letrozol mais AOC vs. AOC sozinho</u> -->
Um ECR foi realizado com 51 mulheres com endometriose pélvica e dor endometriótica (dispareunia, dismenorreia, dor pélvica), com pontuação de cinco ou mais para pelo menos uma dessas dores endometrióticas, após diagnóstico laparoscópico e cirurgia laparoscópica conservadora. As mulheres foram tratadas com letrozol mais AOC (levonorgestrel 0,15 mg + etinilestradiol 0,03 mg) (n=25) ou apenas AOC (n=26) por quatro meses continuamente (20).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: <u>Letrozol vs. danazol vs. placebo</u> -->
Um ECR, no qual 105 pacientes com endometriose foram aleatoriamente designadas para um dos três grupos. O grupo 1 recebeu comprimidos de letrozol (2,5 mg/dia), cálcio (1000 mg/dia) e vitamina D (800 UI/dia). O Grupo 2 recebeu comprimidos de danazol (600 mg/dia), cálcio (1000 mg/dia) e vitamina D (800 UI/dia). O Grupo 3 (grupo placebo) foi designado para tomar dois comprimidos de cálcio diariamente (500 mg/comprimido) e vitamina D (800 UI/dia). Dor pélvica, dismenorreia e dispareunia foram avaliadas em participantes no início e mensalmente durante o estudo por um total de seis meses (22).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: <u>Anastrozol + gosserrelina vs. placebo + gosserrelina</u> -->
Um ECR avaliou a eficácia do uso de anastrozol + gosserrelina vs. placebo + gosserrelina por seis meses após cirurgia conservadora para endometriose grave em 80 pacientes, que foram acompanhadas por 24 meses (21).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Avaliação do risco de viés dos estudos incluídos** -->
Os estudos foram avaliados quanto ao risco de viés de acordo com os desfechos primários relatados, dois estudos apresentaram risco moderado, um estudo alto risco de viés e um estudo baixo risco. Para desfechos de recorrência dos sintomas de dor (dor pélvica, dismenorreia e dispareunia), o risco de viés foi moderado na comparação letrozol e triptorrelina e de baixo risco na comparação anastrozol + gosserrelina vs. placebo + gosserrelina. Para os desfechos de dor pélvica, dismenorreia e dispareunia, avaliados separadamente, o risco de viés foi moderado na comparação letrozol e AOC e de alto risco na comparação  
30  
letrozol vs. danazol. Os domínios mais sujeitos a vieses foram devido a desvios das intervenções pretendidas; falta de dados de resultados e viés na seleção do resultado relatado ( **Figura C** ).

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Síntese dos resultados dos desfechos avaliados** -->
Todos os estudos relataram os desfechos primários de dor: recorrência da dor (19,21), dismenorreia (20–22), dispareunia (20–22) e dor pélvica (20–22). Eventos adversos foram relatados em dois estudos (21,22), formação de cistos (19) e qualidade de vida (21) em apenas um estudo cada. Disquezia e redução dos implantes de endometriose não foram relatados em nenhum dos estudos.  
Em resumo, os inibidores de aromatase (letrozol ou anastrazol) demonstraram redução nos escores de dor relacionada à endometriose quando comparados ao danazol e aos agonistas de GnRH (triptorrelina ou gosserrelina). Quando comparado letrozol + AOC com AOC sozinho, não houve diferenças estatisticamente significantes na redução da dor ( **Tabela A** ).  
31  
**Quadro D** . Características dos estudos incluídos.  
|**Autor,**<br>**ano**|**País**|**N**|**Pacientes**|**Menopausa**|**Cirurgia de**<br>**endometriose**<br>**prévia**|**Intervenção**|**Idade, média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|
|Alborzi,<br>2010|Irã|144|Pacientes com diagnóstico laparoscópico e histológico de<br>endometriose. Todas as pacientes eram inférteis há pelo menos 12<br>meses e algumas apresentavam sintomas como dismenorreia,<br>dispareunia e dor pélvica, com pontuação acima de 5 (VAS).<br>Estágio ASRM: estágio 1-2, n = 24; estágio 3-4, n = 23|NI|Sim<br>(laparoscopia)|Letrozol 2,5 mg/dia (n=47)<br>Triptorrelina 3,75mg/4 semanas<br>(n=40)<br>Nenhum tratamento (n=57)|29,2<br>(5,3)<br>30,94<br>(4,9)<br>29,91 (5,12)|
|Almassin<br>okiani,<br>2014|Irã|51|Mulheres com endometriose pélvica e dor endometriótica<br>(dispareunia, dismenorreia, dor pélvica) pontuação de 5 ou mais<br>(para pelo menos uma dessas dores endometrióticas), após<br>diagnóstico laparoscópico e cirurgia conservadora|NI|Sim<br>(laparoscopia)|Letrozol 2,5 mg + AOC<br>(Levonorgestrel 0,15 mg mais<br>etinilestradiol 0,03 mg) / dia<br>(n=25)<br>AOC/ dia (n=26)|31<br>(NI)<br>27,5 (NI)|
|Roghaei,<br>2010|Irã|105|Mulheres em idade reprodutiva com ciclos menstruais regulares<br>(18 a 45 dias), com diagnóstico confirmado de endometriose por<br>laparoscopia e dor pélvica crônica e dismenorreia por pelo menos<br>duas semanas em cada mês durante os últimos três meses.|NI|Sim<br>(laparoscopia)|Letrozol 2,5 mg/dia (n=38)<br>Danazol 600mg/dia (n=37)<br>Placebo (n=31)<br>Todos recebiam cálcio<br>elementar 1000 mg/dia, vitamina<br>D 880 UI/dia|<br>32,3<br>(6)<br>31,9<br>(6,4)<br>32,3 (5,8)|
|Soysal,<br>2004|Turquia|80|Pacientes com endometriose basal grave (pontuação rASRM > 40)<br>diagnóstico cirúrgico<br>Estágio ASRM: estágio 4, n = 40|Pré-menopausa|Sim<br>(laparoscopia ou<br>laparotomia)|Anastrozol 1 mg/dia +<br>gosserrelina 3,6 mg/4 semanas<br>(n= 40)<br>Placebo + gosserrelina 3,6 mg/4<br>semanas (n= 40)<br>Todos recebiam cálcio|31,3<br>(5,7)<br>32,4 (6,1)|  
32  
|**Autor,**<br>**ano**<br>|**País**<br>**N**<br>**Pacientes**<br>|**Menopausa**<br>|**Cirurgia de**<br>**endometriose**<br>**prévia**<br>**Intervenção**<br>|**Idade, média**<br>**(DP)**<br>|
|---|---|---|---|---|
||||elementar 1200 mg/dia, vitamina<br>D 800 UI/dia<br>||
|**Fon**<br>**Leg**<br>_Med_<br>|**te:**elaboração própria<br>**enda:**VAS: escala analógica visual de 0 (sem dor) a 10 (dor mais intensa já experimentada); A<br>_icine_.<br>|OC: anticoncepcional oral combinado;<br>|NI: nenhuma informação; rASRM:score revisado da_American Soci_<br>|_ety for Reproductive_<br>|  
**Figura C.** Risco de viés dos estudos individuais (Rob 2).  
|**Estudo**|**Intervenção**|**Comparador**|**Desfecho**|**Domínios do ris**<br>|**co de viés**<br>|||||
|---|---|---|---|---|---|---|---|---|---|
|||||**D1**|**D2**|**D3**|**D4**|**D5**|**Geral**|
|Alborzi, 2010|Letrozol|Triptorrelina|Recorrência<br>dos<br>sintomas de dor*|||||||
|Almassinokiani,<br>2014|Letrozol|AOC|Dor<br>pélvica/<br>Dismenorreia/|||||||
||||Dispareunia**|||||||
|Roghaei, 2010|Letrozol|Danazol|Dor<br>pélvica/|||||||
||||Dismenorreia/<br>Dispareunia**|||||||
|Soysal, 2004|Anastrozol +|<br>Placebo<br>+|<br>Recorrência<br>dos|||||||
||gosserrelina|gosserrelina|sintomas de dor*|||||||
|**Domínios:**||||Julgamento:||||||  
33  
|**Estudo**<br>**Intervenção**<br>**Comparador**<br>**Desfecho**|**Domínios d**|**o risco de viés**|||||
|---|---|---|---|---|---|---|
||**D1**|**D2**|**D3**|**D4**|**D5**|**Geral**|
|D1: Risco de viés decorrente do processo de randomização||Alto|||||
|D2: Risco de viés devido a desvios das intervenções pretendidas||Moderado|||||
|D3: Risco de viés devido à falta de dados de resultados||Baixo|||||
|D4: Risco de viés na medição do resultado||Nenhuma infor|mação||||
|D5: Risco de viés na seleção do resultado relatado|||||||  
**Fonte:** elaboração própria  
**Legenda:** AOC: anticoncepcional oral combinado;  
Nota: * dor pélvica, dismenorreia e dispareunia; ** avaliados separadamente.  
34  
**Tabela A.** Resultados dos estudos individuais para os inibidores de aromatase.  
|**Autor, ano**|**Intervenção (n)**|**Recorrência dos**<br>**sintomas de dor,**<br>**n (%) ***|**valor p**|**Dor pélvica, média do**<br>**escore (DP)**|**valor**<br>**p**|**Dismenorreia, média do**<br>**escore (DP)**|**valor p**|**Dispareunia, média do**<br>**escore (DP)**|**valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|
||Letrozol (47)|3 (6,4)||NR|NR|NR|NR|NR|NR|
|Alborzi 2010|Triptorrelina (40)|2 (5)|048|||||||
|,|Nenhum tratamento<br>(57)|3 (5,3)|,|||||||
|Almassinokiani,<br>2014|Letrozol mais AOC<br>(25)|NR|NR|1,9|> 0,05|1,1|> 0,05|1,8|> 0,05|
||AOC (26)|||2,5||1,4||2||
||Letrozol (37)|NR|NR|0,80 (0,74)|< 0,05|0,83 (1,05)|> 0,05|0,38 (0,80)|< 0,05|
|Roghaei, 2010|Danazol (33)|||2,11 (0,60)||2,66 (0,86)||2,44 (0,52)||
||Placebo (9)|||1,10 (0,48)||1,24(0,98)||0,86 (0,58)||
|Sosal 2004|Anastrozol +<br>gosserrelina (40)|3 (7,5)|0,0089|0,7 (0,5)|<|1,4 (0,5)|< 005|0,6 (0,5)|<|
|y,|Placebo + gosserrelina<br>(40)|14 (35)||1,5 (0,5)|0,0001|<br>1,7 (0,7)|,|1,4 (0,8)|0,0001|  
**Fonte:** elaboração própria.  
**Legenda:** AOC: anticoncepcional oral combinado; DP: desvio-padrão; n: número; NR: não relatado; * dor pélvica, dismenorreia e dispareunia avaliados conjuntamente.  
35

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Recorrência dos sintomas de dor** -->
Dois estudos avaliaram a recorrência dos sintomas de dor. Um deles possuía três braços de comparação: letrozol vs. triptorrelina vs. nenhum tratamento (19). Não houve diferença estatisticamente significante entre os grupos. O outro estudo comparou anastrozol + gosserrelina vs. placebo + gosserrelina (21), no qual  anastrozol + gosserrelina diminuiu as taxas de recorrência dos sintomas de dor em pacientes após cirurgia para endometriose grave, risco relativo (RR) 0,21 (IC 95%: 0,07 a 0,69) ( **Figura D** ).  
**Figura D.** Resultado individual dos estudos por comparações de tratamentos para o desfecho de recorrência dos sintomas de dor.  
<!-- Start of picture text -->
Risk Ratio (RR)<br>triptorrelina vs nenhum tratamento<br>Alborzi 2010 —— 0.95 [0.17, 5.43]<br>letrozol vs nenhum tratamento:<br>Alborzi 2010 —— 1.21 (0.26, 5.73]<br>Jetrozol vs triptorrelina<br>Alborzi 2010 ————— 1.28 (0.22, 7.26}<br>anastrozol + gosserrelina vs gosserrelina + placebo<br>Soysal 2004 +—-—+ 0.21 (0.07, 0.69}<br>rres rs |<br>0.01 1 10 100<br>Observed Outcome<br><!-- End of picture text -->  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Dor pélvica** -->
Três estudos avaliaram os escores de dor pélvica em diferentes comparações: letrozol + AOC vs. AOC sozinho (20); letrozol vs. danazol vs. placebo (22) e anastrozol + gosserrelina vs. placebo + gosserrelina (21). O letrozol é mais eficaz do que o danazol para reduzir a dor pélvica com uma diferença das médias (DM) dos escores de dor de 1,31 (IC 95%: 1,00 a 1,62). Não houve diferença estatisticamente significante entre letrozol e placebo. Anastrozol + gosserrelina é mais eficaz do que placebo + gosserrelina na redução da dor pélvica (DM: 0,8; IC 95%: 0,58 a 1,02) ( **Figura E** ).  
Almassinokiani et al., 2014 não apresentaram dados de desvio-padrão, erro-padrão ou intervalo de confiança, não sendo possível estimar a variabilidade para este desfecho. Os autores informaram que não houve diferença estatisticamente significante entre as médias dos escores de dor pélvica do grupo letrozol mais AOC (de 1,9) e do grupo AOC (de 2,5).  
36  
**Figura E.** Resultado individual dos estudos por comparações de tratamentos para o desfecho de dor pélvica.  
<!-- Start of picture text -->
Diferenca das médias (DM)<br>LET vs. PLA Roghaei 2010 ey ~0.30 [-0.69, 0.09}<br>DAN vs. PLA Roghaei 2010 — 1.01 [ 0.64, 1.38)<br>LET vs.DAN ——roghaei 2010 —— 1.31[ 1.00, 1.62}<br>ANA+GOS+H vs. Soysal 2004 _ 0,80 [ 0.58, 1.02}<br>GOS+PLA —<br>“1-05 0 05 1 15 2<br>Observed Outcome<br><!-- End of picture text -->  
**Fonte:** Elaboração própria. **Legenda:** LET: letrozol, PLA:  placebo, DAN: danazol, ANA + GOS: anastrozol + gosserrelina, GOS + PLA: gosserrelina + placebo.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Dismenorreia** -->
Três estudos avaliaram os escores de dismenorreia em diferentes comparações: letrozol + AOC vs. AOC sozinho (20); letrozol vs. danazol vs. placebo (22) e anastrozol + gosserrelina vs. placebo + gosserrelina (21). O letrozol é mais eficaz do que o danazol para reduzir a dismenorreia (DM 1,83; IC 95%: 1,38 a 2,28). Não houve diferença estatisticamente significante entre letrozol e placebo. Anastrozol + gosserrelina é mais eficaz do que placebo + gosserrelina na redução dos escores de dismenorreia (DM: 0,3; IC 95%: 0,03 a 0,57) ( **Figura F** ).  
Almassinokiani et al., 2014 não apresentaram dados de desvio-padrão, erro-padrão ou intervalo de confiança, não sendo possível estimar a variabilidade para este desfecho. Os autores informaram que não houve diferença estatisticamente significante entre as médias dos escores de dismenorreia do grupo letrozol mais AOC (de 1,1) e do grupo AOC (de 1,4).  
**Figura F.** Resultado individual dos estudos por comparações de tratamentos para o desfecho de dismenorreia.  
<!-- Start of picture text -->
Diferengadas médias (DM)<br>LET vs. PLA Roghaei 2010 vee 0.41 [-1.13, 0.31)<br>DAN vs. PLA Roghael 2010 — 142 (0.72,2:12)<br>LET vs. DAN Roghael 2010 — 1.89 1.98, 229)<br>ANA+GOS vs. Soysal 2004 = 030 0.03,057)<br>GOS#PLA 2poe,4vserved0 Outcome1 2 3<br><!-- End of picture text -->  
**Fonte:** Elaboração própria. **Legenda:** LET: letrozol, PLA:  placebo, DAN: danazol, ANA + GOS: anastrozol + gosserrelina, GOS + PLA: gosserrelina + placebo.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Dispareunia** -->
Três estudos avaliaram os escores de dispareunia em diferentes comparações: letrozol + AOC vs. AOC sozinho (20); letrozol vs. danazol vs. placebo (22) e anastrozol + gosserrelina vs. placebo + gosserrelina (21). O letrozol é mais eficaz do que o danazol para reduzir os escores de dispareunia (DM2,06; IC 95%: 1,75 a 2,37). Não houve diferença estatisticamente  
37  
significante entre letrozol e placebo. Anastrozol + gosserrelina é mais eficaz do que placebo + gosserrelina na redução da dispareunia (DM: 0,8; IC 95%: 0,51 a 1,09) ( **Figura G** ).  
Almassinokiani et al., 2014 não apresentaram dados de desvio-padrão, erro-padrão ou intervalo de confiança, não sendo possível estimar a variabilidade para este desfecho. Os autores informaram que não houve diferença estatisticamente significante entre as médias dos escores de dor pélvica do grupo letrozol mais AOC (de 1,8) e do grupo AOC (de 2).  
**Figura G.** Resultado individual dos estudos por comparações de tratamentos para o desfecho de dispareunia.  
<!-- Start of picture text -->
Diferenga<br>das médias (DM)<br>LET vs. PLA Foswe2010 Cal 048-094, -002)<br>DAN vs. PLA Rome'2010 — 158,196, 209)<br>LET vs. DAN Peowei2010 - 2081175, 2371<br>ANA+GOS vs. Sers!2004 - oa01054, 109)<br>a0 1 2 3<br>GOS+PLA So<br><!-- End of picture text -->  
**Fonte:** Elaboração própria.  
**Legenda:** LET: letrozol, PLA:  placebo, DAN: danazol, ANA + GOS: anastrozol + gosserrelina, GOS + PLA: gosserrelina + placebo.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Segurança** -->
Os eventos adversos foram avaliados em dois estudos (21,22) ( **Quadro E)** . No estudo de Roghaei et. al., 2010, as pacientes do grupo letrozol reclamaram de manchas no corpo e dores de cabeça e os do grupo danazol apresentaram eventos adversos devido aos efeitos colaterais androgênicos do danazol (ganho de peso, hirsutismo e acne por exemplo).  
Soysal et. al, 2004 avaliaram o impacto do tratamento médico na densidade mineral óssea (DMO) das vértebras L1-L4. As pacientes no braço de gosserrelina mais anastrozol perderam 2,3% de sua DMO L1–L4 basal em 24 meses de retirada do tratamento e os do braço gosserrelina e placebo, 2,1%. Essas perdas foram estatisticamente significantes quando comparadas aos status do _baseline_ . No entanto, não houve diferenças estatisticamente significativas ao comparar as diferenças das médias da DMO basal e de 24 meses entre os dois tratamentos ( **Quadro E** ).  
No estudo de Almassinokiani et al., 2014, nenhuma das pacientes desenvolveu qualquer efeito adverso de letrozol ou AOC e todos continuaram o medicamento prescrito por quatro meses.  
A formação de cistos funcionais, relatada no estudo de Alborzi, 2010 (19), foi maior no grupo letrozol (24,3%) em relação ao demais grupos (2,5% triptorrelina e nenhum no grupo sem tratamento, p < 0,001) ( **Quadro E** ).  
**Quadro E.** Resultados de segurança dos estudos individuais para os inibidores de aromatase.  
|**Autor, ano**|**Intervenção**|**Formação de**<br>**cisto**|**valor p**|**Eventos adversos, n**|**valor p**<br>**(IC95%)**|
|---|---|---|---|---|---|
||Letrozol (n=47)|11,4 (24,3%)||||
|Alborzi,|Triptorrelina (40)|1 (2,5%)|<0001|||
|2010|Nenhum<br>tratamento (n=57)|0|,|||  
38  
|**Autor, ano**|**Intervenção**|**Formação de**<br>**cisto**|**valor p**|**Eventos adversos, n**|**valor p**<br>**(IC95%)**|
|---|---|---|---|---|---|
||Letrozol (n=37)|||Rubor 33<br>Dor de cabeça 24<br>Manchas 31<br>Fraqueza 7<br>Pele oleosa 2<br>Ganho de peso (10%) 4<br>Aumento do apetite 6<br>Dores ósseas e articulares 2<br>Acne 2<br>Hirsutismo 3||
|Roghaei,<br>2010|Danazol (n=33)|||Rubor 25<br>Dor de cabeça 12<br>Manchas 5<br>Fraqueza 6<br>Pele oleosa 18<br>Ganho de peso (10%) 14<br>Aumento do apetite 9<br>Dores ósseas e articulares 3<br>Acne 17<br>Hirsutismo 24||
||Placebo (n=9)|||Rubor 3<br>Dor de cabeça 12<br>Manchas 18<br>Fraqueza 10<br>Pele oleosa 4<br>Ganho de peso (10%) 5<br>Aumento do apetite 3<br>Dores ósseas e articulares 3<br>Acne 8||
|||||Hirsutismo 4||
|||||média da diferença basal e 24||
||Anastrozol + gosse|rrelina (n= 40)||meses de tratamento da DMO: 27,1|0,46|
|Soysal,||||(46,3)|(-16,9|
|2004||||média da diferença basal e 24|a|
||Placebo + gosserre|lina (n= 40)||meses de tratamento da DMO: 25,2<br>(28,9)|36,4)|  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Qualidade de vida relacionada à saúde** -->
39  
A qualidade de vida foi avaliada em apenas um estudo (21) que comparou anastrazol + gosserrelina vs. gosserrelina + placebo. Para isto, foram utilizadas duas escalas. A escala de Greene modificada, que avalia sintomas vasomotores, somáticos, psicológicos (ansiedade e depressão) e perda de interesse sexual, e o índice de Blatt-Kupperman, que avalia sintomas climatéricos como ondas de calor, parestesia, insônia, nervosismo, depressão, fadiga, artralgia/mialgia, cefaleia, palpitação e zumbido no ouvido.  
Não houve diferenças estatisticamente significantes entre os tratamentos em termos de pontuações da escala de Greene modificada ou as pontuações do índice de Blatt-Kupperman como uma medida da qualidade de vida na menopausa em 24 semanas de avaliação ( **Tabela B** ).  
**Tabela B.** Resultados de qualidade de vida para a comparação entre anastrazol + gosserrelina vs. gosserrelina + placebo.  
|**Autor, ano**|**Intervenção**|**Qualida**|**de de vi**|**da**||**valor p (IC95%)**|
|---|---|---|---|---|---|---|
|Soysal, 2004|Anastrozol + gosserrelina<br>(n= 40)<br>Placebo + gosserrelina<br>(n= 40)|Greene<br>Blatt-Ku<br>(64,7)<br>Greene<br>Blatt-Ku<br>(66,0)|score<br>pperman<br>score<br>pperman|30,3<br>n score<br>29,5<br>n score|(61,9)<br>54,1<br>(61,9)<br>53,9|0,20 (-1,5 a 0,3)<br>0,90 (-2,5 a 2,2)|  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **Avaliação da certeza da evidência** -->
Para a comparação letrozol vs. triptorrelina, os desfechos de recorrência dos sintomas de dor e formação de cisto apresentaram certeza muito baixa. Os principais domínios que comprometeram a certeza da evidência foi o risco de viés, devido à ausência de cegamento do estudo; evidência indireta, devido às diferenças da população da PICO (pacientes do estudo na prémenopausa) e imprecisão ( **Quadro F** ).  
Para a comparação letrozol + AOC vs. AOC, os desfechos de dor pélvica, dismenorreia e dispareunia apresentaram certeza da evidência muito baixa. Os principais domínios que comprometeram a certeza foram: o risco de viés, devido à ausência de cegamento do estudo; evidência indireta, devido às diferenças da população da PICO (pacientes do estudo na pré-menopausa) e imprecisão ( **Quadro G** ).  
Na comparação letrozol vs. danazol, os desfechos de dor pélvica, dismenorreia, dispareunia e eventos adversos apresentaram certeza muito baixa. Os principais domínios que comprometeram a certeza foi o risco de viés, devido à ausência de cegamento do estudo; evidência indireta, devido às diferenças da população da PICO (pacientes do estudo na pré-menopausa) e imprecisão ( **Quadro H** ).  
A comparação entre anastrazol mais gosserrelina vs. gosserrelina mais placebo, os desfechos de recorrência dos sintomas de dor, dor pélvica, dismenorreia, dispareunia, eventos adversos e qualidade de vida, apresentaram certeza moderada. O principal domínio que comprometeu a certeza foi a evidência indireta, incluíram apenas pacientes na pré-menopausa) e imprecisão ( **Quadro I** ).  
40  
**Quadro F.** Avaliação da certeza da evidência para a comparação entre letrozol e triptorrelina (ferramenta GRADE).  
<!-- Start of picture text -->
Avaliação da Certeza da Evidência  № de pacientes  Efeito<br>Delineamento  Risco de  Evidência  Outras  Triptor- Relativo Absoluto Certeza  Importância<br>№ estudos  Inconsistência  Imprecisão  letrozol<br>do estudo  viés  indireta  considerações  relina  (95% CI)  (95% CI)<br>Recorrência dos sintomas de dor (seguimento: 12 meses)<br>14 mais por<br>RR  1.28  1.000  ⨁◯◯◯<br>ensaios clínicos  3/47  2/40<br>1 a grave b não grave  grave c,d grave e nenhum  (0.22 para  (de  39  Muito  CRÍTICO<br>randomizados  (6.4%)  (5.0%)<br>7.26)  menos para  baixa<br>313 mais)<br>Formação de cisto (seguimento: 12 meses)<br>209  mais<br>RR  9.36  por  1.000  ⨁◯◯◯<br>ensaios clínicos  11/47  1/40<br>1 a grave b não grave  grave c,d grave f Nenhum  (1.26 para  (de 7 mais  Muito  IMPORTANTE<br>randomizados  (23.4%)  (2.5%)<br>69.40)  para 1.000  baixa<br>mais)<br><!-- End of picture text -->  
**IC:** Intervalo de Confiança; **RR:** risco relativo.  
- **a.** Alborzi, 2010;  
- **b.** Estudo aberto. Apenas as pacientes que completaram seus períodos de acompanhamento foram incluídos;  
- **c.** Nenhuma informação sobre o status da menopausa, mas pela média da idade das pacientes, podem estar na pré-menopausa;  
- **d.** Inclui apenas mulheres inférteis **;**  
- **e.** Similaridade estatística entre comparadores;  
- **f.** Pequeno tamanho amostral.  
41  
**Quadro G.** Avaliação da certeza da evidência para a comparação entre letrozol mais AOC _vs._ AOC (ferramenta GRADE).  
|||**Avaliaç**|**ão da Certeza da**|**Evidência**|||**Média do e**|**score**|**Valor**|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**letrozol mais**<br>**AOC (n=25)**|**AOC**<br>**(n=26)**|<br>**de p**|**Certeza**|**Importância**|
|Dor pélvi<br>1<sup>a</sup>|ca (seguimento: 4 meses)<br>ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d,e</sup>|nenhum|1.9|2.5|p >0,05|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|
|Dismenor<br>1<sup>a</sup>|reia (seguimento: 4 meses<br>ensaios<br>clínicos<br>randomizados|)<br>grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d,e</sup>|nenhum|1.1|1.4|p >0,05|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|
|Dispareun<br>1<sup>a</sup>|ia (seguimento: 4 meses)<br>ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d,e</sup>|nenhum|1.8|2|p >0,05|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
**IC:** Intervalo de Confiança  
**a.** Almassinokiani, 2014;  
**b.** Estudo aberto. Randomizamos as pacientes atribuindo-as aos grupos caso e controle alternadamente na ordem de admissão;  
**c.** Nenhuma informação sobre o status da menopausa, mas pela média da idade das pacientes, podem estar na pré-menopausa;  
**d.** Pequeno tamanho amostral sem cálculo estatístico da amostra;  
**e.** Similaridade estatística entre comparadores.  
42  
**Quadro H.** Avaliação da certeza da evidência para a comparação entre letrozol e danazol (ferramenta GRADE).  
|||**Avaliaç**|**ão da Certeza d**|**a Evidência**|||**Grupos**|||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**letrozol**<br>**danazol**|**Certeza**|**Importância**|
|Dor pélvi|ca (seguimento: 5 me|ses)||||||||
|1<sup>a</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|Média do escore (DP)<br>Letrozol: 0,80 (0,74)<br>Danazol: 2,11 (0,60)<br>Diferença das médias: 1,31 (IC 95%: 1,00 a 1,62)|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|
|Dismenor|reia (seguimento: 5 m|eses)||||||||
|1<sup>a</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|Média do escore (DP)<br>Letrozol: 0,83 (1,05)<br>Danazol: 2,66 (0,86)<br>Diferença das médias: 1,83 (IC 95%: 1,38 a 2,28)|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|
|Dispareun|ia (seguimento: 5 me|ses)||||||||
|1<sup>a</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|Média do escore (DP)<br>Letrozol: 0,38 (0,80)<br>Danazol: 2,44 (0,52)<br>Diferença das médias: 2,06 (IC 95%: 1,75 a 2,37)|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|
|Eventos a|dversos (seguimento:|5 meses)||||||||  
43  
|||**Avalia**|**ção da Certeza d**|**a Evidência**|||**Grupos**|||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**letrozol**<br>**danazol**|**Certeza**|**Importância**|
|1<sup>a</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>b</sup>|não grave|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|As pacientes do grupo letrozol queixaram-se de<br>manchas, aqueles no grupo Danazol enfrentou muitos<br>problemas devido aos efeitos colaterais androgênicos<br>do Danazol.<br>Letrozol (n) Rubor 33 Dor de cabeça 24 Manchas 31<br>Fraqueza 7 Pele oleosa 2 Ganho de peso (10%) 4<br>Aumento do apetite 6 Dores ósseas e articulares 2 Acne<br>2 Hirsutismo 3<br>Danazol (n) Rubor 25 Dor de cabeça 12 Manchas 5<br>Fraqueza 6 Pele oleosa 18 Ganho de peso (10%) 14<br>Aumento do apetite 9 Dores ósseas e articulares 3 Acne<br>17 Hirsutismo 24|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
**IC:** Intervalo de Confiança; **DP** : Desvio Padrão  
a. Roghaei, 2010  
b. Não informa o método de randomização. Estudo aberto.  
c. Nenhuma informação sobre o status da menopausa, mas pela média da idade das pacientes, podem estar na pré-menopausa.  
d. Pequeno tamanho amostral sem cálculo estatístico da amostra  
44  
**Quadro I.** Avaliação da certeza da evidência para a comparação entre anastrazol mais gosserrelina vs. gosserrelina mais placebo (ferramenta GRADE).  
|||**Avali**|**ação da Certeza**|**da Evidência**|||**№ de pa**|**cientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**estudos**<br>Recorrên|**Delineamento**<br>**do estudo**<br>cia dos sintomas de|**Risco**<br>**de**<br>**viés**<br>dor (seg|**Inconsistência**<br>uimento: 24 mese|**Evidência**<br>**indireta**<br>s)|**Imprecisão**|**Outras**<br>**considerações**|**anastrozol**<br>**mais**<br>**gosserrelina**|**gosserrelina**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|1<sup>a</sup>|ensaios clínicos<br>randomizados|não<br>grave|não grave|grave<sup>b</sup>|não grave|nenhum|3/40 (7.5%)|14/40<br>(35.0%)|RR 0.21<br>(0.07 para<br>0.69)|273<br>menos<br>por<br>1.000<br>(de<br>325<br>menos para<br>109 menos)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|Dor pélv|ica (seguimento: 24|meses)|||||||||||
|1<sup>a</sup><br>Dismeno|ensaios clínicos<br>randomizados<br>rreia (seguimento:|não<br>grave<br>24 meses|não grave<br>)|grave<sup>b</sup>|não grave|nenhum|Média do escore<br>Anastrozol + go<br>Placebo + gosse<br>Diferença das m|(DP)<br>sserrelina: 0,70<br>rrelina: 1,5 (0,5<br>édias: 0,8 (IC 9|(0,5)<br>)<br>5%: 0,58 a|1,02)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|1<sup>a</sup>|ensaios clínicos<br>randomizados|não<br>grave|não grave|grave<sup>b</sup>|não grave|nenhum|Média do escore<br>Anastrozol + go<br>Placebo + gosse<br>Diferença das m|(DP)<br>sserrelina: 1,4 (<br>rrelina: 1,7 (0,7<br>édias: 0,3 (IC 9|0,5)<br>)<br>5%: 0,03 a|0,57)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|Dispareu|nia (seguimento: 24|meses)|||||||||||  
45  
|||**Avali**|**ação da Certeza**|**da Evidência**|||**№ de pacientes**<br>**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**anastrozol**<br>**mais**<br>**gosserrelina**<br>**gosserrelina**<br>**Relativo**<br>**(95%**<br>**CI)**<br>**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|1<sup>a</sup><br>Eventos<br>1<sup>a</sup><br>Qualidad|ensaios clínicos<br>randomizados<br>adversos (seguiment<br>ensaios clínicos<br>randomizados<br>e de vida (seguimen|não<br>grave<br>o: 24 m<br>não<br>grave<br>to: 24 m|não grave<br>eses)<br>não grave<br>eses)|grave<sup>b</sup><br>grave<sup>b</sup>|não grave<br>não grave|nenhum<br>nenhum|Média do escore (DP)<br>Anastrozol + gosserrelina: 0,6 (0,5)<br>Placebo + gosserrelina: 1,4 (0,8)<br>Diferença das médias: 0,8 (IC 95%: 0,51 a 1,09)<br>Média do Δ basal–24 meses de tratamento da DMO,<br>g/cm2 (%)<br>Anastrozol + gosserrelina: 27,1 (46,3)<br>Placebo + gosserrelina: 25,2 (28,9)<br>p= 0,46 (-16,9 a 36,4)|⨁⨁⨁◯<br>Moderada<br>⨁⨁⨁◯<br>Moderada|<br>CRÍTICO<br> <br>CRÍTICO|
|1<sup>a</sup>|ensaios clínicos<br>randomizados|não<br>grave|não grave|grave<sup>b</sup>|não grave|nenhum|Média do escore (DP)<br>- Anastrozol + gosserrelina: Escala Greene: 30,3 (61,9)<br>Blatt-Kuppermann: 54,1 (64,7)<br>- Placebo + gosserrelina: Escala Greene: 29,5 (61,9)<br>Escala Blatt-Kuppermann:53,9 (66,0)<br>p= 0,20 (-1,5 to 0,3)<br>p= 0,90 (-2,5 to 2,2)|⨁⨁⨁◯<br>Moderada|<br>IMPORTANTE|  
46  
**IC:** Intervalo de Confiança; **RR:** risco relativo; **DP:** Desvio Padrão; **DMO:** Densidade mineral óssea; **Escala de Greene modificada:** avalia sintomas vasomotores, somáticos, psicológicos (ansiedade e depressão) e perda de interesse sexual. **Índice de Blatt-Kupperman:** avalia sintomas climatéricos como ondas de calor, parestesia, insônia, nervosismo, depressão, fadiga, artralgia/mialgia, cefaleia, palpitação e zumbido no ouvido.  
Legenda: a. Soysal, 2004; b. Pacientes na pré-menopausa.  
47

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **CONSIDERAÇÕES FINAIS** -->
Poucos estudos avaliaram os inibidores de aromatase para o tratamento de pacientes com endometriose. A indicação em bula destes medicamentos é principalmente para o câncer de mama, mas na prática clínica é comum o uso devido à ausência de outros tratamentos para pacientes com endometriose na pós-menopausa.  
Foram incluídos quatro ECR, realizados em pacientes com diagnóstico de endometriose por laparoscopia ou laparotomia (n=380), com idades médias variando de 29 a 32 anos. Nenhum dos estudos identificados foi avaliado em pacientes na pósmenopausa como mencionado como critério da PICOS, mas foram incluídos na pergunta de pesquisa e tiveram sua certeza rebaixada por evidência indireta. As alternativas comparadas foram: letrozol vs. triptorrelina vs. nenhum tratamento (19); letrozol + AOC vs. AOC sozinho (20); letrozol vs. danazol vs. placebo (22) e anastrozol + gosserrelina vs. placebo + gosserrelina (21).  
Com relação aos desfechos primários de eficácia, entre letrozol vs. triptorrelina vs. nenhum tratamento, não há diferença estatisticamente significante entre os grupos com relação à recorrência dos sintomas de endometriose (dor pélvica, dismenorreia e dispareunia). O letrozol é mais eficaz do que o danazol para reduzir a dor pélvica, dismenorreia e dispareunia, com uma diferença das médias dos escores de dor de 1,31 (IC 95%: 1,00 a 1,62); 1,83; IC 95%: 1,38 a 2,28) e 2,06; IC 95%: 1,75 a 2,37), respectivamente. Não houve diferença estatisticamente significante entre letrozol e placebo com relação à dor pélvica, dismenorreia e dispareunia. Anastrozol + gosserrelina é mais eficaz do que placebo + gosserrelina na redução da dor pélvica, dismenorreia e dispareunia (DM: 0,8; IC 95%: 0,58 a 1,02; DM: 0,3; IC 95%: 0,03 a 0,57 e DM: 0,8; IC 95%: 0,51 a 1,09, respectivamente) e na redução das taxas de recorrência dos sintomas de dor (RR: 0,21; IC 95%: 0,07 a 0,69). Entre letrozol + AOC e AOC sozinho, não houve diferença estatisticamente significante entre as médias dos escores de dor pélvica, dismenorreia e dispareunia.  
A redução de um ponto na EVA (de 0 a 10) é considerada significativa clinicamente (16). Portanto, a evidência mostra que todos os tratamentos com letrozol são mais eficazes que o danazol na redução dos escores de dor pélvica, dismenorreia e dispareunia. Apesar do tratamento com anastrozol + gosserrelina apresentar um benefício na redução dos escores de dor, essa diferença não é clinicamente significante.  
Quanto ao desfecho de segurança, os eventos adversos mais relatados no grupo letrozol foram manchas no corpo e dores de cabeça e no grupo danazol as pacientes apresentaram eventos adversos devido aos efeitos androgênicos do danazol (ganho de peso, hirsutismo e acne por exemplo). Não houve diferenças estatisticamente significantes entre gosserrelina + anastrozol e gosserrelina sozinha com relação à perda de DMO das vértebras L1-L4, após 24 meses de retirada do tratamento. Na comparação entre letrozol e danazol, nenhuma das pacientes desenvolveu qualquer evento adverso e todos continuaram o medicamento prescrito por quatro meses. Houve maior formação de cistos funcionais no grupo letrozol em relação à triptorrelina.  
A qualidade de vida foi avaliada em apenas um estudo (21) que comparou anastrazol + gosserrelina vs. gosserrelina mais placebo. A média das diferenças entre os regimes de tratamento em termos da escala de Greene modificada ou do índice de BlattKupperman como medidas de qualidade de vida no climatério não foram estatisticamente significativas.  
A certeza da evidência foi muito baixa em todos os desfechos das comparações letrozol vs. triptorrelina, letrozol mais AOC vs. AOC e letrozol vs. danazol (recorrência dos sintomas de dor, formação de cisto, dor pélvica, dismenorreia, dispareunia e eventos adversos). Para a comparação entre anastrazol + gosserrelina vs. gosserrelina mais placebo, os desfechos avaliados apresentaram certeza moderada (recorrência dos sintomas de dor, dor pélvica, dismenorreia, dispareunia, eventos adversos e qualidade de vida).  
Pacientes com endometriose após a menopausa são casos raros e mais complexos do que a endometriose em mulheres em idade reprodutiva. Ainda não está claro se as mulheres com endometriose na pós-menopausa estão experimentando uma continuação de uma condição existente (assintomática ou não diagnosticada anteriormente) ou uma nova condição. Além disso, como a endometriose é uma doença inflamatória dependente de estrogênio, a maioria das mulheres que sofrem com a doença  
48  
encontram seus sintomas aliviados após a menopausa, uma vez que os níveis de estrogênio são reduzidos. Os inibidores de aromatase são medicamentos que impedem a produção de estrogênio. Antes da menopausa, a maioria do estrogênio é produzida pelos ovários. Mas para mulheres cujos ovários não estão funcionando, uma pequena quantidade de estrogênio ainda é produzida pela enzima aromatase no tecido adiposo. Os inibidores de aromatase agem bloqueando essa enzima (3).  
Como limitações desta pergunta de pesquisa destacam-se a escassa evidência, com muito baixa certeza para a maioria dos desfechos (por imprecisão, evidência indireta, ausência de cegamento para desfechos subjetivos), a ausência de estudos que tenham incluído pacientes com endometriose na pós-menopausa e de estudos que comparassem os inibidores de aromatase entre si. Além disso, todos os estudos foram conduzidos no Oriente Médio (três no Irã e um na Turquia), o que potencialmente restringe a validade externa dos resultados. Portanto, não foi possível agrupar os dados em uma meta-análise devido ao pequeno número de estudos incluídos e diferentes comparações.  
A evidência sugere que letrozol reduz os escores de dor relacionada à endometriose quando comparado ao danazol, sem ocasionar complicações graves.

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **5. REFERÊNCIAS** -->
1.  ESHRE Endometriosis Guideline Development Group. Endometriosis - Guideline of European Society of Human  
Reproduction and Embryology. 2022;  
2.  Ministério da Saúde. Secretaria de Atenção à Saúde. PORTARIA No 879, DE 12 DE JULHO DE 2016 - Protocolo  
Clínico e Diretrizes Terapêuticas da Endometriose. 2016.  
3.  Patwardhan S, Nawathe A, Yates D, Harrison G, Khan K. Systematic review of the effects of aromatase inhibitors on pain associated with endometriosis. BJOG An Int J Obstet Gynaecol [Internet]. 2008 Jun;115(7):818–22. Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.1471-0528.2008.01740.x  
4.  Bulun SE. Molecular basis for treating endometriosis with aromatase inhibitors. Hum Reprod Update [Internet]. 2000  
Sep 1;6(5):413–8. Available from: https://academic.oup.com/humupd/article-lookup/doi/10.1093/humupd/6.5.413  
5.  Lønning PE, Geisler J. Indications and limitations of third-generation aromatase inhibitors. Expert Opin Investig  
Drugs [Internet]. 2008 May 30;17(5):723–39. Available from: http://www.tandfonline.com/doi/full/10.1517/13543784.17.5.723  
6.  Agência Nacional de Vigilância Sanitária (Anvisa). Consulta de Medicamentos Registrados [Internet]. 2023.  
Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
7.  Bernardi M, Lazzeri L, Perelli F, Reis FM, Petraglia F. Dysmenorrhea and related disorders. F1000Research  
[Internet]. 2017 Sep 5;6:1645. Available from: https://f1000research.com/articles/6-1645/v1  
8.  Febrasgo FB das A de G e O. Manual de Endometriose. 2015; Available from: chrome-  
extension://efaidnbmnnnibpcajpcglclefindmkaj/https://professor.pucgoias.edu.br/SiteDocente/admin/arquivosUpload/13162/m aterial/Manual Endometriose 2015.pdf  
9.  World Health Organization - WHO. Programme on Mental Health: WHOQOL User Manual. 2012;  
10. Nicolas-Boluda A, Oppenheimer A, Bouaziz J, Fauconnier A. Patient-Reported Outcome Measures in  
Endometriosis. J Clin Med [Internet]. 2021 Oct 30;10(21):5106. Available from: https://www.mdpi.com/2077-0383/10/21/5106  
11. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic  
reviews. Syst Rev. 2016;5(1):210.  
12. Higgins JP, Savović J, Page MJ SJ. Revised Cochrane risk of bias tool for randomized trials (RoB 2.0).  
2016;52.  
13. robins-i_-a-tool-for-assessing-risk-of-bias-in-non-randomised-studies-of-interventions.  
49  
14. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for  
systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ [Internet]. 2017 Sep 21;358(j4008):j4008. Available from: http://www.bmj.com/lookup/doi/10.1136/bmj.j4008  
15. COMET COM in ET-. COMET Database [Internet]. COMET. 2022. Available from: https://www.comet-  
initiative.org/Studies  
16. Gerlinger C, Schumacher U, Faustmann T, Colligs A, Schmitz H, Seitz C. Defining a minimal clinically  
important difference for endometriosis-associated pelvic pain measured on a visual analog scale: analyses of two placebocontrolled, randomized trials. Health Qual Life Outcomes [Internet]. 2010;8(1):138. Available from: http://hqlo.biomedcentral.com/articles/10.1186/1477-7525-8-138  
17. Guyatt GH; Oxman AD; Vist GE; et al. GRADE: an emerging consensus on rating quality of evidence and  
strength of recommendations. BMJ. 2008;336((7650)):924–6.  
18. Ministério da Saúde. Diretrizes Metodológicas: Sistema GRADE - manual de graduação da qualidade da  
evidência e força de recomendação para tomada de decisão em saúde. 2014.  
19. Alborzi S, Hamedi B, Omidvar A, Dehbashi S, Alborzi S, Alborzi M. A comparison of the effect of short-term  
aromatase inhibitor (letrozole) and GnRH agonist (triptorelin) versus case control on pregnancy rate and symptom and sign recurrence after laparoscopic treatment of endometriosis. Arch Gynecol Obstet. 2011;284(1):105–10.  
20. Almassinokiani F, Almasi A, Akbari P, Saberifard M. Effect of Letrozole on endometriosis-related pelvic pain.  
Med J Islam Repub Iran. 2014;28(1).  
21. Soysal S, Soysal ME, Ozer S, Gul N, Gezgin T. The effects of post-surgical administration of goserelin plus  
anastrozole compared to goserelin alone in patients with severe endometriosis: A prospective randomized trial. Hum Reprod. 2004;19(1):160–7.  
22. Roghaei MA, Tehrany HGT, Taherian A, Koleini N. Effects of Letrozole Compared with Danazol on Patients  
with Confirmed Endometriosis: A Randomized Clinical Trial.  
23. Acién P, Velasco I, Acién M. Anastrozole and levonorgrestrel-releasing intrauterine device in the treatment of  
endometriosis: a randomized clinical trial. BMC Womens Health [Internet]. 2021 Dec 20;21(1):211. Available from: https://bmcwomenshealth.biomedcentral.com/articles/10.1186/s12905-021-01347-9  
24. Agarwal SK, Foster WG. Reduction in Endometrioma Size with Three Months of Aromatase Inhibition and  
Progestin Add-Back. Biomed Res Int. 2015;2015:5–8.  
25. Chiu CC, Hsu TF, Jiang LY, Chan IS, Shih YC, Chang YH, et al. Maintenance Therapy for Preventing  
Endometrioma Recurrence after Endometriosis Resection Surgery – A Systematic Review and Network Meta-analysis. J Minim Invasive Gynecol [Internet]. 2022;29(5):602–12. Available from: https://doi.org/10.1016/j.jmig.2021.11.024  
26. Ferrero S, Camerini G, Seracchioli R, Ragni N, Venturini PL, Remorgida V. Letrozole combined with  
norethisterone acetate compared with norethisterone acetate alone in the treatment of pain symptoms caused by endometriosis. Hum Reprod. 2009;24(12):3033–41.  
27. Ferrero S, Venturini PL, Gillott DJ, Remorgida V. Letrozole and norethisterone acetate versus letrozole and  
triptorelin in the treatment of endometriosis related pain symptoms: A randomized controlled trial. Reprod Biol Endocrinol. 2011;9:1–7.  
28. Ferrero S, Gillott DJ, Venturini PL, Remorgida V. Use of aromatase inhibitors to treat endometriosis-related pain symptoms: A systematic review. Reprod Biol Endocrinol [Internet]. 2011;9(1):89. Available from: http://www.rbej.com/content/9/1/89  
50  
29. Lete I. Uso de inhibidores de la aromatasa en el tratamiento del dolor pélvico asociado a endometriosis: revisión sistemática. Clin Invest Ginecol Obstet [Internet]. 2022 Jan;49(1):100706. Available from:  
https://linkinghub.elsevier.com/retrieve/pii/S0210573X21000654  
30. Samy A, Taher A, Sileem SA, Abdelhakim AM, Fathi M, Haggag H, et al. Medical therapy options for endometriosis related pain, which is better? A systematic review and network meta-analysis of randomized controlled trials. J Gynecol Obstet Hum Reprod [Internet]. 2021;50(1):101798. Available from: https://doi.org/10.1016/j.jogoh.2020.101798  
31. Wattanayingcharoenchai R, Rattanasiri S, Charakorn C, Attia J, Thakkinstian A. Postoperative hormonal treatment for prevention of endometrioma recurrence after ovarian cystectomy: a systematic review and network meta-analysis. BJOG An Int J Obstet Gynaecol. 2021;128(1):25–35.  
32. Zajec V, Mikuš M, Vitale SG, D’alterio MN, Gregov M, Šarić MJ, et al. Current status and challenges of drug development for hormonal treatment of endometriosis: a systematic review of randomized control trials. Gynecol Endocrinol [Internet]. 2022;38(9):713–20. Available from: https://doi.org/10.1080/09513590.2022.2109145  
33. Zhang Y, Zhu Y, Sun J. Analysis of Adverse Events and Medical Errors in Long-Term Hormone Treatments for Endometriosis: A Study Based on the US Food and Drug Administration Event Reporting System. Int J Womens Health [Internet]. 2022 Sep;Volume 14:1237–50. Available from: https://www.dovepress.com/analysis-of-adverse-events-and-medicalerrors-in-long-term-hormone-tre-peer-reviewed-fulltext-article-IJWH  
34. Zhao Y, Luan X, Wang Y. Letrozole combined with oral contraceptives versus oral contraceptives alone in the treatment of endometriosis-related pain symptoms: a pilot study. Gynecol Endocrinol [Internet]. 2021;37(1):51–5. Available from: https://doi.org/10.1080/09513590.2020.1807502  
51  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Portaria Conjunta nº 54 - Endometriose | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**|||**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação o**|**u alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|||Incorporação do d<br>liberador<br>de<br>pacientes<br>com<br>contraindicação|ispositivo intrauterino<br>levonorgestrel<br>para<br>endometriose<br>com<br>ou não adesão aos|Nã iã d|
|Portaria<br>Conjunta<br>SAES-SAPS-||contraceptivos<br>[Portaria SECTI|orais<br>combinados<br>CS/MS nº 41/2025;|o ncorporaço o acetato<br>de noretisterona (10 mg) e<br>di|
|SCTIE/MS n`º`54/2026<br>[Relatório<br>de<br>Recomendação<br>nº<br>1050/2025]|Incorporação<br>de<br>tecnologias|Relatório<br>de<br>1002/2025]<br>Incorporação<br>d<br>tratamento da end<br>[Portaria SECTI<br>Relatório<br>de<br>1003/2025]|Recomendação<br>n<br>o<br>desogestrel<br>para<br>ometriose<br>CS/MS nº 43/2025;<br>Recomendação<br>nº|enogeste para tratamento<br>da endometriose [Portaria<br>SECTICS/MS nº 43/2025;<br>Relatório de Recomendação<br>nº 1003/2025]|
|Portaria<br>SAS/MS<br>nº<br>879, de 12/07/2016|Atualização<br>do<br>conteúdo|-||-|
|Portaria<br>SAS/MS<br>nº<br>144, de 31 de março de<br>2010|Primeira<br>versão<br>do<br>PCDT|-||-|  
52

---

