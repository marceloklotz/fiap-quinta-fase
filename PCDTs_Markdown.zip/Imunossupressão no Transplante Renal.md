<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: PORTARIA CONJUNTA Nº 1, DE 05 DE JANEIRO DE 2021 -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas para Imunossupressão em Transplante Renal.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre imunossupressão em transplante renal no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos nesta condição;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 549/2020 e o Relatório de Recomendação nº 555 – Setembro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Imunossupressão em Transplante Renal.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da imunossupressão em transplante renal, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-Pcdt,</u> é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da imunossupressão em transplante renal.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos nessa condição em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 712/SAS/MS, de 13 de agosto de 2014, publicada no Diário Oficial da União nº 155, de 14 de agosto  de 2014, seção 1, página 63.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: LUIZ OTAVIO FRANCO DUARTE -->
HÉLIO ANGOTTI NETO  
**ANEXO**  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS  
IMUNOSSUPRESSÃO EM TRANSPLANTE RENAL

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **1. INTRODUÇÃO** -->
O transplante renal é a opção terapêutica de escolha para pacientes com doença renal crônica em estágio terminal (estágio 5). Quando comparado à diálise, o transplante proporciona melhor sobrevida, melhor qualidade de vida e menor custo no longo prazo<sup>1-4</sup> .  
O Brasil é o segundo país em número absoluto de transplantes renais e o 25º quando esse número é calculado por milhão de população. No período de 1964 a 2019 foram realizados 113.032 transplantes renais, havendo um crescimento anual contínuo, principalmente pelo aumento de transplantes com rim de doador falecido. Estima-se que atualmente, em torno de 70 mil pacientes estejam em acompanhamento com enxerto renal funcionante. O País é uma referência mundial de financiamento público dos transplantes, sendo a maioria realizada pelo Sistema Único de Saúde (SUS), desde a avaliação pré-transplante, cirurgia, acompanhamento e distribuição dos medicamentos imunossupressores<sup>5-8</sup> .  
Segundo o DATASUS, em 2019 foram realizados pelo SUS 6.323 transplantes renais isolados e 130 transplantes duplos de pâncreas e rim.  
Após o transplante renal, os medicamentos imunossupressores são utilizados para prevenir as rejeições aguda e crônica. A imunossupressão visa a inibir o reconhecimento imunológico e a ativação da resposta alogênica celular e humoral e é dividida em duas fases: fase de indução e fase de manutenção. Adicionalmente, pode haver necessidade do tratamento das rejeições<sup>9, 10</sup> .  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da imunossupressão em transplante renal no Brasil. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- Z94.0 Rim transplantado  
- T86.1 Falência ou rejeição de transplante de rim

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **3. DIAGNÓSTICO DO RISCO IMUNOGÊNICO DO TRANSPLANTE** -->
A definição do risco imunogênico do transplante deve ser dada antes da realização do procedimento para a definição do esquema de indução. A definição é baseada nas características demográficas do doador e do receptor e em fatores de risco comprovadamente associados com maior risco de rejeição incluindo:  
1. Baixa compatibilidade HLA ( _Human leukocyte antigen_ )<sup>11-14</sup> ;  
2. eventos de sensibilização contra antígenos HLA por conta de gestações, transfusões de sangue e transplante prévio<sup>12-</sup>  
- 14;  
3. presença de anticorpos pré-formados específicos contra antígenos HLA do doador<sup>12-15</sup> ;  
4. disfunção inicial do enxerto<sup>12, 16</sup> .  
A partir destas características, o transplante é definido como de risco menor e maior, conforme **Quadro 1** .  
**Quadro 1 -** Classificação do risco imunológico do transplante  
|**Transplante com risco menor**|**Transplante com risco maior**|
|---|---|
| Receptores de transplante de doador vivo ou<br>falecido;| Receptores de transplante de doador vivo ou<br>falecido;|
| Não sensibilizados ou com baixo grau de<br>sensibilização;| Sensibilizados;<br> Com anticorpos pré-formados anti-HLA do doador|
| Sem anticorpos pré-formados anti-HLA do<br>doador;| Com baixa compatibilidade HLA; ou<br> Com risco de disfunção inicial do enxerto.|
| Com boa compatibilidade HLA; ou<br> Com função renal imediata.||

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **4.1. Diagnóstico clínico da rejeição aguda** -->
O diagnóstico clínico da rejeição aguda é baseado na presença de disfunção aguda do enxerto renal, que é caracterizada pela redução abrupta (dentro de 48h) da função renal, expressa pelo aumento absoluto da creatinina sérica de ≥ 0,3 mg/dL, um aumento percentual de ≥ 50% do seu valor basal ou redução do volume de diurese (< 0,5 mL/Kg/h por mais de 6h)<sup>17</sup> .  
Para o adequado diagnóstico da disfunção aguda do enxerto renal, preconiza-se primeiramente a exclusão de causas pré- e pós-renais, com a avaliação clínica do paciente e a realização de ultrassonografia com doppler e cultura de urina. Os diagnósticos diferenciais mais frequentes são a hipovolemia, a estenose de artéria renal, a infecção urinária e complicações urológicas. O diagnóstico diferencial com outras doenças do parênquima renal inclui a função retardada do enxerto (na fase inicial do transplante), a recidiva de doença primária, uma glomerulopatia de novo, a nefrite induzida pelo poliomavírus e a nefrotoxicidade por fármacos, incluindo os inibidores da calcineurina. Nessas situações o diagnóstico final é firmado somente após a avaliação da biópsia renal.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **4.2. Diagnóstico clínico da rejeição crônica** -->
O diagnóstico clínico da rejeição crônica é baseado na perda lenta e progressiva da função renal, com ou sem proteinúria, mais frequentemente observada após o primeiro ano do transplante. A investigação diagnóstica, que deve incluir a realização da biópsia renal, deve excluir o principal diagnóstico diferencial, que é a fibrose intersticial e atrofia tubular (FIAT) de origem não imunológica, resultado da progressão da perda de parênquima decorrente da história natural da doença renal crônica e de agressões ocorridas ao longo do transplante, como infecções, nefropatia por poliomavírus, nefrotoxicidade por inibidor de calcineurina, incluindo a microangiopatia trombótica, e doenças glomerulares<sup>18-20</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **4.3. Diagnóstico histológico da rejeição** -->
Após a exclusão das causas extra-renais de disfunção renal, preconiza-se a realização da biópsia renal para a confirmação dos possíveis diagnósticos diferenciais. Se o diagnóstico histológico for de rejeição aguda, o tipo e a gravidade podem ser classificados, orientando o tratamento e determinando o prognóstico a curto e longo prazo. Preconiza-se que o exame histológico de enxerto renal inclua:  
1. Microscopia óptica;  
2. pesquisa da deposição do fator do complemento C4d no tecido renal por imunohistoquímica ou por  
imunofluorescência (para auxílio diagnóstico de rejeições mediadas por anticorpos);  
3. pesquisa de deposição de imunoglobulinas e suas frações e frações do complemento no tecido renal por  
imunofluorescência (para diagnóstico das doenças glomerulares, de novo ou recidivantes);  
4. pesquisa do antígeno SV40 por imunohistoquímica no tecido renal (para diagnóstico de nefropatia por  
poliomavírus).  
Para o diagnóstico diferencial de doenças renais após o transplante, a microscopia eletrônica pode ser necessária para a confirmação diagnóstica.  
Quando as alterações histológicas sugerirem o diagnóstico de rejeição mediada por anticorpos (RMA) será necessário a determinação no sangue da presença de anticorpos específicos contra os antígenos HLA do doador para sua confirmação.  
Em situações de elevada suspeita para rejeição aguda e na impossibilidade de diagnóstico histológico ágil, o tratamento pode ser considerado e a biópsia programada caso não haja melhora clínica. Em situações em que o diagnóstico histológico é incerto ou limítrofe e há elevada suspeição para rejeição aguda, o tratamento pode igualmente ser considerado (vide seção Tratamento).

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **4.4. Classificação histológica da biópsia do enxerto renal** -->
A biópsia do enxerto renal é categorizada de acordo com a Classificação Internacional de Banff<sup>(21)</sup> .  
**Categoria 1:** Biópsia normal ou achados inespecíficos  
**Categoria 2:** Alterações mediadas por anticorpos

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **a.** <u>Rejeição mediada por anticorpo ativa</u> -->
Deve atender os três critérios abaixo:  
1. Evidência histológica de dano tecidual agudo, incluindo pelo menos um dos seguintes: inflamação microvascular  
(glomerulite ou pericapilarite), arterite intimal ou transmural, microangiopatia trombótica ou necrose tubular aguda sem causa aparente;  
2. evidência de interação recente/atual entre o anticorpo e o endotélio vascular, incluindo pelo menos um dos seguintes: C4d positivo em capilares peritubulares, inflamação microvascular moderada ou aumento da expressão gênica de transcritos associados à rejeição mediada por anticorpos; e  
3. evidência de anticorpo circulante específico contra HLA do doador.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **b.** <u>Rejeição mediada por anticorpo crônica ativa</u> -->
Deve atender os três critérios abaixo:  
1. Evidência histológica de dano tecidual crônico, incluindo pelo menos um dos seguintes: glomerulopatia do transplante, duplicação da membrana basal do capilar peritubular, fibrose intimal arterial de início recente;  
2. idêntico ao critério 2 da rejeição mediada por anticorpo ativa; e  
3. idêntico ao critério 3 da rejeição mediada por anticorpo ativa.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **c.** <u>Rejeição mediada por anticorpo crônica (inativa)</u> -->
Glomerulopatia do transplante ou delaminação da membrana basal do capilar peritubular na ausência de critérios de  
interação recente/atual do anticorpo com o endotélio, mas com um diagnóstico prévio de rejeição mediada por anticorpos ativa ou crônica ativa ou evidência prévia de anticorpos específicos contra o doador.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **d.** <u>C4d positivo sem evidência de rejeição</u> -->
Deve atender os quatro critérios abaixo:  
1. Positividade para C4d em capilar peritubular por IF ou IHC;  
2. critério 1 para rejeição ativa ou crônica ativa não atendido;  
3. sem evidência molecular (expressão de transcritos gênicos) sugestivos de rejeição mediada por anticorpos ativa ou  
crônica ativa; e  
4. sem rejeição celular aguda ou crônica ativa ou alterações limítrofes.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Categoria 3: Alterações limítrofes - Suspeita para rejeição aguda mediada por célula T** -->
Focos de tubulite com inflamação intersticial mínima; ou inflamação intersticial moderada-grave com tubulite leve;  
sem vasculite.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **a.** <u>Rejeição aguda mediada por célula T (RAMCT)</u> -->
- RAMCT IA: Inflamação intersticial acometendo >25% do parênquima cortical não esclerótico com tubulite moderada acometendo 1 ou mais túbulos de áreas não atróficas.  
- RAMCT IB: Inflamação intersticial acometendo >25% do parênquima cortical não esclerótico com tubulite grave acometendo 1 ou mais túbulos de áreas não atróficas.  
- RAMCT IIA: Arterite intimal leve a moderada, com ou sem infiltrado intersticial ou tubulite.  
- RAMCT IIB: Arterite intimal grave, com ou sem infiltrado intersticial ou tubulite.  
- RAMCT III: Arterite transmural ou necrose fibrinoide da camada muscular média com arterite intimal, com ou sem inflamação intersticial ou tubulite.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **b.** <u>Rejeição crônica ativa mediada por células T (RCMCT)</u> -->
- RCMCT IA: Inflamação intersticial acometendo >25% do córtex total e >25% do parênquima cortical esclerótico, com tubulite moderada acometendo 1 ou mais túbulos de áreas não atróficas.  
- RCMCT IB: Inflamação intersticial acometendo >25% do córtex total e >25% do parênquima cortical esclerótico, com tubulite grave acometendo 1 ou mais túbulos de áreas não atróficas.  
- RMCT II: Arteriopatia crônica do enxerto (fibrose arterial intimal com inflamação mononuclear e formação de neoíntima).

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Categoria 5: Nefropatia por poliomavírus** -->
**Classe 1:** Inclusões virais em ≤1% dos túbulos, com fibrose intersticial leve ou ausente.  
**Classe 2** : Inclusões virais em ≤1% dos túbulos, com tubulite moderada a grave ou; inclusões virais em 1%-10 % dos túbulos, independente do geral de fibrose intersticial ou; inclusões virais em ≥10% dos túbulos, com fibrose intersticial leve ou ausente.  
**Classe 3** :  Inclusões virais em ≥10% dos túbulos, com fibrose intersticial moderada a grave.  
Ao diagnóstico histopatológico é possível a coexistência de rejeição mediada por anticorpos e por célula T.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo: **1)** todos os indivíduos submetidos a transplante renal, conforme o Regulamento Técnico vigente do Sistema Nacional de Transplantes, e **2)** os transplantados com diagnóstico clínico ou histológico de rejeição aguda ou crônica.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
- Serão excluídos deste Protocolo os pacientes não submetidos a transplante renal e também os receptores de transplante renal com condições clínicas cujo risco associado à imunossupressão é maior do que o provável benefício terapêutico.  
- Serão excluídos os indivíduos que apresentarem intolerância, hipersensibilidade ou contraindicação ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7. TERAPÊUTICA IMUNOSSUPRESSORA** -->
A imunossupressão é dividida em duas fases: indução da imunossupressão e manutenção, podendo haver necessidade de tratamento da rejeição. Para pacientes com anticorpos pré-formados anti-HLA do doador, são adicionalmente descritas as terapias de dessensibilização.  
A indução da imunossupressão (terapia de indução) é caracterizada pela utilização de agentes biológicos que inibem a atividade do linfócito T. É utilizada imediatamente antes do transplante, durante o procedimento ou no período perioperatório precoce (primeira semana após o transplante). Seu objetivo principal é aumentar a eficácia da imunossupressão, a fim de reduzir o risco de rejeição ou permitir a minimização dos componentes do esquema de manutenção<sup>17</sup> .  
A terapia de manutenção (manutenção da imunossupressão) é caracterizada pela utilização em longo prazo de uma combinação de fármacos imunossupressores, com o objetivo de prevenir a rejeição, preservando a função renal e minimizando os efeitos adversos. Pode ser iniciada dias antes do transplante ou até 24h após a cirurgia<sup>17</sup> .  
Uma vez que as condutas acima tenham falhado em prevenir os eventos imunomediados e a rejeição ocorra, este episódio deve ser tratado. Assim, o tratamento da rejeição é caracterizado pela utilização de agentes imunossupressores em elevadas doses com o objetivo de reduzir a agressão da resposta imune celular ou mediada por anticorpos no enxerto renal<sup>17</sup> .  
A terapia de dessensibilização é caracterizada pela utilização de agentes biológicos ou técnicas não medicamentosas que inibem a atividade do linfócito B ou do plasmócito, bem como modulam ou removem anticorpos da circulação. Pode ser indicada para indivíduos com anticorpos pré-formados anti-HLA do doador antes ou após o transplante. O tratamento anterior ao transplante objetiva permitir a negativação da prova cruzada e o acesso ao transplante, não sendo, portanto, objeto deste Protocolo. Seu uso após o transplante objetiva reduzir o risco de rejeições mediadas por anticorpos<sup>22, 23</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.1. Indução da imunossupressão** -->
Os agentes disponíveis para terapia de indução são os corticosteroides (metilprednisolona), o anticorpo anti-receptor de interleucina-2 (basiliximabe) e a imunoglobulina antitimócitos humanos (coelho) ou timoglobulina.  
Preconiza-se que todos os receptores de transplante renal recebam metilprednisolona endovenosa no intra-operatório. Adicionalmente, para aqueles de menor risco (vide o **Quadro 1** ), preconiza-se o uso de basiliximabe<sup>24</sup> . Aos pacientes de risco maior, a timoglobulina é preconizada<sup>25-29</sup> . ( **Figura 1** ).  
Em transplantes de menor risco em que se planeja imunossupressão de manutenção de baixa eficácia, ou com minimização ou eliminação de algum dos fármacos do esquema (regime, na **Figura 1** ), a indução com timoglobulina pode ser considerada<sup>12, 30-33</sup> .  
<!-- Start of picture text -->
Regime manutengao Regime<br>triplo sem manutengao com<br>minimizagao minimizagao<br>Basiliximabe Timoglobulina<br><!-- End of picture text -->  
**Figura 1 -** Fluxograma de tratamento da indução da imunossupressão

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.2. Manutenção da imunossupressão** -->
Preconiza-se a associação de um inibidor da calcineurina (ciclosporina ou tacrolimo) com fármaco anti-proliferativo (azatioprina ou micofenolato de mofetila ou sódico), ou um inibidor da _mammalian target of rapamicyn_ (mTOR) (sirolimo e everolimo) e corticosteroides (prednisona). Após a escolha do esquema de imunossupressão inicial, mudanças posteriores, como minimizações e conversões, apenas são preconizadas quando motivadas por eventos adversos relacionados à falência de eficácia ou de segurança<sup>34</sup> .  
Os esquemas de manutenção da imunossupressão estão sumarizados na **Figura 2** , conforme o risco imunogênico.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.2.1. Esquemas de manutenção da imunossupressão** -->
Preconiza-se individualizar o esquema imunossupressor de manutenção, a depender das características da combinação doador-receptor<sup>12, 35, 36</sup> .  
Seguem as combinações possíveis:

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Tacrolimo + micofenolatos** -->
Trata-se de um esquema de elevada eficácia na prevenção de rejeição aguda celular e mediada por anticorpos. Por isto, é considerado o padrão de tratamento para pacientes de alto risco e também uma das opções para pacientes de baixo risco<sup>36-38</sup> . Segundo recomendações de bula, quando esta combinação é utilizada, a concentração sanguínea de tacrolimo deve ser mantida entre 4-11 ng/mL durante todo o período do transplante<sup>39, 40</sup> . Para pacientes de baixo risco, que receberam terapia de indução e em uso de esteroides, evidências sugerem que menores exposições (3-7 ng/mL) são eficazes na prevenção de rejeição<sup>37</sup> . Entretanto, exposições abaixo de 5-7 ng/mL devem ser evitadas em indivíduos de maior risco imunológico, nos que não receberam indução e nos esquemas livres de esteroides<sup>41</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Tacrolimo + azatioprina** -->
A utilização de azatioprina em combinação com tacrolimo é uma boa opção para pacientes de baixo risco imunológico. Apesar de estar associada a maior incidência de rejeição aguda, este esquema proporciona sobrevida do enxerto e do paciente em longo prazo similar à do esquema baseado em tacrolimo + micofenolato, com o benefício de menor incidência de doença invasiva por CMV e eventos adversos gastrointestinais<sup>42-45</sup> .  
Em pacientes em uso combinado de tacrolimo e azatioprina, a concentração de vale (C0) de tacrolimo recomendada por bula nos primeiros 3 meses é de 7-20 ng/mL e 5-15 ng/mL a partir de então<sup>40</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Tacrolimo + inibidor da mTOR** -->
Outra opção de esquema inicial é a combinação de tacrolimo a um inibidor da mTOR, sirolimo ou everolimo. Evidências apontam que esta associação é tão eficaz quanto tacrolimo + micofenolato na prevenção de rejeição aguda e está associada à significativa menor incidência de eventos por citomegalovírus, notadamente em pacientes com sorologia IgG positiva para CMV antes do transplante<sup>33, 46-52</sup> . Para pacientes em uso de inibidores da mTOR, a concentração alvo de tacrolimo é de 3-8 ng/mL<sup>46</sup> . A concentração alvo de everolimo para combinações com tacrolimo varia de 3 a 8 ng/mL<sup>46</sup> . Quanto ao sirolimo, estudos apontam para eficácia com concentrações entre 5-10ng/mL<sup>53</sup> .  
Ao optar-se pela combinação de um inibidor da calcineurina e um inibidor da mTOR, é importante atentar para a interação farmacocinética e farmacodinâmica entre estas classes de fármacos, o que resulta em maior risco de nefrotoxicidade e consequente comprometimento da função renal<sup>54, 55</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Ciclosporina + micofenolatos / azatioprina / inibidor da mTOR** -->
A ciclosporina é uma alternativa para pacientes em que se deseja evitar os principais efeitos indesejáveis do tacrolimo (diabetes e sintomas gastrointestinais). Também é uma opção para crianças pequenas, que não conseguem engolir a cápsula de tacrolimo ou quando se prevê que a dose mínima permitida de tacrolimo (1 mg de 12/12h) resultará em concentrações acima do alvo. O uso de ciclosporina está associado a maior incidência de rejeição aguda, mas as evidências não são uniformes quanto ao impacto disto na sobrevida do enxerto<sup>56, 57</sup> .  A combinação ciclosporina e azatioprina deve ser reservada a paciente de muito baixo risco. Em pacientes em uso combinado de ciclosporina com fármacos antiproliferativos (azatioprina ou micofenolato), a concentração C0 preconizada é de 150-300 ng/mL até o terceiro mês e entre 100-200 ng/mL após este período<sup>37</sup> . Em pacientes em uso combinado com inibidores da mTOR (sirolimo ou everolimo), a C0 preconizada é de 100200 ng/mL até o segundo mês, 75-150 ng/mL entre segundo e quarto meses, 50-100 ng/mL entre quarto e sexto meses e 2550 ng/mL após sexto mês<sup>47</sup> . Ao combinar ciclosporina com sirolimo, este deve ser administrado 4h após a tomada da ciclosporina<sup>58</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Inibidor da mTOR + micofenolatos/azatioprina** -->
Em situações de exceção em que os inibidores de calcineurina precisam ser evitados, os inibidores da mTOR (sirolimo ou everolimo) podem ser combinados aos antiproliferativos (micofenolatos ou azatioprina). Este esquema, que está associado a maior incidência de rejeição e maior risco de eventos adversos hematológicos, deve ser reservada a pacientes de baixo risco imunológico<sup>59-61</sup> .  A concentração de sirolimo nestes esquemas deve ser mantida entre 8-12 ng/mL e a de everolimo entre 6- 10ng/mL<sup>62-64</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Esquemas livres de corticosteroides** -->
Em todos os esquemas mencionados acima, a composição padrão inclui um corticosteroide. Esquemas livres de corticosteroide podem ser considerados em pacientes de baixo risco imunológico, notadamente aqueles com maior risco de desenvolver os eventos adversos associados ao uso crônico destes fármacos, como crianças, idosos, obesos e diabético<sup>65)</sup> . A retirada dos corticoisteroides pode ser feita precocemente, em até cinco a sete dias após o transplante, ou tardiamente, entre 3 e 12 meses após o transplante. Caso seja optado por um esquema livre de esteroides, preconiza-se que seja realizada indução com timoglobulina e que seja evitada a minimização dos outros fármacos que compõem o esquema<sup>66-68</sup> . Os esquemas com retirada dos corticosteroides estão associados a maior incidência de rejeição aguda<sup>69-74</sup> .  
<!-- Start of picture text -->
Menor risco Maior risco<br>TAC + MPS/MMF TAC + PRED + MPS/MMF<br>TAC + PRED + AZA (↓ incidência de CMV, ↑<br>incidência de rejeição)<br>TAC/CsA + PRED + SRL/EVR (↓ incidência de<br>CMV, ↑ risco de nefrotoxicidade)<br>CsA + PRED + AZA (↑ incidência de rejeição,<br>↓eventos adversos gastrointestinais,↓incidência<br>de diabetes pós-transplante)<br>CsA + PRED + MPS/MMF  (↑ incidência de<br>rejeição aguda,↓incidência de diabetes pós-<br>transplante)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Esquemas livres de corticosteroides** -->
SRL/EVR + PRED + AZA  (↑ incidência de rejeição aguda,↑ citopenias, ↓risco de nefrotoxicidade) SRL/EVR + PRED + MPS/MMF  (↑ incidência de rejeição aguda,↑ citopenias, ↓risco de nefrotoxicidade) Regimes sem PRED  (↑ incidência de rejeição aguda, ↓risco e melhor controle de diabetes)  
TAC=tacrolimo; CSA=ciclosporina; MPS=micofenolato sódico; MMF=micofenolato de mofetila; AZA=azatioprina; PRED=prednisona; SRL=sirolimo; EVR=everolimo. As setas que acompanham os desfechos de eficácia e segurança se referem à comparação com o esquema baseado em TAC + MPS/MMF

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.3. Tratamento da rejeição aguda** -->
O tratamento da rejeição aguda depende da apresentação clínica e do diagnóstico histológico. O arsenal terapêutico inclui metilprednisolona, timoglobulina, imunoglobulina humana e plasmaferese.  Além do tratamento específico, em todos os episódios de rejeição deve-se avaliar a aderência do receptor de transplante renal ao esquema de imunossupressão, incluindo as doses diárias e as concentrações sanguíneas recomendadas. A mudança para um esquema de imunossupressão alternativo deve ser individualizada, baseado na análise dos fatores de risco e da segurança do novo esquema.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.3.1. Tratamento da rejeição aguda celular** -->
O tratamento dos episódios de rejeição aguda celular consiste em uso de pulsoterapia com metilprednisolona ou timoglobulina.  
Uma biópsia renal deve ser realizada antes do tratamento sempre que possível. A metilprednisolona está indicada como primeira escolha para o tratamento da rejeição aguda categoria 4 do Banff: Rejeição mediada por célula T (RMCT) IA, IB, IIA*<sup>17</sup> .  
Pacientes com resultado histopatológico de Categoria 3 (suspeita de rejeição mediada por célula T) devem receber metilprednisolona desde que haja elevada suspeita clínica para rejeição aguda<sup>75</sup> .  
Na ausência de diagnóstico histopatológico (por impossibilidade de se proceder à biópsia ou por amostra pouco representativa), o tratamento com metilprednisolona deve também ser indicado se houver elevada suspeita clínica. Preconizase a realização de uma biópsia de seguimento se não for observada a recuperação completa da função renal.  
O tratamento com administração de timoglobulina está indicado para:  
- **a.** Rejeição resistente ao tratamento com metilprednisolona (recomenda-se a comprovação histopatológica)<sup>76</sup> .  
- **b.** Categoria 4 do Banff: Rejeição mediada por célula T aguda Tipo IIA (mais graves), IIB ou III<sup>77</sup> .  
<u>Nota: Em caso de rejeições vasculares (IIA), a decisão por metilprednisolona ou timoglobulina deve levar em</u> consideração a gravidade da apresentação clínica, a cronicidade histológica do parênquima renal e o risco de eventos adversos.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.3.2. Tratamento da rejeição aguda mediada por anticorpos** -->
O tratamento dos episódios de rejeição aguda mediada por anticorpos consiste em sessões de plasmaférese associadas à administração de imunoglobulina humana. Inexiste consenso quanto à melhor forma de combinar estas terapias<sup>17,</sup> 78, 79.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.3.3. Tratamento da rejeição celular crônica ativa** -->
Inclui os pacientes com diagnóstico histológico de rejeição mediada por célula T crônica ativa dos tipos IA, IB ou  
II pela classificação de Banff. Não há evidências robustas que suportem tratamento de resgate para pacientes com rejeição crônica celular. Pode-se prescrever pulsoterapia com metilprednisolona. A adesão ao esquema imunossupressor prescrito deve ser investigada. Caso má adesão seja descartada, o esquema imunossupressor deve ser revisto, incluindo doses e concentrações. Mudanças para esquemas de maior eficácia podem ser considerados.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.3.4. Tratamento da rejeição mediada por anticorpo crônica ativa** -->
Inexistem evidências consistentes que justifiquem o tratamento de resgate em caso de pacientes com rejeição mediada por anticorpo crônica ativa. Dependendo da presença do DSA e do nível de função renal pode-se tentar o tratamento com sessões de plasmaferese associada à administração de imunoglobulina humana<sup>79-82</sup> . Não há consenso quanto à melhor forma de combinar estas terapias. A adesão ao esquema imunossupressor prescrito deve ser investigada. Caso a má adesão seja descartada, o esquema imunossupressor deve ser revisto, incluindo doses e concentrações. Mudanças para esquemas de maior eficácia podem ser consideradas<sup>83</sup> .  
O tratamento da rejeição aguda e crônica está sistematizado na **Figura 3** .  
<!-- Start of picture text -->
Mediada por<br>Metilprednisolona Timoglobulina Plasmaferese+<br>Imunoglobulina<br>humana<br>* Escolha do tratamento das rejeices celulares agudas Banff IIA dependera da gravidade da<br>apresentacdo, da cronicidade do enxerto e do quadro clinico do paciente.<br>Em todos os pacientes a imunossupress4o deve ser revista a ma aderéncia deve ser<br>investigada.<br>Pacientes com elevada suspeita de rejeico podem ser tratados com com pulsoterapia com<br>metilprednisolona na auséncia de comprovacao histoldgica. Isto se aplica também aos casos<br>onde a bidpsia n&o foi condusiva (Suspeita para a rejei¢ao).<br><!-- End of picture text -->  
**Figura 3 -** Tratamento da rejeição aguda e crônica

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.4. Dessensibilização pós-transplante** -->
Em receptores de transplante renal com anticorpos pré-formados específicos contra os antígenos HLA do doador uma terapia para remoção e modulação dos anticorpos pode ser necessária. Sessões de plasmaferese e imunoglobulina humana após o transplante podem ser consideradas nestes pacientes<sup>22, 23, 78, 84</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.5. Fármacos** -->
- Ciclosporina: cápsulas de 10, 25, 50 e 100 mg; solução oral de 100 mg/mL (frascos de 50 mL); 50 mg (solução injetável).  
- Tacrolimo: cápsulas de 1 e 5 mg e solução injetável de 5 mg/mL.  
- Azatioprina: comprimido de 50 mg.  
- Prednisona: comprimidos de 5 e 20 mg.  
- Prednisolona: solução oral de 1 mg/mL e 3 mg/mL.  
- Metilprednisolona: solução injetável de 500 mg.  
- Micofenolato de mofetila: comprimido de 500 mg.  
- Micofenolato de sódio: comprimidos de 180 e 360 mg.  
- Sirolimo: drágeas de 1 e 2 mg.  
- Everolimo: comprimidos de 0,5, 0,75 e 1 mg.  
- Imunoglobulina humana: frascos de 0,5, 1,0, 2,5 e 5,0 g.  
- Basiliximabe: frasco-ampola de 20 mg.  
- Imunoglobulina antitimócitos humanos (obtida de coelho)/timoglobulina: frasco ampola de 25 mg.  
**7.6. Esquemas de administração**  
**Indução**  
- **Metilprednisolona:** 250 a 1.000mg no intra-operatório. Em crianças, a dose é de 30mg/Kg. Doses adicionais no pósoperatório a depender do protocolo do serviço<sup>85</sup> .  
- **Basiliximabe:** 20mg IV no intra-operatório e 20mg IV no quarto dia de pós-operatório. Para crianças abaixo de 35 kg, preconizam-se doses de 10mg<sup>86</sup> .  
- **Imunoglobulina antitimócitos humanos (obtida de coelho)/timoglobulina** : 3,0 – 7,5 mg/Kg (dose total), com  
- administração iniciada antes, durante ou após o implante do enxerto. Não há consenso sobre a melhor forma de administrar a dose total planejada, nem quanto ao melhor momento de iniciar (pré, trans ou pós-operatório). Para minimizar eventos adversos relacionados à infusão, recomenda-se fracionar a dose total em múltiplos de 1,5-3mg/Kg e utilizar um acesso central ou uma veia periférica calibrosa<sup>87, 88</sup> .  
- **Imunoglobulina humana:** 2g/Kg, administrada em dose única ou fracionada (2 a 5 dias), a depender do protocolo do serviço. Para minimizar eventos adversos relacionados à infusão, preconiza-se fracionar a dose total em múltiplos de 1g/Kg ou menos<sup>89</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Manutenção** -->
- **Prednisona ou prednisolona:** Variável de acordo com o protocolo do serviço. Preconiza-se iniciar com 0,5 mg/Kg a 1mg/Kg/dia com desmame gradual, objetivando a dose de manutenção de 5 mg em 1 a 3 meses<sup>90</sup> .  
- **Ciclosporina:** A dose inicial preconizada é 3 a 6 mg/Kg a cada 12h, por via oral, ajustada a seguir de acordo com a concentração sanguínea. Uma vez que a dose depende do monitoramento terapêutico, não há recomendação para dose máxima. **Monitorização terapêutica:** A dose de ciclosporina deve ser ajustada regularmente para manter sua concentração no sangue total imediatamente antes [concentração residual ou de vale (C0)] ou 2 horas após (C2) a sua administração matinal dentro de faixas terapêuticas predeterminadas. |Preconiza-se que a primeira determinação seja obtida 2-3 dias após o início do tratamento. As concentrações alvo dependem do esquema e estão descritas no item “Esquemas de Imunossupressão”<sup>91</sup> .  
- **Tacrolimo:** A dose inicial preconizada para adultos é de 0,05 a 0,15 mg/Kg de 12 em 12h. Para crianças, doses iniciais de até 0,3 mg/Kg de 12 em 12h são reportadas. Uma vez que a dose depende do monitoramento terapêutico, não há recomendação para dose máxima. **Monitorização terapêutica:** A dose de tacrolimo deve ser ajustada regularmente para manter sua concentração no sangue total imediatamente antes [concentração residual ou de vale (C0)] da sua administração matinal dentro de faixas terapêuticas predeterminadas. Preconiza-se que a primeira determinação seja obtida 2-3 dias após o início do tratamento. As concentrações alvo dependem do esquema e foram descritas no item “Esquemas de Imunossupressão”<sup>40</sup> .  
- **Azatioprina:** De acordo com a bula, a dose recomendada é de 1 a 4 mg/Kg/dia, em dose única. Para pacientes em uso de esquema imunossupressor triplo, preconiza-se a dose 1,5-2mg/Kg/dia.  
- **Micofenolato de mofetila:** 1.000 mg de 12h em 12h. **Monitorização terapêutica:** A medida da área sob a curva da concentração de ácido micofenólico (MPA) está disponível para comercialização e pode ser útil em algumas situações, mas seu uso rotineiro são se associa a melhores desfechos quando comparado ao uso de dose fixa de micofenolato, não sendo indicada na prática clínica<sup>92-94</sup> .  
- **Micofenolato sódico:** 720 mg de 12h em 12h. **Monitorização terapêutica:** A medida da área sob a curva da concentração de ácido micofenólico (MPA) está disponível para comercialização e pode ser útil em algumas situações, mas seu uso rotineiro são se associa a melhores desfechos quando comparado ao uso de dose fixa de micofenolato, não sendo indicada na prática clínica<sup>93-95</sup> .  
- **Sirolimo:** A dose inicial preconizada é de 2 a 5 mg em dose única diária, a depender do esquema imunossupressor. Para pacientes submetidos a terapia de indução, não se preconiza a dose de ataque. Para pacientes não induzidos, dose de ataque de 6 a 10mg no primeiro dia pode ser considerada, em virtude da baixa disponibilidade do fármaco. Neste caso, há maior risco de complicações cirúrgicas<sup>96, 97</sup> . Os ajustes de dose dependem do monitoramento terapêutico, portanto não  
há recomendação para dose máxima. Os estudos são bastante heterogênos quanto à dose inicial para crianças<sup>98</sup> . **Monitorização terapêutica:** é realizada com a dosagem da C0, iniciada a partir de 7 dias após a primeira tomada. As concentrações alvo dependem do esquema e foram descritas no item “Esquemas de Imunossupressão”<sup>99</sup> .  
- **Everolimo:** Preconiza-se a dose inicial 1,5 mg de 12 em 12h. Para esquema inicial em combinação com ciclosporina, a dose inicial deve ser de 0,75 mg de 12 em 12h. Os ajustes de dose dependem do monitoramento terapêutico, portanto não há recomendação para dose máxima. A dose inicial para crianças sob esquemas com ciclosporina é de 0,8 mg/m<sup>2</sup> de 12 em 12h<sup>100, 101</sup> . Para associação com tacrolimo, a dose inicial é de 2mg/m<sup>2</sup> de 12 em 12h<sup>102</sup> . **Monitorização terapêutica:** É feita com a dosagem da C0, iniciada a partir de 3 a 5 dias após a primeira tomada. As concentrações alvo dependem do esquema e foram descritas no item “Esquemas de Imunossupressão”<sup>103</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **Tratamento de rejeição aguda** -->
- **Metilprednisolona** : 5 a 10 mg/kg intravenoso por 3 a 5 dias, usualmente 250 a 1.000 mg/dia<sup>85</sup> .  
- **Imunoglobulina antitimócitos humanos (obtida de coelho)/timoglobulina:** 1,0 mg/kg/dia por 7 a 14 dias<sup>88</sup> .  
- **Imunoglobulina humana:** Inexistem evidências sobre a posologia da imunoglobulina humana para o tratamento da rejeição aguda mediada por anticorpos. São reportadas doses de 100-500 mg/Kg em dias alternados, após as sessões de plasmaférese, até obter-se resposta clínico-laboratorial e histopatológica. Alternativamente, é descrito o uso de dose total de 2g/Kg, administrada de uma só vez ou fracionada em 2 a 5 dias<sup>104</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.7. Benefícios esperados** -->
- Redução das taxas de rejeição aguda e crônica;  
- Aumento da sobrevida do enxerto (sem necessidade de diálise);  
- Aumento da sobrevida do paciente;  
- Melhora na qualidade de vida.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.8.1. Imunossupressão em pacientes com câncer** -->
A terapia imunossupressora em pacientes transplantados renais que desenvolvem neoplasias deve levar em consideração múltiplos aspectos clínicos e epidemiológicos. Quando comparada com a população geral, a incidência global de neoplasias de novo é 2 a 4 vezes maior em todos os receptores de transplante de órgãos sólidos<sup>105-107</sup> . A taxa de incidência padronizada (SIR) para qualquer câncer varia entre 2,4 e 6,5 para receptores de transplantes renais e, até 20 anos após o transplante quase 50% desses receptores têm um ou mais cânceres de pele e 10% a 27% de câncer não-cutâneo<sup>107-111</sup> .  
Revisão sistemática recente relata que o risco de mortalidade por todas as causas, mortalidade específica por câncer e de desenvolvimento de neoplasias de novo após o transplante está aumentado em receptores de órgãos sólidos com malignidades pré-transplante em comparação com aqueles sem malignidade pré-transplante<sup>112</sup> .  
Diretrizes atuais sobre a seleção de pacientes para transplante renal sugerem que nenhum tempo de espera é necessário para indivíduos com carcinoma de células renais (CCR) de tamanho pequeno ou incidentalmente descoberto, enquanto as recomendações para pacientes que foram tratados para um CCR sintomático ou para aqueles com tumores grandes ou invasivos são conflitantes. Os demais pacientes devem ser cuidadosamente avaliados por um oncologista antes de serem incluídos em listas para o transplante, enfocando a avaliação do risco de câncer em pessoas já tratadas para malignidade recebendo terapia imunossupressora em longo prazo<sup>112</sup> .  
Na decisão de reduzir ou suspender os medicamentos imunossupressores em receptores de transplantes renais com câncer deve-se levar em consideração<sup>17</sup> :  
- O estágio do câncer no momento do diagnóstico;  
- se o câncer pode ser exacerbado por imunossupressão;  
- as terapias disponíveis para o câncer;  
- se os medicamentos imunossupressores interferem com a quimioterapia;  
- a redução da qualidade de vida resultante da perda do enxerto versus o risco de reduzir a  imunossupressão;  
- para pacientes com sarcoma de Kaposi, usar inibidores da mTOR juntamente com uma redução na imunossupressão geral<sup>17</sup> .  
- Os inibidores mTOR têm sido utilizados após tratamento de linfomas e como terapia adjuvante em pacientes com carcinoma espinocelular ou basocelular de pele<sup>113</sup> .  
Nos receptores de transplantes renais, fazer triagem para os seguintes tipos de câncer, de acordo com as diretrizes locais  
para a população em geral:  
- Mulheres: câncer do colo do útero, da mama e do cólon;  
- homens: câncer de próstata e cólon;  
- pacientes com cirrose compensada: ultrassonografia hepática e alfa feto-proteína a cada 12 meses<sup>17</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **7.8.2. Gravidez e lactação** -->
Gestações em pacientes transplantadas renais são consideradas de alto risco. Desta forma, recomenda-se que a gravidez após o transplante seja planejada em conjunto com a equipe de nefrologia e obstetrícia e evitada no primeiro ano após o transplante, em pacientes instáveis clinicamente, naquelas proteinúricas, em pacientes com eventos imunomediados recentes, com hipertensão sem controle, com modificações recentes no esquema imunossupressor ou com disfunção do enxerto renal (creatinina > 1,5mg/dL)<sup>114, 115</sup> .  
Tacrolimo, ciclosporina, azatioprina e esteroides são considerados seguros durante a gestação. Por outro lado, o micofenolato sódico ou mofetila estão associados a um aumento no risco de abortos espontâneos e malformações fetais<sup>115</sup> . Sobre os inibidores da mTOR, há poucas informações sobre a segurança no uso durante a gravidez. Assim recomenda-se que sejam evitados na gravidez e que tenham seu uso suspenso pelo menos 6 semanas antes da data planejada da concepção e o esquema de manutenção seja baseado em um inibidor da calcineurina (ciclosporina ou tacrolimo), prednisona e azatioprina<sup>115,</sup> 116.  
Durante a gravidez, é recomendado o monitoramento terapêutico atento e frequente dos inibidores da calcineurina, uma vez que mudanças farmacocinéticas podem ocorrer decorrentes de aumento da atividade enzimática, aumento no volume de distribuição e mudanças na disponibilidade de proteínas ligadoras e transportadoras de fármacos, resultando em aumento na dose necessária para manter a concentração alvo<sup>115, 117, 118</sup> .  
Evidências apontam que a exposição neonatal aos inibidores da calcineurina, esteroides e azatioprina é muito baixa durante a lactação, sendo sugerida a manutenção do aleitamento em lactantes em uso destes fármacos. As evidências da segurança da lactação para pacientes em uso de inibidores da mTOR e micofenolatos é escassa, não sendo esse uso, portanto, recomendado<sup>115, 119</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **8. MONITORAMENTO** -->
O sucesso do transplante renal depende de um cuidadoso esquema de atenção que se estende por toda a vida. Não se pode deixar de enfatizar ao paciente e a seus familiares que o ato cirúrgico é apenas a primeira etapa de um tratamento e que o controle inadequado poderá comprometer os resultados. É imprescindível a monitorização do paciente por meio de exames laboratoriais e avaliações clínicas regulares, que propiciarão ao médico a oportunidade de diagnóstico precoce dos eventos imunológicos, efeitos adversos ou infecciosos. No caso de pacientes estáveis (sem complicações clínicas e laboratoriais), o intervalo das visitas médicas e dos exames laboratoriais deve ser gradativamente aumentado. Em caso de alterações, o  
intervalo deve ser adequado às necessidades de cada paciente. Recomenda-se seguimento ambulatorial para pacientes estáveis da seguinte forma: consultas 2 vezes por semana no primeiro mês, semanais entre o segundo e terceiro meses, quinzenais entre o quarto e sexto meses, mensais entre o sétimo e décimo segundo meses, bimestrais ou trimestrais após o primeiro ano<sup>17</sup> .  
O apoio médico, de uma equipe multidisciplinar e da família são fundamentais para que o medicamento seja corretamente utilizado e para se reduzir ao máximo o índice de baixa adesão ao tratamento<sup>120-122</sup> . O monitoramento a intervalos curtos é fundamental para melhor controle. Níveis sanguíneos dos imunossupressores incompatíveis com os habituais preconizados neste Protocolo podem significar uso inadequado dos mesmos<sup>123, 124</sup> .  
Os medicamentos imunossupressores têm diferentes perfis de efeitos colaterais, e podem afetar a qualidade de vida. A tomada de decisão em relação à escolha ou a mudanças na imunossupressão após o transplante renal requer compreensão dos efeitos na qualidade de vida. Por isso é necessário informar os pacientes sobre medicamentos escolhidos e os diferentes efeitos colaterais e resultados adversos que podem afetar o bem-estar do paciente<sup>125</sup> .  
A avaliação regular da qualidade de vida pode ser uma ferramenta útil para informar os profissionais de saúde sobre o prognóstico de receptores de transplante renal<sup>126, 127</sup> .  
O tratamento com os fármacos imunossupressores deve ser mantido enquanto o paciente estiver vivo e com o enxerto funcionante. Após a perda do enxerto renal e retorno para diálise, a retirada gradual dos fármacos (semanas a meses) deve ser feita com o objetivo de evitar episódios de rejeição aguda e sensibilização e para preservar função renal residual.  Não há consenso sobre a melhor forma de suspender os fármacos, nem sobre a melhor sequência de classe de fármacos a serem suspensos<sup>128-130</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Corticosteroides</u>** -->
A monitorização clínica e laboratorial, com a monitorização da pressão arterial, glicemia e eletrólitos, entre outros efeitos adversos, devem ser realizados conforme intervalo definido a critério médico<sup>65, 131</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Azatioprina</u>** -->
Deve-se realizar hemograma em intervalos semanais nos primeiros 2 meses de uso e depois a critério médico. Aconselhase suspender a azatioprina quando os leucócitos totais estiverem abaixo de 3.000/mm<sup>3</sup> , uma vez que a depuração dos metabólitos 6-tioguanina (6-TGN0), responsáveis pela mielotoxicidade, é lenta e se estende, dependendo do nível atingido, por 2 a 3 semanas até o total desaparecimento celular<sup>132</sup> .  
Além da leucopenia, há possibilidade de ocorrência de hepatotoxicidade (hepatite, colestase, doença hepática venoclusiva), devendo ser avaliadas as provas de função hepática e testes de colestase (AST/TGO, ALT/TGP, fosfatase alcalina e bilirrubinas), em intervalos definidos a critério médico<sup>133</sup> . Pancreatite, queda de cabelo e maior risco para o desenvolvimento de câncer de pele também são efeitos adversos relatados<sup>134</sup> .  
A determinação da 6-metilmercaptopurina (6-MMP) e da 6-TGN intra-eritrocitários, bem a como a avaliação de polimorfismo genético da enzima tiopurina metiltransferase (TPMT) podem ser úteis para monitorar dose e minimizar eventos adversos. No entanto, estes testes não são utilizados na prática clínica rotineira<sup>135-137</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Ciclosporina</u>** -->
A monitorização clínica e laboratorial, pela verificação da pressão arterial e realização de hemograma e dosagens séricas de glicose, creatinina, lipídeos, eletrólitos e enzimas hepáticas, deve ser realizada com intervalo definido a critério médico<sup>138</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Tacrolimo</u>** -->
A monitorização clínica e laboratorial, pela verificação da pressão arterial e realização de hemograma e dosagens séricas de glicose, creatinina, lipídeos, eletrólitos e enzimas hepáticas, deve ser realizada com intervalo definido a critério médico<sup>138</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Precursores do ácido micofenólico</u>** -->
Alterações hematopoéticas são comuns durante o uso destes medicamentos. Por isso, deve-se realizar hemograma em intervalos definidos a critério médico para eventuais ajustes de dose. Efeitos adversos gastrointestinais são comuns, podendo  
ser ajustada a dose se necessário. Comumente os pacientes apresentam náusea, anorexia e diarreia e podem desenvolver gastrite. Em caso de doença péptica ulcerosa ativa, o medicamento deve ser evitado<sup>139</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Sirolimo e everolimo</u>** -->
A monitorização da pressão arterial e das dosagens séricas da glicose, creatinina, lipídeos e eletrólitos devem ser realizados com intervalo definido a critério médico. Cefaleia, edema periférico, insônia, acne, diarreia, constipação intestinal, artralgia, fibrilação atrial, depressão, _rash_ cutâneo, edema pulmonar, derrame pleural, impotência, hiperplasia gengival, gengivite, estomatite e ulcerações na boca, entre outros, são efeitos adversos do sirolimo e everolimo<sup>140</sup> .  
Em pacientes com insuficiência hepática, a concentração sanguínea mínima deve ser monitorizada com cautela. Os pacientes devem ser acompanhados quanto ao risco de rabdomiólise e outras adversidades decorrentes do aumento da biodisponibilidade do medicamento<sup>141</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Interações medicamentosas</u>** -->
**Ciclosporina ou tacrolimo:** Vários fármacos interferem no metabolismo destes dois imunossupressores. Alguns aumentam o nível sanguíneo, como o fluconazol, cetoconazol, claritromicina, eritromicina, diltiazem e anlodipina, e outros o diminuem, como a fenitoína, rifampicina, isoniazida e barbitúricos. O uso concomitante destes medicamentos não está contraindicado, mas exige monitorização criteriosa dos níveis sanguíneos do imunossupressor<sup>142</sup> .  
**Azatioprina:** Precauções devem ser tomadas ao se usar alopurinol em associação com azatioprina ou 6-mercaptopurina. O bloqueio da enzima xantina oxidase pelo alopurinol reduz o catabolismo da 6-mercaptopurina propiciando maior formação dos metabólitos 6-tioguanínicos responsáveis pela imunossupressão e mielotoxicidade. Ao serem utilizados azatioprina e alopurinol, é fundamental que se faça significativa redução da dose destes dois agentes e controles hemáticos próximos, semanais até estabilização dos leucócitos sanguíneos<sup>143, 144</sup> .  
**Precursores do ácido micofenólico:** não são de importância clínica, embora haja relatos que assinalam maior área sob a curva (ASC) de micofenolato em associação com sirolimo do que com ciclosporina. Este dado sugere a necessidade de reduzir a dose do medicamento em pacientes que estiverem também em uso de sirolimo<sup>145</sup> . Em razão do mecanismo de ação do micofenolato, sua associação com azatioprina é contraindicada.  
**Sirolimo:** a administração de sirolimo com indutores, como anticonvulsivantes, rifampicina, isoniazida, ou inibidores do citocromo P450 3A, como alguns antifúngicos, inibidores dos canais de cálcio, antibióticos macrolídeos, pode ocasionar interações significativas, devendo ser feita com adequado reajuste de dose<sup>146</sup> .  
**Everolimo:** a administração de everolimo com indutores, como anticonvulsivantes (por exemplo, fenitoína), barbituratos, rifampicina, entre outros agentes, ou com inibidores do citocromo CYP3A4, como antibióticos macrolídeos, cloranfenicol, antifúngicos, pode ocasionar interações significativas, devendo ser feita com adequado ajuste de dose<sup>146</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Tratamentos de suporte e profiláticos</u>** -->
Preconizam-se que as seguintes profilaxias sejam realizadas após o transplante renal:  
- Sulfametoxazol+trimetoprima 400+80 mg ao dia por 6 meses para profilaxia de infecções por _Pneumocystis jirovecci._ Tal profilaxia tem efeito adicional de prevenir infecções urinárias e infecções por _Toxoplasma gondii_<sup>147</sup> .  
- Ivermectina 200 mcg/Kg/dia por 2 dias ou albendazol 400 mg/dia por 3-5 dias para profilaxia de estrongiloidíase disseminada<sup>148</sup> .  
- O tratamento de tuberculose latente em pacientes com antecedente de tuberculose ou com teste tuberculínico positivo deve ser realizado conforme diretrizes do Ministério da Saúde<sup>149</sup> .  
-  
**9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR**  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamento(s).  
Pacientes transplantados de rim devem ser acompanhados regularmente por profissionais capacitados, preferencialmente em serviços habilitados pelo Ministério da Saúde, integrantes do Sistema Nacional de Transplantes.  
Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **11. REFERÊNCIAS** -->
1. Sesso R, Eisenberg JM, Stabile C, Draibe S, Ajzen H, Ramos O. Cost-effectiveness analysis of the treatment of endstage renal disease in Brazil. Int J Technol Assess Health Care. 1990;6(1):107-14. 2. Tonelli M, Wiebe N, Knoll G, Bello A, Browne S, Jadhav D, et al. Systematic review: kidney transplantation compared with dialysis in clinically relevant outcomes. Am J Transplant. 2011;11(10):2093-109. 3. Silva SB, Caulliraux HM, Araújo CA, Rocha E. Cost comparison of kidney transplant versus dialysis in Brazil. Cad Saude Publica. 2016;32(6).  
4. Gouveia DSES, Bignelli AT, Hokazono SR, Danucalov I, Siemens TA, Meyer F, et al. Analysis of economic impact between the modality of renal replacement therapy. J Bras Nefrol. 2017;39(2):162-71.  
5. Medina-Pestana JO, Galante NZ, Tedesco-Silva H, Jr., Harada KM, Garcia VD, Abbud-Filho M, et al. Kidney transplantation in Brazil and its geographic disparity. J Bras Nefrol. 2011;33(4):472-84.  
6. Registro Brasileiro de Transplantes (RBT). Dimensionamento dos Transplantes no Brasil e em cada Estado (20112018) http://www.abto.org.br: Veículo Oficial da Associação Brasileira de Transplantes de Órgãos; 2019.  
7. Garcia VD, Abbud-Filho M, Felipe C, Pestana JM. An Overview of the Current Status of Organ Donation and Transplantation in Brazil. Transplantation. 2015;99(8):1535-7.  
8. Garcia VD KE, Abbud Filho M. Avaliação Econômica do Transplante Renal no Brasil. In: Silva Junior GB OJ, Martins CTB, editor. A Nefrologia e o Sistema de Saúde do Brasil. 1. São Paulo: Livraria Balieiro; 2019. p. 175-200. 9. Denton MD, Magee CC, Sayegh MH. Immunosuppressive strategies in transplantation. Lancet. 1999;353(9158):1083-91.  
10. Nankivell BJ, Alexander SI. Rejection of the kidney allograft. N Engl J Med. 2010;363(15):1451-62. 11. Susal C, Opelz G. Current role of human leukocyte antigen matching in kidney transplantation. Curr Opin Organ Transplant. 2013;18(4):438-44.  
12. Pratschke J, Dragun D, Hauser IA, Horn S, Mueller TF, Schemmer P, et al. Immunological risk assessment: The key to individualized immunosuppression after kidney transplantation. Transplant Rev (Orlando). 2016;30(2):77-84.  
13. Tambur AR, Campbell P, Claas FH, Feng S, Gebel HM, Jackson AM, et al. Sensitization in Transplantation: Assessment of Risk (STAR) 2017 Working Group Meeting Report. Am J Transplant. 2018;18(7):1604-14.  
14. Tait BD, Susal C, Gebel HM, Nickerson PW, Zachary AA, Claas FH, et al. Consensus guidelines on the testing and clinical management issues associated with HLA and non-HLA antibodies in transplantation. Transplantation. 2013;95(1):19-47.  
15. Lefaucheur C, Loupy A, Hill GS, Andrade J, Nochy D, Antoine C, et al. Preexisting donor-specific HLA antibodies predict outcome in kidney transplantation. J Am Soc Nephrol. 2010;21(8):1398-406.  
16. Wu WK, Famure O, Li Y, Kim SJ. Delayed graft function and the risk of acute rejection in the modern era of kidney transplantation. Kidney Int. 2015;88(4):851-8.  
17. Group KDIGOKTW. KDIGO clinical practice guideline for the care of kidney transplant recipients. Am J Transplant. 2009;9 Suppl 3:S1-155.  
18. Pascual M, Theruvath T, Kawai T, Tolkoff-Rubin N, Cosimi AB. Strategies to improve long-term outcomes after renal transplantation. N Engl J Med. 2002;346(8):580-90.  
19. Heemann U, Lutz J. Pathophysiology and treatment options of chronic renal allograft damage. Nephrol Dial Transplant. 2013;28(10):2438-46.  
20. Nankivell BJ, Borrows RJ, Fung CL, O'Connell PJ, Allen RD, Chapman JR. The natural history of chronic allograft nephropathy. N Engl J Med. 2003;349(24):2326-33.  
21. Loupy A, Haas M, Roufosse C, Naesens M, Adam B, Afrouzian M, et al. The Banff 2019 Kidney Meeting Report (I): Updates on and clarification of criteria for T cell- and antibody-mediated rejection. Am J Transplant. 2020.  
22. Loupy A, Suberbielle-Boissel C, Zuber J, Anglicheau D, Timsit MO, Martinez F, et al. Combined posttransplant prophylactic IVIg/anti-CD 20/plasmapheresis in kidney recipients with preformed donor-specific antibodies: a pilot study. Transplantation. 2010;89(11):1403-10.  
23. Amrouche L, Aubert O, Suberbielle C, Rabant M, Van Huyen JD, Martinez F, et al. Long-term Outcomes of Kidney Transplantation in Patients With High Levels of Preformed DSA: The Necker High-Risk Transplant Program. Transplantation. 2017;101(10):2440-8.  
24. Webster AC, Ruster LP, McGee R, Matheson SL, Higgins GY, Willis NS, et al. Interleukin 2 receptor antagonists for kidney transplant recipients. Cochrane Database Syst Rev. 2010(1):CD003897.  
25. Brennan DC, Daller JA, Lake KD, Cibrik D, Del Castillo D, Group TIS. Rabbit antithymocyte globulin versus basiliximab in renal transplantation. N Engl J Med. 2006;355(19):1967-77.  
26. Brennan DC, Schnitzler MA. Long-term results of rabbit antithymocyte globulin and basiliximab induction. N Engl J Med. 2008;359(16):1736-8.  
27. Hellemans R, Hazzan M, Durand D, Mourad G, Lang P, Kessler M, et al. Daclizumab Versus Rabbit Antithymocyte Globulin in High-Risk Renal Transplants: Five-Year Follow-up of a Randomized Study. Am J Transplant. 2015;15(7):192332.  
28. Buttigieg J, Julie BM, Sharma A, Halawa A. Induction Immunosuppression in High-risk Kidney Transplant Recipients. Exp Clin Transplant. 2016;14(4):367-76.  
29. Hwang SD, Lee JH, Lee SW, Park KM, Kim JK, Kim MJ, et al. Efficacy and Safety of Induction Therapy in Kidney Transplantation: A Network Meta-Analysis. Transplant Proc. 2018;50(4):987-92.  
30. Grinyo JM, Gil-Vernet S, Cruzado JM, Caldes A, Riera L, Seron D, et al. Calcineurin inhibitor-free immunosuppression based on antithymocyte globulin and mycophenolate mofetil in cadaveric kidney transplantation: results after 5 years. Transpl Int. 2003;16(11):820-7.  
31. Martin ST, Roberts KL, Malek SK, Tullius SG, Vadivel N, De Serres S, et al. Induction treatment with rabbit antithymocyte globulin versus basiliximab in renal transplant recipients with planned early steroid withdrawal. Pharmacotherapy. 2011;31(6):566-73.  
32. Laftavi MR, Sharma R, Feng L, Said M, Pankewycz O. Induction therapy in renal transplant recipients: a review. Immunol Invest. 2014;43(8):790-806.  
33. Tedesco-Silva H, Felipe C, Ferreira A, Cristelli M, Oliveira N, Sandes-Freitas T, et al. Reduced Incidence of Cytomegalovirus Infection in Kidney Transplant Recipients Receiving Everolimus and Reduced Tacrolimus Doses. Am J Transplant. 2015;15(10):2655-64.  
34. Opelz G, Döhler B. Effect on kidney graft survival of reducing or discontinuing maintenance immunosuppression after the first year posttransplant. Transplantation. 2008;86(3):371-6.  
35. Sprangers B, Kuypers DR, Vanrenterghem Y. Immunosuppression: does one regimen fit all? Transplantation. 2011;92(3):251-61.  
36. Lim MA, Kohli J, Bloom RD. Immunosuppression for kidney transplantation: Where are we now and where are we going? Transplant Rev (Orlando). 2017;31(1):10-7.  
37. Ekberg H, Tedesco-Silva H, Demirbas A, Vítko S, Nashan B, Gürkan A, et al. Reduced exposure to calcineurin inhibitors in renal transplantation. N Engl J Med. 2007;357(25):2562-75. 38. Johnson C, Ahsan N, Gonwa T, Halloran P, Stegall M, Hardy M, et al. Randomized trial of tacrolimus (Prograf) in combination with azathioprine or mycophenolate mofetil versus cyclosporine (Neoral) with mycophenolate mofetil after cadaveric kidney transplantation. Transplantation. 2000;69(5):834-41.  
|39.|Drugs@FDA.<br>**Label**<br>**and**<br>**Approval**<br>**History**<br>**-**<br>**Prograf**|
|---|---|
|http://|www.accessdata.fda.gov/scripts/cder/drugsatfda/index.cfm?fuseaction=Search.Label_ApprovalHistory#apphist [|
|40.|Bula<br>do<br>Prograf.<br>Bulário<br>eletrônico<br>ANVISA.<br>Disponível<br>em|
|http://|www.anvisa.gov.br/datavisa/fila_bula/frmResultado.asp#. Acessado em 16 Setembro de 2019.|
|41.|Gatault P, Kamar N, Buchler M, Colosio C, Bertrand D, Durrbach A, et al. Reduction of Extended-Release|
|Tacrol|imus Dose in Low-Immunological-Risk Kidney Transplant Recipients Increases Risk of Rejection and Appearance of|
|Donor|-Specific Antibodies: A Randomized Study. Am J Transplant. 2017;17(5):1370-9.|  
42. A blinded, randomized clinical trial of mycophenolate mofetil for the prevention of acute rejection in cadaveric renal transplantation. The Tricontinental Mycophenolate Mofetil Renal Transplantation Study Group. Transplantation. 1996;61(7):1029-37.  
43. Knight SR, Russell NK, Barcena L, Morris PJ. Mycophenolate mofetil decreases acute rejection and may improve graft survival in renal transplant recipients when compared with azathioprine: a systematic review. Transplantation. 2009;87(6):785-94.  
44. Schold JD, Kaplan B. AZA/tacrolimus is associated with similar outcomes as MMF/tacrolimus among renal transplant recipients. Am J Transplant. 2009;9(9):2067-74.  
45. Wagner M, Earley AK, Webster AC, Schmid CH, Balk EM, Uhlig K. Mycophenolic acid versus azathioprine as primary immunosuppression for kidney transplant recipients. Cochrane Database Syst Rev. 2015(12):CD007746.  
46. Langer RM, Hené R, Vitko S, Christiaans M, Tedesco-Silva H, Ciechanowski K, et al. Everolimus plus early tacrolimus minimization: a phase III, randomized, open-label, multicentre trial in renal transplantation. Transpl Int. 2012;25(5):592-602.  
47. Tedesco Silva H, Cibrik D, Johnston T, Lackova E, Mange K, Panis C, et al. Everolimus plus reduced-exposure CsA versus mycophenolic acid plus standard-exposure CsA in renal-transplant recipients. Am J Transplant. 2010;10(6):140113.  
48. de Sandes-Freitas TV, Pinheiro PMA, Sales M, Girao CM, Campos EF, Esmeraldo RM. The impact of everolimus in reducing cytomegalovirus events in kidney transplant recipients on steroid-avoidance strategy: 3-year follow-up of a randomized clinical trial. Transpl Int. 2018;31(12):1345-56.  
49. Berger SP, Sommerer C, Witzke O, Tedesco H, Chadban S, Mulgaonkar S, et al. Two-year outcomes in de novo renal transplant recipients receiving everolimus-facilitated calcineurin inhibitor reduction regimen from TRANSFORM study. Am J Transplant. 2019.  
50. Sommerer C, Suwelack B, Dragun D, Schenker P, Hauser IA, Witzke O, et al. An open-label, randomized trial indicates that everolimus with tacrolimus or cyclosporine is comparable to standard immunosuppression in de novo kidney transplant patients. Kidney Int. 2019;96(1):231-44.  
51. Montero N, Quero M, Melilli E, Perez-Saez MJ, Redondo-Pachon D, Bestard O, et al. Mammalian Target of Rapamycin Inhibitors Combined With Calcineurin Inhibitors as Initial Immunosuppression in Renal Transplantation: A Meta-analysis. Transplantation. 2019;103(10):2031-56.  
52. Tedesco-Silva H, Pascual J, Viklicky O, Basic-Jukic N, Cassuto E, Kim DY, et al. Safety of Everolimus With Reduced Calcineurin Inhibitor Exposure in De Novo Kidney Transplants: An Analysis From the Randomized TRANSFORM Study. Transplantation. 2019;103(9):1953-63.  
53. Anil Kumar MS, Irfan Saeed M, Ranganna K, Malat G, Sustento-Reodica N, Kumar AM, et al. Comparison of four different immunosuppression protocols without long-term steroid therapy in kidney recipients monitored by surveillance biopsy: five-year outcomes. Transpl Immunol. 2008;20(1-2):32-42.  
54. Shihab F, Qazi Y, Mulgaonkar S, McCague K, Patel D, Peddi VR, et al. Association of Clinical Events With Everolimus Exposure in Kidney Transplant Patients Receiving Low Doses of Tacrolimus. Am J Transplant. 2017;17(9):2363-71.  
55. Shihab FS, Cibrik D, Chan L, Kim YS, Carmellini M, Walker R, et al. Association of clinical events with everolimus exposure in kidney transplant patients receiving reduced cyclosporine. Clin Transplant. 2013;27(2):217-26.  
56. Webster A, Woodroffe RC, Taylor RS, Chapman JR, Craig JC. Tacrolimus versus cyclosporin as primary immunosuppression for kidney transplant recipients. Cochrane Database Syst Rev. 2005(4):CD003961.  
57. Kramer BK, Montagnino G, Kruger B, Margreiter R, Olbricht CJ, Marcen R, et al. Efficacy and safety of tacrolimus compared with ciclosporin-A in renal transplantation: 7-year observational results. Transpl Int. 2016;29(3):307-14.  
58. Felipe CR, Park SI, Pinheiro-Machado PG, Garcia R, Casarini DE, Moreira S, et al. Cyclosporine and sirolimus pharmacokinetics and drug-to-drug interactions in kidney transplant recipients. Fundam Clin Pharmacol. 2009;23(5):625-31. 59. Ekberg H, Grinyó J, Nashan B, Vanrenterghem Y, Vincenti F, Voulgari A, et al. Cyclosporine sparing with mycophenolate mofetil, daclizumab and corticosteroids in renal allograft recipients: the CAESAR Study. Am J Transplant. 2007;7(3):560-70.  
60. Kreis H, Cisterne JM, Land W, Wramner L, Squifflet JP, Abramowicz D, et al. Sirolimus in association with mycophenolate mofetil induction for the prevention of acute graft rejection in renal allograft recipients. Transplantation. 2000;69(7):1252-60.  
61. Groth CG, Backman L, Morales JM, Calne R, Kreis H, Lang P, et al. Sirolimus (rapamycin)-based therapy in human renal transplantation: similar efficacy and different toxicity compared with cyclosporine. Sirolimus European Renal Transplant Study Group. Transplantation. 1999;67(7):1036-42.  
62. Silva HT, Jr., Felipe CR, Garcia VD, Neto ED, Filho MA, Contieri FL, et al. Planned randomized conversion from tacrolimus to sirolimus-based immunosuppressive regimen in de novo kidney transplant recipients. Am J Transplant. 2013;13(12):3155-63.  
63. Budde K, Becker T, Arns W, Sommerer C, Reinke P, Eisenberger U, et al. Everolimus-based, calcineurin-inhibitorfree regimen in recipients of de-novo kidney transplants: an open-label, randomised, controlled trial. Lancet. 2011;377(9768):837-47.  
64. Liu J, Liu D, Li J, Zhu L, Zhang C, Lei K, et al. Efficacy and Safety of Everolimus for Maintenance Immunosuppression of Kidney Transplantation: A Meta-Analysis of Randomized Controlled Trials. PLoS One. 2017;12(1):e0170246.  
65. De Lucena DD, Rangel EB. Glucocorticoids use in kidney transplant setting. Expert Opin Drug Metab Toxicol. 2018;14(10):1023-41.  
66. Woodle ES, First MR, Pirsch J, Shihab F, Gaber AO, Van Veldhuisen P, et al. A prospective, randomized, doubleblind, placebo-controlled multicenter trial comparing early (7 day) corticosteroid cessation versus long-term, low-dose corticosteroid therapy. Ann Surg. 2008;248(4):564-77.  
67. Liborio AB, Mendoza TR, Esmeraldo RM, Oliveira ML, Paes FJ, Silva Junior GB, et al. Induction antibody therapy in renal transplantation using early steroid withdrawal: long-term results comparing anti-IL2 receptor and anti-thymocyte globulin. Int Immunopharmacol. 2011;11(11):1832-6.  
68. Naesens M, Berger S, Biancone L, Crespo M, Djamali A, Hertig A, et al. Lymphocyte-depleting induction and steroid minimization after kidney transplantation: A review. Nefrologia. 2016;36(5):469-80.  
69. Pascual J, Royuela A, Galeano C, Crespo M, Zamora J. Very early steroid withdrawal or complete avoidance for kidney transplant recipients: a systematic review. Nephrol Dial Transplant. 2012;27(2):825-32.  
70. Pascual J, Zamora J, Galeano C, Royuela A, Quereda C. Steroid avoidance or withdrawal for kidney transplant recipients. Cochrane Database Syst Rev. 2009(1):CD005632. 71. Pascual J. Steroid avoidance or withdrawal in kidney transplantation. Curr Opin Organ Transplant. 2011;16(6):6005. 72. Pascual J, Galeano C, Royuela A, Zamora J. A systematic review on steroid withdrawal between 3 and 6 months after kidney transplantation. Transplantation. 2010;90(4):343-9.  
73. Haller MC, Royuela A, Nagler EV, Pascual J, Webster AC. Steroid avoidance or withdrawal for kidney transplant recipients. Cochrane Database Syst Rev. 2016(8):CD005632.  
74. Knight SR, Morris PJ. Steroid avoidance or withdrawal after renal transplantation increases the risk of acute rejection but decreases cardiovascular risk. A meta-analysis. Transplantation. 2010;89(1):1-14.  
75. Nankivell BJ, Agrawal N, Sharma A, Taverniti A, P'Ng CH, Shingde M, et al. The clinical and pathological significance of borderline T cell-mediated rejection. Am J Transplant. 2019;19(5):1452-63.  
76. Webster AC, Wu S, Tallapragada K, Park MY, Chapman JR, Carr SJ. Polyclonal and monoclonal antibodies for treating acute rejection episodes in kidney transplant recipients. Cochrane Database Syst Rev. 2017;7:CD004756. 77. Wu K, Budde K, Lu H, Schmidt D, Liefeldt L, Glander P, et al. The severity of acute cellular rejection defined by Banff classification is associated with kidney allograft outcomes. Transplantation. 2014;97(11):1146-54.  
78. Velidedeoglu E, Cavaille-Coll MW, Bala S, Belen OA, Wang Y, Albrecht R. Summary of 2017 FDA Public Workshop: Antibody-mediated Rejection in Kidney Transplantation. Transplantation. 2018;102(6):e257-e64.  
79. Schinstock CA, Mannon RB, Budde K, Chong AS, Haas M, Knechtle S, et al. Recommended Treatment for Antibody-mediated Rejection After Kidney Transplantation: The 2019 Expert Consensus From the Transplantion Society Working Group. Transplantation. 2020;104(5):911-22.  
80. Sablik KA, Clahsen-van Groningen MC, Looman CWN, Damman J, van Agteren M, Betjes MGH. Treatment with intravenous immunoglobulins and methylprednisolone may significantly decrease loss of renal function in chronic-active antibody-mediated rejection. BMC Nephrol. 2019;20(1):218.  
81. Mella A, Gallo E, Messina M, Caorsi C, Amoroso A, Gontero P, et al. Treatment with plasmapheresis, immunoglobulins and rituximab for chronic-active antibody-mediated rejection in kidney transplantation: Clinical, immunological and pathological results. World J Transplant. 2018;8(5):178-87.  
82. Nair P, Gheith O, Al-Otaibi T, Mostafa M, Rida S, Sobhy I, et al. Management of Chronic Active AntibodyMediated Rejection in Renal Transplant Recipients: Single-Center Experience. Exp Clin Transplant. 2019;17(Suppl 1):1139.  
83. Davis S, Cooper JE. Acute antibody-mediated rejection in kidney transplant recipients. Transplant Rev (Orlando). 2017;31(1):47-54.  
84. Akalin E, Dinavahi R, Friedlander R, Ames S, de Boccardo G, Sehgal V, et al. Addition of plasmapheresis decreases the incidence of acute antibody-mediated rejection in sensitized patients with strong donor-specific antibodies. Clin J Am Soc Nephrol. 2008;3(4):1160-7. 85. Bula do Solu-Medrol. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=4941152019&pIdAnexo=11209490.</u> Acessado em 03 de Outubro de 2019. 86. Bula do Simulect. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=10046472019&pIdAnexo=11557655.</u> Acessado em 03 de Outubro de 2019. 87. de Castro MC, Deboni L, Esmeraldo Rde M, Matuk TA, Pacheco A, Saitovitch D, et al. Use of Thymoglobulin(R) (antithymocyte immunoglobulin) in renal transplantation: practical guide. J Bras Nefrol. 2015;37(2):228-40. 88. Bula da Thymoglobuline. Bulário eeltrônico da ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=10510482019&pIdAnexo=11582465.</u> Acessado em 03 Outubro de 2019.  
89. Bula da Imunoglobulin. Bulário eletrônico da ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=17961082017&pIdAnexo=9073265.</u> Acesso em 03 de Outubro de 2019. 90. Bula do Meticorten. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=21309042017&pIdAnexo=9968520.</u> Acesso em 03 de outubro de 2019. 91. Bula do Sandimmum Neoral. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=8499122019&pIdAnexo=11433103.</u> Acesso em 03 Outubro 2019. 92. Bula do Cellcept. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=8803432019&pIdAnexo=11456230.</u> Acesso em 03 de Outubro de 2019.  
93. Kiang TK, Ensom MH. Therapeutic drug monitoring of mycophenolate in adult solid organ transplant patients: an update. Expert Opin Drug Metab Toxicol. 2016;12(5):545-53.  
94. Barraclough KA, Isbel NM, Staatz CE. Evaluation of the mycophenolic acid exposure estimation methods used in the APOMYGERE, FDCC, and Opticept trials. Transplantation. 2010;90(1):44-51. 95. Bula do Myfortic. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=12647552016&pIdAnexo=3108163.</u> Acesso em 03 de Outubro de 2019.  
96. Mahalati K, Kahan BD. Clinical pharmacokinetics of sirolimus. Clin Pharmacokinet. 2001;40(8):573-85.  
97. Tiong HY, Flechner SM, Zhou L, Wee A, Mastroianni B, Savas K, et al. A systematic approach to minimizing wound problems for de novo sirolimus-treated kidney transplant recipients. Transplantation. 2009;87(2):296-302.  
98. Kasap B. Sirolimus in pediatric renal transplantation. Pediatr Transplant. 2011;15(7):673-85. 99. Bula do Rapamune. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=9479582019&pIdAnexo=11508162.</u> Acesso em 03 de Outubro de 2019.  
100. Ferraresso M, Belingheri M, Ginevri F, Murer L, Dello Strologo L, Cardillo M, et al. Three-yr safety and efficacy of everolimus and low-dose cyclosporine in de novo pediatric kidney transplant patients. Pediatr Transplant. 2014;18(4):3506.  
101. Pape L, Lehner F, Blume C, Ahlenstiel T. Pediatric kidney transplantation followed by de novo therapy with everolimus, low-dose cyclosporine A, and steroid elimination: 3-year data. Transplantation. 2011;92(6):658-62. 102. Tonshoff B, Ettenger R, Dello Strologo L, Marks SD, Pape L, Tedesco-Silva H, Jr., et al. Early conversion of pediatric kidney transplant patients to everolimus with reduced tacrolimus and steroid elimination: Results of a randomized trial. Am J Transplant. 2019;19(3):811-22.  
103. Bula do Certican. Bulário eletrônico ANVISA. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=12453212018&pIdAnexo=10933388.</u> Acesso em 03 de Outubro de 2019.  
104. Kim M, Martin ST, Townsend KR, Gabardi S. Antibody-mediated rejection in kidney transplantation: a review of pathophysiology, diagnosis, and treatment options. Pharmacotherapy. 2014;34(7):733-44.  
105. Collett D, Mumford L, Banner NR, Neuberger J, Watson C. Comparison of the incidence of malignancy in recipients of different types of organ: a UK Registry audit. Am J Transplant. 2010;10(8):1889-96.  
106. Engels EA, Pfeiffer RM, Fraumeni JF, Jr., Kasiske BL, Israni AK, Snyder JJ, et al. Spectrum of cancer risk among US solid organ transplant recipients. JAMA. 2011;306(17):1891-901. 107. Adami J, Gabel H, Lindelof B, Ekstrom K, Rydh B, Glimelius B, et al. Cancer risk following organ transplantation: a nationwide cohort study in Sweden. Br J Cancer. 2003;89(7):1221-7. 108. Villeneuve PJ, Schaubel DE, Fenton SS, Shepherd FA, Jiang Y, Mao Y. Cancer incidence among Canadian kidney transplant recipients. Am J Transplant. 2007;7(4):941-8. 109. Piselli P, Serraino D, Segoloni GP, Sandrini S, Piredda GB, Scolari MP, et al. Risk of de novo cancers after transplantation: results from a cohort of 7217 kidney transplant recipients, Italy 1997-2009. Eur J Cancer. 2013;49(2):33644.  
110. Krynitz B, Edgren G, Lindelof B, Baecklund E, Brattstrom C, Wilczek H, et al. Risk of skin cancer and other malignancies in kidney, liver, heart and lung transplant recipients 1970 to 2008--a Swedish population-based study. Int J Cancer. 2013;132(6):1429-38.  
111. Matas AJ, Gillingham KJ, Humar A, Kandaswamy R, Sutherland DE, Payne WD, et al. 2202 kidney transplant recipients with 10 years of graft function: what happens next? Am J Transplant. 2008;8(11):2410-9. 112. Acuna SA, Huang JW, Daly C, Shah PS, Kim SJ, Baxter NN. Outcomes of Solid Organ Transplant Recipients With Preexisting Malignancies in Remission: A Systematic Review and Meta-Analysis. Transplantation. 2017;101(3):471-81. 113. de Fijter JW. Cancer and mTOR Inhibitors in Transplant Recipients. Transplantation. 2017;101(1):45-55. 114. McKay DB, Josephson MA, Armenti VT, August P, Coscia LA, Davis CL, et al. Reproduction and transplantation: report on the AST Consensus Conference on Reproductive Issues and Transplantation. Am J Transplant. 2005;5(7):1592-9. 115. Chandra A, Midtvedt K, Asberg A, Eide IA. Immunosuppression and reproductive health after kidney transplantation. Transplantation. 2019.  
116. Coscia LA, Constantinescu S, Davison JM, Moritz MJ, Armenti VT. Immunosuppressive drugs and fetal outcome. Best Pract Res Clin Obstet Gynaecol. 2014;28(8):1174-87.  
117. Zheng S, Easterling TR, Umans JG, Miodovnik M, Calamia JC, Thummel KE, et al. Pharmacokinetics of tacrolimus during pregnancy. Ther Drug Monit. 2012;34(6):660-70. 118. Hebert MF, Zheng S, Hays K, Shen DD, Davis CL, Umans JG, et al. Interpreting tacrolimus concentrations during pregnancy and postpartum. Transplantation. 2013;95(7):908-15. 119. Constantinescu S, Pai A, Coscia LA, Davison JM, Moritz MJ, Armenti VT. Breast-feeding after transplantation. Best Pract Res Clin Obstet Gynaecol. 2014;28(8):1163-73. 120. Prendergast MB, Gaston RS. Optimizing medication adherence: an ongoing opportunity to improve outcomes after kidney transplantation. Clin J Am Soc Nephrol. 2010;5(7):1305-11. 121. Dobbels F, Ruppar T, De Geest S, Decorte A, Van Damme-Lombaerts R, Fine RN. Adherence to the immunosuppressive regimen in pediatric kidney transplant recipients: a systematic review. Pediatr Transplant. 2010;14(5):603-13.  
122. Zhu Y, Zhou Y, Zhang L, Zhang J, Lin J. Efficacy of interventions for adherence to the immunosuppressive therapy in kidney transplant recipients: a meta-analysis and systematic review. J Investig Med. 2017;65(7):1049-56.  
123. Rodrigo E, Segundo DS, Fernandez-Fresnedo G, Lopez-Hoyos M, Benito A, Ruiz JC, et al. Within-Patient Variability in Tacrolimus Blood Levels Predicts Kidney Graft Loss and Donor-Specific Antibody Development. Transplantation. 2016;100(11):2479-85.  
124. Whalen HR, Glen JA, Harkins V, Stevens KK, Jardine AG, Geddes CC, et al. High Intrapatient Tacrolimus Variability Is Associated With Worse Outcomes in Renal Transplantation Using a Low-Dose Tacrolimus Immunosuppressive Regime. Transplantation. 2017;101(2):430-6.  
125. Howell M, Wong G, Turner RM, Tan HT, Tong A, Craig JC, et al. The Consistency and Reporting of Quality-ofLife Outcomes in Trials of Immunosuppressive Agents in Kidney Transplantation: A Systematic Review and Meta-analysis. Am J Kidney Dis. 2016;67(5):762-74.  
126. Molnar-Varga M, Molnar MZ, Szeifert L, Kovacs AZ, Kelemen A, Becze A, et al. Health-related quality of life and clinical outcomes in kidney transplant recipients. Am J Kidney Dis. 2011;58(3):444-52.  
127. Tucker EL, Smith AR, Daskin MS, Schapiro H, Cottrell SM, Gendron ES, et al. Life and expectations post-kidney transplant: a qualitative analysis of patient responses. BMC Nephrology. 2019;20(1):175. 128. Pham PT, Everly M, Faravardeh A, Pham PC. Management of patients with a failed kidney transplant: Dialysis reinitiation, immunosuppression weaning, and transplantectomy. World J Nephrol. 2015;4(2):148-59.  
129. Augustine JJ, Woodside KJ, Padiyar A, Sanchez EQ, Hricik DE, Schulak JA. Independent of nephrectomy, weaning immunosuppression leads to late sensitization after kidney transplant failure. Transplantation. 2012;94(7):738-43.  
130. Woodside KJ, Schirm ZW, Noon KA, Huml AM, Padiyar A, Sanchez EQ, et al. Fever, infection, and rejection after kidney transplant failure. Transplantation. 2014;97(6):648-53.  
131. Schäcke H, Döcke WD, Asadullah K. Mechanisms involved in the side effects of glucocorticoids. Pharmacol Ther. 2002;96(1):23-43.  
132. Nielsen OH, Vainer B, Rask-Madsen J. Review article: the treatment of inflammatory bowel disease with 6- mercaptopurine or azathioprine. Aliment Pharmacol Ther. 2001;15(11):1699-708.  
133. Bjornsson ES, Gu J, Kleiner DE, Chalasani N, Hayashi PH, Hoofnagle JH, et al. Azathioprine and 6- Mercaptopurine-induced Liver Injury: Clinical Features and Outcomes. J Clin Gastroenterol. 2017;51(1):63-9.  
134. Meggitt SJ, Anstey AV, Mohd Mustapa MF, Reynolds NJ, Wakelin S. British Association of Dermatologists' guidelines for the safe and effective prescribing of azathioprine 2011. Br J Dermatol. 2011;165(4):711-34. 135. Bula do Imuran. Bulário eletrônico. Disponível em <u>http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=3728542019&pIdAnexo=11140091.</u> Acesso em 03 de Outubro de 2019.  
136. Duley JA, Florin TH. Thiopurine therapies: problems, complexities, and progress with monitoring thioguanine nucleotides. Ther Drug Monit. 2005;27(5):647-54.  
137. Pacheco Neto M, Alves ANL, Fortini AS, Burattini MdN, Sumita NM, Srougi M, et al. Monitoração terapêutica da azatioprina: uma revisão. Jornal Brasileiro de Patologia e Medicina Laboratorial. 2008;44:161-7.  
138. Malvezzi P, Rostaing L. The safety of calcineurin inhibitors for kidney-transplant patients. Expert Opin Drug Saf. 2015;14(10):1531-46.  
139. Kiang TKL, Ensom MHH. Exposure-Toxicity Relationships of Mycophenolic Acid in Adult Kidney Transplant Patients. Clin Pharmacokinet. 2019.  
140. Kaplan B, Qazi Y, Wellen JR. Strategies for the management of adverse events associated with mTOR inhibitors. Transplant Rev (Orlando). 2014;28(3):126-33.  
141. dos Santos AG, Guardia AC, Pereira TS, Ataide EC, Mei M, Udo ME, et al. Rhabdomyolysis as a clinical manifestation of association with ciprofibrate, sirolimus, cyclosporine, and pegylated interferon-alpha in liver-transplanted patients: a case report and literature review. Transplant Proc. 2014;46(6):1887-8.  
142. Vanhove T, Annaert P, Kuypers DR. Clinical determinants of calcineurin inhibitor disposition: a mechanistic review. Drug Metab Rev. 2016;48(1):88-112.  
143. Gearry RB, Day AS, Barclay ML, Leong RW, Sparrow MP. Azathioprine and allopurinol: A two-edged interaction. J Gastroenterol Hepatol. 2010;25(4):653-5.  
144. Chocair P, Duley J, Simmonds HA, Cameron JS, Ianhez L, Arap S, et al. Low-dose allopurinol plus azathioprine/cyclosporin/prednisolone, a novel immunosuppressive regimen. Lancet. 1993;342(8863):83-4.  
145. Picard N, Premaud A, Rousseau A, Le Meur Y, Marquet P. A comparison of the effect of ciclosporin and sirolimus on the pharmokinetics of mycophenolate in renal transplant patients. Br J Clin Pharmacol. 2006;62(4):477-84.  
146. Klumpen HJ, Beijnen JH, Gurney H, Schellens JH. Inhibitors of mTOR. Oncologist. 2010;15(12):1262-9.  
147. Soave R. Prophylaxis strategies for solid-organ transplantation. Clin Infect Dis. 2001;33 Suppl 1:S26-31.  
148. Hayes J, Nellore A. Management of Strongyloides in Solid Organ Transplant Recipients. Infect Dis Clin North Am. 2018;32(3):749-63.  
149. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Manual de Recomendações para o Controle da Tuberculose no Brasil / Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância das Doenças Transmissíveis. – Brasília: Ministério da Saúde, 2018.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
AZATIOPRINA, CICLOSPORINA, EVEROLIMO, IMUNOGLOBULINA HUMANA, IMUNOGLOBULINA ANTITIMÓCITOS HUMANOS (OBTIDA DECOELHO)/TIMOGLOBULINA, METILPREDNISOLONA,  MICOFENOLATO DE MOFETILA OU DE SÓDIO, PREDNISONA, PREDNISOLONA , TACROLIMO E SIROLIMO.  
Eu,  _________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do(s) medicamento(s) **azatioprina, ciclosporina, everolimo, imunoglobulina humana, imunoglobulina antitimócitos humanos (coelho), metilprednisolona, micofenolato de mofetila ou de sódio, prednisona, prednisolona , tacrolimo e sirolimo** indicados para a indução e manutenção da imunossupressão após o transplante, bem como para o tratamento da rejeição.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico __________________________________________________  (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o (s) medicamento (s) que passo a receber podem trazer os seguintes benefícios:  
- Redução das taxas de rejeição aguda e crônica;  
-  
-  
-  
- aumento da sobrevida do enxerto (sem necessidade de diálise);  
- aumento da sobrevida;  
- melhora na qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, efeitos adversos, riscos e cuidados relacionados ao uso destes medicamentos:  
- Prednisona e prednisolona: medicamentos classificados como fator de risco B para gestantes (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido realizados ou não foram adequados; o medicamento deve ser prescrito com cautela). Caso engravide, devo avisar imediatamente ao meu médico;  
- Metilprednisolona, ciclosporina, micofenolato (de mofetila ou de sódio), sirolimo, everolimo, tacrolimo e imunoglubulina humana: medicamentos classificados como categoria C (pesquisas em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- Azatioprina: medicamento classificado como categoria D (há evidências de riscos ao feto, mas um benefício potencial pode ser maior do que os riscos);  
- **Efeitos adversos da azatioprina:** diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar e pressão baixa.  
- **Efeitos adversos da ciclosporina:** problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração (taquicardia), convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas.  
- **Efeitos adversos da prednisona/prednisolona e metilprednisolona:** retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose, problemas de estômago (úlceras estomacais), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito;  
- **Efeitos adversos do micofenolato (de mofetila ou de sódio):** diarreia, diminuição das células brancas do sangue, infecção generalizada e vômitos, podendo também ocorrer dor no peito, palpitações, pressão baixa, trombose, insuficiência cardíaca, hipertensão pulmonar, morte súbita, desmaio, ansiedade, depressão, rigidez muscular, formigamentos, sonolência, neuropatia, convulsões, alucinações, vertigens, tremores, insônia, tonturas, queda de cabelo, aumento da quantidade de pelos no corpo, coceiras, ulcerações na pele, espinhas, vermelhidão da pele, prisão de ventre, náusea, azia e dor de estômago, perda de apetite, gases, gastrite, gengivite, hipertrofia gengival, hepatite, sangue na urina, aumento da frequência ou retenção urinária, insuficiência renal, desconforto para urinar, impotência sexual, anemia, diminuição das plaquetas do sangue, diabetes melito, síndrome de Cushing, hipotireoidismo, inchaço, alteração de eletrólitos (hipofosfatemia, hiperpotassemia, hipocloremia), hiperglicemia, hipercolesterolemia, alteração de enzimas hepáticas, febre, dor de cabeça, fraqueza, dor nas costas e no abdômen, pressão alta, falta de ar, tosse;  
- **Efeitos adversos do sirolimo:** pressão baixa, palpitação, insuficiência cardíaca, desmaios, hemorragias, trombose, microangiopatia trombótica, doença vascular periférica, insônia, tremores, ansiedade, confusão, depressão, tontura, fraqueza ou rigidez muscular, neuropatia, formigamento, sonolência, aumento da quantidade de pelos, espinhas, vermelhidão na pele, coceiras no corpo, ulcerações na pele, arrotos, gases, gastrites, gengivites, inflamação na boca, diarreia, prisão de ventre, náusea, vômitos, perda de apetite, perda de peso, hipertrofia gengival, alteração de enzimas hepáticas, diminuição das células brancas, vermelhas e das plaquetas do sangue, retardamento na cicatrização, síndrome hemolítico-urêmica, acúmulo de linfa, aumento dos níveis de colesterol e de triglicerídios, alteração de eletrólitos no sangue (cálcio, fósforo, sódio, potássio e magnésio), síndrome de Cushing, diabetes melito, febre, sangramento nasal, toxicidade renal, edema facial, dores no corpo, osteoporose, catarata, alterações visuais;  
- **Efeitos adversos do everolimo:** leucopenia, hipercolesterolemia, hiperlipemia, hipertrigliceridemia, infecções virais, fúngicas e bacterianas, sepse, trombocitopenia, anemia, coagulopatia, púrpura trombocitopênica trombótica/síndrome hemolítico-urêmica, pressão alta, linfocele, tromboembolia venosa, dor abdominal, diarreia, náusea, vômitos, acne, complicações de ferimentos cirúrgicos, edema, artralgias. Não se sabe se o medicamento é excretado pelo leite materno. Não há experiência suficiente para recomendar seu uso em crianças e adolescentes. A experiência clínica em indivíduos com mais de 65 anos de idade é limitada. Pacientes em uso de everolimo são mais sucetíveis a desenvolver linfomas e outras doenças malignas, particularmente de pele. Em pacientes com insuficiência hepática, a concentração sanguínea mínima deve ser monitorizada com cautela. Os pacientes devem ser acompanhados quanto ao risco de rabdomiólise e outras adversidades decorrentes do aumento da biodisponibilidade do medicamento. Métodos contraceptivos devem ser utilizados por pacientes de ambos os sexos sob esquema imunossupressor até que informações mais conclusivas estejam disponíveis;  
- **Efeitos adversos do tacrolimo:** tremores, dor de cabeça, diarreia, pressão alta, náusea e disfunção renal, podendo também ocorrer dor no peito, pressão baixa, palpitações, formigamentos, falta de ar, colangite, amarelão, diarreia, prisão de ventre, vômitos, diminuição do apetite, azia e dor no estômago, gases, hemorragia, dano hepático, agitação, ansiedade, convulsão, depressão, tontura, alucinações, incoordenação, psicose, sonolência, neuropatia, queda de cabelo, aumento da quantidade de pelos no corpo, vermelhidão de pele, coceiras, anemia, aumento ou diminuição das células brancas do sangue, diminuição das plaquetas do sangue, desordens na coagulação, síndrome hemolítico-urêmica, edema periférico, alterações metabólicas (hipo/hiperpotassemia, hiperglicemia, hipomagnesemia, hiperuricemia), diabetes melito, elevação de enzimas hepáticas, toxicidade renal, diminuição importante do volume da urina, febre, acúmulo de líquido  
no abdômen e na pleura, fraqueza, dor lombar, atelectasias, osteoporose, dores no corpo, peritonite, fotossensibilidade, alterações visuais;  
- **Efeitos adversos da imunoglobulina humana:** dor de cabeça, calafrios, febre, reações no local de aplicação da injeção, que incluem dor, coceira e vermelhidão. Problemas nos rins também já foram relatados;  
- **Efeitos adversos da Imunoglobulina antitimócitos humanos (coelho):** febre, calafrios, rigidez, dispneia, náusea, vômitos, diarreia, hipotensão ou hipertensão, mal-estar, erupção cutânea, urticária, diminuição da saturação de oxigênio ou dor de cabeça;  
- Medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos;  
- O risco da ocorrência de efeitos adversos aumenta com a superdosagem;  
- Aumento do risco de infecções e alguns tipos de câncer;  
- Necessidade de dosar os níveis no sangue de alguns dos medicamentos;  
Estou ciente de que estes medicamentos somente podem ser utilizados por mim, comprometendo-me a devolvê-los caso não queira e não possa utilizá-los ou se o tratamento for interrompido. E de que, se o tratamento for suspenso sem orientação médica, corro o risco de perder o transplante e de voltar a necessitar de diálise. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar os medicamentos.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.               (   )  Sim               (   ) Não  
Meu tratamento constará do (s) seguinte (s) medicamento (s):  
- (   ) azatioprina  
- (   ) ciclosporina  
- (   ) prednisona/prednisolona  
- (   ) metilprednisolona  
- (   ) micofenolato de mofetila  
- (   ) micofenolato de sódio  
- (   ) sirolimo  
- (   ) tacrolimo  
- (   ) everolimo  
- (   ) imunoglobulina humana  
- (   ) imunoglobulina antitimócitos humanos (obtida de coelho)/timoglobulina  
|Local:                                                             Data:|
|---|
|Nome do paciente:|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|  
|Assinatura do paciente ou do responsável legal<br>Médico responsável:|CRM:|UF:|
|---|---|---|
|___________________________<br>Assinatura e carimbo do médico<br>Data:____________________|||  
**Nota 1:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2:** Os seguintes medicamentos integram **procedimentos hospitalares especiais** , em AIH, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.03.02.003-8 Ciclosporina 50 mg injetável (por frascoampola), 06.03.02.009-7  Imunoglobulina obtida/coelho antitimócitos humanos 25 mg injetável, 06.03.03.003-3 Imunoglobulina humana 1,0 g, 06.03.08.001-4 – Basiliximabe 20 mg injetável (por frasco ampola), 06.03.08.002-2 Ciclosporina 10 mg p/ transplante (por cápsula), 06.03.08.003-0 Ciclosporina 100 mg p/ transplante (por cápsula), 06.03.08.004-9 Ciclosporina 25 mg p/ transplante (por cápsula), 06.03.08.005-7 Ciclosporina 50 mg p/ transplante (por cápsula), 06.03.08.012-0 Metilprednisolona 500 mg injetável p/ transplante (por frasco ampola), 06.03.08.013-8 Micofenolato de mofetila 500mg p/ transplante (por comprimido), 06.03.08.014-6 Micofenolato de sódio 360mg p/ transplante (por comprimido), 06.03.08.0 22-7 Micofenolato de sódio 180mg p/ transplante (por comprimido), 06.03.08.0162 Sirolimo 1mg p/ transplante (por drágea), 06.03.08.017-0 Sirolimo 1mg/ml solucao oral p/ transplante (por frasco de 60ml), 06.03.08.018-9 Sirolimo 2 mg p/ transplante (por drágea), 06.03.08.019-7 Tacrolimo 0,5 mg p/ transplante (frasco-ampola), 06.03.08.020-0 Tacrolimo 1 mg p/ transplante (por cápsula), 06.03.08.021-9 Tacrolimo 5 mg p/ transplante (por cápsula), 06.03.08.022-7 Micofenolato de sódio 180mg p/transplante (por comprimido), 06.03.08.027-8 Everolimo 0,5 mg para transplante (por comprimido), 06.03.08.028-6 - Everolimo 0,75 mg para transplante (por comprimido) e 06.03.08.029-4 Everolimo 1 mg para transplante (por comprimido).  
**Nota 3:** Os seguintes medicamentos integram **procedimentos ambulatoriai** s, em APAC (Componente Especializado da Assistência Farmacêutica), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.04.31.001-3 Imunoglobulina humana 0,5g, 06.04.31.002-1 Imunoglobulina humana 1 g, 06.04.31.003-0 Imunoglobulina humana 2,5 g, 06.04.31.005-6 Imunoglobulina humana 5,0 g, 06.04.32.001-9 Everolimo 0,5 mg para transplante (por comprimido), 06.04.32.002-7 Everolimo 0,75 mg para transplante (por comprimido), 06.04.32.003-5 Everolimo 1,0 mg para transplante (por comprimido), 06.04.34.006-0 Tacrolimo 1 mg p/ transplante (por cápsula), 06.04.34.007-9 Tacrolimo 5 mg p/ transplante (por cápsula), 06.04.32.008-6 Sirolimo 1mg p/ transplante (por drágea), 06.04.32.009-4 Sirolimo 1mg p/ transplante (por drágea), 06.04.34.001-0 Ciclosporina 10 mg (por cápsula), 06.04.34.002-8 Ciclosporina 25 mg (por cápsula), 06.04.34.003-6 Ciclosporina 50 mg (por cápsula), 06.04.34.004-40 Ciclosporina 100 mg (por cápsula), 06.04.34.005-2 Ciclosporina 100 mg/ml (por frasco de 50 ml), 06.04.32.005-1 Micofenolato de mofetila 500mg p/ transplante (por comprimido), 06.04.32.005-1 Micofenolato de mofetila 500mg p/ transplante (por comprimido), 06.04.32.006-0 Micofenolato de sódio 180mg p/ transplante (por comprimido), 06.04.32.007-8 Micofenolato de sódio 360mg p/ transplante (por comprimido) e azatioprina 50 mg (por comprimido).  
**Nota 4:** A prednisona (comprimidos de 5 mg e de 20 mg) inclui-se no Componente Básico e no Componente Estratégico da Assistência Farmacêutica e a prednisolona 1mg/ml e 3mg/ml, no Componente Básico da Assistência Farmacêutica.  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Imunossupressão no Transplante Renal iniciou-se com a delimitação do escopo, realizada em reunião presencial conduzida no dia 29 de abril de 2019, em Brasília/DF. O objetivo desta reunião foi a discussão da atualização do referido PCDT.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria SAS/MS nº 712, de 14 de agosto de 2014) e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador, com o objetivo de revisar as condutas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.  
Depois da publicação, em 05/01/2021, da Portaria Conjunta n<sup>o</sup> 1/SAES e SCTIE/MS, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas para Imunossupressão no Transplante Renal, pela necessidade de se excluírem apresentações farmacêuticas de imunoglobulina humana devido à ausência de registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). Para tal, foi também adequado o Relatório de Recomendação n.º 555/2021 da Conitec.  
À 104ª Reunião Ordinária da Conitec, realizada dia 09/12/2021, havia sido analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários caducaram ou foram cancelados no Brasil. Àquela ocasião, foi deliberado, por unanimidade, recomendar a exclusão de imunoglobulina humana 3 g pó liofilizado para solução injetável ou solução injetável na concentração de 3 g e imunoglobulina humana 6 g em pó liofilizado para solução injetável 6 g. A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE/MS nº 83, de 29/12/2021. Por fim, o tema foi apresentado como informe à 96ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22/02/2022 e também à 106ª Reunião Ordinária da Conitec, em 10/03/2022.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Colaboração externa</u>** -->
Estiveram presentes à reunião de escopo representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), médicos, médicos especialistas, metodologistas, farmacêuticos e administradores do grupo elaborador de PCDT do Hospital Alemão Oswaldo Cruz.  
Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
O Protocolo foi apresentado à 77ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas. realizada dia 11 de fevereiro de 2020. com a participação de representantes de áreas técnicas do Ministério da  
Saúde e, após a análise e realização dos ajustes e correções apontadas, foi por unanimidade decidido pautar o tema na reunião da Conitec.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **<u>Consulta pública</u>** -->
A Consulta Pública (CP) nº 28/2020 foi realizada entre os dias 21 de julho a 10 de agosto de 2020. As contribuições da CP foram apresentadas na 90ª reunião do Plenário da Conitec, realizada nos dias 02 e 03 de setembro de 2020 e, após a análise e discussão de todos presentes, foi deliberado, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas da Imunossupressão em Transplante Renal apresentado no Relatório de Recomendação n° 555/2020. Foi assinado o Registro de Deliberação n° 549/2020.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Renal | secao: **3. Busca da evidência** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados Pubmed e Embase,  
conforme o **Quadro A** .  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados na atualização do PCDT para Imunossupressão em  
Transplante Renal.  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline<br>(via<br>PubMed)|"Kidney Transplantation"[Mesh]<br>OR "Renal Transplantation"[All<br>Fields] OR "Renal<br>Transplantations"[All Fields] OR<br>("kidney transplantation"[MeSH<br>Terms] OR ("kidney"[All Fields]<br>AND "transplantation"[All<br>Fields]) OR "kidney<br>transplantation"[All Fields]) AND<br>("Immunosuppression"[Mesh] OR<br>"immunosuppression"[All Fields])<br>AND (Guideline[ptyp] OR Meta-<br>Analysis[ptyp] OR systematic[sb])<br>AND ("2014/05/07"[PDAT] :<br>"3000/12/31"[PDAT])|79|57|9<br>**Motivo das**<br>**exclusões:**<br>- sem relação com<br>escopo do PCDT|
|Embase|('kidney transplantation'/exp OR<br>'kidney transplantation') AND<br>('immunosuppressive<br>treatment'/exp OR<br>'immunosuppressive treatment')<br>AND ([cochrane review]/lim OR<br>[systematic review]/lim OR [meta<br>analysis]/lim) AND [embase]/lim<br>AND [2014-2019]/py|168|||  
Seguem os estudos selecionados a partir das buscas e a sua citação no texto do PCDT:  
1. Buttigieg J, Julie BM, Sharma A, Halawa A. Induction Immunosuppression in High-risk Kidney Transplant Recipients. Exp Clin Transplant. 2016;14(4):367-76 - referência 28  
2. Hwang SD, Lee JH, Lee SW, Park KM, Kim JK, Kim MJ, et al. Efficacy and Safety of Induction Therapy in Kidney Transplantation: A Network Meta-Analysis. Transplant Proc. 2018;50(4):987-92. – referência 29  
3. Wagner M, Earley AK, Webster AC, Schmid CH, Balk EM, Uhlig K. Mycophenolic acid versus azathioprine as primary immunosuppression for kidney transplant recipients. Cochrane Database Syst Rev. 2015(12):CD007746. – referência 45  
4. Montero N, Quero M, Melilli E, Perez-Saez MJ, Redondo-Pachon D, Bestard O, et al. Mammalian Target of Rapamycin Inhibitors Combined With Calcineurin Inhibitors as Initial Immunosuppression in Renal Transplantation: A Metaanalysis. Transplantation. 2019;103(10):2031-56. – referência 51  
5. Liu J, Liu D, Li J, Zhu L, Zhang C, Lei K, et al. Efficacy and Safety of Everolimus for Maintenance Immunosuppression of Kidney Transplantation: A Meta-Analysis of Randomized Controlled Trials. PLoS One. 2017;12(1):e0170246. – referência 64  
6. Haller MC, Royuela A, Nagler EV, Pascual J, Webster AC. Steroid avoidance or withdrawal for kidney transplant recipients. Cochrane Database Syst Rev. 2016(8):CD005632. – referência 73  
7. Webster AC, Wu S, Tallapragada K, Park MY, Chapman JR, Carr SJ. Polyclonal and monoclonal antibodies for treating acute rejection episodes in kidney transplant recipients. Cochrane Database Syst Rev. 2017;7:CD004756. – referência 76  
8. Zhu Y, Zhou Y, Zhang L, Zhang J, Lin J. Efficacy of interventions for adherence to the immunosuppressive therapy in kidney transplant recipients: a meta-analysis and systematic review. J Investig Med. 2017;65(7):1049-56. – referência 122  
9. Howell M, Wong G, Turner RM, Tan HT, Tong A, Craig JC, et al. The Consistency and Reporting of Quality-of-Life Outcomes in Trials of Immunosuppressive Agents in Kidney Transplantation: A Systematic Review and Meta-analysis. Am J Kidney Dis. 2016;67(5):762-74. – referência 125  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização do PCDT.  
Após a consulta pública os seguintes estudos foram incluídos no texto:  
1. Loupy A, Haas M, Roufosse C, et al. The Banff 2019 Kidney Meeting Report (I): Updates on and clarification of criteria for T cell- and antibody-mediated rejection [published online ahead of print, 2020 May 28]. Am J Transplant. 2020;10.1111/ajt.15898 – referência 21  
2. Tedesco-Silva H, Pascual J, Viklicky O, et al. Safety of Everolimus With Reduced Calcineurin Inhibitor Exposure in De Novo Kidney Transplants: An Analysis From the Randomized TRANSFORM Study. Transplantation. 2019;103(9):1953-1963 – referência 52  
3. Anil Kumar MS, Irfan Saeed M, Ranganna K, et al. Comparison of four different immunosuppression protocols without long-term steroid therapy in kidney recipients monitored by surveillance biopsy: five-year outcomes. Transpl Immunol. 2008;20(1-2):32-42 – referência 53  
4. Schinstock CA, Mannon RB, Budde K, et al. Recommended Treatment for Antibody-mediated Rejection After Kidney Transplantation: The 2019 Expert Consensus From the Transplantion Society Working Group. Transplantation. 2020;104(5):911-922 – referência 79  
5. de Fijter JW. Cancer and mTOR Inhibitors in Transplant Recipients. Transplantation. 2017;101(1):45-55 – referência 113.

---

