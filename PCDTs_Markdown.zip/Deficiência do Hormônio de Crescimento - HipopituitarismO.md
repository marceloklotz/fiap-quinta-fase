<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS.  
PORTARIA CONJUNTA Nº 28, DE 30 DE NOVEMBRO DE 2018  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Deficiência do Hormônio de Crescimento - Hipopituitarismo.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a deficiência do hormônio do crescimento (hipopituitarismo) no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup>o</sup> 333/2018 e o Relatório de Recomendação n<sup>o</sup> 351 – Março de 2018 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas - Deficiência do Hormônio de Crescimento - Hipopituitarismo.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da deficiência do hormônio de crescimento, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado</u> pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da deficiência do hormônio de crescimento.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 110/SAS/MS, de 10 de março de 2010, publicada no Diário Oficial da União nº 89, de 15 de maio de 2010, seção 1, páginas 57 a 59.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN  
ANEXO

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS -->
DEFICIÊNCIA DE HORMÔNIO DO CRESCIMENTO - HIPOPITUITARISMO

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **1. INTRODUÇÃO** -->
O hormônio do crescimento (GH) é um polipeptídio produzido e secretado por células especializadas localizadas na hipófise anterior, cuja principal função é a promoção do crescimento e desenvolvimento corporal; além disso, participa da regulação do metabolismo de proteínas, lipídeos e carboidratos (1). O eixo fisiológico GH/fator de crescimento insulina- _like_ (IGF-1) exerce efeitos cardiovasculares relevantes, regulando o crescimento cardíaco e a contratilidade miocárdica e contribuindo para a manutenção da massa e da função cardíacas no adulto normal. (2)  
A deficiência de GH (DGH) pode ser congênita ou adquirida. As causas congênitas são menos comuns e podem ou não estar associadas a defeitos anatômicos. As causas adquiridas incluem tumores e doenças infiltrativas da região hipotálamo-hipofisária, tratamento cirúrgico de lesões hipofisárias, trauma, infecções e infarto hipofisário ou radioterapia craniana (3,4).  
A DGH ocorre de maneira isolada ou em associação a outras deficiências de hormônios hipofisários. A persistência de DGH em crianças implica falha de crescimento e, nos casos graves, dificuldade de manutenção de normoglicemia (5). Com a reposição de GH há aumento da altura, do peso e da velocidade de crescimento com melhora do perfil lipídico que se encontra alterado, com diminuição do colesterol total, do colesterol-LDL e dos triglicerídios, com diminuição da espessura da íntima-média carotídea e melhora do nível do colesterol-HDL. (6)  
Nos adultos com DGH, as principais consequências são dislipidemia, maior risco cardiovascular, baixa mineralização óssea e fraqueza muscular (7). O risco cardiovascular aumenta pela aceleração da ateroesclerose e pelas alterações metabólicas, com altos níveis do colesterol total e do colesterol-LDL, níveis baixos de colesterol-HDL associados à resistência à insulina e ao aumento da proteína C reativa.  Independentemente da faixa etária, a não correção do déficit hormonal leva à deposição de gordura abdominal e à diminuição da massa magra em relação à massa gorda. Sendo assim, a reposição de GH altera a composição corporal, com aumento da massa magra, diminuição da massa gorda e redução do colesterol-LDL, sem afetar os níveis de glicose, da HbA1c ou da pressão arterial. O uso de GH é capaz de melhorar  
o bem estar dos pacientes, a performance cognitiva, a densidade mineral óssea e a função cardíaca, ao mesmo tempo que reduz o risco de câncer. A suplementação de GH melhora a qualidade de vida dos portadores de DGH.   (2, 5, 7)  
Inexistem estudos brasileiros sobre a incidência da DGH. Em um estudo americano, a incidência foi de um em cada 3.480 nascidos vivos (8).  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da deficiência do hormônio de crescimento. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
E23.0 Hipopituitarismo

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Os principais achados clínicos em crianças com DGH são baixa estatura e redução na velocidade de crescimento. É importante salientar que outras causas de baixa estatura, como displasias esqueléticas, síndrome de Turner (em meninas) e doenças crônicas, devem ser excluídas (3).  
A investigação para DGH está indicada nas seguintes situações:  
- baixa estatura grave, definida como estatura (comprimento/altura) inferior a 3 desviospadrão (escore z = -3) da curva da Organização Mundial da Saúde (OMS) (9);  
- baixa estatura, definida como estatura entre -3 e -2 desvios-padrão (escore z = -2 a -3) da estatura prevista para idade e sexo (9), associada à redução na velocidade de crescimento, definida como velocidade de crescimento inferior ao percentil 25 da curva de velocidade de crescimento (10,11);  
- estatura acima de -2 desvios-padrão para idade e sexo, associada a uma baixa velocidade de crescimento (abaixo de -1 desvio-padrão da curva de velocidade de crescimento em 12 meses) (3);  
- presença de condição predisponente, como lesão intracraniana e irradiação do sistema nervoso central (SNC);  
- deficiência de outros hormônios hipofisários;  
- sinais e sintomas de DGH/hipopituitarismo no período neonatal (hipoglicemia, icterícia prolongada, micropênis, defeitos de linha média).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
A DGH em adultos pode ser isolada ou associada a outras deficiências hormonais, e pode ser decorrente de duas situações (7):  
- persistência da DGH iniciada na infância;  
- presença de lesão da região hipotálamo-hipofisária (tumor, irradiação, trauma, doença inflamatória ou infecciosa) surgida na vida adulta.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Na avaliação da baixa estatura, a dosagem de somatomedina-C ( _insulin-like growth factor 1_ – IGF-1) é relevante, porém tem baixa especificidade isoladamente (12). Valores de IGF-1 acima da média para idade e sexo são forte evidência contra o diagnóstico de DGH, que deve ser confirmado pela realização de testes provocativos da secreção de GH e pela dosagem de IGF-1. Os testes provocativos envolvem estímulos como administração de insulina, clonidina, levodopa e glucagon, conforme protocolos específicos (5, 13). O teste com hipoglicemia insulínica não deve ser realizado em crianças com história de convulsões, cardiopatias ou com menos de 20 kg. As técnicas que utilizam anticorpos monoclonais, como quimioluminescência e imunofluorimetria, são as mais utilizadas, e o ponto de corte utilizado é uma concentração de GH inferior a 5 ng/mL (13-16).  
Em situações específicas, pode-se prescindir dos testes de estímulo:  
1. Pacientes com critérios auxológicos - relacionados ao crescimento -, compatíveis, defeito anatômico hipotalâmico-hipofisário, tumor, irradiação e uma deficiência hormonal adicional;  
2. Pacientes com hipopituitarismo congênito, ou seja, bebês com dosagem de GH < 5 mcg/L em  vigência de hipoglicemia e ao menos 1 deficiência adicional ou alteração clássica em exame de imagem (12).  
Nos casos de suspeita de deficiência isolada de GH, são necessários dois testes provocativos para que se estabeleça o diagnóstico. Em pacientes que apresentam lesão anatômica ou defeitos da região hipotálamo-hipofisária, história de tratamento com radioterapia ou deficiência associada de outros hormônios hipofisários, apenas um teste provocativo é necessário para o diagnóstico. No caso de deficiência de outros hormônios hipofisários, estes devem estar adequadamente repostos antes da realização do teste.  
No período pré-puberal ou puberal inicial, quando ainda não há estímulo endógeno suficiente para desenvolvimento ou progressão dos caracteres sexuais secundários ( **Apêndice 2** - Critérios de Tanner) (17,18), os testes de estímulo de GH podem ser falsamente negativos. Para discriminar entre DGH e retardo constitucional do crescimento e da puberdade (RCCP), pode-se realizar uso prévio ( _priming_ ) de hormônios sexuais antes da realização do teste provocativo de secreção de GH, conforme descrito abaixo:  
- meninas com idade a partir de 10 anos e estágio puberal abaixo de M3 e P3 de Tanner ( **Apêndice 2** ) (17,18): ß estradiol na dose de 1 mg para meninas com peso menor de 20 Kg e ß estradiol 2 mg para maiores de 20 Kg , via oral, 2 doses, administradas nas 2 noites antes da realização do teste (adaptado de 19, 12);  
- meninos com idade a partir de 11 anos e estágio puberal abaixo de P3 de Tanner ( **Apêndcie 2** ) (16,17): cipionato de testosterona 50-100 mg IM, 1 semana antes da realização do teste (adaptado de 19,12).  
Crianças com baixa velocidade de crescimento, baixa estatura para o alvo genético e atraso de idade óssea que respondem ao teste de estímulo com _priming_ são mais provavelmente indivíduos com RCCP. Inexiste, no entanto, consenso sobre a realização de _priming_ para o diagnóstico de DGH.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
A comprovação da DGH iniciada na vida adulta requer, além de níveis baixos de IGF-1 para a idade, a realização de um teste de estímulo, especialmente na presença de outras deficiências de hormônios hipofisários, história de cirurgia ou traumatismo cranianos, doença com prejuízo estrutural do hipotálamo ou hipófise (20). Pacientes com deficiência isolada de GH na infância devem ser sempre retestados (7, 15). Considera-se deficiência valores de GH no estímulo < 5 ng/mL e deficiência grave concentração de GH inferior a 3 ng/mL (7), mas há  
sugestão de ponto de corte diverso para gravidade dependendo do estímulo (insulina < 5 ng/mL; glucagon < 3 ng/mL) (20).  O paciente com DGH adulto normalmente apresenta sintomas de deficiência, como dislipidemia, osteoporose, adiposidade abdominal e astenia.  
Para que os testes de estímulo sejam valorizados, é imprescindível que os pacientes com outras deficiências hipotálamo-hipofisárias estejam fazendo adequada reposição hormonal (7, 15).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Em crianças maiores de 2 anos com baixa estatura e redução na velocidade de crescimento, a avaliação da idade óssea é um método auxiliar importante (14). Na DGH, em geral, a idade óssea tem um atraso maior que dois desvios-padrão. Na suspeita clínica, com confirmação laboratorial de DGH, deverá ser realizada avaliação por imagem, preferencialmente, ressonância nuclear magnética (RNM)] da região hipotálamo-hipofisária para buscar alterações anatômicas auxiliares no diagnóstico (transecção de haste hipofisária, neuro-hipófise ectópica, hipoplasia de hipófise, lesões expansivas selares ou displasia septoóptica). Na impossibilidade de realizar RNM, a tomografia computadorizada (TC) pode ser o exame de imagem auxiliar.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
No caso de DGH iniciada na vida adulta, também deverá ser realizada avaliação por imagem (TC ou, preferencialmente, RNM) da região hipotálamo-hipofisária. A avaliação da densidade mineral óssea por meio de densitometria permite identificar a presença de osteoporose, que tem PCDT do Ministério da Saúde específico.  
As seguintes informações são necessárias para a confirmação diagnóstica:  
**Crianças e adolescentes**  
- Idade, peso e altura atuais;  
- Peso e comprimento ao nascer, idade gestacional (na impossibilidade de fornecer tais  
- dados, como em casos de crianças adotivas, justificar a não inclusão dos mesmos);  
- Velocidade de crescimento no último ano ou curva de crescimento (preferencialmente)  
- em crianças maiores de 2 anos;  
- Estadiamento puberal;  
- Altura medida dos pais biológicos (na impossibilidade de fornecer tais dados, como em casos de crianças adotivas, justificar a não inclusão dos mesmos);  
- Radiografia de mãos e punhos, para determinação da idade óssea;  
- IGF-1, glicemia, hormônio estimulante da tireoide (em inglês, _thyroid-stimulating hormone_ – TSH) e tiroxina (T4) total ou livre (e demais exames do eixo hipofisário, no caso de pan-hipopituitarismo), e as reposições hormonais realizadas;  
- Testes para GH com datas e estímulos diferentes com valores de pico de GH < 5 ng/mL  
- (informar se foi realizado _priming_ com estradiol ou testosterona);  
- Em lactentes, sinais e sintomas clássicos de DGH/hipopituitarismo incluem hipoglicemia, icterícia prolongada, micropênis e defeitos de linha média. Nessa situação, pode-se confirmar o diagnóstico apenas com uma dosagem de GH e cortisol na vigência de hipoglicemia. No caso de múltiplas deficiências hormonais no lactente e alteração na RNM com IGF-1 abaixo do limite inferior da normalidade, pode-se prescindir do teste de estímulo. [A RNM não é um exame indispensável, mas pode ser considerada como critério de investigação adicional.]  
- Idade;  
- Comprovar deficiência prévia, se existente;  
- Fatores de risco para deficiência iniciada na vida adulta (traumatismo, irradiação no  
- SNC, cirurgias no SNC, doenças que acometem o eixo hipotálamo-hipofisário);  
- IGF-1, glicemia, TSH e T4 total ou livre (e demais exames do eixo hipofisário, no caso de pan-hipopituitarismo);  
- Reposições realizadas, se pertinente;  
- Exame de imagem (RNM de hipófise, preferencialmente, mas não é um exame indispensável, mas pode ser considerada como critério de investigação adicional);  
- Teste de estímulo para GH;  
- Densitometria óssea;  
- Perfil lipídico: colesterol total, colesterol HDL e triglicerídeos séricos.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com diagnóstico de DGH conforme os critérios estabelecidos no item 3. DIAGNÓSTICO e que também apresentem:

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes:** -->
- déficit de crescimento;  
- deficiência comprovada de GH (por meio de dois testes de estímulo quando houver deficiência isolada sem alteração anatômica de hipófise; por uma dosagem de GH em hipoglicemia em caso de sintomas presentes quando lactente (descritos acima); por meio de 1 teste de estimulo na presença de múltiplas deficiências hormonais (pan-hipopituitarismo) ou lesão hipofisária (alteração e exame de imagem, conforme descrito acima).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos:** -->
- deficiência comprovada de GH por reteste, com estímulo de insulina ou clonidina, quando houver deficiência isolada de GH na infância (comprovar deficiência prévia na infância);  
- deficiência comprovada de GH (pico de GH < 3 ng/mL) por teste quando houver sintomas iniciados na vida adulta (descritos acima), múltiplas deficiências hormonais (panhipopituitarismo) ou lesão hipofisária (alteração em exame de imagem, radioterapia, cirurgia no eixo hipotálamo-hipófise, conforme descrito acima).  
- no caso de pico de GH < 5 ng/mL, deve apresentar ao menos um dos fatores abaixo:  
- baixa densidade mineral óssea;  
- dislipidemia;  
- prejuízo no exercício das atividades habituais, atestado pelo médico.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem qualquer uma das  
seguintes condições:  
- doença neoplásica maligna ativa;  
- doença aguda grave (com mais de 1 mês de evolução e que repercute nas funções vitais  
- do indivíduo);  
- hipertensão intracraniana benigna;  
- retinopatia diabética proliferativa ou pré-proliferativa;  
- intolerância ao uso do medicamento;  
- outras causas de baixa estatura para crianças;  
- adolescentes com displasias esqueléticas, síndrome de Turner (em meninas) e doenças  
- crônicas.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **6. CASOS ESPECIAIS** -->
Em situações de doença neoplásica prévia, o tratamento com somatropina somente poderá ser utilizado após liberação documentada por oncologista ou endocrinologista, decorridos 2 anos do tratamento e com remissão completa da doença (21,22).  
Pacientes com critérios clínicos e auxológicos sugestivos de DGH com valores de GH no teste de estímulo entre 5 e 10 devem ser preferentemente avaliados em Centros de Referência, e o tratamento com GH pode ser considerado. Para estes, a reavaliação precoce do _status_ do GH durante o tratamento da DGH isolada é recomendada para pacientes que alcançaram altura < 0,61 desvio-padrão após o primeiro ano de tratamento, especialmente para aqueles com imagem de pituitária normal ou hipoplásica, para evitar tratamentos desnecessários naqueles que não respondem ao tratamento. (23)  
Pacientes nascidos pequenos para idade gestacional (PIG) e com síndromes genéticas com evidência de benefício do uso de GH devem ser avaliados em Centros de Referência ou por equipe técnica especializada.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **7. CENTROS DE REFERÊNCIA** -->
Os pacientes devem passar por avaliação diagnóstica e ter acompanhamento terapêutico com endocrinologistas ou pediatras, cuja avaliação periódica deve ser condição para a continuidade da dispensação do medicamento.  
Pacientes com hipopituitarismo devem ser avaliados com relação à eficácia do tratamento e ao desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses, caso necessário, e o controle de efeitos adversos.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **8. TRATAMENTO** -->
O tratamento da DGH foi realizado inicialmente com a administração de hormônio do crescimento obtido a partir da hipófise de cadáveres humanos. Essa forma de tratamento foi suspensa em 1985, por estar relacionada à ocorrência da doença de Creutzfeldt-Jakob (encefalopatia) (24). Nesse mesmo período, tornou-se disponível a somatropina humana recombinante, forma biossintética que substituiu o tratamento anterior (25).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Em uma revisão sistemática que teve como objetivo avaliar o uso de GH humano recombinante em doenças para as quais este tratamento está recomendado, somente um estudo de tratamento contra não tratamento para crianças com DGH foi localizado (26). Nesse ensaio clínico randomizado (ECR), 77 crianças com baixa estatura foram submetidas a testes provocativos de secreção de GH e então randomizadas, de acordo com a resposta dos testes, para tratamento com diferentes doses de GH ou para não tratamento. Os resultados foram analisados após 1 ano. Dos 77 pacientes, em apenas dois grupos (n = 19) a comparação do tratamento com GH é possível, pois há pareamento entre pacientes com DGH tratados e não tratados. O estudo mostrou melhora no desvio-padrão da altura (-2,3±0,45 versus -2,8±0,45; p < 0,05) e na velocidade de crescimento (8,4±1,4 versus 5,7±1,8; p < 0,05) entre tratados e não tratados, respectivamente. No entanto, esse estudo apresenta limitações metodológicas importantes (não há descrição do método de randomização; o estudo é aberto; não há descrição de outros desfechos, como qualidade de vida). (27)  
Um segundo ECR foi realizado nesse contexto para testar diferentes doses de GH. Nesse estudo, 35 crianças foram randomizadas para o recebimento de duas doses de GH: 0,7 mg/m<sup>2</sup> /dia (aproximadamente 0,025 mg/kg/dia) ou 1,4 mg/m<sup>2</sup> /dia (aproximadamente 0,050 mg/kg/dia). Os resultados demonstraram que os pacientes tratados com a dose mais baixa de GH apresentaram altura na idade final de 4-5 cm menor do que o esperado, enquanto os pacientes tratados com a dose mais alta tiveram uma diferença de 0-2 cm. Essa diferença, porém, não foi estatisticamente significativa. (28)  
Além desses ECRs, os estudos de coorte, embora não apresentem grupo de comparação e tenham sido realizados a partir de banco de dados da indústria farmacêutica, representam a principal evidência de benefício do tratamento com somatropina em crianças com DGH. No estudo de Cutfield et al., houve melhora do desvio-padrão da altura de -3,1 pré-tratamento para -1,5 pós-tratamento, por uma mediana de 8,1 anos (29). No estudo de August et al., houve melhora de -2,6 para -1,3 após um tempo médio de tratamento de 4,5 anos (30).  
Em uma análise de custo-efetividade realizada pelo sistema de saúde inglês a partir dos resultados dos estudos publicados, o tratamento com somatropina em crianças com DGH foi considerado custo-efetivo naquele país (31).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
Em relação ao tratamento de pacientes adultos com GH, embora não haja consenso de quais pacientes devam ser tratados, a recomendação deve ser individualizada (32). Existem evidências oriundas de meta-análises de benefícios sobre densidade mineral óssea (33-35), fatores de risco cardiovasculares e qualidade de vida. (2,34, 36)  
Meta-análise recente, de suplementação com GH em pacientes adultos com DGH em curto ou longo prazo, mostrou que a terapia é segura e que provavelmente leva a diminuição significativa no risco cardiovascular, embora não tenha havido demonstração quantitativa deste efeito. O benefício está relacionado à diminuição do colesterol-LDL demonstrado, além de não ter havido prejuízo ao metabolismo da glicose ou à pressão arterial. Estes resultados permanecem independente da causa da DGH, idiopática ou panhipopituitarismo. (2)  
ECR avaliou o efeito de níveis normais baixos versus normais altos de IGF-1 na cognição e bem-estar de pacientes adultos com DGH, durante tratamento com GH por pelo menos um ano. Verificou-se que mulheres no braço de dose baixa de GH tiveram melhor memória de controle estratégico e de trabalho após 24 semanas de tratamento em oposição ao braço de mulheres com dose alta. Em relação ao humor, os níveis diminuídos de IGF-1 nas mulheres com dose menor estão associados a mais fadiga e menos vigor. O ajuste de dose nas pacientes do sexo feminino deve ser mais estreito, sendo que uma dose muito alta pode prejudicar a função cognitiva prefrontal, enquanto a dose mais baixa está associada com mais fadiga e menos vigor. (37)  
ECR aberto anterior de mesma autoria comparou alvos de IGF-1 normais altos e normais baixos, com doses mais altas e mais baixas de GH, respectivamente, para avaliar eficácia e segurança do tratamento. Verificaram que, apesar da dose mais alta para níveis normais altos de IGF-1, diminuir a circunferência abdominal (p=0,05) especialmente em mulheres e melhorar o bem estar geral dos pacientes (p= 0,04), houve mais queixas de mialgia. Ao mesmo tempo, a dose mais baixa com níveis normais baixos de IGF-1 causou mais fadiga, na comparação. A segurança da dose mais alta não é garantida, com diferença nos gêneros e aparecimento de mialgias. (38)  
Não parece haver maior incidência de neoplasias em pacientes em uso de GH. Pelo contrário, meta-análise de 2016 mostra que a terapia com GH está associada a risco diminuído de câncer em pacientes adultos com DGH. (39) Alguns pacientes com diabetes melito podem precisar de ajustes no tratamento (40). A mortalidade também não parece ser afetada pelo tratamento (34).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **8.1 FÁRMACO** -->
Somatropina injetável: 4 UI, 12UI, 15UI, 16UI, 18UI, 24UI e 30UI.  
Na fórmula de conversão, 1 mg equivale a 3 UI. Há apresentações comerciais com volumes de diluente diferentes para a mesma dose de hormônio, o que deverá ser observado na prescrição e orientação ao paciente.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Somatropina: 0,025-0,035 mg/kg/dia ou 0,075-0,10 UI/kg/dia, administrada por via subcutânea, à noite, 6-7 vezes/semana, ajustada conforme peso corporal, velocidade de crescimento e níveis de IGF-1 (12).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
Somatropina: 0,15-0,3 mg/dia ou 0,5-1,0 UI/dia (independentemente do peso corporal), ajustada com dosagem de IGF-1 (7, 41, 42).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **8.3 TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
O tratamento com somatropina deverá ser interrompido nas seguintes situações:  
- crianças em período de crescimento: quando a velocidade de crescimento for inferior a 2 cm por ano, e esse achado estiver associado à idade óssea de 14-15 anos em meninas e de 16 anos em meninos (43);  
- não comparecimento a duas consultas subsequentes dentro de um intervalo de 3 meses, sem justificativa adequada;  
- em caso de intercorrência, como processo infeccioso grave ou traumatismo com necessidade de internação, o tratamento deverá ser interrompido durante 1 a 2 meses ou até que o paciente se recupere;  
- em caso de câncer surgido ou recidivado durante o tratamento, interromper e somente reiniciar após 2 anos livre da doença, conforme liberação feita pelo oncologista.  
- idade avançada deve ser levada em conta para a suspensão do tratamento, já que não se verificou efeitos adversos óbvios nos parâmentros metabólicos em um ano, além de aumento da massa gorda e diminuição dos marcadores de turnover ósseo. Os efeitos adversos ocorrem mais nos pacientes com menos de 60 anos. Nos pacientes com > 60 anos, os cuidados de rotina cardiovascular em relação à dislipidemia e hipertensão arterial devem ser seguidos conforme diretrizes, após a suspensão do GH. Outro racional para a restrição da terapia com GH nos idosos é o declínio fisiológico da atividade do eixo GH-IGF-1 com a idade, melhorando a longevidade. (44)

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **8.4 BENEFÍCIOS ESPERADOS** -->
> - aumento da velocidade de crescimento e da previsão de estatura em crianças;  
- aumento da densidade mineral óssea e melhora da dislipidemia em adultos;  
- melhora da qualidade de vida.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
A monitorização do tratamento com somatropina em crianças e adolescentes deverá ser realizada a partir de consultas médicas especializadas, com aferição das medidas antropométricas a cada 3-6 meses. Exames laboratoriais para avaliação da glicemia de jejum e da função tireoidiana devem ser realizados a cada ano. No caso de alteração da função tireoidiana, com sugestão de hipotireoidismo, o tratamento deve ser feito com levotiroxina. Exame radiológico para avaliação da idade óssea também deverá ser realizado anualmente. Como forma de verificação do uso adequado da somatropina e monitorização da dose, deve ser realizada dosagem de IGF-1 anualmente ou após mudança de dose. Recomenda-se manter a dose de somatropina para pacientes com valores de IGF-1 dentro da normalidade e com velocidade de crescimento adequada. Em pacientes com crescimento insatisfatório e valores baixos de IGF-1, a aderência ao tratamento deve ser checada e o diagnóstico deve ser reavaliado. No caso de serem observados valores de IGF-1 acima dos limites superiores da normalidade, a dose de somatropina deve ser reduzida, com nova medida da IGF-1 após 30-60 dias, e assim sucessivamente até a normalização dos níveis de IGF-1. Em casos de boa adesão ao tratamento, mas níveis de IGF-1 baixos para a idade óssea e velocidade de crescimento aquém do desejado, recomenda-se ajuste de dose para o peso, visando níveis satisfatórios de IGF-1 e aumento da velocidade de crescimento.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
Em caso de tratamento após o final do crescimento e para o adulto com deficiência de GH, a dosagem de IGF-1 poderá ser realizada um mês após cada mudança de dose, até o estabelecimento da dose adequada. A partir de então, a dosagem poderá ser realizada anualmente. A meta para adequação da dose é manter os níveis de IGF-1 próximos da média para a idade, de acordo com as técnicas e os limites laboratoriais, ou entre a média e o limite superior da normalidade (7, 41, 42). Mulheres em uso de estrogênios orais podem necessitar de doses um pouco mais elevadas, em função da interferência no metabolismo hepático e na síntese de IGF-1 (20). Devem ser monitorizadas complicações da falta de reposição, como dislipidemia e osteoporose (ver os respectivos protocolos do Ministério da Saúde), além da inadequada distribuição de gordura corporal e baixa resistência a atividades físicas, e  
complicações do excesso de reposição, como alterações glicêmicas, características acromegálicas e miocardiopatia hipertrófica (7, 15, 20).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Segurança** -->
A somatropina é considerada um medicamento seguro, com raros efeitos colaterais graves. Deve-se atentar para o risco de desenvolvimento de intolerância à glicose e hipertensão intracraniana benigna. (45) Pacientes com doença neoplásica prévia deverão ser conjuntamente acompanhados por oncologista ou neurocirurgião. Em uma grande série de casos, não houve aumento da recorrência de neoplasia ou da incidência de novos casos em pacientes em uso de somatropina (22).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Crianças e adolescentes** -->
Encerrada a fase de crescimento, interrompe-se o tratamento e, após 30 a 90 dias, testase novamente. É necessário apenas um teste, e o estímulo deve ser com insulina ou glucagon. No reteste, para comprovar a persistência da DGH no período de transição para a vida adulta, considera-se uma IGF-1 baixa para faixa etária e sexo, e uma concentração de GH inferior a 5 ng/ml no teste de estímulo (46-48).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **Adultos** -->
Nos casos de DGH grave (menor que 3 ng/mL), a reposição hormonal é considerada permanente, ajustando-se a dose conforme os níveis de IGF-1 (7, 41, 42).

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **11. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Os doentes devem passar por avaliação diagnóstica e ter acompanhamento terapêutico com endocrinologistas ou endocrinologistas pediátricos, cuja avaliação periódica deve ser condição para a continuidade da dispensação do medicamento.  
Recomenda-se a indicação de centro de referência para avaliação e monitorização clínica das respostas terapêuticas, decisões de interrupção de tratamento e avaliação de casos complexos e de difícil diagnóstico.  
Há de se observar os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, a verificação periódica das doses prescritas e dispensadas, a adequação de uso do medicamento e o acompanhamento pós-tratamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **12. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **13. REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. Thorner MO, Vance M, Laws Jr E, Horvalth E, Kovacs K. The anterior pituitary. In: Wilson JD, Foster DW, Kronenberg HM, Larsen PR, editors. Williams textbook of  endocrinology. 9th ed. Philadelphia: WB Saunders Company; 1998. p. 249-341.  
2. Giagulli VA, Castellana M, Perrone R, Guastamacchia E, Iacoviello M, Triggiani V. GH Supplementation Effects on Cardiovascular Risk in GH Deficient Adult Patients: A Systematic Review and Meta-analysis. Endocr Metab Immune Disord Drug Targets. 2017 Nov 16;17(4):285-296.3.  Reiter E, Rosenfeld R. Normal and aberrant growth. In: Wilson JD, Foster DW, Kronenberg HM, Larsen PR, editors. Williams textbook of endocrinology. 9th ed. Philadelphia: WB Saunders Company; 1998. p. 1427-509.  
4. Adan L, Trivin C, Sainte-Rose C, Zucker JM, Hartmann O, Brauner R. GH deficiency caused by cranial irradiation during childhood: factors and markers in young adults. J Clin Endocrinol Metab. 2001;86(11):5245-51.  
5. Richmond EJ, Rogol AD. Growth hormone deficiency in children. Pituitary. 2008;11(2):115-20.  
6. Chen M, Gan D, Luo Y, Rampersad S, Xu L, Yang S, Li N, Li H. Effect of recombinant human growth hormone therapy on blood lipid and carotid intima-media thickness in children with growth hormone deficiency. Pediatr Res. 2018 May;83(5):954-960.  
7. Jallad RS, Bronstein MD. [Growth hormone deficiency in adulthood: how to diagnose and when to treat?]. Arq Bras Endocrinol Metabol. 2008;52(5):861-71.  
8. Lindsay R, Feldkamp M, Harris D, Robertson J, Rallison M. Utah Growth Study: growth standards and the prevalence of growth hormone deficiency. J Pediatr. 1994;125(1):29-35. 9. de Onis M, Onyango AW, Borghi E, Siyam A, Nishida C, Siekmann J. Development of a WHO growth reference for school-aged children and adolescents. Bull World Health Organ. 2007;85(9):660-7.  
10. Tanner JM, Davies PS. Clinical longitudinal standards for height and height velocity for North American children. J Pediatr. 1985;107(3):317-29.  
11. Rosenfield R, Tanner J, Healy M, Zachman M, Blizzard R. Height and Height Velocity [letter]. 5(2):8-9. Growth, Genetics & Hormones; 1988; 5(2):8-9.  
12. Grimberg et al. PES GH/IGF-I Guidelines. Horm Res Paediatr 2016;86: 361–397.  
13 Paula LP, Czepielewski MA. [Evaluating diagnosis methods on childhood GH (DGH) deficiency: IGFs, IGFBPs, releasing tests, GH rhythm and image exams]. Arq Bras Endocrinol Metabol. 2008;52(5):734-44.  
14. Growth Hormone Research Society. Consensus guidelines for the diagnosis and treatment of growth hormone (GH) deficiency in childhood and adolescence: summary statement of the GH Research Society. J Clin Endocrinol Metab. 2000;85(11):3990-3.  
15. Shalet SM, Toogood A, Rahim A, Brennan BM. The diagnosis of growth hormone deficiency in children and adults. Endocr Rev. 1998;19(2):203-23.  
16. Tauber M. Growth hormone testing in KIGS. In: Ranke MB, Price DA, Reiter EO, editors. Growth hormone therapy in pediatrics – 20 years of KIGS. Basel: Karger; 2007. p. 5485.  
17. Tanner JM. Growth at adolescence. 2nd ed. Oxford: Blackwell field, IL: Charles C Thomas; 1962.  
18. Carel JC, Léger J. Clinical practice. Precocious puberty. N Engl J Med. 2008;358(22):2366-77.  
19. Martinez AS, Domené HM, Ropelato MG, Jasper HG, Pennisi PA, Escobar ME, et al. Estrogen priming effect on growth hormone (GH) provocative test: a useful tool for the diagnosis of GH deficiency. J Clin Endocrinol Metab. 2000;85(11):4168-72.  
20. Reed ML, Merriam GR, Kargi AY. Adult growth hormone deficiency - benefits, side effects, and risks of growth hormone replacement. Front Endocrinol (Lausanne). 2013;4:64. 21. Guidelines for the use of growth hormone in children with short stature. A report by the Drug and Therapeutics Committee of the Lawson Wilkins Pediatric Endocrine Society. J Pediatr. 1995;127(6):857-67.  
22. Blethen SL, Allen DB, Graves D, August G, Moshang T, Rosenfeld R. Safety of recombinant deoxyribonucleic acid-derived growth hormone: The National Cooperative Growth Study experience. J Clin Endocrinol Metab. 1996;81(5):1704-10.  
23. Vuralli D, Gonc EN, Ozon ZA, Alikasifoglu A, Kandemir N. Clinical and laboratory parameters predicting a requirement for the reevaluation of growth hormone status during growth hormone treatment: Retesting early in the course of GH treatment. Growth Horm IGF Res. 2017 Jun;34:31-37  
24. Hintz RL. The prismatic case of Creutzfeldt-Jakob disease associated with pituitary growth hormone treatment. J Clin Endocrinol Metab. 1995;80(8):2298-301. 25. Vance ML, Mauras N. Growth hormone therapy in adults and children. N Engl J Med. 1999;341(16):1206-16.  
26. Takeda A, Cooper K, Bird A, Baxter L, Frampton GK, Gospodarevskaya E, et al. Recombinant human growth hormone for the treatment of growth disorders in children: a systematic review and economic evaluation. Health Technol Assess. 2010;14(42):1-209, iii-iv. 27. Soliman AT, abdul Khadir MM. Growth parameters and predictors of growth in short children with and without growth hormone (GH) deficiency treated with human GH: a randomized controlled study. J Trop Pediatr. 1996;42(5):281-6.  
28. Sas TC, de Ridder MA, Wit JM, Rotteveel J, Oostdijk W, Reeser HM, et al. Adult height in children with growth hormone deficiency: a randomized, controlled, growth hormone dose-response trial. Horm Res Paediatr. 2010;74(3):172-81. 29. Cutfield W, Lindberg A, Albertsson Wikland K, Chatelain P, Ranke MB, Wilton P. Final height in idiopathic growth hormone deficiency: the KIGS experience. KIGS International Board. Acta Paediatr Suppl. 1999;88(428):72-5.  
30. August GP, Julius JR, Blethen SL. Adult height in children with growth hormone deficiency who are treated with biosynthetic growth hormone: the National Cooperative Growth Study experience. Pediatrics. 1998;102(2 Pt 3):512-6.  
31. NICE - National Institute for Clinical Excellence [Internet]. Guidance on the use of human growth hormone (somatropin) in children with growth failure. Technology Appraisal Guidance No. 42 [acesso em 07/05/2010]. Disponível em: www.nice.org.uk.  
32.Molitch ME, Clemmons DR, Malozowski S, Merriam GR, Vance ML. Evaluation and treatment of adult growth hormone deficiency: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab. 2011;96(6):1587-609.  
33.Barake M, Klibanski A, Tritos NA. Effects of recombinant human growth hormone therapy on bone mineral density in adults with growth hormone deficiency: a meta-analysis. J Clin Endocrinol Metab. 2014;99(3):852-60.  
34.Appelman-Dijkstra NM, Claessen KM, Roelfsema F, Pereira AM, Biermasz NR. Longterm effects of recombinant human GH replacement in adults with GH deficiency: a systematic review. Eur J Endocrinol. 2013;169(1):R1-14.  
35.Xue P, Wang Y, Yang J, Li Y. Effects of growth hormone replacement therapy on bone mineral density in growth hormone deficient adults: a meta-analysis. Int J Endocrinol. 2013;2013:216107.  
36.Hazem A, Elamin MB, Bancos I, Malaga G, Prutsky G, Domecq JP, et al. Body composition and quality of life in adults treated with GH therapy: A systematic review and meta-analysis. European Journal of Endocrinology. 2012;166(1):13-20.  
37. van Bunderen CC, Deijen JB, Drent ML. Effect of low-normal and high-normal IGF-1 levels on memory and wellbeing during growth hormone replacement therapy: a randomized clinical trial in adult growth hormone deficiency.Health Qual Life Outcomes. 2018 Jul 6;16(1):135.  
38. van Bunderen CC1, Lips P2, Kramer MH3, Drent ML2. Comparison of low-normal and high-normal IGF-1 target levels during growth hormone replacement therapy: A randomized clinical trial in adult growth hormone deficiency. Eur J Intern Med. 2016 Jun;31:88-93.  
39. Li Z, Zhou Q, Li Y, Fu J, Huang X, Shen L. Growth hormone replacement therapy reduces risk of cancer in adult with growth hormone deficiency: A meta-analysis. Oncotarget. 2016 Dec 6;7(49):81862-81869.  
40.van Bunderen CC, van Varsseveld NC, Erfurth EM, Ket JC, Drent ML. Efficacy and safety of growth hormone treatment in adults with growth hormone deficiency: a systematic review of studies on morbidity. Clin Endocrinol. 2014;81(1):1-14.  
41.Consensus guidelines for the diagnosis and treatment of adults with growth hormone deficiency: summary statement of the Growth Hormone Research Society Workshop on Adult Growth Hormone Deficiency. J Clin Endocrinol Metab. 1998;83(2):379-81.  
42.Johannsson G. Treatment of growth hormone deficiency in adults. Horm Res. 2009;71 Suppl 1:116-22.  
43.Rapaport R, Bowlby D. Clinical Aspects of Gowth and Gowth Disorders. In: Pescovitz OH, Eugster EA, editors. Pediatric endocrinology: mechanisms, manifestations, and management. Philadelphia: Lippincott Williams & Willkins; 2004. p. 172-90.  
44. Appelman-Dijkstra NM, Rijndorp M, Biermasz NR, Dekkers OM, Pereira AM. Effects of discontinuation of growth hormone replacement in adult GH-deficient patients: a cohort study and a systematic review of the literature. Eur J Endocrinol. 2016 Jun;174(6):705-16.  
45.Drug Facts and Comparisons. 61th ed. St Louis: Facts and Comparisons; 2007.  
46.Clayton PE, Cuneo RC, Juul A, Monson JP, Shalet SM, Tauber M. Consensus statement on the management of the GH-treated adolescent in the transition to adult care. Eur J Endocrinol. 2005;152(2):165-70.  
47.Molitch ME, Clemmons DR, Malozowski S, Merriam GR, Shalet SM, Vance ML. Evaluation and treatment of adult growth hormone deficiency: an Endocrine Society Clinical Practice Guideline. J Clin Endocrinol Metab. 2006;91(5):1621-34.  
48.Bonfig W, Bechtold S, Bachmann S, Putzker S, Fuchs O, Pagel P, et al. Reassessment of the optimal growth hormone cut-off level in insulin tolerance testing for growth hormone secretion in patients with childhood-onset growth hormone deficiency during transition to adulthood. J Pediatr Endocrinol Metab. 2008;21(11):1049-56.  
49. Secretaria de Ciência, Tecnologia e Insumos Estratégicos/Ministério da Saúde. Torna pública a decisão de incorporar as apresentações do medicamento somatropina, nas concentrações de 15UI, 16UI, 18UI, 24UI e 30UI, para o tratamento da Síndrome de Turner e  
Deficiência do Hormônio do Crescimento-Hipopituitarismo no âmbito do Sistema Único de Saúde – SUS. Portaria n° 47, de 1 de novembro de 2017.  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: SOMATROPINA -->
Eu, ________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento **somatropina** , indicado para o tratamento da **deficiência de hormônio do crescimento** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- aumento da altura e da velocidade de crescimento em crianças;  
- aumento da densidade mineral óssea em adultos;  
- melhora da dislipidemia em adultos.  
Fui também claramente informado (a) a respeito dos seguintes potenciais efeitos adversos, contraindicações e riscos:  
**- somatropina:** medicamento classificado na gestação como categoria C quando utilizado no primeiro e segundo trimestres de gestação (estudos em animais mostraram anormalidades nos descendentes, mas não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- a segurança para o uso da somatropina durante a amamentação ainda não foi estabelecida;  
**- os efeitos adversos da somatropina:** reações no local da injeção, como dor, inchaço e inflamação. Algumas reações mais raras incluem dor de cabeça, dor nos músculos, fraqueza, aumento da glicose no sangue, resistência à insulina, dor no quadril ou nos joelhos, leucemia e hipotireoidismo;  
- o medicamento está contraindicado em casos de hipersensibilidade (alergia) conhecida ao fármaco;  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo, ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de eu desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações  
relativas ao meu tratamento, desde que assegurado o anonimato.      (   ) Sim         (   ) Não  
Local:                                                                                       Data: Nome do <mark>p</mark> aciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identifica <mark>ç</mark> ão do res <mark>p</mark> onsável le <mark>g</mark> al:  
Assinatura do <mark>p</mark> aciente ou do res <mark>p</mark> onsável le <mark>g</mark> al Médico res <mark>p</mark> onsável: CRM: UF: ___________________________ Assinatura e carimbo do médico Data:____________________  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Deficiência do Hormônio de Crescimento - HipopituitarismO | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA  
Para a análise do tratamento de hipopituitarismo em crianças em fase de crescimento e em adultos deficientes de hormônio do crescimento (em inglês, _growth hormone_ – GH), foram realizadas buscas nas bases descritas abaixo até a data limite de 15/08/2009. Por se tratar de tratamento de reposição hormonal, são escassos os estudos randomizados, controlados e duplos-cegos. Foram avaliados os estudos mais relevantes disponíveis em bases, _guidelines_ e consensos.  
Na base MEDLINE/PubMed foram utilizadas as seguintes palavras-chave: "growth hormone deficiency"; “growth hormone deficiency in children”; “growth hormone deficiency in adults”; “growth hormone deficiency in children” and “diagnosis”; “growth hormone  
deficiency in adults” and “diagnosis”; “growth hormone deficiency in children” and “treatment”; “growth hormone deficiency in adults” and “treatment”.  
Na base Embase: 'growth hormone deficiency'/exp AND 'drug therapy'/exp.  
Na base Cochrane: “growth hormone deficiency".  
No site da Organização Mundial da Saúde (OMS): "growth charts"; "growth velocity charts".  
No site do _Centers for Disease Control and Prevention/National Center for Health Statistics_ (CDC/NCHS): "growth charts"; "growth velocity charts".  
Em 19/01/2016, foi realizada uma atualização da busca na literatura com os critérios de inclusão originalmente empregados.  
Na base MEDLINE/PubMed, foi realizada busca com os termos “Growth Hormone Deficiency With Pituitary Anomalies" [Supplementary Concept]) or "Dwarfism, Pituitary"[Mesh]. Nessa busca, foram ativados os filtros ensaio clínico, ensaio clínico randomizado, meta-análise, revisão sistemática, humanos. Foram localizados 20 estudos, e três foram incluídos neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT).  
Na base Embase, também foi realizada busca com a estratégia 'growth hormone deficiency'/exp 'growth hormone deficiency'/exp and ([cochrane review]/lim OR [systematic review]/lim OR [controlled clinical trial]/lim or [randomized controlled trial]/lim OR [meta analysis]/lim) AND [humans]/lim and [15-8-2009]/sd. Nessa busca, foram identificados 153 estudos, e outros cinco estudos foram incluídos no PCDT. Um estudo que foi identificado nessa busca já havia sido incluído por meio da busca realizada na PubMed.  
Também foi realizada busca por revisões sistemáticas da Cochrane com o termo "growth hormone deficiency", mas não foi encontrada nenhuma revisão completa.  
Foram excluídos estudos com desfechos não clínicos, estudos que avaliaram métodos de tratamento alternativos ou técnicas ou produtos não aprovados no Brasil, estudos com graves problemas metodológicos e estudos com resultados inconclusivos ou insuficientes para resultar em nova recomendação. Foi ainda consultada a base de dados UpToDate, versão 19.3, estudos com delineamentos observacionais, guidelines e revisões narrativas sobre o tema.  
Em 01/11/2017, após a publicação da incorporação das apresentações de 15UI, 16UI, 18UI, 24UI e 30UI de somatropina (49), o texto foi revisado e uma referência incluída no PCDT.  
Em 16/10/2018 foi atualizada a busca utilizando as mesmas estratégias, conforme o Quadro 1.  
**Quadro 1** - Buscas sobre intervenções terapêuticas  
|**Base**|**Estratégia**|**Localizad**<br>**os**|**Selecionados**|
|---|---|---|---|
|Medline<br>(via<br>PubMed)|"Growth Hormone Deficiency With<br>Pituitary<br>Anomalies"[Supplementary<br>Concept]<br>OR<br>"Dwarfism,<br>Pituitary"[Mesh]<br>AND<br>((Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp]<br>OR Randomized Controlled Trial[ptyp]<br>OR<br>systematic[sb])<br>AND<br>("2016/01/20"[PDAT]<br>:<br>"2018/10/16"[PDAT])<br>AND<br>"humans"[MeSH Terms])|9|----|
|Embase|'growth hormone deficiency'/exp AND<br>'drug therapy'/exp AND ([cochrane<br>review]/lim OR [systematic review]/lim<br>OR [meta analysis]/lim OR [controlled<br>clinical trial]/lim OR [randomized<br>controlled<br>trial]/lim)<br>AND<br>[humans]/lim AND [embase]/lim AND<br>([english]/lim OR [portuguese]/lim OR<br>[spanish]/lim) AND [2016-2018]/py|75|----|
||Estudos repetidos (7)|77|7<br>**Motivo das exclusões:**<br>- estudos de fase1/2 (13)<br>- estudos de farmacocinética<br>e farmacodinâmica (4)<br>- assunto fora do escopo<br>(20)<br>-<br>estudo<br>observacional/revisão (2)<br>- estudo retrospectivo (1)<br>-<br>medicamento<br>não<br>disponível no Brasil (17)<br>- outra doença (11)<br>- resumo de congresso(2)|  
CRITÉRIOS DE TANNER  
**APÊNDICE 2**  
<!-- Start of picture text -->
Meninas - DesenvolvimentoMamario<br>M1 (pre-puberal) M2 (broto mamario) M3 M4 M5 (mama adulta)<br>Meninas - Pilificagéo Pubiana<br>|<br>P1(pre-puberal) P2 (grandes labios)  P3 P4 P5 (pilificagao adulta)<br>Meninos - Desenvolvimento Genital e Pilificagao Pubiana<br>G1(pre-puberal) G2 G3 G4 G5 (padraio aduito)<br><!-- End of picture text -->  
Fonte: Tanner (14), Carel & Léger J (15)

---

