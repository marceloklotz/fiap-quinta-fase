<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 08, DE 21 DE MAIO DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose do Tipo VII.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre a mucopolissacaridose do tipo VII no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 600/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 605 – Abril de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Mucopolissacaridose do  
Tipo VII.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da mucopolissacaridose do tipo VII, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado</u> pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da mucopolissacaridose do tipo VII.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
SERGIO YOSHIMASA OKANE  
HÉLIO ANGOTTI NETO

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **1. INTRODUÇÃO** -->
A mucopolissacaridose tipo VII (MPS VII), também conhecida como Síndrome de Sly, é uma doença lisossômica, autossômica recessiva, extremamente rara, crônica, debilitante e associada a óbito precoce<sup>1, 2</sup> . Em todo o mundo, a incidência de MPS VII é de aproximadamente 1:300.000 a 1:2.000.000 casos por nascidos vivos<sup>3</sup> e é inferior a 200 pacientes por ano<sup>2</sup> . No Brasil, a incidência de MPS VII foi estimada em 0,026 casos por 100.000 nascidos vivos<sup>4, 5</sup> , tendo sido confirmados 21 casos no período de 1982 e 2019<sup>6</sup> .  
A MPS VII ocorre devido à presença de variantes patogênicas bialélicas no gene _GUSB_ que codifica a beta-glicuronidase (GUSB), e está localizado no cromossomo 7q21—q22. A GUSB tem papel essencial na degradação de glicosaminoglicanos (GAG), especialmente sulfato de condroitina (SC), sulfato de dermatan (SD) e sulfato de heparan (SH), que são constituintes do tecido conjuntivo. A atividade deficiente da GUSB resulta em degradação parcial e acúmulo de GAG em lisossomos de vários tecidos por todo o corpo, incluindo o sistema nervoso central (SNC), com consequente dano celular e disfunção orgânica<sup>1, 7</sup> .  
A heterogeneidade alélica desse gene contribui para a extensa variabilidade clínica apresentada pelos indivíduos com MPS VII<sup>8, 9</sup> , que varia desde hidropisia fetal letal até formas atenuadas em adolescentes ou adultos com cifose torácica. Não existem critérios nítidos que permitam uma classificação exata da apresentação clínica em forma grave, moderada ou atenuada, haja vista que existe um espectro de gravidade. Entretanto, de forma geral, o início das manifestações clínicas no período pré-natal, com presença de hidropisia, caracteriza uma forma grave da doença. As manifestações clínicas da MPS VII incluem macrocefalia, face infiltrada, pescoço curto, opacidade da córnea, _pectus carinatum_ , hepatomegalia, esplenomegalia, hérnia umbilical, hérnia inguinal, disostose múltipla, hipoplasia do processo odontoide, hipertricose, atraso no desenvolvimento neuropsicomotor e hidrocefalia; além disso, infecções respiratórias são comuns nesses indivíduos<sup>10</sup> .  
Entre as manifestações clínicas mais frequentes entre crianças e adultos com MPS VII, de diferentes países, incluindo o Brasil<sup>3</sup> , foram descritas as seguintes: anormalidades cardíacas (50% com valvulopatias e 37% possuíam cardiomiopatias); perda da amplitude de movimento articular (85%), dando origem à mobilidade restrita (78%), contraturas articulares (84%) e rigidez (72%); deformidades da coluna - escoliose (69%), cifose (68%) e gibosidade toraco-lombar (63%). Além disso, as deformidades nas pernas encontradas incluíram _genu valgum_ (63%) e _talipes equinovarus_ (35%). Anormalidades nas mãos incluíram redução do movimento do punho (58%), mãos em garra (56%) e dedos curvos (54%). Displasia acetabular nos quadris foi observada em 53% dos pacientes e 63% tinham dor no quadril ou nas costas quando se curvaram, 88% dos pacientes tinham tronco curto, 85% tinham _pectus carinatum_ ou _excavatum_ e 79% tinham baixa estatura. No âmbito neurológico, 94% dos pacientes mostravam limitações no vocabulário e 86% apresentavam deficiência intelectual<sup>3</sup> .  
As manifestações clínicas e gravidade da doença estão relacionadas ao genótipo e à atividade enzimática residual<sup>3</sup> . Indivíduos com MPS VII podem ir a óbito antes do nascimento ou sobreviver apenas alguns meses ou até os 35 anos de vida<sup>11</sup> , sendo raros os pacientes que sobrevivem até a quinta década de vida<sup>3</sup> , e, em geral, são pacientes com início dos sintomas mais tardio e inteligência normal ou quase normal. Geralmente, a expectativa de vida é reduzida também pelas infecções frequentes do trato respiratório superior, complicações neurodegenerativas e anormalidades do trato gastrointestinal<sup>12</sup> .  
Embora a MPS VII seja uma doença rara, o impacto social negativo na vida de pacientes e familiares a torna um problema de saúde pública<sup>13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este PCDT visa a estabelecer os critérios de diagnóstico, acompanhamento e tratamento, incluindo terapia de reposição enzimática (TRE) intravenosa (TER IV) com alfavestronidase, de pacientes com MPS VII. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 4** .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E76.2 Outras Mucopolissacaridoses

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3. DIAGNÓSTICO** -->
A confirmação do diagnóstico de MPS VII envolve exames bioquímicos e, caso necessário, testes genéticos, que deverão ser realizados sempre que houver suspeita clínica dessa doença.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3.1. Suspeita Diagnóstica** -->
O diagnóstico de MPS VII deve ser suspeitado em indivíduos que apresentarem pelo menos um dos seguintes sinais e sintomas abaixo relacionados, especialmente naqueles que tiverem a combinação de pelo menos dois deles<sup>3</sup> :  
- Características faciais sugestivas de doença lisossômica (face infiltrada ou de “depósito”);  
- infecções respiratórias superiores precoces e de repetição, incluindo otite média, excluídas outras causas mais frequentes;  
- perda auditiva;  
- diminuição da velocidade de crescimento;  
- hepatoesplenomegalia, excluídas outras causas mais frequentes;  
- hérnias;  
- hidropisia fetal;  
- alterações esqueléticas ou articulares típicas [disostose múltipla, giba, limitação da  
- amplitude de movimento (AM) das articulações];  
- mãos em garra;  
- alterações cardíacas valvares ou cardiomiopatia;  
- achados oculares característicos (opacificação bilateral da córnea);  
- irmã (ão) com MPS VII.  
Como os achados clínicos variam de acordo com a gravidade da doença, os sinais e sintomas, por si só, não são diagnósticos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3.2. Diagnóstico laboratorial** -->
A apresentação extremamente variável dessa doença dificulta o diagnóstico precoce baseado somente na avaliação clínica. A confirmação do diagnóstico de MPS VII envolve métodos bioquímicos e genéticos, caso necessário ( **Figura 1** ).

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3.2.1.  Análises bioquímicas (atividade da GUSB e análise da excreção urinária de GAG)** -->
A atividade deficiente de GUSB gera o acúmulo de GAG, que são excretados em quantidade aumentada na urina, fundamentando a análise qualitativa ou quantitativa de GAG na urina<sup>14</sup> . Contudo, em formas clínicas moderadas, especialmente em adultos, esses níveis urinários de GAG podem estar normais ou apenas levemente aumentados. Estudos de granulócitos podem revelar inclusões

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: metacromáticas grosseiras nesses pacientes.<sup>1</sup> -->
A redução ou ausência de atividade da GUSB em fibroblastos, leucócitos ou sangue impregnado em papel-filtro sugere fortemente o diagnóstico de MPS VII, mas não é suficiente para confirmá-lo devido à possibilidade de ocorrência de pseudo-deficiência<sup>15</sup> . Para exclusão de pseudodeficiência, é necessária, também, a demonstração de níveis urinários aumentados de GAG (por meio de dosagem quantitativa de GAG totais ou cromatografia ou eletroforese de GAG evidenciando aumento de SH e SD) **E** análise genética compatível ou níveis normais de atividade da alfa-L-iduronidase (IDUA) e iduronato-sulfatase (IDS) em leucócitos ou papel-filtro. Os níveis de atividade enzimática, contudo, não permitem uma determinação precisa da gravidade da doença.  
O diagnóstico pré-natal é possível pela amniocentese ou coleta de amostras de vilosidades coriônicas para medir a atividade da GUSB, ou ainda por meio de testes genéticos do gene _GUSB_ .<sup>16</sup>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3.2.2.  Teste genético** -->
Testes genéticos do gene _GUSB_ também estão disponíveis para fins diagnósticos e podem, às vezes, oferecer informações sobre o prognóstico. A presença de duas variantes patogênicas bialélicas no gene _GUSB_ auxilia na confirmação do diagnóstico. A análise por sequenciamento do gene _GUSB_ permite a detecção das variantes que provocam a doença e, consequentemente, o diagnóstico genético e a detecção de heterozigotos, facilitando o aconselhamento genético individual e familiar<sup>3</sup> . Já foram descritas 63 mutações no gene _GUSB_<sup>17</sup> que levam à MPS VII.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3.2.3.  Associação genótipo-fenótipo clínico** -->
A maior importância dos estudos de genótipo-fenótipo é a possibilidade de predição aproximada, em idade precoce, da forma da doença que os indivíduos apresentarão. Apesar de não estar estabelecida para todas as variantes, para algumas delas há associação entre genótipo-fenótipo<sup>3, 9</sup> . Por exemplo, as variantes p.L176F, p.R382C, p.P408S e p.P415L associam-se ao fenótipo atenuado, enquanto a variante p.D362N associa-se ao fenótipo grave<sup>3</sup> . O alelo p.D512N é considerado um alelo de pseudo-deficiência<sup>15</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT todos os pacientes que tiverem o diagnóstico de MPS VII confirmado, de acordo com os critérios abaixo, os quais devem ser comprovados por laudo/relatório médico e pela cópia dos exames realizados<sup>3, 18</sup> , que são também os critérios para início do tratamento com alfavestronidase, ou seja ( **Figura 1** ):  
Presença de níveis aumentados de GAG totais na urina ou de excreção aumentada de SH ou SD **<u>E</u>** atividade da GUSB < 10% do limite inferior dos valores de referência em fibroblastos ou leucócitos ou sangue impregnado em papel-filtro;

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **E** -->
**a)** Atividade da IDUA e da IDS, avaliadas na mesma amostra que a GUSB deficiente, apresentando valores normais;

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **OU** -->
**b)** Presença de variantes patogênicas em homozigose ou heterozigose composta no gene _GUSB_ .  
Os pacientes que já estiverem em uso de alfavestronidase quando da publicação deste PCDT deverão ser reavaliados para verificação dos critérios de inclusão. Caso não preencham os critérios estabelecidos neste PCDT, a reposição da enzima deve ser imediatamente suspensa.  
<!-- Start of picture text -->
Suspeita diagnóstica a partir de sinais e sintomas de MPS VII<br>Dosagem urinária de GAG totais aumentada ou aumento da excreção<br>urinária de SH e SD<br>E<br>Atividade da GUSB < 10% do limite inferior dos valores de referência em<br>fibroblastos ou leucócitos ou sangue impregnado em papel-filtro<br>Atividade da alfa-L-iduronidase e da iduronato-sulfatase<br>normais<br>OU<br>Presença de variantes patogênicas em homozigose ou<br>heterozigose composta no gene  GUSB<br>Sim  Algum critério  Não<br>de exclusão<br>para TRE?<br>Iniciar TRE com alfavestronidase<br>Tratamento de Suporte<br>Diagnóstico<br><!-- End of picture text -->  
**Figura 1** - Fluxograma para o Diagnóstico e Tratamento da MPS VII  
GAG= Glicosaminoglicanos. SH= sulfato de heparan. SD= sulfato de dermatan. GUSB= betaglicuronidase. TRE= terapia de reposição enzimática.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos do tratamento com alfavestronidase os pacientes que se enquadrarem em pelo menos uma das seguintes situações:  
 Condição médica irreversível e que implique em sobrevida provavelmente < 6 meses como resultado da MPS VII ou de outra doença associada, em acordo entre mais de um especialista, incluindo a forma grave neonatal da doença (com manifestações multissistêmicas e hidropisia fetal)<sup>3</sup> ;  
 pacientes maiores de 18 anos que, após serem informados sobre os potenciais riscos e benefícios associados ao tratamento com alfavestronidase, recusarem-se a serem tratados.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **6. CASOS ESPECIAIS** -->
Inexistem dados disponíveis sobre segurança para a gestante e o feto quanto ao uso da alfavestronidase durante a gestação e lactação, embora não se espere que enzimas recombinantes  
cruzem a barreira placentária ou sejam excretadas em quantidade aumentada no leite materno<sup>19-21</sup> . Recomenda-se que o tratamento com TRE não seja iniciado durante a gestação.  
Quando houver reação à infusão mediada por IgE, deve ser discutida a possibilidade de tolerância.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7. TRATAMENTO** -->
O tratamento dos pacientes com MPS VII é estabelecido com base na melhor evidência disponível, também para outras mucopolissacaridoses, uma vez que se trata de doença ultra-rara. Ele envolve equipe multidisciplinar<sup>18, 22-24</sup> e inclui intervenções inespecíficas, realizadas no nível do fenótipo clínico (como cirurgias para correção das alterações esqueléticas), e específicas, realizadas no nível da proteína mutante (como a TRE intravenosa)<sup>18, 25</sup> .  
O transplante de células tronco-hematopoiéticas (TCTH) não está indicado em pacientes com MPS VII devido à alta heterogeneidade e limitações dos estudos existentes até o momento da publicação deste PCDT<sup>3, 26-28</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1. Conduta Geral** -->
O paciente com MPS VII tem uma doença crônica, progressiva e multissistêmica e rotineiramente requer cuidados urgentes por equipe multiprofissional que inclua fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, equipe de enfermagem e diferentes especialidades médicas, entre outros profissionais<sup>18</sup> . É crucial que um médico cuide continuamente do paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando o paciente para especialistas conforme necessário e coordenando o atendimento ao paciente como um todo, idealmente em um centro de referência. Como é uma doença genética, com risco de recorrência de 25% para os irmãos do paciente afetado, é fundamental a realização de aconselhamento genético por profissional habilitado.  
Além disso, é importante que os pacientes e as famílias sejam orientados sobre sua doença e possíveis complicações e riscos, também por meio de um relatório escrito. Os pacientes também devem ser informados de que, em caso de emergência, o médico assistente deve ser informado sobre a doença e receber uma cópia do relatório médico.<sup>18</sup> Os pacientes com MPS VII podem desenvolver sintomas neurológicos secundários à compressão medular; dessa forma, um neurocirurgião poderá fazer parte da equipe multidisciplinar de seu acompanhamento.<sup>18</sup>  
As principais manifestações clínicas da MPS VII e suas opções de tratamento de suporte e sintomáticas podem ser encontradas no **Apêndice 1** . É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e mais graves nos pacientes com a forma grave da doença, que envolve história prévia de hidropisia fetal. Da mesma forma, nem todos os pacientes necessitarão ser submetidos a todas as formas de tratamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.1.  Tratamento ortopédico** -->
Pacientes com MPS VII apresentam acometimento ósseo<sup>3, 18, 22, 29</sup> e requerem fisioterapia motora dinâmica, cujo objetivo principal é a prevenção ou estabilização de deformidades osteoarticulares, mantendo a amplitude de movimento. A fisioterapia, associada ou não a medicação analgésica, deve se concentrar em massoterapia para ajudar o relaxamento de todos os músculos, além de manobras e manipulações de todas as articulações com movimentos lentos para não causar dor, de acordo com os critérios da técnica de mobilização miofascial<sup>18</sup> .  
Além disso, equipamentos de auxílio da marcha ou cadeira de rodas podem aumentar a mobilidade e aliviar a dor; contudo, esforços na medida de postergar ao máximo a utilização dos mesmos devem ser feitos para manter esses pacientes móveis por maior tempo possível, uma vez que a sua qualidade de vida reduz drasticamente ao se tornarem dependentes de cadeira de rodas<sup>18</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.2.  Tratamento das manifestações respiratórias** -->
As manifestações respiratórias são as principais causas de morbimortalidade e podem ocorrer por causas obstrutivas ou restritivas<sup>18</sup> . Entre os objetivos do tratamento clínico está o melhor controle das infecções recorrentes de via aérea. Normalmente, solução salina é usada para eliminar crostas e secreções. Antibióticos são utilizados para o tratamento de exacerbações respiratórias agudas de origem bacteriana, como otite média aguda ou tonsilite, conforme indicação clínica e a critério médico. Corticosteroides sistêmicos por breves períodos podem ajudar a reduzir o edema e facilitar a drenagem de secreções, conforme indicação clínica e a critério médico. Os medicamentos para asma devem ser administrados conforme PCDT específico para essa condição clínica<sup>30</sup> . Pacientes podem, ainda, se beneficiar de terapias de suporte, como imunizações regulares para influenza e pneumococo<sup>18</sup> , seguindo o calendário obrigatório de vacinação do SUS.  
Fisioterapia respiratória visa a melhorar a função pulmonar, ventilação e biomecânica respiratória, prejudicadas na MPS VII<sup>3</sup> . Estão indicadas as manobras de higiene brônquica descritas na literatura, como vibrocompressão, drenagem postural, tosse controlada por manobra de aceleração do fluxo expiratório, nebulização e aspiração nasotraqueal com material estéril e descartável. Orientação para cuidadores e membros da família é de vital importância, porque a fisioterapia respiratória deve ser realizada diariamente.<sup>18</sup>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.3.  Tratamento oftalmológico** -->
A opacificação na córnea e as alterações de refração (astigmatismo, miopia e hipermetropia) são comuns na MPS VII, podendo levar à diminuição da acuidade visual e fotossensibilidade<sup>18, 31</sup> . Lentes corretivas devem ser prescritas para corrigir erros de refração<sup>18</sup> . O transplante de córnea pode melhorar notavelmente a visão<sup>18</sup> , embora possa ocorrer opacificação na córnea transplantada, como já relatado para a MPS IV-A<sup>32</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.4.  Tratamento das manifestações cardíacas** -->
O tratamento do acometimento cardíaco é essencialmente de suporte, envolvendo identificação e tratamento de pacientes com insuficiência cardíaca congestiva desenvolvida como resultado da miocardiopatia, geralmente hipertrófica ou, mais raramente, devido a disfunção valvar grave. Nesse caso, o paciente deve ser tratado com betabloqueador, inibidor da enzima conversora da angiotensina ou diurético, conforme a avaliação clínica. No último caso, os pacientes devem se submeter a valvuloplastia com balão ou reparação/substituição valvar cirúrgica<sup>33-36</sup> . De acordo com as orientações da _American Heart Association_ , recomenda-se profilaxia de endocardite bacteriana apenas para pacientes com história de endocardite ou prótese valvar<sup>37</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.5.  Tratamento das manifestações cognitivas** -->
Crianças com MPS VII devem receber o máximo de estimulação possível ao desenvolvimento durante os estágios iniciais da doença. A adaptação do ambiente às necessidades da criança (por exemplo, teclados com caracteres de grandes dimensões) pode apoiar o desenvolvimento. Habilidades desenvolvidas precocemente podem ser mantidas em fases posteriores de progressão da doença. Crianças com MPS VII que tenham dificuldade de aprendizagem ou alterações comportamentais e beneficiam-se de intervenções usuais para crianças sem MPS<sup>38</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.1.6.  Tratamento cirúrgico** -->
A MPS VII pode evoluir com complicações neurológicas, como hidrocefalia comunicante e compressão medular<sup>18, 39, 40</sup> ; porém, os sinais clássicos de hipertensão intracraniana geralmente estão ausentes, evoluindo de forma insidiosa, e os sintomas são difíceis de distinguir de danos primários ao cérebro<sup>18</sup> . A maioria dos casos de compressão medular apresentam tetraparesia espástica, mas paraparesia espástica ou hemiparesia também podem ocorrer, conforme descrito para outras MPS.<sup>41</sup>  
Cirurgia de coluna tóraco-lombar para correção da cifose pode ser uma alternativa quando a deformidade progride<sup>42-45</sup> . Há relatos que sugerem que os pacientes com MPS que realizam cirurgia da coluna vertebral aumentam risco de grandes complicações, incluindo infarto da medula espinhal e instabilidade da coluna vertebral<sup>42</sup> . Assim, cirurgias de coluna devem ter avaliações periódicas de monitorização com neurofisiologia. Seguimento com ressonância magnética do crânio ao diagnóstico e durante o seguimento a cada 2 a 3 anos é recomendado e imagens da coluna devem ser obtidas na presença de novos sintomas<sup>39</sup> . Eventualmente esses pacientes necessitam de cirurgias corretivas devido a deformidades ósseas diversas, incluindo a região do quadril e joelhos<sup>18, 29</sup> .  
Com relação ao tratamento cirúrgico das manifestações clínicas nas vias aéreas, os procedimentos cirúrgicos mais frequentes incluem adenotonsilectomia, cirurgia de cornetos nasais e traqueostomia<sup>18</sup> . Como o bloqueio das vias aéreas em MPS é multifatorial, os resultados da adenotonsilectomia variam, mas a melhora a médio prazo na qualidade respiratória é percebida na maioria dos casos. Com relação ao tratamento da perda auditiva, quando decorrente de causas condutivas e por infecções respiratórias frequentes requer inserção de tubos de ventilação de longa duração, porém nem sempre é resolutivo<sup>46</sup> .  
Cirurgias das vias aéreas podem ser complicadas pela macroglossia, abertura limitada da boca, margem cirúrgica restrita e instabilidade da coluna cervical, dificultando a visualização do campo cirúrgico. Hiperextensão no pescoço nesses pacientes pode causar compressão medular aguda. Uma alternativa de realização de adenoidectomia, quando o acesso pela abertura bucal está comprometido, é a cirurgia endoscópica por via nasal<sup>47</sup> . A traqueostomia definitiva ou temporária pode ser realizada antes de outras cirurgias para facilitar o controle das vias aéreas, se o suporte ventilatório for inefetivo ou em pacientes com obstrução de via aérea também quando acordados. A traqueostomia deve ser evitada sempre que possível, devido a dificuldades na técnica cirúrgica, endurecimento da traqueia, alterações anatômicas significativas como pescoço curto, e possibilidade de complicações pósoperatórias, como traqueíte, pneumonia recorrente e bloqueio da traqueostomia por secreções espessas. Assim, como as complicações são frequentes neste procedimento, sugere-se a realização apenas em centros com experiência nesses pacientes<sup>18</sup> . Os desafios da gestão de uma traqueostomia nesses pacientes, associados à dificuldade de aceitação pelo paciente e pela família, também devem ser levados em consideração.  
O tratamento cirúrgico das manifestações oftalmológicas consiste, quando necessário, em correção do estrabismo, do aumento da pressão intraocular, além do transplante de córnea já mencionado. Além disso, quando há aumento da pressão intracraniana, a drenagem ventrículoperitoneal pode evitar atrofia do nervo ótico e perda de visão, podendo ser indicada também a descompressão cirúrgica deste nervo<sup>18</sup> .  
Muitos pacientes com MPS apresentam risco anestésico elevado devido à obstrução das vias aéreas superiores. Avaliação pré-operatória para planejamento dos riscos sempre está indicada<sup>18</sup> , uma vez que a dificuldade na intubação pode ser fatal<sup>48</sup> . Idealmente os procedimentos cirúrgicos devem ser realizados em centros de referência com experiência em MPS, sendo fundamental a presença de anestesista experiente em intubação difícil para a realização desses procedimentos, pois a necessidade de acompanhar a intubação com fibroscopia é frequente. As máscaras laríngeas podem ser usadas para o tratamento das vias aéreas por períodos curtos ou para facilitar a intubação de fibra óptica<sup>48-50</sup> . Os tubos endotraqueais podem precisar ser menores do que o previsto para a idade e o tamanho de um paciente com MPS VII. Pacientes geralmente apresentam obstrução pós-operatória das vias aéreas, e a necessidade de manter em observação hospitalar durante a noite não são incomuns. A consciência da possibilidade de traqueostomia pós-operatória é importante para todas as partes envolvidas. Quando possível, os procedimentos que exigem anestesia geral devem ser evitados, para minimizar os riscos descritos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.2. Tratamento Específico - Terapia de reposição enzimática (TRE)** -->
A alfavestronidase é uma forma recombinante de GUSB e é produzida em células de ovário de hamster chinês ( _Chinese Hamster Ovary Cells_ - CHO) e trata-se do fármaco disponível para o tratamento específico da MPS VII<sup>2, 25, 51</sup> . A alfavestronidase foi considerada segura nos estudos avaliados, com eventos adversos leves na maioria dos casos<sup>52, 53</sup> e eficaz para melhora nos níveis urinários de GAG (redução de pelo menos 50% já no primeiro mês de tratamento)<sup>2, 54</sup> . Existem indícios de melhora da hepatoesplenomegalia associada ao tratamento<sup>2, 54, 55</sup> . Além disso, há evidência de estabilidade, em 24 semanas de tratamento, para o escore de fadiga e para os seguintes desfechos do “Índice Multidomínios de Respondedor Clínico” (IMRC): distância percorrida no teste da caminhada dos 6 minutos (TC6M) e acuidade visual<sup>2, 55-58</sup> . O efeito da TRE no escore de fadiga foi avaliado por meio do instrumento Inventário de Qualidade de Vida Pediátrico - Módulo Multidimensional de Fadiga (PedsQL-Fadiga), já validado no Brasil para a população pediátrica geral<sup>59</sup> , e composto por 3 dimensões: fadiga geral, sono/descanso e cognição. Esse instrumento foi aplicado a 12 pacientes com MPS VII, com idades que variaram entre 8 e 25 anos. A motricidade fina e grossa foi avaliada por meio do instrumento de Bruininks-Oseretsky (BOT-2), que não se encontra validado no Brasil<sup>2</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.2.2. Esquema de administração** -->
A dose preconizada para a alfavestronidase é de 4 mg/kg de peso corporal, administrada uma vez a cada duas semanas por infusão intravenosa. O uso de antipiréticos ou anti-histamínicos é recomendado 30 a 60 minutos antes do início da infusão<sup>2, 18, 21, 51</sup> , que deve ser feita em ambiente hospitalar ou ambulatorial. O volume total da infusão é determinado pelo peso corporal do paciente e deve ser infundido ao longo de 4 horas. A taxa de infusão inicial deve ser de 2,5% do volume da dose do medicamento por hora durante a primeira hora. Se a infusão for bem tolerada, a velocidade de infusão pode ser aumentada para um montante igual ao volume restante de 97,5% dividido por 3 horas e permanecer nessa taxa até que a infusão seja concluída em aproximadamente 3 horas. O tempo de infusão pode ser prolongado até 20 horas se ocorrerem reações à infusão<sup>2, 21</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.2.3. Riscos e benefícios esperados** -->
Um ensaio clínico para avaliação da eficácia e segurança da TRE com alfavestronidase incluindo 12 pacientes mostrou uma diminuição rápida e sustentada da excreção de GAG na urina após TRE, o que, do ponto de vista farmacodinâmico, demonstra mecanismo de ação compatível com a fisiopatologia da doença<sup>2</sup> . Avaliando a eficácia da TRE por meio do IMRC combinando de forma independente 6 domínios (TC6M; CVF; amplitude de flexão dos ombros; acuidade visual; teste de BOT-2 para motricidade fina; e teste de BOT-2 para motricidade grossa) considerados importantes no contexto da progressão clínica da doença<sup>2</sup> , observou-se uma variação média de +0,5 (DP ±0,8) no IMRC, após 24 semanas de tratamento (p=0,0527). O IMRC é o resultado do somatório de pontuações atribuídas para cada um dos domínios de acordo com um escore de diferenças clínicas minimamente relevantes préespecificadas (-1 para declínio; 0 para nenhuma mudança ou inacessível; e +1 para melhoria) ( **Tabela 1/Apêndice 2** ). Assim, resultados positivos no somatório do IMRC incicam melhora clínica, enquanto resultados negativos indicam declínio. Neste mesmo estudo, o escore do PedsQL-Fadiga também foi avaliado. Em análise pos-hoc, a média de variação no IMRC incluindo escore total de fadiga foi de +0,8 (DP ±0,94) (p=0,01) após 24 semanas de tratamento com TRE.<sup>2</sup>  
Relatos e séries de caso mostraram outros efeitos benéficos da TRE para pacientes com MPS VII: diminuição da frequência de uso de suporte respiratório (n=2/4)<sup>58, 60</sup> , aumento de frequência escolar e de normalização de hábitos alimentares (n=1/1)<sup>58</sup> . Houve melhora da esplenomegalia em 3 pacientes e da hepatomegalia em 2 pacientes com MPS VII após 12 semanas de tratamento<sup>55</sup> . Redução da  
hepatomegalia ocorreu em 2/7 pacientes que tiveram este desfecho avaliado em Harmatz et al. (2018)<sup>2</sup> , e resultado similar foi encontrado por Dubot et al. (2019) em seu relato de caso<sup>54</sup> .  
O medicamento mostrou-se seguro e as reações anafilactoides registradas em alguns casos podem ser evitadas pelo controle do tempo de infusão e utilização de medicamentos adequados. O uso seguro da alfavestronidase foi descrito para pacientes com MPS VII entre 8 e 15 anos de idade, e em pacientes a partir de 4 meses de idade<sup>2, 54</sup> . A alfavestronidase, com os dados observados até agora, não parece ultrapassar barreira-hematoencefálica, e desta forma não parece ter benefício nas manifestações neurológicas da doença.<sup>2, 51, 61</sup>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.2.4.  Eventos adversos** -->
As reações adversas mais comuns foram reação anafilactoide (13%), urticária (13%), inchaço no local da infusão (13%), extravasamento no local da infusão (8,7%), prurido (8,7%), diarreia (8.7%) e erupção cutânea (8,7%)<sup>21, 62</sup> .  
**Anafilaxia** : foi relatada anafilaxia para alfavestronidase em 2 dos 20 pacientes no programa clínico. Essas reações ocorreram durante a infusão do medicamento e foram observadas já na primeira dose administrada a um paciente. A anafilaxia pode ser letal. O medicamento deve ser administrado sob a supervisão de um profissional de saúde com capacidade para lidar com anafilaxia. Os pacientes devem ser observados por 60 minutos após a administração. Se ocorrerem reações sistêmicas graves, incluindo anafilaxia, a infusão deve ser interrompida e tratamento médico apropriado providenciado. Antes da alta, deve-se informar aos pacientes sobre os sinais e sintomas da anafilaxia e instruí-los a procurar atendimento médico imediato se apresentarem sintomas. Devem ser considerados os riscos e benefícios de se administrar o medicamento após anafilaxia.<sup>21, 62</sup>  
**Imunogenicidade:** tal como acontece com todas as proteínas terapêuticas, existe potencial para imunogenicidade.<sup>21, 62</sup>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **7.2.5. Tempo de tratamento – Critérios de interrupção** -->
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, ao paciente ou aos pais ou responsáveis quando a TRE estiver sendo considerada e antes de iniciá-la. Durante o acompanhamento do paciente com TRE, os parâmetros de resposta terapêutica deverão ser avaliados periodicamente e discutidos com os pais, paciente ou responsáveis. No caso de interrupção por falha de adesão, o paciente e parentes deverão ser inseridos em programa educativo de incentivo à adesão, e o paciente poderá retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas. O tempo de tratamento não pode ser pré-determinado, devendo ser mantido enquanto indicado e dele o doente se beneficie.  
Para fins deste PCDT, a TRE deve ser interrompida nas seguintes situações<sup>2, 63, 64</sup> :  
a) Pacientes que não apresentarem melhora após 3 meses de tratamento dos níveis basais de GAG urinários (melhora definida como a redução dos níveis urinários de GAG em pelo menos 50% em relação aos níveis basais);  
b) Pacientes que não apresentarem melhora clinicamente relevante após 6 meses de tratamento: melhora em pelo menos 1 de 4 domínios da escala IMRC modificada (retirados os domínios do instrumento BOT-2, que não se encontram validados no Brasil), conforme item monitoramento e **apêndices 2 e 3** ; **OU** redução da hepatomegalia ou da esplenomegalia (por quaisquer dos métodos utilizados para aferição dessa condição: exame físico, ecografia abdominal ou ressonância abdominal); **OU** melhora do escore do PedsQL-Fadiga, conforme o item monitoramento e os **apêndices 2 e 3** ;  
c) Pacientes que desenvolverem condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como resultado da MPS VII ou de outra doença associada, em acordo entre mais de um especialista;  
d) Pacientes que não apresentarem pelo menos 50% de adesão ao número de infusões previstas em um ano, ou ao número de consultas previstas em um ano, ou ao número de avaliações previstas em um ano com o médico responsável pelo seguimento do paciente, desde que previamente inseridos, sem sucesso, em programa educativo específico para melhora de adesão, elaborado por cada centro de referência, no qual a equipe assistente avalia os fatores envolvidos na adesão, orienta o paciente e, em conjunto, buscam soluções para esta questão. Ou seja, pacientes que, mesmo após o programa de adesão, não comparecerem a pelo menos 50% do número de infusões, consultas ou avaliações previstas em um ano;  
e) Pacientes que apresentarem hipersensibilidade ou reação adversa grave (choque anafilático, risco de óbito) ao uso da alfavestronidase, que não podem ser controladas com segurança utilizando medidas terapêuticas e preventivas apropriadas;  
f) Pacientes maiores de 18 anos que, após serem devidamente informados sobre os riscos e benefícios de sua decisão, optarem por não mais se submeterem ao tratamento com TRE intravenosa com alfavestronidase.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **8. MONITORAMENTO** -->
A monitorização do tratamento clínico dos pacientes com MPS VII também é estabelecida com base na evidência disponível para outras MPS, uma vez que se trata de doença ultra-rara. Os pacientes devem ter a resposta terapêutica e os eventos adversos monitorados. O médico deve realizar anamnese completa em cada consulta e coletar dados de altura (em pé ou em decúbito dorsal, e, no caso de restrições nos membros inferiores, por segmento), peso e perímetro cefálico, de preferência usando o mesmo instrumento, devidamente calibrado. O exame físico deve ser completo e incluir sinais vitais (temperatura, frequência cardíaca, frequência respiratória e pressão arterial), bem como medidas para quantificação do tamanho do fígado (por hepatimetria) e do baço . A avaliação do desenvolvimento sexual deve ser realizada em adolescentes, de acordo com os critérios de Tanner<sup>65, 66</sup> . Nas consultas, dados sobre todas as avaliações realizadas desde o último agendamento devem ser obtidos e os testes necessários devem ser solicitados, incluindo avaliação por especialistas em neurologia, otorrinolaringologia, ortopedia, oftalmologia, cardiologia e pneumologia, conforme indicação clínica e a critério do médico assistente.  
As avaliações de rotina devem ser realizadas semestralmente pelo médico assistente com vacinas, orientação dietética, exames e conselhos preventivos.<sup>18</sup> Os pacientes e seus familiares devem ter acesso ao aconselhamento genético.  
O **Apêndice 3** apresenta as avaliações consideradas mínimas para o acompanhamento de pacientes com MPS VII, sendo necessárias para o acesso ao medicamento. São definidos períodos mínimos apenas para aquelas avaliações que têm por objetivo detectar a eficácia e segurança da TRE; para as demais, a periodicidade de avaliações fica a critério do médico assistente. Alguns componentes das avaliações específicas serão discutidos a seguir.  
O IMRC foi a escala utilizada para avaliar a resposta terapêutica nesses pacientes e pode ser utilizada para monitorização da doença. O IMRC é composto de seis domínios; contudo, uma vez que o teste BOT-2 função motora global e fina não está validado na população brasileira, foi excluído para fins de avaliação neste PCDT. Assim, os domínios incluídos foram os seguintes: TC6M; CVF; amplitude de flexão dos ombros; acuidade visual, além do PedsQL-Fadiga ( **Tabela 1/Apêndice 2** ).  
A quantificação de GAG urinários é utilizada para diagnóstico e, também, monitorização do tratamento específico da MPS VII, uma vez que, na vigência de tratamento, ocorre diminuição da excreção dessas moléculas<sup>2, 18, 67</sup> .  
Como parte da avaliação do tratamento, deve-se monitorar o uso, a adesão, a indicação e os resultados da TRE com alfavestronidase. Por meio desse monitoramento, será possível estabelecer grupos de pacientes que são de fato beneficiados e reavaliar a incorporação do medicamento a médio  
prazo.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da MPS II deve ser feito por equipe em serviços especializados, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja treinado nessa atividade.  
Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste PCDT. Para a administração dos medicamentos é essencial o atendimento centralizado, para maior racionalidade do uso e avaliação da efetividade. A infusão deve ser feita em ambiente hospitalar ou ambulatorial. Infusões domiciliares podem ser consideradas após 6 meses de tratamento sem intercorrências.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste PCDT, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **11. REFERÊNCIAS** -->
1. Guffon N, Froissart R, Fouilhoux A. A rare late progression form of Sly syndrome mucopolysaccharidosis. JIMD Rep. 2019;49(1):1-6.  
2. Harmatz P, Whitley CB, Wang RY, Bauer M, Song W, Haller C, et al. A novel Blind Start study design to investigate vestronidase alfa for mucopolysaccharidosis VII, an ultra-rare genetic disease. Mol Genet Metab. 2018;123(4):488-94.  
3. Montaño AM, Lock-Hock N, Steiner RD, Graham BH, Szlago M, Greenstein R, et al. Clinical course of sly syndrome (mucopolysaccharidosis type VII). J Med Genet. 2016;53(6):403-18.  
4. Giugliani R, Federhen A, Michelin-Tirelli K, Riegel M, Burin M. Relative frequency and estimated minimal frequency of Lysosomal Storage Diseases in Brazil: Report from a Reference Laboratory. Genet Mol Biol. 2017;40(1):31-9.  
5. Federhen A, Pasqualim G, de Freitas TF, Gonzalez EA, Trapp F, Matte U, et al. Estimated birth prevalence of mucopolysaccharidoses in Brazil. Am J Med Genet A. 2020;182(3):469-83.  
6. Josahkian JA, Trapp FB, Burin MG, Michelin-Tirelli K, Magalhães APPS, Sebastião FM, et al. Updated birth prevalence and relative frequency of mucopolysaccharidoses across Brazilian regions. Genet Mol Biol. 2021;44(1):e20200138.  
7. McCafferty EH, Scott LJ. Vestronidase Alfa: A Review in Mucopolysaccharidosis VII. BioDrugs. 2019;33(2):233-40.  
8. Khan FI, Shahbaaz M, Bisetty K, Waheed A, Sly WS, Ahmad F, et al. Large scale analysis of the mutational landscape in β-glucuronidase: A major player of mucopolysaccharidosis type VII. Gene. 2016;576(1 Pt 1):36-44.  
9. Tomatsu S, Montaño AM, Dung VC, Grubb JH, Sly WS. Mutations and polymorphisms in GUSB gene in mucopolysaccharidosis VII (Sly Syndrome). Hum Mutat. 2009;30(4):511-9.  
10. Suarez-Guerrero JL, Gómez Higuera PJ, Arias Flórez JS, Contreras-García GA. [Mucopolysaccharidosis: clinical features, diagnosis and management]. Rev Chil Pediatr. 2016;87(4):295304.  
11. Zielonka M, Garbade SF, Kölker S, Hoffmann GF, Ries M. Quantitative clinical characteristics of 53 patients with MPS VII: a cross-sectional analysis. Genet Med. 2017;19(9):983-8. 12. National Organization for Rare Disorders [Internet]. Mucopolysaccharidosis Type VII; 2017. Available from: https://rarediseases.org/rare-diseases/sly-syndrome/. 13. Péntek M, Gulácsi L, Brodszky V, Baji P, Boncz I, Pogány G, et al. Social/economic costs and health-related quality of life of mucopolysaccharidosis patients and their caregivers in Europe. Eur J Health Econ. 2016;17 Suppl 1:89-98. 14. Albuquerque R, Liberalesso P, Santos M, Klagenberg K, Jurkiewicz A, Zeigelboim B. Aspectos eletrencefalográficos em crianças com mucopolissacaridose. J Epilepsy Clin Neurophysiol. 2010;16(4):162-6.  
15. Vervoort R, Islam MR, Sly W, Chabas A, Wevers R, de Jong J, et al. A pseudodeficiency allele (D152N) of the human beta-glucuronidase gene. Am J Hum Genet. 1995;57(4):798-804. 16. Chabás A, Guardiola A. beta-Glucuronidase deficiency: identification of an affected fetus with simultaneous sampling of chorionic villus and amniotic fluid. Prenat Diagn. 1993;13(6):429-33.  
17. Institute of Medical Genetics in Cardiff [Internet]. Human Gene Mutation Database. 2018. Available from: http://www.hgmd.cf.ac.uk/ac/index.php.  
18. Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18.  
19. Dornelles AD, de Oliveira Netto CB, Vairo F, de Mari JF, Tirelli KM, Schwartz IV. Breastfeeding in Gaucher disease: is enzyme replacement therapy safe? Clin Ther. 2014;36(6):990-1. 20. Paskulin L, Dornelles AD, Quevedo A, Nalin T, Tirelli KM, Vairo F, et al. Breastfeeding in patients with Gaucher disease: Is taliglucerase alfa safe? Mol Genet Metab Rep. 2019;18:30-1. 21. Mepsevii® (alfavestronidase) [bula de remédio]. São Paulo: Ultragenyx Pharmaceutical; 2018. 22. Neufeld EF, Muenzer J. Part 16: Lysosomal Disorders - The Mucopolysaccharidoses. In: Valle DL, Antonarakis S, Ballabio A, Beaudet AL, Mitchell GA, editors. The Online Metabolic and Molecular Bases of Inherited Disease: McGraw-Hill Education; 2019.  
23. Pastores GM. Musculoskeletal complications encountered in the lysosomal storage disorders. Best Pract Res Clin Rheumatol. 2008;22(5):937-47. 24. Turra GS, Schwartz IV. Evaluation of orofacial motricity in patients with mucopolysaccharidosis: a cross-sectional study. J Pediatr (Rio J). 2009;85(3):254-60. 25. Schwartz IV, Souza CF, Giugliani R. Treatment of inborn errors of metabolism. J Pediatr (Rio J). 2008;84(4 Suppl):S8-19.  
26. Yamada Y, Tomatsu S, Sukegawa K, Suzuki Y, Kondo N, Hopwood JJ, et al. Mucopolysaccharidosis type II (Hunter disease): 13 gene mutations in 52 Japanese patients and carrier detection in four families. Hum Genet. 1993;92(2):110-4.  
27. Orii K, Suzuki Y, Tomatsu S, Orii T, Fukao T. Long-Term Follow-up Posthematopoietic Stem Cell Transplantation in a Japanese Patient with Type-VII Mucopolysaccharidosis. Diagnostics (Basel). 2020;10(2):105.  
28. Sisinni L, Pineda M, Coll MJ, Gort L, Turon E, Torrent M, et al. Haematopoietic stem cell transplantation for mucopolysaccharidosis type VII: A case report. Pediatr Transplant. 2018;22(7):e13278.  
29. White KK. Orthopaedic aspects of mucopolysaccharidoses. Rheumatology (Oxford). 2011;50 Suppl 5:v26-33.  
30. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Asma. Brasil: Ministério da Saúde; 2013.  
31. Ashworth JL, Biswas S, Wraith E, Lloyd IC. The ocular features of the mucopolysaccharidoses. Eye (Lond). 2006;20(5):553-63.  
32. Käsmann-Kellner B, Weindler J, Pfau B, Ruprecht KW. Ocular changes in mucopolysaccharidosis IV A (Morquio A syndrome) and long-term results of perforating keratoplasty. Ophthalmologica. 1999;213(3):200-5.  
33. Pierpont MEM, Moller JH. Cardiac manifestations of genetic disease. In: Moss A, editor. Heart disease in infants, children, and adolescents. 5th ed. ed. London: Williams & Wilkins; 1995. p. 1486-520. 34. Dangel JH. Cardiovascular changes in children with mucopolysaccharide storage diseases and related disorders--clinical and echocardiographic findings in 64 patients. Eur J Pediatr. 1998;157(7):5348.  
35. Fischer TA, Lehr HA, Nixdorff U, Meyer J. Combined aortic and mitral stenosis in mucopolysaccharidosis type I-S (Ullrich-Scheie syndrome). Heart. 1999;81(1):97-9.  
36. Minakata K, Konishi Y, Matsumoto M, Miwa S. Surgical treatment for Scheie's syndrome (mucopolysaccharidosis type I-S): report of two cases. Jpn Circ J. 1998;62(9):700-3. 37. Wilson W, Taubert KA, Gewitz M, Lockhart PB, Baddour LM, Levison M, et al. Prevention of infective endocarditis: guidelines from the American Heart Association: a guideline from the American Heart Association Rheumatic Fever, Endocarditis, and Kawasaki Disease Committee, Council on Cardiovascular Disease in the Young, and the Council on Clinical Cardiology, Council on Cardiovascular Surgery and Anesthesia, and the Quality of Care and Outcomes Research Interdisciplinary Working Group. Circulation. 2007;116(15):1736-54.  
38. Muenzer J, Wraith JE, Clarke LA, I ICPoMaToM. Mucopolysaccharidosis I: management and treatment guidelines. Pediatrics. 2009;123(1):19-29.  
39. Reichert R, Campos LG, Vairo F, de Souza CF, Pérez JA, Duarte J, et al. Neuroimaging Findings in Patients with Mucopolysaccharidosis: What You Really Need to Know. Radiographics. 2016;36(5):144862.  
40. Azevedo AC, Schwartz IV, Kalakun L, Brustolin S, Burin MG, Beheregaray AP, et al. Clinical and biochemical study of 28 patients with mucopolysaccharidosis type VI. Clin Genet. 2004;66(3):208-13.  
41. Kachur E, Del Maestro R. Mucopolysaccharidoses and spinal cord compression: case report and review of the literature with implications of bone marrow transplantation. Neurosurgery. 2000;47(1):223-8; discussion 8-9.  
42. Williams N, Cundy P, Eastwood D. Surgical Management of Thoracolumbar Kyphosis in Patients with Mucopolysaccharidosis: A Systematic Review. Spine (Phila Pa 1976). 2017;42(23):1817-1825. 43. Roberts SB, Dryden R, Tsirikos AI. Thoracolumbar kyphosis in patients with mucopolysaccharidoses: clinical outcomes and predictive radiographic factors for progression of deformity. Bone Joint J. 2016;98-B(2):229-37.  
44. Dalvie SS, Noordeen MH, Vellodi A. Anterior instrumented fusion for thoracolumbar kyphosis in mucopolysaccharidosis. Spine (Phila Pa 1976). 2001;26(23):E539-41.  
45. Bekmez S, Demirkiran HG, Dede O, Ismayilov V, Yazici M. Surgical Management of Progressive Thoracolumbar Kyphosis in Mucopolysaccharidosis: Is a Posterior-only Approach Safe and Effective? J Pediatr Orthop. 2018;38(7):354-9.  
46. Oghan F, Harputluoglu U, Guclu E, Guvey A, Turan N, Ozturk O. Permanent t-tube insertion in two patients with Hurler's syndrome. Int J Audiol. 2007;46(2):94-6.  
47. Nayak DR, Balakrishnan R, Murthy KD. An endoscopic approach to the deviated nasal septum--a preliminary study. J Laryngol Otol. 1998;112(10):934-9.  
48. Shinhar SY, Zablocki H, Madgy DN. Airway management in mucopolysaccharide storage disorders. Arch Otolaryngol Head Neck Surg. 2004;130(2):233-7.  
49. Brain AI. The laryngeal mask--a new concept in airway management. Br J Anaesth. 1983;55(8):801-5.  
50. Walker RW, Allen DL, Rothera MR. A fibreoptic intubation technique for children with mucopolysaccharidoses using the laryngeal mask airway. Paediatr Anaesth. 1997;7(5):421-6.  
51. Cadaoas J, Boyle G, Jungles S, Cullen S, Vellard M, Grubb JH, et al. Vestronidase alfa: Recombinant human β-glucuronidase as an enzyme replacement therapy for MPS VII. Mol Genet Metab. 2020;130(1):65-76.  
52. Gomes DF, Gallo LG, Leite BF, Silva RB, da Silva EN. Clinical effectiveness of enzyme replacement therapy with galsulfase in mucopolysaccharidosis type VI treatment: Systematic review. J Inherit Metab Dis. 2019;42(1):66-76.  
53. Harmatz P, Giugliani R, Schwartz I, Guffon N, Teles EL, Miranda MC, et al. Enzyme replacement therapy for mucopolysaccharidosis VI: a phase 3, randomized, double-blind, placebo-controlled, multinational study of recombinant human N-acetylgalactosamine 4-sulfatase (recombinant human arylsulfatase B or rhASB) and follow-on, open-label extension study. J Pediatr. 2006;148(4):533-9.  
54. Dubot P, Sabourdy F, Plat G, Jubert C, Cancès C, Broué P, et al. First Report of a Patient with MPS Type VII, Due to Novel Mutations in GUSB, Who Underwent Enzyme Replacement and Then Hematopoietic Stem Cell Transplantation. Int J Mol Sci. 2019;20(21):5345.  
55. Jones SA, Breen C, Kakkis ED, Sly WS. Enzyme replacement therapy (ERT) for mucopolysaccharidosis VII (MPS VII; Sly disease) reduces lysosomal storage in a phase 1/2 clinical study. Journal of Inherited Metabolic Disease. 2014;37(1):S43.  
56. Martins EM, Wang RYW, Francisco da Silva Franco J F, Harmatz P H, Lopez-Valdez J LV, Sutton V R S,  et al. Sustained efficacy and safety of long-term vestronidase alfa (rhGUS) enzyme replacement  
therapy in patients with MPS VII. Journal of Inherited Metabolic Disease. 2018;41:S188.  
57. Coker M, Gonzales-Meneses A, Song W, Taylor J, Agarwal S, Haller C, et al. Long-term outcomes with rhGUS in a phase I/II clinical trial in MPS VII. Journal of Inherited Metabolic Disease. 2016;39:S48-S9.  
58. Fox JE, Volpe L, Bullaro J, Kakkis ED, Sly WS. First human treatment with investigational rhGUS enzyme replacement therapy in an advanced stage MPS VII patient. Mol Genet Metab. 2015;114(2):2038.  
59. Klatchoian DA, Len CA, Terreri MT, Silva M, Itamoto C, Ciconelli RM, et al. Quality of life of children and adolescents from São Paulo: reliability and validity of the Brazilian version of the Pediatric Quality of Life Inventory version 4.0 Generic Core Scales. J Pediatr (Rio J). 2008;84(4):308-15.  
60. Coker M, Gonzales-Meneses A, Song W, Taylor J, Agarwal S, Haller C, et al. Long-term outcomes with rhGUS in a phase I/II clinical trial in MPS VII. Journal of Inherited Metabolic Disease. 2016;39:S48S9.  
61. Vogler C, Levy B, Grubb JH, Galvin N, Tan Y, Kakkis E, et al. Overcoming the blood-brain barrier with high-dose enzyme replacement therapy in murine mucopolysaccharidosis VII. Proc Natl Acad Sci U S A. 2005;102(41):14777-82.  
62. Ministério da Saúde. Alfavestronidase no tratamento de mucopolissacaridose tipo VII. Brasil: Ministério da Saúde; 2020. Available from: <u>https://docs.bvsalud.org/biblioref/2020/09/1121184/relatorio_de_recomendacao_alfavestronidase_m ucopolissacaridose_bfkSKUW.pdf.</u>  
63. Giugliani R, Federhen A, Muñoz Rojas MV, Vieira TA, Artigalás O, Pinto LL, et al. [Enzyme replacement therapy for mucopolysaccharidoses I, II and VI: recommendations from a group of Brazilian F experts]. Rev Assoc Med Bras (1992). 2010;56(3):271-7.  
64. Brunelli MJ, Atallah Á, da Silva EM. Enzyme replacement therapy with galsulfase for mucopolysaccharidosis type VI. Cochrane Database Syst Rev. 2016;3:CD009806.  
65. Marshall WA, Tanner JM. Variations in pattern of pubertal changes in girls. Arch Dis Child. 1969;44(235):291-303.  
66. Marshall WA, Tanner JM. Variations in the pattern of pubertal changes in boys. Arch Dis Child. 1970;45(239):13-23.  
67. Swiedler SJ, Beck M, Bajbouj M, Giugliani R, Schwartz I, Harmatz P, et al. Threshold effect of urinary glycosaminoglycans and the walk test as indicators of disease progression in a survey of subjects with Mucopolysaccharidosis VI (Maroteaux-Lamy syndrome). Am J Med Genet A. 2005;134A(2):144-50.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** ALFAVESTRONIDASE  
Eu,____________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de alfavestronidase, indicada para o tratamento da mucopolissacaridose tipo VII.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _______________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber podem trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como melhora no teste de caminhada de 6 minutos e redução dos glicosaminoglicanos (GAG) urinários, diminuição da frequência de uso de suporte respiratório, aumento de frequência escolar, normalização de hábitos alimentares e estabilização de tamanho de baço e fígado.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento sem experiência de uso na gestação e lactação;  
- efeitos adversos da alfavestronidase mais comuns: reação anafilactoide (13%), urticária (13%), inchaço no local da infusão (13%), extravasamento no local da infusão (8,7%), prurido (8,7%), diarreia (8,7%) e erupção cutânea (8,7%);  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes  
- da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (    ) Sim (    ) Não  
||Local:                                                                                          Data:|
|---|---|
||Nome dopaciente:|
||Cartão Nacional do SUS:|
||Nome do responsável legal:|
||Documento de identificação do responsável legal:|
||Assinatura do paciente ou do responsável legal|
||Médico:                                                                           CRM:|
|RS:||
||______________________________<br>Assinatura e carimbo do médico|
||Data:|  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: PRINCIPAIS MANIFESTAÇÕES CLÍNICAS DA MPS VII E CONDUTAS DE SUPORTE E SINTOMÁTICOS -->
|Órgão/sistema|Manifestação clínica|Avaliação/Tratamento|
|---|---|---|
|Sistema<br>nervoso<br>periférico|Compressão medular|Cirurgia, fisioterapia.|
|Olhos|Acuidade visual diminuída<br>Opacificação de córnea|Avaliação oftalmológica<br>Transplante de córnea (em casos<br>específicos)|
|Vias aéreas|Síndrome da apneia obstrutiva do sono<br>Infecções de repetição, hipersecreção<br>Doençapulmonar restritiva|Amigdalectomia,<br>adenoidectomia,<br>oxigenioterapia.<br>Avaliação funcional pulmonar<br>Farmacoterapia<br>Fisioterapia|
|Tecido conjuntivo|Hérnias|Cirurgia|
|Articulações|Dor, contraturas|Fisioterapia, terapia ocupacional.<br>Farmacoterapia|
|Ossos|Geno valgo,luxação dequadril|Correção cirúrgica|
|Orelhas|Hipoacusia<br>Otites de repetição|Próteses (em casos específicos)<br>Farmacoterapia,cirurgia.|
|Gastrointestinal|Diarreia<br>Ganho inadequado ou excessivo de peso<br>Distúrbio da deglutição|Orientação nutricional<br>Orientação nutricional<br>Farmacoterapia, fonoaudiologia.<br>Cirurgia(gastrostomia)|
|Bucomaxilofacial|Mal oclusão, dentição anômala|Cirurgia<br>Aparelho ortodôntico|
|Cardiovascular|Valvulopatias,<br>cardiomiopatia,<br>insuficiência cardíaca|Farmacoterapia, cirurgia.|
|Manifetações pré-<br>natais|Hidropisia Fetal|-|
|Fontes:<br>estudos|Elaborado a partir de Giugliani R et al., 20<br>Harmatz<br>et<br>al.,<br>2018<sup>2</sup><br>e|07<sup>1</sup>e aplicado à MPS VII a partir dos<br>Montaño<br>et<br>al.,<br>2016<sup>3</sup>.|  
**APÊNDICE 2** ÍNDICE MULTIDOMÍNIOS DE RESPONDEDOR CLÍNICO (IMRC) PARA SEGUIMENTO CLÍNICO DOS PACIENTES COM MPS VII SOB TRE<sup>2</sup>  
**Tabela 1 -** Parâmetros que compõem o IMRC e diferenças clínicas relevantes  
|**Domínio**|**Diferença clínica minimamente relevante**|
|---|---|
|**Teste de Caminhada de 6**<br>**minutos**|23 metros**E**um aumento de 10% em relação à linha de base|
|**Capacidade vital forçada (%)**|Aumento de 10% em relação à linha de base|
|**Amplitude de flexão do ombro**|Aumento de 20° na amplitude de flexão|
|**Acuidade visual**|Melhora de 3 linhas(com correção,ambos os olhos)|
||+1 para aumento ≥10 pontos em fadiga/ -1 para diminuição ≥10 ponto|
|**PedsQL-Fadiga**|Modificações<br>fora dessesparâmetros recebem escore 0.|  
Essas diferenças clínicas minimamente relevantes foram estabelecidas de acordo com dados de literatura e informações clínicas provenientes dos resultados de tratamentos com TRE em outras MPS<sup>2</sup> , adaptadas para a realidade brasileira.  
O **Teste de Caminhada de 6 Minutos** tem como objetivo avaliar as respostas globais e integradas de todos os sistemas corporais envolvidos durante o exercício. Ele consiste na mensuração da distância máxima percorrida por um período de seis minutos. Para sua aplicação, é necessária uma superfície plana, com um percurso de 30 metros, devendo haver uma marcação a cada três metros e ao início e final do trajeto, além de paredes próximas para apoio. Caso sejam utilizadas curvas no percurso, estas devem ser sinalizadas.  Deve ser orientado ao indivíduo que ele permaneça dez minutos sentado próximo ao local do teste, descansando. Ao se levantar, devem ser avaliados sinais de fadiga ou falta de ar. Imediatamente antes de iniciar o percurso, deve-se dar a orientação de que o uso de aparelho de auxílio à deambulação já utilizado pelo indivído pode ser feito durante o teste. Reduções na velocidade ou pausas podem ser feitas, com retorno à caminhada assim que possível; curvas devem ser feitas rapidamente e sem hesitação. O avaliador poderá explicar o teste mostrando ao paciente como deve ser feito, mas treinos não podem ser aplicados. Deverão ser contabilizados o número de voltas e a distância percorridas no período de seis minutos com auxílio de um cronômetro<sup>2,4</sup> . A interpretação dos resultados deverá ser feita considerando-se os parâmetros citados na **Tabela 1** deste **Apêndice 2** .  
A avaliação da **Capacidade Vital Forçada (CVF)** representa o volume máximo de ar exalado com esforço máximo, a partir do ponto de máxima inspiração. Sua avaliação pode ser feita por meio do teste de espirometria, que avalia o volume de ar que um indivíduo inala e exala como uma função de tempo. Este teste pressupõe compreensão e colaboração do indivíduo avaliado. A CVF é medida solicitando que a pessoa, após a inspiração máxima (até a capacidade pulmonar total), expire do modo mais rápido e intenso possível em um espirômetro de fluxo ou de volume. Os resultados do teste são então computados e disponibilizados por programas de computador<sup>5,6</sup> . A interpretação dos resultados deverá ser feita considerando-se os parâmetros citados na **Tabela 1** deste **Apêndice 2** .  
A **amplitude de flexão do ombro** deve ser avaliada com auxílio de um goniômetro em um teste de amplitude de movimento ativo. Deve-se solicitar que o indivíduo flexione cada obro por três vezes. A melhor medida de cada lado deve ser utilizada para compor o valor médio<sup>2,7,8</sup> . A interpretação dos resultados deverá ser feita considerando-se os parâmetros citados na **Tabela 1** deste **Apêndice 2** .  
A **acuidade visual** pode ser avaliada por meio de tabelas específicas, que contêm fileiras de  
letras, em diferentes tamanhos, resoluções e contrastes<sup>9</sup> . A uma distância de seis metros, o indivíduo tem cada olho avaliado independentemente com auxílio de refratores oftalmológicos. Deve-se solicitar que cada linha seja lida, da esquerda para a direita e de cima para baixo. A menor linha lida representa a acuidade visual. Para esta avaliação, pode ser mantido o uso de óculos ou lentes de correção<sup>10</sup> . A interpretação dos resultados deverá ser feita considerando-se os parâmetros citados na **Tabela 1** deste **Apêndice 2** .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **APÊNDICE 3** -->
AVALIAÇÕES MÍNIMAS PARA O SEGUIMENTO CLÍNICO DOS PACIENTES COM MPS VII INDEPENDENTEMENTE DO USO DE TRE  
|Avaliações<sup>1,2, 3</sup>|Avaliação<br>inicial|A cada 6<br>meses|A cada 12<br>meses|
|---|---|---|---|
|Atividade enzimática|X|||
|GAG urinários<sup>#</sup>|X||X**|
|História médica|X|X||
|Aconselhamento Genético|X|||
|Revisão do número de infusões realizadas<br>no período**||X||
|Determinação<br>da<br>adesão<br>ao|X|X||
|acompanhamento/tratamento**||||
|Peso/altura|X|X||
|Pressão arterial|X|X||
|Hepatimetria e medida de tamanho do baço<br>(exame físico)|X|X||
|PedsQL-Fadiga (a partir de 8 anos)|X||X**|
|AVALIAÇÃO NEUROLÓGICA||||
|- Exame neurológico clínico|X|||
|AVALIAÇÃO<br>OFTALMOLÓGICA<br>(acuidade|X|X**||
|visual, retina, córnea)||||
|- TC6M** (a partir de 3 anos)|X|X||
|- CVF/VEF1 (espirometria; a partir de 6<br>anos)|X|X**|X|
|AVALIAÇÃO DA MOBILIDADE ARTICULAR|X|X**||
|(incluir flexão do ombro)||||  
#Avaliação recomendada: ao diagnóstico, após 3 meses de tratamento e, após, anualmente. **Para pacientes que estão em terapia de reposição enzimática, quando capazes de realizar a avaliação. As demais avaliações, incluindo as avaliações indicadas somente no período basal (iniciais), devem ser realizadas em períodos determinados pelo médico assistente. Espirometria deve ser realizada anualmente em pacientes que não estiverem em TRE. GAG = glicosaminoglicanos; PedsQL-Fadiga = Inventário de Qualidade de Vida Pediátrico - Módulo Multidimensional de Fadiga; TC6M = teste de caminhada de 6 minutos; CVF = capacidade vital forçada; VEF1 = volume expiratório forçado no primeiro segundo.  
Fontes: Elaborado a partir de Giugliani R et al. (2007)<sup>1</sup> e adaptado à MPS VII a partir dos estudos Harmatz et al., 2018<sup>2</sup> e Montaño et al., 2016<sup>3</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **APÊNDICE 4** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **1. ESCOPO E FINALIDADE DO PROTOCOLO** -->
A elaboração do PCDT de MPS VII foi conduzida sem uma reunião de escopo formal. Entretanto, o Grupo Elaborador deste PCDT incluiu duas especialistas geneticistas.  
Anteriormente à elaboração deste PCDT, a Conitec já havia avaliado as evidências disponíveis e decidido pela incorporação da alfavestronidase para o tratamento da MPS VII. Nesse sentido, nenhuma revisão de literatura foi feita com o intuito de subsidiar a recomendação desse medicamento em específico.  
Asssim, as recomendações quanto a alfavestronidase para o tratamento da MPS VII foram extraídas do Relatório de Recomendação no 540 de junho de 2020, da Conitec, aprovado pela Portaria no 26/SCTIE/MS, de 08 de agosto de 2020, disponível em: <u>http://conitec.gov.br/images/Relatorios/2020/Relatorio_de_Recomendacao_Alfavestronidase_mucopol issacaridose_540_2020.pdf.</u>  
Dessa forma, esse PCDT considera as melhores evidências advindas de diretrizes clínicas já publicadas por outros órgãos ou entidades nacionais e internacionais para o diagnóstico, cuidados e tratamento da MPS VII.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **2. EQUIPE DE ELABORAÇÃO E PARTES INTERESSADAS** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os membros do Grupo Elaborador preencheram o formulário de Declaração de  
Conflitos de Interesse

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **2.1.     Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
O documento foi apresentado à 85ª Reunião da Subcomissão de PCDT, da Conitec, realizada no dia 19 de janeiro de 2021. A versão atual deste PCDT já considera as solicitações desta Subcomissão.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **3. BUSCA DAS EVIDÊNCIAS** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Conitec para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da MPS VII. Foi também realizada, em 11/11/2020, busca por diretrizes clínicas nacionais e internacionais a respeito da doença.  
Não foram encontradas tecnologias disponíveis já incorporadas para o tratamento da MPS VII, além da alfavestronidase.  
As seguintes bases de dados e _websites_ institucionais que abrigam protocolos e diretrizes foram consultados, não sendo encontradas diretrizes clínicas específicas para esta doença:  
- NICE _guidelines_ <u>(http://www.nice.org.uk/guidance/published?type=CG);</u>  
- _National Library of Australia_ – http://webarchive.nla.gov.au/gov/;  
- Diretrizes da Associação Médica Brasileira (AMB);  
- Protocolos Clínicos e Diretrizes terapêuticas do Ministério da Saúde; e  
- PubMed/MEDLINE.  
Para a elaboração dos critérios diagnósticos e para a avaliação das situações especiais de gestação e aleitamento materno foram utilizadas diretrizes clínicas internacionais elaboradas por diferentes grupos de especialistas, que são utilizadas como consenso nos diversos centros de referência para outras MPS consideradas semelhantes<sup>11</sup> .  
Para avaliação de interrupção de tratamento, foi utilizada a seguinte estratégia de busca: “(mucopolysaccharidosis type vii OR Sly syndrome) AND interruption”, sendo apenas dois resultados encontrados que não continham dados sobre interrupção de tratamento<sup>12,13</sup> . Desta forma, para interrupção do tratamento foram utilizadas as diretrizes clínicas internacionais e estudos clínicos para outras MPS consideradas semelhantes<sup>14-18</sup> . Para a elaboração dos demais itens do PCDT, foram utilizadas as buscas, recomendações e referências constantes no relatório de recomendação da alfavestronidase como terapia de reposição enzimática no tratamento da MPS VII, disponível em: <u>http://conitec.gov.br/images/Relatorios/2020/Relatorio_de_Recomendacao_Alfavestronidase_mucopol issacaridose_540_2020.pdf .</u>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo VII | secao: **4. REFERÊNCIAS** -->
1. Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18.  
2. Harmatz P, Whitley CB, Wang RY, Bauer M, Song W, Haller C, et al. A novel Blind Start study design to investigate vestronidase alfa for mucopolysaccharidosis VII, an ultra-rare genetic disease. Mol Genet Metab. 2018;123(4):488-94.  
3. Montaño AM, Lock-Hock N, Steiner RD, Graham BH, Szlago M, Greenstein R, et al. Clinical course of sly syndrome (mucopolysaccharidosis type VII). J Med Genet. 2016;53(6):403-18.  
4. American Thoracic Society. Standardization of Spirometry, 1994 Update. American Thoracic Society. Am J Respir Crit Care Med. 1995;152(3):1107-36.  
5. Pereira C. Espirometria. J Pneumol. 2002;28(Supl. 3):S1-S82.  
6. ATS Committee on Proficiency Standards for Clinical Pulmonary Function Laboratories.  
ATS statement: guidelines for the six-minute walk test. Am J Respir Crit Care Med. 2002;166(1):111-7.  
7. James E Wraith, Lorne A Clarke, Michael Beck, Edwin H Kolodny, Gregory M Pastores, Joseph Muenzer, et al. Enzyme replacement therapy for mucopolysaccharidosis I: a randomized, doubleblinded, placebo-controlled, multinational study of recombinant human alpha-L-iduronidase (laronidase). J Pediatr. 2004;144(5):581-8.  
8. Torayuki Okuyama, Akemi Tanaka, Yasuyuki Suzuki, Hiroyuki Ida, Toju Tanaka, Gerald F Cox, et al. Japan Elaprase Treatment (JET) study: idursulfase enzyme replacement therapy in adult patients with attenuated Hunter syndrome (Mucopolysaccharidosis II, MPS II). Mol Genet Metab. 2010;99(1):18-25.  
9. ClinicalTrials.Gov [Internet]. A phase 3 study of UX003 recombinant human betaglucuronidase (rhGUS) enzyme replacement therapy in patients with mucopolysaccharidosis type 7 (MPS7); 2020. Available from: https://clinicaltrials.gov/ct2/show/NCT02230566.  
10. Azzam D, Ronquillo Y. Snellen Chart. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2020. Available from: https://www.ncbi.nlm.nih.gov/books/NBK558961/  
11. Ministério da Saúde. Galsulfase para o tratamento da mucopolissacaridose tipo VI. Brasil: Ministério da Saúde; 2018.  
12. Qi Y, McKeever K, Taylor J, Haller C, Song W, Jones SA, et al. Pharmacokinetic and Pharmacodynamic Modeling to Optimize the Dose of Vestronidase Alfa, an Enzyme Replacement  
Therapy for Treatment of Patients with Mucopolysaccharidosis Type VII: Results from Three Trials. Clin Pharmacokinet. 2019;58(5):673-83.  
13. Gimovsky AC, Luzi P, Berghella V. Lysosomal storage disease as an etiology of nonimmune hydrops. Am J Obstet Gynecol. 2015;212(3):281-90.  
14. Hendriksz CJ, Berger KI, Giugliani R, Harmatz P, Kampmann C, Mackenzie WG, et al. International guidelines for the management and treatment of Morquio A syndrome. Am J Med Genet A. 2015;167A(1):11-25.  
15. Giugliani R, Federhen A, Muñoz Rojas MV, Vieira T, Artigalás O, Lapagesse Pinto L, et al. Mucopolysaccharidosis I, II, and VI: brief review and guidelines for treatment. Genetics and Molecular Biology. 2010;33:589-604.  
16. Brunelli MJ, Atallah Á, da Silva EM. Enzyme replacement therapy with galsulfase for mucopolysaccharidosis type VI. Cochrane Database Syst Rev. 2016;3:CD009806.  
17. Wegrzyn G, Tylki-Szymańska A, Liberek A, Piotrowska E, Jakóbkiewicz-Banecka J, Marucha J, et al. Rapid deterioration of a patient with mucopolysaccharidosis type I during interruption of enzyme replacement therapy. Am J Med Genet A. 2007;143A(16):1925-7.  
18. Schneider AP, Matte U, Pasqualim G, Tavares AM, Mayer FQ, Martinelli B, et al. Deleterious effects of interruption followed by reintroduction of enzyme replacement therapy on a lysosomal storage disorder. Transl Res. 2016;176:29-37.

---

