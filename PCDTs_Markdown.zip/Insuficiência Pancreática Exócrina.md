<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Pancreática Exócrina.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre reposição enzimática para tratamento da insuficiência pancreática exócrina no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º  Fica aprovado, na forma do Anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo Clínico e Diretrizes Terapêuticas - Insuficiência Pancreática Exócrina.  
Parágrafo único. O Protocolo de que trata este artigo, que contém o conceito geral da insuficiência pancreática exócrina, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da insuficiência pancreática exócrina.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 57/SAS/MS, de 29 de janeiro de 2010, publicada no Diário Oficial da União nº 21, de 1º de fevereiro de 2010, seção 1, páginas 72 e 73.  
ALBERTO BELTRAME  
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
INSUFICIÊNCIA PANCREÁTICA EXÓCRINA

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Para a edição de 2010 deste Protocolo, foram realizadas buscas nas bases descritas abaixo. Foram avaliados todos os estudos disponíveis nas bases descritas, tendo sido selecionadas para avaliação meta-análises e ensaios clínicos randomizados, controlados e duplo-cegos publicados até a data limite de 01/10/2009.  
Na base MEDLINE/PubMed, utilizando-se a estratégia “"Pancreatitis, Chronic"[Mesh] AND Humans OR Meta-Analysis OR Randomized Controlled Trial”, foram localizados 15 artigos, sendo que apenas um se referia a medicamentos registrados na ANVISA.  
Na biblioteca Cochrane, foi utilizado o termo de busca "Pancreatitis, Chronic". Também foram utilizados na revisão os principais livros-texto de gastroenterologia, referências de ensaios clínicos constantes nesses livros e a base eletrônica UpToDate.  
Em 21/11/2014, foi realizada atualização da busca na literatura. Na base MEDLINE/PubMed, foi utilizada a estratégia “"Pancreatitis, Chronic"[Mesh] Filters activated: Meta-Analysis, Randomized Controlled Trial, Publication date from 2009/10/01, Humans”, resultando em 45 estudos. Desses, quatro foram selecionados para leitura na íntegra.  
Na base Embase, utilizando-se a estratégia “'chronic pancreatitis'/exp AND ([randomized controlled trial]/lim OR [meta analysis]/lim) AND [humans]/lim AND [2009-2014]/py AND ([cochrane review]/lim OR [systematic review]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim)” obtiveram-se 114 resultados. Quatro foram selecionados.  
Na biblioteca Cochrane, por meio da estratégia “"chronic pancreatitis" in Title, Abstract, Keywords in Cochrane Reviews', 2009-2014” foram obtidos quatro resultados; uma revisão foi selecionada.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Foram excluídos estudos com delineamento aberto e com duração inferior a 4 semanas. Foram também consultados os capítulos sobre o tema da publicação eletrônica UpToDate versão 19.2. A atualização da busca na literatura resultou na inclusão de três novas referências.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A digestão e a absorção dos alimentos ingeridos são processos complexos que envolvem pelo menos três fases. A primeira é a fase luminal, em que os alimentos são digeridos na luz do tubo digestivo por enzimas presentes em secreções ou na borda em escova do epitélio intestinal. A segunda fase é a absortiva, em que há fluxo dos nutrientes da luz do tubo digestivo para o meio interno. Na terceira fase, os nutrientes alcançam a circulação sanguínea (1). O pâncreas exerce papel fundamental na fase luminal da digestão, pois secreta para a luz intestinal diversas enzimas fundamentais para essa fase. Há grande reserva funcional, daí a má absorção de gordura e proteínas não ser aparente até que pelo menos 90% da função pancreática esteja perdida (2).  
A principal causa de deficiência pancreática exócrina não genética é a pancreatite crônica. Outras causas menos frequentes são os tumores pancreáticos, quando causam obstrução do ducto pancreático, e as pancreatectomias totais ou subtotais. A incidência anual da pancreatite crônica tem sido estimada entre 2 e 9 casos por 100.000 habitantes por ano (3).  
O quadro clínico típico da má absorção é a presença de esteatorreia (fezes claras, acinzentadas, volumosas, com cheiro forte, algumas vezes com gotas de gordura visíveis), associada à perda de peso a despeito de uma ingestão nutricional adequada (2). Alguns raros casos apresentam deficiências de vitaminas lipossolúveis, especialmente da vitamina D, com possibilidade de desenvolvimento de osteopenia e osteoporose (4).  
O objetivo do tratamento é o controle dos sintomas, principalmente da esteatorreia e da desnutrição. A normalização completa da absorção de gorduras é de difícil alcance na prática clínica, não oferece benefícios adicionais e não depende apenas do aumento progressivo da dose de enzimas (5). A insuficiência pancreática causa dificuldades na digestão de proteínas e carboidratos, mas o principal problema é a digestão das gorduras alimentares. Portanto, a reposição de lipase em casos de má absorção de origem pancreática normalmente

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
é suficiente para a melhora dos sintomas de má absorção descritos acima, embora a maioria das apresentações comerciais incluam amilase e protease junto com a lipase.  
Os suplementos enzimáticos são normalmente inativados pelo pH ácido no estômago ou destruídos por proteases. Para superar esse problema, existem duas alternativas. A primeira é a associação de enzimas pancreáticas com a supressão da acidez gástrica, por meio de antagonistas dos receptores H2 ou de inibidores da bomba de prótons (2). A segunda é a utilização de enzimas pancreáticas preparadas para dissolução entérica. Em casos refratários, as duas medidas podem ser utilizadas em conjunto.  
<mark>A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.</mark>  
Pacientes com insuficiência pancreática exócrina secundária à fibrose cística devem ser tratados de acordo com o Protocolo e Diretrizes Terapêuticas de Fibrose Cística - Enzimas Pancreáticas, do Ministério da Saúde.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- K86.0 Pancreatite crônica induzida pelo álcool;  
- K86.1 Outras pancreatites crônicas;  
- K90.3 Esteatorreia pancreática.  
4. DIAGNÓSTICO  
O diagnóstico de esteatorreia é clínico e laboratorial. Os exames laboratoriais mais comuns são a dosagem da excreção fecal de gorduras em 72 horas e a pesquisa qualitativa da gordura fecal (com a coloração de Sudan III). O primeiro teste está em desuso, pois é difícil de ser executado e porque a quantidade de gordura ingerida pelo paciente precisa ser quantificada por pelo menos 6 dias.  
Vários exames podem servir como diagnóstico de pancreatite crônica. Devido às diferenças de sensibilidade e especificidade, além das diferenças de complexidade e risco para o paciente, sugere-se uma abordagem diagnóstica racional na investigação da pancreatite  
crônica (6). A avaliação deve iniciar por uma radiografia simples de abdômen, em que a presença de calcificações no parênquima pancreático é diagnóstica de pancreatite crônica. Recomenda-se ainda a realização de uma ultrassonografia abdominal, que serve tanto para investigação diagnóstica quanto para exclusão de complicações. Se as radiografias simples de abdômen e a ultrassonografia não forem diagnósticas, sugere-se a realização de tomografia computadorizada abdominal se a suspeita clínica for muito forte.  
Uma minoria dos casos com pancreatite crônica apresenta radiografia simples de abdômen, ultrassonografia e tomografia computadorizada normais. Nesses casos, pode ser necessária a realização de exames adicionais, como a colangiopancreatografia endoscópica retrógrada (CPER) ou ultrassonografia endoscópica (6). Como a CPER apresenta uma taxa de até 5% de complicações, ela tem sido substituída pela ressonância magnética de vias biliares. Esse é um método diagnóstico não invasivo, capaz de visualizar a morfologia dos ductos e do parênquima pancreáticos. No entanto, a CPER e a ressonância magnética de vias biliares não conseguem diagnosticar pancreatites crônicas sem anormalidades ductais significativas.  
5. CRITÉRIOS DE INCLUSÃO  
Serão incluídos neste Protocolo pacientes que apresentarem esteatorreia (com pesquisa qualitativa da gordura fecal positiva pela coloração de Sudan III ou dosagem da excreção fecal de gorduras em 72 horas maior que 6 g/dia) associada a pelo menos um dos critérios abaixo (6):  
- Radiografia simples de abdômen mostrando calcificações salpicadas e difusas no  
- parênquima pancreático;  
- Ultrassonografia de abdômen mostrando dilatação do ducto pancreático principal  
- acima de 0,4 cm, ou cistos ou calcificações parenquimatosas;  
- Tomografia computadorizada de abdômen mostrando dilatação ductal, cistos ou  
- calcificações no parênquima;  
- Colangiopancreatografia endoscópica retrógrada ou ressonância magnética de vias biliares mostrando dilatação, estenoses ou defeitos de enchimento no ducto pancreático principal associados a alterações em pelo menos três ramos colaterais;  
- Laudo cirúrgico descrevendo ressecção pancreática subtotal ou total.  
Em casos de câncer pancreático ou ressecções pancreáticas por outras indicações, os critérios de inclusão são clínicos (presença de esteatorreia).

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão excluídos deste Protocolo os pacientes que apresentarem hipersensibilidade ou intolerância ao medicamento (proteína de suínos).

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Uma revisão sistemática publicada em 2009 (7) avaliou o tratamento de reposição enzimática na pancreatite crônica em 619 artigos, dos quais apenas quatro foram incluídos na análise. Não foram encontrados estudos que tivessem comparado a eficácia de diferentes suplementos comerciais. A suplementação de enzimas melhorou a absorção de gorduras quando comparada ao placebo, embora a absorção total não tenha sido alcançada. A conclusão da revisão foi que a complementação de enzimas melhora, mas não elimina, a esteatorreia. Revisão sistemática da Cochrane publicada em 2009 concluiu que o tratamento com enzimas pancreáticas é eficaz na redução de gordura fecal (8).  
Aventou-se a possibilidade de que a reposição de pancreatina pudesse ser benéfica também em aliviar a dor que acompanha os casos de pancreatite crônica. A base teórica seria a de que a reposição de enzimas pancreáticas poderia gerar uma retroalimentação negativa no estímulo para a secreção pancreática, levando a uma diminuição na pressão nos ductos pancreáticos e assim diminuição da dor (9). Nos anos 1980 foram publicados dois estudos, um com 19 e outro com 20 pacientes, que mostraram benefício da reposição enzimática no controle da dor (10,11). Os dois estudos foram cruzados, controlados por placebo, cegos e randomizados. Contudo, graves problemas metodológicos foram encontrados. Além de serem cruzados, sendo que um sem período de _wash-out_ , e com pequeno número de pacientes, houve curto período de seguimento e o sintoma dor não foi avaliado por questionário de sintomas validado. Os estudos também não foram adequadamente descritos, não constando a quantidade de enzimas administrada nem uma descrição detalhada da forma como os dados foram analisados. Em um desses estudos (11), houve benefício apenas em um subgrupo de

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
nove pacientes, não estando descrita a análise de todos os pacientes em conjunto. A reanálise desse estudo por outro grupo não mostrou melhora da dor com o uso de enzimas (12).  
Outros quatro ensaios clínicos randomizados duplo-cegos foram realizados após esses dois estudos iniciais (13-16). Totalizando em conjunto 150 pacientes, nenhum deles encontrou melhora da dor com a utilização de enzimas pancreáticas. Uma meta-análise de todos esses estudos, publicada em 1997, não encontrou benefício no uso de enzimas pancreáticas para o alívio da dor da pancreatite crônica (12). Inexistem provas conclusivas que a reposição enzimática possa melhorar a dor da pancreatite crônica.  
O tratamento deve ser realizado de forma a diminuir a esteatorreia e contribuir para a manutenção de um estado nutricional adequado. A quantidade de enzimas necessária para alcançar esses objetivos é variável, devendo ser ajustada conforme a resposta clínica. Atualmente não se recomenda restrição de gorduras na dieta, devido ao risco de agravar deficiências nutricionais (17).

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Pancreatina: cápsulas de 10.000 e 25.000 unidades internacionais (UI) de lipase  
A dose em UI é baseada na quantidade de lipase presente na formulação.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Pancreatina: 10.000 UI a 50.000 UI nas três principais refeições; e 10.000 UI a 25.000 UI  
em duas refeições adicionais.  
Recomenda-se iniciar com uma dose de lipase de 10.000 UI por refeição e titular de acordo com a resposta terapêutica, avaliada pela melhora dos sintomas, até uma dose de 50.000 UI por refeição. Nos lanches diários, deve-se tomar metade da dose preconizada para as principais refeições.  
As cápsulas devem ser tomadas com bastante líquido e não podem ser amassadas ou mastigadas. Além disso, não devem permanecer na boca porque podem provocar irritação da mucosa e estomatite. Para pacientes que não obtiverem resposta com a dose máxima, após garantida a boa adesão ao tratamento, outras alternativas devem ser tentadas, como o fracionamento das refeições e o uso simultâneo de antagonistas dos receptores H2 ou de  
<!-- Start of picture text -->
|<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
inibidores da bomba de prótons, a fim de se maximizar o efeito enzimático através da adequação do pH intraluminal no sítio de ação (9).

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento será contínuo, pelo tempo em o paciente dele se beneficiar.  
- 7.4 Benefícios esperados  
- Melhora da esteatorreia;  
- Manutenção de um bom estado nutricional.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A monitorização da melhora da esteatorreia deve ser feita semestralmente por meio da anamnese e da avaliação do estado nutricional, que deve ser realizada pela avaliação do índice de massa corporal, a fim de otimizar a dose do medicamento.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a conformidade da prescrição em relação à posologia recomendada, e as quantidades dispensadas por paciente.  
<mark>Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual</mark>  
<mark>componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.</mark>

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
É obrigatório informar ao paciente ou a seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso <mark>do medicamento preconizado neste</mark>  
<mark>Protocolo, levando-se em consideração as informações contidas no TER.</mark>  
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1. Marsh M, Riley S. Maldigestion and malabsorption. In: Feldman M, Friedman LS, Brandt LJ editors. Sleisenger and Fordtran’s gastrointestinal and liver disease. Philadelphia: Saunders Co.; 2003. p. 1471-95.  
2. Mason JB, Milovic VM. Overview of the treatment of malabsorption [Internet]. UpToDate; 2014 [acesso em 07/12/2015]. Disponível em: http://www.uptodate.com/contents/overview-of-the-treatment-of-malabsorption.  
3. Kocher HM. Chronic pancreatitis. Am Fam Physician. 2008;77(5):661-2.  
4. Freedman S. Clinical manifestations and diagnosis of chronic pancreatitis in adults [Internet]. UpToDate; 2014 [acesso em 07/12/2015]. Disponível em: http://www.uptodate.com/contents/clinical-manifestations-and-diagnosis-of-chronicpancreatitis-in-adults.  
5. O'Keefe SJ, Cariem AK, Levy M. The exacerbation of pancreatic endocrine dysfunction by potent pancreatic exocrine supplements in patients with chronic pancreatitis. J Clin Gastroenterol. 2001;32(4):319-23.  
6. Owyang C. Chronic pancreatitis. In: Yamada T, Alpers DKN, Laine L, Owyang C, Powell D, editors. Textbook of gastroenterology. Philadelphia: Lippincott Williams & Wilkins; 2003. p. 2061-90.  
7. Waljee AK, Dimagno MJ, Wu BU, Schoenfeld PS, Conwell DL. Systematic review: pancreatic enzyme treatment of malabsorption associated with chronic pancreatitis. Aliment Pharmacol Ther. 2009;29(3):235-46.  
8. Shafiq N, Rana S, Bhasin D, Pandhi P, Srivastava P, Sehmby SS, et al. Pancreatic enzymes for chronic pancreatitis. Cochrane Database Syst Rev. 2009(4):Cd006302.  
9. Fosmark C. Chronic pancreatitis. In: Feldman M, Friedman LS, Brandt LJ editors. Sleisenger and Fordtran’s gastrointestinal and liver disease. 8th edition. Philadelphia: Saunders Co.; 2006. p. 1271-308.  
10. Isaksson G, Ihse I. Pain reduction by an oral pancreatic enzyme preparation in chronic pancreatitis. Dig Dis Sci. 1983;28(2):97-102.  
11. Slaff J, Jacobson D, Tillman CR, Curington C, Toskes P. Protease-specific suppression of pancreatic exocrine secretion. Gastroenterology. 1984;87(1):44-52.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
12. Brown A, Hughes M, Tenner S, Banks PA. Does pancreatic enzyme supplementation reduce pain in patients with chronic pancreatitis: a meta-analysis. Am J Gastroenterol. 1997;92(11):2032-5.  
13. Malesci A, Gaia E, Fioretta A, Bocchia P, Ciravegna G, Cantor P, et al. No effect of long-term treatment with pancreatic extract on recurrent abdominal pain in patients with chronic pancreatitis. Scand J Gastroenterol. 1995;30(4):392-8.  
14. Halgreen H, Pedersen NT, Worning H. Symptomatic effect of pancreatic enzyme therapy in patients with chronic pancreatitis. Scand J Gastroenterol. 1986;21(1):104-8.  
15. Mössner J, Secknus R, Meyer J, Niederau C, Adler G. Treatment of pain with pancreatic extracts in chronic pancreatitis: results of a prospective placebo-controlled multicenter trial. Digestion. 1992;53(1-2):54-66.  
16. Larvin M, McMahon M, Thomas W. Creon (enteric-coated pancreatin microspheres) for the treatment of pain in chronic pancreatitis. A double-blind, randomized, placebocontrolle, crossover study. Gastroenterology. 1991. p. 100:A283.  
17. Freedman S. Treatment of chronic pancreatitis. [Internet]. UpToDate; 2013 [acesso em 07/12/2015]. Disponível em: http://www.uptodate.com/contents/treatment-of-chronicpancreatitis.

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Eu, ________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso da pancreatina, indicados para o tratamento da insuficiência pancreática exócrina.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ______________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora do cheiro e da quantidade de gordura nas fezes (esteatorreia);  
- manutenção de um bom estado nutricional.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez; portanto, caso  
- engravide, não devo interromper o tratamento e devo avisar imediatamente o médico;  
- contraindicação em casos de hipersensibilidade conhecida ao medicamento ou à  
- proteína de suínos;  
- as cápsulas devem ser tomadas com bastante líquido e não podem ser amassadas ou mastigadas; além disso, não devem permanecer na boca porque podem provocar irritação da mucosa e estomatite;  
- a cápsula não deve ser rompida, pois o contato do pó com a pele pode causar irritação,  
e a inalação pode causar falta de ar;  
- as reações adversas mais comuns, mas com baixa ocorrência, incluem náusea, diarreia,  
prisão de ventre e reações alérgicas na pele;  
- doses extremamente altas têm sido associadas com aumento do ácido úrico na urina  
- (hiperuricosúria) e no sangue (hiperuricemia).

---

<!-- METADADOS: doenca: Insuficiência Pancreática Exócrina | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser assistido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim    (   ) Não  
|Local:                                                                                          Data:||
|---|---|
|Nome do paciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||
|Documento de identificação do responsável legal:||
|_____________________________________<br>Assinatura do paciente ou do responsável legal||
|Médico Responsável:<br>CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico<br>Data:____________________||

---

