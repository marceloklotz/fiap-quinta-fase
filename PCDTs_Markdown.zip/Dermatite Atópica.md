<!-- METADADOS: doenca: Dermatite Atópica | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE -->
PORTARIA CONJUNTA Nº 28, DE 27 DE NOVEMBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Dermatite Atópica.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Dermatite Atópica no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1047/2025 e o Relatório de Recomendação nº 1047 de 2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Dermatite Atópica.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Dermatite Atópica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Dermatite Atópica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS nº 34, de 20 de dezembro de 2023, publicada no Diário Oficial da União (DOU) nº 243, de 22 de dezembro de 2023, seção 1, página 168.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 1. **INTRODUÇÃO** -->
A dermatite atópica (DA) é uma doença crônica não contagiosa, com componentes genéticos e ambientais contribuindo para o seu desenvolvimento<sup>4</sup> . Também conhecida como eczema atópico, é uma condição inflamatória e pruriginosa da pele, que ocorre com maior frequência em crianças (início precoce), mas afeta também os adultos, os quais representam um terço de todos os casos novos da doença<sup>4–6</sup> .  
A prevalência global de DA, de acordo com estudo conduzido pelo _International Study of Asthma and Allergies in Childhood_ (ISAAC) em 2013, foi de 7,9% em crianças de 6 e 7 anos e de 7,3% em adolescentes de 13 e 14 anos<sup>7</sup> . Na população brasileira, em 2006, foi identificado que 12,1% das crianças de 6 e 7 anos e 10,2% dos adolescentes de 13 e 14 anos já tiveram eczema diagnosticado por um médico<sup>8</sup> . No entanto, estudos brasileiros apresentam prevalências discrepantes: 20,1%, entre indivíduos de 6 meses a 17 anos e 5,4%, em crianças menores de 12 anos<sup>9,10</sup> .  
A prevalência da DA pode variar de acordo com a definição utilizada para diagnóstico e com a gravidade da doença. Na população pediátrica brasileira, uma menor proporção de pacientes apresenta DA em sua forma grave. Com base na escala _Patient Oriented Eczema Measure_ (POEM), estima-se que 6,1%, 7,4% e 8,2% dos indivíduos nas faixas etárias de 6 meses a <6 anos, 6 anos a <12 anos e 12 a 18 anos, respectivamente, sejam diagnosticados com DA grave<sup>9</sup> .  
Nos adultos, a prevalência de DA é cerca de 1% a 3% na maioria dos países sendo mais prevalente em pessoas com “tendência atópica”, as quais desenvolvem de uma até três das condições intimamente ligadas: dermatite atópica, rinite alérgica e asma<sup>4,11</sup> . No Brasil, um inquérito realizado com 300 mil pessoas em 88 municípios encontrou uma prevalência de 2,3%, sendo 2,8% em mulheres e 1,8% em homens<sup>10</sup> .A fisiopatologia da DA é complexa e envolve fatores genéticos, ambientais, anormalidade da barreira cutânea, desregulação imunológica e alterações do microbioma da pele, que levam a lesões cutâneas e prurido intenso, comprometendo a saúde e a qualidade de vida das pessoas afetadas por esta condição<sup>7,8,12</sup> .  
Os pacientes com DA têm barreira cutânea suscetível à xerose, um estado de ressecamento patológico da pele ou das membranas mucosas, fazendo com que a exposição a irritantes ambientais e alérgenos levem à inflamação e prurido. As alterações da barreira cutânea podem ocorrer pela diminuição dos níveis de ceramidas, que desempenham um papel na função de barreira da pele e previnem a perda de água transepidérmica.<sup>13</sup>  
A barreira cutânea defeituosa permite que irritantes e alérgenos penetrem na pele e causem inflamação devido a uma resposta Th2 hiperativa (com aumento de IL-4 e citocinas IL-5) em lesões agudas e resposta Th1 (com IFN-γ e IL-12) em lesões crônicas. A filagrina é uma proteína epidérmica decomposta em fator de hidratação natural, de modo que a deficiência dessa proteína também é considerada um dos principais determinantes para alteração da barreira cutânea<sup>13</sup> .  
Pacientes com DA são predispostos ao desenvolvimento de infecções cutâneas bacterianas e virais, sendo que cerca de 90% dos indivíduos atópicos são colonizados por Staphylococcus aureus<sup>14</sup> . O eczema herpético, também chamado de erupção variceliforme de _Kaposi_ , é uma complicação rara que pode afetar pacientes com DA. Em crianças com DA, lesões atípicas da doença-mão-pé-boca tendem a aparecer em áreas previamente ou atualmente afetadas pela dermatite, semelhantes ao eczema herpético<sup>15</sup> .  
A DA também acarreta complicações extracutâneas, como o envolvimento oftalmológico e psicológico. Problemas oculares em pacientes com DA incluem ceratoconjuntivite atópica (AKC) e ceratoconjuntivite vernal (VKC)<sup>15</sup> . AKC é uma doença ocular crônica, alérgica, que ocorre com maior frequência em adultos com histórico de DA. A VKC ocorre mais  
2  
comumente em crianças que vivem em climas quentes, secos e subtropicais. Queimação, lacrimejamento e complicações como ceratocone, queratite infecciosa e blefarite também podem ocorrer<sup>15</sup> .  
Evidências sugerem que vários transtornos e sintomas psiquiátricos, incluindo atividade psicossocial prejudicada, transtorno de déficit de atenção e hiperatividade, dificuldade de aprendizagem, depressão e transtornos de ansiedade, são mais comuns entre adultos e crianças com DA do que na população em geral. A associação da DA com transtornos psiquiátricos pode ser influenciada pela gravidade da doença e outros fatores que afetam negativamente a qualidade de vida, como perda de sono, prurido incapacitante e constrangimento social<sup>15</sup> .  
O cuidado da DA deve começar com a educação dos pacientes, pais ou responsáveis sobre a natureza crônica da doença e a importância da terapia de manutenção, que melhora a barreira cutânea e previne a sensibilização a alérgenos. A DA pode afetar a qualidade de vida dos pacientes e de suas famílias, com consequências físicas, emocionais e sociais. Além disso, a carga econômica da DA inclui custos diretos de tratamento e custos indiretos, como perda de produtividade de pacientes ou de suas famílias<sup>16</sup> . Dados da Pesquisa Nacional de Saúde e Bem-Estar dos EUA estimaram taxas maiores de absenteísmo e presenteísmo em pacientes que autorreferiram DA, comprometendo a estabilidade financeira desta população<sup>17</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 2. **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- L20.0 - Prurigo de Besnier;  
- L20.8 - Outras dermatites atópicas.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 3. **DIAGNÓSTICO** -->
O diagnóstico de DA é essencialmente clínico, com base na história do paciente, morfologia e distribuição das lesões cutâneas, sinais clínicos associados e exclusão de múltiplas condições eritematosas e eczematosas. Porém, devido à alta variabilidade da apresentação clínica relacionada à idade, etnia e gravidade, o diagnóstico pode ser difícil, especialmente em bebês e idosos<sup>11,19</sup> .  
As lesões eczematosas podem se apresentar com formas agudas (edema, vesículas e secreções), subagudas (eritema e edema menos intensos e presença de secreção e crostas nas lesões) e crônicas (liquenificação/espessamento e endurecimento da pele, prurido intenso e lesões de aspecto mais seco)<sup>12,20</sup> . No **Quadro 1** são apresentadas as apresentações clínicas da DA de acordo com a fase de vida do paciente.  
**Quadro 1 –** Apresentação clínica da dermatite atópica de acordo com a idade do paciente.  
|**Idade**|**Apresentação clínica**|
|---|---|
|Infância (0-2 anos)|Lesões agudas caracterizadas por eritema mal definido com edema,<br>vesículas, escoriações e exsudato, que podem ser amplamente|  
3  
|**Idade**|**Apresentação clínica**|
|---|---|
||distribuídos. Normalmente, acometem o rosto, bochechas e o tronco,<br>exceto área da fralda.|
|Infância/adolescência (2-16 anos)|O eczema se torna mais localizado e crônico do que na infância, com<br>eritema mais pálido, pele seca (xerose) e lesões mal definidas que<br>comumente afetam superfícies dos flexores com espessamento de<br>áreas crônicas.|
|Adultos|Apresentam eczema crônico nas mãos ou dermatite acometendo o<br>pescoço, cabeça, tronco superior, ombros e couro cabeludo.|  
Fonte: adaptado de Langan _et al_ . (2020)<sup>12</sup> & Silverberg _et al_ . (2017)<sup>20</sup>  
A DA pode ser classificada como leve, moderava e grave, dependendo de características clínicas e impacto na qualidade de vida do paciente. O Quadro 2 apresenta a classificação da gravidade da DA, de acordo com o guia prático de atualização da Associação Brasileira de Alergia e Imunologia e da Sociedade Brasileira de Pediatria<sup>21</sup> .  
**Quadro 2 –** Classificação da gravidade da dermatite atópica.  
|**Gravidade**|**Clínica**|**Psicossocial**|
|---|---|---|
|Livre|Pele normal, sem evidência de atividade da dermatite|Sem impacto na qualidade de vida|
|Leve|Áreas com xerose, prurido infrequente (com ou sem<br>áreas inflamadas)|Pequeno impacto na qualidade de vida|
||Áreas com xerose, prurido frequente associado à|Moderado impacto nas atividades diárias e|
|Moderada|inflamação (com ou sem sinais de escoriação e áreas<br>localizadas de espessamento da pele|psicossociais, distúrbios do sono frequentes|
|Grave|Xerose difusa, prurido constante e associado à<br>inflamação (com ou sem sinais de escoriação, pele<br>espessada com sangramento, liquenificação e alterações<br>da pigmentação)|Limitação das atividades diárias e<br>psicossociais, noites de sono perdidas.|  
Fonte: adaptado de Antunes _et al_ . (2017)<sup>21</sup>  
Pacientes com doença leve podem apresentar crises intermitentes com remissão espontânea, mas em pacientes com dermatite moderada a grave, os sintomas raramente desaparecem sem tratamento<sup>14</sup> .  
No exame físico é possível observar xerose, liquenificação (espessamento e aumento das marcas da pele), eczema, incluindo áreas mal definidas de eritema, descamação, vesico-pápulas agrupadas e crostas, e escoriações devido principalmente aos arranhões decorrentes do prurido.<sup>5,11,19</sup> O prurido é um sintoma bastante comum entre os pacientes com DA que causa arranhões e contribui para penetração de alergenos e irritantes na pele aumentando o risco de infecção cutânea localizada, além de ser incapacitante afetando o sono e a qualidade de vida no geral<sup>22–24</sup> . O prurido é induzido também pela histamina que por sua vez é liberada pelos mastócitos na pele em resposta aos anticorpos da imunoglobulina E (IgE). No entanto anti-histamínicos não são utilizados para o tratamento da DA e, por isso, não serão abordados neste PCDT<sup>23</sup> . O rosto é um local de acometimento comum em bebês, enquanto regiões de dobras e área flexural são, geralmente, afetadas em crianças maiores e adultos<sup>19</sup> . Em  
4  
alguns pacientes, o eczema se torna generalizado, e naqueles que apresentam tons de pele mais escuros, o acometimento folicular proeminente é comum<sup>19</sup> .  
Vários critérios já foram propostos para auxiliar o diagnóstico de DA e a maioria vem sendo utilizada em estudos epidemiológicos e fornece orientação para a abordagem diagnóstica no ambiente clínico. Os critérios diagnósticos de Hanifin e Rajka<sup>25</sup> e do grupo de trabalho para DA do Reino Unido<sup>26</sup> são reconhecidos globalmente e, pela sua facilidade de utilização, foram adotados neste Protocolo.  
Os critérios de Hanifin e Rajka ( **Quadro 3** ) são abrangentes e geralmente considerados o “padrão-ouro” para o diagnóstico de DA. Com este instrumento define-se DA com 3 ou mais critérios maiores e 3 ou mais critérios menores.  
**Quadro 3 –** Critérios clássicos de Hanifin e Rajka para diagnóstico de dermatite atópica.  
|**Critérios maiores (3 ou mais)**|
|---|
|1. Prurido|
|2. Morfologia e distribuição típicas:|
|2.1 Liquenificação ou linearidade de superfícies flexoras em adultos|
|2.2 Envolvimento de face ou de superfícies extensoras em bebês e crianças|
|3. Dermatite crônica ou cronicamente recidivante|
|4. História pessoal ou familiar de atopia, como asma, rinite alérgica, dermatite atópica|
|**Critérios menores (3 ou mais)**|
|1. Xerose|
|2. Ictiose/hiperlinearidade palmar/queratose pilar|
|3. Reatividade imediata (tipo 1) do teste cutâneo|
|4. Imunoglobulina E sérica elevada|
|5. Idade precoce de início|
|6. Tendência para infecções cutâneas (S. aureus e herpes simples vírus)/imunidade prejudicada, mediada por células|
|7. Tendência para dermatite não específica da mão ou do pé|
|8. Eczema do mamilo|
|9. Queilite|
|10. Conjuntivite recorrente|
|11. Dobra infraorbitária de Dennie-Morgan|
|12. Ceratocone|
|13. Catarata subcapsular anterior|
|14. Escurecimento orbita|
|15. Palidez facial/eritema facial|
|16. Pitiríase alba|
|17. Dobra cervical anterior|
|18. Prurido ao suar|
|19. Intolerância à lã e solventes lipídicos|
|20. Acentuação perifolicular<br>21. Intolerância alimentar|  
5  
|22. Influência do curso por fatores ambientais/emocionais|
|---|
|23. Dermografismo branco/branqueamento tardio|  
Fonte: Adaptado de Hanifin e Rajka (1980)<sup>25</sup> .  
Os critérios do Grupo de Trabalho do Reino Unido para DA são uma versão condensada dos critérios Hanifin e Rajka. Para essa classificação, o paciente deve apresentar prurido em associação com três ou mais critérios ( **Quadro 4** ).  
**Quadro 4 -** Critérios do Grupo de Trabalho do Reino Unido para diagnóstico de dermatite atópica.  
|**Prurido nos últimos 12 meses em associação com 3 ou mais critérios**|
|---|
|1. Pacientes com mais de 4 anos e histórico de início dos sintomas antes dos 2 anos|
|2. História de envolvimento flexural|
|2. História da pele geralmente seca|
|4. História de outra doença atópica no paciente ou em parente de primeiro grau|
|5. Dermatite flexural visível|  
**Fonte:** adaptado de Williams _et al_ . (1994)<sup>26</sup> .  
A biópsia de pele e os testes laboratoriais, incluindo níveis de imunoglobulina E (IgE), não são usados rotineiramente na avaliação de pacientes com suspeita de DA<sup>27</sup> . No entanto, em alguns pacientes o exame histológico da biópsia de pele ou outros testes laboratoriais podem ser úteis para descartar outras condições de pele<sup>11,19</sup> .  
Os pacientes com DA podem apresentar outras condições, que podem agravar a DA ou serem agravadas por ela, como dermatite de contato alérgica ou irritante, dermatite atópica associada à alergia alimentar e associada à aeroalérgenos. Estas condições são apresentadas na seção de diagnóstico diferencial.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **3.1. Avaliação da gravidade da DA** -->
Além dos critérios diagnósticos mencionados acima, é essencial realizar a avaliação da extensão e gravidade das lesões cutâneas para definição da abordagem terapêutica mais apropriada - inclusive a prescrição de medicamentos, bem como monitoramento da resposta ao tratamento.  
É necessário que sejam avaliadas a extensão e as características da erupção cutânea e que se façam perguntas sobre prurido, sono, impacto nas atividades diárias e persistência da doença. Diversas escalas foram desenvolvidas para avaliação da gravidade da DA ( **Quadro 5** )<sup>5,27–29</sup> .  
As escalas validadas incluem o _Scoring of Atopic Dermatites_ (SCORAD) e o _Eczema Area and Severity Index_ (EASI), as quais consideram os sinais clínicos e a área de acometimento. Uma ferramenta _online_ para auxiliar a aplicação da escala SCORAD, disponível em língua inglesa, também inclui uma avaliação subjetiva do prurido e do sono<sup>30</sup> .  
As escalas SCORAD e EASI são usadas principalmente em ensaios clínicos e demandam maior tempo quando utilizadas na rotina clínica. A _Patient-Oriented Eczema Measure_ (POEM) e _Patient-Oriented SCORAD_ (PO-SCORAD) são escalas respondidas pelo paciente, são menos demoradas e mais fáceis de usar, porém podem ser menos precisas. A _Investigator Global Assessment_ (IGA) e a _Validated Investigator Global Assessment for Atopic Dermatitis (_ vIGA-AD _)_ são escalas bastante utilizadas por órgãos. No entanto, IGA é um termo abrangente para mais de 20 escalas variantes publicadas na literatura. Apenas em 2020, especialistas desenvolveram a vIGA-AD e que incluiu avaliação global da doença, sendo executada por um clínico treinado<sup>29</sup> . É  
6  
necessário que os médicos avaliem as vantagens e desvantagens das escalas disponíveis para decisão daquela que será utilizada na rotina clínica<sup>29</sup> .  
**Quadro 5 -** Escalas para avaliação da gravidade da dermatite atópica.  
|**Escala**|**Parâmetros avaliados**|**Gravidade**|**Validação**|
|---|---|---|---|
|EASI<br>(Eczema Area and Severity<br>Index)|Área afetada e gravidade para<br>quatro regiões (cabeça, braços,<br>tronco e pernas)|Limpo (0)<br>Quase limpo (0,1 a 1,0)<br>Leve (1,1 a 7)<br>Moderada (7,1 a 21)<br>Grave (21,1 a 50)<br>Muito grave (50,1 a 72)|Sim|
|SCORAD<br>(Scoring of Atopic<br>Dermatites)|Extensão da doença, gravidade<br>da lesão e sintomas subjetivos<br>relatados pelo paciente (prurido<br>e perda de sono)|Limpo (0 a 9,9)<br>Leve (10 a 28,9)<br>Moderada (29 a 48,9)<br>Grave (49 a 103)|Sim|
|POEM<br>(Patient-Oriented Eczema<br>Measure)|Aspectos clínicos dos últimos<br>sete dias (prurido, sangramento,<br>exsudato, descamação,<br>ressecamento, rachaduras) e<br>sono, avaliadas pelo paciente ou<br>cuidador|Limpo/quase limpo (0 a<br>2)<br>Leve (3 a 7)<br>Moderada (8 a 16)<br>Grave (17 a 24)<br>Muito grave (25 a 28)|Sim|
|PO-SCORAD<br>(Patient-Oriented<br>SCORAD)|Extensão (locais afetados +<br>porcentagem de área),<br>intensidade das lesões,<br>intensidade da coceira e<br>dificuldades para dormir,<br>avaliadas pelo paciente ou<br>cuidador|Limpo (0 a 9,9)<br>Leve (10 a 28,9)<br>Moderada (29 a 48,9)<br>Grave (49 a 103)|Sim|
|vIGA-AD<br>(Validated Investigator<br>Global Assessment for<br>Atopic Dermatitis)|Gravidade da DA com base na<br>avaliação global por avaliadores<br>treinados, baseado em quatro<br>aspectos clínicos (eritema,<br>endurecimento/papulações,<br>liquenificação e<br>exudação/crostas)|Limpo (0)<br>Quase limpo (1)<br>Leve (2)<br>Moderada (3)<br>Grave (4)|Sim|
|IGA|Gravidade da doença com base|Limpo (0)||
|(Investigator Global<br>Assessment)|na avaliação global por<br>avaliadores treinados|Quase limpo (1)<br>Leve (2)|Não|  
7  
|**Escala**|**Parâmetros avaliados**|**Gravidade**|**Validação**|
|---|---|---|---|
|||Moderada (3)||
|||Grave (4)||
|Prurido-NRS|Prurido relatado pelo paciente.|Leve (0-3)||
|(Pruritus Numerical Rating|Escala de 1-10 (0 = sem prurido;|Moderada (4-6)|Não|
|Scale)|10 = pior prurido imaginável)|Grave (7-10)||  
Fonte: adaptado de Fishbein _et al_ . (2020)<sup>29</sup> e Simpson _et al_ . (2020)<sup>28</sup>

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **3.1.1. Avaliação da qualidade de vida** -->
Em relação à qualidade de vida, um método de avaliação relevante é o Índice de Qualidade de Vida Dermatológico (DLQI), instrumento validado para uso no Brasil (Material Suplementar)<sup>31</sup> . Trata-se de um questionário de 10 itens que avalia o impacto de doenças cutâneas na qualidade de vida dos pacientes em relação às atividades de vida diária, lazer, trabalho, estudo, relações pessoais e tratamento. Cada item é pontuado de 0 a 3, e o escore total varia de 0 a 30, sendo tanto melhor a qualidade de vida quanto menor o escore. Uma redução de 5 pontos no escore total tem demonstrado significância clínica como desfecho positivo de uma intervenção terapêutica<sup>31</sup> .  
Outro instrumento útil na avaliação da qualidade de vida é o Escore da Qualidade de Vida na Dermatologia Infantil - CDLQI ( _Children’s Dermatology Life Quality Index_ ), criado para avaliar a qualidade de vida de pacientes entre 5 e 16 anos de idade com diversas dermatoses (Material Suplementar)<sup>32</sup> . O CDLQI é autoexplicativo e possui 10 itens que devem ser respondidos considerando a semana anterior à aplicação do questionário<sup>32</sup> . Os itens são divididos em seis grupos ou domínios (sintomas e sentimentos, lazer, escola/férias, relações pessoais, sono e tratamento) e as respostas variam entre muitíssimo, muito, pouco e não, com escores de 3, 2, 1 ou zero, respectivamente. O resultado é obtido pela soma dos escores de cada questão e quanto mais alto o resultado, pior a qualidade de vida do paciente<sup>32</sup> . Estes questionários podem ser utilizados à critério dos serviços de saúde, quando operacionalmente viável.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **3.2. Diagnóstico diferencial** -->
A manifestação da DA pode apresentar particularidades como:  
**Dermatite de contato alérgica ou irritante** : a dermatite de contato alérgica ou irritante pode ser de difícil diferenciação da DA. Além disso, a dermatite de contato alérgica pode coexistir com a dermatite atópica. A localização da dermatite em uma área específica da pele, histórico de exposição a irritantes e uma positividade relevante no teste alérgico de contato ( _patch test_ ) sugerem o diagnóstico de dermatite de contato. A biópsia de pele não é útil para distinguir a dermatite de contato irritante ou alérgica da dermatite atópica, pois compartilham características histopatológicas idênticas<sup>33</sup> .  
**Dermatite atópica associada à alergia alimentar:** pacientes com DA tem risco aumentado de alergias induzidas por alimentos, sendo essa relação mais importante na primeira infância. O padrão-ouro para o diagnóstico de alergia alimentar é uma provocação alimentar oral (cega e controlada por placebo) realizada após um período sem contato com o alimento suspeito<sup>33,34</sup> . O teste de provocação oral deve ser realizado em ambiente adequado, com suporte especializado e recursos para manejo imediato de possíveis reações graves.  
**Dermatite atópica associada à aeroalérgenos:** as manifestações clínicas de DA podem ser agravadas por aeroalérgenos. Pode ser importante para alguns pacientes identificarem gatilhos, como pólen, pelos de animais, surtos sazonais ou exacerbação  
8  
de lesões eczematosas após o contato com determinada substância<sup>33</sup> . Testes cutâneos ou dosagem de anticorpos IgE podem ser considerados para detectar sensibilização. O teste cutâneo de leitura imediata (TCLI) é um método para identificar anticorpos da classe IgE. Os TCLI pela técnica de puntura ( _prick test_ ) com aeroalérgenos e alérgenos alimentares são normalmente utilizados como testes de primeira linha na detecção de IgE relacionado ao envolvimento destes agentes no desencadeamento do sintoma, mas devem ser avaliados com precaução<sup>21</sup> .  
Diversas doenças de pele apresentam semelhança com a DA, sobretudo aquelas associadas à prurido e lesões eczematosas. Além das condições citadas acima, outros diagnósticos diferenciais incluem linfoma cutâneo de células T, dermatite herpetiforme, impetigo, líquen simples crônico, molusco contagioso, eczema numular, psoríase, escabiose, _Tinea corporis_ , urticária e exantema viral ( **Quadro 6** ).  
**Quadro 6 –** Diagnóstico diferencial de dermatite atópica.  
|**Diagnóstico**|**Morfologia**|**Idade**|**Etiologia**|**Outros fatores**|
|---|---|---|---|---|
|Dermatite de<br>contato|Vesículas eritematosas|Afeta todas as<br>idades|Reação de<br>hipersensibilidade|A erupção ocorre no local<br>da exposição|
|Linfoma<br>cutâneo de<br>células T|Morfologia variada: manchas<br>hipocrômicas, apenas prurido sem<br>lesão|Raro em<br>crianças|Desconhecida|Erupção cutânea se<br>desenvolve lentamente|
|Dermatite<br>herpetiforme|Pápulas urticadas e vesiculação|Raro em<br>crianças|Imunomediada|Associação com<br>sensibilidade ao glúten|
|Impetigo|Pústulas e crostas melicéricas|Comum em<br>crianças|Bacteriana|Muito contagiosa|
|Líquen<br>simples<br>crônico|Bem circunscrito, escamas grossas|Raro em<br>crianças|Prurido crônico|Pode ter associação com<br>estresse e ansiedade|
|Molusco<br>contagioso|Lesão típica é a pápula umbilicada<br>(pápulas avermelhadas em<br>aglomerados)|Comum em<br>crianças|Viral|Normalmente desaparece<br>dentro de meses|
|Eczema<br>numular|Eczema, eritema, vesículas<br>escamocrostas|Menos<br>frequente em<br>crianças|Desconhecida|Manchas podem durar<br>semanas a meses|
|Psoríase|Manchas eritematosas com escamas<br>prateadas|Raro em<br>crianças|Imunomediada|Pode ter acometimento<br>das unhas|
|Escabiose|Pápulas eritematosas lineares, podem<br>conter túneis|Afeta todas as<br>idades|Parasitária|Prurido intenso à noite,<br>pode acometer familiares|
|Dermatite<br>seborréica|Escamas amareladas e oleosas|Afeta todas as<br>idades|Desconhecida|Distribuição no couro<br>cabeludo e rosto|
|Tinea<br>corporis|Fundo eritematoso, placas anulares<br>com bordas circinadas|Comum em<br>crianças|Fúngica|Predomina nas dobras,<br>mas não é exclusivo|  
9  
|**Diagnóstico**|**Morfologia**|**Idade**|**Etiologia**|**Outros fatores**|
|---|---|---|---|---|
|Urticária|Pápulas eritematosas, infiltradas,<br>fugazes ou placas|Incomum em<br>crianças|Imunomediada|Geralmente resolve em 24<br>horas|
|Exantemas<br>virais|Máculas eritematosas difusas e<br>pápulas|Comum em<br>crianças|Viral|Resolve após a doença<br>viral envolvida|  
Fonte: Adaptado de _Frazier et al_ . (2020)<sup>19</sup>

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 4. **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo todos os indivíduos de ambos os sexos com diagnóstico de DA, definido por um dos seguintes instrumentos, conforme descrito no item Diagnóstico:  
- Critérios clássicos de Hanifin e Rajka: 3 ou mais critérios maiores **E** 3 ou mais critérios menores para diagnóstico de  
DA;

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **OU** -->
- Critérios do grupo de trabalho do Reino Unido: prurido nos últimos 12 meses em associação com 3 ou mais critérios  
- para diagnóstico de DA.  
Adicionalmente, devem ser observados os seguintes critérios para uso dos medicamentos:  
- ciclosporina ou metotrexato: o paciente de qualquer idade deverá apresentar doença moderada a  
- grave, evidenciada por uma das escalas de gravidade (Quadro 5);  
- dupilumabe: pacientes de 6 meses a <12 anos de idade com DA grave, evidenciada por uma das  
- escalas de gravidade (Quadro 5), que apresentem falha, intolerância ou contraindicação à ciclosporina ou ao metotrexato;  
- upadacitinibe: pacientes de 12 a <18 anos de idade, com peso corporal de pelo menos 40 kg, com DA  
- grave, evidenciada por uma das escalas de gravidade (Quadro 5), que apresente falha, intolerância ou contraindicação à ciclosporina ou ao metotrexato;  
- furoato de mometasona ou tacrolimo: pacientes acima de 2 anos de idade com qualquer gravidade de  
- DA (leve, moderada ou grave) evidenciada por uma das escalas de gravidade mostradas no Quadro 5.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 5. **CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação ao uso de algum medicamento preconizado por este Protocolo deverão ser excluídos do uso do respectivo medicamento.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 6. **TRATAMENTO** -->
O tratamento da DA segue uma abordagem variada e gradual, adaptada de acordo com a gravidade da doença e com as necessidades do paciente. O tratamento visa a reduzir sintomas, prevenir exacerbações, tratar infecções quando presentes, minimizar os riscos de tratamento e restaurar a integridade da pele.  
10  
Na maioria dos pacientes com doença leve, as metas de tratamento são alcançadas com o uso das terapias tópicas. Para casos moderados ou graves, o tratamento é desafiador e envolve também medicamentos de uso sistêmico, que variam de acordo com a faixa etária do paciente.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.1. Hidratantes e emolientes** -->
A pele seca é um dos sintomas característicos da dermatite atópica. O estrato córneo carente de lipídios intercelulares apresenta uma desproporção entre colesterol, ácidos graxos essenciais, ceramidas<sup>35</sup> . Isso aumenta a perda transepidérmica de água e acarreta pequenas fissuras da camada mais superficial da pele (epiderme). Essas fissuras resultam em inflamação. Para estes casos, a aplicação precoce e a longo prazo de emolientes melhora as condições da pele, reduz o prurido e outras manifestações da Dermatite Atópica<sup>36–40</sup> .  
Emolientes são formulações tópicas livres de ingredientes ativos. Podem conter umectante que hidrata o estrato córneo, como ureia ou glicerol e um ocludente que reduz a evaporação, como petrolato ou parafina. A escolha do emoliente deve ser individualizada e considerar a aceitabilidade e tolerância de cada paciente. Torna-se relevante destacar que o uso de emolientes pelo paciente com dermatite atópica deve ser contínuo e aplicado (espalhado e não esfregado) em toda a extensão corporal. Foi realizada uma revisão das evidências sobre a eficácia e segurança dos emolientes para prevenir e tratar dermatite atópica, contudo, dada as limitações e heterogeneidade, apenas recomenda-se a aplicação de emolientes, cremes de barreira ou soluções micelares na pele íntegra, por pelo menos duas vezes por semana para atrasar o desenvolvimento e melhorar as condições da pele dos pacientes com dermatite atópica de gravidade leve a moderada<sup>35,38,41</sup> . Inclusive, o uso diário de emolientes desde o nascimento pode reduzir a incidência de Dermatite Atópica em uma população de alto risco<sup>37</sup> .  
A hidratação da pele é um componente-chave para o tratamento de pacientes com dermatite atópica<sup>5</sup> . Para manter a hidratação da pele, os emolientes devem ser aplicados pelo menos duas vezes ao dia e imediatamente após o banho ou a lavagem das mãos. O tempo médio de ação de cada hidratante varia de 2 a 6 horas e a quantidade aplicada segue a faixa etária e superfície corporal ( **Quadro 7** ).  
**Quadro 7 -** Quantidade média de hidratante utilizada por semana conforme a faixa etária.  
||**Faixa-etária**|**Quantidade**|
|---|---|---|
|Recém-nascidos e bebês||100 g|
|Crianças||150 a 200 g|
|Adultos||250 g|  
Fonte: Adaptado de Kulthanan _et al_ . (2021)<sup>11</sup>  
Cremes mais espessos, com baixo teor de água, ou pomadas com zero teor de água são preferíveis, pois garantem melhor proteção contra a xerose, embora sejam considerados mais gordurosos pelos pacientes. As loções, embora menos eficazes do que cremes e pomadas espessos, podem ser uma alternativa para esses pacientes<sup>11,19,34</sup> . O agente ideal deve ser seguro, eficaz, barato e livre de aditivos, fragrâncias, perfumes e outras substâncias potencialmente sensibilizantes<sup>42</sup> .  
Na Relação Nacional de Medicamentos Essenciais (RENAME), estão incluídos o gel e o creme de babosa ( _Aloe vera (L.) Burm. f_ .).  
11

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.2. Banhos** -->
O banho pode ter diferentes efeitos na pele e a água, na temperatura adequada, pode promover a hidratação da pele e remover escamas, crostas, irritantes e alérgenos. Tomar banho diariamente não está associado à piora clínica. Os banhos podem ser curtos (5 a 10 minutos) e com temperatura da água entre 27 a 30°C (água morna), preferencialmente com sabonetes com pH fisiológico (levemente ácido). O pH elevado da pele dos pacientes com dermatite atópica favorece a colonização microbiana, permanência de proteases microbianas no leito das lesões e facilita a ruptura da barreira cutânea<sup>43</sup> .  
A aplicação de emolientes após a secagem da pele é recomendada para manter um bom estado de hidratação<sup>14,19,42</sup> . Não existe um consenso sobre a frequência dos banhos e se o uso de banheira ou chuveiro seria preferível em pacientes com DA<sup>42</sup> .  
Sabonetes com formulações antissépticas devem ser evitados, principalmente aqueles que contêm ingredientes alimentares (como proteína de trigo ou amido de arroz), visto que podem causar irritação e sensibilização da pele<sup>11</sup> . Alguns estudos sugerem benefícios do banho com hipoclorito de sódio diluído a 0,006% por 5 a 10 minutos, duas a três vezes na semana para minimizar a necessidade de uso de medicamentos anti-inflamatórios e antibióticos tópicos<sup>11,14</sup> , contudo esse tratamento adjuvante deve ser recomendado e monitorado por profissional de saúde habilitado<sup>11</sup>

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.3. Fototerapia** -->
Em pacientes com prurido difuso que não é controlado apenas com terapia tópica ou outras opções de tratamento falharam ou são inadequadas, a fototerapia pode ser uma opção terapêutica para pacientes que não estejam em uso de ciclosporina (contraindicado o uso concomitante)<sup>7</sup> . Pode incluir luz ultravioleta A (UVA) banda estreita, luz ultravioleta B (UVB), ou uma combinação de psoraleno em conjunto com UVA (PUVA)<sup>6,14</sup> . Espera-se que a fototerapia possa melhorar os sinais clínicos, reduzir o prurido e a colonização de bactérias, poupando o uso de esteroides. Um fator limitante para seu uso é a falta de adesão ao tratamento a longo prazo<sup>14</sup> . A PUVA e a UVB são contraindicadas em pacientes com xeroderma pigmentoso, albinismo e dermatoses fotossensíveis (como lúpus eritematoso sistêmico); história de melanoma ou múltiplos cânceres não melanóticos de pele<sup>14</sup> . Pacientes em uso de ciclosporina não devem receber simultaneamente irradiação ultravioleta B ou fotoquimioterapia PUVA<sup>44</sup> .  
A fototerapia está disponível no SUS para outras indicações, mas não foi avaliada para DA, assim não é preconizada neste Protocolo.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.4. Coberturas (bandagens)** -->
Algumas organizações americanas e a Sociedade Brasileira de Dermatologia relatam que as coberturas úmidas podem ser usadas para reduzir a gravidade da DA, principalmente em pacientes com doença moderada e grave<sup>14,19,42</sup> . A cobertura úmida pode aliviar a agudização da DA em lesões fechadas, na expectativa de que sua utilização ajude a oclusão do agente tópico, aumentando a penetração e diminuindo a perda de água, proporcionando uma barreira física contra arranhões<sup>14</sup> .  
Pacientes com DA são mais suscetíveis a infecções bacterianas, virais e fúngicas da pele, principalmente devido à função de barreira prejudicada, resposta imunológica comprometida e prurido.  Complicações causadas _Staphylococcus aureus_ e o vírus herpes simplex como foliculite, abscessos, eczema herpético são frequentes. Prevenir e limitar o desenvolvimento de infecções interrompendo o ciclo de prurido-arranhões e incentivando o uso contínuo de emolientes hidratantes em toda a extensão corporal são orientações importantes para o paciente e familiares.  
12  
Além do pH elevado da pele dos pacientes com dermatite atópica favorecer a colonização microbiana e a ruptura da barreira cutânea, o uso de imunossupressores tópicos ou sistêmicos usados para o tratamento da DA podem reduzir ainda mais a resposta imunológica dos pacientes<sup>43</sup> .  
Comumente o comprometimento da pele dos pacientes com dermatite atópica são parciais, ou seja, envolve apenas as primeiras camadas da pele (epiderme e derme). Na fase aguda, as lesões aparecem como manchas eritematosas com ou sem exsudação; bolhas e crostas. Na fase crônica as lesões se apresentam como descamação, fissuras (rachaduras) e liquenificação (espessamento e endurecimento da pele)<sup>45,46</sup> .  
Apesar de raro, quando ocorrem comprometimentos totais que envolvem camadas mais profundas da pele e outros tecidos, coberturas não medicamentosas podem ser empregadas para tratar feridas (infectadas ou não) dos pacientes de qualquer faixa etária. O uso de coberturas antimicrobianas (com prata, iodo, mel, biguanida e PHMB) não é aprovado para crianças e neonatos; se associam à resistência microbiana e podem induzir a reações de sensibilidade nos pacientes com DA<sup>47</sup> . Nesse sentido, para tratar lesões mais graves com ou sem infecção, antimicrobianos com corantes orgânicos (como violeta de genciana/azul de metileno) e os de ação mecânica (como o cloreto de dialquilcarbamoil) podem ser as melhores escolhas<sup>48–54</sup> .  
A gestão dessas possíveis lesões deve ser individualizada, considerando os valores e preferências do paciente para estabelecer o plano terapêutico. Inclusive, uma maneira de   incentivar a autonomia e incorporar as peculiaridades de cada caso no processo de cuidado é educar os pacientes, familiares e cuidadores sobre o controle do processo infeccioso a partir do reconhecimento de sinais e sintomas de infecção, como aparecimento de lesões que não respondem às terapias instituídas ou que pioram rapidamente, surgimento de bolhas com conteúdo purulento, febre e mal-estar geral<sup>46,55</sup> .

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.5. Terapia de reversão de hábitos** -->
O prurido intenso pode levar a comportamentos como coçar ou esfregar, que eventualmente se transformam em hábitos. Além dos emolientes e fototerapia<sup>12</sup> que podem reduzir a intensidade do prurido<sup>39,40</sup> , a terapia de reversão de hábitos é uma técnica comportamental usada para diminuir a frequência de comportamentos repetitivos, incluindo cinco componentes a serem exercitados: conscientização, relaxamento, resposta recorrente, apoio social e generalização. No entanto, esta técnica não está amplamente disponível nos serviços de saúde<sup>4</sup> .

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.1.6. Outros tratamentos não medicamentosos** -->
A DA tem efeito significativo na qualidade de vida dos pacientes e de seus familiares. Estresse e fatores emocionais podem exacerbar a doença. Insônia, ausência no trabalho e escola, isolamento social, depressão e ideação suicida podem estar presentes<sup>11,14</sup> . O aconselhamento psicossomático, psicoterapia, terapia comportamental e técnicas de relaxamento são recomendados durante o tratamento da DA<sup>11</sup> .  
A educação do paciente é um componente importante no gerenciamento da DA<sup>6</sup> . Pacientes e familiares podem se beneficiar da educação estruturada fornecida por enfermeiros ou equipes multidisciplinares. Os grupos de apoio formados durante essas reuniões são importantes para compartilhar experiências entre familiares e pacientes essa condição<sup>56</sup> .  
Outras medidas não medicamentosas incluem usar roupas macias (como, por exemplo, as feitas de algodão); evitar o uso de produtos feitos com lã; manter temperaturas amenas, principalmente à noite; utilizar umidificador no inverno e verão; lavar roupas com sabão suave, sem alvejante ou amaciante; e evitar alimentos específicos, em casos de alergia alimentar<sup>57</sup> .  
13

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.2. Tratamento medicamentoso** -->
O tratamento medicamentoso da DA inclui formulações tópicas e sistêmicas e suas indicações variam conforme a gravidade da doença e a idade do paciente. A primeira linha de tratamento engloba medicamentos tópicos (pomadas ou cremes), ciclosporina e metotrexato no caso de pacientes com DA moderada a grave.  
Mais recentemente, duas classes de medicamentos sistêmicos foram incluídas ao tratamento de DA: imunobiológicos (dupilumabe) e inibidores da Janus-quinase (upadacitinibe). Esses medicamentos são indicados para pacientes refratários as terapias de primeira linha<sup>1</sup> . Os critérios para a continuidade ou interrupção de medicamentos sistêmicos estão relacionados à avaliação da resposta terapêutica, considerada adequada ou inadequada, com base em escalas específicas, como EASI, SCORAD, POEM (Quadro 5) e de qualidade de vida. No caso dos imunossupressores sistêmicos, como ciclosporina e metotrexato, também devem ser avaliados o tempo de tratamento recomendado, a necessidade de sua continuidade e a ocorrência de eventos adversos.  
Já os medicamentos dupilumabe e ao upadacitinibe foram incorporados ao SUS, respectivamente, para o tratamento de crianças e adolescentes que apresentaram falha ao tratamento com ciclosporina ou metotrexato. Além desses medicamentos, outros três (mometasona, tacrolimo e metotrexato) foram incorporados ao SUS.  
Ressalta-se que mesmo havendo necessidade de iniciar tratamento com um dos novos medicamentos, todo arsenal terapêutico para DA incorporado no SUS fica disponível, respeitando-se as indicações e contraindicações de cada medicamento.  
As mudanças na terapia sistêmica devem ser feitas com base em tomadas de decisão e com cumprimento de metas para o tratamento, utilizando principalmente o Índice de Área e Gravidade do Eczema (EASI). Pelo consenso da Sociedade Brasileira de Dermatologia (SBD), os objetivos iniciais aceitáveis do tratamento de pacientes com DA devem atingir, pelo menos:  
 Após 3 meses: EASI-50 (redução 50% comparado com o valor basal); SCORAD-50; redução de pelo menos três pontos para o pico de prurido NRS (0-10); redução de pelo menos quatro pontos DLQI e; redução de pelo menos quatro pontos no POEM.  
 Após 6 meses: EASI-75 (redução de 75% comparado com o valor basal) ou EASI≤7; SCORAD-75 ou SCORAD≤24; pico de prurido NRS (0 a 10) com escore absoluto de ≤ 4; DLQI com escore absoluto de ≤5 e; pontuação absoluta no POEM de ≤ 7.  
Recomenda-se que, ao mudar para um novo tratamento sistêmico, mantenha-se a terapia com medicamentos tópicos até que o novo medicamento sistêmico seja totalmente eficaz ou usar a terapia tópica como adjuvante durante a terapia sistêmica em andamento<sup>58</sup> . Em pacientes que estão mudando para outra terapia sistêmica, recomenda-se um período de 1 a 2 meses de sobreposição em que o medicamento original tem sua dose reduzida enquanto o novo medicamento começa a fazer efeito<sup>58</sup> . Para efeitos do presente PCDT essa estratégia pode ser adotada na transição entre ciclosporina ou metotrexato para dupilumabe ou upadacitinibe.  
O **Quadro 8** apresenta as opções terapêuticas de acordo com características da doença e a população.  
**Quadro 8 –** Opções de tratamento medicamentoso (tópicos e sistêmicos) de acordo com a característica da dermatite atópica e população elegível.  
|**Medicamento**|**Característica da DA**|**População**|
|---|---|---|
|Dexametasona, Hidrocortisona|Sem restrição|Sem restrição|
|Furoato de mometasona|Sem restrição|Maiores de 2 anos|
|Tacrolimo*|Sem restrição|Maiores de 2 anos|  
14  
|**Medicamento**|**Característica da DA**|**População**|
|---|---|---|
|Ciclosporina|Moderada a grave|Sem restrição|
|Metotrexato|Moderada a grave|Sem restrição|
||Grave com falha, intolerância ou contraindicação à||
|Dupilumabe*|ciclosporina ou ao metotrexato e que possuem<br>indicação à terapia sistêmica|Crianças de 6 meses a < 12 anos|
||Grave com falha, intolerância ou contraindicação à||
|Upadacitinibe|ciclosporina ou ao metotrexato e que possuem<br>indicação à terapia sistêmica|Adolescentes de 12 a <18 anos|  
Fonte: Autoria própria, 2025. * Diferente dose a depender da idade e/ou peso corporal do paciente.  
O **Quadro 9** resume as opções terapêuticas para cada faixa etária dos pacientes, de acordo com a gravidade da dermatite atópica.  
**Quadro 9 –** Opções de tratamento medicamentoso (tópicos e sistêmicos) de acordo com faixa etária dos pacientes e gravidade da dermatite atópica.  
|**População**|**Gravidade da doença**|**Medicamento**|
|---|---|---|
||Leve|Dexametasona, Hidrocortisona,<br>Furoato de mometasona*<br>Tacrolimo*|
|Crianças||Dexametasona, Hidrocortisona,<br>Furoato de mometasona*|
||Moderada a grave|Tacrolimo*,<br>Ciclosporina,<br>Metotrexato|
|Crianças (6 meses a<br><12 anos)|Grave com falha, intolerância ou contraindicação à<br>ciclosporina ou metotrexato e que possuem indicação<br>à terapia sistêmica|Dexametasona, Hidrocortisona,<br>Furoato de mometasona*<br>Tacrolimo*,<br>Dupilumabe|
||Leve|Dexametasona, Hidrocortisona,<br>Furoato de mometasona*<br>Tacrolimo*|
|Adolescentes<br>(12 a <18 anos)|Moderada a grave|Dexametasona, Hidrocortisona,<br>Furoato de mometasona*<br>Tacrolimo*,<br>Ciclosporina,<br>Metotrexato|
||Grave com falha, intolerância ou contraindicação à<br>ciclosporina ou metotrexato e que possuem indicação|Dexametasona, Hidrocortisona,<br>Furoato de mometasona|
||à terapia sistêmica|Tacrolimo,|  
15  
|**População**|**Gravidade da doença**|**Medicamento**|
|---|---|---|
|||Upadacitinibe|
|||Dexametasona, Hidrocortisona,|
||Leve|Furoato de mometasona|
|||Tacrolimo|
|Adultos||Dexametasona, Hidrocortisona,<br>Furoato de mometasona|
||Moderada a grave|Tacrolimo,|
|||Ciclosporina,|
|||Metotrexato|  
Fonte: Autoria própria, 2025. * Acima de 2 anos  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.2.1. Medicamentos tópicos** -->
Os corticoides tópicos são usados como primeira linha de tratamento em adultos e crianças com DA, incluindo uso em surtos agudos e prurido<sup>11,19,34,42</sup> . A escolha do corticoide deve ser baseada na idade do paciente, área do corpo envolvida e no grau de inflamação da pele<sup>5,19,27</sup> .  
Os corticoides tópicos disponíveis no SUS são a dexametasona, o acetato de hidrocortisona e o furoato de momentasona. A dexametasona e o acetato de hidrocortisona são corticoides de baixa potência, enquanto o furoato de mometasona é classificado como de média potência quando em creme e alta potência quando em pomada.  Este último pode ser utilizado em crianças a partir de 2 anos de idade e em adultos<sup>59</sup> .  
Outros corticoides de diferentes potências são citados como opções na literatura, no entanto, como não estão disponíveis no Sistema Único de Saúde para o tratamento de DA, não são preconizados por este Protocolo.  
O tacrolimo é um inibidor da calcineurina agindo como imunossupressor. Em sua formulação tópica é uma opção de tratamento para crianças a partir de 2 anos de idade e para adultos que não possuem uma boa resposta ou são intolerantes aos tratamentos convencionais. Também pode ser utilizado na manutenção do tratamento de DA para prevenção de surtos dos sintomas e para prolongar os intervalos livres de surtos em pacientes que possuem alta frequência de exacerbação da doença (4 ou mais vezes por ano) que tiveram uma resposta inicial a um tratamento máximo de 6 semanas, 2 vezes ao dia<sup>5</sup> . Podem ser usados em áreas sensíveis como rosto, pescoço, áreas intertriginosas e genitais.  
16

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **Ciclosporina** -->
As aplicações terapêuticas da ciclosporina foram descobertas na década de 1970, quando começou a ser utilizada como imunossupressor das células T e da produção de interleucina. Desde então, novos benefícios clínicos foram identificados e sua utilização para DA foi relatada pela primeira vez em 1991<sup>60</sup> .  
Atualmente, a ciclosporina é comumente usada para tratamento de DA<sup>11,14</sup> . Em 2022, foi incorporada ao SUS para tratamento de pacientes com DA moderada a grave sem restrição de idade<sup>61</sup> . Em bula, consta que a experiência no uso de ciclosporina em crianças é limitada. No consenso da Sociedade Brasileira de Dermatologia não há contraindicação ao uso em crianças, desde que os pacientes sejam devidamente monitorados para eventos adversos<sup>1,44</sup> .  
A ciclosporina deve ser utilizada por 8 a 12 meses, mas seu uso poderá ser estendido por mais um ano caso seja bem tolerada. Recomenda-se redução da dose de ciclosporina em 0,5 a 1,0 mg/kg/dia a cada duas semanas até completa retirada do medicamento<sup>1</sup> . Após este período, caso haja necessidade de manter o tratamento com imunossupressor para controle da doença, recomenda-se que o paciente passe a utilizar metotrexato.  
A ciclosporina age como inibidor da calcineurina, que atua inibindo o citocromo P450 e a glicoproteína P. Como consequência, algumas citocinas inflamatórias não são sintetizadas, incluindo a interleucina 2 – essencial para ativação dos linfócitos T e sua diferenciação. Sua eficácia está relacionada à inibição específica e reversível de linfócitos imunocompetentes durante o ciclo celular<sup>60</sup> .  
O tratamento da DA com ciclosporina é considerado eficaz para a maioria dos pacientes, evidenciado por meio da diminuição da atividade da doença dentro de duas a seis semanas após o início do tratamento<sup>62</sup> .  
Há evidência de melhora clínica de pacientes com DA com o uso da ciclosporina, quando comparada à placebo, porém com preocupações quanto à qualidade dos estudos<sup>63,64</sup> . Em comparação ao dipropionato de betametasona e prednisolona, ambos da classe dos corticoides, não há diferença na melhora clínica com o uso de ciclosporina, porém a certeza da evidência é baixa ou muito baixa<sup>64</sup> .  
Em relação à segurança, o número de eventos adversos foi maior no grupo tratado com ciclosporina. Os eventos adversos mais frequentes relatados nos estudos incluídos foram: náusea, diarreia, hipertricose, dor de cabeça e hipertensão. Eventos adversos graves incluíram: dor abdominal; episódios únicos de dor de cabeça; parestesia; dor nas pernas e febre; rosto e pálpebras inchados; e dispneia. A maioria dos estudos incluídos na revisão sistemática relatou alterações laboratoriais de ureia ou creatinina (parâmetro para avaliação da função renal) nos pacientes em tratamento com ciclosporina. Diante disso, o tratamento com ciclosporina deve considerar cautela devido ao número elevado de eventos adversos relatados pelos ECRs avaliados<sup>64</sup> .  
De forma geral, diretrizes clínicas internacionais recomendam a utilização de ciclosporina para pacientes com dermatite atópica moderada a grave orientando-se prescrever a menor dose capaz de controlar a doença com o objetivo de minimizar a ocorrência de eventos adversos, com utilização recomendada por período de até 02 anos contínuos caso bem tolerada, preferencialmente não ultrapassando 8 a 12 meses de uso<sup>11,61,64</sup> . É indicado o monitoramento constante de pressão arterial e função renal durante o tratamento<sup>14</sup> .  
Devem ser considerados fatores como nefropatia, hipertensão e infecção durante a terapia com ciclosporina. A combinação de ciclosporina com fototerapia é contraindicada, e a proteção solar é fortemente recomendada durante o tratamento. A segurança desse medicamento durante a administração a longo prazo ainda não foi totalmente estabelecida. Assim, é importante a substituição da ciclosporina pelo tratamento tópico convencional após a melhora dos sintomas<sup>11,14</sup> .  
17  
Quanto ao uso da ciclosporina, deve-se atentar as possíveis interações medicamentosas, principalmente as relacionadas aos inibidores de protease.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **Metotrexato** -->
O metotrexato (ácido 4-amino-10-metil-fólico) é um antimetabólito análogo do ácido fólico. Ele é um imunossupressor que age inibindo a proliferação celular e a resposta inflamatória, o que pode ajudar a controlar os sintomas da DA. Tradicionalmente, o metotrexato é usado para doenças autoimunes e algumas condições neoplásicas, mas tem mostrado eficácia em casos de DA moderada a grave, que não respondem bem a outras terapias<sup>65</sup> .  
Os estudos que compararam o uso de ciclosporina com metotrexato sugerem que ambos apresentam resultados próximos para melhora clínica e qualidade de vida. Em crianças, adolescentes e adultos, a melhora clínica foi maior nas semanas iniciais com a ciclosporina<sup>66,67</sup> . A fase de seguimento dos estudos indicou que o metotrexato consegue sustentar melhor o controle da doença, principalmente em crianças e adolescentes<sup>66</sup> .  
Metotrexato e ciclosporina apresentaram melhora semelhante na qualidade de vida para crianças e adolescentes e adultos, mas apenas um estudo avaliou este desfecho em cada população<sup>66,68</sup> .  
Em relação à segurança, os resultados obtidos não demonstraram diferença estatisticamente significativa entre os tratamentos, tanto em relação eventos adversos gerais quanto para eventos adversos graves<sup>66–68</sup> . Os principais eventos adversos do metotrexato descritos em bula são estomatite (inflamação da mucosa da boca) ulcerativa, leucopenia (redução de células de defesa no sangue), náusea (enjoo) e desconforto abdominal.  Também são eventos adversos relatados com frequência indisposição, fadiga indevida, calafrios e febre, tonturas e resistência reduzida à infecção<sup>69</sup> .  
Não consta em bula a indicação de metotrexato para DA, porém sua utilização está bem documentada na literatura e prevista em diretrizes da Sociedade Brasileira de Dermatologia (SBD)<sup>1</sup> , bem como nas diretrizes das academias americana<sup>2</sup> e europeia<sup>3</sup> de dermatologia.  
A terapia com metotrexato foi incorporada ao SUS para tratamento de dermatite atópica moderada a grave. Ressalta-se que, mesmo havendo necessidade de iniciar terapia com o metotrexato, os medicamentos tópicos permanecem disponíveis para o tratamento dos pacientes, respeitando-se as indicações e contraindicações de cada medicamento.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **Dupilumabe** -->
O dupilumabe é um anticorpo monoclonal humano recombinante do tipo IgG4 que inibe a sinalização da interleucina-4 e da interleucina-13 ligando-se à subunidade IL-4Rα compartilhada pelos complexos de receptores IL4 e IL- 13<sup>32</sup> .  
Quando comparado com placebo, o uso de dupilumabe promoveu melhora dos sinais clínicos da DA, do prurido e da qualidade de vida. Dois ensaios clínicos randomizados apontaram que a proporção de pacientes que atingiram EASI-50, EASI75 e EASI-90 foi maior no grupo de crianças que receberam dupilumabe em relação ao placebo em 16 semanas de tratamento<sup>70,71</sup> . O grupo que recebeu dupilumabe também apresentou redução do prurido substancialmente maior, com melhora maior ou igual a 4 pontos, avaliado pela escala WSI-NRS<sup>71</sup> . A qualidade de vida, avaliada pela escala CDLQI, apresentou melhora maior no grupo que utilizou dupilumabe<sup>70,71</sup> . O uso de dupilumabe se mostrou seguro em ambos os estudos. Em um deles a incidência geral de eventos adversos emergentes do tratamento (EAET) foi semelhante entre os pacientes que usaram dupilumabe e os pacientes que usaram placebo<sup>71</sup> . No outro estudo, a incidência de EAET foi menor no grupo que utilizou dupilumabe do que no grupo placebo<sup>70</sup> .  
18  
Os eventos adversos mais comuns relatados em bula são reações no local da injeção, que incluem vermelhidão, edema (inchaço), prurido (coceira e/ou ardência), dor e inchaço, conjuntivite, dor nas articulações, herpes oral e eosinofilia (aumento dos glóbulos brancos)<sup>72</sup> . Conjuntivite é o evento adverso mais comum presente em mais de 30% dos casos, sendo na maioria de grau leve ou moderado, sem haver necessidade de suspensão do tratamento, e facilmente manejável com colírios antiinflamatórios tópicos<sup>1</sup> .  
A terapia com dupilumabe foi incorporada ao SUS para o tratamento de crianças de 6 meses a menores de 12 anos de idade com diagnóstico de DA grave que apresentam falha, intolerância ou contraindicação à ciclosporina ou metotrexato e que possuem indicação à terapia sistêmica<sup>73</sup> . Embora seu uso também seja indicado para adolescentes e adultos, a Conitec recomendou sua não incorporação ao SUS para estas populações devido ao alto impacto orçamentário<sup>1,74</sup> . Ressalta-se que, mesmo havendo necessidade de iniciar terapia com o dupilumabe, todo arsenal terapêutico para DA incorporado no SUS fica disponível, respeitando-se as indicações e contraindicações de cada medicamento.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **Upadacitinibe** -->
O upadacitinibe é um inibidor seletivo e reversível da enzima _Janus Quinase_ tipo 1 (JAK1). A inibição da atividade enzimática da JAK1 resulta em redução da inflamação<sup>1</sup> .  
Quando comparado com placebo, o uso de upadacitinibe promoveu melhora dos sinais clínicos da DA e do prurido. Em adolescentes tratados até 16 semanas a proporção de pacientes que apresentaram melhora na pontuação nas escalas EASI-75 e EASI-90 foi maior no grupo tratado com upadacitinibe<sup>75</sup> . Ainda, a melhora foi maior nos pacientes que usaram uma dose de 30 mg/dia comparado ao uso de 15 mg/dia, porém para adolescentes, apenas a dose de 15 mg está aprovada em bula da Anvisa<sup>76</sup> .  
O grupo que recebeu upadacitinibe também apresentou maior redução do prurido em relação ao grupo placebo, com melhora maior ou igual a 4 pontos, avaliado pela escala WSI-NRS<sup>75</sup> . Em relação à qualidade de vida, quando pacientes adultos e adolescentes foram avaliados, houve melhora maior ou igual a 4 pontos, avaliada pela escala DLQI<sup>77,78</sup> .  
O perfil de segurança do upadacitinibe varia conforme a dose, sendo que o tratamento com a dose maior (30 mg) resulta em eventos adversos mais frequentes do que o tratamento com a dose de 15 mg<sup>77,79</sup> . Os estudos que avaliaram eventos adversos do upadacitinibe 15 mg comparado com placebo em adolescentes encontraram que não houve diferença no desenvolvimento de eventos adversos graves<sup>77</sup> . Em relação aos eventos adversos não graves, os resultados variam entre não haver diferença e maior número de eventos adversos no grupo que usou upadacitinibe quando comparado com o placebo<sup>77,79,80</sup> .  
Em nenhum dos estudos houve óbitos ou descontinuação do tratamento em razão de eventos adversos. Com isso, o perfil de segurança de upadacitinibe em adolescentes é aceitável. Os eventos adversos mais comuns relatados em bula são infecção do trato respiratório superior, neutropenia, hipercolesterolemia, hipertrigliceridemia, tosse, pirexia e náusea<sup>76</sup> .  
A terapia com upadacitinibe foi incorporada ao SUS para o tratamento de adolescentes de 12 anos a menores de 18 anos de idade, com peso corporal de pelo menos 40 kg, com diagnóstico de DA grave que apresentam falha, intolerância ou contraindicação à ciclosporina ou metotrexato e que possuem indicação à terapia sistêmica<sup>73</sup> . O upadacitinibe não foi estudado em adolescentes com peso corporal menor que 40 kg ou em crianças menores de 12 anos de idade<sup>76</sup> . Embora seu uso também seja indicado para adultos, a Conitec recomendou sua não incorporação ao SUS para esta população devido ao alto impacto orçamentário<sup>1,74</sup> . Ressalta-se que mesmo havendo necessidade de iniciar terapia com o upadacitinibe, todo arsenal terapêutico para DA incorporado no SUS fica disponível, respeitando-se as indicações e contraindicações de cada medicamento.  
19  
O tratamento não deve ser iniciado em pacientes com contagem absoluta de linfócitos (CAL) menor que 500 células/mm<sup>3</sup> , contagem absoluta de neutrófilos (CAN) menor que 1000 células/mm<sup>3</sup> ou que possuam níveis de hemoglobina menores que 8 g/dL. Pode ser usado em associação com corticosteroides tópicos.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.3.1. Gestantes** -->
Os corticosteroides contemplados neste PCDT (dexametasona, acetato de hidrocortisona e furoato de mometasona) estão classificados na categoria C de risco na gravidez<sup>81–83</sup> . Isso indica que estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos. De maneira geral, dados sobre o uso de glicocorticoides tópicos durante a gravidez são insuficientes, com isso, corticoides tópicos não devem ser utilizados durante o primeiro trimestre de gravidez.  
Os corticosteroides tópicos só devem ser usados durante a gestação se o possível benefício justificar o risco potencial para o feto, mãe ou recém-nascido. Deve-se evitar o uso prolongado ou em área extensa. Estes medicamentos não devem ser utilizados por mulheres grávidas sem orientação médica ou do cirurgião-dentista.  
O tacrolimo tópico pertence à categoria C de risco na gravidez. Portanto, assim como os corticosteroides ele não deve ser utilizado por mulheres grávidas sem orientação médica ou do cirurgião-dentista<sup>84</sup> .  
A ciclosporina também pertence à categoria C de risco na gravidez. Inexistem evidências que demonstrem teratogenicidade, porém seu uso deve ser restrito a casos em que os benefícios superem os riscos e a contracepção é recomendada para mulheres em idade fértil que estejam em uso deste medicamento<sup>64</sup> . É consenso da Sociedade Brasileira de Dermatologia que o uso de ciclosporina em gestantes é permitido, com risco de baixo peso ao nascer<sup>1</sup> .  
O metotrexato é classificado na categoria X de risco de gravidez, portanto este medicamento não deve ser utilizado por mulher grávidas ou que possam ficar grávidas durante o tratamento<sup>69</sup> .  
O dupilumabe pertence à categoria B de risco na gravidez (não deve ser utilizado por mulheres grávidas sem orientação médica)<sup>76</sup> . Upadacitinibe é contraindicado durante a gravidez<sup>76</sup> . Ambos não foram incorporados para uso em população adulta com DA.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.3.2. Lactantes e Lactentes** -->
Deve-se decidir entre descontinuar a amamentação ou descontinuar o tratamento com corticosteroides, levando-se em consideração a importância do tratamento para a mãe. Deve-se evitar o uso prolongado ou em área extensa. Ainda, lactantes não devem utilizar o produto nas mamas<sup>82,83</sup> .  
Não existem dados adequados para o uso de tacrolimo pomada em lactantes. Dados com humanos demonstraram que, após administração sistêmica, tacrolimo é excretado no leite materno. Com isso, mulheres que estão amamentando não devem utilizar tacrolimo sem orientação médica ou do cirigião-dentista.<sup>84</sup>  
A ciclosporina pode causar eventos adversos graves em recém-nascidos/crianças lactentes. Deve-se decidir pela interrupção da amamentação ou do uso do medicamento, considerando o risco-benefício ao tratamento da mãe<sup>44</sup> . Deve-se considerar que há risco de imunossupressão do lactente.  
O uso de metotrexato é contraindicado durante a lactação<sup>69</sup> .  
20

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.3.3. Idosos** -->
Segundo a bula, inexistem estudos específicos sobre o uso de tacrolimo por pacientes idosos. A experiência clínica disponível nesta população de pacientes não demonstrou necessidade de qualquer ajuste de dose<sup>84</sup> .  
Pacientes idosos somente devem ser tratados com a ciclosporina na presença de dermatite atópica incapacitante. Como precaução adicional, a função renal deve ser monitorada com cuidado especial<sup>44</sup> .  
O uso de metotrexato não foi amplamente estudado em idosos. Devido à redução da função hepática e renal, bem como aos menores estoques de folatos nessa população, recomenda-se considerar doses relativamente baixas e realizar monitoramento rigoroso para identificar precocemente sinais de toxicidade. Pacientes idosos em uso de metotrexato devem ser esclarecidos que a dose recomendada é administrada semanalmente para evitar toxicidade<sup>69</sup> .  
Para o acetato de hidrocortisona não foram realizadas investigações especiais em indivíduos idosos<sup>82</sup> .  
Após avaliação da Conitec, os medicamentos dupilumabe e upadacitinibe não foram incorporados ao SUS para tratamento de adultos ou idosos com DA (Portaria SECTICS/MS nº 53/2025). Assim, este Protocolo não preconiza o uso dos medicamentos nessa população.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.4. Medicamentos** -->
- Acetato de hidrocortisona: creme de 10 mg/g  
- Ciclosporina cápsulas de 25 mg, 50 mg e 100 mg; solução oral de 100 mg/mL;  
- Dexametasona: creme de 1 mg/g  
- Dupilumabe: solução injetável de 200 mg ou 300 mg;  
- Furoato de mometasona: creme ou pomada de 1 mg/g  
- Metotrexato: comprimido de 2,5 mg, solução injetável de 25 mg/mL;  
- Tacrolimo: pomada de 0,3 mg/g ou 1 mg/g;  
- Upadacitinibe: comprimidos revestidos de liberação prolongada de 15 mg.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.5. Esquemas de administração** -->
- Acetato de hidrocortisona: aplicar uma camada fina do creme, 2 a 3 vezes por dia, sob ligeira fricção; após melhora do quadro clínico, uma aplicação por dia é suficiente na maioria dos casos. Em lactentes e crianças abaixo de 4 anos, o tratamento não deve prolongar-se por mais de 3 semanas, especialmente nas zonas cobertas por fraldas.  
- Ciclosporina – via oral: O esquema terapêutico com a ciclosporina varia de acordo com o curso da doença. Durante a fase aguda, a terapia é voltada especialmente para a remissão dos sintomas, enquanto na fase de manutenção o principal objetivo é minimizar as chances de recorrência das manifestações cutâneas. O tratamento dos episódios agudos, tanto em pacientes adultos quanto pediátricos, é realizado pela administração oral de 3 a 5 mg/kg/dia, dividida em duas doses diárias (manhã e noite). Após seis semanas, durante a fase de manutenção, a dose diária é reduzida a 2,5 a 3 mg/kg/dia. Sugere-se que doses iniciais mais altas possam resultar em um controle mais rápido da doença e na redução da área de superfície corporal envolvida, além de melhorar a qualidade de vida do paciente. Apesar disso, é preconizado que a dose inicial prescrita seja baseada em diversos fatores, como gravidade da doença e outras morbidades identificadas. Ao todo, as terapias de curto e longo prazo podem ser úteis e a duração do tratamento varia entre três meses e um ano<sup>64</sup> . Preferencialmente, seu uso deve ser restrito a 8 a 12 meses, não sendo recomendado por período superior a dois anos contínuos<sup>11,60,64</sup> . A prescrição da menor dose clinicamente útil considerando o tratamento a longo prazo pode ser aconselhável em alguns casos e, para redução de dose, aconselha-se considerar a eficácia  
21  
clínica do tratamento<sup>3</sup> . A associação do tratamento com ciclosporina e terapia ultravioleta (UV) não é recomendada, enquanto a proteção UV é altamente indicada<sup>3,11</sup> .  
- Dexametasona creme: uma a três aplicações diárias do creme por períodos inferiores a 30 dias; na fase de manutenção, aplicar o creme 2 vezes/semana.  
- Dupilumabe: administrado por via subcutânea pelo paciente, por um profissional de saúde ou por um cuidador. Antes da administração, deve ser inspecionado visualmente para verificar a presença de partículas ou alterações de coloração. Se a solução estiver descolorida ou contiver partículas visíveis, não deve ser utilizada. Recomenda-se que o local da injeção seja rotativo para cada injeção. O medicamento não deve ser injetado em áreas sensíveis, machucadas ou que tenham hematomas ou cicatrizes. Dose deve ser definida conforme peso corporal e idade:

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: <u>Pacientes de 6 meses a 5 anos de idade:</u> -->
5 kg até menos de 15 kg: dose inicial de 200 mg (1 injeção de 200mg), seguida de 200 mg a cada quatro semanas. 15 kg até menos de 30 kg: dose inicial de 300 mg (1 injeção de 300mg), seguida de 300 mg a cada quatro semanas.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: <u>Pacientes de 6 anos a menores de 12 anos de idade:</u> -->
15 kg até menos de 30 kg: dose inicial de 600 mg (2 injeções de 300 mg), seguida de 300 mg a cada quatro semanas.  
30 kg até menos de 60 kg: dose inicial de 400 mg (2 injeções de 200 mg), seguida de 200 mg a cada duas semanas.  
60 kg ou mais: dose inicial de 600 mg (2 injeções de 300 mg), seguida de 300 mg a cada duas semanas.  
- Furoato de mometasona: aplicar uma camada fina de creme ou pomada que deverá cobrir toda a área afetada, 1 vez por dia. Antes do uso, bata levemente a bisnaga em superfície plana com a tampa virada para cima, para que o conteúdo do produto esteja na parte inferior da bisnaga e não ocorra desperdício ao se retirar a tampa. Indica-se a não realização de curativos sobre a aplicação (curativos oclusivos), a não ser por indicação médica.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: - Metotrexato: -->
Pacientes de 2 a 16 anos: 0,4 mg a 0,6 mg/kg/semana (ou 10 a 15 mg/m²/semana), por via oral ou injetável., conforme especificado em bula.  
Pacientes a partir dos 16 anos: 15 mg a 25 mg/semana, por via oral ou injetável.  
Recomenda-se a suplementação de ácido fólico por via oral, para minimizar possíveis eventos adversos da administração de metotrexato. A maior parte das diretrizes não recomendem uma dose para suplementação de ácido fólico nesses casos. Uma revisão sistemática identificou recomendações de suplementação com ácido fólico de 5 mg/semana no dia seguinte à administração do metotrexato ou 5 mg/dia, exceto no dia de uso do metotrexato, para adultos; e de 400 µg/semana para crianças<sup>85</sup> .

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: - Tacrolimo: -->
Entre 2 e 15 anos: O tratamento com o tacrolimo 0,3 mg/g deve ser iniciado, com a aplicação duas vezes ao dia por até três semanas. Após esse período, a frequência de aplicação deve ser reduzida para uma vez ao dia até o desaparecimento da lesão. Como tratamento de manutenção, o tacrolimo 0,3 mg/g deve ser aplicado uma vez ao dia, duas vezes por semana nas áreas  
22  
comumente afetadas pela dermatite atópica para prevenir a progressão da lesão para surtos. Entre as aplicações, deve haver um período de 2 a 3 dias sem tratamento com o tacrolimo.  
A partir dos 16 anos: O tratamento deve ser iniciado com tacrolimo 1 mg/g, aplicado duas vezes ao dia e deve continuar até o desaparecimento da lesão. Caso os sintomas reapareçam, deve-se reiniciar o tratamento com tacrolimo 1 mg/g, aplicado duas vezes ao dia. Se as condições clínicas do paciente permitirem, deve-se tentar reduzir a frequência de aplicação ou utilizar tacrolimo 0,3mg/g. A manutenção deve ser realizada pela aplicação de com o tacrolimo 0,3 mg/g ou 1 mg/g uma vez ao dia, duas vezes por semana, nas áreas comumente afetadas pela dermatite atópica para prevenir a progressão da lesão para surtos. Entre as aplicações, deve haver um período de 2 a 3 dias sem tratamento com o tacrolimo. Se um sinal de surto ocorrer, o tratamento deve ser reiniciado com a aplicação duas vezes ao dia.  
- Upadacitinibe: o tratamento é realizado com 15 mg/dia, por via oral, nos pacientes entre 12 e <18 anos com peso corporal de, no mínimo, 40 kg. Deve ser ingerido com ou sem alimento, inteiro, com água, aproximadamente no mesmo horário todos os dias. O ideal é que não seja partido, aberto ou mastigado.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.6. Contraindicações** -->
As contraindicações para cada um dos medicamentos preconizados por este Protocolo são descritas abaixo.  
Dexametasona: tuberculose da pele, varicelas, infecção por fungo ou herpes simples.  
Acetato de hidrocortisona: processos tuberculosos ou sifilíticos na área a ser tratada, doenças causadas por vírus (por exemplo, varicela e herpes zoster), rosácea, dermatite perioral e reações após aplicação de vacinas na área a ser tratada.  
Furoato de mometasona: pessoas sensíveis ao furoato de mometasona, a outros corticoides e menores de dois anos. Tacrolimo: hipersensibilidade aos macrolídeos em geral e menores de dois anos.  
Ciclosporina: insuficiência renal crônica, neoplasia em atividade, lactação, infecção aguda ou crônica ativa, tuberculose sem tratamento, hipertensão não controlada, hipersensibilidade ao medicamento e o uso simultâneo de fototerapia e vacinas de vírus atenuados<sup>1,44</sup> . Adicionalmente, o medicamento deve ser utilizado com cautela, conforme avaliação clínica do médico, em pacientes vivendo com HIV, HCV, HBV e HPV.  
Metotrexato: aleitamento, insuficiência renal grave, insuficiência hepática grave, abuso de álcool, infecções graves, agudas ou crônicas (tuberculose, HIV e outras síndromes de imunodeficiência), úlceras da cavidade oral e doenças ulcerosa gastrointestinal ativa, discrasias sanguíneas pré-existentes (hipoplasia da medula óssea, leucopenia, trombocitopenia ou anemia significativa, vacinação concomitante com vacinas vivas.  
Dupilumabe: é contraindicado em pacientes com hipersensibilidade conhecida ao dupilumabe ou a qualquer excipiente. Vacinas com vírus vivo não devem ser administradas concomitantemente com dupilumabe<sup>72</sup> .  
Upadacitinibe: contraindicado para pacientes com insuficiência hepática grave; hipersensibilidade ao upadacitinibe (substância ativa) ou aos excipientes da fórmula (celulose microcristalina, hipromelose, manitol, ácido tartárico, dióxido de silício, estearato de magnésio e Opadry II [álcool polivinílico, macrogol 3350, talco, dióxido de titânio, óxido de ferro preto e óxido de ferro vermelho]); pacientes com tuberculose ativa ou infecções graves ativas. Conforme a bula do medicamento, recomenda-se não combinar o uso de upadacitinibe com outros potentes imunossupressores como azatioprina, ciclosporina, tacrolimo e medicamentos modificadores do curso da doença (MMCD) biológicos, uma vez que a combinação não foi avaliada por estudos clínicos<sup>76</sup> .  
23

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.7. Critérios de interrupção** -->
A literatura científica sobre os critérios de interrupção para os tratamentos de DA disponíveis é limitada. Seguem os critérios de interrupção previstos em bula para cada medicamento:  
Ciclosporina: se o paciente apresentar redução da função renal, deve reduzir a dose de ciclosporina por um mês. Após esse período, caso não haja melhora da função renal, o tratamento deve ser interrompido. Além disso, deve-se interromper o tratamento com ciclosporina caso o paciente desenvolva hipertensão que não pode ser controlada com terapia anti-hipertensiva apropriada<sup>44</sup> .  
Metotrexato: como o uso do medicamento pode exacerbar doença pulmonar adjacente, se o paciente apresentar sintomas pulmonares pode haver necessidade de interromper o tratamento com metotrexato. O tratamento com metotrexato também pode ser interrompido caso o paciente apresente sintomas como diarreia e estomatite ulcerativa<sup>69</sup> . Se houver anormalidade persistente ou significativa na função hepática ou em testes para investigação de fibrose hepática ou biópsia hepática, a terapia com metotrexato deve ser interrompida<sup>69</sup> .  
Upadacitinibe: pode ser necessário interromper temporariamente o tratamento caso o paciente tenha contagem absoluta de neutrófilos menor que 1000 células/mm³ ou contagem absoluta de linfócitos menor que 500 células/mm³ ou se a hemogloblina for menor que 8 g/dL ou se houver suspeita de lesão hepática induzida por medicamento<sup>76</sup> . Deve-se considerar a interrupção do tratamento com upadacitinibe caso o paciente não demonstre evidência de benefício terapêutico após 12 semanas de tratamento. Considerando a recomendação da Conitec, os pacientes devem interromper o tratamento ao completar 18 anos.  
Dupilumabe: considerando a recomendação da Conitec, os pacientes devem interromper o tratamento ao completar 12 anos.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **6.8. Fluxo de tratamento** -->
A **Figura 1** descreve o fluxograma de tratamento da dermatite atópica, conforme a gravidade da doença e a idade dos pacientes. Os cuidados com hidratação e estilo de vida, bem como aqueles relacionados ao controle de outras condições que podem agravar a DA, como dermatite de contato alérgica ou irritante, dermatite atópica associada à alergia alimentar e associada à aeroalérgenos, devem ser seguidos independentemente da gravidade da doença ou idade do paciente.  
24  
<!-- Start of picture text -->
Figura  1 -  Fluxograma  de  tratamento  para  dermatite  atópica  de  acordo  com  a  gravidade  da  doença  e  idade  do  paciente.<br><!-- End of picture text -->  
<!-- Start of picture text -->
Pacientes com diagnéstico de Dermatite Atopica<br>Avaliacdo da gravidade da doenca<br>=a = ea<br>Medicamentos topicos Medicamentos topicos + Medicamentos topicos +<br>(Gexametasona, hidrocortisona, sistémico (ciclosporina ou sistémico (ciclosporina ou<br>furoato de mometasona, tacrolimo) metotrexato") metotrexato")<br>sim Nao | Monitorar o paciente e<br>‘tetenpeespoobesigelaS,peneme 8 eeeaeoH terapéutica?Houve falha conforme‘doenca,reavaliar se a 0gravidade tratamento necessério da_<br>Considerar idade do paciente<br>Para definir tratamento<br>(6 meses‘Criancas:a <12 anos, (12.a<17Adolescenteano s ) (18 an‘Adultou o s mais)s<br><!-- End of picture text -->  
<!-- Start of picture text -->
Medicamentos topicos + ‘Medicamentos topicos + fe ee©<br>dupilumabe upadacitinibe )<br>Monitorar 0 paciente e reavaliar 0<br>tratamento conforme a gravidade da<br>doenca, se necessario<br>itedugdo" A ciclosporinada dosedevede ciclosporinaser utilizada empor0,58 aa 121,0 meses,mg/kg/dia no sendoa cada recomendadoduas semanas poraté periodocompletada superiorretiradaa doisdo anosmedicamento. continuos. ApdsRecomenda-seeste periodo,<br>\caso haja necessidade de manter o tratamento com imunossupressor para controle da doenca, recomenda-se que o paciente passe a utilizar<br>Imetotrexato.<br><!-- End of picture text -->  
25

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 7. **MONITORAMENTO** -->
Alguns medicamentos recomendados para o tratamento da DA podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) previamente ao início do tratamento.  
Antes do início do uso de MMCD biológicos, como dupilumabe e upadacitinibe, com objetivo de realizar o planejamento terapêutico adequado, deve-se pesquisar a ocorrência de TB ativa e ILTB. Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados para investigar a presença de ILTB, como radiografia simples de tórax, a prova tuberculínica (PT com o _purified protein derivative_ – PPD) ou o IGRA ( _Interferon-Gamma Release assays_ ), que podem ser solicitados para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desses exames.  
O tratamento da ILTB é indicado para pacientes com PT ≥ 5 mm ou IGRA reagente. Proceder também com o tratamento da ILTB, sem necessidade de realizar o IGRA ou a PT quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar. Os esquemas de tratamento da TB ativam e da ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomendase o início do uso de MMCD após 1 mês do início do tratamento de ILTB ou concomitantemente ao tratamento da TB ativa.  
Para fins de acompanhamento, considera-se desnecessário repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
Não há necessidade de repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição (novo contato).  
Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente recomenda-se repetir a PT ou IGRA anualmente, especialmente locais com alta carga de tuberculose. Não há necessidade de repetir a radiografia simples de tórax, caso não haja suspeita clínica de TB, exceto no caso PT ≥ 5 mm ou IGRA reagente nessa avaliação anual. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir em uma nova amostra. Cabe destacar que essa avaliação deva ser a rotina no seguimento da doença de base. A dispensação dos medicamentos para a doença de base não deve ser condicionada à realização dos exames para acompanhamento.  
Os principais eventos adversos e medidas de monitoramento existentes para cada medicamento são:  
- dexametasona creme: quando prescrito corticoide tópico, deve-se reavaliar o paciente e ajustar as doses entre uma a duas semanas para discutir o gerenciamento a longo prazo<sup>4</sup> . Os locais de aplicação devem ser avaliados regularmente para verificar a ocorrência de eventos adversos, principalmente com o uso de agentes potentes. Pacientes em uso de corticoide tópico devem ser monitorados por meio de exame físico para eventos cutâneos<sup>42</sup> . Os eventos adversos associados ao uso de corticoides incluem atrofia da pele, dermatite perioral, supressão adrenal, acne rosácea e o desenvolvimento de estrias. Após a cura das lesões, os pacientes devem diminuir o uso desses medicamentos para a cada dois dias antes de iniciar a terapia de manutenção<sup>11,19,42</sup> .  
- acetato de hidrocortisona: a resposta inicial ocorre em 7 dias. Os fatores que aumentam a absorção percutânea incluem o grau de inflamação da pele, uso oclusivo, tipo de veículo e concentração do produto. Em relação aos eventos adversos, sintomas  
26  
locais como prurido, ardor, eritema ou vesiculação podem ocorrer em casos isolados durante o tratamento com acetato de hidrocortisona. Quando preparações tópicas contendo corticoide são utilizadas em áreas extensas do corpo (aproximadamente 10% ou mais) ou por períodos prolongados (mais de 4 semanas), bem como em caso de curativos oclusivos ou de regiões naturalmente úmidas e ocluídas, podem ocorrer sintomas locais, tais como atrofia da pele, telangiectasia, estrias, alterações cutâneas acneiformes e efeitos sistêmicos do corticoide devido à absorção. Em casos raros, podem ocorrer foliculite, hipertricose, dermatite perioral e reações alérgicas cutâneas a qualquer um dos componentes do produto. Recém-nascidos podem apresentar eventos adversos como redução da função adrenocortical, quando houver uso do medicamento pela mãe nas últimas semanas de gravidez<sup>82</sup> .  
- furoato de mometasona: os pacientes pediátricos poderão demonstrar maior suscetibilidade à supressão do eixo hipotálamo-hipófise-adrenal e síndrome de Cushing induzidas por corticosteroides tópicos do que pacientes adultos, em decorrência da relação entre a área de superfície da pele e o peso corporal. O uso de corticosteroides tópicos em crianças deve ser limitado à mínima dose compatível com um regime terapêutico efetivo. O tratamento crônico com corticosteroides pode interferir no crescimento e desenvolvimento das crianças. O furoato de mometasona deve ser suspenso em caso de irritação ou sensibilização com o uso. Em caso de infecção dermatológica, deverá ser instituído o uso de um agente antimicótico ou antibiótico apropriado. Se uma resposta favorável não ocorrer rapidamente, o corticosteroide deve ser suspenso até que a infecção seja controlada adequadamente<sup>83</sup> .  
- tacrolimo: o tacrolimo não deve ser utilizado em pacientes com imunodeficiência congênita ou adquirida ou em pacientes fazendo uso de medicamentos que causem imunossupressão. O efeito do tratamento de tacrolimo pomada no sistema imune desenvolvido de crianças, especialmente as mais novas, ainda não foi estabelecido e isto deve ser levado em conta quando da prescrição para pacientes neste grupo de idade. A exposição da pele a luz do sol deve ser minimizada e o uso de luz ultravioleta (UV) provenientes de um solário, terapia com UVB e UVA em combinação com psoralens (PUVA), deve ser evitada durante o uso de tacrolimo pomada. Os pacientes devem ser aconselhados a utilizarem métodos de proteção solar apropriados. O tacrolimo pomada não deve ser aplicado em lesões que sejam consideradas como potencialmente malignas ou pré-malignas. Emolientes não devem ser aplicados na mesma área antes de duas horas após a aplicação de tacrolimo pomada<sup>84</sup> .  
- ciclosporina: a duração da terapia pode ser orientada pela eficácia e pela tolerância do paciente ao tratamento<sup>3</sup> . No início e após as primeiras quatro semanas de tratamento, deve-se solicitar hemograma completo e exames laboratoriais para avaliação das funções hepática e renal. Deve-se repetir essa avaliação a cada três meses durante o tratamento com ciclosporina. Recomendase também a investigação de Hepatites B e C e HIV<sup>1</sup> . Em função do seu estreito índice terapêutico, deve-se monitorar rigorosamente a pressão arterial e os sinais de insuficiência renal durante o tratamento com ciclosporina, mesmo que o aumento da creatinina sérica seja menor que o esperado – níveis aumentados de creatinina sérica são indicativos da necessidade de redução de dose ou suspensão do tratamento<sup>86</sup> . Ressalta-se que, para o monitoramento da pressão da arterial, deve-se atentar ao uso de equipamento adequado, incluindo braçadeiras com diâmetro ajustável à necessidade de crianças, adolescentes e adultos. Pacientes que utilizam altas doses iniciais de ciclosporina podem apresentar níveis mais altos de creatinina sérica, que tendem a diminuir ao longo do tempo<sup>33</sup> . Não é necessária avaliação de rotina de níveis mínimos de ciclosporina durante a terapia<sup>3</sup> . Os eventos adversos relacionados à utilização da ciclosporina devem ser cuidadosamente monitorados, o que pode incluir nefrotoxicidade, hipertensão, tremor, hipertricose, dor de cabeça, hiperplasia gengival e aumento do risco de câncer de pele e linforma<sup>33</sup> . A nefrotoxicidade é mais comum em idosos, em doses superiores a 5 mg/kg/dia, em uso prolongado e em pacientes com elevacão da creatinina sérica<sup>1</sup> . A redução da dose deve ser gradual e orientada com base na eficácia da terapia e a suspensão do tratamento com ciclosporina pode ocasionar uma reativação da atividade da doença em, aproximadamente, duas semanas.  
27  
Preferencialmente, seu uso deve ser restrito a 8 a 12 meses, não sendo recomendado por período superior a dois anos contínuos<sup>11,60,6459,63</sup> . Não é necessária a repetição periódica do teste cutâneo para o monitoramento do uso da ciclosporina. A ciclosporina não deve ser utilizada como substituto do tratamento tópico. Seu uso é permitido na gravidez, com certo risco de baixo peso ao nascer, sem risco de malformação ou morte fetal.  
- metotrexato: os pacientes devem ser informados dos potenciais benefícios e riscos do uso do metotrexato (incluindo os primeiros sinais e sintomas de toxicidade), a necessidade de serem assistidos por seus clínicos imediatamente se essas ocorrerem e a necessidade de acompanhamento próximo, incluindo exames laboratoriais periódicos, para monitorar a toxicidade<sup>65,69</sup> . A avaliação basal deve incluir um hemograma completo com contagens diferenciais e de plaquetas; enzimas hepáticas; exames de infecção por hepatite B ou C, sorologia para HIV e exames de função renal; beta-HCG (para mulheres) e radiografia torácica. Estes exames devem ser repetidos 15 a 30 dias após o início do tratamento. O monitoramento do nível sérico de metotrexato pode reduzir significativamente a toxicidade e a mortalidade ao permitir o ajuste da dose de metotrexato e a realização das medidas adequadas de resgate. Em caso de alteração persistente da função hepática, o metotrexato deve ser interrompido e o paciente avaliado por médico hepatologista<sup>1</sup> . Os pacientes sujeitos às seguintes condições são predispostos ao desenvolvimento de níveis elevados ou prolongados de metotrexato e se beneficiam do monitoramento rotineiro dos níveis: efusão pleural, ascite, obstrução do trato gastrintestinal, terapia anterior com cisplatina, desidratação, acidúria, função renal comprometida. Alguns pacientes podem ter a depuração de metotrexato retardada na ausência dessas características. É importante que os pacientes sejam identificados dentro de 48 horas, uma vez que a toxicidade do metotrexato pode ser irreversível se o resgate adequado com ácido folínico for atrasado por mais de 42 a 48 horas. O monitoramento das concentrações de metotrexato deve incluir a determinação de um nível de metotrexato em 24, 48 e 72 horas e a avaliação da taxa de declínio nas concentrações de metotrexato (para determinar por quanto tempo continuar o resgate com ácido folínico)<sup>69</sup> .  
- dupilumabe: pacientes com asma não devem ajustar ou parar os tratamentos para a asma sem consultar seu médico. Estes pacientes devem ser cuidadosamente monitorados após a descontinuação de dupilumabe. Os corticosteroides sistêmicos, tópicos ou inalatórios devem ser descontinuados gradualmente e realizados sob a supervisão de um médico. Os pacientes tratados com este medicamento que desenvolvem conjuntivite que não se resolve após tratamento padrão ou sinais e sintomas sugestivos de ceratite devem ser submetidos a exame oftalmológico<sup>72</sup> .  
- upadacitinibe: os pacientes devem ser cuidadosamente monitorados quanto ao desenvolvimento de sinais e sintomas de infecção durante e após tratamento com upadacitinibe. Deve-se interromper o seu uso se houver desenvolvimento de uma infecção grave ou oportunista<sup>76</sup> . O paciente deve ser submetido a um teste diagnóstico imediato e completo e a terapia antimicrobiana apropriada deve ser iniciada. Para pacientes com infecção crônica ou recorrente; expostos à tuberculose; com histórico de infecção grave ou oportunista; que residiram em áreas de tuberculose endêmica ou micoses endêmicas ou viajaram para tais áreas; ou com condições subjacentes que podem predispô-los à infecção, antes do início do tratamento deve-se considerar os riscos e benefícios<sup>76</sup> . Recomenda-se realizar realizar hemograma completo, rastreamento para Hepatite B e C, HIV e radiografia torácica antes de iniciar o tratamento. Recomenda-se repetir hemograma completo, perfil renal, hepático e lipídico, bem como medir os níveis de creatinina fosfoquinase após 4 semanas de tratamento e, em seguida, repetir a cada três meses durante a terapia<sup>1</sup> . São comuns herpes simples (herpes genital, herpes simples genital, dermatite herpetiforme, herpes oftálmico, herpes simples, herpes nasal, herpes simples oftálmico, infecção por vírus de herpes, herpes oral), herpes zoster, foliculite, influenza, neutropenia, anemia, tosse, náusea, dor abdominal e dor abdominal superior, pirexia, fadiga, aumento de creatina fosfoquinase sérica (CPK), aumento de peso e dor de cabeça. São incomuns pneumonia, candidíase oral, hipercolesterolemia, hipertrigliceridemia, aumento de ALT, aumento de AST e urticaria.<sup>76</sup>  
28

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 8. **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com diagnóstico de DA devem ser atendidos preferencialmente em serviços especializados em dermatologia e alergologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Os pacientes devem ser encaminhados a um especialista (como alergologistas ou dermatologistas) em casos de: incerteza diagnóstica; eczema grave ou moderado com disfunção significativa que responde parcialmente à terapia convencional ou aqueles refratários à terapia de primeira linha; atrofia de pele devido ao uso de corticoides tópicos; preocupação com a quantidade necessária de corticoides; possíveis casos de dermatite alérgica de contato; suspeita de deficiências imunológicas ou alergias alimentares e a outros alérgenos<sup>4,5</sup> .  
A confirmação do diagnóstico, o tratamento e o acompanhamento dos pacientes com ceratoconjuntivite atópica (AKC) e ceratoconjuntivite vernal (VKC) devem ser realizados em serviços especializados em oftalmologia. O atendimento hospitalar pode ser necessário, a critério médico, para o controle da DA ou das comorbidades relacionadas à atopia em casos de DA grave. Em pacientes com dermatite grave cronicamente prolongada, existem problemas relacionados à atividade da doença, adesão tratamento e fatores de agravamento. O atendimento hospitalar pode possibilitar: realização de terapia tópica intensiva; revisão de fatores desencadeantes, formas de aplicação e cuidados com a pele, assim como das estratégias para superá-los. O principal objetivo do atendimento hospitalar é alcançar a remissão precoce da dermatite por meio da terapia tópica intensiva e melhorar a adesão por meio de orientação educacional<sup>87</sup> .  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo. Os procedimentos diagnósticos, terapêuticos e medicamentos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada, ressaltando que os serviços, notadamente os de natureza pública ou filantrópica, oferecem assistência adicional à especificada nesse Sistema.  
Os exames para diagnóstico diferencial de DA: teste de contato (patch test) e teste cutâneo de leitura imediata ( _prick test_ ) são correspondentes, respectivamente, com os procedimentos 02.02.03.114-4 - Testes alérgicos de contato e 02.02.03.115-2 - Testes cutâneos de leitura imediata, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS<sup>88</sup> .  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do (s) medicamento (s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
29

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 9. **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos  
relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 10. **REFERÊNCIAS** -->
1. Orfali, R. L. _et al._ Consensus on the therapeutic management of atopic dermatitis ‒ Brazilian Society of Dermatology: an update on phototherapy and systemic therapy using e-Delphi technique. _An Bras Dermatol_ **98** , 814–836 (2023).  
2. Davis, R. G., Hepfinger, C. a., Sauer, K. A. & Wilhardt, M. S. Retrospective evaluation of medication appropriateness and clinical pharmacist drug therapy recommendations for home-based primary care veterans. _Am J Geriatr Pharmacother_ **5** , 40–47 (2007).  
3. Wollenberg, A. _et al._ European guideline (EuroGuiDerm) on atopic eczema: part I – systemic therapy. _Journal of the European Academy of Dermatology and Venereology_ **36** , 1409–1431 (2022). 4. Cunliffe T. Primary care dermatology society. Eczema: atopic eczema. https://www.pcds.org.uk/clinical-guidance/atopic-eczema.  
5. National Institute for Health and Care Excellence (NICE). _Atopic Eczema in under 12s: Diagnosis and Management. Clinical Guideline_ . (2023). 6. Malaysian Health Technology Assessment Section (MaHTAS). _Clinical Practice Guidelines: Management of Atopic Eczema_ . (Malaysian Health Technology Assessment Section (MaHTAS), 2018). 7. Mallol, J. _et al._ The International Study of Asthma and Allergies in Childhood (ISAAC) Phase Three: A global synthesis. _Allergol Immunopathol (Madr)_ **41** , 73–85 (2013). 8. Solé, D. _et al._ Prevalence of atopic eczema and related symptoms in Brazilian schoolchildren: results from the International Study of Asthma and Allergies in Childhood (ISAAC) phase 3. _J Investig Allergol Clin Immunol_ **16** , 367–76 (2006).  
9. Silverberg, J. I. _et al._ Atopic dermatitis in the pediatric population. _Annals of Allergy, Asthma & Immunology_ **126** , 417-428.e2 (2021). 10. Miot, H. A. _et al._ The (one‐year) prevalence of atopic dermatitis in Brazil: A population‐based telephone survey. _Journal of the European Academy of Dermatology and Venereology_ **37** , (2023). 11. Kulthanan, K. _et al._ Clinical practice guidelines for the diagnosis and management of atopic dermatitis. _Asian Pac J Allergy Immunol_ **39** , 145–155 (2021). 12. Langan, S. M., Irvine, A. D. & Weidinger, S. Atopic dermatitis. _The Lancet_ **396** , 345–360 (2020). 13. Li, H., Zhang, Z., Zhang, H., Guo, Y. & Yao, Z. Update on the Pathogenesis and Therapy of Atopic Dermatitis. _Clin Rev Allergy Immunol_ **61** , 324–338 (2021). 14. Aoki, V. _et al._ Consensus on the therapeutic management of atopic dermatitis - Brazilian Society of Dermatology. _An Bras Dermatol_ **94** , 67–75 (2019). 15. Leung, D. Y. M. Why is eczema herpeticum unexpectedly rare? _Antiviral Res_ **98** , 153–157 (2013).  
30  
16. Torres, T. _et al._ Update on Atopic Dermatitis. _Acta Med Port_ **32** , 606–613 (2019).  
17. Silverberg, J. I. _et al._ Patient burden and quality of life in atopic dermatitis in US adults. _Annals of_  
_Allergy, Asthma & Immunology_ **121** , 340–347 (2018).  
18. Brasil. Ministério da Saúde. Secretaria de Ciência, T. I. e I. E. em Saúde. _Diretrizes Metodológicas:_  
_Elaboração de Diretrizes Clínicas_ . (2020).  
19. Frazier, W. & Bhardwaj, N. Atopic Dermatitis: Diagnosis and Treatment. _Am Fam Physician_ **101** ,  
590–598 (2020).  
20. Silverberg, N. B. Typical and atypical clinical appearance of atopic dermatitis. _Clin Dermatol_ **35** ,  
354–359 (2017).  
21. Antunes, A. A. _et al._ Guia prático de atualização em dermatite atópica - Parte I: etiopatogenia, clínica e diagnóstico. Posicionamento conjunto da Associação Brasileira de Alergia e Imunologia e da Sociedade Brasileira de Pediatria. _Arquivos de Asma, Alergia e Imunologia_ **1** , (2017).  
22. Garcovich, S. _et al._ Pruritus as a Distinctive Feature of Type 2 Inflammation. _Vaccines (Basel)_ **9** , 303  
(2021). 23. Droitcourt, C., Vittrup, I., Kerbrat, S., Egeberg, A. & Thyssen, J. P. Risk of systemic infections in  
adults with atopic dermatitis: A nationwide cohort study. _J Am Acad Dermatol_ **84** , 290–299 (2021).  
24. Chu, D. K. _et al._ Atopic dermatitis (eczema) guidelines: 2023 American Academy of Allergy, Asthma  
and Immunology/American College of Allergy, Asthma and Immunology Joint Task Force on Practice Parameters GRADE– and Institute of Medicine–based recommendations. _Annals of Allergy, Asthma & Immunology_ **132** , 274–312 (2024).  
25. Hanifin, J. M. & Rajka, G. Diagnostic Features of Atopic Dermatitis. _Acta Derm Venereol_ **60** , 44–47  
(1980).  
26. WILLIAMS, H. C. _et al._ The U.K. Working Party’s Diagnostic Criteria for Atopic Dermatitis.. _British_  
_Journal of Dermatology_ **131** , 383–396 (1994).  
27. Katoh, N. _et al._ Clinical practice guidelines for the management of atopic dermatitis 2018. _J Dermatol_  
**46** , 1053–1101 (2019).  
28. Simpson, E. _et al._ The Validated Investigator Global Assessment for Atopic Dermatitis (vIGA-AD):  
The development and reliability testing of a novel clinical outcome measurement instrument for the severity of atopic dermatitis. _J Am Acad Dermatol_ **83** , 839–846 (2020).  
29. Fishbein, A. B., Silverberg, J. I., Wilson, E. J. & Ong, P. Y. Update on Atopic Dermatitis: Diagnosis,  
Severity Assessment, and Treatment Selection. _J Allergy Clin Immunol Pract_ **8** , 91–101 (2020).  
30. Modasia, K. H. & Kaliyadan, F. Digital Tools for Assessing Disease Severity in Dermatology. _Indian_  
_Dermatol Online J_ **13** , 190–198 (2022).  
31. Martins, G. A., Arruda, L. & Mugnaini, A. S. B. Validação de questionários de avaliação da qualidade  
de vida em pacientes de psoríase. _An Bras Dermatol_ **79** , 521–535 (2004).  
32. Prati, C., Comparin, C., Catucci, B. & Ferreira, C. Brazilian-portuguese version of the Children’s  
Dermatology Life Quality Index (CDLQI): validity study. _Med Cutan Iber Lat Am._ **38** , 229–233 (2010).  
33. Sidbury, R. _et al._ Guidelines of care for the management of atopic dermatitis. _J Am Acad Dermatol_  
**71** , 1218–1233 (2014).  
31  
34. Aoki, V. _et al._ Consensus on the therapeutic management of atopic dermatitis - Brazilian Society of Dermatology. _An Bras Dermatol_ **94** , 67–75 (2019).  
35. Danby, S. G. _et al._ Different types of emollient cream exhibit diverse physiological effects on the skin barrier in adults with atopic dermatitis. _Clin Exp Dermatol_ **47** , 1154–1164 (2022).  
36. Silverberg, J. I. _et al._ Tapinarof cream 1% once daily: Significant efficacy in the treatment of moderate  
to severe atopic dermatitis in adults and children down to 2 years of age in the pivotal phase 3 ADORING trials. _J Am Acad Dermatol_ **91** , 457–465 (2024).  
37. Liang, J. _et al._ Systematic review and network meta‐analysis of different types of emollient for the prevention of atopic dermatitis in infants. _Journal of the European Academy of Dermatology and Venereology_ **37** , 501– 510 (2023).  
38. Danby, S. _et al._ 52909 MOISTURIZER WITH SKIN IDENTICAL LIPIDS RESTORES BARRIER FUNCTION IN ECZMEA-PRONE SKIN AND REDUCES SKIN SUSCEPTIBILITY TO IRRITANTS. _J Am Acad Dermatol_ **91** , AB259 (2024).  
39. Parikh-Das, A., Ganopolsky, I. & Vaught, C. A clinical trial to determine the therapeutic benefit of  
an investigational over-the-counter cream on dry, itchy skin of adults and children with atopic dermatitis. _J Am Acad Dermatol_ **76** , AB10 (2017).  
40. Freeman, S. _et al._ Efficacy, cutaneous tolerance and cosmetic acceptability of desonide 0.05% lotion (Desowen<sup>®</sup> ) versus vehicle in the short‐term treatment of facial atopic or seborrhoeic dermatitis. _Australasian Journal of Dermatology_ **43** , 186–189 (2002).  
41. Zhong, Y., Samuel, M., van Bever, H. & Tham, E. H. Emollients in infancy to prevent atopic dermatitis: A systematic review and meta‐analysis. _Allergy_ **77** , 1685–1699 (2022).  
42. Eichenfield, L. F. _et al._ Guidelines of care for the management of atopic dermatitis. _J Am Acad_  
_Dermatol_ **70** , 338–351 (2014).  
43. Droitcourt, C., Vittrup, I., Kerbrat, S., Egeberg, A. & Thyssen, J. P. Risk of systemic infections in adults with atopic dermatitis: A nationwide cohort study. _J Am Acad Dermatol_ **84** , 290–299 (2021).  
44. ANVISA. Agência Nacional de Vigilância Sanitária. _Ciclosporina Cápsula Mole e Solução Oral_  
_[Bula]_ .  
45. Weidinger, S., Beck, L. A., Bieber, T., Kabashima, K. & Irvine, A. D. Atopic dermatitis. _Nat Rev Dis_  
_Primers_ **4** , 1 (2018).  
46. Napolitano, M. _et al._ Infections in Patients with Atopic Dermatitis and the Influence of Treatment. _Am J Clin Dermatol_ **26** , 183–197 (2025).  
47. Swanson, T. _et al._ IWII Wound Infection in Clinical Practice consensus document: 2022 update. _J_  
_Wound Care_ **31** , S10–S21 (2022).  
48. Lullove, E. A Prospective, Open-Label, Nonrandomized Clinical Trial Using Polyvinyl Alcohol Antibacterial Foam for Debridement of Diabetic Foot Ulcers. _Wounds_ **36** , 160–165 (2024).  
49. Lullove, E. Use of Ovine-based Collagen Extracellular Matrix and Gentian Violet/Methylene Blue Antibacterial Foam Dressings to Help Improve Clinical Outcomes in Lower Extremity Wounds: A Retrospective Cohort Study. _Wounds_ **29** , 107–114 (2017).  
32  
50. Applewhite, A., Attar, P., Liden, B. & Stevenson, Q. Gentian Violet and Methylene Blue Polyvinyl  
Alcohol Foam Antibacterial Dressing as a Viable Form of Autolytic Debridement in the Wound Bed. _Surg Technol Int_ **26** , 65–70 (2015).  
51. Coutts, P. M., Ryan, J. & Sibbald, R. G. Case Series of Lower-Extremity Chronic Wounds Managed  
with an Antibacterial Foam Dressing Bound with Gentian Violet and Methylene Blue. _Adv Skin Wound Care_ **27** , 9–13 (2014).  
52. Schwarzer, S. _et al._ Does the use of <scp>DACC</scp> ‐coated dressings improve clinical outcomes  
for hard to heal wounds: A systematic review. _Int Wound J_ **21** , (2024).  
53. Mulpur, P. _et al._ Dialkyl Carbamoyl Chloride (DACC)-Impregnated Dressings for the Prevention of  
Surgical Site Infections: Experience From a Multi-disciplinary Study in India. _Cureus_ (2024)  
doi:10.7759/cureus.72654.  
54. Jeyaraman, M. _et al._ Efficacy of Dialkylcarbamoylchloride (DACC)-Impregnated Dressings in  
Surgical Wound Management: A Review. _European Burn Journal_ **6** , 1 (2025).  
55. Kilpatrick, M., Hutchinson, A. & Bouchoucha, S. L. Nurse’s perceptions on infection prevention and  
control in atopic dermatitis in children. _Infect Dis Health_ **24** , 141–146 (2019).  
56. Castro APM, S. D. F. N. J. C. R. M. F. M. et al. Guia Prático para o Manejo da Dermatite Atópica –  
opinião conjunta de especialistas em alergologia da Associação Brasileira de Alergia e Imunopatologia e da Sociedade Brasileira de Pediatria. _Rev. bras. alerg. imunolpatol_ **29** , 268–282 (2006).  
57. Medscape. Atopic Dermatitis Treatment & Management.  
https://emedicine.medscape.com/article/1049085-treatment?form=fpf (2024).  
58. Eichenfield, L. F. _et al._ Systemic Therapy for Atopic Dermatitis in Children and Adolescents: A US  
Expert Consensus. _Dermatology_ 1–13 (2024) doi:10.1159/000540920.  
59. Prakash, A. & Benfield, P. Topical Mometasone. _Drugs_ **55** , 145–163 (1998).  
60. Tapia C, N. T. Z. P. Cyclosporine. _In: StatPearls [Internet]. Treasure Island (FL): StatPearls_  
_Publishing_ (2023).  
61. BRASIL. Ministério da Saúde. _PORTARIA SCTICS/MS N_<sup>_o_</sup> _116, DE 5 DE OUTURBRO DE 2022 Torna Pública a Decisão de Incorporar, No Âmbito Do Sistema Único de Saúde - SUS, a Ciclosporina Oral Para o Tratamento Da Dermatite Atópica Moderada a Grave, Conforme Protocolo Estabelecido Pelo Ministério Da Saúde._ (2022).  
62. Sidbury, R. _et al._ Guidelines of care for the management of atopic dermatitis. _J Am Acad Dermatol_  
**71** , 327–349 (2014).  
63. Sowden, J. M. _et al._ Double-blind, controlled, crossover study of cyclosporin in adults with severe  
refractory atopic dermatitis. _The Lancet_ **338** , 137–140 (1991).  
64. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _772: Ciclosporina Oral Para o_  
_Tratamento de Dermatite Atópica Moderada a Grave_ . (2022).  
65. Samorano, L. P. _et al._ Methotrexate for refractory adult atopic dermatitis leads to alterations in  
cutaneous IL-31 and IL-31RA expression. _An Bras Dermatol_ **99** , 72–79 (2024).  
33  
66. Flohr, C. _et al._ Efficacy and safety of ciclosporin versus methotrexate in the treatment of severe atopic  
dermatitis in children and young people (TREAT): a multicentre parallel group assessor-blinded clinical trial. _British Journal of Dermatology_ **189** , 674–684 (2023).  
67. El-Khalawany, M. A., Hassan, H., Shaaban, D., Ghonaim, N. & Eassa, B. Methotrexate versus  
cyclosporine in the treatment of severe atopic dermatitis in children: a multicenter experience from Egypt. _Eur J Pediatr_ **172** , 351–356 (2013).  
68. Goujon, C. _et al._ Methotrexate Versus Cyclosporine in Adults with Moderate-to-Severe Atopic Dermatitis: A Phase III Randomized Noninferiority Trial. _J Allergy Clin Immunol Pract_ **6** , 562-569.e3 (2018).  
69. ANVISA. Agência Nacional de Vigilância Sanitária. _Metotrexato (MTX Blau Farmacêutica SA)_  
_[Bula]_ .  
70. Paller, A. S. _et al._ Efficacy and safety of dupilumab with concomitant topical corticosteroids in children 6 to 11 years old with severe atopic dermatitis: A randomized, double-blinded, placebo-controlled phase 3 trial. _J Am Acad Dermatol_ **83** , 1282–1293 (2020).  
71. Paller, A. S. _et al._ Dupilumab in children aged 6 months to younger than 6 years with uncontrolled atopic dermatitis: a randomised, double-blind, placebo-controlled, phase 3 trial. _The Lancet_ **400** , 908–919 (2022).  
72. Agência Nacional de Vigilância Sanitária (Anvisa). _Dupixent (Dupilumabe) Solução Injetável 200mg e 300mg. Bula._ (2024).  
73. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _931. Abrocitinibe, Dupilumabe e Upadacitinibe Para o Tratamento de Adolescentes Com Dermatite Atópica Moderada a Grave e Dupilumabe Para o Tratamento de Crianças Com Dermatite Atópica Grave._ (2024).  
74. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _930. Abrocitinibe, Baricitinibe, Dupilumabe e Upadacitinibe Para o Tratamento de Adultos Com Dermatite Atópica Moderada a Grave._ (2024).  
75. Thyssen, J. P. _et al._ Upadacitinib for moderate‐to‐severe atopic dermatitis: Stratified analysis from three randomized phase 3 trials by key baseline characteristics. _Journal of the European Academy of Dermatology and Venereology_ **37** , 1871–1880 (2023).  
76. ANVISA. Agência Nacional de Vigilância Sanitária. _Upadacitinibe (Rinvoq) [Bula]_ .  
77. Guttman-Yassky, E. _et al._ Once-daily upadacitinib versus placebo in adolescents and adults with  
moderate-to-severe atopic dermatitis (Measure Up 1 and Measure Up 2): results from two replicate double-blind, randomised controlled phase 3 trials. _The Lancet_ **397** , 2151–2168 (2021).  
78. Paller, A. S. _et al._ Efficacy and Safety of Upadacitinib Treatment in Adolescents With Moderate-to-  
Severe Atopic Dermatitis. _JAMA Dermatol_ **159** , 526 (2023).  
79. Reich, K. _et al._ Safety and efficacy of upadacitinib in combination with topical corticosteroids in adolescents and adults with moderate-to-severe atopic dermatitis (AD Up): results from a randomised, double-blind, placebo-controlled, phase 3 trial. _The Lancet_ **397** , 2169–2181 (2021).  
80. Katoh, N. _et al._ A phase 3 randomized, multicenter, double-blind study to evaluate the safety of upadacitinib in combination with topical corticosteroids in adolescent and adult patients with moderate-to-severe atopic dermatitis in Japan (Rising Up): An interim 24-week analysis. _JAAD Int_ **6** , 27–36 (2022).  
81. Agência Nacional de Vigilância Sanitária (ANVISA). Acetato de dexametasona. https://consultas.anvisa.gov.br/#/.  
34  
82. Agência Nacional de Vigilância Sanitária (ANVISA). Acetato de hidrocortisona.  
https://consultas.anvisa.gov.br/#/.  
83. ANVISA. Agência Nacional de Vigilância Sanitária. _Furoato de Mometasona 1mg/g [Bula]_ .  
84. ANVISA. Agência Nacional de Vigilância em Saúde. _Tacrolimo Pomada Dermatológica 0,1% e_  
- _0,03% [Bula]_ . 85. Caron, A. G. M. _et al._ The wide variety of methotrexate dosing regimens for the treatment of atopic  
- dermatitis: a systematic review. _Journal of Dermatological Treatment_ **35** , (2024).  
86. Wollenberg, A. _et al._ ETFAD/EADV Eczema task force 2015 position paper on diagnosis and  
treatment of atopic dermatitis in adult and paediatric patients. _Journal of the European Academy of Dermatology and Venereology_ **30** , 729–747 (2016).  
87. Katoh, N. _et al._ Japanese guidelines for atopic dermatitis 2020. _Allergology International_ **69** , 356–  
369 (2020).  
88. Ministério da Saúde. Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM  
do SUS (SIGTAP). http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp (2025).  
89. BRASIL. Ministério da Saúde. _Diretrizes Metodológicas: Sistema GRADE – Manual de Graduação_  
_Da Qualidade Da Evidência e Força de Recomendação Para Tomada de Decisão Em Saúde_ . (2014).  
90. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _967: Furoato de Mometasona 0,1%_  
_Para o Tratamento de Dermatite Atópica_ . (2025).  
91. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _966: Tacrolimo_ . (2025).  
92. BRASIL. Ministério da Saúde. _Relatório de Recomendação N_<sup>_o_</sup> _968: Metotrexato Para o Tratamento de_  
_Pacientes Com Dermatite Atópica Moderada a Grave_ . (2025).  
35

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **DEXAMETASONA, ACETATO DE HIDROCORTISONA, FUROATO DE MOMETASONA, TACROLIMO, CICLOSPORINA, METOTREXATO, DUPILUMABE, UPADACITINIBE** -->
Eu, _____________________________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos dexametasona, acetato de hidrocortisona, furoato de mometasona, tacrolimo, ciclosporina, metotrexato, dupilumabe e/ou upadacitinibe.  
Os termos médicos foram explicados e todas as minhas dúvidas foram esclarecidas pelo médico ________________________________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora na gravidade da doença durante o tratamento;  
- redução da intensidade da coceira;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das contraindicações, dos potenciais eventos adversos e dos riscos a  
seguir:  
- os riscos na gestação e na amamentação já são conhecidos; portanto, caso engravide, devo avisar imediatamente o médico;  
- medicamentos classificados na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos): Dexametasona, acetato de hidrocortisona, tacrolimo e ciclosporina;  
- medicamentos que não devem ser utilizados por mulheres grávidas sem orientação médica): furoato de mometasona, dupilumabe e upadacitinibe;  
- medicamentos classificados na gestação como categoria X (não devem ser utilizados por mulheres grávidas ou que possam ficar grávidas durante o tratamento): metotrexato;  
- eventos adversos da dexametasona: atrofia da pele, dermatite perioral, supressão adrenal, acne rosácea e o desenvolvimento de estrias;  
- eventos adversos do acetato de hidrocortisona: atrofia da pele, telangiectasia, estrias, alterações cutâneas acneiformes e efeitos sistêmicos do corticoide devido à absorção. Em casos raros, podem ocorrer foliculite, hipertricose, dermatite perioral e reações alérgicas cutâneas a qualquer um dos componentes do produto. Recém-nascidos podem apresentar reações adversas como redução da função adrenocortical, quando houver uso do medicamento pela mãe nas últimas semanas de gravidez);  
- eventos adversos da ciclosporina: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração (taquicardia), convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição  
36  
das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas; - eventos adversos do tacrolimo: queimação e prurido no local de aplicação. São comuns infecção local na pele independentemente da etiologia específica, incluindo, mas não limitada a eczema herpético, foliculite, herpes simples, infecção pelo vírus do herpes, erupção variceliforme de Kaposi; intolerância ao álcool (rubor facial e irritação na pele após o consumo de bebida alcoólica); parestesia e disestesia (hiperestesia e sensação de queimação); prurido; aquecimento, eritema, dor, irritação, parestesia, dermatite e rash no local de aplicação. É incomum o aparecimento de acne e a frequência é desconhecida para rosácea, edema no local de aplicação e aumento dos níveis de tacrolimo no sangue.  
- eventos adversos do furoato de mometasona: parestesia (formigamento), prurido (coceira), sinais de atrofia cutânea (pele mais fina e frágil), abcesso, exacerbação da doença, eritema (vermelhidão), furunculose, acne, reações no local de aplicação e foliculite (inflamação dos folículos da pele). Um dos componentes de furoato de mometasona, o propilenoglicol, é potencialmente irritante e pode causar sensação de queimação, se usado sobre a área inflamada;  
- eventos adversos do metotrexato: A incidência e a gravidade das reações adversas estão relacionadas à dose e à frequência da administração. As reações adversas mais frequentes são: estomatite ulcerativa, leucopenia, náusea, desconforto abdominal, indisposição, fadiga indevida, calafrios, febre, tonturas e resistência reduzida a infecções. As úlceras na mucosa oral são geralmente relatadas como os sinais precoces de intoxicação;  
- eventos adversos do dupilumabe: conjuntivite, conjuntivite alérgica, herpes oral, eosinofilia, artralgia e reações no local da injeção (incluindo eritema, edema, prurido, dor e inchaço). As reações adversas incomuns identificadas são: angioedema, prurido no olho, blefarite, ceratite, olho seco e erupção facial (rash). Já as raras são reações da doença do soro, reações semelhantes à doença do soro, reações anafiláticas e ceratite ulcerativa;  
- eventos adversos do upadacitinibe: são muito comuns infecções do trato respiratório superior (laringite, laringite viral, nasofaringite, dor orofaríngea, abscesso faríngeo, faringite, faringite estreptocócica, faringotonsilite, infecção do trato respiratório, infecção viral do trato respiratório, rinite, rinolaringite, sinusite, amigdalite, amigdalite bacteriana, infecção do trato respiratório superior, faringite viral, infecção do trato respiratório superior) e acne. São comuns herpes simples (herpes genital, herpes simples genital, dermatite herpetiforme, herpes oftálmico, herpes simples, herpes nasal, herpes simples oftálmico, infecção por vírus de herpes, herpes oral), herpes zoster, foliculite, influenza, neutropenia, anemia, tosse, náusea, dor abdominal e dor abdominal superior, pirexia, fadiga, aumento de creatina fosfoquinase sérica (CPK), aumento de peso e dor de cabeça. São incomuns pneumonia, candidíase oral, hipercolesterolemia, hipertrigliceridemia, aumento de ALT, aumento de AST e urticaria;  
- Contraindicações da dexametasona: tuberculose da pele, varicelas, infecção por fungo ou herpes simples ou hipersensibilidade (alergia) a dexametasona ou aos componentes da fórmula;  
- Contraindicações do acetato de hidrocortisona: processos tuberculosos ou sifilíticos na área a ser tratada, doenças causadas por vírus (por exemplo, varicela, herpes zoster), rosácea, dermatite perioral, reações após aplicação de vacinas na área a ser tratada ou hipersensibilidade (alergia) ao acetato de hidrocortisona ou aos componentes da fórmula;  
- Contraindicações da ciclosporina: insuficiência renal crônica, neoplasia em atividade, lactação, infecção aguda ou crônica ativa, tuberculose sem tratamento, hipertensão não controlada, hipersensibilidade ao medicamento. Adicionalmente, o medicamento deve ser utilizado com cautela, conforme avaliação clínica do médico, em pacientes  
37  
vivendo com HIV, HCV, HBV e HPV. Outras contraindicações incluem o uso concomitante de ciclosporina com fototerapia (aumento do risco de câncer de pele) e a aplicação de vacinas de vírus vivos atenuados.  
- Contraindicações do furoato de mometasona: pessoas sensíveis ao furoato de mometasona, a outros corticosteroides e menores de dois anos;  
- Contraindicações do tacrolimo: hipersensibilidade aos macrolídeos em geral e menores de dois anos;  
- Contraindicações do metotrexato: gravidez, aleitamento, insuficiência renal grave, insuficiência hepática grave, abuso de álcool, infecções graves, agudas ou crônicas (tuberculose, HIV e outras síndromes de imunodeficiência), úlceras da cavidade oral e doenças ulcerosa gastrointestinal ativa, discrasias sanguíneas pré-existentes (hipoplasia da medula óssea, leucopenia, trombocitopenia ou anemia significativa, vacinação concomitante com vacinas vivas;  
- Contraindicações do dupilumabe: é contraindicado em pacientes com hipersensibilidade conhecida ao dupilumabe ou a qualquer excipiente;  
- Contraindicações do upadacitinibe: contraindicado para pacientes com pacientes com insuficiência hepática grave; hipersensibilidade ao upadacitinibe (substância ativa) ou aos excipientes da fórmula (celulose microcristalina, hipromelose, manitol, ácido tartárico, dióxido de silício, estearato de magnésio e Opadry II [álcool polivinílico, macrogol 3350, talco, dióxido de titânio, óxido de ferro preto e óxido de ferro vermelho]); pacientes com tuberculose ativa ou infecções graves ativas.  
Fui também informado(a) que este(s) medicamento(s) não tem por objetivo curar a causa da dermatite atópica. Estou ciente de que este(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-lo(s) caso não queira ou não possa utilizá-lo(s), ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de eu desistir de usar o(s) medicamento(s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o meu anonimato.  
- (   ) Sim (   ) Não  
Meu tratamento constará do seguinte medicamento:  
- (   ) acetato de hidrocortisona  
- (   ) ciclosporina  
- (   ) dexametasona  
- (   ) dupilumabe  
- (   ) furoato de mometasona  
- (   ) metotrexato  
- (   ) tacrolimo  
- (   ) upadacitinibe  
Local:  
Data:  
Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
38  
Assinatura do paciente ou do responsável legal  
|Médico responsável:|CRM:|UF:|
|---|---|---|
|Assinatura e carimbo do|||
|médico Data:|||  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
39

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **ÍNDICE DE QUALIDADE DE VIDA EM DERMATOLOGIA – DLQI-BRA** -->
Este questionário visa a medir o quanto o problema de pele que você tem afetou sua vida durante a semana que passou. Escolha apenas uma resposta para cada e marque um X sobre a alternativa correspondente.  
1. O quanto sua pele foi afetada durante a semana que passou por causa de coceira, inflamação, dor ou queimação?  
|3 realmente muito|2 bastante|1 um pouco<br>0 nada|
|---|---|---|  
2. Quanto constrangimento ou outro tipo de limitação foi causado por sua pele durante a semana que passou?  
|3 realmente muito|2 bastante|1 um pouco<br>0 nada|
|---|---|---|  
3. O quanto sua pele interferiu nas suas atividades de compras ou passeios, em casa ou locais públicos, durante a  
semana que passou?  
|3 realmente muito<br>2 bastante|1 um pouco<br>0 nada/sem relevância|
|---|---|  
4. Até que ponto sua pele interferiu na semana que passou com relação às roupas que você normalmente usa?  
|3 realmente muito|2 bastante|1 um pouco<br>0 nada/sem relevância|
|---|---|---|  
5. O quanto sua pele afetou qualquer uma das suas atividades sociais ou de lazer na semana que passou?  
|3 realmente muito<br>6. Quão difícil foi para|2 bastante<br>você praticar esportes duran|1 um pouco<br>te a semana que passou?|0 nada/sem relevância|
|---|---|---|---|
|3 realmente muito|2 bastante|1 um pouco|0 nada/sem relevância|  
6. Quão difícil foi para você praticar esportes durante a semana que passou?  
7. Sua pele impediu que você fosse trabalhar ou estudar durante a semana que passou?  
|3 sim<br>0 não<br>0 sem relevância|
|---|  
40  
Em caso negativo, sua pele já foi problema para você no trabalho ou na vida escolar?  
|2 bastante|0 um pou|co<br>0 nada||
|---|---|---|---|
|8. Quão problemática s|e tornou sua relação com o(|a) parceiro(a), amigos próximos ou par|entes, por causa de sua pele?|
|3 realmente muito|2 bastante|1 um pouco|0 nada/sem relevância|
|9. Até que ponto sua pe|le criou dificuldade na sua|vida sexual na semana que passou?||
|3 realmente muito|2 bastante|1 um pouco|0 nada/sem relevância|
|10. Até que ponto seu tr|atamento dermatológico cr|iou problemas para você na semana que|passou?|
|3 realmente muito|2 bastante|1 um pouco|0 nada/sem relevância|  
41

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **MATERIAL SUPLEMENTAR** -->
Na semana que passou:  
1. Sua pele tem apresentado coceira, sensibilidade ou dor?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
2.Você sentiu-se constrangido ou inibido, chateado ou triste por causa de sua pele?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
3. Sua pele tem afetado suas amizades?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
4. Você mudou a sua maneira de vestir por causa de sua pele?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
5. Sua pele tem atrapalhado as suas atividades de lazer em geral?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
6. Você evitou nadar ou praticar outros esportes por causa dos seus problemas de pele?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
7. a) Era período escolar? Se era: o quanto seu problema de pele interferiu em suas atividades escolares? Me impediu de ir à escola  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
7. b) Era período de férias? Se era: o quanto seu problema de pele interferiu no aproveitamento de suas férias? Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
8. Você teve problemas com pessoas dizendo nomes, caçoando, intimidando, fazendo perguntas ou evitando você? Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
9. Seu sono foi afetado por causa de seu problema de pele?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
10. Seu tratamento dermatológico foi problemático?  
Muitíssimo ( ) Muito ( ) Pouco ( ) Não ( )  
Por favor, verifique se você respondeu todas as perguntas. Obrigado  
42

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 1. **Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Dermatite Atópica foi motivada pela incorporação de cinco novas tecnologias para o tratamento dessa condição, a saber: furoato de mometasona, tacrolimo, metotrexato, dupilumabe e upadacitinibe. O dupilumabe e o upadacitinibe foram incorporados para tratamento de DA grave em crianças e adolescentes, respectivamente, por meio da portaria Portaria SECTICS/MS nº 48/2024, apoiada pelo Relatório de Recomendação nº 931/2024. O furoato de mometasona foi incorporado por meio da Portaria SECTICS/MS nº 18/2025, o tacrolimo pela Portaria SECTICS/MS nº 31/2025 e o metotrexato pela Portaria SECTICS/MS nº 17/2025.  
Considerando a versão do PCDT de 2023, publicado por meio da Portaria Conjunta SAES/SECTICS/MS nº 34, esta atualização rápida focou na inclusão de furoato de mometasona, tacrolimo, metotrexato, dupilumabe e upadacitinibe no âmbito do SUS.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 2. **Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pelo Núcleo de Avaliação de Tecnologias em Saúde da Universidade Federal de São Paulo, Campus Diadema - NUD.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A -** Questionário de conflitos de interesse das diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser|(   ) Sim|
|beneficiada ou prejudicada com as recomendações da diretriz?|(   ) Não|  
43  
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca,<br>royalties) de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|---|---|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interes<br>afetados pela sua atividade na elaboração ou revisão da diretriz?|ses possam ser|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses<br>possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que<br>você irá escrever e que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima,|(   ) Sim|
|que possa afetar sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos<br>listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 3. **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Dermatite Atópica foi apresentada na 124ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de abril de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES), Secretaria de Atenção Primária em Saúde (SAPS), Secretaria de Saúde Indígena (SESAI) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).  
44

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 4. **Consulta Pública** -->
A Consulta Pública nº 57/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Dermatite Atópica, foi realizada entre os dias 04 a 23 de julho de 2025. Foram recebidas seiscentos contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/cp_conitec_057_2025_protocolo_clinico_e.pdf</u>

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: 5. **Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias ( **Quadro B** )<sup>89</sup> .  
**Quadro B** – Níveis de evidências de acordo com o sistema GRADE.  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|Alto|Há forte confiança de que o verdadeiro efeito<br>esteja próximo daquele estimado|É improvável que trabalhos adicionais irão<br>modificar a confiança na estimativa do efeito.|
|||Trabalhos futuros poderão modificar a confiança na|
|Moderado|Há confiança moderada no efeito estimado.|estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|||Trabalhos futuros provavelmente terão um impacto|
|Baixo|A confiança no efeito é limitada.|importante em nossa confiança na estimativa de<br>efeito.|
||A confiança na estimativa de efeito é muito||
|Muito baixo|limitada.<br>Há importante grau de incerteza nos achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Foram adotadas as recomendações da Conitec para as seguintes tecnologias:

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **QUESTÃO 1: Qual é a eficácia e a segurança dos medicamentos abrocitinibe, dupilumabe e upadacitinibe para o tratamento de pacientes adolescentes com dermatite atópica moderada a grave com falha, intolerância ou contraindicação à ciclosporina e com indicação à terapia sistêmica?** -->
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de abrocitinibe e dupilumabe para o tratamento de adolescentes com dermatite atópica moderada a grave, conforme Relatório de Recomendação nº 931/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-931abrocitinibe-dupilumabe-e-upadacitinibe-para-o-tratamento-de-adolescentes-com-dermatite-atopica.  
A estrutura da pergunta de pesquisa, conforme acrônimo PICO, está descrita no **Quadro C.**  
45  
**Quadro C** - Pergunta PICO abrocitinibe, dupilumabe e upadacitinibe (população, intervenção, comparação e outcomes [desfecho]).  
|**População**|Adolescentes (a partir de 12 anos) com dermatite atópica moderada a grave com falha,<br>intolerância ou contraindicação à ciclosporina e com indicação à terapia sistêmica.|
|---|---|
|**Intervenção**|Abrocitinibe, dupilumabe e upadacitinibe|
||Tecnologias sistêmicas disponíveis no SUS: ciclosporina oral de baixa dosagem (2,5-3|
|**Comparadores**|mg/kg/dia) e de alta dosagem (3-5 mg/kg/dia); Placebo; Abrocitinibe, dupilumabe e<br>upadacitinibe|
||Desfechos primários:<br>(i) Melhora clínica avaliada por escala validada1<br>EASI - Índice de Área e Gravidade do Eczema<br>SCORAD - Índice de Pontuação de Dermatite Atópica<br>IGA - Avaliação Global dos Investigadores<br>Outras escalas de avaliação da melhora clínica<br>Desfechos Secundários:<br>(V) Prurido1<br>Escala de Avaliação Numérica de Pico de Prurido (PP-NRS)|
|**Desfechos (outcomes)**|Prurido na Escala Visual Analógica (VAS)<br>Outras escalas numéricas de avaliação de prurido<br>(VI) Qualidade de vida1<br>Índice de Qualidade de Vida em Dermatologia Infantil - CDQLI (crianças)<br>Índice de Qualidade de Vida em Dermatologia - DLQI (adultos)<br>Outros instrumentos de avaliação de qualidade de vida<br>(VII) Resultados de segurança<br>Descontinuação por qualquer causa<br>Quaisquer eventos adversos<br>Quaisquer eventos adversos graves|
|**Delineamento de estudo**|Revisão sistemática de estudos clínicos randomizados ou estudos clínicos randomizados|  
**CDLQI:** _Children's Dermatology Life Quality Index_ ; **DLQI:** _Dermatology life Quality Index_ . **EASI:** _Eczema Score and Severity Index_ . **PP-NRS:** _Peak Pruritus Numerical Rating Scale_ ; **SCORAD:** _Scoring of Atopic Dermatitis._  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 931 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 2: Qual é a eficácia e a segurança do medicamento dupilumabe para o tratamento de crianças com dermatite atópica moderada a grave com falha, intolerância ou contraindicação à ciclosporina e com indicação à terapia sistêmica?**  
46  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de dupilumabe para o tratamento de crianças com dermatite atópica grave, conforme Relatório de Recomendação nº 931/2024, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-931-abrocitinibe-dupilumabe-eupadacitinibe-para-o-tratamento-de-adolescentes-com-dermatite-atopica.</u>  
A estrutura da pergunta de pesquisa, conforme acrônimo PICO, está descrita no **Quadro D.**  
**Quadro D** - Pergunta PICO dupilumabe (população, intervenção, comparação e outcomes [desfecho]).  
|**População**|Crianças (de 6 meses a 11 anos) com dermatite atópica moderada a grave com falha,<br>intolerância ou contraindicação à ciclosporina e com indicação à terapia sistêmica.|
|---|---|
|**Intervenção**|Dupilumabe|
|**Comparadores**|Tecnologias sistêmicas disponíveis no SUS: ciclosporina oral de baixa dosagem (2,5-3<br>mg/kg/dia) e de alta dosagem (3-5 mg/kg/dia); Placebo|
|**Desfechos (outcomes)**|Desfechos primários:<br>(i) Melhora clínica avaliada por escala validada<br>EASI - Índice de Área e Gravidade do Eczema<br>SCORAD - Índice de Pontuação de Dermatite Atópica<br>IGA - Avaliação Global dos Investigadores<br>Outras escalas de avaliação da melhora clínica<br>Desfechos Secundários:<br>(V) Prurido1<br>Escala de Avaliação Numérica de Pico de Prurido (PP-NRS)<br>Prurido na Escala Visual Analógica (VAS)<br>Outras escalas numéricas de avaliação de prurido<br>(VI) Qualidade de vida<br>Qualidade de Vida em Dermatologia Infantil - IDQoL (≤4 anos) ou Índice de Qualidade<br>de Vida em Dermatologia Infantil - CDQLI (crianças)<br>Índice de Qualidade de Vida em Dermatologia - DLQI (adultos)<br>Outros instrumentos de avaliação de qualidade de vida<br>(VII) Resultados de segurança<br>Descontinuação por qualquer causa<br>Quaisquer eventos adversos<br>Quaisquer eventos adversos graves|
|**Delineamento de estudo**|Revisão sistemática de estudos clínicos randomizados ou estudos clínicos randomizados|  
**CDLQI:** _Children's Dermatology Life Quality Index_ ; **DLQI:** _Dermatology life Quality Index_ . **EASI:** _Eczema Score and Severity Index_ . **PP-NRS:** _Peak Pruritus Numerical Rating Scale_ ; **SCORAD:** _Scoring of Atopic Dermatitis._  
47  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 931/2025  
da Conitec<sup>73</sup> . Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 3: Qual é a eficácia e a segurança do furoato de mometasona para o tratamento de pacientes com dermatite atópica, em comparação às alternativas disponíveis no sus (acetado de hidrocortisona 1%, dexametasona 0,1%) ou ao placebo?**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de furoato de mometasona, conforme Relatório de Recomendação nº 967/2025, disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2025/relatorio-de-recomendacao-no-967-mometasona.</u>  
A estrutura da pergunta de pesquisa, conforme acrônimo PICO, está descrita no **Quadro E.**  
**Quadro E** - Pergunta PICO furoato de mometasona (população, intervenção, comparação e outcomes [desfecho]).  
|**População**|Pacientes com dermatite atópica com qualquer grau de gravidade a<br>partir de 2 anos de idade|
|---|---|
|**Intervenção**|Furoato de mometasona 0,1%|
|**Comparadores**|Alternativas disponíveis no SUS (Acetado de hidrocortisona 1%,<br>dexametasona 0,1%) ou placebo|
||Desfechos primários:<br>(i) Melhora clínica avaliada por escala validada<br>EASI<br>SCORAD<br>IGA - Avaliação Global dos Investigadores<br>Outras escalas de avaliação de sinais clínicos<br>(ii) Resultados de segurança<br>Quaisquer eventos adversos<br>Desfechos Secundários:|
|**Desfechos (outcomes)**|(i) Qualidade de vida<br>Índice de Qualidade de Vida em Dermatologia - DLQI (adultos);<br>CDLQI (crianças e adolescentes); IDQoL (≤4 anos)<br>Outros instrumentos de avaliação de qualidade de vida<br>(ii) Prurido1<br>Escala de Avaliação Numérica de Pico de Prurido (PP-NRS)<br>Prurido na Escala Visual Analógica (VAS)<br>Outras escalas numéricas de avaliação de prurido<br>(ii) Resultados de segurança<br>Descontinuação por qualquer causa<br>Quaisquer eventos adversos graves|  
48  
**Delineamento de estudo** Ensaios clínicos randomizados (ECRs)  
**CDLQI:** _Children's Dermatology Life Quality Index_ ; **DLQI:** _Dermatology life Quality Index_ . **EASI:** _Eczema Score and Severity Index_ . **PP-NRS:** _Peak Pruritus Numerical Rating Scale_ ; **SCORAD:** _Scoring of Atopic Dermatitis._  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 967/2025 da Conitec<sup>90</sup> . Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 4 - O uso de tacrolimo tópico (0,3mg/g ou 1mg/g) é eficaz, seguro e custo-efetivo para o tratamento de**

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **dermatite atópica em pacientes acima de 2 anos de idade?** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de tacrolimo tópico, conforme Relatório de Recomendação nº 966/2025, disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2025/relatorio-de-recomendacao-no-966-tacrolimo.</u>  
A estrutura da pergunta de pesquisa, conforme acrônimo PICO, está descrita no **Quadro F.**  
**Quadro F** - Pergunta PICO tacrolimo (população, intervenção, comparação e outcomes [desfecho]).  
|**População**|Pacientes acima de 2 anos com dermatite atópica de qualquer gravidade|
|---|---|
|**Intervenção**|Tacrolimo tópico 0,3mg/g ou 1mg/g|
||Placebo ou alternativas disponíveis no SUS (acetato de hidrocortisona 10mg/g ou dexametasona|
|**Comparadores**|creme<br>1mg/g)|
||Desfechos primários:<br>(i) Melhora clínica avaliada por escala validada<br>EASI<br>mEASI – Índice de Área e Gravidade do Eczema modificado<br>SCORAD - Índice de Pontuação de Dermatite Atópica<br>(ii) Segurança:<br>Eventos adversos gerais|
|**Desfechos (outcomes)**|Desfechos Secundários:<br>(i) Prurido<br>Escala de Avaliação Numérica de Prurido (NRS ou PP-NRS)<br>(ii) Qualidade de vida<br>Índice de Qualidade de Vida em Dermatologia - DLQI (adultos)<br>CDLQI (crianças e adolescentes); IDQoL (≤4 anos)<br>(iii) Resultados de segurança<br>Descontinuação por eventos adversos<br>Eventos adversos graves|
|**Delineamento de estudo**|Ensaios clínicos randomizados|  
49  
**CDLQI:** _Children's Dermatology Life Quality Index_ ; **DLQI:** _Dermatology life Quality Index_ . **EASI:** _Eczema Score and Severity Index_ . **PP-NRS:** _Peak Pruritus Numerical Rating Scale_ ; **SCORAD:** _Scoring of Atopic Dermatitis._  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 966/2025  
da Conitec<sup>91</sup> . Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **QUESTÃO 5 - O uso do metotrexato para o tratamento de dermatite atópica moderada a grave é eficaz e seguro quando comparado a ciclosporina ou a placebo?** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de metotrexato, conforme Relatório de Recomendação nº 968/2025, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de- <u>recomendacao-no-968-metotrexato-da.</u>  
A estrutura da pergunta de pesquisa, conforme acrônimo PICO, está descrita no **Quadro G.**  
**Quadro G** - Pergunta PICO metotrexato (população, intervenção, comparação e outcomes [desfecho]).  
|**População**|Pacientes com dermatite atópica moderada a grave|
|---|---|
|**Intervenção**|Metotrexato|
|**Comparadores**|Ciclosporina ou placebo|
||Desfechos primários:|
||(i) Melhora clínica avaliada por escala validada<br>EASI|
||SCORAD|
||(ii) Segurança<br>Eventos adversos gerais<br>Desfechos secundários:|
|**Desfechos (outcomes)**|(i) Qualidade de vida<br>Índice de Qualidade de Vida em Dermatologia - DLQI (adultos); CDLQI (crianças<br>e adolescentes);<br>(ii) Prurido<br>Escala de Avaliação Numérica de Pico de Prurido (PP-NRS)<br>(iii) Resultados de segurança|
||Quaisquer eventos adversos graves<br>Descontinuação por evento adverso|
|**Delineamento de estudo**|Ensaios clínicos randomizados (ECRs)|  
**CDLQI:** _Children's Dermatology Life Quality Index_ **; DLQI:** _Dermatology life Quality Index_ . **EASI** : _Eczema Score and Severity Index_ . **PP-NRS:** _Peak Pruritus Numerical Rating Scale_ ; **SCORAD:** _Scoring of Atopic Dermatitis_ .  
50  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 968/2025 da Conitec<sup>92</sup> . Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **BUSCA NA LITERATURA SOBRE O HIDRATANTE PARA PREVENÇÃO E TRATAMENTO DE PACIENTES COM DERMATITE ATÓPICA** -->
Também foi realizada uma busca na literatura sobre a eficácia dos hidratantes empregados na gestão de pacientes com Dermatite Atópica, a fim de atualizar o texto publicado pela Portaria Conjunta SAES- SCTIE/MS nº 34/2023, como Protocolo Clínico e Diretrizes Terapêuticas da Dermatite Atópica.  
O objetivo da revisão foi analisar as evidências científicas disponíveis sobre a eficácia relacionadas ao uso de hidratantes para prevenir e tratar de pacientes com Dermatite Atópica. Para sua elaboração, estabeleceu-se a seguinte pergunta ( **Quadro H** ):  
**Pergunta:** O uso de hidratantes é eficaz e seguro no tratamento de pacientes com Dermatite Atópica?  
**Quadro H -** Pergunta estruturada utilizada para elaboração do relatório.  
|**População**|Pacientes com Dermatite Atópica|
|---|---|
|**Intervenção**|Hidratante|
|**Comparadores**|Outros hidratantes ou não uso|
|**Desfechos (****_outcomes_) **|Prevenção de Dermatite Atópica, segurança, qualidade de vida, função de barreira,<br>hidratação, perda transepidérmica de água, prurido e eritema.|
|**Delineamento de estudo**|Revisões sistemáticas (RS) com ou sem meta-análisee e ensaios clínicos randomizados<br>(ECR)|  
A busca de evidências foi realizada nas bases de dados Medline (PubMed), Embase e Cochrane Library. As estratégias de busca e resultados dessa busca se encontram detalhadas no **Quadro I** .  
**Quadro I** - Estratégias de busca nas bases de dados PubMed e Cochrane  
|**Base de dados**|**Estratégia de busca**|**Número de**|
|---|---|---|
|||**estudos**|
|Pubmed|("Dermatitis, Atopic"[Mesh]) AND "Emulsions"[Mesh]<br>Filtros: meta-analysis, ECR e Revisão Sistemática|16|
|Cochrane|#1 MesH descriptor: [Dermatitis, Atopic] explode all trees||
||#2 MesH descriptor: [Emulsion]|<br>14|
||#3 #1 AND #2||
|Embase|#1 'atopic dermatitis'/exp                                                                        65.065|30|  
51  
|**Base de dados**|**Estratégia de busca**|**Número de**<br>**estudos**|
|---|---|---|
||#2 'emulsion'/exp                                                                                    63.194||
||#3 AND ('randomized controlled trial'/de OR 'systematic review'/de)<br>#1 AND #2 AND #3<br>30||  
Foram considerados elegíveis revisões sistemáticas e ensaios clínicos randomizados que avaliaram o uso de hidratantes para prevenção e tratamento de pacientes com dermatite atópica. As revisões sistemáticas foram consideradas elegíveis se incluíssem ensaios clínicos randomizados sobre a eficácia e segurança dessa tecnologia. Foram aplicados os seguintes critérios de exclusão: tipo de estudo (ensaios clínicos fase I e II, estudos piloto), tipo de intervenção (em uso de outra tecnologia que não hidratantes) e tipo de pacientes (pacientes com Dermatite Atópica).  
Foram identificados 60 estudos (16 na Pubmed; 14, na Cochrane e 30, na Embase), sendo 19 duplicatas. Em todas as bases de dados foram empregados os filtros para ensaio clínico controlado randomizado e revisão sistemática ( **Figura A** ). A partir da leitura dos títulos e resumos, foram aplicados os critérios de elegibilidade e excluídos 25 estudos (14 pelo tipo de estudo, 5 pelo tipo de participante e 6 pelo tipo de intervenção).  
**Figura A -** Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
° Publicacées identificadasatravés da<br>% pesquisa nas bases de dados: 60<br>2<br>$ PUBMED: 16<br>S Cochrane: 14<br>2 Embase: 30<br><!-- End of picture text -->  
<!-- Start of picture text -->
*S,° Publicagdes apés remogdo de duplicatas: Publicacdes excluidas :<br>3 44 16<br>a<br>°<br>3 Publicagéescritérios excluidas segundo os<br>2 Estudos excluidos de excluso:<br>2 25 : Tipo de estudo: 14<br><!-- End of picture text -->  
<!-- Start of picture text -->
2 Tipo de intervengao:5<br>cy Tipo de participante:6<br>Estudos incluidos:<br>19<br><!-- End of picture text -->  
52  
O **Quadro J** descreve as principais informações (título e ano de publicação) dos estudos selecionados.  
**Quadro J** - Detalhamento dos estudos selecionados.  
|**Nº**|**Título**|**Ano**|
|---|---|---|
|1|52909 Moisturizer with skin identical lipids restores barrier function in eczmea-prone skin and reduces<br>skin susceptibility to irritants|2024|
|2|Randomized double-blind placebo-controlled cosmetic trial of a topical first-in-class Neutraligand<br>targeting the chemokine TARC/CCL17 in mild-to-moderate atopic dermatitis|2024|
|3|Systematic review and network meta-analysis of different types of emollient for the prevention of atopic<br>dermatitis in infants|2023|
|4|Emollients in infancy to prevent atopic dermatitis: A systematic review and meta-analysis|2022|
|5|Novel botanical for atopic dermatitis|2020|
|6|Echinacea purpurea-derived alkylamides exhibit potent anti-inflammatory effects and alleviate clinical<br>symptoms of atopic eczema|2017|
|7|A clinical trial to determine the therapeutic benefit of an investigational over-the-counter cream on dry,<br>itchy skin of adults and children with atopic dermatitis|2017|
|8|Long-term use of a 4% sodium cromoglicate cutaneous emulsion in the treatment of moderate to severe<br>atopic dermatitis in children|2015|
|9|A randomised, controlled trial of a 4% cutaneous emulsion of sodium cromoglicate in treatment of atopic<br>dermatitis in children|2015|
|10|Application of moisturizer to neonates prevents development of atopic dermatitis|2015|
|11|A special pill-mask to re-hydrate the skin affected by atopic dermatitis|2004|
|12|Efficacy and safety of pimecrolimus cream in the long-term management of atopic dermatitis in children.|2002|
||Treatment of the atopic dermatitis with a water-in-oil emulsion with or without the addition of||
|13|hydrocortisone - Results of a controlled double-blind randomized study using clinical evaluation and<br>bioengineering methods|1996|
|14|An oil-in-water emulsion containing a combination of ginger extract and synthetic cannabidiol with potent<br>in vitro anti-inflammatory effects alleviates symptoms of atopic dermatitis in a clinical trial|2024|
|15|Systematic review and network meta-analysis of different types of emollient for the prevention of atopic<br>dermatitis in infants|2023|
|16|Efficacy and safety of pimecrolimus cream in the long-term management of atopic dermatitis in children|2002|
|17|A body-weight-independent dosing regimen of cyclosporine microemulsion is effective in severe atopic<br>dermatitis and improves the quality of life|2000|
|18|Efficacy, cutaneous tolerance and cosmetic acceptability of desonide 0.05% lotion (Desowen) versus<br>vehicle in the short-term treatment of facial atopic or seborrhoeic dermatitis|2002|
|19|Effect of topically applied evening primrose oil on epidermal barrier function in atopic dermatitis as a<br>function of vehicle|1999|  
53  
Verificou-se que os estudos incluídos têm amostras pequenas, de modo que a maioria envolve lactantes e crianças e não apresentam diferenças significativas entre as alternativas. As frequências de uso de um mesmo hidratante variaram e poucos estudos relataram a região anatômica acometida e a gravidade da dermatite atópica. Apenas um dos estudos incluídos nesta revisão relatou a proporção da superfície corporal comprometida. Esses fatores podem modificar o desempenho dos hidratantes, pois processos inflamatórios induzem profundas modificações metabólicas que também interferem na capacidade reparação da pele.  
Os horizontes temporais dos estudos incluídos nesta revisão variaram de 5 dias a 1 ano. Em sua maioria, os pacientes foram acompanhados por 2 semanas, o que pode ser insuficiente para avaliar se as alternativas terapêuticas são eficazes. Nem todos os estudos relataram as intervenções associadas aos protocolos de tratamento. Alguns estudos associam a intervenção com o uso de corticoesteroides, o que pode interferir nos resultados encontrados.  
Não foram incluídos estudos brasileiros, limitando a extrapolação dos resultados para o contexto do SUS, tendo em vista as peculiaridades de cada sistema de saúde, fatores clínicos, epidemiológicos e demográficos de cada país. Ademais, a heterogeneidade dos estudos dificultou a comparação dos dados, não sendo possível fundamentar a tomada de decisão sobre qual hidratante é mais eficaz para pacientes com dermatite atópica. Contudo, essa revisão mostra uma tendência de uso de hidratantes tópicos por pelo menos duas vezes por dia para prevenir ou atenuar a manifestação dos sinais e sintomas da dermatite atópica.  
54

---

<!-- METADADOS: doenca: Dermatite Atópica | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**<br>**da diretriz clínica**||**Tecnologias av**|**aliadas pela Conitec**|
|---|---|---|---|
|**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|||Dupilumabe para o tratamento<br>de crianças com dermatite<br>atópica grave e o upadacitinibe<br>para<br>o<br>tratamento<br>de<br>adolescentes com dermatite<br>atópica grave [Relatório de<br>Recomendação nº 931/2024;<br>Portaria<br>SECTICS/MS<br>nº<br>48/2024]<br>Metotrexato para o tratamento<br>de pacientes com dermatite| Abrocitinibe e dupilumabe<br>para o**tratamento de adolescentes**<br>com dermatite atópica moderada a<br>grave [Relatório de Recomendação nº<br>931/2024; Portaria SECTICS/MS nº<br>48/2024]|
|Relatório<br>de<br>Recomendação<br>nº<br>1047/2025|Incorporação<br>de<br>tecnologias|atópica<br>grave.<br>[Portaria<br>SECTICS/MS nº 17/2025]<br>Furoato de mometasona 0,1%<br>para o tratamento de pacientes<br>com<br>dermatite<br>atópica.<br>[Portaria<br>SECTICS/MS<br>nº<br>18/2025]<br>Tacrolimo tópico 0,03% e<br>tacrolimo<br>0,1%<br>para<br>o<br>tratamento de pacientes com<br>dermatite atópica.<br>[Portaria<br>SECTICS/MS<br>nº<br>31/2025]|<br> <br> <br> Abrocitinibe,<br>baricitinibe,<br>dupilumabe e upadacitinibe para o<br>tratamento<br>de<br>dermatite<br>atópica<br>moderada a grave**em adultos**.<br>[Relatório DE Recomendação nº<br>930/2024; Portaria SECTICS/MS nº<br>53/2024]|
|Portaria<br>Conjunta<br>SAES/SECTICS<br>nº<br>34/2023.|Primeira<br>versão<br>do<br>documento|<br>Ciclosporina oral para<br>o tratamento da dermatite<br>atópica moderada a grave no|-|  
55  
|Relatório<br>de|SUS.|[Relatório|DE|
|---|---|---|---|
|Recomendação<br>nº|Recomenda|ção<br>nº|772;|
|825/2023|Portaria<br>116/2022]|SCTIE/MS|nº|  
56

---

