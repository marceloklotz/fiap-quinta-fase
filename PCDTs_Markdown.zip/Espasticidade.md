<!-- METADADOS: doenca: Espasticidade | secao: Geral -->
<!-- Start of picture text -->
aE:<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Espasticidade. -->
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a espasticidade no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com este distúrbio;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 717/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 721– Março de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Espasticidade.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da espasticidade, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da espasticidade.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com esse distúrbio em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS n<sup>o</sup> 2, de 29 de maio de 2017, publicada no Diário Oficial da União nº 102, de 30 de maio de 2017 seção 1, página 75.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Espasticidade | secao: **1. INTRODUÇÃO** -->
A espasticidade é um distúrbio do movimento frequente em condições em que há danos nas áreas motoras do sistema nervoso central e se manifesta clinicamente por aumento no tônus muscular, que se torna mais aparente com movimentos de alongamento mais rápidos<sup>1</sup> . Em uma das definições mais recentes, a espasticidade foi descrita como hiperatividade muscular involuntária na presença de paresia central<sup>2</sup> . Existem três mecanismos que desempenham papel central no desenvolvimento da espasticidade: (i) alterações na entrada aferente que chega aos neurônios motores espinhais; (ii) alterações nos arcos reflexos que afetam a excitabilidade dos neurônios motores; e (iii) alterações nas características internas dos neurônios motores<sup>3</sup> .  
A espasticidade pode variar de um problema focal a uma condição difusa (generalizada). Quando focal, afeta um único grupo muscular ou região funcional. Se grupos musculares adjacentes forem afetados em um ou mais membros, a espasticidade é classificada como segmentar. Por fim, tem-se um quadro de espasticidade generalizada quando mais de dois membros são acometidos<sup>4</sup> .  
As principais causas de espasticidade são acidente vascular cerebral (AVC), esclerose múltipla e paralisia cerebral. Danos cerebrais hipóxicos ou traumáticos e danos da medula espinhal são menos frequentes, mas podem levar à espasticidade particularmente grave. A espasticidade também pode surgir como uma consequência de doenças inflamatórias, infecciosas e tumorais<sup>2</sup> . As regiões mais afetadas são os músculos flexores dos membros superiores (dedos, punho e cotovelo) e os músculos extensores dos membros inferiores (joelho e tornozelo).  
Definir a prevalência de espasticidade na população torna-se um desafio pela heterogeneidade com que a condição se apresenta e por ser uma consequência de outras doenças, na maioria das vezes. Dessa forma, a incidência e a prevalência variam de acordo com a condição associada e também com sua gravidade, músculos afetados, tempo de acometimento pela doença, entre outros fatores<sup>5–7</sup> . No **Quadro** 1, estão descritas as estimativas de prevalência e incidência para as condições mais comumente associadas à espasticidade<sup>6</sup> .  
**Quadro 1 –** Estimativas de incidência e prevalência mundial de condições comumente associadas à espasticidade  
|**Doença**|**Incidência anual**|**Prevalência**|
|---|---|---|
|Acidente Vascular Cerebral|30-485/ 100.000|40-600/100.000|
|Esclerose múltipla|-|2-350/100.000|
|Paralisia cerebral|-|240-360/100.000|
|Traumatismo craniano|100–235/100.000|-|
|Lesão da medula espinal|0,2–8/100.000|22-90/100.000|  
Fonte: Adaptado de Martin et al (2014)<sup>6</sup> .  
No Brasil, dados epidemiológicos sobre as condições associadas à espasticidade e sua frequência são escassos. No entanto, em média, 15.469 pacientes receberam toxina botulínica tipo A (TBA), no SUS, entre 2017 e 2020, de acordo com os dados da _Sala Aberta de Inteligência em Saúde (SABEIS) com dados administrativos para gestão de PCDT de tecnologias providas pelo SUS_<sup>8</sup> .  
Quando não tratada, a espasticidade leva a um ciclo vicioso, no qual a contração sem oposição dos músculos afetados causa uma postura anormal do membro, com encurtamento do tecido mole e outras alterações biomecânicas nos músculos contraídos - esse quadro dificulta o alongamento muscular e mantém a rigidez<sup>9</sup> . Manifestações clínicas comuns em pacientes  
com espasticidade incluem: dor, espasmos, contratura e deformidade dos membros que, consequentemente, levam a prejuízos na mobilidade, destreza, higiene, autocuidado e sono, fadiga, baixa autoestima, úlceras de pressão e à incapacidade de usar órteses<sup>9,10</sup> . Os prejuízos também são associados à participação em atividades sociais e relacionadas ao trabalho e à qualidade de vida<sup>9,11</sup> . No entanto, é importante destacar que a espasticidade nem sempre é prejudicial, quando se apresenta em combinação com fraqueza muscular, por exemplo, a espasticidade pode ajudar o paciente a manter a postura, ficar em pé ou andar. Isso deve ser considerado na definição do plano terapêutico, ao mesmo tempo que o profissional precisa estar ciente de que o quadro pode mudar com o passar do tempo, o que exige avaliações regulares e readequação do planejamento de cuidados<sup>9</sup> .  
A identificação de fatores de risco e do distúrbio em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da espasticidade e o processo de seu desenvolvimento seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>12</sup> , que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ).<sup>13,14</sup> . A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Espasticidade | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
Os seguintes diagnósticos caracterizam ou relacionam-se com a espasticidade<sup>15</sup> :  
- G04.1 Paraplagia espástica tropical  
- G80.0 Paralisia cerebral espástica  
- G80.1 Diplegia espástica  
- G80.2 Hemiplegia infantil  
- G81.1 Hemiplegia espástica  
- G82.1 Paraplegia espástica  
- G82.4 Tetraplegia espástica  
- I69.0 Sequelas de hemorragia subaracnoidea  
- I69.1 Sequelas de hemorragia intracerebral  
- I69.2 Sequelas de outras hemorragias intracranianas não traumáticas  
- I69.3 Sequelas de infarto cerebral  
- I69.4 Sequelas de acidente vascular cerebral não especificado como hemorrágico ou isquêmico  
- I69.8 Sequelas de outras doenças cerebrovasculares e das não especificadas  
- T90.5 Sequelas de traumatismo intracraniano  
- T90.8 Sequelas de outros traumatismos especificados da cabeça

---

<!-- METADADOS: doenca: Espasticidade | secao: **3. DIAGNÓSTICO** -->
O diagnóstico da espasticidade é clínico e a avaliação inicia-se com o levantamento da história clínica detalhada e exame físico do paciente<sup>3,16</sup> . A graduação da espasticidade pode ser realizada por meio de um sistema de pontuação validado, como a escala de Ashworth ou a escala de Tardieu<sup>17,18</sup> . A Escala de Ashworth foi publicada na década de 60, como um método de classificação da espasticidade em trabalhos com pacientes com esclerose múltipla. É uma escala que mensura a resistência em um músculo, que não necessariamente é causada pela espasticidade, exigindo uma interpretação mais cuidadosa. Já a escala de Tardieu avalia tanto a resistência do músculo quanto seu ângulo de captura e velocidade do movimento<sup>19</sup> .  
No fim da década de 80, a escala foi modificada com intuito de aumentar sua sensibilidade, sendo adicionado um grau (grau 1+) ( **Quadro 2** )<sup>20</sup> . A partir do grau 1, um indicador associado à disfunção, à dor e a necessidades de assistência, um tratamento pode ser indicado. A Escala de Ashworth modificada (EAM) é amplamente usada, especialmente pela facilidade de uso<sup>17,18</sup> , servindo tanto para avaliar a intensidade da hipertonia como para avaliar a resposta terapêutica. Trata-se de uma escala numérica de 5 pontos (0 a 4), em que 0 representa um músculo sem resistência e 4 um músculo rígido em flexão ou extensão.  
**Quadro 2 -** Escala de Ashworth modificada (EAM)  
|Grau|Descrição|
|---|---|
|0|Tônus normal.|
|1|Leve aumento do tônus muscular, com mínima resistência no fim do movimento.|
|1+|Leve aumento do tônus muscular, com mínima resistência em menos da metade do<br>movimento.|
|2|Aumento mais marcado do tônus muscular na maior parte do movimento, mas a mobilização passiva é efetuada<br>com facilidade.|
|3|Considerável aumento do tônus muscular, e o movimento passivo é difícil.|
|4|Segmento afetado rígido em flexão ou extensão.|  
Fonte: Baunsgaard et al (2016)<sup>5</sup> .  
É importante destacar que, de forma isolada, a avaliação pelas escalas não é suficiente para determinar o plano terapêutico ou seus resultados. Por isso, a equipe multiprofissional de saúde deve considerar também o quanto a espasticidade interfere na funcionalidade e se leva à incapacidade para realização de atividades cotidianas<sup>21,22</sup> . Em situações excepcionais, a critério médico, a confirmação dos grupos musculares espásticos pode ser feita por meio de eletromiografia, eletroestimulação ou ultrassonografia<sup>23</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com espasticidade segmentar ou focal que apresentarem todas as condições abaixo:  
- um dos diagnósticos codificados no item 2 - Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde (CID-10);  
- grau 1, 1+, 2 ou 3 na EAM;  
- comprometimento funcional, dor ou risco de desenvolvimento de deformidades osteomusculoarticulares, devidamente informados por laudo médico; e  
- inserção em programa de reabilitação ou, no mínimo, realização de fisioterapia ou terapia ocupacional.

---

<!-- METADADOS: doenca: Espasticidade | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
- Serão excluídos deste Protocolo os pacientes espásticos que apresentarem pelo menos uma das situações abaixo listadas:  
- hipersensibilidade a um ou mais componentes da formulação das apresentações de TBA;  
- uso exclusivo para tratamento de espasticidade generalizada;  
- perda definitiva da mobilidade articular por contratura fixa ou anquilose com grau 4 na EAM para o segmento a ser tratado;  
- doenças da junção neuromuscular (por exemplo, miastenia grave, síndrome de Lambert-Eaton, etc);  
- desenvolvimento de anticorpos contra TBA;  
- infecção no local de aplicação;  
- gestação ou amamentação;  
- uso concomitante de antibióticos aminoglicosídeos; ou  
- impossibilidade de seguimento do acompanhamento médico e manutenção dos cuidados de reabilitação propostos.

---

<!-- METADADOS: doenca: Espasticidade | secao: **6. TRATAMENTO** -->
A espasticidade pode ter diversas causas e gerar dor, angústia e deficiências que pioram a qualidade de vida, podem incapacitar os pacientes e dificultar o processo de reabilitação. O **Quadro 3** descreve o impacto da espasticidade no corpo, na capacidade de realização de atividades e participação na sociedade, de acordo com a Classificação Internacional de Funcionalidade da Organização Mundial de Saúde (OMS)<sup>24–26</sup> .  
**Quadro 3 –** Impacto da espasticidade no corpo, na capacidade de realização de atividades e participação na sociedade de acordo com a Classificação Internacional de Funcionalidade da Organização Mundial da Saúde  
|**Impacto**|**Problema**|**Efeito**|
|---|---|---|
|**Físico**|Espasmos musculares<br>Postura<br>anormal<br>de<br>tronco<br>e<br>membros<br>Dor|Dor<br>Fadiga<br>Dificuldades posturais<br>Contraturas<br>Deformidade de membros<br>Úlceras por pressão e outros problemas de pele<br>Angústia, mau humor, depressão<br>Problemas no padrão de sono|
|**Motor**|Perda<br>de<br>atividade<br>funcional<br>Perda de função passiva|Redução da mobilidade e destreza<br>Dificuldades na relação sexual<br>Incontinências<br>Dificuldades com autocuidado e higiene<br>Aumento de atividades realizadas por cuidadores<br>Dificuldades na utilização de cadeira de rodas ou posicionamentos<br>em cadeiras e camas|
|**Social**|Impacto de todos os problemas acima|Baixa autoestima<br>Problemas com a autoimagem|  
|Redução da interação social|
|---|
|Impacto nas relações familiares e sociais|
|Impacto no trabalho e atividades domésticas|  
Adaptado de: Organização Mundial de Saúde (https://www.who.int/standards/classifications/international-classification-of-functioning-disability-and-  
<u>health)</u>  
O cuidado ao paciente deve ser considerado gradualmente, envolvendo o uso progressivo de modalidades de tratamento, iniciando com aquelas mais conservadoras e evoluindo para as mais invasivas. Uma das etapas iniciais do tratamento da espasticidade envolve identificar, evitar e tratar condições que possam estar associadas, incluindo infecção, dor, trombose venosa profunda e úlceras de pressão<sup>10,16</sup> .  
O tratamento específico deve ser iniciado quando a espasticidade estiver causando sintomas, prejuízos na função ou na prestação de cuidados e quando o benefício para o paciente for significativo. A equipe multiprofissional deve considerar uma visão geral do quadro do paciente na elaboração do plano terapêutico, uma vez que a espasticidade pode contribuir para algumas funções, como a manutenção da postura<sup>9</sup> . Os objetivos do tratamento devem visar ao alívio dos sintomas (dor e espasmos), melhora da função e postura e diminuição da carga de cuidado<sup>10</sup> . Benefícios mais expressivos podem ser vistos nas metas de função passiva em comparação com as metas de função ativa<sup>9</sup> .  Uma série de intervenções podem ser aplicadas no controle da espasticidade, frequentemente oferecidas em conjunto - como o uso de TBA associado ao gesso seriado ou órteses<sup>9</sup> .  
Independentemente da conduta adotada para o cuidado, é fundamental que ele envolva a discussão do plano terapêutico e, sobretudo, do alinhamento de expectativas com o paciente, família ou cuidador<sup>21</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **6.1 Tratamento não medicamentoso** -->
Existem evidências de que a associação de terapias não medicamentosas às terapias medicamentosas melhore os sintomas de espasticidade em pacientes pediátricos, adolescentes<sup>19</sup> e adultos, devendo o cuidado da espasticidade ser realizado em um programa de reabilitação que envolva intervenções físicas e medicamentosas de forma individualizada e de acordo com as necessidades dos pacientes. Os médicos e equipes multiprofissionais devem adotar condutas baseadas em evidências para identificação e utilização das intervenções adequadas a cada indivíduo<sup>19,21,26–31</sup> .  
Entre as terapias não medicamentosas citadas na literatura científica e em diretrizes clínicas internacionais, estão: tratamentos cirúrgicos, estimulação elétrica, imobilização por gesso, bandagens, alongamento, acupuntura, entre outras<sup>19,21,26–35</sup> . Estas modalidades podem ser associadas ao uso de toxina botulínica, porém os parâmetros ideais para seu uso são desconhecidos, sendo recomendada a avaliação cuidadosa da eficácia sobre os desfechos esperados, se forem utilizadas<sup>21,33</sup> .  
As recomendações das diretrizes clínicas internacionais para terapias não medicamentosas serão abordadas a seguir.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Estimulação Elétrica** -->
A estimulação elétrica funcional (EEF) é uma técnica que utiliza a passagem de corrente elétrica através de eletrodos para ativar músculos e nervos que se encontram enfraquecidos ou paralisados devido à ausência de comandos cerebrais. Geralmente a estimulação elétrica muscular é utilizada para redução de dor, terapia de exercício e iniciação de uso de órteses<sup>26</sup> . Os sistemas de EEF tópicos são facilmente encontrados, podem ser implantados e possuem poucas contraindicações<sup>36</sup> .  
Apesar da escassez de evidências de qualidade que demonstrem que a estimulação elétrica em associação à toxina botulínica melhore os resultados de espasticidade, há pelo menos um estudo clínico cujos resultados sugerem que a estimulação elétrica melhorou as pontuações da EAM em pacientes sobreviventes de AVC, sendo essa uma alternativa citada em diretriz internacional para o cuidado de pacientente no pós AVC<sup>21</sup> . Os resultados de uma revisão sistemática, publicada em 2015, analisou  
dados de 29 estudos clínicos incluindo 940 pacientes e sugere que o uso de estimulação elétrica neuromuscular associada a outras terapias, em pacientes com espasticidade após AVC, pode reduzir a espasticidade e melhorar a amplitude dos movimentos<sup>34</sup> .  
Já o uso de estimulação neuromuscular elétrica transcutânea (TENS, do inglês: _Transcutaneous electrical nerve stimulation_ ) para tratamento da espasticidade relacionada à Esclerose Múltipla não foi recomendado em um consenso italiano<sup>28</sup> . Recentemente têm sido publicados novos estudos clínicos avaliando a combinação do uso de mais de um sistema de estimulação e, ainda que a melhora da espasticidade nem sempre seja alcançada, alguns benefícios em relação à capacidade de locomoção de pacientes parecem promissores e trazem uma nova perspectiva no processo de cuidado<sup>37–40</sup> . No entanto, em virtude das limitações das evidências disponíveis sobre o tema, não é possível afirmar que a estimulação elétrica muscular aumenta a captação de toxina botulínica quando utilizada próxima ao momento da aplicação do medicamento<sup>41</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **Imobilização – gesso, bandagens, órteses e talas.** -->
Gesso e bandagens são muito utilizados na prática clínica<sup>42,43</sup> , principalmente após uso de toxina botulínica na espasticidade focal<sup>26</sup> , apesar das incertezas sobre sua eficácia e segurança em virtude do pequeno número de estudos e baixo tamanho amostral<sup>21</sup> . Contudo, seu uso é frequentemente empregado como forma de prolongar o alongamento dos músculos afetados pela espasticidade<sup>26</sup> . As diretrizes do Colégio de Terapeutas Ocupacionais e da Associação de Fisioterapeutas Credenciados dos Estados Unidos recomendam que as imobilizações com gesso sejam utilizadas na fase aguda do tratamento e com aplicações curtas de 1 a 4 dias, uma vez que apresentam menores complicações quando comparadas às aplicações mais longas<sup>44</sup> .  
Evidências de baixa certeza sugerem que o uso de bandagens em tornozelos pode ter efeito superior quando comparado ao alongamento isolado após a injeção de toxina botulínica<sup>45</sup> e que o uso de bandagem associada à terapia com toxina botulínica pode reduzir a espasticidade de pulsos e dedos<sup>46</sup> . Os resultados de um estudo de fase 2 sugerem que imobilização gessada pode reduzir o nível de espasticidade enquanto um ensaio clínico randomizado com 70 pacientes comparou a utilização de bandagem à técnica de alongamento muscular diária, sugerindo melhora da espasticidade e deficiência após um mês com o uso de bandagem<sup>35</sup> .  
Uma revisão sistemática recentemente publicada, incluindo meta-análise de 25 estudos clínicos, considerou que o uso de gesso seriado foi eficaz em melhorar a dorsiflexão passiva do tornozelo e diminuir a hipertonicidade medida pela EAM a curto prazo, além de melhorar os resultados de marcha funcional a médio prazo. Os autores destacam que ainda permanece pouco clara a importância clínica de melhorar a dorsiflexão do tornozelo por um adicional de três graus, mas que o uso do gesso seriado em membros inferiores pode contribuir para melhora de vários resultados relevantes para a função desses membros, apoiando a sua utilização clínica em crianças com paralisia cerebral ainda que mais estudos precisem ser realizados, sobretudo na avaliação de longo prazo<sup>47</sup> . Os resultados dessa revisão reforçam o que já havia sido relatado anteriormente em análises retrospectivas de prontuários<sup>47–50</sup> .  
Órtese externa é o termo define dispositivos utilizados externamente com a finalidade de modificar a estrutura ou função do sistema musculoesquelético aplicando forças externas contínuas durante sua utilização<sup>8</sup> . Principalmente para crianças e adolescentes com espasticidade, o uso de órteses pode ser recomendado considerando a necessidade dos pacientes, visando a benefícios como melhora da postura ou da função do membro, aumento da eficiência da caminhada, prevenção ou retardo do desenvolvimento de contraturas e migração do quadril, alívio de dor e desconforto, prevenção e tratamento de lesões<sup>19</sup> .  
O uso de órteses deve ser discutido com os pacientes ou responsáveis para decisão compartilhada e balanço de riscos e benefícios. A indicação de órteses deve ser individualizada e considerar<sup>19</sup> :  
- potencial risco de desconforto e lesões devido ao seu uso;  
- importância da educação de pacientes, familiares e cuidadores sobre forma de utilização, tempo de uso, como aplicar e  
- retirar e como higienizar;  
- necessidade do tamanho e do encaixe estarem corretos;  
- necessidade de suspender o uso e retornar ao médico, em caso de dor que não alivie com reposicionamento.  
Para crianças e adolescentes com espasticidade de membros superiores e inferiores, podem ser desenvolvidas órteses que visem à extensão, otimização da função e limitação da deformidade, facilitando o desenvolvimento motor. Para músculos que controlam duas articulações, preconiza-se o uso de órteses noturnas para melhorar o alongamento e a redução de dificuldades funcionais. O uso de órteses por crianças e adolescentes deve ser monitorado frequentemente por médicos e equipes multiprofissionais capacitados para garantir a correta utilização e os melhores desfechos<sup>19</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **Alongamento** -->
Alongamento é definido como qualquer movimento que vise estiramento dos tecidos moles por um período<sup>51</sup> . Usualmente, o alongamento é utilizado para combater o encurtamento muscular e prevenir o desenvolvimento de contraturas. Entretanto, evidências limitadas indicam que, para ser eficaz, é necessária aplicação do alongamento por várias horas durante o dia ou de forma contínua na espasticidade<sup>44,51,52</sup> . Apesar da escassez das evidências, o alongamento é rotineiramente utilizado e estudos têm sido desenvolvidos visando a avaliar sua eficácia<sup>53</sup> .  
Não é recomendado uso rotineiro de alongamento para reduzir espasticidade em pacientes pós-AVC<sup>52</sup> , uma vez que existem evidências de certeza moderada a forte de que tais intervenções não afetam a espasticidade ou mobilidade articular<sup>21</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **Procedimentos cirúrgicos** -->
A rizotomia dorsal seletiva é um procedimento neurocirúrgico que consiste na secção de alguns nervos sensoriais que contribuem para a espasticidade<sup>19</sup> . De acordo com a diretriz clínica do _National Institute for Health and Care Excellence_ (NICE) sobre o cuidado da paralisia cerebral em adultos, evidências com baixo nível de certeza sugerem que rizotomia dorsal seletiva é eficaz para redução do tônus muscular em pacientes adultos com espasticidade. Ainda, a rizotomia dorsal deveria ser considerada somente se outros tratamentos não fossem efetivos ou fossem contraindicados, após avaliação por equipe multidisciplinar experiente e especializada, uma vez que se trata de um procedimento irreversível com possíveis complicações a longo prazo. É imprescindível a discussão com o paciente e seus responsáveis sobre riscos e benefícios do procedimento<sup>27</sup> .  
Em pacientes pediátricos e adolescentes, a cirurgia ortopédica pode ser considerada um importante complemento para as demais intervenções que visam à melhoria da espasticidade, podendo prevenir a deterioração e melhorar a função dos membros<sup>19</sup> . Também a rizotomia dorsal seletiva é considerada como opção para crianças e jovens com espasticidade grave mediante criteriosa elegibilidade dos pacientes e considerando a avaliação multiprofissional de equipe com amplo conhecimento no cuidado da espasticidade e a resposta/acesso a opções de tratamento. A diretriz do NICE recomenda que seja discutida a irreversibilidade do procedimento e incertezas sobre os desfechos de longo prazo com o paciente ou seus familiares ou cuidadores<sup>54</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **6.2 Tratamento medicamentoso** -->
A literatura científica e as diretrizes clínicas internacionais descrevem o uso de alguns medicamentos como parte do tratamento reabilitador e controle da espasticidade, uma vez que o tratamento físico isolado pode ser insuficiente<sup>9,19,27–30</sup> .  
Entre os medicamentos considerados para tratamento e controle da espasticidade estão: toxina botulínica, baclofeno, tizanidina, triexifenidil e fenol<sup>9,19,27–30,55–58</sup> . Outros medicamentos são citados quando discutido o tratamento medicamentoso da espasticidade, mas sem que apresentem indicação específica para essa condição, como: canabidiol, diazepam, gabapentina, pregabalina, levetiracetam e clonidina<sup>9,19,27–30,55–58</sup> .  
Diretrizes clínicas de outros países recomendam o uso de baclofeno intratecal<sup>9,19,27–30</sup> . No entanto, uma vez que não há registro válido junto à Agência Nacional de Vigilância Sanitária (Anvisa) para esta apresentação, não é possível recomendar seu  
uso no Brasil. Já o uso de baclofeno oral pode ser considerado para espasticidade generalizada ou segmentar<sup>9,19,27–30</sup> . Seu uso em adultos foi avaliado pela Conitec para o tratamento da espasticidade, conforme o Relatório de Recomendação nº 715/2022. Ressalta-se que não há indicação aprovada em bula para uso em crianças, motivo pelo qual essa população não foi contemplada na avaliação. As evidências são escassas para adultos e crianças, com resultados pouco expressivos para a eficácia e segurança, provenientes de estudos clínicos com limitações metodológicas importantes, além do tamanho amostral reduzido, o que impede qualquer conclusão. É importante ressaltar que o mesmo cenário já havia sido relatado em diretrizes clínicas internacionais<sup>9,19,27–</sup> 30, incluindo aquelas que citam o baclofeno como uma das opções terapêuticas para tratamento da espasticidade, uma vez que é comum seu emprego na prática clínica e diante da falta de outras opções mais eficazes.  
Na análise sobre eficácia e segurança do baclofeno oral foram incluídos 14 Ensaios Clínicos Randomizados (ECR)<sup>7-20</sup> . Estudos envolvendo a população adulta incluíram, na maioria, participantes com esclerose múltipla, enquanto os relacionados às crianças envolveram pacientes com paralisia cerebral. Em relação à eficácia do baclofeno, os estudos que avaliaram a melhora clínica da espasticidade por meio da escala de Ashworth (em crianças e adultos) indicaram que a intervenção não apresentou diferença entre os efeitos dos comparadores (placebo e diazepam) significativa. Sobre segurança, todos os ECR (independentemente da população ou comparador) trouxeram apenas o número dos eventos adversos ocorridos. Foi possível constatar mais casos no grupo baclofeno em relação ao placebo, mas, quando comparado ao diazepam, essa diferença quase não existiu. Por outro lado, qualidade de vida não foi avaliada em nenhum dos ECR incluídos.  
Os demais desfechos (dor associada à espasticidade e capacidade funcional durante as atividades de vida diária) não foram relatados nos estudos comparando baclofeno com diazepam (para adultos e crianças). Quando comparado ao placebo, os ECR indicaram que o baclofeno foi eficaz para a população adulta na redução da dor associada à espasticidade, apesar das análises terem sido subjetivas e heterogêneas, não houve diferença significativa sobre a capacidade funcional durante as atividades de vida diária. Para as crianças, por outro lado, foi inconclusiva a eficácia do baclofeno para a capacidade funcional no cotidiano, porque algumas análises indicaram benefício e outras não - nos mesmos estudos, inclusive -, a dor associada à espasticidade não foi avaliada nesses pacientes.  
Não é possível fonercer um resultado conclusivo sobre a eficácia e a segurança do baclofeno para a população adulta e pediátrica com espasticidade, por conta da baixa qualidade metodológica das evidências e da heterogeneidade das avaliações (diferentes escalas clínicas, análises subjetivas, exames clínicos) e dos dados para os desfechos analisados para pergunta de pesquisa englobada por este documento. Para todos os desfechos, a certeza do conjunto de evidências foi classificada como “muito baixa”, exceto para a avaliação da espasticidade pela escala de Ashworth na população pediátrica comparando baclofeno a diazepam, cuja certeza foi considerada “baixa”.  
Em uma análise complementar, não foram identificados estudos observacionais que comparem o baclofeno a placebo ou diazepam e justificassem a inclusão desse tipo de estudo na revisão sistemática conduzida nesta síntese. Portanto, há necessidade de estudos primários mais robustos e melhor conduzidos para ambas as populações incluídas nesta síntese.  
Em outras revisões sistemáticas avaliando a eficácia de agentes antiespasmódicos orais, de forma geral a conclusão gira em torno da limitação das evidências científicas disponíveis, tanto em relação à quantidade quanto à qualidade, para que possam ser formuladas recomendações a respeito de seu uso<sup>18,56–59</sup> . Há estudos cujos resultados sugerem que o diazepam pode reduzir o tônus muscular, porém não apresentando diferenças significativas de eficácia quando comparado à tizanidina e baclofeno oral. Deste modo, há recomendação fraca para uso de diazepam visando à redução da espasticidade em pacientes com esclerose múltipla na diretriz clínica do NICE<sup>27,30</sup> . O diazepam não deve ser administrado para tratamento de espasticidade em pacientes com paralisia cerebral, exceto em casos agudos de dor grave ou ansiedade associadas à espasticidade<sup>19</sup> .  
O fenol é um composto químico formado por ácido carbólico, ácido fênico, ácido fenílico, hidroxibenzeno e oxibenzona tendo sido muito utilizado para realização de neurólise neural em alguns casos de espasticidade sobretudo antes da disponibilidade de TBA, porém as evidências sobre seu uso são muito limitadas<sup>60–66</sup> . O uso de fenol combinado à TBA pode ser  
útil para o tratamento de espasticidade que cause problemas multifocais, como  meio para aumentar a eficácia da TBA a longo prazo, mas sua administração também requer profissionais capacitados, tal qual ocorre com a TBA - sua aplicação em nervos mistos (motores + sensoriais) pode causar dor neurogênica sendo mais seguro o uso em nervos motores puros<sup>26</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Toxina botulínica</u>** -->
A toxina botulínica é produzida pela bactéria _Clostridium botulinum_ e consiste em uma complexa mistura de proteínas contendo neurotoxina botulínica e várias proteínas não tóxicas. A neurotoxina botulínica consiste em uma cadeia pesada e uma cadeia leve unidas por uma única ligação dissulfeto. É sintetizada como um polipeptídeo de cadeia única relativamente inativo com massa molecular de aproximadamente 150kD e ativada quando a cadeia polipeptídica é clivada. As toxinas botulínicas são uma família de proteínas que possui sete sorotipos clássicos de neurotoxinas (A, B, C, D, E, F e G)<sup>67</sup> , mas que são imunologicamente distintos. Cada sorotipo pode incluir subtipos adicionais. As neurotoxinas inibem a liberação de acetilcolina, embora as proteínas-alvo intracelulares, características específicas de suas ações e potências variem. Apenas os sorotipos A e B foram autorizados para uso clínico, sendo a TBA mais estudada para fins terapêuticos<sup>68,69</sup> e única com registro válido na Anvisa atualmente.  
Existem diferentes formulações de toxina botulínica do tipo A comercializadas no Brasil. As diferenças entre as preparações de TBA, que dependem de seus biotipos específicos e processo de fabricação, levam a diferenças importantes a ser consideradadas. Assim, cada formulação possui características particulares, resultando em doses, eventos adversos e recomendações de conservação e armazenamento próprios. Também as indicações em bula dos vários produtos biológicos que são registrados no Brasil sob o nome de “toxina botulínica” podem variar. As doses de TBA são usualmente medidas em unidades (U) e deve-se considerar a orientação de cada fabricante durante o uso<sup>70,71</sup> .  
O uso terapêutico da TBA deve reduzir a espasticidade do(s) segmento(s) afetado(s), ser capaz de tratar ou prevenir alterações osteomioarticulares, reduzir a dor e ser seguro, sem risco de perda funcional.  
Para a atualização deste PCDT, foram realizadas revisões sistemáticas para a população de adultos e de crianças. Como resultados, foi encontrado que, em crianças, quando comparada à fisioterapia ou cuidados usuais, há evidências de qualidade muito baixa de que a TBA melhora a espasticidade dos flexores plantares do tornozelo no seguimento de médio prazo (diferença padronizada das médias (DMP) -1,31 [IC 95% -2,21; -0,41]) e longo prazo (DMP -0,78 [IC 95% -1,03; -0,52]), mas não no seguimento de curto prazo (DMP -0,77 [IC 95%-1,68; 0,15]). Em comparação ao placebo, evidências de qualidade moderada demonstram que a TBA é eficaz em reduzir a espasticidade na EAM em um curto prazo (diferença média (DM) -0,49 [IC 95% -0,78; -0,20]), médio (DM -0,50 [IC 95% -0,78; -0,22]), mas não em longo prazo (DM -0,18 [IC 95% -0,81; 0,46]). Nos adultos, a TBA exibiu eficácia na semana 4 em relação ao valor basal (evidência de qualidade baixa) nos membros superiores (DM 0,27 [IC 95% 0,15; 0,39]) e nos membros inferiores (DM 0,80 [IC 95% 0,63; 0,97]) (evidência de qualidade moderada).  
Em relação à segurança, nos adultos, o risco de apresentar algum evento adverso foi maior no grupo da TBA quando comparado ao placebo apenas para a análise dos membros superiores (RR 1,15 [IC 95%: 1,02; 1,30]). Entretanto, ao considerar apenas os eventos adversos graves, não houve diferença entre os grupos (RR: 0,88 [IC 95% 0,50; 1,57]). Para os membros inferiores, não houve diferença entre TBA e placebo tanto em adultos (RR: 1,18 [IC 95% 0,99; 1,41]) quanto em crianças (RR 1,29 [IC 95% 0,87; 1,93]). Para todas as avaliações, a certeza da evidência foi considerada baixa.  
Os benefícios esperados do tratamento com TBA são<sup>9,19,27–30</sup> :  
- Melhora da capacidade funcional (locomoção, transferências – mobilidade do paciente, atividades da vida diária);  
- prevenção de contraturas e deformidades osteomusculoarticulares;  
- diminuição da dor;  
- facilitação no uso de órteses e na realização dos cuidados de higiene do paciente;  
- redução da taxa de uso de outros medicamentos;  
- diminuição da frequência e gravidade dos espasmos;  
- redução do número de procedimentos de reabilitação;  
- quando usada nas fases iniciais da reabilitação pós AVC, espera-se que o uso de TBA possa prevenir o encurtamento de  
- tecidos causado pela espasticidade e imobilidade dos membros, podendo evitar o desuso e otimizar a recuperação neurológica.  
Para o uso de TBA como modalidade terapêutica, o paciente deve estar inserido em um programa de reabilitação ou, no mínimo, sob atendimento de fisioterapia ou terapia ocupacional que vise a manobras de manutenção da amplitude do movimento articular, treino funcional e órteses de posicionamento<sup>9,19,27–30</sup> . Fatores que podem causar exacerbação do tônus muscular, como infecções, úlceras de pressão, órteses mal adaptadas ou complicações clínicas, devem ser afastados ou tratados concomitantemente<sup>9,19,27–30.</sup>  
A TBA é recomendada nas diretrizes clínicas internacionais, principalmente para o tratamento de espasticidade focal ou segmentar<sup>9,19,27–30</sup> . Além disso, a TBA deve ser considerada após lesão cerebral não progressiva adquirida, caso a espasticidade cause dificuldades posturais ou funcioniais<sup>26</sup> , e é uma das intervenções combinadas necessárias nos casos de espasticidade de padrão misto, que combina elementos focais e generalizados<sup>9</sup> . Contudo, o uso da TBA não tem indicação para recuperação de funções perdidas, exceto se esta perda tiver relação com a hiperatividade do músculo antagonista<sup>26</sup> .  
Para crianças e adolescentes com espasticidade focal ou segmentar, o uso de TBA deve ser considerado quando há impedimento da função motora fina, comprometimento da possibilidade de autocuidado, presença de dor, impedimento de outros tratamentos, preocupações estéticas ou distúrbios do sono<sup>19</sup> . Entretanto, o medicamento não deve ser administrado em crianças e adolescentes com presença de fraqueza muscular grave, histórico de reação adversa a TBA ou durante tratamento com aminoglicosídeos. Ainda, seu uso deve ser cauteloso neste subgrupo quando houver presença de distúrbios do sangue e coagulação, espasticidade generalizada, contraturas musculares fixas ou forem identificados problemas para adesão ao programa de fisioterapia pós tratamento<sup>19,26</sup> .  
Os eventos adversos mais frequentes são locais, como dor, hematoma, infecção, atrofia e fraqueza muscular e alterações da sudorese. Os eventos adversos sistêmicos mais comuns são cansaço, fraqueza generalizada, prurido e reações alérgicas. Geralmente, esses efeitos são de leve a moderada intensidade e, na maioria dos casos, autolimitados. Há, entretanto, relatos de efeitos sistêmicos graves, como disfagia e dificuldade respiratória, principalmente em crianças com paralisia cerebral que receberam TBA para o tratamento de espasticidade em membros. Algumas dessas complicações foram atribuídas à superdose, o que reforça a importância do pleno domínio por parte do médico assistente dos aspectos posológicos e da técnica de administração referentes a cada produto<sup>70–74</sup> . É importante ressaltar que, da mesma forma que a dose, também os eventos adversos das diferentes formulações de TBA podem variar em frequência e gravidade.

---

<!-- METADADOS: doenca: Espasticidade | secao: **6.2.1.  Medicamento** -->
Toxina botulínica tipo A: frasco-ampola com 100 U e frasco-ampola com 500 U.

---

<!-- METADADOS: doenca: Espasticidade | secao: **6.2.2.  Esquemas de administração** -->
A toxina botulínica é um produto biológico, cujas apresentações disponíveis no mercado são sintetizadas como complexos proteicos macromoleculares distintos, o que pode afetar sua farmacocinética. Consequentemente, os produtos mostram diferenças em seus perfis _in vivo_ , incluindo curvas de resposta à dose pré-clínica e dosagem clínica, eficácia, duração e segurança/eventos adversos. Dessa forma, recomenda-se que eles devam ser usados de acordo com as orientações do fabricante<sup>75–77</sup> .  
A TBA é injetada pela via intramuscular, conforme o plano terapêutico. A aplicação deve ser realizada por médico devidamente capacitado, especialista em medicina física e reabilitação (fisiatria), neurologia, neuropediatria, neurocirurgia ou ortopedia. A dose total por sessão de tratamento deve seguir as recomendações das bulas de cada fabricante, dividida entre os músculos selecionados. A determinação das doses baseia-se na intensidade da espasticidade, comprometimento funcional, peso  
corporal e tamanho e número de músculos a serem tratados, devendo ser também consideradas as orientações do fabricante de cada produto. Cada aplicação deve sempre utilizar a menor dose eficaz estimada. Nos casos que os objetivos não forem alcançados, novas aplicações podem ser consideradas, respeitando o intervalo mínimo de 3 a 4 meses entre cada dose. Tais medidas são indispensáveis para minimizar o risco de falha terapêutica em decorrência da formação de anticorpos<sup>78</sup> .  
A duração do efeito é variável. Recomenda-se a reavaliação em 4 a 6 semanas após cada aplicação, sendo as demais reavaliações realizadas a critério médico. Após a aplicação local, a TBA difunde-se pelo tecido muscular e por outros tecidos. Seu efeito concentra-se próximo ao ponto de aplicação e diminui ao se afastar dele. Pode ocorrer difusão para músculos vizinhos, especialmente quando são utilizadas doses ou volumes elevados. O efeito distante da TBA é preocupante, pois pode resultar em efeitos adversos sistêmicos. Os efeitos adversos sistêmicos são devidos ao efeito da TBA nos tecidos distantes da administração local.<sup>78,79</sup>  
Em relação às técnicas de aplicação, são feitas as seguintes recomendações<sup>80–82</sup> :  
- Utilizar sempre solução salina sem conservantes (soro fisiológico a 0,9%) para a reconstituição;  
- evitar o borbulhamento ou a agitação do conteúdo do frasco durante a reconstituição e recuperação do medicamento  
para a seringa de injeção;  
- para a localização correta dos músculos, é possível utilizar eletroestimulação ou eletromiografia, de modo a posicionar com precisão a agulha, especialmente nos casos de difícil discriminação, como músculos do antebraço em obesos e crianças, por exemplo;  
- em músculos grandes ou distais, preconiza-se a aplicação em pelo menos dois pontos;  
- pode-se injetar mais de um músculo no mesmo procedimento, desde que as doses de medicamentos disponíveis sejam  
- adequadas para cada músculo injetado;  
- a critério médico, os procedimentos podem ser realizados sob sedação ou anestesia geral, principalmente em crianças.  
- Com relação à manutenção da resposta terapêutica em longo prazo, preconiza-se:  
- Utilizar a menor dose eficaz estimada em cada aplicação;  
- respeitar o intervalo mínimo de 3 a 4 meses entre aplicações;  
- prolongar o intervalo entre as reaplicações o máximo possível.

---

<!-- METADADOS: doenca: Espasticidade | secao: **6.2.3.  Critérios de interrupção** -->
A duração do tratamento não é pré-determinada, podendo ser interrompido por qualquer uma das situações relacionadas no item “Critérios de exclusão”. Após um número imprevisível de aplicações, o efeito da TBA pode se tornar mais fraco ou ausente, mesmo com o aumento de dose. Esses casos levam à suspeita de formação de anticorpos. As preparações de TBA disponíveis contêm proteínas não humanas, estas podem atuar como antígenos e induzir a formação de anticorpos que neutralizam o seu efeito farmacêutico<sup>83</sup> .  
Um teste clínico simples e acessível pode ser feito, o teste de anticorpos no músculo frontal, durante o qual injetam-se TBA no músculo frontal, três centímetros acima da comissuralateral de um dos olhos. Após 1 a 3 semanas em avaliação médica, pede-se para o paciente elevar as sobrancelhas e, caso o músculo injetado apresente movimento similar ao do lado não injetado (ausência de paralisia ou fraqueza muscular), considera-se falha no efeito da TBA<sup>78,84</sup> .  
O tratamento também pode ser interrompido em caso de eventos adversos, sendo geralmente de três tipos os de maiores relevância clínica<sup>83</sup> :  
- Efeitos adversos relacionados aos efeitos esperados da TBA, por exemplo, fraqueza muscular local excessiva;  
- efeitos adversos devido à disseminação da TBA para os músculos adjacentes ao músculo alvo da injeção e que não eram  
- alvo da intervenção;  
- efeitos adversos devido à distribuição sistêmica da toxina.

---

<!-- METADADOS: doenca: Espasticidade | secao: **7. MONITORAMENTO** -->
O monitoramento deve ser realizado por meio do registro de informações relevantes sobre o tratamento, incluindo informações sobre o diagnóstico, grupos musculares abordados, doses utilizadas, avaliação de tônus e registro de eventos adversos. Com o uso de doses adequadas e respeitando a técnica correta de aplicação por profissionais credenciados e experientes, a TBA é um tratamento seguro. O paciente ou o seu responsável deve ser orientado a procurar o médico imediatamente se qualquer efeito indesejável surgir.  
O uso de TBA pode ser necessário por vários anos, sendo necessário gerenciamento da evolução clínica e física dos pacientes nos períodos entre as administrações, o que pode reduzir a frequência das aplicações de TBA, reduzindo também a probabilidade de falta de resposta secundária, devendo-se observar o prazo para repetição de aplicações, que não deve ser inferior a 3 meses<sup>9</sup> .  
O monitoramento do paciente após administração de TBA é tão importante quanto à administração do medicamento e deve envolver os diversos profissionais de saúde que avaliam o paciente antes e durante a administração. O monitoramento do paciente após injeção de TBA deve fazer parte do plano terapêutico dos pacientes<sup>9</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração, o monitoramento do tratamento, a verificação periódica das doses prescritas e dispensadas bem como a adequação de uso dos medicamentos.  
Sempre que disponível, a confirmação do diagnóstico, o tratamento e o acompanhamento dos pacientes com espasticidade devem ser realizados em serviços especializados. Se administrada a TBA, essa aplicação deve ser realizada por profissionais capacitados para tal. A equipe multidisciplinar deve incluir, sempre que possível, médico(s) com especialização em medicina física e reabilitação, fisiatria, neurologia, neurocirurgia, neuropediatria ou ortopedia. O objetivo dos serviços especializados é viabilizar uma estrutura de apoio no SUS para o atendimento dos pacientes de forma a prestar um serviço com maior potencial de benefício com a aplicação da TBA e também possibilitar o acompanhamento da resposta terapêutica.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Espasticidade | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Espasticidade | secao: **10. REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. Trompetto C, Marinelli L, Mori L, Pelosin E, Currà A, Molfetta L, et al. Pathophysiology of Spasticity: Implications  
for Neurorehabilitation. Biomed Res Int. 2014;2014:354906.  
2. Dressler D, Bhidayasiri R, Bohlega S, Chana P, Chien HF, Chung TM, et al. Defining spasticity: a new approach considering current movement disorders terminology and botulinum toxin therapy. J Neurol. 2018;265(4):856–62.  
3. Petek Balci B. Spasticity Measurement. Arch Meuropychiatry. 2018;55(Supplement 1):S49–53.  
4. Francisco GE, Wissel J, Platz T, Li S. Post-Stroke Spasticity. In: Clinical Pathways in Stroke Rehabilitation. Cham: Springer International Publishing; 2021. p. 149–73.  
5. Baunsgaard CB, Nissen U V., Christensen KB, Biering-Sørensen F. Modified Ashworth scale and spasm frequency score in spinal cord injury: Reliability and correlation. Spinal Cord. 2016;54(9):702–8.  
6. Martin A, Abogunrin S, Kurth H, Dinet J. Epidemiological, humanistic, and economic burden of illness of lower limb spasticity in adults: A systematic review. Neuropsychiatr Dis Treat. 2014;10:111–22.  
7. Fernández Ó, Costa-Frossard L, Martínez-Ginés M, Montero P, Prieto JM, Ramió L. The Broad Concept of “Spasticity-Plus Syndrome” in Multiple Sclerosis: A Possible New Concept in the Management of Multiple Sclerosis Symptoms. Front Neurol. 2020;11(March):1–8.  
8. Ferré F, De Oliveira G, De Queiroz M, Gonçalves F. Sala de Situação aberta com dados administrativos para gestão de Protocolos Clínicos e Diretrizes Terapêuticas de tecnologias providas pelo SUS. In: Anais Principais do Simpósio Brasileiro de Computação Aplicada à Saúde (SBCAS 2020). Sociedade Brasileira de Computação - SBC; 2020. p. 392–403.  
9. Royal College of Physicians, Royal College of Physicians British; Society of Rehabilitation Medicine; The Chartered Society of Physiotherapy; Association of Chartered Physiotherapists in Neurology; Royal College of Occupational Therapists. Spasticity in adults: management using botulinum toxin. 2<sup>o</sup> ed. London: RCP; 2018.  
10. Ghai A, Garg N, Hooda S, Gupta T. Spasticity - Pathogenesis, prevention and treatment strategies. Saudi J Anaesth. 2013;7(4):453–60.  
11. Schroeder AS, Berweck S, Dabrowski ER, Heinen F. Spasticity, Dystonia, and Other Movement Disorders: A Comprehensive Treatment Guide. In: Acute Pediatric Neurology. London: Springer London; 2014. p. 339–64.  
12. Lord C, Elsabbagh M, Baird G, Veenstra-Vanderweele J. Autism spectrum disorder. Vol. 392, The Lancet. Lancet Publishing Group; 2018. p. 508–20.  
13. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência eTecnologia. Diretrizes Metodológicas: Sistema GRADE- manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. 2014.  
14. Schünemann H, Brożek J, GordonGuyatt, Oxman A. GRADE Handbook. 2013.  
15. Organização Mundial da Saúde. CID-10 - Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde. 10<sup>o</sup> ed. 2017.  
16. Rivelis Y, Zafar N, Morice K. Spasticity. In: StatPearls [Internet]. 2021.  
17. Haugh A, Pandyan A, Johnson G. A systematic review of the Tardieu Scale for the measurement of spasticity. Disabil Rehabil. 2006;28(15):899–907.  
18. Synnot A, Chau M, Pitt V, O’Connor D, Gruen RL, Wasiak J, et al. Interventions for managing skeletal muscle spasticity following traumatic brain injury. Cochrane Database Syst Rev. 2017;2017(11).  
19. National Institute for Health and Care Excellence (NICE). Spasticity in under 19s: management | NICE. 2016. 1–41 p.  
20. Harb, A; Kishner S. Modified Ashworth Scale. In: StatPearls [Internet]. StatPearls Publishing; 2021.  
21. Stroke Foundation. Clinical Guidelines for Stroke Management 2017. Chapter 6 of 8: Managing Complications. 2017. 1–168 p.  
22. Rekand T. Clinical assessment and management of spasticity: A review. Acta Neurol Scand. 2010;122(SUPPL. 190):62–6.  
23. Grigoriu AI, Dinomais M, Rémy-Néris O, Brochard S. Impact of Injection-Guiding Techniques on the Effectiveness of Botulinum Toxin for the Treatment of Focal Spasticity and Dystonia: A Systematic Review. Arch Phys Med Rehabil. 2015;96(11):2067-2078.e1.  
24. Ward AB. Long-term modification of spasticity. J Rehabil Med. maio de 2003;(41 Suppl):60–5.  
25. World Health Organization (WHO). International Classification of Functioning Disability and Health (ICF). [Internet]. 2001 [citado 11 de fevereiro de 2021]. Available at: https://www.who.int/standards/classifications/internationalclassification-of-functioning-disability-and-health  
26. Royal College of Physicians. Spasticity in adults: management using botulinum toxin. 2<sup>o</sup> ed. London: RCP; 2018.  
27. National Institute for Health and Care Excellence (NICE). Cerebral palsy in adults. 2019. 1–65 p.  
28. Comi G, Solari A, Leocani L, Centonze D, Otero‐Romero S, Amadeo R, et al. Italian consensus on treatment of spasticity in multiple sclerosis. Eur J Neurol. março de 2020;27(3):445–53.  
29. National Health Service in Scotland. Quality Improvement Scotland. Management of patients with stroke: rehabilitation, prevention and management of complications, and discharge planning. Scottish Intercollegiate Guidelines Network (SIGN). 2010. 1–108 p.  
30. National Institute for Health and Care Excellence (NICE). Multiple sclerosis in adults: management. NICE Clin Guidel.  
31. Simpson DM, Hallett M, Ashman EJ, Comella CL, Green MW, Gronseth GS, et al. Practice guideline update summary: Botulinum neurotoxin for the treatment of blepharospasm, cervical dystonia, adult spasticity, and headache Report of the Guideline Development Subcommittee of the American Academy of Neurology. Neurology. 2016;86(19):1818–26.  
32. Lim SM, Yoo J, Lee E, Kim HJ, Shin S, Han G, et al. Acupuncture for Spasticity after Stroke: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. Evidence-Based Complement Altern Med. 2015;2015:1–12.  
33. Mills PB, Finlayson H, Sudol M, O’Connor R. Systematic review of adjunct therapies to improve outcomes following botulinum toxin injection for treatment of limb spasticity. Clin Rehabil. junho de 2016;30(6):537–48.  
34. Stein C, Fritsch CG, Robinson C, Sbruzzi G, Plentz RDM. Effects of Electrical Stimulation in Spastic Muscles After Stroke. Stroke. agosto de 2015;46(8):2197–205.  
35. Santamato A, Micello MF, Panza F, Fortunato F, Picelli A, Smania N, et al. Adhesive taping vs. daily manual muscle stretching and splinting after botulinum toxin type A injection for wrist and fingers spastic overactivity in stroke patients: a randomized controlled trial. Clin Rehabil. janeiro de 2015;29(1):50–8.  
36. Wilkenfeld AJL. Review of electrical stimulation, botulinum toxin, and their combination for spastic drop foot. J Rehabil Res Dev. 2013;50(3):315.  
37. Awosika OO, Matthews S, Staggs EJ, Boyne P, Song X, Rizik BA, et al. Backward locomotor treadmill training combined with transcutaneous spinal direct current stimulation in stroke: a randomized pilot feasibility and safety study. Brain Commun. 2020;2(1):fcaa045.  
38. Sandler EB, Condon K, Field-Fote EC. Efficacy of Transcutaneous Spinal Stimulation versus Whole Body Vibration for Spasticity Reduction in Persons with Spinal Cord Injury. J Clin Med. 24 de julho de 2021;10(15).  
39. Liu Z, Dong S, Zhong S, Huang F, Zhang C, Zhou Y, et al. The effect of combined transcranial pulsed current stimulation and transcutaneous electrical nerve stimulation on lower limb spasticity in children with spastic cerebral palsy: a randomized and controlled clinical study. BMC Pediatr. 2021;21(1):141.  
40. Estes S, Zarkou A, Hope JM, Suri C, Field-Fote EC. Combined Transcutaneous Spinal Stimulation and Locomotor Training to Improve Walking Function and Reduce Spasticity in Subacute Spinal Cord Injury: A Randomized Study of Clinical Feasibility and Efficacy. J Clin Med. 11 de março de 2021;10(6).  
41. Hesse S, Reiter F, Konrad M, Jahnke MT. Botulinum toxin type A and short-term electrical stimulation in the treatment of upper limb flexor spasticity after stroke: a randomized, double-blind, placebo-controlled trial. Clin Rehabil. outubro de 1998;12(5):381–8.  
42. Adrienne C, Manigandan C. Inpatient occupational therapists hand-splinting practice for clients with stroke: A crosssectional survey from Ireland. J Neurosci Rural Pract. julho de 2011;02(02):141–9.  
43. Andringa A, van de Port I, Meijer J-W. Long-Term Use of a Static Hand-Wrist Orthosis in Chronic Stroke Patients: A Pilot Study. Stroke Res Treat. 2013;2013:1–5.  
44. Moseley AM, Hassett LM, Leung J, Clare JS, Herbert RD, Harvey LA. Serial casting versus positioning for the treatment of elbow contractures in adults with traumatic brain injury: a randomized controlled trial. Clin Rehabil. maio de 2008;22(5):406–17.  
45. Baricich A, Carda S, Bertoni M, Maderna L, Cisari C. A single-blinded, randomized pilot study of botulinum toxin type A combined with non-pharmacological treatment for spastic foot. J Rehabil Med. 2008;40(10):870–2.  
46. Carda S, Molteni F. Taping versus electrical stimulation after botulinum toxin type A injection for wrist and finger spasticity. A case—control study. Clin Rehabil. setembro de 2005;19(6):621–6.  
47. Preissner KS. The effects of serial casting on spasticity: a literature review. Occup Ther Heal care. 2002;14(2):99–106.  
48. Westberry DE, Davids JR, Jacobs JM, Pugh LI, Tanner SL. Effectiveness of Serial Stretch Casting for Resistant or Recurrent Knee Flexion Contractures Following Hamstring Lengthening in Children With Cerebral Palsy. J Pediatr Orthop. janeiro de 2006;26(1):109–14.  
49. Glanzman AM, Kim H, Swaminathan K, Beck T. Efficacy of botulinum toxin A, serial casting, and combined treatment for spastic equinus: a retrospective analysis. Dev Med Child Neurol. dezembro de 2004;46(12):807–11.  
50. Booth MY, Yates CC, Edgar TS, Bandy WD. Serial casting vs combined intervention with botulinum toxin A and serial casting in the treatment of spastic equinus in children. Pediatr Phys Ther. 2003;15(4):216–20.  
51. Katalinic OM, Harvey LA, Herbert RD, Moseley AM, Lannin NA, Schurr K. Stretch for the treatment and prevention of contractures. In: Katalinic OM, organizador. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2010.  
52. Harvey LA, Katalinic OM, Herbert RD, Moseley AM, Lannin NA, Schurr K. Stretch for the treatment and prevention of contractures. Cochrane Database Syst Rev. janeiro de 2017;2017(2).  
53. Hugos CL, Bourdette D, Chen Y, Chen Z, Cameron M. A group-delivered self-management program reduces spasticity in people with multiple sclerosis: A randomized, controlled pilot trial. Mult Scler J - Exp Transl Clin. março de 2017;3(1):205521731769999.  
54. National Institute for Health and Care Excellence. Selective dorsal rhizotomy for spasticity in cerebral palsy. nterventional procedures guidance [IPG373]. 2010. 1–7 p.  
55. Lumsden DE, Crowe B, Basu A, Amin S, Devlin A, DeAlwis Y, et al. Pharmacological management of abnormal tone and movement in cerebral palsy. Arch Dis Child. 2019;104(8):775–80.  
56. Otero-Romero S, Sastre-Garriga J, Comi G, Hartung H-P, Soelberg Sørensen P, Thompson AJ, et al. Pharmacological management of spasticity in multiple sclerosis: Systematic review and consensus paper. Mult Scler. 2016;22(11):1386–96.  
57. Taricco M, Adone R, Pagliacci C, Telaro E. Pharmacological interventions for spasticity following spinal cord injury. Cochrane database Syst Rev. 2000;(2):CD001131.  
58. Lindsay C, Kouzouna A, Simcox C, Pandyan AD. Pharmacological interventions other than botulinum toxin for spasticity after stroke. Cochrane database Syst Rev. 6 de outubro de 2016;10:CD010362.  
59. Montané E, Vallano A, Laporte JR. Oral antispastic drugs in nonprogressive neurologic diseases: a systematic review. Neurology. 26 de outubro de 2004;63(8):1357–63.  
60. Wade DT, Hewer RL. Functional abilities after stroke: measurement, natural history and prognosis. J Neurol Neurosurg Psychiatry. fevereiro de 1987;50(2):177–82.  
61. D’Souza RS, Warner NS. Phenol Nerve Block. StatPearls. 2021.  
62. Gündüz S, Kalyon TA, Dursun H, Möhür H, Bilgiç F. Peripheral nerve block with phenol to treat spasticity in spinal cord injured patients. Paraplegia. novembro de 1992;30(11):808–11.  
63. Botte MJ, Abrams RA, Bodine-Fowler SC. Treatment of acquired muscle spasticity using phenol peripheral nerve blocks. Orthopedics. fevereiro de 1995;18(2):151–9.  
64. Viel E, Pellas F, Ripart J, Pélissier J, Eledjam J-J. Peripheral neurolytic blocks and spasticity. Ann Fr Anesth Reanim. junho de 2005;24(6):667–72.  
65. Garland DE, Lucie RS, Waters RL. Current uses of open phenol nerve block for adult acquired spasticity. Clin Orthop Relat Res. maio de 1982;(165):217–22.  
66. van Kuijk AA, Geurts ACH, Bevaart BJW, van Limbeek J. Treatment of upper extremity spasticity in stroke patients  
by focal neuronal or neuromuscular blockade: a systematic review of the literature. J Rehabil Med. março de 2002;34(2):51–61.  
67. Palazón-García R, Benavente-Valdepeñas AM. Botulinum Toxin: From Poison to Possible Treatment for Spasticity in Spinal Cord Injury. Int J Mol Sci. maio de 2021;22(9).  
68. Ferrari A. Pharmacological differences and clinical implications of various botulinum toxin preparations: a critical appraisal. Funct Neurol. 2018;33(1):7.  
69. Erbguth FJ. From poison to remedy: the chequered history of botulinum toxin. J Neural Transm. 2008;115(4):559–65.  
70. Bellows S, Jankovic J. Immunogenicity Associated with Botulinum Toxin Treatment. Toxins (Basel). 2019;11(9).  
71. Naumann M, Boo LM, Ackerman AH, Gallagher CJ. Immunogenicity of botulinum toxins. J Neural Transm. fevereiro de 2013;120(2):275–90.  
72. Phadke CP, Balasubramanian CK, Holz A, Davidson C, Ismail F, Boulias C. Adverse Clinical Effects of Botulinum Toxin Intramuscular Injections for Spasticity. Can J Neurol Sci. março de 2016;43(2):298–310.  
73. Hornik A, Gruener G, Jay WM. Adverse Reactions from Botulinum Toxin Administration. Neuro-Ophthalmology. 27 de fevereiro de 2010;34(1):6–13.  
74. Bakheit AMO. The possible adverse effects of intramuscular botulinum toxin injections and their management. Curr Drug Saf. agosto de 2006;1(3):271–9.  
75. Sławek J, Bogucki A, Bonikowski M, Car H, Dec-Ćwiek M, Druzdz A, et al. Botulinum toxin type-A preparations are not the same medications - clinical studies (Part 2). Neurol Neurochir Pol. 2021;55(2):141–57.  
76. Rupp D, Nicholson G, Canty D, Wang J, Rh C, Le L, et al. Activity Compared to IncobotulinumtoxinA , In Vitro and In Vivo Assays.  
77. Brin MF, James C, Maltman J. Botulinum toxin type A products are not interchangeable: A review of the evidence. Biol Targets Ther. 2014;8:227–41.  
78. Moore AP, Naumann M. General and clinical aspects of treatment with botulinum toxin. Handbook of botulinum toxin. In: Moore A, Naumann M, organizadores. 2nd ed New Jersey: Wiley-Blackwell; 2003. p. 28–75.  
79. Dressler D, Benecke R. Pharmacology of therapeutic botulinum toxin preparations. Disabil Rehabil. dezembro de 2007;29(23):1761–8.  
80. Gracies JM, Hefter H, Simpson DP, Moore AP. Handbook of botulinum toxin treatment. In: Moore A, Naumann M, organizadores. Handbook of botulinum toxin treatment. 2nd ed New Jersey: Wiley-Blackwell; 2003. p. 219–71.  
81. Pathak MS, Nguyen HT, Graham HK, Moore AP. Management of spasticity in adults: Practical application of botulinum toxin. In: European Journal of Neurology. Eur J Neurol; 2006. p. 42–50.  
82. Ward AB. Spasticity treatment with botulinum toxins. J Neural Transm. abril de 2008;115(4):607–16.  
83. Samizadeh S, De Boulle K. Botulinum neurotoxin formulations: overcoming the confusion. Clin Cosmet Investig Dermatol. maio de 2018;11:273.  
84. Li S, Francisco GE. The Use of Botulinum Toxin for Treatment of Spasticity. In 2019. p. 127–46.

---

<!-- METADADOS: doenca: Espasticidade | secao: TOXINA BOTULÍNICA TIPO A -->
Eu, ________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente  
sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento toxina botulínica tipo A, indicado para o tratamento da espasticidade.  
Os termos médicos foram explicados e todas as minhas dúvidas foram esclarecidas pelo médico _________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora da atividade funcional (locomoção, atividades da vida diária);  
- prevenção de contratura e deformidades nas articulações (juntas);  
- diminuição da dor;  
- facilitação no uso de órteses e na realização dos cuidados de higiene;  
- diminuição da frequência e gravidade dos espasmos;  
- redução do uso de medicamentos antiespásticos;  
- redução do número de procedimentos de reabilitação.  
Fui também claramente informado(a) a respeito das contraindicações, dos potenciais efeitos adversos e dos riscos a seguir:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez; portanto, caso engravide, devo avisar imediatamente ao meu médico;  
- o principal efeito desagradável é dor no local de aplicação da injeção;  
- os efeitos adversos são pouco frequentes. Estima-se que a cada 100 pacientes que recebem o medicamento, apenas três terão algum tipo de reação. Já foram relatados fraqueza, náusea, disfagia, coceira, dor de cabeça, alergias na pele, malestar geral, febre e dor no corpo.  
Fui também informado(a) que este medicamento não tem por objetivo curar a doença que originou a espasticidade. Conforme a marca comercial utilizada, a dose da toxina botulínica pode ser ajustada, e devo procurar orientação do médico ou farmacêutico em caso de dúvida.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo, ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de eu desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.    (    ) Sim     (    ) Não  
Local:                                                             Data:  
<!-- Start of picture text -->
Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se  
encontra o medicamento preconizado neste Protocolo.  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Espasticidade | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Espasticidade contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão). O documento tem como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O painel de especialistas incluiu médicos das áreas de neurologia e fisiatria, além de representantes do Ministério da Saúde, universidades, hospitais de excelência e sociedades médicas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
O processo de atualização do PCDT de espasticidade se iniciou com a reunião para delimitação do escopo de atualização do referido documento, realizada virtualmente com o uso de videoconferência, no dia 21 de junho de 2021. A dinâmica da reunião incluiu a discussão de cada seção do PCDT vigente (Portaria Conjunta SAS-SCTIE/MS nº 2/2017), bem como das condutas clínicas e das tecnologias que poderiam ser priorizadas para que fosse realizada revisão sistemática das evidências com ou sem formulação de recomendações – sendo norteada por uma revisão prévia de diretrizes internacionais e revisões sistemáticas recentemente publicadas. Na reunião, foi definido que seria elaborada uma síntese de evidências sobre a toxina botulínica tipo A (TBA) para diferentes faixas etárias (pacientes adultos e crianças), por ser o medicamento preconizado no PCDT vigente, além de uma avaliação para incorporação do medicamento baclofeno.  
Para o baclofeno, foi avaliada a possibilidade de incorporação do medicamento apenas por administração oral e para adultos, considerando a indisponibilidade da especialidade farmacêutica para administração intratecal no Brasil e o fato da indicação em bula da apresentação oral não envolver crianças. No entanto, no presente documento são apresentados os resultados da revisão sistemática das evidências sobre o uso de baclofeno via oral tanto em adultos quanto crianças.  
Foram estabelecidas três perguntas de pesquisa a serem respondidas: a) atualização da questão clínica sobre TBA em adultos; b) atualização da questão clínica sobre TBA em crianças; c) questão clínica sobre o uso de baclofeno via oral para adultos e crianças.

---

<!-- METADADOS: doenca: Espasticidade | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor deste Protocolo foi composto por especialistas que atuaram sob a coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O painel de especialistas incluiu médicos da neurologia, psiquiatria e neurocirurgia, além de representantes do Ministério da Saúde, universidades, hospitais e sociedades médicas.  
**Declaração e Encaminhamento de Conflito de Interesses**  
Todos os membros do Grupo Elaborador declararam seus conflitos de interesses, utilizando um modelo padrão de Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algu<br>abaixo?|m dos benefícios|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada<br>ou prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser<br>afetados?|(   ) Sim<br>(   ) Não|  
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá|(   ) Sim|
|---|---|
|escrever e que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa|(   ) Sim|
|afetar sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados|(   ) Sim|
|acima?|(   ) Não|  
O resumo dos conflitos de interesses dos membros do Grupo Elaborador está no **Quadro B** .  
**Quadro B -** Declaração de conflitos de interesse dos membros do Grupo Elaborador do PCDT  
|**Participante**||**Conflitos de interesses declarados**|**Decisão tomada**|
|---|---|---|---|
||**Questão**|**Descrição geral**||
|Andréa da Silva Dourado|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Bettina Menezes dos Santos|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Bruna Bento dos Santos|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Cinara Stein|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Daniela Oliveira de Melo|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Daniele Yukari Kawakami|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Debora Dalmas Gräf|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Eduardo Freire de Oliveira|1a, 1b, 5a,<br>6|Declarou possuir uma clínica de reabilitação.|Declarar e participar|
|Elene Paltrinieri Nardi|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Emilly Kelly Silva Monteiro|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Gláucia Somensi de Oliveira-<br>Alonso|1f|Declarou participação em evento patrocinado<br>por indústria.|Declarar e participar|
|Karlyse Claudino Belli|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Maicon Falavigna|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Maria Matilde de Mello<br>Sposito|1a,5c, 5e|Declarou realização de palestras e conferências<br>sobre o tema e participação em grupo ligado à<br>indústria farmacêutica|Declarar e participar|
|Simone Consuelo de Amorim|-|Declarou não possuir conflitos de interesse.|Declarar e participar|
|Verônica Colpani|-|Declarou não possuir conflitos de interesse.|Declarar e participar|

---

<!-- METADADOS: doenca: Espasticidade | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Espasticidade foi apresentada na 95ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em novembro de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Vigilância Sanitária (SVS) e Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria Especial de Saúde Indígena (SESAI). O PCDT foi aprovado para avaliação pelo Plenário da Conitec.  
**4. Busca da evidência e recomendações**  
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Revisão Sistemática e meta-análise do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dosresultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>1,2</sup> .  
Foram conduzidas revisões sistemáticas sobre o uso de TBA e baclofeno por via oral no tratamento da espasticidade. Dessa forma, foram desenvolvidas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT) para cada questão PICO, sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente do da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão ( **Quadro C** ).  
**Quadro C -** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado.|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
|**Muito baixo**|A confiança na estimativa de efeito é<br>muito limitada.<br>Há importante grau de incerteza nos<br>achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de  
decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Na sequência, são apresentadas para cada uma das questões, os métodos e resultados das buscas, as recomendações do painel de especialistas, recomendações de outras diretrizes, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Espasticidade | secao: **QUESTÃO 1: A TOXINA BOTULÍNICA DO TIPO A (TBA) É EFICAZ E SEGURA PARA O TRATAMENTO DA ESPASTICIDADE EM ADULTOS?** -->
**<u>Recomendação:</u>** A toxina botulínica do tipo A (TBA) é recomendada para o tratamento da espasticidade em adultos (recomendação não graduada por já ser preconizado no PCDT de espasticidade publicado na Portaria Conjunta SAS-SCTIE/MS nº2/2017).  
Diante dos resultados de uma busca exploratória por revisões sistemáticas que tenham avaliado a TBA no tratamento de espasticidade, optou-se por realizar nova revisão sistemática considerando que as disponíveis avaliavam somente membros  
inferiores ou superiores ou ainda que avaliavam apenas pacientes com determinada condição de base, como pós acidente vascular cerebral ou esclerose múltipla, por exemplo.  
Assim, a estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos diagnosticados com espasticidade secundária a qualquer causa.  
**Intervenção:** Toxina botulínica do tipo A.  
**Comparador:** Placebo ou outras alternativas disponíveis no SUS.  
**Desfechos:** Redução do escore da escala de Ashworth (EA), redução da dor associada à espasticidade, melhora da  
qualidade de vida relacionada à saúde (utilizando escala validada) e frequência de eventos adversos.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Métodos e resultados da busca:** -->
Foram realizadas buscas sistematizadas da literatura nas bases de dados MEDLINE (via PubMed), Cochrane Library, EMBASE, LILACS (via BVS) para a identificação de estudos clínicos randomizados. A estratégia combinou a população relacionada à espasticidade (hipertonia muscular, paralisia cerebral, acidente vascular cerebral (AVC), lesões da medula espinhal) e a toxina botulínica. Foram também conduzidas buscas na literatura cinzenta ( _Open Grey_ ) e buscas manuais nas listas de referências dos estudos relevantes, de acordo com o estabelecido na revisão original. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas foram conduzidas em 11/08/2021. As estratégias de busca para cada base estão descritas no **Quadro D** .  
**Quadro D -** . Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o uso de toxina botulínica do tipo A no tratamento de espasticidade em adultos  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
|MEDLINE (via Pubmed)|(((((((((("Muscle Hypertonia"[Mesh]) OR "Muscle Spasticity"[Mesh]OR (Spasticity,<br>Muscle) OR (Spastic Clasp-Knife Spasticity) OR (Clasp Knife Spasticity) OR<br>(Spasticity,<br>Clasp-Knife)<br>OR<br>(spastic*<br>or<br>high<br>tone)))<br>OR<br>(("Multiple<br>Sclerosis"[Mesh] OR (Sclerosis, Multiple) OR (Sclerosis, Disseminated) OR<br>(Disseminated Sclerosis) OR (MS (Multiple Sclerosis)) OR (Multiple Sclerosis, Acute<br>Fulminating)))) OR (("Cerebral Palsy"[Mesh] OR (CP (Cerebral Palsy)) OR (Cerebral<br>Palsy, Dystonic-Rigid) OR (Cerebral Palsies, Dystonic-Rigid) OR (Cerebral Palsy,<br>Dystonic Rigid) OR (Dystonic-Rigid Cerebral Palsies) OR (Dystonic-Rigid Cerebral<br>Palsy) OR (Cerebral Palsy, Mixed) OR (Mixed Cerebral Palsies) OR (Mixed Cerebral<br>Palsy) OR (Cerebral Palsy, Monoplegic, Infantile) OR (Monoplegic Infantile Cerebral<br>Palsy) OR (Infantile Cerebral Palsy, Monoplegic) OR (Cerebral Palsy, Quadriplegic,<br>Infantile) OR (Quadriplegic Infantile Cerebral Palsy) OR (Infantile Cerebral Palsy,<br>Quadriplegic) OR (Cerebral Palsy, Rolandic Type) OR (Rolandic Type Cerebral Palsy)<br>OR (Cerebral Palsy, Congenital) OR (Congenital Cerebral Palsy) OR (Little Disease)<br>OR (Little's Disease) OR ([Cerebral Palsy) OR (Diplegias, Spastic) OR (Spastic<br>Diplegias) OR (Diplegia, Spastic) OR (Monoplegic Cerebral Palsy) OR (Cerebral<br>Palsies, Monoplegic) OR (Cerebral Palsy, Monoplegic) OR (Monoplegic Cerebral<br>Palsies) OR (Cerebral Palsy, Athetoid) OR (Athetoid Cerebral Palsy) OR (Cerebral<br>Palsies, Athetoid) OR (Cerebral Palsy, Dyskinetic) OR (Cerebral Palsies, Dyskinetic)<br>OR (Dyskinetic Cerebral Palsy) OR (Cerebral Palsy, Atonic) OR (Atonic Cerebral|  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
||Palsy) OR (Cerebral Palsy, Hypotonic) OR (Hypotonic Cerebral Palsies) OR<br>(Hypotonic Cerebral Palsy) OR (Cerebral Palsy, Diplegic, Infantile) OR (Diplegic<br>Infantile Cerebral Palsy) OR (Infantile Cerebral Palsy, Diplegic) OR (Cerebral Palsy,<br>Spastic) OR (Spastic Cerebral Palsies) OR (Spastic Cerebral Palsy)))) OR<br>(("Stroke"[Mesh] OR (Strokes) OR (Cerebrovascular Accident) OR (Cerebrovascular<br>Accidents) OR (CVA (Cerebrovascular Accident)) OR (CVAs (Cerebrovascular<br>Accident)) OR (Cerebrovascular Apoplexy) OR (Apoplexy, Cerebrovascular) OR<br>(Vascular Accident, Brain) OR (Brain Vascular Accident) OR (Brain Vascular<br>Accidents) OR (Vascular Accidents, Brain) OR (Cerebrovascular Stroke) OR<br>(Cerebrovascular<br>Strokes)<br>OR<br>(Stroke,<br>Cerebrovascular)<br>OR<br>(Strokes,<br>Cerebrovascular) OR (Apoplexy) OR (Cerebral Stroke) OR (Cerebral Strokes) OR<br>(Stroke, Cerebral) OR (Strokes, Cerebral) OR (Stroke, Acute) OR (Acute Stroke) OR<br>(Acute Strokes) OR (Strokes, Acute) OR (Cerebrovascular Accident, Acute) OR<br>(Acute Cerebrovascular Accident) OR (Acute Cerebrovascular Accidents) OR<br>(Cerebrovascular Accidents, Acute))))) OR ((("Spinal Cord Injuries"[Mesh] OR<br>(Spinal Cord Trauma) OR (Cord Trauma, Spinal) OR (Cord Traumas, Spinal) OR<br>(Spinal Cord Traumas) OR (Trauma, Spinal Cord) OR (Traumas, Spinal Cord) OR<br>(Myelopathy,<br>Traumatic)<br>OR<br>(Myelopathies,<br>Traumatic)<br>OR<br>(Traumatic<br>Myelopathies) OR (Traumatic Myelopathy) OR (Injuries, Spinal Cord) OR (Cord<br>Injuries, Spinal) OR (Cord Injury, Spinal) OR (Injury, Spinal Cord) OR (Spinal Cord<br>Injury) OR (Spinal Cord Transection) OR (Cord Transection, Spinal) OR (Cord<br>Transections, Spinal) OR (Spinal Cord Transections) OR (Transection, Spinal Cord)<br>OR (Transections, Spinal Cord) OR (Spinal Cord Laceration) OR (Cord Laceration,<br>Spinal) OR (Cord Lacerations, Spinal) OR (Laceration, Spinal Cord) OR (Lacerations,<br>Spinal Cord) OR (Spinal Cord Lacerations) OR (Post-Traumatic Myelopathy) OR<br>(Myelopathies, Post-Traumatic) OR (Myelopathy, Post-Traumatic) OR (Post<br>Traumatic Myelopathy) OR (Post-Traumatic Myelopathies) OR (Spinal Cord<br>Contusion) OR (Contusion, Spinal Cord) OR (Contusions, Spinal Cord) OR (Cord<br>Contusion, Spinal) OR (Cord Contusions, Spinal) OR (Spinal Cord Contusions)))))<br>OR (("Brain Injuries, Traumatic"[Mesh] OR (Brain Injury, Traumatic) OR (Traumatic<br>Brain Injuries) OR (Trauma, Brain) OR (Brain Trauma) OR (Brain Traumas) OR<br>(Traumas, Brain) OR (TBI (Traumatic Brain Injury)) OR (Encephalopathy, Traumatic)<br>OR (Encephalopathies, Traumatic) OR (Traumatic Encephalopathies) OR (Injury,<br>Brain, Traumatic) OR (Traumatic Encephalopathy) OR (TBIs (Traumatic Brain<br>Injuries)) OR (TBI (Traumatic Brain Injuries)) OR (Traumatic Brain Injury) OR<br>(Apoplexy)))) AND ("Botulinum Toxins"[Mesh] OR (Toxins, Botulinum) OR<br>(Botulinum Neurotoxins) OR (Neurotoxins, Botulinum) OR (Botulinum Toxin) OR<br>(Toxin, Botulinum) OR (Clostridium botulinum Toxins) OR (Toxins, Clostridium<br>botulinum) OR (Botulinum Neurotoxin) OR (Neurotoxin, Botulinum) OR (Botulin)))|  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
||AND ((randomized controlled trial [pt] OR controlled clinical trial [pt] OR randomized<br>[tiab] OR placebo [tiab] OR clinical trials as topic [mesh: noexp] OR randomly [tiab]<br>OR trial [ti]) NOT (animals [mh] NOT humans [mh]))|
|EMBASE|('spasticity'/exp OR 'muscle hypertonia'/exp OR 'muscle rigidity'/exp OR 'clasp<br>knife' OR 'muscle spasticity' OR 'multiple sclerosis'/exp OR 'cerebral palsy'/exp<br>OR 'cerebrovascular accident'/mj OR 'spinal cord disease'/mj OR 'traumatic brain<br>injury'/exp) AND ('botulinum toxin a'/exp OR 'btxa' OR 'bont a' OR 'bont a ds' OR<br>'bont serotype a' OR 'clostridium botulinum neurotoxin a' OR 'clostridium botulinum<br>neurotoxin type a' OR 'clostridium botulinum type a neurotoxin' OR 'abobotulinum<br>toxin a' OR 'abobotulinumtoxin a' OR 'abobotulinumtoxina' OR 'agn 151607' OR<br>'agn151607' OR 'azzalure' OR 'bocouture' OR 'botox' OR 'botox (100 u) injection' OR<br>'botox (oculinum)' OR 'botox 100e' OR 'botox a' OR 'botox cosmetic' OR 'botulin a'<br>OR 'botulin toxin a' OR 'botulinium a toxin' OR 'botulinum a exotoxin' OR 'botulinum<br>a toxin' OR 'botulinum neurotoxin a' OR 'botulinum neurotoxin type a' OR 'botulinum<br>toxin a' OR 'botulinum toxin type a' OR 'botulinum toxins, type a' OR 'clostridium<br>botulinum a toxin' OR 'clostridium botulinum endotoxin' OR 'clostridium botulinum<br>toxin type a' OR 'daxibotulinum toxin a' OR 'daxibotulinumtoxin a' OR<br>'daxibotulinumtoxina' OR 'dwp 450' OR 'dwp450' OR 'dyslor' OR 'dysport' OR<br>'evabotulinum toxin a' OR 'evabotulinumtoxin a' OR 'evabotulinumtoxina' OR<br>'evosyal'<br>OR<br>'gemibotulinum<br>toxin<br>a'<br>OR<br>'gemibotulinumtoxin<br>a'<br>OR<br>'gemibotulinumtoxina' OR 'incobotulinum toxin a' OR 'incobotulinumtoxin a' OR<br>'incobotulinumtoxina' OR 'jeuveau' OR 'letibotulinum toxin a' OR 'letibotulinumtoxin<br>a' OR 'letibotulinumtoxina' OR 'meditoxin' OR 'mt 10109' OR 'mt10109' OR 'nabota'<br>OR 'nivobotulinum toxin a' OR 'nivobotulinumtoxin a' OR 'nivobotulinumtoxina' OR<br>'nt 201' OR 'nt201' OR 'nuceiva' OR 'oculinum' OR 'onabotulinum toxin a' OR<br>'onabotulinumtoxin a' OR 'onabotulinumtoxina' OR 'onaclostox' OR 'pm 12759' OR<br>'pm12759' OR 'prabotulinum toxin a' OR 'prabotulinumtoxin a' OR 'prabotulinumtoxin<br>a<br>xvfs'<br>OR<br>'prabotulinumtoxina'<br>OR<br>'prabotulinumtoxina<br>xvfs'<br>OR<br>'prabotulinumtoxina-xvfs' OR 'prosigne' OR 'purtox' OR 'qm 1114' OR 'qm1114' OR<br>'relabotulinum toxin a' OR 'relabotulinumtoxin a' OR 'relabotulinumtoxina' OR<br>'reloxin' OR 'rtt 150' OR 'rtt150' OR 'vistabel' OR 'vistabex' OR 'xeomeen' OR 'xeomin')<br>AND ('randomized controlled trial'/exp OR 'controlled trial, randomized' OR<br>'randomised controlled study' OR 'randomised controlled trial' OR 'randomized<br>controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled')<br>AND<br>'randomized controlled trial'/exp OR 'randomized controlled trial' OR 'controlled trial,<br>randomized'/exp OR 'controlled trial, randomized' OR 'randomized':ab,ti OR<br>'placebo':ab,ti OR 'clinical trial (topic)'/exp OR 'clinical trial (topic)' OR<br>'randomly':ab,ti OR 'trial':ti AND'human'/de AND  [embase]/lim NOT ([embase]/lim|  
|**Bases de dados**|**Estrat**|**égia de busca**|
|---|---|---|
||AND [|medline]/lim)|
|Cochrane Library|#1|MeSH descriptor: [Botulinum Toxins] explode all trees|
||#2|(botulinum or botulinium) and (toxin or toxins)|
||#3|botulin*|
||#4|Botox|
||#5|Dysport|
||#6|Prosigne|
||#7|Xeomin|
||#8|OnabotulinumtoxinA|
||#9|AbobotulinumtoxinA|
||#10|IncobotulinumtoxinA|
||#11|(#1 or #2 or #3 or #4 or #5 or #6 or #7 or #8 or #9 or #10)|
||#12|'Muscle Hypertonia'|
||#13|MeSH descriptor: [Muscle Hypertonia] explode all trees|
||#14|MeSH descriptor: [Muscle Spasticity] explode all trees|
||#15|'Muscle Spasticity'|
||#16|spastic*|
||#17|MeSH descriptor: [Multiple Sclerosis] explode all trees|
||#18|Multiple Sclerosis|
||#19|MeSH descriptor: [Cerebral Palsy] explode all trees|
||#20|Cerebral Pals*|
||#21|Spastic Diplegia*|
||#22|MeSH descriptor: [Stroke] explode all trees|
||#23|stroke|
||#24|Cerebrovascular Accident|
||#25|MeSH descriptor: [Spinal Cord Injuries] explode all trees|
||#26|'Spinal Cord Injury'|
||#27|'Spinal Cord Laceration'|
||#28|MeSH descriptor: [Brain Injuries] explode all trees|
||#29|'Brain Injur*'|
||#30|'Brain Trauma'|
||#31|#12 OR #13 OR #14 OR #15 OR #16 OR #17 OR #18 OR #19 OR #20 OR|
||#21 O<br>#32|R #22 OR #23 OR #24 OR #25 OR #26 OR #27 OR #28 OR #29 OR #30<br>#11 AND #31|
|LILACS (via BVS)|Mh:"E<br>OR (E|spasticidade Muscular" OR (Espasticidade Muscular) OR (Muscle Spasticity)<br>spasicidad Muscular) OR (Espasticidade) OR (Espasticidade em Canivete) OR|
|LILACS (103)|Mh:"H|ipertonia Muscular" OR (Hipertonia Muscular) OR (Muscle Hypertonia) OR|
|IBECS (72)|(Hiper|tonía Muscular) OR (Hipermiotonia) OR (Hipertonicidade Muscular) OR|  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
|BINACIS (9)|Mh:"Paralisia Cerebral" OR (Paralisia Cerebral) OR (Cerebral Palsy) OR (Parálisis|
|BRISA/RedTESA (4)|Cerebral) OR (Spastic Diplegia) OR (Diplegia Espastica) OR Mh:" Acidente Vascular|
|Sec. Munic. Saúde SP (2)|Cerebral" OR (Acidente Vascular Cerebral) OR (AVC) OR (Stroke) OR (Accidente|
|Coleciona SUS (2)|Cerebrovascular) OR Mh:" Traumatismos da Medula Espinal"  OR (Traumatismos da|
|BBO - Odontologia (1)|Medula Espinal) OR (Spinal Cord Injuries) OR (Traumatismos de la Médula Espinal)|
|BIGG - guias GRADE (1)|OR (Lesões da Medula Espinhal) OR Mh:" Lesões Encefálicas" OR (Lesões|
|Index Psicologia - Periódicos|Encefálicas) OR (Brain Injuries) OR (Lesiones Encefálicas) OR (Lesão Cerebral)|
|(1)|AND Mh:"Toxinas Botulínicas Tipo A" OR (Toxinas Botulínicas Tipo A) OR|
|SOF<br>-<br>Segunda<br>opinião<br>formativa (1)|(Botulinum Toxins, Type A) OR (Toxinas Botulínicas Tipo A) OR (Botox) OR<br>(Meditoxin) OR (Neuronox) OR (Neurotoxina Botulínica Tipo A) OR (Oculinum) OR<br>(Onabotulinumtoxina A) OR (OnabotulinumtoxinaA) OR (Toxina Botulínica A) OR<br>(Toxina Botulínica Tipo A) OR (Toxina de Clostridium botulinum Tipo A) OR<br>(Vistabel) OR (Vistabex)|
|Open Grey|spasticity AND (Botulinum Toxin OR Botox)<br>muscular hypertonia AND (Botulinum Toxin OR Botox) -<br>stroke AND (Botulinum Toxin OR Botox)<br>palsy AND (Botulinum Toxin OR Botox)|  
A elegibilidade dos estudos foi realizada em duas etapas, por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®3</sup> . Na segunda etapa, realizou-se a leitura de texto completo, também por dois revisores independentes, mantendo-se estudos clínicos randomizados (ECR) que avaliassem a TBA para o tratamento da espasticidade. As divergências, quando necessário, foram discutidas até chegar a um consenso ou discutidas com um terceiro pesquisador.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: pacientes adultos com diagnóstico de espasticidade por qualquer causa  
- (b) Tipo de intervenção: TBA em qualquer dose.  
- (c) Tipos de estudos: foram considerados os ensaios clínicos randomizados comparando a TBA a placebo ou outras  
- alternativas disponíveis no SUS.  
- (d) Desfechos: redução do escore da escala de Ashworth (EA), redução da dor associada à espasticidade, melhora da  
- qualidade de vida relacionada à saúde utilizando escala validada e frequência de eventos adversos.  
- (e) Idioma: foram mantidos apenas os textos publicados em inglês, português ou espanhol.  
Para todos os ECR incluídos, foi realizada avaliação do risco de viés utilizando instrumento validado, sendo empregada a ferramenta de avaliação de Risco de Viés da Cochrane (RoB 2.0), tanto a versão para ECR paralelos, quanto para ECR cruzados 1. Para a avaliação do grau de certeza das evidências foi utilizada o método _The Grading of Recommendations Assessment, Development and Evaluation_ (GRADE)<sup>2</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Resultados da busca</u>** -->
Inicialmente, foram identificadas 2.825 publicações. Após a exclusão das duplicatas (n = 726) e triagem pela leitura de títulos e  
resumos, 107 publicações foram selecionadas para a leitura do texto completo ( **Figura A** ). Foram incluídas 43 publicações  
referentes a 41 ECR. Foi realizada busca manual na lista de referências de revisões sistemáticas recentemente publicadas, incluindo quatro estudos. A lista de estudos excluídos e a razão para exclusão é apresentada no **Quadro E** .  
<!-- Start of picture text -->
Referéncias identificadas em:<br>CochraneBasPubMedEmbaseCENTRAL es aoe, (219)(n =780(n =1557) 282) ReferénciasprovessoDuplicatas de selegdo:removidas(n =726) antes do Referenciaséncias identiicadasi si em7<br>Cochrane Review(n=68)<br>2 LILACS (n =194)<br>Open Gray (n=7)<br>Referéncias avaliadas por titulo Referéncias ex cluidas<br>e resumo (n=1984)<br>(n=2099)<br>Referéncias incluidas para Referéncias cujo texto completo Referéncias incluidas para Referéncias cujo texto completo<br>avaliagao por texto completo nao foi identific ado ay alia¢ao por texto completo I><br>(n=115) (n= 24) (n=7) (n=0)<br>3 | no foi identificado<br>a Referéncias excluidas: n=52<br>Referéncias avaliadas por texto - Resumo de congresso de estudo Referéncias avaliadas por texto as -<br>completo ja incluido (n =24) completo \—___»] Referéncias excluidas: (n=3)<br>(n= 91) -incluidos Analise conjuntaou sem possibilidadede estudosjade (n=7) -ja Analise conjuntaincluidos (n =2) de estudos<br>identificagao (mn =10) - Avaliagdo da escala de<br>- Avaliagao da escala de Ashworth acima de 4<br>Ashworth acima de 4 semanas: semanas: (r=1)<br>(re?)<br>- Analise post-hoc (n=6)<br>- Nao relata resultados para grupo<br>Publicagées incluidas na revisao controle ou intervengao (n=5)<br>(n= 43) referentes a 41 estudos<br>clinicos<br><!-- End of picture text -->  
**Figura A -** Fluxograma de seleção dos estudos incluídos sobre toxina botulínica no tipo A (TBA) para o tratamento da espasticidade  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
**Quadro E -** Lista de referências excluídas na fase de elegibilidade por leitura de texto completo dos estudos clínicos – sínteses sobre toxina botulínica do tipo A em adultos  
Resumo de congresso de um estudo já incluído (sem acréscimo de informação) Rosales, R., Kong, K. H., Kumthornthip, W., Mazlan, M., Abdul Latif, L., De Los Santos, M. M. D., Chotiyarnwong, C., Tanvijit, P., Nuez, O., Maisonobe, P., Goh, K. J., & Balcaitiene, J. (2018). Safety of early use abobotulinumtoxina (DYSPORT) in adults with post-stroke spasticity: Results from the ontime and abcdes studies. European Stroke Journal, 3(1), 53–54. Rosales, R., Goh, K. J., Kumthornthip, W., Mazlan, M., Abdul Latif, L., DeLos Santos, M. M., Chotiyarnwong, C., Tanvijit, P., Balcaitiene, J., Maisonobe, P., & Kong, K.-H. (2017). Effect of early abobotulinumtoxinA use after stroke on the time to reach reinjection criteria: Asymptomatic versus symptomatic patients. Movement Disorders, 32, 759–760. Rosales, R. L., Kong, K. H., Kumthornthip, W., Mazlan, M., Abdul Latif, L., De Los Santos, M. M. D., Chotiyarnwong, C., Tanvijit, P., Nuez, O., Balcaitiene, J., Maisonobe, P., & Goh, K. J. (2017). Early use of abobotulinumtoxina in adults with post-stoke spasticity improves muscle tone and increases time to reinjection: Results from ontime and abcde s studies. European Stroke Journal, 2(1), 32 Kaji, R., & Kimura, A. (2013). Botulinum toxin type A in post-stroke spasticity: Clinical trials with functional measures. Toxicon, 68, 79–80. Kanovsky, P., Platz, T., Comes, G., Grafe, S., & Sassin, I. (2009). NT201 botulinum neurotoxin free from complexing proteins (Xeomin) provided sustained efficacy and was safe in spasticity: 89 weeks long-term data. Journal of the Neurological Sciences, 285, S75–S76. Hughes, A., Baguley, I., De Graaff, S., Davies, L., McCrory, P., Sandanam, J., & Katrak, P. (2008). Botulinum toxin (Dysport) in upper limb spasticity following stroke - a placebo-controlled study. Journal of Clinical Neuroscience, 15, 355– 356. Stoquart, G., Boyer, F. C., Hedera, P., Brashear, A., Esquenazi, A., Grandoulier, A.-S., Vilain, C., Picaut, P., & Gracies, J.M. (2018). Efficacy of abobotulinumtoxinA for the treatment of hemiparetic adult patients with lower limb spasticity previously treated with botulinum toxins. Toxicon, 156, S108–S108. Rosales, R. L., Goh, K. J., Kumthornthip, W., Mazlan, M., Latif, L. A., De Los Santos, M. M. D., Chotiyarnwong, C., Tanvijit, P., Balcaitiene, J., Maisonobe, P., & Kong, K. H. (2018). Effect of early use of abobotulinumtoxina on time to post-stroke spasticity progression: Results of the ontime pilot study. Neurorehabilitation and Neural Repair, 32(4), 319–320. Rosales, R. L., Goh, K. J., Kumthornthip, W., Mazlan, M., Abdul Latif, L., De Los Santos, M. M. D., Chotiyarnwong, C., Tanvijit, P., Balcaitiene, J., Maisonobe, P., & Kong, K. H. (2017). Effect of early use of abobotulinumtoxina on time to post-stroke spasticity progression: Results of the ontime pilot study. Journal of the Neurological Sciences, 381, 151–152. Goh, K. J., Kong, K. H., Kumthornthip, W., Mazlan, M., Latif, L. A., De Los Santos, M. M. D., Chotiyarnwong, C., Tanvijit, P., Nuez, O., Balcaitiene, J., Maisonobe, P., & Rosales, R. L. (2017). Effect of early use of abobotulinumtoxina after stroke on muscle tone and spasticity progression: Results of a pilot study. European Stroke Journal, 2(1), 173. Patel, A., Marciniak, C., Munin, M. C., Hanschmann, A., Hiersemenzel, R., & Elovic, E. P. (2016). Randomized, placebocontrolled, phase III study of incobotulinumtoxinA for upper-limb post-stroke spasticity. Archives of Physical Medicine and Rehabilitation, 97(10), e10–e11. Patel, A. T., Ward, A. B., Geis, C., Liu, C., Jost, W. H., & Dimitrova, R. (2016). Impact of early intervention with onabotulinumtoxina treatment in adult patients with post-stroke lower limb spasticity. PM and R, 8(9), S279–S279. Wissel, J., Ganapathy, V., Ma, Y., Ward, A., Borg, J., Ertzgaard, P., Fulford-Smith, A., & Gillard, P. (2014). OnabotulinumtoxinA improves spasticity related pain in post-stroke patients: Findings from a randomized controlled trial. Annals of Physical and Rehabilitation Medicine, 57, e44–e44.  
Shaw, L., Barnes, M., Ford, G., Graham, L., Price, C., Rodgers, H., Shackley, P., Steen, N., & Van Wijck, F. (2009). Final results: from the BoTULS trial: A randomised controlled trial to evaluate the clinical effect of treating post stroke upper limb spasticity with botulinum toxin. International Journal of Stroke, 4, 10. Shaw, L. C., Price, C., Van Wijck, F., Barnes, M., Graham, L., Ford, G. A., Shackley, P., Steen, I. N., & Rodgers, H. (2009). Botuls: A multi-centre randomised controlled trial to evaluate the clinical effect of Treating upper limb spasticity due to stroke with Botulinum toxin type a. Cerebrovascular Diseases, 27, 42. Lam, K., Lau, K. K., So, K. K., Tam, C. K., Wu, Y. M., Cheung, G., Liang, K. S., Yeung, K. M., Lam, K. Y., Yui, S., & Leung, C. (2016). Use of botulinum toxin to improve upper limb spasticity and decrease subsequent carer burden in longterm care residents: a randomised controlled study. Hong Kong Medical Journal = Xianggang Yi Xue Za Zhi, 22, S43-5 Gracies, J.-M., Brashear, A., Mc Allister, P., Walker, H. W., Marciniak, C. M., Gul, F., Edgley, S. R., & Picaut, P. (2014). Randomized, double-blind placebo-controlled phase iii study of dysport, abobotulinumtoxina, in the treatment of adults with upper limb spasticity. PM and R, 6(9), S327–S327  
Gracies, J. M., Brashear, A., Jech, R., & Picaut, P. (2014). Efficacy and safety of abobotulinumtoxina (dysport) in the treatment of adults with upper limb spasticity: randomized double-blind placebo-controlled phase III study. PM and R., 6(8), S85–S85.  
Gracies, J.-M., Lejeune, T., Boyer, F. C., Serdar, K., Marque, P., & sanyi, A. (2015). AbobotulinumtoxinA (Dysport) in the treatment of adults with upper limb spasticity in a randomized, double-blind, placebo-controlled study. Toxicon, 93, S30– S30  
Wein, T., Dimitrova, R., Esquenazi, A., Jost, W. H., Ward, A., & Pan, G. (2015). OnabotulinumtoxinA treatment in adult patients with post-stroke lower limb spasticity: results from a double-blind, placebo-controlled, phase 3 clinical trial. International Journal of Stroke. Conference: 2015 Canadian Stroke Conference. Toronto, ON Canada.  
Esquenazi, A., Wein, T., Jost, W. H., Ward, A. B., & Kwan, T. (2015). Onabotulinumtoxina treatment in adult patients with post-stroke lower limb spasticity: results from a double-blind, placebo-controlled, phase 3 clinical trial. PM and R., 7(9), S98–S99  
Patel, A. T., Ward, A. B., Geis, C., Jost, W. H., Liu, C., & Dimitrova, R. (2020). Impact of early intervention with onabotulinumtoxinA treatment in adult patients with post-stroke lower limb spasticity: results from the double-blind, placebo-controlled, phase 3 REFLEX study. Journal of Neural Transmission. Wein, T., Esquenazi, A., Jost, W. H., Ward, A., Kwan, T., Pan, G., & Dimitrova, R. (2016). OnabotulinumtoxinA treatment in post-stroke lower limb spasticity: long-term results from a phase 3 study. Stroke. Conference: American Heart Association/American Stroke Association 2016 International Stroke Conference and State-of-the-Science Stroke Nursing Symposium Los Angeles, CA United States. Conference Start: 20160216 Conference End: 20160219. Conferenc, 47. Wein, T. H., Esquenazi, A., Ward, A. B., Geis, C., Liu, C., Dimitrova, R., Wein, T. H., Ward, A. B., Liu, C., Dimitrova, R., Esquenazi, A., Ward, A. B., Geis, C., Liu, C., & Dimitrova, R. (2016). Muscle selection patterns for injection of onabotulinumtoxinA in adult patients with post-stroke lower-limb spasticity influence outcome: Results from a doubleblind, placebo-controlled phase 3 clinical trial. Movement Disorders, 31(9), S306–S306  
Análise conjunta de estudos já incluídos na nossa revisão sistemática Kaňovský, P., Elovic, E. P., Munin, M. C., Hanschmann, A., Pulte, I., Althaus, M., Hiersemenzel, R., & Marciniak, C. (2021). Sustained efficacy of incobotulinumtoxina repeated injections for upper-limb post-stroke spasticity: A post hoc analysis. Journal of Rehabilitation Medicine, 53(1), jrm00138–jrm00138. Turkel, C. C., Bowen, B., Liu, J., & Brin, M. F. (2006). Pooled analysis of the safety of botulinum toxin type A in the treatment of poststroke spasticity. Archives of Physical Medicine and Rehabilitation, 87(6), 786–792.  
Wein, T., Ward, A. B., Esquenazi, A., Chapman, M. A., Shi, G., James, L., Thompson, C., & Dimitrova, R. (2014). Effect of onabotulinumtoxinA on patient-related outcomes for lower limb spasticity. Annals of Physical and Rehabilitation Medicine., 57, e46–e46.  
Kaňovský, P., Elovic, E. P., Munin, M. C., Hanschmann, A., Pulte, I., Althaus, M., Hiersemenzel, R., & Marciniak, C. (2018). Sustained efficacy of incobotulinumtoxinA in upper-limb poststroke spasticity: Pooled analysis of 2 phase 3 trials. Toxicon, 156, S57–S57.  
Marciniak, C., Kanovsky, P., Munin, M. C., Althaus, M., Hanschmann, A., Pulte, I., & Hiersemenzel, R. (2017). Incobotulinumtoxina sustainably improves upper limb spasticity-pooled analysis of two phase 3 trials. PM and R, 9(9), S159–S160  
Shaw, L., Rodgers, H., Price, C., van Wijck, F., Shackley, P., Steen, N., Barnes, M., Ford, G., & Graham, L. (2010). BoTULS: a multicentre randomised controlled trial to evaluate the clinical effectiveness and cost-effectiveness of treating upper limb spasticity due to stroke with botulinum toxin type A. Health Technology Assessment (Winchester, England), 14(26), 1–113, iii–iv.  
Esquenazi (2020). Duration of Symptom Relief Between Injections for AbobotulinumtoxinA (Dysport®) in Spastic Paresis and Cervical Dystonia: Comparison of Evidence From Clinical Studies "Front Neurol. 2020 Sep 25;11:576117.  
Rodgers H, Shaw L, Price C, et al. BoTULS trial: a randomised controlled trial to evaluate the clinical effect and cost effectiveness of treating upper limb spasticity due to stroke with botulinum toxin type A. Health Technol Assess 2010; 14: 1–141.  
Resumo de congresso de análise conjunta de dados sem a possibilidade de identificação do estudo  
James, L. M., Shi, G., Demos, G., Dimitrova, R., & Earl, N. (2013). Onabotulinumtoxina in lower limb spasticity: safety results from a pooled analysis. PM and R., 5(9), S253–S253. https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01024751/full  
James, L., Dimitrova, R., Shi, G., Asare, C., & Thompson, C. (2014). Safety profile of repeat onabotulinumtoxina doses of 400u for the treatment of upper limb spasticity. PM and R., 6(9), S303–S303.  
Avaliação da escala de Ashworth acima de 4 semanas  
Gordon, M. F., Brashear, A., Elovic, E., Kassicieh, D., Marciniak, C., Liu, J., & Turkel, C. (2004). Repeated dosing of botulinum toxin type A for upper limb spasticity following stroke. Neurology, 63(10), 1971–1973.  
Meythaler, J. M., Vogtle, L., & Brunner, R. C. (2009). A preliminary assessment of the benefits of the addition of botulinum toxin a to a conventional therapy program on the function of people with longstanding stroke. Archives of Physical Medicine and Rehabilitation, 90(9), 1453–1461.  
Prazeres, A., Lira, M., Aguiar, P., Monteiro, L., Vilasbôas, Í., & Melo, A. (2018). Efficacy of physical therapy associated with botulinum toxin type A on functional performance in post-stroke spasticity: A randomized, double-blinded, placebocontrolled trial. Neurology International, 10(2), 7385.  
Basumatary, L. (2018). Evaluation of Effectiveness and Safety of Botulinum Toxin Type-A (BTX-A) for Chronic Focal Post-Stroke Upper Limb Spasticity in Indian Stroke Patients. Movement Disorders, 33, S502–S502.  
Bhakta, B. B., Cozens, J. A., Chamberlain, M. A., & Bamford, J. M. (2000). Randomized double-blind placebo-controlled trial of botulinum toxin treatment on the disabling effects of severe arm spasticity in stroke. Clinical Rehabilitation, 14, 213.  
Tao W, Yan D, Li JH, Shi ZH. Gait improvement by low-dose botulinum toxin A injection treatment of the lower limbs in subacute stroke patients. Phys Ther Sci. 2015;27(3):759–762.  
Smith, S. J., Ellis, E., White, S., & Moore, A. P. (2000). A double-blind placebo-controlled study of botulinum toxin in upper limb spasticity after stroke or head injury. Clinical Rehabilitation, 14(1), 5–13.  
Análise post-hoc de estudo já incluído com desfechos ou população que não são de interesse Gracies, J.-M., Jech, R., Valkovic, P., Marque, P., Vecchio, M., Denes, Z., Vilain, C., Delafont, B., & Picaut, P. (2021). When can maximal efficacy occur with repeat botulinum toxin injection in upper limb  spastic paresis? Brain Communications, 3(1), fcaa201–fcaa201. Esquenazi, A., Wein, T. H., Ward, A. B., Geis, C., Liu, C., & Dimitrova, R. (2019). Optimal Muscle Selection for OnabotulinumtoxinA Injections in Poststroke Lower-Limb Spasticity: A Randomized Trial. American Journal of Physical Medicine & Rehabilitation, 98(5), 360–368. Marciniak, C., McAllister, P., Walker, H., Brashear, A., Edgley, S., Deltombe, T., Khatkova, S., Banach, M., Gul, F., Vilain, C., Picaut, P., Grandoulier, A.-S., & Gracies, J.-M. (2017). Efficacy and Safety of AbobotulinumtoxinA (Dysport) for the Treatment of Hemiparesis in Adults With Upper Limb Spasticity Previously Treated With Botulinum Toxin: Subanalysis From a Phase 3 Randomized Controlled Trial. PM & R : The Journal of Injury, Function, and Rehabilitation, 9(12), 1181– 1190. O’Dell, M. W., Brashear, A., Jech, R., Lejeune, T., Marque, P., Bensmail, D., Ayyoub, Z., Simpson, D. M., Volteau, M., Vilain, C., Picaut, P., & Gracies, J. M. (2018). Dose-Dependent Effects of AbobotulinumtoxinA (Dysport) on Spasticity and Active Movements in Adults With Upper Limb Spasticity: Secondary Analysis of a Phase 3 Study. PM & R : The Journal of Injury, Function, and Rehabilitation, 10(1), 1–10. Marciniak, C. M., Brashear, A., Mcallister, P., Rubin, B., Hedera, P., Isaacson, S., Picaut, P., & Gracies, J.-M. (2015). Efficacy and safety of abobotulinumtoxina (Dysport) in adult hemiparetic patients with upper limb spasticity previously treated with botulinum toxins. PM and R. ( Var.Pagings), 7(9), S100–S101. Marciniak, C., Brashear, A., McAllister, P., Rubin, B., Hedera, P., & Isaacson, S. (2017). Efficacy and safety of abobotulinumtoxina (dysport) in adult hemiparetic patients with upper limb spasticity previously treated with botulinum toxins. Neurorehabilitation and Neural Repair, 31(2), NP13–NP13  
Não relata os resultados para o grupo controle ou intervenção Kanovsky, P., Pulte, I., Grafe, S., & Barnes, M. (2013). Significant and sustained efficacy of incobotulinumtoxinA in upper limb spasticity. Toxicon., 68, 115–116. Yoo, S. D., Kim, D. W., & Jeong, Y. S. (2010). The efficacy of chemodenervation using botulinum toxin in post stroke spasticity: ultrasonography guidance application. International Journal of Stroke, 5, 309. Gracies, J.-M., Esquenazi, A., Brashear, A., Edgley, S. R., O’Dell, M., Hedera, P., Rubin, B. S., & Picaut, P. (2016). Efficacy and safety of repeated abobotulinumtoxina injections in adults with lower limb spasticity. PM and R, 8(9), S254– S254.  
Burbaud, P., Wiart, L., Dubos, J. L., Gaujard, E., Debelleix, X., Joseph, P. A., Mazaux, J. M., Bioulac, B., Barat, M., & Lagueny, A. (1996). A randomised, double blind, placebo-controlled trial of botulinum toxin in the treatment of spastic foot in hemiparetic patients. Journal of Neurology, Neurosurgery, and Psychiatry, 61(3), 265–269. Jacobson, D., Lowing, K., Kullander, K., Rydhberner, B.-M., Ljung, M., & Tedroff, K. (2019). Botulinum toxin-a for chronic pain in spastic cerebral palsy: a randomized placebo-controlled double-blinded trial. Developmental Medicine and Child Neurology, 61, 34--34

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise e apresentação dos resultados** -->
Foram avaliadas 43 publicações de 41 estudos diferentes, sendo 25 deles referentes à avaliação de membros superiores<sup>4–29</sup> , 13 de membros inferiores<sup>30–43</sup> e 3 de ambos os membros<sup>44–46</sup> . Nos estudos, foram avaliadas quatro TBAs, todas elas disponíveis no Brasil: Botox® (Allergan), Dysport® (Ipsen), Xeomin® (Merz Pharmaceuticals) e Prosigne® (Cristália). A maior parte dos estudos envolveu apenas pacientes adultos com espasticidade secundária a AVC<sup>4–8,10–13,15–18,21,22,24–27,29,31,33,35,40,41,43,46,47</sup> . Outras  
condições encontradas foram traumatismo craniano, lesão da medula espinhal, paraplegia espástica hereditária, hipóxia cerebral difusa, tumor e esclerose múltipla. No **Quadro F** , estão descritas as principais características dos estudos clínicos incluídos divididos por membros avaliados.  
**Quadro F -** Características dos estudos clínicos avaliando toxina botulínica do tipo A (TBA) no tratamento da espasticidade em adultos  
|**Autor, ano (registro**<br>**do estudo)**|**Número de pacientes**<br>**randomizados**|**Condição**<br>**primária**|**Toxina avaliada /**<br>**Nome comercial**|**Desfechos de**<br>**interesse avaliados**|
|---|---|---|---|---|
|**Membros superiores**|||||
|Masakado, 2020 (J-<br>PURE; JapicCTI<br>Number:<br>CTI-153029)<sup>12</sup>|TBA 400 U: 44; Placebo<br>alta dose: 22<br>TBA 250 U: 23; Placebo<br>baixa dose: 11|AVC|IncobotulinumtoxinA /<br>Xeomin|- redução do escore<br>EA|
|Rosales, 2018;<br>ONTIME ;<br>NCT02321436<sup>15</sup>|TBA: 28<br>Placebo: 14|AVC|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA<br>- eventos adversos|
|Elovic, 2016; Elovic,<br>2014<br>(Estudo PURE /<br>NCT01392300 /<br>EudraCT 2010-<br>023043-15)<sup>26,27</sup>|Avaliação de segurança:<br>317 (TBA: 210; Placebo:<br>107)<br>Análise completa: 259<br>(TBA: 171; Placebo: 88)|AVC|IncobotulinumtoxinA /<br>Xeomin|- redução do escore<br>EA<br>- evento adverso|
|Gracies, 2015<br>(NCT01313299)<sup>28</sup>|Intention-to-treat: 238<br>(TBA 500 U: 80; TBA<br>1000 U: 79; Placebo:79)<br>Segurança: 243 (TBA<br>500 U: 81; TBA 1000 U:<br>81; Placebo: 81)|AVC e<br>traumatismo<br>craniano|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA<br>- qualidade de vida<br>(SF-36 e EQ-5D)<br>- eventos adversos|
|O´Dell, 2015<sup>14</sup>|TBA 500U ou 1000U: 14<br>Placebo: 9|Traumatismo<br>craniano|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA|
|Marciniak, 2012<br>(NCT00661089)<sup>10</sup>|TBA: 10; placebo: 11|AVC|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA<br>- dor|
|Wolf, 2012 (IIT-<br>000121)<sup>21</sup>|TBA 100 U: 12; Placebo:<br>13;|AVC|OnabotuliunumtoxinA /<br>Botox|- qualidade de vida<br>(SIS)|
|Rosales, 2012<br>(NCT00234546)<sup>17</sup>|TBA: 80; Placebo: 83|AVC|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA<br>- dor<br>- eventos adversos|
|Lam, 2012<sup>9</sup>|TBA: 30; Placebo: 25|Não relatado|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA<br>- dor|  
|**Autor, ano (registro**|**Número de pacientes**|**Condição**|**Toxina avaliada /**|**Desfechos de**|
|---|---|---|---|---|
|**do estudo)**|**randomizados**|**primária**|**Nome comercial**|**interesse avaliados**|
|Kaji, 2010|TBA baixa dose|AVC|OnabotulinumtoxinA /|- redução do escore|
|(NCT00460564)<sup>6</sup>|(120U):21; Placebo baixa<br>dose: 11<br>TBA alta dose (200): 51;<br>Placebo alta dose:26||Botox|EA<br>- eventos adversos|
|Kanovský, 2009<br>(NCT00465738)<sup>7</sup>|TBA:73; Placebo:75|AVC|IncobotulinumtoxinA /<br>Xeomin|- redução do escore<br>EA<br>- eventos adversos|
|McCrory, 2009<sup>13</sup>|TBA: 54; Placebo: 42|AVC|AbobotulinumtoxinA /<br>Dysport|- dor<br>- qualidade de vida<br>(AQoL)|
|Simpson, 2009<br>(NCT00430196)<sup>19</sup>|TBA intramuscular +<br>placebo oral: 20; Placebo<br>intramuscular + placebo<br>oral: 19|AVC ou<br>traumatismo<br>craniano|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA<br>- eventos adversos|
|De Boer, 2008<sup>25</sup>|TBA: 10; Placebo: 11|AVC|OnabotuliunumtoxinA /<br>Botox|- dor|
|Jahangir, 2007<sup>29</sup>|TBA 80 U: 27; Placebo:<br>25|AVC|OnabotuliunumtoxinA /<br>Botox|- redução do escore<br>EA<br>- qualidade de vida<br>(EQ-5D e EQ-VAS)|
|Yelnik, 2007<sup>22</sup>|TBA 500 U: 15; Placebo:<br>10.|AVC|Abobotulinumtoxina /<br>Dysport|- redução do escore<br>EA<br>- dor<br>- eventos adversos|
|Marco, 2007<br>(RHBESPE/TOXIN-|Placebo + transcutaneous<br>electrical nerve|AVC|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA|
|1)<sup>11</sup>|Stimulation (TENS): 15<br>TBA 500U + TENS :16|||- dor|
|Suputtitada, 2005<sup>20</sup>|TBA 350 U: 15;<br>TBA 500 U: 15;<br>TBA 1000: 5;<br>Placebo: 15;|AVC, lesão<br>cerebral<br>traumática, lesão<br>da medula<br>espinhal,<br>esclerose múltipla<br>e doenças<br>degenerativas.|Abobotulinumtoxina /<br>Dysport|- redução do escore<br>EA<br>- dor|
|Kong, 2004<sup>8</sup>|TBA: 8; Placebo: 9|AVC|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA|  
|**Autor, ano (registro**|**Número de pacientes**|**Condição**|**Toxina avaliada /**|**Desfechos de**|
|---|---|---|---|---|
|**do estudo)**|**randomizados**|**primária**|**Nome comercial**|**interesse avaliados**|
|||||- dor<br>- eventos adversos|
|Childers, 2004<sup>24</sup>|TBA 90U -baixa dose: 21<br>TBA 180U -dose média:<br>23<br>TBA 360U -alta dose: 21<br>Placebo: 26|AVC|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA<br>- qualidade de vida<br>(SF 36)<br>- dor<br>- eventos adversos|
|Brashear, 2002<sup>23</sup>|TBA: 64; Placebo: 62|AVC|OnabotuliunumtoxinA /<br>Botox|- redução do escore<br>EA|
|Bakheita, 2001<sup>4</sup>|TBA 1000 U: 27;<br>Placebo: 32|AVC|Abobotulinumtoxina /<br>Dysport|- redução do escore<br>EA<br>- eventos adversos|
|Bakheita, 2000<sup>5</sup>|TBA 500U: 22<br>TBA 1000U: 22<br>TBA 1500U: 19<br>Placebo: 19|AVC|AbobotulinumtoxinA /<br>Dysport|- redução do escore<br>EA<br>- eventos adversos|
|Bhakta, 2000<sup>16</sup>|TBA 1000U: 20;<br>Placebo: 20|AVC|Abobotulinumtoxina /<br>Dysport|- redução do escore<br>EA<br>- eventos adversos|
|Simpson, 1996<sup>18</sup>|TBA 75U: 9<br>TBA 150U: 9<br>TBA 300U: 9<br>Placebo: 10|AVC|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA|
|**Membros inferiores**|||||
|Diniz, 2021<br>(SPASTOX /<br>NCT02604186)<sup>30</sup>|TBA:27; Placebo:28|Paraplegia<br>espástica<br>hereditária|Prosigne|- dor<br>- eventos adversos|
|Masakado, 2020 (J-<br>PURE; JapicCTI<br>Number:<br>CTI‐153030)<sup>43</sup>|TBA: 104; Placebo: 104|AVC|IncobotulinumtoxinA /<br>Xeomin|- redução do escore<br>EA<br>- eventos adversos|
|Kerzoncuf, 2020<br>(NCT03405948)<sup>41</sup>|TBA 300 U:19; Placebo:<br>21|AVC|OnabotulinumtoxinA<br>/Botox|- redução do escore<br>EA|
|Napoli, 2018; Gracies,|TBA 1000 U: 125|AVC e|AbobotulinumtoxinA /|- redução do escore|
|2017 (CT01249404)<br>32,37|TBA 1500U: 128<br>Placebo: 128|traumatismo<br>craniano|Dysport|EA<br>- qualidade de vida<br>(SF-36 e EQ-5D)|  
|**Autor, ano (registro**|**Número de pacientes**|**Condição**|**Toxina avaliada /**|**Desfechos de**|
|---|---|---|---|---|
|**do estudo)**|**randomizados**|**primária**|**Nome comercial**|**interesse avaliados**|
|||||- eventos adversos|
|Wein, 2018<br>(NCT01575054 -<br>REFLEX)<sup>35</sup>|TBA: 233; placebo: 235|AVC|OnabotulinumtoxinA<br>/Botox|- redução do escore<br>EA<br>- dor<br>- eventos adversos|
|Fietzek, 2014<sup>36</sup>|TBA: 26; Placebo: 26|AVC,<br>traumatismo<br>craniano ou<br>hipóxia cerebral<br>difusa|OnabotulinumtoxinA<br>/Botox|- redução do escore<br>EA|
|Dunne, 2012 (BTOX-<br>702-8051)<sup>31</sup>|TBA 200U: 28<br>TBA 300U: 28<br>Placebo: 29|AVC|OnabotulinumtoxinA /<br>Botox|- dor<br>- eventos adversos|
|Maanum, 2011<br>(NCT00432055)<sup>42</sup>|TBA 50 U: 33; Placebo:<br>33|Paralisia Cerebral|OnabotulinumtoxinA<br>/Botox|- qualidade de vida<br>(SF-36)<br>- eventos adversos|
|Kaji, 2010<br>(NCT00460655)<sup>40</sup>|TBA 300U: 58; Placebo:<br>62|AVC|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA<br>- eventos adversos|
|Gusev, 2008<sup>38</sup>|TBA 1000 – 1500 U: 55;<br>Placebo: 51|Esclerose múltipla|Abobotulinumtoxina /<br>Dysport|- dor<br>- eventos adversos|
|Verplancke, 2005<sup>34</sup>|Gesso + solução salina:<br>12<br>Gesso + TBA 200U: 12|Traumatismo<br>craniano|OnabotulinumtoxinA /<br>Botox|- redução do escore<br>EA|
|Pittock, 2003<sup>33</sup>|TBA 500 U: 59<br>TBA 1000 U: 60<br>TBA 1500 U:60<br>Placebo: 55|AVC|Abobotulinumtoxina /<br>Dysport|- redução do escore<br>EA<br>- dor<br>- eventos adversos|
||TBA 500U: 21|||- redução do escore|
|Hyman, 2000<sup>39</sup>|TBA 1000U: 20<br>TBA 1500U: 17|Esclerose múltipla|Abobotulinumtoxina /<br>Dysport|EA<br>- dor|
||Placebo: 16|||- eventos adversos|
|**Membros superiores**|||||
|**+ inferiores**|||||
|Jacobson, 2021<br>(NCT02434549)<sup>44</sup>|TBA: 8; Placebo: 8|Paralisia Cerebral|Abobotulinumtoxina /<br>Dysport|- dor<br>- eventos adversos|
|Wissel, 2016 (BEST|TBA + tratamento|AVC|OnabotulinumtoxinA /|- dor|
|(BOTOX Economic|padrão: 139||Botox||  
|**Autor, ano (registro**<br>**do estudo)**|**Número de pacientes**<br>**randomizados**|**Condição**<br>**primária**|**Toxina avaliada /**<br>**Nome comercial**|**Desfechos de**<br>**interesse avaliados**|
|---|---|---|---|---|
|Spasticity Trial /|Placebo + tratamento||||
|NCT00549783)<sup>46</sup>|padrão: 134||||
|Richardson, 2000<sup>45</sup>|Membro superior:|AVC,|OnabotuliunumtoxinA /|- redução do escore|
||TBA 100 U: 16; Placebo:|traumatismo|Botox|EA|
||16|craniano, lesão|||
||Membro inferior:|medular|||
||TBA 100 U: 11; Placebo:<br>9|incompleta,<br>tumor, paralisia<br>cerebral e<br>episódios<br>anóxicos.|||  
Notas: AVC: Acidente vascular cerebral; AQoL: _Assessment of Quality of Life_ ; EA: escala de Ashworth; EQ-VAS: _EuroQol-visual analogue_  
_scales_ ; EQ-5D: _EuroQol 5 Dimensions_ ; SF-36: _Short Form-36_ ; SIS: _Stroke Impact Scale_ ; TBA: toxina botulínica do tipo A.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Avaliação do risco de viés</u>** -->
De acordo com o Rob 2.0<sup>1</sup> , para a alteração média da EA, apenas cinco estudos apresentaram risco de viés baixo<sup>6,26,28,35,48</sup> e para a proporção de pacientes que tiveram redução ≥ 1 ponto na EA, apenas três estudos apresentaram risco de viés baixo<sup>26,28,35</sup> . Os demais estudos foram classificados como tendo algumas preocupações ou alto risco de viés atribuídos, principalmente, por não fornecerem informações a respeito do cegamento dos participantes ou dos avaliadores, do processo de randomização, do sigilo de alocação e por não apresentar informações de maneira satisfatória sobre as características basais para ambos os desfechos. Sobre o desfecho dor, parte dos estudos não usou escalas validadas, enquanto para eventos adversos, não ficava clara a forma de mensuração do desfecho.  A avaliação completa do risco de viés é apresentada no Material Suplementar 1.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Redução do escore da escala de Ashworth</u>** -->
A avaliação da eficácia foi feita utilizando a EA e sua versão modificada (EAM), instrumentos validados e aceitos para avaliação da espasticidade<sup>49–53</sup> . Para o relato da redução da EA/EAM foram consideradas a redução média do escore na semana 4 em comparação ao valor basal e a proporção de pacientes que tiveram redução de 1 ponto ou mais na escala dentro desse período. Procurou-se avaliar a eficácia em um período curto, por esse motivo, quando o estudo não relatava especificamente os resultados na semana 4, foram coletados os dados das semanas anteriores.  
Para a avaliação da redução média do escore da EA/EAM entre a semana 4 e o valor basal, foram avaliados 15 estudos clínicos para os membros superiores ( **Figura B** ) e seis para os membros inferiores ( **Figura C** ). As análises de eficácia indicam que a alteração das médias da pontuação na escala EA/EAM foi maior no grupo tratado com TBA em comparação com o placebo: Diferença de média [IC 95%]: 0,80 [0,63; 0,97] para os membros inferiores e 0,27 [0,15; 0,39] para os membros superiores. Para esse desfecho, a certeza da evidência foi considerada baixa para os membros superiores e moderada para os inferiores.  
Para ambos os membros, apenas um estudo relatou esse desfecho, o qual apresentou maior redução no grupo que recebeu a TBA em comparação ao placebo (p <0,0001)<sup>45</sup> .  
**Figura B** - _Forest plot_ da diferença média da redução do escore da escala de Ashworth (EA) e da escala de Ashworth modificada (EAM) – Membros Superiores.  
<!-- Start of picture text -->
Study or Subgroup Mean__SDTBA Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95%Ci_ Year IV,MeanRandom, Difference 95%Cl<br>Simpson (TBA 75U) 1996 07 05 9 02 04 10 51% 0.50 [0.09, 0.91) 1996 —<br>Simpson (TBA 150U) 1996 og 1 9 02 O04 10 33%  0.60[-0.10,1.30) 1996<br>‘Simpson (TBA 300U) 1996 W441 9 02 O04 10 30% 0.90 (0.14, 1.66) 1996 ——_<br>Bhakta 2000 475.215 20 012024 17 22% — 1.69(068,258) 2000 ——<br>Brashear 2002 178 062 64 042 052 62 66% 1.36 [1.16, 1.56) 2002 _<br>Childers (TBA 180U) 2004 1011 23) 06 06 26 44%  0.400.11,0.91) 2004<br>Childers<br>(TBA 360U) 2004 15 03 2% 06 08 2% 49% 090 [o45, 1.35) 2004 —<br>ChildersKong 2004(TBA 90U) 2004 1.3813°090.92 217 0.4906 04406 269 48%31% 0.701.19 (0.25,(0.45, 1.93)1.15] 20042004 _——_—_<br>Jahangir 2007 1442 27 0149 26 3.6% 1.00 (0.37, 1.63) 2007 _—<br>Mareo 2007 02 074 14 003 059 15 45% 0474092, 068) 2007<br>Simpson 2009 156 119° 20 067 091 19 35% 0.88 (0.22, 1.54) 2009 _—<br>Kaji (dose alta) 2010 1.05 091 51 0.48 067 26 55% 0.57 (0.21, 0.93) 2010 —_—<br>Kaji (dose baixa) 2010 088 074 21 073 1.01 11 3.4% 0.16 [-0.63,0.83] 2010<br>Marcniak 2012 15093 10 D.O7¢ 4 31% — 4.60(078,222) 2012 —_——<br>Rosales 2012 243065 80 184 074 83 65% 0.59 (0.38, 0.80] 2012 _<br>GraciesGravis (TBA 1000 U) 2015 1411 79 03 06 79 61% 1.40 (0.82, 1.38) 2015 —_<br>Elovic 2016(TBA 500 U) 2018 09.078121 1718 0503 07508 8879 62%66%  n90In64,0.40 (0.20, 0.60)1.16) 20182016 __<br>Rosales 2018 127 09 28 0.26082 14 4.2% 1.04 (0.47, 1.55) 2018 _—<br>MasakadoMasakado (BAbaba(TBA alta dose)dose)2020 2020112135099085 4429 053028 04708 2211 48%48% 0.82084 (0.38,(040, 1.26)1.28) 20207020 — _—,<br>Total (95% Cl) 831 679 100.0% 0.80 (0.63, 0.97] a<br>Heterogeneity: Tau®= 0.11; Chi*= 80.54, df= 21 (P <0,00001); P= 74% $4 j { $<br>Testfor overall fect 2= 9.14  « 0.00001) Favours [contro] Favours [experimental]<br><!-- End of picture text -->  
TBA: Toxina Botulínica do Tipo A. Para os estudos que apresentam os resultados por região do corpo de aplicação, foram selecionados os resultados com os maiores valores basais na escala de Ashworth<sup>8,10,16,18,19,23,24,29</sup> . Dois estudos foram excluídos da análise por não possuírem informação suficiente para a imputação de dados<sup>9,20</sup> .  
**Figura C -** _Forest plot_ da diferença média da redução do escore da escala de Ashworth (EA) e da escala de Ashworth modificada (EAM) – Membros Inferiores.  
<!-- Start of picture text -->
‘Study or Subgroup Mean TBASD Total MeanPlacebo:SD Total Weight IV,MeanRandom, Difference 95% CI Year IV,MeanRandom, Difference 95% Cl<br>Verplancke 2005 1:14.24 12 1.2 0.98 12 1.8% — -0.20[-1.09, 0.69] 2005<br>Kaji 2010 0.88 0.69 58 043 072 62 16.1% 0.45 (0.20, 0.70] 2010 _—<br>Fietzek 2014 043 0.96 26 0.01 109 26 43% 0.420.14,0.98) 2014<br>Napoli (1000U) 2018 06 086 125 05 087 128 20.1% 0.10(0.11,0.31] 2018<br>Napoli (1500U) 2018 08 058 128 05 087 128 24.4% 0.30 (0.12, 0.48) 2018 ~~<br>‘Wein 2018 0.81 0.87 233 0.61 084 235 28.6% 0.20 (0.05, 0.96) 2018 all<br>Kerzoncuf 2020 08 094 19 016 076 21 4.7% 0.64 (0.11, 1.17] 2020 TT<br>Total (95% Cl) 601 612 100.0% 0.27 (0.15, 0.39] °<br>Heterogeneity: Tau*= 0.01; Chi*= 8.38, df= 6 (P= 0.21), P= 28% 2 t 0 i 2<br>Test for overall effect2= 4.35 (P < 0.0001) Favours [control] Favours [experimental]<br><!-- End of picture text -->  
TBA: Toxina Botulínica do Tipo A. Para o estudo que apresenta os resultados por região do corpo de aplicação, foi incluído na meta-análise o resultado com o maior valor basal na escala de Ashworth<sup>41</sup> . Um estudo foi excluído da análise por não possuir informação suficiente para a imputação de dados<sup>43</sup> e outro por ter reportado valores muito superiores e irreais da escala de Ashworth<sup>39</sup> .  
Assim como a redução na média da EA/EAM, a proporção de pacientes que tiveram redução de 1 ponto ou mais na escala de EA/EAM foi maior no grupo que fez uso da TBA em comparação ao do placebo: (i) membros superiores (n=7 estudos; **Figura D** ): Risco relativo (RR) 1,60 [IC 95%: 1,22; 2,08] (Certeza da evidência baixa); (ii) membros inferiores (n=2 estudos, **Figura E** ): RR [IC 95%] de 2,32 [1,30; 4,14] (Certeza da evidência baixa). Os estudos que avaliaram os membros superiores e inferiores de forma conjunta não relataram esse desfecho  
**Figura D -** _Forest plot_ da proporção de pacientes que tiveram redução de 1 ponto ou mais na escala de Ashworth (EA) e na escala de Ashworth modificada (EAM) – Membros Superiores.  
<!-- Start of picture text -->
Experimental Control Risk Ratio Risk Ratio<br>BakheitStudyor Subgroup Events Total Events Total Weight M-H, Random, 95% Cl MH, Random,95% Cl<br>Bakheit (TBA 1000 U) 2000 2 2 13 19 87% 1,33 10.95, 1.88)<br>Bakheit (TBA(TBA 1500U)S00U) 2000 2000 152 22191319«13° 19 8.3%87% 1.451.33 (0.79,(0.95, 1.69),1.85),<br>Bakhelta 2001 2 9 22 32 9.0% 1.49 (0.88, 1.59),<br>Elovic 2016 119° 171-33 8B 8.0% 1.86 [1.39, 2.47] _<br>Gracies (1000 U) 2015 62 79 18 79 80% 3.44 [2.26, 5.25), —_<br>Gracies (600 U) 2015 59 801879 80% 3.24 (2.11, 4.96), —_<br>Kanovsky 2009 60 73 QF 73 BT% 1.85 [1.32, 2.60], _<br>O’Dell 2015 9 14 2 9 30% 2.89 0.80, 10.44)<br>Suputttada (TBA 1000 U) 2005 5 5 13 15 88% 1.09 (0.79, 1.50),<br>Suputtitada (TBA 350 U) 2005, 15 15 13 159.4% 1.45 (0.91, 1.44)<br>Suputtitada (TBA 500 U) 2005 15 15 1315 9.4% 4.45 (0.91, 1.44)<br>Yelnik 2007 7 40 0 10 09% 15.00 (0.97, 231.84)<br>Total (95% Cl) 552 472 100.0% 1.60[1.22, 2.08] °<br>Total events 418 198<br>Heterogeneity: Tau<br>= 0.18; Chit= 84.97, df= 12 (P < 0.00001); P= 86%<br>Testor overall effect.Z= 3.46 (P = 0.0008) ‘ . por Favoursoa [control] ' Favours [expa e rimental]‘90<br><!-- End of picture text -->  
TBA: Toxina Botulínica do Tipo A. Para o estudo que apresenta os resultados por região do corpo de aplicação, foi selecionado o resultado com o maior número de pacientes<sup>7</sup> .  
**Figura E** - _Forest plot_ da proporção de pacientes que tiveram redução de 1 ponto ou mais na escala de Ashworth (EA) e na escala de Ashworth modificada (EAM) – Membros Inferiores.  
<!-- Start of picture text -->
Study or Subgrouy EventsTBA Total_EventsPlaceboTotal Weight M-H, Random,Risk Ratio Risk Ratio<br>WeinPittockPittockPittock 2018(TBA(TBA(TBA 1500U)500U)1000 U)200320032003, 121235?23359233°58 Gt888 236855555 32.4223%223%229 % 2.772.7334 . 6134/1.09[1.36,[1.33,{1.8295% ,  71 64)667]8.87] . 17] 20032003 20 Cl_Year1803 MH, Random,—————95% Cl<br>Total (95% Cl) 407 400 100.0% 2.32 [1.30, 4.14] ><br>Total events 198 118<br>Heterogeneity.<br>Testor overall effect:Tau = 0.26;Z= 2.85Chi*=(P= 13.43,0.004) df= 3 (P= 0,004); F= 78% bn Favoursth [control] + Favours [experimental]+h ad<br><!-- End of picture text -->  
TBA: Toxina Botulínica do Tipo A.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Redução da dor associada à espasticidade</u>** -->
No **Quadro G** , estão descritos os ECR que avaliaram a dor associada à espasticidade. Diferentes instrumentos e tempo de avaliação foram utilizados, impossibilitando a realização de meta-análise dos dados. Por esse motivo, os resultados foram relatados de forma descritiva.  
Dos estudos que avaliaram os membros superiores, seis relataram diferença estatisticamente significativa na redução de dor, favorecendo a TBA em comparação ao placebo<sup>8–10,13,24,25</sup> . Três estudos relataram diferença não estatisticamente significativa entre os grupos<sup>11,17,22</sup> e um descreveu uma redução numericamente superior da dor no grupo TBA, sem tratamento estatístico do resultado<sup>20</sup> . Para os membros inferiores, houve uma maior redução da dor em pacientes do grupo TBA em comparação ao placebo em dois estudos<sup>31,38</sup> . Dois estudos não encontraram diferença estatisticamente significativa entre os grupos TBA e placebo<sup>30,35</sup> e outros dois não fizeram nenhuma análise de inferência, sendo que um demonstrou maior proporção de pacientes sem dor no grupo da TBA<sup>33</sup> e um maior proporção sem dor no grupo do placebo<sup>39</sup> .  
Para os estudos que avaliaram tanto os membros superiores quanto inferiores, um estudo encontrou superioridade da TBA na redução da dor<sup>46</sup> e outro não encontrou diferença entre os grupos<sup>44</sup> .  
**Quadro G -** Avaliação da redução da dor associada a espasticidade após o tratamento com toxina botulínica do tipo A (TBA) em comparação a placebo  
|**Autor, ano**|**Escala utilizada**|**Resultados**|
|---|---|---|
|**Membro Superior**|||
|Lam, 2012<sup>9</sup>|_Pain Assessment in Advanced_<br>_Dementia_(PAINAD)_Scale_<sup>a</sup>(escala<br>numérica 0 a 10)<br>Avaliação: Semanas 2, 6, 8, 12, 16,<br>20 e 24|Os pacientes no grupo de tratamento tiveram uma melhora<br>significativa na pontuação PAINAD em repouso na semana<br>6. No entanto, não houve diferença significativa na mudança<br>entre os dois grupos nas 24 semanas do estudo. Diferença<br>média entre grupos na mudança da linha de base (IC 95%):<br>Semana 6 – dor no descanso:  1,27 [0,21; 2,34], p=0,02<br>Semana 6 – dor em cuidados básicos: -0,11 (-1,45; 1,24)<br>p=.874<br>Semana 24 – dor no descanso:  1,20 (-0,08; 2,48); p=0,065<br>Semana 24 – dor em cuidados básicos: 0,03 (-1,56; 1,62),<br>p=0,972|
|Marciniak, 2012<br>(NCT00661089)<sup>10</sup>|McGill_Pain Questionnaire - Short_<br>_Form_<sup>b</sup>e questionário diário sobre dor<br>(pior dor, melhor dor, dor para se<br>vestir e dor interferindo no sono)<br>Diferença de 2 pontos foi<br>considerada clinicamente<br>significativa<br>Avaliação: semanas 2, 4 e 6|A redução dos descritores de dor avaliados pelo Questionário<br>de Dor McGill não foi estatisticamente significativa na<br>comparação entre os grupos: Média (SD)<br>Semana 2 - TBA: -1.60 (-7,42 a 4,22) vs Placebo: -2,09 (-<br>6,83 a 2,64), p=0,884<br>Semana 4 - TBA: - 1,00 (-6,85 a 4,85) vs Placebo: -2.00 (-<br>6,71 a 2,71), p= 0,766<br>Semana 6 – TBA: -3,80 (-11,33 a 3,73) vs Placebo: -2,27 (-<br>8,09 a 3,55)<br>No questionário diário sobre dor, não houve, também,<br>diferença estatisticamente significativa entre os dois grupos.|
|Rosales, 2012<br>(NCT00234546)<sup>17</sup>|Escala visual analógica (EVA; 0–100<br>mm)<br>Avaliação: semanas 2, 4, 8, 12 e 24|Embora nem todos os participantes tenham relatado dor<br>(placebo: 34/83; TBA: 40/80), os participantes que<br>receberam a TBA relataram reduções na dor relacionada à<br>espasticidade em comparação com o valor basal ao longo do<br>estudo, e isso foi significativamente maior do que o placebo<br>nas semanas 4 e 24. Redução da dor TBA vs Placebo –<br>diferença (IC 95%)<sup>f</sup>:<br>Semana 2: −3,50 (−9,43, 2,43); Semana 4: −7,87 (−13,28,<br>−2,46); Semana 8: −5,84 (−12,61, 0,94); Semana 12: −5,93<br>(−12,63, 0,77); Semana 24: −7,15 (−13,76, −0,54).|
|McCrory, 2009<sup>13</sup>|Escala visual analógica (EVA; 0-<br>100mm)<br>Avaliação: semanas 8, 12, 20 e 24|Menos da metade dos pacientes relatou dor significativa. O<br>tratamento com TBA não mostrou melhora significativa na<br>dor em comparação com o placebo. Diferença entre TBA vs<br>placebo (IC 95%):<br>Semana 8: 5,07 (–10,9, 21,0); p=0,53<br>Semana 20: 10,14 (–8,1; 27,4); p=0,25|  
|**Autor, ano**|**Escala utilizada**|**Resultados**|
|---|---|---|
|||Uma subanálise da mudança no escore de dor em movimento<br>foi conduzida apenas para aqueles com uma classificação de<br>dor ≥ 25 em movimento no início do estudo (n = 40).<br>Dentro deste subconjunto, ambos os grupos mostraram<br>redução significativa nos níveis de dor nas semanas 8 e 20.<br>Foi observada diferença estatisticamente significativa entre<br>os grupos na semana 12, mas não nas semanas 8 e 20.<br>Destaca-se, porém, que aqueles tratados com TBA tiveram<br>níveis significativamente mais elevados de dor ao movimento<br>no início do estudo e isso pode ser responsável pela redução<br>da dor relativamente maior neste grupo. Os dados não são<br>relatados pelos autores.|
|De Boer, 2008<sup>25</sup>|Escala visual analógica (EVA; 0–<br>100mm).<br>Avaliação: semanas 6 e 12|Ao final do período de acompanhamento, observou-se<br>melhora média da redução do escore de dor EVA (p = 0,08).<br>No<br>entanto,<br>não<br>houve<br>diferença<br>estatisticamente<br>significativa entre a TBA e o placebo (p= 0,61)|
|Marco, 2007<br>(RHBESPE/TOXIN-<br>1)<sup>11</sup>|Escala visual analógica (EVA; 0-<br>100mm)<sup>c</sup><br>Clinicamente significativa: 33,3 mm<br>Avaliação: semana 1 e meses 1, 3 e 6<br>(ao imobilizar o ombro)|A TBA é mais eficaz do que o placebo na redução da dor. A<br>redução na EVA foi observada nos dois grupos na primeira<br>semana, sendo que a magnitude dessa diminuição foi maior<br>no grupo da TBA em comparação com o grupo do placebo.<br>Os valores da EVA continuaram nos meses subsequentes<br>(primeiro, terceiro e sexto) para os dois grupos, com uma<br>diferença estatisticamente significativa entre eles (p = 0,035).<br>EVA - média (DP):<br>Antes da infiltração: TBA:76,4 (15,6) vs Placebo:70,1 (15,3)<br>Semana 1- TBA: 44,4 (25,9) vs Placebo: 59.3 (21.0)<br>Mês 1- TBA:38,7 (27,0) vs Placebo: 60,1 (22,1)<br>Mês 3 – TBA: 35,4 (25,3) vs Placebo: 56,7 (23,4)<br>Mês 6 – 30,1 (26,9) vs Placebo: 48,3 (29,4)<br>Efeitos de interação: 0,035|
|Yelnik, 2007<sup>22</sup>|Escala verbal (0 a 10 pontos)<br>Avaliação: semana 4|Houve melhora da dor no período observado após a<br>administração da TBA, enquanto mudanças mínimas pós-<br>tratamento foram observadas no grupo do placebo. A<br>melhora da dor apareceu logo na semana 1 e foi<br>significativamente diferente na semana 4. Redução na escala<br>de dor (mediana):<br>Semana 1 - TBA: -2,8 vs Placebo: -1,3; p=0,234<br>Semana 2: TBA: -3,6 vs Placebo: -1,6; p=0,098<br>Semana 4: TBA: -4,0 vs Placebo: -1,0; p=0,025|  
|**Autor, ano**|**Escala utilizada**|**Resultados**|
|---|---|---|
|Suputtitada, 2005<sup>20</sup>|Escala visual analógica (EVA; 0 -10)<br>Avaliação: semanas 2, 4, 8, 16 e 24|No grupo que foi tratado com TBA, houve maior redução da<br>média de EVA em comparação ao placebo. Redução média<br>do EVA (DP):<br>4 semanas - TBA 350 U: -4,1 vs TBA 500 U: -5,6 vs TBA<br>1000: -8,4 vs Placebo: -0,5<br>8 semanas - TBA 350 U: -5,27 (3,06) vs TBA 500 U: -7,93<br>(2,73) vs TBA 1000:  -9,20 (1,10) vs Placebo: -0,87 (0,64)|
|Childers, 2004<sup>24</sup>|Escala de frequência de dor de 5<br>pontos (0, nunca; 4, constante), uma<br>escala de gravidade de dor de 5<br>pontos (0, nenhuma; 4, muito grave,<br>intolerável)|Apenas 27% (25/91) dos indivíduos indicaram que sentiam<br>dor na avaliação inicial (basal).<br>Os escores médios de frequência de dor no início do estudo<br>eram baixos, variou de 1,0 (ocorre às vezes) no placebo e<br>grupo de TBA 90U, para 1,3 nos grupos TBA 180 U e TBA<br>360 U. Os escores de intensidade basal variaram de 1,3 (dor<br>leve) no grupo de TBA 90 U para 1,5 nos grupos TBA 180 U<br>e TBA 360 U.<br>Não foi observada diferenças significativas na frequência e<br>intensidade entre os grupos. Os dados não são relatados pelos<br>autores.|
||Escala visual analógica (EVA; 0 -<br>10)<br>Diferença de 2 pontos foi<br>considerada como clinicamente|Após a injeção, houve redução na pontuação da EVA em<br>ambos os grupos em todos os períodos de acompanhamento.<br>Nenhuma diferença estatística pôde ser detectada entre os<br>dois grupos: Mediana (IQ)|
|Kong, 2004<sup>8</sup>|significativa<br>Avaliação: semanas 4, 8 e 12|Semana 4 - TBA: -2,0 (-2,0 a -1,0) vs Placebo: - 3,0 (-4,0 a -<br>1,3), p=0,21<br>Semana 8 - TBA: -2,0 (-1,5 a 3,0) vs Placebo: -2,0 (-5,4 a<br>1,3), p=0,48<br>Semana 12 - TBA: -3,0 (-3,5 a -0,5) vs Placebo: -2,0 (-4,0 a<br>-1,8), p=0,50|
|**Membro Inferior**|||
|Diniz, 2021<br>(SPASTOX /<br>NCT02604186)<sup>30</sup>|_Brief Pain Inventory_(BPI)<sup>d</sup>, que foi<br>separado em 2 domínios: intensidade<br>da dor (BPI-S; intervalo, 0 - 10) e<br>interferência da dor (BPI-I; intervalo<br>0 - 10)|Não houve diferença estatisticamente significativa entre o<br>grupo TBA em comparação ao placebo:<br>BPI-S pré vs pós-média (DP):<br>TBA: 1,76 ± 2,35 vs 1,58 ± 2,32 / Placebo: 1,81 ± 2,20 vs<br>1,56 ± 2,16, p=0,83|
||Avaliação: semana 8|BPI-I pré vs pós-média (DP):<br>TBA: 1,29 ±2,21 vs 1,16 ± 2,22 / Placebo: 1,10±1,66 vs<br>1,13±1,92; p= 0,75|
|Wein, 2018|Escala de 11 pontos: 0 (sem dor) a 10|Sem diferenças significativas entre os grupos de tratamento|
|(NCT01575054 -<br>REFLEX)<sup>35</sup>|(a pior dor que se pode imaginar) nas<br>últimas 48 horas durante caminhada|em qualquer momento da fase duplo-cega do estudo. Os<br>autores não relatam os resultados.|  
|**Autor, ano**|**Escala utilizada**|**Resultados**|
|---|---|---|
||Avaliação: semanas 4, 6||
|Dunne, 2012<br>(BTOX-702-8051)<br>31|Escala visual analógica (EVA; 0-<br>100mm)<sup>e</sup><br>Avaliação: 12 semanas|Houve diferença estatisticamente significativa da melhora da<br>dor em 20% no grupo TBA em comparação ao do placebo:<br>Melhora da dor em 20% em 12 semanas - TBA:8/14 vs<br>Placebo:1/8; p=0,02|
|Gusev, 2008<sup>38</sup>|A intensidade da dor na coxa foi<br>avaliada pedindo aos pacientes que<br>classificassem o grau de dor<br>associado a espasticidade em ambas<br>as coxas em repouso de acordo com<br>uma escala de quatro pontos [0 =<br>ausente, 1 = leve, 2 = moderado e 3 =<br>forte].|A proporção de respondentes foi maior no grupo da TBA em<br>comparação ao do placebo:<br>Perna direita - Semana 4: TBA x placebo: p=0,092; Semana<br>8: TBA x placebo: p=0,008; Semana 12: TBA x placebo: p =<br>0,013;<br>Perna esquerda: Semana 4: TBA 1000 – 1500 U x placebo:<br>p=0,027; Semana 8: TBA1000–1500 U x placebo: p=0,008;<br>Semana 12: TBA1000–1500 U x placebo: p=0,008|
||Avaliação semanas 4, 8 e 12||
|Pittock, 2003<sup>33</sup>|Uma avaliação subjetiva da dor no<br>joelho, perna, tornozelo ou pé foi<br>pontuada em uma escala de 4 pontos<br>[sem dor (0), dor leve (1), dor<br>moderada (2), dor intensa (3)]. A<br>pontuação geral foi a soma das<br>pontuações de cada articulação.<br>Avaliação: semanas 4, 8 e 12|No início do estudo, os escores de dor foram significativamente<br>maiores naqueles que receberam a TBA 1.000 U e TBA 1.500<br>U em comparação com o placebo.<br>Nos grupos tratados com TBA, uma redução na dor foi<br>registrada em cada momento, com pouca mudança observada no<br>grupo placebo.  As maiores reduções foram observadas em 8<br>semanas na TBA 1.000 unidades, mas também na TBA 1.500<br>unidades na semana 4 e na 12. Proporção de pacientes que<br>tiveram redução da dor – n (%)<br>Semana 4 – TBA 500: 14 (24%) vs TBA 1000: 23 (38%) vs<br>TBA 1500: 20 (33%) vs Placebo: 11 (20%)<br>Semana 8 - TBA 500: 20 (34%) vs TBA 1000: 25 (42%) vs<br>TBA 1500: 23 (38%) vs Placebo: 10 (18%)<br>Semana 12 - TBA 500: 18 (31%) vs TBA 1000: 22 (37%) vs<br>TBA 1500: 17 (28%) vs Placebo: 10 (18%)|
|Hyman, 2000<sup>39</sup>|Escala de quatro pontos (ausente,<br>leve, moderado e forte)<br>Avaliação: semanas 2, 4, 8 e 12|A proporção de pacientes sem dor aumentou para todos os<br>grupos na semana 4 em comparação com a semana 0. Embora<br>a maior melhora tenha sido no grupo do placebo, as<br>proporções de pacientes sem dor na semana 4 foram<br>semelhantes para todos os grupos. Proporção de pacientes<br>sem dor na perna – n (%):<br>Semana 0 – TBA 500 U: 11 (52%) vs TBA 1000 U: 6 (30%)<br>vs TBA 1500 U: 7 (41%) vs Placebo: 3 (19%)|  
|**Autor, ano**|**Escala utilizada**|**Resultados**|
|---|---|---|
|||Semana 4 - TBA 500 U: 11 (61%) vs TBA 1000 U: 7 (41%)<br>vs TBA 1500 U: 11 (65%) vs Placebo: 10 (67%)|
|**Os dois membros**|||
|Jacobson, 2021<br>(NCT02434549)<sup>44</sup>|BPI_, Brief Pain Inventory–Short_<br>_Form_<sup>d</sup>– avaliou o número de<br>respondentes ao tratamento (definido<br>como uma redução da pontuação de<br>interferência média de ≥1 no BPI)|Não houve diferenças significativas entre os grupos na<br>interferência da dor (conforme avaliado com o BPI) 10<br>semanas após o tratamento. Os resultados não foram<br>relatados pelos autores.|
||Avaliação: semana 6 e 10||
|Wissel, 2016 (BEST|Escala de avaliação numérica de dor|Na semana 12, a redução média da dor em relação ao início|
|(BOTOX Economic|de 11 pontos (0 = sem dor a 10 = dor|do estudo foi maior no grupo TBA em comparação ao|
|Spasticity Trial /<br>NCT00549783)<sup>46</sup>|tão forte quanto pode ser imaginada)<br>Avaliação: semana 12|placebo. Redução média em relação a linha de base<br>Placebo + tratamento padrão: -0,13 [IC 95% -0,51; 0,24]<br>TBA + tratamento padrão: -0,77 [IC 95% -1,14; -0,40]; P<<br>0,05|  
DP: desvio padrão; TBA: toxina botulínica do tipo A; EVA= Escala Visual Analógica a) Lam (2012); utilizou a _Pain Assessment in Advanced Dementia_ (PAINAD) _scale_ , publicada por Warden V. _et al._ (2003)<sup>54</sup> ; b) Marcianiak (20122): utilizou The _short-form McGill pain questionnaire_ , publicado por Melzack R. (1987)<sup>55</sup> ; c) Marco (2007): utilizou a escala visual publicada por Collins _et al._ (1997)<sup>56</sup> ; d) Diniz (2021) e Jacobson (2021): utilizou o _Brief Pain Inventory_ (BPI) publicado por Ferreira _et al_ (2011)<sup>57</sup> ; e) Dunne (2012): utilizou a escala visual analógica publicada por Farrar, _et alI_ (2001)<sup>58</sup> ; f) Rosales, 2012<sup>17</sup> : Semana 2: não estatisticamente significativas; Semana 4: p=0,0043; Semana 8: não estatisticamente significativas; Semana 12: não estatisticamente significativas; Semana 24: p=0,340.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Melhora da qualidade de vida relacionada à saúde</u>** -->
Dos sete estudos que avaliaram a qualidade de vida, apenas um deles demonstrou melhora significativa entre os grupos TBA e placebo<sup>24</sup> . Essa melhora, no entanto, foi observada apenas no domínio que avalia aspectos sociais do _Short Form-_ 36 (SF36). No **Quadro H** , estão descritos os instrumentos utilizados por cada estudo, bem como seus resultados. Assim como na avaliação da dor, não foi possível realizar a meta-análise dos dados, uma vez que foram utilizados diferentes instrumentos e tempos de avaliação.  
**Quadro H -** Avaliação da melhora da qualidade de vida após o tratamento com toxina botulínica do tipo A (TBA) em comparação a placebo  
|**Autor, ano**|**Instrumento utilizado**|**Resultados encontrados**|
|---|---|---|
|**Membro Superior**|||  
|**Autor, ano**|**Instrumento utilizado**|**Resultados encontrados**|
|---|---|---|
|Gracies, 2015<br>(NCT01313299)<sup>28</sup>|SF-36 e EQ-5D<br>Avaliação: semana 12|Foi relatado que os subescores de qualidade de vida (SF-36 e EQ-<br>5D) no final do estudo ou retirada precoce permaneceram<br>inalterados em cada um dos três grupos. Não houve, também,<br>diferença estatisticamente significativas entre os grupos. Média<br>(SD):<br>**SF-36 (componente mental):**<br>Placebo: 1,28 (8,67)<br>TBA 1000 U: -0,00 (11,06); p=0,8720<br>TBA 500 U: 0,48 (91,2); p=0,9406<br>**SF-36 (componente físico):**<br>Placebo: 1,77 (7,53)<br>TBA 500 U: 0,68 (6,03); p=0,1878<br>TBA 1000 U: 1,16 (6,01); p=0,7696<br>**EQ-5D VAS**<br>Placebo: 2,0 (19,6)<br>TBA 500 U: 2,4 (18,9), p=0,8102<br>TBA 1000 U: 2,9 (15,9), p=0,4536|
|Wolf, 2012 (IIT-<br>000121)<sup>21</sup>|_Stroke Impact_Scale (SIS)<br>Avaliação: 24 meses|Não foram observadas diferenças entre os grupos para nenhum dos<br>domínios do SIS:<br>Função manual: P=0,89;<br>Domínio físico; p=0,86;<br>Recuperação da mão: p=0,09.<br>Domínios de força; p=0,40.|
|McCrory, 2009<sup>13</sup>|AQoL<br>Avaliação: semana 20|Não foi observada diferença entre grupos em comparação aos<br>resultados basais: -0,03 [IC 95% -0,09; 0,02]; p=0,27|
|Jahangir, 2007<sup>29</sup>|EQ-5D e EQ-VAS<br>Avaliação: semanas 4 e<br>12|Tanto os pacientes do grupo TBA, quanto do placebo tiveram<br>melhora nas pontuações medianas do EQ-5D e VAS em todas as<br>visitas de acompanhamento em comparação com os valores basais.<br>No entanto, não houve mudanças significativas entre os grupos em<br>todas as visitas de acompanhamento. Mediana (Q1, Q3):<br>**TBA - EQ-5D:**<br>Semana 0 - TBA: 0,205 (0,205; 0,682) vs Placebo: 0,364 (0,205;<br>0,682); p=0,846<br>Semana 4 - TBA: 0,364 (0,205; 0,682) vs Placebo: 0,364 (0,046;<br>0,841); p=0,712<br>Semana 12 – TBA: 0,523 (0.205; 0,682) vs Placebo: 0,523 (0,046;<br>0,921); p=0.941<br>**TBA – EQ VAS:**<br>Semana 0 – TBA: 60 (50; 70) vs Placebo: 55 (40; 72,5); p=0,427<br>Semana 4 – TBA: 70 (60; 80) vs Placebo: 60 (45; 80); p=0,442|  
|**Autor, ano**|**Instrumento utilizado**|**Resultados encontrados**|
|---|---|---|
|||Semana 12 – TBA: 70 (55; 80) vs Placebo: 60 (45; 80); p=0,363|
|Childers, 2004<sup>24</sup>|SF-36<br>Avaliação: semana 6|A única melhora significativa em comparação com placebo foi no<br>grupo TBA 90U, na semana 6 na seção de funcionamento social<br>(Média [SD]: 20,8 [34,0] vs. -10,0 [24,2]; p=0,002). Uma relação<br>dependente da dose não foi observada. Mudança média em<br>comparação aos resultados basais:<br>Placebo: -10,0 (24,2)<br>TBA 90U: 20,8(34,0)<br>TBA 180U: -5,1 (42,7)<br>TBA 360U: -4,4 (27,9)|
|**Membro inferior**|||
|Napoli, 2018; Gracies,<br>2017<br>(CT01249404)<sup>32,37</sup>|SF-36<br>EQ-5D|Não relatam os resultados, só mencionam que não houve diferença<br>dos resultados em comparação aos valores basais.|
|Maanum, 2011<br>(NCT00432055)<sup>42</sup>|SF-36<br>Avaliação: 8 semanas|Não houve diferença estatisticamente significativa entre os grupos.<br>Média ajustada (IC 95%) – diferença entre os grupos:<br>Capacidade funcional: –1,2 (–7,6 a 5,2)<br>Limitação por aspectos físicos: –11,6 (–29,1 a 5,9)<br>Dor: –4,4 (–12,9 a 4,2)<br>Estado geral de saúde: –4,7 (–11,8 a 2,4)<br>Vitalidade: –0,27 (–7,8 a 7,7)<br>Aspectos sociais: 3,4 (–4,0 a 10,9)<br>Aspectos emocionais: 5,7 (–8,1 a 19,5)<br>Saúde mental: 1,4 (–4,4 a 7,2)|  
AQoL: _Assessment of Quality of Life_ ; EQ-VAS: _EuroQol-visual analogue scales_ ; EQ-5D: _EuroQol 5 Dimensions_ ; SF-36: _Short Form_ -36.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Frequência de eventos adversos</u>** -->
O risco de apresentar algum evento adverso foi maior no grupo do TBA quando comparado ao placebo apenas para a análise dos membros superiores ( **Figura F** ): Risco relativo (RR): 1,15 [IC 95%: 1,02; 1,30]. Para os membros inferiores, não houve diferença entre os grupos ( **Figura G** ): RR: 1,18 [IC 95% 0,99; 1,41] e o risco de apresentar algum evento adverso grave não diferiu entre os grupos TBA e placebo nem para os membros superiores (RR: 1,51 [IC 95% 0,94;2,42]), nem para os membros inferiores (RR: 0,88 [IC 95% 0,50; 1,57]). Apenas um estudo que avaliou ambos os membros apresentou dados de eventos adversos, sendo que o grupo do placebo apresentou maior frequência que o grupo da TBA (Eventos adveros graves – TBA: 75%; Placebo: 88%)<sup>44</sup> .  Para todas as avaliações, a certeza da evidência foi considerada baixa.  
<!-- Start of picture text -->
1.1.1Study Eventosor SubgroupAdversosEvents(Total)TBA Total_EventsPlaceboTotal _Weight_M.H. RiskRandom, Ratio95% Cl_Year M.H, RiskRandom, Ratio 95% Cl<br>Bakheit 2000 25 63 8 19 4.0% 0.94 (0.81, 1.73] 2000<br>Bhakta 2000 3 20 3 17 07% 0.86 (0.20, 3.67] 2000<br>Bakheita 2001 18 27 «620 32. 87% 0.95 (0.63, 1.43] 2001<br>ChildersKong 20042004 546517286 16 6 16 16.3%1.6% 1.271.20 (0.94,10.46, 3.15]1.72] 20042004<br>Yelnik 2007 3 10 2 10 06% 1.50 (0.32, 7.14) 2007<br>KanovskyMcCrory 20082009 27300207536 5402842 «16.1%5.4% 1.081.08 (0.80,(0.64, 1.82]1.46] 20092009<br>Simpson 2009 8 2 10 19 3.1% 0.76 (0.38, 1.61] 2009<br>Kaji 2010. 32. 720-2 OF 10.1% 0.78 (0.53, 1.15) 2010<br>WolfRosales20122012, 48°6 8012 «36-833 13 16.0%1.0% 1,381.81 (1.02,(0.55, 6.98]1.87] 20122012<br>Gracies 2015 70 162 21 81 88% 4.87 (1.11, 2.51] 2018 ——<br>Elovic 2016 47 210 18 107 61% 1.33 (0.81,217] 2016<br>Rosales 2018, 8 28 414 1.4% 1,00 [0.36, 2.76] 2018<br>Subtotal (95% Ci) 912 591 100.0% 4.15 [1.02, 1.30}<br>Total events 382 214<br>Heterogeneity: Tau?<br>Test for overall effect:= 0.00;Z= 2.25 Ch#=(P = 13.20, 0.02) df= 14 (P= 0.51); F= 0%<br>1.1.2 Eventos adversos (graves)<br>KajiRosalesChilders2010 2012 2004 12185 806572 «138331 2637 84.6%16.2%51% 2.671.604.440.31,(0.49,(0.75,21.20)2.74]5.21] 200420102012<br>Gracies 2018 6 162 3 81 12.2% 1.00 (0.26, 3.90) 2015<br>ElovicRosales 20162018, 73 21028 20 10714 9.4%27% 3620.20,1,78 (0.38,65.60]8.44) 20162018<br>Subtotal (95% Cl) 617 348 100.0% 1.51 (0.94, 2.42]<br>Total events 51 22<br>Heterogeneity: Tau*= 0.00; ChF= 1.03, df= 5 (P<br>Test for overall effect: Z= 1.69 (P = 0.09) = 0.96); F= 0%<br>01 on i 10 100<br>Favours [experimental] Favours [control]<br><!-- End of picture text -->  
**Figura F -** _Forest plot_ da frequência de eventos adversos (total e graves) - Membros Superiores TBA: Toxina Botulínica do Tipo A.  
<!-- Start of picture text -->
7.1.1‘StudyEventos or SubgroupadversosEvents(Total)TBA Total_EventsPlaceboTotal Weight _M-H, RiskRandom, Ratio 95%CI_Year M.H, Random,Risk Ratio 95% Cl<br>Hyman 2000 32. 68 «= 1018 10.5% 0.88 (0.7, 1.38] 2000<br>Pittock 2003 52 176 15 55 9.7% 1.03 [0.64, 1.65] 2003<br>‘Gusev 2008 29° «$4 14 S187 1.98 (1.17, 3.26] 2008 _—<br>Kaji 2010 28 58 «27 «62 :12:0% 1.03 (0.69, 1.54) 2010<br>Maanum 2011 a 32 7 33° 37% 1.33 (0.66, 3.13] 2011<br>‘WeinDunne2018,2012 195 23168 112980 233 20.5%5.2% 0.544.20 (0.27,(0.95, 1.09]1.52] 20182012<br>Masakado 2020 32 87 «12,33 85% 1.31 (0.78, 2.20) 2020<br>Napoli 2020 107 255 41-130. 17.1% 4.33 (0.99, 1.78] 2020<br>Diniz 2021 14 51 7 St 40% 2.00 (0.88, 4.54] 2021<br>Subtotal (95% CI) 1034 693 100.0% 1.18 [0.99, 1.41]<br>TotalHeterogeneity:Testevents Tau*= 0.02;407 Chi¥= 13.55, df=225 9 (P = 0.14); P= 34%<br>for overall effect: Z= 1.85 (P = 0.08)<br>Pittock1.1.2 Eventos2003 adversos (grave)10 174 5 86 309% 0.63 (0.23, 1.77] 2003<br>Kaji 2010 5 58 1 62 7.3% 5.34 0.64, 44.39] 2010,<br>DunneNapoli 20202012 106 25554 37 13028 191%36.9% 1.070.73 (0.28,(0.29, 3.98]1.87] 20122020<br>Masakade 2020 2 67 133 59% 0.99 0.09, 10.47] 2020<br>Subtotal (95% Cl) 608 308 100.0% 0.88 (0.50, 1.57]<br>TotalHeterogeneity:Testevents Tau*= 0.00; Chi*=33 3.82, df= 4 (P17 = 0.47); P= 0%<br>for overall effect Z= 0.42 (P= 0.67)<br>oot at 7 10 00<br>Favours [experimental] Favours [control]<br><!-- End of picture text -->  
**Figura G -** _Forest plot_ da frequência de eventos adversos (total e graves) - Membros Inferiores  
TBA: Toxina Botulínica do Tipo A.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Perfil de evidências:** -->
Nas **tabelas A e B** , são apresentados os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos alteração da média da EA/EAM, proporção de pacientes com redução de um ponto ou mais na escala de EA/EAM e a frequência de eventos adversos.  
**Tabela A** - Toxina botulínica do tipo A comparada a placebo, para o tratamento de espasticidade na população adulta  
|||**A**|**valiação da c**|**erteza**|||**№ de pa**|**cientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estu**<br>**dos**|**Delineame**<br>**nto do**<br>**estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistê**<br>**ncia**|**Evidê**<br>**ncia**<br>**indire**<br>**ta**|**Imprecis**<br>**ão**|**Outras**<br>**considera**<br>**ções**|**Toxina**<br>**Botulíni**<br>**ca A**|**Placeb**<br>**o**|**Relativ**<br>**o**<br>**(95%**<br>**IC)**|**Absoluto**<br>**(95% IC)**|**Certeza**|**Importânci**<br>**a**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Alteração da média Escala de Ashworth - membros superiores (Escala de: 1 para 5)** -->
|15<br>**Altera**|ensaios<br>clínicos<br>randomizad<br>os<br>**ção da média**|grave<sup>a</sup><br>**da escala**|grave<sup>b</sup><br>**de Ashworth**|não<br>grave<br>**- membr**|não grave<br>**os inferiores (**|nenhum<br>**Escala de: 1**|831<br>**para 5)**|679|-|MD**0.8 mais**<br>**alto**<br>(0.63 mais alto<br>para 0.97 mais<br>alto)|⨁⨁◯◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|6|ensaios|grave<sup>c</sup>|grave<sup>b</sup>|não|não grave|nenhum|601|612|-|MD**0.27 mais**|⨁⨁◯◯|CRÍTICO|
|**Redu**|clínicos<br>randomizad<br>os<br>**ção de um pon**|**to ou mai**|**s na escala de**|grave<br>**Ashwort**|**h - membros**|**superiores**||||**alto**<br>(0.15 mais alto<br>para 0.39 mais<br>alto)|Baixa||
|8|ensaios|grave<sup>d</sup>|não grave|não|não grave|nenhum|418/552|198/47|RR 1.60|**25 mais por**|⨁⨁⨁◯|CRÍTICO|
||clínicos|||grave|||(75.7%)|2|(1.22|**100**|Moderada||
||randomizad<br>os|||||||(41.9<br>%)|para<br>2.08)|(de 9 mais<br>para 45 mais)|||
|**Redu**|<br>**ção de um pon**|**to ou mai**|**s na escala de**|**Ashwort**|**h - membros**|**inferiores**|||||||
|2|ensaios|grave<sup>e</sup>|grave<sup>b</sup>|não|grave<sup>f</sup>|nenhum|198/407|115/40|RR 2.32|**379 mais por**|⨁◯◯|CRÍTICO|
||clínicos|||grave|||(48.6%)|0|(1.30|**1.000**|◯||  
||randomizad<br>os|||||||(28.7<br>%)|para<br>4.14)|(de 86 mais<br>para 903 mais)|Muito<br>baixa||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Frequ**|**ência de event**|**os advers**|**os (Total) - m**|**embros s**|**uperiores**||||||||
|15|ensaios|muito|não grave|não|não grave|nenhum<sup>g</sup>|382/912|214/59|RR 1.15|**54 mais por**|⨁⨁◯◯|IMPORTA|
||clínicos|grave<sup>d</sup>||grave|||(41.9%)|1|(1.02|**1.000**|Baixa|NTE|
||randomizad<br>os|||||||(36.2<br>%)|para<br>1.30)|(de 7 mais<br>para 109 mais)|||
|**Frequ**|**ência de event**|**os advers**|**os (graves) -**|**membros**|**superiores**||||||||
|6|ensaios<br>clínicos|muito<br>grave<sup>d</sup>|não grave|não<br>grave|não grave|nenhum<sup>g</sup>|51/617<br>(8.3%)|22/348<br>(6.3%)|RR 1.15<br>(0.94|**9 mais por**<br>**1.000**|⨁⨁◯◯<br>Baixa|IMPORTA<br>NTE|
||randomizad<br>os||||||||para<br>2.42)|(de 4 menos<br>para 90 mais)|||
|**Frequ**<br>|**ência de event**<br>|**os advers**<br>|**os (Total) - m**<br>|**embros i**<br>|**nferiores**<br>||||<br>|<br>|||
|10|ensaios<br>clínicos|muito<br>grave<sup>d</sup>|não grave|não<br>grave|não grave|nenhum|407/1034<br>(39.4%)|225/69<br>3|RR 1.18<br>(0.99|**58 mais por**<br>**1.000**|⨁⨁◯◯<br>Baixa|IMPORTA<br>NTE|
||randomizad<br>os|||||||(32.5<br>%)|para<br>1.41)|(de 3 menos<br>para 133 mais)|||
|**Frequ**<br>|**ência de event**<br>|**os advers**<br>|**os (graves) -**|**membros**|**inferiores**||||||||
|5|ensaios|muito|não grave|não|não grave|nenhum<sup>g</sup>|33/608|17/309|RR 0.88|**7 menos por**|⨁⨁◯◯|IMPORTA|
||clínicos<br>randomizad|grave<sup>d</sup>||grave|||(5.4%)|(5.5%)|(0.50<br>para|**1.000**<br>(de 28 menos|Baixa|NTE|
||os||||||||1.57)|para 31 mais)|||  
IC: Intervalo de confiança; DM: Diferença média; OR: _Odds ratio_ ; RR: Risco relativo  
**a.** Houve algumas preocupações sobre vieses provenientes da randomização, devido a desvios da intervenção, na aferição do desfecho e na seleção do resultado a ser relatado. Houve risco alto de viés no processo de randomização e devido a dados faltantes de desfecho; **b.** Inconsistência: o teste do Chi2 tem p-valor < 0.1 e o valor do I<sup>2</sup> é igual ou maior que 70%. No entanto, a maioria dos intervalos de confiança estão sobrepostos e eles possuem a mesma direção de efeito; **c.** Houve algumas preocupações sobre vieses provenientes da randomização, devido a desvios da intervenção, na aferição do desfecho e na seleção do resultado a ser relatado. Houve risco alto de viés no processo de randomização; **d.** Houve algumas preocupações sobre vieses provenientes da randomização, devido a desvios da intervenção, na aferição do desfecho e na seleção do resultado a ser relatado. Houve risco alto de viés no processo de randomização e desvios da intervenção; **e.** Para um dos dois estudos incluídos, houve risco de viés proveniente do processo de randomização, devido a desvios da intervenção pretendida, na aferição do desfecho e na na seleção do resultado a ser relatado; **f.** Apesar  
de não apresentar desfecho nulo, o intervalo de confiança é largo, o que pode ter sido causado pelo baixo número de participantes; **g.** Assimetria no _funnel plot_ , indicando talvez, a não publicação pelos autores dos eventos adversos graves. No entanto, como se espera que os eventos adversos graves não estejam associados à toxina botulínica, não foi rebaixada a qualidade da evidência  
**Tabela B -** Toxina botulínica do tipo A comparada a placebo, para o tratamento de espasticidade na população adulta – desfechos qualidade de vida e dor  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da certeza**<br>**Inconsistência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário dos resultados**<br>**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Dor - membro superior** -->
|10|ensaios|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|Diversas escalas foram|⨁⨁◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|
|(n= 571)|clínicos<br>randomizados||||||utilizadas pelos estudos<br>para avaliar a dor e<br>tiveram<br>resultados<br>diferentes:<br>1)<br>para<br>membros<br>superiores,<br>diferença estatisticamente<br>significativa na redução<br>da dor favorecendo TBA<sup>8–</sup><br>10,13,24,25, diferença não<br>estatisticamente<br>significativa<sup>11,17,22</sup>, e uma<br>redução<br>numericamente<br>superior da dor no grupo<br>TBA,<br>sem<br>tratamento<br>estatístico do resultado<sup>20</sup>;<br>2)<br>para<br>membros<br>inferiores,<br>redução<br>significativa<br>da<br>dor<br>favorecendo<br>TBA<sup>31,38</sup>,<br>sem<br>diferença|Baixa||  
|**№**|**Dli**|**Risco**|**Avaliação da ce**|**rteza**<br>**Eidêi**||**O**|**Sumário dos resultados**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**dos**<br>**estudos**|**eneamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**vnca**<br>**indireta**|**Imprecisão**|**utras**<br>**considerações**|**Impacto**|||
||||||||estatisticamente<br>significativa<sup>30,35</sup>e sem<br>alguma<br>análise<br>de<br>inferência,<br>mostrando<br>maior<br>proporção<br>de<br>pacientes sem dor no<br>grupo da TBA<sup>33</sup>e no<br>grupo do placebo<sup>39</sup>; 3)<br>para membros superiores<br>e inferiores, superioridade<br>da TBA na redução da dor<br>46e sem diferença entre os<br>grupos<sup>44</sup>.<br>Entre os resultados que<br>demonstraram que a TBA<br>é mais eficaz que o<br>placebo na redução da dor,<br>é possível citar:<br>- Rosales (2012)<sup>17</sup>, que<br>utilizou a escala visual<br>analógica<br>e<br>indicou<br>redução<br>significativamente maior|||  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da ce**<br>**Inconsistência**|**rteza**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário dos resultados**<br>**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
||||||||na semana 4, em que a<br>diferença (IC 95%) da<br>redução da dor TBA vs<br>placebo foi de -7,84 [-<br>13,28; -2,46]. No entanto,<br>o<br>mesmo<br>estudo<br>demonstrou<br>que,<br>na<br>semana 2, a diferença não<br>é<br>estatisticamente<br>significativa, visto que foi<br>-3,50 [-9,43; 2,43].<br>-Childers (2004)<sup>24</sup>, que<br>utilizou uma escala<br>numérica para avaliar<br>frequência e intensidade<br>de dor, apesar de não<br>detalhar os dados.<br>Concluiu que não foi<br>observada diferença<br>significativa entre os<br>grupos e que 27% (25/91)<br>participantes do estudo|||  
|**№ d**|**Dli**|**Risco**|**Avaliação da ce**|**rteza**<br>**Eidêi**||**O**|**Sumário dos resultados**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**os**<br>**estudos**|**eneamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**vnca**<br>**indireta**|**Imprecisão**|**utras**<br>**considerações**|**Impacto**|||
|**Dor - mem**<br>|**bro inferior**<br>||||||relataram que sentiam dor<br>na avaliação inicial.<br>|||
|9<br>(n=1022)|ensaios<br>clínicos<br>randomizados|grave<sup>c</sup>|grave<sup>d</sup>|não grave|não grave|nenhum|Diversas escalas foram<br>utilizadas pelos estudos<br>para avaliar dor. O estudo<br>que<br>incluiu<br>o<br>maior<br>número de participantes,<br>Wein (2018)<sup>35</sup>, utilizou<br>uma escala de 11 pontos e<br>embora os autores não<br>relatem<br>os<br>resultados,<br>concluiram que não houve<br>diferença<br>significativa<br>entre<br>os<br>grupos<br>de<br>tratamento, em qualquer<br>momento da fase duplo-<br>cega do estudo. Por outro<br>lado, o estudo conduzido<br>por Dunne (2012)<sup>31</sup>, que<br>utilizou a escala visual<br>analógica, concluiu que na<br>semana 12 houve uma|⨁⨁◯◯<br>Baixa|IMPORTANTE|  
||||**Avaliação da ce**|**rteza**|||**Sumário dos resultados**|||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
||||||||diferença estatisticamente<br>significante da melhora da<br>dor em 20% no grupo<br>tratado com TBA em<br>comparação ao placebo,<br>isto é, no grupo que<br>recebeu<br>TBA<br>8/14,<br>enquanto<br>no<br>grupo<br>placebo 1/8.|||  
**Dor - ambos os membros**  
|2|ensaios|grave<sup>e</sup>|grave<sup>f</sup>|não grave|grave<sup>g</sup>|nenhum|Foram utilizadas escalas|⨁◯◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|
|(n=289)|clínicos<br>randomizados||||||diferentes para avaliação.<br>O estudo conduzido por<br>Jacobson (2021)<sup>44</sup>utilizou<br>a Brief Pain Inventory–<br>Short Form e apesar de<br>não relatar os resultados<br>concluiu que não houve<br>diferença<br>significativa|Muito<br>baixa||
||||||||entre<br>os<br>grupos<br>na<br>interferência da dor 10|||
||||||||semanas<br>após<br>o|||
||||||||tratamento. Enquanto o|||  
|**№ d**|**Dli**|**Risco**|**Avaliação da ce**|**rteza**<br>**Eidêi**||**O**|**Sumário dos resultados**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**os**<br>**estudos**|**eneamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**vnca**<br>**indireta**|**Imprecisão**|**utras**<br>**considerações**|**Impacto**|||
||||||||estudo<br>conduzido<br>por<br>Wissel (2016)<sup>46</sup>utilizou<br>uma escala numérica e<br>demonstrou<br>que<br>na<br>semana 12 a redução<br>média da dor em relação<br>ao início do estudo foi<br>maior no grupo tratado<br>com TBA em comparação<br>ao placebo, sendo que a<br>redução no grupo placebo<br>foi -0,13 [IC 95% -0,51;<br>0,24] e no grupo que<br>recebeu TBA foi -0,77 [IC<br>95% -1,14; -0,40].|||
|**Qualidad**<br>|**e de vida – memb**<br>|**ro super**|**ior**|||||||
|5<br>(n=502)|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|Foram utilizados vários<br>instrumentos para avaliar<br>a qualidade de vida, no<br>entanto a maioria dos<br>estudos relata que não<br>houve<br>diferença<br>significativa<br>entre<br>os|⨁⨁⨁◯<br>Moderada|IMPORTANTE|  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da ce**<br>**Inconsistência**|**rteza**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário dos resultados**<br>**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
||||||||grupos, como demonstrou<br>o estudo conduzido por<br>Gracies<br>(2015)<sup>28</sup>,<br>que<br>utilizou SF-36 e EQ-5D.<br>O<br>estudo<br>McCrory<br>(2009)<sup>13</sup>,<br>que<br>utilizou<br>AQoL, relatou que não foi<br>observada diferença entre<br>os grupos em comparação<br>aos resultados basais. Já o<br>estudo Childers (2004)<sup>24</sup>,<br>que utilizou o instrumento<br>SF-36, relatou uma única<br>melhora significativa que<br>ocorreu no grupo tratado<br>com TBA 90 U em<br>comparação ao placebo,<br>na<br>seção<br>de<br>funcionamento social em<br>que a média (DP), foi 20,8<br>(34,0) vs. -10,0 (24,2);<br>p=0,002.|||  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da certeza**<br>**Inconsistência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário dos resultados**<br>**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|  
**Qualidade de vida – membro inferior**  
|2<br>(n=447)|ensaios<br>clínicos<br>randomizados|grave<sup>h</sup>|não grave|não grave|grave<sup>i</sup>|nenhum|Ambos<br>os<br>estudos<br>utilizaram o instrumento<br>SF-36.<br>O<br>estudo<br>conduzido<br>por<br>Napoli<br>(2018)<sup>32</sup>não forneceu os<br>resultados,<br>apenas<br>menciona que não houve<br>diferença dos resultados<br>em<br>comparação<br>aos<br>valores basais. O estudo<br>Maanum<br>(2011)<sup>42</sup>,<br>também relatou que não<br>houve<br>diferença<br>estatisticamente<br>significativa<br>entre<br>os<br>grupos.|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|  
**DP:** Desvio padrão. **IC:** Intervalo de confiança. **TBA:** Toxina botulínica tipo A.  
**a.** Os estudos apresentaram algumas preocupações e alto risco de viés, principalmente por não fornecerem informações suficientes sobre o processo de randomização, sigilo de alocação, cegamento das partes envolvidas e por não apresentarem protocolo; **b.** Determinados estudos, como Lam (2012)<sup>9</sup> e Marciniak (2012)<sup>10</sup> , demonstram que não houve diferença significativa na redução de dor entre os grupos, enquanto outros estudos, como Rosales (2012)<sup>17</sup> e Marco (2007)<sup>11</sup> , demonstram que a TBA é mais eficaz do que o placebo; **c.** Apenas um estudo apresentou baixo risco de viés. Três estudos apresentaram algumas preocupações sendo que um apresentou informação diferente do protocolo e significativa perda de participantes e os outros dois estudos não apresentaram protocolo. Dois estudos apresentaram alto risco de viés devido à ausência de informações sobre randomização, sigilo de alocação e cegamento; **d.** Alguns estudos apresentaram diferença significativa, enquanto outros não; **e.** Um estudo apresentou baixo risco de viés, enquanto o outro apresentou alto risco porque o desfecho avaliado não consta no protocolo e os que foram apresentados não são exatamente iguais aos registrados; **f.** Um estudo relatou que não houve diferença significativa entre os grupos, enquanto o outro relatou que houve uma redução maior no grupo tratado com TBA; **g.** Um estudo relatou que não houve  
diferença significativa entre os grupos, enquanto o outro relatou redução da dor no grupo tratado com TBA; apenas 2 estudos e tamanho amostral; **h.** Estudo conduzido por Maanum apresentou baixo risco de viés, enquanto Napoli apresentou algumas preocupações devido à falta de informações a respeito do cegamento e pelos dados utilizados na análise; **i.** Apenas 2 estudos incluídos, sendo que um deles não relata de maneira satisfatória os resultados.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Considerações</u>** -->
A TBA já está disponível no SUS e recomendada no PCDT de espasticidade publicado por meio da Portaria Conjunta SAS-SCTIE/MS nº2/2017<sup>110</sup> . Essa revisão sistemática, portanto, teve por objetivo revisitar a literatura no que diz ao seu uso para o tratamento da espasticidade na população adulta. Como resultado, foi verificado que a TBA é superior ao placebo no que diz respeito à redução do escore EA/EAM tanto em membros superiores quanto em inferiores. Além disso, a maioria dos estudos incluídos, que avaliou o desfecho dor associada à espasticidade, demonstrou maior redução nos grupos que fizeram uso da TBA. A melhora da espasticidade e da dor associada a ela, no entanto, não refletiu em melhora da qualidade de vida dos pacientes. Em relação à segurança, foi demonstrado não haver diferença na frequência dos eventos adversos no uso da TBA em comparação ao placebo. Dessa forma, manteve-se a recomendação do uso da TBA no tratamento da espasticidade em adultos.

---

<!-- METADADOS: doenca: Espasticidade | secao: **QUESTÃO 2: A TOXINA BOTULÍNICA DO TIPO A (TBA) É EFICAZ E SEGURA PARA O TRATAMENTO DA ESPASTICIDADE EM CRIANÇAS?** -->
**<u>Recomendação:</u>** A TBA é recomendada para o tratamento da espasticidade em crianças (recomendação não graduada por já ser preconizado no PCDT de espasticidade publicado por meio da Portaria Conjunta SAS-SCTIE/MS nº2/2017).  
A seleção das evidências para a revisão sistemática do uso da TBA em crianças foi realizada em duas etapas: (1) foram selecionadas revisões sistemáticas (RS) com meta-análise que avaliam o efeito da TBA em crianças; (2)  a revisão sistemática selecionada foi atualizada, incluindo-se ensaios clínicos randomizados publicados a partir da data da busca da revisão.

---

<!-- METADADOS: doenca: Espasticidade | secao: <u>Etapa 1:</u> -->
Na **Figura H** , está descrita a seleção das RS sobre a TBA para o tratamento de espasticidade em crianças. Das 13 RS identificadas ( **Quadro I** ), as duas mais recentes eram de 2019, sendo uma delas publicada pela Colaboração Cochrane (Blumetti _et al_ , 2019<sup>59</sup> ).  
**Figura H -** Fluxograma de seleção dos estudos incluídos sobre toxina botulínica no tipo A (TBA) para o tratamento da espasticidade  
<!-- Start of picture text -->
ReferénciasBasesdeidentificadas dados ern 3<br>PubMed (n= 151) Referéncias removidas antes do processo<br>Embase<br>: (n = 67) de selerao<br>Hy3 ‘CochraneLILACS (n= Library 33)  (n = 35) Duplicatas (n= 61)<br>Enistemonikos (n= 02)<br>Registros (n= 289)<br>Referéncias avaliadas por titulo Referbnclas exclidas<br>e(n=resumo238) men<br>Referénciasavaliagao porincluidas texto completopara = |_| Referénciasidentificada cujo texto completo nao foi<br>(n= 2 (n= 00)<br>Referénciascompleto  avaliadas por texto | werdReferéncias exclufdas:si<br>(n= 23 Néo 6 revisdo sistematica<br>(n= 02)<br>Avalia adjuvantes para toxina ou outros<br>desfechos que nao os de interesse<br>(n= 07)<br>Revises sisteméticas<br>identtficadas (n= 13)<br><!-- End of picture text -->  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
**Quadro I -** Relação das revisões sistemáticas avaliadas na etapa 1 - toxina botulínica A em crianças

---

<!-- METADADOS: doenca: Espasticidade | secao: **Revisões Sistemáticas sobre o uso da toxina botulínica A em crianças** -->
1. Boyd RN, Hays RM. Current evidence for the use of botulinum toxin type A in the management of children  with cerebral palsy: a systematic review. Eur J Neurol 2001; 8 Suppl 5: 1–20.  
2. Ryll U, Bastiaenen C, De Bie R, et al. Effects of leg muscle botulinum toxin A injections on walking in children with spasticity-related cerebral palsy: a systematic review. Dev Med Child Neurol 2011; 53: 210–216.  
3. Blumetti FC, Belloti JC, Tamaoki MJ, et al. Botulinum toxin type A in the treatment of lower limb spasticity in children with  cerebral palsy. Cochrane database Syst Rev 2019; 10: CD001408.  
4. Pin TW, Elmasry J, Lewis J. Efficacy of botulinum toxin A in children with cerebral palsy in Gross Motor  Function Classification System levels IV and V: a systematic review. Dev Med Child Neurol 2013; 55: 304–313.  
5. Koog YH, Min B-I. Effects of botulinum toxin A on calf muscles in children with cerebral palsy: a  systematic review. Clin Rehabil 2010; 24: 685–700.  
6. Albavera-Hernández C, Rodríguez JM, Idrovo AJ. Safety of botulinum toxin type A among children with spasticity secondary to  cerebral palsy: a systematic review of randomized clinical trials. Clin Rehabil 2009; 23: 394–407.  
7. Kahraman A, Seyhan K, Değer Ü, et al. Should botulinum toxin A injections be repeated in children with cerebral palsy? A  systematic review. Dev Med Child Neurol 2016; 58: 910–917.  
8. Novak I, McIntyre S, Morgan C, et al. A systematic review of interventions for children with cerebral palsy: state of the evidence. Dev Med Child Neurol 2013; 55: 885–910.  
9. Wasiak J, Hoare B, Wallen M. Botulinum toxin A as an adjunct to treatment in the management of the upper limb in children with spastic cerebral palsy. Cochrane database Syst Rev 2004; CD003469.  
10. Hoare BJ, Wallen MA, Imms C, et al. Botulinum toxin A as an adjunct to treatment in the management of the upper limb in  children with spastic cerebral palsy (UPDATE). Cochrane database Syst Rev 2010; 2010: CD003469.  
11. Reeuwijk A, van Schie PEM, Becher JG, et al. Effects of botulinum toxin type A on upper limb function in children with cerebral  palsy: a systematic review. Clin Rehabil 2006; 20: 375–387.  
12. Guyot P, Kalyvas C, Mamane C, et al. Botulinum Toxins Type A (Bont-A) in the Management of Lower Limb Spasticity in  Children: A Systematic Literature Review and Bayesian Network Meta-analysis. J Child Neurol 2019; 34: 371–381.  
13. García Salazar LF, dos Santos GL, Pavão SL, et al. Intrinsic properties and functional changes in spastic muscle after application of  BTX-A in children with cerebral palsy: systematic review. Dev Neurorehabil 2015; 18: 1–14.

---

<!-- METADADOS: doenca: Espasticidade | secao: <u>Etapa 2</u> -->
Diante dos resultados de uma busca exploratória por revisões sistemáticas que tenham avaliado a TBA no tratamento de espasticidade, optou-se por realizar atualização de uma revisão sistemática da Colaboração Cochrane (Blumetti _et al_ , 2019<sup>59</sup> ), que avaliou a TBA no tratamento de espasticidade em crianças com paralisia cerebral (membros inferiores).  
Deste modo, a estrutura PICO para esta pergunta foi:  
**População:** Crianças com paralisia cerebral, diagnosticadas com espasticidade  
**Intervenção:** Toxina botulínica do tipo A  
**Comparador:** Placebo ou fisioterapia/terapia padrão  
**Desfechos:** Primários: dor, amplitude do movimento, qualidade de vida, eventos adversos, alteração da Escala de Ashworth ou da Escala de Ashworth Modificada; secundários: capacidade funcional durante as atividades de vida diária mensurada por escalas  
de movimento funcional.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Métodos e resultados da busca:** -->
A presente síntese consistiu em uma atualização de uma revisão sistemática com meta-análise realizada em 2019<sup>59</sup> . Foi realizada uma nova busca sistematizada da literatura nas bases de dados MEDLINE (via PubMed), Cochrane Library, CINAHL e EMBASE. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas foram conduzidas em 11 de agosto de 2021. As estratégias de busca para cada base estão descritas no **Quadro J** .  
**Quadro J -** Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o uso de toxina botulínica do tipo A no tratamento de espasticidade em crianças  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
|MEDLINE (via|((("Cerebral palsy"[MeSH Terms]) OR ("cerebral pals*")) AND (((((((((Botulinum toxins[MeSH Terms])|
|Pubmed)|OR ("botulin*")) OR (Botox)) OR (Dysport)) OR (Prosigne)) OR (Xeomin)) OR (OnabotulinumtoxinA))<br>OR (AbobotulinumtoxinA)) OR (IncobotulinumtoxinA))) AND (((clinical[Title/Abstract] AND<br>trial[Title/Abstract]) OR clinical trials as topic[MeSH Terms] OR clinical trial[Publication Type] OR<br>random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading]))<br>Filters: from 2018/10/1 - 2021/8/5|
|EMBASE|('cerebral palsy'/exp OR 'central paralysis' OR 'cerebral palsy' OR 'cerebral paralysis' OR 'cerebral paresis')<br>AND ('botulinum toxin a'/exp OR 'abobotulinum toxin a' OR 'abobotulinumtoxin a' OR 'botox' OR<br>'botulinium a toxin' OR 'botulin toxin a' OR 'botulinum a toxin' OR 'botulinum toxin type a' OR 'botulinum<br>toxins, type a' OR 'incobotulinum toxin a' OR 'incobotulinumtoxin a' OR 'incobotulinumtoxina' OR<br>'onabotulinum toxin a' OR 'onabotulinumtoxin a' OR 'onabotulinumtoxina' OR 'prosigne' OR|  
|**Bases de dados**|**Estrat**|**égia de busca**|
|---|---|---|
||'abobo<br>10-201|tulinumtoxina') AND ([controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND [1-<br>8]/sd NOT [6-8-2021]/sd AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|
|Cochrane Library|#1<br>#2|MeSH descriptor: [Cerebral Palsy] explode all trees<br>cerebral pals*|
||#3|#1 OR #2|
||#4|MeSH descriptor: [Botulinum Toxins] explode all trees|
||#5|(botulinum or botulinium) and (toxin or toxins)|
||#6|botulin*|
||#7|Botox|
||#8|Dysport|
||#9|Prosigne|
||#10|Xeomin|
||#11|OnabotulinumtoxinA|
||#12|AbobotulinumtoxinA|
||#13|IncobotulinumtoxinA|
||#14|(#4 or #5 or #6 or #7 or #8 or #9 or #10 or #11 or #12 or #13)|
||#15|#3 AND #14|
|CINAHL<br>(EBSCO Host)|MH "<br>n1 ma<br>mask*<br>"Rand<br>"Quan<br>MH "<br>botox<br>Incobo<br>AND|Clinical Trials" OR PT clinical trial OR TX clinic* n1 trial* OR ( TX ( (singl* n1 blind*) or(singl*<br>sk*) ) or TX ( (doubl* n1 blind*) or(doubl* n1 mask*) ) or TX ( (tripl* n1 blind*) or(tripl* n1<br>) ) or TX ( (trebl* n1 blind*) or (trebl* n1 mask*) ) ) OR TX randomi* control* trial* OR MH<br>om Assignment" OR TX random* allocat* OR TX placebo* OR MH "Placebos" OR MH<br>titative Studies" OR TX allocat* random* AND<br>Botulinum toxins" OR ( (botulinum OR botulinium) AND (toxin OR toxins) ) OR botulin* OR<br>OR dysport OR prosigne OR xeomin OR OnabotulinumtoxinA OR AbobotulinumtoxinA OR<br>tulinumtoxinA|
||MH "|Cerebral palsy" OR cerebral pals|  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
|Web of Science|(((TS=(random* or placebo* or assign* or allocat* or "cross-ove"r or crossover or control or controls|
||or((singl* or doubl* ortripl* ortrebl*) AND (blind* or mask*)) or prospective or factorial*)) AND|
||TS=(botulin or botox or Dysport or Prosigne or Xeomin or OnabotulinumtoxinA or AbobotulinumtoxinA|
||or IncobotulinumtoxinA) OR TS= ((botulinum OR botulinium) NEAR/3 (toxin OR toxins)))|
||AND"cerebral pals*" (All Fields) Timespan: 2018-10-01 to 2021-08-05||  
A elegibilidade dos estudos foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>® 3</sup> . Na segunda etapa, realizou-se a leitura de texto completo, também por dois revisores independentes, mantendo-se estudos clínicos randomizados (ECR) que avaliassem a TBA para o tratamento da espasticidade. As divergências, quando necessário, foram discutidas até chegar a um consenso ou discutidas com um terceiro pesquisador.  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes: crianças (indivíduos com idade entre o nascimento e 18 anos) com paralisia cerebral (PC) que foram tratadas para espasticidade de membros inferiores. Foram incluídos estudos envolvendo diagnósticos mistos somente se os dados do grupo com PC pudessem ser extraídos separadamente. Não foram feitas restrições quanto ao nível funcional ou distribuição topográfica.  
(b) Tipo de intervenção: TBA nos músculos dos membros inferiores. O grupo de tratamento deve ter recebido toxina botulínica A, e o grupo controle não deve ter recebido toxina botulínica A. Co-intervenções foram permitidas, desde que aplicadas em ambos os grupos.  
(c) Tipos de estudos: foram considerados ECR comparando TBA a placebo ou fisioterapia.  
(d) Desfechos: medidas de função e estrutura corporal (amplitude de movimento e espasticidade), bem como atividade e participação (análise de marcha e função). Outras medidas, como qualidade de vida e satisfação, também são consideradas relevantes.  
(e) Idioma: não foram feitas restrições.  
Para todos os ECR incluídos, foi realizada avaliação do risco de viés utilizando instrumento validado, sendo empregada a ferramenta de avaliação de Risco de Viés da Cochrane (RoB 2.0), tanto a versão para ECR paralelos, quanto para ECR cruzados<sup>1,91</sup> . Para a avaliação do grau de certeza das evidências foi utilizada o método _The Grading of Recommendations Assessment, Development and Evaluation_ (GRADE)<sup>1,92</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Resultados da busca</u>** -->
A revisão original<sup>59</sup> incluiu 31 estudos com quatro comparações principais com base nas intervenções de controle: (1) toxina botulínica e fisioterapia/exercícios; (2) toxina botulínica e placebo; (3) toxina botulínica e gesso seriado; (4) toxina botulínica e órtese. Nesta atualização foram incluídos 23 estudos a partir da revisão anterior, os estudos das comparações três e quatro da revisão original foram excluídos. Foram excluídos também um estudo, e seu relato secundário, que utilizou uma cointervenção (órtese SWASH®) apenas no grupo intervenção<sup>60,61</sup> , outros dois estudos que não relataram nenhum desfecho de interesse<sup>62,63</sup> . Um relato secundário (publicação secundária) do estudo de Scholtes 2006<sup>64</sup> também foi excluída por não abordar nenhum desfecho de interesse para esta revisão.  
Inicialmente, foram identificadas 548 publicações a partir das novas buscas. Após a exclusão das duplicatas (n = 156) e triagem pela leitura de títulos e resumos, 51 publicações foram selecionadas para a leitura do texto completo ( **Figura I** ). Foram incluídas duas publicações na presente atualização. Totalizando 25 estudos incluídos na revisão. Foi realizada busca manual na lista de referências de revisões sistemáticas recentemente publicadas, mas nenhum outro estudo foi incluído por essa busca. A lista de estudos excluídos e a razão para exclusão é apresentada no **Quadro K** .  
**Figura I -** Fluxograma de seleção dos estudos incluídos sobre toxina botulínica no tipo A (TBA) para o tratamento da espasticidade em crianças  
<!-- Start of picture text -->
Estudos incluidas da Relatos identific ados de:<br>revisdo (n= 239 Bases de dados (n= 548) Relatos removidos antes do<br>~ MEDLINE (n= 115) processo de selegao:<br>FRetatos de estudos 5 EMBASECENTRAL (n= (n= 61)223) DuplicatasRemovidas par(n= ferramentas63)<br>3 anterior da revisdo (n = CINAHL (n= 39) automaticas (n = 93)<br>28) ‘Web of Science (n= 110)<br>Relatos avaliados por titulo e Relatos excluidos™(n = 341)<br>resumo Todas remavidas por dais<br>(n= 392) pesquisadores<br>Relatos incluidosi para avalia¢aoiacd Relatos cujo texto corrpleto nao<br>por texto completo (n= 51) fea<br>Relatos avaliados por texto Se araon in 26)<br>completo (n = 50) Delineamento do estudo (n=<br>19)<br>Intervengao (n=1)<br>Populagao (n= 1)<br>Problemas com 0 relato dos<br>dados (n= 1)<br>Novos estudos incluidos na<br>revisdo (n= 02)<br>Novos relatos inc luidos (n = 4**)<br>Total de estudos incluidos na<br>revisdo (n= 25)<br>Registros de todos os estudos<br>incluidos (n= 27)<br><!-- End of picture text -->  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ * Para fins desta revisão, os estudos das comparações três e quatro da revisão original, foram excluídos. Foram excluídos também um estudo que utilizou uma co-intervenção apenas no grupo intervenção e outros dois estudos que não relataram nenhum desfecho de interesse; ** Várias publicações (resumo) de um mesmo registro de estudo (NCT01603628) ainda não publicado de forma completa, mas com dados disponíveis no ClinicalTrials.gov  
**Quadro K -** Lista de referências excluídas na fase de elegibilidade por leitura de texto completo dos estudos clínicos – sínteses sobre toxina botulínica do tipo A em adultos  
|**Comparador**|||||||
|---|---|---|---|---|---|---|
|ACTRN1260700032649|3. A randomised c|ontrolled|trial to determine the|optimum|frequency of|Botulinum|
|Toxin<br>injections|to<br>the|calf|in<br>children|with|cerebral|palsy.|
|_http://www.who.int/trials_|_earch/Trial2.aspx_|_?TrialID=_|_ACTRN126070003264_|_93_,|||
|https://www.cochranelib|rary.com/central/d|oi/10.100|2/central/CN-01838248|/full (20|07).||
|ChiCTR-IPR-15006318.|A clinical study|on differ|ent doses of botulinum|toxin|A injection on|the lower|
|extremities<br>spasm|in<br>children|with|cerebral<br>palsy|by|ultrasound|guidance.|  
_http://www.who.int/trialsearch/Trial2.aspx?TrialID=ChiCTR-IPR-15006318_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01829975/full (2015).  
Dabrowski E, Chambers HG, Gaebler-Spira D, et al. Efficacy and safety of incobotulinumtoxinA for upper- or combined upper- and lower-limb spasticity in children and adolescents with cerebral palsy: results of the Phase 3 XARA study. _Toxicon_ 2021; 190: S14–S15.  
Dabrowski E, Chambers HG, Gaebler-Spira D, et al. IncobotulinumtoxinA Efficacy/Safety in Upper-Limb Spasticity in Pediatric Cerebral Palsy: Randomized Controlled Trial. _Pediatr Neurol_ 2021; 123: 10–20.  
Dabrowski E, Chambers HG, Heinen F, et al. Efficacy and safety of incobotulinumtoxinA for upper-limb or combined upper- and lower-limb spasticity in children and adolescents with cerebral palsy: XARA study design. _Toxicon_ 2018; 156: S19--S19-.  
Dabrowski E, Chambers HG, Heinen F, et al. Multi-level and multi-pattern lower-and upper-limb spasticity treatment with incobotulinumtoxina in children and adolescents with cerebral palsy. _Mov Disord_ 2020; 35: S522--S522-.  
Dağ N, Cerit MN, Şendur HN, et al. The utility of shear wave elastography in the evaluation of muscle stiffness in patients with cerebral palsy after botulinum toxin A injection. _J Med Ultrason (2001)_ 2020; 47: 609–615.  
Esquenazi A, Gracies J-M, Picaut P, et al. AbobotulinumtoxinA (Dysport®) improves functional outcomes after single and repeat dosing in adults and children with spasticity. _Toxicon_ 2018; 156: S30–S31.  
Esquenazi A, Gracies J-M, Picaut P, et al. AbobotulinumtoxinA improves functional outcomes after single and repeat dosing in adults and children with spasticity. _PM R_ 2019; 11: S85–S85.  
EUCTR2005-001794-10-GB. A Phase IV, Randomised, Double-blind, Dose-ranging, Study in Children and Young People to determine the Optimal Dose of Botulinum Toxin Type-A (Dysport®) in Managing the Symptoms of Hip Muscle Spasticity due to Cerebral Palsy - Use of Dysport in Managing Symptoms of Hip Muscle Spasticity in Cerebral Palsy. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=EUCTR2005001794-10-GB_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01858212/full (2006).  
EUCTR2014-002539-32-NO. Does botox make walking easier i in children with cerebral palsy? _http://www.who.int/trialsearch/Trial2.aspx?TrialID=EUCTR2014-002539-32-NO_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01859032/full (2014).  
Heinen F, Kanovsky P, Schroeder AS, et al. Efficacy and safety of incobotulinumtoxinA for lower-limb spasticity in children and adolescents with cerebral palsy. _Toxicon_ 2018; 156: S44--S44-.  
Heinen F, Kaňovský P, Schroeder AS, et al. Improvement of spasticity-related pain with incobotulinumtoxinA treatment in children/adolescents with cerebral palsy: Pooled analysis of three Phase 3 studies. _Dev Med Child Neurol_ 2021; 63: 38.  
Heinen F, Kaňovský P, Schroeder AS, et al. IncobotulinumtoxinA for the treatment of lower-limb spasticity in children and adolescents with cerebral palsy: A phase 3 study. _J Pediatr Rehabil Med_ 2021; 14: 183–197.  
Influence of combined use of botulinum therapy and robotic kinesiotherapy on indicators of general motor function in children with cerebral palsy. _Toxicon_ 2018; 156: S6--S6-.  
ISRCTN24558210. Single blinded cross over trial of two, versus multiple, injections of Botulinum A (Dysport), into the gastrocnemius muscle of children with cerebral palsy, to compare efficacy and discomfort of either method. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=ISRCTN24558210_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01832642/full (2004).  
Kanovsky P, Gaebler-Spira D, Schroeder AS, et al. Pooled efficacy/safety analysis of incobotulinumtoxinA for upper-/lower-limb spasticity in children with severe cerebral palsy (GMFCS level IV-V). _Dev Med Child Neurol_ 2021; 63: 39--39-.  
Kurenkov AL, Klochkova OA, Bursagova BI, et al. Efficacy and safety of botulinum toxin type A (IncobotulinumtoxinA) in the treatment of patients with cerebral palsy. _Zhurnal Nevrol i psikhiatrii Im SS Korsakova_ 2017; 117: 37–44.  
Long-term safety and efficacy of incobotulinumtoxinA for lower- or combined upper- and lower-limb spasticity in children and adolescents with cerebral palsy. _Toxicon_ 2018; 156: S56--S56-. Love S, Cole J, Valentine J, et al. Should we be using botulinum toxin earlier? _Dev Med Child Neurol_ 2010; 52: 35--35-.  
Meilahn J, Kim H, Racette B, et al. Long-term safety and efficacy of onabotulinumtoxina for the treatment of lower limb spasticity in children with cerebral palsy: Open-label extension study. _Ann Neurol_ 2019; 86: S99– S100.  
NTR41. Effect of botulinum toxin treatment in children with cerebral palsy. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=NTR41_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01854802/full (2005).  
Oleszek J, Tilton A, Carranza J, et al. Dosing from a phase 3, pivotal study of abobotulinumtoxinA injection in upper-limb muscles in pediatric patients with cerebral palsy. _Dev Med Child Neurol_ 2020; 62: 116--116-. Pooled efficacy and safety analysis of incobotulinumtoxinA in the treatment of upper- and lower-limb spasticity in children with severe cerebral palsy (GMFCS levels IV and V). _Toxicon_ 2021; 190: S36--S36-. Schroeder AS, Kanovsky P, Chambers HG, et al. Sustained efficacy of incobotulinumtoxinA over 6 injection cycles for the treatment of lower-limb spasticity in children and adolescents with cerebral palsy. _Toxicon_ 2021; 190: S67–S68. Yigitoglu P, Kozanoglu E. Effectiveness of electrical stimulation after administration of botulinum toxin in children with spastic diplegic cerebral palsy: a prospective, randomized clinical study. _Turkish J Phys Med Rehabil_ 2019; 65: 16–23.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Delineamento do estudo** -->
|ACTRN12607000484448. The effect of botulinum toxin-A on the functional ability of the very|young child|
|---|---|
|with<br>spastic<br>hemiplegia<br>due<br>to<br>cerebral|palsy.|
|_http://www.who.int/trialsearch/Trial2.aspx?TrialID=ACTRN12607000484448_,||
|https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01880012/full.||  
Boyd RN. The central and peripheral effects of botulinum toxin A in children with cerebral palsy, https://www.cochranelibrary.com/central/doi/10.1002/central/CN-02272486/full.  
EUCTR2013-002896-17-AT. Functional evaluation of two therapy concepts: dynamic orthoses and BoNT. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=EUCTR2013-002896-17-AT_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01886962/full (2013).  
Goldberg MJ. Botulinum toxin type A improved ankle function in children with cerebral palsy and dynamic equinus foot deformity. _J Bone Joint Surg Am_ 2000; 82: 874--874-.  
ISRCTN85066174. Botulinum Toxin in the management of spasticity in children with cerebral palsy: a randomised double blind trial. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=ISRCTN85066174_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01849456/full (2004).  
Mall V, Berweck S, Kirschner J, et al. Treatment of spastic movement disorders during childhood with botulinum toxin A. _Klin Neurophysiol_ 2001; 32: 218–224.  
NCT03704155. Effect of Botulinum Toxin Type A Associated With Physical Therapy on Children With Spastic Cerebral Palsy. _https://clinicaltrials.gov/show/NCT03704155_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01648830/full (2018).  
NCT04328168. Comparision Of The Effectiveness Of Physiotherapy Methods. _https://clinicaltrials.gov/show/NCT04328168_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-02089492/full (2020).  
NTR1655. Kosten-effectiviteit van combinatie behandeling botuline-toxine injecties en intensieve fysiotherapie bij kinderen met spastische Cerebrale Parese. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=NTR1655_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01824634/full (2009).  
RBR-5qzs8h. Static Balance in Children with Cerebral Palsy Submitted to Neuromuscular Block and Neuromuscular Electrical Stimulation. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=RBR-5qzs8h_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01839521/full (2012).  
SCHASFOORT F, PANGALILA R, SNEEKES E, et al. INTRAMUSCULAR BOTULINUM TOXIN PRIOR TO COMPREHENSIVE REHABILITATION HAS NO ADDED VALUE FOR IMPROVING MOTOR IMPAIRMENTS, GAIT KINEMATICS AND GOAL ATTAINMENT IN WALKING CHILDREN WITH SPASTIC CEREBRAL PALSY. _J Rehabil Med (Stiftelsen Rehabiliteringsinformation)_ 2018; 50: 732–742.  
Sobti A, Magill N, Norman-Taylor F. Preoperative botulinum toxin a for children with bilateral cerebral palsyundergoing major hip surgery: a randomised double-blind placebo-controlled trialwith 6 months followup. _Arch Dis Child_ 2020; 105: A23--A23-.  
Value of botulinum toxin injections preceding a comprehensive rehabilitation period for children with spastic cerebral palsy: a cost-effectiveness study. _J Rehabil Med_ 2018; 50: 22–29.  
Will E, Magill N, Arnold R, et al. Preoperative botulinum neurotoxin A for children with bilateral cerebral palsy undergoing major hip surgery: a randomized double-blind placebo-controlled trial. _Dev Med Child Neurol_ 2019; 61: 1074–1079.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Intervenção** -->
Elnaggar RK, Alqahtani BA, Elbanna MF. Functional outcomes of botulinum neurotoxin-A injection followed by reciprocal electrical stimulation in children with cerebral palsy: A randomized controlled trial. _Restor Neurol Neurosci_ 2020; 38: 431–441.

---

<!-- METADADOS: doenca: Espasticidade | secao: **População** -->
EUCTR2005-004685-17-BE. A prospective placebo controlled study of botulilium toxin (BOTOX) on gait disorder induced by spastic equinovarus foot. _http://www.who.int/trialsearch/Trial2.aspx?TrialID=EUCTR2005-004685-17-BE_ , https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01837625/full (2006).

---

<!-- METADADOS: doenca: Espasticidade | secao: **Dados incompletos para análise** -->
Dursun N, Bonikowski M, Dabrowski E, Matthews D, Gormley M, Tilton A, Carranza J, Grandoulier A S, Picaut P &. Delgado Mauricio R (2020) Efficacy of Repeat AbobotulinumtoxinA (Dysport®) Injections in Improving Gait in Children with Spastic Cerebral Palsy, Developmental Neurorehabilitation, 23:6, 368-374, DOI: 10.1080/17518423.2019.1687602

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise e apresentação dos resultados** -->
Foram avaliadas 27 publicações de 25 estudos diferentes, todos considerados ECR. Quatro<sup>65–68</sup> estudos não relataram a distribuição motora e a maioria dos estudos (n=14) incluiu crianças com, pelo menos, um tipo de disfunção motora. Em relação aos músculos alvo, a maior parte dos estudos (n=15) envolveu injeções isoladas de TBA nos flexores plantares do tornozelo (gastrocnêmio ou sóleo; ou ambos) e por esse motivo as análises, em sua maioria, foram realizadas com foco nesse grupamento muscular. Nos **quadros L e M** , estão descritas as principais características dos estudos incluídos.  
Os resultados da presente atualização foram agrupados em duas comparações principais: (1) TBA e fisioterapia/cuidado usual e (2) TBA e placebo. Ainda, foram analisados considerando o período em que foram avaliados, da seguinte forma: **Curto prazo** : desfechos avaliados duas a oito semanas após a intervenção **Médio prazo** : resultados avaliados em 12 a 16 semanas após a intervenção  
**Longo prazo:** resultados avaliados em 24 semanas ou mais após a intervenção  
**Quadro L -** Características dos estudos clínicos avaliando toxina botulínica A comparada à fisioterapia no cuidado de crianças com espasticidade.  
|**Autor (ano)**|**Características**|**Desfecho avaliado**|
|---|---|---|
|Bertan|Objetivo: comparar a resposta do músculo gastrocnêmio após injeção de|⋅ Rigidez muscular|
|(2020)<sup>115</sup>|toxina botulínica com um programa de exercícios em casa, por meio de um|(avaliada por|
||método elastrográfico (impulso de força de radiação acústica - ARFI) e|elastografia de onda|
||examinar a relação entre os parâmetros elastográficos e clínicos (MTS,|de cisalhamento)|
||MAS e WeeFIM).|⋅ MTS|
||Tipo de toxina botulínica:  onabotulinumtoxinA (50 U/músculo, 100 U|⋅ MAS|
||total)|⋅ WeeFIM*|
||Incluiu 33 crianças (49 membros inferiores) com idade entre 2 e 7 anos||  
|**Autor (ano)**|**Características**<br>GMFCS: não descrito<br>Local da injeção: gastrocnêmio medial e lateral<br>Estudo clínico randomizado, simples-cego (avaliador cego), o grupo<br>controle foi submetido a um programa de exercícios em casa. Não foi<br>descrito o tempo de seguimento total, mas foram feitas uma avaliação basal<br>(início), após quatro e 12 semanas.|**Desfecho avaliado**<br>_* O estudo não_<br>_forneceu os valores da_<br>_WeeFim, este desfecho_<br>_não foi incluído nas_<br>_análises de nossa_<br>_revisão._|
|---|---|---|
|Chaturvedi<br>(2013)<sup>66</sup>|Objetivo: comparar os efeitos combinados da fisioterapia e toxina<br>botulínica com fisioterapia isolada em crianças com PC espástica usando<br>imagens de tensor de difusão<br>Tipo de toxina botulínica: abobotulinumtoxinA 100 a 500 U/músculo não<br>excedendo 30 U/kg<br>Local da injeção: variável, mas sempre em membros inferiores<br>GMFCS: não descrito<br>Incluiu 36 crianças com idade acima de 2 anos<br>Tipo de estudo: randomizado, aberto, todos os pacientes receberam um<br>protocolo de fisioterapia padronizado (controle e intervenção). Os<br>pacientes tiveram uma avalição basal e após seis meses.|⋅ Imagens de tensor de<br>difusão<br>⋅ GMFM|
|Çağlar<br>(2019)<sup>65</sup>|Objetivo: avaliar a mudança na capacidade de locomoção e espasticidade<br>de crianças com PC que receberam injeção de toxina botulínica tipo A e<br>foram submetidas a terapia de reabilitação<br>Tipo de toxina botulínica: onabotulinumtoxinA 3 UI/kg/músculo<br>Local da injeção: gastrocnêmio, sóleo, tibial anterior e posterior,<br>quadríceps, adutores do quadril e isquiotibiais<br>GMFCS: não descrito por participantes<br>Incluiu 30 crianças com idade entre dois e 15 anos.<br>Tipo de estudo: estudo randomizado, aberto, o grupo controle e intervenção<br>receberam 5 sessões de fisioterapia por semana (20 sessões), seguidas dos<br>exercícios mantidos em casa. O seguimento fi de 12 semanas, com<br>avaliações basal, na semana 4 e 12.|⋅ MAS<br>⋅ GAS<br>⋅ Teste de controle<br>motor seletivo<br>⋅ GMFCS*<br>_*Neste estudo a_<br>_GMFCS foi utilizado_<br>_como medida de_<br>_desfecho em vez de_<br>_descrever as_<br>_características dos_<br>|
|||_participantes_|
|El-Etribi<br>(2004)<sup>69</sup>|Objetivo: investigar a potencial eficácia do bloqueio neuromuscular<br>usando toxina botulínica tipo A na diplegia espástica em crianças com PC<br>crianças, especificamente espasticidade, amplitude de movimento e<br>padrões de marcha<br>Tipo de toxina botulínica: onabotulinumtoxinA 3 a 6 U/kg, não excedendo<br>200 U<br>Local da injeção: gastrocnêmio, adutores do quadril ou isquiotibiais<br>GMFCS: Não descrito|⋅ MAS<br>⋅ PRS (modificada)<br>⋅ Amplitude do<br>movimento<br>⋅ Eletromiograma|  
|**Autor (ano)**|**Características**<br>Incluiu 40 crianças com idade entre 2 e 6 anos com pé equino móvel<br>Tipo de estudo: randomizado, aberto, ambos os grupos receberam<br>fisioterapia 3 vezes na semana por 3 meses. O tempo de seguimento foi de<br>12 semanas, com avaliações basal, na semana 4, 8 e 12.|**Desfecho avaliado**|
|---|---|---|
|Ibrahim<br>(2007)<sup>70</sup>|Objetivo: comparar os efeitos da TBA quando administrada no<br>gastrocnêmio ou adutores do quadril (ou ambos) em crianças deambulantes<br>com hemiplegia espástica devido à paralisia cerebral.<br>Tipo de toxina botulínica: onabotulinumtoxinA 6 a 12 IU/kg (dose máxima<br>total 200U)<br>Local da injeção: gastrocnêmio lateral e medial (grupo gastrocnêmio),<br>adutor magnus, longus e brevis (grupo adutores) e ambos os grupamentos.<br>GMFCS: Não descrito, mas de acordo com os critérios de inclusão,<br>presumivelmente todos os GMFCS I ou II<br>Incluiu 60 crianças com idade entre 3 e 7 anos.<br>Tipo de estudo: clínico randomizado, cegamento não descrito<br>(provavelmente aberto pela natureza da intervenção). A duração total do<br>acompanhamento não é clara. As crianças foram observadas 6 meses após<br>o último dos 3 ciclos de injeções de TBA, cada um separado por um<br>intervalo de 3 a 4 meses|⋅ O estudo utilizou um<br>índice de<br>espasticidade<br>Composto:<br>⋅ Escala de Ashworth<br>modificada obtida<br>para o quadril e<br>tornozelo (escala<br>original de 0 a 4 com<br>nota +1 foi ajustado<br>para dar uma<br>pontuação de 0 a 5).<br>As pontuações foram<br>somadas, dando um<br>índice de 0 a 10<br>⋅ Principais parâmetros<br>|
|||de marcha|
|Love (2001)<sup>71</sup>|Objetivo: avaliar o efeito das injeções de TBA, nas extremidades<br>inferiores, sobre a capacidade funcional de crianças com hemiplegia<br>espástica devido à PC<br>Tipo de toxina botulínica: onabotulinumtoxinA 2,8 a 7,3 U/kg<br>Local da injeção: gastroc-soleus (tríceps sural) e tibial posterior<br>GMFCS: todos os pacientes nível I<br>Incluiu 24 crianças de 3 a 13 anos<br>Tipo de estudo: clínico randomizado, cegamento não descrito<br>(provavelmente aberto pela natureza da intervenção). Seguimento de 6<br>meses com avaliações no início do estudo e nos meses 1, 3 e 6.|⋅ Amplitude de<br>movimento passiva do<br>tornozelo<br>⋅ MTS<br>⋅ MAS<br>⋅ Medida da função<br>motora bruta<br>⋅ Satisfação dos pais<br>(escala visual<br>analógica)|
|Navarrete<br>(2010)<sup>72</sup>|Objetivo: avaliar o nível de independência funcional de crianças com PC<br>do tipo diplegica e hemiplegia espástica submetidas a uma terapia com<br>TBA multinível associada às terapias abrangentes (ocupacional, ortótica e<br>fisioterapia) nas extremidades inferiores<br>Tipo de toxina botulínica: onabotulinumtoxinA 15 U/kg de peso (dose<br>máxima)<br>Local da injeção: grupos musculares determinados individualmente para<br>cada criança. Os músculos injetados foram selecionados usando a Escala<br>de Tardieu (considerando uma diferença entre R1 e R2> 20 °). Sofreram|⋅ GMFM-88<br>⋅ WeeFIM|  
|**Autor (ano)**|**Características**|**Desfecho avaliado**|
|---|---|---|
||intervenções os músculos: gastrocnêmio bilateral, adutores bilaterais,<br>isquiotibiais bilaterais, sóleo bilateral, tibial anterior bilateral, panturrilha<br>unilateral, isquiotibiais unilaterais, tibial anterior unilateral.<br>GMFCS: Grupo TBA: 0 nível I; 5 nível II; 4 nível III; 6 nível IV; 3 nível V<br>Grupo placebo: 1 nível I; 7 nível II; 5 nível III; 4 nível IV; 1 nível V<br>Incluiu 36 crianças com idade entre 3 e 10 anos.<br>Tipo de estudo: randomizado, aberto. Acompanhamento por 6 meses, com<br>avaliações no início do estudo, nos meses 1, 3 e 6.||
|Reddihough<br>(2002)<sup>73</sup>|Objetivo: comparar e determinar o desfecho funcional de crianças com PC<br>espástica submetidas a um programa de fisioterapia ou TBA, em um<br>desenho_cross-over,_e verificar se as mudanças podem persistir em 6 meses<br>após a injeção.<br>Tipo de toxina botulínica: não descrito<br>Local da injeção: grupos musculares determinados individualmente para<br>cada criança de acordo com o protocolo<br>GMFCS: Grupo TBA: 3 nível I; 6 nível II; 9 nível III; 4 nível IV<br>Grupo controle: 4 nível I; 5 nível II; 11 nível III; 7 nível IV<br>Incluiu 49 crianças de 2 a 6 anos (22 a 80 meses)<br>Tipo de estudo: clínico randomizado, cegamento não descrito<br>(provavelmente aberto pela natureza da intervenção). As crianças foram<br>acompanhadas por 12 meses.  Fase TBA: todas as crianças atendidas no<br>início do estudo, 3 e 6 meses. Fase de controle: 30 crianças atendidas no<br>início e 6 meses, enquanto 19 crianças atendidas no início do estudo, 3 e 6<br>meses|⋅ GMFM<br>⋅ Bateria de Avaliação<br>Vulpe<br>⋅ MAS<br>⋅ Amplitude de<br>movimento<br>⋅ Questionário de<br>Percepção Parental|
|Scholtes<br>(2006)<sup>74</sup>;<br>Scholtes<br>(2007)<sup>75</sup>|Objetivo: verificar o efeito da TBA de vários níveis nos membros inferiores<br>e uma reabilitação abrangente, em comparação com o cuidado usual em<br>crianças ambulatoriais com paralisia cerebral que caminham com os<br>joelhos flexionados.<br>Tipo de toxina botulínica: onabotulinumtoxinA 4 a 6 U/kg<br>Local da injeção: grupos musculares determinados individualmente para<br>cada criança de acordo com o protocolo (psoas, isquiotibiais medial e<br>lateral, adutores do quadril, reto femoral, gastrocnêmio, sóleo e músculo<br>tibial posterior)<br>GMFCS: grupoTBA: 9 nível I; 3 nível II; 10 nível III; 1 nível IV<br>Grupo controle: 9 nível I; 4 nível II; 7 nível III; 3 nível IV<br>Incluiu 46 crianças de 4 a 12 anos.<br>Tipo de estudo: estudo clínico randomizado, aberto. GrupoTBA:<br>avaliações no início do estudo, 6, 12 e 24 semanas. O acompanhamento foi<br>realizado por 6 meses. A análise da marcha foi realizada apenas no início<br>do estudo, nas semanas 6 e 24.|⋅ Edinburgh visual Gait<br>Analysis Interval<br>Testing (GAIT) scale<br>⋅ GMFM-66<br>⋅ Amplitude de<br>movimento<br>⋅ Espasticidade<br>(embora não tenha<br>sido declarada, a<br>descrição corresponde<br>à Escala de Tardieu)|  
|**Autor (ano)**|**Características**|**Desfecho avaliado**|
|---|---|---|
||Grupo de controle: 2 avaliações com intervalo médio de 24,61 semanas<br>(DP 5,7; faixa de 18 a 30).||
|Steenbeek<br>(2005)<sup>76</sup>|Objetivo:  medir o efeito do tratamento com TBA em crianças com PC em<br>relação às metas individuais relativas às habilidades funcionais, usando<br>escala de alcance de metas.<br>Tipo de toxina botulínica: onabotulinumtoxinA 4 a 6 U/kg, máximo de 50<br>U/kg<br>Local da injeção: grupos musculares determinados individualmente para<br>cada criança de acordo com o protocolo<br>GMFCS: 4 nível I; 3 nível II; 3 nível III; 1 nível IV; 0 nível V<br>Incluiu 12 crianças de 3 a 12 anos.<br>Tipo de estudo: estudo clínico randomizado, aberto. Acompanhamento total de<br>14 semanas e semanal para ambos os grupos.|⋅ Escala de alcance de<br>meta<br>⋅ MAS|
|Tedroff<br>(2010)<sup>77</sup>|Objetivo: avaliar o efeito do tratamento com TBA no tônus muscular, no<br>desenvolvimento de contratura e no padrão de marcha em crianças<br>pequenas com PC<br>Tipo de toxina botulínica: onabotulinumtoxinA 6U/kg<br>Local da injeção: flexores plantares do tornozelo<br>GMFCS: não descrito<br>Incluiu 16 crianças de 1 a 6 anos.<br>Tipo de estudo: estudo clínico randomizado, aberto. Acompanhamento de<br>1 ano (denominado como a "fase de tratamento" do estudo). As crianças<br>foram então acompanhadas e ambos os grupos receberam TBA conforme<br>necessário. A avaliação final foi realizada em média 3,5 anos (DP 3,5<br>meses). Para os fins desta revisão, avaliamos apenas a parte controlada do<br>estudo (avaliações no início do estudo e 1 ano após a intervenção)|⋅ MAS<br>⋅ Amplitude do<br>movimento<br>⋅ GMFM-66<br>⋅ Pediatric Evaluation<br>of Disability<br>Inventory|
|Xu (2006)<sup>67</sup>|Objetivo: Comparar os efeitos da injeção da TBA guiada por estimulação<br>elétrica associada à fisioterapia, com a fisioterapia isolada na espasticidade<br>do flexor plantar do tornozelo em crianças com PC.<br>Tipo de toxina botulínica: ianbotulinumtoxinA 12 U/kg<br>Local da injeção: flexores plantares do tornozelo<br>GMFCS: não descrito<br>Incluiu 43 crianças de 2 a 10 anos.<br>Tipo de estudo:  estudo clínico randomizado, aberto. Acompanhamento de<br>3 meses. Avaliações no início do estudo, 1, 2 e 3 meses|⋅ Amplitude do<br>movimento passivo<br>⋅ MAS<br>⋅ GMFM (domínio D e<br>E)<br>⋅ Velocidade da<br>caminhada|
|Zhu (2016)<sup>78</sup>|Objetivo: investigar a eficácia clínica a longo prazo e os efeitos adversos<br>da TBA no tratamento da espasticidade gastrocnêmio em crianças de 9-36<br>meses com paralisia cerebral.<br>Tipo de toxina botulínica: onabotulinumtoxinA 3 U/kg<br>Local da injeção: gastrocnêmio|⋅ MTS<br>⋅ Eletromiografia de<br>superfície<br>⋅ GMFM-88<br>⋅ Eventos adversos|  
|**Autor (ano)**|**Características**|**Desfecho avaliado**|
|---|---|---|
||GMFCS: não descrito<br>Incluiu 80 crianças entre 9 e 36 meses.||
||Tipo de estudo: estudo clínico randomizado, aberto. Acompanhamento de<br>6 meses. Avaliações no início do estudo, 1, 2, 3 e 6 meses.||  
**Quadro M -** Características dos estudos clínicos avaliando toxina botulínica A comparada à placebo no cuidado de crianças com espasticidade.  
|**Autor (ano)**|**Características**|**Desfechos**|
|---|---|---|
|Baker<br>(2002)<sup>79</sup>|Objetivo: avaliar a eficácia e segurança de três doses diferentes de<br>Dysport® (10, 20 e 30 U/kg de peso corporal) no tratamento de<br>espasticidade do pé equino em pacientes com PC.<br>Tipo de toxina botulínica: abobotulinumtoxinA 3 doses diferentes 10, 20<br>e 30 U/kg. Dose de 20U escolhida para análise.<br>Local da injeção: junção do quarto proximal e os três quartos distais do<br>gastrocnêmio<br>GMFCS: TBA: 11 nível I; 1 nível II; Placebo: 14 nível l; 0 nível II<br>Incluiu 126 crianças com idade entre 2 e 9 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para os participantes, profissionais e pesquisadores. Seguimento de 16<br>semanas, com avaliação basal e nas semanas 4, 8 e 16.|⋅ Mudança no<br>componente dinâmico<br>do encurtamento do<br>gastrocnêmio<br>⋅ Eventos adversos<br>⋅ GMFM<br>⋅ Amplitude do<br>movimento|
|Bjornson<br>(2007)<sup>80</sup>|Objetivo: verificar os efeitos da TBA nos músculos gastrocnêmios em<br>crianças com diplegia espástica.<br>Tipo de toxina botulínica: onabotulinumtoxinA 12U/kg<br>Local da injeção: cabeças medial e lateral do gastrocnêmio<br>GMFCS: BA: 47% nível I; 41% nível II; 12% nível III; Placebo: 25%<br>nível I; 50% nível II; 25% nível III<br>Incluiu 33 crianças com idade entre 3 e 12 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para os pesquisadores, coordenadores do estudo, fisioterapeutas e<br>participantes. O estudo teve acompanhamento de 24 semanas, com<br>avaliações basal e nas semanas 3, 8, 12 e 24.|⋅ Comprimento do<br>passo (sistema de<br>medição de<br>espasticidade)<br>⋅ GMFM-66 e<br>GMFM-88<br>⋅ Cinesiologia<br>eletromiográfica<br>quantitativa<br>⋅ Escala de Ashworth<br>⋅ Reflexos tendinosos<br>profundos<br>⋅ Clonus<br>⋅ Amplitude de<br>movimento passivo<br>do tornozelo<br>⋅ Torque voluntário<br>máximo<br>⋅ Índice de custo de<br>energia|  
|**Autor (ano)**|**Características**|**Desfechos**<br>⋅ COPM<br>⋅ GAS|
|---|---|---|
|Copeland<br>(2014)<sup>81</sup>|Objetivo: examinar a eficácia e a segurança do TBA intramuscular para<br>reduzir a espasticidade e melhorar o conforto e facilidade de atendimento<br>em crianças que não deambulam com paralisia cerebral<br>Tipo de toxina botulínica: onabotulinumtoxinA (0,5-4U/kg/ grupo<br>muscular) não superior a 12 U/kg (ou total de 400 U)<br>Local da injeção: ão descrito, mas em membros inferiores e superiores<br>GMFCS: Grupo TBA (IV / V): 3/20; grupo placebo (IV/V): 0/18<br>Incluiu 41 crianças com idade entre 2 e 16 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para pacientes, pais, cuidadores e avaliadores. A duração do<br>acompanhamento foi de 16 semanas, com uma avaliação inicial, nas<br>semanas 4 e 16|⋅ COPM<br>⋅ Prioridades do<br>cuidador e índice de<br>saúde infantil da vida<br>com deficiência<br>⋅ Questionário de<br>hipertonia de cuidado<br>e conforto<br>⋅ Questionário de<br>Qualidade de Vida<br>em Paralisia Cerebral<br>para Crianças<br>⋅ Perfil de dor<br>pediátrica|
|||⋅ Eventos adversos|
|Delgado<br>(2016)<sup>82</sup>|Objetivo: avaliar a eficácia e segurança da TBA (Dysport®) em<br>comparação com placebo em crianças com espasticidade associada à PC.<br>Tipo de toxina botulínica:  abobotulinumtoxinA 10 e 15 U/kg/perna, num<br>máximo de 1000 U ou 30 U/kg por criança.<br>Local da injeção: gastrocnêmio e sóleo<br>GMFCS: TBA 15 U / kg: 45 nível I; 24 nível II; 10 nível III; placebo: 40<br>nível I; 30 nível II; 7 nível II<br>Incluiu 241 crianças entre 2 e 17 anos.<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes, profissionais e avaliadores de desfecho. Os pacientes<br>foram acompanhados por 12 semanas, com avaliações basal, nas semanas<br>4 e 12.|⋅ MAS<br>⋅ Physician's Global<br>Assessment<br>⋅ GAS<br>⋅ Escala de Tardieu<br>⋅ Eventos adversos|
|Tilton<br>(2017)<sup>83</sup>|Objetivo: análise secundária de estudo duplo-cego randomizado avaliou a<br>eficácia de 2 doses de abobotulinumtoxinA associada ao cuidado usual<br>versus placebo, também associado ao cuidado usual, em crianças com<br>equino dinâmico devido à paralisia cerebral utilizando a Goal Attainment<br>Scaling.<br>Ver informações de Delgado (2016)<sup>82</sup>.|⋅ GAS|
|Kanovsky<br>(2004)<sup>84</sup>|Objetivo: avaliar o benefício funcional da toxina botulínica (Dysport®)<br>no tratamento da espasticidade da PC de pé equino dinâmico<br>Tipo de toxina botulínica: abobotulinumtoxinA 30 U/kg<br>Local da injeção: gastrocnêmio|⋅ GMFM<br>⋅ Avaliação<br>videográfica da<br>marcha|  
|**Autor (ano)**|**Características**|**Desfechos**|
|---|---|---|
||GMFCS: Não descrito, mas de acordo com os critérios de inclusão,<br>presumivelmente todos eram GMFCS I, II ou III.<br>Incluiu 52 crianças com idade entre 2 e 7 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores. Avaliações ocorreram no início do<br>estudo e semanas 4, 8 e 16 pós-tratamento. Duração de 16 semanas de<br>seguimento.|⋅ Avaliação funcional<br>subjetiva<br>⋅ Eventos adversos|
|Kim (2018)<sup>68</sup>|Objetivo: avaliar a segurança e eficácia de onabotulinumtoxinA para<br>espasticidade/hipertonia de membros inferiores em crianças com PC<br>quando comparada ao placebo<br>Tipo de toxina botulínica: onabotulinumtoxinA 4 e 8 UI/kg<br>Local da injeção: Flexores plantares do tornozelo<br>GMFCS: não descrito<br>Incluiu 376 crianças com idade entre 2 e menores de 17 anos.<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores.|⋅ MAS-B<br>⋅ CGI<br>⋅ GAS<br>⋅ Mudança em relação<br>ao basal na gravidade<br>da espasticidade do<br>tornozelo calculado<br>usando MTS|
|Koman<br>(1994)<sup>85</sup>|Objetivo: avaliar a eficácia das injeções intramusculares locais de TBA<br>no tratamento da deformidade equina dinâmica associada à PC<br>Tipo de toxina botulínica: onabotulinumtoxinA 1 U/kg por lado nas<br>deformidades em equinovaro, o tibial posterior também sofreu<br>intervenção<br>Segunda injeção de TBA (onabotulinumtoxinA) 2 U/kg por lado nos<br>mesmos locais de injeção<br>Local da injeção: gastrocnêmio e tibial posterior<br>GMFCS: não descrito<br>Incluiu 12 crianças com idade entre 4 e 11 anos<br>Tipo de estudo: randomizado, cego para os participantes e pesquisadores.<br>A duração do seguimento foi de 12 semanas com avaliação inicial, nas<br>semanas 2, 4, 8 e 12.|⋅ PRS<br>⋅ Dinamometria<br>computadorizada<br>isocinética Biodex<br>⋅ Avaliações<br>fisioterapêuticas<br>⋅ Eventos adversos<br>⋅ Avaliação dos<br>pais/responsáveis|
|Koman (2000)<br>86|Objetivo: avaliar a eficácia das injeções e segurança em curto prazo da<br>TBA<br>Tipo de toxina botulínica: onabotulinumtoxinA<br>Local da injeção: gastrocnêmio (medial e lateral)<br>GMFCS: não descrito<br>Incluiu 114 crianças com idade entre 2 e 16 anos<br>Tipo de estudo: clínico randomizado, cego para os participantes e<br>pesquisadores. A duração do acompanhamento foi de 12 semanas, as<br>avaliações ocorreram no início, nas semanas 2, 4, 8 e 12.<br>_1. Um total de 145 pacientes foram inicialmente inscritos e incluídos na_<br>_avaliação de segurança. Os dados de 1 centro (n = 15) foram excluídos_|⋅ PRS<br>⋅ Médica<br>⋅ Amplitude de<br>movimento passiva<br>do tornozelo<br>⋅ Amplitude de<br>movimento ativa do<br>tornozelo<br>⋅ Medidas<br>eletrofisiológicas<br>⋅ Eventos adversos|  
|**Autor (ano)**|**Características**<br>_da análise de eficácia porque os regulamentos daquele país proibiam o_<br>_uso de placebo em crianças; consequentemente, os dados deste centro_<br>_não foram ocultados. Os dados de 16 crianças foram excluídos da_<br>_avaliação de eficácia devido ao não cumprimento dos critérios de_<br>_entrada._<br>_2. Uma vez que ambas as injeções foram administradas com 4 semanas_<br>_de intervalo e com uma dose baixa cada, consideramos isso como um_<br>_estudo de injeção única para os fins de nossa revisão._|**Desfechos**<br>⋅ Anticorpos do soro<br>sanguíneo|
|---|---|---|
|Mall (2006)<sup>87</sup>|Objetivo: testar a hipótese de a espasticidade do músculo adutor ser<br>reduzida pelo tratamento com TBA.<br>Tipo de toxina botulínica: abobotulinumtoxinA 30 UI/kg nos adutores<br>(2/3 da dose total) e nos isquiotibiais mediais (1/3 da dose total)<br>Local da injeção: músculos adutores e isquiotibiais mediais<br>GMFCS: Grupo TBA: 1 nível I; 3 nível II; 12 nível III; 12 nível IV; 4<br>nível V; Grupo placebo: 2 nível I; 2 nível II; 5 nível III; 17 nível IV; 2<br>nível V<br>Incluiu 61 crianças com idade entre 10 meses e 10 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores/avaliadores de desfecho. O<br>acompanhamento teve duração de 3 meses com avaliações inicial e nas<br>semanas 4 e 12.|⋅ Distância joelho-<br>joelho<br>⋅ Abdução do quadril<br>(amplitude de<br>movimento)<br>⋅ MAS<br>⋅ GMFM<br>⋅ GAS|
|Moore<br>(2008)<sup>88</sup>|Objetivo: Avaliar a eficácia da TBA em longo prazo (até 2 anos).<br>Tipo de toxina botulínica: abobotulinumtoxinA. Dose máxima de 15 U/kg<br>no primeiro ciclo<br>A dose máxima aumentou 5 U/kg a cada ciclo de 3 meses, até uma dose<br>máxima de 30 U/kg. As injeções foram administradas a cada 3 meses, se<br>clinicamente indicado, por 2 anos<br>Local da injeção: grupos musculares determinados individualmente para cada<br>criança de acordo com o protocolo<br>GMFCS: não descrito<br>Incluiu 64 crianças com idade entre 2 e 8 anos<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores/avaliadores de desfecho. O<br>Acompanhamento foi realizado por dois anos. As crianças foram<br>avaliadas no início do estudo, nas semanas 2, 6 e após 3 meses<br>Este padrão continuou por até 8 vezes após as injeções ao longo de 2 anos.|⋅ GMFM<br>⋅ PEDI (aos 2 anos)<br>⋅ Alteração de peso<br>⋅ Eventos adversos|
|Sutherland<br>(1999)<sup>89</sup>|Objetivo: quantificar, usando a análise de marcha 3-D, quaisquer<br>mudanças no desempenho funcional após a injeção de TBA nos músculos<br>gastrocnêmios de crianças com paralisia cerebral que demonstraram um<br>padrão de marcha em equino dinâmico.|⋅ Análise de marcha<br>tridimensional|  
|**Autor (ano)**|**Características**|**Desfechos**|
|---|---|---|
||Tipo de toxina botulínica: onabotulinumtoxinA<br>Local da injeção: gastrocnêmio (cabeças medial e lateral)<br>GMFCS: não descrito<br>Incluiu 20 crianças com idade entre 2 e 16 anos.<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores/avaliadores de desfecho. Avaliações no<br>início do estudo e 8 semanas (4 semanas após a segunda injeção), num<br>total de 8 semanas de acompanhamento|* Dorsiflexão<br>dinâmica do<br>tornozelo<br>* Parâmetros de<br>tempo-distância<br>* Eletromiografia<br>dinâmica<br>⋅ Dorsiflexão passiva<br>do tornozelo<br>⋅ Força do músculo<br>flexor plantar (não<br>disponível para todas<br>as crianças)|
|Ubhi (2000)<sup>90</sup>|Objetivo: Para determinar se o BT-A intramuscular pode melhorar a<br>marcha em crianças com paralisia cerebral.<br>Tipo de toxina botulínica: abobotulinumtoxinA 25 U/kg para diplégicos e<br>15 U/kg para hemiplégicos.<br>Local da injeção: gastrocnêmio e sóleo<br>GMFCS: não descrito<br>Incluiu 40 crianças com idade entre 2 a 16 anos.<br>Tipo de estudo: estudo clínico randomizado controlado por placebo, cego<br>para participantes e pesquisadores/avaliadores de desfecho. Avaliações<br>basal (2 avaliações iniciais separadas por 2 semanas de intervalo) e nas<br>semanas 2, 6 e 12, num total de 12 semanas de acompanhamento.|⋅ Análise de marcha<br>em vídeo<br>⋅ Eventos adversos<br>⋅ Medida da função<br>motora bruta<br>⋅ Dorsiflexão passiva<br>do tornozelo<br>⋅ Custo de energia<br>fisiológica (PCI|

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Avaliação do risco de viés</u>** -->
De acordo com o Rob 2.0<sup>91</sup> , Para todos os desfechos de interesse avaliados nessa síntese, apenas seis estudos apresentaram baixo risco de viés<sup>68,81–83,86–88</sup> .Os demais estudos foram classificados como apresentando algumas preocupações ou alto risco de viés causados, principalmente, por não fornecerem informações de maneira satisfatória sobre o processo de randomização ou sigilo de alocação, a respeito do cegamento das partes envolvidas no estudo ou pela ausência de cegamento de uma parte importante envolvida na avaliação do desfecho. A avaliação completa do risco de viés é apresentada no Material Suplementar 1.  
TBA comparada à fisioterapia  
A avaliação da função motora foi realizada, principalmente, utilizando a _Gross Motor Function Measure_ (GMFM) e _Goal Attainment Scaling_ (GAS). As análises foram realizadas considerando o período de avaliação, a curto prazo a diferença padronizada das médias [IC 95%] foi de 0,59 [0,23; 0,95] ( **Figura J** ), para médio prazo 1,06 [0,17; 1,94] ( **Figura K** ) e longo prazo 0,34 [-0,56; 1,24] ( **Figura L** ). Foram realizadas análises de subgrupo para longo e médio prazo ( **Figuras M e N** ). A certeza da evidência foi considerada como muito baixa.  
**<u>Análise da função motora</u>**  
**Figura J -** _Forest plot_ da Análise de função motora - GMFM (pontuações total e alvo) - curto prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Std. Mean Difference Std, Mean Difference<br>Study<br>XuZhu 220 0 or166  Subgroup Mean6852 SD 1 13 Total_Mean40451223 698 97SD Total42 0 Weight(85.634.4 % __IV, 0 .55Fixed,.66(0.11,(0.04,95%1.00)1.28]Cl IV, Fixed,i95% Cl<br>Total (95% Cl) 63 60 100.0% 0.59 0.23, 0.95) ><br>TestHeterogeneity: for overall Chi*=effect: 2=0.07, 3.20df=(P1 = (P 0.0= 0 .79),1)  P= 0% Favorece$—to controle Favorece TBA<br><!-- End of picture text -->  
**Figura K -** _Forest plot_ da Análise de função motora - GMFM (pontuações total e alvo) e GAS – médio prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Std. Mean Difference Std. Mean Difference<br>1.2.1StudyNewor SubgroupSubgroup Mean SD Total_Mean SD Total Weight _ IV, Random,95% CI IV, Random,95% Cl<br>Gablar 2019 29° 09 15 «17 «06 © 15 23.2% 1,53 10.70, 2.35] —_——_<br>Reddihough 2002 27 48 19 4 71 19 25.3% © -0.21 £0.85, 0.43]<br>Xu 2008 744 «98 «23 «6219920 25.0% 41.25 10.59, 1.91] —_<br>Zhu 2016 69 120 «40 Bt 9 40 26.5% 41,68 [1.17, 219] —+—<br>Subtotal (95% Cl) 97 94 100.0% 1.06 [0.17, 1.94] —=>_<br>Heterogenelty: Tau*=<br>Test for overall effect Z=0.70; 2.35Ch*=(P = 022 . 02)40, df= 3  < 0.0001); P= 87%<br>Total (95% Cl) 97 94 100.0% 1.06 0.17, 1.94] =~<br>Heterogeneity: Tau*= 0.70; Chi= 22.40, df= 3 P< 0.0001); P= 87% $—t t<br>TestTest for for subaroupoverall effectdifferences:Z= 2.35 (P=Notapnlicable0.02) Favorece controle Favorece TBA<br><!-- End of picture text -->  
**Figura L -** _Forest plot_ da Análise de função motora - GMFM (vários domínios) - longo prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Std. Mean Difference Std, Mean Difference<br>Study<br>Chaturvedior Subgroup2013, Mean5 SD3 Total_Mean18 6 SD5 Total18 Weight31.9% _ IV, -0.24/0.89,0.2] Random,95% CI IV, Random,95% Cl<br>Reddinough 2002 36 74 24 34 68 24 33.4% 003 £0.54, 0.59)<br>Zhu 2016 mM 41 40 6909 4038.7 4.18 10.71, 1.66] =<br>Total (95% Ci) 82 82 100.0% 0.34 [-0.56, 1.24]<br>Heterogenelty: Tau*= 0.55; Ch*= 16.39, df= 2 P= 0.0005); P= 87% $+<br>Test for overall effect 2= 0.75 (P= 0.45) Favorece controle Favorece TBA<br><!-- End of picture text -->  
**Figura M -** _Forest plot_ da Análise de função motora - GMFM pontuação total - longo prazo (subgrupo)  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Mean Difference Mean Difference<br>Study or Subgroup _Mean SD Total Mean SD __Total_Weight_IV, Random,<br>ChaturvediReddinough2013 2002 365 743 1824 346 685 1824 69.0%31.0% -1,00/3.69,0.205 3.82,95%4.22}1.69]Cl IV, Random, 95%Cl<br>Total (95% CI) 42 42 100.0%  -0.63[-2.87, 1.61]<br>‘TestHeterogeneity: Tau= 0.00; Chi*= 0.24, df=1 (P= 0.63); F= 0% ho $ ry t rr<br>for overall effect: Z= 0.56 (P = 0.58) Favorece TBA Favorece controle<br><!-- End of picture text -->  
**Figura N -** _Forest plot_ da Análise de função motora - GMFM e GAS - médio prazo - análise de subgrupo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Std. Mean Difference Std, Mean Difference<br>XuCablarStudy2006or 2019) Subgroup _Mean744°290995SD Total_Mean23«15 621«17 9908SD Total2018 Weight19.4%30.4% _ IV, Random,1.531.25 (0.70,(0.59,95%235] CI1.91] IV, Random,95%————Cl<br>Zhu 2016 69 12 «40 Bt 9 40 50.3% 1.68 (1.17, 219] =<br>Total (95% Cl) 78 75 100.0% 1.52 [1.16, 1.88] a><br>TestHeterogeneity: for overall Tau?effect:= Z= 0.00; 8.18Chi*= (P < 0.00001)1.04, df= 2 (P= 0.60); F= 0% Favorece$—tcontrole Favorecet  TBA<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Amplitude de movimento</u>** -->
Para análise desse desfecho foi considerada a amplitude do movimento passivo. Para a articulação do tornozelo, considerou-se preferencialmente a dorsiflexão passiva com o joelho estendido, que contrai o músculo gastrocnêmio. Na análise de curto prazo ( **Figura O** ) foram avaliados dois estudos clínicos, que indicaram maior amplitude de movimento no grupo tratado com TBA em comparação a fisioterapia: diferença média [IC 95%]: 8,35 [1,19; 15,50]. Considerando o período de médio prazo ( **Figura P** ), foram analisados cinco estudos, cujos resultados também favorecem a TBA, diferença média [IC 95%]: 6,37 [4,04; 8,71]. Para análise de longo prazo ( **Figura Q** ) foram considerados quatro estudos clínicos que também indicaram maior  
amplitude de movimento no grupo de indivíduos tratados com TBA, Diferença média [IC 95%]:6,47 [4,42; 8,52]. Para esse desfecho, a certeza da evidência foi considerada como muito baixa.  
**Figura O -** _Forest plot_ da Amplitude do movimento - dorsiflexão passiva do tornozelo - curto prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Mean Difference Mean Difference<br>Study or Subgroup _Mean SD Total Mean SD _Total_Weight_IV, Random,<br>Xu 2006 17 66 23 -03 a1 20 499% 12,00/9.34,14.66)95% Cl IV, Random, 95% Cl =<br>Zhu 2016 181 76 71 134 82 70 601% 4.70 (2.09,7.31) -_<br>Total (95% CI) 4 90 100.0% 8.35 1.19, 15.50] <=<br>TestHeterogeneity: Tau?= 24.84; Chit= 14.73, df=1 (P= 0.0001); F= 93% bate ry to a0<br>for overall effect: Z= 2.29 (P = 0.02) Favorece controle Favorece TBA<br><!-- End of picture text -->  
**Figura P -** _Forest plot_ da Amplitude do movimento - dorsiflexão passiva do tornozelo - médio prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Mean Difference Mean Difference<br>Study or Subgroup Mean SD Total Mean SD Total Weight IV, Random,<br>EPEtribi 95% Cl IV, Random, 95% Cl<br>Love 20012004 2 8 82 13564 2012 26411 287 © 2012-75186 % — 9,921 0 (/ 2 10,06, 17.70}6.26) —_—<br>Reddinough 2002 14 75 11-73-7911 10.2% 8.70 (2.26, 15.14] —_——<br>Xu 2006 M120 49 23° 340-26 20 31.3% 8.10 [6.80, 10.40) =<br>Zhu 2016 M8 58 71 162 75 72 325%  5.60(3.43,7.77] ><br>Total (95% Cl) 137 135 100.0% 6.37 [4.04, 8.71] ><br>Heterogeneity: Tau*= 3.15; Chi*= 7.99, df= 4 (P= 0.09); P= 50% Sat j i] rr<br>Test for overall effect: Z= 6.36 (P < 0.00001) Favorece controle Favorece TBA<br><!-- End of picture text -->  
**Figura Q -** _Forest plot_ da Amplitude do movimento - dorsiflexão passiva do tornozelo - longo prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Mean Difference Mean Difference<br>Study or Subgroup Mean SD Total_Mean SD __Total_Weight_IV, Random,<br>Love 2001 4894 12-52 44 12 11.7% 10.00(4.13, 1587)95% Cl IV, Random, 95%—————Cl<br>Redalhough 2002 54 92 34 31 117 34 16.0% 8.60 (3.50, 13.80} —_—_<br>Tedroff 2010 6 0 6 2 a9 9 39% 8.005229, 18.29)<br>Zhu 2016 21 57 Tl 168 77 72 68.4% — §.30(3.08,7.52) a<br>Total (95% Cl) 123 127 100.0% 6.47 [4.42, 8.52] ><br>TestHeterogeneity: Tau*= 0.32; Chit= 3.15, df= 3 (P = 0.37); P= 5% bate ry to 7}<br>for overall effect: Z= 6.19 (P < 0.00001) Favorece controle Favorece TBA<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Espasticidade</u>** -->
A espasticidade foi avaliada com auxílio de diversas escalas. As escalas mais utilizadas pelos estudos clínicos foram a EAM (n=13) e a escala de Tardieu Modificada (n=7). Considerando a avaliação dos flexores plantares do tornozelo, as análises indicam que há maior redução nas pontuações das EA/EAM e Tardieu no grupo tratado com TBA, sendo a diferença padronizada das médias [IC 95%] de -0,77 [-1,68; 0,15] em curto prazo ( **Figura R** ), -1,31 [-2,21; -0,41] em médio prazo ( **Figura S** ) e -0,78 [-1,03; -0,52] em longo prazo ( **Figura T** ). Outros grupos musculares também foram analisados a longo prazo ( **Figura T** ). Foi realizada análise de subgrupo considerando a avaliação dos flexores plantares do tornozelo a médio prazo ( **Figura U** ). Para esse desfecho, a certeza da evidência foi considerada muito baixa.  
**Figura R -** _Forest plot_ da Espasticidade - flexores plantares do tornozelo - curto prazo  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Std. Mean Difference Std, Mean Difference<br>Study or Subgroup Mean SD Total_Mean SD Total Weight _ IV, Random, 95% CI IV, Random, 95% Cl<br>Bertan 2020 2 083 25 198 OF 24 333%  0.03¢053,059)<br>xu 2006 O7 OF 23° 18 03 20 30.6% 1,96 [2.70,-1.22) ——*—<br>Zhu 2016 16 09 71 2 OF 72 362% -0.49-0.83,-0.16) _<br>Total (95% Cl) 119 116 100.0% — -0.7 [-1.68, 0.15]<br>Heterogeneity: Tau*= 0.57; Ch*= 18.03, df= 2 P= 0.0001); P= 89% $—+ +<br>Test for overall effect Z= 1.64 (P = 0.10) Favorece TBA Favorece controle<br><!-- End of picture text -->  
**Figura S -** _Forest plot_ da Espasticidade - flexores plantares do tornozelo - médio prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinicaSD Total_MeanCuidado usualSD ou FTTotal Weight Std._ IV, Mean Random, Difference95% CI StdIV ,  MeaRa n  Differencedom,95% Cl<br>2004 09 08 20 18 03 20 238%  -1.86(261,-1.11] =<br>BertanELEtribi2020 173079 25 1.98 O72 24 257% -0.33/0.89,0.24)<br>Xu 2006 1 03° 23° 18 03 20 23.0% © -262-3.45,-1.78} —<br>Znu 2016 120 1 7 18 08 72 27.8% — -0.86(-41.00,-0.32] _<br>Total (95% Cl) 139 136 100.0% © -1.31[-2.21,-0.41] =><br>Heterogeneity: Tau?=<br>Test for overall effect: Z=0.73; 2.86Chi*= (P  28= 0 . 004)44, df= 3 (P « 0.00001); P= 89% 4—+Favorece TBA + Favorece+ controle +<br><!-- End of picture text -->  
**Figura T -** _Forest plot_ da Espasticidade – vários grupos musculares - longo prazo  
<!-- Start of picture text -->
1.11.4Study orFlexores SubgroupplantaresMeanToxinado tomnozelo botulinicaSD Total_MeanCuidado usualSD ou FTTotal Weight Std._ IV, Mean Random, Difference95% CI StdIV ,  MeaRa n  Differencedom,95% Cl<br>lorahim 2007 63012 18 7 13 18 98%  -1.3262.12,-0.57] —_—<br>Reddinough 2002-01 08 35 O4 08 35 24.2%  -0.62[-41.10,-0.14) =<br>Tedroff 2010 08 12 6 01 O07 = 95.5% = -071 £1.79, 0.36)<br>Zhu 2016 110 40720 18) 0871 41.9% 0.77 4.11, -0.43] =<br>Subtotal (95% CI 128 130 81.3% — 0.78 [-1.03, 0.52] ad<br>TestHeterogenelty: Tau*=0.00; Chi*= 2.22, df= 3 (P= 0.53), P= 0%<br>for overall effect: Z= 5.99 (P < 0.00001)<br>1.11.2 Adutores<br>lrahimReddihough2007 do quadrit2002-06531«14 15«68 = 7131 08) 18 9.4%47% -1.43F2.24,-061]4.87 F2.74,-0.41] ——————<br>Subtotal (95% Ci) 2B 23 14.1% © 4472.14, 081] <=_<br>TestHeterogenelly: Tau*=0.00; Chi*= 0.04, df=1 (P= 0.84); P= 0%<br>for overall effect Z= 4.33 (P < 0.0001)<br>1.11.3 Isquiotibiais, ————<br>TedroffSubtotal 2010(95% Cl) 05 05 66 0 02 99 46%46%  1.35(253,.018 -135'253,-018) $=—<br>Heterogeneity: Not applicable<br>Test<br>for overall effect Z= 2.25 (P= 0.02)<br>Total (95% Cl) 187 162 100.0% 0.91 [-1.17, -0.65] ><br>Hetrognety:est for overall  T=effect 0.01;Z= Chk < 84. ef« 6 P= 0.7) P= 4—+—}—- +++<br>Test for subaroun differences: Chit= 4.28, df= 2(P = 0.12), P= 63.2% Favarece TBA Favarece conivole<br><!-- End of picture text -->  
**Figura U -** _Forest plot_ da Espasticidade - flexores plantares do tornozelo - médio prazo (subgrupo)  
<!-- Start of picture text -->
Toxina botulinica Cuidado usual ou FT Mean Difference Mean Difference<br>Study or Subgroup Mean SD Total Mean SD __Total_Weight_IV, Random,<br>95% Cl<br>175 079° 26 «187 O75 24 270% -0.1250.55,0.31]<br>Bertan 2020 IV, Random, 95%Cl<br>ELEtribi 2004 09 06 2 18 03 20 338% -090/1.19,-061) =<br>Xu 2008 1 03 23 18 03 20 392% -0.80[-0.98,-0.62) =<br>Total (95% Cl) 68 64 100.0%  -0.65[-1.01, -0.29] =><br>TestHeterogeneity: Tau*= 0.08; Chit= 9,50, df= 2 (P= 0,009); F= 79% 5 4 ry + 3<br>for overall effect: Z= 3.60 ( = 0,0005) Favorece TBA Favorece controle<br><!-- End of picture text -->  
TBA comparada a placebo

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Análise de marcha</u>** -->
Para avaliação da marcha, os estudos clínicos realizaram análise observacional utilizando uma versão da _Physician Rating Scale (PRS)_ ou análise de vídeo da marcha (VGA) para classificar o padrão de marcha da criança em cinco categorias, de acordo com o contato inicial do pé. A análise realizada em curto prazo incluiu quatro estudos clínicos e a de média prazo incluiu três. Ambas indicaram que a utilização da TBA favorece a marcha, sendo o risco relativo [IC 95%] 1,66 [1,16; 2,37] no período de curto prazo ( **Figura V** ) e 1,90 [1,32; 2,74] considerando médio prazo ( **Figura W** ). Um estudo clínico realizou análise instrumental da marchae em curto prazo utilizando a goniometria avaliando o pico de dorsiflexão do tornozelo em posição e em balanço, o estudo obteve como resultado da análise diferença média [IC 95%] de 11,56 [6,17; 16,96] ( **Figura X** ). Para esse desfecho, a certeza da evidência foi considerada baixa.  
**Figura V -** _Forest plot_ da Análise observacional da marcha - VGA ou PRS – curto prazo  
<!-- Start of picture text -->
Toxina botulinica Placebo Risk Ratio Risk Ratio<br>Study<br>orSubgroup __Events __Total_Events Total Weight M-H, Random, 95% Cl M-H, Random, 95% Cl<br>Kanovsky 2004 16 52 13.50 33.2M «1.18 (0.64, 2.20]<br>Koman 1994 5 G 2 6 9.1% 2.50 10.76, 8.19]<br>Koman 2000 25 53 1555 -47.7M 1.73 [1.03, 2.90]<br>bhi 2000 10 21 3 18 10.1% 2.86 [0.93, 6.61]<br>Total (95% Cl) 132 129 100.0% 1.66 [1.16, 2.37] ><br>Total events 56 33<br>Heterogenety: Tau? = 0.00; Chr = 2.52, df= 3 (P = 0.47); F = OX OT to a0<br>Test for overall effect: Z = 2.78 (P = 0.006) " Favorece placebo Favorece TBA<br><!-- End of picture text -->  
**Figura W -** _Forest plot_ da Análise observacional da marcha - VGA ou PRS - médio prazo  
<!-- Start of picture text -->
Toxina botulinica Placebo Risk Ratio Risk Ratio<br>Study<br>orSubgroup __Events _Total_Events Total Weight M-H, Random, 95% Cl M-H, Random, 95% Cl<br>Kanovsky 2004 20 52. 10 50 317M 1.82 [1.00, 3.69]<br>Koman 2000 28 53017) «55 GL.2M 1.71 [1.07, 2.73] Ha<br>bhi 2000 10 20 2 18 7.1% 4.50 [1.13, 17.85] ———<br>Total (95% Cl) 12s 123 100.0% 1.90 [1.32, 2.74] 5<br>Total events 58 29<br>Heterogenety: Tau?<br>Test = 0.00; Chi= 1.76, df= 2 (P = 0.42); F = Ox OT to a0<br>for overall effect: Z = 3.43 (P = 0.0006) ey” Favorece placebo Favorece TBA<br><!-- End of picture text -->  
**Figura X -** _Forest plot_ da Análise instrumental da marcha – Goniometria - curto prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinica__SD_ Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95% Cl Iv,MeanRandom, Difference95% Cl<br>1.3.1 Pico de dorsiflexao do tornozelo em posi¢ao<br>Sutherland 1999 125 145 10 -3.4 9.8 8 23.9N 15.90 [4.87, 26.93] =<br>Subtotal (95% CI) 10 9 23.9% 15.90 [4.87, 26.93] ><br>Heterogeneity: Not applicable<br>Test for overall effect: Z = 2.82 (P = 0.005)<br>1.3.2 Pico de dorsiflexao do tornozelo em balanco<br>Sutherland 1999 64 5 10 -3.8 6.2 8 76.1% 10.20 [4.01, 16.39] a<br>Subtotal (95% Cl) 10 9 76.1% 10.20 [4.01, 16.39] °<br>Heterogenetty: Not applicable<br>Test for overall effect: Z = 3.23 (P = 0.001)<br>Total (95% Cl) 20 18 100.0% 11.56 (6.17, 16.96] °<br>TestTestHeterogenetty: for  overallsubgroup Tau? effect:differences:= 0.00;Z = 4.20ChChi? (P= < = 0.78, 0.0001) 0.78, df df= =1 (P1 (P = = 0.38); 0.38),F =F = ON 0% ‘oo Favorecete placebo Favorece TBA= 700<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Análise da função motora</u>** -->
Para avaliação da função motora, os estudos clínicos utilizaram a _Gross Motor Function Measure_ (GMFM), _Canadian Occupational Performance Measure_ (COPM) e _Physician's Global Assessment_ (PGA). Na avaliação a curto prazo ( **Figura Y** ), dois estudos realizaram medida padrão, sendo que a diferença padronizada das médias [IC 95%] obtida foi -0,28 [-0,66; 0,10]. Outros dois estudos utilizaram medidas individualizadas e a diferença padronizada das médias [IC 95%] obtida foi 0,71 [0,43; 1,00]. Na avaliação a médio prazo ( **Figura Z** ), dois estudos utilizaram medida padrão e a diferença padronizada das médias [IC 95%] obtida foi 0,05 [-0,32; 0,43] e três estudos clínicos utilizaram medidas individualizadas e apresentaram como diferença padronizada das médias [IC 95%] 0,39 [0,12; 0,66]. A longo prazo, apenas um único estudo utilizou medida padrão e um outro estudo medida individualizada ( **Figura AA** ). A certeza da evidência foi considerada moderada para esse desfecho no curto e médio prazo e baixa para o longo prazo.  
**Figura Y -** _Forest plot_ da Função - GMFM, COPM ou PGA - curto prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinicaSD Total MeanPlaceboSD Total Weight Std.IV, MeanRandom,Difference95% CL ‘Std.1,  MeanRandom,Difference95% Ct<br>‘1.4.1 Medida Padrao<br>Baker 2002 21 a7 26 41 43 30° 24.7% = -+).36 [-0.89, 0.17]<br>Kanovaky 2004 29 29 26 38 «63 26 24AN 0.20 [-0.75, 0.34]<br>‘Subtotal (95% Cl) 52 56 49.2%  -0.28 [-0.66, 0.10)<br>TestHeterogenelty:for overall effect:Tau! = 0.00;Z = 1.45Che(P = =0.16, 0.15)df = 1(P = 0.69); F = Ox<br>1.4.2 Medidas Individualizadas<br>Copeland 2014 6.21 2.15 23° 4.42 2.13 18 22.6% 0.82 (0.18, 1.46] —_—_<br>Delgado 2016 15 12054 79 0.73 10133 77 283K 0.69 10.36, 1.01] =<br>SubtotalTestHeterogeneity:for overall(95%  effect:Tau!CI) = 0.00;Z = 4.64 Che (P <= 0.13, 0.00001} df102= 1(P = 0.72); F =0X95 50.8% 0.71 (0.43, 1.00) ><br>Total (95% Cl) 1s4 151 100.0% 0.24 [-0.35, 0.83]<br>Heterogenetty: Tau! = 0.29; Che<br>TestTest for  overallsubgroup effect: differences:Z = 0.81Chi (P == = 16.97, 0.42)16.68,df df= = 3 (P1  =(P < 0.0007); 0.0001), # =F = 62x 94.0% Favorece+—placebo Favorece THA<br><!-- End of picture text -->  
**Figura Z -** _Forest plot_ da Função - GMFM, COPM ou PGA - médio prazo  
<!-- Start of picture text -->
Study15.1  orMedida SubgroupPadrao__ MeanToxina botulinicaSD_ Total MeanPlaceboSD_ Total Weight Std.IV, Mean Random,Difference 95% CI ‘Std.IV, Random, Mean Difference 95% Cl<br>KanovskySubtotalBaker 2002(95%2004Cl 595.9 56B.1 26522 6641 66Bo 265731 (17.5%162%33.7% -0.11[-0.66,0.210.05 [-0.31,[-0.32, 0.73]0.43)0.43]<br>TestHeterogeneity:for overall effect:Tau = 0.00;Z = 0.26Chi! (P = =0.69, 0.78)df = 1 (P = 0.41); F = OX<br>1.5.2 Medidas Individualizadas<br>Bjornson 2007 7? 14 17 12 L? 16 10.1% 0.31 [-0.37, 1.00]<br>Copeland 2014 5.22 1.94 23° 4.41 1.93 18 12.3% 0.41 [-0.21, 1.03]<br>Delgado 2016 112949 74 (04 1.6776 70 43.9% 0.40 10.07, 0.73] Pa<br>Subtotal (95% CI) 114 104 66.3% 0.39 (0.12, 0.66] ><br>TestHeterogeneity:for overall effect:Tau = Z0.00; = 2.84Chi! (P = =0.05, 0.005)df = 2 (P = 0.97); F = Ox<br>Total (95% CI) 166 161 100.0% 0.28 [0.06, 0.49} ><br>Heterogenelty: Tau!<br>‘TestTest for  overallsubgroup effect: differences:= 0.00; Z = 2.47 CheChi(P == 2.76, = 0.01)2.01, df=df =4 (P1  =(P =0.60); 0.16),F = Ox# = 50.2% Favorece+—placebo Favorece TBA<br><!-- End of picture text -->  
**Figura AA -** _Forest plot_ da GMFM, COPM ou PGA - longo prazo  
<!-- Start of picture text -->
Study1.6.1  orMedida SubgroupPadrao_ MeanToxina botulinicaSD_ Total MeanPlaceboSD Total Weight Std.IV, Mean Random,Difference 95% CI Std.IV, Random, Mean Difference 95% Cl<br>Moore 2008 68 6 30 B268 28 637K -0.22[-0.73, 0.301<br>Subtotal (95% Cl) 30 28 63.7% -0.22 [-0.73, 0.30)<br>Heterogenelty: Not applicable<br>‘Test for overall effect: Z = 0.82 (P = 0.41)<br>BjornsonSubtotal1.6.2 Medidas 2007(95% Cl)Individualizadas21 17 1717 17:22 1616 36.3%36.3% 0.200.20 [-0.49,[-0.49, 0.88)0.88]<br>Heterogenetty: Not applicable<br>‘Test for overall effect: Z = 0.57 (P = 0.57)<br>Total (95% Cl) 47 44 100.0%  -0.07 [-0.48, 0.35]<br>Heterogenetty: Tau?<br>‘TestTest for  overallsubgroup effect: differences:= 0.00;Z = 0.31ChF Chi (P == = 0.90, 0.76) 0.90,df= df= 1 1(P (P = = 0.34); 0.34),F F= = OX Ox Favorece+—placebo Favorece TBA<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Amplitude de movimento</u>** -->
Para análise desse desfecho foi considerada a amplitude de movimento passiva, utilizando a goniometria. Na análise de curto prazo ( **Figura AB** ) foram considerados três estudos clínicos, que indicaram maior amplitude de movimento no grupo tratado com TBA em comparação a placebo, diferença média [IC 95%]: 2,68 [0,12; 5,23]. Considerando o período de médio prazo ( **Figura AC** ), apenas dois estudos foram analisados e a diferença média [IC 95%] obtida foi 1,57 [-2,12; 5,25]. Para análise de longo prazo ( **Figura AD** ), um único estudo clínico foi considerado, com diferença média de -1,09 [-6,52; 4,33]. Para esse desfecho, a certeza da evidência foi considerada muito baixa.  
**Figura AB -** _Forest plot_ da Amplitude do movimento passivo – Goniometria - curto prazo  
<!-- Start of picture text -->
Toxina botulinica Placebo Mean Difference Mean Difference<br>Study or Subgroup Mean SD Total Mean SD_Total_Weight IV, Random, 95% Cl IV, Random, 95% Cl<br>Baker 2002 06 163 50 06 135 46 184K 0.00 (-5.97, 5.971<br>Delgado 2016 29 116078 79 1.2 11.8157 76 48.1X 4.10 (0.41, 7.79] —»—<br>bhi 2000 3.8 4.9619 22 17 64458 18 335K 2.10 [-2.32,6.521<br>Total (95% CI) 151 140 100.0% 2.68 (0.12, 5.23] eae<br>Heterogenehty: Tau<br>Test for overall effect:= Z0.00; = 2.05Ch (P= = 1.41, 0.04) df = 2 (P = 0.49); # = Ox SetFavorece placebo Favorece TBA 7<br><!-- End of picture text -->  
<!-- Start of picture text -->
Figura AC - Forest plot  da Amplitude do movimento passivo – Goniometria - médio prazo<br>Study or Subgroup MeanToxina botulinicaSD Total Mean Placebo_SD_Total Weight 1V,MeanRandom, Difference95% CI IV,MeanRandom, Difference95% Cl<br>Baker 2002 22 132 55 -28 148 55 49.1N 0.60[-4.66, 5.66]<br>Ubhi 2000 22 63451 22 0.3 8.244718 50.9% 2.50 [-2.66, 7.66]<br>Total (95% Cl) 7 73 100.0% 1.57 {-2.12, 5.25)<br>Heterogeneity: Tau?<br>Test for overall effec:= Z0.00; = 0.83Ch (? == 0.26, 0.40)df= 1(P = 0.61); F = OX haeFavorece placebo Favorece TBA a<br><!-- End of picture text -->  
<!-- Start of picture text -->
Figura AD - Forest plot  da Amplitude do movimento passivo – Goniometria - longo prazo<br>Study or Subgroup MeanToxina botulinicaSD Total MeanPlaceboSD Total Weight _1V,MeanRandom, Difference95% Cl IV,MeanRandom, Difference95% Cl<br>1.10.1 Dorsiflexao do tornozelo<br>Moore 2008 1 102 21 0.3 5.8 19 587K 0.20 [-4.88, 5.28]<br>Subtotal (95% Cl) 2 19 58.7% 0.20 [-4.88, 5.28]<br>Heterogenetty: Not applicable<br>‘Test for overall effect: Z = 0.08 (P = 0.94)<br>1.10.2 Extensio do joelho<br>Moore 2008 “31 7.7 11 25 93 6 34.0% -5.60 1-13.49, 2.29]<br>Subtotal (95% Cl) rv 8 34.0% ~5.60 [-13.49, 2.29]<br>“TestHeterogeneity: for overall effect:Not applicable Z = 1.39 (P = 0.16)<br>1.10.3 Abdugao de quadril<br>Moore 2008 1.7 161 3 21103 68 7.2% 9.601-9.97,29.17]<br>Subtotal (95% Cl) 3 8 72% 9.60 [-9.97, 29.17]<br>‘TestHeterogeneity:for overall effect:Not applicable Z = 0.96 (P = 0.34)<br>Total (95% C) 35 35 100.0% -1.09 [-6.52, 4.33]<br>Heterogeneity: Tau! = 6.32; Chi = 2.65, df= 2 (P = 0.27); P= 24% 00 6 aoe<br>‘TestTest for for subgroupoverall effect:differences:Z = 0.40Chi?(P = =0.68)2.65, df= 2(? = 0.27), F = 24.5% Favorece placebo Favorece TBA<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Espasticidade</u>** -->
A espasticidade foi avaliada com a EAM. Utilizando a avaliação dos flexores plantares do tornozelo, apenas um único ECR foi considerado na análise de curto e médio prazo ( **figuras AE e AF** ), o resultado obtido indica que o grupo tratado com TBA tem maior redução na pontuação da escala, sendo a diferença média [IC 95%]: -0,49 [-0,78; -0,20] e -0,50 [-0,78; -0,22], respectivamente. Na análise a longo prazo ( **Figura AG** ), outro único estudo foi considerado e a diferença média [IC 95%] foi 0,10 [-0,58; 0,78]. Para esse desfecho, a certeza da evidência foi considerada moderada no curto e médio prazo e baixa no longo prazo.  
<!-- Start of picture text -->
Figura AE - Forest plot  da Espasticidade: flexores plantares do tornozelo – MAS - curto prazo<br>Study or Subgroup MeanToxina botulinica__SD_Total_Mean PlaceboSD Total Weight IV,MeanRandom, Difference95% CI IV,MeanRandom, Difference95% Cl<br>Delgado 2016 0.87 0.9376 79 0.48 0.9252 77 100.0N -0.49 [-0.78, 0.20]<br>TotalHeterogenety:(95% CI) Not applicable 79 77 100.0% -0.49 [-0.78, -0.20] 3 ><br>Test for overall effect: Z = 3.29 (P = 0.001) Favorete TBA’ Favorece placebo<br>Figura AF - Forest plot  da Espasticidade: flexores plantares do tornozelo – MAS - médio prazo<br>Study or Subgroup MeanToxina botulinicaSD Total Mean Placebo__SD_Total_Weight__1V,MeanRandom, Difference95% CI WV,MeanRandom, Difference95% Cl<br>Delgado 2016 “1 0.8633 74 0.5 0.8388 70 100.0% -0.50 [-0.76, -0.22]<br>Total (95% Cl) 74 70 100.0% -0.50 [-0.78, -0.22] ><br>Heterogenety: Not applicable =<br>Test for overall effect Z = 3.52 (P = 0.0004) Favorece TBA. Favorece placebo<br><!-- End of picture text -->  
**Figura AG -** _Forest plot_ da Espasticidade – MAS - longo prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinicaSD Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95% Cl IV,MeanRandom, Difference95% Cl<br>1.13.1 Flexores plantares de tornozelo<br>Moore 2008 05 13 21 040.9 21 43.2% 0.10 [-0.58, 0.78]<br>Subtotal (95% Cl) 21 21 43.2% 0.10 [-0.58, 0.78]<br>Heterogeneity: Not applicable<br>Test for overall effect: Z = 0.28 (P = 0.77)<br>1.13.2 Isquiotibiais<br>Moore 2008 07 11 7 0306 3 25.2% 1.00 [-2.06, 0.06]<br>Subtotal (95% Cl) 7 3 25.2% -1.00 [-2.06, 0.06]<br>‘TestHeterogeneity: for overall Noteffect: applicableZ = 1.85 (P = 0.06)<br>1.13.3 Abdugio de quadril<br>Moore 2008 02 08 5 0.10.8 8 316N 0.10[-0.79,0.99]<br>Subtotal (95% Cl) 5 8 316% 0.10 [-0.79, 0.99]<br>Heterogeneity: Not applicable<br>Test for overall effect: Z = 0.22 (P = 0.83)<br>Total (95% Cl) 33 32 100.0% -0.18 [-0.81, 0.46]<br>Heterogeneity: Tau?<br>Test = 0.12; Ch= 3.28, dF= 2 (P = 0.19); P= 39% +S<br>‘Test for  overallsubgroup effect:differences:Z = 0.55 Ch’ (P = = 0.58)3.28, dF = 2 (P = 0.19), F = 39.1N Favorece TBA” Favorece placebo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Satisfação</u>** -->
Para avaliar a satisfação, três estudos clínicos utilizaram uma avaliação subjetiva da percepção do cuidador sobre o benefício do tratamento. Na avaliação de curto prazo, dois ECR foram considerados com risco relativo [IC 95%] de 1,20 [0,72; 2,01] ( **Figura AH** ). Para médio prazo, também foram considerados dois estudos com risco relativo [IC 95%] obtido de 1,32 [0,94;1,83] ( **Figura AI** ). Ainda sobre esse desfecho, outros dois estudos clínicos utilizaram o domínio de satisfação da _Canadian Occupational Performance Measure_ (COPM), com análises de curto, médio e longo prazo realizadas e as diferenças médias [IC 95%] obtidas de 1,81 [0,25; 3,37], 0,96 [0,04; 1,88] e 0,10 [-1,27; 1,47] respectivamente – **figuras AJ, AK e AL** . A certeza da evidência para esse desfecho foi considerada muito baixa quando utilizado o questionário subjetivo e baixa quando utilizado o COPM.  
**Figura AH -** _Forest plot_ da Satisfação - Questionário subjetivo - curto prazo  
<!-- Start of picture text -->
Toxina botulinica Placebo Risk Ratio Risk Ratio<br>Study or Subgroup __Events_Total_Events Total Weight M-H, Random, 95% Cl M-H, Random, 95% Cl<br>Kanovsky 2004 13 26 «1226 «833M «1.08 (0.62, 1.91]<br>Koman 1994 4 6 2 6 16.7% 2.00 10.56, 7.09]<br>Total (95% Cl) 32 32 100.0% 1.20 (0.72, 2.01]<br>Total events 17 14<br>Heterogenety: Tau?<br>Test for overall effect:= 0.00;Z = 0.69Ch (P= = 0.75,0.48)df = 1 (P = 0.39); P = ON TossFavorece placebo Favorece TBA rT<br><!-- End of picture text -->  
**Figura AI -** _Forest plot_ da Satisfação - Questionário subjetivo - médio prazo  
<!-- Start of picture text -->
Toxina botulinica Placebo Risk Ratio Risk Ratio<br>Study or Subgroup __Events__Total_Events Total Weight M-H, Random, 95% Cl M-H, Random, 95% Cl<br>Baker 2002 21 27 «1631 «85.0N 1.34 (0.93, 1.92]<br>Kanovsky 2004 8 26 7 27 15.0% 1.19 (0.50, 2.60]<br>Total (95% Cl) 53 58 100.0% 1.32 (0.94, 1.83]<br>Total events 23 25<br>Heterogenety: Tau?<br>Test for overall effect:= Z = 0.00; 1.62Ch(?= = 0.07, 0.11)df = 1 (P = 0.79); P = Ox TonesFavorece placebo Favorece TBA 7}<br><!-- End of picture text -->  
**Figura AJ -** _Forest plot_ da Satisfação – COPM - curto prazo  
<!-- Start of picture text -->
Study or Subgroup _MeanToxina botulinica__SD Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95% CI IV,MeanRandom, Difference95% Cl<br>Copeland 2014 621 263 23 4.4 2.45 18 100.0% 1.81 [0.25, 3.37]<br>Total (95% CI, 23 18 100.0% 1.81 (0.25, 3.37] -_<br>Heterogenetty: Not applicable to 10<br>‘Test for overall effect: Z = 2.27 (P = 0.02) Favorece placebo Favorece TBA<br><!-- End of picture text -->  
**Figura AK -** _Forest plot_ da Satisfação – COPM - médio prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinicaSD Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95% CI IV,MeanRandom, Difference95% CI<br>Bjornson 2007 1818 17 11 17 16 59.5N 0.70[-0.49, 1.89]<br>Copeland 2014 5.24 265 23 3.89 2.08 18 405K 1.35 [-0.10, 2.80]<br>Total (95% Cl) 40 34 100.0% 0.96 [0.04, 1.88] ———<br>Heterogenetty: Ta?<br>Test for overall effect:= Z0.00; = 2.05Chi(P= =0.46,0.04) df= 1 (P = 0.50);P=ON Favorece+—placebo Favorece TBA<br><!-- End of picture text -->  
**Figura AL -** _Forest plot_ da Satisfação – COPM - longo prazo  
<!-- Start of picture text -->
Study or Subgroup MeanToxina botulinicaSD Total MeanPlaceboSD Total Weight IV,MeanRandom, Difference95% Cl IV,MeanRandom, Difference95% Cl<br>Copeland 2014 16 22 17 17 18 16 100.0N 0.10[-1.27,1.47]<br>Total (95% CD 17 16 100.0% 0.10 [-1.27, 1.47]<br>Heterogenetty: Not applicable 4 Ty<br>Test for overall effect: Z = 0.14 (P = 0.89) Favorece placebo Favorece TBA<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Eventos adversos</u>** -->
Para esse desfecho foram analisados resultados de 11 ECR. Foram considerados todos os eventos adversos relatados, independente da gravidade. A análise resultou em um risco relativo [IC 95%] de 1,29 [0,87; 1,93], conforme **Figura AM** . Para esse desfecho, a certeza da evidência foi considerada muito baixa.  
**Figura AM -** _Forest plot_ de eventos adversos  
<!-- Start of picture text -->
Toxina botulinica Placebo Risk Ratio Risk Ratio<br>Study<br>Baker 2002or Subgroup __Events_Total_Events48 94 «10.31Total Weight«12.4K M-H, Random,«1.58 (0.92,95%2.74]CI M-H, Random, 95% Cl<br>Blornson 2007 30 56-26 «56 «14.1% 1.15 (0.80, 1.67]<br>Copeland 2014 18 23° «6 «18 109% 2.35 [1.18, 4.67] —_——<br>Delgado 2016 11180 7 79 BBX 0.78 (0.31, 1.92]<br>Kanovsky 2004 10 260-1326 11.6N 0.77 (0.41, 1.43]<br>Koman 1994 3 € 6 6 10.1% 0.54 10.25, 1.16]<br>Koman 2000 12 72 3 72 GAX = 4,00 [1.18, 13.58] ——<br>Mall 2006 3 32 3 28 65K 2.63 10.79, 8.75]<br>Moore 2008 23 30-27) «28 «16.0% = 1.00 (0.91, 1.11]<br>Sutherland 1999 0 a or) Not estimable<br>bhi 2000 6 22 1 18 3.1% 4,91 10.65, 37.13]<br>Total (95% Cl) 531 371 100.0% 1.29 [0.87, 1.93]<br>Total events 176 102<br>‘TestHeterogenehy: Tau? = 0.26; Ch? = 44.47, df= 9 <P < 0.00001); F = 80% T0205 70<br>for overall effect: Z = 1.26 (P = 0.21) “ """ Favorece BTA Favorece placebo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **Perfil de evidências:** -->
Nas **tabelas C e D** , são apresentados os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) de TBA comparada à fisioterapia ou cuidado usual para os desfechos função motora, amplitude de movimento e espasticidade, sendo que na primeira considera-se o período de curto prazo, enquanto na segunda a avaliação o período de médio prazo. A **Tabela E** apresenta os resultados e a avaliação da certeza da evidência para o período de longo prazo para os mesmos desfechos, além da satisfação. As **tabelas F a H** consideram o período de análise e apresentam avaliação da certeza da evidência de TBA comparada à placebo para os desfechos de marcha, função, espasticidade e satisfação. Já a **Tabela I** apresenta os resultados para o desfecho de eventos adversos da comparação entre TBA e placebo.  
**Tabela C -** TBA comparado a cuidado usual ou fisioterapia para espasticidade em crianças – curto prazo 2 a 8 semanas  
||||**Avaliação d**|**a certeza**|||**Nº de**|**pacientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Nº de**<br>**estud**<br>**os**|**Delinea**<br>**mento**<br>**do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsist**<br>**ência**|**Evidênci**<br>**a**<br>**indireta**|**Impreci**<br>**são**|**Outras**<br>**considerações**|**TBA**|**Cuidado**<br>**usual ou**<br>**fisioterapi**<br>**a**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|**Certeza**|**Importânci**<br>**a**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise de função motora - curto prazo (seguimento: variação 2 semanas para 8 semanas; avaliado com: GMFM pontuação total e alvo)** -->
|2|ensaios|muito|não|não|grave<sup>b</sup>|nenhum|63|60|-|DMP**0.59**|⨁◯◯◯|IMPORTA|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Ampli**|clínicos<br>randomi<br>zados<br>**tude do mo**|grave<sup>a</sup><br>**vimento -**|grave<br>**dorsiflexão**|grave<br>**passiva do**|**tornozelo -**|**curto prazo (av**|**aliado com:**|**Goniômetro**|**(graus))**|**mais alto**<br>(0.23 mais<br>alto para<br>0.95 mais<br>alto)|Muito<br>baixa|NTE|
|2|ensaios|muito|grave<sup>e</sup>|não||nenhum|94|90|-|DM**8.35**|⨁◯◯◯|IMPORTA|
||clínicos<br>randomi|grave<sup>a</sup>||grave|grave<sup>f</sup>|||||**mais alto**<br>(1.19 mais|Muito<br>baixa|NTE|
||zados|||||||||alto para<br>15.5 mais<br>alto)|||
|**Espas**<br>|**ticidade - fl**<br>|**exores plan**<br>|**tares do to**<br>|**rnozelo - c**<br>|**urto prazo (**<br>|**seguimento: va**<br>|**riação 2 sem**<br>|**anas para 8 s**<br>|**emanas; a**|**valiado com:**<br>|**várias escala**<br>|**s)**<br>|
|3|ensaios|muito|muito|não|muito|nenhum|119|116|-|DMP**0.77**|⨁◯◯◯|CRÍTICO|
||clínicos|grave<sup>a</sup>|grave<sup>c</sup>|grave|grave<sup>d,f</sup>|||||**menor**|Muito||
|||||||||||(1.68|baixa||  
<!-- Start of picture text -->
Avaliação da certeza  Nº de pacientes  Efeito<br>Delinea Cuidado  Importânci<br>Nº de  Evidênci Certeza<br>mento  Risco de  Inconsist Impreci Outras  usual ou  Relativo  Absoluto  a<br>estud a  TBA<br>do  viés  ência  são  considerações  fisioterapi (IC95%)  (IC95%)<br>os  indireta<br>estudo  a<br>randomi menor para<br>zados  0.15 mais<br>alto)<br><!-- End of picture text -->  
**IC:** Intervalo de confiança; **DM:** Diferença de médias; **DMP:** Diferença padronizada de médias  
a. Rebaixado dois níveis devido a diversas fontes de vieses; b. Penalizado em um nível devido ao tamanho amostral; **c.** Elevada heterogeneidade (> 75%); **d.** Amplo intervalo de confiança que inclui a nulidade de efeito; **e.** Apesar do I-quadrado elevado, foi rebaixado apenas um nível, os resultados tendem a apontar para a mesma direção; **f.** Penalizado devido ao tamanho amostral. Em um estudo, os membros inferiores foram utilizados como unidade de análise.  
**Tabela D -** TBA comparado a cuidado usual ou fisioterapia para espasticidade em crianças – médio prazo 12 a 16 semanas  
<!-- Start of picture text -->
Avaliação da certeza  Nº de pacientes  Efeito<br>№  Delinea Cuidado  Importân<br>Evidênci Certeza<br>dos  mento  Risco de  Inconsist Impreci Outras  usual ou  Relativo  Absoluto  cia<br>a  TBA<br>estud do  viés  ência  são  considerações  fisioterapi (IC 95%)  (IC 95%)<br>indireta<br>os  estudo  a<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise de função motora - médio prazo (seguimento: variação 12 semanas para 16 semanas; avaliado com: GMFM (pontuações total e alvo) e GAS)** -->
|4|ensaios|muito|muito|não|não<br>nenhum|97|94|-<br>DMP**1.06**|⨁◯◯◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|grave<sup>a</sup>|grave<sup>c</sup>|grave|grave|||**mais alto**|Muito|ANTE|
||randomi|||||||(0.17 mais|baixa||
||zados|||||||alto para|||  
<!-- Start of picture text -->
1.94 mais<br>alto)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento - dorsiflexão passiva do tornozelo - médio prazo (avaliado com: Goniômetro (graus))** -->
<!-- Start of picture text -->
5  ensaios  muito  grave e não  não  nenhum  137  135  -  DM  6.37  ⨁◯◯◯ IMPORT<br>clínicos  grave a grave  grave  mais alto Muito  ANTE<br>randomi (4.04 mais  baixa<br>zados  alto para<br>8.71 mais<br>alto)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade - flexores plantares do tornozelo - médio prazo (seguimento: variação 12 semanas para 16 semanas; avaliado com: várias escalas)** -->
|4|ensaios|muito|grave<sup>c</sup>|não|grave<sup>d</sup>|nenhum|139|136|-<br>DMP**1.31**|⨁◯◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|grave<sup>a</sup>||grave|||||**menor**|Muito||
||randomi<br>zados||||||||(2.21<br>menor para<br>0.41<br>menor)|baixa||  
**IC:** Intervalo de confiança; **DM:** Diferença de médias; **DMP:** Diferença padronizada de médias s; **DP** : Desvio padrão; **GMFM:** _Gross Motor Function Measure_ **; GAS:** _Goal Attainment Scaling_ .  
**a.** Rebaixado dois níveis devido a diversas fontes de vieses; **b.** Penalizado em um nível devido ao tamanho amostral; **c.** Elevada heterogeneidade (> 75%); **d.** Amplo intervalo de confiança que inclui a nulidade de efeito; **e.** Apesar do I-quadrado elevado, foi rebaixado apenas um nível, os resultados tendem a apontar para a mesma direção; **f.** Penalizado devido ao tamanho amostral. Em um estudo os membros inferiores foram utilizados como unidade de análise; **g.** Moderada heterogeneidade (50%)  
**Tabela E -** TBA comparado a cuidado usual ou fisioterapia para espasticidade em crianças – longo prazo  
|**Certeza da avaliação**|**Nº de pacientes**<br>**Efeito**<br>**Certeza**|
|---|---|  
<!-- Start of picture text -->
№  Delinea Cuidado<br>Evidênci<br>dos  mento  Risco de  Inconsist Impreci Outras  usual ou  Relativo  Absoluto  Importânci<br>a  TBA<br>estud do  viés  ência  são  considerações  fisioterapi (95% CI)  (95% CI)  a<br>indireta<br>os  estudo  a<br><!-- End of picture text -->  
**Análise de função motora - longo prazo (seguimento: variação > 24 semanas para mais; avaliado com: GMFM (vários domínios/pontuação total e alvo))**  
|3|ensaios|muito|muito|não|muito|nenhum|82|82|-<br>SMD**0.34**|⨁◯◯|IMPORTA|
|---|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|grave<sup>a</sup>|grave<sup>c</sup>|grave|grave<sup>d</sup>||||**mais alto**|◯|NTE|
||randomi<br>zados||||||||(0.56 menor<br>para 1.24<br>mais alto)|Muito<br>baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento - dorsiflexão passiva do tornozelo - longo prazo (avaliado com: Goniômetro (graus))** -->
|4|ensaios|muito|não|não|grave<sup>e</sup>|nenhum|123|127|-<br>MD**6.47**|⨁◯◯|IMPORTA|
|---|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|grave<sup>a</sup>|grave|grave|||||**mais alto**|◯|NTE|
||randomi<br>zados||||||||(4.42 mais<br>alto para<br>8.52 mais<br>alto)|Muito<br>baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade - Flexores plantares do tornozelo - longo prazo (seguimento: variação 24 semanas para mais; avaliado com: Várias escalas)** -->
|4<br>ensaios|muito|não|não|grave<sup>e</sup>|nenhum|128|130|-<br>SMD**0.78**|⨁◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos|grave<sup>a</sup>|grave|grave|||||**SD menor**|◯||
|randomi||||||||(1.03 menor|Muito||
|zados||||||||para 0.52<br>menor)|baixa||  
**Satisfação (seguimento: variação 24 semanas para mais; avaliado com: Escala Visual Analógica; Escala de: 0 para 10)**  
|1|ensaios|muito|não|não|grave<sup>b</sup>|nenhum|12|12|-<br>MD**1.57**|⨁◯◯|IMPORTA|
|---|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|grave<sup>a</sup>|grave|grave|||||**mais**|◯|NTE|
||randomi||||||||(0.76 mais|Muito||
||zados||||||||para 2.38<br>mais)|baixa||  
**IC:** Intervalo de confiança; **DM:** Diferença de médias; **DMP:** Diferença padronizada de médias . **GMFM:** Gross Motor Function Measure **; GAS:** Goal Attainment Scaling  
**a.** Rebaixado dois níveis devido a diversas fontes de vieses; **b.** Penalizado em um nível devido ao tamanho amostral; **c.** Elevada heterogeneidade (> 75%); **d.** Amplo intervalo de confiança que inclui a nulidade de efeito;  
**e.** Penalizado devido ao tamanho amostral. Em um estudo, os membros inferiores foram utilizados como unidade de análise.  
**Tabela F -** TBA comparado a placebo para espasticidade em crianças – curto prazo 2 a 8 semanas  
|||**A**|**valiação da c**|**erteza**|||**№ de p**|**acientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**<br>**Anális**<br>|**Delineamen**<br>**to do estudo**<br>**e observacion**<br>|**Risco**<br>**de viés**<br>**al da mar**<br>|**Inconsistê**<br>**ncia**<br>**cha em curt**<br>|**Evidênci**<br>**a**<br>**indireta**<br>**o prazo (2**<br>|**Imprecisã**<br>**o**<br>**a 8 semanas)**<br><sup>b</sup>|**Outras**<br>**considera**<br>**ções**<br>**- VGA ou P**<br>|**TBA**<br>**RS**<br>|**Placebo**<br>|**Relativo**<br>**(95% CI)**<br>|**Absoluto**<br>**(95% CI)**<br>|**Certeza**<br>|**Importânc**<br>**ia**<br>|
|4|ensaios|grave<sup>a</sup>|não grave|não|grave|nenhum|56/132|33/129|RR 1.66|**169 mais por**|⨁⨁◯◯|CRÍTICO|
||clínicos|||grave|||(42.4|(25.6%)|(1.16 para|**1.000**|Baixa||
|**Anális**|randomizad<br>os<br>**e instrumenta**|**l de marc**|**ha em curto**|**prazo (2 a**|**8 semanas)**|**- Goniometr**|%)<br>**ia - Pico d**|**e dorsiflex**|2.37)<br>**ão do tornoz**|(de 41 mais<br>para 350 mais)<br>**elo em posição**|||  
|1<br>ensaios|não|não grave|não|muito|nenhum|10|9<br>-<br>MD**15.9 mais**|⨁⨁◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|
|clínicos|grave||grave|grave<sup>d,e</sup>|||**alto**|Baixa||
|randomizad|||||||(4.87 mais alto|||
|os||||||||||  
|||**A**|**valiação da c**|**erteza**|||**№ de**|**pacientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**to do estudo**|**Risco**<br>**de viés**|**Inconsistê**<br>**ncia**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**considera**<br>**ções**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|||||||||||para 26.93<br>mais alto)|||  
**Análise instrumental de marcha em curto prazo (2 a 8 semanas) - Goniometria - Pico de dorsiflexão do tornozelo em balanço**  
|1<br>ensaios<br>clínicos<br>randomizad<br>os|não<br>grave|não grave|não<br>grave|muito<br>grave<sup>d,e</sup>|nenhum|10|9<br>-|MD**10.2 mais**<br>**alto**<br>(4.01 mais alto<br>para 16.39<br>mais alto)|⨁⨁◯◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em curto prazo (2 a 8 semanas) - GMFM, COPM ou PGA - Medida Padrão** -->
|2<br>ensaios|não|não grave|não|grave<sup>b</sup>|nenhum|52|56|-|SMD**0.28**|⨁⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomizad<br>os|grave||grave||||||**menor**<br>(0.66 menor<br>para 0.1 mais<br>alto)|Moderada||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em curto prazo (2 a 8 semanas) - GMFM, COPM ou PGA - Medidas Individualizadas** -->
|2<br>ensaios|não|não grave|não|grave<sup>b</sup>|nenhum|102|95|-<br>SMD**0.71**|⨁⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos|grave||grave|||||**mais alto**|Moderada||
|randomizad<br>os||||||||(0.43 mais alto|||  
|||**A**|**valiação da c**|**erteza**|||**№ de**|**pacientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**to do estudo**|**Risco**<br>**de viés**|**Inconsistê**<br>**ncia**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**considera**<br>**ções**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|||||||||||para 1 mais<br>alto)|||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento passivo em curto prazo (2 a 8 semanas) - Goniometria** -->
|3<br>ensaios|grave<sup>a</sup>|não grave|não|não grave|nenhum|151|140|-|MD**2.68 mais**|⨁⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomizad<br>os|||grave||||||**alto**<br>(0.12 mais alto<br>para 5.23 mais<br>alto)|Moderada||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade: flexores plantares do tornozelo em curto prazo (2 a 8 semanas) - MAS** -->
|1<br>ensaios<br>clínicos|não<br>grave|não grave|não<br>grave|grave<sup>f</sup>|nenhum|79|77|-<br>MD**0.49**<br>**menor**|⨁⨁⨁◯<br>Moderada|IMPORT<br>ANTE|
|---|---|---|---|---|---|---|---|---|---|---|
|randomizad<br>os||||||||(0.78 menor<br>para 0.2<br>menor)|||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Satisfação em curto prazo (2 a 8 semanas) - Questionário subjetivo** -->
|2<br>ensaios|grave<sup>g</sup>|não grave|não|muito|nenhum|17/32|14/32|RR 1.20|**87 mais por**|⨁◯◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|---|
|clínicos|||grave|grave<sup>b,c,e</sup>||(53.1|(43.8%)|(0.72 para|**1.000**|◯|ANTE|
|randomizad||||||%)||2.01)|(de 123 menos|Muito||
|os|||||||||para 442 mais)|baixa||  
|||**A**|**valiação da c**|**erteza**|||**№ de p**|**acientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**<br>**Satisf**|**Delineamen**<br>**to do estudo**<br>**ação em curto**|**Risco**<br>**de viés**<br>**prazo (2**|**Inconsistê**<br>**ncia**<br>**a 8 semanas)**|**Evidênci**<br>**a**<br>**indireta**<br>**- COPM**|**Imprecisã**<br>**o**|**Outras**<br>**considera**<br>**ções**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|1|ensaios<br>clínicos<br>randomizad<br>os|não<br>grave|não grave|não<br>grave|grave<sup>d</sup>|nenhum|23|18|-|MD**1.81 mais**<br>**alto**<br>(0.25 mais alto<br>para 3.37 mais<br>alto)|⨁⨁⨁◯<br>Moderada|IMPORT<br>ANTE|  
**CI:** Confidence interval; **MD:** Mean difference; **RR:** Risk ratio; **SMD:** Standardised mean difference. a. Alguns estudos apresentaram algumas preocupações devido a informações insuficientes sobre o processo de randomização, desvios da intervenção pretendida e na seleção do resultado a ser relatado; b. Tamanho da amostra relativamente pequeno; c. Poucos eventos; d. Desfecho relatado por um único estudo com amostra pequena; e. Possui amplo intervalo de confiança; f. Desfecho relatado por um único estudo; g. Alguns estudos apresentaram algumas preocupações devido a informações insuficientes sobre a seleção do resultado a ser relatado  
**Tabela G -** TBA comparado a placebo para espasticidade em crianças – médio prazo 12 a 16 semanas  
|||**A**|**valiação da**|**certeza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**to do estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidência**<br>**indireta**|**Imprecis**<br>**ão**|**Outras**<br>**consideraçõ**<br>**es**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise observacional da marcha em médio prazo (12 a 16 semanas) - VGA ou PRS** -->
|3<br>ensaios|grave<sup>a</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|58/125|29/123|RR 1.90|**212 mais por**|⨁⨁◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|clínicos||||||(46.4|(23.6%)|(1.32 para|**1.000**|Baixa||
|randomizad<br>os||||||%)||2.74)|(de 75 mais<br>para 410 mais)|||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em médio prazo (12 a 16 semanas) - GMFM, COPM ou PGA - Medida Padrão** -->
|2<br>ensaios<br>clínicos<br>randomizad<br>os|não<br>grave|não grave|não grave|grave<sup>b,e,f</sup>|nenhum|52|57|-|SMD**0.05**<br>**mais alto**<br>(0.32 menor<br>para 0.43 mais<br>alto)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em médio prazo (12 a 16 semanas) - GMFM, COPM ou PGA - Medidas Individualizadas** -->
|3<br>ensaios<br>clínicos<br>randomizad<br>os|não<br>grave|não grave|não grave|grave<sup>b,e,f</sup>|nenhum|114|104|-|SMD**0.39**<br>**mais alto**<br>(0.12 mais alto<br>para 0.66 mais<br>alto)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
**Função (melhoria da GMFM) em médio prazo (12 a 16 semanas) - GMFM**  
|||**A**|**valiação da**|**certeza**|||**№ de p**|**acientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**to do estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidência**<br>**indireta**|**Imprecis**<br>**ão**|**Outras**<br>**consideraçõ**<br>**es**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|1|ensaios<br>clínicos<br>randomizad|não<br>grave|não grave|não grave|muito<br>grave<sup>d</sup>|nenhum|7/19<br>(36.8<br>%)|1/15<br>(6.7%)|RR 5.53<br>(0.76 para<br>40.14)|**302 mais por**<br>**1.000**<br>(de 16 menos|⨁⨁◯◯<br>Baixa|CRÍTICO|
||os|||||||||para 1.000<br>mais)|||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento passivo em médio prazo (12 a 16 semanas) - Goniometria** -->
|2<br>ensaios<br>clínicos<br>randomizad<br>os|grave<sup>a</sup>|não grave|não grave|grave<sup>e</sup>|nenhum|77|73|-|MD**1.57 mais**<br>**alto**<br>(2.12 menor<br>para 5.25 mais<br>alto)|⨁⨁◯◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade: flexores plantares do tornozelo em médio prazo (12 a 16 semanas) - MAS** -->
|1<br>ensaios|não|não grave|não grave|grave<sup>g</sup>|nenhum|74|70|-<br>MD**0.5**|⨁⨁⨁◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos|grave|||||||**menor**|Moderada|ANTE|
|randomizad<br>os||||||||(0.78 menor<br>para 0.22<br>menor)|||  
**Satisfação em médio prazo (12 a 16 semanas) - Questionário subjetivo**  
|||**A**|**valiação da**|**certeza**|||**№ de p**|**acientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**to do estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidência**<br>**indireta**|**Imprecis**<br>**ão**|**Outras**<br>**consideraçõ**<br>**es**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|2|ensaios|grave<sup>h</sup>|não grave|não grave|muito|nenhum|29/53|25/58|RR 1.32|**138 mais por**|⨁◯◯|IMPORT|
||clínicos||||grave<sup>b,c,e</sup>||(54.7|(43.1%)|(0.94 para|**1.000**|◯|ANTE|
||randomizad||||||%)||1.83)|(de 26 menos|Muito||
||os|||||||||para 358 mais)|baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Satisfação em médio prazo (12 a 16 semanas) - COPM** -->
|2<br>ensaios|grave<sup>h</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|40|34|-|MD**0.96 mais**|⨁⨁◯◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomizad<br>os|||||||||**alto**<br>(0.04 mais alto<br>para 1.88 mais<br>alto)|Baixa|ANTE|  
**IC:** Intervalo de confiança; **MD:** Diferença de médias; **RR:** Risco Relativo; **DMP:** Diferença padronizada de médias **; VGA:** Video gait analysis; **PRS:** Physician Rating Scale; **GMFM:** Gross Motor Function Measure;  
**COPM:** Canadian Occupational Performance Measure; **PGA:** Physician's Global Assessment; **MAS:** Modified Ashworth Scale.  
a. Alguns estudos apresentaram algumas preocupações devido a informações insuficientes sobre o processo de randomização, desvios da intervenção pretendida e na seleção do resultado a ser relatado.; b. Tamanho da amostra relativamente pequeno.; c. Poucos eventos; d. Desfecho relatado por um único estudo com amostra pequena.; e. Possui amplo intervalo de confiança; f. Diferentes tipos de escalas foram usados (medidas de função individualizada e escalas motoras padrão).; g. Desfecho relatado por um único estudo.; h. Alguns estudos apresentaram algumas preocupações devido a informações insuficientes a seleção do resultado a ser relatado.  
**Tabela H -** TBA comparado a placebo para espasticidade em crianças – longo prazo >24 semanas  
||||**Avaliação d**|**a certeza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineame**<br>**nto do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidênc**<br>**ia**<br>**indireta**|**Impreci**<br>**são**|**Outras**<br>**considerações**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em longo prazo (>24 semanas) - GMFM, COPM ou PGA - Medida Padrão** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|30|28|-<br>SMD**0.22**|⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomiz<br>ados|grave||grave|grave<sup>a,c</sup>||||**menor**<br>(0.73 menor<br>para 0.3 mais<br>alto)|◯<br>Baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Função em longo prazo (>24 semanas) - GMFM, COPM ou PGA - Medidas Individualizadas** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|17|16|-<br>SMD**0.2**|⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomiz<br>ados|grave||grave|grave<sup>a,c</sup>||||**mais alto**<br>(0.49 menor<br>para 0.88<br>mais alto)|◯<br>Baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento passivo em longo prazo ( >24 semanas) - Goniometria - Dorsiflexão do tornozelo** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|21|19|-<br>MD**0.2 mais**|⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomiz<br>ados|grave||grave|grave<sup>b,c</sup>||||**alto**<br>(4.88 menor<br>para 5.28<br>mais alto)|◯<br>Baixa||  
||||**Avaliação d**|**a certeza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineame**<br>**nto do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidênc**<br>**ia**<br>**indireta**|**Impreci**<br>**são**|**Outras**<br>**considerações**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento passivo em longo prazo ( >24 semanas) - Goniometria - Extensão do joelho** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|11|8|-<br>MD**5.6**|⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomiz<br>ados|grave||grave|grave<sup>b,c</sup>||||**menor**<br>(13.49 menor<br>para 2.29<br>mais alto)|◯<br>Baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Amplitude do movimento passivo em longo prazo ( >24 semanas) - Goniometria - Abdução de quadril** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|3|8|-<br>MD**9.6 mais**|⨁⨁◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomiz<br>ados|grave||grave|grave<sup>b,c</sup>||||**alto**<br>(9.97 menor<br>para 29.17<br>mais alto)|◯<br>Baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade em longo prazo ( >24 semanas) - MAS - Flexores plantares de tornozelo** -->
|1<br>ensaios|não|não grave|não|muito|nenhum|21|21|-<br>MD**0.1 mais**|⨁⨁◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos|grave||grave|grave<sup>b,c</sup>||||**alto**|◯|ANTE|
|randomiz||||||||(0.58 menor|Baixa||
|ados||||||||para 0.78<br>mais alto)|||  
**Espasticidade em longo prazo ( >24 semanas) - MAS - Isquiotibiais**  
||||**Avaliação da**|**certeza**|||**№ de p**|**acientes**|**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineame**<br>**nto do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsist**<br>**ência**|**Evidênc**<br>**ia**<br>**indireta**|**Impreci**<br>**são**|**Outras**<br>**considerações**|**TBA**|**Placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importânc**<br>**ia**|
|1|ensaios|não|não grave|não|muito|nenhum|7|3|-|MD**1 menor**|⨁⨁◯|IMPORT|
||clínicos|grave||grave|grave<sup>b,c</sup>|||||(2.06 menor|◯|ANTE|
||randomiz|||||||||para 0.06|Baixa||
||ados|||||||||mais alto)|||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Espasticidade em longo prazo ( >24 semanas) - MAS - Abdução de quadril** -->
|1<br>ensaios<br>clínicos<br>randomiz<br>ados<br>**tisfação em long**|não<br>grave<br>**o prazo (**|não grave<br>**> 24 semanas)**|não<br>grave<br>**- COPM**|muito<br>grave<sup>b,c</sup><br>|nenhum|5|8|-|MD**0.1 mais**<br>**alto**<br>(0.79 menor<br>para 0.99<br>mais alto)|⨁⨁◯<br>◯<br>Baixa|IMPORT<br>ANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1<br>ensaios<br>clínicos|não<br>grave|não grave|não<br>grave|muito<br>grave<sup>b,c</sup>|nenhum|17|16|-|MD**0.1 mais**<br>**alto**|⨁⨁◯<br>◯|IMPORT<br>ANTE|
|randomiz<br>ados|||||||||(1.27 menor<br>para 1.47<br>mais alto)|Baixa||

---

<!-- METADADOS: doenca: Espasticidade | secao: **Satisfação em longo prazo (> 24 semanas) - COPM** -->
**IC:** Intervalo de confiança; **MD:** Diferença de médias; **RR:** Risco Relativo; **DMP:** Diferença padronizada de médias **; GMFM:** _Gross Motor Function Measure_ ; **COPM:** _Canadian Occupational Performance_  
_Measure_ ; **PGA:** _Physician's Global Assessment_ ; **MAS:** _Modified Ashworth Scale_ .  
a. Tamanho da amostra relativamente pequeno.; b. Desfecho relatado por um único estudo com amostra pequena.; c. Possui amplo intervalo de confiança.  
**Tabela I -** TBA comparado a placebo para espasticidade em crianças – eventos adversos  
<!-- Start of picture text -->
Avaliação da certeza  № de pacientes  Efeito<br>№  Importânc<br>Delineam Evidênc Certeza<br>dos  Risco de  Inconsist Impreci Outras  Relativo  Absoluto  ia<br>ento do  ia  TBA  Placebo<br>estud viés  ência  são  considerações  (95% CI)  (95% CI)<br>estudo  indireta<br>os<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espasticidade | secao: **Eventos adversos** -->
|11|ensaios|grave<sup>a</sup>|grave<sup>c</sup>|não|grave<sup>b</sup>|nenhum|176/531|102/371|RR 1.29|**80 mais**|⨁◯◯|IMPORT|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||clínicos|||grave|||(33.1%)|(27.5%)|(0.87|**por 1.000**|◯|ANTE|
||randomiz||||||||para|(de 36|Muito||
||ados||||||||1.93)|menos para<br>256 mais)|baixa||  
**IC:** Intervalo de confiança; **MD:** Diferença de médias; **RR:** Risco Relativo; **DMP:** Diferença padronizada de médias **.**  
a. Alguns estudos apresentaram algumas preocupações devido a informações insuficientes sobre o processo de randomização, desvios da intervenção pretendida e na seleção do resultado a ser relatado.; b. Possui amplo intervalo de confiança; c. I2 alto e IC que não se sobrepõem.

---

<!-- METADADOS: doenca: Espasticidade | secao: **QUESTÃO 3: O BACLOFENO VIA ORAL É EFICAZ E SEGURA PARA O TRATAMENTO DA ESPASTICIDADE EM ADULTOS E CRIANÇAS?** -->
Optou-se por realizar uma nova revisão sistemática. A estrutura PICO para esta pergunta foi:  
**População:** pacientes com espasticidade (independentemente da causa da espasticidade e da idade dos pacientes). **Intervenção:** baclofeno oral.  
**Comparador:** placebo ou outras alternativas terapêuticas disponíveis no SUS.  
**Desfechos:** avaliação da espasticidade por escala de Ashworth; dor associada à espasticidade; capacidade funcional durante as atividades da vida diária; qualidade de vida; e segurança.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Métodos e resultados da busca:** -->
Foi realizada busca sistematizada da literatura nas bases de dados MEDLINE (via PubMed), Cochrane Library, EMBASE, PEDRO e LILACS (via BVS). Conduzimos ainda buscas no website _Opengrey_ (https://opengrey.eu) e na plataforma de preprints Medrxiv (https://www.medrxiv.org/), além de realizar busca manual nas listas de referências dos estudos relevantes. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas foram conduzidas em 26/06/2021. As estratégias de busca para cada base estão descritas no **Quadro N** .  
**Quadro N -** Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o uso de baclofeno no tratamento de espasticidade  
|**Bases de dados**|**Estratégias de busca**|
|---|---|
|MEDLINE (via<br>Pubmed)|(((((((("Muscle Hypertonia"[Mesh]) OR "Muscle Spasticity"[Mesh]OR (Spasticity, Muscle) OR<br>(Spastic Clasp-Knife Spasticity) OR (Clasp Knife Spasticity) OR (Spasticity, Clasp-Knife) OR<br>(spastic$ or high tone))) OR (("Multiple Sclerosis"[Mesh] OR • (Sclerosis, Multiple) OR (Sclerosis,<br>Disseminated) OR (Disseminated Sclerosis) OR (MS (Multiple Sclerosis)) OR (Multiple Sclerosis,<br>Acute Fulminating)))) OR (("Cerebral Palsy"[Mesh] OR (CP (Cerebral Palsy)) OR (Cerebral Palsy,<br>Dystonic-Rigid) OR (Cerebral Palsies, Dystonic-Rigid) OR (Cerebral Palsy, Dystonic Rigid) OR<br>(Dystonic-Rigid Cerebral Palsies) OR (Dystonic-Rigid Cerebral Palsy) OR (Cerebral Palsy, Mixed)<br>OR (Mixed Cerebral Palsies) OR (Mixed Cerebral Palsy) OR (Cerebral Palsy, Monoplegic, Infantile)<br>OR (Monoplegic Infantile Cerebral Palsy) OR (Infantile Cerebral Palsy, Monoplegic) OR (Cerebral<br>Palsy, Quadriplegic, Infantile) OR (Quadriplegic Infantile Cerebral Palsy) OR (Infantile Cerebral<br>Palsy, Quadriplegic) OR (Cerebral Palsy, Rolandic Type) OR (Rolandic Type Cerebral Palsy) OR<br>(Cerebral Palsy, Congenital) OR (Congenital Cerebral Palsy) OR (Little Disease) OR (Little's<br>Disease) OR (Spastic Diplegia) OR (Diplegias, Spastic) OR (Spastic Diplegias) OR (Diplegia,<br>Spastic) OR (Monoplegic Cerebral Palsy) OR (Cerebral Palsies, Monoplegic) OR (Cerebral Palsy,<br>Monoplegic) OR (Monoplegic Cerebral Palsies) OR (Cerebral Palsy, Athetoid) OR (Athetoid<br>Cerebral Palsy) OR (Cerebral Palsies, Athetoid) OR (Cerebral Palsy, Dyskinetic) OR (Cerebral<br>Palsies, Dyskinetic) OR (Dyskinetic Cerebral Palsy) OR (Cerebral Palsy, Atonic) OR (Atonic<br>Cerebral Palsy) OR (Cerebral Palsy, Hypotonic) OR (Hypotonic Cerebral Palsies) OR (Hypotonic<br>Cerebral Palsy) OR (Cerebral Palsy, Diplegic, Infantile) OR (Diplegic Infantile Cerebral Palsy) OR<br>(Infantile Cerebral Palsy, Diplegic) OR (Cerebral Palsy, Spastic) OR (Spastic Cerebral Palsies) OR|  
|**Bases de dados**|**Estratégias de busca**|
|---|---|
||(Spastic Cerebral Palsy)))) OR (("Stroke"[Mesh] OR (Strokes) OR (Cerebrovascular Accident) OR<br>(Cerebrovascular Accidents) OR (CVA (Cerebrovascular Accident)) OR (CVAs (Cerebrovascular<br>Accident)) OR (Cerebrovascular Apoplexy) OR (Apoplexy, Cerebrovascular) OR (Vascular<br>Accident, Brain) OR (Brain Vascular Accident) OR (Brain Vascular Accidents) OR (Vascular<br>Accidents, Brain) OR (Cerebrovascular Stroke) OR (Cerebrovascular Strokes) OR (Stroke,<br>Cerebrovascular) OR (Strokes, Cerebrovascular) OR (Apoplexy) OR (Cerebral Stroke) OR (Cerebral<br>Strokes) OR (Stroke, Cerebral) OR (Strokes, Cerebral) OR (Stroke, Acute) OR (Acute Stroke) OR<br>(Acute Strokes) OR (Strokes, Acute) OR (Cerebrovascular Accident, Acute) OR (Acute<br>Cerebrovascular Accident) OR (Acute Cerebrovascular Accidents) OR (Cerebrovascular Accidents,<br>Acute))))) OR ((("Spinal Cord Injuries"[Mesh] OR (Spinal Cord Trauma) OR (Cord Trauma, Spinal)<br>OR (Cord Traumas, Spinal) OR (Spinal Cord Traumas) OR (Trauma, Spinal Cord) OR (Traumas,<br>Spinal Cord) OR (Myelopathy, Traumatic) OR (Myelopathies, Traumatic) OR (Traumatic<br>Myelopathies) OR (Traumatic Myelopathy) OR (Injuries, Spinal Cord) OR (Cord Injuries, Spinal)<br>OR (Cord Injury, Spinal) OR (Injury, Spinal Cord) OR (Spinal Cord Injury) OR (Spinal Cord<br>Transection) OR (Cord Transection, Spinal) OR (Cord Transections, Spinal) OR (Spinal Cord<br>Transections) OR (Transection, Spinal Cord) OR (Transections, Spinal Cord) OR (Spinal Cord<br>Laceration) OR (Cord Laceration, Spinal) OR (Cord Lacerations, Spinal) OR (Laceration, Spinal<br>Cord) OR (Lacerations, Spinal Cord) OR (Spinal Cord Lacerations) OR (Post-Traumatic<br>Myelopathy) OR (Myelopathies, Post-Traumatic) OR (Myelopathy, Post-Traumatic) OR (Post<br>Traumatic Myelopathy) OR (Post-Traumatic Myelopathies) OR (Spinal Cord Contusion) OR<br>(Contusion, Spinal Cord) OR (Contusions, Spinal Cord) OR (Cord Contusion, Spinal) OR (Cord<br>Contusions, Spinal) OR (Spinal Cord Contusions))))) OR (("Brain Injuries, Traumatic"[Mesh] OR<br>(Brain Injury, Traumatic) OR (Traumatic Brain Injuries) OR (Trauma, Brain) OR (Brain Trauma)<br>OR (Brain Traumas) OR (Traumas, Brain) OR (TBI (Traumatic Brain Injury)) OR (Encephalopathy,<br>Traumatic) OR (Encephalopathies, Traumatic) OR (Traumatic Encephalopathies) OR (Injury, Brain,<br>Traumatic) OR (Traumatic Encephalopathy) OR (TBIs (Traumatic Brain Injuries)) OR (TBI<br>(Traumatic Brain Injuries)) OR (Traumatic Brain Injury) OR (Apoplexy))))) AND (Baclofen"[Mesh]<br>OR Baclophen OR lioresal)|
|EMBASE|'spasticity'/exp OR 'muscle hypertonia'/exp OR 'muscle rigidity'/exp OR 'clasp knife' OR 'muscle<br>spasticity' OR 'multiple sclerosis'/exp OR 'cerebral palsy'/exp OR 'cerebrovascular accident'/mj<br>OR 'spinal cord disease'/mj OR 'traumatic brain injury'/exp AND 'baclofen'/exp OR lioresal AND<br>[embase]/lim NOT ([embase]/lim AND [medline]/lim)|
|Cochrane Library|#1 MeSH descriptor: [Baclofen] explode all trees|
|PEDRO|baclofen|
|LILACS (via BVS)<br>Medrxiv|baclofen<br>baclofen|  
|**Bases de dados**|**Estratégias de busca**|
|---|---|
|OpenGrey|baclofen|  
A elegibilidade dos estudos foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI®<sup>3</sup> . Na segunda etapa, realizou-se a leitura de texto completo, também por dois revisores independentes, mantendo-se ECR que avaliassem o medicamento para a indicação analisada. As divergências, quando necessário, foram discutidas até chegar a um consenso ou discutidas com um terceiro pesquisador.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: pacientes (adultos e crianças) com espasticidade, independentemente da doença de base.  
- (b) Tipo de intervenção: baclofeno oral, em monoterapia, administrada em qualquer dose.  
- (c) Tipos de estudos: ensaios clínicos randomizados comparando baclofeno oral a placebo ou outras alternativas  
- terapêuticas disponíveis no SUS.  
- (d) Desfechos: avaliação da espasticidade por escala de Ashworth; dor associada à espasticidade; capacidade funcional  
- durante as atividades da vida diária; qualidade de vida; e segurança.  
- (e) Idioma: apenas textos publicados em inglês, português ou espanhol.  
(f) Critérios de exclusão: foram excluídos estudos que não avaliassem espasticidade e com quaisquer outros delineamentos que não ECR; estudos com comparadores que não estivessem incorporados ao SUS ou intervenções não medicamentosas; estudos que não avaliassem os desfechos de interesse elencados na pergunta de pesquisa; estudos publicados em outros idiomas que não português, espanhol e inglês.  
Para todos os ECR incluídos, foi realizada avaliação do risco de viés utilizando instrumento validado, sendo empregada a ferramenta de avaliação de Risco de Viés da Cochrane (RoB 2.0), tanto a versão para ECR paralelos, quanto para ECR cruzados.<sup>1,91</sup> Para a avaliação do grau de certeza das evidências foi utilizada o método _Th_ e _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE).<sup>1,92</sup>  
Optou-se por priorizar a avaliação da espasticidade pela escala de Ashworth (e sua versão modificada) por ser um instrumento validado e amplamente aceito para avaliação dessa condição<sup>93–95</sup> . Essa foi uma alternativa adotada frente à variação das aferições entre os estudos encontrados na busca. Os resultados são apresentados de acordo com a população (adultos e crianças) e considerando o comparador (placebo ou diazepam – única alternativa terapêutica disponível no SUS comparada nos estudos incluídos); e não foram agrupados em meta-análises devido à heterogeneidade das análises e da apresentação desses resultados nos estudos primários.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>Resultados da busca</u>** -->
Foram identificadas 4.359 publicações inicialmente e 6 publicações na busca manual. Após a exclusão das duplicatas (n = 368) e triagem pela leitura de títulos e resumos, apenas 44 publicações foram triadas pela leitura do texto completo, sendo que para 7 delas não foram encontrados os textos completos - como pode ser observado na **Figura AN** . A lista de estudos excluídos na fase de elegibilidade por leitura de texto completo e a razão para exclusão é apresentada no **Quadro O** . Ao final, foram incluídos 14 ECR: nove deles avaliando adultos<sup>96–104</sup> e cinco incluindo crianças.<sup>105–109</sup>  
**Figura AN -** Fluxograma de seleção dos estudos incluídos sobre baclofeno via oral para o tratamento da espasticidade  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
<!-- Start of picture text -->
RotorénciasBasesPubMedde dadosientiicadas(n = 1:970) (n = 4.359) om Referénciasprocesso removidas antes do<br>CochraneLILACSParoEmbaso nmYn(nLibrary18),== 2060)18)  (n= 261) ‘automaticasDuplicatasRomovidasRlemovidasde selecao: por(npor(n= torramentas,=368)outras0) razbes RoferénciasBuscarevis6esde citagdesidentiticadassistomaticasem (n= em 6)<br>Moar‘Openrey 18)(n=20) Gen<br>FRoforéncias avaladas por titulo Rolorénclas exclvidas<br>(= 3991) (o= 9.959)<br>Referencias incluidas para Reteréncias cujo texto completo Referéncias incluidas para<br>fvaliaglo(= 38)  por texto completo roer) fol endicnde {valago=8)  por texto completo Roterénciaevo exo completo<br>FRoferénciascompleto(n= 31) avaliadas por texto ReterénciasDelineamentoNao analsoueporiouexcluidasde estudo(n =destecho 20) (n = 15) ‘completoRoferéncias(n= 6) avaliadas por texto RoforonciasidiomaResGinter e naisousse (n=exciuidas(n 1)= desiecho2) (9 = de3):<br>de intoresse (n= 3)<br>‘Assunto (n = 2)<br>Estudos incluidos na revisto<br>@= 14)<br>Folatos dos estudos incluidos<br>(eta)<br><!-- End of picture text -->  
*Castro ML, Traldi S. The use of baclofen in cerebral spasticity. Folha Med 1977; 74: 561–564; Levine IM, Jossmann PB, DeAngelis V. Lioresal, a new muscle relaxant in the treatment of spasticity - a double-blind quantitative evaluation. Dis Nerv Syst 1977; 38: 1011–1015; Medaer R, Hellebuyk H, Van Den Brande E, et al. Treatment of spasticity due to stroke. A double-blind, cross-over trial comparing baclofen with placebo. Acta Ther 1991; 17: 323–331; Roussan, M., Terrence, C., & Fromm, G. (1985). Baclofen versus diazepam for the treatment of spasticity and long-term follow-up of baclofen therapy. Pharmatherapeutica, 4(5), 278–284.; Hudson, P., Weightman, D., & Cartlidge, N. E. (1972). Clinical trial of baclofen against placebo. Postgraduate Medical Journal, 48, Suppl 5:3740; Calia RG, Santomauro E, Traldi S. The use of baclofen in children with cerebral palsy. Folha Med 1976; 73: 199–202. Schwartzman, J. S., Tilbery, C. P., Kogler, E., & Gusman, S. (1976). Effects of lioresal in cerebral palsy. Folha Medica, 72(3), 297–302.  
**Quadro O -** Lista de referências excluídas na fase de elegibilidade por leitura de texto completo dos estudos clínicos – síntese sobre baclofeno  
Delineamento de estudo Aisen ML, Dietz MA, Rossi P, et al. Clinical and pharmacokinetic aspects of high dose oral baclofen therapy. J Am Paraplegia Soc 1992; 15: 211–216. Cendrowski, W., & Sobczyk, W. (1977). Clonazepam, baclofen and placebo in the treatment of spasticity. European Neurology, 16(1), 257–262. Dai AI. Decreased side-effects of oral baclofen with add-on treatment of botulinum toxin type A in cerebral palsy: A study from Turkey. Neurol Psychiatry Brain Res 2006; 13: 155–158. Hassan N, McLellan DL. Double-blind comparison of single doses of DS103-282, baclofen and placebo for suppression of spasticity. J Neurol Neurosurg Psychiatry 1980; 43: 1132–1136. Hedley, D. W., Maroun, J. A., & Espir, M. L. (1975). Evaluation of baclofen (Lioresal) for spasticity in multiple sclerosis. Postgraduate Medical Journal, 51(599), 615–618. Jerusalem F. Double-blind study on the antispastic effect of beta-94-chlorophenyl-gammaaminobutyric acid (CIBA) in multiple sclerosis. Nervenarzt 1968;39:515–17 (in German). Kemp E, Dass S, Issa M. Oral baclofen in children with cerebral Palsy, is it really effective? A 10 year retrospective study. Dev Med Child Neurol 2021; 63: 40.  
Mizuno S, Takeda K, Maeshima S, et al. Effect of oral baclofen on spasticity poststroke: responders versus non-responders. Top Stroke Rehabil 2018; 25: 438–444. Nielsen, J. F., & Sinkjaer, T. (2000). Peripheral and central effect of baclofen on ankle joint stiffness in multiple sclerosis. Muscle & Nerve, 23(1), 98–105. Norris, F. H. J., U, K. S., Sachais, B., & Carey, M. (1979). Trial of baclofen in amyotrophic lateral sclerosis. Archives of Neurology, 36(11), 715–716. Peck J, Urits I, Crane J, et al. Oral Muscle Relaxants for the Treatment of Chronic Pain Associated with Cerebral Palsy. Psychopharmacol Bull 2020; 50: 142–162. Pedersen, E., & Arlien-Soborg, P. (1972). Studies on the effect and mechanism of a Gaba derivative (Lioresal R) in spasticity. Acta Neurologica Scandinavica. Supplementum, 51, 485–486  
van Doornik J, Kukke S, McGill K, et al. Oral baclofen increases maximal voluntary neuromuscular activation of ankle plantar flexors in children with spasticity due to cerebral palsy. J Child Neurol 2008; 23: 635–639. Young JA. Clinical experience in the use of baclofen in children with spastic cerebral palsy: A further report. Scott Med J 1980; 25: S 23-S 25.  
Wininger M, Craelius W, Settle J, et al. Biomechanical analysis of spasticity treatment in patients with multiple sclerosis. Ther Adv Neurol Disord 2015; 8: 203–211.  
Não analisou ou relatou os resultados para desfechos de interesse  
Basmajian JV, Yucel V. EDects of GABA-derivative (BA-34647) on spasticity. Preliminary report of a double-blind crossover study & rehabilitation. American Journal of Physical Medicine 1974;53(5):223-8.  
Basmajian, J. V. (1975). Lioresal (baclofen) treatment of spasticity in multiple sclerosis. American Journal of Physical Medicine, 54(4), 175–177. Dapas F, Hartman SF, Martinez L, et al. Baclofen for the treatment of acute low-back syndrome. A double-blind comparison with placebo. Spine 1985;10(4):345–349.  
Hulme A, MacLennan WJ, Ritchie RT, et al. Baclofen in the elderly stroke patient its side-effects and pharmacokinetics. Eur J Clin Pharmacol 1985; 29: 467–469.  
Smith, M. B., Brar, S. P., Nelson, L. M., Franklin, G. M., & Cobble, N. D. (1992). Baclofen effect on quadriceps strength in multiple sclerosis. Archives of Physical Medicine and Rehabilitation, 73(3), 237–240.  
Assunto  
Anand JS, Zając M, Waldman W, et al. Correlation between the single, high dose of ingested baclofen and clinical symptoms. Ann Agric Environ Med 2017; 24: 566–569. Corston, R. N., Johnson, F., & Godwin-Austen, R. B. (1981). The assessment of drug treatment of spastic gait. Journal of Neurology, Neurosurgery, and Psychiatry, 44(11), 1035–1039.  
Idioma  
Liu W, Li L, Wang BS. Botulinum toxin A and lioresal for managing spasticity: Clinical comparative study. Chinese J Clin Rehabil 2002; 6: 1103–1104.  
O diazepam foi o único medicamento disponível no SUS (listado no Componente Básico da Assistência Farmacêutica) identificado em estudos comparativos com baclofeno oral. Apesar da toxina botulínica do tipo A ser o único medicamento preconizado pelo Protocolo Clínico e Diretrizes Terapêutica de Espasticidade vigente (2017)<sup>110</sup> e a tecnologia para a qual há mais evidências, foi identificado apenas um ECR comparando-a ao baclofeno oral e esse não foi incluído por ter sido publicado em chinês.  
Todos os estudos são cruzados, exceto Sachais (1977)<sup>101</sup> (para pacientes adultos) e Goyal (2016)<sup>109</sup> (para pacientes pediátricos). Dos ECR para população adulta, foram incluídos, de modo geral, participantes com espasticidade secundária à esclerose múltipla - mesmo aqueles que não incluíram somente esse tipo de pacientes, a maioria deles tinham essa condição<sup>99,104</sup> . O tempo de seguimento variou de 10 dias até 10 semanas, com diferentes tempos de _washout_ - quando informados. Por outro lado, em relação aos ECR para população pediátrica, todos consideraram pacientes com paralisia cerebral; e o tempo de seguimento variou entre oito semanas e três meses. As características dos estudos incluídos são apresentadas com mais detalhes no **Quadro P** .  
Para todos os ECR incluídos, foi realizada avaliação do risco de viés utilizando instrumento validado da Colaboração Cochrane (RoB 2.0)<sup>91</sup> . Para todos os desfechos de interesse analisados nos estudos incluídos, foi caracterizado alto risco de viés. Os principais vieses identificados nos ECR foram relacionados à randomização, ao sigilo de alocação e ao cegamento – processos que não foram descritos ou o foram de maneira superficial. Ainda, nenhum dos estudos tinha um protocolo publicado ou disponibilizado. Alguns apresentaram dados incompletos ou relataram perda deles ou do seguimento dos pacientes, sendo este último ponto importante porque a maioria dos ECR tinha pequeno número de participantes. A maioria dos estudos cruzados apresentou problema no relato do processo de _crossover,_ mais especificamente sobre o equilíbrio das características basais dos grupos antes e após do período de _washout_ – avaliado pelo Domínio S do RoB 2.0. O Material Suplementar 1 contém as avaliações do risco de viés para os ECR comparando baclofeno oral com placebo e com diazepam tanto para adultos quanto para crianças.  
**Quadro P -** Características dos estudos clínicos randomizados e controlados que avaliaram baclofeno oral para o tratamento da espasticidade  
|**Autor**<br>**(ano)**<br>**Baclofeno**|**Design e pacientes**<br>**vs placebo**|**Objetivo**<br>**ECR com partici**|**Dose do**<br>**baclofeno oral**<br>**pantes adultos**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
|Brar<br>(1991)<sup>96</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=38) com esclerose<br>múltipla|Examinar os<br>efeitos de<br>baclofeno oral em<br>pacientes com<br>espasticidade<br>mínima a<br>moderada na<br>esclerose múltipla|15 mg/dia, até o<br>máximo de 20<br>mg/dia|10 semanas|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária|
|Duncan<br>(1976)<sup>97</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos|Avaliar o efeito do<br>baclofeno em<br>vários|Dose inicial: 5<br>mg, 3x/dia.<br>Incrementos em|4 semanas com<br>uma das<br>intervenções, 1|- Dor<br>associada à<br>espasticidad|
||(n=22) com esclerose|componentes em|até 3 dias até|semana de|e|  
|**Autor**<br>**(ano)**|**Design e pacientes**|**Objetivo**|**Dose do**<br>**baclofeno oral**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
||múltipla e lesões na<br>medula espinhal|pacientes com<br>lesões na medula<br>espinhal|melhora máxima<br>ou uma dose<br>máxima de 100<br>mg/dia.|_washout_e 4<br>semanas com a<br>outra intervenção|- Segurança|
|Feldman<br>(1978)<sup>98</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=33) com esclerose<br>múltipla|Estudar efeitos e<br>segurança do<br>baclofeno em<br>pacientes com<br>esclerose múltipla,<br>que tiveram sinais<br>e sintomas na<br>medula espinhal,<br>particularmente<br>espasticidade.|Dose inicial: 5<br>mg, 3x/dia por 3<br>dias.<br>Incremento: em<br>intervalos de pelo<br>menos 3 dias até o<br>máximo de 80 mg.|10 semanas de<br>estudo duplo cego<br>e 3 anos de estudo<br>aberto|- Dor<br>associada à<br>espasticidad<br>e<br>- Segurança|
|Hudgson<br>(1971)<sup>99</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=23) com esclerose<br>múltipla, mielopatia,<br>doença do neurônio<br>motor, paraplegia<br>espástica familiar,<br>paraparesia espástica<br>progressiva.|Avaliar a eficácia<br>de baclofeno oral<br>no tratamento de<br>espasticidade|10 mg, 3x/dia|10 dias|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária<br>S|
||||||- egurança|
|Orsnes<br>(2000)<sup>100</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=14) com esclerose<br>múltipla.|Medir a marcha e<br>estabilidade<br>postural por<br>métodos objetivos<br>em pacientes com<br>esclerose múltipla<br>espástica e avaliar<br>o efeito do<br>baclofeno na|Dose inicial: 5<br>mg, 3x/dia.<br>Incremento de 15<br>mg, 3x/dia até<br>tolerância.|11 dias|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>- Segurança|  
|**Autor**<br>**(ano)**|**Design e pacientes**|**Objetivo**|**Dose do**<br>**baclofeno oral**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
|||marcha e<br>estabilidade<br>postural.||||
|Sachais<br>(1977)<sup>101</sup>|ECR duplo-cego<br>multicênctrico (16<br>centros), incluindo<br>pacientes adultos<br>(n=166) com esclerose<br>múltipla|Comparar a<br>eficácia do<br>baclofeno e do<br>placebo em<br>pacientes com<br>espasticidade<br>secundária à<br>esclerose múltipla.|– para**pacientes**<br>**ambulatoriais**, 1ª<br>semana: 5 mg<br>3x/dia durante 3<br>dias e 10 mg<br>3x/dia durante 4<br>dias; 2ª semana:<br>15 mg 3x/dia<br>durante 3 dias e 20<br>mg 3x/dia durante<br>4 dias.<br>– para**pacientes**<br>**internados**, 1ª<br>semana: 10 mg<br>3x/dia durante 3<br>dias e 15 mg<br>3x/dia durante 4<br>dias; 2ª semana:<br>20 mg 3x/dia (10<br>ou 20 mg<br>adicionais, como<br>requerido, até 80<br>mg/dia).|5 semanas|- Dor<br>associada à<br>espasticidad<br>e<br>-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária<br>- Segurança|
|Sawa<br>(1979)<sup>102</sup><br>**Baclofeno**|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=21) com esclerose<br>múltipla.<br>**vs diazepam**|Estudar a<br>espasticidade dos<br>membros inferiores<br>em 21 pacientes<br>com esclerose<br>múltipla<br>clinicamente<br>definida ou<br>mielopatia crônica<br>(esclerose múltipla<br>presumida).|Dose inicial: 5<br>mg, 3x/dia.<br>Incremento: até o<br>máximo de 60 mg.|21 dias de uma<br>das intervenções,<br>sete dias de<br>_washout_e 21 dias<br>da outra<br>intervenção.|- Dor<br>associada à<br>espasticidad<br>e<br>- Segurança|  
|**Autor**<br>**(ano)**|**Design e pacientes**|**Objetivo**|**Dose do**<br>**baclofeno oral**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
|From<br>(2009)<sup>103</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes adultos<br>(n=17) com esclerose<br>múltipla.|Fazer avaliação<br>clínica entre<br>baclofeno oral e<br>diazepam para<br>espasticidade<br>associada à<br>esclerose múltipla.|Dose média foi de<br>61,2 mg (30 a 120<br>mg) e de<br>diazepam, de 26,8<br>mg (10 a 40 mg).|4 semanas da 1ª<br>intervenção (duas<br>para ajuste de<br>dose e outras duas<br>para o tratamento)<br>e 4 semanas para a<br>2ª (separadas por<br>um “período<br>conhecido de<br>placebo”).|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>- Segurança|
|Cartlidge<br>(1974)<sup>104</sup><br>**Baclofeno v**|ECR duplo-cego,<br>incluindo pacientes<br>adultos (n=40) com<br>esclerose múltipla em<br>remissão, paraparesia,<br>mielopatia<br>espondilótica,<br>paraplegia espástica<br>hereditária e<br>traumática.<br>**s placebo**|Comparar as ações<br>de baclofeno e de<br>diazepam em<br>relação ao alívio da<br>espasticidade e à<br>indução de efeitos<br>colaterais.<br>**ECR com particip**|Doses: para<br>baclofeno, 30<br>mg/dia por 2<br>semanas (baixa<br>dose) e 60 mg/dia<br>por 2 semanas<br>(alta dose); para<br>diazepam, 15<br>mg/dia por 2<br>semanas (baixa<br>dose) e 30 mg/dia<br>por 2 semanas<br>(alta dose).<br>**antes pediátricos**|1 semana de<br>_washout_e 8<br>semanas<br>recebendo os<br>tratamentos.|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>- Segurança|
|Scheinber<br>g (2006)<sup>108</sup>|ECR piloto, cruzado e<br>duplo-cego, incluindo<br>pacientes pediátrico<br>entre 4 e 15 anos<br>(n=15) com paralisia<br>cerebral.|Avaliar a eficácia<br>do baclofeno oral<br>na redução da<br>espasticidade e na<br>melhora da função<br>em crianças com<br>paralisia cerebral.|**< 8 anos**:<br>Dose inicial: 2,5<br>mg/dia<br>Incremento<br>semanal até a 7ª<br>semana até uma<br>dose total de 10<br>mg/3x dia<br>**≥ 8 anos**<br>Dose inicial: 5<br>mg/dia|13 semanas com<br>uma das<br>intervenções, 2<br>semanas de<br>_washout_e 13<br>semanas com a<br>outra intervenção|-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária<br>- Segurança|  
|**Autor**<br>**(ano)**|**Design e pacientes**|**Objetivo**|**Dose do**<br>**baclofeno oral**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
||||Incremento<br>semanal até a 9ª<br>semana até uma<br>dose total de 20<br>mg/3x dia|||
|McKinlay<br>(1980)<sup>106</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes pediátricos<br>entre 7 e 16 anos<br>(n=20) com paralisia<br>cerebral.|Avaliar os efeitos<br>do baclofeno oral<br>nas atividades<br>cotidianas dos<br>pacientes.|1ª semana: 0,5<br>mg/kg/dia dividida<br>em 3 doses<br>2ª semana: 1<br>mg/kg/dia<br>dividida em 3<br>doses<br>3ª semana: 2<br>mg/kg/dia dividida<br>em 3 doses<br>4ª semana: 1<br>mg/kg/dia dividida<br>em 3 doses<br>Dose máxima: 60<br>mg/dia|4 semanas com<br>uma das<br>intervenções, 1<br>semana de<br>_washout_e 4<br>semanas com a<br>outra intervenção|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária<br>- Segurança|
|Lopez<br>(1996)<sup>105</sup>|ECR cruzado,<br>incluindo pacientes<br>pediátricos entre 3 e<br>26 anos (n=20) com<br>paralisia cerebral.|Avaliar os efeitos<br>do baclofeno oral<br>na espasticidade<br>devido à paralisia<br>cerebral.|12,5 mg 3x/dia<br>Incremento<br>semanal: 0,5<br>mg/kg/dia até uma<br>dose total de 1 a 2<br>mg/kg/dia|6 semanas com<br>uma das<br>intervenções, 2<br>semanas de<br>_washout_e 6<br>semanas com a<br>outra intervenção|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>-<br>Capacidade<br>funcional<br>durante as<br>atividades<br>de vida<br>diária<br>- Segurança|
|Milla<br>(1973)<sup>107</sup>|ECR cruzado e duplo-<br>cego, incluindo<br>pacientes pediátricos<br>entre 2 e 16 anos|Avaliar os efeitos<br>do baclofeno em<br>comparação com o<br>placebo na|Dose inicial:  10<br>mg/dia em 2 doses|4 semanas com<br>uma das<br>intervenções e 4|- Avaliação<br>da<br>espasticidad<br>e por Escala|  
|**Autor**<br>**(ano)**|**Design e pacientes**|**Objetivo**|**Dose do**<br>**baclofeno oral**|**Tempo de**<br>**seguimento**|**Desfechos**<br>**de**<br>**interesse**<br>**avaliados**|
|---|---|---|---|---|---|
|**Baclofeno**|(n=20) com paralisia<br>cerebral além de<br>diplegia, hemiplegia<br>ou tetraplegia.<br>**vs diazepam**|incapacidade<br>devido à<br>espasticidade<br>piramidal em<br>crianças que<br>sofrem de paralisia<br>cerebral.|Três incrementos<br>ao longo de um<br>período de nove<br>dias considerando<br>dose diária<br>máxima de 60 mg<br>(≥ 8 anos) ou de<br>30-40 mg (2 a 7<br>anos)|semanas com a<br>outra intervenção<br>(sem tempo de<br>_washout_)|de<br>Ashworth<br>- Segurança|
|Goyal<br>(2016)<sup>109</sup>|ECR_open-label_,<br>incluindo pacientes<br>pediátricos entre 2 e<br>18 anos (n=67) com<br>paralisia cerebral<br>espástica.|Avaliar e comparar<br>os resultados de<br>diazepam e<br>baclofeno orais em<br>crianças com<br>paralisia cerebral<br>espástica em<br>termos de extensão<br>da redução da<br>espasticidade e do<br>perfil de efeitos<br>adversos.|**< 8 anos**:<br>Dose inicial: 2,5<br>mg 3x/dia<br>Incremento<br>semanal: 5 mg a<br>um máximo de 40<br>mg / dia<br>**> 8 anos**<br>Dose inicial: 5<br>mg 3x/dia<br>Incremento<br>semanal: 5 mg a<br>um máximo de 60<br>mg / dia|3 meses|- Avaliação<br>da<br>espasticidad<br>e por Escala<br>de<br>Ashworth<br>- Segurança|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Análise e apresentação dos resultados** -->
Os resultados detalhados dos estudos primários incluídos são apresentados de acordo com cada desfecho e comparador no Material Suplementar 2. Aqui, apresentamos uma síntese dos resultados dos estudos primários, considerando desfecho e comparador, para cada uma das populações estudadas (adultos e crianças).

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>ADULTOS</u>** -->
Foram sintetizados os resultados de 9 ECR e o sistema GRADE foi aplicado para avaliar a confiança das evidências para a comparação com placebo e diazepam. O desfecho qualidade de vida não foi avaliado em nenhum dos ECR. O resumo dos resultados foi realizado de maneira descritiva pela impossibilidade de realizar meta-análise devido à heterogeneidade das análises e da apresentação desses resultados nos estudos primários. Além disso, para todos os desfechos, nas duas comparações (com placebo e com diazepam), a certeza da evidência foi julgada como “muito baixa” – exceto para dor associada à espasticidade na comparação de baclofeno com placebo, cuja certeza foi classificada como “baixa” – devido ao alto risco de viés dos estudos, à  
heterogeneidade principalmente nos métodos de avaliação e tipos de análises dos resultados, ao tamanho amostral pequeno do conjunto de evidências.  
_Avaliação da espasticidade por escala de Ashworth_  
Não foram todos os ECR identificados que aplicaram a escala de Ashworth ou mesmo outras escalas validadas para avaliação da espasticidade. Mesmo quando utilizada, os resultados dos ECR foram apresentados de maneira heterogênea, descrevendo o resultado para avaliação clínica geral da espasticidade ou focando apenas no tônus muscular. Cinco ECR aplicaram a escala de Ashworth na comparação com placebo (Brar (1991)<sup>96</sup> , Hudgson (1971)<sup>99</sup> e Orsnes (2000)<sup>100</sup> ) e dois na comparação com diazepam (From (2009)<sup>103</sup> e Cartlidge (1974)<sup>104</sup> ).  
De forma geral, os estudos que compararam baclofeno oral com placebo sugerem tendência de efeitos mais positivos para a intervenção. Dois deles<sup>96,100</sup> , porém, indicaram não haver diferença significativa entre os grupos, enquanto Hudson (1971)<sup>99</sup> mostrou diferença entre os grupos de 0,90 ± 0,426 (p<0,05). Os que compararam este medicamento com diazepam, por outro lado, indicaram uma diferença pouco significante entre as tecnologias em termos de efeito: um indicando uma variação da soma da pontuação da escala antes e após 4 semanas depois dos tratamentos e outro pela diferença média da pontuação para dose baixa (comparando antes e depois dos tratamentos) e para dose alta (imediatamente após a dose baixa)<sup>103,104</sup> . No entanto, em ambos os casos, ou seja, considerando os estudos para os dois comparadores (placebo e diazepam), o número de pacientes é muito pequeno e os resultados são pouco expressivos, o que impede qualquer conclusão em ambas as comparações.  
_Dor associada à espasticidade_  
O desfecho dor foi avaliado de forma subjetiva pelos participantes em praticamente todos os estudos; e o relato dificulta a análise e conclusão. O ECR de Sachais (1977)<sup>101</sup> foi o que fez uma análise mais completa em relação à dor associada à espasticidade para pacientes com esclerose múltipla. Foram avaliadas as diferenças entre o período basal e a última visita após os participantes já terem sido submetidos a baclofeno oral ou a placebo. Reduções estatisticamente significativas dos valores basais na dor foram vistas em pacientes tratados com baclofeno oral, principalmente quando se considerou a avaliação neurológica da dor relacionada aos espasmos flexores (baclofeno: -1,10; placebo: -0,08; p < 0,001) e, também, a partir da impressão clínica geral do médico (baclofeno: -2,69; placebo: -2,26; p<0,025). Por outro lado, a autoavaliação dos pacientes sobre as dores nos braços e pernas não teve diferença estatisticamente significativa entre os grupos (baclofeno: -0,08; placebo: - 0,12; p = não especificado). Vale destacar que cada uma das avaliações foi feita por escalas graduadas distintas para classificação da dor, cujas diminuições do escore significam menores impressões de dor.  
_Capacidade funcional durante as atividades de vida diária_  
A capacidade funcional é relatada de diferentes formas pelos estudos. Hudgson (1971)<sup>99</sup> relatou as impressões dos pacientes durante o tratamento: dos 23, 13 que usaram baclofeno confirmaram melhora e, para o grupo controle, apenas cinco. Brar (1991)<sup>96</sup> , por outro lado, fez uso de escala de autoavaliação dos pacientes para atividades funcionais diárias, avaliando a proporção de melhora para os grupos baclofeno, baclofeno + alongamento, placebo e placebo + alongamento para deambulação de 100 jardas (10% vs 10% vs 17% vs 30%), subir escadas ou meio-fio (20% vs 23% vs 13% vs 7%) e atividades domésticas (17% vs 23% vs 20% vs 23%). Sachais (1977)<sup>101</sup> fez uma avaliação por impressão geral do paciente (de 0,16 para ambos os grupos) e do médico, que, neste caso, envolveu o efeito do baclofeno e placebo para andar (2,30 vs 2,28), vestir ou despir (2,11 vs 2,31), função da bexiga (2,02 vs 2,1), dormindo (2,22 vs 2,14), destreza geral (2,17 vs 2,19) e fala ou mentação (1,93 vs 2,04). Orsnes (2000)<sup>100</sup> fez a avaliação funcional, mas não apresentou resultados. Os quatro ECR comparam baclofeno oral a placebo e indicaram não haver diferença estatisticamente significativa entre as duas intervenções analisadas.

---

<!-- METADADOS: doenca: Espasticidade | secao: _Qualidade de vida_ -->
Não foram encontrados ECR durante realização desta síntese de evidências que avaliassem a qualidade de vida com o uso em adultos de baclofeno oral, então não é possível estabelecer qualquer influência da tecnologia sobre esse desfecho.

---

<!-- METADADOS: doenca: Espasticidade | secao: _Segurança_ -->
Nenhum dos ECR identificados apresentaram dados estatísticos para a ocorrência de EAM, mas indicaram as quantidades de casos/eventos adversos ao medicamento e dos comparadores (placebo ou diazepam), sem realizar, inclusive, comparação entre os resultados encontrados. Detalhes presentes no Material Suplementar 2.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>CRIANÇAS</u>** -->
Foram sintetizados os resultados de 5 ECR e o sistema GRADE também foi aplicado para avaliar a confiança das evidências para crianças. Para todos os desfechos, a certeza da evidência julgada foi como “muito baixa”, considerando os comparadores placebo e diazepam, exceto para o desfecho avaliação da espasticidade pela escala de Ashworth para a evidência relacionada ao comparador diazepam – que foi classificada como “baixa”. Os desfechos qualidade de vida e dor associada à espasticidade não foram avaliados nos ECR incluídos. O resumo dos resultados também foi feito de maneira descritiva devido à heterogeneidade das análises e da apresentação desses resultados nos estudos primários.  
_Avaliação da espasticidade por escala de Ashworth_  
Dos 5 ECR analisados, apenas um não utilizou a escala de Ashworth<sup>108</sup> . Os estudos apresentaram os resultados de maneiras diferentes, também considerando avaliação geral da espasticidade ou apenas para tônus muscular. Goyal (2016)<sup>109</sup> comparou baclofeno oral com diazepam e indicou não haver diferença entre os tratamentos. Lopez (1996)<sup>105</sup> , McKinlay (1980)<sup>106</sup> e Milla (1973)<sup>107</sup> compararam o baclofeno oral a placebo e seus resultados mostram pequena ou nenhuma diferença estatística entre os grupos, o que pode ser explicado tanto pelo pequeno número de pacientes em cada estudo quanto pela baixa magnitude de diferença do efeito. Os quatro ECR incluíram participantes com espasticidade secundária à paralisia cerebral.

---

<!-- METADADOS: doenca: Espasticidade | secao: _Dor associada à espasticidade_ -->
Não foram encontrados ECR que avaliassem a dor associada à espasticidade com o uso em crianças de baclofeno oral.  
_Capacidade funcional durante as atividades de vida diária_  
Dos ECR, apenas três relataram sobre a capacidade funcional das crianças durante as atividades diárias. Todos compararam baclofeno oral a placebo. Lopez (1996)<sup>105</sup> avaliou a capacidade e autonomia por meio de escala aplicada aos responsáveis pelos pacientes. Os autores indicaram alterações favoráveis como maior facilidade nos alongamentos e nas trocas de roupas, mais mobilidade espontânea e um pequeno aumento da autonomia para se alimentar. McKinlay (1980)<sup>106</sup> relatou as percepções dos pais e professores também, que comentaram efeitos positivos de baclofeno nas atividades de vida diária, apesar dos autores indicarem não ter tido melhora por meio de exames clínicos, bem como no aprendizado em sala de aula ou na caligrafia.  
Já Scheinberg (2006)<sup>108</sup> utilizou-se das escalas PEDI ( _Pediatric Evaluation of Disability Inventory_ ) e GAS ( _Goal Attainment Scaling_ ) para avaliação da capacidade funcional dos pacientes pediátricos. A primeira refere-se a uma ferramenta para determinar a capacidade de uma criança de realizar suas atividades de autocuidado em relação à sua idade de desenvolvimento (desempenho esperado)<sup>111,112</sup> , enquanto a segunda é uma técnica para avaliar o alcance da meta funcional de  
crianças que recebem terapias para determinadas condições<sup>113,114</sup> . Para GAS, baclofeno apresentou resultado favorável em relação ao placebo, os resultados não foram estatisticamente significativos para PEDI.  
_Qualidade de vida_  
Também não foram identificados ECR que avaliassem a qualidade de vida com o uso em crianças de baclofeno oral.  
_Segurança_  
Todos os ECR apresentaram apenas o número de casos/eventos adversos ao medicamento ou comparadores (placebo ou diazepam), sem realizar comparações entre os resultados. Detalhes podem ser encontrados no Material Suplementar 2, mas cabe destacar que quase todos os eventos foram classificados como leves; destaque para a sedação, que foi o mais frequente para os grupos baclofeno e diazepam: respectivamente, 5 e 11 casos relatados em From (2009)<sup>103</sup> ; e, para dose baixa, 6 e 5 [sedação sozinha] e 3 e 5 [sedação associada a outros efeitos], enquanto, para dose alta, 5 e 4 [sedação sozinho] e 1 e 6 [sedação associada a outros efeitos], casos apresentados por Cartlidge (1974)<sup>104</sup> .

---

<!-- METADADOS: doenca: Espasticidade | secao: **Perfil de evidências:** -->
As **tabelas J, K, L e M** apresentam os resultados da avaliação da certeza da evidência para adultos e crianças, comparando baclofeno oral a placebo e diazepam.  
**Tabela J1** - Avaliação da qualidade da evidência para estudos clínicos comparando baclofeno oral e placebo em adultos, a partir da ferramenta GRADE  
|||**Avaliação da**|**certeza d**|**as evidência**|**s**||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participant**<br>**es)**|**Risco**<br>**de**<br>**viés**|**Inconsistênc**<br>**ia**|**Evidên**<br>**cia**<br>**indiret**<br>**a**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaç**<br>**ão**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**|**Importâ**<br>**ncia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Avaliação da espasticidade por escala de Ashworth** -->
|3 ECR<br>(n=84)|muito<br>grave<br>a|não grave|não<br>grave|grave<sup>c</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Hudson (1971)<sup>99</sup>identificou melhora clínica da<br>espasticidade avaliada pela escala de Ashworth com<br>uma diferença significativa favorecendo baclofeno<br>oral em relação ao placebo. Ele indicou melhora média<br>na pontuação da escala de 1,44 para baclofeno e 0,54<br>para placebo, com diferença entre os grupos de 0,90 ±<br>0,426 (p<0,05).<br>Por outro lado, Brar (1991)<sup>96</sup>e Ornes (2000)<sup>100</sup>não<br>mostraram haver diferença significativa entre os<br>grupos pela escala.|CRÍTIC<br>O|
|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Dor associada à espasticidade** -->
|4 ECR|muito|não grave|não|grave<sup>c</sup>|nenhum|⨁⨁◯◯|Todos os ECR relataram melhora da dor associada à|IMPORT|
|---|---|---|---|---|---|---|---|---|
|(n=245)|grave<br>a||grave|||BAIXA|espasticidade, mas as análises foram subjetivas e<br>heterogêneas. Sawa (1979)<sup>102</sup>apenas afirmou a<br>melhora, enquanto Duncan (1976)<sup>97</sup>e Feldman<br>(1978)<sup>98</sup>indicaram redução de espasmos dolorosos<br>pelo uso de baclofeno em 72% dos pacientes e em 9 de<br>16 dos participantes, respectivamente, a partir das<br>impressões dos próprios indivíduos. Já Sachais|ANTE|  
|||**Avaliação da**|**certeza d**|**as evidências**|||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participant**<br>**es)**|**Risco**<br>**de**<br>**viés**|**Inconsistênc**<br>**ia**|**Evidên**<br>**cia**<br>**indiret**<br>**a**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaç**<br>**ão**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**|**Importâ**<br>**ncia**|
||||||||(1977)<sup>101</sup>indicou valores para da diferença entre as<br>aferições iniciais e da última visita considerando<br>diferentes análises (sendo a diferença entre os grupos<br>das duas primeiras estatisticamente significativa) –<br>baclofeno_vs_placebo:<br>_Avaliação neurológica da dor relacionada aos_<br>_espasmos flexores_: -1,10_vs_-0,08 (p<0,001)<br>_Impressão clínica geral do médico:_-2,69_vs_-2,26<br>(p<0,025)<br>_Autoavaliação dos pacientes sobre as dores nos_<br>_braços e pernas:_-0,08_vs_-0,12 (p=não especificado)||
|**Capacidade f**|**uncional**|**durante as ativi**|**dades de v**|**ida diária**|||||
|4 ECR|muito|não grave|não|grave<sup>c</sup>|nenhum|⨁◯◯◯|Nenhum dos ECR<sup>96,99–101</sup>identificou diferença entre os|IMPORT|
|(n=241)<br>**Eventos adve**|grave<br>a<br>**rsos**||grave|||MUITO<br>BAIXA|tratamentos utilizados estatisticamente significativa.<br>|ANTE|
|6 ECR|muito|grave<sup>b</sup>|não|grave<sup>c</sup>|nenhum|⨁◯◯◯|Todos os ECR<sup>96–102</sup>comparando baclofeno e placebo|IMPORT|
|(n=291)|grave||grave|||MUITO|relataram<br>um<br>número<br>de<br>eventos<br>adversos|ANTE|
||a|||||BAIXA|relativamente maior para o grupo em uso de baclofeno||  
<!-- Start of picture text -->
Avaliação da certeza das evidências  Sumário de Resultados<br>Evidên Importâ<br>Estudos   Risco  Viés de  Certeza<br>Inconsistênc cia  Imprecis ncia<br>(participant de  publicaç geral de  Impacto<br>ia  indiret ão<br>es)  viés  ão  evidência<br>a<br>oral.  Os  principais  eventos  adversos  foram<br>relacionados à sedação<br><!-- End of picture text -->  
**a.** Maioria dos estudos tiveram problemas com a randomização, sigilo de alocação e o cegamento pela falta de informações disponíveis ou completas, além de não apresentarem os protocolos de pesquisa; **b.** Heterogeneidade  
nas estimativas de efeito entre os resultados dos estudos; **c.** Tamanho amostral pequeno; **d.** Há estudos que avaliaram capacidade funcional, não indicando necessariamente a relação com atividades da vida diária; **e.** Os estudos apenas relatam o número de casos para alguns eventos adversos, sem realizar comparação entre os resultados encontrados.  
**Tabela K -** Avaliação da qualidade da evidência para estudos clínicos comparando baclofeno oral e diazepam em adultos, a partir da ferramenta GRADE  
|||**Avaliação d**|**a certeza d**|**as evidências**|||**Sumário de Result**|**ados**|
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participante**<br>**s)**|**Risco**<br>**de viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Viés de**<br>**publicaçã**<br>**o**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**|**Importânc**<br>**ia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Avaliação da espasticidade por escala de Ashworth** -->
|2 ECR<br>(n=57)|muito<br>grave<sup>a</sup>|não grave|não<br>grave|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|From (2009)<sup>103</sup>mostrou variação de 76 para<br>55 para o grupo de baclofeno na soma das<br>pontuações da escala, enquanto, para o grupo<br>de diazepam, mudou de 80 para 57.<br>Cartlidge (1974)<sup>104</sup>indicou, para dose baixa,<br>uma diferença na pontuação da escala de<br>0,49 (0,163), com p<0,01, para o grupo de<br>baclofeno e de 0,71 (0,159), com p<0,001,<br>para o de diazepam. Para dose alta, os<br>valores para os grupos foram,<br>respectivamente, 1,31 (0,227) e 1,13 (0,202);<br>ambos com p<0,001. Ambos os estudos, por<br>fim, identificaram que a diferença entre os<br>tratamentos utilizados não foi<br>estatisticamente significativa.|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
**Eventos adversos**  
|2 ECR|muito|não grave|não|grave<sup>b</sup>|nenhum|⨁◯◯◯|Número de eventos adversos de baclofeno|IMPORTA|
|---|---|---|---|---|---|---|---|---|
|(n=57)|grave<sup>a</sup>||grave|||MUITO|oral parecido ao de diazepam, sem diferença|NTE|
|||||||BAIXA|significativa, tanto para From (2009)<sup>103</sup><br>quanto para Cartlidge (1974)<sup>104</sup>.||  
**a.** Maioria dos estudos tiveram problemas com a randomização, sigilo de alocação e o cegamento pela falta de informações disponíveis ou completas, além de não apresentarem os protocolos de pesquisa; **b.** Tamanho  
amostral pequeno; **c.** Os estudos apenas relataram o número de casos para alguns eventos adversos, sem realizar comparação entre os resultados encontrados.  
**Tabela L -** Avaliação da qualidade da evidência para estudos clínicos comparando baclofeno oral e placebo em crianças, a partir da ferramenta GRADE  
|||**Avaliação da**|**certeza da**|**s evidência**|**s**||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participant**<br>**es)**|**Risco**<br>**de**<br>**viés**|**Inconsistênc**<br>**ia**|**Evidên**<br>**cia**<br>**indiret**<br>**a**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaç**<br>**ão**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**|**Importân**<br>**cia**|  
|3 ECR|muito|não grave|não|grave<sup>c</sup>|nenhum|⨁◯◯◯|McKinlay (1980)<sup>106</sup>e Milla (1973)<sup>107</sup>indicaram pouca|CRÍTICO|
|---|---|---|---|---|---|---|---|---|
|(n=60)|grave<br>a||grave|||MUITO<br>BAIXA|ou nenhuma diferença estatística entre os grupos.<br>Lopez (1996)<sup>105</sup>mostrou que todos os pacientes<br>tinham escores ≥ 3 não se alteraram com o placebo,<br>mas diminuíram significativamente durante o uso de<br>baclofeno, tendo 10 casos com tônus baixo (escore 2)<br>(p <0,05) ao final.||  
**Capacidade funcional durante as atividades de vida diária**  
|3 ECR|muito|Não grave|não|grave<sup>c</sup>|nenhum|⨁◯◯◯|McKinlay (1980)<sup>106</sup>relatou não haver benefício por|IMPORT|
|---|---|---|---|---|---|---|---|---|
|(n=55)|grave<br>a||grave|||MUITO<br>BAIXA|baclofeno nas atividades funcionais quando feitos<br>exames clínicos, mas professores e pais comentaram<br>que as crianças tiveram efeitos positivos. Lopez<br>(1996)<sup>105</sup>, por sua vez, indicou alterações favoráveis<br>com baclofeno em 9 pacientes por meio de avaliação<br>com os pais/responsáveis. Já Scheinberg (2006)<sup>108</sup><br>mostrou, para a escala GAS, uma mudança na análise<br>entre os grupos baclofeno e placebo de 6,6 (1,0 a 12,3)<br>e p=0,05, favorecendo a intervenção em relação ao<br>comparador (resultado significativo) e, para PEDI, a<br>mudança foi analisada para 3 itens: auto-cuidado [−1,5<br>(−3,5 a 0,6), p=0,21], mobilidade [−1,5 (−3,1 a 0,2),<br>p=0,08] e função social [−0,2 (−3,0 a 2,6), p=0,96]<br>(resultados não significativos estatisticamente).|ANTE|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Segurança** (ocorrência de eventos adversos ao medicamento) -->
|4 ECR|muito|Não grave<sup>b</sup>|grave<sup>d</sup>|grave<sup>c</sup>|nenhum|⨁◯◯◯|Todos os ECR comparando baclofeno e placebo<sup>105–108</sup>|IMPORT|
|---|---|---|---|---|---|---|---|---|
|(n=75)|grave<sup>a</sup>|||||MUITO|relataram um número de eventos adversos|ANTE|
|||||||BAIXA|relativamente maior para o grupo em uso de<br>baclofeno oral.||  
**PEDI:** _Pediatric Evaluation of Disability Inventory_ ; **GAS:** _Goal Attainment Scaling_ .  
**a.** Maioria dos estudos a problemas com a randomização, sigilo de alocação e o cegamento pela falta de informações disponíveis ou completas, além de não apresentarem os protocolos de pesquisa; **b.** Heterogeneidade  
efeito nas estimativas de efeito entre os resultados dos estudos; **c.** Tamanho amostral pequeno; **d.** Os estudos apenas relataram o número de casos para alguns eventos adversos, sem realizar comparação entre os resultados encontrados.  
**Tabela M -** Avaliação da qualidade da evidência para estudos clínicos comparando baclofeno oral e diazepam em crianças, a partir da ferramenta GRADE  
|||**Avaliação d**|**a certeza da**|**s evidências**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participant**<br>**es)**|**Risco**<br>**de viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Viés de**<br>**publicaçã**<br>**o**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**<br>**Importân**<br>**cia**|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Avaliação da espasticidade por escala de Ashworth** -->
|1 ECR<br>(n=67)|grave<sup>a</sup>|não grave|não<br>grave|grave<sup>b</sup>|nenhum|⨁⨁◯◯<br>BAIXA|Goyal (2016)<sup>109</sup>indicou que baclofeno e<br>diazepam foram eficazes para melhora da<br>espasticidade na paralisia cerebral, mas não<br>houve diferença significativa entre eles.<br>Resultados para os diferentes períodos do<br>estudo (baclofeno_vs_diazepam):<br>Pré-tratamento (p=0,28)<br>1,84±0,64 (IC: 1,60-2,08) vs 1,96±0,40 (IC:<br>1,78-2,15)<br>1 mês (p=0,22)<br>1,84±0,64 (IC: 1,60-2,08) vs 1,63±0,40 (IC:<br>1,48-1,79)<br>3 meses (p=0,22)<br>1,31±0,48 (IC: 1,13-1,50) vs 1,41±0,36 (IC:<br>1,28-1,55)|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
**Segurança** (ocorrência de eventos adversos ao medicamento)  
|1 ECR|grave<sup>a</sup>|não grave|não|grave<sup>b</sup>|nenhum|⨁◯◯◯|Goyal (2016)<sup>109</sup>apresentou número de eventos|IMPORTA|
|---|---|---|---|---|---|---|---|---|
|(n=67)|||grave|||MUITO|adversos de baclofeno oral parecido ao de|NTE|
|||||||BAIXA|diazepam, sem diferença significativa. Para||  
|sonolência,|por exemplo, no 1º mês, foram|
|---|---|
|indicados 6|casos no grupo de baclofeno e 9,|
|no de dia|zepam. Outros eventos, como|
|fraqueza, fre|quência em urinar, dor de cabeça,|
|não tiveram|mais que 3 ocorridos durante no|
|primeiro ou|depois de três meses para ambos|
|os grupos.||  
**a.** O estudo teve risco de viés avaliado como “Alto”; **b.** Tamanho amostral pequeno; **c** Os estudos apenas relataram o número de casos para alguns eventos adversos, sem realizar comparação entre os resultados encontrados.

---

<!-- METADADOS: doenca: Espasticidade | secao: **<u>CONSIDERAÇÕES</u>** -->
Para esta síntese, foram incluídos 14 ECR<sup>96–109</sup> sobre uso de baclofeno para o tratamento de espasticidade secundária a alguma doença de base. Aqueles referentes à população adulta incluíram, na maioria, participantes com esclerose múltipla, enquanto os relacionados à pediátrica trabalharam com pacientes com paralisia cerebral. Em relação à eficácia do baclofeno, os estudos que avaliaram a melhora clínica da espasticidade por meio da escala de Ashworth (tanto para crianças, quanto para adultos) indicaram que a intervenção não apresentou diferença entre os efeitos dos comparadores (placebo e diazepam) significativa. Sobre segurança, todos os ECR (independentemente da população ou comparador) trouxeram apenas o número dos eventos adversos ocorridos. Foi possível constatar mais casos no grupo baclofeno em relação ao placebo, mas, quando comparado a diazepam, essa diferença quase não existiu. Por outro lado, qualidade de vida não foi avaliada em nenhum dos ECR incluídos nesta síntese.  
Os demais desfechos (dor associada à espasticidade e capacidade funcional durante as atividades de vida diária) não foram relatados nos estudos comparando baclofeno com diazepam (para adultos e crianças). Os ECR que compararam o medicamento ao placebo indicaram: para a população adulta, o baclofeno foi eficaz para a dor associada à espasticidade, apesar das análises terem sido subjetivas e heterogêneas, e não teve diferença significativa para os efeitos sobre a capacidade funcional durante as atividades de vida diária. Por outro lado, para as crianças, a eficácia do baclofeno para a capacidade funcional no cotidiano foi inconclusiva, porque algumas análises indicaram benefício e outras não – dentro dos mesmos estudos, inclusive -, e não foi avaliada a dor associada à espasticidade para esses pacientes.  
Para todos os desfechos, a certeza do conjunto de evidências foi classificada como “muito baixa”, exceto para a avaliação da espasticidade pela escala de Ashworh na população pediátrica comparando baclofeno a diazepam, cuja certeza foi considerada “baixa”. Portanto, há necessidade de estudos primários mais robustos e melhor conduzidos para ambas as populações incluídas nesta síntese. Não é possível oferecer um resultado conclusivo sobre a eficácia e a segurança do baclofeno para a população adulta e pediátrica com espasticidade, por conta da baixa qualidade metodológica das evidências e da heterogeneidade das avaliações (diferentes escalas clínicas, análises subjetivas, exames clínicos) e dos dados para os desfechos analisados para pergunta de pesquisa englobada por este documento.  
É importante destacar que entre as publicações para as quais não foi encontrado o texto completo, estão dois estudos clínicos que compararam baclofeno a placebo em crianças e adultos (um ECR por população) incluídos em revisões anteriores, mas nenhum deles mudaria o resultado das análises conduzidas para elaboração desse documento. Além disso, não foram identificados estudos observacionais que comparassem o baclofeno a placebo ou diazepam e justificassem a inclusão desse tipo de estudo na análise.

---

<!-- METADADOS: doenca: Espasticidade | secao: **5. Referências** -->
1. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes Metodológicas: Elaboração de revisão sistemática e meta-análise de ensaios clínicos randomizados. 2021. Disponível em: https://rebrats.saude.gov.br/images/Documentos/2021/20210622_Diretriz_Revisao_Sistematica_2021.pdf. Acesso: 16/11/2021.  
2. Schünemann H, Brożek J, GordonGuyatt, Oxman A. GRADE Handbook. 2013.  
3. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst  
Rev. 2016 Dec;5(1):210.  
4. Bakheit AMO, Pittock S, Moore AP, Wurker M, Otto S, Erbguth F, et al. A randomized, double-blind, placebo-controlled study of the efficacy and safety of botulinum toxin type A in upper limb spasticity in patients with stroke. Eur J Neurol. 2001;8(6):559–65.  
5. Bakheit AMO, Thilmann AF, Ward AB, Poewe W, Wissel J, Muller J, et al. A randomized, double-blind, placebocontrolled, dose-ranging study to compare the efficacy and safety of three doses of botulinum toxin type A (Dysport) with placebo in upper limb spasticity after stroke. Stroke. 2000;31(10):2402–6.  
6. Kaji R, Osako Y, Suyama K, Maeda T, Uechi Y, Iwasaki M. Botulinum toxin type A in post-stroke upper limb spasticity. Curr Med Res Opin. 2010;26(8):1983–92.  
7. Kaňovský P, Slawek J, Denes Z, Platz T, Sassin I, Comes G, et al. Efficacy and safety of botulinum neurotoxin NT 201 in poststroke upper limb spasticity. Clin Neuropharmacol. 2009;32(5):259–65.  
8. Kong KH, Neo JJ, Chua KSG. A randomized controlled study of botulinum toxin A in the treatment of hemiplegic shoulder pain associated with spasticity. Clin Rehabil. 2007;21(1):28–35.  
9. Lam K, Lau KK, So KK, Tam CK, Wu YM, Cheung G, et al. Can Botulinum Toxin Decrease Carer Burden in Long Term Care Residents With Upper Limb Spasticity? A Randomized Controlled Study. J Am Med Dir Assoc. 2012;13(5):477–84.  
10. Marciniak CM, Harvey RL, Gagnon CM, Duraski SA, Denby FA, McCarty S, et al. Does botulinum toxin type a decrease pain and lessen disability in hemiplegic survivors of stroke with shoulder pain and spasticity? A randomized, doubleblind, placebo-controlled trial. Am J Phys Med Rehabil. 2012;91(12):1007–19.  
11. Marco E, Duarte E, Villa J, Tejero M, Guillen A, Boza R, et al. Is botulinum toxin type A effective in the treatment of spastic shoulder pain in patients after stroke? A double-blind randomized clinical trial. J Rehabil Med. 2007;39(6):440– 7.  
12. Masakado Y, Abo M, Kondo K, Saeki S, Saitoh E, Dekundy A, et al. Efficacy and safety of incobotulinumtoxinA in post-stroke upper-limb spasticity in Japanese subjects: results from a randomized, double-blind, placebo-controlled study (J-PURE). J Neurol. 2020;267(7):2029–41.  
13. McCrory P, Turner-Stokes L, Baguley IJ, De Graaff S, Katrak P, Sandanam J, et al. Botulinum toxin a for treatment of upper limb spasticity following stroke: A multi-centre randomized placebo-controlled study of the effects on quality of life and other person-centred outcomes. J Rehabil Med. 2009;41(7):536–44.  
14. O’Dell MW, Walker HW, Edgley SR, Gracies J-M, Gul F, Wimmer M, et al.  Poster 36 AbobotulinumtoxinA (Dysport ® ) in the Treatment of Adult Patients with Upper Limb Spasticity Due to Traumatic Brain Injury . Pm&R. 2015;7(9):S103–S103.  
15. Rosales RL, Balcaitiene J, Berard H, Maisonobe P, Goh KJ, Kumthornthip W, et al. Early abobotulinumtoxina (Dysport®) in post-stroke adult upper limb spasticity: ONTIME pilot study. Toxins (Basel). 2018;10(7):1–12.  
16. Bhakta BB, Cozens JA, Chamberlain MA, Bamford JM. Impact of botulinum toxin type A on disability and carer burden due to arm spasticity after stroke: A randomised double blind placebo controlled trial. J Neurol Neurosurg Psychiatry. 2000;69(2):217–21.  
17. Rosales RL, Kong KH, Goh KJ, Kumthornthip W, Mok VCT, Delgado-De Los Santos MM, et al. Botulinum toxin  
injection for hypertonicity of the upper extremity within 12 weeks after stroke: A randomized controlled trial. Neurorehabil Neural Repair. 2012;26(7):812–21.  
18. Simpson DM, Alexander DN, O’Brien CF, Tagliati M, Aswad AS, Leon JM, et al. Botulinum toxin type A in the treatment of upper extremity spasticity: A randomized, double-blind, placebo-controlled trial. Neurology. 1996;46(5):1306–10.  
19. Simpson DM, Gracies JM, Yablon SA, Barbano R, Brashear A, Team TBS. Botulinum neurotoxin versus tizanidine in upper limb spasticity: A placebo-controlled study. J Neurol Neurosurg Psychiatry. 2009;80(4):380–5.  
20. Suputtitada S, Suwanwela NC. The lowest effective dose of botulinum A toxin in adult patients with upper limb spasticity. Disabil Rehabil. 2005;27(4):176–84.  
21. Wolf SL, Milton SB, Reiss A, Easley KA, Shenvi N V., Clark PC. Further assessment to determine the additive effect of botulinum toxin type a on an upper extremity exercise program to enhance function among individuals with chronic stroke but extensor capability. Arch Phys Med Rehabil. 2012;93(4):578–87.  
22. Yelnik AP, Colle FM, Bonan I V., Vicaut E. Treatment of shoulder pain in spastic hemiplegia by reducing spasticity of the subscapular muscle: A randomised, double blind, placebo controlled study of botulinum toxin A. J Neurol Neurosurg Psychiatry. 2007;78(8):845–8.  
23. Brashear A, Gordon MF, Elovic E, Kassicieh VD, Marciniak C, Do M, et al. Intramuscular Injection of Botulinum Toxin for the Treatment of Wrist and Finger Spasticity after a Stroke. N Engl J Med. 2002 Aug;347(6):395–400.  
24. Childers MK, Brashear A, Jozefczyk P, Reding M, Alexander D, Good D, et al. Dose-dependent response to intramuscular botulinum toxin type a for upper-limb spasticity in patients after a stroke. Arch Phys Med Rehabil. 2004;85(7):1063–9.  
25. De Boer KS, Arwert HJ, De Groot JH, Meskers CGM, Rambaran Mishre AD, Arendzen JH. Shoulder pain and external rotation in spastic hemiplegia do not improve by injection of botulinum toxin A into the subscapular muscle. J Neurol Neurosurg Psychiatry. 2008;79(5):581–3.  
26. Elovic EP, Munin MC, Kaňovský P, Hanschmann A, Hiersemenzel R, Marciniak C. Randomized, placebo-controlled trial of incobotulinumtoxina for upper-limb post-stroke spasticity. Muscle and Nerve. 2016;53(3):415–21.  
27. Elovic E, Munin MC, Hanschmann A, Hiersemenzel R, Marciniak CM. Poster 397 Topline Results from a Randomized, Placebo-Controlled, Phase III Study Investigating the Safety and Efficacy of IncobotulinumtoxinA in Treating PostStroke Spasticity of the Upper Limb. Pm&R. 2014;6(9):S324.  
28. Gracies JM, Brashear A, Jech R, McAllister P, Banach M, Valkovic P, et al. Safety and efficacy of abobotulinumtoxinA for hemiparesis in adults with upper limb spasticity after stroke or traumatic brain injury: A double-blind randomised controlled trial. Lancet Neurol. 2015;14(10):992–1001.  
29. Jahangir AW, Tan HJ, Norlinah MI, Nafisah WY, Ramesh S, Hamidon BB, et al. Intramuscular injection of botulinum toxin for the treatment of wrist and finger spasticity after stroke. Med J Malaysia. 2007;62(4):319–22.  
30. Diniz de Lima F, Faber I, Servelhere KR, Bittar MFR, Martinez ARM, Piovesana LG, et al. Randomized Trial of Botulinum Toxin Type A in Hereditary Spastic Paraplegia — The SPASTOX Trial. Mov Disord. 2021;36(7):1654–63.  
31. Dunne JW, Gracies JM, Hayes M, Zeman B, Singer BJ. A prospective, multicentre, randomized, double-blind, placebocontrolled trial of onabotulinumtoxinA to treat plantarflexor/invertor overactivity after stroke. Clin Rehabil.  
2012;26(9):787–97.  
32. Napoli S, Berkovich RR, Brown T, Ayyoub ZA, Suarez G, Picaut P, et al. Poster 54: Dosing of AbobotulinumtoxinA (Dysport®) Injections for Adults with Lower Limb Spasticity. Pm&R. 2018;10:S25–S25.  
33. Pittock SJ, Moore AP, Hardiman O, Ehler E, Kovac M, Bojakowski J, et al. A double-blind randomised placebocontrolled evaluation of three doses of botulinum toxin type A (Dysport®) in the treatment of spastic equinovarus deformity after stroke. Cerebrovasc Dis. 2003;15(4):289–300.  
34. Verplancke D, Snape S, Salisbury CF, Jones PW, Ward AB. A randomized controlled trial of botulinum toxin on lower limb spasticity following acute acquired severe brain injury. Clin Rehabil. 2005;19(2):117–25.  
35. Wein T, Esquenazi A, Jost WH, Ward AB, Pan G, Dimitrova R. OnabotulinumtoxinA for the Treatment of Poststroke Distal Lower Limb Spasticity: A Randomized Trial. PM R. 2018;10(7):693–703.  
36. Fietzek UM, Kossmehl P, Schelosky L, Ebersbach G, Wissel J. Early botulinum toxin treatment for spastic pes equinovarus - a randomized double-blind placebo-controlled study. Eur J Neurol. 2014;21(8):1089–95.  
37. Gracies JM, Esquenazi A, Brashear A, Banach M, Kocer S, Jech R, et al. Efficacy and safety of abobotulinumtoxinA in spastic lower limb: Randomized trial and extension. Neurology. 2017;89(22):2245–53.  
38. Gusev YI, Banach M, Simonow A, Skoromets A, Czlonkowska A, Shmidt T, et al. Efficacy and safety of botulinum type a toxin in adductor spasticity due to multiple sclerosis. J Musculoskelet Pain. 2008;16(3):175–88.  
39. Hyman N, Barnes M, Bhakta B, Cozens A, Bakheit M, Kreczy-Kleedorfer B, et al. Botulinum toxin (Dysport) treatment of hip adductor spasticity in multiple sclerosis: a prospective, randomised, double blind, placebo controlled, dose ranging study. J Neurol Neurosurg Psychiatry. 2000;68(6):707–12.  
40. Kaji R, Osako Y, Suyama K, Maeda T, Uechi Y, Iwasaki M. Botulinum toxin type A in post-stroke lower limb spasticity: A multicenter, double-blind, placebo-controlled trial. J Neurol. 2010;257(8):1330–7.  
41. Kerzoncuf M, Viton JM, Pellas F, Cotinat M, Calmels P, Milhe de Bovis V, et al. Poststroke Postural Sway Improved by Botulinum Toxin: A Multicenter Randomized Double-blind Controlled Trial. Arch Phys Med Rehabil. 2020;101(2):242–8.  
42. Maanum G, Jahnsen R, Stanghelle JK, Sandvik L, Keller A. Effects of botulinum toxin a in ambulant adults with spastic cerebral palsy: A randomized double-blind placebo-controlled trial. J Rehabil Med. 2011;43(4):338–47.  
43. Masakado Y, Dekundy A, Hanschmann A, Kaji R. Efficacy and safety of incobotulinumtoxinA in the treatment of lowerlimb spasticity in Japanese patients. Toxicon. 2021;190:S48.  
44. Jacobson D, Löwing K, Kullander K, Rydh BM, Tedroff K. A First Clinical Trial on Botulinum Toxin-A for Chronic Muscle-Related Pain in Cerebral Palsy. Front Neurol. 2021;12(August):1–10.  
45. Richardson D, Sheean G, Werring D, Desai M, Edwards S, Greenwood R, et al. Evaluating the role of botulinum toxin in the management of focal hypertonia in adults. J Neurol Neurosurg Psychiatry. 2000;69(4):499–506.  
46. Wissel J, Ganapathy V, Ward AB, Borg J, Ertzgaard P, Herrmann C, et al. OnabotulinumtoxinA Improves Pain in Patients With Post-Stroke Spasticity: Findings From a Randomized, Double-Blind, Placebo-Controlled Trial. J Pain Symptom Manage. 2016;52(1):17–26.  
47. Population S, Design S. Bot Ul Inum Tox in for Spasticit Y a F Ter St Roke Intramuscular Injection of Botulinum Toxin for the Treatment of Wrist and Finger Spasticity After a Stroke. N Engl J Med. 2002;347(6):395–400.  
48. Kaji R, Osako Y, Suyama K, Maeda T, Uechi Y, Iwasaki M. Botulinum toxin type A in post-stroke lower limb spasticity: a multicenter, double-blind, placebo-controlled trial. J Neurol [Internet]. 2010 Aug 1;257(8):1330–7. Available from: http://link.springer.com/10.1007/s00415-010-5526-3  
49. Ansari NN, Naghdi S, Mashayekhi M, Hasson S, Fakhari Z, Jalaie S. Intra-rater reliability of the Modified Modified Ashworth Scale (MMAS) in the assessment of upper-limb muscle spasticity. NeuroRehabilitation. 2012 Jul;31(2):215– 22.  
50. Brashear A, Zafonte R, Corcoran M, Galvez-Jimenez N, Gracies J-M, Gordon MF, et al. Inter- and intrarater reliability of the Ashworth Scale and the Disability Assessment Scale in patients with upper-limb poststroke spasticity. Arch Phys Med Rehabil. 2002 Oct;83(10):1349–54.  
51. Ghotbi N, Ansari NN, Naghdi S, Hasson S, Jamshidpour B, Amiri S. Inter-rater reliability of the Modified Modified Ashworth Scale in assessing lower limb muscle spasticity. Brain Inj. 2009 Jan;23(10):815–9.  
52. Ghotbi N, Nakhostin Ansari N, Naghdi S, Hasson S. Measurement of lower-limb muscle spasticity: Intrarater reliability of Modified Modified Ashworth Scale. J Rehabil Res Dev. 2011;48(1):83.  
53. Gregson JM, Leathley M, Moore AP, Sharma AK, Smith TL, Watkins CL. Reliability of the tone assessment scale and the modified ashworth scale as clinical tools for assessing poststroke spasticity. Arch Phys Med Rehabil. 1999 Sep;80(9):1013–6.  
54. Warden V, Hurley AC, Volicer L. Development and Psychometric Evaluation of the Pain Assessment in Advanced Dementia (PAINAD) Scale. J Am Med Dir Assoc. 2003 Jan;4(1):9–15.  
55. Melzack R. The short-form McGill pain questionnaire. Pain. 1987 Aug;30(2):191–7.  
56. Collins SL, Moore AR, McQuay HJ. The visual analogue pain intensity scale: what is moderate pain in millimetres? Pain. 1997 Aug;72(1):95–7.  
57. Ferreira KA, Teixeira MJ, Mendonza TR, Cleeland CS. Validation of brief pain inventory to Brazilian patients with pain. Support Care Cancer. 2011 Apr;19(4):505–11.  
58. Farrar JT, Young JP, LaMoreaux L, Werth JL, Poole MR. Clinical importance of changes in chronic pain intensity measured on an 11-point numerical pain rating scale. Pain. 2001 Nov;94(2):149–58.  
59. Blumetti FC, Belloti JC, Tamaoki MJ, Pinto JA. Botulinum toxin type A in the treatment of lower limb spasticity in children with cerebral palsy. Cochrane Database Syst Rev [Internet]. 2019 Oct 8; Available from: https://doi.wiley.com/10.1002/14651858.CD001408.pub2  
60. Boyd RN, Dobson F, Parrott J, Love S, Oates J, Larson A, et al. The effect of botulinum toxin type A and a variable hip abduction orthosis on gross motor function: a randomized controlled trial. Eur J Neurol [Internet]. 2001 Nov;8(s5):109– 19. Available from: http://doi.wiley.com/10.1046/j.1468-1331.2001.00043.x  
61. Graham HK, Boyd R, Carlin JB, Dobson F, Lowe K, Nattrass G, et al. Does Botulinum Toxin A Combined with Bracing Prevent Hip Displacement in Children with Cerebral Palsy and “Hips at Risk”? J Bone Jt Surgery-American Vol [Internet]. 2008 Jan;90(1):23–33. Available from: http://journals.lww.com/00004623-200801000-00005  
62. Jóźwiak M, Harasymczuk P, Ciemniewska-Gorzela K. [The use of botulinum toxin in the treatment of spastic hip joint instability in children with cerebral palsy]. Chir Narzadow Ruchu Ortop Pol [Internet]. 72(3):205–9. Available from: http://www.ncbi.nlm.nih.gov/pubmed/17941584  
63. Barwood S, Baillieu C, Boyd R, Brereton K, Low J, Nattrass G, et al. Analgesic effects of botulinum toxin A: a randomized, placebo-controlled clinical trial. Dev Med Child Neurol [Internet]. 2000 Feb;42(2):S0012162200000220. Available from: http://doi.wiley.com/10.1017/S0012162200000220  
64. Van der Houwen LEE, Scholtes VA, Becher JG, Harlaar J. Botulinum toxin A injections do not improve surface EMG patterns during gait in children with cerebral palsy—A randomized controlled study. Gait Posture [Internet]. 2011 Feb;33(2):147–51. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0966636210003899  
65. Çağlar Okur S, Uğur M, Şenel K. Effects of Botulinum Toxin A Injection on Ambulation Capacity in Patients with Cerebral Palsy. Dev Neurorehabil [Internet]. 2019 May;22(4):288–91. Available from: http://www.ncbi.nlm.nih.gov/pubmed/30095354  
66. Chaturvedi SK, Rai Y, Chourasia A, Goel P, Paliwal VK, Garg RK, et al. Comparative assessment of therapeutic response to physiotherapy with or without botulinum toxin injection using diffusion tensor tractography and clinical scores in term diplegic cerebral palsy children. Brain Dev [Internet]. 2013 Aug;35(7):647–53. Available from: http://www.ncbi.nlm.nih.gov/pubmed/23165172  
67. Xu K, Yan T, Mai J. [Effects of botulinum toxin guided by electric stimulation on spasticity in ankle plantar flexor of children with cerebral palsy: a randomized trial]. Zhonghua er ke za zhi = Chinese J Pediatr [Internet]. 2006 Dec;44(12):913–7. Available from: http://www.ncbi.nlm.nih.gov/pubmed/17254459  
68. Kim H, Meilahn J, Liu C, Chambers H DR. Efficacy and safety of onabotulinumtoxina for the treatment of pediatric lower limb spasticity: primary results. Dev Med Child Neurol [Internet]. 2018 Oct;60:33–33. Available from: https://onlinelibrary.wiley.com/doi/10.1111/dmcn.49_14017  
69. El-Etribi MA, Salem ME, El-Shakankiry HM, El-Kahky AM, El-Mahboub SM. The effect of botulinum toxin type-A injection on spasticity, range of motion and gait patterns in children with spastic diplegic cerebral palsy: an Egyptian study. Int J Rehabil Res [Internet]. 2004 Dec;27(4):275–81. Available from: http://www.ncbi.nlm.nih.gov/pubmed/15572990  
70. Ibrahim AI, Hawamdeh ZM, Al-Qudah AA. Functional outcome of botulinum toxin injection of gastrocnemius and adductors in spastic hemiplegic cerebral palsied children. Eura Medicophys [Internet]. 2007 Mar;43(1):13–20. Available from: http://www.ncbi.nlm.nih.gov/pubmed/17021584  
71. Love SC, Valentine JP, Blair EM, Price CJ, Cole JH, Chauvel PJ. The effect of botulinum toxin type A on the functional ability of the child with spastic hemiplegia a randomized controlled trial. Eur J Neurol [Internet]. 2001 Nov;8 Suppl 5:50–8. Available from: http://www.ncbi.nlm.nih.gov/pubmed/11851734  
72. Navarrete Á, Peters D, Ruz S. Resultado funcional de infiltración de toxina botulínica multinivel en extremidades inferiores y terapia integral en niños con parálisis cerebral espástica. Rehabilitación [Internet]. 2010 Jul;44(3):236–43. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0048712010000575  
73. Reddihough DS, King JA, Coleman GJ, Fosang A, McCoy AT, Thomason P, et al. Functional outcome of botulinum toxin A injections to the lower limbs in cerebral palsy. Dev Med Child Neurol [Internet]. 2002 Dec;44(12):820–7. Available from: http://www.ncbi.nlm.nih.gov/pubmed/12455858  
74. Scholtes VA, Dallmeijer AJ, Knol DL, Speth LA, Maathuis CG, Jongerius PH, et al. The combined effect of lower-limb multilevel botulinum toxin type a and comprehensive rehabilitation on mobility in children with cerebral palsy: a randomized clinical trial. Arch Phys Med Rehabil [Internet]. 2006 Dec;87(12):1551–8. Available from:  
http://www.ncbi.nlm.nih.gov/pubmed/17141633  
75. Scholtes VA, Dallmeijer AJ, Knol DL, Speth LA, Maathuis CG, Jongerius PH, et al. Effect of multilevel botulinum toxin a and comprehensive rehabilitation on gait in cerebral palsy. Pediatr Neurol [Internet]. 2007 Jan;36(1):30–9. Available from: http://www.ncbi.nlm.nih.gov/pubmed/17162194  
76. Steenbeek D, Meester-Delver A, Becher JG, Lankhorst GJ. The effect of botulinum toxin type A treatment of the lower extremity on the level of functional abilities in children with cerebral palsy: evaluation with goal attainment scaling. Clin Rehabil [Internet]. 2005 May;19(3):274–82. Available from: http://www.ncbi.nlm.nih.gov/pubmed/15859528  
77. Tedroff K, Löwing K, Haglund-Akerlind Y, Gutierrez-Farewik E, Forssberg H. Botulinum toxin A treatment in toddlers with cerebral palsy. Acta Paediatr [Internet]. 2010 Aug;99(8):1156–62. Available from: http://www.ncbi.nlm.nih.gov/pubmed/20222884  
78. Zhu D-N, Wang M-M, Wang J, Zhang W, Li H-Z, Yang P, et al. [Effect of botulinum toxin A injection in the treatment of gastrocnemius spasticity in children aged 9-36 months with cerebral palsy: a prospective study]. Zhongguo Dang Dai Er Ke Za Zhi [Internet]. 2016 Feb;18(2):123–9. Available from: http://www.ncbi.nlm.nih.gov/pubmed/26903058  
79. Baker R, Jasinski M, Maciag-Tymecka I, Michalowska-Mrozek J, Bonikowski M, Carr L, et al. Botulinum toxin treatment of spasticity in diplegic cerebral palsy: a randomized, double-blind, placebo-controlled, dose-ranging study. Dev Med Child Neurol [Internet]. 2002 Oct;44(10):666–75. Available from: http://www.ncbi.nlm.nih.gov/pubmed/12418791  
80. Bjornson K, Hays R, Graubert C, Price R, Won F, McLaughlin JF, et al. Botulinum toxin for spasticity in children with cerebral palsy: a comprehensive evaluation. Pediatrics [Internet]. 2007 Jul;120(1):49–58. Available from: http://www.ncbi.nlm.nih.gov/pubmed/17606561  
81. Copeland L, Edwards P, Thorley M, Donaghey S, Gascoigne-Pees L, Kentish M, et al. Botulinum toxin A for nonambulatory children with cerebral palsy: a double blind randomized controlled trial. J Pediatr [Internet]. 2014 Jul;165(1):140-146.e4. Available from: http://www.ncbi.nlm.nih.gov/pubmed/24630348  
82. Delgado MR, Tilton A, Russman B, Benavides O, Bonikowski M, Carranza J, et al. AbobotulinumtoxinA for Equinus Foot Deformity in Cerebral Palsy: A Randomized Controlled Trial. Pediatrics [Internet]. 2016 Feb;137(2):e20152830. Available from: http://www.ncbi.nlm.nih.gov/pubmed/26812925  
83. Tilton A, Russman B, Aydin R, Dincer U, Escobar RG, Kutlay S, et al. AbobotulinumtoxinA (Dysport®) Improves Function According to Goal Attainment in Children With Dynamic Equinus Due to Cerebral Palsy. J Child Neurol [Internet]. 2017;32(5):482–7. Available from: http://www.ncbi.nlm.nih.gov/pubmed/28068857  
84. Kaňovský P, Slawek J, Denes Z, Platz T, Sassin I, Comes G, et al. Efficacy and Safety of Botulinum Neurotoxin NT 201 in Poststroke Upper Limb Spasticity. Clin Neuropharmacol [Internet]. 2009 Sep;32(5):259–65. Available from: https://journals.lww.com/00002826-200909000-00005  
85. Koman LA, Mooney JF, Smith BP, Goodman A, Mulvaney T. Management of spasticity in cerebral palsy with botulinum-A toxin: report of a preliminary, randomized, double-blind trial. J Pediatr Orthop [Internet]. 1994;14(3):299– 303. Available from: http://www.ncbi.nlm.nih.gov/pubmed/8006158  
86. Koman LA, Mooney JF, Smith BP, Walker F, Leon JM. Botulinum toxin type A neuromuscular blockade in the treatment of lower extremity spasticity in cerebral palsy: a randomized, double-blind, placebo-controlled trial. BOTOX Study Group. J Pediatr Orthop [Internet]. 2000;20(1):108–15. Available from:  
http://www.ncbi.nlm.nih.gov/pubmed/10641699  
87. Mall V, Heinen F, Siebel A, Bertram C, Hafkemeyer U, Wissel J, et al. Treatment of adductor spasticity with BTX-A in children with CP: a randomized, double-blind, placebo-controlled study. Dev Med Child Neurol [Internet]. 2006 Jan;48(1):10–3. Available from: http://www.ncbi.nlm.nih.gov/pubmed/16359588  
88. Moore AP, Ade-Hall RA, Smith CT, Rosenbloom L, Walsh HPJ, Mohamed K, et al. Two-year placebo-controlled trial of botulinum toxin A for leg spasticity in cerebral palsy. Neurology [Internet]. 2008 Jul 8;71(2):122–8. Available from: http://www.ncbi.nlm.nih.gov/pubmed/18606966  
89. Sutherland DH, Kaufman KR, Wyatt MP, Chambers HG, Mubarak SJ. Double-blind study of botulinum A toxin injections into the gastrocnemius muscle in patients with cerebral palsy. Gait Posture [Internet]. 1999 Sep;10(1):1–9. Available from: http://www.ncbi.nlm.nih.gov/pubmed/10469936  
90. Ubhi T, Bhakta BB, Ives HL, Allgar V, Roussounis SH. Randomised double blind placebo controlled trial of the effect of botulinum toxin on walking in cerebral palsy. Arch Dis Child [Internet]. 2000 Dec;83(6):481–7. Available from: http://www.ncbi.nlm.nih.gov/pubmed/11087280  
91. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ [Internet]. 2019 Aug 28;l4898. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.l4898  
92. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ [Internet]. 2008 Apr 26;336(7650):924–6. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.39489.470347.AD  
93. Dewan MC, Rattani A, Gupta S, Baticulon RE, Hung Y-C, Punchak M, et al. Estimating the global incidence of traumatic brain injury. J Neurosurg [Internet]. 2019 Apr;130(4):1080–97. Available from: https://thejns.org/view/journals/jneurosurg/130/4/article-p1080.xml  
94. Baunsgaard CB, Nissen U V, Christensen KB, Biering-Sørensen F. Modified Ashworth scale and spasm frequency score in spinal cord injury: reliability and correlation. Spinal Cord [Internet]. 2016 Sep 9;54(9):702–8. Available from: http://www.nature.com/articles/sc2015230  
95. Petek Balci B. Spasticty measurement. Arch Neuropsychiatry [Internet]. 2018; Available from: http://submission.noropsikiyatriarsivi.com/default.aspx?s=public~kabul&mId=23339  
96. Brar SP, Smith MB, Nelson LM, Franklin GM, Cobble ND. Evaluation of treatment protocols on minimal to moderate spasticity in multiple sclerosis. Arch Phys Med Rehabil [Internet]. 1991 Mar;72(3):186–9. Available from: http://www.ncbi.nlm.nih.gov/pubmed/1998451  
97. Duncan GW, Shahani BT, Young RR. An evaluation of baclofen treatment for certain symptoms in patients with spinal cord lesions: A double-blind, cross-over study. Neurology [Internet]. 1976 May 1;26(5):441–441. Available from: http://www.neurology.org/cgi/doi/10.1212/WNL.26.5.441  
98. Feldman RG, Hayes MK, Conomy J, Foley J. Baclofen: double blind crossover and long term study. Neurology [Internet]. 1978;28(4):333. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L8302124&from=export  
99. Hudgson P, Weightman D. Baclofen in the Treatment of Spasticity. BMJ [Internet]. 1971 Oct 2;4(5778):15–7. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.4.5778.15  
100. Orsnes GB, Sørensen PS, Larsen TK, Ravnborg M. Effect of baclofen on gait in spastic MS patients. Acta Neurol Scand [Internet]. 2000 Apr;101(4):244–8. Available from: http://www.ncbi.nlm.nih.gov/pubmed/10770520  
101. Sachais BA, Logue JN, Carey MS. Baclofen, a new antispastic drug. A controlled, multicenter trial in patients with multiple sclerosis. Arch Neurol. 1977;34(7):422–8.  
102. Sawa GM, Paty DW. The Use of Baclofen in Treatment of Spasticity in Multiple Sclerosis. Can J Neurol Sci / J Can des Sci Neurol [Internet]. 1979 Aug 18;6(3):351–4. Available from: https://www.cambridge.org/core/product/identifier/S0317167100023994/type/journal_article  
103. From A, Heltberg A. A double-trial with baclofen (Lioresal®) and diazepam in spasticity due to multiple sclerosis. Acta Neurol Scand [Internet]. 2009 Jan 29;51(2):158–66. Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.16000404.1975.tb01366.x  
104. Cartlidge NEF, Hudgson P, Weightman D. A comparison of baclofen and diazepam in the treatment of spasticity. J Neurol Sci [Internet]. 1974 Sep;23(1):17–24. Available from: https://linkinghub.elsevier.com/retrieve/pii/0022510X74901373  
105. Lopez S I, Troncoso Sch M, Avaria B M de los A, Clunes C A, Hernandez Ch M. Efectividad de baclofeno en el tratamiento de espasticidad de origen cerebral. Rev Chil pediatría [Internet]. 1996 Oct;67(5). Available from: http://www.scielo.cl/scielo.php?script=sci_arttext&pid=S0370-41061996000500003&lng=en&nrm=iso&tlng=en  
106. McKinlay I, Hyde E, Gordon N. Baclofen: A Team Approach to Drug Evaluation of Spasticity in Childhood. Scott Med J [Internet]. 1980 Oct 25;25(4):S26–8. Available from: http://journals.sagepub.com/doi/10.1177/003693308002500440  
107. Milla PJ, Jackson ADM. A Controlled Trial of Baclofen in Children with Cerebral Palsy. J Int Med Res [Internet]. 1973 Jan 25;1(2):398–404. Available from: http://journals.sagepub.com/doi/10.1177/030006057300100203  
108. Scheinberg A, Hall K, Lam LT, O’Flaherty S. Oral baclofen in children with cerebral palsy: A double-blind cross-over pilot study. J Paediatr Child Health [Internet]. 2006 Nov;42(11):715–20. Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.1440-1754.2006.00957.x  
109. Goyal V, Laisram N, Wadhwa R, Kothari S SR. Comparative study of oral diazepam and baclofen on spasticity in cerebral palsy. Dev Med Child Neurol. 2012;54(Suppl 6):70–1.  
110. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria Conjunta n<sup>o</sup> 2, de 29 de maio de 2017. Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Espasticidade. [Internet]. 2017. Available from: http://conitec.gov.br/images/Protocolos/Protocolo_Uso/PCDT_Espasticidade_29_05_2017.pdf  
111. Haley SM, Ludlow LH, Coster WJ. Pediatric Evaluation of Disability Inventory: Clinical Interpretation of Summary Scores Using Rasch Rating Scale Methodology. Phys Med Rehabil Clin N Am [Internet]. 1993 Aug;4(3):529–40. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1047965118305680  
112. Ho ES, Curtis CG, Clarke HM. Pediatric Evaluation of Disability Inventory: Its Application to Children With Obstetric Brachial Plexus Palsy. J Hand Surg Am [Internet]. 2006 Feb;31(2):197–202. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0363502305007471  
113. Turner-Stokes L. Goal attainment scaling (GAS) in rehabilitation: a practical guide. Clin Rehabil [Internet]. 2009 Apr 29;23(4):362–70. Available from: http://journals.sagepub.com/doi/10.1177/0269215508101742  
114. Ashford S, Turner-Stokes L. Goal attainment for spasticity management using botulinum toxin. Physiother Res Int  
- [Internet]. 2006 Mar;11(1):24–34. Available from: https://onlinelibrary.wiley.com/doi/10.1002/pri.36  
115.    Bertan H, Oncu J, Vanli E, et al. Use of Shear Wave Elastography for Quantitative Assessment of Muscle Stiffness After  Botulinum Toxin Injection in Children With Cerebral Palsy. J ultrasound Med  Off J Am Inst  Ultrasound Med 2020; 39: 2327–2337

---

<!-- METADADOS: doenca: Espasticidade | secao: **MATERIAL SUPLEMENTAR 1. Avaliação do risco de viés para os estudos clínicos incluídos.** -->
Avaliação do risco de viés para os estudos clínicos que compararam toxina botulínica do tipo A (TBA) com placebo em adultos.  
|**Desfecho**<br>**Alteração m**|**Estudo**<br>**édia da EAM**|**Viés proveniente do**<br>**processo de**<br>**randomização**|**Viés devido a**<br>**desvios da**<br>**intervenção**<br>**pretendida**|**Viés devido a**<br>**dados faltantes**<br>**sobre o desfecho**|**Viés na aferição do**<br>**desfecho**|**Viés na seleção do**<br>**resultado a ser**<br>**relatado**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
||Rosales, 2012<br>17|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|**Algumas**<br>**preocupações**|
||Masakado,<br>2020<sup>12</sup>|Algumas<br>preocupações<sup>b</sup>|Baixo|Alto<sup>c</sup>|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Rosales, 2018;<br>15|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|Baixo|Baixo|**Algumas**<br>**preocupações**|
|MEMBRO|Childers, 2004<br>24|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|S<br>SUPERIOR|Simpson, 1996<br>18|Alto<sup>e</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|ES|Simpson, 2009<br>19|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Lam, 2012<sup>9</sup>|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>g</sup>|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Marco, 2007<sup>11</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Kaji, 2010<sup>6</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Jahangir, 2007<br>29|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|  
||Suputtitada,<br>2005<sup>20</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>h</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|---|---|---|---|---|---|---|---|
||Elovic, 2016;<br>Elovic, 2014<br>26,27|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Gracies, 2015<br>28|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Marciniak,<br>2012<sup>10</sup>|Algumas<br>preocupações<sup>b</sup>|Baixo|Algumas<br>preocupações<sup>i</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Kong, 2004<sup>8</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Brashear, 2002<br>23|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Bhakta, 2000<sup>16</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Verplancke,<br>2005<sup>34</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Kaji, 2010<sup>48</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|MEMBRO<br>S|Kerzoncuf,<br>2020<sup>41</sup>|Algumas<br>preocupações<sup>b</sup>|Baixo|Algumas<br>preocupações<sup>i</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|**Alto**|
|INFERIOR|Wein, 2018<sup>35</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|ES|Napoli, 2018;<br>Gracies, 2017<br>32,37|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>j</sup>|Baixo|Baixo|Baixo|**Algumas**<br>**preocupações**|
||Hyman, 2000<br>39|Alto<sup>k</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|  
||Fietzek, 2014<br>36|Algumas<br>preocupações<sup>b</sup>|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|---|---|---|---|---|---|---|---|
||Masakado,<br>2020<sup>43</sup>|Alto<sup>k</sup>|Alto<sup>l</sup>|Alto<sup>m</sup>|Algumas<br>preocupações<sup>l</sup>|Baixo|**Alto**|
|MEMBRO<br>S|Richardson,<br>2000<sup>45</sup>|||||||
|SUPERIOR<br>ES +||Algumas<br>preocupações<sup>b</sup>|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|INFERIOR<br>ES||||||||
|**proporção ≥**|**1 ponto**|||||||
||Bakheita, 2001<br>4|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Yelnik, 2007<sup>22</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|MEMBRO<br>|Elovic, 2016;<br>Elovic, 2014<br>26,27|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|S<br>SUPERIOR<br>ES|Kanovský,<br>2009<sup>84</sup>|Baixo|Alto<sup>n</sup>|Baixo|Algumas<br>preocupações<sup>n</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Gracies, 2015<br>28|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||O´Dell, 2015<sup>14</sup>|Alto<sup>k</sup>|Alto<sup>l</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Bakheita, 2000<br>5|Alto<sup>k</sup>|Alto<sup>l</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Alto**|  
||Suputtitada,<br>2005<sup>20</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>h</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|---|---|---|---|---|---|---|---|
|MEMBRO<br>S|Pittock, 2003<sup>33</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|INFERIOR<br>ES|Wein, 2018<sup>35</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|**Dor**||||||||
||Rosales, 2012<br>17|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|**Algumas**<br>**preocupações**|
||Childers, 2004<br>24|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Lam, 2012<sup>9</sup>|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>g</sup>|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|MEMBRO|Marco, 2007<sup>11</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|S<br>SUPERIOR|De Boer, 2008<br>25|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|ES|Suputtitada,<br>2005<sup>20</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>h</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Yelnik, 2007<sup>22</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Marciniak,<br>2012<sup>10</sup>|Algumas<br>preocupações<sup>b</sup>|Baixo|Algumas<br>preocupações<sup>i</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Kong, 2004<sup>8</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||McCrory, 2009<br>13|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|  
||Diniz, 2021<sup>30</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|**Algumas**<br>**preocupações**|
|---|---|---|---|---|---|---|---|
|MEMBRO|Dunne, 2012<sup>31</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|S<br>INFERIOR|Pittock, 2003<sup>33</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|ES|Gusev, 2008<sup>38</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Wein, 2018<sup>35</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Hyman, 2000<br>39|Alto<sup>k</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|MEMBRO|Wissel, 2016<sup>46</sup>|Baixo|Baixo|Baixo|Baixo|Alto<sup>o</sup>|**Alto**|
|S<br>SUPERIOR|Jacobson, 2021<br>44|||||||
|ES +||Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|INFERIOR<br>ES||||||||
|**Eventos adv**|**ersos**|||||||
||Simpson, 2009<br>19|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
|MEMBRO<br>S|Rosales, 2012<br>17|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
|SUPERIOR<br>ES|Rosales, 2018<br>15|Baixo|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>g</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Childers, 2004<br>24|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|  
||Kaji, 2010<br>(NCT0046056<br>4)<sup>6</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|---|---|---|---|---|---|---|---|
||Bakheita, 2001<br>4|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Yelnik, 2007<sup>22</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Elovic, 2016<br>26,27|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>p</sup>|Algumas<br>preocupações<sup>q</sup>|**Algumas**<br>**preocupações**|
||Kanovský,<br>2009<sup>84</sup>|Baixo|Alto<sup>n</sup>|Baixo|Algumas<br>preocupações<sup>n</sup>|Algumas<br>preocupações<sup>f</sup>|**Alto**|
||Gracies, 2015<br>28|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Bakheita, 2000<br>5|Alto<sup>k</sup>|Alto<sup>l</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Kong, 2004<sup>8</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Bhakta, 2000<sup>16</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||McCrory, 2009<br>13|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|MEMBRO|Diniz, 2021<sup>30</sup>|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|**Algumas**<br>**preocupações**|
|S<br>INFERIOR|Dunne, 2012<sup>31</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|ES|Kaji, 2010<sup>48</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|  
||Maanum, 2011<br>42|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|---|---|---|---|---|---|---|---|
||Pittock, 2003<sup>33</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Gusev, 2008<sup>38</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
||Wein, 2018<sup>35</sup>|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
||Napoli, 2018<br>32,37|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>j</sup>|Baixo|Baixo|Baixo|**Algumas**<br>**preocupações**|
||Hyman, 2000<br>39|Alto<sup>k</sup>|Algumas<br>preocupações<sup>f</sup>|Baixo|Algumas<br>preocupações<sup>f</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
||Masakado,<br>2020<sup>43</sup>|Alto<sup>k</sup>|Alto<sup>l</sup>|Alto<sup>m</sup>|Algumas<br>preocupações<sup>l</sup>|Baixo|**Alto**|
|MEMBRO<br>S|Jacobson, 2021<br>44|||||||
|SUPERIOR<br>ES +||Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|INFERIOR<br>ES||||||||
|**Qualidade d**|**e vida - SF36**|||||||
|MEMBRO<br>S|Childers, 2004<br>24|Baixo|Baixo|Algumas<br>preocupações<sup>c</sup>|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|
|SUPERIOR<br>ES|Gracies, 2015<br>28|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|MEMBRO<br>S|Maanum, 2011<br>42|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|  
|INFERIOR<br>ES|Napoli, 2018;<br>Gracies, 2017<br>32,37|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>j</sup>|Baixo|Baixo|Baixo|**Algumas**<br>**preocupações**|
|---|---|---|---|---|---|---|---|
|**Qualidade d**|**e vida - EQ-5D**|||||||
|MEMBRO<br>S|Jahangir, 2007<br>29|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|SUPERIOR<br>ES|Gracies, 2015<br>28|Baixo|Baixo|Baixo|Baixo|Baixo|**Baixo**|
|MEMBRO<br>S<br>INFERIOR<br>ES|Napoli,<br>2018<sup>32,37</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>j</sup>|Baixo|Baixo|Baixo|**Algumas**<br>**preocupações**|
|**Qualidade d**|**e vida - EQ-VAS**|||||||
|MEMBRO<br>S<br>SUPERIOR<br>ES|Jahangir, 2007<br>29|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|**Qualidade d**|**e vida -****_Stroke Impa_**|**_ct Scale_ (SIS)**||||||
|MEMBRO<br>S<br>SUPERIOR<br>ES|Wolf, 2012<sup>21</sup>|Algumas<br>preocupações<sup>b</sup>|Algumas<br>preocupações<sup>a</sup>|Baixo|Algumas<br>preocupações<sup>a</sup>|Algumas<br>preocupações<sup>d</sup>|**Alto**|
|**Qualidade d**|**e vida - AQoL**|||||||
|MEMBRO<br>S<br>SUPERIOR<br>ES|McCrory, 2009<br>13|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações<sup>d</sup>|**Algumas**<br>**preocupações**|  
**a.** Sem informações detalhadas a respeito do cegamento de alguma parte envolvida; **b.** Sem detalhes sobre o processo de randomização ou sigilo de alocação; **c.** número significativo de perdas ou sem informações de motivo e a que grupo pertencia; **d.** protocolo não identificado; **e.** Sem detalhes sobre o processo de randomização ou sigilo de alocação e não apresenta informações de maneira satisfatória sobre as características basais; **f.** Ausência ou informação divergente do protocolo; **g.** Em alguns casos o cegamento poderia ser quebrado; **h.** Um recrutamento interrompido; **i.** Algumas perdas e número pequeno da amostra; **j.** Dados utilizados na análise; **k.** Ausência de informações sobre a randomização e o sigilo de alocação; **l.** Ausência de informações sobre cegamento; m. sem informações sobre todos os participantes do estudo; n. informações confusas e divergentes sobre o cegamento; **o.** Não consta o desfecho no protocolo e os que foram apresentados nas publicações não são exatamente iguais ao registrados; **p.** Forma de mensuração do desfecho; **q.** Emenda do protocolo e forma de análise diferente.  
Avaliação do risco de viés para os estudos clínicos que compararam toxina botulínica do tipo A (TBA) com placebo em crianças  
|**Estudo**|**Desfecho**|**Viés**<br>**proveniente do**<br>**processo de**<br>**randomização**<br>**(Domínio 1)**|**Viés devido a desvios da**<br>**intervenção pretendida**<br>**(Domínio 2)**|**Viés devido a**<br>**dados faltantes**<br>**sobre o desfecho**<br>**(Domínio 3)**|**Viés na aferição**<br>**do desfecho**<br>(**Domínio 4**)|**Viés na seleção do**<br>**resultado a ser**<br>**relatado**<br>(**Domínio 5**)|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|**Baker 2002**<br>Justificativa para<br>classificação<br>| _Mudança no componente_<br>_dinâmico do encurtamento do_<br>_gastrocnêmio –_<br>_(eletrogoniômetro)_<br> _Evento adverso_<br> _Amplitude do movimento_<br>_passivo do tornozelo_<br> _Gross Motor Function_<br>_Measure (GMFM)_<br> _Avaliação subjetiva da_<br>_percepção do cuidador e_<br>_pesquisador sobre o benefício_<br>_do tratamento_<br> <br>|_Baixo_<br>**_Domínio 1:_**_O co_<br>_de randomização._<br>_do contratant_<br>**_D_**<br>**_Domín_**<br>|_Baixo_<br>_ntratante independente respon_<br>_Como as preparações medica_<br>_e. A geração da sequência de_<br>**_omínio 2_**_: Participantes, fami_<br>**_Domínio 3:_**_Apenas du_<br>**_io 4:_**_Desfechos avaliados de f_<br>**_Domínio 5:_**_O estudo al_<br>**_Risco_**<br>|_Baixo_<br>_sável pela preparação_<br>_mentosas eram indisti_<br>_alocação e inscrição d_<br>_liares, equipe clínica e_<br>_as perdas em 126 pac_<br>_orma igual, métodos a_<br>_ega ter um protocolo e_<br>**_de viés igual para tod_**<br>|_Baixo_<br>_do medicamento util_<br>_nguíveis, o esquema_<br>_e participantes foram_<br>_os responsáveis pelo_<br>_ientes, sendo uma an_<br>_propriados e amplam_<br>_scrito previamente, p_<br>**_os os desfechos do es_**<br>|_Algumas_<br>_preocupações_<br>_izado no estudo també_<br>_de randomização foi oc_<br>_, portanto, completam_<br>_s avaliadores foram c_<br>_terior a intervenção._<br>_ente utilizados nesse t_<br>_orém não há registro._<br>**_tudo_**<br>|_Algumas_<br>_preocupações_<br>_m produziu o esquema_<br>_ultado de todos, exceto_<br>_ente independente._<br>_egados_<br>_ipo de estudo_<br> <br>|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Bertan 2020**| _Modified Ashworth_<br>_Scale,_|_Algumas_<br>_preocupações_|_Alto_|_Algumas_<br>_preocupações_|_Baixo_|_Algumas_<br>_preocupações_|**_Alto_**|
|Justificativa para<br>classificação| _Modified Tardieu Scale_<br> _Pediatric Functional_<br>_Independence Measure_<br> _Amplitude do_<br>_movimento avaliada por_<br>_goniômetro_<br>|**_Domínio 1:_** <br>**_Domínio 2_**_: Simpl_<br>**_Domínio 4:_**_Fora_|_Os pacientes foram divididos e_<br>_aloc_<br>_es-cego (avaliadores cegados,_<br>_foi monitorada, mas não r_<br>**_Domínio 3:_**_O estudo nã_<br>_m utilizadas as escalas, métod_<br>**_Domínio 5:_**_Não há protoc_|_m 2 grupos de acordo_<br>_ação; características b_<br>_pacientes e cuidador_<br>_elata os achados; não_<br>_o faz qualquer comen_<br>_os de avaliação mais_<br>_olo de estudo. Os desf_|_com uma tabela de n_<br>_asais bem equilibrad_<br>_es não cegados), desc_<br>_descreve se houve pe_<br>_tário sobre perdas ou_<br>_utilizados nesse tipo_<br>_echos relevantes para_|_úmeros aleatórios; nã_<br>_as_<br>_reve que a adesão ao_<br>_rdas ou análise por IT_<br>_como lidar com elas._<br>_de estudo e os investig_<br>_o tema foram relatad_|_o descreve sigilo de_<br>_programa de exercícios_<br>_T._<br>_adores foram cegados._<br>_os._|  
|||_Comentário: ris_|_co de viés igual para to_|_dos os desfechos do estu_|_do._ _Não avaliamos o d_|_esfecho primário (a_|_nálise elastográfica)_|
|---|---|---|---|---|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Bjornson 2007**| _Comprimento elástico e_<br>_total da passada_|_Algumas_<br>_preocupações_|_Baixo_|_Baixo_|_Baixo_|_Algumas_<br>_preocupações_|_Algumas_<br>_preocupações_|
||_(sistema de medição de_<br>_espasticidade)_<br> _GMFM-66 e GMFM-_<br>_88"_|**_Domínio 1:_**_Embora_<br>_sendo a sequência_<br>_controle (47 I vs 25 C_<br>_disso, no grupo i_|_não deixei claro como a_<br>_entregue em envelopes l_<br>_) e mais que o dobro de_<br>_ntervenção 70.6 % do se_|_sequência de randomiz_<br>_acradas. Há quase o do_<br>_participantes nível III n_<br>_xo masculino, em contr_|_ação foi gerada, ela fo_<br>_bro de pacientes GMF_<br>_o grupo controle (25_<br>_aste com 37.5% no gru_|_i feita por um farma_<br>_CS nível I no grupo_<br>_C vs 12 I) do que no_<br>_po controle. Contud_|_cêutico e um estatístico,_<br>_intervenção do que no_<br>_grupo intervenção. Além_<br>_o, a única diferença_|
|Justificativa para<br>classificação| _Escala de Ashworth_<br> _Amplitude do_<br>_movimento passivo do_<br>_tornozelo_<br> _Canadian Occupational_<br>_Performance Measure_<br> _Goal Attainment_<br>_Scaling (GAS)_<br> <br>|**_Domínio 2_**_: os invest_<br>_interve_<br>**_Domín_**<br>|_estatisticamente_<br>_igadores, coordenadores_<br>_nção. Embora não cite u_<br>**_io 4:_**_Escalas e ferramen_<br>Risco de vié<br>|_significativa foi na frequ_<br>_do estudo, fisioterapeu_<br>_ma análise por intenção_<br>**_Domínio 3:_**_Não_<br>_tas aplicadas de maneir_<br>**_Domínio 5:_**_Não há re_<br>s considerado o mesmo<br>|_ência cardíaca de cam_<br>_tas, participantes e ava_<br>_de tratar (ITT), não h_<br>_houve perdas_<br>_a igual. Os desfechos f_<br>_gistro de protocolo._<br>para os desfechos relat<br>|_inhada (média)._<br>_liadores de resultad_<br>_á perdas ou trocas n_<br>_oram considerados_<br>ados ao lado<br>|_os estavam cegos para a_<br>_os grupos._<br>_relevantes._<br>|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Chatuverdi**<br>**2013**||_Algumas_<br>_preocupações_|_Alto_|_Baixo_|_Alto_|_Algumas_<br>_preocupações_|**_Alto_**|
|<br>||<br>**_Domí_**|**_nio 1:_**_Descreve apenas_<br>**_Domínio 2_**_: Não_|_que foi randomizado sem_<br>_há descrição de cegame_<br>|_dar detalhes sobre o_<br>_nto dos pesquisadores_<br>|<br>_método ou sigilo de_<br>_ou participantes._|_alocação._|
|Justificativa para<br>classificação| _GMFM_<br>|**_Domínio 4:_**_A GM_<br>_levando em conside_|_FM é utilizada com o o_<br>_ração a qualidade do de_|**_Domínio 3:_**_Não_<br>_bjetivo de avaliar as mu_<br>_sempenho. Contudo, co_<br>_ausência de_|_houve perdas_<br>_danças na função moto_<br>_nserva certo grau de s_<br>_cegamento._|_ra grossa sob o asp_<br>_ubjetividade que pod_|_ecto quantitativo, não_<br>_e ser influenciada pela_|
|||**_Domínio 5:_**_Não há_|_registro de estudo, apes_|_ar disso a GMFM é um_|_a medida amplamente_|_utilizada em estudos_|_com toxina botulínica._|  
||||**Comentário: risco de viés igual p**|**ara todos os desfechos**|**do estudo**|
|---|---|---|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**<br>**Domínio 3**|**Domínio 4**|**Domínio 5**<br>**Risco de viés geral**|
|**Copeland 2014**| _Canadian_|_Baixo_|_Baixo_<br>_Baixo_|_Baixo_|_Baixo_<br>_Baixo_|
|Justificativa para<br>classificação|_Occupational and_<br>_Performance Measure_<br>_(COPM)_<br> _Caregiver Priorities_<br>_and Child Health_<br>_Index of Life with_<br>_Disabilities_<br> _Care and Comfort_<br>_Hypertonicity_<br>_Questionnaire_<br> _Cerebral Palsy_|**_Domínio 1:_**_Geraçã_<br>_seria realizada_<br>**_Domínio 2_**_: “duplo_<br>_que realizou o pr_<br>**_Domínio 4:_**_Fora_<br>**_Domínio 5:_**|_o de sequência não descrita claramente, mas os_<br>_usando alocação oculta”, provavelmente a seq_<br>_participantes be_<br>_cego”. Pelo registro informa que participantes, c_<br>_ocedimento e, portanto, ciente das intervenções n_<br>**_Domínio 3:_**_Não houve_<br>_m utilizadas as escalas, métodos de avaliação ma_<br>_estavam_<br>_Há protocolo publicação previamente e o estudo_|_autores do estudo rela_<br>_uência foi gerada por c_<br>_m equilibradas._<br>_uidadores, profissiona_<br>_ão participou das aval_<br>_perda de seguimento_<br>_is utilizados nesse tipo_<br>_cegos_<br>_e o estudo está de acor_|_tam em seu protocolo que "a randomização_<br>_omputador. Características basais dos_<br>_is e pesquisadores foram cegados. O médico_<br>_iações. O estudo se propôs a realizar ITT_<br>_de estudo e os investigadores, cuidadores_<br>_do.  Doi: 10.1186/1471-2431-12-120_|
||_Quality of Life_|||||
||_Questionnaire for_<br>_Children_||**_Risco de viés igual para tod_**|**_os os desfechos do est_**|**_udo_**|
|| _Evento adverso_|||||  
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|**Çaglar 2019**<br>Justificativa para<br>classificação<br>| _Modified Ashworth_<br>_Scale (MAS)_<br> _Modified Tardieu Scale_<br>_(MTS)_<br> _Selective motor control_<br>_(SMC)_<br> _Goal Attainement Scale_<br>_(GAS)_<br> _GMFCS_<br>|_Algumas_<br>_preocupações_<br>**_D_**<br>**_Domínio 2_**_: Part_<br>**_Domínio 3:_**_Os d_<br>**_Domínio 4_**<br>|_Algumas preocupações_<br>**_omínio 1:_**_Detalhes sobre a ran_<br>_Discrepâncias_<br>_icipantes estavam cientes da in_<br>_ados não foram apresentados p_<br>_de MAS e Tardie_<br>**_:_**_GMFCS foi usado como medi_<br>_participantes. Ausên_<br>**_Domínio 5:_**_Protocolo do est_<br>**_Risco de vié_**<br>|_Alto_<br>_domização não infor_<br>_entre as característic_<br>_tervenção; fisioterape_<br>_houve perdas ou a_<br>_ara todos os grupos_<br>_u se referem. O texto_<br>_da de resultado, ao in_<br>_cia de cegamento po_<br>_udo não disponível. A_<br>**_s considerado para o_**<br>|_Alto_<br>_mados, apenas relatad_<br>_as basais não foram i_<br>_utas que aplicaram o_<br>_nálise por ITT._<br>_musculares. Não ficou_<br>_não fornece detalhes_<br>_vés de ser usado pra_<br>_r parte dos avaliadore_<br>_maioria dos resultad_<br>**_s desfechos relatados_**<br>|_Algumas_<br>_preocupações_<br>_o que foi realizada e_<br>_dentificadas_<br>_s protocolos foram ce_<br>_claro a quais múscu_<br>_sobre perdas._<br>_descrever as caracter_<br>_s dos desfechos._<br>_os relevantes foi relat_<br>**_ao lado_**<br>|**_Alto_**<br>_m bloco._<br>_gados; não descreve se_<br>_los os dados das escalas_<br>_ísticas basais dos_<br>_ado._<br>|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Delgado 2016a;**<br>**Delgado(b)**<br>**~~Tilton 2017~~**<br>**Delgado (c)**<br>**Dursun 2019**|<br> _MAS_<br> _Goal attainment scaling_<br> _Observational Gait_<br>_Scale (OGS)_|_Baixo_<br>_Baixo_|_Baixo_<br>_Baixo_|_Baixo_<br>_Baixo_|_Baixo_<br>_Baixo_|_Baixo_<br>_Alto_|_Baixo_<br>**_Alto_**|
|Justificativa para<br>classificação||**_Domínio 1_**<br>**_Domínio 3:_**_Du_|**_:_**_Não descrito claramente, ma_<br>_Características basai_<br>**_Domínio 2_**_:  Participante_<br>_zentos e quarenta e um pacient_|_s a randomização foi_<br>_s dos participantes n_<br>_s, cuidadores, pesqui_<br>_es foram randomizad_<br>_incluiu 235 pac_|_feita pelo patrocinado_<br>_ão indicam problema_<br>_sadores e demais ava_<br>_os e 226 completaram_<br>_ientes (98%)_|_r. Presumivelmente a_<br>_na randomização._<br>_liador foram cegados_<br>_o estudo; a intenção_|_locação central._<br> <br>_de tratar a população_|  
|||**_Domínio 4:_**_Foram utilizadas as escalas, métodos de avaliação mais comumente empregados, os investigadores e cuidadores foram_<br>_cegados._<br>**_Domínio 5:_**_Há registro do estudo e aparentemente está de acordo nos relatos de Delgado 2016 e Tilton 2017. Já em Dursun, os autores_<br>_alegam que a análise da OGS  foi pré-especificada, mas, apesar de os dados terem sido coletados durante o estudo, não foram descritos_<br>_como desfecho no protocolo e parte dos achados trata-se de uma análise post-hoc. Adicionalmente, os autores especificaram o item 2 da_<br>_OGS (contato inicial do pé) como o item clinicamente mais relevante para crianças ambulatoriais com deformidade dinâmica do pé_<br>_equino, de acordo com critérios próprios._<br>**_Risco de viés considerado para os desfechos relatados ao lado_**<br>**_(a, b e c)_**_Os estudos de Tilton 2017 e Dursun 2019 são análises secundárias de dados do estudo de Delgado (NCT01249417). O estudo_<br>_de Dursun incluiu dados de uma fase open-label do estudo original (NCT01251380), os dados de tal fase não foram considerados na_<br>_presente análise._<br> <br> <br> <br> <br> <br>|
|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**<br>**Domínio 2**<br>**Domínio 3**<br>**Domínio 4**<br>**Domínio 5**<br>**Risco de viés geral**|
|**El-Etribi 2004**|•_Escala de Ashworth_<br>_modificada_|_Algumas_<br>_preocupações_<br>_Algumas preocupações_<br>_Baixo_<br>_Alto_<br>_Algumas_<br>_preocupações_<br>**_Alto_**|
||_• Physician Rating Scale_<br>_modificada_<br>_• Amplitude do_|**_Domínio 1:_**_Descreve apenas que foi randomizado, não aborda sigilo de alocação. Não fornece detalhes (características basais) dos_<br>_participantes, apenas idade e sexo._<br>**_Domínio 2_**_: Não há descrição de cegamento dos pesquisadores ou participantes, não relata ITT, mas não houve perda de seguimento ou_|
|Justificativa para<br>classificação|_movimento do tornozelo_|_desvio das atribuições dos participantes._<br>**_Domínio 3:_**_Não houve perdas_<br>**_Domínio 4:_**_As escalas utilizadas estão de acordo com o considerado relevante nesse tipo de estudo, contudo, as análises realizadas_<br>_conservam um grau de subjetividade que pode ser sido influenciado pela ausência de cegamento._<br>**_Domínio 5:_**_Não há registro de estudo, as medidas de desfecho são relevantes para o tema._|
|||**_Risco de viés considerado para os desfechos relatados ao lado_**|  
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|**Ibrahim 2007**|•_Índice de Espasticidade_<br>_Composto:_|_Algumas_<br>_preocupações_|_Algumas preocupações_|_Baixo_|_Alto_|_Algumas_<br>_preocupações_|**_Alto_**|
|_Justificativa_<br>_para_<br>_classificação_|_* Escala de Ashworth_<br>_modificada obtida para o_<br>_quadril_<br>_e_<br>_tornozelo_<br>_(escala original de 0 a 4_<br>_com nota +1 foi ajustado_<br>_para dar uma pontuação_<br>_de 0 a 5)_<br>_* As pontuações foram_<br>_somadas,_<br>_dando_<br>_um_<br>_índice de 0 a 10_<br>_• Principais parâmetros_<br>_de marcha_|**_Domínio 1:_**_De_<br>**_Domínio 2_** <br>**_Domínio 4:_**_A_|_screve apenas que foi randomiza_<br>_característic_<br>_: Não há descrição de cegamento_<br>_s escalas utilizadas estão de aco_<br>_conservam um grau de subje_<br>**_Domínio 5:_**_Não há registro de_<br>**_Risco de vié_**|_do por meio de núme_<br>_as basais dos partici_<br>_dos pesquisadores o_<br>_atribuições dos_<br>**_Domínio 3:_**_Não_<br>_rdo com o considerad_<br>_tividade que pode ser_<br>_estudo, as medidas d_<br>**_s considerado para o_**|_ros retirados de em u_<br>_pantes estão bem equ_<br>_u participantes, não_<br>_participantes._<br>_houve perdas._<br>_o relevante nesse tip_<br>_sido influenciado pel_<br>_e desfecho escolhidas_<br>**_s desfechos relatado_**|_m chapéu, não abord_<br>_ilibradas._<br>_houve perda de segui_<br>_o de estudo, contudo,_<br>_a ausência de cegam_<br>_são relevantes para_<br>**_s ao lado_**|_a sigilo de alocação. As_<br>_mento ou desvio das_<br>_as análises realizadas_<br>_ento._<br>_o tema._|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Karnovsky**<br>**2004**| _Índice de Espasticidade_<br>_Composto:_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|_Algumas_<br>_preocupações_|**_Algumas_**<br>**_preocupações_**|
|_Justificativa_<br>_para_<br>_classificação_| _Escala de Ashworth_<br>_modificada obtida para_<br>_o quadril e tornozelo_<br>_(escala original de 0 a 4_<br>_com nota +1 foi_<br>_ajustado para dar uma_<br>_pontuação de 0 a 5)_|**_Domínio 4:_**_As e_|**_Domínio 1:_**_S_<br>**_Dom_**<br>_scalas utilizadas estão de acord_<br>**_Domínio 5:_**_Não há registro de_<br>**Risco de vié**|_equência gerada por_<br>**_ínio 2_**_: Participantes_<br>**_Domínio 3:_**_Não_<br>_o com o considerado_<br>_os partici_<br>_estudo, as medidas d_<br>**s considerado para**|_computador e alocaç_<br>_e avaliadores cegado_<br>_houve perdas._<br>_relevante nesse tipo d_<br>_pantes._<br>_e desfecho escolhidas_<br>**os desfechos relatado**|_ão central._<br>_s._<br>_e estudo e foram feita_<br>_são relevantes para_<br>**s ao lado**|_s igualmente para todos_<br>_o tema._|  
|| _As pontuações foram_<br>_somadas, dando um_<br>_índice de 0 a 10_<br> _Principais parâmetros_<br>_de marcha_<br>||<br>|<br>||
|---|---|---|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**<br>**Domínio 3**|**Domínio 4**<br>**Domínio 5**|**Risco de viés geral**|
|**Kim 2018**||_Baixo_|_Baixo_<br>_Baixo_|_Baixo_<br>_Baixo_|**_Baixo_**|
|| Alteração média em<br>relação ao basal na|**_Domínio 1:_**_Um_|_esquema de randomização centralizada foi realiz_<br>_sugerem problemas co_|_ado pelo patrocinador. As características d_<br>_m a randomização._|_os participantes não_|
||escala de Ashworth<br>modificada-Bohannon<br>(MAS-B)|**_Domínio 2_**_: Os pac_<br>_O RIM não est_<br>_populações serão_|_ientes e todo o pessoal do local, com exceção do re_<br>_eve envolvido em nenhum procedimento do estudo_<br>_utilizadas na análise estatística: população de segu_|_constituidor independente de medicamento_<br>_além da preparação e controle logístico do_<br>_rança (referente ao tratamento recebido) e_|_s (RIM), foram cegados._<br>_medicamento. Duas_<br>_população de intenção_|
|Justificativa para| Impressão Clínica<br>||_de tratar modifi_|_cada (mITT)._||
|classificação|Global  (CGI)|**_Domínio_**|**_3:_**_Oito pacientes (2,1%) suspenderam o acompanh_|_amento e os números foram equilibrados en_|_tre os grupos._|
|| Goal Attainment||**_Domínio 4: métodos de mensuração adequad_**|**_os, participantes e pesquisadores cegados_**||
||Score (GAS) (semana|**_Domínio 5:_**_Os desf_|_echos estão relatados de acordo com o registro NC_|_T01603628. Cabe ressaltar que apenas res_|_umos foram publicados,_|
||8 e 12)<br> Escala de Tardieu||_mas os resultados primários e protocolo detal_|_hado estão disponíveis no clinicaltrials.gov_||
||modificada (MTS)||**_Risco de viés considerado para os t_**|**_odos desfechos relatados ao lado_**||  
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|**Koman 1994**| _Escala de Avaliação_<br>_Médica_|_Algumas_<br>_preocupações_|_Algumas preocupações_|_Baixo_|_Baixo_|_Baixo_|**_Algumas_**<br>**_preocupações_**|
|_Justificativa_<br>_para_<br>_classificação_| _Dinamometria_<br>_computadorizada_<br>_isocinética Biodex_<br> _Avaliações_<br>_fisioterapêuticas_<br> _Avaliação dos_<br>_pais/responsáveis_|**_Domínio 1:_**_Não in_<br>**_Dom_**<br>**_Domínio 4:_**_Foram_<br>**_D_**|_forma detalhes sobre a rando_<br>**_ínio 2_**_: Estudo duplo-cego, m_<br>_utilizadas as escalas, método_<br>**_omínio 5:_**_Protocolo do estud_|_mização e ocultação._<br>_randomi_<br>_as não detalha quem_<br>**_Domínio 3:_**_Não_<br>_s de avaliação mais u_<br>_pois o texto não in_<br>_o não disponível. Par_|_As características dos_<br>_zação._<br>_foi cegado. Não relata_<br>_houve perdas._<br>_tilizados. Não ficou se_<br>_forma detalhes._<br>_ece que os resultados_|_participantes não s_<br>_análise por intençã_<br>_os avaliadores dos_<br>_relevantes foram abo_|_ugerem problemas com a_<br>_o de tratar._<br>_resultados estavam cegos_<br>_rdados._|
|| _Eventos adversos_||**_Risco de vi_**|**_és considerado para_**|**_os desfechos relatados_**|**_ao lado_**||
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Koman 2000**||_Baixo_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|**_Baixo_**|  
|| _Escala de avaliação_<br>_médica (PRS)_<br> _Amplitude de_<br>_movimento passiva do_<br>_tornozelo_|**_Domínio 1:_**_Não detalha a randomização, apenas diz que foi aleatório. Estudo multicêntrico, provável a_<br>_características dos participantes não sugerem problemas com a randomização._<br>**_Domínio 2:_**_Os participantes e a equipe estavam cegos. Não ficou claro se foi usado análise por intenção de tr_|_locação central. As_<br>_atar, mas provavelmente_|
|---|---|---|---|
|_Justificativa_<br>_para_<br>_classificação_| _Amplitude de_<br>_movimento ativa do_<br>_tornozelo_<br> _Medidas_<br>_eletrofisiológicas_<br> _Eventos adversos_<br> _Anticorpos do soro_<br>_sanguíneo_|_sim._<br>**_Domínio 3:_**_3 crianças do grupo BoNT-A e do grupo placebo perderam o acompanhamento por razões_<br>**_Domínio 4:_**_Foram empregadas as escalas, métodos de avaliação mais utilizados nesse tipo de estudo/popula_<br>_resultados estavam cegos._<br>**_Domínio 5:_**_Protocolo do estudo não disponível. Parece que os resultados relevantes foram ab_<br>_Risco de viés considerado para os todos desfechos relatados ao lado_|_não declaradas._<br>_ção e os avaliadores dos_<br>_ordados._|
|**Estudo**|**Desfecho**|**Domínio 1**<br>**Domínio 2**<br>**Domínio 3**<br>**Domínio 4**<br>**Domínio 5**|**Risco de viés geral**|
|**Love 2001**| _Amplitude de_|_Alto_<br>_Baixo_<br>_Baixo_<br>_Baixo_<br>_Baixo_|**_Alto_**|
||_movimento_<br> _Modified Tardieu Scale_<br>_(MTS)_|**_Domínio 1:_**_Geração de alocação não descrita. Sem ocultação de alocação. As características dos participante_<br>_com a randomização._<br>**_Domínio 2_**_: Sem cegamento dos participantes e equipe devido a natureza do estudo. Não ficou claro se foi usad_|_s não sugerem problemas_<br>_a análise por intenção de_|
|_Justificativa_<br>_para_<br>_classificação_| _Modified Ashworth_<br>_Scale (MAS)_<br> _Gross Motor Function_<br>_Measure (GMFM)_|_tratar._<br>**_Domínio 3:_**_Grupo BoNT-A (3 suspensos) e grupo placebo (3 suspensos). Razões não decla_<br>**_Domínio 4:_**_Foram utilizadas as escalas, métodos de avaliação mais utilizados. Não informado sobre o cegam_<br>_desfechos._|_radas._<br>_ento dos avaliadores dos_|
|| _Escala visual analógica_<br>_(satisfação)_|**_Domínio 5:_**_Protocolo do estudo não disponível. Parece que os resultados relevantes foram ab_<br>**_Risco de viés considerado para os todos desfechos relatados ao lado_**|_ordados._|  
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|**Mall 2006**| _Modified Ashworth_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|**_Baixo_**|
|Justificativa para<br>classificação|_Scale (MAS)_<br> _Amplitude de_<br>_movimento_<br> _Gross Motor Function_<br>_Measure (GMFM)_<br> _Goal Attainment Scale_<br>_(GAS)_<br> _Eventos adversos_<br>|**_Domínio 1:_**<br>**_Domínio 4:_**|_Não informa detalhes sobre a_<br>_mantida em sigilo. As carac_<br>**_Domínio 2_**_: Os participan_<br>**_Domíni_**<br> _Foram empregadas as escala_<br>**_Domínio 5:_**_Protocolo do est_|_randomização, apenas_<br>_terísticas dos participan_<br>_tes e a equipe estavam c_<br>**_o 3:_**_4 crianças perdidas_<br>_s, métodos de avaliação_<br>_udo não disponível. Par_|_que foi simples. O texto_<br>_tes não sugerem proble_<br>_egos. Foi usada anális_<br>_durante o acompanha_<br>_mais utilizados e os av_<br>_ece que os resultados r_|_informa que a lista_<br>_mas com a randomi_<br>_e por intenção de tra_<br>_mento._<br>_aliadores dos resulta_<br>_elevantes foram abor_|_de randomização foi_<br>_zação._<br>_tar._<br>_dos estavam cegos._<br>_dados._|
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|_Moore 2008_| _Gross Motor Function_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|_Baixo_|**_Baixo_**|
||_Measure (GMFM)_<br> _Eventos adversos_|**_Domínio 1:_**_Ran_|_domização realizada em bloco_<br>_da coleta de dados. A_|_s, gerada a partir de so_<br>_s características basais_|_rteio em computador. A_<br>_dos participantes estão_|_alocação não foi re_<br>_bem equilibradas._|_velada até a finalização_|
|Justificativa para<br>classificação| _Pediatric Evaluation of_<br>_Disability Inventory_<br>_(PEDI)_<br> _Mudança de peso ao_<br>_longo de 2 anos_<br>|**_Domínio 3:_**<br>**_Domínio 4_**|**_Domínio 2_**_: Participan_<br> _6 crianças perdidas para aco_<br>**_:_**_Foram utilizadas as escalas,_<br>**_Domínio 5:_**_Protocol_|_tes e equipe estavam ce_<br>_mpanhamento e 19 cria_<br>_perceberam nenhum be_<br>_métodos de avaliação_<br>_o do estudo não disponí_|_gos. Realizada analise p_<br>_nças "retiraram-se do t_<br>_nefício das injeções._<br>_mais utilizados e os ava_<br>_vel. Resultados relevant_|_or intenção de trata_<br>_ratamento durante o_<br>_liadores dos resultad_<br>_es foram relatados._|_r_<br>_estudo porque não_<br>_os estavam cegos._|
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|_Navarrete 2010_| _Gross Motor Function_|_Baixo_|_Algumas preocupações_|_Baixo_|_Baixo_|_Baixo_|**_Algumas_**<br>**_preocupações_**|
|Justificativa para<br>classificação|_Measure 88_<br> _Wee Functional_<br>_Independence Measure_<br>|**_Domínio 1:_**_De_<br>_geração da sequ_|_screve apenas que a randomiz_<br>_encia. Ocultação da alocação_|_ação foi realizada em b_<br>_feita por meio de envel_<br>_estão bem eq_|_locos, considerando o G_<br>_opes opacos e lacrados_<br>_uilibradas._|_MFCS, idade e sexo_<br>_. As características_|_. Porém, não detalha a_<br>_basais dos participantes_|  
|||**_Domínio 4:_**|**_Do_**<br> _Foram utiliz_<br>**_Domí_**<br>**Domínio**|**_mínio 2_**_: Não houv_<br>_adas as escalas, mé_<br>**_nio 5:_**_Protocolo do_|_e cegamento para o_<br>**_Domínio 3:_**_Não_<br>_todos de avaliação_<br>_estudo não disponí_|_s participantes e equip_<br>_houve perdas._<br>_mais utilizados e os av_<br>_vel. Resultados releva_|_e, não relata ITT._<br>_aliadores dos resulta_<br>_ntes foram relatados._|_dos estavam cegos._<br>|
|---|---|---|---|---|---|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**|**S**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Reddihough**<br>**2002**| _Modified Ashworth_<br>_Scale (MAS)_|_Algumas_<br>_preocupações_|_Baixo_|_Algumas_<br>_preocupações_|_Baixo_|_Alto_|_Baixo_|**_Alto_**|
|Justificativa para<br>classificação| _Gross Motor Function_<br>_Measure (GMFM)_<br> _Amplitude de_<br>_movimento_<br> _Eventos adversos_<br> _Percepção do cuidador_<br>_sobre o tratamento_<br> _Vulpe Assessment_<br>_Battery(VAB)_|**_Domínio 1_**<br>**_Domínio S_**_:_<br>**_Domínio 3:_**_12_<br>**_Domínio 4:_**_Fora_|**_:_**_Não informa_<br>_Número de p_<br>**_Do_**<br>_crianças perd_<br>_deixa_<br>_m utilizadas a_<br>**_Domíni_**|_detalhes sobre a a_<br>_articipantes equilib_<br>**_mínio 2_**_: Não houv_<br>_eram o acompanha_<br>_ram o estudo devid_<br>_s escalas, métodos_<br>**_o 5:_**_Não há registr_|_locação. Provavelm_<br>_rados; tempo adequ_<br>_(crossover) d_<br>_e cegamento para o_<br>_mento (7 necessitar_<br>_o à incapacidade de_<br>_de avaliação mais u_<br>_o de estudo, as med_|_ente não houve cegam_<br>_ado de washout, inter_<br>_e seis meses_<br>_s participantes e equip_<br>_am de cirurgia durant_<br>_continuar com o pro_<br>_tilizados. Porém, os a_<br>_idas de desfecho são r_|_ento devido a naturez_<br>_valo entre o primeiro_<br>_e, não relata ITT._<br>_e o período do estudo_<br>_tocolo de avaliação)_<br>_valiadores dos result_<br>_elevantes para o tema_|_a da intervenção._<br>_e segundo período_<br>_e foram retiradas, e 5_<br>_ados não estavam cegos._<br>_._|
|**Estudo**|**Desfecho**|**Domínio 1**|**Do**|**mínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|**Scholtes 2006**<br>**(a)**<br>**Scholtes 2007**| _Gross Motor Function_<br>_Measure 66_<br> _Teste de Intervalo de_|_Alto_|_Algumas_|_preocupações_|_Baixo_|_Baixo_|_Baixo_|**_Alto_**|
|Justificativa para<br>classificação|_Análise de Marcha_<br>_Visual de Edimburgo_<br>_(GAIT)_<br>_Amplitude de movimento_||**_Domínio 1:_**<br>**_Domín_**|_Randomização em_<br>_Não houv_<br>**_io 2_**_: Não houve ce_<br>**_Domí_**|_bloco gerada por c_<br>_e cegamento devido_<br>_gamento entre os gr_<br>**_nio 3:_**_Perda de segu_|_omputador feita por u_<br>_a natureza das interve_<br>_upos. Não informado_<br>_imento de uma crianç_|_m estatístico independ_<br>_nções_<br>_sobre análise por ITT._<br>_a._|_ente._<br>|  
|||**_Domínio 4:_**_For_<br>|_am utilizadas as escalas, métod_<br>_vídeo_<br>**_Domínio 5:_**_Protocolo d_<br>**_Risco de viés c_**<br>|_os de avaliação mai_<br>_estava cego, os dem_<br>_o estudo não disponí_<br>**_onsiderado para os t_**<br>|_s utilizados. Porém, apenas o avaliador da a_<br>_ais não estavam cegos._<br>_vel. Resultados relevantes foram relatados._<br>**_odos desfechos relatados ao lado_**<br> <br>|_nalise de marcha por_<br>|
|---|---|---|---|---|---|---|
|**Estudo**|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**<br>**Domínio 5**|**Risco de viés geral**|
|**Steenbeek 2005**||_Alto_|_Algumas preocupações_|_Baixo_|_Baixo_<br>_Baixo_|**_Alto_**|
|**Justificativa**<br>**para**<br>**classificação**<br>| _Modified Ashworth_<br>_Scale (MAS)_<br> _Goal Attainment_<br>_Scaling (GAS) –_<br>_realizado com e sem_<br>_cegamento_<br>|**_Domínio 1:_**_Nã_<br>**_Domínio 4:_**_Fo_<br>|_o informa detalhes sobre a ran_<br>_alocação. Não id_<br>**_Domínio 2_**_: Não houve ce_<br>**_Do_**<br>_ram utilizadas as escalas, méto_<br>**_Domínio 5:_**_Protocolo d_<br>**Risco de viés co**<br>|_domização, apenas_<br>_entificado discrepân_<br>_gamento entre os gr_<br>**_mínio 3:_**_Não houve_<br>_dos de avaliação ma_<br>_estavam_<br>_o estudo não disponí_<br>**nsiderado para os**<br>|_que foi de forma aleatória. Não houve oculta_<br>_cias entre as características basais._<br>_upos. Não informado sobre análise por ITT._<br>_perda de seguimento._<br>_is utilizados nesse tipo de estudo e os avalia_<br>_cegos._<br>_vel. Resultados relevantes foram relatados._<br>**todos desfechos relatados ao lado**<br> <br>|_ção da sequencia de_<br>_dores dos resultados_<br>|
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**<br>**Domínio 5**|**Risco de viés geral**|
|_Sutherland 1999_|<sup> </sup><sup>_Análise de marcha_</sup>|_Algumas_<br>|_Algumas preocupações_|_Baixo_|_Baixo_<br>_Baixo_|**_Algumas_**<br>|
||_tridimensional_|_preocupações_||||**_preocupações_**|
|**Justificativa**<br>**para**<br>**classificação**|<br> _Dorsiflexão dinâmica_<br>_do tornozelo_<br> _Parâmetros de tempo ‐_<br>_distância_<br> _Eletromiografia_<br>_dinâmica_<br> _Dorsiflexão passiva do_<br>_tornozelo_|**_Domínio 1:_**_Não_<br>**_Domínio 3:_**_Perda_<br>**_Domínio 4:_**_Fora_|_descreve detalhes da randomiz_<br>_Houve si_<br>**_Domínio 2_**_: Participa_<br>_de seguimento de 1 criança do_<br>_todas as crianças,_<br>_m utilizadas as escalas, método_<br>**_Domínio 5:_**_Protocolo d_|_ação. Apenas inform_<br>_gilo de alocação pe_<br>_ntes e equipe estava_<br>_grupo placebo. O r_<br>_porém, esse não é u_<br>_s de avaliação mais_<br>_o estudo não disponí_|_a "o procedimento de randomização foi real_<br>_la indústria patrocinadora._<br>_m cegos; não descreve análise por ITT._<br>_esultado da força dos flexores plantares não_<br>_m desfecho de interesse para revisão._<br>_utilizados nesse tipo de estudo e os investiga_<br>_vel. Resultados relevantes foram relatados._|_izado pela Allergan"._<br>_estava disponível para_<br>_dores foram cegados._|  
|| _Força do músculo_<br>_flexor plantar (não_<br>_disponível para todas as_<br>_crianças)_<br> _Eventos adversos_<br>||**_Risco de viés_**<br>|**_considerado para os todos desfechos relatad_**<br> <br>|**_os ao lado_**<br>||
|---|---|---|---|---|---|---|
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**<br>**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|_Tedroff 2010_||_Algumas_<br>_preocupações_|_Algumas preocupações_|_Baixo_<br>_Alto_|_Baixo_|**_Alto_**|
|| _Modified Ashworth_<br>_Scale (MAS)_|**_Domín_**<br>_A alocação fic_|**_io 1:_**_Randomização incluiu 2_<br>_ou oculta, somente a enferme_<br>_processo d_|_0 envelopes lacrados, divididos em blocos de_<br>_ira ajudante teve acesso as informações de a_<br>_e dispensação da toxina, se foi feito de forma_|_4, produzidos por um_<br>_locação dos paciente_<br>_oculta._|_estatístico._<br>_s. Não ficou claro o_|
|| _Amplitude do_|_Aparentemente u_|_m pequeno desequilíbrio entr_|_e os grupos toxina (n=6) e controle (n=9). O_|_diagnostico bilateral_|_foi mais predominante_|
||_movimento_|||_do que o unilateral na população estudada._|||
|**Justificativa**<br>**para**<br>**classificação**| _Gross Motor Function_<br>_Measure 66_<br> _Pediatric Evaluation of_|**_Domínio 2_**_: Pa_<br>_randomização. Nã_|_rticipantes estavam cientes so_<br>_o há informações sobre os cu_|_bre a intervenção. O texto relata que o médi_<br>_idadores e as pessoas que realizaram a inter_<br>_ITT._|_co condutor do estudo_<br>_venção. Não descreve_|_estava cego sobre a_<br>_se utilizou análise por_|
||_Disability Inventory_<br> _Gillette Gait Index_<br> _Eventos adversos_|**_Domínio 3:_** <br>**_Domínio 4:_**_Não f_|_Houve perda de seguimento d_<br>_icou claro, cita que foram rea_<br>_avaliadores da aná_<br>**_Domínio 5:_**_Protocolo_|_e uma criança, mas ela saiu do estudo antes_<br>_lizadas 3 avaliações. Nas duas primeiras não_<br>_lise de marcha 3D não tinham conhecimento_<br>_do estudo não disponível. Resultados relevan_|_de receber a primeira_<br>_houve cegamento, n_<br>_da intervenção._<br>_tes foram relatados._|_injeção de toxina._<br>_a última informa que os_|
||||**_Risco de viés_**|**_considerado para os todos desfechos relatad_**|**_os ao lado_**||  
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|_Ubhu 2000_| _Análise de marcha em_|_Baixo_|_Algumas preocupações_|_Baixo_|_Baixo_|_Baixo_|**_Algumas_**<br>**_preocupações_**|
|**Justificativa**<br>**para**<br>**classificação**|_vídeo (VGA)_<br> _Gross Motor Function_<br>_Measure (GMFM)_<br> _Dorsiflexão passiva do_<br>_tornozelo_<br> _Custo de energia_<br>_fisiológica (PCI)_|**_Domínio 1:_**_O de_<br>_o mascaram_<br>**_Domínio 2_**_:_<br>**_Domínio 4:_**_For_|_partamento de estatística produ_<br>_ento, rotulagem e dispensação_<br>_Participantes e os responsáveis_<br>**_Domíni_**<br>_am utilizadas as escalas, métod_<br>**_Domínio 5:_**_Protocolo do estu_<br>**_Risco de viés c_**|_ziu de forma indepen_<br>_dos medicamentos. N_<br>_pela intervenção est_<br>**_o 3:_**_O texto não forn_<br>_os de avaliação mais_<br>_do não disponível. A_<br>**_onsiderado para os t_**|_dente um código de r_<br>_ão identificado discr_<br>_avam cegos; não desc_<br>_ece detalhes sobre pe_<br>_utilizados nesse tipo_<br>_maioria dos resultad_<br>**_odos desfechos relata_**|_andomização. A farm_<br>_epâncias entre as car_<br>_reve se houve perdas_<br>_rdas._<br>_de estudo e os investi_<br>_os relevantes foi rela_<br>**_dos ao lado_**|_ácia do hospital assumiu_<br>_acterísticas basais._<br>_ou análise por ITT._<br>_gadores foram cegados._<br>_tado._|
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|_Xu 2006_| _• Amplitude de_<br>_movimento passiva do_|Algumas<br>preocupações|_Algumas preocupações_|_Baixo_|_Baixo_|_Algumas_<br>_preocupações_|**_Algumas_**<br>**_preocupações_**|
||_tornozelo com o joelho_<br>_estendido_|**_Domínio 1:_**_s_|_equência gerada por computad_|_or, não está claro se_<br>_participantes não i_|_ou como foi feito sigil_<br>_ndicam problema_|_o de alocação. Cara_|_cterísticas basais dos_|
|| _MAS_|**_Domínio 2_**_: part_|_icipantes e profissionais do cuid_|_ado não foram cega_|_dos, os autores do est_|_udo descrevem uma_|_avaliação cega, mas não_|
|**Justificativa**<br>**para**<br>**classificação**| _Escala de espasticidade_<br>_composta_<br> _GMFM (dimensões D e_<br>_E)_<br> _Velocidade da marcha_|_fornecem uma de_<br>_alcance_<br>**_Domínio 4:_**_Fora_<br>**_D_**|_scrição detalhada quanto aos m_<br>_desse objetivo com os desfecho_<br>_m utilizadas as escalas, método_<br>**_omínio 5_**_: o estudo não tem pro_<br>**_Risco de viés c_**|_étodos usados para_<br>_s específicos utilizad_<br>**_Domínio 3:_** <br>_s de avaliação mais_<br>_cegados, de acord_<br>_tocolo publicado, os_<br>**_onsiderado para os t_**|_mascarar os avaliado_<br>_os neste estudo. Não_<br>_sem perdas_<br>_utilizados nesse tipo d_<br>_o com o relato._<br>_desfechos de interess_<br>**_odos desfechos relata_**|_res. O contato direto_<br>_há informação sobre_<br>_e estudo e os avalia_<br>_e parecem ter sido r_<br>**_dos ao lado_**|_com a criança dificulta o_<br>_análise por ITT_<br>_dores de desfechos foram_<br>_elatados._|  
|_Estudo_|**Desfecho**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|
|_Zhu 2016_| _• Amplitude de_<br>_movimento passiva do_|_Alto_|_Alto_|_Baixo_|_Algumas_<br>_preocupações_|_Baixo_|**_Alto_**|
|**Justificativa**<br>**para**<br>**classificação**|_tornozelo com o joelho_<br>_estendido_<br> _MAS_<br> _Escala de espasticidade_<br>_composta_<br> _GMFM (dimensões D e_<br>_E)_<br> _Velocidade da marcha_|**_Domínio 1:_**_se_<br>_randomização foi_<br>**_Domínio 2_**_: particip_<br>**_Domínio 4:_**_Foram_<br>_não cegados, com_|_quência gerada por uma ta_<br>_realizado pela própria equ_<br>_sigilo de alocação._<br>_antes, profissionais do cui_<br>_utilizadas as escalas, méto_<br>_o as avaliações têm um cer_<br>**_Domínio 5_**_: nenhum_<br>_disponí_|_bela de números randô_<br>_ipe consideramos que_<br>_Características basais_<br>_dado e pesquisadores n_<br>_com as p_<br>**_Domínio 3:_** <br>_dos de avaliação mais_<br>_to grau de subjetivida_<br>_ausência de_<br>_relatório seletivo. Prot_<br>_vel em www.chictr.org._|_micos, não é descrito s_<br>_não houve sigilo de al_<br>_dos participantes não i_<br>_ão foram cegados, nã_<br>_erdas._<br>_sem perdas_<br>_utilizados nesse tipo d_<br>_de, consideramos que a_<br>_cegamento_<br>_ocolo de estudo previa_<br>_cn (ChiCTR-IPR-1500_|_igilo de alocação e c_<br>_ocação, não está clar_<br>_ndicam problema_<br>_o é descrito ITT ou co_<br>_e estudo, os avaliado_<br>_avaliação pode ter s_<br>_mente registrado e_<br>_6318)_|_omo o processo de_<br>_o se ou como foi feito_<br>_mo os autores lidariam_<br>_res de desfechos foram_<br>_ido influenciada pela_|
||||**_Risco de v_**|**_iés considerado para_**|**_os desfechos relatados_**|**_ao lado_**||  
Avaliação do risco de viés para os ECR que avaliaram baclofeno oral em adultos, considerando todos os desfechos de interesse  
|**ECR**|**Viés**<br>**proveniente do**<br>**processo de**<br>|**Viés devido a**<br>**desvios da**<br>**intervenção**<br>|**Viés devido a**<br>**dados faltantes**<br>**sobre o desfecho**|**Viés na aferição**<br>**do desfecho**|**Viés na seleção**<br>**do resultado a**<br>**ser relatado**|**Domínio S**|**Risco de viés**<br>**geral**|
|---|---|---|---|---|---|---|---|
||**randomização**|**pretendida**|**ECR com partic**<br>**Baclofeno**<br>Al|**ipantes adultos**<br>**vs placebo**<br>Al|Al|Al||
|Brar (1991)<sup>7</sup>|Alto|Alto|gumas<br>preocupações|gumas<br>preocupações|gumas<br>preocupações|gumas<br>preocupações|Alto|
|Duncan (1976)<sup>8</sup>|Alto|Alto|Algumas<br>preocupações|Baixo|Baixo|Algumas<br>preocupações|Alto|
|Feldman (1978)<sup>9</sup>|Alto|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Alto|
|Hudgson<br>(1971)<sup>10</sup>|Algumas<br>preocupações|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Alto|
|Orsnes (2000)<sup>11</sup>|Alto|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Baixo|Alto|
|Sachais (1977)<sup>12</sup>|Algumas<br>preocupações|Alto|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Não se aplica*|Alto|
|Sawa (1979)<sup>13</sup><br>|Alto|Alto|Baixo<br>**Baclofeno v**<br>|Algumas<br>preocupações<br>**s diazepam**<br>|Algumas<br>preocupações<br>|Algumas<br>preocupações<br>|Alto|
|Cartlidge<br>(1974)<sup>15</sup>|Alto|Alto|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Alto|
|From (1975)<sup>14</sup>|Algumas<br>preocupações|Alto|Baixo<br>**ECR com particip**|Algumas<br>preocupações<br>**antes pediátricos**|Algumas<br>preocupações|Baixo|Alto|  
||||**Baclofen**|**o vs placebo**||||
|---|---|---|---|---|---|---|---|
|Scheinberg<br>(2006)<sup>19</sup>|Algumas<br>preocupações|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Baixo|Alto|
|McKinlay<br>(1980)<sup>17</sup>|Alto|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|Alto|
|Lopez (1996)<sup>16</sup>|Alto|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Baixo|Alto|
|Milla (1973)<sup>18</sup>|Alto|Alto|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Alto|Alto|
||||**Baclofeno**|**vs diazepam**||||
|Goyal (2016)<sup>20</sup>|Baixo|Algumas<br>preocupações|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Não se aplica*|Alto|  
* Foi utilizado RoB 2.0 para ECR paralelos, ao invés do instrumento para ECR cruzados

---

<!-- METADADOS: doenca: Espasticidade | secao: **Resultados da avaliação da espasticidade pela escala de Ashworth** -->
|**ECR**|**Pacientes (adultos)**|**Avaliação clínica geral da**<br>**espasticidade**|**Tônus muscular**|**Discussão**|
|---|---|---|---|---|
|**Baclofeno v**|**s placebo**||||
|Brar<br>(1991)<sup>7</sup>|Esclerose múltipla<br>(n=38)|-|Proporção de melhora na<br>pontuação da escala:<br>Baclofeno: 30%<br>Baclofeno+alongamento (terapia<br>combinada): 40%<br>Placebo: 20%<br>Placebo+alongamento: 17%|A melhora apontada indicou que o tratamento<br>com o baclofeno oral e com a terapia<br>combinada (baclofeno oral + alongamento)<br>foram mais eficazes do que o placebo sozinho<br>ou com exercícios de alongamento. Duas vezes<br>mais pacientes melhoraram com a terapia<br>combinada em relação aos grupos com placebo<br>(p=0,105).|
|Hudgson<br>(1971)<sup>10</sup>|Esclerose múltipla<br>(n=18), mielopatia<br>(n=2), doença do<br>neurônio motor (n=1),<br>paraplegia espástica<br>familiar (n=1) e<br>progressiva (n=1)|**Melhora média na**<br>**pontuação da escala:**<br>Baclofeno: 1,44<br>Placebo: 0,54<br>Diferença média entre os<br>grupos: 0,90 ± 0,426<br>(p<0,05)|-|A melhora clínica da espasticidade medida<br>pela escala de Ashworth mostrou uma<br>diferença significativa favorecendo baclofeno<br>oral em relação ao placebo. Não houve<br>diferença significante se o tratamento com<br>baclofeno foi feito antes ou depois do placebo.|
|Orsnes<br>(2000)<sup>11</sup>|Esclerose múltipla<br>(n=14)|-|Média (DP) [para as articulações<br>do joelho]:|Foram identificadas tendências não<br>estatisticamente significativas de melhoria do<br>tônus muscular nos joelhos durante o|  
|**Baclofeno v**|**s diazepam**||_Antes do tratamento:_Baclofeno:<br>1,9 (1,5)<br>Placebo: 3,1 (2,1)<br>_Depois do tratamento:_Baclofeno:<br>2,8 (2,4)<br>Placebo: 3,2 (2,3)<br>p=0,33|tratamento com baclofeno oral em<br>comparação com placebo.|
|---|---|---|---|---|
|From<br>(2009)<sup>14</sup>|Esclerose múltipla<br>(n=17)|Soma das pontuações [para<br>membros inferiores]:<br>- Antes do estudo:<br>Baclofeno: 76<br>Diazepam: 80<br>- Após as 4 semanas:<br>Baclofeno: 55<br>Diazepam: 57|-|Não houve diferença estatística entre os<br>grupos na redução dos escores de<br>espasticidade para avaliação clínica dos<br>membros inferiores.|
|Cartlidge<br>(1974)<sup>15</sup>|Esclerose múltipla em<br>remissão (n=34),<br>mielopatia espondilótica<br>(n=1), paraparesia (n=2),<br>paraplegia espástica<br>hereditária (n=2) e<br>traumática (n=1)|Diferença média na melhora<br>das pontuações (DP):<br>_Dose baixa (comparando_<br>_antes e depois dessa dose):_<br>Baclofeno: 0,49 (0,163)<br>P<0,01<br>Diazepam: 0,71 (0,159)<br>P<0,001|-|Comparando as melhorias dos dois fármacos<br>durante o período de:<br>- baixa dose: a diferença não foi<br>estatisticamente significativa (P > 0.2).<br>- alta dose: a diferença de 0,2 com um erro<br>padrão de 0,311 não foi estatisticamente<br>significativa (P> 0,5).|  
_Alta dose (imediatamente após a baixa dose):_ Baclofeno: 1,31 (0,227) P<0,001 Diazepam: 1,13 (0,202) p<0,001  
DP = desvio padrão.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Resultados da avaliação da dor associada à espasticidade** -->
|**ECR**|**Pacientes (adultos)**|**Resultados/Discussão**|
|---|---|---|
|**Baclofeno vs pl**|**acebo**||
|Duncan<br>(1976)<sup>8</sup>|Esclerose múltipla (n=11) e<br>lesões da medula espinhal<br>(n=11)|Impressões subjetivas dos participantes quanto à dor associada à espasticidade: 72% daqueles que tiveram<br>melhora com baclofeno ao invés de placebo relataram redução da dor durante os espasmos.|
|Feldman<br>(1978)<sup>9</sup>|Esclerose múltipla (n=33)|Impressões dos pacientes: 10 dos 16 com espasmos dolorosos frequentes nas pernas mostraram uma redução<br>significativa na frequência destes durante os ensaios do estudo (p <0,05). Destes 10, nove estavam em uso de<br>baclofeno oral e apenas um, de placebo.|
|Sawa (1979)<sup>13</sup>|Esclerose múltipla (n=21)|Os autores informaram redução da dor com o baclofeno oral, mas sem descrição do método utilizado e dos<br>resultados.|
|Sachais<br>(1977)<sup>12</sup>|Esclerose múltipla (n=166)|**Diferença entre valores inicial e da última visita:**<br>_Avaliação neurológica da dor relacionada aos espasmos flexores:_-1,10_vs_-0,08 (p<0,001)<br>_Impressão clínica geral do médico:_-2,69_vs_-2,26 (p<0,025)<br>_Autoavaliação dos pacientes sobre as dores nos braços e pernas:_-0,08_vs_-0,12 (p=não especificado)|  
Dos resultados, houve redução estatisticamente significativa para as duas primeiras análises no grupo baclofeno. A autoavaliação dos pacientes não foi verificada a significância, tampouco diferença entre os grupos. **Baclofeno vs diazepam** Não foram identificados estudos que comparavam baclofeno oral a diazepam e avaliaram dor associada à espasticidade.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Avaliação da capacidade funcional durante as atividades de vida diária** -->
|**ECR**|**Pacientes (adultos)**|**Resultados**|**Discussão**|
|---|---|---|---|
|Brar|Esclerose múltipla|_Proporção de melhora – Baclofeno vs_|Componentes da função diária foram avaliados por escala de|
|(1991)<sup>7</sup>|(n=38)|_Baclofeno/alongamento vs Placebo vs_|autoavaliação. A dificuldade no desempenho de oito atividades|
|||_Placebo/alongamento:_|funcionais foi atribuída a uma das quatro avaliações: nenhuma,|
|||**Ambulando 100 jardas*:**|leve, moderada ou grave. A pontuação para cada atividade|
|||10%_vs_10%_vs_17%_vs_30%|funcional (deambulação de 200 jardas, subir escadas ou meio-|
|||**Subir escadas ou meio-fio:**|fio, transferência, deambular em casa, gerenciar barreiras|
|||20%_vs_23%_vs_13%_vs_7%|físicas no trabalho, realizar tarefas domésticas, vestir-se e|
|||**Atividades domésticas:**|realizar um programa de exercícios em casa) foi somada para|
|||17%_vs_23%_vs_20%_vs_23%<br>Dificuldade no desempenho: todos pacientes|obter uma medida funcional sumária, que, quando analisada,<br>indicou que nenhuma das diferenças entre os tratamentos foi<br>estatisticamente significativa.|
|||relataram pelo menos leve, sendo que 70%||
|||relataram moderada e 20%, severa. Não houve|Três áreas foram citadas como as mais problemáticas:|
|||separação entre grupos de tratamentos.|atividades domésticas, deambular 200 jardas e subir escadas,<br>cujos resultados estão ao lado.|  
|Hudgson<br>(1971)<sup>10</sup>|Esclerose múltipla<br>(n=18), mielopatia (n=2),<br>doença do neurônio<br>motor (n=1), paraplegia<br>espástica familiar (n=1) e<br>progressiva (n=1)|Treze dos 23 pacientes se sentiram melhor durante<br>o uso de baclofeno, mas em três a mobilidade<br>melhorada foi associada a maior fraqueza. Outros<br>cinco se sentiram melhor com o placebo, sendo<br>uma melhora acompanhada por aumento da<br>fraqueza. Cinco pacientes disseram que não<br>sentiram diferença entre os períodos de<br>tratamento.<br>Foi identificado que de 47% a 90% (intervalo de<br>confiança de 95%) dos participantes prefeririam o<br>baclofeno oral ao placebo.|Os resultados não foram estatisticamente significativos.|
|---|---|---|---|
|Sachais<br>(1977)<sup>12</sup>|Esclerose múltipla<br>(n=166)|_Impressão geral do médico_<sup>_1_</sup>_– Baclofeno vs_<br>_Placebo:_<br>**Andar:**2,30_vs_2,28;**Vestir ou despir:**2,11_vs_<br>2,31;**Função da bexiga:**2,02_vs_2,12;<br>**Dormindo:**2,22_vs_2,14;**Destreza geral:**2,17_vs_<br>2,19;**Fala ou mentação:**1,93_vs_2,04|Nenhuma das diferenças entre os tratamentos foi<br>estatisticamente significativa.|
|||_Autoavaliação do paciente_<sup>_2_</sup>_– Baclofeno vs_<br>_Placebo:_<br>-0,16_vs_-0,16||
|Orsnes<br>(2000)<sup>11</sup>|Esclerose múltipla<br>(n=14)|Avaliação funcional por**EDSS**e**MSIS**, mas não<br>relata os resultados.|Autores afirmaram não haver diferença estatística entre os<br>grupos para os dois métodos de avaliação.|  
EDSS = Escala de Status de Incapacidade Expandida de Kurtzke. MSIS = escala de incapacidade de esclerose múltipla. **1.** A escala utilizava de cinco pontos: marcado (5), moderado (4), leve (3), sem mudança (2) ou pior  
(1). **2.** A escala nesse caso tinha 4 pontos: indica nada ou pouco tempo (0); ocasionalmente ou parte do tempo (1); na maioria das vezes (2); e o tempo todo (3). * Na metodologia e na discussão da publicação do estudo, comenta sobre 200 jardas, mas os resultados são para 100 jardas.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Eventos adversos ao baclofeno oral** -->
|**ECR**|**Pacientes (adultos)**||**Resultados**|
|---|---|---|---|
|**Baclofeno v**|**s placebo**|||
|Duncan|Esclerose múltipla (n=11) e lesões|Vertigem: 5 vs 1|Vômito: 1 vs 0|
|(1976)<sup>8</sup>|da medula espinhal (n=11)|Nausea: 5 vs 1<br>Sonolência: 3 vs 1<br>Boca seca: 3 vs 0<br>Fraqueza: 2 vs 0|Tontura: 1 vs 1<br>Edema na perna: 1 vs 0<br>Hipotensão postural: 1 vs 0|
|Feldman<br>(1978)<sup>9</sup>|Esclerose múltipla (n=33)|Boca seca: 5 vs 1<br>Sonolência: 4 vs 4|Visão turva: 2 vs 2<br>Parestesia: 5 vs 2|
|Hudgson|Esclerose múltipla (n=18),|Náusea: 3 vs 1|Infecção do trato respiratório superior: 0 vs 1|
|(1971)<sup>10</sup>|mielopatia (n=2), doença do<br>neurônio motor (n=1), paraplegia<br>espástica familiar (n=1) e<br>progressiva (n=1)|Vertigem: 1 vs 0<br>Visão embaçada: 0 vs 1|Dor supraorbital: 1 vs 0<br>Sonolência: 1 vs 0|
|Orsnes<br>(2000)<sup>11</sup>|Esclerose múltipla (n=14)|Fadiga: 5_vs_1<br>Tontura: 3_vs_1|Diplopia diminuída: 1_vs_0<br>Mau humor: 1_vs_0|
|||Diarreia: 1_vs_1|Obstipação: 1_vs_0|
|||Sonolência: 2_vs_0|Incontinência agravada: 1_vs_0|
|||Náusea: 1_vs_0|Micção frequente: 1_vs_0|
|Sachais|Esclerose múltipla (n=166)|_1) Neurológico:_|Depressão: 4%_vs_2%|
|(1977)<sup>12</sup>||Sonolência: 70%_vs_33%<br>Vertigem: 13%_vs_10%<br>Fraqueza excessiva: 24%_vs_15%|Fraqueza excessiva, extremidades inferiores:<br>6%_vs_2%|
|||Dor de cabeça: 17%_vs_13%|_2) Gastrintestinais:_|
|||Frequência de micção: 13%_vs_0%|Náusea: 15%_vs_4%|
|||Insônia: 9%_vs_6%|Constipação: 9%_vs_4%|  
||||Vômito: 2%_vs_0%|
|---|---|---|---|
|Sawa|Esclerose múltipla (n=21)|**Pelo menos 1 evento adverso**: 71%_vs_19%|Fraqueza aumentada: 14% (18; moderada a|
|(1979)<sup>13</sup><br>**Baclofeno v**<br>|**s diazepam**<br>|**Eventos adversos com o baclofeno**(duração média<br>em dias; gravidade):<br>_1) Neurológico:_<br>Sedação: 29% (15; leve a severa)<br>Dor de cabeça: 14% (6; severa)<br>Mudanças de humor – euforia: 10% (9; leve a<br>moderada)<br>Mudanças de humor – depressão: 10% (9; severa)<br>Tontura: 10% (16; leve)<br>Perturbação do equilíbrio: 10% (6; moderada a<br>proibitiva)<br>|proibitiva)<br>_2) Gastrointestinais:_<br>Náusea: 24% (8; leve a proibitiva)<br>Vômito: 10% (5; moderada)<br>Diarreia: 5% (14; sem relato)<br>Dor abdominal: 10% (5; moderada a<br>proibitiva)<br>_3) Outros:_<br>Mal-estar geral: 10% (14; moderada)<br>Boca seca: 5% (16; moderada)<br>Ganho de peso: 5% (21; severa)<br>|
|From<br>(2009)<sup>14</sup>|Esclerose múltipla (n=17)|Sedação: 5 vs 11<br>Depressão: 2 vs 0<br>Confusão: 0 vs 1<br>Euforia: 1 vs 1<br>Vertigem: 1 vs 1|Náusea: 2 vs 0<br>Dor de cabeça: 1 vs 0<br>Diarreia: 1 vs 0<br>Fraqueza: 3 vs 2|
|Cartlidge|Esclerose múltipla em remissão|_Baixa dose_|_Alta dose_|
|(1974)<sup>15</sup>|(n=34), mielopatia espondilótica<br>(n=1), paraparesia (n=2), paraplegia<br>espástica hereditária (n=2) e<br>traumática (n=1)|Sedação sozinha:  6_vs_5<br>Sedação associada a outros efeitos: 3_vs_5<br>Fraqueza:  2_vs_6<br>Outros EAM (total): 19_vs_21<br>Retirada do estudo: 0_vs_0|Sedação sozinha: 5_vs_4<br>Sedação associada a outros efeitos: 1_vs_6<br>Fraqueza: 4_vs_6<br>Outros EAM (total): 22_vs_23<br>Retirada do estudo: 11_vs_14|

---

<!-- METADADOS: doenca: Espasticidade | secao: **Resultados da avaliação da espasticidade pela escala de Ashworth** -->
|**ECR**|**Pacientes**<br>**(adultos)**|**Avaliação clínica geral da**<br>**espasticidade**|**Tônus muscular**|**Discussão**|
|---|---|---|---|---|
|**Baclofeno vs**|**placebo**||||
|McKinlay<br>(1980)<sup>17</sup>|Paralisia<br>cerebral (n=20)|-|Os fisioterapeutas relataram redução do<br>tônus muscular ou melhor movimento em 19<br>pacientes durante o estudo: 14 em uso de<br>baclofeno; cinco, de placebo; e um não<br>apresentou alterações (p = 0,064).|Apesar dos resultados, os autores<br>indicaram não haver mudança<br>significativa entre baclofeno e<br>placebo para tônus muscular.|
|Lopez<br>(1996)<sup>16</sup>|Paralisia<br>cerebral (n=20)|-|**Proporção de pacientes em cada grau da**<br>**escala de Ashworth após intervenções**<br>**(baclofeno****_vs_ placebo) e no estágio basal**<br>**(terceiro valor):**<br>Grau 1: 0%_vs_0%_vs_0%<br>Grau 2: 50%_vs_5%_vs_0%<br>Grau 3: 45%_vs_55%_vs_45%<br>Grau 4: 5%_vs_40%_vs_50%<br>Grau 5: 0%_vs_0%_vs_5%|Todos os pacientes apresentaram<br>escores ≥ 3, que não se alteraram com<br>o placebo, mas diminuíram<br>significativamente durante o<br>tratamento com baclofeno, tendo 10<br>casos com tônus baixo (escore 2) (p<br><0,05) ao final.|
||||Basal-placebo: p = não significante<br>Basal-baclofeno: p<0,01<br>Baclofeno-placebo: p<0,05||
|Milla<br>(1973)<sup>18</sup>|Paralisia<br>cerebral além de<br>diplegia,|**Quantidade de pacientes que:**<br>**-**apresentaram melhora:<br>14 (p<0,001)_vs_2 (p=0,25)|-|Considerando a gravidade da<br>espasticidade, os pacientes de 2 a 7<br>anos geralmente melhoraram em uma|  
||hemiplegia ou<br>tetraplegia<br>(n=20)|- melhoraram mais de uma<br>categoria da escala: 5_vs_0|ou mais categorias na escala de<br>Ashworth, enquanto os mais velhos<br>(de 7 e 16 anos) melhoraram<br>ligeiramente ou nada. No entanto, a<br>diferença não é estatisticamente<br>significativa entre os grupos<br>baclofeno e placebo.|
|---|---|---|---|
|**Baclofeno v**|**s diazepam**|||
|Goyal<br>(2016)<sup>20</sup>|Paralisia<br>cerebral (n=67)|**Pré-tratamento**<br>1,84 ± 0,64 (IC: 1,60 a 2,08)_vs_<br>1,96 ± 0,40 (IC: 1,78 a 2,15)<br>p=0,28<br>**1 mês**<br>1,84 ± 0,64 (7IC: 1,60 a 2,08)_vs_<br>1,63 ± 0,40 (IC: 1,48 a 1,79)<br>p=0,22<br>**3 meses**<br>1,31±0,48 (IC: 1,13 a 1,50)_vs_<br>1,41±0,36 (IC: 1,28 a 1,55)<br>p=0,22|-<br>Tanto diazepam quanto baclofeno<br>foram eficazes em tratar a<br>espasticidade na paralisia cerebral,<br>mas não houve diferença significativa<br>entre eles.|  
DP = desvio padrão. IC = intervalo de confiança.

---

<!-- METADADOS: doenca: Espasticidade | secao: **Avaliação da capacidade funcional durante as atividades de vida diária** -->
|**ECR**|**Pacientes**|**Resultados**|**Discussão**|
|---|---|---|---|
||**(crianças)**|||  
|Lopez|Paralisia|_Escala aplicada aos responsáveis dos pacientes:_|As alterações coincidiram com os participantes que tiveram a|
|---|---|---|---|
|(1996)<sup>16</sup>|cerebral<br>(n=20)|Observadas alterações favoráveis em 9 pacientes na<br>fase de baclofeno e em 3 na de placebo.|espasticidade diminuída. As mudanças consistiram em maior<br>facilidade nos alongamentos e nas trocas de roupas, mais mobilidade<br>espontânea e um pequeno aumento da autonomia para se alimentar.|
|McKinlay<br>(1980)<sup>17</sup>|Paralisia<br>cerebral<br>(n=20)|Não identificados.|Segundo os autores, por exames clínicos, não houve benefício por<br>baclofeno nas atividades funcionais das crianças. Professores e pais,<br>porém, comentaram que elas tiveram efeitos positivos com o<br>fármaco, apesar do estudo indicar não ter ocorrido mudança no<br>aprendizado em sala de aula ou na caligrafia.|
|Scheinberg|Paralisia|**Escala GAS**(baclofeno_vs_placebo):|Para GAS, a mudança na escala favoreceu baclofeno em relação ao|
|(2006)<sup>19</sup>|cerebral<br>(n=15)|6,6 (IC: 1,0 a 12,3); p=0,05<br>**Escala PEDI**(baclofeno_vs_placebo):<br>_Auto-cuidado:_−1,5 (IC: −3,5 a 0,6); p=0,21<br>_Mobilidade:_−1,5 (IC: −3,1 a 0,2); p=0,08<br>_Função social:_−0,2 (IC: −3,0 a 2,6); p=0,96|placebo e o resultado foi significativo. Por outro lado, para PEDI, os<br>resultados não foram estatisticamente significativos para nenhum dos<br>itens (auto-cuidado, mobilidade, função social).|  
GAS: _Goal Attainment Scaling_ . PEDI: _Pediatric Evaluation of Disability Inventory_ .

---

<!-- METADADOS: doenca: Espasticidade | secao: **Eventos adversos** -->
|**ECR**|**Pacientes (adultos)**||**Resultados**|
|---|---|---|---|
|**Baclofeno vs**|**placebo**|||
|Scheinberg|Paralisia cerebral (n=15)|Letargia: Z_vs_Z|Sonolência: Z_vs_0|
|(2006)<sup>19</sup>||Constipação: Z_vs_Z|Hipotonia: 0_vs_Z|
|||Convulsões: Z_vs_Z|Dificuldade em urinar: 0_vs_Z|
|||Baixo apetite: Z_vs_0||  
|McKinlay|Paralisia cerebral (n=20)|**Relato de EAs pelos pais das crianças**(sem di|stinção se ocorrência entre os grupos): sonolência|
|---|---|---|---|
|(1980)<sup>17</sup>||(n=5), mal-estar (n=2), tontura (n=2), enurese n<br>fala arrastada (n=2) e fraqueza (n=1).|oturna (n=2), estados de ausência epileptiforme (n=2),|
|||**Relato de EAs pelos terapeutas e professores**|(para baclofeno)**:**sonolência (n=12)|
|Lopez<br>(1996)<sup>16</sup>|Paralisia cerebral (n=20)|Náusea e vômito: 3_vs_0||
|Milla<br>(1973)<sup>18</sup>|Paralisia cerebral além de diplegia,<br>hemiplegia ou tetraplegia (n=20)|Sonolência/sedação: 4_vs_0<br>Hipotonia: 3_vs_0||
|**Baclofeno vs**|<br>**diazepam**|||
|Goyal|Paralisia cerebral espástica (n=67)|**1 mês**|**3 meses**|
|(2016)<sup>20</sup>||Sonolência: 6 (20%) vs 9 (30%)<br>Fraqueza: 2 vs 3|Sonolência: 1(3,33%) vs 3 (10%)<br>Fraqueza: 2 vs 1|
|||Frequência em urinar: 3 vs 3<br>Dor de cabeça: 2 vs 2<br>Constipação: 0 vs 2|Frequência em urinar: 1 vs 1<br>Dor de cabeça: 0 vs 1<br>Constipação: 1 vs 0|
|||Salivação: 0 vs 1<br>Ataxia: 0 vs 1|Salivação: 0 vs 3<br>Ataxia: 0 vs 0|
|||Náusea: 2 vs 0|Náusea: 0 vs 0|
|||Mudanças de comportamento: 0 vs 0|Mudanças de comportamento: 1 vs 0|
|||Parestesia: 1 vs 0|Parestesia: 0 vs 0|
|||Urticaria: 1 vs 1|Urticaria: 0 vs 0|

---

