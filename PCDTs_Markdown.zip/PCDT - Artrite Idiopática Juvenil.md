<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SCTIE Nº 34, DE 19 DE JANEIRO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Artrite Idiopática Juvenil.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Considerando a necessidade de se atualizarem os parâmetros sobre a Artrite Idiopática Juvenil no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1020/2025  e o Relatório de Recomendação nº 1022/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Artrite Idiopática Juvenil.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Artrite Idiopática Juvenil, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Artrite Idiopática Juvenil.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta nº 16, de 3 de setembro de 2021 , publicada no Diário Oficial da União (DOU) nº 172, em 10 de setembro de 2021, seção 1, página 107.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A artrite Idiopática Juvenil (AIJ) é a denominação escolhida pela Liga Internacional de Associações de Reumatologia ( _International League of Associations for Rheumatology_ - ILAR) para definir um grupo heterogêneo de doenças autoimunes caracterizadas pela presença de artrite crônica (com duração maior do que seis semanas), de origem desconhecida e que se inicia antes dos 16 anos de idade. Esta classificação, proposta no fim do século XX e início do século XXI<sup>1</sup> , teve como objetivo principal organizar as diferentes formas de apresentação das doenças que cursam com artrite crônica na infância, facilitando a execução e interpretação de pesquisas básicas e clínicas<sup>2</sup> ). Atualmente, esta classificação está passando por um processo de revisão pela _Pediatric Rheumatology International Trials Organization_ (PRINTO). Esta proposta perpassa desde a definição da doença, com sugestão de início de manifestação dos sintomas até 18 anos, até os diferentes subtipos de AIJ. Com base em critérios clínicos e laboratoriais, o grupo busca identificar grupos clinicamente homogêneos e diferenciar formas de artrite crônica observadas em crianças de doenças em população adulta com manifestação durante a infância. A proposta inicial está, no momento, passando por um processo de validação em uma coorte de pacientes com AIJ<sup>2</sup> .  
A etiologia da AIJ não é conhecida, mas provavelmente é multifatorial. O processo patológico é a inflamação crônica, na qual os sistemas de imunidade inata e adaptativa exercem um relevante papel. Dependendo do subtipo de AIJ, os mecanismos diferem, como pode ser observado pela presença ou não de auto anticorpos, fator reumatoide, associação com diferentes tipos de antígeno leucocitário humano B27 (HLA-B27), sexo e faixas etárias<sup>3</sup> .  
A AIJ é a doença reumática crônica mais comum em crianças. Inexistem estudos epidemiológicos no Brasil, mas estimase que seja tão frequente como na Europa e Estados Unidos, onde os dados mostram uma incidência entre 2 a 20/100.000 casos/ano e prevalência em torno de 16 a 150/100.000<sup>4</sup> .  
A AIJ clínica acomete pacientes de qualquer etnia, embora não existam dados fidedignos sobre as diferenças étnicas. Uma distribuição bimodal para a idade de início indica um pico em crianças com menos de cinco anos e outro no grupo de 10 a 16 anos de idade. Em análise global de todos os subtipos, o sexo feminino se mostrou mais acometido que o masculino, mas ao analisar os subtipos não houve diferença de acometimento por sexo na artrite sistêmica, enquanto na artrite relacionada a entesite o sexo masculino predominou<sup>1</sup> .  
A frequência de cada subtipo varia nas diferentes populações, e o **Quadro 1** mostra os percentuais aproximados.  
**Quadro 1 - Frequências de cada um dos subtipos de AIJ**<sup>**1**</sup> **.**  
|**Subtipos**|**Subtipos da AIJ**|**Frequência aproximada**|
|---|---|---|
|1|Artrite sistêmica|15%|
|2|AIJ poliarticular com fator reumatoide negativo|17%|
|3|AIJ poliarticular com fator reumatoide positivo|3%|
|4|AIJ oligoarticular|50%|
|5|Artrite relacionada à entesite|15%|
|6|Artrite psoríaca|5%|
|7|Artrite indiferenciada|5%|  
2  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da artrite idiopática juvenil.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
<mark>A classificação da ILAR (1997/2004) subdivide a AIJ em subtipos bem definidos, de acordo com os critérios de inclusão e exclusão observados no início da doença e um sétimo grupo, chamado de artrite indiferenciada, por não atender todos os critérios de um subtipo ou preencher critérios para mais de um subtipo</mark><sup>1</sup> <mark>. Os critérios de inclusão se encontram no</mark> **<mark>Quadro 2</mark>** <mark>. Os critérios de exclusão aplicáveis a cada subgrupo se encontram detalhados no</mark> **<mark>Quadro 3</mark>** <mark>.</mark>  
**Quadro 2 - Critérios de inclusão e exclusão na classificação dos subtipos de AIJ**<sup>**1**</sup> **.**  
|**Subtipo de AIJ**|**Critérios de inclusão**|**Critérios de**<br>**Exclusão***|
|---|---|---|
|Sistêmico|Artrite<br>Febre (> 15 dias, documentada por pelo menos 3 dias na semana)<br>Mais outra manifestação extra-articular:_rash, s_erosite, hepatomegalia,<br>esplenomegalia, linfonodomegalia generalizada|1, 2, 3, 4|
|AIJ oligoarticular|Uma a 4 articulações com artrite nos 6 primeiros meses de doença|1, 2, 3, 4, 5|
|AIJ poliarticular<br>FR positivo|Mais de 4 articulações acometidas nos primeiros 6 meses de doença<br>Fator reumatoide positivo em 2 testes com intervalo de 3 ou mais meses|1, 2, 3, 5|
|AIJ poliarticular<br>FR negativo|Mais de 4 articulações nos primeiros 6 meses (grandes e pequenas<br>articulações)<br>Fator reumatoide negativo|1, 2, 3, 4, 5|
|Artrite psoríaca|Artrite e Psoríase<br>Ou<br>Artrite e 2 dos seguintes: dactilite, alteração ungueal (pequenas depressões<br>puntiformes nas unhas ou onicólise), parente do primeiro grau com<br>psoríase|2, 3, 4, 5|
|Artrite relacionada<br>a entesite|Artrite e entesite<br>Ou<br>Artrite ou entesite + 2 dos seguintes: HLA B27 positivo, dor lombo-sacra<br>inflamatória ou dor a digito-pressão de sacroilíacas, início da artrite no<br>sexo masculino, pacientes com mais de 6 anos, uveíte anterior aguda,<br>parente de 1<sup>0</sup>. grau com doença ligada ao HLAB27: espondilite<br>anquilosante, artrite relacionada a entesite, doença intestinal inflamatória<br>com sacroiliite, artrite reativa, uveíte anterior aguda.|1, 3, 4, 5|
|Artrite indiferenciada|Pacientes que não preenchem critérios de inclusão de nenhum dos 6<br>subtipos.||  
3  
|**Subtipo de AIJ**|**Critérios de inclusão**|**Critérios de**<br>**Exclusão***|
|---|---|---|
||Ou||
||Pacientes que preenchem critérios para mais de um dos 6 subtipos||  
* Listados no **Quadro 3** .  
**Quadro 3 - Critérios de exclusão dos subtipos de AIJ segundo a ILAR**<sup>**1**</sup> **.**  
|1. Psoríase ou história de psoríase em paciente ou parente de 1º grau|
|---|
|2. Artrite com início em paciente com mais de seis anos, do sexo masculino e presença de HLA-B27|
|3. Espondilite anquilosante, artrite relacionada a entesite, sacroiliíte com artrite inflamatória intestinal, síndrome de<br>artrite reativa, uveíte anterior aguda ou história de uma dessas doenças em um parente de 1<sup>o</sup>grau|
|4. Presença de fator reumatoide IgM em duas ocasiões, com intervalo superior a 3 meses|
|5. Presença de artrite sistêmica no paciente|  
Assim, em que pese a Classificação Internacional de Doenças e Problemas Relacionados à Saúde (CID) atual não utiliza a nomenclatura da ILAR, para fins de registro nos Sistemas de Infomação em Saúde serão considerados:  
- M08.0 Artrite reumatoide juvenil  
- M08.1 Espondilite anquilosante juvenil  
- M08.2 Artrite juvenil com início sistêmico  
- M08.3 AIJ poliarticular juvenil  
- M08.4 Artrite juvenil pauciarticular (ou oligoarticular)  
- M08.8 Outras artrites juvenis  
- M08.9 Artrite juvenil não especificada

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O diagnóstico precoce e a condução do tratamento adequado são essenciais para o rápido controle da inflamação, permitindo uma boa qualidade de vida e prevenção de sequelas<sup>3</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A identificação da artrite é feita em bases clínicas ao se perceber o aumento de volume articular ou a presença de dois sinais inflamatórios, tais como dor à palpação ou dor com limitação de movimentos<sup>5</sup> .  
A duração da artrite superior a seis semanas permite defini-la como artrite crônica, como é o caso da AIJ, separando-a de artrites agudas (menos de seis semanas de duração), como geralmente é observado nas artrites associadas a infecções<sup>1</sup> .  
Os pacientes com artrite crônica devem ser encaminhados a um especialista que fará o diagnóstico diferencial entre AIJ e outras doenças que cursam com sintomas articulares, tais como as doenças difusas do tecido conjuntivo, dores de origem mecânica, infecciosa ou neoplásica e síndromes de amplificação dolorosa. É importante estabelecer precocemente o diagnóstico, pois o tratamento adequado melhorará o prognóstico e diminuirá as chances de dano articular e prejuízo da função.  
O exame físico deve considerar as manifestações articulares e extra-articulares. O exame músculo-esquelético permite detectar a presença de artrite ativa, artrite inativa, mas com limitação de movimento, representando sequela articular e artrite  
4  
inativa e sem sequelas. As manifestações extra-articulares dependem do subtipo de AIJ e incluem principalmente: psoríase, uveíte anterior, febre, erupção cutânea, serosite, esplenomegalia ou linfadenopatia generalizada.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O subtipo de início sistêmico é o mais grave e apresenta características que lembram as doenças autoinflamatórias, com grande participação do sistema de imunidade inata. No início da doença, predominam a febre e outras manifestações sistêmicas e, em cerca de 10% dos pacientes, a artrite terá início tardio, surgindo após algumas semanas ou meses das manifestações sistêmicas<sup>1</sup> .  
Este subtipo apresenta maiores possibilidades de complicações fatais, como a síndrome de ativação macrofágica (SAM), que ocorre em 10% dos casos<sup>1</sup> . O tratamento é diferente e deve ser instituído rapidamente. Clinicamente se caracteriza por febre geralmente persistente, organomegalia, disfunção do sistema nervoso central, sintomas hemorrágicos e, laboratorialmente, por queda da velocidade de hemossedimentação, citopenia, hipofibrinogenemia e aumento da ferritina, enzimas hepáticas, desidrogenase lática, D-dímeros, triglicerídeos e prolongamento do tempo de protrombina e do tempo parcial da tromboplastina. Observa-se aumento de citocinas pró-inflamatórias como IL-6 e TNF-alfa<sup>6-8</sup> . A SAM é uma complicação que evolui rapidamente, e o paciente pode não apresentar os critérios diagnósticos no início. É necessário que o paciente seja acompanhado com exames frequentes para que o tratamento correto seja realizado a tempo, pois trata-se de uma complicação grave que pode ser fatal em 6%-8% dos casos.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A AIJ oligoarticular se caracteriza pela presença de artrite em uma a quatro articulações, nos primeiros seis meses de doença. Se após este período, o número de articulações acometidas ultrapassar cinco, será denominada como AIJ oligoarticular estendida; se permanecer com menos de cinco articulações, será denominada de AIJ oligoarticular persistente<sup>1</sup> .  
A AIJ oligoarticular é o subtipo mais comum e benigno, compreendendo 50% dos casos de AIJ, tendo predomínio em crianças pré-escolares e no sexo feminino<sup>1</sup> .  
A principal complicação extra-articular deste subtipo de AIJ é a Uveíte Anterior Crônica (UAC), uma condição assintomática, que pode levar a cegueira se não diagnosticada e tratada adequadamente<sup>1</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A AIJ poliarticular é definida pela presença de artrite em cinco ou mais articulações, nos primeiros seis meses da doença. Os casos que cursam com AIJ poliarticular e fator reumatoide (FR) positivo têm as mesmas características clínicas, laboratoriais e associações genéticas da artrite reumatoide de adultos. Para classificação desse subtipo de AIJ se faz necessário que o FR tenha resultado positivo em duas análises, com intervalo mínimo de três meses<sup>1</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A AIJ poliarticular com FR negativo acomete cinco ou mais articulações e pode evoluir como uma forma exacerbada e  
mais grave da AIJ oligoarticular, inclusive com risco de UAC<sup>1</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A artrite relacionada a entesite é o subtipo que tem forte associação com o antígeno HLA B27 e pode evoluir como uma espondiloartrite. O diagnóstico é feito na presença de artrite associada a entesite ou, na falta de um deles, seria necessário detectar mais dois dos seguintes critérios<sup>1</sup> :  
- HLA B27 positivo;  
- dor lombo-sacra inflamatória ou dor a digito-pressão de sacroilíacas;  
- início da artrite no sexo masculino;  
5  
- pacientes com mais de seis anos;  
- uveíte anterior aguda;  
- parente de primeiro grau com doença associada ao HLAB27 tais como: espondilite anquilosante, artrite relacionada a entesite, doença intestinal inflamatória com sacroiliíte, artrite reativa, uveíte anterior aguda.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A artrite psoríaca é rara e pode ser diagnosticada na presença de artrite e psoríase, mas também na ausência de psoríase, se o paciente apresentar, além da artrite, duas das três outras características que costumam estar presentes na artrite psoríaca: dactilite, alterações ungueais típicas da psoríase e um parente de primeiro grau com psoríase<sup>1</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O termo “artrite indiferenciada” é reservado para os pacientes com quadros incompletos que não preenchem os critérios de inclusão para nenhum dos seis subtipos descritos acima, assim como para aqueles que apresentam características de mais de um dos subtipos<sup>1</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Os exames laboratoriais para o diagnóstico de AIJ incluem basicamente o hemograma e testes que avaliam a presença de inflamação, como a determinação da velocidade de hemossedimentação (VHS) e a dosagem de proteína C reativa (PCR).  
Os testes imunológicos como a determinação de FR e a detecção do HLA B27 ajudam na separação de subtipos de AIJ e a identificação de fator antinuclear (FAN), na avaliação do risco de uveíte.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Os exames de imagem podem confirmar a presença de artrite, mas geralmente não são necessários.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Serão incluídos neste Protocolo pacientes com diagnóstico de Artrite Idiopática Juvenil (códigos da CID-10: M08.0, M08.1, M08.2, M08.3, M08.4, M08.8 e M08.9) de qualquer idade, de ambos os sexos, seja em forma de início recente ou estabelecida, independentemente da atividade da doença.  
Considerando o seu desabastecimento, adicionalmente, para o **início** de tratamento com abatacepte, é necessário que o  
paciente tenha **menos de 18 anos** e apresente ao menos um dos critérios a seguir:  
- Artrite Idiopática Juvenil oligoarticular estendida ou poliarticular ou sistêmica **e** que apresentaram toxicidade ou falha  
- terapêutica ao uso de dois MMCDb;  
- Artrite Idiopática Juvenil sistêmica  
- Qualquer subtipo de AIJ com uveíte ativa refratária ou intolerante a três imunobiológicos (2 MMCDb anti-TNF-alfa **e**  
- tocilizumabe);  
- Ter apresentado evento adverso grave a algum MMCDb anti-TNF-alfa **e** ao tocilizumabe;  
- Apresentar contraindicação ou hipersensibilidade ao uso de MMCDb anti-TNF-alfa **e** tocilizumabe.  
Nota: Essa recomendação poderá ser revisada futuramente, conforme a regularização do fornecimento do medicamento ao Ministério da Saúde.  
6

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Serão excluídos para o uso de algum medicamento preconizado neste Protocolo os pacientes que, respectivamente, se enquadrarem na condição de contraindicação absoluta.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A conduta terapêutica orientada para um alvo (“ _treat to target_ ”) adotada na Artrite Reumatoide também tem sido usada na AIJ. Basicamente consiste em estabelecer um alvo, utilizar instrumentos de avaliação capazes de medir a resposta terapêutica e estabelecer um fluxograma de tratamento. O tratamento ideal deve ser precoce e individualizado, isto é, centrado nas necessidades de cada paciente. É importante que as decisões sobre o tratamento sejam decisões compartilhadas entre o médico e a família ou o paciente com capacidade de compreender e tomar decisões, o que certamente aumentará a adesão ao tratamento<sup>9,10</sup> .  
Os alvos são estabelecidos de acordo com o tempo de tratamento e avaliados a cada consulta programada com o objetivo de avaliar a eficácia, a segurança e adesão ao tratamento, permitindo ajustes de doses de acordo com as necessidades do paciente. Nestas consultas são empregados diferentes instrumentos de avaliação, que consideram as manifestações articulares, extraarticulares, exames laboratoriais e as percepções do médico, do paciente e dos familiares. A meta final será a remissão completa e sustentada da doença, prevenindo sequelas e melhorando a qualidade de vida. Em caso de AIJ sistêmica, espera-se que, além da remissão clínica e laboratorial, o paciente não esteja mais usando glicocorticoide<sup>9,10</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A equipe deve estar atenta não só ao tratamento medicamentoso, mas também às condições psicossociais da criança e da família, pois pode ser necessário indicar um atendimento psicológico<sup>4</sup> . A criança deve frequentar a escola e praticar esportes frequentemente. Deve ainda ser orientada sobre a importância de manter uma dieta saudável, para se prevenir contra a obesidade induzida pelo glicocorticoide e pela inatividade e contra a osteoporose, por isso, também deve ser orientada sobre o controle da necessidade diária de cálcio e vitamina D.  
Fisioterapia e terapia ocupacional podem ser necessárias durante alguma fase do tratamento. Atendimento odontológico também pode ser necessário, principalmente nos casos de acometimento das articulações temporomandibulares. Atualmente, com as novas modalidades de tratamento, raramente serão necessárias cirurgias ortopédicas.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A escolha do medicamento deve resultar de uma decisão compartilhada entre o médico, a família e o paciente com capacidade de compreender e tomar decisões, que devem ser esclarecidos sobre o curso e prognóstico da doença, a eficácia dos medicamentos usados durante o tratamento e as medidas de segurança para evitar efeitos adversos. Deverão ser fornecidas informações sobre as vantagens e desvantagens de cada medicamento disponível, a necessidade de se adaptar o tratamento à idade da criança e ao subtipo de AIJ, a via de administração do fármaco, e a frequência das doses, portanto, é necessário esclarecer todas as dúvidas relacionadas ao tratamento<sup>4</sup> .  
Os medicamentos foram selecionados de acordo com o subtipo de AIJ. Incluem anti-inflamatórios não esteroidais (AINE), glicocorticoides sistêmicos e de uso tópico ocular ou intra-articular, Medicamentos Modificadores do Curso de Doença (MMCD) sintéticos (metotrexato, sulfassalazina, leflunomida e ciclosporina) e MMCD biológicos (anti-TNF-alfa: etanercepte, adalimumabe e infliximabe; anti-IL6: tocilizumabe e CTLA4-Ig: abatacepte).  
7

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Os AINE não modificam o curso da doença e são usados como tratamento sintomático. Os AINE aprovados e mais comumente usados em pediatria são o naproxeno e o ibuprofeno. No SUS apenas o ibuprofeno é disponível em formulação líquida, sendo indicado para crianças de baixa idade. É opcional a associação de inibidor de bomba de prótons como o omeprazol para reduzir efeitos adversos gástricos. Não se recomenda usar AINE como monoterapia por mais de 2 meses.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A administração de glicocorticoide por via sistêmica, em altas doses, sob a forma oral ou de pulsoterapia endovenosa, deve ser reservada apenas para o controle das manifestações extra-articulares da artrite sistêmica (febre alta que não responde aos AINE, anemia grave, miocardite ou pericardite) e complicações como a SAM<sup>11-13</sup> . Apesar do rápido efeito anti-inflamatório e imunossupressor, os glicocorticoides não devem ser mantidos por longos períodos devido aos seus graves efeitos adversos<sup>11-</sup> 14.  
Uma indicação excepcional de glicocorticoide por via sistêmica, apenas por curto período (menos de 3 meses), seria em casos graves de AIJ poliarticular que não podem aguardar algumas semanas pelo efeito dos MMCD. Nestes casos, enquanto se aguarda o efeito terapêutico de um MMCD iniciado recentemente, um curto período de prednisona ou prednisolona em dose baixa (0,2 - 0,5 mg/kg/dia) pode ser considerado (15).

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A aplicação de glicocorticoide intra-articular é uma forma especial de dose alta (de ação local) muito empregada na AIJ. É bastante eficaz na maioria dos casos, proporcionando alívio rápido dos sintomas, principalmente na AIJ oligoarticular, evitando-se o uso de terapia sistêmica. Múltiplas infiltrações podem ser feitas em um só dia, geralmente com sedação ou anestesia em crianças pequenas. As principais complicações do uso desta via são o aparecimento de atrofia do tecido subcutâneo, calcificações periarticulares, sinovite induzida por cristais e artrite séptica<sup>14,15</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Antes do início do uso dos imunomoduladores, devem-se excluir infecções graves como hepatites, HIV/Aids e tuberculose (ativa e latente), com o objetivo de adequado planejamento terapêutico e tratamento destes agravos, caso possível, antes de iniciar o mesmo. Em caso de tuberculose, ativa ou latente, devem ser seguidas as orientações do Manual de Recomendações para o Controle da Tuberculose no Brasil<sup>16</sup> . A cobertura vacinal deve ser atualizada antes do início do tratamento, para crianças e adultos<sup>17</sup> .  
Podem ser utilizados MMCD de origem sintética (MMCDs) ou biológica (MMCDb), e a escolha é feita de acordo com a idade do paciente, o subtipo de AIJ e resposta aos diferentes esquemas de tratamento. Os MMCDs sintéticos incluem metotrexato, leflunomida e sulfassalazina. Os MMCD biológicos incluem tocilizumabe, etanercepte, adalimumabe, infliximabe e abatacepte. Em geral, inicia-se com um MMCDs e, em em caso de falha terapêutica ou resposta incompleta, preconiza-se o uso de MMCDb. Duas exceções são a AIJ sistêmica com manifestações sistêmicas ativas e a artrite relacionada a entesite com sacroiliíte, nas quais os biológicos poderão ser prescritos antes dos sintéticos, respeitando as faixas etárias indicadas na informação técnica do medicamento. Os MMCDb recomendados para cada subtipo encontram-se no **Quadro 4** .  
**Quadro 4 - Classe medicamentosa recomendada de acordo com o subtipo de AIJ**<sup>**18**</sup> **.**  
|**Subtipo**|**Classe medicamentosa**<br>**recomendada**|**Medicamentos**|
|---|---|---|
|AIJ sistêmica|Preferencialmente anti-IL6|Tocilizumabe.|  
8  
|**Subtipo**|**Classe medicamentosa**<br>**recomendada**|**Medicamentos**|
|---|---|---|
|AIJ sistêmica com predomínio de poliartrite e sem<br>manifestações sistêmicas|Anti-TNF-alfa e CTLA4-Ig|Etanercepte, adalimumabe,<br>infliximabe, abatacepte.|
|Artrite relacionada à entesite|Anti-TNF-alfa|Etanercepte, adalimumabe,<br>infliximabe.|
|Artrite psoríaca|Anti-TNF-alfa, CTLA4-Ig, anti-<br>IL6|Etanercepte, adalimumabe e<br>infliximabe|
|AIJ oligoarticular e poliarticular|Anti-TNF-alfa, CTLA4-Ig, anti-<br>IL6|Etanercepte, adalimumabe,<br>infliximabe, abatacepte,<br>tocilizumabe.|  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Para cada subtipo de AIJ, os tratamentos preconizados devem seguir os fluxogramas específicos.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Preconiza-se iniciar o tratamento com AINE ou glicocorticoide intra-articular. Contudo, em casos de contratura, iniciase com glicocorticoide intra-articular, que apresenta efeito rápido e prolongado. O uso de AINE deve ser considerado em pacientes com função articular preservada, sem contraturas, ou na fase inicial de investigação do diagnóstico. Nas avaliações seguintes, se a artrite persistir, ou se o paciente já apresenta contratura, pode-se considerar a injeção de glicocorticoide intraarticular (GC IA) que poderá ser repetida, no máximo, três vezes durante o ano, com intervalo mínimo de quatro meses entre as infiltrações<sup>19,20</sup> .  
O uso de MMCDs na AIJ oligoarticular é recomendado em casos de duração do efeito do glicocorticoide intra-articular inferior a seis meses, presença de doença grave e erosiva, acometimento de novas articulações ou de articulações de mau prognóstico, tais como, coluna cervical, punhos e tornozelos. Os casos que evoluem como AIJ oligoarticular estendida devem receber tratamento semelhante ao da AIJ poliarticular ( **Figura 1** ).  
9  
**Figura 1** - Fluxograma para pacientes com AIJ oligoarticular.  
<!-- Start of picture text -->
Paciente com Artie idiopdtica Juveni oligoarticular<br>sim Pacienteapresenta Nao<br>contratura?<br>articular esteroidal<br>Nao Paciente Picci<br>‘apresenta crtérios* atte ou<br>para uso do contratura?<br>MMCDs?<br>sm |<br>Gicocorticoide intra-<br>articular<br>* Crtérios para uso de medicamento modificador do curso da doenca sintético (MMICDs)<br>doenca grave e erosiva ou<br>duragdo<br>= Comprometimentode efetodode novasglicocorticoide articulacbesintra-articular ou articulacbesmenor que 6 de prognéme s tico ruimes  ou<br><!-- End of picture text -->  
Legenda: MMCDs: Medicamento Modificador do Curso da Doença sintético.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O tratamento com AINE ou glicocorticoide intra-articular pode ser iniciado com a suspeita de AIJ poliarticular. Entretanto, uma vez confirmado o diagnóstico, o metotrexato (MTX) deve ser iniciado. O MTX deve ser introduzido na dose de 15 mg/m<sup>2</sup> , associado ao uso de ácido fólico (ou folínico). O AINE pode ser empregado para alívio dos sintomas, mas nunca deverá ser usado como monoterapia e nem por tempo prolongado.  
Corticoide em baixas doses pode ajudar a controlar a inflamação no período inicial do tratamento, enquanto os MMCDs não tiverem atingido a sua eficácia, devendo ser considerada, principalmente, nos casos de AIJ poliarticular grave com prejuízo funcional, por curtos períodos de tempo (inferior a 3 meses) para alívio dos sintomas. O uso de glicocorticoide intra-articular (GC-IA) pode ser empregado ocasionalmente em articulações que não responderam completamente a MMCDs. Em casos de toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou ausência de resposta ao MTX, o uso da leflunomida pode ser considerado.  
Se a resposta terapêutica ao MMCDs for insuficiente após 3 meses de tratamento, preconiza-se associar um MMCDb, preferencialmente, um anti-TNF-alfa (etanercepte ou adalimumabe ou infliximabe). Em casos de falha com o primeiro anti-TNFalfa, este poderá ser substituído por um segundo anti-TNF-alfaou tocilizumabe.  
Em casos de falha com o segundo MMCDb anti-TNF-alfa ou tocilizumabe, a alternativa disponível é o abatacepte ( **Figura 2** ), uma vez que seu uso foi restringido em razão da descontinuação temporária de fabricação do medicamento, conforme petição protocolada em 15 de março de 2022. Assim, enquanto o seu desabastecimento persistir, essa apresentação será priorizada para pacientes pediátricos que atendam aos critérios de inclusão específicos.  
10  
**Figura 2 - Fluxograma para pacientes com AIJ do subtipo oligoarticular estendido ou poliarticular** .  
<!-- Start of picture text -->
Facet comarte lense Jue lgoareuar een ou potareular<br>oesuspata (contmagi[aspaen"| o<br>Anv.ntanatio<br>Atentamati noe slsoverato Aadr o feancoete<br>coneoce em cosebava araconto geo ne<br>ant totaneno sim _/ copiiAvagiesapresentarammicossvena2s awManter | N80 /fobswspacienteTeste3 mas comsos, ‘Sim —/ nolerdnciaPacenencaepocaamda0ou \ N80<br>ince? mete?<br>Wo aa<br>Carte am cose sscocaruncoo | |__ tosermetrecto<br>site nageheakasntao anti-TNF para leflunomida_<br>Manter toeatPecente<br>wtanero ee Terese?apresentouou aha<br>pottersues | co<br>‘ockaunasTN oo<br>ante to Rasen<br>vetonero soundertesa?sprceiy ona<br>McD<br>subspersot ‘sim<br><!-- End of picture text -->  
Legenda: MMCDs: Medicamento Modificador do Curso da Doença sintético; MMCDb: Medicamento Modificador do Curso da Doença biológico. Nota: Enquanto o desabastecimento de abatacepte 250 mg persistir, prioriza-se o fornecimento dessa apresentação para pacientes pediátricos que atendam a critérios específicos, conforme detalhado nos critérios de inclusão.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Para este tipo de AIJ, preconiza-se, inicialmente, o uso de AINE e GC-IA. Nos casos de falha terapêutica em que haja artrite periférica, a sulfassalazina e o MTX podem ser indicados. A presença de entesite não responsiva, mesmo na ausência de artrite, pode ser indicativa da necessidade de anti-TNF-alfa. Se o paciente apresentar sacroiliíte também deverá ser tratado com anti-TNF-alfa e, se o primeiro falhar, um outro anti-TNF-alfa deverá ser prescrito<sup>21</sup> ( **Figura 3** ).  
11  
**Figura 3 - Fluxograma para pacientes com AIJ do subtipo artrite relacionada a entesit** e  
<!-- Start of picture text -->
| Paciente com arte relacionada a entesite<br>‘Antvinflamatorio nao esteroidal<br>Giicocorticoide intra-articular<br>Mantertrtamento NBO / spresentaterapéuticaPaciente falaou<br>artite<br>periterica?<br>sim<br>MucDs<br>(cutfassalazina ou<br>metotrexato)<br>Nao / — Paciente sim Paciente Nao<br>apresenta presenta<br>sacrolite? entesiteresponsiva? nao eee<br>sim<br>Mantertratamento MMCDb ant-TNF | cna<br>zo / Paciento sim<br>Nl0/ presenta<br>toxicidade ou faina<br>terapéutica?<br>aa Substiuir MMCDb<br><!-- End of picture text -->  
Legenda: MMCDs: Medicamento Modificador do Curso da Doença sintético; MMCDb: Medicamento Modificador do Curso da Doença biológico. Nota: Duas exceções são a AIJ sistêmica com manifestações sistêmicas ativas e a artrite relacionada a entesite com sacroiliíte, nas quais os biológicos poderão ser prescritos antes dos sintéticos, respeitando as faixas etárias indicadas na informação técnica do medicamento.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Dependendo da apresentação clínica da artrite e da gravidade da psoríase, as normas de tratamento devem seguir o que foi estabelecido para os subtipos já discutidos anteriormente. Os biológicos mais recentes e dirigidos para a artrite psoríaca em adultos ainda não foram estudados em crianças e, portanto, ainda não são indicados<sup>15,22,23</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Nos casos de AIJ sistêmica provável (pacientes que apresentam manifestações sistêmicas típicas, mas sem artrite) devem ter o tratamento iniciado com a prescrição de glicocorticoide em doses altas com ou sem a adição de anti-IL6, nesse caso, o tocilizumabe<sup>11</sup> .  
Na AIJ sistêmica, preconiza-se a administração de pulsos intravenosos de metilprednisolona, seguido do uso de prednisona por via oral. Se ao final de sete dias a febre estiver controlada e a proteína C reativa reduzida em 50%, poderá ser iniciada a redução da dose do corticoide. Caso não haja resposta satisfatória, um novo pulso endovenoso deve ser programado na semana seguinte. Se após duas semanas a febre persistir ou se continuar necessitando de doses altas de glicocorticoide, um MMCDb deve ser iniciado<sup>11</sup> . Preconiza-se, preferencialmente, o uso de um anti-IL6 (tocilizumabe), que age tanto em manifestações sistêmicas quanto nas articulares.  
O uso de corticoide intra-articular e o AINE também podem ser considerados como terapia adjuvante<sup>11</sup> ( **Figura 4).**  
12  
**Figura 4** - Fluxograma para pacientes com AIJ sistêmica com manifestações sistêmicas (com ou sem artrite)  
<!-- Start of picture text -->
Paciente com artriteidiopatica juvenil com manifestagoes<br>sistémicas ativas com ou sem artrite<br>Pulsoterapia IV com glicocorticoide (10 a 30 mg/kgjdia por 3 dias)<br>Prednisona ou prednisolona 1 a 2 mgikg/dia<br>sim Paciente Neo<br>atingiu alvot<br>‘apés 7 dias?<br>Repetiro pulso de<br>Reduzir aalicocorticoidedose de Iniciarglicocorticoide MMCDb,<br>preferencialmente ant IL6<br>Paciente Nao sim /  Paciente<br>atingiu alvo? Manter 0 tratamento atingiu alvo?<br>‘apés 4 semanas? apés 4 semanas?<br>| sim | Wao<br>‘Aumentar 0<br>Reduzir aglicocorticoidedose de ‘AumentarslicocorticoideMMCDb a dose do<br>Paciente Nao Paciente<br>atingiu alvo® Manterotratamento [¢—/_atingiu alvo?<br>apés 6 a 12 mentor otratame! ‘apsmeses?<br>meses? 6 a 12<br>sim Nao<br>‘Suspender 0 uso de ‘AumentarMMCDb<br>glicocorticoide a dose do<br> alvo em 7 dias: Auséncia de febre e dosagem de Proteina C Reativa (PCR) reduzida em<br>50%;<br>2!|Avaliagao Alvo lvo  em  em 4 6 Global semanas: a 12 meses: pelo RedugaoMédico) Doenca  em¢ inativa JADAS 50% do e sem <  niimero5,4; uso de  de glicocorticoides;  articulagbes com artrite, da PGA<br><!-- End of picture text -->  
Legenda: MMCDb: Medicamento Modificador do Curso da Doença biológico.  
Na AIJ sistêmica com predomínio de poliartrite e sem manifestações sistêmicas ativas, a conduta é diferente. O paciente poderá continuar a retirada do glicocorticoide e iniciar ou manter o anti-IL6 que oferece boa resposta para a artrite. Se já estava sendo tratado com anti-IL6 (tocilizumabe) sem resposta satisfatória, o tratamento poderá ser conduzido como na AIJ poliarticular, com MTX e anti-TNF-alfa ou abatacepte<sup>11</sup> . Há casos refratários e de mau prognóstico, nos quais serão necessárias prescrições excepcionais como a de imunossupressores<sup>24,25</sup> ( **Figura 5** ).  
13  
**Figura 5** - Fluxograma para pacientes com AIJ sistêmica sem manifestações sistêmicas cursando com poliartrite  
<!-- Start of picture text -->
Paciente com artrite idiopatica juvenil sistémica sem<br>manifestagées sistémicas ativas cursando com poliartrite<br>Glicocorticoide e MMCDb (anti-TNF ou,<br>preferencialmente, tocilizumabe)<br>‘Sim Paciente Nao<br>apresentou resposta<br>a0 tratamento?<br>Reducio e retirada Metotrexato*<br>do glicocorticoide<br>Etanercepte ou<br>Manutenc&o do adalimumabe ou<br>MMCDb tocilizumabe*<br>sim Paciente Nao<br>apresentou<br>resposta a0<br>tratamento?<br>See nee<br>"  metotrexato pode ser usado como terapia adjuvante<br>|? Considerar tocilizumabe caso nao tenha sido usado anteriormente<br><!-- End of picture text -->  
Legenda: MMCDb: Medicamento Modificador do Curso da Doença biológico.  
Nota: Enquanto o desabastecimento de abatacepte 250 mg persistir, prioriza-se o fornecimento dessa apresentação para pacientes pediátricos que atendam a critérios específicos, conforme detalhado nos critérios de inclusão.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Recomenda-se que o tratamento da SAM inicie com pulsos endovenosos de metilprednisolona. Se a resposta não for  
evidente, deve-se acrescentar ciclosporina <mark>por via oral ou intravenosa - doses altas se justificam em casos excepcionalmente</mark>  
<mark>graves, que podem ser fatais.</mark>

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O tratamento da uveíte relacionada à AIJ envolve o uso de agentes tópicos e sistêmicos. A introdução de imunossupressor  
sistêmico deve ser feita precocemente com o objetivo de reduzir o corticoide tópico e sistêmico<sup>26</sup> .  
O alvo de eficácia do tratamento da uveíte é _Standardization of Uveitis Nomenclature_ (SUN)<sup>37</sup> grau 0 (zero) de células  
nos dois olhos. O tratamento deve ser iniciado sempre que houver<sup>26,27</sup> :  
- 1- Grau de celularidade da câmara anterior maior que 0,5+;  
- 2- presença de fibrina na câmara anterior;  
- 3- presença de precipitados ceráticos com edema de córnea; ou  
- 4- perda de acuidade visual.  
O tratamento sistêmico com imunossupressor deve ser intensificado em caso de<sup>26,27</sup> :  
- 1- Falha na melhora da inflamação; ou  
- 2- presença de fatores prognósticos (baixa visão inicial, catarata, glaucoma, hipotonia ocular, opacidade vítrea densa e  
- edema macular).  
14  
O tratamento com anti-inflamatórios esteroidais ou não esteroidais não é indicado nos casos de ceratopatia em faixa, sinéquias, catarata e glaucoma apresentados de forma isolada e na ausência de uveíte ativa<sup>26, 27</sup> .  
O tratamento de primeira linha para a uveíte anterior aguda e crônica é o corticoide tópico. Se a doença não for controlada em 3 meses de tratamento (com dose superior a 3 gotas em cada olho por dia), está indicado o tratamento sistêmico com MMCDs. O MTX é o primeiro tratamento de segunda linha, após o corticoide<sup>26, 27</sup> .  
Os MMCDb com dose ajustada para tratamento do acometimento ocular devem ser adicionados se o paciente apresentar toxicidade (intolerância, hipersensibilidade ou outro evento adverso) com o uso de MTX, em caso de piora da doença ou se não houver controle na inflamação ocular, com presença de células da câmara anterior grau zero, após 3 a 4 meses de uso do MTX. Em caso de uveíte anterior grave e com complicações ameaçadoras de visão, pode-se iniciar com MTX + anti-TNF-alfa imediatamente.  
Preconiza-se o uso de adalimumabe ou infliximabe como primeira escolha naqueles pacientes que não responderam adequadamente ao MTX<sup>26, 27</sup> . se não for observada resposta ou em caso de recidiva com o primeiro anti-TNF-alfa em dose padrão, deve-se ajustar dose e intervalo antes de tentar o segundo anti-TNF-alfa.  
Se não for observada resposta ou em caso de recidiva ao segundo anti-TNF-alfa, preconiza-se tocilizumabe como MMCDb<sup>28--36</sup> ou ciclosporina como alternativa de MMCDs. Se não for observada resposta ou em caso de recidiva ao uso de tocilizumabe, preconiza-se o uso de abatacepte ( **Figura 6** ).  
Destaca-se que o uso do abatacepte 250 mg foi restringido em razão da descontinuação temporária de fabricação do medicamento, conforme petição protocolada em 15 de março de 2022. Assim, enquanto o seu desabastecimento persistir, essa apresentação será priorizada para pacientes pediátricos que atendam a critérios de inclusão.  
O uso de leflunomida no tratamento da uveíte não é indicado. O etanercepte, bem como AINE tópicos e sistêmicos, não são indicados para pacientes com uveíte relacionada a AIJ por aumentar o risco de recorrência de uveíte<sup>26,27</sup> .  
15  
**Figura 6 - Algoritmo para o tratamento da uveíte associada a AIJ (38, 39** )  
<!-- Start of picture text -->
—————=E——=—'/<br>Paciente com arttite idiopatica juvenil com uveite ativa<br>(Células na cémara anterior > 0,5+)<br>corticoldes topicos4a2 cae(si(3s dias?) (a.  + Nao PRESaapeeea sim pacara2 poehoras poror1 a3 (2dias?)ee+<br>adversos'? Corticoides sistémicos<br>Melhora até grau 0 Melhora de 2 graus mas ainda ‘Sem methora ou piora ou > flare ou flare<br>(auséncia de inflamagao) nao < 0,5 + ‘com sequela<br>semanas e reavaliar via oral<br>Reavaliagao em 3a 4 meses<br>Melhora até grau 0 Melhora de 2 graus mas ‘Sem melhora ou piora ou >3 flare<br>(auséncia de inflamagao) ainda ndo < 0,5 + u flare com sequela<br>‘Manutengaoporabi 12 mesesdo oumetotrexato24 meses,¥ Manteraitarias tratamentoSs Tesvair por6 Manter metotrexato 15 mg/m@/semana,<br>ona por via oral e adicionar um anti-TNF<br>{ (auséncia Methorade atéinfl gr a umagao) 0 Melhora denao 2 graus< 0,5  mas+  ainda 23‘Semflare methoraou flare oucom piora sequela ou<br>(ee Tentar alcancar inatividade com Maximizar dose do anti-TNF<br>ses colirio de corticoide < 2 gotasidia ‘Otimizar intervalo e via de tratamento<br>Avaliar adesao<br>Medir nivel sérico do medicamento (se<br>| Reavaliagso ] Corticoide oral e/oupossiv subt noniano se e l)  3+ ou 4+<br>Methora até grau 0 ‘Melhora de 2 graus mas ainda nao ‘Sem melhora ou piora ou > 3 flare ou<br>(auséncia de inflamacao) 505+ flare com sequela<br>‘Manter tratamento por Tentar alcangar inatividade com ‘Trocar para outro anti-TNF<br>2timeces) colirio de corticoide < 2 gotas/dia<br>‘Sem melhora ou piora ou > 3 flare ou<br>flare com sequela<br>|' Fatores prognésticos adversos: baixa visdo inicial,<br>jipotonia ocular, glaucoma, catarata, edema ‘Trocar MMCDb para ‘Trocar MMCDs<br>‘acular, opacidade vitrea densa. tocilizumabe? para ciclosporina?<br>PA reducdo do corticoide tépico deve ocorrer com o|<br>inicio do uso do metotrexato. ‘Sem methora ou piora ou<br>> 3 flare ou flare com sequela<br>’ Deve-se optar por uma das trocas: MMCDb para<br>ocilizumabe ou MMCDs para ciclosporina. Trocar MMCDb para<br>abatacepte<br><!-- End of picture text -->  
Legenda: MMCDs: Medicamento Modificador do Curso da Doença sintético; MMCDb: Medicamento Modificador do Curso da Doença biológico. Nota: Enquanto o desabastecimento de abatacepte 250 mg persistir, prioriza-se o fornecimento dessa apresentação para pacientes pediátricos que atendam a critérios específicos, conforme detalhado nos critérios de inclusão.  
16

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Os esquemas de tratamento, por medicamento e conforme citados anteriormente, podem ser vistos no **Quadro 5** .  
**Quadro 5 - Medicamentos disponíveis no SUS e suas respectivas posologias para tratamento da AIJ**  
|**Medicamento**|**Apresentações disponíveis no SUS**|**Esquema de administração**|**Observações**|
|---|---|---|---|
|Naproxeno|Anti-inflamatórios não es<br>Comprimido de 250 mg e         500<br>mg|teroidais (AINEs)<br>10 a 20 mg/kg/dia divididos<br>em 2 doses por dia, por via<br>oral||
|Ibuprofeno|Comprimido de 200 mg, 300 mg e<br>600 mg<br>Suspensão oral de 50 mg/mL|10 a 30 mg/kg/dia em 3 a 4<br>doses por dia, por via oral|Não exceder 3.200<br>mg/dia em adultos, 800<br>mg/dia em crianças|
|Metilprednisolona|<br>Glicocorticoides<br>Pó para solução injetável          500<br>mg|sistêmicos<br>20 a 30 mg/kg/dia por 1 a 3<br>dias consecutivos, seguidos<br>por doses de 2 mg/kg/dia de 2<br>a 4 vezes por dia. Dose<br>máxima de 60 mg||
|Prednisona oral|Comprimido de 5 mg e 20 mg|Manutenção pós pulsoterapia:<br>1 a 2 mg/kg/dia até o máximo<br>de 60 mg<br>Dose pediátrica:<br>De 0,14 a 2 mg/kg de peso<br>por dia, ou de 4 a 60 mg/m<sup>2</sup><br>por dia<br>Dose para adultos:<br>De 5 a 60 mg por dia||
|Fosfato sódico de<br>prednisolona|Solução oral de 1 mg/mL e 3 mg/mL<br>Glicocorticoide para us<br>|Dose pediátrica:<br>0,2 a 0,5 mg/kg por dia<br>Dose para adultos:<br>De 5 a 60 mg por dia<br>o tópico ocular<br>||
|Dexametasona|1 mg/ml (0,1%) suspensão oftálmica<br>ou pomada oftálmica|Uma gota no olho afetado a<br>cada 2 a 4 horas, de acordo||  
17  
|**Medicamento**|**Apresentações disponíveis no SUS**|**Esquema de administração**|**Observações**|
|---|---|---|---|
||Glicocorticoide para us<br>|com a gravidade da<br>inflamação ocular<br>o intra-articular||
|Acetato de<br>metilprednisolona|Pó para solução injetável             40<br>mg/2 mL|0,5 a 1,0 mg/kg/articulação||
||Medicamentos modificadores do curso|de doença - MMCD sintéticos||
|Metotrexato (MTX)|Comprimido de 2,5 mg ou solução<br>injetável de 25 mg/mL (frasco com 2<br>mL)|10 a 15 mg/m<sup>2</sup>por semana<sup>40</sup>,<br>VO, IV, SC ou IM.|Em casos graves de<br>uveíte: 20 mg/m<sup>2</sup><br>Associar ácido fólico (1<br>mg/ dia por 6 dias) ou<br>ácido folínico (1/3 da<br>dose do MTX) pelo<br>menos 24 horas após a<br>administração de<br>MTX<sup>41</sup>|
|Sulfassalazina|Comprimido de 500 mg|Artrite relacionada a entesite<br>com comprometimento<br>periférico, sem resposta a<br>AINE: 40 a 50 mg/kg, com<br>máximo de 2 a 3 g por dia||
|Leflunomida|Comprimido de 20 mg|Para pacientes com mais de<br>40 kg: 20 mg|Uso apenas para<br>pacientes maiores de 18<br>anos e com toxicidade<br>(intolerância,<br>hipersensibilidade ou<br>outro evento adverso)<br>do MTX (42, 43)|
|Ciclosporina|Cápsula mole de 10 mg, 25 mg, 50<br>mg e 100 mg<br>Solução oral de 100 mg/mL (frasco<br>com 50 mL)<br>Solução injetável de 50 mg/mL|Na AIJS com SAM: 2 a 5<br>mg/kg por dia||
||Medicamentos modificadores do curso|de doença - MMCD biológicos||  
18  
|**Medicamento**|**Apresentações disponíveis no SUS**|**Esquema de administração**|**Observações**|
|---|---|---|---|
|Etanercepte (anti-TNF-<br>alfa)|Solução injetável de 25 mg e 50 mg|Dose semanal de 0,8 mg/kg<br>de peso (máximo de 50 mg<br>por dose)|Uso a partir de 2 anos<sup>44,</sup><br>45|
|Adalimumabe<br>(anti-TNF-alfa)|Solução injetável de 40 mg|Para pacientes com menos de<br>30 kg: 20 mg a cada 14 dias,<br>por via subcutânea (SC)<br>Para pacientes com mais de<br>30 kg: 40 mg ou 24 mg/m<sup>2</sup>a<br>cada 14 dias, SC.<br>Para pacientes com uveíte: 24<br>mg/m<sup>2</sup>, com dose máxima de<br>40 mg a cada 14 dias, SC.|Uso a partir de 2<br>anos<sup>44,45</sup>|
|Infliximabe<br>(anti-TNF-alfa)|Pó para solução injetável de 100 mg<br>(frasco com 10 mL)|Iniciar com 3 mg/kg/dose, nas<br>semanas 0, 2, 6 e, após,<br>manter a mesma dose a cada 2<br>meses, IV.<br>Para pacientes com uveíte: 5<br>mg/kg, IV.|Uso a partir dos 6<br>anos<sup>18</sup>.|
|Abatacepte (CTLA4-<br>Ig)|Pó para solução injetável de 250 mg|Para pacientes com menos de<br>75 kg: 10 mg/kg de peso,<br>administrado IVinicialmente<br>nos dias 0, 15, 30 e, a seguir,<br>a cada 30 dias.<br>Para pacientes com 75-100<br>kg:<br>750 mg administrada IV<br>inicialmente nos dias 0, 15,<br>30 e, a seguir, a cada 30 dias.<br>Para pacientes com mais de<br>100 kg:<br>A dose máxima de 1.000 mg,<br>administrada IV inicialmente<br>nos dias 0, 15, 30 e, a seguir,<br>a cada 30 dias.|Uso a partir dos 6<br>anos<sup>18</sup>, conforme<br>critérios de inclusão.|
|Tocilizumabe<br>(anti-IL6)|Solução injetável de 20 mg/mL<br>(frasco com 4 ml)|Para pacientes com menos de<br>30 kg:|Uso a partir de 2 anos<sup>44,</sup><br>45|  
19  
|**Medicamento**|**Apresentações disponíveis no SUS**|**Esquema de administração**|**Observações**|
|---|---|---|---|
|||AIJ poliarticular:10 mg/kg a<br>cada 4 semanas, IV.<br>AIJ sistêmica:12 mg/kg na<br>AIJ sistêmica a cada 2<br>semanas, IV.<br>Para pacientes com mais de<br>30 kg:||
|||AIJ poliarticular:8 mg/kg a<br>cada 4 semanas, IV.||
|||AIJ sistêmica:8 mg/kg a cada||
|||2 semanas, IV.||  
Nota 1: A administração endovenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
Nota 2: A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O alvo final desejável será a remissão completa e sustentada da doença, prevenindo sequelas e melhorando a qualidade de vida, embora em alguns casos, seja aceitável a baixa atividade da doença. Na AIJ sistêmica espera-se que, além da remissão clínica e laboratorial, definidas conforme avaliação pelo cJADAS e Critérios de Wallace (ver em 8 Monitorização), o paciente não esteja mais usando glicocorticoides.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Existem algumas situações em que o tratamento da AIJ requer cuidados específicos antes ou durante o tratamento.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Na gestação, o MTX, leflunomida e tocilizumabe são contraindicados. Os AINE podem ser utilizados no primeiro e segundo trimestre de gestação, e a sulfassalazina também deve ser suspensa no último trimestre. O adalimumabe e o infliximabe podem ser utilizados até a 20ª semana e o etanercepte até a 32ª semana, podendo ser usados durante toda a gestação em casos individualizados<sup>46</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O início de MMCD é contraindicado em casos com diagnóstico ou suspeita de infecção ativa. Nos casos de pacientes de hepatite C que estejam recebendo ou que receberam terapia antiviral específica, pode-se proceder ao tratamento com as mesmas recomendações daqueles sem esta condição. Nos casos de hepatite B, deve-se avaliar a condição do vírus com os exames sorológicos específicos. Em casos de hepatite B crônica ativa ou inativa ou contato prévio com o vírus tratado, o paciente deve ser avaliado quanto à necessidade de tratamento específico ou terapia profilática de reativação viral antes do início do tratamento, principalmente quando houver necessidade de corticoide em doses elevadas ou o uso de terapia anti-TNF-α<sup>47</sup> .  
**Insuficiência cardíaca classe funcional III ou IV**  
20  
Nos casos de insuficiência cardíaca diagnosticada em classe funcional III ou IV, são contraindicados os medicamentos anti-TNF-alfa. Em caso de paciente com insuficiência cardíaca congestiva em classe funcional II ou III que evolui com piora da doença cardíaca, também se deve dar preferência para MMCD sintético ou biológico (exceto os anti-TNF-alfa)<sup>47</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Devido à falta de artrite em alguns pacientes na fase inicial da AIJ sistêmica, recentemente foi feita uma nova proposta de reclassificação destes pacientes<sup>2</sup> . Nesta situação, um critério obrigatório na AIJ sistêmica passou a ser a febre típica, enquanto a artrite e o exantema evanescente entrariam como critérios maiores. Para o diagnóstico definitivo, seriam necessários, além da febre, mais dois critérios maiores, ou febre mais um critério maior e dois critérios menores (serosite, hepato, espleno ou linfonodomegalia, leucocitose, artralgia por mais de duas semanas e mais de 15.000 leucócitos/mm<sup>3</sup> ). Estes pacientes receberiam o mesmo tipo de tratamento daqueles com AIJ sistêmica com manifestações sistêmicas e artrite.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
O tratamento da AIJ envolve não apenas o uso de medicamentos anti-inflamatórios e MMCD. O monitoramento do uso dos medicamentos é essencial a fim de minimizar o risco de eventos adversos, toxicidade e possíveis danos. Os pacientes devem ser avaliados em intervalos de 4 ou 12 semanas ou conforme a necessidade<sup>48</sup> .  
Os fluxogramas para o tratamento AIJ oligoarticular e AIJ poliarticular consideram reavaliações a cada 3 e 6 meses, quando a doença está controlada. Incluem também definições de fatores de mau prognóstico que devem influenciar a escolha do medicamento. Entre eles estão: artrite de quadril, coluna cervical, punhos, tornozelos; alterações radiológicas como redução do espaço articular e erosões; fator reumatoide ou anti-CCP positivo; persistência de provas de atividade inflamatória elevadas (PCR e VHS) e de manifestações sistêmicas assim como necessidade de glicocorticoide por via sistêmica, após seis meses de tratamento.  
O JADAS ( _Juvenile Arthritis Disease Activity Score)_ é o índice composto mais utilizado para quantificar a atividade da AIJ (49-51). Inicialmente foi concebido e validado com quatro variáveis (número de articulações ativas, avaliação global pelo paciente (escala analógica visual de 0 a 10 cm), avaliação global pelo médico (escala analógica visual de 0 a 10 cm) e uma prova de atividade inflamatória como a VHS ou a PCR. Existe o JADAS 71 que avalia 71 articulações, outro que analisa 27 (JADAS 27) e o JADAS 10 que seleciona apenas 10.  
O número de articulações ativas consideradas no JADAS (71, 27 ou 10) somado ao valor de cada uma das outras três variáveis que valem 10 pontos cada, oferece o valor de JADAS que poderá atingir pontuações de 101, 57 ou 40. Para que a velocidade de hemossedimentação (VHS) ou da proteína C reativa (PCR) sejam pontuadas de 0 a 10, haverá necessidade de se normalizar os dados destes exames.  
Mais recentemente, foi verificado que a exclusão do critério laboratorial (VHS ou PCR) caracterizaria o JADAS clínico (ou cJADAS), também permitindo uma boa avaliação da doença. Neste caso, a pontuação máxima alcançaria 91, 47 e 30 pontos, dependendo do número de articulações analisadas. O cJADAS é mais simples, pois pode ser realizado no dia da consulta sem a necessidade de aguardar o resultado dos exames laboratoriais<sup>49</sup> .  
O critério de doença inativa utilizando qualquer um dos JADAS deve mostrar um escore de 0 a 1. Um novo conceito, diferente de doença inativa seria a baixa atividade de doença, aceitável em alguns pacientes. Neste caso, os valores do JADAS e JADAS clínico poderiam ser um pouco maiores do que 1 ( **Quadro 6** )<sup>50</sup> .  
**Quadro 6** - JADAS na avaliação de doença inativa  
|**Índice**|**Doença Inativa**|**Baixa Atividade de Doença**|
|---|---|---|  
21  
|JADAS|AIJ oligoarticular e AIJ poliarticular<br>JADAS 27 ≤ 1|Oligoarticular – JADAS 27 ≤ 2<br>Poliarticular – JADAS 27 ≤ 3,8|
|---|---|---|
|JADAS clínico|AIJ oligoarticular e AIJ poliarticular<br>cJADAS 10 ≤ 1|Oligoarticular – cJADAS 10 ≤ 1,5<br>Poliarticular – cJADAS 10 ≤ 2,5|  
O cJADAS pode ser usado como um guia para indicar o MMCDb a cada avaliação trimestral: 3, 6 e 12 meses. Desta forma, sugere-se que cJADAS > 5 na AIJ oligoarticular e, cJADAS > 7 na AIJ poliarticular, após três meses, assim como cJADAS > 3 na AIJ oligoarticular e cJADAS > 4 na AIJ poliarticular, após 6 meses, podem receber a adição de biológico no tratamento, desde que o paciente tenha cumprido corretamente o tratamento inicial com glicocorticoide por via intra-articular e usado o MTX em doses de 15 mg/m<sup>2</sup> por via subcutânea ( **Quadro 7** ). A introdução de valores de VHS no cJADAS não altera a decisão de introduzir ou não com biológicos<sup>49</sup> .  
**Quadro 7 - Indicação de início de MMCD biológico no tratamento da AIJ de acordo com o JADAS clínico (cJADAS) em pacientes com AIJ oligoarticular e AIJ poliarticular**  
|Índice|**AIJ oligoarticular**|**AIJ poliarticular**|
|---|---|---|
|cJADAS após 3 meses|>5|>7|
|cJADAS após 6 meses|>3|>4|  
Conceitos e definições de doença inativa, remissão, baixa atividade da doença, falha terapêutica foram desenvolvidos e atualmente são amplamente utilizados no tratamento da AIJ<sup>52</sup> .  
Os critérios de doença inativa e remissão, atualmente conhecidos como critérios Wallace<sup>53, 54</sup> , consideram doença inativa se houver ausência de artrite, de manifestações sistêmicas (febre, exantema, serosite, esplenomegalia, e linfadenopatia generalizada), uveíte, VHS e PCR normais, rigidez matinal por menos 15 minutos e avaliação global do médico igual a zero ( **Quadro 8** ). Se o paciente mantiver a doença inativa pelos próximos seis meses, será classificado como Remissão com Medicamento (RCM). Após a retirada de todos os medicamentos, e se permanecer 12 meses sem recidivas, será classificado como Remissão sem Medicamento (RSM).  
**Quadro 8 - Critérios de Wallace**  
Nenhuma articulação com artrite  
|Ausência de: febre, exantema, serosite, esplenomegalia, linfonodomegalia generalizada atribuída a AIJ|
|---|
|Sem uveíte ativa|
|VHS e PCR com valores dentro dos limites normais e, se elevado, não ser atribuído a AIJ|
|Avaliação global do médico com o melhor escore possível|
|Duração de rigidez matinal por menos de 15 minutos|  
Além dos critérios Wallace e JADAS, os alvos na AIJ sistêmica devem incluir avaliações específicas e em diferentes intervalos de tempo. A curto prazo (7 dias), um alvo possível é a resolução da febre e melhora de 50% do valor da proteína C reativa; a médio prazo (4 semanas), a melhora de 50% do número de articulações ativas e da avaliação global do médico e o escore máximo do JADAS 10 igual ou inferior a 5,4; e a longo prazo (6 a 12 meses), doença clinicamente inativa e sem glicocorticoide<sup>11</sup> .  
22  
Deve-se levar em consideração a condição epidemiológica do paciente e risco de tuberculose e preconizam-se testes sorológicos para hepatites B e C e HIV no momento do diagnóstico.  
Conforme descrito nos itens anteriores deste PCDT, as VHS e a PCR são utilizadas para avaliação de atividade de doença e são úteis para avaliação de resposta terapêutica. Devem ser solicitadas antes do início do tratamento e após 4 a 12 semanas, conforme a necessidade<sup>48</sup> .  
Para o monitoramento dos eventos adversos dos medicamentos, o hemograma e as dosagens de aminotransferases/transaminases (AST/TGO e ALT/TGP) e creatinina devem ser procedidos no início do tratamento. Posteriormente, esses exames poderão ser realizados a cada 4 a 12 semanas conforme especificado no **Quadro 9** , em que se pode ver que outros exames são preconizados conforme o medicamento. Antes do uso dos medicamentos, deve-se proceder à pesquisa de infecções ativas.  
**Quadro 9 - Monitoramento dos medicamentos usados no tratamento da AIJ**  
|**Medicamento**|**Avaliação**|**Conduta frente a alterações**|
|---|---|---|
|AINE|Hemograma, creatinina,<br>AST/TGO, ALT/TGP e<br>análise de urina a cada 6<br>meses<sup>48</sup>.|-Hipersensibilidade:suspensão do medicamento.<br>-Sangramento do trato gastrointestinal:suspensão do<br>medicamento.<br>-Doença hepática e doença renal aguda ou crônica:suspensão do<br>medicamento.<br>-Terceiro trimestre da gestação:suspensão do medicamento.|
|MTX e Leflunomida|Hemograma, creatinina,<br>AST/TGO e ALT/TGP 4 ou<br>12 semanas quando há<br>aumento de dose e para<br>pacientes em dose estável a<br>cada 8 ou 12 semanas<sup>48</sup>.|- Aumento de AST/TGO e ALT/TGP acima de duas vezes o<br>limite superior da normalidade: redução da dose ou suspensão<br>temporária.<br>- Aumentos de AST/TGO e ALT/TGP mantidos acima de 3 vezes<br>do limite superior da normalidade, a despeito da diminuição da<br>dose do medicamento: suspensão do medicamento.|
|Sulfassalazina|Hemograma, AST/TGO,<br>ALT/TGP, creatinina no<br>início e a cada 1 a 2 semanas,<br>durante incremento de dose e<br>trimestral em manutenção.<br>Imunoglobulinas a cada 6<br>meses|-Reações de hipersensibilidade tais como exantema, úlceras orais<br>e síndrome de Stevens- Johnson: suspensão do tratamento<br>- Aleitamento materno de recém-nascido: suspender o tratamento|
|Ciclosporina|Hemograma, creatinina,<br>AST/TGO, ALT/TGP no<br>início e a cada 4 a 12<br>semanas.|- Se aumento de creatinina em 30% reduzir dose de 25%-50%<br>- Se aumento de creatinina 50% considerar redução adicional da<br>dose ou suspensão|  
23  
|**Medicamento**|**Avaliação**|**Conduta frente a alterações**|
|---|---|---|
|||- Hipertensão arterial e aumento de creatinina sérica > 30% do<br>nível basal: reduzir a dose<br>- Não usar durante gravidez|
|Anti-TNF-alfa|Hemograma, AST/TGO,<br>ALT/TGP e creatinina no<br>início e a cada 3 a 6 meses<sup>48</sup>.|-Infecções ativas:suspensão do medicamento.<br>-Doenças desmielinizantes:suspensão do medicamento.<br>-Insuficiência cardíaca classe funcional III e IV:suspensão do<br>medicamento.|
|Tocilizumabe (TCZ)|Hemograma (cada 4 a 8<br>semanas nos primeiros 6<br>meses e posteriormente a<br>cada 12 semanas), AST/TGO<br>e ALT/TGP (cada 8 semanas<br>nos primeiros 6 meses e<br>posteriormente a cada 12<br>semanas), colesterol total e<br>frações e triglicerídeos (cada<br>8 semanas no início e<br>posteriormente a cada 6<br>meses)|-Aumento de AST/TGOe ALT/TGP1 a 3 vezes:<br>1) Modificar dose de tocilizumabe se necessário<br>2) Diminuir dose 4mg/kg ou interromper infusão até que volte ao<br>normal<br>3) Reiniciar 4mg/kg ou 8mg/kg quando normal<br>4) SC: passar semanas alternadas até normal e voltar semanal se<br>necessário/adequado<br>-Aumento de AST/TGOe ALT/TGP3 a 5 vezes:<br>1) Interromper a dose até < 3 x normal<br>2) Quando atingir < 3 x normal, recomeçar 4mg/kg ou 8mg/kg<br>3) Aumento persistente > 3 x normal, suspender TCZ<br>-Aumento de AST/TGOeALT/TGP> 5 vezes:<br>Suspender TCZ<br>-Neutrófilo > 1000/mm<sup>3</sup><br>Manter dose<br>-Neutrófilo 500-1000/mm<sup>3</sup><br>1) Interromper TCZ<br>2) Quando > 1000, recomeçar 4 mg/kg (se SC 162 mg a cada duas<br>semanas) e aumentar para 8 mg/kg (se SC 162 mg semanal)<br>quando apropriado<br>-Neutrófilo  < 500/mm<sup>3</sup><br>Suspender TCZ<br>-Plaquetas < 50.000 mm<sup>3</sup><br>Suspender TCZ|  
Após seis meses de tratamento, é desejável que o alvo tenha sido alcançado e, ao final de um ano, o paciente mantenhase com doença inativa. Na AIJ sistêmica, os alvos para controle das manifestações sistêmicas devem ser atingidos mais precocemente do que as manifestações articulares<sup>10</sup> . Para os pacientes que conseguem alcançar o estado de doença inativa, é desejável suspender os medicamentos que podem trazer efeitos adversos. Contudo, não existem regras estabelecidas e há um alto  
24  
grau de recidiva quando o tratamento é suspenso. Em geral, as decisões de suspensão se baseiam no tempo de doença inativa, sendo preferível aguardar um período de 12 meses nesta condição. Além disso, outros critérios considerados na suspensão são o subtipo de AIJ, evidência de atividade em exame de imagem, toxicidade do medicamento, preferência da família, duração da doença e presença de sequelas<sup>20</sup> .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
A avaliação oftalmológica de pacientes de alto risco é essencial, objetivando-se o diagnóstico e tratamento precoces, para minimizar a inflamação intraocular e evitar as complicações que levam a perda definitiva da visão<sup>26</sup> .  
**Avaliação oftalmológica** (Adaptada de “ _British Society for Paediatric and Adolescent Rheumatology/Royal College of Ophthalmology Guidelines for uveitis screening in JIA_ )<sup>55</sup> :  
Pacientes devem ser encaminhados logo no diagnóstico ou suspeita de AIJ; sendo que aqueles com sintomas oculares devem ser avaliados na mesma semana.  
Reavaliação oftalmológica deve ser realizada a cada duas semanas, desde o início da artrite, por um período de 6 meses; depois a cada 3 a 4 meses, até completarem 11 anos de idade.  
Após a interrupção do tratamento com imunossupressores, tais como MTX, o paciente deve ser submetido a uma avaliação a cada dois meses por um período de seis meses.  
Após alta da triagem, os pacientes devem receber orientação de automonitorização da visão, de cada olho separadamente,  
uma vez por semana, ou manter o screening, se não tiver condições de avaliar independentemente sua visão. Devem também manter controle oftalmológico anual.  
Ressalta-se que as frequências de monitoramento sugeridas anteriormente podem ser modificadas de acordo com o estado clínico do paciente e a avaliação médica.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Alguns medicamentos recomendados para o tratamento da AIJ podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
- Antes do início do uso de MMCD biológicos e com objetivo de realizar o planejamento terapêutico adequado, deve-  
- se considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A  
- radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa, independente de sinais e sintomas.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o  
- teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da  
- Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de MMCD biológicos após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, a critério da equipe de saúde assistente, o início de uso de MMCD biológicos pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
- Nos casos de troca do MMCD biológicos, não é necessário repetir as condutas preconizadas para início de tratamento.  
25  
Durante o acompanhamento da pessoa em uso de MMCD biológicos, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o  
- tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso dos MMCD biológicos não influencie o resultado dos exames, pacientes que realizaram a PT antes do  
- início do tratamento com MMCD biológicos devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com MMCD biológicos devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer  
- momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da  
- ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos.  
Pacientes com artrite idiopática juvenil devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento. Preferentemente, que o tratamento seja orientado por reumatologista ou pediatra com experiência em reumatologia.  
A prescrição de medicamentos biológicos dependerá da disponibilidade dos medicamentos da Assistência Farmacêutica no âmbito do SUS.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem: -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
1. Merino R dIJ, García-Consuegra J. Evaluation of revised International League of Associations for Rheumatology classification criteria for juvenile idiopathic arthritis in Spanish children (Edmonton 2001). J Rheumatol. 2005;32(3):559-61.  
26  
2. Martini A RA, Avcin T, Beresford MW, Burgos-Vargas R, Cuttica R, Ilowite NT, Khubchandani R, Laxer RM, Lovell DJ, Petty RE, Wallace CA, Wulffraat NM, Pistorio A, Ruperto N, Pediatric Rheumatology International Trials Organization (PRINTO). Toward New Classification Criteria for Juvenile Idiopathic Arthritis: First Steps, Pediatric Rheumatology International Trials Organization International Consensus. J Rheumatol. 2019;46(2).  
3. Petty RE LR, Lindsley CB, Wedderburn LR. . Textbook of Pediatric Rheumatology. Elsevier ae, editor2016.  
4. Giancane G CA, Lanni S, Davi S, Schiappapietra B, Ravelli A. Juvenile Idiopathic Arthritis: Diagnosis and Treatment. Rheumatol Ther. 2016;3(2):187-207.  
5. Combe B LR, Daien CI, Hua C, Aletaha D, Álvaro-Gracia JM, Bakkers M, Brodin N, Burmester GR, Codreanu C, Conway R, Dougados M, Emery P, Ferraccioli G, Fonseca J, Raza K, Silva-Hernández L, Smolen JS, Skingle D, Szekanecz Z, Kvien TK, van der Helm-van Mil A, van Vollenhoven R. Annals of the Rheumatic Diseases 2016 update of the EULAR recommendations for the management of early arthritis. Ann Reum Dis. 2017;76(6):948-59.  
6. Yasin S SG. Systemic juvenile idiopathic arthritis and macrophage activation syndrome: update on pathogenesis and treatment. Curr Opin Rheumatol. 2018;30(5):514-20.  
7. Ravelli A MF, Davì S, Horne A, Bovis F, Pistorio A, Aricò M, Avcin T, Behrens EM, De Benedetti F, Filipovic L, Grom AA8 Henter JI, Ilowite NT, Jordan MB, Khubchandani R, Kitoh T, Lehmberg K, Lovell D, Miettunen P, Nichols KE, Ozen S, Pachlopnik Schmid J, Ramanan AV, Russo R, Schneider R, Sterba G, Uziel Y, Wallace C, Wouters C, Wulffraat N, Demirkaya E, Brunner HI, Martini A, Ruperto N, Cron RQ; Paediatric Rheumatology International Trials Organisation; Childhood Arthritis and Rheumatology Research Alliance; Pediatric Rheumatology Collaborative Study Group; Histiocyte Society. 2016 Classification Criteria for Macrophage Activation Syndrome Complicating Systemic Juvenile Idiopathic Arthritis: A European League Against Rheumatism/American College of Rheumatology/Paediatric Rheumatology International Trials Organisation Collaborative Initiative. Arthritis & rheumatology (Hoboken, NJ). 2016;68(3):566-76.  
8. Bracaglia C dGK, Pires Marafon D, Guilhot F, Ferlin W, Prencipe G, Caiello I, Davì S, Schulert G, Ravelli A, Grom AA, de Min C, De Benedetti F. Elevated circulating levels of interferon-γ and interferon-γ-induced chemokines characterise patients with macrophage activation syndrome complicating systemic juvenile idiopathic arthritis. Ann Rheumat Dis. 2017;76(1):166.  
9. Consolaro A NG, Lanni S, Solari N, Martini A, Ravelli A. Toward a treat-to-target approach in the management of juvenile idiopathic arthritis. Clinical and experimental rheumatology. 2012;30(4 Suppl 73):S157-62.  
10. Ravelli A CA, Horneff G, Laxer RM, Lovell DJ, Wulffraat NM, Akikusa JD, Al-MAyouf SM, Antón J, Avcin T, Berard RA, Beresford MW, Burgos-Vargas R, Cimaz R, De Benedetti F, Demirkaya E, Foell D, Itoh Y, Lahdenne P, Morgan EM, Quartier P, Ruperto N, Russo R, Saad-Magalhães C, Sawhey S, Scott C, Shenoi S, Swart JF, Uziel Y, Vastert Sj, Smolen JS. Treating juvenile idiopathic arthritis to target: recommendations of an international task force. Ann Reum Dis. 2018;77(6):81928.  
11. Hinze CH HD, Lainka E, Haas JP, Speth F, Kallinich T, Rieber N, Hufnagel M, Jansson AF, Hedrich C, Winowski H, Berger T, Foeldvari I, Ganser G, Hospach A, Huppertz HI, Mönkemöller K, Neudorf U, Weißbarth-Riedel E, Wittkowski H, Horneff G, Foell D; PRO-KIND SJIA project collaborators. Practice and consensus-based strategies in diagnosing and managing systemic juvenile idiopathic arthritis in Germany. Pediatric rheumatology online journal. 2018;16(1).  
12. Stoll ML CR. Treatment of juvenile idiopathic arthritis: a revolution in care. Pediatric rheumatology online journal. 2014;12:13.  
13. DeWitt EM KY, Beukelman T, Nigrovic PA, Onel K, Prahalad S, Schneider R, Stoll ML, Angeles-Han S, Milojevic D, Schikler KN, Vehe RK, Weiss JE, Weiss P, Ilowite NT, Wallace CA; . Consensus treatment plans for new-onset systemic juvenile idiopathic arthritis. Juvenile Idiopathic Arthritis Disease-specific Research Committee of Childhood Arthritis Rheumatology and Research Alliance. Arthritis care & research. 2012;64(7):1001-10.  
27  
14. Ilowite NT1 SC FB, Grom A, Schanberg LE, Giannini EH, Wallace CA, Schneider R, Kenney K, Gottlieb B, Hashkes PJ, Imundo L, Kimura Y, Lang B, Miller M, Milojevic D, O'Neil KM, Punaro M, Ruth N, Singer NG, Vehe RK, Verbsky J, Woodward A. Algorithm development for corticosteroid management in systemic juvenile idiopathic arthritistrial using consensus methodology. Pediatr Rheumatol. 2012;10(1):31.  
15. Wallace CA GE, Spalding SJ, Hashkes PJ, O'Neil KM, Zeft AS, Szer IS, Ringold S, Brunner HI, Schanberg LE, Sundel RP, Milojevic D, Punaro MG, Chira P, Gottlieb BS, Higgins GC, Ilowite NT, Kimura Y, Hamilton S, Johnson A, Huang B, Lovell DJ; Childhood Arthritis and Rheumatology Research Alliance. Trial of early aggressive therapy in polyarticular juvenile idiopathic arthritis. Arthritis and rheumatism. 2012;64(6):2012-21.  
16. Brasil. Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância Epidemiológica, Manual de recomendações para o controle da tuberculose no Brasil. Brasília: Ministério da Saúde, 2011. Disponívem em: http://bvsms.saude.gov.br/bvs/publicacoes/manual_recomendacoes_controle_tuberculose_br asil.pdf  
17. Brasil. Ministério da Saúde. Calendário Nacional de Vacinação. Brasília: Ministério da Saúde, 2019. Disponível em: http://www.saude.gov.br/saude-de-a-z/vacinacao/calendario-vacinacao.  
18. Joost Swart GG GH, Bo Magnusson, Michael Hofer, Еkaterina Alexeeva, Violeta Panaviene, Brigitte Bader-Meunier, Jordi Anton, Susan Nielsen, Fabrizio De Benedetti, Sylvia Kamphuis, Valda Staņēviča, Maria Tracahana, Laura Marinela Ailioaie, Elena Tsitsami, Ariane Klein, Kirsten Minden, Ivan Foeldvari, Johannes Peter Haas, Jens Klotsche, Anna Carin Horne, Alessandro Consolaro, Francesca Bovis, Francesca Bagnasco, Angela Pistorio, Alberto Martini, Nico Wulffraat, Nicolino Ruperto, for the Paediatric Rheumatology International Trials Organisation (PRINTO). BiKeR and the board of the Swedish Registry Pharmacovigilance in juvenile idiopathic arthritis patients treated with biologic or synthetic drugs: combined data of more than 15,000 patients from Pharmachild and national registries. Arthritis research & therapy. 2018;20:285.  
19. Papadopoulou C KM, Gonzalez-Fernandez MI, Bohm M, Nieto-Gonzalez JC, Pistorio A, Lanni S, Consolaro A, Martini A, Ravelli A. Delineating the role of multiple intraarticular corticosteroid injections in the management of juvenile idiopathic arthritis in the biologic era. Arthtritis Care Res (Hoboken). 2013;65(7):1112-20. 20. Giancane G AA, Rosina S, Tibaldi J, Consolaro A, Ravelli A. Recent therapeutic advances in juvenile idiopathic arthritis. Best Pract Res Clin Rheumatol. 2017;31(4):476-87.  
21. Aggarwal A MD. Enthesitis-related arthritis. Clinical rheumatology. 2015;34(11):1839-46.  
22. Horneff G B-VR, Constantin T, Foeldvari I, Vojinovic J, Chasnyk VG, Dehoorne J, Panaviene V, Susic G, Stanevica V, Kobusinska K, Zuber Z, Mouy R, Rumba-Rozenfelde I, Breda L, Dolezalova P, Job-Deslandre C, Wulffraat N, Alvarez D, Zang C, Wajdula J, Woodworth D, Vlahos B, Martini A, Ruperto N; Paediatric Rheumatology International Trials Organisation (PRINTO). Efficacy and safety of open-label etanercept on extended oligoarticular juvenile idiopathic arthritis, enthesitis-related arthritis and psoriatic arthritis: part 1 (week 12) of the CLIPPER study. Annals of the rheumatic diseases. 2014;73(6):1114-22.  
23. Singh JA FD, Bharat A, Curtis JR, Kavanaugh AF, Kremer JM, Moreland LW, O'Dell J, Winthrop KL, Beukelman T, Bridges SL Jr, Chatham WW, Paulus HE, Suarez-Almazor M, Bombardier C, Dougados M, Khanna D, King CM, Leong AL, Matteson EL, Schousboe JT, Moynihan E, Kolba KS, Jain A, Volkmann ER, Agrawal H, Bae S, Mudano AS, Patkar NM, Saag KG. 2012 update of the 2008 American College of Rheumatology recommendations for the use of disease-modifying antirheumatic drugs and biologic agents in the treatment of rheumatoid arthritis. Arthritis care & research. 2012;64(5):625-39. 24. Silva JMF, Ladomenou F, Carpenter B, Chandra S, Sedlacek P, Formankova R, et al. Allogeneic hematopoietic stem cell transplantation for severe, refractory juvenile idiopathic arthritis. Blood Advances. 2018;2(7):777-86. 25. Brinkman DM dKI, ten Cate R, van Rossum MA, Bekkering WP, Fasth A, van Tol MJ, Kuis W, Wulffraat NM, Vossen JM. Autologous stem cell transplantation in children with severe progressive systemic or polyarticular juvenile idiopathic arthritis: long-term follow-up of a prospective clinical trial. Arthritis and rheumatism. 2007;56(7):2410-21.  
28  
26. Sen ES DA, Ramanan AV. Uveitis associated with juvenile idiopathic arthritis. Nature reviews Rheumatology. 2015;11(6):338-48.  
27. Heiligenhaus A MK, Tappeiner C, Baus H, Bertram B, Deuter C, Foeldvari I, Föll D, Frosch M, Ganser G2, Gaubitz M6, Gunther A2, Heinz C3, Horneff G2, Huemer C2, Kopp I7, Lommatzsch C3, Lutz T2, Michels H2, Neß T3, Neudorf U2, Pleyer U3, Schneider M6, Schulze-Koops H6, Thurau S3, Zierhut M3, Lehmann HW2. Update of the evidence based, interdisciplinary guideline for anti-inflammatory treatment of uveitis associated with juvenile idiopathic arthritis. Semin Arthritis Rheum. 2019;49(1):43-55.  
28. A phase II trial of tocilizumab in anti TNF refractory patients with JIA associated uveitis (APTITUDE study) [Internet]: Biomed Central; 2015 [Available from: http://www.isrctn.com/ISRCTN95363507.  
29. Tappeiner C MM, Adán A, Anton J, Ramanan AV, Carreno E, Mackensen F, Kotaniemi K, de Boer JH, Bou R, de Vicuña CG, Heiligenhaus A. Evidence for tocilizumab as a treatment option in refractory uveitis associated with juvenile idiopathic arthritis. J Rheumatol. 2016;43(12).  
30. Tsang AC RJ, Gottlieb C. Tocilizumab for severe chronic anterior uveitis associated with juvenile idiopathic arthritis in a pediatric patient. Ocul Immunol Inflamm. 2014;22(2):155-7.  
31. Calvo-Río V S-GM, Calvo I, González-Fernández MI, López-Montesinos B, Mesquida M, Adán A, Hernández MV, Maíz O, Atanes A, Bravo B, Modesto C, Díaz-Cordovés G, Palmou-Fontana N, Loricera J, González-Vela MC, Demetrio-Pablo R, Hernández JL, González-Gay MA, Blanco R. Anti-interleukin- 6 receptor tocilizumab for severe juvenile idiopathic arthritisassociated uveitis refractory to anti-tumor necrosis factor therapy: a multicenter study of twenty-five patients. Arthritis & rheumatology (Hoboken, NJ). 2017;69(3):668-75.  
32. Burmester GR R-RA, Cantagrel A, Hall S, Leszczynski P, Feldman D, Rangaraj MJ, Roane G, Ludivico C, Lu P, Rowell L, Bao M, Mysler EF. A randomised, double-blind, parallelgroup study of the safety and efficacy of subcutaneous tocilizumab versus intravenous tocilizumab in combination with traditional disease-modifying antirheumatic drugs in patients with moderate to severe rheumatoid arthritis (SUMMACTA study). Annals of the rheumatic diseases. 2014;73(1):69-74.  
33. ClinicalTrials.Gov. Long-term extension study to evaluate the safety and efficacy of subcutaneous tocilizumab in patients with polyarticularcourse and systemic juvenile idiopathic arthritis Bethesda, MD: National Library of Medicine (US); 2017 [Available from: https://clinicaltrials.gov/ct2/show/NCT02165345.  
34. Brunner HI TN, Vega-Cornejo G, Louw I, Berman A, Calvo Penadés I, Antón J, Ávila-Zapata F, Cuttica R, Horneff G, Foeldvari I, Keltsev V, Kingsbury DJ, Viola DO, Joos R, Lauwerys B, Paz Gastañaga ME, Rama ME, Wouters C, Bohnsack J, Breedt J, Fischbach M, Lutz T, Minden K, Miraval T, Ally MMTM, Rubio-Pérez N, Solau Gervais E, van Zyl R, Li X, Nys M, Wong R, Banerjee S, Lovell DJ, Martini A, Ruperto N; Paediatric Rheumatology International Trials Organisation (PRINTO) and the Pediatric Rheumatology Collaborative Study Group (PRCSG). Subcutaneous abatacept in patients with polyarticularcourse juvenile idiopathic arthritis: results from a phase III open-label study Arthritis & rheumatology (Hoboken, NJ). 2018;70(7):1144-54.  
35. Maggi L CR, Capone M, Santarlasci V, Rossi MC, Mazzoni A, Montaini G, Pagnini I, Giani T, Simonini G, Scaletti C, Liotta F, Maggi E, Annunziato F, Cosmi L. Immunosuppressive Activity of Abatacept on Circulating T Helper Lymphocytes from Juvenile Idiopathic Arthritis Patients. Int Arch Allergy Immunol. 2016;171(1):45-53.  
36. Birolo C ZM, Arsenyeva S, Cimaz R, Miserocchi E, Dubko M, Deslandre CJ, Falcini F, Alessio M, La Torre F, Denisova E, Martini G, Nikishina I, Zulian F. Comparable Efficacy of Abatacept Used as First-line or Second-line Biological Agent for Severe Juvenile Idiopathic Arthritis-related Uveitis. J Rheumatol. 2016;43(11):2068-73.  
29  
37. Jabs DA NR, Rosenbaum JT; Standardization of Uveitis Nomenclature (SUN) Working Group. The Standardization of Uveitis Nomenclature (SUN) Working Group. Standardization of Uveitis Nomenclature for Reporting Clinical Data. Am J Ophtalmol. 2005;140(3):509-16.  
38. Angeles-Han ST RS, Beukelman T, Lovell D, Cuello CA, Becker ML, Colbert RA, Feldman BM, Holland GN, Ferguson PJ, Gewanter H10, Guzman J, Horonjeff J, Nigrovic PA, Ombrello MJ, Passo MH, Stoll ML, Rabinovich CE, Sen HN, Schneider R, Halyabar O, Hays K, Shah AA, Sullivan N, Szymanski AM, Turgunbaev M, Turner A, Reston J. 2019 American College of Rheumatology/Arthritis Foundation Guideline for the Screening, Monitoring, and Treatment of Juvenile Idiopathic ArthritisAssociated Uveitis. Arthritis Care Res (Hoboken) 2019 Jun;71(6):703-16.  
39. Bou R AA, Borrás F, Bravo B, Calvo I, De Inocencio J, Díaz J, Escudero J, Fonollosa A, de Vicuña CG, Hernández V, Merino R, Peralta J, Rúa MJ, Tejada P, Antón J. Clinical management algorithm of uveitis associated with juvenile idiopathic arthritis: interdisciplinary panel consensus. Rheumatology international. 2015;35(5):777-85.  
40. Ruperto N MK, Gerloni V, Wulffraat N, de Oliveira SK, Falcini F, Dolezalova P, Alessio M, Burgos-Vargas R, Corona F, Vesely R, Foster H, Davidson J, Zulian F, Asplin L, Baildam E, Consuegra JG, Ozdogan H, Saurenmann R, Joos R, Pistorio A, Woo P, Martini A; Pediatric Rheumatology International Trials Organization. A randomized trial of parenteral methotrexate comparing an intermediate dose with a higher dose in children with juvenile idiopathic arthritis who failed to respond to standard doses of methotrexate. ARTHRITIS & RHEUMATISM. 2004;50(7):2191-201.  
41. Ravelli A MD, Viola S, Ruperto N, Pistorio A, Martini A. Efficacy of folinic acid in reducing methotrexate toxicity in juvenile idiopathic arthritis. Clinical and experimental rheumatology. 1999;17(5):625-7.  
42. Silverman E MR, Spiegel L, Jung LK, Saurenmann RK, Lahdenne P, Horneff G, Calvo I, Szer IS, Simpson K, Stewart JA, Strand V; Leflunomide in Juvenile Theumatoid Arthritis (JRA) Investigator Group. Leflunomide or methotrexate for juvenile rheumatoid arthritis. The New England journal of medicine. 2005;352(16):1655-66.  
43. Silverman E SL, Hawkins D, Petty R, Goldsmith D, Schanberg L, Duffy C, Howard P, Strand V. Long-term open-label preliminary study of the safety and efficacy of leflunomide in patients with polyarticular-course juvenile rheumatoid arthritis. Arthritis and rheumatism. 2005;52(2):554-62.  
44. Brunner HI RN, Zuber Z, Keane C, Harari O, Kenwright A, Lu P, Cuttica R, Keltsev V, Xavier RM, Calvo I, Nikishina I, Rubio-Pérez N, Alexeeva E, Chasnyk V, Horneff G, Opoka-Winiarska V, Quartier P, Silva CA, Silverman E, Spindler A, Baildam E, Gámir ML, Martin A, Rietschel C, Siri D, Smolewska E, Lovell D, Martini A, De Benedetti F; Paediatric Rheumatology International Trials Organisation PRINTO; Pediatric Rheumatology Collaborative Study Group (PRCSG). Efficacy and safety of tocilizumab in patients with polyarticular-course juvenile arthritis: results from a phase 3, randomised, double-bling withdrawal trial. Annals of the rheumatic diseases. 2015;74(6):1110-7.  
45. De Benedetti F, Brunner HI, Ruperto N, Kenwright A, Wright S, Calvo I, et al. Randomized trial of tocilizumab in systemic juvenile idiopathic arthritis. The New England journal of medicine. 2012;367(25):2385-95. 46. Skorpen CG HM, Tincani A. . The EULAR points to consider for use of antirheumatic drugs before pregnancy, and during pregnancy and lactation. . Annals of the rheumatic diseases. 2016;75:795-810. 47. Singh JA SK, Bridges SL et al. . 2015 American College of Rheumatology Guideline for the Treatment of Rheumatoid Arthritis. . Arthritis & rheumatology (Hoboken, NJ). 2016;68:1-26. 48. Beukelman T PN, Saag KG et al.  . 2011 American College of Rheumatology Recommendations for the Treatment of Juvenile Idiopathic Arthritis: Initiation and Safety Monitoring of Therapeutic Agents for the Treatment of Arthritis and Systemic Features. . Arthritis care & research. 2011;63:465-82  
49. Swart JF PvDE, Wulffraat NM, de Rook S  Clinical Juvenile Arthritis Disease Activity Score proves to be a useful tool in treat-to-target therapy in juvenile idiopathic arthritis. BMJ. 2018;77(3):336-42.  
30  
50. Consolaro A RA. Defining criteria for disease activity states in juvenile idiopathic arthritis. Rheumatology (Oxford, England). 2016;55(4):595-6.  
51. Consolaro A RN, Bazso A, Pistorio A, Magni-Manzoni S, Filocamo G, Malattia C, Viola S, Martini A, Ravelli A; Paediatric Rheumatology International Trials Organisation. Development and validation of a composite disease activity score for juvenile idiopathic arthritis. Arthritis Rheumat. 2009;61(5):658-66.  
52. Shoop-Worrall SJW VS, Baildam E, Chieng A, Davidson J, Foster H, Ioannou Y, McErlane F, Wedderburn LR, Thomson W, Hyrich KL. How common is clinically inactive disease in a prospective cohort of patients with juvenile idiopathic arthritis? The importance of definition. Annals of the rheumatic diseases. 2017;76(8).  
53. Wallace CA GE, Huang B, Itert L, Ruperto N; Childhood Arthritis Rheumatology Research Alliance; Pediatric Rheumatology Collaborative Study Group; Paediatric Rheumatology International Trials Organisation. American College of Rheumatology provisional criteria for defining clinical inactive disease in select categories of juvenile idiopathic arthritis. Arthritis care & research. 2011;63(7):929-36.  
54. Wallace CA RN, Giannini E; Childhood Arthritis and Rheumatology Research Alliance; Pediatric Rheumatology International Trials Organization; Pediatric Rheumatology Collaborative Study Group. Preliminary criteria for clinical remission for select categories of juvenile idiopathic arthritis. J Rheumatol. 2004;31(11):2290-4.  
55. BSPAR R. Guidelines for screening for uveitis in juvenile idiopathic arthritis: The Royal College of Ophtalmologists; 2006 [Available from: https://www.rcophth.ac.uk/wp-content/uploads/2017/08/2006_PROF_046_JuvenileArthritis-updated-cr  
31  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Eu, _______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de naproxeno, sulfassalazina, metotrexato, ciclosporina, leflunomida, metilprednisolona, adalimumabe, etanercepte, infliximabe, abatacepte e tocilizumabe, indicados para o tratamento da artrite idiopática juvenil.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico ___________________________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Expresso também minha concordância e espontânea vontade em submeter-me ao referido tratamento, assumindo a responsabilidade e os riscos pelos eventuais efeitos indesejáveis. Assim, declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber pode(m) trazer os seguintes benefícios:  
- prevenção das complicações da doença;  
- controle da atividade da doença;  
- melhora da capacidade de realizar atividades funcionais;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos colaterais e riscos:  
- os riscos na gestação e na amamentação já são conhecidos; portanto, caso engravide, devo avisar imediatamente o  
- médico;  
- medicamentos classificados na gestação como categoria B (estudos em animais não mostraram anormalidades nos descendentes, porém não há estudos em humanos; risco para o bebê muito improvável): infliximabe, etanercepte, adalimumabe e sulfassalazina (no primeiro trimestre);  
- medicamentos classificados na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos): ciclosporina, metilprednisolona, abatacepte e tocilizumabe;  
- medicamento classificado na gestação como categoria D (há evidências de riscos ao feto, mas um benefício potencial  
- pode ser maior do que os riscos) sulfassalazina (no terceiro trimestre);  
- medicamentos classificados na gestação como categoria X (estudos em animais ou em humanos claramente mostraram  
- risco para o bebê que suplantam quaisquer potenciais benefícios, sendo contraindicados na gestação): leflunomida e metotrexato;  
- efeitos adversos do naproxeno: dor abdominal, sede, constipação, diarreia, dispneia, náusea, estomatite, azia, sonolência, vertigens, enxaqueca, tontura, erupções cutâneas, prurido, sudorese, ocorrência de distúrbios auditivos e visuais, palpitações, edemas, dispepsia e púrpura;  
- efeitos adversos da sulfassalazina: dores de cabeça, aumento da sensibilidade aos raios solares, alergias de pele graves, dores abdominais, náusea, vômitos, perda de apetite, diarreia, hepatite, dificuldade para engolir, diminuição do número dos glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos do sangue (anemia hemolítica), diminuição do número de plaquetas no sangue, falta de ar associada a tosse e febre (pneumonite intersticial), dores articulares, cansaço e reações alérgicas;  
- efeitos adversos da ciclosporina: disfunção renal, tremores, aumento da quantidade de pelos no corpo, pressão alta, hipertrofia gengival, aumento dos níveis de colesterol e triglicerídios, formigamentos, dor no peito, infarto do miocárdio,  
32  
batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, gastrite, úlcera péptica, soluços, inflamação na boca, dificuldade para engolir, hemorragias, inflamação do pâncreas, prisão de ventre, desconforto abdominal, síndrome hemolíticourêmica, diminuição das células brancas do sangue, linfoma, calorões, hiperpotassemia, hipomagnesemia, hiperuricemia, toxicidade para os músculos, disfunção respiratória, sensibilidade aumentada a temperatura e reações alérgicas, toxicidade renal e hepática e ginecomastia;  
- efeitos adversos da metiprednisolona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, e manifestação de diabetes melito;  
- efeitos adversos do metotrexato: convulsões, encefalopatia, febre, calafrios, sonolência,  queda de cabelo, espinhas, furúnculos, alergias de pele leves a graves, sensibilidade à luz, alterações da pigmentação da pele e de mucosas, náusea,  vômitos, perda de apetite, inflamação da boca, úlceras de trato gastrointestinal, hepatite, cirrose e necrose hepática, diminuição das células brancas do sangue e das plaquetas, insuficiência renal, fibrose pulmonar e diminuição das defesas imunológicas do organismo com ocorrência de infecções;  
- efeitos adversos da leflunomida: pressão alta, dor no peito, palpitações, aumento do número de batimentos do coração, vasculite, varizes, edema, infecções respiratórias, sangramento nasal, diarreia, hepatite, náusea, vômitos, perda de apetite, gastrite,  gastroenterite, dor abdominal, azia, gazes, ulcerações na boca, pedra na vesícula, prisão de ventre, desconforto abdominal, sangramento nas fezes, candidíase oral, aumento das glândulas salivares, boca seca, alterações dentárias,  distúrbios do paladar, infecções do trato geniturinário, ansiedade, depressão, fraqueza, dores de cabeça, tonturas, febre, sonolência, distúrbios do sono, formigamentos, alteração da cor e queda de cabelo, alergias de pele, coceira, pele seca, espinhas, hematomas, alterações das unhas, alterações da cor da pele, úlceras de pele, hipopotassemia, diabetes melito, hiperlipidemia, hipertireoidismo, desordens menstruais, dores pelo corpo, alteração da visão, anemia, infecções e alteração da voz;  
- efeitos adversos de adalimumabe, etanercepte, infliximabe: reações no local da aplicação da injeção como dor e coceiras, dor de cabeça, tosse, náusea, vômitos, febre, cansaço, alteração na pressão arterial; reações mais graves: infecções oportunísticas fúngicas e bacterianas do trato respiratório superior, como faringite, rinite, laringite, tuberculose, histoplasmose, aspergilose e nocardiose, podendo, em casos raros, ser fatal;  
- efeitos adversos de abatacepte: reações no local da aplicação da injeção ou reações alérgicas durante ou após a infusão, dor de cabeça, nasofaringite, enjoos e  risco aumentado a uma variedade de infecções, como herpes-zóster, infecção urinária, gripe, pneumonia, bronquite e infecção localizada. A tuberculose pode ser reativada ou iniciada com o uso do medicamento e aumento de risco para alguns tipos de câncer (abatacepte);  
- efeitos adversos do tocilizumabe: reações no local da aplicação da injeção e durante a infusão, alergias, coceira, urticária, dor de cabeça, tonturas, aumento da pressão sanguínea, tosse, falta de ar, feridas na boca, aftas, dor abdominal e  risco aumentado a uma variedade de infecções, como infecções de vias aéreas superiores, celulite, herpes simples e herpes-zóster, alterações nos exames laboratoriais (aumento das enzimas do fígado, bilirrubinas, aumento do colesterol e triglicerídios);  
- alguns medicamentos biológicos aumentam o risco de tuberculose, devendo ser realizada antes do início do tratamento pesquisa de infecção ativa ou de tuberculose latente, para tratamento apropriado;  
- medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula;  
- o risco de ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvêlo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a) inclusive em caso de desistir da usar o(s) medicamento(s).  
33  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento,  
desde que assegurado o anonimato.  (   )  Sim       (   ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (  ) naproxeno   (  ) sulfassalazina   (  ) metotrexato   (  ) ciclosporina    (  ) leflunomida    (  ) metilprednisolona   (  ) adalimumabe  
- (  ) etanercepte  (  ) infliximabe    (  ) abatacepte    (  ) tocilizumabe  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**Nota 1** : A prescrição de medicamentos biológicos dependerá da disponibilidade dos medicamentos da Assistência Farmacêutica no âmbito do SUS.  
**Nota 2** : Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 3** : A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
Nota 4: A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
34

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 34/2026, identificou-se a necessidade de ajuste do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Idiopática Juvenil, para correção de sobreposição de faixas de peso relacionadas à posologia de administração do medicamento abatacepte, disposta no “Quadro 5. Medicamentos disponíveis no SUS e suas respectivas posologias para tratamento da AIJ”. Na coluna relaciona ao esquema de administração do abatacepte, a faixa de peso “60-100 kg” foi substituída por “75-100 kg”.  
O tema foi apresentado como informe à 136ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 19 de maio de 2026.  
**Atualização do Protocolo Clínico e Diretrizes Terapêuticas Da Artrite Idiopática Juvenil após a priorização de abatacepte 250 mg para pacientes que atendam a critérios específicos - versão 2025.**

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Idiopática Juvenil foi priorizar o uso de abatacepte 250 mg para pacientes que atendam a critérios específicos, devido à sua descontinuação temporária junto à Agência Nacional de Vigilância Sanitária (Anvisa), conforme petição protocolada em 15 de março de 2022. Contudo, destaca-se que poderá ocorrer alterações posteriores conforme regularização e continuidade no fornecimento do medicamento ao Ministério da Saúde. Ressalta-se que esta demanda foi oriunda de solicitação do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS).  
Considerando a versão do PCDT da Artrite Reumatoide, aprovada por meio do Relatório de Recomendação nº 653/2021, esta atualização rápida focou na priorização de abatacepte 250 mg para pacientes que atendam a critérios específicos no âmbito do SUS.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
A atualização rápida do Protocolo foi realizada pela Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SCTIE/MS).

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
A proposta de atualização do PCDT de Artrite Idiopática Juvenil foi apresentada na 123ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em março de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a  
35  
proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 139ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
A Consulta Pública nº 23/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Idiopática Juvenil, foi realizada entre os dias 08/05/2025 e 27/05/2025. Foram recebidas 03 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-da-cp-23-2025-pcdt-da-artrite-idiopaticajuvenil</u>

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Considerando a versão do PCDT da Artrite Idiopática Juvenil, aprovado por meio do Relatório de Recomendação nº 653/2021, esta atualização rápida focou na priorização da apresentação intravenosa de abatacepte 250 mg.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
O Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Idiopática Juvenil (AIJ) teve início com reunião presencial para delimitação do escopo do PCDT. Dsta reunião participaram três membros do Comitê Gestor, quatro membros de áreas técnicas do Ministério da Saúde (Coordenação-Geral de Atenção Especializada, do Departamento de Atenção Especializada e Temática, da Secretaria de Atenção à Saúde do Ministério da Saúde - CGAE/DAET/SAS/MS e Departamento de Assistência Farmacêutica do Ministério da Saúde - DAF/SCTIE/MS) e por nove membros do grupo elaborador, sendo seis especialistas (uma oftalmologista, quatro reumatologistas, sendo uma pediátrica, e uma farmacêutica), dois metodologistas e a coordenadora administrativa do projeto PCDT no Hospital Alemão Oswaldo Cruz. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e de confidencialidade.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do protocolo, embasado no disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009 (1), e nas Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde (2), sendo definidas as seções do documento.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Deste modo, as especialistas foram orientadas a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO ( **Figura A** ) para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião.  
36  
**Figura A - Definição da questão de pesquisa estruturada de acordo com o acrônimo pico.**  
- P •População ou condição clínica •Intervenção, no caso de estudos experimentais •Fator de exposição, em caso de estudos  
- I observacionais •Teste índice, nos casos de estudos de acurácia diagnóstica  
- •Controle, de acordo com tratamento/níveis de  
- C exposição do fator/exames disponíveis no SUS  
- •Desfechos: sempre que possível, definidos a priori, de  
- O acordo com sua importância  
Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já disponíveis no SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.  
Para o PCDT da AIJ, apenas duas questões de pesquisa foram levantadas, referentes ao uso do canaquinumabe para o tratamento de pacientes com AIJ sistêmica, com ou sem síndrome de ativação macrofágica:  
**Questão 1: “Qual a eficácia e a segurança do canaquinumabe para o tratamento da AIJ com manifestação**

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Nesta pergunta, os pacientes (P) tinham AIJ sistêmica; a intervenção (I) era o canaquinumabe; os comparadores (C) eram o tocilizumabe e os corticoides sistêmicos; e os desfechos (O), a ausência de febre em sete dias e a queda da PCR em 50%, 6 a 12 meses sem corticoides, com doença inativa (JADAS clínico; EVA médico, EVA paciente), falha terapêutica e remissão (com medicamento e sem medicamento).  
**Questão 2: “Qual a eficácia e a segurança do canaquinumabe para o tratamento da AIJ com síndrome de ativação macrofágica?”**  
Nesta pergunta, os pacientes (P) tinham AIJ sistêmica com síndrome de ativação macrofágica; a intervenção (I) era o canaquinumabe; os comparadores (C) eram o tocilizumabe, a ciclosporina e os corticoides sistêmicos; e os desfechos (O), a diminuição de febre, redução de citopenia, ferritina, fibrinogênio, AST/TGO e ALT/TGP.  
A relatoria das seções foi distribuída entre os especialistas posteriormente à circulação da ata da reunião de escopo, devido à indisponibilidade de tempo. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas à ocasião do consenso.  
Acordou-se que a equipe de metodologistas envolvida no processo ficaria responsável pela busca e avaliação de evidências, segundo a metodologia GRADE. Ambas as questões de pesquisa foram respondidas por uma única estratégia de busca. Por conveniência, as questões foram unificadas, sem prejuízo no processo de seleção e análise das evidências. Deste modo, a busca na literatura foi realizada nas bases PubMed e Embase e validadas no Google Scholar e Epistemonikos. A  
37  
estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por dois metodologistas, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia e segurança. Adicionalmente, checou-se à identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e séries de casos. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto deste Apêndice 2.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel®. As características dos participantes nos estudos foram definidas com base na importância para a interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (3), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (4), os estudos observacionais pela ferramenta Newcastle-Ottawa (5). Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ) (6), de forma qualitativa, visto que, dada a heterogeneidade dos dados, não foi possível conduzir meta-análise do conjunto de evidências. Este foi avaliado para cada desfecho considerado no Protocolo, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles. Posteriormente, ainda de acordo com a metodologia GRADE, foi construída a tabela _Evidence to Decision_ (EtD), que sumariza os principais achados do processo de avaliação da tecnologia segundo aspectos que devem ser levados em consideração no momento de tomada de decisão sobre a incorporação do produto (magnitude do problema, benefícios, danos, balanço entre danos e benefícios, certeza na evidência, aceitabilidade, viabilidade de implementação, uso de recursos, custo-efetividade, equidade, valores e preferências dos pacientes) (7).  
Após a conclusão do relatório de recomendação do canaquinumabe e de sua apresentação ao Plenário na 80ª Reunião Ordinária da CONITEC, houve reunião de monitoramento e consenso, da qual participaram membros do grupo elaborador, sendo  
38  
as três especialistas e os dois metodologistas inicialmente envolvidos no processo. Nesta reunião, foram apresentados os resultados do relatório e realizado painel de consenso por meio do _webapp_ GRADEpro a partir das evidências levantadas. Nesta reunião, discutiu-se ainda o progresso na escrita do PCDT e a necessidade de ajustes no documento e realizado consenso a respeito das evidências do canaquinumabe para o tratamento da AIJ. Para mais informações sobre a avaliação do canaquinumabe e o processo de tomada de decisão sobre a incorporação do medicamento, consultar a página da CONITEC, onde consta o Relatório de Recomendação deste medicamento (8).  
**Questão de pesquisa: “Qual a eficácia e a segurança do canaquinumabe para o tratamento da AIJ sistêmica com e sem síndrome de ativação macrofágica?”**

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
**Quadro A - Estratégias de busca nas bases de dado PubMed e Embase**  
|**Base de dados**|**Estratégia de Busca**|**Resultados**|
|---|---|---|
|Pubmed|(("canakinumab" [Supplementary Concept] OR canakinumab OR ilaris)) AND<br>("Arthritis, Juvenile"[Mesh] OR Juvenile Rheumatoid Arthritis OR Juvenile<br>Systemic Arthritis OR Juvenile Idiopathic Arthritis)|79|
||Data de acesso: 26/02/2019||
|Embase|('canakinumab'/exp OR 'canakinumab') AND [embase]/lim OR ilaris AND<br>[embase]/lim AND ('juvenile rheumatoid arthritis'/exp OR 'juvenile rheumatoid<br>arthritis') AND [embase]/lim OR (('juvenile'/exp OR juvenile) AND systemic<br>AND ('arthritis'/exp OR arthritis))|533|
||Data de acesso: 26/02/2019||

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
A busca das evidências resultou em 612 referências (79 no Pubmed e 533 no EMBASE). Destas, 77 foram excluídas por estarem duplicadas. Quinhentas e trinta e cinco referências foram triadas por meio da leitura de título e resumos, das quais 60 tiveram seus textos completos avaliados para confirmação da elegibilidade. Após a leitura do texto completo dos estudos, cinquenta e quatro estudos foram excluídos: (1) Três por tipo de estudo (9-11); (2) Dois por tipo de desfecho (12, 13); 2.1) Dois por tipo de comparador (14, 15); Quarenta e sete por tipo de publicação (16-62).  
Ao final, foram incluídas 06 referências, sendo dois ensaios clínicos randomizados contendo três relatos (63, 64), duas coortes (65, 66) e duas revisões sistemáticas com meta-análises indiretas (67, 68). A representação do processo de seleção das evidências encontra-se esquematizada no fluxograma a seguir ( **Figura B** ).  
39

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
<!-- Start of picture text -->
Publicações identificadas pela pesquisa nas<br>bases de dados: 612<br>PUBMED = 79<br>EMBASE= 533<br>Publicações após remoção de duplicatas: 535<br>Publicações excluídas segundo<br>critérios de exclusão: 475<br>Publicações excluídas segundo<br>Publicações selecionadas para leitura  critérios de exclusão: 54<br>completa: 60<br>Tipo de publicação: 47<br>Tipo de desfecho: 2<br>Tipo de comparador: 2<br>Tipo de estudo: 3<br>Estudos incluídos: 06 (07 relatos)<br>Coorte: 2<br>ECR: 2 (3 relatos)<br>RS: 2<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se no **Quadro B** . A caracterização dos participantes de cada estudo pode ser vista no **Quadro C** . Resultados de eficácia do canaquinumabe encontram-se nos **Quadros D** e **E** . No **Quadro F,** podem ser vistos os desfechos de segurança relacionados ao uso do canaquinumabe. A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista na **Tabela A** . Esta tabela corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. A **Tabela B** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
40  
**Quadro B - Características dos estudos incluídos para avaliar a eficácia e segurança do canaquinumabe em pacientes com artrite idiopática juvenil sistêmica.**  
|**Autor e ano**|**Desenho de**<br>**estudo**|**Objetivos**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|
|Otten et al.<br>2012|RS+ MA<br>indireta|Comparar, indiretamente, a eficácia de<br>agentes biológicos no tratamento da AIJ|3 ECR = 200 participantes|anakinra, canaquinumabe e<br>tocilizumabe|placebo, MMCD ou<br>biológicos entre si.|-|
|Tarp et al.<br>2016|RS+MA<br>indireta|Definir o melhor biológico para AIJ baseada<br>nos dados de eficácia e segurança dos ECR|5 ECR = 458 participantes|anaquinra, canaquinumabe,<br>tocilizumabe e rilonacepte|placebo, MMCD ou<br>biológicos entre si.|-|
|Ruperto et al.<br>2012|ECR fase III|Avaliar a eficácia e segurança do<br>canaquinumabe no tratamento da AIJ<br>sistêmica|84 no EC 1; 177 na parte 1<br>do EC 2 e 100 na parte 2 do<br>EC2.|Canaquinumabe|Placebo, nas partes<br>controladas|EC 1: 29 dias EC 2: 12 a 32 semanas|
|Woerner et al.<br>2015|Coorte<br>retrospectiva|Descrever efeitos da troca ou descontinuação<br>de um agente biológico e avaliar a proporção<br>de pacientes capazes de manter doença inativa<br>ou remissão clínica sem corticoides e após a<br>retirada da terapia com agente biológico|n=77|etanercept, anakinra,<br>canaquinumabe e tocilizumabe|Biológicos entre si|mediana (variação): 1,1 (0,5-8,0)<br>anos|
|Cabrera et al.<br>2018|Coorte<br>retrospectiva|Analisar e relatar a incidência de eventos<br>adversos de agentes biológicos em pacientes<br>pediátricos com doenças inflamatórias por<br>meio de uma coorte de vida real|n=813 (681 com AIJ)|etanercept, adalimumabe,<br>infliximabe, golimumabe,<br>anakinra, canaquinumabe,<br>rituximabe, abatacept e<br>tocilizumabe|Biológicos entre si|média (DP): 4,7 (3,1) anos|
|Ruperto et al.<br>2018|Extensão ECR<br>fase III|Avaliar a eficácia e segurança do<br>canaquinumabe em pacientes com AIJ<br>sistêmica em longo prazo|n= 144|Canaquinumabe|-|no mínimo 96 semanas com mediana<br>de tempo de exposição ao<br>canquinumabe de 3,5 anos (Q1 0,6;<br>Q3 4,4)|  
**Legenda:** RS: Revisão Sistemática; MA: Meta-análise; ECR: Ensaio Clínico Randomizado; EC: Ensaio Clínco; MMCD: Medicamento Modificador do Curso da Doença; DP: Desvio Padrão; Q: quartil; n: número da amostra.  
41  
**Quadro C - Características basais para os estudos que avaliaram a segurança e eficácia do canaquinumabe em pacientes com artrite idiopática juvenil sistêmica**  
|**Autor e**<br>**ano**|**Amostra (n)**|**Idade - média (DP)**|**Sexo F (%)**|**Tempo de doença - média**<br>**(DP)**|**Tratamento prévio**|**Número de**<br>**articulações**<br>**acometidas**|
|---|---|---|---|---|---|---|
|Otten et al.<br>2012|<br>11 ECR/659 pacientes|-|-|-|-|-|
|Tarp et al.<br>2016|5 ECR/ 458 pacientes|-|-|-|-|-|
|Ruperto et<br>al. 2012|84 no EC 1; 177 na parte<br>1 do EC 2 e 100 na parte<br>2 do EC2.|Idades medianas EC 1: Interv.<br>= 8 anos, Placebo = 9 anos;<br>Parte 1 do EC 2: 8 anos; Parte<br>2 do EC 2: Interv. e Placebo =<br>8 anos|EC 1: Interv. = 63%,<br>Placebo = 56%; Parte 1 do<br>EC 2: 55%; Parte 2 do EC 2:<br>Interv. = 56% Placebo =<br>54%|Medianas EC 1: Interv. = 2,3<br>anos, Placebo = 2,0 anos; Parte<br>1 do EC 2: 2,1 anos; Parte 2 do<br>EC 2: Interv. = 2,7 e Placebo =<br>1,8 anos|EC 1: Interv. = 37% anakinra, 2% Tocilizumabe,<br>33% Anti-TNF Placebo = 37% anakinra, 5%<br>tocilizumabe, 39% anti-TNF; Parte 1 do EC 2:<br>47% anakinra, 6% tocilizumabe, 35% anti-TNF;<br>Parte 2 do EC 2: Intv. = 50% anakinra, 8%<br>tocilizumabe, 28% anti-TNF e Placebo = 40%<br>anakinra, 2% tocilizumabe, 24 anti-TNF|-|
|Woerner et<br>al. 2015|<br>n=77: etanercept (n=12),<br>anakinra (n=51),<br>canaquinumabe (n=10),<br>tocilizumabe (n=2)|idade no diagnóstico (mediana<br>(IQR): Total: 3.8 (2,6–7,1)<br>anos/ canaquinumabe: 6.0<br>(5.0–8,4) anos/ Tocilizumabe:<br>3,3 (3,2–3,4) anos|Total: 52%/<br>Canaquinumabe: 40%/<br>tocilizumabe: 50%|mediana (IQR): Total: 24,0<br>(7,5-53,8) meses/<br>Canaquinumabe: 6,7 (3,8-18,8)<br>meses/ Tocilizumabe: 57,3<br>(35,6-78,9) meses|<br>Total: AINEs: 100%; corticoides: 98,7%; MTX:<br>29,8%; MMCDs: 5,2%/ Canaquinumabe: AINES:<br>100%; corticoides: 90%, MTX:30%;<br>MMCDs:10%/ Tocilizumabe: AINEs: 100%,<br>corticoides:100%; MTX:0, MMCDs:0|<br>Total: 6,7 (6,3)/<br>Canaquinumabe: 9,1<br>(8,4)|
|Cabrera et<br>al. 2018|AIJ: n=681|-|65%|-|||
|Ruperto et<br>al. 2018|n= 144: canaquinumabe|9,0 (6,0–13,0)|55%|2,3 (0,9–4,4) de 101<br>participantes|45,1% anakinra, 4,9% tocilizumabe, 34,7% anti-<br>TNF|Média: 1,0 (0-5)|  
**Legenda:** EC: Ensaio Clínico; DP: Desvio Padrão; n: número da amostra; AIJ: Artrite Idiopática Juvenil; IQR: Intervalo Interquartil; MMCD: Medicamento Modificador do Curso da Doença; MTX: metotrexato.  
42  
**Quadro D - Desfechos de eficácia de estudos de canaquinumabe em pacientes com artrite idiopática juvenil sistêmica**  
|**Autor**|**Inatividade (interv. vs.**<br>**comp.)**|**EVA médico (interv. vs.**<br>**comp.)**|**EVA paciente**<br>**(interv. vs.**<br>**comp.)**|**JADAS (interv.**<br>**vs. comp.)**|**Ausência de**<br>**febre (interv. vs.**<br>**comp.)**|**PCR (interv. vs. comp.)**|**Remissão (interv. vs.**<br>**comp.)**|
|---|---|---|---|---|---|---|---|
|Otten et al.,<br>2012|-|-|-|-|-|-|-|
|Tarp et al.<br>2016|-|-|-|-|-|-|-|
|Ruperto et<br>al. 2012|EC 2: Interv. 31%|Mediana EC 1: Interv. = 11<br>(1,0-29,0); Parte 1 do EC 2:<br>0,0 (0,0-6,0); Parte 2 do EC<br>2: Interv. = 0,0 (0,0-7,0)<br>Placebo = 6,5 (0,0-30,0)|Mediana EC 1:<br>Interv. = 6,5 (0,0-<br>26,0); Parte 1 do<br>EC 2: 2,0 (0,0-<br>12,0); Parte 2 do<br>EC 2: Interv. =<br>1,0 (0,0-7,0)<br>Placebo = 3,0<br>(1,0-30,0)|-|Mediana EC 1:<br>Interv. = 12%;<br>Parte 1 do EC 2:<br>0%; Parte 2 do EC<br>2: Interv. = 6%<br>Placebo = 18%|Mediana EC 1: Interv. = 12<br>(3,3-76,6); Parte 1 do EC 2:<br>5,3 (1,8-16,5); Parte 2 do EC<br>2: Interv. = 5,0 (1,2-10,0)<br>Placebo = 17,9 (3,3-68,0)|-|
|Woerner et<br>al. 2015|Anakinra: 44,1%,<br>Canaquinumabe: 41,9%,<br>Tocilizumabe: 45%;<br>Etanercepte: 5,9%|-|-|-|-|-|Total: 51.9%; anakinra<br>(23); canaquinumabe<br>(10); tocilizumabe (5);<br>etanercept (1), abatacept<br>(1)|
|Ruperto et<br>al. 2018|Mediana de diminuição da<br>atividade da doença: 64,6%<br>dos pacientes teve uma<br>mudança mediana de -24,9|-|-|CID JADAS:<br>32,8% em 6<br>meses, 39,5%<br>em 2 anos,|-|-|-|  
43  
|**Autor**|**Inatividade (interv. vs.**<br>**comp.)**|**EVA médico (interv. vs.**<br>**comp.)**|**EVA paciente**<br>**(interv. vs.**<br>**comp.)**|**JADAS (interv.**<br>**vs. comp.)**|<br>**Ausência de**<br>**febre (interv. vs.**<br>**comp.)**|**PCR (interv. vs. comp.)**|**Remissão (interv. vs.**<br>**comp.)**|
|---|---|---|---|---|---|---|---|
||(Q1 -32,7; Q3 -24,8) após 6|||36,7% em 3||||
||meses de tratamento e 93,5%|||anos e 12,4%||||
||dos participantes teve uma|||em 5 anos de||||
||mudança mediana de -31,8|||tratamento.||||
||(Q1 -40,3, Q3 -24,8) após 2<br>anos de tratamento|||||||  
**Legenda:** EC: Ensaio Clínco; DP: Desvio Padrão; n: número da amostra; Q: quartil; Interv: Intervenção; Comp: Comparador; EVA: Escala Analógica Visual; PCR: Proteína C Reativa; JADAS: _Juvenile Arthritis Disease Activity Score_ .  
44  
**Quadro E - Desfechos de eficácia de estudos de canaquinumabe em pacientes com artrite idiopática juvenil sistêmica**  
|**Autor**|**Descontinuação**<br>**(interv. vs. comp.)**|**_Switch_ (interv. vs.**<br>**comp.)**|**CHAQ-DI**|**ACR 30**|**ACR 50**|**ACR 70**|**N° de**<br>**articulações**<br>**com artrite**<br>**ativa**|**N° de**<br>**articulações**<br>**com limitação**<br>**de movimento**|
|---|---|---|---|---|---|---|---|---|
|Otten et<br>al. 2012|-|-|-|Tocilizumabe vs.<br>canaquinumabe:<br>RR (IC 95%): 0,41<br>(0,14-1,23), p=0,11||-|-|-|
|Tarp et al.<br>2016|<br>-|-|-|Canaquinumabe<br>vs. tocilizumabe:<br>OR [IC 95%] =<br>1.25 [0.28 to 5.66]|-|-|-|-|
|Ruperto et<br>al. 2012|<br>-|-|Mediana EC 1: Interv.<br>= 6,5 (0,0-26,0); Parte<br>1 do EC 2: 2,0 (0,0-<br>12,0); Parte 2 do EC 2:<br>Interv. = 1,0 (0,0-7,0)<br>Placebo = 3,0 (1,0-<br>30,0)|EC 1: Interv. 84%<br>vs. placebo 10%;<br>p<0,001|EC 2: Interv.<br>73%||Mediana EC 1:<br>Interv. = 1,0 (0-<br>6,0); Parte 1 do<br>EC 2: 0,0 (0,0-<br>2,0); Parte 2 do<br>EC 2: Interv. =<br>0,0 (0,0-2,0)<br>Placebo = 0,0<br>(0,0-4,0)|Mediana EC 1:<br>Interv. = 2,0<br>(0-8,0); Parte 1<br>do EC 2: 0,0<br>(0,0-2,0); Parte<br>2 do EC 2:<br>Interv. = 0,0<br>(0,0-2,0)<br>Placebo = 1,0<br>(0,0-4,0)|
|Woerner<br>et al. 2015|<br>-|canaquinumabe<br>(n=19),<br>tocilizumabe|-|-|-|-|-|-|  
45  
|**Autor**|**Descontinuação**<br>**(interv. vs. comp.)**|**_Switch_ (interv. vs.**<br>**comp.)**|**CHAQ-DI**|**ACR 30**|**ACR 50**|**ACR 70**|**N° de**<br>**articulações**<br>**com artrite**<br>**ativa**|**N° de**<br>**articulações**<br>**com limitação**<br>**de movimento**|
|---|---|---|---|---|---|---|---|---|
|||(n=17), anakinra<br>(n=8), etanercepte<br>(n=5), adalimumabe<br>(n=3), abatacepte<br>(n=2)|||||||
|Ruperto et<br>al. 2018|<br>33|69|-|73,4% em 6 meses<br>de tratamento e<br>54,8% em 3 anos|65,5% em 6<br>meses de<br>tratamento e<br>53,7% em 3<br>anos|52,0% em 6<br>meses de<br>tratamento e<br>49,7% em 3<br>anos|-|-|  
**Legenda:** EC: Ensaio Clínco; DP: Desvio Padrão; RR: Risco Relativo; IC: Intervalo de Confiança; n: número; Inter: Intervenção; Comp: Comparador; CHAQ-DI: _Childhood Health Assessment Questionnaire Disability Index_ ; ACR:  
_American College of Rheumatology_ .

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
|**Autor e**<br>**ano**|**Incidência de**<br>**eventos adversos**|**Incidência de eventos**<br>**adversos graves**|**Infecções**|**Infecções graves**|**Reações**<br>**locais**|<br>**Síndrome de**<br>**Ativação**<br>**Macrofágica**|**Alterações**<br>**GI**|**Câncer**|**Morte**|**Hospitalização**|
|---|---|---|---|---|---|---|---|---|---|---|
||Canaquinumabe vs.||||||||||
|Tarp et<br>al. 2016|Tocilizumabe: OR<br>[IC 95%] = 0.25<br>[0.09 to 0.71]|-|-|-|-|-|-|-|-|-|  
46  
|**Autor e**<br>**ano**|**Incidência de**<br>**eventos adversos**|**Incidência de eventos**<br>**adversos graves**|**Infecções**|**Infecções graves**|**Reações**<br>**locais**|**Síndrome de**<br>**Ativação**<br>**Macrofágica**|**Alterações**<br>**GI**|**Câncer**|**Morte**|**Hospitalização**|
|---|---|---|---|---|---|---|---|---|---|---|
|Ruperto<br>et al.<br>2012|EC 1: Interv. = 49<br>eventos em 56% dos<br>participantes,<br>Placebo: 27 eventos<br>em 39% dos<br>participantes; Parte<br>1 do EC 2: 664<br>eventos em 78% dos<br>participantes; Parte<br>2 do EC 2: Interv. =<br>272 eventos em<br>80% dos<br>participantes<br>Placebo = 229<br>eventos em 70% dos<br>participantes|EC 1: Interv. = 5% dos<br>participantes, Placebo:<br>5% dos participantes;<br>Parte 1 do EC 2: 8%<br>dos participantes;<br>Parte 2 do EC 2:<br>Interv. = 12% dos<br>participantes Placebo<br>= 12% dos<br>participantes|EC 1: Interv. =<br>30% dos<br>participantes,<br>Placebo: 12% dos<br>participantes; Parte<br>1 do EC 2: 55%<br>dos participantes;<br>Parte 2 do EC 2:<br>Interv. = 54% dos<br>participantes<br>Placebo = 38% dos<br>participantes|EC 1: Interv. = 5%<br>dos participantes,<br>Placebo: 2% dos<br>participantes; Parte<br>1 do EC 2: 4% dos<br>participantes; Parte<br>2 do EC 2: Interv.<br>= 4% dos<br>participantes<br>Placebo = 4% dos<br>participantes|-|7 casos no<br>geral, sendo 3<br>no placebo|-|Nenhum<br>caso em<br>nenhum<br>grupo de<br>nenhum<br>dos estudos|<br>EC 1: Interv. =<br>0% dos<br>participantes,<br>Placebo: 0% dos<br>participantes;<br>Parte 1 do EC 2:<br>1% dos<br>participantes;<br>Parte 2 do EC 2:<br>Interv. = 0% dos<br>participantes<br>Placebo = 2%<br>dos participantes|-|
|Woerner||24 eventos em 77|||||||||
|et al.<br>2015||pacientes: 0,09<br>eventos/ paciente-ano|-|15/24|1/24|2/24|3/24|0|0|17/24|
|Cabrera<br>et al.<br>2018|Canaquinumabe: 15<br>eventos, 6,2 [3,0;<br>9,3] / Tocilizumabe:<br>48, 19,6 [14,0; 25,1]|Canaquinumabe: 2<br>eventos, 0.8 [0.0; 2.0]<br>/Tocilizumabe: 5<br>eventos graves, 2.0|-|Canaquinumabe: 1<br>episódio|-|Tocilizumabe:<br>2 eventos (0.8<br>por 100 PA,|-|-|-|Tocilizumabe: 11<br>eventos, 4.5 por<br>100 PA (95% CI<br>[1,7; 8,1] /|  
47  
|**Autor e**<br>**ano**|**Incidência de**<br>**eventos adversos**|**Incidência de eventos**<br>**adversos graves**|**Infecções**|**Infecções graves**|**Reações**<br>**locais**|<br>**Síndrome de**<br>**Ativação**<br>**Macrofágica**|**Alterações**<br>**GI**|**Câncer**|**Morte**|**Hospitalização**|
|---|---|---|---|---|---|---|---|---|---|---|
|||[0,0; 3,8]; 3 eventos<br>muito graves, 1,2 [0.0;<br>2,6]||||95% CI [0,0;<br>1,9])||||Canaquinumabe: 3<br>eventos, 1,2 [0,0;<br>2,6]|
|Ruperto<br>et al.<br>2018|-|194 eventos em 64<br>participantes (36,2%)|1.036 eventos em<br>136 participantes<br>(76,8%)|Incidência de<br>10.28 a cada 100<br>participantes/ano<br>expostos ao<br>canaquinumabe|-|17 eventos em<br>10<br>participantes<br>(5,6)|513 eventos<br>em 99<br>participantes<br>(55,9%)|0|2|-|  
**Legenda:** EC: Ensaio clínico; GI: gastrointestinais; IC: Intervalo de confiança; Interv: Intervenção; OR: Odds ratio; PA: pacientes-ano.

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**<br>ACR 30/50/70|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|  
48  
|||**Risco**|**Avaliação da Qu**|**alidade**<br>|||**It**|**Qualidade**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**mpaco**|**Global**|**mpornca**|
|10|ensaios clínicos<br>randomizados|não<br>grave|não grave|grave|grave<sup>a</sup>|nenhum|Otten et al., 2012 (18), que incluiu 3 ECR na meta-<br>análise indireta, não foram encontradas diferenças<br>estatisticamente significantes entre tocilizumabe e<br>canaquinumabe (RR=0,41, IC 95% [0,14-1,23]<br>p=0,11) no ACR 30.<br>Na meta-análise indireta de Tarp et al., 2015, que<br>incluiu 5 ECR, não foram encontradas diferenças<br>estatisticamente significantes entre anakinra,<br>canaquinumabe e tocilizumabe para os desfechos de<br>ACR30.<br>Em Ruperto et al., 2012 Comparado ao placebo, o<br>canaquinumabe foi superior quanto à resposta ACR<br>30/50/70 em ECR de fase III. Em estudo de extensão<br>de Ruperto et al., 2018, observou-se manutenção de<br>resposta ACR 30/50/70 aproximadamente 50% dos<br>pacientes após três anos de tratamento com<br>canaquinumabe.|⨁⨁◯◯<br>BAIXA|IMPORTANTE|  
Remissão  
49  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|1<br>1|estudo<br>observacional<br>estudo<br>observacional|não<br>grave<br>não<br>grave|grave<sup>b</sup><br>grave<sup>b</sup>|não grave<br>não grave|não grave<br>não grave|nenhum<br>Inativação da doe<br>nenhum|Woerner et al., 2015, observou-se remissão da<br>doença em cerca de 52% dos pacientes, sendo que<br>10 receberam canaquinumabe como primeira opção<br>de tratamento com biológicos ou em opções<br>subsequentes.<br>nça<br>Woerner et al., 2015, observou-se inatividade da<br>doença em 37 de 77 pacientes:<br>1°agente biológico:7 de 10 pacientes em uso de<br>canaquinumabe e nos 2 em uso de tocilizumabe.<br>2°agente biológico:4 de 17 pacientes em uso de<br>canaquinumabe e 2 de seis em uso de tocilizumabe.<br>3°agente biológico:2 de 5 pacientes em tratamento<br>com canaquinumabe e 4 de 11 pacientes com<br>tocilizumabe.<br>4°agente biológico:o canaquinumabe não foi capaz<br>de inativar a doença em nenhum dos dois pacientes,<br>enquanto o paciente em uso de tocilizumabe<br>apresentou inativação da doença.|⨁◯◯◯<br>MUITO<br>BAIXA<br>⨁⨁◯◯<br>BAIXA|CRÍTICO<br>CRÍTICO|  
50  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2|ensaios clínicos<br>randomizados|não<br>grave|grave<sup>b</sup>|não grave|não grave|nenhum|Na parte 2 do ECR de fase III, 31% dos pacientes<br>que receberam canaquinumabe tiveram a doença<br>inativada. Em estudo de extensão, houve diminuição<br>mediana da atividade da doença em cerca de 65%<br>dos pacientes aos 6 meses e em aproximadamente<br>94% dos pacientes após 2 anos de tratamento. Em<br>coorte retrospectiva, 42% dos pacientes em uso de<br>canaquinumabe apresentaram inativação da doença,<br>comparado a 45% dos pacientes em uso de<br>tocilizumabe (primeira opção ou switch).|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
Eventos adversos  
51  
|||**Risco**|**Avaliação da Qu**|**alidade**<br>|||**It**|**Qualidade**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**mpaco**|**Global**|**mpornca**|
|7|ensaios clínicos<br>randomizados|não<br>grave|grave|grave|grave<sup>a</sup>|nenhum|Na meta-análise indireta de Tarp et al., 2015, o<br>tocilizumabe apresentou maior risco de eventos<br>adversos comparado ao canaquinumabe (OR = 0,25,<br>IC 95% = [0,09 – 0,71]).<br>Ruperto et al., 2012 (16), que relatou que, na<br>primeira fase do estudo, ocorreram eventos adversos<br>graves 5% dos participantes que receberam<br>canaquinumabe e dos que receberam placebo. Na<br>continuação da fase open-label com<br>acompanhamento de 96 semanas, Ruperto et al.,<br>2018 (17) relataram que ocorreram 194 eventos<br>adversos graves em 64 participantes (36,2%).|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|2|estudo<br>observacional|não<br>grave|grave<sup>b</sup>|não grave|não grave|nenhum|No estudo de Woerner et al., 2015 (20), foram<br>observados 24 eventos adversos graves em 77<br>pacientes, sendo que em 17 destes eventos foi<br>necessária hospitalização.<br>No estudo de Cabrera et al., 2018 (21), foram<br>observados 419 eventos adversos em 335 em<br>pacientes com AIJ.|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
Síndrome de Ativação Macrofágica  
52  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2|ensaios clínicos<br>randomizados|não<br>grave|grave<sup>b</sup>|grave<sup>b</sup>|grave<sup>a</sup>|nenhum|Em ECR de fase III, foram identificados sete casos<br>de MAS, sendo que três deles ocorreram no grupo<br>placebo. Em estudo de extensão, foram observados<br>17 casos de MAS, e 10 ocorreram no grupo que<br>recebeu canaquinumabe. Entre os estudos<br>observacionais, os resultados foram divergentes:<br>sendo um mais frequente no grupo que recebeu<br>canaquinumabe, enquanto no outro estudo, a MAS<br>foi mais frequente no grupo de indivíduos que<br>recebeu tocilizumabe.|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|  
53  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2|estudo<br>observacional|não<br>grave|grave<sup>b</sup>|não grave|não grave|nenhum<br>Infecções|No estudo de Woerner et al., 2015 foi observado<br>apenas um caso de síndrome de ativação<br>macrofágica entre os 30 pacientes que fizeram uso<br>de canaquinumabe, em qualquer linha de tratamento.<br>Não foram observados casos entre os pacientes em<br>uso de tocilizumabe no período avaliado.<br>No estudo de Cabrera et al., 2018 foram<br>identificados dois episódios de síndrome de ativação<br>macrofágica entre pacientes em uso de tocilizumabe,<br>sendo a incidência de 0,8 por 100 pacientes ano (IC<br>95%: [0,0 a 1,9]). Não foram observados casos no<br>grupo que recebeu canaquinumabe.|⨁⨁◯◯<br>BAIXA|CRÍTICO|
|2|ensaios clínicos<br>randomizados|não<br>grave|grave<sup>b</sup>|grave<sup>b</sup>|não grave|nenhum|Eventos infecciosos foram frequentes entre os<br>pacientes que receberam canaquinumabe. Em uma<br>coorte retrospectiva, observou-se que infecções<br>foram mais frequentes entre pacientes que receberam<br>canaquinumabe comparado ao grupo que recebeu<br>tocilizumabe.|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
54  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Avaliação da Qu**<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**<br>**Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2|estudo<br>observacional|não<br>grave|grave<sup>b</sup>|grave<sup>c</sup>|não grave|nenhum|No estudo de Woerner et al., 2015 ocorreram 15 EA<br>infecciosos, sendo os mais comuns: Infecção por<br>CMV, por Varicella, por micoplasma e pneumonia.<br>Destes, três ocorreram com uso de canaquinumabe e<br>nenhum com tocilizumabe.<br>No estudo de Cabrera et al., 2018 a ocorrência de<br>infecções esteve relacionada a todos os biológicos<br>investigados. Para tocilizumabe, foram observados<br>20 eventos infecciosos, com incidência de 8,2 (IC<br>95%: 4,3 a 11,7)/100 pacientes-ano. Em pacientes<br>em uso de canaquinumabe, foram observados 28<br>episódios de infecção, com incidência de 11,5<br>(IC95%: 7,3 a 15,8)/100 pacientes-ano.|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
**Legenda:** a. Intervalo de confiança maior do que a magnitude do efeito; b. Heterogeneidade entre grupos de tratamento; c. Pacientes fizeram troca de tratamento durante o estudo, o que gera incertezas a qual medicamento o efeito pode ser atribuído; ACR: _American College of Rheumatology Criteria_ ; ECR: Ensaio Clínico Randomizado; MAS: Síndrome de Ativação Macrofágica.  
55

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
|**Canaquinumabe v**|**s. Tocilizumabe ou corticoides sistêmicos para AIJ sistêmica com ou sem síndrome de ativação macrofágica**|
|---|---|
|**População:**|AIJ sistêmica com ou sem síndrome de ativação macrofágica|
|**Intervenção:**|canaquinumabe|
|**Comparação:**|Tocilizumabe ou corticoides sistêmicos|
|**PRINCIPAIS**<br>**RESULTADOS:**|ACR 30/50/70; Remissão; Inativação da doença; Eventos adversos; Síndrome de Ativação Macrofágica; Infecções;|
|**Avaliação**||
|Problema<br>O problema é uma p|rioridade?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não|· A AIJ é a doença reumática mais frequente em crianças;|
|○ Provavelmente|Não<br>· A AIJ é uma condição clínica com manifestações distintas da Artrite Reumatoide (AR) e de etiologia desconhecida e que não são atendidas pela PCDT de|
|○ Provavelmente|sim<br>AR;|
|● Sim|· A prevalência de AIJ é altamente variável: 3,8 a 400 casos a cada 100.000 indivíduos;|
|○ Varia|· É mais frequente entre mulheres;|
|○ Incerto|· Estima-se que 15% dos pacientes com AIJ tenham a forma sistêmica da doença;<br>· Cerca de 10% dos casos apresentam SAM, uma complicação potencialmente fatal;<br>· A AIJS não responde aos anti-TNF.|
|Efeitos Desejáveis||  
56  
Quão substanciais são os efeitos desejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE PES|QUISA|
|---|---|---|
|● Trivial|· Os desfechos clinicam|ente relevantes (febre e interrupção da dose de corticoide) não foram avaliados pelos estudos. A escala ACR não os contempla, não|
|○ Pequeno|sendo ideal para avaliar|AIJS;|
|○ Moderado|· Maior número de pacie|ntes que receberam canaquinumabe alcançam o ACR30/50/70, em relação aos que receberam placebo.|
|○ Grande|O canaquinumabe apare|ntemente apresenta menor taxa de eventos adversos do que o tocilizumabe (disponível no SUS), de acordo com uma meta-análise em|
|○ Variável|rede.||
|○ Incerto|· O canaquinumabe não<br>meta-análise em rede;|apresentou diferença estatisticamente significante em relação ao tocilizumabe (disponível no SUS) para o alcance de ACR30 em duas|
||· Pacientes em uso de ca|naquinumabe apresentaram risco aumentado para desenvolver eventos adversos sérios;|
||· Podem ocorrer compli<br>Reações infecciosas fora<br><br>|cações graves da doença associadas ao uso de canaquinumabe, incluindo síndrome de ativação macrofágica;<br>m observadas na maioria dos pacientes, decorrente da infecção por diferentes patógenos.<br>|
||heats<br>Si<br><br>|d<br>|
|Efeitos Indesejáveis<br>Quão substanciais são os<br>JULGAMENTO|efeitos indesejáveis?<br>EVIDÊNCIAS DE PES<br><br><br>[14s[**o**65io3**8**) <br>[0.34f .14t00. 0]<br>Odds ratios with 95%co|QUISA<br>SSS<br> **|**canokinumad [SSS<br>442[1.53t012.76]<br>[Rilonacest<br>|<br>nfidence intervals. Statistical significant results are in bold.|  
57  
|● Trivial|· Os desfechos clinicamente relevantes (febre e interrupção da dose de corticoide) não foram avaliados pelos estudos. A escala ACR não os contempla, não|
|---|---|
|○ Pequeno|sendo ideal para avaliar AIJS;|
|○ Moderado|· Maior número de pacientes que receberam canaquinumabe alcançam o ACR30/50/70, em relação aos que receberam placebo.|
|○ Grande|O canaquinumabe aparentemente apresenta menor taxa de eventos adversos do que o tocilizumabe (disponível no SUS), de acordo com uma meta-análise em|
|○ Variável|rede.|
|○ Incerto|· O canaquinumabe não apresentou diferença estatisticamente significante em relação ao tocilizumabe (disponível no SUS) para o alcance de ACR30 em duas<br>meta-análise em rede;|
||· Pacientes em uso de canaquinumabe apresentaram risco aumentado para desenvolver eventos adversos sérios;|
||· Podem ocorrer complicações graves da doença associadas ao uso de canaquinumabe, incluindo síndrome de ativação macrofágica;<br>Reações infecciosas foram observadas na maioria dos pacientes, decorrente da infecção por diferentes patógenos.<br><br>|
||heats<br>SidSSS<br>[14s[**o**65io38)**|**canokinumad[SSS<br>[0.34<br><br><br>|

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Qual é a certeza global  da evidência dos efeitos?  
|JULGAMENTO||EVIDÊNCIAS DE PESQUISA|
|---|---|---|
|● Muito|Baixa|A qualidade geral da evidência é de baixa a muito baixa.|
|○ Baixa||A evidência não nos permite um alto nível de certeza em relação a igualdade de eficácia do canaquinumabe e tocilizumabe.|
|○ Moderada|||
|○ Alta|||
|○ Sem<br>estudos|incluídos||  
58  
|Desfechos|Importância|Certainty<br>of<br>(GRADE)|the|evidence|
|---|---|---|---|---|
|ACR 30/50/70|IMPORTANTE|⨁⨁◯◯<br>BAIXA<sup>a,b</sup>|||
|Remissão|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>c</sup>|||
|Inativação da doença|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>c</sup>|||
|Inativação da doença|CRÍTICO|⨁⨁◯◯<br>BAIXA<sup>b,c</sup>|||
|Eventos adversos|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,b,c</sup>|||
|Eventos adversos|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>c</sup>|||
|Síndrome de Ativação Macrofágica|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,b,c</sup>|||
|Síndrome de Ativação Macrofágica|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>c</sup>|||
|Infecções|CRÍTICO|⨁⨁◯◯<br>BAIXA<sup>b,c</sup>|||  
59  
||Infecções<br>CRÍTICO<br>⨁◯◯◯<br>MUITO BAIXA<sup>c</sup>|
|---|---|
||Intervalo de confiança maior do que a magnitude do efeito.<br>Pacientes fizeram troca de tratamento durante o estudo, o que gera incertezas a qual medicamento o efeito pode ser atribuído.<br>Heterogeneidade entre grupos de tratamento|
|Valores<br>Existe importante incerteza ou<br>JULGAMENTO|variabilidade acerca de quanto as pessoas valorizam os resultados primários?<br>EVIDÊNCIAS DE PESQUISA|
|○ Importante incerteza ou<br>variabilidade|· Inexistem dados sobre a preferência dos pacientes ou dos pais quanto ao esquema de administração dos medicamentos.<br>De acordo com a prática clínica, pode existir preferência dos pacientes e pais pela forma subcutânea|
|● Possível<br>Importante|· Canaquinumabe é medicamento subcutâneo e de rápida aplicação, que pode ser administrado por paciente ou cuidador treinado, enquanto o tocilizumabe,|
|incerteza ou variabilidade|disponível no SUS, é endovenoso e de infusão lenta e feita exclusivamente por profissional da saúde em estabelecimento adequado.|
|○ Provavelmente nenhuma<br>Importante<br>incerteza<br>ou<br>variabilidade|· O fato do tocilizumabe ser endovenoso envolve maior dedicação e preparo por parte dos pais, dos serviços hospitalares. Além disso, envolve maior custo.<br>· O tocilizumabe está disponível na apresentação subcutânea, embora ainda não seja fornecido pelo SUS|
|○ Sem importante incerteza<br>ou variabilidade||
|Balanço dos efeitos||
|O balanço entre efeitos desejá<br>JULGAMENTO|veis e indesejáveis favorece a intervenção ou o comparador?<br>EVIDÊNCIAS DE PESQUISA|  
60  
|○ Favorece o|comparador|Conforme observ|ado em efeitos desejáv|eis e indesejáveis:||
|---|---|---|---|---|---|
|○ Provavelmente<br>comparador<br>○ Não favorece|favorece o<br>um e nem o|· Maior número<br>. Canaquinumab<br>· Pacientes em u|de pacientes que recebe<br>e não apresentou difere<br>so de canaquinumabe a|ram canaquinumabe alcançam o ACR30/50<br>nça estatisticamente significante em relação<br>presentaram risco aumentado para desenvol|/70, em relação aos que receberam placebo.<br>ao tocilizumabe quanto ao desfecho ACR 30.<br>ver eventos adversos sérios;|
|outro<br>○ Provavelmente<br>intervenção<br>○ Favorece a<br>○ Variável|favorece a<br>intervenção|· Podem ocorrer<br>Reações infeccio<br>De acordo com a|complicações graves da<br>sas foram observadas n<br>evidência analisada, n|doença associadas ao uso de canaquinuma<br>a maioria dos pacientes, decorrente da infec<br>ão é possível emitir julgamento sobre a supe|be, incluindo síndrome de ativação macrofágica;<br>ção por diferentes patógenos.<br>rioridade de uma tecnologia em detrimento da outra|
|● Incerto||||||
|Recursos finance<br>O quão grande s|iros requerid<br>ão os recursos|os<br>financeiros nece|ssários?|||
|JULGAMENTO||EVIDÊNCIAS D|E PESQUISA|||
|● Grande<br>○ Moderado<br>○ Custos<br>ou|custo<br>custo<br>economia|Avaliação impac<br>_Market share:_30<br>· Todos os pacie|to orçamentário - Valor<br>% / 35% / 40% /45%/<br>ntes com AIJ sistêmica|base: média de preços pagos em compras f<br>50% (ano 1 ao ano 5)<br>|ederais no ano anterior – R$ 36.763,57|
|desprezíveis||· Ano 1 - R$ 8,5|bilhões|||
|○ Economia|moderada|5 anos: R$ 114 b|ilhões|||
|○ Grande<br>○ Variável|economia|Ano<br>_Marke_|Prevalência Média|Prevalência<br>Mínima<br>Prevalência Máxima|Prevalência Orphanet|
|○ Incerto||<br>_t share_|<br>Custo<br>anual<br>por<br>paciente|Custo anual por<br>paciente<br>Custo<br>anual<br>por<br>paciente|Custo<br>anual<br>por<br>paciente|
|||2020<br>30%|R$ 8.487.559.847,01|R$ 159.746.049,62<br>R$ 16.815.373.644,40|R$ 2.802.562.274,07|  
61  
||2021<br>35%|R$ 9.975.193.167,45|R$ 187.745.091,81|R$ 19.762.641.243,10|R$ 3.293.773.540,52|
|---|---|---|---|---|---|
||2022<br>40%|R$ 11.480.967.038,79|R$ 216.085.560,91|R$ 22.745.848.516,67|R$ 3.790.974.752,78|
||2023<br>45%|R$ 13.003.610.385,39|R$ 244.743.533,75|R$ 25.762.477.237,03|R$ 4.293.746.206,17|
||2024<br>50%|R$ 14.541.993.193,03|R$ 273.697.742,12|R$ 28.810.288.643,94|R$ 4.801.714.773,99|
|Custo-efetividade<br>A custo-efetividade favorece a|AIO 5 anos<br>intervenção ou|R$ 57.489.323.631,67<br>o comparador?|R$1.082.017.978,<br>21|R$ 113.896.629.285,13|R$ 18.982.771.547,52|
|JULGAMENTO|EVIDÊNCIAS|DE PESQUISA||||
|○ Favorece o comparador<br>● provavelmente favorece o<br>comparador<br>○ não favorece nem um nem<br>outro<br>○ provavelmente favorece a<br>intervenção<br>○ favorece<br>a<br>intervenção<br>○ Variável<br>○ sem estudos incluídos|· Eficácia do ca<br>· Custo do trata<br>· Custo do trata<br>· Análise de cus<br>· A análise econ<br>adequada, pois n<br>de análise foi ad|naquinumabe equivalent<br>mento mensal por pacien<br>mento mensal por pacien<br>to-minimização: custo i<br>ômica provavelmente f<br>ão foram levados em co<br>otado por outras agênci|e ao tocilizumabe;<br>te com canaquinum<br>te com tocilizumab<br>ncremental de R$ 4<br>avorece o tocilizum<br>nsideração outros f<br>as internacionais de|abe (SIASG): R$ 36.763<br>e (SIASG): R$1.632,36;<br>21.574,52/ paciente-ano<br>abe para o tratamento d<br>atores como preferências<br>vido à indisponibilidade|,57;<br> <br>com a utilização de canaquinumabe.<br>e AIJS. Entretanto, a análise de custo-minimização talvez não seja a mais<br>de pacientes, dias de trabalho perdidos, entre outros. Contudo, este modelo<br>destes dados.|  
62

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
Qual seria o impacto em equidade em saúde?  
|JULGAMENTO||EVIDÊNCIAS DE PESQUISA|
|---|---|---|
|● Reduzida||· Medicamento não disponível no SUS. Para tratamento de AIJ sistêmica já está disponível o tocilizumabe IV.|
|○ Provavelmente|reduzida|· Provavelmente a população com melhores condições financeiras e com acesso à informação possa já ter acesso ao tratamento por via judicial;|
|○ Provavelmente|nenhum|· Custo de oportunidade, a incorporação desse medicamento (no preço atualmente pago pelo MS) gastaria grande parte do orçamento dos medicamentos|
|impacto||especializados, comprometendo a aquisição de outros para outras condições clínicas. Isso torna-se ainda mais relevante quando se trata da incorporação de um|
|○ Provavelmente<br>○ Aumentada|aumentada|medicamento com incertezas de efetividade comparativa ao tocilizumabe. Assim, esse cenário de incorporação não ocasionaria equidade para o sistema.|
|○ Variável|||
|○ Incerto|||
|Aceitabilidade<br>A intervenção é ac|eitável para|os principais atores sociais (_stakeholders_)?|
|JULGAMENTO||EVIDÊNCIAS DE PESQUISA|
|○ Não||· Provavelmente o canaquinumabe é mais aceitável do que o tocilizumabe, uma vez que o canaquinumabe é subcutâneo enquanto o tocilizumabe é endovenoso.|
|● Provavelmente|não|. O SUS já fornece o tocilizumabe, que tem a mesma eficácia e apresenta um custo menor, em relação ao canaquinumabe. Portanto, para a sustentabilidade do|
|○ Provavelmente|sim|sistema, uma nova incorporação, com as atuais condições, não é interessante e pode inviabilizar a sustentabilidade do sistema.|
|○ Sim||. Reumatologistas pediátricos defendem a ideia de ter-se uma segunda opção de tratamento para aqueles não respondedores ao tocilizumabe, ou seja, aqueles|
|○ Variável||pacientes com atividade sistêmica após 6 meses de tratamento, comprovado por exames clínicos e laboratoriais (69).|
|○ Incerto<br>Viabilidade||. Contudo, no preço atual, não seria bem aceito pelos gestores a incorporação do canaquinumabe, devido a insustentabilidade do sistema.|  
É viável a implementação da tecnologia?  
63  
|JULGAMENTO||EVIDÊNCIAS DE PESQUISA|
|---|---|---|
|○ Não||· O cuidado de armazenamento do tocilizumabe e canaquinumabe são equivalentes, contudo, existe uma maior complexidade na administração do tocilizumabe.|
|● Provavelmente|não|. O medicamento só seria prescrito por especialista, na atenção secundária/ consulta com especialista e isso será uma potencial barreira.|
|○ Provavelmente|sim|. Não existe viabilidade econômica para a incorporação do canaquinumabe nos cenários estimados (eficácia similar e custo muito mais alto).|
|○ Sim||Existiria viabilidade de implementação do canaquinumabe mediante equiparação ou redução de preço em relação ao tocilizumabe.|
|○ Variável|||
|○ Incerto|||

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
|Recomendação forte contra a<br>tecnologia|Recomendação condicional contra a<br>tecnologia|Não favorece uma ou outra|**Recomendação condicional a favor**<br>**da tecnologia**|Recomendação forte a favor da<br>tecnologia|
|---|---|---|---|---|
|○|○|○|**●**|○|

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
A qualidade da evidência para os desfechos analisados foi muito baixa e não mostrou diferença de eficácia entre tocilizumabe e canaquinumabe. Existe provável aceitabilidade maior de administração subcutânea com o canaquinumabe. A recomendação é condicional à equiparação ou redução de preço do canaquinumabe em relação aos tratamentos já disponibilizados pelo SUS.  
64

---

<!-- METADADOS: doenca: PCDT - Artrite Idiopática Juvenil | secao: **10. REFERÊNCIAS** -->
1. BRASIL. PORTARIA Nº 375, DE 10 DE NOVEMBRO DE 2009. In: Saúde Md, editor. Brasília2009.  
2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. In: Saúde Md, editor. Brasília2016.  
3. Shea BJ RB, Wells G, Thuku M, Hammel C, Moran J, Moher J, Tugwell P, Welch V, Kristjansson E, Henry DA. AMSTAR 2: a critical apparaisal tool for systematic reviews that ionclude randomised or non randomised studies of healthcare interventions, or both. BMJ. 2017;358.  
4. Higgins JPT SG. Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration 2011.  
5. Wells G SB, O'Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for Assessing the Quality of Nonrandomised Studies in meta-analysis. . 2011;2009.  
6. Guyatt GH OA, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, Schunemann HJ. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008;336(7560):924.  
7. Moberg J OA, rosenbaum S, Schunemann HJ, Guyatt G, Flottorp S, Glenton C, Lewin A, Morelli A, Rada D, AlonsoCoello P The GRADE Evidence to Decision (EtD) framework for health system and public health decisions. Health Research and Policy Systems. 2018;16:45.  
8. Brasil. CONITEC 2019 [Available from: http://conitec.gov.br/tecnologias-em-avaliacao.  
9. Feist E QP, Fautrel B, Scneider R, Sfriso P, Efthimou P, Cantarini L, Lheritier K, Leon K, Karyekar CS, Speziale A. Efficacy and safety of canakinumab in patients with Still's disease: exposure-response analysis of pooled systemic juvenile idiopathic arthritis data by age groups. Clin Exp Rheumatol. 2018;36(4):668-75.  
10. Aeschlimann FA CS, Lyons TW, Beinvogl BC, Góez-Mogollón LM, Tan S, Laxer RM. Risk of Serious Infections Associated with Biologic Agents in Juvenile Idiopathic Arthritis: A Systematic Review and Meta-Analyses. J Peadiatr. 2019;204:162-71.  
11. Grom AA IN, Pascual V, Brunner HI, Martini A, Lovell D, Ruperto N, Paediatric Rheumatology International Trials Organisation and the Paediatric Rheumatology Collaborative Study Group, Leon K, Lheritier K, Abrams K. Rate and Clinical Presentation of Macrophage Activation Syndrome in Patients with Systemic Juvenile Idiopathic Arthritis Treated with Canakinumab. Arthritis Rheumatol. 2016;68(1):218-28.  
12. Schulert GS MF, Bohnsack J, Cron RQ, Hashad S, Koné-Paut I, Kostik M, Lovell D, Maritsi D, Nigrovic PA, Pal P, Ravelli Am Shimizu M, Stanevicha V, Vastert S, Woerner A, de Benedetti F, Grom AA. Effect of Biologic Therapy on Clinical and Laboratory Features of Macrophage Activation Syndrome Associated With Systemic Juvenile Idiopathic Arthritis. Arthritis Care Res (Hoboken). 2018;70(3):409-19.  
13. Shenoi S HG, Cidon M, Ramanan AV, Kimura Y, Quartier P, Foeldvari I, Zeft A, Lomax KG, Gregson J, Abma T, Campbell-Hill S, Weiss J, Patel D, Marinsek N, Wulffraat N. The burden of systemic juvenile idiopathic arthritis for patients and caregivers: An international survey and retrospective chart review. Clin Exp Rheumatol. 2018;36(5):920-8.  
14. Sota J IA, Cimaz E, Alessio M, Cattalini M, Gallizzi R, Maggio MC, Lopalco G, La torre F, Fabiani C, Pardeo M, Olivieri AN, Sfriso P, Salvarani C, Gaggiano C, Grosso S, Bracaglia C, De Benedetti F, Rigante D, Cantarini L. Drug Retention Rate and Predictive Factors of Drug Survival for Interleukin-1 Inhibitors in Systemic Juvenile Idiopathic Arthritis. Front Pharmacol. 2019;9(1526).  
15. Horneff G SA, Klotsche J, Hospach A, Minden K, Foeldvari I, Trauzeddel R, Ganser G, Weller-Heiemann F, Haas JP. Experience with etanercept, tocilizumab and interleukin-1 inhibitors in systemic onset juvenile idiopathic arthritis patients from the BIKER registry. Arthritis Res Ther. 2017;19(1):256.  
65  
16. Quartier P RN, Wullffrat N, Brunner H, brik R, McCann L, Foster H, Frosch H, Gerloni V, Harel L, Len C, Houghton K, Joos R, Kim D, Abrams K, Ricci J, Martini A, Lovell D. Canakinumab improves health-related quality of life (HRQOL) and daily functioning in systemic juvenile idiopathic arthritis (SJIA) patients. Ann Rheum Dis. 2013;71(3).  
17. Grom AA BH, Ruperto N, Martini A, Lovell D, Pascual V, Lheritier K, Abrams K, Ilowite N. Canakinumab in Systemic Juvenile Idiopathic Arthritis: Impact on the Rate and Clinical Presentation of Macrophage Activation Syndrome. Annals of the rheumatic diseases. 2014;73(2):578.  
18. Brunner H QP, Constantin T, Padeh S, Calvo I, Erguven M, Goffin L, Hofer M, Kallinich T, Oliveira S, Uziel Y, Viola S, Viola S, Nistala K, Wouters C, Lheritier K, kruska J, Abrams K, Mrtini A, Ruperto N, Lovell DJ. Canakinumab in the treatment of systemic juvenile idiopathic arthritis: Results from a 12-week pooled post-hoc analysis for efficacy. 2013.  
19. Ravelli A BH, Ruperto N, Quartier P, Consolaro A, Wulffraat, Lheritier K, Gaillez C, Martini A, Lovell DJ. Canakinumab treatment shows maintained efficacy in systemic juvenile idiopathic arthritis (sJIA) patients at individual patient level: An analysis of 12 week pooled data. 2014.  
20. Wulffraat NM RN, Brunner HI, Oliveira S, Uziel Y, Nistala K, Cimaz R, Ferrandiz MA, Flato B, Gamir M, Kone-Paut I, Gaillez C, Lheritier K, Abrams K, Martini A, Lovell D. Canakinumab treatment shows maintained efficacy in systemic juvenile idiopathic arthritis patients. Pediatr Theumatol Online J. 2014;12(Suppl1):P68.  
21. Boteanu AL VM, Cañamero AB, Corral SG, Alaluna CB, Gamir MG. Clinical and laboratory assessment of a systemic juvenile idiopathic arthritis cohort: A retrospective study. Pediatric Rheumatology. 2017;15:65.  
22. Shenoi S HG, Cidon M, Ramanan A, Kimura Y, Quartier P, Foeldvari I, Zeft A, Lomax KG, Gregson J, Tineke A, Campbell S, Weiss J, Marinsek N, Patel D, Wulffraat N. The disease burden of systemic juvenile idiopathic arthritis for patients and caregivers: An international health related quality of life survey and retrospective chart review. Annals of the rheumatic diseases. 2017;76(Suppl2).  
23. Shenoi S HG, Cidon M, Ramanan A, Kimura Y, Quartier P, Foeldvari I, Zeft A, Lomax KG, Gregson J, Tineke A, Campbell S, Weiss J, Marinsek N, Patel D, Wulffraat N. The disease burden of systemic juvenile idiopathic arthritis for patients and caregivers: An international health related quality of life survey and retrospective chart review. 2017.  
24. Woerner A UF, Melki I, Bader-Meunier B, Mouy R, Wouters C, P Quartier. Drug survival and switching of biological agents in systemic juvenile idiopathic arthritis. Pediatr Rheumatol Online J. 2013;11(Suppl2):P146.  
25. Vastert SJ dJW, Noordman BJ, Holzinger D, Kuis W, Prakken BJ, Wulffraat NM. Effectiveness and long-term follow up of recombinant IL-1RA as first line therapy in newly onset juvenile idiopathic arthritis. Annals of the rheumatic diseases. 2013;71(Suppl3):268.  
26. Tarp S AG, Foeldvari I, Christensen R, Woo JM, Cohen N, Pope TD, Furst DE. Efficacy and safety of biological agents for systemic juvenile idiopathic arthritis: A systematic review and meta-analysis of randomised trials. Annals of the rheumatic diseases. 2015;74(Suppl2):391-2.  
27. Ruperto N BH, Quartier P, Constantin T, Alexeeva E, Kone-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Kemmerle Deschner J, Kallinich T, Lauwerys B, Haddad Em Nasonov E, Trachana M, Vougiouka O, Abrams K, Leon K, Lheritier K, Martini A, Lovell D. Efficacy and safety of canakinumab in children with systemic juvenile idiopathic arthritis with and without fever. Annals of the rheumatic diseases. 2015;74(Suppl2):608.  
28. Brunner H RN, Quartier P, Constantin T, Wulffraat N, Horneff G, Brik R, McCann L, Ozdogan H, Rutkowska-Sak L, Scheneider R, Berkun Y, Calvo, I, Erguven M, Goffin L, Hofer M, Tilmann K, Lheritier K, Abrams K, Stancati A, Lovell DJ, Martini A. Efficacy and safety of canakinumab in patients with active systemic juvenile idiopathic arthritis and fever: Results from two pivotal phase 3 trials. 2012.  
29. Brunner H RN, Quartier P, constantin T, Alexeeva E, Schneider R, Koné-Paut I, Schikler KN, Marzan K, Wulffraat N, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauerys B, Haddad E, Nasonov EL, Trachana M,  
66  
Voufiouka O, Leon K, Speziale A, Lheritier K, Vritzali E, Martini A, Lovell D. Efficacy and safety of canakinumab in patients with systemic juvenile idiopathic arthritis: Results from an open- label, long-term follow-up study. 2017.  
30. Brunner HI RN, Quartier P, Constantin T, Alexeeva E, Schneider R, Kone-Paut I, Schikler K, Marzan K, Wulffraat N, Padeh S, Chasnuk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov EL, Tchachana M, Vougiouka O, Leon K, Speziale A, Lheritier K, Vritzali E, Lovell DJ, Martini A. Efficacy and safety of canakinumab in patients with systemic juvenile idiopathic arthritis: Results from an open-label long-term followup study. 2016.  
31. Ruperto N BH, Horneff G, Quartier P, Constantin T, Berkun Y, Erguven M, Kallinich T, Brik R, Wulffraat NM, Ferrandiz MA, Rutkowska-Sak L, Ozdogan H, Lheritier K, Presiss R, Tseng L, Martini A, Lovell DJ. Efficacy and safety of canakinumab, a long acting fully human anti-Interleukin-1b antibody, in systemic juvenile idiopathic arthritis with active systemic features: Results from a phase III study. Pediatr Rheumatol Online J. 2011;9(Suppl1):O21.  
32. Ruperto N BH, Quartier P, Constantin T, Wulffraat NM, Horneff G, et al. Efficacy and safety of canakinumab, fully human anti-interleukin-1beta antibody, in systemic juvenile idiopathic arthritis. Annals of the rheumatic diseases. 2012;71(Suppl3):i-705.  
33. Ruperto N BH, Quartier P, Constantin T, Wulffraat N, Horneff G, Brik R, McCann L, Kasapcopur O, Rutkowska-Sak L, Schneider R, Berkun Y, Calvo I, Erguven M, Goffin L, Hofer M, Kallinich T, Oliveira S, Uziel Y, Nistala K, Wouters C, Cimaz R, Ferriz M, Flato B, Gamir M, Kone-Paut I, Grom A, Magnusson B, Ozen S, Sztajnbok F, Lheritier K, Abrams K, Kim D, Martini A, Lovell D. Efficacy and safety of canakinumab, fully human anti-interleukin-1β antibody, in systemic juvenile idiopathic arthritis: Results of two randomized phase 3 trials. Zeitschrift fur Rheumatologie. 2012;71(0):37.  
34. Ruperto N BH, Quartier P, Constantin T, Alexeeva E, Schneider R, Kone-Paut I, Schikler K, Marzan K, Wulffraat N, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov E, Trachana M, Vougiouka O, Leon K, Speziale A, Lheritier K, Vritzali E, Martini A, Lovell D. Efficacy and safety of canakinumab in patients with systemic juvenile idiopathic arthritis: Results from an open-label long-term follow-up study. Pediatric Rheumatology. 2017;15(0).  
35. Horneff G SA, Hospach A, Ganser G, Foeldvari I, Thon A, Trauzeddel R, Weller F, Minden K, Haas JP. Efficacy comparison with tocilizumab, interleukin-1 inhibitors and etanercept for treatment of systemic juvenile idiopathic arthritis. Annals of the Rheumatic Diseases. 2016;75(0):270-1.  
36. Anink J OM, Spronk S, Van Suijlekom-Smit LWA. Efficacy of biologic agents in juvenile idiopathic arthritis: A systematic review using indirect comparisons. Arthritis and Rheumatism. 2012;64(0):S490.  
37. Ravelli A BH, Ruperto N, Quartier P, Consolaro A, Wulffraat NM, Lheritier K, Gaillez C, Martini A, Lovell DJ. Efficacy of canakinumab in patients with systemic juvenile idiopathic arthritis (sJIA) using JADAS Criteria-an analysis of 12week pooled data. Arthritis and Rheumatology 2014;66(0):S1002-S3.  
38. Takei S HR, Umebayashi H, Iwata N, Imagawa T, Shimizu M, Tomiita M, Seko N, Kitawaki T, Wang G, Yokota S. Evaluation of efficacy and safety of canakinumab in Japanese patients with systemic juvenile idiopathic arthritis in phase iii clinical trial, composed predominantly of patients with prior use of tocilizumab. Annals of the Rheumatic Diseases. 2018;77(0):499-500.  
39. Horneff G SA, Minden K, Weller-Heinemann F, Hospach A, Haas JP. Experience with Tocilizumab, interleukin-1 inhibitors and etanercept for systemic Juvenile Idiopathic Arthritis. Pediatric Rheumatology. 2017;15(0).  
40. Aygun D AA, Bektas S, Sahin S, Barut K, Cokugras H, Camcioglu Y, Kasapcopur O. The frequency of infections in patients with juvenile idiopathic arthritis on biologic agents: One year prospective study. Pediatric Rheumatology. 2017;15(0):116.  
67  
41. Quartier P EM, Horneff G, Berkun Y, Lheritier K, Kim D, Abrams K, Constantin T. IL-1beta inhibition with canakinumab in patients with systemic juvenile idiopathic arthritis: Efficacy and safety outcomes from a single-dose, placebocontrolled study. Annals of the rheumatic diseases. 2013;71(0).  
42. Fern EZ SL, González-Fernández MI, López-Montesinos B, Benito-Costey S, Calvo-Penadés I. Infectious adverse effects during treatment with IL-1 inhibitors in patients with systemic juvenile idiopathic arthritis and autoinflammatory diseases. Pediatric Rheumatology. 2014;12(0).  
43. Dumaine C HV. Infectious adverse events in children with juvenile idiopathic arthritis: Data from the jircohorte. Pediatric Rheumatology 2018;16(0).  
44. Horneff G RN, Brunner H, Quartier P, Constantin T, Alexeeva E, Kone-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Deschner JK, Kallinich T, Lauwerys B, Haddad E, Nasonov E, Trachana M, Vougiouka O, Abrams K, Leon K, Lheritier K, Martini A, Lovell D. Long term efficacy and safety of canakinumab in children with systemic juvenile idiopathic arthritis with and without fever. Pediatric Rheumatology. 2015;13(1).  
45. Brunner H RN, Quartier P, Constantin T, Alexeeva E, Koné-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov EL, Trachana M, Vougiouka O, Leon K, Vritzali E, Lheritier K, Martini A, Lovell D. Long-term efficacy and safety of canakinumab in patients with active systemic juvenile idiopathic arthritis (SJIA): Results from a phase III extension study. Arthritis and Rheumatology. 2017;69(0):65-7.  
46. Brunner HI RN, Quartier P, Constantin T, Alexeeva E, Koné-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov EL, Trachana M, Vougiouka O, Leon K, Vritzali E, Lheritier K, Martini A, Lovell DJ. Long-term efficacy and safety of canakinumab in patients with active systemic juvenile idiopathic arthritis (SJIA): Results from a phase III extension study. Arthritis and Rheumatology. 2016;68(0):4009-11.  
47. Ruperto N BH, Quartier P, Constantin T, Alexeeva E, Kone-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov E, Trachana M, Vougiouka O, Leon K, Vritzali E, Lheritier K, Martini A, Lovell D. Long-term efficacy and safety of canakinumab in patients with active systemic juvenile idiopathic arthritis (SJIA): Results from a phase III extension study. Pediatric Rheumatology. 2017;15(0).  
48. Ruperto N BH, Quartier P, Constantin T, Alexeeva E, Schneider R, Kone-Paut I, Schikler K, Marzan K, Wulffraat N, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov E, Trachana M, Vougiouka O, Leon K, Speziale A, Lheritier K, Martini A, Lovell D. Long-term efficacy and safety of canakinumab in patients with systemic juvenile idiopathic arthritis (SJIA): 5-year follow-up of an open-label trial. Annals of the Rheumatic Diseases. 2016;75(0):265-6.  
49. Wulffraat NM RN, Brunner HI, Oliveira S, Uziel Y, Nistala K, Cimaz R, Ferriz MA, Flato B, Gamir ML, Koné-Paut I, Gaillez C, Lheritier K, Abrams K, Martini A, Lovell DJ. Maintenance of efficacy by canakinumab treatment in systemic juvenile idiopathic arthritis patients. Annals of the rheumatic diseases. 2014;73(0).  
50. Schneider R BH, Ruperto N, Wulffraat N, Quartier P, Brik R, McCann L, Foster HE, Frosch M, Gerloni V, Harel L, Len C, Houghton K, Joos R, Abrams K, Lheritier, K, Kessabi S, Martini A, Lovell DJ. Marked improvement in patient reported outcomes of children with active systemic juvenile idiopathic arthritis with canakinumab treatment-results of the phase iii program. Arthritis and Rheumatism. 2013;65(0):S111-S2.  
51. Cabrera N WA, Roethlisberger S, Aeschlimann F, Wouters C, Berthet G, Kondi A, Merlin E, Kaiser D, Malik S, Koupai BK, Higel L, Maes A, Cannizzaro E, Jeanneret C, Kone-Paut I, Belot A, Hofer M. Multicenter retrospective study of biological tolerance in juvenile idiopathic arthritis (jir-cohort). Pediatric Rheumatology. 2014;12(0).  
68  
52. Brunner H RN, Horneff G, Quartier P, Constantin T, Berkun Y, Kallinich T. Phase III study results on the efficacy and safety of canakinumab, a long-acting, fully human anti-interleukin-1 antibody, in systemic juvenile idiopathic arthritis with active systemic features. Arthritis and Rheumatism. 2011;63(10).  
53. Woerner A UF, Melki I, Bader-Meunier B, Mouy R, Wouters C, Quartier P. PReS-FINAL-2133: Drug survival and switching of biological agents in systemic juvenile idiopathic arthritis. Pediatric Rheumatology. 2013;11(0).  
54. Quartier P BH, Constantin T, Padeh S, Calvo I, Erguven M, Goffin L, Hofer M, Kallinich T, Oliveira S, Uziel Y, Viola S, Nistala K, Wouters C, Lheritier K, Hruska J, Abrams K, Martini A, Ruperto N, Lovell D. PReS-FINAL-2157: Efficacy of canakinumab in the treatment of systemic juvenile idiopathic arthritis: A 12-week pooled post-hoc analysis. Pediatric Rheumatology. 2013;11(0).  
55. Quartier P RN, Wulffraat N, Brunner H, Brik R, McCann L, Foster H, Frosch M, Gerloni V, Harel L, Len C, Houghton K, Joos R, Abrams K, Lheritier K, Kessabi S, Martini A, Lovell D. PReS-FINAL-2158: Effect of canakinumab on functional ability and health-related quality of life in systemic juvenile idiopathic arthritis (SJIA) patients. Pediatric Rheumatology. 2013;11(0).  
56. Wulffraat NM RN, Brunner HI, Oliveira S, Uziel Y, Nistala K, Cimaz R, Ferriz M, Flato B, Gamir ML, Koné-Paut I, Gaillez C, Lheritier K, Abrams K, Martini A, Lovell DJ. Response to canakinumab treatment is maintained in systemic juvenile idiopathic arthritis patients. Arthritis and Rheumatology. 2014;66(0):S413-S4.  
57. Russo RA KM. Severe adverse events associated with use of biologic therapy in patients with systemic juvenile arthritis: A single-center study. Pediatric Rheumatology. 2017;15(0):102.  
58. Tarp S AG, Foeldvari I, Cohen N, Pope TD, Woo JMP, Christensen R, Furst DE. Short term efficacy of biologic agents in patients with systemic juvenile idiopathic arthritis: Network meta-analysis of randomized trials. Arthritis and Rheumatism. 2013;65(0):S924-S5.  
59. Quartier P AJ, Barash J, Berner R, Abrams K, Lheritier K, Kim D, Wulffraat N. Sustained maintenance of adapted ACR pediatric response with canakinumab in patients with active systemic juvenile idiopathic arthritis. Annals of the rheumatic diseases. 2013;71(0).  
60. Ruperto N BH, Quartier P, Constantin T, Alexeeva E, Kone-Paut I, Marzan K, Wulffraat N, Schneider R, Padeh S, Chasnyk V, Wouters C, Kuemmerle-Deschner JB, Kallinich T, Lauwerys B, Haddad E, Nasonov E, Trachana M, Vougiouka O, Leon K, Speziale A, Lheritier K, Martini A, Lovell D. Treating to target with canakinumab in patients with active systemic juvenile idiopathic arthritis: Results from the long-term extension the phase III pivotal trial. Annals of the Rheumatic Diseases. 2016;75(0):401-2.  
61. Quartier P AE, Wouters C, Calvo I, Kallinich T, Magnusson B, Wulffraat N, Wei X, Slade A, Abrams K, Martini A. Canakinumab, on a reduced dose or a prolonged dose interval without concomitant corticosteroids and methotrexate, maintains efficacy in systemic juvenile idiopathic arthritis patients in clinical remission. Arthritis and Rheumatology. 2018;70(0):3223-4.  
62. Ruperto N BH, Quartier P, Constantin T, Wulffraat N, Horneff G, Brik R, McCann L, Kasapcopur O, Rutkowska-Sak L, Schneider R, Berkun Y, Calvo I, Erguven M, Goffin L, Hofer M, Kallinich T, Knupp S, Uziel Y, Viola S, Nistala K, Wouters C, Cimaz R, Ferriz M, Flato B, Luz-Gamir M, Kone-Paut I, Grom A, Magnusson B, Ozen S, Sztajnbok F, Lheritier K, Kim D, Abrams K, Martini A, Lovell D. Efficacy and safety of canakinumab, fully human anti-interleukin-1beta antibody, in systemic juvenile idiopathic arthritis. Annals of the rheumatic diseases. 2013;70(0).  
63. Ruperto N BH, Quartier P, Constantin T, Wulffraat N, Horneff G, et al. Two randomized trials of canakinumab in systemic juvenile idiopathic arthritis. The New England journal of medicine. 2012;367(25):2396-406.  
64. Ruperto N BH, Quartier P, Constantin T, Wulffraat NM, Horneff G, et al. Canakinumab in patients with systemic juvenile idiopathic arthritis and active systemic features: results from the 5-year long-term extension of the phase III pivotal trials. Annals of the rheumatic diseases. 2018;77(12):1710-9.  
69  
65. Woerner A UF, Melki I, Mouy R, Wouters C, Bader-Meunier B, et al. . Biological treatment in systemic juvenile idiopathic arthritis: achievement of inactive disease or clinical remission on a first, second or third biological agent. RMD open. 2015;1(1):e000036.  
66. Cabrera N LJ, Kassai B, Wouters C, Kondi A, Cannizzaro E, et al. Safety of biological agents in paediatric rheumatic diseases: A real-life multicenter retrospective study using the JIRcohorte database. . Joint, bone, spine : revue du rhumatisme. 2018.  
67. Tarp S AG, Foeldvari I, Christensen R, Woo JM, Cohen N, et al. Efficacy and safety of biological agents for systemic juvenile idiopathic arthritis: A systematic review and meta-analysis of randomised trials ;74:391-2. Annals of the rheumatic diseases. 2015;74:391-2.  
68. Otten MH AJ, Spronk S, van Suijlekom-Smit LW. Efficacy of biological agents in juvenile idiopathic arthritis: a systematic review using indirect comparisons 72(11):1806-12. Annals of the rheumatic diseases. 2013;72(11):1806-12.  
69. Ringold S WP, Beukelman T, DeWitt EM, Ilowite NT, Kimura Y, Laxer RM, Lovell DJ, Nigrovic PA, Robinson AB, Vehe RK. 2013 Update of the 2011 American College of Rheumatology Recommendations for the Treatment of Juvenile Idiopathic Arthritis. Arthritis and Rheumatism. 2013;65(10):2499-512.  
70  
**APÊNDICE 2**  
**HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO**  
|**Número do Relatório**||**Tecnologia**|**s avaliadas pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**||||
|<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou**<br>**alteração do uso no SUS**|**Não incorporação ou não alteração no**<br>**SUS**|
|Portaria Conjunta<br>SAES/SCTIE nº 34, de<br>19 de janeiro de 2026|Correção da faixa de peso<br>relacionada à posologia de<br>administração do<br>medicamento abatacepte|-|-|
|[Relatório de<br>Recomendação nº<br>1022/2025]|Criterios de inclusão<br>temporários para<br>abatacepte solução<br>injetável 250 mg|-|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>16/2021 [Relatório de<br>Recomendação nº<br>654/2021]|Exclusão de abatacepte<br>125 mg, o qual era<br>preconizado<br>equivocadamente|-|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>14/2020 [Relatório de<br>Recomendação nº<br>551/2020]|Republicação devido à<br>atualização do PCDT da<br>Artrite Reumatoide|-|-|
|Portaria Conjunta<br>SAES-SCTIE/MS nº<br>05/2020 [Relatório de<br>Recomendação nº<br>460/2020]|Primeira versão do PCDT<br>da AIJ|-|-|  
71

---

