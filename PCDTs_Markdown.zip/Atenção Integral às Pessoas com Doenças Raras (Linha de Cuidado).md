<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: Geral -->
ce  
5 eae. sg Gi ~ 4  
Se "oe OL Seek 7 Cte es : RP he aa _ INTEGRALAS” -* Soaps ghee . Ut a | “Be: 8¢' aa | PESSOAS —_:.:.'*, Sean's COM DOENCAS. tar: rar: RARAS SR oul va Re Ss 0 NOSISTEMA. 2-3. 3h"! 4 : ee UNICODE. 3 ot aie athe we =} T e °e S win Said eR * ee <u>@</u> e *e ay oh ese (ta ® SAUDE ~~-~~ SUS . > ah Mes veee aa Portaria GM/MS n° 199 de 30/01/2014ct : ma ¥ [*]e af oe,' Be Be. i Brasilia <u>-</u> DF oss ye sia A oH so ° 2014 a ee LE ee Oe ee NR i  
**MINISTÉRIO DA SAÚDE Secretaria de Atenção à Saúde Departamento de Atenção Especializada e Temática Coordenação Geral de Média e Alta Complexidade**  
**DIRETRIZES PARA ATENÇÃO INTEGRAL ÀS PESSOAS COM DOENÇAS RARAS NO SISTEMA ÚNICO DE SAÚDE – SUS**  
**Portaria GM/MS nº 199 de 30/01/2014(*)**  
**Brasília – DF 2014**  
#### © 2014 Ministério da Saúde.  
Todos os direitos reservados. É permitida a reprodução parcial ou total desta obra, desde que citada a fonte e que não seja para venda ou qualquer fim comercial. A responsabilidade pelos direitos autorais de textos e imagens desta obra é da área técnica. A coleção institucional do Ministério da Saúde pode ser acessada na íntegra na Biblioteca Virtual em Saúde do Ministério da Saúde: http://www.saude.gov.br/bvs.  
Triagem: 1° edição – 2014- xxx.xxx exemplares  
Elaboração, distribuição e Informações: Ministério da Saúde Secretaria de Atenção à Saúde Departamento de Atenção Especializada e Temática Coordenação Geral de Média e Alta Complexidade Edifício Premium, SAF Sul, Quadra 2, Lotes 5/6, Bloco II, Sala 203 CEP: 70.070-600 Brasília – DF Fones (61) 3315-6140/ 3315-6150 Correio eletrônico: altacomplexidade@saude.gov.br Endereço eletrônico: www.saude.gov.br/sas  
Coordenação: Alzira de Oliveira Jorge Helvécio Miranda Magalhães Júnior José Eduardo Fogolin Passos Lêda Lúcia Couto de Vasconcelos Organização: Carla Valença Daher Elizabete Ana Bonavigo José Eduardo Fogolin Passos Revisão Técnica Carla Valença Daher Elizabete Ana Bonavigo Hamilton Farias da Silva José Eduardo Fogolin Passos Marcos José Burle Aguiar Paulo Cesar Cavalcante de Almeida Zaida de Barros Melo Nascimento Santos  
Colaboração Associações de familiares e pessoas com Doenças Raras Departamento de Atenção Básica - DAB Departamento de Ações Programáticas e Estratégicas – DAPES Especialistas em Doenças Raras Fabio Baptista Mazzini Juliana Ribeiro Rocha Lílian Cristina dos Santos  
#### Ficha Catalográfica  
Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. Coordenação Geral de Média e Alta Complexidade. Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde – SUS / Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. Coordenação Geral de Média e Alta Complexidade. – Brasília: Ministério da Saúde, 2014. 41 p. ISBN 1. Doença Rara. 2.Genética. 3. Atenção Integral.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
|1.|APRESENTAÇÃO .......................................................................................................................... 5|
|---|---|
|2.|METODOLOGIA ........................................................................................................................... 5|
|3.|OBJETIVO ..................................................................................................................................... 5<br>|
|4.|INTRODUÇÃO: ............................................................................................................................. 5<br>|
|5.<br>RISCO|DIRETRIZES PARA A ATENÇÃO INTEGRAL AOS INDIVÍDUOS COM DOENÇAS RARAS OU COM<br>DE DESENVOLVÊ-LAS ..................................................................................................................... 6|
|6.|DOENÇAS RARAS NA REDE DE ATENÇÃO À SAÚDE ..................................................................... 7<br>|
|6.1.|ATENÇÃO BÁSICA ........................................................................................................................ 7<br>|
|6.2.|ATENÇÃO DOMICILIAR ................................................................................................................ 9|
|6.3.|ATENÇÃO ESPECIALIZADA AMBULATORIAL E HOSPITALAR. ..................................................... 10|
|6.3.1.|A SOLICITAÇÃO E EXECUÇÃO DOS PROCEDIMENTOS AVALIAÇÃO CLÍNICA PARA DIAGNÓSTICO|
|DE DO|ENÇAS RARAS ............................................................................................................................... 11|
|6.3.2.|ACONSELHAMENTO GENÉTICO (AG) ........................................................................................ 12|
|6.4.|A FUNÇÃO DO CENTRO ESPECIALIZADO EM REABILITAÇÃO – CER NA POLÍTICA NACIONAL DE|
|ATENÇ|ÃO INTEGRAL ÀS PESSOAS COM DOENÇAS RARAS ..................................................................... 14|
|7.|ORGANIZAÇÃO DO CUIDADO ÀS PESSOAS COM DOENÇAS RARAS: ......................................... 15|
|7.1.<br>|EIXO I: 1 - ANOMALIAS CONGÊNITAS OU DE MANIFESTAÇÃO TARDIA .................................... 15<br>|
|7.1.1.|ATENÇÃO BÁSICA ...................................................................................................................... 16<br>|
|A.|FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 16|
|B.|PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 16|
|7.1.2.|ATENÇÃO ESPECIALIZADA ......................................................................................................... 17|
|A.|FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 17|
|B.|PROCEDIMENTOS ESPECÍFICOS NA ATENÇÃO ESPECIALIZADA: ............................................... 17|
|C.|APOIO DIAGNÓSTICO: EXAMES COMPLEMENTARES: ............................................................... 18|
|7.1.3.|FLUXOGRAMA: ATENDIMENTO RECOMENDADO PARA ANOMALIAS CONGÊNITAS. ............... 18<br>|
|7.2.|EIXO I: 2 - DEFICIÊNCIA INTELECTUAL ....................................................................................... 18|
|7.2.1.|ATENÇÃO BÁSICA ...................................................................................................................... 19|
|A.|FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 19|
|B.|PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 19<br>|
|C.<br>|CRITÉRIOS DE ENCAMINHAMENTO PARA SERVIÇO ESPECIALIZADO OU SERVIÇO DE<br>|
|REFERÊ|NCIA EM DR: ............................................................................................................................... 19|
|7.2.2.|ATENÇÃO ESPECIALIZADA ......................................................................................................... 20|
|A.|FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 20|
|B.|PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA (SERVIÇOS ESPECIALIZADOS OU|
|SERVIÇ|OS DE REFERÊNCIA EM DR): ....................................................................................................... 20|
|C.|APOIO DIAGNÓSTICO: EXAMES COMPLEMENTARES: ............................................................... 21|
|7.2.3.|FLUXOGRAMA: ATENDIMENTO RECOMENDADO PARA DEFICIÊNCIA INTELECTUAL ............... 22|
|7.3.|EIXO I: 3 - ERRO INATO DO METABOLISMO (EIM). ................................................................... 22|
|7.3.1.|CLASSIFICAÇÃO CLÍNICA DOS EIM ............................................................................................. 22|
|7.3.2.|ATENÇÃO BÁSICA ...................................................................................................................... 23|
|A.|FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 23|
|B.|<br>PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 23|
|7.3.3.|<br>ATENÇÃO ESPECIALIZADA ......................................................................................................... 24|
|A.|FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 24|
|B.|<br>PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA ................................................ 25|
|C.|APOIO DIAGNÓSTICO: EXAMES COMPLEMENTARES: ............................................................... 25|
|7.3.4.|FLUXOGRAMA: ATENDIMENTO RECOMENDADO PARA ERROS INATOS DO METABOLISMO .. 27|
|7.4.|EIXO II - DOENÇA RARA DE ORIGEM NÃO GENÉTICA................................................................ 28|
|7.4.1.|II: 1- DOENÇAS RARAS INFECCIOSAS. ........................................................................................ 28|  
|7.4.1.1. ATENÇÃO BÁSICA ...................................................................................................................... 28|
|---|
|A.<br>FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 28<br>|
|7.4.1.2. ATENÇÃO ESPECIALIZADA ......................................................................................................... 29|
|A.<br>FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 29|
|B.<br>PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA ................................................ 30<br>|
|7.4.2. II: 2 - DOENÇAS RARAS INFLAMATÓRIAS .................................................................................. 30|
|7.4.2.1. ATENÇÃO BÁSICA ...................................................................................................................... 30|
|A.<br>FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 30|
|B.<br>PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 30<br>|
|7.4.2.2. ATENÇÃO ESPECIALIZADA ......................................................................................................... 31|
|A.<br>FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 31|
|B.<br>PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA ................................................ 31|
|7.4.3. II: 3 - DOENÇAS RARAS AUTOIMUNES ...................................................................................... 32|
|7.4.3.1. ATENÇÃO BÁSICA ...................................................................................................................... 32|
|A.<br>FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 32|
|B.<br>PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 32|
|7.4.3.2. ATENÇÃO ESPECIALIZADA ......................................................................................................... 33|
|A.<br>FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 33|
|B.<br>PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA ................................................ 33|
|7.4.4. II: 4 - OUTRAS DOENÇAS RARAS DE ORIGEM NÃO GENÉTICA .................................................. 34|
|7.4.4.1. ATENÇÃO BÁSICA ...................................................................................................................... 34|
|A.<br>FUNÇÃO DA ATENÇÃO BÁSICA: ................................................................................................ 34|
|B.<br>PROCEDIMENTOS DA ATENÇÃO BÁSICA: .................................................................................. 34|
|7.4.4.2. ATENÇÃO ESPECIALIZADA ......................................................................................................... 34|
|A.<br>FUNÇÃO DA ATENÇÃO ESPECIALIZADA: ................................................................................... 34|
|B.<br>PROCEDIMENTOS ESPECÍFICOS DA ATENÇÃO ESPECIALIZADA ................................................ 35|
|8.<br>REFERÊNCIAS BIBLIOGRÁFICAS ................................................................................................. 36|  
**1. APRESENTAÇÃO**  
Este documento visa estabelecer as diretrizes para o cuidado às pessoas com Doenças Raras na Rede de Atenção à Saúde. É um documento de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes, e pelos Serviços de Saúde habilitados junto ao SUS.  
**2. METODOLOGIA**  
A elaboração das Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde – SUS foi uma ação do Departamento de Atenção Especializada e Temática (DAET) da Coordenação de Média e Alta Complexidade (CGMAC), na qual participaram representantes do Ministério da Saúde, de Sociedades/Especialistas e Associações de Apoio às Pessoas com Doenças Raras.  
**3. OBJETIVO**  
O objetivo destas diretrizes é organizar a atenção às pessoas com Doenças Raras no âmbito do Sistema Único de Saúde, o que permitirá reduzir o sofrimento dos afetados e o ônus emocional sobre os pacientes e seus familiares, permitindo ao gestor de saúde a racionalização de recursos.  
**4. INTRODUÇÃO:**  
De acordo com Denis e colaboradores (2009), a Organização Mundial de Saúde, define uma Doença rara (DR) como aquela que afeta até 65 pessoas em cada 100.000 indivíduos, ou seja, 1,3 pessoas para cada 2.000 indivíduos. As Doenças Raras são caracterizadas por uma ampla diversidade de sinais e sintomas e variam não só de doença para doença, mas também de pessoa para pessoa acometida pela mesma condição. Manifestações relativamente frequentes podem simular doenças comuns, dificultando o seu diagnóstico, causando elevado sofrimento clínico e psicossocial aos afetados, bem como para suas famílias. As Doenças Raras são geralmente crônicas, progressivas, degenerativas e até incapacitantes, afetando a qualidade de vida das pessoas e de suas famílias.  
O número exato de doenças raras não é conhecido. Estima-se que existam entre 6.000 e 8.000 tipos diferentes de DR. Oitenta por cento (80%) delas decorrem de fatores genéticos, as demais advêm de causas ambientais, infecciosas, imunológicas, entre outras.  
Muito embora sejam individualmente raras, como um grupo elas acometem um percentual significativo da população, o que resulta em um problema de saúde relevante.  
O diagnóstico das doenças raras é difícil e demorado, o que leva os pacientes a ficarem meses ou até mesmo anos visitando inúmeros serviços de saúde, sendo submetidos a tratamentos inadequados, até que obtenham o diagnóstico definitivo.  
Não seria possível organizar uma Diretriz abordando as doenças raras de forma individual devido ao grande número de doenças. Essa proposta foi organizada na forma de eixos estruturantes, que permitem classificar as doenças raras de acordo com suas características comuns, com a finalidade de maximizar os benefícios aos usuários.  
As Doenças Raras foram classificadas em sua natureza como: de origem genética e de origem não genética. Desta forma, foram elencados dois eixos de DR, sendo o primeiro composto por DR de origem genética: 1-Anomalias Congênitas ou de Manifestação Tardia, 2-Deficiência Intelectual, 3-Erros inatos do Metabolismo; e o segundo formado por DR de origem não genética. O eixo das anomalias congênitas inclui toda a anomalia funcional ou estrutural do desenvolvimento do feto, decorrente de fator originado antes do nascimento, seja genético, ambiental ou desconhecido, mesmo quando os defeitos não forem aparentes no recém-nascido e só se manifeste mais tarde (OPAS, 1984). Para o eixo II - Doenças Raras de Natureza não Genética - foram propostos os seguintes grupos de causas: 1- Infecciosas, 2- Inflamatórias, 3- Autoimunes, e 4 – Outras Doenças Raras de origem não Genética .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
A organização da atenção deve seguir a lógica de cuidados, produzindo saúde de forma sistêmica, por meio de processos dinâmicos voltados ao fluxo de assistência ao usuário. A assistência ao usuário deve ser centrada em seu campo de necessidades, vistas de forma ampla. No que se refere à atenção especializada em doença rara, serão propostos Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras como componentes estruturantes complementares à Rede de Atenção à Saúde.  
A atenção aos familiares e pacientes com DR deverá garantir:  
a) Estruturação da atenção de forma integrada e coordenada em todos os  
níveis, desde a prevenção, acolhimento, diagnóstico, tratamento (baseado em protocolos clínicos e diretrizes terapêuticas), apoio até a resolução, seguimento e reabilitação.  
- b) Acesso a recursos diagnósticos e terapêuticos;  
- c) Acesso à informação e ao cuidado;  
- d) Aconselhamento Genético (AG), quando indicado.  
Os Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras serão componentes da Rede de Atenção à Saúde, na Política Nacional de Atenção Integral às Pessoas com Doenças Raras no SUS, e deverão oferecer assistência especializada e integral, prestada por equipe multidisciplinar e interdisciplinar. Serão responsáveis por ações preventivas, diagnósticas e terapêuticas aos indivíduos com doenças raras ou com risco de desenvolvê-las e seus familiares, de acordo com eixos assistenciais, sendo o primeiro composto por Doenças Raras de origem genética: I: 1 - Anomalias Congênitas ou de Manifestação Tardia, I: 2 - Deficiência Intelectual e I: 3 - Erros Inatos do Metabolismo, e o segundo composto por  Doenças Raras não Genéticas: II: 1- Infecciosas, II: 2- Inflamatórias, II: 3- Autoimunes, e II: 4- Outras Doenças Raras de origem não Genética .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
A Atenção Básica, por meio das Unidades Básicas de Saúde, Equipes de Saúde da Família, Equipes de Atenção Básica tradicionais e/ou parametrizadas e do Núcleo de Saúde da Família (NASF), é uma das portas de entrada do indivíduo com necessidade de cuidado em Doenças Raras e sua família. Ela se presta, em especial, à orientação para a prevenção de anomalias congênitas, deficiência intelectual, erros inatos do metabolismo, doenças raras não genéticas e também ao reconhecimento do indivíduo com necessidade de atendimento em doenças raras.  
A educação permanente para os profissionais que atuam na Atenção Básica tem papel fundamental na qualificação do atendimento na porta de entrada da linha de cuidado às pessoas com Doenças Raras, garantindo processo formativo aos profissionais na assistência, aos pacientes e suas famílias. Além disso, é capaz de propiciar o encaminhamento regulado do paciente com DR aos serviços especializados, informações precisas sobre o apoio às pessoas e famílias com patologias raras, informações que caracterizam suas condições de riscos ou recorrências, formas de lidar com as diferentes  
situações geradas, reabilitação e adaptação, apoio familiar e reinserção social, podendo proporcionar, assim, um cuidado integral.  
As orientações relacionadas às doenças raras devem ser realizadas preferencialmente por equipe multidisciplinar e interdisciplinar, permitindo a discussão conjunta, favorecendo a compreensão e o seguimento da atenção.  
A Atenção Básica deverá ainda encaminhar para Serviço de Atenção Especializada ou Serviços de Referência em Doenças Raras os indivíduos e famílias com suspeita de doenças genéticas, incluindo anomalias congênitas ou de manifestação tardia, deficiência intelectual, erros inatos do metabolismo e doenças raras não genéticas, ou com risco de desenvolvê-las, conforme definido neste documento, bem como nos casos a seguir para avaliação de necessidade de AG, conforme a definição deste procedimento adotada nesta diretriz.  
Também deverá dar seguimento ao AG realizado em serviço habilitado, após contrarreferência, abordando-se de forma não diretiva estas questões, em conjunto com a atenção especializada.  
Ainda cabe à Atenção Básica oferecer consulta médica para avaliação e eventual encaminhamento a Serviço Especializado ou Serviços de Referência em DR, fundamentada em anamnese e exame físico, com coleta dos dados referentes à situação apresentada, podendo incluir:  
- Doença Rara diagnosticada: anamnese completa, com especial atenção à história familiar, exame físico meticuloso, incluindo os aspectos morfológicos;  
- Futura descendência: anamnese completa, com especial atenção à história familiar e presença de consanguinidade. Coletar o máximo de informações sobre os casos que motivaram a consulta, se possível examinando-os ou coletando dados prévios mais objetivos sobre a afecção (exames subsidiários, consultas, relatórios médicos, laudos de exames complementares, especialmente biopsias e necropsias).  
- Caracterizar adequadamente a consanguinidade: realizar exame físico cuidadoso, considerando a suspeita diagnóstica e o fato de indivíduos de isolados geográficos poderem ter uma maior incidência de doenças raras,  
necessitando de uma vigília constante da Atenção Básica.  
- Gestações de risco: anamnese completa, história familiar, laudos de ultrassons e outros exames complementares;  
Demais casos: principais sinais e sintomas da doença avaliada, situações ambientais que favoreçam o aparecimento da doença, e grau de parentesco ou convivência com outros afetados.  
Por fim, a Atenção Básica deverá oferecer atenção multiprofissional e projeto terapêutico singular: o indivíduo e sua família devem ser acompanhados no seu território pela equipe de atenção básica, durante e após o processo de definição diagnóstica. O apoio multiprofissional, a partir da necessidade de cada paciente, é essencial para a qualidade do cuidado prestado. Alguns instrumentos, como a realização do Projeto Terapêutico Singular (PTS), são norteadores para as equipes de referência (Serviços Especializados e Serviços de Referência de Doenças Raras, Atenção Básica, NASF e outros) atuarem com uma abordagem integral, compartilhando o cuidado entre si.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
O Processo de Atenção Domiciliar é complexo, não específico de patologia ou grupo etário, tendo como fator determinante o grau de incapacidade apresentado pelas pessoas com Doenças Raras.  
Com a publicação da regulamentação específica para a Atenção Domiciliar, Portaria GM/MS nº 963, de 27 de maio de 2013, que redefine a Atenção Domiciliar no âmbito do Sistema Único de Saúde – SUS, propõe-se a reorganização do processo de trabalho das equipes que prestam cuidado domiciliar na atenção básica, ambulatorial e hospitalar, com vistas à humanização da atenção, à redução da demanda por atendimento hospitalar e/ou redução do período de permanência de usuários internados, à desinstitucionalização, ao apoio à rede de serviços (principalmente à Atenção Básica) e à ampliação da autonomia dos usuários.  
Conceitualmente, a atenção domiciliar consiste em uma modalidade de atenção à saúde substitutiva ou complementar às já existentes, caracterizada por um conjunto de ações de promoção à saúde, prevenção e tratamento de doenças, bem como reabilitação, prestadas em domicílio, com garantia de continuidade de cuidados e integração à rede de atenção à saúde. Configura-se, desta maneira, como mecanismo de articulação entre os pontos de atenção à saúde, potencializando a assistência ao paciente com doenças raras  
por meio do cuidado compartilhado, de forma horizontal, promovendo a corresponsabilização dos casos pelas equipes de saúde, envolvendo em um certo território as equipes de atenção básica, equipes hospitalares, Unidades de Pronto Atendimento e equipes ambulatoriais especializadas.  
O Serviço de Atenção Domiciliar deverá garantir, por meio do cuidado pelas equipes de Atenção Domiciliar, o atendimento multiprofissional, estabelecendo proposta de intervenção alinhada às necessidades do paciente e promovendo o acesso ao atendimento, ao diagnóstico e ao tratamento por especialistas em doenças raras, quando necessário. Deverá garantir também o acesso à referência para os procedimentos diagnósticos, cirúrgicos e terapêuticos das diversas especialidades.  
Abordar as necessidades específicas de cada paciente trata-se de um grande desafio, pois as Doenças Raras são frequentemente crônicas, progressivas, degenerativas e/ou incapacitantes. Desta forma, considerando as singularidades de seus afetados, o atendimento no domicílio pode ser considerado como alternativa ao projeto terapêutico proposto ao paciente, garantindo a acessibilidade ao serviço de saúde e a continuidade da atenção. Isso deve ocorrer por meio da interação com a família, considerando-a como sujeito de atenção, no seu contexto físico, econômico, social e cultural, respeitando as singularidades culturais e as preferências das pessoas e famílias.  
Neste sentido, o trabalho de articulação entre paciente, família, cuidador, comunidade e serviços de saúde deve visar à promoção da vida independente e a inclusão na comunidade, não bastando, portanto, uma simples assistência ou cuidado. Essa postura exige outras formas de articulação com serviços (ações intersetoriais) e com outras redes de apoio (como as construídas na comunidade), a fim de qualificar a assistência.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Entende-se por atenção especializada ambulatorial e hospitalar no cuidado às pessoas com DR um conjunto de diversos pontos de atenção já existentes na Rede de Atenção à Saúde (RAS), com diferentes densidades tecnológicas, para a realização de ações e serviços de urgência, serviços de reabilitação, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção básica de forma resolutiva e em tempo oportuno.  
São propostos, além da atenção especializada supracitada, Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras como componentes estruturantes complementares da RAS. Os Serviços de Atenção Especializada e Serviços  
de Referência em DR serão responsáveis por ações preventivas, diagnósticas e terapêuticas aos indivíduos com doenças raras ou com risco de desenvolvê-las, de acordo com eixos assistenciais, sendo o primeiro composto por DR de origem genética: I: 1 - Anomalias Congênitas ou de Manifestação Tardia, I: 2 - Deficiência Intelectual e I: 3 - Erros Inatos do Metabolismo, e o segundo–composto por Doenças Raras não Genéticas: II: 1- Infecciosas, II: 2- Inflamatórias, II: 3- Autoimunes, e II: 4 - Outras Doenças Raras de origem não Genética .  
A Atenção Especializada deve garantir:  
a) Acesso a recursos diagnósticos e terapêuticos, mediante protocolos e diretrizes;  
b) Acesso à informação;  
c) AG, quando indicado;  
d) Estruturação do cuidado de forma integrada e coordenada, desde o acolhimento, apoio, reabilitação e prevenção;  
e) Apoio matricial à Atenção Básica;  
f) Apoio matricial à atenção básica pós AG.  
Este nível de atenção deverá garantir também a referência para os procedimentos diagnósticos, cirúrgicos e terapêuticos de diversas especialidades que estejam neste nível de complexidade. Entretanto, é fundamental ressaltar que, em função da complexidade de alguns exames diagnósticos e do custo de alguns medicamentos, existe a previsão de encaminhamentos a Serviços de Atenção Especializada ou Serviços de Referência em DR (sejam pacientes em situações específicas, teleconsultoria/telessaúde ou amostras de exames para investigação) com estabelecimento de protocolos, inclusive para tratamento e reabilitação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Os procedimentos de avaliação clínica para diagnóstico de doenças raras (exames específicos de doenças raras disponíveis no Sistema Único de Saúde) e de AG somente poderão ser solicitados e/ou executados pelos Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras, devidamente habilitados pelo Ministério da  
Saúde, conforme legislação especifica sobre as profissões de saúde e regulamentação dos seus respectivos conselhos profissionais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Considerando que cerca de 80% das DR são de origem genética, o AG é fundamental na atenção às famílias e pessoas com essas doenças. Segundo o Committee on Genetic Counseling of the American Society of Human Genetics (1974), o AG é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas capacitadas apropriadamente, com o objetivo de ajudar o indivíduo ou a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e o manejo disponível. Ainda, o AG tem o papel de avaliar como a hereditariedade contribui para a doença e o risco de recorrência nos familiares, bem como compreender as opções para lidar com o risco de recorrência. O AG também fornece subsídio para escolha do curso de ação que pareça apropriado à família, em função dos seus riscos e objetivos; a agir de acordo com sua decisão e a adaptar-se à doença da melhor maneira possível, considerando-se tanto um membro da família afetado quanto o risco de recorrência daquela doença.  
O AG envolve a existência prévia ou o estabelecimento de diagnóstico de determinada doença, a interpretação de achados e estimativas de riscos genéticos para pessoas clinicamente normais com familiares que apresentam diagnóstico de doença rara documentada, a transmissão das informações relativas à etiologia, à evolução, ao prognóstico e ao risco de recorrência, as estratégias de tratamento e prevenção, além de recomendações para acompanhamento e elaboração de relatório final a ser entregue ao consulente.  
O AG pode ser realizado nos indivíduos e famílias com DR de origem genética ou sob risco de desenvolvê-la e tem como objetivo primordial a assistência e a educação, permitindo o conhecimento, aos indivíduos e/ou famílias, sobre todos os aspectos da doença em curso ou em risco, desde a sua etiologia, evolução, prognóstico, bem como a tomada de decisões a respeito do direito reprodutivo.  
O AG é bem mais amplo do que a informação dos riscos reprodutivos. Trata-se de informar os aspectos envolvidos na doença e as opções reprodutivas. Secundariamente, o AG também pode exercer uma função preventiva, que depende de opções livres e conscientes dos casais que apresentam a possibilidade de gerar filhos com anomalias  
congênitas ou doenças geneticamente determinadas. Os indivíduos são conscientizados da situação, sem serem privados do seu direito de decisão reprodutiva.  
Considerando o caráter não diretivo e não coercitivo do AG, é vedado ao profissional que realiza o AG recomendar, sugerir ou indicar condutas às famílias e/ou indivíduos, ou exigir deles alguma postura. As decisões tomadas por esses últimos devem ser absolutamente livres e pessoais, sendo isentas de qualquer influência ou procedimentos externos, por parte de profissionais ou de instituições.  
Muitas vezes a necessidade de AG será identificada em serviços de especialidades.  
O AG –poderá ser indicado nas seguintes situações:  
a) Pessoas com doenças genéticas raras previamente diagnosticadas sem AG e seu familiares;  
b) Indivíduos, casais e gestantes com questionamento sobre riscos individuais ou para prole futura em função de doença genética rara (confirmada ou sob suspeita) na família;  
c) Gestantes/casais com suspeita de doença genética rara na gestação em curso que ainda não tenham sido encaminhados para o AG.  
O AG deverá ser realizado por equipe multiprofissional capacitada, contendo em sua equipe o médico geneticista e/ou profissionais de saúde capacitados, com graduação na área da saúde e pós-graduação - mestrado ou doutorado acadêmico na área de Genética Humana ou Título de especialista em Biologia Molecular Humana ou Citogenética Humana, emitidos pela Sociedade Brasileira de Genética ou Titulo de Especialista em Genética, emitido pelo Conselho Federal de Biologia, e Comprovação de no mínimo 800 horas de experiência profissional ou estagio supervisionado em AG.  
Durante o AG, as informações sobre etiologia, evolução e prognóstico da doença devem ser repassadas ao consulente e/ou familiares, juntamente com as informações acerca do risco reprodutivo. Isso deve ser feito de forma não diretiva e com discussão das opções frente ao risco de ocorrência/recorrência, favorecendo a compreensão e o seguimento da atenção ao consulente e seus familiares.  
Deverá ser garantida a contrarreferência orientada para seguimento na Atenção Básica, com possibilidade de retorno ao serviço de atenção especializada ou serviço de referência em DR caso seja identificada necessidade de orientação. Quando a DR não for de natureza genética, deve ser garantido o acesso aos Serviços Especializados ou Serviços  
de Referência em Doenças Raras, para o atendimento adequado às suas necessidades. Quando o AG envolver diagnóstico médico, tratamento clínico e medicamentoso será obrigatória a presença  de médico geneticista.  
É obrigatória a elaboração de laudo escrito e assinado pelo profissional responsável que realizou o AG, a ser anexado no prontuário do consulente.  
O AG será realizado no SUS apenas nos serviços de saúde definidos e pactuados pelo gestor local com habilitação específica para o referido procedimento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
O Centro Especializado em Reabilitação (CER) é um ponto de atenção ambulatorial especializada em reabilitação que realiza diagnóstico, tratamento, concessão, adaptação e manutenção de tecnologia assistiva, constituindo-se como referência para a rede de atenção à saúde no território. Poderá ser organizado das seguintes formas:  
CER II: composto por dois serviços de reabilitação habilitados;  
CER III: composto por três serviços de reabilitação habilitados;  
CER IV: composto por quatro ou mais serviços de reabilitação habilitados. Constitui-se como um serviço de referência regulado aquele que funciona segundo base territorial e fornece atenção especializada às pessoas com deficiência temporária ou permanente; progressiva, regressiva, ou estável; intermitente ou contínua; severa ou em regime de tratamento intensivo. Pretende-se que o CER possa:  
a) Estabelecer-se como lugar de referência do cuidado e proteção para usuários, familiares e acompanhantes nos processos de reabilitação auditiva, física, intelectual, visual, ostomias e múltiplas deficiências;  
b) Produzir em conjunto com o usuário, seus familiares e acompanhantes, de forma matricial na rede de atenção, um Projeto Terapêutico Singular, baseado em avaliações multidisciplinares das necessidades e capacidades das pessoas com deficiência, incluindo dispositivos e tecnologias assistivas e com foco na produção da autonomia e do máximo de independência em diferentes aspectos da vida;  
c) Garantir a indicação de dispositivos assistivos, devendo estes serem criteriosamente escolhidos, bem adaptados e adequados ao ambiente físico e social, garantindo o uso seguro e eficiente;  
d) Melhorar a funcionalidade e promover a inclusão social das pessoas com deficiência em seu ambiente social, por meio de medidas de prevenção e/ou redução do ritmo da perda funcional, de melhora ou recuperação da função, de compensação da função perdida e de manutenção da função atual;  
e) Estabelecer fluxos e práticas de cuidado à saúde, contínuos, coordenados e articulados entre os diferentes pontos de atenção da rede de cuidados às pessoas com deficiência em cada território;  
f) Realizar ações de apoio matricial na Atenção Básica no âmbito da Região de Saúde, compartilhando a responsabilidade com os demais pontos da Rede de Atenção à Saúde;  
g) Articular-se com a Rede do Sistema Único de Assistência Social (SUAS) da Região de Saúde a que pertença para acompanhamento compartilhado de casos, quando necessário;  
h) Articular-se com a Rede de Ensino da Região de Saúde a que pertença para identificar crianças, adolescentes e adultos com deficiência e avaliar suas necessidades, dar apoio e orientação aos educadores, às famílias e à comunidade escolar, visando à adequação do ambiente escolar às especificidades das pessoas com deficiência.  
Os Centros Especializados em Reabilitação (CER), atualmente responsáveis pela reabilitação das pessoas com deficiência, são componentes estruturantes da Política Nacional de Atenção às Pessoas com Doenças Raras. De acordo com a integralidade do cuidado, esses Centros também serão responsáveis pela reabilitação dos pacientes encaminhados pelos Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
No Brasil, 2% a 3% do total de nascidos vivos têm alguma anomalia congênita, esta é a segunda causa de mortalidade infantil e é responsável por mais de 1/3 das internações pediátricas. Estima-se minimamente 60.000 novos casos por ano. Consideradas as doenças de manifestação tardia o percentual fica em torno de 5%. Incluem-se entre as anomalias congênitas as condições que, embora a alteração genética esteja presente no nascimento só irão se manifestar mais tarde na vida.  
Além das condições detectáveis ao nascimento, este eixo inclui toda anomalia funcional ou estrutural do desenvolvimento do feto, decorrente de fator originado antes do nascimento, seja genético, ambiental ou desconhecido, mesmo quando o defeito não for aparente no recém-nascido e só se manifeste mais tarde (OPAS, 1984). Inclui também doenças neurodegenerativas, bem como qualquer doença genética, em especial as causadas por genes principais ou mendelianos, ou seja, de herança autossômica dominante, autossômica recessiva e ligadas ao cromossomo X.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Cabe à Atenção Básica detectar ou aventar a suspeita de anomalia congênita (isolada ou múltipla) e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. O indivíduo e sua família devem ser acompanhados, preferencialmente, no seu território, pela equipe de atenção básica durante e após o processo de definição diagnóstica.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Na consulta, a anamnese deve ser feita com especial atenção para antecedentes gestacionais e de parto; evolução do desenvolvimento neuropsicomotor; histórico familiar positivo; consanguinidade parental; exposição a agentes físicos, químicos e/ou biológicos; exame físico completo, com realização de antropometria e cuidado para a percepção de sinais dismórficos. Também deve ser feito acompanhamento de rotina na Atenção Básica.  
Ainda cabe à Atenção Básica encaminhar e referenciar de forma regulada o paciente com anomalia congênita isolada ou com anomalias congênitas múltiplas a Serviços de Atenção Especializada ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de deficiências físicas múltiplas ou isoladas, de atraso no desenvolvimento neuropsicomotor, cumpre encaminhar para terapias de apoio no CER. Interfaces recomendadas: Terapias de apoio (fisioterapia, fonoaudiologia, terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) e serviços especializados em geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção Especializada ou Serviços de Referência em DR, em especial para DR com anomalias congênitas, estes serviços deverão ser a referência para os encaminhamentos oriundos da Atenção Básica ou de outro serviço de saúde da atenção especializada.  
São de responsabilidade da Atenção Especializada a detecção de suspeita de anomalia congênita e o levantamento dos diagnósticos possíveis aplicáveis ao caso, bem como os encaminhamentos necessários.  
Ainda cabe a esse nível de atenção fazer o encaminhamento e a referência, de forma regulada, de paciente com anomalia congênita isolada ou com anomalias congênitas múltiplas, a Serviços ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de deficiências físicas múltiplas ou isoladas, de atraso ou risco de atraso no desenvolvimento neuropsicomotor, cumpre encaminhar para terapias de apoio.  
Interfaces recomendadas: Terapias de apoio (fisioterapia, fonoaudiologia, terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) e serviços especializados em geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
a) Observação genético-clínica: anamnese, elaboração de heredograma (pelo menos três gerações), atenção aos antecedentes gestacionais, condições ao nascimento e período neonatal, desenvolvimento somático e neuropsicomotor e outras intercorrências mórbidas relevantes; exame físico completo, com especial atenção à antropometria e presença de sinais dismórficos;  
b) Avaliação genético-clínica de natimortos e avaliação de óbitos de indivíduos com anomalias congênitas;  
c) Encaminhamento para outras especialidades, para investigação e manejo, se necessário;  
- d) AG, com elaboração de relatório a ser entregue ao consulente;  
- e) Contrarreferência para segmento na Atenção Básica, com diagnóstico (se  
- possível), orientação e monitoramento de cuidados, e conclusão do AG;  
- f) Solicitação de exames diagnósticos;  
- g) Tratamento específico de acordo com o problema e baseado em Protocolos  
Clínicos e Diretrizes Terapêuticas;  
- h) Terapia de apoio;  
- i) Ações de inclusão social.  
- **C. APOIO DIAGNÓSTICO: EXAMES COMPLEMENTARES:**  
- a) Exames de Imagem;  
- b) Exames laboratoriais;  
- c) Avaliação por demais especialidades;  
- d) Investigação laboratorial para anomalias congênitas;  
- e) Investigação de Erros Inatos do metabolismo:  
- **7.1.3. FLUXOGRAMA: ATENDIMENTO RECOMENDADO PARA ANOMALIAS CONGÊNITAS.**  
- **7.2. EIXO I: 2 - DEFICIÊNCIA INTELECTUAL**  
A Deficiência Intelectual pode resultar de causas genéticas, da exposição a fatores deletérios do ambiente, ou ainda da interação entre ambos. Cerca de 1 a 2% são graves e  
causadas por Doenças Raras, podendo, então, ser atendidos pelos Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou aventar a suspeita de Deficiência Intelectual e fazer os encaminhamentos necessários para avaliação diagnóstica. Em caso de comprovação de deficiência intelectual decorrente de doença rara ou com doença rara associada, o paciente e sua família serão atendidos nos Serviços de Atenção Especializada e Serviços de Referência em Doenças Raras.  Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Na consulta, realizar anamnese com especial atenção para antecedentes gestacionais e de parto, evolução do desenvolvimento neuropsicomotor, desempenho escolar, histórico familiar positivo, consanguinidade parental; exame físico completo, com especial atenção para antropometria e sinais dismórficos; acompanhamento de rotina na Atenção Básica e de acordo com a rotina recomendada pelo serviço de referência.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Encaminhar/referenciar de forma regulada a Serviços de Atenção Especializada ou Serviços de Referência em DR, com relatório clínico resumido, paciente com:  
a) Deficiência Intelectual aparentemente isolada (sem sinais dismórficos) com suspeita de doença rara para avaliação neurológica ou genética em função da suspeita clínica;  
b) Deficiência Intelectual associada a quadro dismórfico  
c) Deficiência Intelectual com ou sem sinais dismórficos, associado à consanguinidade e/ou histórico familiar positivo  
Independentemente do diagnóstico etiológico, em caso de deficiências físicas múltiplas ou isoladas, de atraso, ou risco de atraso no desenvolvimento neuropsicomotor, encaminhar para terapias de apoio. Interfaces recomendadas: Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor), neurologia, CER ou nos Serviços Especializados em  
Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção ou Serviço de Referência em DR, em especial para DR com Deficiência Intelectual, estes serviços deverrão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada. Alguns fatores podem indicar a necessidade de encaminhamento para o geneticista clínico, tais como: sinais dismórficos não detectados anteriormente, associação com malformações, recorrência familiar de Deficiência Intelectual, regressão psicomotora.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de DR com Deficiência Intelectual, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários. O paciente com suspeita de Deficiência Intelectual associada à doença rara poderá ser encaminhado/referenciado de forma regulada a Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de atraso no desenvolvimento neuropsicomotor, encaminhar para terapias de apoio. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Neurologia; b) Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional/psicopedagogia/outros serviços de atenção ao desenvolvimento neuropsicomotor) e  
c) CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
a) Observação genético-clínica: Anamnese, elaboração de heredograma (pelo menos três gerações), atenção aos antecedentes gestacionais, condições ao nascimento e período neonatal, desenvolvimento somático e neuropsicomotor e outras intercorrências  
mórbidas relevantes; exame físico completo, com especial atenção a antropometria e presença de sinais dismórficos;  
- b) Encaminhamento para outras especialidades, para investigação e manejo, se  
necessário;  
- c) AG com elaboração de relatório a ser entregue ao consulente ou seu  
responsável.  
- d) Contrarreferência para seguimento na Atenção Básica, com diagnóstico  
- (quando possível), orientação e monitoramento de cuidados, e conclusão do AG.  
- e) Solicitação de exames diagnósticos;  
- f) Tratamento específico de acordo com o problema e baseado em Protocolos  
- Clínicos e Diretrizes Terapêuticas;  
- g) Terapia de apoio;  
- h) Ações de inclusão social.  
- **C. APOIO DIAGNÓSTICO: EXAMES COMPLEMENTARES:**  
- a) Exames de Imagem:  
- b) Avaliação Laboratorial;  
- c) Avaliação por demais especialidades;  
- d) Apoio em genética;  
- e) Apoio diagnóstico específico em genética (indicação seletiva):

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Mais de 550 doenças foram descritas neste grupo, sendo a incidência do seu conjunto estimada em 1: 1000 a 1:2500 nascimentos. No Brasil estima-se 3000 novos casos de EIM a cada ano. Os EIM são geralmente multissistêmicos, muitos evoluindo com comprometimento neurológico e óbito precoce. O diagnóstico dos EIM é complexo, compreendendo várias etapas de investigação. Há possibilidade de intervenção terapêutica em boa parte dos casos. O tratamento específico envolve dietoterapia, uso de fármacos, reposição enzimática e até transplante de órgãos e tecidos. Pacientes com EIM necessitam de acompanhamento especializado cuidadoso.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
A. **EIM Grupo I:** comprometimento do metabolismo intermediário caracterizado por quadro clínico de intoxicação aguda e crônica, relacionado diretamente com ingestão alimentar de proteína ou açúcar, incluindo defeito no metabolismo dos aminoácidos, dos ácidos orgânicos, do ciclo da uréia e intolerância aos açúcares;  
B. **EIM Grupo II:** deficiência na produção ou utilização de energia, incluindo doenças de depósito do glicogênio, doenças mitocondriais de cadeia respiratória, defeitos  
de beta-oxidação de ácidos graxos e hiperlacticemias congênitas;  
C. **EIM Grupo III:** deficiência na síntese ou catabolismo de moléculas complexas, caracterizado por sinais e sintomas permanentes e progressivos sem relação com ingestão alimentar; incluindo doenças de depósito lisossômico e dos peroxissomos, dos lipídeos, dos ácidos biliares, das vitaminas, do transporte de metais entre outras.  
O Serviço de Atenção Especializado e Serviço de Referência em DR com EIM é referência para o atendimento a indivíduos com EIM, oriundos da Atenção Básica ou da Atenção Especializada.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou aventar a suspeita de EIM ou receber o diagnóstico laboratorial e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
a) Consulta médica: Anamnese com especial atenção para antecedentes gestacionais e de parto, historia alimentar, desenvolvimento neuropsicomotor (atraso, involução), consanguinidade, histórico familiar positivo para casos semelhantes, óbitos neonatais ou na infância de causa indeterminada, exame físico completo com especial atenção para antropometria, sinais dismórficos específicos, exame neurológico, alterações oculares, de pele, cabelos e unhas (fâneros).  
b) Encaminhamento para Serviço Especializado / Serviço de Referência em Doenças Raras quando suspeita de erro inato do metabolismo – presença de um ou mais dos itens abaixo:  
 Sinais e sintomas no período neonatal: Hipoglicemia injustificada, alcalose respiratória em intercorrências perinatais, acidose metabólica persistente, cetonúria, síndrome séptica sem fator de risco para infecção, cardiomiopatia hipertrófica, disfunção hepática injustificada, odores incomuns, manifestações neurológicas precoces não justificadas por intercorrências na gravidez, parto e período neonatal, discrasias sanguíneas inexplicadas, instabilidade térmica, catarata congênita, dificuldades alimentares. História Familiar: pais consanguíneos, abortos espontâneos, neomortos,  
hidropisia fetal não imune inexplicada, óbitos neonatais, familiares afetados por algum EIM, fenilcetonúria materna, irmãos com doenças inexplicadas (encefalopatia, sepsis, síndrome da morte súbita do lactente). História gestacional: síndrome HELLP (hemólise, alteração de enzimas hepáticas e plaquetopenia), esteatose hepática aguda da gravidez.  
 Sinais e sintomas fora do período neonatal: Distúrbios metabólicos inexplicáveis, quadros recorrentes de vômitos e/ou desidratação que representam crise metabólica, epilepsia inexplicável e/ou de difícil controle, quadros neurológicos recorrentes como ataxia intermitente ou crises de letargia e/ou coma, quadro neurológico flutuante que alterna consciência com torpor, atraso de desenvolvimento neuropsicomotor ou Deficiência Intelectual inexplicável, involução do desenvolvimento neuropsicomotor ou perda da fala e/ou marcha e/ou compreensão em qualquer idade, hepatomegalia e/ou esplenomegalia inexplicável acompanhada ou não de atraso do desenvolvimento ou Deficiência Intelectual, anormalidades oculares como, luxação do cristalino ou mancha vermelho cereja ou retinose pigmentar ou córnea verticillata ou cegueira familiar, quadro semelhante a acidente vascular encefálico inexplicável em qualquer idade.  
 Outros sinais e sintomas são possíveis de ocorrer tanto no período neonatal, quanto após o mesmo, em doenças classificadas neste eixo.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção ou Serviço de Referência em DR, em especial para DR com EIM, estes serviços deverrão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de DR com EIM, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários. O paciente com suspeita de EIM poderá ser encaminhado/referenciado de forma regulada para o Serviço de Atenção Especializada ou Serviço de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de atraso no  
desenvolvimento neuropsicomotor, encaminhar para terapias de apoio. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Outras especialidades médicas em geral; b) Serviços de imagem, c) Laboratório de análises clínicas e d) Serviços laboratoriais de apoio diagnóstico em genética clínica: laboratório de citogenética / erros inatos de metabolismo / biologia molecular.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
a) Anamnese, elaboração de heredograma (pelo menos três gerações), atenção aos antecedentes gestacionais, condições ao nascimento e período neonatal, desenvolvimento somático e neuropsicomotor e outras intercorrências mórbidas relevantes. Exame físico completo, com especial atenção a antropometria, presença de sinais dismórficos, exame neurológico, alterações oculares e dos cabelos.  
b) Avaliação genético-clínica de natimortos e de indivíduos falecidos com distúrbios metabólicos / morte súbita de causa indeterminada;  
c) Encaminhamento para outras especialidades, para investigação e manejo, se necessário;  
d) AG;  
e) Contrarreferência para seguimento na Atenção Básica, com diagnóstico (quando possível), orientação e monitoramento de cuidados, e conclusão do AG;

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Classificação do paciente em um dos três grupos citados acima (Classificação Clínica dos EIM – Grupos I, II e III) e realização de triagem urinária específica para detecção de metabólitos relacionados aos EIM e triagem sanguínea. É importante salientar que sempre que considerado um EIM deve ser considerada a realização de triagem no sangue e na urina, principalmente para a Classificação Clínica dos EIM dos grupos I e III  
a) Triagem sanguínea solicitada na suspeita de um EIM (indicação seletiva): Hemograma; Gasometria venosa; Sódio, potássio, cloro; Glicose; Colesterol total e frações, triglicérides; ALT, AST, gama GT; Ácido úrico; CPK; Lactato, piruvato, amônia;  
b) Exames complementares e consultas solicitadas: Exames de Imagem; Avaliação hormonal; Avaliação oftalmológica; Avaliação auditiva; Avaliação neurológica.  
Amostras de sangue/urina do paciente deverão ser encaminhadas para  
laboratórios de referência em EIM, juntamente com a descrição do caso e os resultados dos exames acima citados. As amostras encaminhadas para estes laboratórios deverão ser analisadas conforme a suspeita diagnóstica:  
- a) Dosagem quantitativa de aminoácidos no sangue, e/ou na urina  
- b) Dosagem de ácidos orgânicos na urina;  
- c) Cromatografia ou eletroforese ou dosagem de glicosaminoglicanos na urina;  
- d) Cromatografia / dosagem de sialiloligossacarideos;  
- e) Cromatografia / dosagem de oligossacarídeos;  
- f) Cromatografia de açúcares.  
Realizar, conforme o caso:  
- a) Ensaios enzimáticos específicos em plasma e ou sangue em papel filtro;  
- b) Ensaios de enzimas específicas em leucócitos, eritrócitos e outros tecidos;  
- c) Ensaios de enzimas específicas e outros testes em células cultivadas;  
- d) Exames de genética molecular (indicação seletiva).  
- e) Outras tecnologias de análise bioquímicas ou moleculares incorporadas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
<!-- Start of picture text -->
Suspeita clinica (1)<br>Anamnese/Exame fisico (2)<br>Persisténcia da<br>Exames confirmatorios hipotese diagnéstica<br>Testes especficos,<br>Confirmagao diagnéstica dependentes de<br>‘suspeita clinica (3/4)<br>‘Acompanhamento clinico; Taso no confrmado<br>Tratamento;<br>Aconselhamento genético<br>@ avaliagiodo risco de recorréncia;<br>Encaminhamento a outros especialistas<br>Cuidadose seguimento<br>(Gi) Principais sinais<br>Morte neonatal ou infantile sintomassem clinicoscausa definida; sugestivos de EIM<br>|Consangilinidade<br>EncefalopatiaEpisédios de hipoglicemiainexplicdvelentre os pais;queem  ocorrejejum, acidoseem qualquermetabélica idade eou de uma forma recorrente;<br>alcalose respiratéria;<br>Regressioneurolégica;<br>Retardo mental progressivo;<br>Hepato e/ou esplenomegalia,ictericia colestatica sem causa aparente;<br>Déficit de crescimento e/ou alteracdes ésteo-articulares.<br><!-- End of picture text -->  
<!-- Start of picture text -->
(2) Testes de triagem inespecificos (urina/sangue), conforme a apresentagio clinica,<br>tendoExamesdiferencaslaboratoriaisinespecificsde apresentaciodenas pequenas suspeitas e grandede EIM  moléculas.<br>Tiemograma,erames qualtativa Ge urin,gasometl,provas de Tunes Trvor nates com sntomas hepaicos,<br>Identificacio<br>Identiicagao dee quantificagoOigoesisloigoss de Glicos a minoglicancaride o ssurinarios<br>[Perfil Tandem urinarios<br>(2) Testes quantitativos.<br>[ame TMiaterial de andlise  [EIM associado<br>fAnalisecromatografa de dcidosorganicosnagasosaacoplada urinapor20 —|Urina JAcidemiaslenergético,organicas,aminodcidopatias. doongas do metabotismo<br>espectrémetro de massa—CG/MS<br>[DazagemHPLC, auto-analisador, quantitative deTandem aminoscdos par —[Urina,papel  sangue,tro  quar |Aminoacopatias,neurotransmissoresidemias organicas, doangade<br>[Acdos raxos de cadeta mo Tongs WICFA)[Sanaue sindromeDoenga dosde peronissomosZehveger) adrenoleucodistvofia,<br>[Posagem de Succniacetona<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Aproximadamente 20% das DR possuem etiologia não genética. Já é possível identificar alguns grupos de doenças raras não genéticas: doenças raras infecciosas, doenças raras inflamatórias e doenças raras autoimunes, entre outras.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Algumas doenças raras infecciosas, embora no país sejam raras, podem ser frequentes em algumas regiões pelo seu caráter endêmico. Para muitas dessas doenças o Ministério da Saúde tem políticas específicas. Embora possam existir Serviços Especializados ou Serviços de Referência específicos, por doenças, com o seu desenvolvimento e de acordo com as necessidades eles podem ser agrupados sob a denominação de Serviços Especializados ou Serviços de Referência para Doenças Raras Infecciosas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou suspeitar de Doença Rara Infecciosa e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Procedimentos da Atenção Básica:  
Na consulta, realizar a anamnese com especial atenção para sinais e sintomas clínicos, residência em áreas de risco, exposição a outros afetados, vetores e ambientes de risco; exame físico completo com especial atenção para órgãos mais frequentemente  
atingidos; acompanhamento de rotina na atenção básica de acordo com a orientação dos serviços de atenção especializada. Pacientes com suspeita de doença rara de natureza infecciosa poderão ser encaminhados/referenciados de forma regulada a Serviços ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de atraso no desenvolvimento neuropsicomotor associado, encaminhar para terapias de apoio no CER. Interfaces recomendadas: Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) no CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção Especializada ou Serviço de Referência em DR, em especial para DR não Genética e de causa Infecciosa, estes serviços deverão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de DR não Genética Infecciosa, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários, incluindo a prescrição de medidas capazes de prevenir ou diminuir a incidência desse tipo de doença. O paciente com DR não genética e infecciosa poderá ser encaminhado/referenciado de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido. Independentemente do diagnóstico etiológico, em caso de atraso no desenvolvimento neuropsicomotor, encaminhar para terapias de apoio no CER. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Terapias de apoio (fisioterapia/ fonoaudiologia/terapia ocupacional/psicopedagogia/outros serviços de atenção ao desenvolvimento neuropsicomotor) e b) CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
- a) Observação clínica: realizar anamnese, exame físico cuidadoso com base nos  
- sinais e sintomas clínicos da doença infecciosa em avaliação;  
- b) Encaminhamento para outras especialidades, para investigação e manejo, se  
- necessário;  
- c) Identificação de outras pessoas em risco;  
- d) Contrarreferência para seguimento na Atenção Básica, com diagnóstico (quando  
- possível), orientação e monitoramento dos cuidados;  
- e) Solicitação de exames diagnósticos (patologia clínica, sorológicos);  
- f) Tratamento específico para o cuidado da doença, baseado em Protocolos Clínicos  
- e Diretrizes Terapêuticas;  
- i) Exames complementares.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Diversas Doenças Raras de etiologia não genética podem ter natureza inflamatória. Embora possam existir Serviços Especializados ou Serviços de Referência específicos, por doenças, com o seu desenvolvimento e de acordo com as necessidades, eles podem ser agrupados sob a denominação de Serviços Especializados ou Serviços de Referência para Doenças Raras Inflamatórias.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou suspeitar de Doença Rara Inflamatória e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Na consulta, realizar a anamnese e exame clínico cuidadoso com especial atenção para sinais e sintomas clínicos específicos; acompanhamento de rotina na atenção básica de acordo com a orientação dos serviços de atenção especializada. Pacientes com suspeita de doença rara de natureza inflamatória poderá ser encaminhado/referenciado de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, encaminhar para terapias de apoio  
no CER. Interfaces recomendadas: Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) e CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção Especializada ou Serviços de Referência em DR, em especial para DR não Genética e de causa Inflamatória, estes serviços deverão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de DR não Genética Inflamatória, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários, incluindo a prescrição de medidas capazes de prevenir ou diminuir a incidência desse tipo de doença. Pacientes com DR não genética e inflamatória poderá ser encaminhado/referenciado de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de comprometimento da saúde funcional, encaminhar para terapias de apoio no CER. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Terapias de apoio (fisioterapia/ fonoaudiologia/terapia ocupacional/psicopedagogia/outros serviços de atenção ao desenvolvimento neuropsicomotor) e b) CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
- a) Observação clínica: Anamnese, exame físico cuidadoso com base nos sinais e sintomas clínicos da doença inflamatória em avaliação;  
- b) Encaminhamento para outras especialidades, para investigação e manejo, se necessário;  
- c) Contrarreferência para seguimento na Atenção Básica, com diagnóstico (quando possível), orientação e monitoramento dos cuidados;  
- d) Solicitação de exames diagnósticos necessários (de patologia clínica, sorológicos, imunológicos entre outros);  
- e) Tratamento específico para o cuidado da doença, baseado em Protocolos Clínicos e Diretrizes Terapêuticas;  
- f) Terapia de apoio;

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Diversas Doenças Raras de etiologia não genética podem ter natureza autoimune. Trata-se de doenças crônicas. Embora possam existir Serviços Especializados ou Serviços de Referência específicos, por doenças, com o seu desenvolvimento e de acordo com as necessidades eles podem ser agrupados sob a denominação de Serviços Especializados ou Serviços de Referência para Doenças Raras Autoimunes.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou suspeitar de Doença Rara Autoimune e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Na consulta, realizar a anamnese e exame clínico cuidadoso com especial atenção para sinais e sintomas clínicos específicos; acompanhamento de rotina na atenção básica de acordo com a orientação dos serviços de atenção especializada. O paciente com suspeita de doença rara de natureza autoimune poderá ser encaminhado/referenciado de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de comprometimento da saúde funcional, encaminhar para terapias de apoio no CER. Interfaces recomendadas: Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) e no CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção Especializada ou Serviço de Referência em DR, em especial para DR não Genética e de causa Autoimune, estes serviços deverão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de DR não Genética Autoimune, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários, incluindo a prescrição de medidas capazes de prevenir ou diminuir a incidência desse tipo de doença. Pacientes com DR não genética e autoimune poderão ser encaminhados/referenciados de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de comprometimento da saúde funcional, encaminhar para terapias de apoio no CER. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Terapias de apoio (fisioterapia/ fonoaudiologia/terapia ocupacional/psicopedagogia/outros serviços de atenção ao desenvolvimento neuropsicomotor) e b) CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
a) Observação clínica: Anamnese, exame físico cuidadoso com base nos sinais e sintomas clínicos da doença autoimune em avaliação;  
- b) Encaminhamento para outras especialidades, para investigação e manejo, se  
- necessário;  
- c) Contrarreferência para seguimento na Atenção Básica, com diagnóstico (quando possível), orientação e monitoramento de cuidados;  
- d) Solicitação de exames diagnósticos necessários (patologia clínica, sorológicos,  
- imunológicos entre outros);  
- e) Tratamento específico para o cuidado da doença;  
f) Terapia de apoio;  
g) Ações de inclusão social;  
h) Exames Complementares.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Detectar ou suspeitar de Doença Rara de origem não Genética e fazer os encaminhamentos necessários. Em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Na consulta, realizar a anamnese e exame clínico cuidadoso com especial atenção para sinais e sintomas clínicos específicos; acompanhamento de rotina na atenção básica de acordo com a orientação dos serviços de atenção especializada. O paciente com suspeita de doença rara de origem não genética poderá ser encaminhado/referenciado de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de comprometimento da saúde funcional, encaminhar para terapias de apoio no CER. Interfaces recomendadas: Terapias de apoio (fisioterapia/fonoaudiologia/terapia ocupacional e outros serviços de atenção ao desenvolvimento neuropsicomotor) e no CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
Compete à atenção especializada realizar ações e serviços de diagnóstico, habilitação/reabilitação e tratamento específico, de acordo com a necessidade complementar de todas as especialidades. Quando a atenção especializada se configurar como Serviço de Atenção Especializada ou Serviço de Referência em DR, em especial para DR de origem não Genética (outras Doenças Raras de origem não Genética), estes serviços deverão ser a referência para os encaminhamentos oriundos da atenção básica ou de outro serviço de saúde da atenção especializada.  
É de responsabilidade da Atenção Especializada detectar ou aventar a suspeita de  
DR de origem não Genética, realizar as investigações e firmar os diagnósticos possíveis e fazer os encaminhamentos necessários, incluindo a prescrição de medidas capazes de prevenir ou diminuir a incidência desse tipo de doença. Pacientes com DR de origem não genética poderão ser encaminhados/referenciados de forma regulada para os Serviços Especializados ou Serviços de Referência em DR, com relatório clínico resumido.  
Independentemente do diagnóstico etiológico, em caso de comprometimento da saúde funcional, encaminhar para terapias de apoio no CER. Independente do diagnóstico etiológico, em caso de problemas clínicos associados, providenciar os encaminhamentos de acordo com a necessidade. Interfaces recomendadas: a) Terapias de apoio (fisioterapia/ fonoaudiologia/terapia ocupacional/psicopedagogia/outros serviços de atenção ao desenvolvimento neuropsicomotor) e b) CER ou nos Serviços Especializados em Geral (já inseridos no fluxo normal de atendimento).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
- a) Observação clínica: Anamnese, exame físico cuidadoso com base nos sinais e  
- sintomas clínicos da doença rara de origem não genética em avaliação;  
- b) Encaminhamento para outras especialidades, para investigação e manejo, se  
- necessário;  
- c) Contrarreferência para seguimento na Atenção Básica, com diagnóstico (quando  
- possível), orientação e monitoramento de cuidados;  
- d) Solicitação de exames diagnósticos necessários (patologia clínica, sorológicos,  
- imunológicos entre outros);  
- e) Tratamento específico para o cuidado da doença;  
- f) Terapia de apoio;  
- g) Ações de inclusão social;  
- h) Exames Complementares.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Doenças Raras (Linha de Cuidado) | secao: **SUMÁRIO** -->
AGUIAR M J B, LEÃO L L. **A criança com malformações** . In: Leão E, Corrêa E J, Mota J A C, Viana M B. (Org). _Pediatria Ambulatorial_ . Belo Horizonte: Coopmed Editora Médica. 2013  
AGUIAR M J B. **Principais síndromes genéticas** . In: FREIRE L M S (Org). _Diagnóstico diferencial em pediatria_ . Rio de Janeiro: Guanabara Koogan. 2008 p. 495-501.  
BAKER E, HINTON L, CALLEN D F, ALTREE M, DOBBIE A, EYRE H J, SUTHERLAND G R, THOMPSON E, THOMPSON P, WOOLLATT E, HAAN E. Study of 250 children with idiopathic mental retardation reveals nine cryptic and diverse subtelomeric chromosome anomalies. **Am J Med Genet Part A** , 107:285-293, 2002.  
BATAGLIA A, CAREY J. Diagnostic evaluation of developmental delay/mental retardation. **Am J Med Genet** : Part C – Seminars in Medical Genetics; 117C: 3-14, 2003.  
BATLLE D, HAQUE SK. Genetic causes and mechanisms of distal renal tubular acidosis. **Nephrol Dial Transplant** . 27(10):3691-704, Oct. 2012. doi: 10.1093/ndt/gfs442.  
BLAS E, KURUP A S, EDITORS. Equity, social determinants and public health programmes. **Geneva** : World Health Organization; 2010.  
BRASIL. Ministério da Saúde. Portaria GM/MS nº 793, de 24 de Abril de 2012. Institui a Rede de Cuidados à Pessoa com Deficiência no âmbito do Sistema Único de Saúde.  
BRASIL. Ministério da Saúde. Portaria nº 1.533, de 16 de julho de 2012, Altera e acresce dispositivos à Portaria nº 2.527/GM/MS, de 27 de outubro de 2011, que redefine a Atenção Domiciliar no âmbito do Sistema Único de Saúde (SUS).  
BRUNONI D, MARTINS A M, CAVALCANTI D P, CERNACH M C S P. Avaliação genéticoclínica do recém - nascido. Sociedade Brasileira de Genética Clínica. **Projeto diretrizes** : Associação Médica Brasileira e Conselho Federal de Medicina, 2007. Disponível em: <http://www.projetodiretrizes.org.br/projeto_diretrizes/019.pdf> Acesso em: 18/03/2013.  
Cf. (WHO, Van Weely S, Leufkens H. Orphan diseases. In: Priority Medicines for Europe and the World "A Public Health Approach to Innovation"; 7 October 2004. apud Denis A, Simoens S, Fostier C, Mergaert L, Cleemput I. Policies for Rare diseases and Orphan Drugs.Health Technology Assessment (HTA). Brussels: Belgian Health Care Knowledge Centre (KCE); 2009. KCE reports 112C (D/2009/10.273/32) https://kce.fgov.be/sites/default/files/page_documents/d20091027332.pdf.  
CLARKE J T R. **A Clinical guide to inherited metabolic diseases** . 3a Ed. Cambridge: Cambridge University Press, 2006.  
CURRY C J, STEVENSON R E, AUGHTON D, BYRNE J, CAREY J G, CASSIDY S. _et al_ . Evaluation of mental retardation: Recommendations of a Consensus Conference. **Am J Med Genet** . 72: 468-477, 1997.  
DOHERTY M, JANSEN T L, NUKI G, PASCUAL E, PEREZ-RUIZ F, PUNZI L, SO A K, BARDIN T. Gout: why is this curable disease so seldom cured? **Ann Rheum Dis** . Nov;71(11):1765-70, 2012. doi: 10.1136/annrheumdis-2012-201687.  
FAHED A C, GELB B D, SEIDMAN J G, SEIDMAN C E. Genetics of congenital heart disease: the glass half empty. **Circ Res** . 15; 112(4):707-20, Feb 2013. Doi:10.1161/CIRCRESAHA.112.300853.  
GAZZERRO E, ANDREU A L, BRUNO C. Neuromuscular disorders of glycogen metabolism. **Curr Neurol Neurosci Rep** . 13(3):333, Mar 2013. doi: 10.1007/s11910-012-0333-0.  
GIRIRAJAN S, ROSENFELD J A, COE B P, PARIKH S, FRIEDMAN N, GOLDSTEIN A, FILIPINK R A, MCCONNELL J S, ANGLE B, MESCHINO W S, NEZARATI M M, ASAMOAH A, JACKSON K E, GOWANS G C, MARTIN J A, CARMANY E P, STOCKTON D W, SCHNUR R E, PENNEY L S, MARTIN D M, RASKIN S, LEPPIG K, THIESE H, SMITH R, ABERG E, NIYAZOV D M, ESCOBAR L F, EL-KHECHEN D, JOHNSON K D, LEBEL R R, SIEFKAS K, BALL S, SHUR N, MCGUIRE M, BRASINGTON C K, SPENCE J E, MARTIN L S, CLERICUZIO C, BALLIF B C, SHAFFER L G, EICHLER E E. Phenotypic heterogeneity of genomic disorders and rare copy-number variants. **N Engl J Med** . 4;367(14):1321-31, Oct 2012. doi: 10.1056/NEJMoa1200395.  
GROPMAN A L. Patterns of brain injury in inborn errors of metabolism. **Semin Pediatr Neurol** . 19(4):203-10, Dec 2012. doi: 10.1016/j.spen.2012.09.007.  
HARTLEY L, SALT A, DORLING J, GRINGRAS P. Investigation of children with “developmental delay”. **West J Med** . 176:29-33, 2002.  
HAYASHI S, IMOTO I, AIZU Y, OKAMOTO N, MIZUNO S, KUROSAWA K, OKAMOTO N, HONDA S, ARAKI S, MIZUTANI S, NUMABE H, SAITOH S, KOSHO T, FUKUSHIMA Y, MITSUBUCHI H, ENDO F, CHINEN Y, KOSAKI R, OKUYAMA T, OHKI H, YOSHIHASHI H, ONO M, TAKADA F, ONO H, YAGI M, MATSUMOTO H, MAKITA Y, HATA A, INAZAWA J. Clinical application of array-based comparative genomic hybridization by two-stage screening for 536 patients with mental retardation and multiple congenital anomalies. **J Hum Genet** . 56(2):110-24, Feb 2011. doi: 10.1038/jhg.2010.129.  
HONDA S, HAYASHI S, IMOTO I, TOYAMA J, OKAZAWA H, NAKAGAWA E, GOTO Y, INAZAWA J. Copy-number variations on the X chromosome in Japanese patients with mental retardation detected by array-based comparative genomic hybridization analysis. **J Hum Genet** . 55(9):590-9, Sep 2010. doi: 10.1038/jhg.2010.74.  
JIN M, YU Y, HUANG H. An update on primary ovarian insufficiency. **Sci China Life Sci** . 55(8):677-86, Aug 2012. doi: 10.1007/s11427-012-4355-2. Epub 2012 Aug 30.  
KNIGHT SJ, REGAN R. Idiopathic learning disability and genome imbalance. **Cytogenet Genome Res** . 115:215-224, 2006.  
LEÃO L L, AGUIAR M J B. A criança com anomalias congênitas. In: LOPEZ FA, CAMPOS Jr. **Tratado de Pediatria** . 2ª Edição. Barueri. Manole. 2010. p 1103-1113.  
LEÃO L L, AGUIAR M J B. Síndromes Dismórficas com Alterações do Sistema Nervoso Central. In: Luiz Fernando Fonseca; Christovão de Castro Xavier; Geraldo Pianetti. (Org.). **Compêndio de Neurologia Infantil** . Rio de Janeiro/RJ: MedBook Editora Científica Ltda, 2010, v. 1, p. 615-628.  
LEÃO LL, AGUIAR MJB. A criança com anomalias congênitas. In: LOPEZ A, CAMPOS Jr D. (Org). **Tratado de Pediatria. Barueri** : Manole, 2007. p. 1009-1019  
LEDBETTER D H, MARTIN C L. Cryptic telomere imbalance: a 15-year update. **Am J Med Genet Part C, Semin Med Genet** . 145C:327-334, 2007.  
LEUZZI V, MASTRANGELO M, BATTINI R, CIONI G. Inborn errors of creatine metabolism and epilepsy. **Epilepsia** . 54(2):217-27, Feb 2013. doi: 10.1111/epi.12020.  
LLERENA Jr J C, SANTA-ROSA A A, CORREIA P, HOROVITZ D, SILVA E J C, MASCARENHAS E F, SILVA R, CAMACHO L, RAGGIO R.. Investigação do retardo mental e doenças genéticas a partir de um estudo transversal em escolas do Estado do Rio de janeiro. **Informe Epidemiológico do SUS** , 9:251-262, 2000.  
MERWICK A, O'BRIEN M, DELANTY N. Complex single gene disorders and epilepsy. **Epilepsia** . 53 Suppl 4:81-91, Sep 2012. doi: 10.1111/j.1528-1167.2012.03617.x.  
MOESCHLER J B, SHEVELL M, AND THE COMMITTEE ON GENETICS. Clinical genetic evaluation of the child with mental retardation or developmental delays. **Pediatrics** . 117(6):2304-2316, 2006.  
MOESCHLER J B. Genetic evaluation of intellectual disabilities. **Semin Pediatr Neurol** . 15(1):2-9, Mar 2008. doi: 10.1016/j.spen.2008.01.002.  
Online Mendeian Inheritance in Man. Disponível em: <www.omim.ncbi.org>. Acesso em 14 jun 2009.  
ORGANIZAÇÃO PAN-AMERICANA DE SAÚDE. Prevenção e controle de enfermidades genéticas e os defeitos congênitos: relatório de um grupo de consulta. Washington D.C., 1984. 30p. **Publicação Científica nº 460** .  
ORPHANET. **Orphanet Report Series - Prevalence of rare diseases** : Bibliographic data - November 2012 – Number 1 Disponível em: http://www.orpha.net/orphacom/cahiers/docs/GB/Prevalence_of_rare_diseases_by_alp habetical_list.pdf  
PAPETTI L, PARISI P, LEUZZI V, NARDECCHIA F, NICITA F, URSITTI F, MARRA F, PAOLINO M C, SPALICE A. Metabolic epilepsy: An update. **Brain Dev** . Dec 2012 26. doi: pii: S03877604(12)00299-9. 10.1016/j.braindev.2012.11.010.  
POTTER B K, CHAKRABORTY P, KRONICK J B, WILSON K, COYLE D, FEIGENBAUM A, GERAGHTY M T, KARACEPER M D, LITTLE J, MHANNI A, MITCHELL J J, SIRIWARDENA K, WILSON B J, SYROWATKA A. Achieving the "triple aim" for inborn errors of metabolism: a review of challenges to outcomes research and presentation of a new practice-based evidence framework. **Genet Med** . 2012 Dec 6. doi: 10.1038/gim.2012.153.  
PRINCE E, RING H. Causes of learning disability and epilepsy: a review. **Curr Opin Neurol** . 24(2):154-8, Apr 2011. doi: 10.1097/WCO.0b013e3283444c70.  
RAFATI M, GHADIRZADEH M R, HESHMATI Y, ADIBI H, KEIHANIDOUST Z, ESHRAGHIAN M R, DASTAN J, HOSEINI A, PURHOSEINI M, GHAFFARI S R. "Familial" versus "sporadic" intellectual disability: contribution of subtelomeric rearrangements. **Mol Cytogenet** . 5(1):4, 19 Jan 2012. doi: 10.1186/1755-8166-5-4.  
RAFATI M, SEYYEDABOUTORABI E, GHADIRZADEH M R, HESHMATI Y, ADIBI H, KEIHANIDOUST Z, ESHRAGHIAN M R, JAVADI G R, DASTAN J, MOSAVI-JARRAHI A, HOSEINI A, PURHOSEINI M, GHAFFARI SR. "Familial" versus "Sporadic" intellectual disability: contribution of common microdeletion and microduplication syndromes. **Mol Cytogenet** . 5(1):9, 29Jan 2012. doi: 10.1186/1755-8166-5-9.  
RAHMAN S, FOOTITT E J, VARADKAR S, CLAYTON P T. Inborn errors of metabolism causing epilepsy. **Dev Med Child Neurol** . 55(1):23-36, Jan 2013. doi: 10.1111/j.14698749.2012.04406.x.  
RAUCH A, HOYER J, GUTH S, ZWEIER C, KRAUS C, BECKER C, ZENKER M, HÜFFMEIER U, THIEL C, RÜSCHENDORF F, _et al_ . Diagnostic yield of various genetic approaches in patients with unexplained developmental delay or mental retardation. **Am J Med Genet Part A** , 140:2063-2074, 2006.  
RODRIGUEZ L, MARTINEZ-FERNANDEZ M L, MANSILLA E, MENDIOROZ J, ARTEAGA R M, TORAL J F, GUARDIA N M, GARCIA A, CENTENO F, PANTOJA J, _et al_ . Screening for subtelomeric chromosome alteration in a consecutive series of newborns with congenital defects. **Clin Dysmorphol** , 17:5-12, 2008.  
ROID G H, & MILLER L J (1997). Leiter International Performance Scale-Revised. Wood Dale, IL: Stoelting.  
ROOMS L, REYNIERS E, KOOY R F. Subtelomeric rearrangements in the mentally retarded: a comparison of detection methods. **Hum Mutat** , 25:513-524, 2005.  
SCRIVER C R, BEAUDET A L, SLY W S & VALLE D (eds). The metabolic and molecular basis of inherited disease, 8th ed, New York: McGraw-Hill, 2001: 155-166.  
SHARMA S, PRASAD A N. Genetic testing of epileptic encephalopathies of infancy: an approach. **Can J Neurol Sci** . 40(1):10-6, Jan 2013.  
SORGE G, SORGE A. Epilepsy and chromosomal abnormalities. **Ital J Pediatr** . 36:36, 3 May 2010. doi: 10.1186/1824-7288-36-36.  
UJHÁZY E, MACH M, NAVAROVÁ J, DUBOVICKÝ M. Teratology on the crossroads: historical aspects and modern approaches. **Neuro Endocrinol Lett** . 33(3):304-13, 2012.  
VAN GELDER C M, VOLLEBREGT A A, PLUG I, VAN DER PLOEG A T, REUSER A J. Treatment options for lysosomal storage disorders: developing insights. **Expert Opin Pharmacother** . 13(16):2281-99, Nov 2012. doi: 10.1517/14656566.2012.729039.  
VAN KARNEBEEK C D M, JANSWEIJER M C E, LEENDERS A G R, _et al_ . Diagnostic investigation in individuals with mental retardation: a systematic literature review of their usefulness. **European J Hum Genetics** . 13:6-25, 2005.  
VISSERS L E, STANKIEWICZ P. Microdeletion and microduplication syndromes. **Methods Mol Biol** . 838:29-75, 2012. doi: 10.1007/978-1-61779-507-7_2.  
WARE S M, JEFFERIES J L. New Genetic Insights into Congenital Heart Disease. **J Clin Exp Cardiolog** . S8, 15Jun 2012. doi:pii: 003.  
WATERHAM H R, EBBERINK M S. Genetics and molecular basis of human peroxisome biogenesis disorders. **Biochim Biophys Acta** . 1822(9):1430-41, Sep 2012. doi:10.1016/j.bbadis.2012.04.006.  
WHITE K K, SOUSA T. Mucopolysaccharide disorders in orthopaedic surgery. **J Am Acad Orthop Surg** . 21(1):12-22, Jan 2013. doi: 10.5435/JAAOS-21-01-12.  
WICKS E C, ELLIOTT P M. Genetics and metabolic cardiomyopathies. **Herz** . 37(6):598610, Sep 2012.

---

