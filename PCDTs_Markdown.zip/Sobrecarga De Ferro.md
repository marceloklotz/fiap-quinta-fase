<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SCTIE Nº 38, DE 21 DE JANEIRO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Sobrecarga de Ferro.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E**  
**INOVAÇÃO EM SAÚDE,** no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, e  
Considerando a necessidade de se atualizarem os parâmetros sobre a Sobrecarga de Ferro no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação nº 1024 e o Registro de Deliberação nº 1022/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Sobrecarga de Ferro.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Sobrecarga de Ferro, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Sobrecarga de Ferro.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE nº 7, de 23 de fevereiro de 2018, publicada no Diário Oficial da União nº 41, de 1º de março de 2018, Seção 1, pág. 58.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: FERNANDA DE NEGRI -->
1

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **1         INTRODUÇÃO** -->
Diversos processos metabólicos e bioquímicos do organismo humano são dependentes da atividade férrica, como transporte de oxigênio, síntese de DNA e respiração mitocondrial, tornando-a vital para manutenção fisiológica do organismo<sup>1–</sup> 3. A reserva corporal fisiológica de ferro varia, em média, entre 3 g a 5 g, sendo que 67% encontram-se na forma de hemoglobina, dentro do eritrócito (hemácia)<sup>3,4</sup> .  
No trato gastrointestinal, no enterócito, o ferro pode ser armazenado como ferritina, se a taxa de saturação de transferrina estiver normal ou aumentada no sangue periférico; ou pode ser transportado pela membrana basolateral a caminho da circulação, se os valores da saturação da transferrina estiverem baixos no sangue periférico. O transporte do ferro através da membrana basolateral é mediado pela ferroportina, que transporta Fe<sup>2+</sup> ao plasma, sendo oxidado a Fe<sup>3+</sup> pela hefaestina, facilitando a ligação do ferro à transferrina. A hepcidina regula a função da ferroportina, inibindo sua exportação de ferro. Em caso de concentrações elevadas de hepcidina no plasma, a maior parte do ferro absorvido será retido como ferritina no enterócito e esfoliada na luz intestinal com as fezes<sup>2,3</sup> .  
Em condições fisiológicas, o excesso de ferro é eliminado por processos lentos de descamação epitelial, secreções intestinais e por sangramento menstrual, não trazendo complicações ao indivíduo<sup>2</sup> . Em indivíduos normais, a taxa de excreção (ou perda) de ferro é de aproximadamente 1 mg/dia; mulheres no período menstrual apresentam perda adicional de 0,5 a 1 mg/dia<sup>5</sup> . Todavia, existem situações em que o ferro não é eliminado adequadamente, gerando um acúmulo agudo ou crônico. O efeito tóxico do ferro no organismo acontece porque sua forma livre é facilmente convertida em íons divalente e trivalente, que agem como carreadores de elétrons, desencadeando reações bioquímicas com a reação de Fenton, que produz radicais livres. As espécies reativas de oxigênio danificam as macromoléculas como as proteínas, DNA e lipídios além de outras organelas como lisossomos e mitocôndrias. Esses danos podem ocasionar disfunção reversível ou permanente nos órgãos. Na sobrecarga de ferro, quando se excede em capacidade de saturação com a transferrina em 60% a 70%, forma-se o “íon não ligado a transferrina” (“ _non-transferrin-bound iron_ ”, o NTBI). Uma pequena fração de NTBI, denominada de “ferro plasmático lábil” é redox-ativo e quelatável, podendo ser captado facilmente pelas células miocárdicas via canais de cálcio voltagem dependentes e células hepáticas parenquimais, o que leva ao acúmulo do íon no coração e fígado.  
As causas da toxicidade férrica variam desde a ingestão de dose única e excessiva do ferro, quanto por acúmulo crônico proveniente da dieta, uso inadequado de sais de ferro ou decorrente de transfusões sanguíneas.  
A causa primária da sobrecarga de ferro é uma condição genética chamada hemocromatose hereditária (HH), enquanto as principais condições clínicas resultantes do acúmulo crônico de ferro (hemossiderose transfusional ou secundária) incluem talassemia maior, doença falciforme e síndromes mielodisplásicas<sup>6,8</sup> , além de síndrome de falência medular (como a anemia aplásica refratária e a aplasia pura de série eritroide), leucemias agudas, anemia sideroblástica, anemia de Fanconi, anemia diseritropoiética congênita tipos I, II e III, anemia hemolítica e beta talassemia<sup>6</sup> . Outras anemias raras também podem levar à dependência transfusional e à sobrecarga de ferro, como anemia de _Blackfan-Diamond_ não responsiva à corticoterapia e deficiência de piruvatoquinase<sup>7,8</sup> . Portanto, a sobrecarga de ferro pode ser classificada quanto à origem e ao mecanismo de toxicidade do ferro.  
A incidência e prevalência de sobrecarga de ferro são incertas e variam de acordo com a etnia, sexo e idade da população, bem como o método usado para a estimativa (triagem com ferritina, saturação de transferrina ou testes genéticos). Por outro lado,  
2  
as condições genéticas associadas ao risco de sobrecarga de ferro são prevalentes em todo o mundo, o que indiretamente permite estimar a população que necessita de transfusões sanguíneas frequentes e está em risco de sobrecarga de ferro<sup>9</sup> .  
A prevalência mundial da HH em populações caucasianas foi estimada em 3,5 a 4,5 por 1000 pessoas com expressão clínica, sendo maior em homens do que em mulheres. Anualmente, em todo o mundo, aproximadamente 21.000 crianças nascem com hemoglobina E-beta talassemia (cerca de metade das quais são dependentes de transfusão sanguínea) e aproximadamente 23.000 nascem com talassemia maior; outras 14.000 nascem com doença da hemoglobina H<sup>9</sup> . Aproximadamente 60% a 80% dos pacientes com síndrome mielodisplásica experienciam sintomas de anemia e 40% a 50% desenvolvem dependência transfusional, que está associada com o desenvolvimento de sobrecarga de ferro<sup>10</sup> .  
Entre 2014 e 2020, a média anual brasileira de novos casos de crianças diagnosticadas com doença falciforme, de acordo com o Programa Nacional de Triagem Neonatal, foi de 1.087, numa incidência de 3,75 a cada 10.000 nascidos vivos. A distribuição no Brasil é bastante heterogênea, sendo a Bahia, São Paulo e Piauí as unidades federadas de maior incidência<sup>11</sup> . A talassemia é a segunda hemoglobinopatia de maior prevalência na população parda e preta adulta brasileira, destacando a região Nordeste com as maiores prevalências<sup>12</sup> .  
A avaliação do status de ferro não é precisa, uma vez que as proteínas refletem o status de diferentes compartimentos no corpo. Por exemplo, a dosagem da ferritina sérica avalia o ferro em armazenamento, enquanto as dosagens de ferro sérico e o percentual de saturação de transferrina refletem o suprimento de ferro aos tecidos. O diagnóstico da sobrecarga de ferro é clínico e laboratorial. Biópsia hepática e exames de imagem podem ser utilizados para confirmação diagnóstica, de acordo com a indicação de especialista.  
O tratamento da sobrecarga de ferro envolve a administração parenteral ou oral de quelantes de ferro. Em casos de doença falciforme e hemocromatose hereditária, podem-se também indicar procedimentos para retirada de volume de sangue (flebotomia/sangria terapêutica) ou apenas de eritrócitos (eritrocitaférese).  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da sobrecarga de ferro. A identificação dos fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **2       CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- T45.4 Intoxicação por ferro e seus compostos  
- E83.1 Doença do metabolismo do ferro

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **3         DIAGNÓSTICO** -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, de raça, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diagnóstico clínico** -->
O início da sobrecarga de ferro é insidioso, muitas vezes sem apresentação de sinais e sintomas ou quando presentes são inespecíficos, como letargia, fadiga, dor abdominal e perda de peso. No entanto, na hemocromatose hereditária, as manifestações clínicas da doença podem levantar a suspeita diagnóstica. Essas manifestações incluem artropatia (com rigidez e artralgia) nas articulações metacarpofalangeanas, aumento da pigmentação da pele (resultante da deposição de melanina e ferro) e perda de  
3  
libido<sup>13</sup> . Já as manifestações clínicas da sobrecarga de ferro transfusional, como puberdade atrasada ou ausente, distúrbios de crescimento, hipotireoidismo, hipogonadismo, anormalidades ósseas, cirrose e doenças cardíacas, não devem ser aguardadas para o diagnóstico da sobrecarga de ferro, dada a gravidade que o acúmulo de ferro já atingiu quando esses sintomas se manifestam<sup>14</sup> .  
Durante o exame físico, também podem ser identificadas hepatomegalia e esplenomegalia<sup>244</sup> . Alguns homens, especialmente aqueles com severa sobrecarga de ferro, apresentam disfunção erétil, perda de massa muscular, osteoporose, atrofia testicular e ginecomastia devido ao hipogonadismo hipogonadotrófico. Nas mulheres, o hipogonadismo leva à amenorreia e infertilidade<sup>113,15</sup> . Geralmente, quando os sintomas se manifestam, os danos teciduais já são irreversíveis<sup>16</sup> .  
A sobrecarga de ferro pode se manifestar de forma diferente dependendo da origem, sendo importante distinguir entre as duas formas, primária e secundária:  
 **Sobrecarga de ferro do tipo primária** :  estão incluídas as alterações em genes de proteínas relacionadas à homeostase do ferro no organismo, geralmente causadas por um distúrbio do sistema hepcidina-ferroportina ou por um distúrbio do transporte de ferro<sup>3</sup> , como ocorre na hemocromatose hereditária (HH).  
A HH é uma doença genética autossômica recessiva do metabolismo do ferro, caracterizada por sobrecarga sistêmica como resultado do aumento inapropriado da absorção intestinal de ferro<sup>17,18</sup> . Mais de 90% dos casos, está associada a uma mutação no gene HFE, enquanto distúrbios de hemocromatose não-HFE são raros<sup>17,18</sup> . Os seis subtipos da doença que resultam na mutação do gene HFE são<sup>17,19</sup> : HH tipo I; HH tipo IIA; HH tipo IIB; HH tipo III; HH tipo IVA (atípica); e HH tipo IVB.  
As mutações C282Y e H63D são mais comumente relacionadas ao desenvolvimento da HH. Uma revisão de estudos publicados sobre a população brasileira descreveu que a mutação em C282Y está presente em homozigose em 4,4% dos indivíduos e 7,8% em heterozigose, enquanto a frequência da mutação alélica de H63D foi de 20%, em consonância com a maioria das taxas mundiais<sup>6</sup> . Outros estudos demonstraram que a frequência do genótipo C282Y em pacientes brasileiros com sobrecarga primária de ferro é baixa, com predomínio em caucasianos (1,4%)<sup>20–22</sup> .  
A doença geralmente afeta homens, caucasianos, entre a quarta e quinta década de vida e pode levar a cirrose, diabetes, pan-hipopituitarismo, cardiomiopatia, artrite e hiperpigmentação da pele<sup>23</sup> Lesões hepáticas associadas têm grande potencial para o desenvolvimento de fibrose progressiva e, consequentemente, carcinoma hepatocelular quando associadas à HH<sup>13</sup> .  
 **Sobrecarga de ferro do tipo secundária** : associada a doenças congênitas ou adquiridas que cursam como doenças hematológicas ou eritropoiese ineficaz, e que requerem múltiplas transfusões de eritrócitos ou sangue total. As principais condições clínicas que levam à hemossiderose transfusional ou secundária são: doença falciforme e talassemia maior – de origem congênita – e síndromes mielodisplásicas – de origem adquirida<sup>6</sup> .  
Enquanto as complicações das doenças hematológicas são reduzidas com procedimentos transfusionais, estes podem resultar em um acúmulo de ferro tão importante nos tecidos que, sem tratamento, podem levar o paciente a óbito até a segunda década de vida<sup>8</sup> . Geralmente esses pacientes são submetidos a transfusões sanguíneas crônicas acima 10 a 20 procedimentos<sup>15,24</sup> . Estudos indicam que mesmo uma frequência transfusional baixa pode resultar em toxicidade cumulativa<sup>25</sup> .  
A sobrecarga de ferro é o evento adverso mais comum e significativamente associado aos pacientes que realizam terapia de transfusão sanguínea crônica no Brasil<sup>26</sup> . Mesmo em uso de quelantes de ferro, um terço dos pacientes desenvolveram sinais de sobrecarga de ferro, e a taxa de sobrevivência em longo prazo permaneceu baixa, sendo que 50% não chegou aos 35 anos de idade<sup>14</sup> .  
Os sistemas cardíaco e endócrino são particularmente suscetíveis à rápida elevação férrica, visto que suas células têm mais mitocôndrias e menos antioxidantes do que as células do fígado. Por outro lado, o carregamento gradual de ferro leva a um fenótipo mais brando, com início tardio dos sintomas<sup>13</sup> . O acúmulo de ferro por transfusões sanguíneas é, em média, cerca de 40  
4  
vezes mais rápido (0,4 mg/kg/dia) do que por aumento de absorção de ferro no trato gastrointestinal (0,001 mg/kg/dia)<sup>17</sup> . Quando o corpo acumula de 12 g a 24 g de ferro normalmente se iniciam os sinais e sintomas relacionados à toxicidade<sup>1</sup> .  
Além das manifestações clínicas, recomenda-se que pacientes de alto risco sejam submetidos a avaliações médicas e a exames laboratoriais para diagnóstico precoce<sup>6,27,28</sup> . Esse grupo inclui indivíduos com histórico familiar de primeiro grau de HH; desordem genética com suspeita de acometimento de órgãos, como fígado e pâncreas – sugestivos de etiologia de sobrecarga de ferro; pacientes com função hepática anormal, para prevenir a progressão da lesão tecidual irreversível; pacientes cujos níveis séricos de ferritina e a saturação de ferro são muito elevados e não podem ser explicados pela carga transfusional ou comorbidades; e pacientes com aumento muito rápido da ferritina, observado durante a terapia transfusional<sup>27</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diagnóstico laboratorial** -->
<mark>O diagnóstico laboratorial da sobrecarga de ferro é,</mark> geralmente, dado pela elevação das concentrações plasmáticas de ferro e ferritina sérica, bem como pela saturação da transferrina. Essas dosagens devem ser avaliadas em conjunto, de forma que, mesmo nos casos de ferritina aumentada, a ausência de saturação de transferrina elevada na mesma proporção não descarta a sobrecarga de ferro. Essa combinação anormal pode ocorrer em pacientes com uma mutação que causa perda de função da ferroportina, por exemplo<sup>2</sup> .  
**Ferritina sérica** : dosagem menor que 300 μg/L em homens e 200 μg/L em mulheres é considerada normal, porém <mark>é ideal que sejam feitas duas dosagens para confirmação, uma vez que a ferritina é uma proteína de fase aguda</mark><sup>14</sup> <mark>. A</mark> dosagem seriada da ferritina sérica é indicada para todos os pacientes que recebem transfusões regulares, devendo ser realizada a cada 3 meses ou em intervalos menores conforme a necessidade, com base no nível de sobrecarga de ferro. Em pacientes com talassemia dependente de transfusão, a dosagem da ferritina pode ser efetuada após a 10ª transfusão e, se o valor for ≥1.000 μg/mL, a coleta deve ser repetida em 30 dias para confirmar a tendência de ascensão ou queda da ferritina<sup>16</sup> . É importante ressaltar que pacientes com doença falciforme apresentam um processo inflamatório crônico inerente à fisiopatologia da doença. Consequentemente, a ferritina sérica desses indivíduos pode estar ligeiramente elevada, não necessariamente em decorrência de transfusões sanguíneas<sup>24</sup> .  
A ferritina sérica correlaciona-se amplamente com a sobrecarga de ferro tecidual. Níveis acima de 2.500 μg/L estão associados à maior probabilidade de eventos cardíacos e mortalidade precoce<sup>26</sup> . Estima-se um aumento aproximado de 36% no risco de morte para cada 500 μg/L na ferritina sérica acima do limiar de 1000 μg/L<sup>10</sup> .  
Por ser uma proteína de fase aguda, muitos fatores afetam a relação entre a sobrecarga de ferro e os níveis séricos de ferritina, especialmente condições inflamatórias, como doença renal crônica, artrite reumatoide e outras doenças autoimunes. Além disso, pacientes não transfundidos apresentam níveis séricos de ferritina muito mais baixos para uma determinada carga de ferro do que pacientes transfundidos cronicamente<sup>29</sup> .  
Outros fatores podem afetar os níveis séricos de ferritina, incluindo doença hepática, rápida renovação celular, deficiência de vitamina C (que auxilia na absorção de ferro oral), hemólise, abuso de álcool e doenças neoplásicas<sup>25,29,30</sup> .  
**Saturação da transferrina** : é mais sensível que a ferritina sérica na triagem para hemocromatose hereditária<sup>2</sup> . É calculada a partir da razão entre o ferro sérico e a capacidade total de ligação do ferro (também chamado de capacidade de fixação do ferro), devendo ser coletado em jejum. O valor de corte para diagnóstico escolhido para a transferrina é um aumento da saturação em 45%, por ter uma alta sensibilidade a partir desse valor<sup>13</sup> . Para valores acima de 45% em mulheres ou acima de 50% em homens, podem ser solicitados testes genéticos, como a análise de mutação do HFE, no caso de suspeita de HH<sup>2</sup> . Os valores de referência para transferrina são entre 20% e 50% para homens e 15% a 50% para mulheres<sup>31</sup> .  
A saturação de transferrina também pode ser utilizada para definir a necessidade de iniciar a terapia de depleção de ferro em pacientes não transfundidos e em crianças dependentes de transfusão sanguínea que nunca receberam essa alternativa terapêutica<sup>29</sup> . Como há uma variação considerável nos níveis de transferrina ao longo do dia devido à flutuação do ferro sérico<sup>2</sup> ,  
5  
pacientes que utilizam quelantes de ferro e que serão submetidos à dosagem de transferrina devem ser instruídos a suspender o uso do medicamento por pelo menos um dia antes do exame<sup>29</sup> . O ferro tóxico às células, chamado de ferro plasmático lábil (LPI), aparece quando o índice de saturação da transferrina atinge valores acima de 70%<sup>32</sup> .  
Nas síndromes de aumento de absorção, como na talassemia ou hemocromatose hereditária, as taxas de ferro oscilam significativamente em resposta à dieta, acidez gastrointestinal e concentração no organismo, tornando quase impossível quantificar taxas de acúmulo desde o início da doença. No entanto, nos casos secundários às terapias transfusionais, a quantidade de ferro é bem caracterizada, pois o fluxo das transfusões sanguíneas pode ser facilmente previsto e supera as contribuições da dieta<sup>1,29,33</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Ressonância magnética** -->
Na sobrecarga de ferro, o envolvimento do fígado pode levar ao aumento sérico de transaminases e evoluir para fibrose ou cirrose<sup>1,13</sup> , enquanto o envolvimento do coração pode resultar em insuficiência cardíaca, arritmia e maior risco de mortalidade<sup>14</sup> . Portanto, a dosagem do ferro cardíaco e hepático tem um papel essencial tanto na avaliação de complicações iminentes, quanto na orientação da terapia de quelação de ferro<sup>2</sup> sendo a ressonância magnética por T2* (lê-se _T2-estrela_ ) o método recomendado para avaliação funcional desses órgãos em diferentes diretrizes clínicas<sup>27,33–39</sup> .  
A avaliação por ressonância magnética (T2*) do fígado é recomendada na literatura para pacientes com talassemia não dependentes de transfusão quando a ferritina for ≥ 800 μg/L. Para pacientes com anemia hereditária que recebem transfusão e hemácias, a avaliação por T2* é recomendada quando os valores de ferritina estiverem acima de 1.000 μg/L e, nos casos de defeitos no metabolismo do ferro ou via heme, acima de 500 μg/L<sup>33,37</sup> . Por outro lado, não há relação entre a carga de ferro cardíaca e os parâmetros convencionais de status de ferro, ferritina sérica e ferro hepático<sup>40,41</sup> . Assim, o método é indicado, quando disponível, para avaliação funcional em pacientes com histórico conhecido ou risco de doença cardíaca ou condições associadas que podem oferecer risco ao coração. Essa avaliação também pode auxiliar na identificação de pacientes que requerem aumento oportuno da intensidade da quelação (frequência ou dose)<sup>33</sup> .  
A ressonância magnética por T2* é um método de imagem não invasivo, rápido, com acurácia diagnóstica para a sobrecarga de ferro tecidual<sup>40–42</sup> . Para tanto é necessária a inclusão da instalação e utilização de sequências (T2*) padronizadas dos fabricantes, análise de imagens utilizando _software_ aprovado pelas autoridades reguladoras e treinamento adequado na aquisição e análise. Contudo, apesar da efetiva acurácia diagnóstica, os custos elevados e a disponibilidade limitada do exame impedem sua utilização como exame de rotina.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Biópsia hepática** -->
A biópsia para avaliação da concentração hepática de ferro é um método quantitativo específico e sensível, sendo a quantidade de ferro no tecido hepático descrita em miligramas de ferro por grama de tecido hepático seco. Assim, uma concentração hepática de ferro acima de 3,2 mg/g de fígado seco é considerada critério diagnóstico de sobrecarga de ferro<sup>29</sup> . O método pode ser considerado caso realizado anteriormente devido a outras condições, como estadiamento da fibrose hepática<sup>37</sup> .  
O perfil invasivo desse procedimento e a variação da amostragem dificultam seu emprego como exame de rotina, ficando sua utilização reservada para casos especiais de confirmação diagnóstica, em casos duvidosos ou documentação da presença de fibrose hepática<sup>29</sup> . Ao realizar o exame, o paciente deve ser comunicado sobre o risco de sangramento e complicações<sup>43</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Complicações da sobrecarga de ferro** -->
Como não existe um mecanismo natural para a remoção do excesso de ferro, observa-se um acúmulo gradual nos tecidos, com a consequente elevação a níveis tóxicos e formação de radicais livres que podem induzir dano celular, fibrose e esclerose<sup>2–</sup> 4,6. Sem tratamento, o acúmulo de ferro no sangue afeta diretamente os órgãos, particularmente as células parenquimatosas, levando à produção de partículas de oxigênio altamente reativas que podem danificar as estruturas intracelulares<sup>30</sup> .  
6  
A sobrecarga de ferro pode causar ou contribuir para a falência orgânica e está associada a uma variedade de distúrbios, incluindo infecções, doença renal, doença hepática<sup>25</sup> . O comprometimento cardíaco é considerado o principal responsável pelo óbito nos pacientes com talassemia beta maior (2/3 dos casos), sendo também de importância expressiva na morbimortalidade de pacientes com doença falciforme e mielodisplasia<sup>4</sup> . Pacientes mais jovens geralmente têm cardiopatia detectável por sobrecarga de ferro após os 9,5 anos de idade<sup>14</sup> .  
A deposição cardíaca de ferro pode se manifestar como insuficiência cardíaca ou arritmias, incluindo fibrilação atrial, taquicardia ventricular (indicador grave de disfunção cardíaca), bradicardia e bloqueio cardíaco. As arritmias atriais são mais comuns em idosos. Taquicardia secundária à sobrecarga de ferro tem sido apresentada como fibrilação atrial e taquicardia ventricular, porém bradicardia e bloqueio cardíaco também podem ocorrer. A taquicardia ventricular é uma disfunção que requer avaliação urgente por especialista. A sobrecarga de ferro miocárdica é mais provável quando ocorrem taxas transfusionais que excedem significativamente a utilização de ferro pela medula óssea - na ausência de transfusão sanguínea, raramente isso acontece, mesmo com quantidades altas de ferro no organismo<sup>33</sup> .  
Quanto ao fígado, as espécies de ferro não ligadas levam à necrose celular e eventual fibrose hepática, que pode progredir para cirrose, especialmente quando a sobrecarga de ferro excede 7 mg/g de peso seco hepático. O padrão de distribuição de ferro hepatocelular periportal pode explicar a associação com carcinoma hepatocelular, mesmo nos pacientes que não apresentam hepatite C<sup>13,33</sup> .  
A maioria das complicações da sobrecarga de ferro pode ser evitada ou revertida com quelação adequada antes que ocorra dano permanente ou disfunção orgânica, como, por exemplo, hipogonadismo hipogonadotrófico, hipotireoidismo, atraso no crescimento, osteoporose, trombose, hipertensão pulmonar e disfunção renal<sup>3,33</sup> .  
A extensão e a gravidade da sobrecarga de ferro são afetadas tanto pelo distúrbio subjacente quanto pela intensidade e frequência da transfusão sanguínea. Os pacientes em transfusões sanguíneas regulares de reposição estão em maior risco de desenvolver a condição, enquanto aqueles em transfusões sanguíneas intermitentes a desenvolvem mais lentamente<sup>33</sup> . O aumento rápido e consistente de ferro no plasma pode causar distúrbio orgânico grave, principalmente em casos de início precoce, como as formas juvenis de hemocromatose<sup>13</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **4         CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT indivíduos de ambos os sexos com diagnóstico de condições clínicas que desencadeiam sobrecarga de ferro ou em situações clínicas que requeiram transfusões sanguíneas regulares (10 a 20 procedimentos) e apresentem uma das seguintes condições:  
- ferritina sérica acima de 1.000 μg/L; **ou**  
- biópsia hepática com concentração de ferro acima de 3,2 mg/g de fígado seco; **ou**  
- ressonância magnética por T2* com sobrecarga cardíaca ou hepática de ferro.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **5         CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos indivíduos cuja doença de base (que motivou as transfusões sanguíneas e, consequentemente, a sobrecarga de ferro) esteja resolvida, não sendo mais necessária terapia transfusional.  
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser excluídos ao uso do respectivo medicamento preconizado.  
Adicionalmente, para o uso de deferiprona, serão excluídos pacientes com idade inferior a 6 anos.  
7

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **6         CASOS ESPECIAIS** -->
Em pacientes com hemocromatose hereditária, o uso de quelantes de ferro deve ocorrer em uma das seguintes situações:  
- pacientes com anemia de etiologia não ferropriva, com hemoglobina abaixo de 11 g/L; **ou**  
- pacientes com hipotensão sintomática e intolerância a flebotomia; **ou**  
- pacientes sem possibilidade de acesso venoso para realização de flebotomia.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **7         TRATAMENTO** -->
Pacientes com sobrecarga de ferro possuem alternativas não-medicamentosas e medicamentosas para o tratamento da condição. O objetivo geral de ambas as terapias é a redução da carga total de ferro no organismo a concentrações não tóxicas ao organismo. A terapia é definida conforme contexto clínico do paciente, considerando a etiologia da doença e riscos associados<sup>6</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Flebotomia** -->
A flebotomia, também denominada de sangria terapêutica, consiste na retirada de sangue em uma fase de indução e outra de manutenção, normalmente a partir de acesso venoso no braço. A evidência disponível sugere que a flebotomia pode melhorar a fadiga, pigmentação da pele, artralgias e testes de função hepática, e resultar na regressão da fibrose hepática e cirroses<sup>27,37</sup> .  
Na fase de indução da flebotomia, o volume de sangue a ser retirado semanalmente varia entre 500 mL e 1.000 mL, conforme a tolerabilidade do paciente ou até que o nível sérico de ferritina alvo seja atingido (50 <mark>µg/L)</mark> . Então, inicia-se a fase de manutenção, com uma média de 2 a 6 sessões de flebotomia por ano, para que o nível sérico de ferritina seja mantido dentro da faixa esperada (50 <mark>µg/L</mark> a 100 <mark>µg/L)</mark> . É recomendado o monitoramento do nível de hemoglobina antes e durante o tratamento, garantindo que esteja sempre acima de 11 g/dL<sup>27,37,44–46</sup> . A administração de inibidores de bomba de prótons como terapia adjuvante na fase de manutenção da flebotomia pode promover a redução da absorção de ferro não-heme e da frequência da necessidade de flebotomia anualmente, mas não é recomendada para a rotina de tratamento da hemocromatose<sup>27,37</sup> .  
A flebotomia é recomendada no tratamento de pacientes com talassemia, doença falciforme<sup>44</sup> e síndrome mielodisplásica<sup>34,45,46</sup> , quando submetidos ao transplante de células hematopoiéticas, idealmente após a interrupção ou a redução de imunossupressão sistêmica, e recomendada como escolha inicial para depleção de ferro em paciente com hemocromatose<sup>27,37</sup> . Ao mesmo tempo, <mark>é contraindicada em condições potencialmente danosas como anemia grave e insuficiência cardíaca, baixa tolerância e refratariedade ao método, sendo preferido o uso do tratamento medicamentoso com quelantes de ferro para pacientes com sobrecarga de ferro secundária</mark><sup>37</sup> <mark>.</mark>  
<mark>Em pacientes grávidas, se a sobrecarga de ferro for considerada de leve a moderada e não apresentar sinais de doença hepática avançada, é recomendada a interrupção da flebotomia devido aos riscos associados à deficiência de ferro no desenvolvimento fetal. Caso seja necessário manter a flebotomia, o número de sessões deve ser diminuído e o nível sérico de ferritina deve ser mantido sempre acima de 45 µg/L</mark><sup>27,37</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Eritrocitaférese** -->
A eritrocitaférese é um procedimento, realizado em máquina de aférese, que consiste na remoção de eritrócitos com alteração qualitativa e quantitativa, seguida pela reposição de eritrócitos normais ou de uma solução de substituição, conforme indicação clínica. Esse procedimento tem sido descrito nas diretrizes internacionais como uma alternativa à flebotomia em pacientes com níveis de hemoglobina maior que 9 g/dL e com indicação de redução da hemoglobina S, na doença falciforme<sup>47–</sup> 49. Para pacientes com HH que apresentem hipoproteinemia ou trombocitopenia, eritrocitaférese pode ser considerada uma opção 37. Na doença falciforme, pode ser considerada como alternativa em pacientes com sobrecarga de ferro secundária a transfusões  
8  
crônicas, que apresentam eventos adversos ou não toleram/aderem à terapia de quelação<sup>48</sup> . Para pacientes com talassemia, não há qualquer recomendação para o uso do procedimento<sup>33,44</sup> . Seu uso para as condições recomendadas ocorre conforme disponibilidade do procedimento, experiência do serviço de saúde e necessidades e preferências do paciente<sup>27,37,47–49</sup> .  
Pode ser mais adequada para alguns grupos de pacientes, como em caso de intolerância ou refratariedade à flebotomia ou quando a flebotomia tem potencial danoso, quando há anemia grave ou insuficiência cardíaca congestiva. Também é uma alternativa para pacientes submetidos à transfusão sanguínea crônica, com doença cardíaca, devido à alteração hemodinâmica reduzida em comparação com a flebotomia, e aqueles com trombocitopenia ou hipoproteinemia devido ao retorno de outros componentes sanguíneos à circulação, visto que o método remove seletivamente as hemácias e devolve ao paciente os componentes remanescentes, como proteínas plasmáticas, fatores de coagulação e plaquetas<sup>27,37,47,48</sup> .  
Na HH a frequência recomendada de eritrocitaférese é uma vez a cada 2 semanas ou 3 semanas, dependendo dos valores de hemoglobina do paciente. O nível sérico de ferritina a ser atingido é semelhante ao da flebotomia: 50 μg/L na fase de indução e entre 50 μg/L a 100 μg/L na manutenção, sendo o volume de hemácias a ser removido geralmente entre 350 mL e 800 mL<sup>27,37</sup> .  
É importante destacar que o citrato, anticoagulante utilizado durante a eritrocitaférese, pode resultar em reações leves comuns nos pacientes, como cãibras musculares, parestesia e náusea<sup>27,37,48</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Tratamento medicamentoso** -->
O tratamento medicamentoso consiste no uso de quelantes de ferro que agem mediante a ligação ao ferro livre no organismo, promovendo assim a sua excreção pela urina e fezes. A quelação normalmente reduz o armazenamento de ferro no fígado mais rapidamente do que em outros tecidos, como o coração<sup>33</sup> . O objetivo do tratamento é manter as concentrações de ferritina sérica abaixo de 1.000 μg/L ou manter o ferro corpóreo correspondente a concentrações hepáticas de 3,2 mg/g a 7 mg/g de peso de fígado seco<sup>50</sup> . Esse tipo de tratamento permite maior comodidade de administração e manutenção quando comparado às medidas não-medicamentosas, devido à possibilidade de uso das apresentações orais, sem necessariamente depender de um ambiente hospitalar para a sua administração<sup>51</sup> .  
Diretrizes internacionais recomendam o uso de quelantes de ferro em casos de <mark>sobrecarga de ferro secundária</mark><sup>27,34–</sup> 39,44,46,48,51–53 <mark>.</mark> Já em casos de hemocromatose hereditária, a quelação de ferro está indicada nas seguintes situações: (i) pacientes com anemia de etiologia não ferropriva, com hemoglobina abaixo de 11 g/L; (ii) pacientes com hipotensão sintomática e intolerância a flebotomia; **OU** (iii) pacientes sem possibilidade de acesso venoso para realização de flebotomia.  
Ainda não há consenso na literatura sobre o momento ideal para iniciar com a terapia de quelação, havendo diferentes recomendações de diretrizes internacionais e nacionais conforme a etiologia da sobrecarga de ferro, o número de transfusões sanguíneas, as dosagens de ferritina sérica, saturação de transferrina e expectativa de vida<sup>32–35,52,53</sup> . Contudo, o que se tem em consenso dos medicamentos aprovados pela Agência Nacional de Vigilância Sanitária (Anvisa), é o início aproximadamente após dez transfusões de concentrados de hemácias ou 20 primeiras transfusões sanguíneas, ou quando for evidenciada a sobrecarga de ferro com o nível sérico de ferritina acima de 1.000 μg/L<sup>54,55</sup> . É necessário ajustar a dose dos quelantes durante o tratamento, em casos de insuficiência renal<sup>33,39,51</sup> .  
Os três quelantes de ferro aprovados pela Anvisa podem ser utilizados como primeira opção de tratamento, respeitandose os critérios de inclusão e exclusão deste PCDT. A escolha do quelante de ferro, seja em monoterapia ou em terapia quelante combinada, deve considerar o perfil do paciente, a adesão ao tratamento e o monitoramento dos eventos adversos.  
Em geral, a literatura sobre o uso dos quelantes no tratamento da sobrecarga de ferro é escassa, o que se deve à dificuldade de obtenção de grandes amostras de pacientes que necessitem de transfusões sanguíneas rotineiras que possam resultar na condição e às limitações dos diversos estudos, como seguimento de curto prazo e avaliação de desfechos laboratoriais.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de  
9  
problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Mesilato de desferroxamina** -->
O mesilato de desferroxamina é indicado como tratamento em monoterapia da quelação de ferro nos casos de acúmulo crônico de ferro (hemossiderose transfusional, hemocromatose idiopática ou em pacientes com contraindicação a flebotomia e acúmulo de ferro associado a porfiria cutânea tardia em pacientes que não toleram a flebotomia), sobrecarga de ferro secundária 35,37 e tratamento de intoxicação aguda por ferro, em paciente adulto e pediátrico. O mecanismo de ação resulta na formação de complexos com o ferro sérico, de modo que 1 g de mesilato de desferroxamina liga-se a 85 mg de ferro sérico<sup>54</sup> .  
Os principais desfechos abordados nos estudos de eficácia foram redução de danos a órgãos-alvos resultantes da deposição de ferro, medidas de concentração de ferro (ferritina sérica, saturação de transferrina, capacidade de ligação do ferro, ferro sérico), excreção de ferro (urina e fezes de 24 horas, principalmente) e eventos adversos<sup>56–66</sup> .  
A eficácia de mesilato de desferroxamina foi similar a de deferasirox quando observada comparações em doses proporcionais (28,2 mg/dia de deferasirox _versus_ 51,6 mg/dia de mesilato de desferroxamina)<sup>60</sup> . Em contrapartida, em outras três revisões que avaliaram tal comparação, não foram observadas diferenças significativas na sobrecarga de ferro no tecido hepático<sup>56,57,61</sup> e miocárdico<sup>61</sup> entre os grupos tratados. O aumento médio da creatinina também foi significativamente menor com mesilato de desferroxamina, comparada a deferasirox em duas revisões avaliadas<sup>61,64</sup> .  
Quanto aos eventos adversos, os resultados mostraram que foram menos prováveis no tratamento com mesilato de desferroxamina, em comparação a deferiprona e a deferasirox<sup>58</sup> . Em geral, o risco de ocorrência é reduzido quando se emprega terapia em doses baixas. Os eventos adversos mais descritos nos estudos clínicos foram retinopatia e toxicidade auditiva; houve raros relatos de retardo no crescimento e alterações ósseas (principalmente em pacientes pediátricos que iniciaram o tratamento nos primeiros três anos de vida com doses elevadas); insuficiência cardíaca quando terapia combinada com altas doses de vitamina C (acima de 500 mg/dia)<sup>27,34</sup> e dor nas articulações<sup>62</sup> . Dentre os eventos mais comuns estão cefaleia, dor abdominal, urina avermelhada, hipotensão arterial, urticária, vertigens, diarreia, náusea e vômitos<sup>54</sup> .  
Devido a sua baixa absorção por via oral, o medicamento é administrado por via subcutânea, intravenosa e intramuscular, conforme registro sanitário<sup>54</sup> . Contudo, cronogramas de infusão lenta subcutânea ou intravenosa se tornam um dificultador na adesão terapêutica ao tratamento, especialmente devido aos eventos adversos relacionados ao uso da bomba de infusão – risco de infecção, pneumonite ou insuficiência renal devido à alta dose ou taxas de infusão rápidas<sup>14,62</sup> . Além disso, a ausência de registro da bomba de infusão na Anvisa, as dificuldades na manutenção do equipamento, devido à ausência de equipes especializadas no país, e os custos dos insumos dificultam a operacionalização do procedimento, de caráter essencialmente hospitalar<sup>67</sup> . Se disponível, o uso da bomba de infusão é recomendado, em dispositivos portáteis por 8 horas a 12 horas por dia, durante 5 dias a 7 dias da semana, e especialmente para sobrecarga de ferro cardíaca, podendo ser administrados por tempo maior (24 horas ou mais), a depender do quadro do paciente<sup>67–69</sup> . Em pacientes incapacitados para receber a infusão subcutânea ou que tenham problemas cardíacos secundários ao acúmulo de ferro, é indicada a infusão intravenosa contínua<sup>54</sup> .  
O tratamento deve ser mantido até que os pacientes não apresentem mais sintomas de intoxicação sistêmica de ferro, com nível de ferro inferior a 100 µg/dL<sup>54</sup> . Essa orientação não se aplica aos casos de sobrecarga de ferro transfusional, nos quais os  
10  
critérios terapêuticos são distintos e baseiam-se, em geral, nos níveis de ferritina sérica. Em adultos com síndrome mielodisplásica, o tratamento deverá ser interrompido em caso de febre, até que seja descartado o risco de infecção (administração por bomba de infusão)<sup>14</sup> ou se a ferritina estiver menor que 1000 μg/L<sup>36</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Deferiprona** -->
O tratamento de quelação de ferro com deferiprona é indicado em monoterapia nos pacientes com talassemia para os quais a terapia com mesilato de desferroxamina não é recomendada ou em combinação com outros quelantes de ferro quando há necessidade de uma correção rápida ou intensiva dos níveis de ferro<sup>70,71</sup> . Também é indicado para o tratamento de excesso de ferro em pacientes com doença falciforme ou outras anemias, em pacientes adultos e pediátricos acima de 10 anos. As evidências são muito limitadas e não existem dados sobre o uso do produto em crianças menores de 6 anos. Assim, quando necessário, o uso em crianças com idades entre 6 e 10 anos, o tratamento deve ser realizado com cautela e acompanhamento adequados. Além disso, é considerada uma alternativa terapêutica para pacientes intolerantes ao deferasirox, para aqueles com comprometimento renal e para casos em que há necessidade de terapia combinada. O mecanismo de ação resulta na formação de complexos com o ferro sérico na proporção de 3:1 molar<sup>70</sup> .  
De uso oral, a deferiprona é considerada principalmente quando o paciente possui contraindicação ao uso de mesilato de desferroxamina<sup>37,63,71</sup> . Salienta-se que a apresentação de deferiprona 1.000 mg comprimido de liberação prolongada foi recomendada pela Conitec para o tratamento da sobrecarga de ferro, independente da causa, em virtude da discussão da avaliação de ampliação de uso da deferiprona para pacientes com sobrecarga de ferro e doença falciforme.  
A literatura aponta que a deferiprona pode ser particularmente eficaz na diminuição da concentração do ferro cardíaco, sendo utilizada para intensificar o tratamento com mesilato de desferroxamina nesse contexto<sup>63</sup> . Tem se mostrado eficaz também na redução do nível sérico de ferritina, principalmente em pacientes recebendo a dose diária de 75 mg/kg<sup>37</sup> .  
Em relação à segurança, os eventos adversos mais descritos nos estudos foram neutropenia, agranulocitose, náusea, artralgia e erupção cutânea<sup>33–35,37</sup> . Alguns estudos indicam que a agranulocitose é uma reação idiossincrática e que a neutropenia não se relaciona com a sua evolução, mesmo que preexistente ao tratamento com deferiprona<sup>72,73</sup> . O uso em pacientes com síndromes mielodisplásicas não tem sido rotineiramente indicado em diretrizes internacionais devido ao risco associado a agranulocitose em pacientes com neutropenia preexistente<sup>34–36,71</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Deferasirox** -->
É indicado para o tratamento de sobrecarga crônica de ferro devido às transfusões sanguíneas (hemossiderose transfusional) em pacientes adultos e pediátricos acima de 2 anos<sup>74</sup> e eficaz na deleção de ferro em sobrecarga secundária à talassemia<sup>59,75</sup> , doença falciforme<sup>64,76</sup> e síndrome mielodisplásica<sup>77,78</sup> . De uso oral, seu mecanismo de ação é altamente seletivo e consiste na ligação ao ferro com alta afinidade na proporção 2:1, promovendo sua excreção pelas fezes<sup>55</sup> .  
Considerado medicamento de escolha para o tratamento de sobrecarga de ferro em pacientes com anemia, dependentes de transfusão sanguínea em qualquer frequência, e com ferritina sérica elevada (acima de 1.000 μg/L), desde que a função renal esteja normal e estável nas primeiras semanas<sup>34–36,46,51–53</sup> . Também é uma alternativa terapêutica para pacientes que não tolerarem ou apresentarem contraindicações a mesilato de desferroxamina ou a deferiprona<sup>55</sup> . Também há estudos em que pacientes previamente tratados com mesilato de desferroxamina mostraram melhor satisfação no tratamento com deferasirox<sup>65</sup> .  
O tratamento com deferasirox é considerado eficaz devido à redução significativa da concentração de ferro hepática e cardíaca, podendo ser observada melhora nos valores de T2* em um ano de tratamento diário. O benefício também pode ser observado em pacientes em exposição transfusional regular<sup>55.</sup>  
Em relação à segurança, os eventos adversos mais descritos nos estudos foram distúrbios gastrintestinais, erupção cutânea, elevação da aminotransferase e toxicidade renal, que podem ocorrer em mais de 10% de todos os pacientes<sup>35,37</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Medicamentos** -->
11  
- mesilato de desferroxamina: pó para solução injetável de 500 mg;  
- deferiprona: comprimidos de 500 mg e comprimido revestido de liberação prolongada de 1.000 mg;  
- deferasirox: comprimidos para suspensão de 125 mg, 250 mg e 500 mg.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Esquemas de administração** -->
Mesilato de desferroxamina: infusão por via subcutânea através de bomba de infusão, de 20 mg/kg/dia a 60 mg/kg/dia, durante 8 horas a 24 horas. Um esquema alternativo é a infusão lenta por via intravenosa, de dose única de 2.000 mg, durante a transfusão de concentrado de hemácias, em pacientes adultos.  
Deferiprona: deve-se observar que os esquemas de administração diferem entre as apresentações de 500 mg e 1.000 mg, respectivamente:  
- 500 mg: 75 mg/kg/dia, divididos em três administrações (25 mg/kg a cada 8 horas), por via oral – 1 comprimido de 500  
- mg a cada 8 horas; OU  
- 1.000 mg: 75 mg/kg/dia, divididos em duas administrações a cada 12 horas de intervalo, por via oral, junto com  
- alimentos – arredondar a dose para 500 mg próximos (meio comprimido), conforme sugerido na Tabela 1;  
- Dose máxima: 100 mg/kg/dia.  
**Tabela 1. Número de comprimidos de deferiprona comprimido revestido de liberação prolongada de 1.000 mg necessários para atingir a dose inicial diária (75 mg/kg/dia) conforme peso do paciente.**  
|Peso corporal (kg)|Manhã|Noite|
|---|---|---|
|20|0,5|1|
|30|1|1,5|
|40|1,5|1,5|
|50|2|2|
|60|2|2,5|
|70|2,5|3|
|80|3|3|
|90|3,5|3,5|  
Para minimizar o desconforto gastrointestinal no início da terapia, a dose pode começar com 45 mg/kg/dia e aumentar semanalmente em incrementos de 15 mg/kg/dia até que a dose total prescrita seja alcançada.  
Deferasirox: 20 mg/kg/dia, por via oral, em dose única inicial. A dose máxima diária é de 40 mg/kg. Os comprimidos devem ser dissolvidos preferencialmente em água.  
A terapia de quelação de ferro deve ser revista a cada 3 meses para avaliar a eficácia, eventos adversos e adesão ao tratamento<sup>33</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Terapia combinada** -->
A terapia combinada com quelantes de ferro consiste na administração simultânea ou sequencial dos medicamentos e pode ser considerada quando<sup>33</sup> :  
- A sobrecarga de ferro não é controlada com o tratamento em monoterapia com deferiprona, mesilato de desferroxamina  
- ou deferasirox devido à dose insuficiente;  
- O paciente apresenta toxicidade dependente da dose limitada a monoterapia;  
- A adesão à monoterapia na frequência necessária é inadequada; ou  
- A combinação simultânea tem o potencial de aumentar sinergicamente as taxas de remoção de ferro celular.  
12  
As combinações de terapias descritas na literatura estão listadas no Quadro 1.  
**Quadro 1. Terapias combinadas recomendadas para o tratamento da sobrecarga de ferro.**  
|**Terapia combinada**|**Recomendaçōes**|
|---|---|
||-<br>A combinação pode ser utilizada para melhorar a excreção de ferro<sup>33</sup>em paciente com<br>insuficiência cardíaca induzida por ferro<sup>62,71</sup>e em pacientes com talassemia dependentes de<br>transfusão<sup>59,62</sup>, quando a monoterapia com deferasirox ou com deferiprona falhar no controle<br>do excesso de ferro ou na prevenção de suas complicações e, especialmente, como emergência|
|**Mesilato de**<br>**desferroxamina +**|médica, quando é necessária correção rápida dos níveis de ferro para prevenção da condição<br>cardíaca, que pode ser fatal<sup>71</sup>;|
|**deferiprona**|-<br>Deve ser utilizado com cautela devido ao risco aumentado de agranulocitose<br>associado ao uso da terapia combinada<sup>33,71</sup>;<br>-<br>A combinação com mesilato de desferroxamina não é recomendada quando a<br>monoterapia com qualquer um dos quelantes é adequada ou quando a dosagem de ferritina<br>sérica cai abaixo de 500 μg/L<sup>71</sup>.|
||-<br>A terapia combinada é eficaz e bem tolerada<sup>33</sup>, especialmente para paciente com<br>grave sobrecarga cardíaca de ferro<sup>36</sup>;|
|**Mesilato de**<br>**desferroxamina +**<br>**deferasirox**|-<br>Estudos demonstram em pacientes com grave sobrecarga hepática e cardíaca de ferro:<br>redução de 44% da ferritina sérica e de 52% da concentração de ferro no fígado, e o aumento<br>do T2* cardíaco em 33%<sup>33</sup>;<br>-<br>A combinação com mesilato de desferroxamina não é recomendada quando a<br>monoterapia com qualquer um dos quelantes é adequada ou quando a dosagem de ferritina<br>sérica cai abaixo de 500 μg/L<sup>71</sup>.|
|**Deferiprona +**<br>**deferasirox**|-<br>Dados limitados estão disponíveis sobre o uso dessa terapia combinada, mas a<br>associação tem sido descrita na literatura como eficaz, principalmente melhorando o T2*<br>cardíaco<sup>33,71</sup>.|  
Fonte: autoria própria.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Contraindicações** -->
Devem ser observadas as seguintes contraindicações:  
**Deferiprona**<sup>70,71</sup> **:**  
- gestantes e lactantes;  
- pacientes com história de agranulocitose, recorrência de neutropenia ou, ainda, que utilizem concomitantemente  
- medicamento(s) que possa(m) causar essas condições.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Deferasirox**<sup>55</sup> **:** -->
- pacientes com depuração de creatinina abaixo de 40 mL/min ou creatinina sérica acima de duas vezes o limite superior  
- da normalidade;  
- pacientes com menos de 2 anos de idade;  
- pacientes com síndrome mielodisplásica de alto risco e pacientes com outras condições de origem hematopoética ou  
não, nos quais não se esperam benefícios da terapia com quelantes.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Critérios de interrupção** -->
13  
**Mesilato de desferroxamina:** considerar interrupção quando o nível sérico de ferritina estiver abaixo de 1.000 μg/L<sup>54</sup> ou abaixo de 500 μg/L em pacientes com talassemia<sup>14</sup> ;  
**Deferiprona:** considerar interrupção quando o nível sérico de ferritina estiver abaixo de 500 μg/L<sup>70,71</sup> . Considerar suspensão em caso de neutropenia e interromper o tratamento em casos de agranulocitose<sup>35,72</sup> ;  
**Deferasirox:** considerar interrupção quando o nível sérico de ferritina estiver abaixo de 500 μg/L<sup>36</sup> .  
Cabe ressaltar que muitos pacientes com bom nível de quelação e que continuam sob transfusão sanguínea regular poderão apresentar valores de ferritina sérica abaixo de 1.000 μg/L, não estando indicada a suspensão do fornecimento do quelante<sup>33</sup> . Tais pacientes continuam tendo excesso de ferro por transfusão sanguínea, produzindo ferro livre, elemento que promove a injúria tecidual nos órgãos. Nesses casos, deve-se orientar a redução da dose e não a suspensão dos medicamentos<sup>79</sup>

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Tratamento de populações específicas** -->
A realização de flebotomia em gestantes com sobrecarga de ferro deverá ser avaliada pelo médico<sup>27</sup> .  
Mesilato de desferroxamina e deferasirox são medicamentos de categoria C de risco na gravidez, portanto, só devem ser utilizados quando o benefício esperado supera o risco potencial para o feto. Ambos os medicamentos não devem ser utilizados sem orientação médica<sup>27,54,55</sup> . Deferiprona é um medicamento de categoria X de risco na gravidez, portanto, o risco para o feto é maior do que qualquer benefício possível para a paciente<sup>70</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **8         MONITORAMENTO** -->
Os níveis de ferritina sérica devem ser avaliados para a adequação do tratamento com quelante de ferro eleito. A remoção do ferro do fígado demora no mínimo 12 meses e, do coração, pelo menos o dobro desse tempo. Estima-se aumento aproximado de 30% no risco de morte para cada 500 μg/L na ferritina sérica acima do limiar de 1.000 μg/L<sup>10,14</sup> . Portanto, o ideal é a verificação dos valores séricos de ferritina com maior frequência, a cada 3 semanas a 6 semanas, para que médias de execução possam ser calculadas, diminuindo os erros decorrentes de flutuações transitórias; além da complementação do exame com outros parâmetros, como marcadores inflamatórios<sup>2,5,35</sup> .  
Além disso, a relação entre os valores de ferritina sérica e o estoque corporal de ferro pode variar de acordo com o quelante usado e o tempo de quelação<sup>33</sup> . Nesse sentido, as diretrizes clínicas também recomendam: (i) para sobrecarga de ferro associada à HH, o monitoramento mensal de níveis séricos de ferro e avaliação da função renal e hepática; (ii) para sobrecarga de ferro associada à doença falciforme, o monitoramento do ferro hepático por meio de ressonância magnética T2* a cada 1 a 2 anos e acompanhamento regular da ferritina sérica em pacientes que recebem transfusão sanguínea crônica, pelo menos a cada 3 meses; (iii) para sobrecarga de ferro secundária à síndrome mielodisplásica, o monitoramento da função hepática renal, com avaliações laboratoriais regulares durante todo o período de quelação de ferro (pelo menos nas oito primeiras semanas), incluindo monitoramento semanal da creatinina sérica nas primeiras semanas de tratamento e acompanhamento contínuo da função hepática e cardíaca; e (iv) para sobrecarga de ferro secundária à talassemia, monitoramento anual cardíaco e hepático em pacientes transfundidos.  
O monitoramento por ressonância magnética cardíaca e fração de ejeção do ventrículo esquerdo (FEVE) auxilia na identificação de pacientes que requerem aumento oportuno da intensidade da quelação (frequência ou dose)<sup>33</sup> . Também deve ser considerado em pacientes que recebem transfusões sanguíneas regularmente<sup>48</sup> , dado o risco aumentado de sobrecarga cardíaca. Além disso, a insuficiência cardíaca aguda pode ser precedida por uma pequena queda na FEVE.  
Ademais, todos os pacientes com sobrecarga de ferro devem ser acompanhados com avaliação trimestral de creatinina, aminotransferases/transaminases – AST/TGO e alanina aminotransferase (ALT)/ transaminase glutâmico-pirúvica (TGP), gamaglutamiltransferase, fosfatase alcalina, bilirrubinas, ferritina sérica e saturação de transferrina<sup>50</sup> .  
14  
Em relação à segurança na utilização dos quelantes de ferro, o risco de eventos adversos é reduzido quando se emprega terapia em doses baixas<sup>33</sup> e são reversíveis quando identificados precocemente, devendo haver o monitoramento dos sinais e sintomas dos pacientes durante o uso de quelantes de ferro<sup>31</sup> . A maioria dos casos de toxicidade por ferro ocorre em tecidos extra-hepáticos, os quais apresentam mecanismos diferentes de absorção/depuração de ferro em relação ao fígado<sup>29</sup> . Como resultado, a deposição de ferro em órgãos extra-hepáticos é fortemente influenciada pela duração da exposição aos quelantes, enquanto os níveis hepáticos de ferro têm relação mais estabelecida com a quantidade total de quelante utilizada<sup>29,33</sup> .  
Pacientes em uso de mesilato de desferroxamina devem ter suas acuidades visual e auditiva avaliadas antes do início do tratamento e a cada três meses após o início, uma vez que podem ocorrer catarata, neurite óptica, perdas visual e auditiva. Os eventos adversos mais comuns são cefaleia, dor abdominal, urina avermelhada, hipotensão arterial, urticária, vertigens, diarreia, náusea e vômitos. Se a concentração hepática não puder ser regularmente avaliada, um índice de toxicidade, definido como a dose média de mesilato de desferroxamina dividida pela concentração de ferritina, deve ser calculado para os pacientes, a cada 6 meses, e não deve exceder 0,02526. Pacientes com distúrbios visuais prévios ou que desenvolvam tal complicação com o tratamento não devem utilizar o medicamento<sup>54</sup> .  
Pacientes em uso de deferiprona devem ser monitorados semanalmente para contagem de neutrófilos e identificação de episódios de neutropenia e agranulocitose. A suspensão da terapia é suficiente para resolver o quadro, mas em caso de recorrência, a reintrodução do medicamento não é recomendada em caso de agranulocitose<sup>27,71</sup> . Recomenda-se o monitoramento da função hepática, uma vez que a deferiprona pode causar hepatotoxicidade. Também é indicado o acompanhamento da função renal e da concentração plasmática de zinco, com suplementação de sulfato de zinco em caso de deficiência<sup>71</sup> . Os pacientes que apresentarem agranulocitose devem ser tratados conforme Protocolo de Síndrome de Falência Medular vigente do Ministério da Saúde<sup>80</sup> .  
Pacientes em uso de deferasirox devem ter as funções hepática e renal (creatinina e proteinúria) avaliadas antes do início do tratamento e mensalmente após o início<sup>33,55</sup> . É recomendado avaliar riscos e benefícios clínicos da terapia com o medicamento<sup>32</sup> . Está indicada a suspensão do medicamento quando houver insuficiência hepática ou depuração de creatinina abaixo de 40 mL/min<sup>33,55</sup> .  
Na hemocromatose hereditária, a suplementação com vitamina C deve ser evitada, pois o ácido ascórbico aumenta a absorção intestinal de ferro. É importante, ainda, investigar distúrbios relacionados ao álcool e aconselhar abstenção antes de prosseguir com o tratamento, especialmente em caso de doença hepática<sup>27,37</sup> .  
Na talassemia dependente de transfusão, se a deficiência de vitamina C for confirmada, a suplementação injetável de vitamina C (2 mg/kg/dia a 3 mg/kg/dia) é recomendada junto com mesilato de desferroxamina. A vitamina C pode ser útil para reduzir o estresse oxidativo e melhorar a eficácia do deferasirox, particularmente em pacientes com sobrecarga de ferro grave. Porém, a suplementação deve ser usada com cautela na dose de 2 mg/kg/dia a 3 mg/kg/dia (geralmente 100 mg/dia) para evitar toxicidade e o aumento do ferro não ligado à transferrina<sup>14,16</sup> .  
Considerando que a vitamina C aumenta a excreção de ferro ao elevar a disponibilidade do ferro quelável, seu uso pode ser benéfico como adjuvante em alguns casos, e está disponível a nível hospitalar como vitamina C injetável. Porém, em doses altas, pode aumentar a toxicidade do ferro. Importante lembrar que a vitamina C só deve ser administrada quando o paciente não apresenta disfunção cardíaca aguda. O uso de vitamina C com deferiprona não é claro e, portanto, não é recomendado<sup>16,71</sup> .

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **9         REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do  
15  
acompanhamento. Os pacientes com sobrecarga de ferro devem ser atendidos em serviços especializados em hemoterapia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com sobrecarga de ferro devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos. Os procedimentos diagnósticos (Grupo 02) e terapêuticos clínicos (Grupo 03) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva condição clínica, no SIGTAP – Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Algumas doenças de base que desencadeiam a sobrecarga de ferro são consideradas raras, tais como anemia sideroblástica, anemia de Fanconi, anemia aplásica refratária, anemia diseritropoiética congênita tipos I, II e III, aplasia pura de série eritroide, leucemias agudas, anemia hemolítica, doença falciforme, beta talassemia, síndrome mielodisplásica, e que requerem múltiplas transfusões de hemácias ou sangue total<sup>6</sup> . Outras anemias raras também podem levar a dependência transfusional e à sobrecarga de ferro, como anemia de _Blackfan-Diamond_ não responsiva a corticoterapia e deficiência de piruvatoquinase<sup>7,8</sup> .  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017<sup>81</sup> e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>82</sup> .  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adscrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de atenção especializada em doenças raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de referência em doenças raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
16  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS, e se houver necessidade o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Pacientes com suspeita de anemia sideroblástica, anemia de Fanconi, anemia aplásica refratária, anemia diseritropoiética congênita tipos I, II e III, aplasia pura de série eritroide, leucemias agudas, anemia hemolítica, doença falciforme, beta talassemia, síndrome mielodisplásica, anemia de _Blackfan-Diamond_ não responsiva a corticoterapia e deficiência de piruvatoquinase devem ser encaminhados, preferencialmente, a um serviço especializado ou de referência em doenças raras para seu adequado diagnóstico.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com sobrecarga de ferro deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **10       TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).  
17

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **11       REFERÊNCIAS** -->
1. Brasil. Boletim Brasileiro de Avaliação de Tecnologias em Saúde. _BRATS_ ; IV.  
2. Gattermann N, Muckenthaler M, Kulozik A, et al. The Evaluation of Iron Deficiency and Iron Overload. _Dtsch Arztebl Int_ 2021; 118: 847–856.  
3. Roemhild K, von Maltzahn F, Weiskirchen R, et al. Iron metabolism: pathophysiology and pharmacology. _Trends Pharmacol Sci_ 2021; 42: 640–656.  
4. Santos P, Cançado R, Terada C, et al. Alterações moleculares associadas à hemocromatose hereditária. _Rev Bras Hematol Hemoter_ 2009; 31: 192–202.  
5. Kushner JP, Porter JP, Olivieri NF. Secondary Iron Overload. _Hematology_ 2001; 2001: 47–61.  
6. Herkenhoff M, Pitlovanciv A, Remualdo V. Prevalence of C282Y and H63D mutations in the HFEgene in patients from São Paulo and Southern Brazil. _J Bras Patol Med Lab_ 2016; 52: 21–24.  
7. Camaschella C. Hereditary sideroblastic anemias: pathophysiology, diagnosis, and treatment. _Semin Hematol_ 2009; 46: 371–377.  
8. Cappellini MD, Porter J, El-Beshlawy A, et al. Tailoring iron chelation by iron intake and serum ferritin: the prospective EPIC study of deferasirox in 1744 patients with transfusion-dependent anemias. _Haematologica_ 2010; 95: 557–566.  
9. World Health Organization. WHO Guideline on use of ferritin concentrations to assess iron status in individuals and population, https://www.who.int/publications/i/item/9789240000124 (2020, accessed 22 June 2024).  
10. Mantovani LF, Santos FPS, Perini GF, et al. Hepatic and cardiac and iron overload detected by T2* magnetic  
- resonance (MRI) in patients with myelodisplastic syndrome: A cross-sectional study. _Leuk Res_ 2019; 76: 53–57.  
11. Ministério da Saúde. Dia de conscientização sobre a Doença Falciforme: diagnóstico e tratamento podem ser feitos pelo SUS, https://www.gov.br/saude/pt-br/assuntos/noticias/2024/junho/dia-de-conscientizacao-sobre-a-doencafalciforme-diagnostico-e-tratamento-podem-ser-feitos-pelo-sus (2024, accessed 17 June 2025).  
12. Rosenfeld LG, Bacal NS, Cuder MAM, et al. Prevalência de hemoglobinopatias na população adulta brasileira: Pesquisa Nacional de Saúde 2014-2015. _Revista Brasileira de Epidemiologia_ ; 22. Epub ahead of print 2019. DOI: 10.1590/1980-549720190007.supl.2.  
13. Krindges S, Flores J, Lul R. Lesões hepáticas associadas à hemocromatose hereditária. _Rev Assoc Méd Rio Gd do Sul_ 2021; 65: 01022105.  
14. Veríssimo MP de A, Loggetto SR, Fabron Junior A, et al. Brazilian Association of Thalassemia protocol for iron chelation therapy in patients under regular transfusion. _Rev Bras Hematol Hemoter_ ; 35. Epub ahead of print 2013. DOI: 10.5581/1516-8484.20130106.  
15. Cançado RD, Jesus JA. A doença falciforme no Brasil. _Rev Bras Hematol Hemoter_ ; 29. Epub ahead of print September 2007. DOI: 10.1590/S1516-84842007000300002.  
16. Taher AT, Farmakis D, Porter JB, et al. _Guidelines for the Management of Transfusion-Dependent β- Thalassaemia (TDT)_ . 5th ed. Nicosia: Thalassaemia International Federation, 2025.  
17. Villani KJ, Viana GC, Caravalho GR de, et al. Hemocromatose hereditária relacionada ao gene HFE / Hereditary hemochromatosis HFE gene related. _Rev interdisciplin estud exp anim hum (impr)_ 2010; 2: 14–21.  
18. Alves LNR, Santos EVW, Stur E, et al. Molecular epidemiology of HFE gene polymorphic variants (C282Y, H63D and S65C) in the population of Espírito Santo, Brazil. _Genetics and Molecular Research_ ; 15. Epub ahead of print 2016. DOI: 10.4238/gmr.15028189.  
18  
19. Katsarou M-S, Papasavva M, Latsi R, et al. Hemochromatosis: Hereditary hemochromatosis and HFE gene. 2019, pp. 201–222.  
20. Agostinho MF, Arruda VR, Basseres DS, et al. Mutation Analysis of the HFE Gene in Brazilian Populations. _Blood Cells Mol Dis_ 1999; 25: 324–327.  
21. Bueno S, Duch CR, Figueiredo MS. Mutations in the HFE gene (C282Y, H63D, S65C) in a Brazilian population. _Rev Bras Hematol Hemoter_ ; 28. Epub ahead of print December 2006. DOI: 10.1590/S151684842006000400015.  
22. Santos P, Cançado R, Terada C, et al. Relação entre mutações no gene HFE e TFR2 e alterações nos parâmetros de ferro segundo a frequência de doação em doadores de sangue. _Rev Bras Hematol Hemoter_ 2008; 30: 21.  
23. Bittencourt PL, Marin MLC, Couto CA, et al. Analysis of HFE And Non-HFE Gene Mutations in Brazilian Patients with Hemochromatosis. _Clinics_ 2009; 64: 837–841.  
24. Coates TD, Wood JC. How we manage iron overload in sickle cell patients. _Br J Haematol_ 2017; 177: 703– 716.  
25. Wells RA, Leber B, Buckstein R, et al. Iron overload in myelodysplastic syndromes: A Canadian consensus guideline. _Leuk Res_ 2008; 32: 1338–1353.  
26. Kelly S, Belisário AR, Werneck Rodrigues DO, et al. Blood utilization and characteristics of patients treated with chronic transfusion therapy in a large cohort of Brazilian patients with sickle cell disease. _Transfusion (Paris)_ 2020;  
60: 1713–1722.  
27. Zoller H, Schaefer B, Vanclooster A, et al. EASL Clinical Practice Guidelines on haemochromatosis. _J Hepatol_ 2022; 77: 479–502.  
28. Leandro B, Paneque M, Sequeiros J, et al. Insufficient Referral for Genetic Counseling in the Management of Hereditary Haemochromatosis in Portugal: A Study of Perceptions of Health Professionals Requesting _HFE_ Genotyping. _J Genet Couns_ 2014; 23: 770–777.  
29. Wood JC. Guidelines for quantifying iron overload. _Hematology_ 2014; 2014: 210–215.  
30. Pietrangelo A. Hereditary Hemochromatosis: Pathogenesis, Diagnosis, and Treatment. _Gastroenterology_ 2010; 139: 393-408.e2.  
31. DB - Diagnósticos. Guia de Exames. Índice de Saturação da Transferrina (IST). CID10: E83.1, D50, N18, N04, D56, https://gde.diagnosticosdobrasil.com.br/GDE_Home/DetalheDoExame.aspx?ExameId=IST (2023, accessed 7 May 2023).  
32. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. _Orientações para diagnóstico e tratamento das Talassemias Beta / Ministério da Saúde, Secretaria de Atenção à Saúde, Departamento de Atenção Especializada e Temática_ . 1 ed. Brasília: Ministério da Saúde, 2016.  
33. Shah FT, Porter JB, Sadasivam N, et al. Guidelines for the monitoring and management of iron overload in patients with haemoglobinopathies and rare anaemias. _Br J Haematol_ 2022; 196: 336–350.  
34. Leitch HA, Buckstein R, Zhu N, et al. Iron overload in myelodysplastic syndromes: Evidence based guidelines from the Canadian consortium on MDS. _Leuk Res_ 2018; 74: 21–41.  
35. Valent P, Stauder R, Theurl I, et al. Diagnosis, management and response criteria of iron overload in myelodysplastic syndromes (MDS): updated recommendations of the Austrian MDS platform. _Expert Rev Hematol_ 2018; 11: 109–116.  
36. Killick SB, Ingram W, Culligan D, et al. British Society for Haematology guidelines for the management of adult myelodysplastic syndromes. _Br J Haematol_ 2021; 194: 267–281.  
19  
37. Kowdley K V., Brown KE, Ahn J, et al. ACG Clinical Guideline: Hereditary Hemochromatosis. _American Journal of Gastroenterology_ 2019; 114: 1202–1218.  
38. Davis BA, Allard S, Qureshi A, et al. Guidelines on red cell transfusion in sickle cell disease. Part I: principles and laboratory aspects. _Br J Haematol_ 2017; 176: 179–191.  
39. Davis BA, Allard S, Qureshi A, et al. Guidelines on red cell transfusion in sickle cell disease Part II: indications for transfusion. _Br J Haematol_ 2017; 176: 192–209.  
40. Kayrak M, Acar K, Gul EE, et al. The Association between Myocardial Iron Load and Ventricular Repolarization Parameters in Asymptomatic Beta-Thalassemia Patients. _Adv Hematol_ 2012; 2012: 1–6. 41. Anderson L. Cardiovascular T2-star (T2*) magnetic resonance for the early diagnosis of myocardial iron overload. _Eur Heart J_ 2001; 22: 2171–2179.  
42. Tanner MA, He T, Westwood MA, et al. Multi-center validation of the transferability of the magnetic resonance T2* technique for the quantification of tissue iron. _Haematologica_ 2006; 91: 1388–91.  
43. Porter JB, Davis BA. Monitoring chelation therapy to achieve optimal outcome in the treatment of thalassaemia. _Best Pract Res Clin Haematol_ 2002; 15: 329–68.  
44. Shenoy S, Gaziev J, Angelucci E, et al. Late Effects Screening Guidelines after Hematopoietic Cell Transplantation (HCT) for Hemoglobinopathy: Consensus Statement from the Second Pediatric Blood and Marrow Transplant Consortium International Conference on Late Effects after Pediatric HCT. _Biology of Blood and Marrow Transplantation_ 2018; 24: 1313–1321.  
45. DeFilipp Z, Ciurea SO, Cutler C, et al. Hematopoietic Cell Transplantation in the Management of Myelodysplastic Syndrome: An Evidence-Based Review from the American Society for Transplantation and Cellular Therapy Committee on Practice Guidelines. _Transplant Cell Ther_ 2023; 29: 71–81.  
46. de Witte T, Bowen D, Robin M, et al. Allogeneic hematopoietic stem cell transplantation for MDS and CMML: recommendations from an international expert panel. _Blood_ 2017; 129: 1753–1762.  
47. Biller E, Zhao Y, Berg M, et al. Red blood cell exchange in patients with sickle cell disease—indications and management: a review and consensus report by the therapeutic apheresis subsection of the AABB. _Transfusion (Paris)_ 2018; 58: 1965–1972.  
48. Chou ST, Alsawas M, Fasano RM, et al. American Society of Hematology 2020 guidelines for sickle cell disease: transfusion support. _Blood Adv_ 2020; 4: 327–355.  
49. Loggetto SR, Veríssimo MPA, Darrigo-Junior LG, et al. Guidelines on sickle cell disease: secondary stroke prevention in children and adolescents. Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular guidelines project: Associação Médica Brasileira - 2022. _Hematol Transfus Cell Ther_ 2022; 44: 246–255.  
50. Olivieri NF, Brittenham GM. Iron-Chelating Therapy and the Treatment of Thalassemia. _Blood_ 1997; 89: 739– 761.  
51. Fenaux P, Haase D, Santini V, et al. Myelodysplastic syndromes: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up† ☆ . _Annals of Oncology_ 2021; 32: 142–156.  
52. Miyazaki Y. JSH Guideline for Tumors of Hematopoietic and Lymphoid Tissues: Leukemia: 6. Myelodysplastic syndromes (MDS). _Int J Hematol_ 2017; 106: 151–159.  
53. Miyazaki Y. JSH practical guidelines for hematological malignancies, 2018: I. Leukemia-6 myelodysplastic syndromes (MDS). _Int J Hematol_ 2020; 111: 481–493.  
54. Anvisa. Mesilado de desferroxamina 500 mg. Desferal. Bula Profissional. 2021. Novartis Biociências. _Agência Nacional de Vigilância Sanitária_ ,  
20  
https://consultas.anvisa.gov.br/api/consulta/medicamentos/arquivo/bula/parecer/eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiI xNDAxMzEzOSIsIm5iZiI6MTcxOTI1MzgwOSwiZXhwIjoxNzE5MjU0MTA5fQ.3FuY7eLTMIPFAP5J0RQIrLLug U_ovgn9ndOwA1ntUm6BOIma71k57cXSKMSUaFFfxveQHBvyUh9BspL5BOOZ3w/?Authorization= (2021, accessed 20 June 2024).  
55. Anvisa. Deferasirox 125 mg, 250 mg e 500 mg. Exjade. Bula Profissional. Novartis Biociências. _Agência Nacional de Vigilância Sanitária_ , https://consultas.anvisa.gov.br/api/consulta/medicamentos/arquivo/bula/parecer/eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiI yMjIwMjUxMiIsIm5iZiI6MTcxOTI2NDI5MiwiZXhwIjoxNzE5MjY0NTkyfQ.aaQa2RHIrTdmdGSLGM0WkemxSkvD3twgmsEaPZvG9wtbPFsgJ_wSjWttRf0hB5BAWGSAQlrklr04n3LEVNGoA/?Authorization= (2024, accessed 20 June 2024).  
56. Roberts D, Rees D, Howard J, et al. Desferrioxamine mesylate for managing transfusional iron overload in people with transfusion-dependent thalassaemia. In: Roberts D (ed) _Cochrane Database of Systematic Reviews_ . Chichester, UK: John Wiley & Sons, Ltd, 2005. Epub ahead of print 19 October 2005. DOI: 10.1002/14651858.CD004450.pub2.  
57. Roberts D, Brunskill S, Doree C, et al. Oral deferiprone for iron chelation in people with thalassaemia. In: Roberts D (ed) _Cochrane Database of Systematic Reviews_ . Chichester, UK: John Wiley & Sons, Ltd, 2007. Epub ahead of print 18 July 2007. DOI: 10.1002/14651858.CD004839.pub2.  
58. Meerpohl JJ, Antes G, Rücker G, et al. Deferasirox for managing transfusional iron overload in people with sickle cell disease. In: Meerpohl JJ (ed) _Cochrane Database of Systematic Reviews_ . Chichester, UK: John Wiley & Sons, Ltd, 2010. Epub ahead of print 4 August 2010. DOI: 10.1002/14651858.CD007477.pub2.  
59. Maggio A, Kattamis A, Felisi M, et al. Evaluation of the efficacy and safety of deferiprone compared with deferasirox in paediatric patients with transfusion-dependent haemoglobinopathies (DEEP-2): a multicentre, randomised, open-label, non-inferiority, phase 3 trial. _Lancet Haematol_ 2020; 7: e469–e478.  
60. Meerpohl JJ, Antes G, Rücker G, et al. Deferasirox for managing iron overload in people with thalassaemia. In: Meerpohl JJ (ed) _Cochrane Database of Systematic Reviews_ . Chichester, UK: John Wiley & Sons, Ltd, 2012. Epub ahead of print 15 February 2012. DOI: 10.1002/14651858.CD007476.pub2.  
61. Qadah T. Deferasirox versus deferoxamine in managing iron overload in patients with Sickle Cell Anaemia: a systematic review and meta-analysis. _Journal of International Medical Research_ ; 50. Epub ahead of print 22 December 2022. DOI: 10.1177/03000605221143290.  
62. Fisher SA, Brunskill SJ, Doree C, et al. Desferrioxamine mesylate for managing transfusional iron overload in people with transfusion-dependent thalassaemia. _Cochrane Database of Systematic Reviews_ ; 2013. Epub ahead of print 21 August 2013. DOI: 10.1002/14651858.CD004450.pub3.  
63. Fisher SA, Brunskill SJ, Doree C, et al. Oral deferiprone for iron chelation in people with thalassaemia. _Cochrane Database of Systematic Reviews_ ; 2013. Epub ahead of print 21 August 2013. DOI: 10.1002/14651858.CD004839.pub3.  
64. Meerpohl JJ, Schell LK, Rücker G, et al. Deferasirox for managing transfusional iron overload in people with sickle cell disease. _Cochrane Database of Systematic Reviews_ ; 2017. Epub ahead of print 4 June 2014. DOI: 10.1002/14651858.CD007477.pub3.  
65. Bollig C, Schell LK, Rücker G, et al. Deferasirox for managing iron overload in people with thalassaemia. _Cochrane Database of Systematic Reviews_ ; 2017. Epub ahead of print 15 August 2017. DOI: 10.1002/14651858.CD007476.pub3.  
21  
66. Saleem A, Waqar E, Shuja SH, et al. No difference in myocardial iron concentration and serum ferritin with deferasirox and deferiprone in pediatric patients with hemoglobinopathies: A systematic review and meta-analysis. _Transfusion Clinique et Biologique_ 2023; 30: 69–74.  
67. Brittenham GM. Iron-Chelating Therapy for Transfusional Iron Overload. _New England Journal of Medicine_ 2011; 364: 146–156.  
68. Hayes D, Reilly R, Lee M. The pharmaceutical stability of deferoxamine mesylate. _Canadian Journal of Hospital Pharmacy_ ; 47.  
69. Franchini M, Gandini G, Veneri D, et al. Safety and efficacy of subcutaneous bolus injection of deferoxamine in adult patients with iron overload: an update. _Blood_ 2004; 103: 747–748.  
70. Anvisa. Deferiprona 1000 mg. Ferriprox BD. Bula Profissional. Chiesi Farmaceutica. _Agência Nacional de Vigilância Sanitária_ , https://www.chiesi.com.br/ferriprox-bd/bula-paciente (2024, accessed 18 February 2025).  
71. Anvisa. Deferiprona 500 mg. Ferriprox. Bula Profissional. Chiesi Farmaceutica. _Agência Nacional de Vigilância Sanitária_ , https://consultas.anvisa.gov.br/api/consulta/medicamentos/arquivo/bula/parecer/eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiI xNDk2NDUxOCIsIm5iZiI6MTcxOTk1ODc1NSwiZXhwIjoxNzE5OTU5MDU1fQ.PhL9Dmir5LdAeGMKHy44acsnI IQA5CpBuHYllCHlY9MhMb5OaWa1On_GUH_WL8nV4Dm_W4o6RlX2B8LMRYAIEg/?Authorization= (2021, accessed 20 June 2024).  
72. Elalfy M, Wali YA, Qari M, et al. Deviating from safety guidelines during deferiprone therapy in clinical practice may not be associated with higher risk of agranulocytosis. _Pediatr Blood Cancer_ 2014; 61: 879–884.  
73. Tricta F, Uetrecht J, Galanello R, et al. Deferiprone‐induced agranulocytosis: 20 years of clinical observations. _Am J Hematol_ 2016; 91: 1026–1031.  
74. Cançado R, Melo MR, de Moraes Bastos R, et al. Deferasirox in patients with iron overload secondary to hereditary hemochromatosis: results of a 1‐yr Phase 2 study. _Eur J Haematol_ 2015; 95: 545–550.  
75. Cappellini MD, Cohen A, Piga A, et al. A phase 3 study of deferasirox (ICL670), a once-daily oral iron chelator, in patients with beta-thalassemia. _Blood_ 2006; 107: 3455–3462.  
76. Cancado R, Olivato MCA, Bruniera P, et al. Two-Year Analysis of Efficacy and Safety of Deferasirox Treatment for Transfusional Iron Overload in Sickle Cell Anemia Patients. _Acta Haematol_ 2012; 128: 113–118.  
77. Adams RLC, Bird RJ. Safety and efficacy of deferasirox in the management of transfusion-dependent patients with myelodysplastic syndrome and aplastic anaemia: a perspective review. _Ther Adv Hematol_ 2013; 4: 93–102.  
78. Jiménez‐Solas T, López‐Cadenas F, Aires‐Mejía I, et al. Deferasirox reduces oxidative DNA damage in bone marrow cells from myelodysplastic patients and improves their differentiation capacity. _Br J Haematol_ 2019; 187: 93– 104.  
79. Glickstein H, El R Ben, Link G, et al. Action of chelators in iron-loaded cardiac cells: accessibility to intracellular labile iron and functional consequences. _Blood_ 2006; 108: 3195–3203.  
80. Brasil. Ministério da Saúde. Portaria Conjunta n<sup>o</sup> 23, de 04 de novembro de 2022. Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Falência Medular, https://www.gov.br/conitec/ptbr/midias/protocolos/20221109_pcdt_sindrome_falencias_medulares.pdf (2022, accessed 20 June 2024).  
81. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017, https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html (2017, accessed 20 June 2024).  
82. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 6, de 28 de setembro de 2017, https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.html (2017, accessed 20 June 2024).  
22  
Eu,______________________________________________________________________________________ (nome

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE MESILATO DE DESFERROXAMINA, DEFERIPRONA, DEFERASIROX** -->
do[a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de mesilato de desferroxamina, deferiprona e deferasirox, indicados para o tratamento de sobrecarga de ferro.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- diminuição dos estoques de ferro no organismo:  
- redução das complicações cardíacas e hepáticas, decorrentes do excesso de ferro; e  
- diminuição da mortalidade em pessoas com talassemia  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Medicamento mesilato de desferroxamina e deferasirox: medicamentos classificados na gestação como categoria C  
- (significa que risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos);  
- Medicamento deferiprona na gestação: em estudos em animais e mulheres grávidas, o fármaco provocou anomalias  
- fetais, havendo clara evidência de risco para o feto que é maior do que qualquer benefício possível para a paciente.  
• Os eventos adversos mais comuns do medicamento mesilato de desferroxamina são: reações no local de aplicação da injeção (dor, inchaço, coceira, vermelhidão), urina escura, vermelhidão da pele, coceira, reações alérgicas, visão borrada, catarata, distúrbios de audição, zumbidos, tontura, dificuldade para respirar, desconforto abdominal, diarreia, cãibra nas pernas, taquicardia, febre, retardo no crescimento (em pacientes que iniciam o tratamento antes dos 3 anos de vida), distúrbio renal, suscetibilidade a infecções ( _Yersinia_ e mucormicose);  
- Os eventos adversos mais comuns do medicamento deferiprona são: infecções (febre, dor de garganta, sintomas gripais),  
- dor e inchaço nas articulações, dor abdominal, náusea, vômitos, alteração de apetite, urina escura, elevação de enzimas hepáticas (ALT), diminuição das células brancas do sangue e agranulocitose (reversíveis com a suspensão do tratamento);  
- Os eventos adversos mais comuns do medicamento deferasirox são:  distúrbios gastrointestinais (incluindo náuseas,  
- vômitos, diarreia, dor abdominal, distensão abdominal, constipação, indigestão); elevação da creatinina sérica, erupção cutânea, dores de cabeça; reações menos comuns: tontura, febre, dor de garganta, ansiedade, distúrbios do sono, cansaço, mudança na cor da pele e inchaço de extremidades.  
- Consultas e exames durante o tratamento são necessários.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
23  
- (    ) mesilato de desferroxamina  
- (    ) deferiprona  
- (    ) deferasirox  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
24

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **1         Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Sobrecarga de Ferro contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo EconômicoIndustrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu farmacêutico e médicos das seguintes especialidades: hematologista, nefrologista e cardiologistas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **2        Etapas do processo de elaboração** -->
A proposta inicial de atualização do PCDT da Sobrecarga de ferro foi inicialmente discutida durante a reunião de préescopo, ocorrida em 26 de junho de 2023. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); e Secretaria de Atenção Especializada em Saúde (SAES).  
Posteriormente, o escopo do documento foi discutido na reunião de escopo, ocorrida em 20 de julho de 2023. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS e SAES, representantes de pacientes, de sociedades médicas e especialistas convidados.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **3         Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Sobrecarga de ferro foi apresentada na 123ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 11 de março de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Saúde Indígena (SESAI) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **4         Consulta pública** -->
A Consulta Pública nº 21/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Sobrecarga de Ferro, foi realizada entre os dias 08/05/2025 a 27/05/2025. Foram recebidas 44 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-da-cp-21-2025-pcdt-da-sobrecarga-deferro.</u>  
25

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **5         Busca da evidência e recomendações** -->
Durante o processo de atualização do PCDT da Sobrecarga de Ferro não foram identificadas novas tecnologias passíveis de avaliação para incorporação, apenas a possibilidade de ampliação de uso da deferiprona para pacientes com doença falciforme e sobrecarga de ferro.  
Com o objetivo de atualizar as informações fornecidas neste documento sobre o cuidado de pacientes diagnosticados com sobrecarga de ferro, foram realizadas buscas sistemáticas da literatura para identificação de documentos e estudos para atualização do texto do PCDT. As revisões foram divididas em três grupos principais. A primeira revisão foi realizada com o objetivo de identificar estudos ou documentos nacionais que considerassem a perspectiva ou incluísse pacientes brasileiros na análise. A segunda parte do processo de revisão realizada para atualização do texto do PCDT foi referente à busca e análise de recomendações de diretrizes clínicas com recomendações para sobrecarga de ferro. O último grupo de busca teve como objetivo identificar revisões sistemáticas sobre os medicamentos recomendados neste PCDT – mesilato de desferroxamina, deferiprona e deferasirox – para o cuidado da sobrecarga de ferro. As publicações identificadas por meio dos três grupos de revisões foram utilizadas na composição do texto atualizado do PCDT.  
O documento atual considera as mesmas recomendações da sua versão anterior:  
**Recomendação 1:** O mesilato de desferroxamina é recomendada para o tratamento da sobrecarga de ferro.  
**Recomendação 2:** A deferiprona é recomendada para o tratamento da sobrecarga de ferro.  
**Recomendação 3:** O deferasirox é recomendado para o tratamento da sobrecarga de ferro.  
As recomendações não foram graduadas por já serem preconizadas no PCDT da Sobrecarga de Ferro publicado por meio da Portaria Conjunta SAS-SCTIE/MS n<sup>o</sup> 7, de 23 de fevereiro de 2018.  
As estruturas PICOs para as perguntas de pesquisa consideradas para incorporação dessas tecnologias não foram descritas em versão anterior do PCDT de sobrecarga de ferro.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Estudos e documentos com perspectiva nacional** -->
Foi realizada uma busca abrangente da literatura com o objetivo de identificar documentos que considerem a perspectiva  
nacional, estudos que incluam pacientes brasileiros ou que analisem a situação da doença no Brasil. Para isso, a pergunta de pesquisa utilizada considerando o acrônimo PCC (População, Conceito, Contexto) descrito no **Quadro A** :  
**Quadro A. Pergunta de pesquisa PCC para busca de estudos e documentos com perspectiva nacional sobre sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro|
|---|---|
|**Conceito**|Publicações que abordem o cuidado ou aspectos relacionados à sobrecarga de ferro|
|**Contexto**|Perspectiva brasileira ou pacientes brasileiros|  
Fonte: autoria própria  
As buscas foram conduzidas nas bases Medline (via PubMed), EMBASE e Lilacs (via BVS) em 23/02/2023. Com o objetivo de aumentar a sensibilidade da busca, foram considerados os termos da condição clínica (sobrecarga de ferro), assim como condições clínicas que podem causar a sobrecarga de ferro (hemocromatose, síndrome mielodisplásica, talassemia e doença  
26  
falciforme). Foram também considerados termos relacionados ao Brasil. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). As estratégias de busca para cada base estão descritas no **Quadro B.**  
**Quadro B. Estratégias de busca, de acordo com a base de dados, para identificação de estudos e documentos brasileiros sobre a sobrecarga de ferro**  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
||("Iron Overload"[Mesh]) OR ((("Hemochromatosis"[Mesh] OR (Bronzed<br>Cirrhosis) OR (Bronzed Cirrhoses) OR (Cirrhoses, Bronzed) OR (Cirrhosis,<br>Bronzed) OR (Diabetes, Bronze) OR (Haemochromatosis) OR<br>(Haemochromatoses) OR (Von Recklenhausen-Applebaum Disease) OR<br>(Diseases, Von Recklenhausen-Applebaum) OR (Recklenhausen-Applebaum<br>Disease, Von)OR (Disease, Von Recklenhausen-Applebaum) OR<br>(Recklenhausen-Applebaum Diseases, Von) OR (Von Recklenhausen<br>Applebaum Disease) OR (Von Recklenhausen-Applebaum Diseases) OR<br>(Bronze Diabetes) OR (Iron Storage Disorder) OR (Disorder, Iron Storage) OR<br>(Disorders, Iron Storage) OR (Iron Storage Disorders)OR (Storage Disorder,<br>Iron)OR (Storage Disorders, Iron) OR (Pigmentary Cirrhosis) OR (Cirrhoses,<br>Pigmentary) OR (Cirrhosis, Pigmentary) OR (Pigmentary Cirrhoses) OR<br>(Troisier-Hanot-Chauffard Syndrome) OR (Syndrome, Troisier-Hanot-<br>Chauffard) OR (Syndromes, Troisier-Hanot-Chauffard) OR (Troisier Hanot<br>Chauffard Syndrome) OR (Troisier-Hanot-Chauffard Syndromes) OR<br>(Hemochromatoses) OR (Hemochromatose) OR (Familial||
|Medline (via<br>PubMed)|Hemochromatosis)OR (Familial Hemochromatoses) OR (Hemochromatoses,<br>Familial) OR (Hemochromatosis, Familial) OR (Primary Hemochromatosis)<br>OR (Genetic Hemochromatosis) OR (Genetic Hemochromatoses) OR<br>(Hemochromatoses, Genetic) OR (Hemochromatosis, Genetic)) OR<br>(("Thalassemia"[Mesh]) OR "Anemia, Sickle Cell"[Mesh] OR (Anemias,<br>Sickle Cell) OR (Sickle Cell Anemias) OR (Hemoglobin S Disease) OR<br>(Disease, Hemoglobin S) OR (Hemoglobin S Diseases) OR (Sickle Cell<br>Anemia) OR (Sickle Cell Disorders) OR (Cell Disorder, Sickle) OR (Sickle<br>Cell Disorder) OR (Sickling Disorder Due to Hemoglobin S) OR (HbS<br>Disease) OR (Cell Disorders, Sickle) OR (Sickle Cell Disease) OR (Cell<br>Disease, Sickle) OR (Cell Diseases, Sickle) OR (Sickle Cell Diseases))) OR<br>("Myelodysplastic Syndromes"[Mesh] OR (Myelodysplastic Syndrome) OR<br>(Syndrome, Myelodysplastic) OR (Syndromes, Myelodysplastic) OR<br>(Dysmyelopoietic Syndromes) OR (Dysmyelopoietic Syndrome) OR<br>(Syndrome, Dysmyelopoietic) OR (Syndromes, Dysmyelopoietic) OR<br>(Hematopoetic Myelodysplasia) OR (Myelodysplasia, Hematopoetic) OR<br>(Myelodysplasias, Hematopoetic) OR (Hematopoetic Myelodysplasias))) AND<br>"Brazil"[Mesh]|439|
|EMBASE|('iron overload'/exp OR 'hemochromatosis'/exp OR 'thalassemia'/exp OR<br>'sickle cell anemia'/exp OR 'myelodysplastic syndrome'/exp) AND|335|  
27  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
||('brazil'/exp) AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Lilacs (via BVS)|(("Sobrecarga de Ferro" OR "Iron Overload" OR "Sobrecarga de Hierro" OR<br>"Hemocromatose" OR "Diabetes Bronzeada" OR "Hemochromatosis" OR<br>"Hemocromatosis" OR "Talassemia" OR "Thalassemia" OR "Talasemia" OR<br>"Talassemia delta" OR "delta-Thalassemia" OR "Talasemia delta" OR<br>"Talassemia alfa" OR "Doença da Hemoglobina H" OR "alpha-Thalassemia"<br>OR "Talasemia alfa" OR "Talassemia beta" OR "Anemia de Cooley" OR<br>"Anemia do Mediterrâneo" OR "Anemia Eritroblástica" OR "Doença da<br>Hemoglobina F" OR "Talassemia Maior" OR "Talassemia Menor" OR "beta-<br>Thalassemia" OR "Talasemia beta" OR "Anemia Falciforme" OR "Anemia,<br>Sickle Cell" OR "Anemia de Células Falciformes" OR "Doença Falciforme"<br>OR "Doença da Hemoglobina S" OR "Doença de Células Falciformes" OR<br>"Doenças Falciformes" OR "Doenças de Células Falciformes" OR<br>"Deficiência de GATA2" OR "Deficiência de Células Matadoras Naturais" OR<br>"Deficiência de Células NK" OR "Haploinsuficiência de GATA2" OR<br>"Imunodeficiência Tipo 21" OR "Leucemia Mieloide Aguda e Síndrome<br>Mielodisplásica" OR "Linfedema Primário com Mielodisplasia" OR<br>"Síndrome de Emberger" OR "Síndrome MonoMac" OR "GATA2 Deficiency"<br>OR "Deficiencia GATA2")) AND ("Brasil" OR "Brazil")|405|  
Fonte: autoria própria  
A elegibilidade dos estudos identificados por meio de busca sistemática foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> . Na segunda etapa, realizou-se a leitura de texto completo, mantendo-se documentos que considerem a perspectiva nacional, estudos que incluam pacientes brasileiros ou que analisem e forneçam informações sobre a situação da doença no Brasil. As divergências foram resolvidas por terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tema: Sobrecarga de Ferro;  
- (b) Tipos de estudos: documentos que considerem a perspectiva nacional, estudos que incluam pacientes brasileiros ou  
- que analisem e forneçam informações sobre a situação da doença no Brasil;  
- (c) Idioma: português, inglês e espanhol.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Resultados da busca** -->
Foram identificadas 1.179 publicações. Após a exclusão das duplicatas (n = 65) e triagem pela leitura de títulos e resumos, 54 publicações foram selecionadas para a leitura do texto completo ( **Figura A** ). Seis estudos foram excluídos por leitura de texto completo. Os estudos e os motivos da exclusão são descritos no **Quadro C.** No total, foram incluídas 42 publicações, descritas no **Quadro D.**  
28  
**Figura A. Fluxograma de seleção dos estudos ou documentos brasileiros incluídos sobre a sobrecarga de ferro**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Bases de dados (n = 1179)  Referências removidas antes do<br>PubMed (n = 439)<br>processo de seleção:<br>Embase (n = 335)<br>Duplicatas (n = 65)<br>LILACS (n = 405)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 1060)<br>(n = 1114)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 54)  (n = 5)<br>Referências  avaliadas por  texto<br>Referências excluídas: (n=6)<br>completo (n = 49)<br>Estudos incluídos na revisão<br>(n = 42)<br>Relatos dos estudos incluídos<br>(n = 42)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro C. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Arruda SF, Ramos LV, Barbosa JL de A, Hankins NAC, Rodrigues PAM, Cunha M de SB da. The|Não aborda condição|
|Action of JAK/STAT3 and BMP/HJV/SMAD Signaling Pathways on Hepcidin Suppression by|clínica de interesse|  
29  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Tucum-do-Cerrado in a Normal and Iron-Enriched Diets. Nutrients. 2020;12(5).||
|Gomes KB, Carvalho MG, Coelho FF, Rodrigues IF, Soares AL, Guimarães DA, et al. Lack of<br>association of C282Y and H63D mutations in the hemochromatosis (HFE) gene with diabetes<br>mellitus type 2 in a case-control study of women in Brazil. Genet Mol Res. 2009;8(4):1285–91.|Não aborda população<br>de interesse|
|Alvarenga AM, Silva NK da, Cançado RD, Carvalho LEMR de, Santos PCJL. Brazilian family<br>with hyperferritinemia-cataract syndrome: case report. Vol. 20, Einstein. 2022. p. eRC0076–<br>eRC0076.|Não aborda população<br>de interesse|
|Petroni RC, Rosa SEA da, Carvalho FP de, Santana RAF, Hyppolito JE, Nascimento CMDB, et al.<br>Ferritin light chain gene mutations in two Brazilian families with hereditary hyperferritinemia-<br>cataract syndrome. Vol. 15, Einstein. 2017. p. 492–5.|Não aborda população<br>de interesse|
|Leão GDR, Paiva A, Fernandes ALAC, Gil EA, Vasconcelos RC, Sales VSF, et al. Mutation<br>analysis and allele frequencies of HFE Gene C282Y, H63D and S65D in patients with<br>hyperferritinemia and healthy controls from a city in Northeastern Brazil. Blood [Internet].<br>2017;130.|Não aborda população<br>de interesse|
|Terada CT, Santos PCJL, Cançado RD, Rostelato S, Lopreato FR, Chiattone CS, et al. Iron<br>deficiency and frequency of HFE C282Y gene mutation in Brazilian blood donors. Transfus Med.<br>2009;19(5):245–51.|Não aborda população<br>de interesse|
|Campos WN, Massaro JD, Martinelli ALC, Mendes-Junior CT, Donadi EA. Genetic structure of<br>coding region of the HFE gene: SNPS, haplotypes and suggested allele nomenclature. Hum<br>Immunol [Internet]. 2013;74:143.<br>Fonte: autoria própria|Não aborda população<br>de interesse|  
**Quadro D. Lista de estudos ou documentos com perspectiva nacional incluídos**  
**Estudo** Ferreira ACS, Oliveira VC, Caxito FA, Gomes KB, Castro AM, Pardini VC. Prevalence of C282Y and H63D mutations in the HFE gene of Brazilian individuals with clinical suspicion of hereditary hemochromatosis TT - Prevalência das mutações C282Y e H63D no gene HFE em indivíduos brasileiros com suspeita clínica de hemocromatose h. Rev bras hematol hemoter [Internet]. 2008;30(5):379–83. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1516- <u>84842008000500010</u> Santos PCJL, Cançado RD, Terada CT, Guerra-Shinohara EM. Alterações moleculares associadas à hemocromatose hereditária TT - Molecular changes associated with hereditary hemochromatosis. Rev bras hematol hemoter [Internet]. 2009;31(3):192–202. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1516-84842009000300016 Alves LNR, Santos EVW, Stur E, Silva Conforti AMA, Louro ID. Molecular epidemiology of HFE gene polymorphic variants (C282Y, H63D and S65C) in the population of Espírito Santo, Brazil. Genet Mol Res. 2016;15(2). Jin N, Fernandes JL, Firmin D, Azevedo CF, Da Silveira JS, Mathew GL, et al. Free-breathing myocardial T2∗ mapping using GRE-EPI and MOCO for myocardial and hepatic iron overload assessment: A multi-centre study. J Cardiovasc Magn Reson [Internet]. 2016; 18.  Available at: <u>https://www.embase.com/search/results?subaction=viewrecord&id=L72183272&from=export</u> Mantovani LF, Santos FPS, Perini GF, Nascimento CMB, Silva LP, Wroclawski CK, et al. Hepatic and cardiac and iron overload detected by T2* magnetic resonance (MRI) in patients with myelodisplastic syndrome: A cross-sectional study.  
30  
**Estudo** Leuk Res. 2019;76:53–7. Angulo IL, Covas DT, Carneiro AA, Baffa O, Junior JE, Vilela G. Determination of iron-overload in thalassemia by hepatic MRI and ferritin TT - Determinação da sobrecarga de ferro na talassemia pela IRM hepática e ferritina. Rev bras hematol hemoter. 2008;30(6):449–52. Koppe TB, Vairo F, Doneda D, Netto CB, Schwartz ID. Does hyperferritinemia reflect iron overload in Gaucher disease? Mol Genet Metab. 2014;111(2):S62–3. Torres FR, Souza-Neiras WC, D’Almeida Couto AA, D’Almeida Couto VSC, Cavasini CE, Rossit ARB, et al. Frequency of the HFE C282Y and H63D polymorphisms in Brazilian malaria patients and blood donors from the Amazon region. Genet mol res [Internet]. 2008;7(1):60–4. Available at: http://www.funpecrp.com.br/gmr/year2008/vol7-1//pdf/gmr408.pdf Wen F, Rock A, Salomon-Andonie J, Kurban G, Niu X, Wang S, et al. Genome Wide Association Analysis of Iron Overload in the Trans-Omics for Precision Medicine (TOPMed) Sickle Cell Disease Cohorts. Blood. 2020;136:52. Leão GDR, Freire JM, Cunha Fernandes ALA, Moura de Oliveira TM, Leão ND, Gil EA, et al. Analysis of HFE genes C282Y, H63D, and S65D in patients with hyperferritinemia from northeastern Brazil. J Clin Lab Anal. 2014;28(3):178–85. Santos AF, Baldanzi G, Leonart MSS, Nascimento AJ. Protective action of deferiprone and deferoxamine in erythrocytes isolated from patients with B-thalassemias TT - Ação protetora de deferiprona e desferoxamina nos eritrócitos isolados de pacientes com B-talassemias. Rev bras hematol hemoter [Internet]. 2009;31(6). Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1516-84842009000600013&lng=pt&nrm=iso&tlng=en SUS CN de I de T no. Protocolo clínico e diretrizes terapêuticas: sobrecarga de ferro TT - Clinical protocol and therapeutic guidelines: iron overload [Internet]. 2018. Available at: http://conitec.gov.br/images/Relatorios/2018/Relatorio_PCDT_SobrecargaFerro.pdf Santos PCJ de L. Hemocromatose hereditária: associação entre as mutações no gene HFE e o estado de ferro em doadores de sangue e pesquisa de mutações nos genes HFE, HJV, HAMP, TFR2 e SLC40A1 em pacientes com sobrecarga de ferro primária TT - Hereditary hemochromatosis: r [Internet]. 2010. p. 120. Available at: http://www.teses.usp.br/teses/disponiveis/9/9136/tde-04022011-110402/publico/PauloSantos.pdf Martinelli AL, Filho R, Cruz S, Franco R, Tavella M, Secaf M, et al. Hereditary hemochromatosis in a Brazilian university hospital in São Paulo State (1990-2000). Genet mol res [Internet]. 2005;4(1):31–8. Available at: http://funpecrp.com.br/gmr/year2005/vol1-4/gmr0092_full_text.htm Campos WN, Massaro JD, Martinelli ALC, Halliwell JA, Marsh SGE, Mendes-Junior CT, et al. HFE gene polymorphism defined by sequence-based typing of the Brazilian population and a standardized nomenclature for HFE allele sequences. HLA. 2017;90(4):238–42. Villani KJ, Viana GC, Caravalho GR de, Guideline AT, Corrêa JO do A, de Mesquita HL. Hemocromatose hereditária relacionada ao gene HFE TT - Hereditary hemochromatosis HFE gene related. Rev Interdiscip Estud exp anim hum. 2010;2(1):14–21. Verissimo MP de A, Loggetto SR, Fabron Junior A, Baldanzi GR, Hamerschlak N, Fernandes JL, et al. Brazilian Thalassemia Association protocol for iron chelation therapy in patients under regular transfusion. Rev bras hematol hemoter [Internet]. 2013;35(6):428–34.  Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1516-84842013000600428 Felix De Souza G, Cavalcante Barbosa M, Ellen De Jesus Santos T, Maria De Jesus Ponte Carvalho T, Mendes De Freitas R, Ricardo Alves Martins M, et al. Increased parameters of oxidative stress and its relation to transfusional iron overload in  
31  
**Estudo** patients with myelodysplastic syndromes. Leuk Res [Internet]. 2013;37:S113–S113. Available at: https://www.embase.com/search/results?subaction=viewrecord&id=L71832936&from=export Santos PCJL, Cançado RD, Terada CT, Rostelato S, Gonzales I, Hirata RDC, et al. HFE gene mutations and iron status of Brazilian blood donors. Braz j med biol res [Internet]. 2010;43(1):107–14. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0100-879X2010000100015 Meneses FGA, Schnabel B, Silva IDCG, Alberto FL, Toma L, Nader HB, et al. Identification of the mutations associated with hereditary hyperferritinemia cataract syndrome and hemochromatosis in a Brazilian family. Vol. 79, Clinical genetics. 2011. p. 189–92. Martins JM. Considerations on the food fortification policy in Brazil. Rev bras hematol hemoter [Internet]. 2011;33(2):158– 63. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S151684842011000200017&lng=en&nrm=iso&tlng=en Bittencourt PL, Marin MLC, Couto CA, Cançado ELR, Carrilho FJ, Goldberg AC. Analysis of HFE and non-HFE gene mutations in Brazilian patients with hemochromatosis. Clinics [Internet]. 2009;64(9):837–41. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1807-59322009000900003 Manzur F, Cancado R, Watman N, Lobo C, Chona Z, Traina F, et al. Assessment of liver and cardiac iron overload using MRI in patients with chronic anemias in Latin American countries: Results from ASIMILA study. Eur J Heart Fail. 2018;20:55. Santos PCJL, Cançado RD, Pereira AC, Schettert IT, Soares RAG, Pagliusi RA, et al. Hereditary hemochromatosis: mutations in genes involved in iron homeostasis in Brazilian patients. Blood Cells Mol Dis. 2011;46(4):302–7. Perícole F V, Alves MAVR, Saad STO, Costa FF. Hemochromatosis (HFE) gene mutations in Brazilian chronic hemodialysis patients. Braz j med biol res [Internet]. 2005;38(9):1321–4. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0100-879X2005000900005  
Barbosa LC, Miranda-Vilela AL, Hiragi C de O, Ribeiro IF, Daldegan MB, Grisolia CK, et al. Haptoglobin and myeloperoxidase (- G463A) gene polymorphisms in Brazilian sickle cell patients with and without secondary iron overload. Blood Cells Mol Dis. 2014;52(2):95–107. Santos PCJL, Pereira AC, Cançado RD, Schettert IT, Sobreira TJP, Oliveira PSL, et al. HFE gene mutations in patients with primary iron overload: is there a significant improvement in molecular diagnosis yield with HFE sequencing? Blood Cells Mol Dis. 2010;45(4):302–7. Krindges SF, Flores JL, Lul RM. Lesões hepáticas associadas à hemocromatose hereditária TT - Liver lesions associated with hereditary hemochromatosis. Rev Assoc Méd Rio Gd do Sul [Internet]. 2021;65(2):1022105. Available at: https://fiadmin.bvsalud.org/document/view/br5e2 Santos PCJL, Cançado RD, Pereira AC, Chiattone CS, Krieger JE, Guerra-Shinohara EM. HJV hemochromatosis, iron overload, and hypogonadism in a Brazilian man: treatment with phlebotomy and deferasirox. Acta Haematol. 2010;124(4):204–5.  
Martinelli AL, Zago MA, Roselino AM, Filho AB, Villanova MG, Secaf M, et al. Porphyria cutanea tarda in Brazilian patients: association with hemochromatosis C282Y mutation and hepatitis C virus infection. Am J Gastroenterol. 2000;95(12):3516–21.  
Ribeiro TF, Rios JO, Domingos CRB. DIFFERENCES IN THE FREQUENCY OF POLYMORPHISMS IN THE HFE GENE (H63D AND C282Y) IN A POPULATION GROUP FROM NORTHWEST SÃO PAULO, BRAZIL. Hematol Transfus Cell  
32  
**Estudo**  
Ther. 2022;44:S2–S2.  
Barbosa KVBD, de Souza AFM, Chebli JMF, Proietti FA, Meirelles RSP, de Souza JL. Hereditary hemochromatosis: population screening based on phenotype in Brazilian blood donors. J Clin Gastroenterol. 2005;39(5):430–4. de Lima Santos PCJ, Pereira AC, Cançado RD, Schettert IT, Hirata RDC, Hirata MH, et al. Hemojuvelin and hepcidin genes sequencing in Brazilian patients with primary iron overload. Genet Test Mol Biomarkers. 2010;14(6):803–6. Herkenhoff ME, Pitlovanciv AK, Remualdo VR. Prevalence of C282Y and H63D mutations in the HFEgene in patients from São Paulo and Southern Brazil TT - Prevalência das mutações C282Y e H63D no gene HFEem pacientes de São Paulo e do Sul do Brasil. J bras patol med lab [Internet]. 2016;52(1):21–4. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S1676-24442016000100021 Oliveira VC, Caxito FA, Gomes KB, Castro AM, Pardini VC, Ferreira ACS. Frequency of the S65C mutation in the hemochromatosis gene in Brazil. Genet Mol Res. 2009;8(3):794–8. VIEIRA G de A, AMARAL AC de C, CARVALHO FILHO RJ de, SOUZA AL da S, MEDINA-PESTANA JO, FERRAZ MLG. Alterações hepáticas em transplantados renais do maior centro de transplante do Brasil TT - Hepatic alterations in kidney transplant recipients from the largest kidney transplant center in brazil. Arq gastroenterol [Internet]. 2022;59(1):65– 70. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0004-28032022000100065 Bittencourt PL, Palácios SA, Couto CA, Cançado ELR, Carrilho FJ, Laudanna AA, et al. Analysis of HLA-A antigens and C282Y and H63D mutations of the HFE gene in Brazilian patients with hemochromatosis. Braz j med biol res [Internet]. 2002;35(3):329–35. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0100-879X2002000300007 Fonseca PFS, Cançado RD, Uellendahl Lopes MM, Correia E, Lescano MA, Santos PCJL. HAMP Gene Mutation Associated with Juvenile Hemochromatosis in Brazilian Patients. Acta Haematol. 2016;135(4):228–31. Agostinho MF, Arruda VR, Basseres DS, Bordin S, Soares MC, Menezes RC, et al. Mutation analysis of the HFE gene in Brazilian populations. Blood Cells Mol Dis. 1999;25(5):324–7.  
Martins JM. Universal iron fortification of foods: the view of a hematologist. Rev bras hematol hemoter [Internet]. 2012;34(6):459–63. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S151684842012000600017&lng=en&nrm=iso&tlng=en  
Pereira AC, Mota GF, Krieger JE. Hemochromatosis gene variants in three different ethnic populations: effects of admixture for screening programs. Hum Biol. 2001;73(1):145–51.  
Kelly S, Belisário AR, Werneck Rodrigues DO, Carneiro-Proietti ABF, Gonçalez TT, Loureiro P, et al. Blood utilization and characteristics of patients treated with chronic transfusion therapy in a large cohort of Brazilian patients with sickle cell disease. Transfusion. 2020;60(8):1713–22.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes Clínicas** -->
Para identificar as recomendações de diretrizes clínicas para o cuidado da sobrecarga de ferro, foram realizadas buscas sistemáticas da literatura tanto para sobrecarga de ferro como também para possíveis causas-base da doença, como hemocromatose, doença falciforme, síndrome mielodisplásica e talassemia.  
As buscas foram conduzidas nas bases Medline (via PubMed) e EMBASE em 23/02/2023. Para todas as buscas foram considerados termos da condição clínica e termos específicos para identificação de diretrizes clínicas. Com o intuito de utilizar apenas documentos recentes e atualizados, foi utilizado filtro de data de publicação entre os anos de 2017 e 2023.  
A elegibilidade dos estudos identificados por meio de busca sistemática foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> . Na segunda etapa, realizou-se  
33  
a leitura de texto completo, mantendo-se diretrizes clínicas com recomendações para o cuidado da sobrecarga de ferro, independente da causa base. As divergências foram resolvidas por terceiro revisor  
Foram considerados como critérios de elegibilidade:  
a) Tema: Deficiência de biotinidase com recomendações para o cuidado da sobrecarga de ferro  
- (b) Tipos de estudos: Diretrizes clínicas.  
- (c) Idioma: português, inglês e espanhol.  
São descritos abaixo estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR (população, intervenção,  
comparação, atributos das diretrizes clínicas e recomendação), estratégia utilizada, bem como os resultados para cada uma das buscas por diretrizes clínicas.  
Sobrecarga de ferro  
A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR para identificação de diretrizes clínicas sobre sobrecarga de ferro está descrita no **Quadro E.**  
**Quadro E. Pergunta PICAR (população, intervenção, comparação, atributos das diretrizes clínicas e recomendação) para identificação de diretrizes clínicas sobre sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro associada ou não a outras condições|
|---|---|
|**Intervenção**|Qualquer intervenção|
|**Comparador**|Qualquer comparador|
|**Atributos das diretrizes**|Diretrizes clínicas publicadas a partir de 2017, disponíveis em inglês, espanhol ou português,|
||desde que incluíssem recomendações sobre o cuidado da sobrecarga de ferro|
|**Recomendações**|Recomendações sobre o cuidado da sobrecarga de ferro associada ou não a outras condições|  
Fonte: autoria própria  
Com base na busca de pesquisa acima, foi elaborada a estratégia de busca descrita no **Quadro F.**  
34  
**Quadro F. Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre a sobrecarga de ferro**  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline (via PubMed)|("Iron Overload"[Mesh]) AND (("Guideline" [Publication Type] OR<br>"Guidelines as Topic"[Mesh] OR "Practice Guideline" [Publication Type]<br>OR "Health Planning Guidelines"[Mesh]OR Guidelines as Topics OR<br>Clinical Practice Guideline OR "Clinical Protocols"[Mesh] OR Protocol,<br>Clinical OR Clinical Protocol OR Protocols, Clinical OR Treatment<br>Protocols OR Treatment Protocol OR Protocols, Treatment OR Clinical<br>Research Protocol OR Research Protocols, Clinical OR Protocols, Clinical<br>Research OR Research Protocol, Clinical OR Clinical Research Protocols<br>OR Protocol, Clinical Research OR "Consensus"[Mesh] OR "Consensus<br>Development Conference, NIH" [Publication Type] OR "Consensus<br>Development Conference" [Publication Type] OR "Consensus Development<br>Conferences, NIH as Topic"[Mesh] OR "Consensus Development<br>Conferences as Topic"[Mesh] OR "Standard of Care"[Mesh] OR Care<br>Standard OR Care Standards OR Standards of Care) Filters: from 2017 -<br>2023|68|
|EMBASE|'iron overload'/exp AND ('practice guideline'/exp OR (clinical AND practice<br>AND guidelines) OR guidelines OR (guidelines AND as AND topic) OR<br>(practice AND guidelines) OR (practice AND guidelines AND as AND<br>topic) OR 'clinical protocol'/exp OR 'consensus'/exp) AND [embase]/lim<br>NOT ([embase]/lim AND [medline]/lim) AND (2017:py OR 2018:py OR<br>2019:py OR 2020:py OR 2021:py OR 2022:py OR 2023:py)|165|  
Foram identificadas 233 publicações. Após a exclusão das duplicatas (n = 69) e triagem pela leitura de títulos e resumos, 9 publicações foram selecionadas para a leitura do texto completo. Ao todo, sete diretrizes clínicas com recomendações para o cuidado da sobrecarga de ferro incluídas. A **Figura B** resume os resultados do processo de elegibilidade e o **Quadro G** apresenta as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
35  
**Figura B. Fluxograma de seleção dos estudos incluídos sobre diretrizes clínicas sobre sobrecarga de ferro.**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Referências removidas antes do<br>Bases de dados (n = 233)<br>processo de seleção:<br>PubMed (n = 68)<br>Duplicatas (n = 69)<br>Embase (n = 165)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 155)<br>(n = 164)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 9)  (n = 0)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n=2)<br>(n = 9)<br>Estudos incluídos na revisão<br>(n = 7)<br>Relatos dos estudos incluídos<br>(n = 7)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro G. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Lal A, Sheth S, Gilbert S, Kwiatkowski JL. Thalassemia management checklists: Quick||
|reference guides to reduce disparities in the care of patients with transfusion-dependent|Não é uma diretriz|
|thalassemia. Blood [Internet]. 2018;132.||
|Leitch H, Ezzat H, Merkely H, Buckstein R, Zhu N, Nevill T, et al. MDS iron road: An|Não é uma diretriz|  
36  
internet-based algorithm for the diagnosis, workup and management of iron overload (IOL) in patients with myelodysplastic syndromes (MDS) from the canadian consortium on MDS (CCMDS). HemaSphere [Internet]. 2020;4:373–4.  
Hemocromatose  
A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR para identificação de diretrizes clínicas sobre hemocromatose está descrita no **Quadro H.**  
**Quadro H. Pergunta PICAR (população, intervenção, comparação, atributos das diretrizes clínicas e recomendação) para identificação de diretrizes clínicas sobre hemocromatose**  
|**População**|Pacientes com sobrecarga de ferro devido à hemocromatose hereditária|
|---|---|
|**Intervenção**|Qualquer intervenção|
|**Comparador**|Qualquer comparador|
|**Atributos das diretrizes**|Diretrizes clínicas publicadas a partir de 2017, disponíveis em inglês, espanhol ou português,<br>desde que incluíssem recomendações sobre o cuidado da sobrecarga de ferro|
|**Recomendações**|Recomendações sobre o cuidado da sobrecarga de ferro devido à hemocromatose hereditária|  
Fonte: autoria própria  
Com base na busca de pesquisa acima, foi elaborada a estratégia de busca descrita no **Quadro I.**  
**Quadro I. Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre hemocromatose.**  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline (via PubMed)|((("Hemochromatosis"[Mesh] OR (Bronzed Cirrhosis) OR (Bronzed<br>Cirrhoses) OR (Cirrhoses, Bronzed) OR (Cirrhosis, Bronzed) OR (Diabetes,<br>Bronze) OR (Haemochromatosis) OR (Haemochromatoses) OR (Von<br>Recklenhausen-Applebaum Disease) OR (Diseases, Von Recklenhausen-<br>Applebaum) OR (Recklenhausen-Applebaum Disease, Von)OR (Disease, Von<br>Recklenhausen-Applebaum)OR (Recklenhausen-Applebaum Diseases,<br>Von)OR (Von Recklenhausen Applebaum Disease)OR (Von Recklenhausen-<br>Applebaum Diseases)OR (Bronze Diabetes)OR (Iron Storage Disorder)OR<br>(Disorder, Iron Storage)OR (Disorders, Iron Storage)OR (Iron Storage<br>Disorders)OR (Storage Disorder, Iron)OR (Storage Disorders, Iron)OR<br>(Pigmentary Cirrhosis)OR (Cirrhoses, Pigmentary)OR (Cirrhosis,<br>Pigmentary)OR (Pigmentary Cirrhoses)OR (Troisier-Hanot-Chauffard<br>Syndrome)OR (Syndrome, Troisier-Hanot-Chauffard)OR (Syndromes,<br>Troisier-Hanot-Chauffard)OR (Troisier Hanot Chauffard Syndrome)OR<br>(Troisier-Hanot-Chauffard Syndromes)OR (Hemochromatoses)OR<br>(Hemochromatose)OR (Familial Hemochromatosis)OR (Familial<br>Hemochromatoses)OR (Hemochromatoses, Familial)OR (Hemochromatosis,<br>Familial)OR (Primary Hemochromatosis)OR (Genetic Hemochromatosis)OR<br>(Genetic Hemochromatoses)OR (Hemochromatoses, Genetic)OR<br>(Hemochromatosis, Genetic)) AND (("Guideline" [Publication Type] OR|49|  
37  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
||"Guidelines as Topic"[Mesh] OR "Practice Guideline" [Publication Type] OR<br>"Health Planning Guidelines"[Mesh]OR Guidelines as Topics OR Clinical<br>Practice Guideline OR "Clinical Protocols"[Mesh] OR Protocol, Clinical OR<br>Clinical Protocol OR Protocols, Clinical OR Treatment Protocols OR<br>Treatment Protocol OR Protocols, Treatment OR Clinical Research Protocol<br>OR Research Protocols, Clinical OR Protocols, Clinical Research OR<br>Research Protocol, Clinical OR Clinical Research Protocols OR Protocol,<br>Clinical Research OR "Consensus"[Mesh] OR "Consensus Development<br>Conference, NIH" [Publication Type] OR "Consensus Development<br>Conference" [Publication Type] OR "Consensus Development Conferences,<br>NIH as Topic"[Mesh] OR "Consensus Development Conferences as<br>Topic"[Mesh] OR "Standard of Care"[Mesh] OR Care Standard OR Care<br>Standards OR Standards of Care) Filters: from 2017 - 2023||
|EMBASE|'hemochromatosis'/exp AND ('practice guideline'/exp OR (clinical AND<br>practice AND guidelines) OR guidelines OR (guidelines AND as AND topic)<br>OR (practice AND guidelines) OR (practice AND guidelines AND as AND<br>topic) OR 'clinical protocol'/exp OR 'consensus'/exp) AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim) AND (2017:py OR 2018:py OR 2019:py<br>OR 2020:py OR 2021:py OR 2022:py OR 2023:py)|94|  
Foram identificadas 143 publicações. Após a exclusão das duplicatas (n = 4) e triagem pela leitura de títulos e resumos, 9 publicações foram selecionadas para a leitura do texto completo. Ao todo, três diretrizes clínicas sobre sobrecarga de ferro devido à hemocromatose hereditária foram incluídas. A **Figura C** resume os resultados do processo de elegibilidade e o **Quadro J** apresenta as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
38  
**Figura C. Fluxograma de seleção dos estudos incluídos sobre diretrizes clínicas sobre sobrecarga de ferro devido à hemocromatose**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Bases de dados (n = 143)  Referências removidas antes do<br>PubMed (n = 49)  processo de seleção:<br>Embase (n = 94)  Duplicatas (n = 4)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 130)<br>(n = 139)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 9)  (n = 0)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n=7)<br>(n = 9)<br>Estudos incluídos na revisão<br>(n = 2)<br>Relatos dos estudos incluídos<br>(n = 2)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro J. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Zhou Y, Procop GW, Riley JD. A Novel Approach to Improving Utilization of Laboratory<br>Testing. Arch Pathol Lab Med. fevereiro de 2018;142(2):243–7.|Não é uma diretriz|
|Traynor BP, Hazel K, O’Donnell J, Farrell RJ, Smyth C, Kelly O. Imaging in hereditary<br>haemochromatosis: Establishing a local guideline for cardiac and hepatic surveillance. Heart|Não é uma diretriz|  
39  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|[Internet]. 2018;104:A9.||
|Kowdley K V, Brown KE, Ahn J, Sundaram V. ACG Clinical Guideline: Hereditary<br>Hemochromatosis. Clin Liver Dis [Internet]. 2020;16(5):177.|Não é uma diretriz|
|Adams P, Altes A, Brissot P, Butzeck B, Cabantchik I, Cançado R, et al. Therapeutic<br>recommendations in HFE hemochromatosis for p.Cys282Tyr (C282Y/C282Y) homozygous<br>genotype. Vol. 12, Hepatology international. United States; 2018. p. 83-6.|Não é uma diretriz|
|White D, Brissot P, Butzeck B, Don H, Evans R, Santos P, et al. Haemochromatosis<br>international-an alliance of hereditary haemochromatosis groups around the world. Am J<br>Hematol [Internet]. 2017;92(8):E258|Não é uma diretriz|
|Liu Yin J, Cussen C, Harrington C, Foskett P, Raja K, Ala A. Guideline Review: European||
|Association for the Study of Liver (EASL) Clinical Practice Guidelines on Haemochromatosis. J<br>Clin Exp Hepatol [Internet]. 2022.|Não é uma diretriz|
|Zhang W, Huang J, Ou XJ, You H, Jia JD. [Hemochromatosis International: therapeutic<br>recommendations in HFE hemochromatosis for p.Cys282Tyr homozygous genotype]. Zhonghua<br>gan zang bing za zhi = Zhonghua ganzangbing zazhi = Chinese J Hepatol. dezembro de<br>2019;27(12):980–1.|Idioma|

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Doença falciforme** -->
A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR para identificação de diretrizes clínicas sobre doença falciforme com recomendações para o cuidado da sobrecarga de ferro está descrita no **Quadro K.**  
**Quadro K. Pergunta PICAR (população, intervenção, comparação, atributos das diretrizes clínicas e recomendação) para identificação de diretrizes clínicas sobre doença falciforme com recomendações para sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro transfusional na doença falciforme|
|---|---|
|**Intervenção**|Qualquer intervenção|
|**Comparador**|Qualquer comparador|
|**Atributos das**|Diretrizes clínicas publicadas a partir de 2017, disponíveis em inglês, espanhol|
|**diretrizes**|ou português, desde que incluíssem recomendações sobre o cuidado da<br>sobrecarga de ferro|
|**Recomendações**|Recomendações sobre o cuidado da sobrecarga de ferro secundária à doença<br>falciforme|  
Fonte: autoria própria  
Com base na busca de pesquisa acima, foi elaborada a estratégia de busca descrita no **Quadro L.**  
40  
**Quadro L. Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre doença falciforme com recomendações para o cuidado da sobrecarga de ferro.**  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
||"Anemia, Sickle Cell"[Mesh] OR (Anemias, Sickle Cell) OR (Sickle Cell<br>Anemias) OR (Hemoglobin S Disease) OR (Disease, Hemoglobin S) OR<br>(Hemoglobin S Diseases) OR (Sickle Cell Anemia) OR (Sickle Cell Disorders)<br>OR (Cell Disorder, Sickle) OR (Sickle Cell Disorder) OR (Sickling Disorder Due<br>to Hemoglobin S) OR (HbS Disease) AND (("Guideline" [Publication Type] OR<br>"Guidelines as Topic"[Mesh] OR "Practice Guideline" [Publication Type] OR<br>"Health Planning Guidelines"[Mesh]OR Guidelines as Topics OR Clinical<br>Practice Guideline OR "Clinical Protocols"[Mesh] OR Protocol, Clinical OR||
|Medline (via<br>PubMed)|Clinical Protocol OR Protocols, Clinical OR Treatment Protocols OR Treatment<br>Protocol OR Protocols, Treatment OR Clinical Research Protocol OR Research<br>Protocols, Clinical OR Protocols, Clinical Research OR Research Protocol,<br>Clinical OR Clinical Research Protocols OR Protocol, Clinical Research OR<br>"Consensus"[Mesh] OR "Consensus Development Conference, NIH" [Publication<br>Type] OR "Consensus Development Conference" [Publication Type] OR<br>"Consensus Development Conferences, NIH as Topic"[Mesh] OR "Consensus<br>Development Conferences as Topic"[Mesh] OR "Standard of Care"[Mesh] OR<br>Care Standard OR Care Standards OR Standards of Care) Filters: from 2017 -<br>2023|497|
|EMBASE|'sickle cell anemia'/exp AND ('practice guideline'/exp OR (clinical AND practice<br>AND guidelines) OR guidelines OR (guidelines AND as AND topic) OR<br>(practice AND guidelines) OR (practice AND guidelines AND as AND topic) OR<br>'clinical protocol'/exp OR 'consensus'/exp) AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim) AND (2017:py OR 2018:py OR 2019:py OR<br>2020:py OR 2021:py OR 2022:py OR 2023:py)|763|  
Foram identificadas 1.260 publicações. Após a exclusão das duplicatas (n = 120) e triagem pela leitura de títulos e resumos, 29 publicações foram selecionadas para a leitura do texto completo. Ao todo, seis diretrizes clínicas sobre doença falciforme com recomendações para o cuidado da sobrecarga de ferro incluídas. A **Figura D** resume os resultados do processo de elegibilidade e o **Quadro M** apresenta as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
41  
**Figura D. Fluxograma de seleção dos estudos incluídos sobre diretrizes clínicas sobre doença falciforme com recomendações para o cuidado da sobrecarga de ferro.**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Bases de dados (n = 1.260)  Referências removidas antes do<br>PubMed (n = 497)  processo de seleção:<br>Embase (n = 763)  Duplicatas (n = 120)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 1.112)<br>(n = 1.140)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 28)  (n = 1)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n = 21)<br>(n = 27)<br>Estudos incluídos na revisão<br>(n = 6)<br>Relatos dos estudos incluídos<br>(n = 6)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro M. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Liem RI, Lanzkron S, D Coates T, DeCastro L, Desai AA, Ataga KI, et al. American Society|Não possui|
|of Hematology 2019 guidelines for sickle cell disease: cardiopulmonary and kidney disease.|recomendações sobre|
|Blood Adv. dezembro de 2019;3(23):3867–97.|sobrecarga de ferro|
|Oteng-Ntim E, Pavord S, Howard R, Robinson S, Oakley L, Mackillop L, et al. Management|Não possui|
|of sickle cell disease in pregnancy. A British Society for Haematology Guideline. Vol. 194,|recomendações sobre|  
42  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|British journal of haematology. England; 2021. p. 980–95.|sobrecarga de ferro|
|2018 Annual Meeting of the American Society of Hematology, ASH 2018. Blood [Internet].<br>2018;132.|Tipo de publicação:<br>conference review|
|Lobitz S, Cario H. Recommendations for action according to the sickle cell disease guideline:||
|Pain crises in patients with sickle cell disease. Monatsschr Kinderheilkd [Internet].<br>2022;170(11):1034–7.|Idioma|
|Izcovich A, Cuker A, Kunkle R, Neumann I, Panepinto J, Pai M, et al. A user guide to the<br>American Society of Hematology clinical practice guidelines. Blood Adv. maio de|Não possui<br>recomendações sobre|
|2020;4(9):2095–110.|sobrecarga de ferro|
|Witt V. Impact of ASFA Guidelines 2019 on paediatric apheresis. Transfus Med Hemotherapy<br>[Internet]. 2020;47(SUPPL 1):18|Não é uma diretriz|
|Kanter J, Liem RI, Bernaudin F, Bolaños-Meade J, Fitzhugh CD, Hankins JS, et al. American|Não possui|
|Society of Hematology 2021 guidelines for sickle cell disease: stem cell transplantation. Blood<br>Adv. setembro de 2021;5(18):3668–89.|recomendações sobre<br>sobrecarga de ferro|
|Compernolle V, Chou S, Tanael S, Savage W, Howard J, Josephson C, et al. Red cell<br>specifications for patients with hemoglobinopathies: A systematic review and guideline. Vox<br>Sang [Internet]. 2017;112:266|Não é uma diretriz|
|Walker I, Trompeter S, Howard J, Williams A, Bell R, Bingham R, et al. Guideline on the<br>peri-operative management of patients with sickle cell disease: Guideline from the Association|Não possui<br>recomendações sobre|
|of Anaesthetists. Anaesthesia. junho de 2021;76(6):805–17.|sobrecarga de ferro|
|Dampier C, Palermo TM, Darbari DS, Hassell K, Smith W, Zempsky W. AAPT Diagnostic<br>Criteria for Chronic Sickle Cell Disease Pain. J pain. maio de 2017;18(5):490–8.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Casale M, Perrotta S. The Italian approach to sickle cell disease in childhood: Guidelines and<br>national initiatives. Ital J Pediatr [Internet]. 2019;45.|Não é uma diretriz|
|Compernolle V, Chou ST, Tanael S, Savage W, Howard J, Josephson CD, et al. Red blood|Não possui|
|cell specifications for patients with hemoglobinopathies: a systematic review and guideline.<br>Transfusion. junho de 2018;58(6):1555–66.|recomendações sobre<br>sobrecarga de ferro|
|Valentine SL, Bembea MM, Muszynski JA, Cholette JM, Doctor A, Spinella PC, et al.||
|Consensus Recommendations for RBC Transfusion Practice in Critically Ill Children From the|Não possui|
|Pediatric Critical Care Transfusion and Anemia Expertise Initiative. Pediatr Crit care Med a J<br>Soc Crit Care Med World Fed Pediatr Intensive Crit Care Soc. setembro de 2018;19(9):884–|recomendações sobre<br>sobrecarga de ferro|
|98.||
|Whitmore R, Mugridge H. NHS Blood and Transplant (NHSBT) management of Ro (Dce)<br>blood for patients with sickle cell disease (SCD). Transfus Med [Internet]. 2017;27:27.|Não é uma diretriz|
|Alashkar F, Aramayo-Singelmann C, Böll J, Hoferer A, Jarisch A, Kamal H, et al. Transition<br>in Sickle Cell Disease (SCD): A German Consensus Recommendation. J Pers Med [Internet].|Não possui<br>recomendações sobre|
|2022;12(7).|sobrecarga de ferro|
|Svarch E, Machín García S, Marcheco Teruel B, Martínez Triana R, González Otero A,|Não é uma diretriz|  
43  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Menéndez Veitía A. Program for comprehensive sickle cell disease care in Cuba. Rev Cuba<br>Hematol Inmunol y Hemoter [Internet]. 2017;33(1).||
|Qureshi A, Kaya B, Pancham S, Keenan R, Anderson J, Akanni M, et al. Guidelines for the<br>use of hydroxycarbamide in children and adults with sickle cell disease: A British Society for|Não possui<br>recomendações sobre|
|Haematology Guideline. Vol. 181, British journal of haematology. England; 2018. p. 460–75.|sobrecarga de ferro|
|Steiner ME, Zantek ND, Stanworth SJ, Parker RI, Valentine SL, Lehmann LE, et al.||
|Recommendations on RBC Transfusion Support in Children With Hematologic and Oncologic|Não possui|
|Diagnoses From the Pediatric Critical Care Transfusion and Anemia Expertise Initiative.|recomendações sobre|
|Pediatr Crit care Med a J Soc Crit Care Med World Fed Pediatr Intensive Crit Care Soc.<br>setembro de 2018;19(9S Suppl 1):S149–56.|sobrecarga de ferro|
|Cronin RM, Mayo-Gamble TL, Stimpson SJ, Badawy SM, Crosby LE, Byrd J, et al. Adapting<br>medical guidelines to be patient-centered using a patient-driven process for individuals with|Não possui<br>recomendações sobre|
|sickle cell disease and their caregivers. BMC Hematol. 8 de junho de 2018;18(1).|sobrecarga de ferro|
|Kang HA, Wang B, Barner JC, Ataga KI, Mignacca RC. Unintended Consequences of the||
|CDC’s 2016 Guideline for Prescribing Opioids for Chronic Pain for the Individuals with<br>Sickle Cell Disease. Value Heal [Internet]. 2022;25(7):S292.|Não é uma diretriz|
|Alai S, Lanzkron S, Thompson A, Carroll P, Debaun M, Kanter J, et al. Cure sickle cell||
|initiative common data elements recommendations version 1.0 development. Clin Trials<br>[Internet]. 2021;18(SUPPL 5):95.|Não é uma diretriz|

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Síndrome mielodisplásica** -->
A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR para identificação de diretrizes clínicas sobre  
síndrome mielodisplásica com recomendações para o cuidado da sobrecarga de ferro está descrita no **Quadro N.**  
**Quadro N. Pergunta PICAR (população, intervenção, comparação, atributos das diretrizes clínicas e recomendação) para identificação de diretrizes clínicas sobre síndrome mielodisplásica com recomendações para sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro transfusional na síndrome mielodisplásica|
|---|---|
|**Intervenção**|Qualquer intervenção|
|**Comparador**|Qualquer comparador|
|**Atributos das diretrizes**|Diretrizes clínicas publicadas a partir de 2017, disponíveis em inglês, espanhol ou português,|
||desde que incluíssem recomendações sobre o cuidado da sobrecarga de ferro|
|**Recomendações**|Recomendações sobre o cuidado da sobrecarga de ferro secundária à síndrome mielodisplásica|  
Fonte: autoria própria  
Com base na busca de pesquisa acima, foi elaborada a estratégia de busca descrita no **Quadro O.**  
44  
**Quadro O. Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre síndrome mieolodisplásica com recomendações para o cuidado da sobrecarga de ferro**  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline (via<br>PubMed)|"Myelodysplastic Syndromes"[Mesh] OR (Myelodysplastic Syndrome) OR<br>(Syndrome, Myelodysplastic) OR (Syndromes, Myelodysplastic) OR<br>(Dysmyelopoietic Syndromes) OR (Dysmyelopoietic Syndrome) OR (Syndrome,<br>Dysmyelopoietic) OR (Syndromes, Dysmyelopoietic) OR (Hematopoetic<br>Myelodysplasia) OR (Myelodysplasia, Hematopoetic) OR (Myelodysplasias,<br>Hematopoetic)OR (Hematopoetic Myelodysplasias))) AND (("Guideline"<br>[Publication Type] OR "Guidelines as Topic"[Mesh] OR "Practice Guideline"<br>[Publication Type] OR "Health Planning Guidelines"[Mesh]OR Guidelines as<br>Topics OR Clinical Practice Guideline OR "Clinical Protocols"[Mesh] OR<br>Protocol, Clinical OR Clinical Protocol OR Protocols, Clinical OR Treatment<br>Protocols OR Treatment Protocol OR Protocols, Treatment OR Clinical Research<br>Protocol OR Research Protocols, Clinical OR Protocols, Clinical Research OR<br>Research Protocol, Clinical OR Clinical Research Protocols OR Protocol, Clinical<br>Research OR "Consensus"[Mesh] OR "Consensus Development Conference,<br>NIH" [Publication Type] OR "Consensus Development Conference" [Publication<br>Type] OR "Consensus Development Conferences, NIH as Topic"[Mesh] OR<br>"Consensus Development Conferences as Topic"[Mesh] OR "Standard of<br>Care"[Mesh] OR Care Standard OR Care Standards OR Standards of Care)<br>Filters: from 2017 - 2023|541|
|EMBASE|'myelodysplastic syndrome'/exp AND ('practice guideline'/exp OR (clinical AND<br>practice AND guidelines) OR guidelines OR (guidelines AND as AND topic) OR<br>(practice AND guidelines) OR (practice AND guidelines AND as AND topic) OR<br>'clinical protocol'/exp OR 'consensus'/exp) AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim) AND (2017:py OR 2018:py OR 2019:py OR<br>2020:py OR 2021:py OR 2022:py OR 2023:py)|429|  
Foram identificadas 970 publicações. Após a exclusão das duplicatas (n = 61) e triagem pela leitura de títulos e resumos, 30 publicações foram selecionadas para a leitura do texto completo. Ao todo, oito diretrizes clínicas sobre síndrome mielodisplásica com recomendações para o cuidado da sobrecarga de ferro incluídas. A **Figura E** resume os resultados do processo de elegibilidade e o **Quadro P** apresenta as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
45  
**Figura E. Fluxograma de seleção dos estudos incluídos sobre diretrizes clínicas sobre doença falciforme com recomendações para o cuidado da sobrecarga de ferro**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Bases de dados (n = 1.260)  Referências removidas antes do<br>PubMed (n = 541)  processo de seleção:<br>Embase (n = 429)  Duplicatas (n = 61)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 879)<br>(n = 909)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 30)  (n = 2)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n = 20)<br>(n = 28)<br>Estudos incluídos na revisão<br>(n = 8)<br>Relatos dos estudos incluídos<br>(n = 8)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro P. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Magalhães SMM, Niero-Melo L, Chauffaille MDLLF, Velloso EDRP, Lorand-Metze I, Buzzini|Não possui|
|R, et al. Guidelines on myelodysplastic syndromes: Associação Brasileira de Hematologia,|recomendações sobre|
|Hemoterapia e Terapia Celular. Hematol Transfus Cell Ther [Internet]. 2018;40(3):255–61.|sobrecarga de ferro|  
46  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Blum S, Malcovati L. EHA Endorsement of the European Guidelines for Myelodysplastic<br>Syndromes, MDS-RIGHT. HemaSphere [Internet]. 2021;5(9).|Não é uma diretriz|
|Killick SB, Wiseman DH, Quek L, Cargo C, Culligan D, Enright H, et al. British Society for<br>Haematology guidelines for the diagnosis and evaluation of prognosis of Adult Myelodysplastic|Não possui<br>recomendações sobre|
|Syndromes. Vol. 194, British journal of haematology. England; 2021. p. 282–93.|sobrecarga de ferro|
|Baliakas P, Tesi B, Wartiovaara-Kautto U, Stray-Pedersen A, Friis LS, Dybedal I, et al. Nordic|Não possui|
|Guidelines for Germline Predisposition to Myeloid Neoplasms in Adults: Recommendations for<br>Genetic Diagnosis, Clinical Management and Follow-up. HemaSphere [Internet]. 2019;3(6).|recomendações sobre<br>sobrecarga de ferro|
|Stojkov K, Silzle T, Stussi G, Schwappach D, Bernhard J, Bowen D, et al. Development of<br>guideline-based indicators for adult patients with myelodysplastic syndromes. HemaSphere<br>[Internet]. 2020;4:360–1.|Não é uma diretriz|
|Rudelius M, Weinberg OK, Niemeyer CM, Shimamura A, Calvo KR. The International<br>Consensus Classification (ICC) of hematologic neoplasms with germline predisposition,<br>pediatric myelodysplastic syndrome, and juvenile myelomonocytic leukemia. Virchows Arch.<br>janeiro de 2023;482(1):113–30.|Não é uma diretriz|
|Tanasijevic AM, Revette A, Klepin HD, Zeidan A, Townsley D, DiNardo CD, et al. Consensus<br>minimum hemoglobin level above which patients with myelodysplastic syndromes can safely<br>forgo transfusions. Leuk Lymphoma. dezembro de 2020;61(12):2900–4.<br>Greenberg PL, Stone RM, Al-Kali A, Barta SK, Bejar R, Bennett JM, et al. Myelodysplastic<br>Syndromes, Version 2.2017, NCCN Clinical Practice Guidelines in Oncology. J Natl Compr<br>Canc Netw. janeiro de 2017;15(1):60–87.|Não é uma diretriz<br>Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Greenberg PL, Stone RM, Al-Kali A, Bennett JM, Borate U, Brunner AM, et al. NCCN<br>Guidelines® Insights: Myelodysplastic Syndromes, Version 3.2022. J Natl Compr Canc Netw.<br>fevereiro de 2022;20(2):106–17.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Tarlock K, Sulis ML, Chewning JH, Pollard JA, Cooper T, Gamis A, et al. Hematopoietic Cell<br>Transplantation in the Treatment of Pediatric Acute Myelogenous Leukemia and<br>Myelodysplastic Syndromes: Guidelines from the American Society of Transplantation and<br>Cellular Therapy. Vol. 28, Transplantation and cellular therapy. United States; 2022. p. 530–<br>45.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Kasprzak A, Kaivers J, Nachtkamp K, Haas R, Kobbe G, Gattermann N, et al. Guidelines for<br>Myelodysplastic Syndromes: Converting Evidence into Action? Int J Environ Res Public<br>Health. julho de 2021;18(14).|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Bowen D. ELN recommendations for treating MDS. Hematol Transfus Cell Ther [Internet].<br>2021;43:S67.|Não é uma diretriz|
|Stojkov K, Silzle T, Stussi G, Schwappach D, Bernhard J, Bowen D, et al. I-Care for MDS:<br>Development of Guidelines-Based Indicators for Appropriate Care in Adult Patients with<br>Myelodysplastic Syndromes. Blood [Internet]. 2019;134:4752.|Não é uma diretriz|
|Stojkov I, Conrads-Frank A, Rochau U, Koinig K, Arvandi M, Symeonidis A, et al. Developing<br>a core outcome set for myelodysplastic syndromes-the MDS-right health professional delphi<br>survey. HemaSphere [Internet]. 2018;2:943.|Não é uma diretriz|  
47  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Falini B, Martelli MP. Comparison of the International Consensus and 5th WHO edition||
|classifications of adult myelodysplastic syndromes and acute myeloid leukemia. Am J Hematol.<br>março de 2023;98(3):481–92.|Não é uma diretriz|
|Alkharabsheh O, Al-Kali A, Saadeh S, He R, Viswanatha D, Greipp P, et al. The clinical<br>outcomes of reclassified erythroleukemia (erythroid/myeloid) as myelodysplastic syndrome<br>(MDS) per 2017 WHO guideline compared to MDS. Vol. 93, American journal of hematology.<br>United States; 2018. p. E355–7.|Não é uma diretriz|
|Van De Loosdrecht AA, Mandac Smoljanović I. EHA Endorsement of ESMO Clinical Practice<br>Guidelines for Diagnosis, Treatment, and Follow-up for Myelodysplastic Syndromes.<br>HemaSphere [Internet]. 2022;6(3):E695.|Não é uma diretriz|
|Hasserjian RP, Orazi A, Orfao A, Rozman M, Wang SA. The International Consensus||
|Classification of myelodysplastic syndromes and related entities. Virchows Arch. janeiro de<br>2023;482(1):39–51.|Não é uma diretriz|
|Kar R, Dolai TK, Shekhawat PS, Malhotra P, Singh A, Naithani R, et al. Indian Society of|Não possui|
|Hematology and Blood Transfusion (ISHBT) Consensus Document on Hematological Practice|recomendações sobre|
|During COVID-19 Pandemic. Indian J Hematol Blood Transfus [Internet]. 2021;37(1).|sobrecarga de ferro|
|Li Y, Cui R, Qin T, Xu Z, Zhang Y, Cai W, et al. Validation of the WHO 2016 proposals for||
|Myelodysplastic syndromes patients with the presence of ring sideroblasts but without excess<br>blasts. Vol. 178, British journal of haematology. England; 2017. p. 813–6.|Não é uma diretriz|

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Talassemia** -->
A estrutura da pergunta de pesquisa de acordo com o acrônimo PICAR para identificação de diretrizes clínicas sobre talassemia com recomendações para o cuidado da sobrecarga de ferro está descrita no **Quadro Q.**  
**Quadro Q. Pergunta PICAR (população, intervenção, comparação, atributos das diretrizes clínicas e recomendação) para identificação de diretrizes clínicas sobre talassemia com recomendações para sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro transfusional na talassemia|
|---|---|
|**Intervenção**|Qualquer intervenção|
|**Comparador**|Qualquer comparador|
|**Atributos das diretrizes**|Diretrizes clínicas publicadas a partir de 2017, disponíveis em inglês, espanhol ou português,|
||desde que incluíssem recomendações sobre o cuidado da sobrecarga de ferro|
|**Recomendações**|Recomendações sobre o cuidado da sobrecarga de ferro secundária à talassemia|  
Fonte: autoria própria  
Com base na busca de pesquisa acima, foi elaborada a estratégia de busca descrita no **Quadro R.**  
48  
**Quadro R. Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas sobre talassemia com recomendações para o cuidado da sobrecarga de ferro**  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline (via PubMed)|"Thalassemia"[Mesh] OR (Thalassemias) AND (("Guideline" [Publication<br>Type] OR "Guidelines as Topic"[Mesh] OR "Practice Guideline" [Publication<br>Type] OR "Health Planning Guidelines"[Mesh]OR Guidelines as Topics OR<br>Clinical Practice Guideline OR "Clinical Protocols"[Mesh] OR Protocol,<br>Clinical OR Clinical Protocol OR Protocols, Clinical OR Treatment Protocols<br>OR Treatment Protocol OR Protocols, Treatment OR Clinical Research<br>Protocol OR Research Protocols, Clinical OR Protocols, Clinical Research<br>OR Research Protocol, Clinical OR Clinical Research Protocols OR Protocol,<br>Clinical Research OR "Consensus"[Mesh] OR "Consensus Development<br>Conference, NIH" [Publication Type] OR "Consensus Development<br>Conference" [Publication Type] OR "Consensus Development Conferences,<br>NIH as Topic"[Mesh] OR "Consensus Development Conferences as<br>Topic"[Mesh] OR "Standard of Care"[Mesh] OR Care Standard OR Care<br>Standards OR Standards of Care) Filters: from 2017 - 2023|272|
|EMBASE|'thalassemia'/exp AND ('practice guideline'/exp OR (clinical AND practice<br>AND guidelines) OR guidelines OR (guidelines AND as AND topic) OR<br>(practice AND guidelines) OR (practice AND guidelines AND as AND<br>topic) OR 'clinical protocol'/exp OR 'consensus'/exp) AND [embase]/lim<br>NOT ([embase]/lim AND [medline]/lim) AND (2017:py OR 2018:py OR<br>2019:py OR 2020:py OR 2021:py OR 2022:py OR 2023:py)|339|  
Foram identificadas 611 publicações. Após a exclusão das duplicatas (n = 44) e triagem pela leitura de títulos e resumos, 13 publicações foram selecionadas para a leitura do texto completo. Ao todo, duas diretrizes clínicas sobre talassemia com recomendações para o cuidado da sobrecarga de ferro incluídas. A **Figura F** resume os resultados do processo de elegibilidade e o **Quadro S** apresenta as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
49  
**Figura F. Fluxograma de seleção dos estudos incluídos sobre diretrizes clínicas sobre talassemia com recomendações para o cuidado da sobrecarga de ferro**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:  Referências removidas antes do<br>Bases de dados (n = 611)  processo de seleção:<br>PubMed (n = 272)  Duplicatas (n = 44)<br>Embase (n = 339)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 554)<br>(n = 567)<br>Referências incluídas para avaliação<br>Referências cujo texto completo não<br>por texto completo<br>foi identificado<br>(n = 13)<br>(n = 1)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n = 10)<br>(n = 12)<br>Estudos incluídos na revisão<br>(n = 2)<br>Relatos dos estudos incluídos<br>(n = 2)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Ref. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro S. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Compernolle V, Chou S, Tanael S, Savage W, Howard J, Josephson C, et al. Red cell||
|specifications for patients with hemoglobinopathies: A systematic review and guideline. Vox|Não é diretriz|
|Sang [Internet]. 2017; 112:266.||
|Shang X, Zhang X, Yang F, Xu X. [Clinical practice guidelines for alpha-thalassemia].<br>Zhonghua yi xue yi chuan xue za zhi = Zhonghua yixue yichuanxue zazhi = Chinese J Med|Idioma|  
50  
|**Estudo**|**Motivo da exclusão**|
|---|---|
|Genet. março de 2020;37(3):235–42.||
|Casale M, Baldini M, Del Monte P, Gigante A, Grandone A, Origa R, et al. The Management<br>of Endocrine Complications in Patients with Haemoglobinopathies: Good Clinical Practice of<br>the Italian Society of Thalassemia and Haemoglobinopathies (SITE). Recenti Prog Med<br>[Internet]. 2022;113(9):495–554.|Idioma|
|Compernolle V, Chou ST, Tanael S, Savage W, Howard J, Josephson CD, et al. Red blood cell<br>specifications for patients with hemoglobinopathies: a systematic review and guideline.<br>Transfusion. junho de 2018;58(6):1555–66.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Trompeter S, Massey E, Robinson S. Position paper on International Collaboration for<br>Transfusion Medicine (ICTM) Guideline “Red blood cell specifications for patients with<br>hemoglobinopathies: a systematic review and guideline”. Br J Haematol. maio de<br>2020;189(3):424–7.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Casale M, Baldini MI, Del Monte P, Gigante A, Grandone A, Origa R, et al. Good Clinical<br>Practice of the Italian Society of Thalassemia and Haemoglobinopathies (SITE) for the<br>Management of Endocrine Complications in Patients with Haemoglobinopathies. J Clin Med.<br>2022;11(7).|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Kolnagou A, Kontoghiorghes GJ. Chelation protocols for the elimination and prevention of<br>iron overload in thalassaemia. Front Biosci (Landmark Ed. janeiro de 2018;23(6):1082–98.|Não é diretriz|
|Farmakis D, Giakoumis A, Cannon L, Angastiniotis M, Eleftheriou A. COVID-19 and<br>thalassaemia: A position statement of the Thalassaemia International Federation. Eur J<br>Haematol. outubro de 2020;105(4):378–86.|Não possui<br>recomendações sobre<br>sobrecarga de ferro|
|Chinese guideline for diagnosis and treatment of transfusion dependent β-thalassemia (2022).<br>Zhonghua Xue Ye Xue Za Zhi. novembro de 2022;43(11):889–96.|Idioma|
|Viprakasit V, Ajlan A, Aydinok Y, Al Ebadi BAA, Dewedar H, Ibrahim AS, et al. MRI for the<br>diagnosis of cardiac and liver iron overload in patients with transfusion-dependent thalassemia:<br>An algorithm to guide clinical use when availability is limited. Vol. 93, American journal of<br>hematology. United States; 2018. p. E135–7.|Não é diretriz|

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Busca complementar em repositórios de diretrizes clínicas** -->
Além das buscas em bases de dados descritas acima, também foram realizadas buscas em repositórios específicos de diretrizes clínicas para identificar diretrizes ou documentos com recomendações sobre o cuidado da sobrecarga de ferro ou que possam ter alguma relação com a doença – em relação à causa base, exames diagnósticos ou alternativas medicamentosas. A busca foi realizada em 14/03/2023 nos seguintes repositórios: Ministério da Saúde do Brasil (gov.br/conitec/pt-br), _Guidelines International Network_ (g-i-n.net), _Canadian Agency for Drugs and Technologies in Health_ – CADTH (cadth.ca), _Canadian Medical Association_ (cma.ca), _Scottish Intercollegiate Guidelines Network_ (sign.ac.uk), Ministério da Saúde do Chile (bibliotecaminsal.cl/guias-clinicas-auge/), ECRI _Guidelines_ (https://guidelines.ecri.org/), _Portal Guía Salud_ (guiasalud.es), _World Health Organization_ (WHO) e _National Institute for Health and Care Excellence_ (nice.org.uk).  
Para os repositórios específicos, os termos utilizados foram _iron overload, iron metabolism disorders_ , _sobrecarga de Hierro_ e sobrecarga de ferro, de acordo com o idioma do repositório. As buscas foram realizadas no dia 14 de março de 2023.  
51  
Foram identificadas 53 publicações e documentos com recomendações para o cuidado de sobrecarga de ferro. As diretrizes foram identificadas nos repositórios do CADTH, Ministério da Saúde do Brasil, WHO e GIN. Após avaliação por texto completo, foram incluídas quatro publicações.  
Durante a revisão do PCDT por especialistas médicos com experiência em tratamento de pacientes com sobrecarga de ferro, dois estudos foram incluídos manualmente. A justificativa deve-se à percepção de que essas referências abordam mais adequadamente a agranulocitose induzida pelo tratamento com quelantes de ferro.  
Foram incluídas as referências:  
1. Elalfy M, Wali YA, Qari M, et al. Deviating from safety guidelines during deferiprone therapy in clinical practice  
may not be associated with higher risk of agranulocytosis. Pediatr Blood Cancer 2014; 61: 879–884.  
2. Tricta F, Uetrecht J, Galanello R, et al. Deferiprone‐induced agranulocytosis: 20 years of clinical observations. Am J Hematol 2016; 91: 1026–1031.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes incluídas** -->
A lista de diretrizes clínicas identificadas por meio das buscas descritas acima é descrita no **Quadro T** . Ressalta-se que  
uma mesma diretriz clínica pode ter sido identificada em mais de uma busca e, dessa forma, constar mais de uma vez no quadro.  
**Quadro T. Lista de diretrizes clínicas identificadas.**

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes clínicas sobre sobrecarga de ferro** -->
1. Zoller, H., Schaefer, B., Vanclooster, A., Griffiths, B., Bardou-Jacquet, E., Corradini, E., et al. European Association for the Study of the Liver. European Association for the Study of the L. EASL Clinical Practice Guidelines on haemochromatosis. J Hepatol. 2022;77(2):479-502.  
2. Cullis JO, Fitzsimons EJ, Griffiths WJ, Tsochatzis E, Thomas DW. Investigation and management of a raised serum ferritin. Vol. 181, British journal of haematology. England; 2018. p. 331–40.  
3. Adams P, Altes A, Brissot P, Butzeck B, Cabantchik I, Cançado R, et al. Therapeutic recommendations in HFE hemochromatosis for p.Cys282Tyr (C282Y/C282Y) homozygous genotype. Vol. 12, Hepatology international. United States; 2018. p. 83–6.  
4. Kowdley K V, Brown KE, Ahn J, Sundaram V. ACG Clinical Guideline: Hereditary Hemochromatosis. Am J Gastroenterol. agosto de 2019;114(8):1202–18.  
5. Loggetto SR, Veríssimo MPA, Darrigo-Junior LG, Simões R, Bernardo WM, Braga JAP. Guidelines on sickle cell disease: secondary stroke prevention in children and adolescents. Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular guidelines project: Associação Médica Brasileira - 2022. Hematol Transfus Cell Ther [Internet]. 2022;44(2):246–55. Available at:  
https://www.embase.com/search/results?subaction=viewrecord&id=L2017300514&from=export  
6. White D, Brissot P, Butzeck B, Don H, Evans R, Santos P, et al. Haemochromatosis international-an alliance of hereditary haemochromatosis groups around the world. Am J Hematol [Internet]. 2017;92(8):E258. Available at: https://www.embase.com/search/results?subaction=viewrecord&id=L617420631&from=export  
7. Chou ST, Alsawas M, Fasano RM, Field JJ, Hendrickson JE, Howard J, et al. American society of hematology 2020 guidelines for sickle cell disease: Transfusion support. Vol. 4, Blood Advances. American Society of Hematology; 2020. p. 327–55.  
**Diretrizes clínicas sobre hemocromatose com recomendações para cuidado da sobrecarga de ferro**  
52  
1. Kowdley K V, Brown KE, Ahn J, Sundaram V. ACG Clinical Guideline: Hereditary Hemochromatosis. Am J Gastroenterol. agosto de 2019;114(8):1202–18.  
2. Zoller, H., Schaefer, B., Vanclooster, A., Griffiths, B., Bardou-Jacquet, E., Corradini, E., et al. European Association for the Study of the Liver. European Association for the Study of the L. EASL Clinical Practice Guidelines on haemochromatosis. J Hepatol. 2022;77(2):479-502.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes clínicas sobre doença falciforme com recomendações para cuidado da sobrecarga de ferro** -->
1. Chou ST, Alsawas M, Fasano RM, Field JJ, Hendrickson JE, Howard J, et al. American Society of Hematology 2020 guidelines for sickle cell disease: transfusion support. Blood Adv. janeiro de 2020;4(2):327–55.  
2. Loggetto SR, Veríssimo MPA, Darrigo-Junior LG, Simões R, Bernardo WM, Braga JAP. Guidelines on sickle cell disease: secondary stroke prevention in children and adolescents. Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular guidelines project: Associação Médica Brasileira - 2022. Hematol Transfus Cell Ther [Internet]. 2022;44(2):246–55. Available at: https://www.embase.com/search/results?subaction=viewrecord&id=L2017300514&from=export  
3. Davis BA, Allard S, Qureshi A, Porter JB, Pancham S, Win N, et al. Guidelines on red cell transfusion in sickle cell disease. Part I: principles and laboratory aspects. Br J Haematol. janeiro de 2017;176(2):179–91.  
4. Davis BA, Allard S, Qureshi A, Porter JB, Pancham S, Win N, et al. Guidelines on red cell transfusion in sickle cell disease Part II: indications for transfusion. Br J Haematol. janeiro de 2017;176(2):192–209.  
5. Biller E, Zhao Y, Berg M, Boggio L, Capocelli KE, Fang DC, et al. Red blood cell exchange in patients with sickle cell disease-indications and management: a review and consensus report by the therapeutic apheresis subsection of the AABB. Transfusion. agosto de 2018;58(8):1965–72.  
6. Shenoy S, Gaziev J, Angelucci E, King A, Bhatia M, Smith A, et al. Late Effects Screening Guidelines after Hematopoietic Cell Transplantation (HCT) for Hemoglobinopathy: Consensus Statement from the Second Pediatric Blood and Marrow Transplant Consortium International Conference on Late Effects after Pediatric HCT. Biol blood marrow Transplant J Am Soc Blood Marrow Transplant. julho de 2018;24(7):1313–21.  
**Diretrizes clínicas sobre síndrome mielodisplásica com recomendações para cuidado da sobrecarga de ferro**  
1. DeFilipp Z, Ciurea SO, Cutler C, Robin M, Warlick ED, Nakamura R, et al. Hematopoietic Cell Transplantation in the Management of Myelodysplastic Syndrome: An Evidence-Based Review from the American Society for Transplantation and Cellular Therapy Committee on Practice Guidelines. Vol. 29, Transplantation and cellular therapy. United States; 2023. p. 71–81.  
2. Leitch HA, Buckstein R, Zhu N, Nevill TJ, Yee KWL, Leber B, et al. Iron overload in myelodysplastic syndromes: Evidence based guidelines from the Canadian consortium on MDS. Leuk Res. novembro de 2018;74:21–41.  
3. Killick SB, Ingram W, Culligan D, Enright H, Kell J, Payne EM, et al. British Society for Haematology guidelines for the management of adult myelodysplastic syndromes. Vol. 194, British journal of haematology. England; 2021. p. 267– 81.  
4. Miyazaki Y. JSH practical guidelines for hematological malignancies, 2018: I. Leukemia-6 myelodysplastic syndromes (MDS). Int J Hematol. abril de 2020;111(4):481–93.  
5. Fenaux P, Haase D, Santini V, Sanz GF, Platzbecker U, Mey U. Myelodysplastic syndromes: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Vol. 32, Annals of oncology: official journal of the European Society for Medical Oncology. England; 2021. p. 142–56.  
53  
6. Miyazaki Y. JSH Guideline for Tumors of Hematopoietic and Lymphoid Tissues: Leukemia: 6. Myelodysplastic syndromes (MDS). Int J Hematol. agosto de 2017;106(2):151–9. 7. de Witte T, Bowen D, Robin M, Malcovati L, Niederwieser D, Yakoub-Agha I, et al. Allogeneic hematopoietic stem cell transplantation for MDS and CMML: recommendations from an international expert panel. Blood. março de 2017;129(13):1753–62.  
8. Valent P, Stauder R, Theurl I, Geissler K, Sliwa T, Sperr WR, et al. Diagnosis, management and response criteria of iron overload in myelodysplastic syndromes (MDS): updated recommendations of the Austrian MDS platform. Expert Rev Hematol. fevereiro de 2018;11(2):109–16.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes clínicas sobre talassemia com recomendações para cuidado da sobrecarga de ferro** -->
1. Shenoy S, Gaziev J, Angelucci E, King A, Bhatia M, Smith A, et al. Late Effects Screening Guidelines after Hematopoietic Cell Transplantation (HCT) for Hemoglobinopathy: Consensus Statement from the Second Pediatric Blood and Marrow Transplant Consortium International Conference on Late Effects after Pediatric HCT. Biol blood marrow Transplant J Am Soc Blood Marrow Transplant. julho de 2018;24(7):1313–21.  
2. Shah FT, Porter JB, Sadasivam N, Kaya B, Moon JC, Velangi M, et al. Guidelines for the monitoring and management of iron overload in patients with haemoglobinopathies and rare anaemias. Vol. 196, British journal of haematology. England; 2022. p. 336–50.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes clínicas e documentos com recomendações para cuidado da sobrecarga de ferro identificadas por meio de busca complementar** -->
1. World Health Organization (WHO). WHO Guideline on use of ferritin concentrations to assess iron status in individuals and population. 2020. 82 p.  
2. Brasil. Ministério da Saúde. Portaria Conjunta No 7, de 23 de fevereiro de 2018. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Sobrecarga de Ferro. 2018.  
3. Canadian Agency for Drugs and Technologies in Health (CADTH). Recommendation and Reasons. Exjade (deferasirox). 2007.  
4. Canadian Agency for Drugs and Technologies in Health (CADTH). CADTH Reimbursement Review. Deferiprone (Ferriprox). Can J Heal Technol. 2023;3(4).  
O **Quadro U** elenca as recomendações extraídas dessas diretrizes clínicas. Cabe ressaltar que a recomendação global citada em cada item, representando as seções desse PCDT, consiste em consenso de pelo menos duas diretrizes, independentemente da certeza de evidência e força da recomendação. O PCDT da Sobrecarga de Ferro, do Ministério da Saúde, não foi incluído por se tratar do documento em atualização.  
54  
**Quadro U. Recomendações das diretrizes clínicas incluídas para o tratamento da sobrecarga de ferro, associada ou não a outras condições.**  
|**Recomendações das**|**diretrizes clínicas**|**sobre sobrecarga de ferro**||||||
|---|---|---|---|---|---|---|---|
||**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|Diagnóstico clínico||Investigar pacientes<br>com ferritina sérica<br>elevada, risco para<br>doença hepática,<br>história de transfusão,<br>história familiar de<br>sobrecarga de ferro e<br>presença diabetes<br>mellitus tipo 2,<br>obesidade e<br>hipertensão.|||Sintomas<br>hepáticos e de<br>doença cardíaca<br>devem ser<br>investigados para<br>sobrecarga de<br>ferro.||Recomenda-se investigar<br>sobrecarga de ferro em<br>pacientes com doença<br>hepática.|
|Diagnóstico<br>laboratorial||Hemograma completo,<br>ferritina sérica,<br>saturação de<br>transferrina,<br>marcadores<br>inflamatórios (proteína<br>C reativa, velocidade<br>de hemossedimentação<br>ou viscosidade<br>plasmática), creatinina<br>sérica e eletrólitos para<br>função renal, testes de<br>função hepática e|Nível de ferro<br>sérico: saturação de<br>transferrina (teste<br>inicial de<br>preferência),<br>ferritina sérica e<br>capacidade de<br>ligação do ferro<br>insaturado.<br>Medição não<br>invasiva: T2*<br>hepática.||Nível de ferro<br>sérico: dosagem<br>de ferritina sérica<br>e saturação de<br>transferrina.<br>Medição não<br>invasiva: T2* para<br>quantificar<br>concentrações de<br>ferro hepático,<br>cardíaco e<br>envolvimento de<br>outros órgãos.||Recomenda-se quantificar<br>nível de ferro sérico pela<br>saturação de transferrina e<br>ferritina sérica e quantificar<br>a concentração de ferro<br>hepático e cardíaco por<br>T2* para descartar<br>sobrecarga de ferro<br>secundária clinicamente<br>significativa.|  
55

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Recomendações das diretrizes clínicas sobre sobrecarga de ferro** -->
||**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|---|
|||ultrassonografia<br>abdominal (se função<br>hepática anormal) e<br>estudos de glicemia e<br>lipídios.|Obs.: Se houver<br>necessidade<br>concomitante de<br>estadiar a fibrose<br>hepática (FC) ou<br>avaliar doenças<br>hepáticas<br>alternativas,<br>preferir a biópsia<br>hepática.|||||
|Tratamento não<br>medicamentoso|A sobrecarga de<br>ferro após o<br>transplante de<br>células tronco pode<br>ser tratada por<br>flebotomias.|Em pacientes saudáveis<br>com níveis de ferritina<br>sérica moderadamente<br>elevados e<br>inexplicáveis (<1000<br>lg/l) e saturação de<br>transferrina normal, um<br>período de observação,<br>com ajuste de estilo de<br>vida, se apropriado,<br>pode ser razoável com<br>repetição da avaliação<br>após 3-6 meses|Flebotomia<br>semanal até atingir<br>ferritina sérica<br>entre 50 e<br>100mg/dL e na fase<br>de manutenção, 3 a<br>4 vezes no ano, até<br>50 ng/mL de<br>ferritina sérica.<br>Eritrocitaférese<br>alternativa em<br>pacientes com<br>hipoproteinemia ou<br>trombocitopenia|Eritrocitaférese<br>automatizada para<br>pacientes que não<br>toleram, apresentam<br>efeitos adversos ou<br>não aderem à<br>terapia de quelação.|Flebotomia em 1ª<br>linha, com<br>indução semanal<br>ou bissemanal até<br>ferritina sérica em<br>50 µg/L e<br>manutenção 2-6<br>por ano para uma<br>ferritina entre 50-<br>100 µg/L, sendo a<br>eritrocitaférese<br>alternativa na fase<br>de indução, se<br>disponível.|Eritrocitaféreses<br>manual ou<br>automatizada é<br>eficaz para<br>diminuir a carga<br>de ferro.|Recomenda-se flebotomia<br>como tratamento de<br>escolha semanal e<br>eritrocitaférese, se<br>disponível.|  
56  
||**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|---|
||||uma vez a cada 2–3<br>semanas.|||||
|Tratamento<br>medicamentoso|O painel de<br>especialistas<br>concordou que os<br>pacientes com<br>histórico de<br>transfusão de 0,20<br>unidades de<br>hemácias, que são<br>potenciais<br>candidatos ao<br>transplante de<br>células tronco,<br>devem receber<br>terapia adequada de<br>quelação de ferro<br>antes do<br>condicionamento<br>para transplante.||Uso de quelantes<br>de ferro,<br>desferroxamina,<br>deferiprona e<br>deferasirox, para<br>paciente intolerante<br>ou refratário à<br>flebotomia ou<br>quando a<br>flebotomia tem<br>potencial danoso,<br>em caso de anemia<br>grave ou<br>insuficiência<br>cardíaca<br>congestiva.||Quelantes de ferro<br>em 1ª linha nos<br>pacientes com<br>acesso venoso<br>difícil, fobia de<br>agulhas, anemia<br>concomitante à<br>hemocromatose e<br>sobrecarga de<br>ferro com risco à<br>vida. Uso<br>complementar de<br>inibidores de<br>bombas de próton.||Recomenda-se uso de<br>quelantes de ferro para<br>pacientes que tenham<br>limitações à realização de<br>flebotomia.|
|Educação do<br>paciente|||Evitar suplementos<br>de vitamina C,<br>porque o ácido||Evitar suplemento<br>de ferro e<br>vitamina C, frutos||Recomenda-se ao paciente:<br>evitar suplementos de<br>vitamina C e abster-se de|  
57  
**Recomendações das diretrizes clínicas sobre sobrecarga de ferro**  
||**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|---|
||||ascórbico aumenta<br>a absorção de ferro.<br>Investigar<br>distúrbios<br>relacionados ao<br>álcool e aconselhar<br>abstenção antes de<br>prosseguir com o<br>tratamento.||do mar crus e mal-<br>cozidos.<br>Pacientes com<br>doença no fígado,<br>abster-se de<br>álcool.||álcool (especialmente em<br>caso de doença hepática).|
|Casos especiais|||||Flebotomia em<br>gestantes com<br>sobrecarga de<br>ferro deverá ser<br>avaliada pelo<br>médico, sendo<br>recomendada<br>pausa do<br>tratamento.<br>Quelantes são<br>contraindicados<br>para gestantes e<br>devem ter a dose<br>ajustada em casos<br>de insuficiência<br>renal.|||  
58  
|**Recomendações d**|**as diretrizes clínicas**|**sobre sobrecarga de ferro**||||||
|---|---|---|---|---|---|---|---|
||**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|Monitoramento|||Verificar o nível de<br>hemoglobina antes<br>e durante o<br>tratamento com<br>flebotomia para<br>garantir que esteja<br>acima de 11 g/dL.<br>O nível de ferritina<br>sérica deve ser<br>verificado<br>mensalmente<br>durante o curso da<br>flebotomia até que<br>uma meta de nível<br>de 50–100 ng/mL<br>seja atingida.|Sugere triagem<br>cardíaca por<br>ressonância<br>magnética T2*<br>para o subgrupo de<br>pacientes com alta<br>carga de ferro (teor<br>de ferro no fígado<br>0,15 mg/g - peso<br>seco - por 2 anos ou<br>mais, evidência de<br>dano ao órgão-alvo<br>devido a<br>sobrecarga<br>transfusional de<br>ferro ou evidência<br>de disfunção<br>cardíaca).|Monitoramento de<br>insuficiência<br>hepática e renal<br>quando em uso de<br>desferroxamina.||Recomenda-se<br>monitoramento mensal de<br>níveis séricos de ferro e<br>função renal e hepática (em<br>uso de desferroxamina).|
|Recomendações<br>negativas||Não há evidências que<br>apoiem uso de<br>flebotomia para reduzir<br>os níveis séricos de<br>ferritina em pacientes<br>com doença hepática<br>gordurosa não alcoólica|Biópsia de fígado<br>não é indicada, a<br>menos que haja um<br>fator de risco<br>concomitante para<br>cirrose.|Se o nível de<br>ferritina for <1.000<br>ng/mL e o paciente<br>estiver recebendo<br>transfusão com<br>balanço de ferro<br>neutro ou negativo,|Biópsia hepática<br>tem objetivo de<br>identificar cirrose<br>ou avaliar fibrose<br>hepática quando<br>ferritina sérica<br>>1.000µg/L e não||Recomenda-se NÃO<br>utilizar quelação de ferro<br>como terapia de primeira<br>linha e a biópsia hepática<br>para diagnóstico de<br>sobrecarga de ferro.|  
59  
|**Recomendações das diretrizes clínicas sobre sobrecarga de ferro**|
|---|  
|**Witte, 2017**|**Cullis, 2018**|**Kowdley, 2019**|**Chou, 2020**|**Zoller, 2022**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|
|||Não recomenda<br>quelação como<br>terapia de primeira<br>linha, dada a<br>eficácia da|a ressonância<br>magnética para<br>determinar o<br>conteúdo de ferro<br>no fígado não é|é recomendada<br>para diagnóstico<br>de sobrecarga de<br>ferro.<br>Não considerar|||
|||flebotomia e os<br>efeitos colaterais|necessária.<br>Não é indicada|níveis de<br>hepcidina no|||
|||associados à<br>quelação, incluindo<br>toxicidade hepática<br>e renal.|triagem rotineira de<br>sobrecarga de ferro<br>por T2* para<br>conteúdo de ferro<br>cardíaco em<br>pacientes que<br>recebem transfusão<br>crônica.|diagnóstico de<br>sobrecarga de<br>ferro (referência<br>não estabelecida).|||

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Recomendações das diretrizes clínicas de hemocromatose para sobrecarga de ferro secundária** -->
||**Kowdley, 2019**|**Zoller, 2022**|**Recomendação global**|
|---|---|---|---|
|Diagnóstico clínico||Sintomas hepáticos e de doença cardíaca devem<br>ser investigados para sobrecarga de ferro.||
|Diagnóstico<br>laboratorial|Nível de ferro sérico: saturação de transferrina<br>(teste inicial de preferência), ferritina sérica e<br>capacidade de ligação do ferro insaturado.|Nível de ferro sérico: dosagem de ferritina<br>sérica e saturação de transferrina.|Recomenda-se, em pacientes com hemocromatose,<br>quantificar nível de ferro sérico pela saturação de<br>transferrina e ferritina sérica.|  
60  
|**Recomendações das diretrizes clínicas de hemocromatose para sobrecarga de ferro secundária**|
|---|  
||**Kowdley, 2019**|**Zoller, 2022**|**Recomendação global**|
|---|---|---|---|
||Medição não invasiva por ressonância magnética<br>(T2*) hepática.<br>Obs.: Se houver necessidade concomitante de<br>estadiar a fibrose hepática (FC) ou avaliar doenças<br>hepáticas alternativas, preferir a biópsia hepática.|Medição não invasiva: T2* para quantificar<br>concentrações de ferro hepático, cardíaco e<br>envolvimento de outros órgãos.|Quantificar concentração de ferro hepático e cardíaco por<br>T2* para descartar sobrecarga de ferro secundária<br>clinicamente significativa.|
|Tratamento não<br>medicamentoso|Flebotomia semanal de 500mL de sangue até atingir<br>um nível de ferritina sérica entre 50 e 100mg/dL.<br>Volumes maiores de sangue, geralmente 1.000 mL,<br>se tolerados. Na fase de manutenção, com<br>flebotomia de 3 a 4 vezes no ano, níveis de ferritina<br>sérica próximos a 50 ng/mL são esperados.<br>Eritrocitaférese alternativa em pacientes com<br>hipoproteinemia ou trombocitopenia uma vez a<br>cada 2–3 semanas. O volume de hemácias a ser<br>removido fica entre 350 e 800 mL. A hemoglobina<br>alvo mínima pós-procedimento é de 10 mg/dL.|Flebotomia em 1ª linha, com indução semanal<br>ou bissemanal até ferritina sérica em 50 µg/L e<br>manutenção 2-6 por ano para uma ferritina entre<br>50-100 µg/L, sendo a eritrocitaférese alternativa<br>na fase de indução, se disponível.|Recomenda-se, em pacientes com hemocromatose, a<br>flebotomia como tratamento de escolha semanal e<br>eritrocitaférese, se disponível.|
|Tratamento<br>medicamentoso|Uso de quelantes de ferro, desferroxamina,<br>deferiprona e deferasirox, para paciente intolerante<br>ou refratário à flebotomia ou quando a flebotomia<br>tem potencial danoso, em caso de anemia grave ou<br>insuficiência cardíaca congestiva.|Quelantes de ferro em 1ª linha nos pacientes<br>com acesso venoso difícil, fobia de agulhas,<br>anemia concomitante à hemocromatose e<br>sobrecarga de ferro com risco à vida. Uso<br>complementar de inibidores de bombas de<br>próton.|Recomenda-se, em pacientes com hemocromatose, uso de<br>quelantes de ferro em caso de limitações à realização de<br>flebotomia.|  
61  
||**Kowdley, 2019**|**Zoller, 2022**|**Recomendação global**|
|---|---|---|---|
|Educação do<br>paciente|Evitar suplementos de vitamina C, porque o ácido<br>ascórbico aumenta a absorção de ferro.<br>Investigar distúrbios relacionados ao álcool e<br>aconselhar abstenção antes de prosseguir com o<br>tratamento.|Evitar suplemento de ferro e vitamina C, frutos<br>do mar crus e mal-cozidos.<br>Pacientes com doença no fígado, abster-se de<br>álcool.|Recomenda-se, para pacientes com hemocromatose, evitar<br>suplementos de vitamina C e abster-se de álcool<br>(especialmente em caso de doença hepática).|
|||Flebotomia em gestantes com sobrecarga de<br>ferro deverá ser avaliada pelo médico, sendo<br>recomendada pausa do tratamento.||
|Casos especiais||Quelantes são contraindicados para gestantes e<br>devem ter a dose ajustada em casos de<br>insuficiência renal.||
||Verificar o nível de hemoglobina antes<br>e durante o tratamento com flebotomia para garantir<br>que esteja acima de 11 g/dL.|Em insuficiência hepática e renal com uso de|Recomenda-se, em pacientes com hemocromatose,|
|Monitoramento|O nível de ferritina sérica deve ser verificado<br>mensalmente durante o curso da flebotomia até que<br>uma meta de nível de 50–100 ng/mL seja atingida.|desferroxamina, monitorar função dos órgãos<br>mensalmente.|monitoramento mensal de níveis séricos de ferro e função<br>renal e hepática (em uso de desferroxamina).|
|Recomendações<br>negativas|Biópsia de fígado não é indicada, a menos que haja<br>um fator de risco concomitante para cirrose.|Biópsia hepática tem objetivo de identificar<br>cirrose ou avaliar fibrose hepática quando<br>ferritina sérica >1.000µg/L e não é recomendada<br>para diagnóstico de sobrecarga de ferro.|Recomenda-se, em pacientes com hemocromatose, NÃO<br>utilizar biópsia hepática para diagnóstico de sobrecarga de<br>ferro.|  
62  
|**Kowdley, 2019**|**Zoller, 2022**|**Recomendação global**|
|---|---|---|
|Não recomenda quelação como terapia de primeira|||
|linha, dada a eficácia da flebotomia e os efeitos|Não considerar níveis de hepcidina no||
|colaterais associados à quelação, incluindo|diagnóstico de sobrecarga de ferro (referência||
|toxicidade hepática e renal.|não estabelecida).||

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Recomendações das diretrizes clínicas de anemia falciforme para sobrecarga de ferro secundária** -->
||**Davis, 2017 (I e II)**|**Shenoy, 2018**|**Biller, 2018**|**Chou, 2020**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|
|Diagnóstico clínico|||||||
|Diagnóstico<br>laboratorial|Avaliação da<br>concentração de ferro no<br>fígado utilizando<br>ressonância magnética é<br>recomendada para<br>pacientes com sobrecarga<br>transfusional de ferro<br>suspeita; com frequência<br>sugerida de testes a cada<br>1–2 anos.||||||
|Tratamento não<br>medicamentoso||Consenso de uso da<br>flebotomia para redução<br>da carga de ferro.|Eritrocitaférese em<br>vez da transfusão<br>crônica, é benéfica<br>para limitar a<br>sobrecarga de ferro.|Eritrocitaférese em<br>pacientes que recebem<br>transfusões crônicas ou<br>que não toleram,<br>apresentam efeitos|Eritrocitaféreses<br>manuais ou<br>automatizadas para<br>diminuir a sobrecarga<br>de ferro.|Recomenda-se, em pacientes<br>com anemia falciforme, o uso<br>de eritrocitaférese para<br>redução da sobrecarga de|  
63  
**Recomendações das diretrizes clínicas de anemia falciforme para sobrecarga de ferro secundária**  
||**Davis, 2017 (I e II)**|**Shenoy, 2018**<br>**Biller, 2018**|**Chou, 2020**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|
||||adversos ou não aderem à<br>terapia de quelação.||ferro em pacientes com<br>anemia falciforme.|
|Tratamento<br>medicamentoso|Os autores concluíram<br>que a transfusão e a<br>quelação continuam a ser<br>a melhor forma de tratar<br>crianças com anemia<br>falciforme e sobrecarga<br>de ferro.|Consenso de uso de<br>quelantes de ferro para<br>redução da carga de<br>ferro.|||Recomenda-se, em pacientes<br>com anemia falciforme, uso<br>de quelantes de ferro em caso<br>sobrecarga de ferro.|
|Educação do<br>paciente||||||
|Casos especiais||||||
|Monitoramento|Pacientes cronicamente<br>transfundidos devem ser<br>monitorados<br>regularmente com<br>ferritina sérica pelo<br>menos a cada 3 meses; e<br>medições de ferro<br>hepático (T2*) a cada 1 a<br>2 anos.<br>Pacientes transfundidos<br>intermitentemente devem||Durante terapia de<br>quelação, sugere-se:<br>triagem de sobrecarga de<br>ferro hepático por<br>ressonância magnética<br>(R2, T2* ou R2*) a cada<br>1 a 2 anos, em pacientes<br>recebendo terapia<br>transfusional crônica<br>para verificar o conteúdo<br>de ferro no fígado,||Recomenda-se, em pacientes<br>com anemia falciforme,<br>monitoramento do ferro<br>hepático por meio de<br>ressonância magnética e<br>acompanhamento regular da<br>dosagem de ferritina sérica<br>em pacientes que recebem<br>transfusão crônica.|  
64  
||**Davis, 2017 (I e II)**|**Shenoy, 2018**|**Biller, 2018**|**Chou, 2020**|**Loggetto, 2022**|**Recomendação global**|
|---|---|---|---|---|---|---|
||ser monitorados quanto à<br>sobrecarga de ferro como<br>parte de seus cuidados de<br>rotina.|||independentemente do<br>nível de ferritina.<br>A ferritina sérica é útil<br>para monitorar<br>tendências na carga de<br>ferro ao longo do tempo.|||
|Recomendações<br>negativas||||Sugere-se contra a adição<br>de triagem rotineira de<br>sobrecarga de ferro por<br>ressonância magnética<br>para conteúdo de ferro<br>cardíaco em comparação<br>com o monitoramento<br>seriado dos níveis de<br>ferritina isoladamente em<br>pacientes que recebem<br>transfusão crônica.|||  
|**Recomendações das**|**diretrizes clínicas**<br>**de Witte, 2017**|**de síndrome mielod**<br>**Leitch, 2018**|**isplásica para sobre**<br>**Valent, 2018**|**carga de ferro se**<br>**Miyazaki,**<br>**2017/2020**|**cundária**<br>**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
|Diagnóstico clínico|||||||||
|Diagnóstico||A sobrecarga de|Nível sérico de||A ressonância||A ferritina|Recomenda-se, em|
|laboratorial||ferro deve ser|ferritina e a||magnética para||sérica é um|pacientes com|  
65  
**Recomendações das diretrizes clínicas de síndrome mielodisplásica para sobrecarga de ferro secundária**  
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**|**Miyazaki,**<br>**2017/2020**|**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
|||verificada por<br>níveis séricos de<br>ferritina sérica e<br>uma saturação de<br>transferrina em<br>jejum de 0,5 ou<br>mais.<br>Avaliar função<br>dos órgãos (fígado<br>e coração) para<br>sobrecarga de<br>ferro em<br>ressonância<br>magnética.|saturação da<br>transferrina para<br>determinar<br>sobrecarga de<br>ferro. Contagens<br>diferenciais de<br>enzimas<br>hepáticas e<br>parâmetros de<br>inflamação,<br>(fibrinogênio e<br>proteína C<br>reativa), para<br>confirmatório.<br>Avaliar função<br>hepática ou<br>cardíaca<br>(ressonância<br>magnética).||R2 ou avaliações<br>cardíacas e<br>hepáticas T2<br>podem ser usadas<br>para ajudar a<br>quantificar a<br>carga de ferro e<br>seu impacto na<br>função orgânica.||indicador útil de<br>sobrecarga de<br>ferro.|síndrome<br>mielodisplásica,<br>dosagem de ferritina<br>sérica e saturação de<br>transferrina para<br>diagnóstico da<br>sobrecarga de ferro.<br>Em complemento, mas<br>não como critério<br>diagnóstico,<br>recomenda-se<br>avaliação da função<br>hepática e cardíaca por<br>ressonância magnética.|
|Tratamento não<br>medicamentoso|Sugere-se que a<br>sobrecarga de<br>ferro após o<br>transplante de<br>células tronco|Flebotomia em<br>pacientes que<br>alcançam<br>independência<br>transfusional e|||||Se viável,<br>considerar a<br>flebotomia até<br>que o nível de<br>ferritina sérica|Recomenda-se, em<br>pacientes com<br>síndrome<br>mielodisplásica,<br>tratamento da|  
66  
**Recomendações das diretrizes clínicas de síndrome mielodisplásica para sobrecarga de ferro secundária**  
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**|**Miyazaki,**<br>**2017/2020**|**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
||seja tratada por<br>flebotomias.|hemoglobina<br>normal/quase.<br>Pós transplante de<br>células-tronco,<br>considerar<br>flebotomia<br>seriada.|||||ou concentração<br>de ferro<br>hepático/<br>cardíaco tenham<br>normalizado.|sobrecarga de ferro<br>com flebotomia, se<br>disponível.|
|Tratamento<br>medicamentoso|Sugere-se que<br>pacientes com<br>histórico de<br>transfusão de<br>mais de 20<br>unidades de<br>hemácias,<br>potenciais<br>candidatos ao<br>transplante de<br>células tronco,<br>devem receber<br>terapia de<br>quelação de ferro<br>antes do<br>transplante.|Considerar terapia<br>tanto com<br>desferroxamina<br>quanto deferasirox<br>em pacientes com<br>histórico de<br>transfusão,<br>potenciais<br>candidatos a<br>transplante de<br>células tronco;<br>pacientes<br>dependentes de<br>transfusão com<br>ferritina sérica ><br>1.000 ng/mL; e<br>pacientes com|Recomenda-se<br>tratar<br>precocemente a<br>pacientes<br>cronicamente<br>transfundidos,<br>com anemia,<br>dependentes de<br>transfusão em<br>qualquer<br>frequência, e<br>pacientes com<br>ferritina sérica<br>elevada (>2.000<br>ng/mL).<br>Deferasirox é a<br>primeira linha de|Recomenda-se<br>quelação de<br>ferro no<br>tratamento da<br>sobrecarga de<br>ferro pós-<br>transfusional em<br>pacientes que<br>tenham<br>expectativa de<br>vida suficiente,<br>necessitem de<br>transfusões<br>regulares e<br>tenham<br>sintomática e<br>em pacientes|Recomenda-se<br>quelação de ferro<br>em todos os<br>pacientes que<br>receberam mais<br>de 20 unidades de<br>hemácias e<br>quando a ferritina<br>for >1.000 μg/l;<br>em pacientes que<br>receberam mais<br>de 20 unidades de<br>hemácias antes do<br>transplante de<br>células tronco.<br>Deferasirox é o<br>medicamento de|Defende-se o<br>início da<br>quelação em<br>pacientes com<br>um prognóstico<br>relativamente<br>favorável (ou<br>seja, de risco<br>baixo ou<br>intermediário)<br>que receberam<br>20-60 unidades<br>de concentrados<br>de hemácias, ou<br>com ferritina<br>sérica > 1.000-<br>2.500 U/l; em||Recomenda-se, em<br>pacientes com<br>síndrome<br>mielodisplásica,<br>terapia de quelação de<br>ferro em histórico de<br>mais de 20 unidades<br>de transfusão de<br>hemácias, candidatos a<br>transplante de células-<br>tronco, dependentes de<br>transfusão com<br>ferritina sérica<br>superior a 1.000<br>ng/mL, e expectativa<br>de vida superior a 1-2<br>anos. O deferasirox|  
67

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Recomendações das diretrizes clínicas de síndrome mielodisplásica para sobrecarga de ferro secundária** -->
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**|**Miyazaki,**<br>**2017/2020**|**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
|||expectativa de<br>vida > 1-2 anos.<br>Suplementação de<br>vitamina C, se<br>necessário, após<br>9–12 meses de<br>terapia de<br>quelação de ferro<br>para evitar o seu<br>efeito pró-<br>oxidante inicial,<br>podendo aumentar<br>a eficácia da<br>desferroxamina,<br>melhorando a<br>função cardíaca.|tratamento, desde<br>que a função<br>renal esteja<br>normal e estável<br>nas primeiras<br>semanas. Se<br>houver<br>intolerância ou<br>quelação<br>insuficiente,<br>desferroxamina<br>ou deferiprona<br>podem ser usados<br>como<br>alternativas.<br>A deferiprona<br>deve ser<br>interrompida em<br>casos de<br>neutropenia.|dependentes de<br>transfusões<br>(pelo menos 2<br>unidades/mês de<br>transfusões por<br>pelo menos 6<br>meses) que<br>tenham uma<br>expectativa de<br>vida de pelo<br>menos 1 ano e<br>tiveram ferritina<br>sérica superior a<br>1000 ng/mL<br>durante pelo<br>menos 2 meses.|escolha para<br>sobrecarga de<br>ferro relacionada<br>à transfusão, mas<br>deve ser<br>interrompido se a<br>ferritina cair <500<br>μg/l e a<br>desferroxamina<br>deve ser<br>interrompida se a<br>ferritina cair<br><1000 μg/l.|pacientes com<br>sobrecarga de<br>ferro<br>transfusional;<br>em pacientes<br>candidatos para<br>transplante de<br>células tronco.||seria a primeira linha<br>de escolha, desde que<br>a função renal esteja<br>normal e estável nas<br>primeiras semanas, e<br>em caso de<br>intolerância ou<br>quelação insuficiente,<br>desferoxamina ou<br>deferiprona podem ser<br>usados como<br>alternativas.|
|Educação do<br>paciente|||||||||
|Casos especiais|||Em pacientes<br>idosos com||||||  
68  
**Recomendações das diretrizes clínicas de síndrome mielodisplásica para sobrecarga de ferro secundária**  
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**|**Miyazaki,**<br>**2017/2020**|**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
||||ferritina<br>levemente<br>elevada e<br>expectativa de<br>vida reduzida<br>(menos de 2<br>anos), a quelação<br>de ferro não deve<br>ser introduzida.||||||
|Monitoramento||Recomenda-se<br>monitoramento<br>clínico e<br>laboratorial<br>durante quelação<br>de ferro pelo<br>menos nas<br>primeiras oito<br>semanas.<br>Avaliar da função<br>renal com<br>dosagens semanais<br>da creatinina<br>sérica.|Avaliar níveis<br>séricos de<br>ferritina e<br>saturação de<br>transferrina em<br>repetição seriada.<br>Avaliar função<br>renal durante o<br>tratamento com<br>deferasirox e<br>deferiprona.|A resposta ao<br>tratamento é<br>avaliada pelos<br>níveis séricos de<br>ferritina, e a<br>meta é manter<br>um nível de<br>500–1000<br>ng/mL.|Estimativas de<br>rotina da carga de<br>ferro podem ser<br>feitas por<br>monitoramento<br>seriado da<br>ferritina e<br>rastreamento de<br>unidades de<br>sangue<br>transfundidas.<br>Os níveis de<br>ferritina devem<br>ser medidos a<br>cada 12 semanas|||Recomenda-se<br>realização de ferritina<br>seriada para<br>monitoramento,<br>acompanhamento da<br>função hepática e renal<br>e por exame de<br>imagem.|  
69  
|**Recomendações das diretrizes clínicas de síndrome mielodisplásica para sobrecarga de ferro secundária**|
|---|  
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**|**Miyazaki,**<br>**2017/2020**|**Killick, 2021**|**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
|---|---|---|---|---|---|---|---|---|
|||A ressonância<br>cardíaca em<br>pacientes com<br>sobrecarga de<br>ferro cardíaca<br>grave.<br>Testes de acuidade<br>visual, lâmpada de<br>fenda exames,<br>fundoscopia e<br>audiometria em<br>pacientes em<br>tratamento<br>prolongado com<br>desferroxamina.|||junto a exames<br>oftalmológicos e<br>auditivos antes de<br>iniciar a terapia e<br>anualmente<br>durante o<br>tratamento.||||
|Recomendações<br>negativas|||Uma biópsia do<br>fígado ou do<br>trato<br>gastrointestinal<br>pode ser<br>realizada, mas<br>geralmente não é<br>recomendada.||A deferiprona não<br>deve ser usada<br>rotineiramente na<br>síndrome<br>mielodisplásica,<br>especialmente<br>quando os<br>neutrófilos basais<br>forem <1.5 x|O deferasirox<br>não deve ser<br>usado em<br>pacientes com<br>insuficiência<br>renal.<br>Deferiprona não<br>deve ser usada<br>em pacientes||Recomenda-se NÃO<br>utilizar deferiprona<br>para o tratamento de<br>pacientes com risco de<br>neutropenia.|  
70  
|**Recomendações das**|**diretrizes clínicas**|**de síndrome mielod**|**isplásica para sobrecarga de ferro secundária**|||
|---|---|---|---|---|---|
||||**Miyazaki,**|||
||**de Witte, 2017**|**Leitch, 2018**|**Valent, 2018**<br> <br>**2017/2020**<br>**Killick, 2021**<br>**Fenaux, 2021**|**DeFilip, 2023**|**Recomendação global**|
||||10<sup>9</sup>/l, somente<br>após consideração<br>cuidadosa com<br>um<br>hematologista.<br>com risco de<br>neutropenia.<br>**Recomendações das diretrizes clínicas de talassemia**|||
|||**Shenoy, 2018**|**Shah, 2022**|**Recomenda**|**ção global**|
|Diagnóstico clínico||||||
|Diagnóstico<br>laboratorial|||A ressonância magnética inicial do coração e do<br>fígado para avaliar a carga de ferro deve ser<br>realizada em pacientes transfundidos que nunca<br>foram avaliados e em crianças assim que<br>conseguirem se deitar em um scanner sem sedação<br>(geralmente antes dos oito anos de idade). Se houver<br>evidência clínica que sugira sobrecarga grave de<br>ferro em crianças muito jovens, pode ser realizada<br>com sedação.<br>Os pacientes não transfundidos devem ser<br>submetidos a avaliação por ressonância magnética<br>do fígado se a ferritina estiver acima de 800 μg/l.|||
|Tratamento não|Consenso de uso|da flebotomia para|redução da|||
|medicamentoso|carga de ferro.|||||  
71  
||**Recomen**|**dações das diretrizes clínicas de talassemia**||
|---|---|---|---|
||**Shenoy, 2018**|**Shah, 2022**|**Recomendação global**|
|Tratamento||Se houver evidência de sobrecarga de ferro (ferritina||
|medicamentoso|Consenso de uso de quelantes de ferro para redução<br>da carga de ferro.|> 500 μg/l ou conteúdo de ferro hepático ><br>5mg/g/peso seco) considerar terapia de quelação.<br>Os pacientes devem iniciar terapia quelante quando<br>realizadas 10-12 transfusões ou quando a ferritina<br>sérica for >1.000 μg/L em duas medições.<br>A terapia combinada deve ser considerada quando a<br>sobrecarga de ferro não é controlada com<br>monoterapia (deferiprona, desferroxamina ou<br>deferasirox).<br>Para pacientes que não realizam transfusão, a terapia<br>de quelação de ferro é realizada em pacientes acima<br>dos 6 anos de idade, ferritina sérica >800 μg/l ou<br>conteúdo de ferro hepático > 5 mg/g/peso seco.|Recomenda-se, para pacientes com talassemia e<br>sobrecarga de ferro, iniciar terapia quelante em<br>pacientes com evidência de sobrecarga de ferro<br>(ferritina > 500 μg/l ou ferro hepático > 5 mg/g/peso<br>seco). Pacientes devem começar a terapia quelante<br>após 10-12 transfusões ou se a ferritina sérica for<br>>1.000 μg/l em duas medições. Considerar terapia<br>combinada se a sobrecarga de ferro não for controlada<br>com monoterapia (deferiprona, desferroxamina ou<br>deferasirox). Para pacientes não transfundidos, iniciar<br>terapia de quelação de ferro em maiores de 6 anos com<br>ferritina sérica >800 μg/l ou ferro hepático > 5<br>mg/g/peso seco.|
|Educação do<br>paciente||||
|Casos especiais||Crianças <6 anos de idade devem inicialmente<br>receber infusões subcutâneas de desferroxamina. Se<br>houver falha, então deferasirox deve ser iniciado o<br>mais rápido possível para evitar o agravamento da<br>sobrecarga de ferro.||  
72  
||**Recom**|**endações das diretrizes clínicas de talassemia**||
|---|---|---|---|
||**Shenoy, 2018**|**Shah, 2022**|**Recomendação global**|
|||Desferroxamina e/ou deferiprona em baixas doses<br>podem ser usadas em pacientes com doença renal<br>crônica (DRC) antes da diálise. Uma vez iniciada a<br>diálise, qualquer um dos quelantes pode ser usado<br>em doses baixas com monitoramento rigoroso da<br>toxicidade.||
|Monitoramento|Considerar medição de ferro cardíaco por<br>ressonância magnética T2* 1 ano após o<br>transplante de células hematopoiéticas em<br>pacientes que tinham sobrecarga moderada ou<br>grave de ferro antes do procedimento.|Os pacientes devem ser avaliados pelo menos uma<br>vez por ano quanto à sobrecarga de ferro e<br>complicações aos órgãos-alvo.<br>A ressonância magnética para avaliação do ferro<br>cardíaco/fígado deve ser realizada em intervalos<br>regulares em adultos e crianças transfundidos.<br>Os pacientes em transfusão devem realizar<br>ressonância magnética do ferro hepático com base<br>nas tendências de aumento consistente da ferritina.<br>Pacientes com sobrecarga de ferro anterior ou que<br>estejam recebendo terapia quelante de ferro devem<br>fazer avaliação regular por ressonância magnética do<br>fígado, pois a ferritina não é confiável.<br>A terapia de quelação de ferro deve ser revista a cada<br>3 meses para avaliar a eficácia e avaliar<br>complicações e adesão ao tratamento.<br>Durante o uso de deferasirox, monitorar alanina<br>aminotrasferase e a função renal em crianças.<br>Durante o uso de desferroxamina, monitorar a|Recomenda-se, para pacientes com talassemia em<br>tratamento de sobrecarga de ferro, realizar medição de<br>ferro cardíaco por ressonância magnética T2* um ano<br>após o transplante de células hematopoiéticas em<br>pacientes com sobrecarga moderada ou grave de ferro.<br>Avaliar anualmente a sobrecarga de ferro e<br>complicações aos órgãos-alvo, com ressonância<br>magnética regular para ferro cardíaco e hepático em<br>adultos e crianças transfundidos. Pacientes com<br>sobrecarga de ferro anterior ou em terapia quelante<br>devem realizar avaliações regulares de ferro hepático.<br>Revisar a terapia de quelação de ferro a cada 3 meses<br>para avaliar eficácia, complicações e adesão.<br>Monitorar ALT e função renal em crianças usando<br>deferasirox, insuficiência renal com desferroxamina e<br>agranulocitose ou neutropenia com deferiprona.|  
73  
|||**Recomendações das diretrizes clínicas de talassemia**||
|---|---|---|---|
||**Shenoy, 2018**|**Shah, 2022**|**Recomendação global**|
|||insuficiência renal. Durante o uso de deferiprona||
|||monitorar se há agranulocitose ou neutropenia.||
|Recomendações||||
|negativas||||

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Diretrizes clínicas e documentos com recomendações para cuidado da sobrecarga de ferro identificadas por meio de busca complementar** -->
||**CADTH, 2007**|**WHO, 2020**|**CADTH, 2023**|**Recomendação global**|
|---|---|---|---|---|
|Diagnóstico clínico|||||
|Diagnóstico<br>laboratorial||Ferritina sérica é recomendada como<br>marcador adequado de acúmulo de<br>ferro, mas deve ser interpretada com<br>outros testes, como saturação de<br>transferrina.|||
|Tratamento não<br>medicamentoso|||||
|Tratamento<br>medicamentoso|Recomenda deferasirox para<br>pacientes que necessitam de<br>quelação de ferro, nos quais a<br>desferroxamina é contraindicada.||Recomenda deferiprona para o<br>tratamento de pacientes com sobrecarga<br>de ferro transfusional devido à doença<br>falciforme ou outras anemias.|Recomenda-se uso de quelantes de ferro<br>em pacientes com sobrecarga de ferro,<br>associada ou não a outras condições.|
|Educação do<br>paciente|||||
|Casos especiais|||Recomenda descontinuação do uso de<br>deferiprona em gestantes e lactantes.||
|Monitoramento|||||  
74  
|**Diretrizes clínicas**|**e documentos com recomendações para cuidado da sobrecarga de ferro id**|**entificadas por meio de busca complementa**|**r**|
|---|---|---|---|
||**CADTH, 2007**<br>**WHO, 2020**|**CADTH, 2023**|**Recomendação global**|
|Recomendações||||
|negativas||||  
75

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Medicamentos recomendados** -->
Com o intuito de atualizar as informações fornecidas sobre os medicamentos recomendados neste PCDT, foi realizada uma busca sistemática da literatura para identificar revisões sistemáticas sobre o mesilato de desferroxamina, deferiprona ou deferasirox para o tratamento da sobrecarga de ferro. Para isso, foi utilizada a pergunta de pesquisa considerando o acrônimo PICOT (População, Intervenção, Comparador, Desfecho e Tipo de estudo) descrito no **Quadro V.**  
**Quadro V. Pergunta de pesquisa PICOT para busca de estudos e documentos com perspectiva nacional sobre sobrecarga de ferro**  
|**População**|Pacientes com sobrecarga de ferro associada ou não à outras condições|
|---|---|
|**Intervenção**|Desferroxamina, deferiprona e/ou deferasirox|
|**Comparador**|Qualquer comparador|
|**Desfecho**|Não se aplica|
|**Tipo de estudo**|Revisões sistemáticas|  
Fonte: autoria própria  
As buscas foram conduzidas nas bases Medline (via PubMed), EMBASE, Cochrane Reviews e Lilacs (via BVS) em 31/07/2023. Para aumentar a sensibilidade da busca, foram utilizados apenas os termos dos medicamentos. Não foram utilizadas restrições de data, idioma ou tipo da publicação (resumo ou texto completo). As estratégias de busca para cada base estão descritas no **Quadro W.**  
**Quadro W. Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas sobre mesilato de desferroxamina, deferiprona ou deferasirox para o tratamento da sobrecarga de ferro**  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
|Medline (via<br>PubMed)|("Deferoxamine"[Mesh] OR (Desferrioxamine) OR (Desferioximine) OR<br>(Deferoxamine B) OR (Desferrioxamine B) OR (Deferoximine) OR<br>(Deferrioxamine B) OR (Desferroxamine) OR (Desferrioxamine B Mesylate)<br>OR (Mesylate, Desferrioxamine B) OR (Deferoxamine Mesilate) OR<br>(Mesilate, Deferoxamine) OR (Deferoxamine Mesylate) OR (Mesylate,<br>Deferoxamine) OR (Deferoxamine Methanesulfonate) OR (Methanesulfonate,<br>Deferoxamine) OR (Desferal)) OR ("Deferiprone"[Mesh] OR( 1,2-Dimethyl-<br>3-hydroxy-4-pyridinone) OR (1,2 Dimethyl 3 hydroxy 4 pyridinone) OR<br>(DMOHPO) OR (1,2-Dimethyl-3-hydroxypyrid-4-one) OR (1,2 Dimethyl 3<br>hydroxypyrid 4 one) OR (3-Hydroxy-1,2-dimethyl-4-pyridinone) OR (3<br>Hydroxy 1,2 dimethyl 4 pyridinone) OR (HDMPP) OR (1,2-Dimethyl-3-<br>hydroxypyridin-4-one) OR (1,2 Dimethyl 3 hydroxypyridin 4 one) OR<br>(Ferriprox)) OR ("Deferasirox"[Mesh] OR (4-(3,5-Bis-(2-hydroxyphenyl)-<br>(1,2,4)-triazol-1-yl)benzoic acid) OR (ICL 670A) OR (ICL-670A) OR<br>(ICL670A) OR (ICL-670) OR (ICL670) OR (ICL 670) OR (Exjade)) AND<br>systematic [sb]|48|
|EMBASE|('deferoxamine'/exp OR 'ba 29837' OR 'ba29837' OR 'deferoxamine b' OR<br>'deferriferrioxamine b' OR 'deferrioxamine' OR 'deferrioxamine b' OR<br>'desferoxamine' OR 'desferrioxamine' OR 'desferrioxamine b' OR 'nsc 527604'|294|  
76  
|**Base de dados**|**Estratégia**<br>OR 'deferoxamine') OR ('deferiprone'/exp OR '1, 2 dimethyl 3 hydroxy 4<br>pyridone' OR '1, 2 dimethyl 3 hydroxypyrid 4 one' OR '1, 2 dimethyl 3<br>hydroxypyridin 4 one' OR '3 hydroxy 1, 2 dimethyl 1, 4 dihydro 4 pyridinone'<br>OR '3 hydroxy 1, 2 dimethyl 1, 4 dihydropyridin 4 one' OR '3 hydroxy 1, 2<br>dimethyl 4 pyridinone' OR '3 hydroxy 1, 2 dimethyl 4 pyridone' OR '3 hydroxy<br>1, 2 dimethylpyrid 4 one' OR 'apo 066' OR 'apo 66' OR 'apo066' OR 'apo66'<br>OR 'cgp 37391' OR 'cgp37391' OR 'cp 020' OR 'cp 20' OR 'cp020' OR 'cp20'<br>OR 'crmd 001' OR 'crmd001' OR 'deferidone' OR 'deferrum' OR 'deferum' OR<br>'ferriprox' OR 'kelfer' OR 'l 1' OR 'upkanz' OR 'deferiprone') OR<br>('deferasirox'/exp OR '4 [3, 5 bis (2 hydroxyphenyl) 1, 2, 4 triazol 1 yl] benzoic<br>acid' OR '4 [3, 5 bis (2 hydroxyphenyl) 1h 1, 2, 4 triazol 1 yl] benzoic acid' OR<br>'cgp 72670' OR 'cgp72670' OR 'desirox' OR 'dst 0509' OR 'dst0509' OR<br>'exjade' OR 'icl 670' OR 'icl 670a' OR 'icl670' OR 'icl670a' OR 'jadenu' OR<br>'jadenu sprinkle' OR 'deferasirox') AND ('systematic review'/de OR 'systematic<br>review (topic)'/de OR (('comprehensive':ti,ab,kw OR 'integrated':ti,ab,kw OR<br>'integrative':ti,ab,kw OR 'mapping':ti,ab,kw OR 'methodology':ti,ab,kw OR<br>'narrative':ti,ab,kw OR 'scoping':ti,ab,kw OR 'systematic':ti,ab,kw) AND<br>('search':ti,ab,kw OR 'searched':ti,ab,kw OR 'searches':ti,ab,kw OR<br>'studies':ti,ab,kw) AND ('cinahl':ti,ab,kw OR 'cochrane':ti,ab,kw OR<br>'embase':ti,ab,kw OR 'psycinfo':ti,ab,kw OR 'pubmed':ti,ab,kw OR<br>'medline':ti,ab,kw OR 'scopus':ti,ab,kw OR 'web of science':ti,ab,kw OR<br>'bibliographic review':ti,ab,kw OR 'bibliographic reviews':ti,ab,kw OR<br>'literature review':ti,ab,kw OR 'literature reviews':ti,ab,kw OR 'literature<br>search':ti,ab,kw OR 'literature searches':ti,ab,kw OR 'narrative review':ti,ab,kw<br>OR 'narrative reviews':ti,ab,kw OR 'qualitative review':ti,ab,kw OR 'qualitative<br>reviews':ti,ab,kw OR 'quantitative review':ti,ab,kw OR 'quantitative<br>reviews':ti,ab,kw)) OR 'comprehensive review':ti,ab,kw OR 'comprehensive<br>reviews':ti,ab,kw OR 'comprehensive search':ti,ab,kw OR 'comprehensive<br>searches':ti,ab,kw OR 'critical review':ti,ab,kw OR 'critical reviews':ti,ab,kw<br>OR 'evidence assessment':ti,ab,kw OR 'evidence review':ti,ab,kw OR<br>'exploratory review':ti,ab,kw OR 'framework synthesis':ti,ab,kw OR 'integrated<br>review':ti,ab,kw OR 'integrated reviews':ti,ab,kw OR 'integrative<br>review':ti,ab,kw OR 'integrative reviews':ti,ab,kw OR 'mapping<br>review':ti,ab,kw OR 'meta-review':ti,ab,kw OR 'meta-synthesis':ti,ab,kw OR<br>'methodology review':ti,ab,kw OR 'mixed methods review':ti,ab,kw OR 'mixed<br>methods synthesis':ti,ab,kw OR (overview NEAR/4 reviews) OR<br>('prisma':ti,ab,kw AND 'preferred':ti,ab,kw) OR 'prisma-p':ti,ab,kw OR<br>'prognostic review':ti,ab,kw OR 'psychometric review':ti,ab,kw OR 'rapid<br>evidence assessment':ti,ab,kw OR 'rapid literature review':ti,ab,kw OR 'rapid|**Resultados**|
|---|---|---|  
77  
|**Base de dados**|**Estratégia**<br>literature search':ti,ab,kw OR 'rapid realist':ti,ab,kw OR 'rapid review':ti,ab,kw<br>OR 'rapid reviews':ti,ab,kw OR 'realist review':ti,ab,kw OR 'review of<br>reviews':ti,ab,kw OR 'scoping review':ti,ab,kw OR 'scoping reviews':ti,ab,kw<br>OR 'scoping study':ti,ab,kw OR 'state of the art review':ti,ab,kw OR 'systematic<br>evidence map':ti,ab,kw OR 'systematic evidence mapping':ti,ab,kw OR<br>'systematic literature':ti,ab,kw OR 'systematic medline':ti,ab,kw OR 'systematic<br>pubmed':ti,ab,kw OR 'systematic review':ti,ab,kw OR 'systematic<br>reviews':ti,ab,kw OR 'systematic search':ti,ab,kw OR 'systematic<br>searches':ti,ab,kw OR 'systematical literature review':ti,ab,kw OR 'systematical<br>review':ti,ab,kw OR 'systematical reviews':ti,ab,kw OR 'systematically<br>identified':ti,ab,kw OR 'systematically review':ti,ab,kw OR 'systematically<br>reviewed':ti,ab,kw OR 'umbrella review':ti,ab,kw OR 'umbrella<br>reviews':ti,ab,kw OR '13616137':is OR 'cochrane database of systematic<br>reviews'/jt) AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|**Resultados**|
|---|---|---|
|Cochrane Reviews|#1 - MeSH descriptor: [Deferoxamine] explode all trees<br>#2 - (Desferrioxamine B) OR (Deferoximine) OR (Desferroxamine) OR<br>(Deferrioxamine B) OR (Desferrioxamine) OR (Deferoxamine B) OR<br>(Desferioximine) OR (Mesylate, Deferoxamine) OR (Methanesulfonate,<br>Deferoxamine) OR (Deferoxamine Mesilate) OR (Mesylate, Desferrioxamine<br>B) OR (Deferoxamine Mesylate) OR (Desferrioxamine B Mesylate) OR<br>(Mesilate, Deferoxamine) OR (Deferoxamine Methanesulfonate) OR<br>(Desferal)<br>#3 - MeSH descriptor: [Deferiprone] explode all trees<br>#4 - (3 Hydroxy 1 2 dimethyl 4 pyridinone) OR (3 Hydroxy 1 2 dimethyl 4<br>pyridinone) OR (1 2 Dimethyl 3 hydroxypyridin 4 one) OR (1 2 Dimethyl 3<br>hydroxy 4 pyridinone) OR (1 2 Dimethyl 3 hydroxy 4 pyridinone) OR (1 2<br>Dimethyl 3 hydroxypyridin 4 one) OR (1 2 Dimethyl 3 hydroxypyrid 4 one)<br>OR (DMOHPO) OR (1 2 Dimethyl 3 hydroxypyrid 4 one) OR (HDMPP) OR<br>(Ferriprox)<br>#5 - MeSH descriptor: [Deferasirox] explode all trees<br>#6 - (Exjade) OR (ICL 670A) OR (ICL 670A) OR (4 (3 5 Bis (2<br>hydroxyphenyl) (1 2 4) triazol 1 yl)benzoic acid) OR (ICL 670) OR (ICL670)<br>OR (ICL670A) OR (ICL 670)<br>#7 - #1 OR #2 OR #3 OR #4 OR #5 OR #6|23|
||(mh: "Desferroxamina" OR (Deferoxamine) OR (Deferoxamina) OR<br>(Desferroxamina) OR mh:D02.092.570.394.265$ mh:D02.241.511.372.265$)|65|
|Lilacs (via BVS)|OR (mh: "Deferiprona" OR (Deferiprone) OR (Deferiprona) OR (1,2-Dimetil-<br>3-Hidroxi-4-Piridinona) OR (1,2-Dimetil-3-Hidroxipiri-4-dona) OR (1,2-<br>Dimetil-3-Hidroxipiridi-4-nona) OR (3-Hidroxi-1,2-Dimetil-4-Piridinona) OR||  
78  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
||(DMOHPO) OR (Ferriprox) OR (HDMPP) OR mh:D03.383.725.791.298$)<br>OR (mh: "Deferasirox" OR (Exjade) OR (ICL 670) OR (ICL 670ª) OR (ICL-<br>670) OR (ICL-670A) OR (ICL670A) OR mh: D02.241.223.100.250$ OR||
||mh:D02.455.426.559.389.127.266$ OR mh:D03.383.129.799.363$)||  
Fonte: autoria própria  
A elegibilidade dos estudos identificados por meio de busca sistemática foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> . Na segunda etapa, realizou-se a leitura de texto completo, mantendo-se revisões sistemáticas que abordem um dos medicamentos recomendados neste PCDT – mesilato de desferroxamina, deferiprona ou deferasirox – para o tratamento da sobrecarga de ferro. As divergências foram resolvidas em consenso.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: pacientes (adultos ou crianças) diagnosticados com sobrecarga de ferro;  
- (b) Tipo de intervenção: mesilato de desferroxamina, deferiprona ou deferasirox - administradas em qualquer dose;  
- (c) Tipos de estudos: revisões sistemáticas com busca sistematizada em pelo menos duas bases de dados e que  
apresentaram avaliação de risco de viés dos estudos primários incluídos;  
- (d) Comparador: qualquer intervenção;  
- (d) Desfechos: qualquer desfecho;  
- (e) Idioma: apenas textos publicados em português, inglês ou espanhol.  
Resumos, anais de congresso, ou quaisquer outras publicações que não apresentassem o texto completo na íntegra, foram excluídos.

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Resultados da busca** -->
Foram identificadas 430 publicações. Após a exclusão das duplicatas (n = 23) e triagem pela leitura de títulos e resumos, 46 publicações foram selecionadas para a leitura do texto completo ( **Figura G** ). Trinta e cinco estudos foram excluídos por leitura de texto completo. Esses estudos e os motivos da exclusão são descritos no **Quadro X.** No total, foram incluídas 11 publicações.  
79  
**Figura G. Fluxograma de seleção de revisões sistemáticas sobre mesilato de desferroxamina, deferiprona ou deferasirox para o tratamento da sobrecarga de ferro**  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Bases de dados (n = 430)<br>Referências removidas antes do<br>PubMed (n = 48)<br>processo de seleção:<br>Embase (n = 294)<br>Duplicatas (n = 23)<br>Cochrane Reviews (n = 23)<br>Lilacs (n = 65)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 359)<br>(n = 407)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 48)  (n = 2)<br>Referências  avaliadas por  texto<br>completo  Referências excluídas: (n = 35)<br>(n = 46)<br>Estudos incluídos na revisão<br>(n = 11)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro X. Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.**  
|**Estudo**|**Motivo da**<br>**exclusão**|
|---|---|
|Walczak et al. Cost-Utility Analysis of Deferasirox for the Treatment of Iron Overload Due to|Resumo de|
|Frequent Blood Transfusions in the Children and Adolescents. VALUE IN HEALTH 16 (2013)|congresso|  
80  
|**Estudo**|**Motivo da**<br>**exclusão**|
|---|---|
|A323–A636||
|Oliva EN, Huey K, Deshpande S, Turner M, Chitnis M, Schiller E, et al. PCN78 A Set of Systematic<br>and Targeted Reviews to Identify the Burden of Iron Chelation Therapy in Myelodysplastic<br>Syndromes. Value Heal [Internet]. 2021;24:S33–4.|Resumo de<br>congresso|
|Romadhon PZ, Ashariati A, Bintoro SUY, Thaha M, Suryantoro SD, Windradi C, et al. Markers of<br>Renal Complications in Beta Thalassemia Patients with Iron Overload Receiving Chelation Agent<br>Therapy: A Systematic Review. J Blood Med [Internet]. 2022; 13:725–38.|Não apresenta<br>avaliação de risco<br>de viés|
|Meerpohl JJ, Antes G, Rücker G, McLeod C, Fleeman N, Niemeyer C, et al. Deferasirox for<br>managing transfusional iron overload in people with sickle cell disease. Cochrane Database Syst Rev<br>[Internet]. 2008;(4).|Não apresenta<br>avaliação de risco<br>de viés|
|Guariglia R, Martorelli MC, Pietrantuono C, Villani O, Mansueto G, D’Auria F, et al. Hematologic<br>response in myelodysplastic syndromes (MDS) receiving deferasirox as iron chelation therapy:<br>Updated systematic review of the published cases, including personal experience. Haematologica<br>[Internet]. 2011; 96:163.|Não apresenta texto<br>completo|
|Li J, Wang P, Li X, Wang Q, Zhang J, Lin Y. Cost-Utility Analysis of four Chelation Regimens for<br>β-thalassemia Major: A Chinese perspective. Mediterr J Hematol Infect Dis [Internet]. 2020;12(1).<br>Available at: https://www.embase.com/search/results?|Não é revisão<br>sistemática|
|Li J, Lin Y, Li X, Zhang J. Economic evaluation of chelation regimens for β-Thalassemia Major: A<br>systematic review. Mediterr J Hematol Infect Dis [Internet]. 2019;11(1).|Revisão sistemática<br>de estudo<br>econômico|
|Caro JJ, Huybrechts KF, Green TC. Estimates of the effect on hepatic iron of oral deferiprone<br>compared with subcutaneous desferrioxamine for treatment of iron overload in thalassemia major: A<br>systematic review. BMC Blood Disord [Internet]. 2002;2.|Não apresenta<br>avaliação de risco<br>de viés|
|Huang V, Luini C, El-Ali A, Kessabi S. Iron chelation therapy: A review of the literature on the<br>issues and importance of adherence to treatment in iron overload. Blood [Internet].<br>2015;126(23):4748. A|Não apresenta texto<br>completo|
|Ahmed W, Rethmeier L, Nottmeier M, Pollock RF. EE662 Cost-Effectiveness of Iron Chelation<br>Therapies for the Treatment of Transfusional Iron Overload in β-Thalassaemia, Sickle Cell Disease,<br>and Myelodysplastic Syndrome: A Literature Review. Value Heal [Internet]. 2022;25(12):S187.|Não é revisão<br>sistemática|
|Sunil Bhandari SB, Emmeline Igboekwe EI, Noemi Toiber Temin NTT, Khashayar Azimpour KA,<br>Jonathan Alsop JA, Caroline Fradette CF, et al. REAL-WORLD CHANGES IN KIDNEY<br>FUNCTION FOR PATIENTS WITH SICKLE CELL DISEASE OR OTHER ANAEMIAS<br>RECEIVING IRON CHELATION THERAPY IN THE US. HemaSphere [Internet]. 2023;7:43–4.|Não é revisão<br>sistemática|
|Geneen LJ, Dorée C, Estcourt LJ. Interventions for improving adherence to iron chelation therapy in<br>people with sickle cell disease or thalassaemia. Cochrane Database Syst Rev [Internet]. 2023;(3).|Não apresenta texto<br>completo|
|Xu Y, Xia S-J, Zhang S-H, Jiang H. Iron chelation therapy in beta-thalassemia major: a systematic<br>review with meta-analysis. Chinese Pharm J [Internet]. 2013;48(21):1875–80.|Não apresenta texto<br>completo|
|Scoglio M, Cappellini MD, D’angelo E, Bianchetti MG, Lava SAG, Agostoni C, et al. Kidney<br>tubular damage secondary to deferasirox: Systematic literature review. Children [Internet].|81<br>Não apresenta<br>avaliação de risco|  
|**Estudo**|**Motivo da**<br>**exclusão**|
|---|---|
|2021;8(12).|de viés|
|Azman NF, Abdullah W-Z, Mohamad N, Bahar R, Johan MF, Diana R, et al. Practice of iron<br>chelation therapy for transfusion-dependent thalassemia in Southeast Asia. Asian Biomed [Internet].<br>2016;10(6):537–47.|Não é revisão<br>sistemática|
|Mamtani M, Kulkarni H. Influence of iron chelators on myocardial iron and cardiac function in<br>transfusion-dependent thalassaemia: a systematic review and meta-analysis. Br J Haematol. junho de<br>2008;141(6):882–90.|Não apresenta<br>avaliação de risco<br>de viés|
|Kuo KHM, Mrkobrada M. A systematic review and meta-analysis of deferiprone monotherapy and<br>in combination with deferoxamine for reduction of iron overload in chronically transfused patients<br>with β-thalassemia. Hemoglobin. 2014;38(6):409–21.|Não apresenta texto<br>completo|
|McLeod C, Fleeman N, Kirkham J, Bagust A, Boland A, Chu P, et al. Deferasirox for the treatment<br>of iron overload associated with regular blood transfusions (transfusional haemosiderosis) in patients<br>suffering with chronic anaemia: a systematic review and economic evaluation. Health Technol<br>Assess. janeiro de 2009;13(1):iii–iv, ix–xi, 1–121.|Não apresenta<br>avaliação de risco<br>de viés|
|Khorasani E, Ghaffari Darab M, Seyedifar M. Cost-Utility Of New Film-Coated Tablet Formulation<br>Of Deferasirox Versus Deferoxamine Among Major B-Thalassemia Patients In Iran. Value Heal<br>[Internet]. 2018;21:S445.|Não é revisão<br>sistemática|
|Walczak J, Lipińska M, Jarosz J, Moczyński W,͆la¸zak B, Laczewski T. Clinical effectiveness<br>analysis of deferasirox for the treatment of iron overload due to frequent blood transfusions. Value<br>Heal [Internet]. 2013;16(7):A377–8.|Não apresenta texto<br>completo|
|Luangasanatip N, Chaiyakunapruk N, Upakdee N, Wong P. Comparative cost-effectiveness analyses<br>of iron chelating therapies in transfusion-dependent thalassaemia population in Thailand. Value Heal<br>[Internet]. 2010;13(7):A565.|Não apresenta texto<br>completo|
|Fabron Júnior A, Tricta F. Terapia quelante oral com deferiprona em pacientes com sobrecarga de<br>ferro TT - Oral iron chelator therapy with deferiprone in patients with overloaded iron. Rev bras<br>hematol hemoter [Internet]. 2003;25(3):177–88.|Não é revisão<br>sistemática|
|Souto EX. Tratamento de suporte e quelação de ferro em pacientes com síndromes mielodisplásicas<br>TT - Supportive care, tranfusion and chelation therapy for patients with myelodysplastic syndromes.<br>Rev bras hematol hemoter [Internet]. 2006;28(3):204–9.|Não é revisão<br>sistemática|
|Salud I de ET en. Evaluación de efectividad y seguridad de deferasirox en Hemosiderosis<br>Transfusional TT - Evaluation of effectiveness and safety of deferasirox in Hemosiderosis<br>Transfusional [Internet]. 2013.|Não é revisão<br>sistemática|
|Cançado RD. Sobrecarga e quelação de ferro na anemia falciforme TT - Iron overload and iron<br>chelation in sickle cell disease. Rev bras hematol hemoter [Internet]. 2007;29(3):316–26.|Não é revisão<br>sistemática|
|Xu Y, Zhang S, Xia S, Jiang H. Safety of iron chelator in the treatment of beta-thalassemia major: A<br>systematic review with meta-analysis. Pharm Care Res [Internet]. 2014;14(5):382–|Não apresenta texto<br>completo|
|Meerpohl JJ, Antes G, Rücker G, McLeod C, Fleeman N, Niemeyer C, et al. Deferasirox for<br>managing iron overload in patients with myelodysplastic syndrome. Cochrane Database Syst Rev<br>[Internet]. 2008;(4).|82<br>Não apresenta texto<br>completo|  
|**Estudo**|**Motivo da**<br>**exclusão**|
|---|---|
|Ballas SK, Zeidan AM, Duong VH, DeVeaux M, Heeney MM. The effect of iron chelation therapy<br>on overall survival in sickle cell disease and β-thalassemia: A systematic review. Am J Hematol.<br>julho de 2018;93(7):943–52.|Não apresenta<br>avaliação de risco<br>de viés|
|Fortin PM, Fisher SA, Madgwick K V, Trivella M, Hopewell S, Doree C, et al. Interventions for<br>improving adherence to iron chelation therapy in people with sickle cell disease or thalassaemia.<br>Cochrane database Syst Rev. maio de 2018;5(5):CD012349.|Intervenções<br>diferentes das<br>propostas na<br>PICOT|
|Lal A, Sheth S, Gilbert S, Kwiatkowski JL. Thalassemia management checklists: Quick reference<br>guides to reduce disparities in the care of patients with transfusion-dependent thalassemia. Blood<br>[Internet]. 2018;132.|Não é revisão<br>sistemática|
|Yampayon K, Anantachoti P, Chongmelaxme B, Yodsurang V. Genetic polymorphisms influencing<br>deferasirox pharmacokinetics, efficacy, and adverse drug reactions: a systematic review and meta-<br>analysis. Front Pharmacol [Internet]. 2023;14.|Intervenções<br>diferentes das<br>propostas na<br>PICOT|
|Badfar G, Mansouri A, Shohani M, Karimi H, Khalighi Z, Rahmati S, et al. Hearing loss in Iranian<br>thalassemia major patients treated with deferoxamine: A systematic review and meta-analysis. Casp J<br>Intern Med [Internet]. 2017;8(4):239–49.|Não apresenta<br>avaliação de risco<br>de viés|
|Kattamis A, Kwiatkowski J, Tricta F, Igboekwe E, Fradette C, Piga A, et al. Rationale For The Use<br>Of Combination Chelation Therapy In Patients With Thalassemia Syndromes Or Sickle Cell Anemia:<br>A Systematic Literature Review. HemaSphere [Internet]. 2022; 6:3852–3.|Não apresenta texto<br>completo|
|Piga A, Sheth S, Kattamis A, Tricta F, Igboekwe E, Fradette C, et al. Efficacy and Safety Of<br>Combination Iron Chelation Therapy With Deferiprone And Deferasirox In Patients With B-<br>Thalassemia Major: A Systematic Literature Review. HemaSphere [Internet]. 2022; 6:2650–1. =|Não apresenta texto<br>completo|
|Ballas SK, Duong VH, Deveaux M, Zeidan AM. A systematic review of the effect of iron chelation|Não apresenta texto|
|therapy on survival in patients with sickle cell disease and β-thalassemia. Blood [Internet]. 2017;130.|completo|  
O **Quadro Y** lista as revisões sistemáticas incluídas e o **Quadro Z** caracteriza estas revisões de acordo com o desenho dos estudos incluídos, intervenção e comparadores, além de um resumo dos achados de cada comparação. As conclusões dessas revisões subsidiaram a redação das recomendações da seção de terapia combinada, deste PCDT, especialmente a seção _Tratamento medicamentoso_ .  
**Quadro Y. Lista de revisões sistemáticas sobre mesilato de desferroxamina, deferiprona ou desferasirox para o tratamento da sobrecarga de ferro incluídas.**  
|**Revisões**|
|---|
|Fisher SA, Brunskill SJ, Doree C, Gooding S, Chowdhury O, Roberts DJ. Desferrioxamine mesylate for managing|
|transfusional iron overload in people with transfusion‐dependent thalassaemia. Cochrane Database Syst Rev [Internet].|
|2013;(8). (a)|
|Fisher SA, Brunskill SJ, Doree C, Chowdhury O, Gooding S, Roberts DJ. Oral deferiprone for iron chelation in people with|
|thalassaemia. Cochrane Database Syst Rev [Internet]. 2013;(8). (b)|  
83  
**Revisões** Bollig C, Schell LK, Rücker G, Allert R, Motschall E, Niemeyer CM, et al. Deferasirox for managing iron overload in people with thalassaemia. Cochrane Database Syst Rev [Internet]. 2017;(8). Meerpohl JJ, Schell LK, Rücker G, Motschall E, Fleeman N, Niemeyer CM, et al. Deferasirox for managing transfusional iron overload in people with sickle cell disease. Cochrane Database Syst Rev [Internet]. 2014;(5). Qadah T. Deferasirox versus deferoxamine in managing iron overload in patients with Sickle Cell Anaemia: a systematic review and meta-analysis. J Int Med Res. dezembro de 2022;50(12):3000605221143290.  
Maggio A, Filosa A, Vitrano A, Aloj G, Kattamis A, Ceci A, et al. Iron chelation therapy in thalassemia major: a systematic review with meta-analyses of 1520 patients included on randomized clinical trials. Blood Cells Mol Dis. outubro de 2011;47(3):166–75. Roberts DJ, Brunskill SJ, Doree C, Williams S, Howard J, Hyde CJ. Oral deferiprone for iron chelation in people with thalassaemia. Cochrane database Syst Rev. julho de 2007;(3):CD004839. Meerpohl JJ, Antes G, Rücker G, Fleeman N, Niemeyer C, Bassler D. Deferasirox for managing transfusional iron overload in people with sickle cell disease. Cochrane database Syst Rev. agosto de 2010;(8):CD007477. Saleem A, Waqar E, Shuja SH, Naeem U, Moeed A, Rais H, et al. No difference in myocardial iron concentration and serum ferritin with deferasirox and deferiprone in pediatric patients with hemoglobinopathies: A systematic review and meta-analysis. Transfus Clin Biol J la Soc Fr Transfus Sang. fevereiro de 2023;30(1):69–74. Roberts DJ, Rees D, Howard J, Hyde C, Alderson P, Brunskill S. Desferrioxamine mesylate for managing transfusional iron overload in people with transfusion-dependent thalassaemia. Cochrane database Syst Rev. outubro de 2005;(4):CD004450. Meerpohl JJ, Antes G, Rücker G, Fleeman N, Motschall E, Niemeyer CM, et al. Deferasirox for managing iron overload in people with thalassaemia. Cochrane database Syst Rev. fevereiro de 2012;(2):CD007476.  
84  
**Quadro Z.** Caracterização e achados das revisões sistemáticas incluídas, sobre tratamento de sobrecarga de ferro associada ou não a outras condições.  
|**Autor, ano**|**Roberts, 2005**|**Roberts, 2007**|**Meerpohl, 2010**|**Maggio, 2011**|**Meerpohl, 2012**|**Qadah, 2022**|
|---|---|---|---|---|---|---|
|**Número de**|||**_Parte 1_**||||
|**estudos**<br>**incluídos**|08|10|01|16|04|03|
|**Desenho dos**<br>**estudos**|Ensaios clínicos<br>randomizados (ECRs) e<br>quasi-randomizados|ECRs|ECRs|ECRs|ECRs|ECRs, pesquisas<br>transversais e pesquisas<br>experimentais|
|**Critérios de**<br>**inclusão**|Estudos comparando<br>desferroxamina com<br>placebo; com outro<br>quelante de ferro; ou<br>dois esquemas de<br>desferroxamina, em<br>pessoas com talassemia<br>dependente de<br>transfusão|ECRs comparando a<br>deferiprona com outro<br>quelante de ferro; ou<br>comparando dois<br>esquemas de deferiprona,<br>em pessoas com<br>talassemia dependente de<br>transfusão.|ECRs comparando<br>deferasirox com<br>nenhuma terapia ou<br>placebo ou com outro<br>esquema de tratamento<br>com quelante de ferro|Pacientes com qualquer<br>idade com talassemia<br>maior dependente de<br>transfusão, de qualquer<br>local do mundo.|ECRs comparando<br>deferasirox com nenhuma<br>terapia, placebo ou com<br>outro tratamento quelante<br>de ferro|ECRs publicados entre<br>2007 e 2020 que<br>comparam a eficácia de<br>deferasirox e<br>desferroxamina|
|**Critérios de**<br>**Exclusão**|Outros desenhos de<br>estudo ou sem desfechos<br>relevantes para a revisão|Outros desenhos de<br>estudo / não inclusão de<br>um braço comparador<br>elegível / não inclusão de<br>resultados que relevantes<br>para revisão|Pacientes com outras<br>doenças / Revisão ou<br>editorial ou comentário<br>ou outra forma de artigo<br>publicado / outra<br>intervenção que não<br>inclua deferasirox /<br>estudos de custo-<br>efetividade|Ensaios de fase II /<br>Estudos que apontam<br>dados ou relatos de casos|Outras intervenções/<br>Pessoas com outras<br>doenças além da<br>talassemia / Outros<br>desenhos de estudo|Não ser escrito em inglês<br>ou estudos em animais /<br>não ser ECRs / não ser<br>relevante / falta de<br>medidas de intervenção /<br>não atender os outros<br>critérios de inclusão /<br>dados não recuperáveis.|  
85  
|**Autor, ano**|**Roberts, 2005**|**Roberts, 2007**|**Meerpohl, 2010**|**Maggio, 2011**|**Meerpohl, 2012**|**Qadah, 2022**|
|---|---|---|---|---|---|---|
|**Total de**<br>**Participantes**|334|398|203|1520|704|791|
|**Intervenção**|Desferroxamina|Deferiprona|Deferasirox|Desferroxamina e<br>deferiprona, isolados|Deferasirox|Deferasirox|
|**Comparadores**<br>**ou comparações**|Desferroxamina X<br>Placebo<br>Desferroxamina X<br>deferiprona<br>Desferroxamina X<br>desferroxamina +<br>deferiprona<br>Desferroxamina X<br>deferiprona X<br>desferroxamina +<br>deferiprona<br>Diferentes esquemas de<br>administração de|Deferiprona X placebo<br>Deferiprona X outro<br>tratamento quelante de<br>ferro<br>Esquema de deferiprona<br>A<br>X esquema de<br>deferiprona B|Deferasirox X nenhuma<br>terapia ou placebo.<br>Deferasirox X outro<br>esquema de tratamento<br>com quelante de ferro|Desferroxamina X<br>placebo ou via diferente<br>de administração<br>Deferiprona X<br>desferroxamina<br>Deferasirox X<br>desferroxamina<br>Desferroxamina +<br>deferiprona X<br>desferroxamina ou<br>deferiprona isolados<br>Terapia sequencial:<br>Deferiprona +<br>desferroxamina X|Deferasirox X nenhuma<br>terapia ou placebo<br>Deferasirox X outro<br>tratamento quelante de<br>ferro|Desferroxamina|
||desferroxamina|||desferroxamina ou<br>deferiprona isolados|||
|**Desfechos**|Desfecho primário:<br>Mortalidade.<br>Desfechos secundários:<br>1. Evidência de redução<br>de danos aos órgãos-|Desfecho primário:<br>Mortalidade.<br>Desfecho secundário:<br>1. Evidência de redução<br>de danos aos órgãos-alvo|Desfecho primário:<br>Mortalidade global<br>medida em qualquer<br>momento<br>Desfecho secundário:|1. Fração de ejeção<br>2. Concentração de ferro<br>no fígado no final<br>de tratamento<br>3. Concentração de ferro|Desfecho primário:<br>Mortalidade global em<br>qualquer momento<br>Desfecho secundário:<br>1. Redução de danos em|Concentração de ferro no<br>tecido hepático, ferritina<br>sérica e/ou concentração<br>de ferro no miocárdio.|
||alvo.|devido à deposição de|1. Redução de danos em|miocárdico ao final do|órgãos-alvo devido à||  
86  
|**Autor, ano**|**Roberts, 2005**|**Roberts, 2007**|**Meerpohl, 2010**|**Maggio, 2011**|**Meerpohl, 2012**|**Qadah, 2022**|
|---|---|---|---|---|---|---|
||2. Medidas de<br>sobrecarga de ferro.<br>3. Eventos adversos ou|ferro<br>2. Medidas de sobrecarga<br>de ferro|órgãos-alvo devido à<br>deposição de ferro<br>2. Medidas de sobrecarga|ensaio<br>4. Ferritina sérica como<br>diferença entre o valor|deposição de ferro<br>2. Medidas de sobrecarga<br>de ferro||
||toxicidade devido ao|3. Medidas de excreção|de ferro|final versus o valor basal|3. Medidas de excreção||
||tratamento com|de ferro (urina e fezes)|3. Medidas de excreção|5. Ferro urinário|de ferro||
||desferroxamina.|durante 24 horas|de ferro (urina e fezes)|excreção.|4. Quaisquer eventos||
||4. Conformidade do|4. Eventos adversos|durante 24 horas||adversos||
||participante com o|5. Conformidade do|4. Quaisquer eventos||5. Satisfação do||
||tratamento.|participante com o|adversos||participante||
||5. Custo da|tratamento de quelação de|5. Satisfação do||6. Custo da intervenção||
||desferroxamina|ferro<br>6. Custo das intervenções|participante<br>6. Custo da intervenção<br>por ano||por ano.||
||Desferroxamina|Não houve uma diferença|Comparando eficácia e|Meta-análise sugere|Os estudos mostraram|Meta-análise mostrou que|
||comparada à|consistente na redução da|segurança do deferasirox|menores concentrações|que o deferasirox|a sobrecarga de ferro no|
||deferiprona ou a um|sobrecarga de ferro entre|e da desferroxamina,|finais de ferro no fígado|promove a excreção de|tecido hepático não foi|
||esquema diferente, não|os tratamentos, exceto na|após 12 meses, a redução|durante o tratamento|ferro com segurança|significativamente|
|**Principais**<br>**resultados**|resultou em diferenças<br>estatisticamente<br>significativas nas|excreção urinária de<br>ferro, onde deferiprona<br>foi favorecida em um|da ferritina sérica e a<br>concentração de ferro foi<br>semelhante em ambos os|associado em<br>comparação com a<br>monoterapia (p <|aceitável. Nos ensaios de<br>fase II e fase III, a<br>eficácia do deferasirox|diferente entre os grupos<br>deferasirox e<br>desferroxamina. No|
||medidas de sobrecarga|ensaio e desferroxamina|grupos, sem diferenças|0,0001), aumento nos|foi semelhante ou|entanto, a sobrecarga de|
||de ferro.|em três. A medida da|estatisticamente|níveis de ferritina sérica|superior à da|ferro medida pela|
||A adesão foi menor para|excreção urinária|significativas. A|durante o tratamento com|desferroxamina no|ferritina sérica foi|
||a desferroxamina do que|subestimou a quantidade|concentração de ferro no|deferasirox 5, 10 e 20|subgrupo altamente|significativamente menor|
||para a deferiprona e não|total de ferro excretada|fígado também foi|mg/kg em comparação|sobrecarregado de ferro,|no grupo desferroxamina|
||houve diferença na|pela desferroxamina.|semelhante entre os|com os grupos tratados|com uma proporção|(DMP, 278,13 mg/L; IC|  
87  
|**Autor, ano**|**Roberts, 2005**|**Roberts, 2007**|**Meerpohl, 2010**|**Maggio, 2011**|**Meerpohl, 2012**|**Qadah, 2022**|
|---|---|---|---|---|---|---|
||comparação com<br>desferroxamina e<br>deferiprona combinadas.|Eventos adversos foram<br>comuns em todos os<br>grupos, sendo mais|grupos e houve aumentos<br>leves na creatinina com<br>deferasirox, e dor|com desferroxamina (p <<br>0,00001, p < 0,00001 e p<br>= 0,002), mas nenhuma|média de 1 mg de<br>deferasirox para 1,8 mg<br>de desferroxamina,|95% 36,69 a 519,57). A<br>concentração de ferro<br>miocárdico não|
||Eventos adversos foram<br>significativamente<br>menos prováveis com a|prováveis com<br>deferiprona em um ensaio<br>específico, com RR 2,24|abdominal e diarreia<br>foram mais comuns RR<br>1,64 (IC 95%: 0,98 a|diferença<br>estatisticamente<br>significativa durante o|correspondendo a uma<br>dose média de 28,2<br>mg/dia e 51,6 mg/dia,|apresentou diferença<br>significativa entre<br>desferroxamina e|
||desferroxamina do que|(IC 95%: 1,19 a 4,23).|2,74). Eventos adversos|tratamento com 30|respectivamente.|deferasirox.|
||com a deferiprona, com<br>um RR 0,45 (IC 95%:<br>0,24 a 0,84).||raros e de longo prazo<br>não foram relatados.<br>Satisfação e conveniência<br>do tratamento foram<br>melhores com<br>deferasirox.|mg/kg. Houve aumentos<br>na excreção urinária de<br>ferro durante o<br>tratamento associado ou<br>sequencial de<br>desferroxamina +<br>deferiprona em<br>comparação com a<br>monoterapia (p = 0,008 e<br>p = 0,02).|A satisfação dos<br>pacientes foi<br>significativamente<br>melhor com deferasirox,<br>com taxas de<br>descontinuação<br>semelhantes entre os<br>tratamentos.||
||Os resultados não|A revisão não identificou||O estudo não sugere|Deferasirox é uma|Embora limitados pelo|
||sugerem mudança na<br>prática clínica com uso|evidências que alterassem<br>as atuais recomendações|O deferasirox parece ser<br>tão eficaz quanto a|qualquer mudança nos<br>protocolos de tratamento|importante alternativa de<br>tratamento para|número de estudos<br>incluídos, os resultados|
||de desferroxamina.  No|de tratamento, ou seja, a|desferroxamina a longo|de quelação.|talassemia e sobrecarga|mostraram que a|
|**Conclusões**|entanto, reafirma existir<br>uma incerteza<br>considerável sobre o|deferiprona indicada para<br>o tratamento da<br>sobrecarga de ferro em|prazo. A segurança a<br>curto prazo de<br>deferasirox parece ser|Os resultados sugerem os<br>órgãos nacionais e<br>agências reguladoras|de ferro secundária, mas<br>não parece ser superior à<br>desferroxamina.|concentração de ferro no<br>fígado não teve diferença<br>entre os tratamentos com|
||esquema ideal para o|pessoas com talassemia|aceitável.|internacionais|Deve ser oferecido como|deferasirox ou|
||tratamento com esse|maior quando a||considerem o uso da|uma alternativa a todos|desferroxamina.|  
88  
|**Autor, ano**|**Roberts, 2005**|**Roberts, 2007**|**Meerpohl, 2010**|**Maggio, 2011**|**Meerpohl, 2012**|**Qadah, 2022**|
|---|---|---|---|---|---|---|
||quelante de ferro em|desferroxamina é||combinação em|os pacientes com|Em geral, os resultados|
||pessoas com talassemia|contraindicada ou||associação ou sequencial|talassemia que|mostram que deferasirox|
||dependente de|inadequada.||de deferiprona e|apresentam intolerância|foi tão eficaz quanto|
||transfusão.|||desferroxamina.|ou baixa adesão à<br>desferroxamina.|desferroxamina.|  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
||||_Parte 2_|||
|**Número de**||||||
|**estudos**|22|17|02|16|05|
|**incluídos**||||||
||||||Ensaios clínicos e estudos|
|**Desenho dos**<br>**estudos**|ECRs e ensaios clínicos quasi-<br>randomizados|ECRs|ECRs|ECRs|observacionais (coortes<br>prospectivas/ coortes<br>transversais)|
||||||(a) Ensaios clínicos ou|
||ECRs comparando|ECRs comparando a|||estudos observacionais|
|**Critérios de**|desferroxamina com placebo,<br>com outro quelante de ferro, ou|deferiprona com outro quelante<br>de ferro; ou comparando dois|ECRs comparando deferasirox<br>com nenhuma terapia placebo ou|ECRs comparando<br>deferasirox com nenhuma|(coortes prospectivas/<br>coortes transversais)|
|<br>**inclusão**|comparando dois esquemas ou<br>doses de desferroxamina, em<br>pessoas com talassemia|esquemas ou doses de<br>deferiprona, em pessoas com<br>talassemia dependente de|,<br>com outro esquema de<br>tratamento com quelante de ferro.|terapia, placebo ou com<br>outro tratamento quelante<br>de ferro|(b) população pediátrica<br>(<18 anos) com<br>hemoglobinopatias|
||dependente de transfusão|transfusão|||hereditárias e dependentes de<br>transfusão|  
89  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
||||||(c) grupos comparando<br>deferasirox com deferiprona|
|**Critérios de**<br>**Exclusão**|Outros desenhos de estudo /<br>incluiu pacientes não<br>talassêmicos e não relatou dados<br>separadamente / não reportou<br>grupo intervenção / estudo<br>transversal comparando custos do<br>tratamento / resumo com<br>informações insuficientes|Outros desenhos de estudo /<br>sem braço comparador elegível<br>/ com participantes que<br>receberam todas as<br>intervenções|Estudos com pessoas com outras<br>condições clínicas / Outros<br>desenhos de estudo / Dados<br>observacionais de sobrecarga de<br>ferro / Outras intervenções que<br>não incluam deferasirox / estudos<br>de custo-efetividade|Estudos com pessoas com<br>outras condições clínicas /<br>incluídos pessoas com<br>talassemia que receberam<br>transplante de células-<br>tronco / outros desenhos de<br>estudo / intervenções ou<br>comparações diferentes de<br>deferasirox|Estudos que incluíram<br>terapia combinada de<br>desferroxamina e deferasirox<br>ou deferiprona / com<br>pacientes maiores de 18 anos<br>de idade e estudos em<br>animais / relatos de casos,<br>comentários e editoriais|
|**Total de**<br>**Participantes**|2187|1061|415|1807|607|
|**Intervenção**|Desferroxamina|Deferiprona|Deferasirox|Deferasirox|Deferasirox|
||DesferroxaminaX placebo<br>Desferroxamina X deferiprona|||Deferasirox X nenhuma<br>terapia ou placebo (em||
||Desferroxamina + deferiprona X|Deferiprona X Placebo|Deferasirox X nenhuma terapia|pessoas com talassemia||
||deferiprona|Deferiprona X outro esquema|ou placebo|dependente de transfusão)||
|**Comparadores**<br>**ou comparações**|Desferroxamina X<br>desferroxamina + deferiprona<br>Desferroxamina X deferasirox<br>Desferroxamina em duas vias de<br>administração (bolus e infusão<br>contínua)|de tratamento quelante de ferro<br>Dosa A de deferiprona X Dose<br>B de deferiprona|Deferasirox X outro esquema de<br>tratamento com quelante de ferro<br>(desferroxamina ou deferiprona<br>ou qualquer combinação destes)|Deferasirox X nenhuma<br>terapia ou placebo (em<br>pessoas com talassemia não<br>dependente de transfusão)<br>Deferasirox X outro<br>tratamento quelante de ferro|Deferiprona|  
90  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
|||||(desferroxamina ou<br>deferiprona ou qualquer<br>combinação destes) em<br>pessoas com talassemia<br>dependente de transfusão<br>Deferasirox X Outro<br>tratamento quelante de ferro||
|||||(desferroxamina ou||
|||||deferiprona ou qualquer<br>combinação destes) em||
|||||pessoas com talassemia não<br>dependentes de transfusão||
|||Desfecho primário:|Desfecho primário: mortalidade|Desfecho primário:||
||Desfecho primário: Mortalidade|Mortalidade|por qualquer causa|Mortalidade global medida||
||Desfechos secundários:|Desfecho secundário:||em qualquer momento.||
||1. Evidência de redução de danos|1. Evidência de redução de|Desfecho secundário:|Desfecho secundário: 1.|Desfechos primários:|
||aos órgãos-alvos.|danos em órgãos-alvos devido|1. Redução de danos em órgãos-|Redução de danos em|1. Concentração de ferro no|
||2. Medidas de sobrecarga de ferro|à deposição de ferro|alvo devido à deposição de ferro|órgãos-alvo devido à|miocárdio ao final do|
|**Desfechos**|3. Eventos adversos ou|2. Medidas de sobrecarga de|2. Medidas de sobrecarga de|deposição de ferro. 2,|tratamento|
||toxicidade devido ao tratamento|ferro|ferro|Medidas de sobrecarga de|2. Níveis séricos de ferritina|
||4. Conformidade do participante|3. Eventos adversos|3. Medidas de excreção de ferro|ferro.  3. Medidas de|no início e no final do|
||com o tratamento de quelação de|4. Conformidade do|(urina e fezes) durante 24 horas|excreção de ferro durante|tratamento|
||ferro|participante com o tratamento|4. Quaisquer eventos adversos|24 horas. 4. Qualquer||
||5. Custo de tratamento|de quelação do ferro|5. Satisfação do participante|reação adversa. 5.||
|||5. Custos das intervenções|6.Custo anual da intervenção|Satisfação do participante.||  
91  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
|||||6. Custo da intervenção por<br>ano.||
||A terapia combinada com|Sugere-se uma vantagem da||Os dados sugerem que uma||
||desferroxamina e deferiprona|terapia combinada sobre a|A redução da ferritina sérica foi|eficácia similar pode ser||
||pode ser mais eficaz na redução|monoterapia na redução das|significativamente maior com|alcançada dependendo da||
||das reservas de ferro medida pela|reservas de ferro, medida pela|desferroxamina, com uma|proporção das doses de||
||ferritina sérica, em comparação|ferritina sérica. No entanto, não|diferença média de mudança de|desferroxamina e||
||com a monoterapia. No entanto,|há evidências conclusivas ou|440,69 μg/L (IC 95%: 11,73 a|deferasirox comparadas;||
||não há diferenças significativas|consistentes de uma melhoria|869,64).|com dose média de 28,2 e||
||na redução do ferro hepático<br>entre a combinação e a<br>desferroxamina isolada.|na eficácia da terapia<br>combinada com deferiprona e<br>desferroxamina em relação à|A ocorrência de eventos adversos<br>graves não diferiu entre os<br>medicamentos. Náusea, diarreia e|51,6 mg por dia,<br>respectivamente. Os efeitos<br>combinados são para|A análise de cinco estudos<br>mostrou que não há<br>diferença estatisticamente|
||Resultados anteriores sugerem|monoterapia, seja por medidas|erupção cutânea foram|ferritina sérica, diferença|<br>significativa entre a eficácia|
|**Principais**|que a deferiprona pode reduzir o|diretas ou indiretas do ferro|significativamente mais|média (DM) de 454,42|<br>de deferasirox e|
|**resultados**|ferro cardíaco mais rapidamente|hepático.|frequentes em pessoas tratadas|ng/mL (IC 95%: 337,13 a|<br>desferroxamina no|
||do que a desferroxamina, mas|Meta-análise de dois estudos|com deferasirox, enquanto|571,71); concentração de|<br>tratamento da sobrecarga de|
||não há diferenças significativas|mostrou um aumento|eventos adversos de qualquer|ferro hepático, 1 a 7 mg|<br>ferro em crianças com|
||nos danos ao coração entre os|significativo no risco de|tipo foram mais frequentemente|Fe/g de peso seco, RR 0,80|<br>desordens sanuíneas|
||dois tratamentos.|eventos adversos associados à|relatados para pacientes tratados|(IC 95%: 0,69 a 0,92). A|g.|
||Eventos adversos foram comuns|combinação de deferiprona e|com desferroxamina (um estudo).|satisfação dos pacientes foi||
||em todos os tratamentos, sendo|desferroxamina em|O aumento médio da creatinina|melhor com deferasirox||
||menos prováveis com a|comparação com a|também foi significativamente|entre aqueles que haviam||
||desferroxamina do que com a|desferroxamina isolada, RR|maior com deferasirox, com uma|recebido tratamento prévio||
||deferiprona RR 0,45 (IC 95%:|3,04 (IC 95% 1,18 a 7,83). O|diferença média de 3,24 (IC|com desferroxamina, RR||
||0,24 a 0,84), como reações no|evento adverso mais|95%: 0,45 a 6,03).|2,20 (IC 95%: 1,89 a 2,57).||
||local a infusão – dor e inchaço.|comumente relatado foi dor nas||A taxa de descontinuações||  
92  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
|||articulações, com mais<br>frequência em pacientes que<br>receberam deferiprona do que<br>desferrioxamina, RR 2,64 (IC<br>95% 1,21 a 5,77).||foi semelhante para ambos.<br>Em talassemia dependente<br>de transfusão o tratamento<br>com deferasirox reduziu a<br>ferritina sérica, DM            -<br>306,74 ng/mL (IC 95%:    -<br>398,23 a -215,24) e<br>concentração de ferro<br>hepático, DM -3,27 mg Fe/g<br>de peso seco (IC 95%: -4,44<br>a -2,09). O número de<br>participantes<br>experimentando eventos<br>adversos e a taxa de<br>descontinuações foram<br>semelhantes em ambos os<br>grupos.||
|**Conclusões**|Desferroxamina é indicada como<br>terapia de primeira linha para<br>sobrecarga de ferro em pessoas<br>com talassemia maior.<br>Deferiprona ou deferasirox são<br>indicados para tratar a sobrecarga<br>de ferro quando a desferroxamina<br>é contraindicada ou inadequada.|Deferiprona é indicada para<br>tratar sobrecarga de ferro em<br>pessoas com talassemia maior<br>quando a desferroxamina é<br>contra-indicada ou inadequada.<br>Deferiprona é indicada para<br>intensificar o tratamento com<br>desferroxamina para reverter a|Deferasirox parece ter eficácia<br>semelhante à desferroxamina<br>(depende da proporção<br>comparada).<br>A segurança a curto prazo do<br>deferasirox parece ser aceitável.|Deferasirox é uma<br>importante opção de<br>tratamento para pessoas<br>com talassemia e sobrecarga<br>secundária de ferro.<br>O deferasirox não parece<br>ser superior à<br>desferroxamina na|A análise não mostrou<br>diferença significativa entre<br>a eficácia de deferasirox e<br>deferiprona no tratamento de<br>sobrecarga de ferro em<br>crianças com doenças<br>sanguíneas hereditárias.|  
93  
|**Autor, ano**|**Fisher, 2013 (a)**|**Fisher, 2013 (b)**|**Meerpohl, 2014**|**Bollig, 2017**|**Saleem, 2023**|
|---|---|---|---|---|---|
||Defarasirox é indicado para uso<br>em crianças com mais de seis<br>anos que recebem transfusão de|disfunção cardíaca devido à<br>sobrecarga de ferro.|Atualmente, o uso de deferasirox<br>parece ser justificado<br>principalmente como opção de|proporção de 1 mg de<br>deferasirox para 2 mg de<br>desferroxamina, no entanto,||
||sangue frequentes e em crianças|Os resultados sugerem uma|tratamento para pessoas com|uma eficácia semelhante||
||de dois a cinco anos que recebem|vantagem da combinação da|doença falciforme que não|parece ser alcançada||
||transfusão de sangue pouco|deferiprona com|toleram ou cumprem a|dependendo da dose e da||
||frequentes.|desferroxamina em vez de<br>monoterapia com|desferroxamina.|proporção comparada.||
||O aumento da deposição de ferro|desferroxamina para reduzir||O deferasirox poderia ser||
||no coração em pacientes que|reservas de ferro medidas pela||oferecido como a opção de||
||recebem apenas desferroxamina<br>sugere intensificação do|ferritina sérica.||primeira linha para<br>indivíduos que demonstram||
||tratamento por via subcutânea ou|||uma forte preferência pelo||
||intravenosa, ou combinação de|||deferasirox, e pode ser uma||
||desferroxamina e deferiprona.|||opção de tratamento||
|||||razoável para pessoas que<br>mostram intolerância ou<br>baixa adesão à<br>desferroxamina.||  
94

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo Núcleo de Avaliação de Tecnologias em Saúde da Universidade Federal de São Paulo, Campus Diadema - NUD.  
Declaração e Manejo de Conflitos de Interesse  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro AA).

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **Equipe de elaboração e partes interessadas** -->
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos b|enefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim|  
95  
||(   ) Não|
|---|---|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
96

---

<!-- METADADOS: doenca: Sobrecarga De Ferro | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**||**Tecnologias avaliada**|**s pela Conitec**|
|---|---|---|---|
|**Relatório da diretriz**||||
|**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de<br>Recomendação<br>nº 1024/2025|Atualização do documento e<br>ampliação de uso de tecnologia em<br>saúde|Deferiprona para tratamento da<br>sobrecarga de ferro. [Relatório de<br>Recomendação nº 965/2025;<br>Portaria SECTICS/MS nº<br>19/2025]|-|
|Portaria Conjunta<br>SAS/SCTIE/MS nº<br>7/2018|Atualização do documento|-|-|
|Portaria SAS/MS nº<br>1.324/2013|Atualização do documento|-|-|
|Portaria SAS/MS nº<br>853/2011|Estabelecimento de parâmetros<br>nosológicos sobre sobrecarga de<br>ferro e de diretrizes nacionais para<br>diagnostico, tratamento e<br>acompanhamento dos pacientes.|-|-|
|Portaria SAS/MS nº<br>75/2006|Primeira versão<br>do documento|-|-|  
97

---

