<!-- METADADOS: doenca: Dislipidemia | secao: Geral -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 8, DE 30 DE JULHO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a dislipidemia no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta condição;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 440/2019 e o Relatório de Recomendação n<sup><u>o</u></sup> 451 – Maio de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Dislipidemia: prevenção de eventos cardiovasculares e pancreatite.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da dislipidemia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o controle da dislipidemia.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa condição em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria nº 200/SAS/MS, de 25 de fevereiro de 2013, publicada no Diário Oficial da União nº 39, de 27 de fevereiro de 2013, seção 1, páginas 116-120.

---

<!-- METADADOS: doenca: Dislipidemia | secao: Geral -->
DENIZAR VIANNA

---

<!-- METADADOS: doenca: Dislipidemia | secao: **1 INTRODUÇÃO** -->
A dislipidemia é um fator de risco cardiovascular relevante, pelo desenvolvimento da aterosclerose. Na aterogênese, o papel do colesterol total, particularmente o contido nas partículas de lipoproteínas de baja densidade (LDL, do Inglês _low density lipoproteins_ ), o LDL-C, foi constatado em uma série de estudos observacionais e experimentais das últimas décadas, passando por estudos pré-clínicos, patológicos, clínicos e genéticos, em diferentes populações. Os trabalhos iniciais relacionaram o colesterol total com doença arterial coronariana (DAC). Como o LDL-C corresponde à maior parte do colesterol total (60%-70% na população geral do Estudo de Framingham), a forte correlação entre colesterol total e DAC reflete a relação entre LDL-C e DAC, confirmada pelo _Framingham Heart Study_<sup>1</sup> . Importantes trabalhos demonstraram o desenvolvimento de DAC nos pacientes sem doença prévia com níveis mais elevados de colesterol total ou LDL-C: o _Framingham Heart Study_<sup>1</sup> , o _Multiple Risk Factor Intervention Trial (MRFIT)_<sup>2</sup> e o _Lipid Research Clinics Coronary Primary Prevention Trial_<sup>3,4</sup> .  
Evidências epidemiológicas contundentes relacionam baixos níveis de colesterol nas partículas de lipoproteínas de alta densidade (HDL, do Inglês _high density lipoproteins_ ), o HDL-C, com maior risco de morbimortalidade por DAC. Níveis elevados de HDL-C, por outro lado, se associam ao menor risco, sem aumentar o risco de morte por outras causas<sup>1,5,6</sup> .  
Apesar de as evidências serem menos expressivas, a elevação de triglicerídeos também se associa a risco de DAC. Duas meta-análises do final da década de 1990 relacionaram, de maneira independente, níveis elevados de triglicerídeos com DAC<sup>7,8</sup> .  
Os níveis de LDL-C apresentam correlação direta com o risco de ocorrência de eventos cardiovasculares<sup>9-12</sup> . Pode-se dizer que não existe um valor normal de LDL-C, mas níveis desejáveis acima dos quais intervenções já demonstram benefícios. Atualmente, níveis de LDL- C maiores de 100 mg/dL parecem estar relacionados com maior risco do desenvolvimento de eventos ateroscleróticos; níveis menores de 100 mg/dL são considerados alvo terapêutico para a maioria dos indivíduos com risco cardiovascular elevado, não significando que tais níveis os isentem desse risco. Sendo as doenças cardiovasculares ateroscleróticas de etiologia multifatorial, a presença de outros fatores de risco (por exemplo, hipertensão arterial sistêmica, tabagismo, obesidade, diabete melito, história familiar etc.) é considerada tão importante quanto os níveis de colesterol total ou de LDL-C, de maneira que, de acordo com a agregação desses fatores de risco, níveis diferentes de LDL-C são desejados como meta para tratamento, não havendo firme consenso sobre qual o valor de LDL para início ou alvo de tratamento<sup>13</sup> . Situação clínica de particular aumento de risco é a hipercolesterolemia familiar, que resulta em grande elevação dos níveis de colesterol e aumento de doença cardíaca isquêmica prematura<sup>12,14,15</sup> .  
Outra situação clínica, não cardiovascular, associada à dislipidemia, particularmente à hipertrigliceridemia, é a pancreatite aguda. Níveis de triglicerídeos maiores do que 500 mg/dL podem precipitar ataques de pancreatite aguda, embora a patogênese da inflamação não seja clara<sup>16</sup> . Um estudo estimou que hipertrigliceridemia foi a etiologia da pancreatite aguda entre 1,3%3,8% dos casos de pancreatite<sup>17</sup> .  
Estudos observacionais de base populacional conduzidos no Brasil  revelam prevalências de dislipidemia de 43% a 60%<sup>18,19</sup> . Logo, dada sua elevada frequência na população geral, o diagnóstico e tratamento adequados da dislipidemia são majoritariamente de responsabilidade da Atenção Pimária. Assim, a identificação da dislipidemia em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da dislipidemia. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E78.0 Hipercolesterolemia pura  
- E78.1 Hipertrigliceridemia pura  
- E78.2 Hiperlipidemia mista  
- E78.3 Hiperquilomicronemia  
- E78.4 Outras hiperlipidemias  
- E78.5 Hiperlipidemia não especificada  
- E78.6 Deficiências de lipoproteínas  
- E78.8 Outros distúrbios do metabolismo de lipoproteínas

---

<!-- METADADOS: doenca: Dislipidemia | secao: **3 DIAGNÓSTICO** -->
O diagnóstico de dislipidemia baseia-se na dosagem dos lipídios séricos: colesterol total, HDL-C e triglicerídeos. A dosagem direta do LDL-C não é necessária, podendo o cálculo ser feito por meio da fórmula de Friedewald [LDL-C = (colesterol total [CT] – HDL-C) – (triglicerídios [TG]/5)], quando o valor dos triglicerídeos for inferior a 400 mg/dL. Para os casos em que o nível dos triglicerídeos for superior a 400 mg/dL, utiliza-se como critério o colesterol não HDL [não HDL-C = CT – HDL-C], cujo alvo é 30 mg/dL acima do alvo de LDL-C (isto é, para pacientes  cujo  LDL-C  alvo  for  100  mg/dL,  o alvo  de  não  HDL-C  será  130 mg/dL)<sup>9,10</sup> .  
Para o diagnóstico e a detecção dos pacientes sob risco de desenvolvimento de eventos cardiovasculares, o primeiro passo é a identificação dos que já apresentam manifestação da doença (i.e., doença arterial coronariana e periférica, insuficiência cardíaca isquêmica, ataque isquêmico transitório ou acidente vascular cerebral isquêmico). Esses pacientes têm elevado risco de novos eventos. Para os pacientes sem manifestação prévia da doença, o Escore de Risco de Framingham (ver o **Apêndice 2** ) é uma das ferramentas mais aceitas e utilizadas pela comunidade científica médica, apesar de algumas limitações, particularmente em pacientes jovens e doentes de diabete melito<sup>9,10,11</sup> . Em artigo de 2008, D’Agostino _et al._ publicaram uma reanálise da coorte original do Estudo de Framingham, produzindo dois novos algoritmos, um para homens e outro para mulheres, de predição de doença cardiovascular (i.e., DAC, AVC, doença arterial periférica e insuficiência cardíaca)<sup>20</sup> . Esses foram chamados de Escore de Risco Global (ERG) e endossados pela Diretriz Brasileira de Dislipidemias e Prevenção de Aterosclerose de 2017<sup>11</sup> . Cabe salientar que o ERG não é uma ferramenta inteiramente nova, mas um refinamento do consagrado Escore de Risco de Framingham, que agregou valor preditivo ao escore original, equilibrando seus parâmetros e introduzindo algoritmos específicos para s sexos. O presente Protocolo recomenda o uso do ERG para a estratificação de risco, por sexo, de doença cardiovascular<sup>20</sup> .  
O diagnóstico de hipercolesterolemia familiar deve ser considerado se houver níveis muito elevados de colesterol (acima do percentil 90), presença de xantomas tendinosos, arco córneo em paciente com menos de 45 anos, xantomas tuberosos ou xantelasma em pacientes com menos de 25 anos e familiar de primeiro grau com as manifestações anteriores<sup>21</sup> .Os critérios diagnósticos de hipercolesterolemia familiar definidos pela Organização Mundial da Saúde (OMS)<sup>22</sup> estão descritos no **Quadro1** .  
**Quadro 1 –** Critérios Diagnósticos de Hipercolesterolemia Familiar (OMS)<sup>18</sup>  
|**Critérios**|**Pontos**|
|---|---|
|**História familiar**||
|Familiar de primeiro grau com doença aterosclerótica prematura (homens com menos de 55 anos e<br>mulheres com menos de 60 anos).|1|
|Familiar de primeiro grau com LDL-C acima do percentil 95.||
|Familiar de primeiro grau com xantoma tendinoso ou arco córneo.|2|
|Criança (menores de 18 anos) com LDL-C acima do percentil 95.||
|**História clínica**||
|Paciente com doença arterial coronariana prematura (homens com menos de 55 anos e<br>mulheres com menos de 60 anos).|2|
|Paciente com doença arterial cerebral ou periférica prematura (homens com menos de<br>55 anos e mulheres com menos de 60 anos).|1|
|**Exame físico**||
|Xantoma tendinoso|6|
|Arco córneo antes dos 45 anos|4|
|**Exames laboratoriais**||
|LDL-C maiores ou iguais a 330 mg/dL|8|
|LDL-C entre 250 e 329 mg/dL|5|
|LDL-C entre 190 e 249 mg/dL|3|
|LDL-C entre 155 e 189 mg/dL|1|
|Mutação genética presente|8|
|**Diagnóstico de hipercolesterolemia familiar é**||
|Definitivo com|Mais de 8 pontos|
|Provável com|6-8 pontos|
|Possível com|3-5 pontos|

---

<!-- METADADOS: doenca: Dislipidemia | secao: **4 CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes que apresentarem qualquer um dos critérios  
abaixo:  
a) diabete melito em homens com idade superior a 45 anos e em mulheres com idade superior a 50 anos, com pelo menos um fator de risco cardiovascular maior (tabagismo, hipertensão arterial sistêmica ou história familiar em parente de primeiro grau de doença arterial coronariana precoce – antes dos 55 anos para homens e dos 65 anos para mulheres);  
b) moderado a alto risco cardiovascular definido pelo Escore de Risco de Framingham com risco superior a 10% em 10  
anos;  
- c) evidência clínica de doença aterosclerótica, entendendo-se como tal qualquer um dos itens abaixo:  
1. Infarto Agudo do Miocárdio (IAM) ou revascularização miocárdica prévios;  
2. evidência de doença arterial coronariana por cineangiocoronariografia;angina com evidência objetiva de isquemia  
miocárdica demonstrada por teste provocativo (por exemplo: ergometria, cintilografia miocárdica ou ecocardiografia de  
estresse);  
3. isquemia cerebral em exames de imagem (tomografia computadorizada ou ressonância magnética de encéfalo);  
4. história de acidente isquêmico transitório com evidência de aterosclerose em território carotídeo, à ultrassonografia  
ou arteriografia, ou endarterectomia prévia;  
5. evidência de doença arterial periférica manifestada por claudicação intermitente ou história de revascularização.  
- d) diagnóstico definitivo de hiperlipidemia familiar, de acordo com **Quadro 1** .  
Considerando que genfibrozila não pode ser usada em associação com estatinas pelo risco de rabdomiólise, serão incluídos para tratamento com o fibrato genfibrozila pacientes com qualquer um dos seguintes critérios:  
a) intolerantes ou refratários ao tratamento com estatinas e com triglicerídeos acima de 200 mg/dL, HDL inferior a 40 mg/dL, refratários a tratamento dietético por pelo menos 3 meses e com confirmação laboratorial (pelo menos duas determinações de cada exame com duas semanas de intervalo);  
- b) intolerantes ou refratários ao tratamento com estatinas e com triglicerídeos acima de 500 mg/dL (objetivando  
- prevenção de pancreatite).  
Serão incluídos para tratamento com os fibratos (fenofibrato, ciprofibrato, etofibrato e bezafibrato) pacientes sem indicação de uso de estatinas e com triglicerídeos acima de 500 mg/dL (objetivando prevenção de pancreatite). Serão incluídos para tratamento com ácido nicotínico somente pacientes com indicação de uso de estatinas, porém intolerantes ou com contraindicação a elas e que não preencham os critérios para uso de fibratos.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **5 CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo pacientes que apresentarem uma das seguintes condições:  
- a) hipotireoidismo descompensado (TSH acima de 10 mcUI/mL);  
b) gestantes ou mulheres em idade fértil que não estejam utilizando pelo menos dois métodos contraceptivos seguros ou que não adotem meio de contracepção definitiva;  
c) doença hepática aguda ou crônica grave (como elevação das aminotransferases/transaminases mais de 3 vezes os valores normais, icterícia ou  prolongamento do tempo de protrombina); ou  
d) hipersensibilidade ou evento adverso prévio conhecido ao medicamento ou a qualquer componente da sua fórmula.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **6 CASOS ESPECIAIS** -->
Pacientes de muito alto risco cardiovascular (Escore de Risco de Framingham superior a 20% em 10 anos ou prevenção secundária com manutenção de fatores de risco maiores) podem ser considerados candidatos à terapia hipolipemiante agressiva com alta dose de estatina (até as doses máximas preconizadas neste Protocolo), mesmo na ausência de evidência de impacto sobre a mortalidade<sup>9,11</sup> . Sugere-se que estes casos sejam avaliados em serviços da Atenção Terciária.  
Apesar da ausência de evidências clínicas contundentes de interações das estatinas que interferem no citocromo P450 com medicamentos antirretrovirais, algumas diretrizes recomendam o emprego preferencial de pravastatina ou atorvastatina por não interferirem nesta rota metabólica. Assim, a pravastatina, por ser a alternativa preferencial de menor custo, é a estatina de escolha para estes pacientes.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7 TRATAMENTO** -->
O tratamento da dislipidemia tem por objetivo final a redução de eventos cardiovasculares, incluindo mortalidade, bem como a prevenção de pancreatite aguda associada à hipertrigliceridemia grave.  
Tradicionalmente, o tratamento buscava atingir níveis de LDL abaixo de 100 mg/dL ou de triglicerídeos abaixo de 150  
mg/dL<sup>9,10</sup> ; mais recentemente, a prioridade passou a ser a redução do risco cardiovascular do paciente. Vale dizer que, para se avaliar o risco cardiovascular do paciente, a busca de níveis de colesterol isoladamente já não é critério suficiente. Neste Protocolo, o risco cardiovascular do paciente é critério de inclusão no tratamento.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.1 TRATAMENTO NÃO MEDICAMENTOSO** -->
Aspecto fundamental no tratamento da dislipidemia são as medidas não medicamentosas direcionadas não somente à redução dos níveis de lipídios séricos, mas também a outros fatores de risco cardiovascular.  
A conduta não medicamentosa deve ser recomendada a todos os pacientes com dislipidemia, incluindo, no mínimo, terapia nutricional, exercícios físicos e cessação do tabagismo.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.1 TRATAMENTO NÃO MEDICAMENTOSO** -->
Está bem demonstrado que o aumento do consumo de gorduras totais associa-se à elevação da concentração plasmática de colesterol e à maior incidência de aterosclerose<sup>1,9,11</sup> .  
A quantidade de gorduras saturadas e de colesterol presentes nos alimentos influencia diferentemente os níveis lipídicos plasmáticos, em especial a colesterolemia. Para reduzir a ingestão de colesterol, deve-se diminuir o consumo de alimentos de origem animal, em especial carne gordurosa, vísceras, leite integral e seus derivados, embutidos, frios, pele de aves e gema de ovos. Recomenda-se a substituição parcial de ácidos graxos saturados por mono e poli- insaturados<sup>11</sup> . Para diminuir o consumo de ácidos graxos saturados, aconselha-se a redução da ingestão de gordura animal (carnes gordurosas, leite e derivados), de polpa e leite de coco e de alguns óleos vegetais que contêm quantidades significativas de ácidos graxos saturados, como os óleos de palma, de coco e de dendê<sup>9,10,11</sup> . Também se recomenda a exclusão completa dos ácidos graxos trans da dieta<sup>11</sup> .  
Para a hipertrigliceridemia há duas condutas distintas, porém complementares. Para os pacientes com hiperquilomicronemia, geralmente com níveis de triglicerídeos acima de 1.000 mg/dL, situação associada a aumento do risco de pancreatite, recomenda-se reduzir a ingestão de gordura total da dieta (principalmente os óleos de cozinha e gorduras visíveis), e substituí-la, quando necessário, pela utilização de ácidos graxos de cadeia média que não entram na composição das quilomicras<sup>11</sup> .  
Para os pacientes com hipertrigliceridemia secundária, com valores de triglicerídeos geralmente abaixo de 1.000 mg/dL, comumente devido a excesso de ingestão de carboidratos, obesidade ou diabete melito, recomendam-se restrição de carboidratos, dieta hipocalórica e hipoglicídica e compensação do diabete, respectivamente, além da redução das gorduras da  dieta e abstenção do consumo de álcool<sup>9,10,11</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.1 TRATAMENTO NÃO MEDICAMENTOSO** -->
Exercícios físicos são eficazes principalmente como coadjuvantes da dieta no tratamento da hipertrigliceridemia associada à obesidade. Devem ser adotados com frequência de 3-6 vezes/semana e prescrição média de 150 minutos/semana de exercícios leves a moderados. Atividades aeróbicas, exercícios contra resistência e de flexibilidade estão indicados. Pacientes assintomáticos dispensam avaliação médica prévia, devendo ser mantidos os medicamentos de uso corrente<sup>9,11</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.1 TRATAMENTO NÃO MEDICAMENTOSO** -->
O hábito de fumar pode estar associado à redução significativa dos níveis de HDL-C<sup>11</sup> . O tabagismo deve ser combatido de forma agressiva. O tratamento inclui duas etapas: abordagem cognitivo-comportamental e, se necessário, farmacoterapia.  
O tratamento do tabagismo no Sistema Único de Saúde (SUS) é previsto no Programa Nacional de Controle do Tabagismo.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
O grupo das estatinas foi o primeiro a apresentar evidência de benefício no tratamento da dislipidemia. O estudo conhecido por 4S<sup>23</sup> , de 1994, foi o primeiro a demonstrar prevenção de eventos cardiovasculares e de morte com o tratamento da dislipidemia, tendo avaliado pacientes em prevenção secundária com níveis de colesterol elevado e de alto risco cardiovascular. Depois dele, vários trabalhos demonstraram benefícios em populações diferentes. Em prevenção secundária, destacam-se os clássicos 4S<sup>23</sup> , CARE<sup>24</sup> e LIPID<sup>25</sup> , que demonstraram redução na recorrência de infarto, morte coronariana, revascularização cardíaca e acidente cerebrovascular; em dois desses estudos, foi observada redução da mortalidade total. Em prevenção primária, destacam-se os estudos WOSCOPS<sup>26</sup> e  AFCAPS/TexCAPS<sup>27</sup> .  
Várias publicações podem ser encontradas nos últimos anos, entre as quais meta-análises confirmando o benefício do uso das estatinas em várias populações diferentes<sup>28-35</sup> . A mais recente meta-análise foi a de Chou R e colaboradores, publicada em 2016<sup>36</sup> . Tal meta-análise veio somente corroborar os dados já existentes a respeito do benefício do uso de estatinas na mortalidade, com benefício maior nas populações de mais alto risco cardiovascular.  
Quanto a comparações entre as estatinas, uma publicação da _Oregon Health & Science University_<sup>_37_</sup> _,_ que avaliou os produtos disponíveis à época, concluiu que: faltam estudos comparando diretamente os produtos ( _head-to-head comparison_ ) em prevenção primária e, em prevenção secundária, altas doses de atorvastatina (80 mg/dia) foram superiores a doses usuais de pravastatina (40 mg/dia) em um estudo<sup>38</sup> e de atorvastatina (10 mg/dia) em outro<sup>39</sup> .  
As melhores e mais contundentes evidências no que se refere à prevenção de  mortalidade com o tratamento da dislipidemia são disponíveis para sinvastatina<sup>23,40</sup> e pravastatina<sup>24,25</sup> . Em estudo de prevenção primária em pacientes hipertensos, a atorvastatina (10 mg/dia) reduziu desfechos cardiovasculares maiores, mas não demonstrou benefício em termos de mortalidade<sup>41</sup> . Quando usada em altas doses, a atorvastatina (80 mg/dia) mostrou mais benefícios em pacientes pós-IAM comparada à sinvastatina (20 mg/dia), reduzindo eventos cardiovasculares maiores, sem alterar a mortalidade total<sup>42</sup> .  
Há um único estudo de prevenção  primária em pacientes de risco intermediário (risco de eventos cardiovasculares de 10%-20% em 10 anos pelo Escore de Risco de Framingham), que avaliou desfechos primordiais com rosuvastatina<sup>43</sup> . Esse estudo clínico randomizado incluiu homens acima de 50 anos e mulheres acima de 60 anos, sem história de eventos cardiovasculares ou diagnóstico de diabete melito, com níveis de LDL-C acima de 130 mg/dL e de proteína-C reativa altamente sensível igual ou superior a 2 mg/l. A intervenção reduziu significativamente desfechos cardiovasculares maiores e mortalidade total _versus_ placebo (44). Entretanto, esse estudo tem sido motivo de grande controvérsia no meio científico, desacreditado por alguns autores devido à finalização precoce sem uma definição _a priori_ explícita dos critérios, incidência de eventos muito aquém do esperado e grande potencial de  conflitos de interesse<sup>44,45</sup> . Vale ressaltar também que, na análise individual das estatinas, a rosuvastatina foi associada ao desenvolvimento de diabete melito em meta-análise, com aumento de risco de 18% (IC 95%; 4%33%)<sup>46</sup> . Han e colaboradores realizaram análise _post-hoc_ secundária do estudo ALLHAT-LLT, avaliando pacientes com mais de 65 anos de idade em prevenção primária. Neste estudo, a estatina utilizada foi a pravastatina na dose de 40 mg ao dia. Os autores não observaram diferença na mortalidade por todas as causas no final do seguimento de 6 anos, embora tenha ocorrido redução dos níveis de colesterol<sup>47</sup> .  
Três publicações mais recentes não avaliaram a eficácia das estatinas em desfechos primordiais: dois estudos avaliaram anticorpos monoclonais anti-PCSK9<sup>48,49</sup> e um teve como desfecho distúrbios do sistema de condução<sup>50</sup> . A mais recente publicação é a análise de seguimento de 20 anos do estudo WOSCOPS, sugerindo que o benefício da terapia é mantido no longo prazo<sup>51</sup> . Ainda entre os artigos mais recentes, há o trabalho de Yusuf e colaboradores<sup>52</sup> , um ensaio clínico randomizado que comparou rosuvastatina a placebo em pacientes com risco cardiovascular moderado. Esse estudo apresenta algumas limitações:  
financiamento do laboratório produtor do medicamento, inclusão somente dos pacientes que toleraram o uso do medicamento em um período pré-randomização (imputando um potencial viés de seleção) e o uso de desfechos compostos como desfechos primários. O primeiro desfecho primário foi composto de morte cardiovascular, infarto não fatal e acidente cerebrovascular não fatal e apresentou uma redução absoluta de 1,1% (NNT 90 por 5,6 anos). Quando esses desfechos foram avaliados isoladamente, o único que manteve diferença estatisticamente significativa foi acidente cerebrovascular, com diferença absoluta de 0,5% (NNT 200 por 5,6 anos). Quanto ao segundo desfecho primário do estudo, composto por parada cardiorrespiratória reanimada, descompensação de insuficiência cardíaca e revascularização, novamente encontrou-se diferença entre os grupos no desfecho combinado (diferença absoluta de 1,3%, NNT 77 por 5,6 anos), diferença que somente manteve significância estatística para a taxa de revascularização (diferença absoluta de 0,4%, NNT 250 por 5,6 anos).  
Apesar de alguns trabalhos sugerirem terapia hipolipemiante agressiva em pacientes de muito alto risco cardiovascular<sup>9,53</sup> , as evidências são conflitantes. Os resultados da terapia agressiva (LDL-C alvo de 70 mg/dL) não demonstraram benefício sobre mortalidade geral ou mortalidade cardiovascular<sup>53,54</sup> . Os estudos apontam para uma redução da incidência de IAM, mas também para uma maior taxa de eventos adversos, com elevação de enzimas hepáticas, miopatia, aumento da incidência de diabetes e abandono de tratamento<sup>54,55,56</sup> . Outras evidências da falta de benefício da busca do LDLC muito baixo são as apresentadas em artigos nos quais o uso de ezetimiba (fármaco já avaliado pela CONITEC e não incorporado no SUS), apesar de diminuir significativamente os níveis de colesterol, não mostra qualquer benefício clínico.  
Assim sendo, os representantes da classe das estatinas com evidência inequívoca de benefício em desfechos primordiais tanto em homens quanto em mulheres<sup>57</sup> e que serão considerados por este Protocolo são: sinvastatina, pravastatina e atorvastatina. O tratamento será baseado no paciente sob risco e não na busca do LDL-C alvo.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
Apesar de comumente serem considerados uma única classe de medicamentos, os representantes dos fibratos apresentam características e mecanismos de ação diferentes, não devendo ser tratados como efeito de classe, mas avaliados individualmente<sup>58</sup> .  
O benefício cardiovascular dos fibratos foi sugerido em estudos das décadas de 1980 e 1990. O _Helsinki Heart Study_<sup>59</sup> , publicado em 1987, foi um Ensaio Clínico Randomizado que avaliou o uso de genfibrozila (600 mg, 2 vezes/dia) em homens com colesterol não HDL acima de 200 mg/dL. Nesse estudo, apesar de não ter ocorrido redução na mortalidade total, verificouse diminuição de 34% na incidência de eventos cardiovasculares. O _VA_ - _HIT_<sup>60</sup> , publicado em 1999, corroborou os resultados do _Helsinki Heart Study_ , com redução da incidência de infarto do miocárdio, de eventos cerebrovasculares e do desfecho combinado de infarto, acidente cerebrovascular e mortalidade.  
Apesar desses estudos iniciais, meta-análises posteriores não demonstraram benefício cardiovascular desta classe de medicamentos. Studer e colaboradores<sup>30</sup> não observaram qualquer evidência de benefício, tendo sido obtido um risco relativo de 1,0 (IC 95%; 0,91-1,11) para mortalidade total, de 0,93 (IC 95%; 0,81-1,08) para mortalidade cardíaca e de 1,13 (IC 95%; 1,01-1,27) para mortalidade não cardíaca. No estudo de Abourbih e colaboradores<sup>61</sup> , foi detectada prevenção de infartos não fatais, sem benefício sobre mortalidade.  
Desta forma, com os trabalhos disponíveis, conclui-se que a genfibrozila está associada à redução de eventos cardiovasculares maiores em pacientes com hipercolesterolemia e  naqueles com hipertrigliceridemia associada a baixos níveis de HDL<sup>45</sup> . Os fibratos demonstraram benefícios na redução de eventos cardiovasculares maiores e coronarianos,  apesar de não reduzirem a incidência de acidentes vasculares cerebrais, mortalidade total ou mortalidade cardiovascular<sup>62</sup> .  
A genfibrozila não pode ser usada em associação com estatinas pelo risco de rabdomiólise, logo, outros fibratos devem  
ser empregados em associação com estatinas<sup>11</sup> . Em pacientes com triglicerídeos maiores que 500 mg/dL, com adesão a dieta e exercícios e em uso de estatinas, estas podem ser combinadas com fenofibrato para redução do risco de pancreatite aguda<sup>11,63</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
O benefício do ácido nicotínico foi sugerido no _Coronary Drug Project_ , ECR desenvolvido entre 1966 e 1975, com a redução do risco de infarto do miocárdio<sup>64</sup> . Em estudo de seguimento de longo prazo, após a fase randomizada, houve redução de mortalidade total e cardiovascular (NNT 17 e 21, respectivamente)<sup>65</sup> .  
No entanto, o estudo de Studer e colaboradores<sup>27</sup> encontrou uma razão de risco de 0,96 (IC 95%; 0,86-1,08) para o desfecho de mortalidade, sugerindo ausência de benefício. Já o estudo HPS2-THRIVE, que randomizou mais de 25 mil pacientes para receber niacina-laropipranto ou placebo, após um seguimento médio de 3,9 anos, demonstrou não haver benefício da terapia ativa na prevenção de desfechos cardiovasculares maiores<sup>66</sup> .  
Desta forma, o uso de ácido nicotínico neste Protocolo será considerado apenas para as situações em que o paciente tenha intolerância a estatinas e não preencha os critérios para uso de fibratos.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
A meta-análise de Upadhyay e colaboradores<sup>67</sup> não avaliou o ezetimiba isoladamente, mas agrupou várias terapias hipolipemiantes em uma única análise conjunta. Também limitou a análise a pacientes com insuficiência renal crônica, restringindo a estes pacientes a aplicação dos resultados do estudo. Além disso, essa meta-análise apresentou taxa de inconsistência dos dados relativamente alta, caracterizando uma heterogeneidade dos resultados dos estudos  incluídos. Dos 18 ensaios clínicos incluídos, apenas 2 avaliaram a ezetimiba<sup>68,69</sup> . O primeiro, de Landray e colaboradores<sup>68</sup> , foi um estudo pequeno, com apenas 203 pacientes, que teve como desfecho o nível sérico de lípides, não avaliando desfecho clínico. O segundo<sup>69</sup> , conhecido pelo acrônimo de SHARP, randomizou 9.270 pacientes com insuficiência renal crônica (3.023 em terapia renal substitutiva) para associação de ezetimiba e sinvastatina comparada com placebo. Esse estudo demonstrou uma redução da incidência de eventos ateroscleróticos maiores no grupo tratado. Entretanto, não há como isolar o efeito do ezetimiba e da sinvastatina, uma vez que a comparação foi realizada entre a associação e o placebo.  
Conforme resultado de um único ensaio clínico randomizado – IMPROVE-IT<sup>70</sup> e suas sub-análises<sup>71,72</sup> , o uso de ezetimiba associado à sinvastatina em pacientes em fase aguda de síndrome coronária aguda é capaz de prevenir a ocorrência do desfecho composto de morte cardiovascular e evento cardiovascular maior (IAM, angina instável necessitando reospitalização, revascularização e AVE). Em 7 anos de seguimento houve redução de desfecho composto de 2% no grupo com ezetimiba (32,7% _versus_ 34,7% – HR 0,936, IC 0,89 – 0,99). Tal diferença se deu às custas da redução de infarto do miocárdio, acidente vascular encefálico (AVE isquêmico) e necessidade de revascularização urgente após 30 dias da randomização. Em outra sub-análise deste estudo<sup>73</sup> , ficou demonstrado que os pacientes de mais alto risco cardiovascular apresentaram benefício com o uso combinado de ezetimiba e sinvastatina, enquanto nos pacientes de mais baixo risco não houve benefício.  
O estudo IMPROVE-IT apresenta algumas limitações metodológicas que potencializam a ocorrência de vieses, como o fato de ter tido a participação e o patrocínio do laboratório produtor do medicamento em teste. Também chama a atenção uma taxa muito alta (42%) de  descontinuação do tratamento que, no entanto, ocorreu em ambos os grupos. Ressalte-se ainda a significância limítrofe encontrada no estudo com intervalo de confiança de 0,99, além do fato de o número de pacientes ter sido recalculado e aumentado no transcorrer do estudo, caracterizando um menor tamanho de efeito do que o previsto. Salienta-se o questionável (NNT) de 50 para o desfecho primário composto em um horizonte temporal de 7 anos.  
Na revisão sistemática de Lozano e colaboradores pelo _US Preventive Service Task Force_<sup>74</sup> , a respeito de dislipidemia familiar, dois estudos avaliaram o uso de ezetimiba na terapêutica desses pacientes. Nenhum deles avaliou desfechos primordiais,  
como ocorrência de infarto ou morte e, sim, taxa de redução de colesterol. Um dos estudos<sup>75</sup> mostrou redução de  LDL de 54% (-122,2 mg/dL) com o uso de ezetimiba e sinvastatina, comparado com redução de 38,1% (-4,7 mg/dL) no grupo que recebeu somente sinvastatina. No segundo estudo<sup>76</sup> , ocorreu uma redução de 28% (-60 mg/dL) nos usuários de monoterapia com ezetimiba, comparada com alteração desprezível no grupo placebo.  
Em função de haver apenas um ensaio clínico randomizado que avaliou desfecho clínico duro, com tamanho de efeito (NNT = 50) de relevância questionável, e em conformidade com recomendação de não incorporação da CONITEC (Portaria SCTIE/MS nº 34, de 29/08/2018), este Protocolo não preconiza a ezetimiba como terapia hipolipemiante<sup>77,78</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
O evolocumabe é um medicamento que foi registrado em abril de 2016 na ANVISA para tratamento da dislipidemia. A pesquisa na literatura a seu respeito encontrou 21 ensaios clínicos, sendo que nenhum abordou nem avaliou desfechos primordiais, como mortalidade. Os estudos iniciais encontrados são estudos de fase 1 e 2, com curto seguimento e nível de colesterol como desfecho<sup>79-87</sup> .  
Apenas um ensaio avaliou efeitos clínicos<sup>48</sup> . Nesse estudo, 27.564 pacientes com doença cardiovascular aterosclerótica e colesterol LDL acima de 70 mg/dL e já em uso de estatinas foram randomizados para evolocumabe (140 mg a cada 2 semanas ou 420 mg ao mês) ou placebo. No seguimento médio de 2,2 anos, os autores observaram uma redução de 15% (IC 8% a 21%) no desfecho composto de mortalidade cardiovascular, infarto do miocárdio, acidente vascular cerebral, hospitalização por angina instável ou revascularização coronariana. Esse estudo apresenta alguns potenciais vieses: o laboratório produtor foi patrocinador e colaborou com o desenho do estudo, bem como foi responsável pela coleta dos dados; a posologia do medicamento foi definida de acordo com a preferência do paciente (140 mg a cada 2 semanas ou 420 mg por mês), o que é algo pouco usual. Não ficou claro no estudo qual foi a dose mais utilizada do medicamento.  
Um único estudo avaliou desfechos clinicamente relevantes sugerindo benefícios, sendo ainda estudo com potenciais vieses. O evolocumabe, entretanto, é um medicamento novo, o que faz com que a segurança em médio e longo prazos ainda não esteja completamente estabelecida. Além disso, há recomendação da CONITEC de não incorporação do evolocumabe para o tratamento da hipercolesterolemia familiar homozigótica<sup>88</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.2 TRATAMENTO MEDICAMENTOSO** -->
O alirocumabe também é um medicamento da classe dos inibidores da PCSK9 e foi registrado em agosto de 2016 na ANVISA para tratamento da dislipidemia. Foram realizados 22 estudos globais, incluindo mais de 29 mil pacientes em mais de 3 mil centros de pesquisa. A eficácia do alirocumabe foi investigada em dez estudos clínicos de fase 3, envolvendo a andomização de 5.296 pacientes com hipercolesterolemia (não familiar e familiar heterozigótica) ou dislipidemia mista<sup>89-96</sup> .  
O estudo ODYSSEY OUTCOMES, apresentado em março de 2018, avaliou desfechos clínicos do uso de alirocumabe<sup>97</sup> . Nesse estudo, 18.924 pacientes com Síndrome Coronariana Aguda recente e colesterol LDL acima de 70 mg/dL já em uso das máximas doses toleradas de estatinas foram randomizados para alirocumabe (75 mg a cada 2 semanas, podendo a dose ser ajustada para atingir as metas entre 25-50 mg/dL de LDL-C) ou placebo. No seguimento médio de 2,8 anos, os autores observaram uma redução de 15% (IC 7% a 22%) no desfecho primário composto de mortalidade coronariana, infarto do miocárdio, acidente vascular cerebral ou hospitalização por angina instável. O uso de alirocumabe foi seguro e bem tolerado ao longo da duração do estudo e esteve associado com taxa menor de morte por todas as causas (p=0,026). Esse estudo apresenta alguns potenciais vieses: o laboratório produtor foi patrocinador e colaborou com o desenho do estudo, bem como foi responsável pela coleta dos dados.  
Considerando a revisão da literatura acima a respeito do evolocumabe e  do alirocumabe, concluiu-se que esses medicamentos apresentam um efeito redutor de LDL que parece ser significativo. Um único estudo avaliou desfechos clinicamente relevantes demonstrando benefícios para cada medicamento. Estes, entretanto, tratam-se de medicamentos muito novos -registrados no Brasil em 2016 – o que faz com que a segurança em médio e  longo prazos ainda não esteja completamente estabelecida, particularmente para uso em saúde pública. Sugere-se, desta forma, que se aguarde maior tempo de experiência de uso desses medicamentos antes que sejam avaliados para incorporação no SUS.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.3 FÁRMACOS** -->
- Atorvastatina cálcica: comprimidos de 10, 20, 40 e 80 mg.  
- Pravastatina sódica: comprimidos de 10, 20 e 40 mg.  
- Sinvastatina: comprimidos de 10, 20 e 40 mg.  
- Bezafibrato: comprimidos e drágeas de 200 mg e comprimidos de desintegração lenta de 400 mg.  
- Ciprofibrato: comprimidos de 100 mg.  
- Etofibrato: cápsulas de 500 mg.  
- Fenofibrato: cápsulas de 200 mg e cápsulas de liberação retardada de 250 mg.  
- Genfibrozila: comprimidos de 600 e 900 mg.  
- Ácido nicotínico: comprimidos de 500 mg.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
Devem ser usadas via oral, em dose única diária preferencialmente à noite para se obter o efeito máximo. Os representantes  
destes grupos com suas doses mínimas e máximas encontram-se na **Tabela 1** .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
Devem ser tomados preferencialmente em horário afastado das estatinas, quando estas forem usadas concomitantemente,  
para diminuir o risco de toxicidade, ou seja, pela manhã. A genfibrozila nunca deve ser administrada concomitantemente ao uso  
de estatinas. Os representantes destes grupos com suas doses mínimas e máximas encontram-se na **Tabela 1** .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
Utilizam-se 2 a 3 g/dia (início do efeito terapêutico com 1 a 2 g/dia), ajustados conforme o efeito ou a tolerância. Devido  
à baixa tolerância imediata a doses elevadas, inicia-se o tratamento com doses baixas (250 mg em dose única após o jantar), com aumento gradual a cada 2 a 4 semanas, até atingir a dose eficaz (ver Tabela 1).  
**Tabela 1 –** Doses Iniciais e máximas dos medicamentos  
|**Medicamento**|**Dose inicial (mg)**|**Dose máxima (mg)**|
|---|---|---|
||**ESTATINAS**||
|Atorvastatina cálcica|10|80*|
|Pravastatina sódica|20|40|
|Sinvastatina|20|80**|
||**FIBRATOS**||
|Bezafibrato|200|400|
|Ciprofibrato|100|100|  
|Etofibrato||500|500|
|---|---|---|---|
|Fenofibrato||200|250|
|Genfibrozila||600|1200|
||**OUTROS**|||
|Ácido nicotínico||500|3.000|  
* Restrita a casos especiais, sendo 10 mg a dose usual.  
** 80 mg por dia se associa a risco aumentado de toxicidade

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.5 TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
O tratamento deve ser feito de modo contínuo. Mialgias durante o uso dos medicamentos, elevação de creatinofosfoquinase (CPK) 10 vezes acima do valor normal, aumento de aminotransferases/transaminases (AST-TGO/ALTTGP) 3 vezes acima do valor normal ou o surgimento de contraindicações determinarão sua suspensão.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **7.6 BENEFÍCIOS ESPERADOS** -->
1. Estatinas: prevenção de eventos cardiovasculares maiores, incluindo morte, IAM, acidente vascular cerebral e revascularização, entre  outros.  
2. Fibratos: prevenção de eventos cardiovasculares maiores quando utilizados em pacientes com hipertrigliceridemia associada a HDL baixo e prevenção de pancreatite aguda.  
3. <mark>Ácido nicotínico: prevenção de eventos cardiovasculares maiores.</mark>

---

<!-- METADADOS: doenca: Dislipidemia | secao: **8 MONITORIZAÇÃO** -->
Após iniciado o tratamento com estatinas objetivando a prevenção de eventos cardiovasculares, não se faz necessária monitorização de perfil lipídico, uma vez que o tratamento será contínuo. Para pacientes que utilizam outros medicamentos que não estatinas, apesar de utilidade questionável na avaliação prognóstica, a aferição do perfil lipídico pode ser feita anualmente com o intuito de dirimir dúvidas e aumentar o conhecimento e a adesão dos pacientes. Para pacientes cujo objetivo terapêutico é a prevenção de pancreatite secundária a hipertrigliceridemia, a monitorização sérica de triglicerídeos pode ser realizada semestralmente.  
Para usuários de estatinas e fibratos, provas de função hepática (aminotransferases/transaminases) e muscular (CPK) devem ser realizadas no início do tratamento, após 6 meses, e toda vez que for alterada a dose do medicamento ou forem associados outros fármacos que aumentem o risco de toxicidade. Em meta-análise de Guo e colaboradores, que avaliou a segurança da associação de fenofibrato a estatinas em pacientes não controlados com estatinas em monoterapia, observou-se maior taxa de elevação de aminotransferases/transaminases, porém sem diferença em eventos adversos graves ou que levassem a suspensão da terapia<sup>98</sup> .  
Uma meta-análise avaliou o risco de desenvolvimento de diabete com a terapia com niacina e observou um aumento de risco de 34% (IC 95% 21% a 49%), com um NNH de 43 pacientes tratados por 5 anos<sup>99</sup> .

---

<!-- METADADOS: doenca: Dislipidemia | secao: **9 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos. Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência  
Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se cientificar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos colaterais  
relacionados ao uso dos medicamentos, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **11 REFERÊNCIAS** -->
1. Wilson PW, D’Agostino RB, Levy D, Belanger AM, Silbershatz H, Kannel WB. Prediction of coronary heart disease  
using risk factor categories. Circulation. 1998 May 12;97(18):1837–47.  
2. Stamler J, Wentworth D, Neaton JD. Is relationship between serum cholesterol and risk of premature death from  
coronary heart disease continuous and graded? Findings in 356,222 primary screenees of the Multiple Risk Factor Intervention Trial (MRFIT). JAMA. 1986 Nov 28;256(20):2823–8.  
3. The Lipid Research Clinics Coronary Primary Prevention Trial results. I. Reduction in incidence of coronary heart  
disease. JAMA. 1984 Jan 20;251(3):351–64.  
4. The Lipid Research Clinics Coronary Primary Prevention Trial results. II. The relationship of reduction in incidence  
of coronary heart disease to cholesterol lowering. JAMA. 1984 Jan 20;251(3):365–74.  
5. Gordon DJ, Probstfield JL, Garrison RJ, Neaton JD, Castelli WP, Knoke JD, et al. High- density lipoprotein  
cholesterol and cardiovascular disease. Four prospective American studies. Circulation. 1989 Jan;79(1):8–15.  
6. Abbott RD, Donahue RP, Kannel WB, Wilson PW. The impact of diabetes on survival following myocardial infarction  
in men vs women. The Framingham Study. JAMA. 1988 Dec 16;260(23):3456–60.  
7. Austin MA, Hokanson JE, Edwards KL. Hypertriglyceridemia as a cardiovascular risk factor. Am J Cardiol. 1998 Feb  
26;81(4A):7B-12B.  
8. Assmann G, Schulte H, Funke H, von Eckardstein A. The emergence of triglycerides as a significant independent risk  
factor in coronary artery disease. Eur Heart J. 1998 Oct;19 Suppl M:M8-14.  
9. Sposito AC, Caramelli B, Fonseca FAH, Bertolami MC, Afiune Neto A, Souza AD, et al. [IV Brazilian Guideline for Dyslipidemia and Atherosclerosis prevention: Department of Atherosclerosis of Brazilian Society of Cardiology]. Arq Bras Cardiol. 2007 Abr;88 Suppl 1:2–19.  
10.Genest J, McPherson R, Frohlich J, Anderson T, Campbell N, Carpentier A, et al. 2009 Canadian Cardiovascular Society/Canadian guidelines for the diagnosis and treatment of dyslipidemia and prevention of cardiovascular disease in the adult - 2009 recommendations. Can J Cardiol. 2009 Oct;25(10):567–79.  
11.Faludi A, Izar M, Saraiva J, Chacra A, Bianco H, Afiune Neto A, et al. Atualização da Diretriz Brasileira de Dislipidemias e Prevenção da Aterosclerose - 2017. Arq. bras. cardiol. [Internet]. 2017 [acesso em 29 maio 2018];109(1). Disponível em: http://www.gnresearch.org/doi/10.5935/abc.20170121  
12.European Association for Cardiovascular Prevention & Rehabilitation, Reiner Z, Catapano AL, De Backer G, Graham I, Taskinen M-R, et al. ESC/EAS Guidelines for the management of dyslipidaemias: the Task Force for the management of dyslipidaemias of the European Society of Cardiology (ESC) and the European Atherosclerosis Society (EAS). Eur Heart J. 2011 July;32(14):1769–818.  
13.Lebenthal Y, Horvath A, Dziechciarz P, Szajewska H, Shamir R. Are treatment targets for hypercholesterolemia evidence based? Systematic review and meta-analysis of randomised controlled trials. Arch Dis Child. 2010 Sept;95(9):673–80.  
14.Genest JJ, Martin-Munley SS, McNamara JR, Ordovas JM, Jenner J, Myers RH, et al. Familial lipoprotein disorders in patients with premature coronary artery disease. Circulation. 1992 June;85(6):2025–33.  
15. Goldberg AC, Hopkins PN, Toth PP, Ballantyne CM, Rader DJ, Robinson JG, et al. Familial hypercholesterolemia: screening, diagnosis and management of pediatric and adult patients: clinical guidance from the National Lipid Association Expert Panel on Familial Hypercholesterolemia. J Clin Lipidol. 2011 June;5(3):133–40.  
16. UpToDate [homepage da Internet]. [acesso em 30 abr 2018]. Etiology of acute pancreatitis. Disponível em: https://www.uptodate.com/contents/etiology-of-acute-  
pancreatitis?search=Etiology%20of%20acute%20pancreatitis&source=search_result&sel  
ectedTitle=1~150&usage_type=default&display_rank=1  
17. Fortson MR, Freedman SN, Webster PD. Clinical assessment of hyperlipidemic pancreatitis. Am J Gastroenterol.  
1995 Dec;90(12):2134–9.  
18. Gus I, Ribeiro RA, Kato S, Bastos J, Medina C, Zazlavsky C, et al. Variations in the Prevalence of Risk Factors for Coronary Artery Disease in Rio Grande do Sul-Brazil: A Comparative Analysis between 2002 and 2014. Arq Bras Cardiol. Dez 2015;105(6):573– 9.  
19. Garcez MR, Pereira JL, Fontanelli M de M, Marchioni DML, Fisberg RM. Prevalence of dyslipidemia according to the nutritional status in a representative sample of São Paulo. Arq Bras Cardiol. Dez 2014;103(6):476–84.  
20. D’Agostino RB, Vasan RS, Pencina MJ, Wolf PA, Cobain M, Massaro JM, et al. General cardiovascular risk profile for use in primary care: the Framingham Heart Study. Circulation. 2008 Feb 12;117(6):743–53.  
21. Goldberg AC, Hopkins PN, Toth PP, Ballantyne CM, Rader DJ, Robinson JG, et al. Familial hypercholesterolemia: screening, diagnosis and management of pediatric and adult patients: clinical guidance from the National Lipid Association Expert Panel on Familial Hypercholesterolemia. J Clin Lipidol. 2011 June;5(3):133–40.  
22. WHO Human Genetics Programme. (1999). Familial hypercholesterolaemia (FH) : report of a second WHO consultation, Geneva, 1998 Sept 4. [Internet]. Geneva: World Health Organization; 1998. 42 p. Report No.: WHO/HGN/FH/CONS/99.2. Disponível em:  
<u>http://apps.who.int/iris/bitstream/handle/10665/66346/WHO_HGN_FH_CONS_99.2.pdf?sequence=1&isAllowed=y</u>  
23. Randomised trial of cholesterol lowering in 4444 patients with coronary heart disease: the Scandinavian Simvastatin  
Survival Study (4S). Lancet. 1994 Nov 19;344(8934):1383–9.  
24. Sacks FM, Pfeffer MA, Moye LA, Rouleau JL, Rutherford JD, Cole TG, et al. The effect of pravastatin on coronary events after myocardial infarction in patients with average cholesterol levels. Cholesterol and Recurrent Events Trial investigators. N Engl J Med. 1996 Oct 3;335(14):1001–9.  
25. Long-Term Intervention with Pravastatin in Ischaemic Disease (LIPID) Study Group. Prevention of cardiovascular events and death with pravastatin in patients with coronary heart disease and a broad range of initial cholesterol levels. N Engl J Med. 1998 Nov 5;339(19):1349–57.  
26. Shepherd J, Cobbe SM, Ford I, Isles CG, Lorimer AR, MacFarlane PW, et al. Prevention of coronary heart disease with pravastatin in men with hypercholesterolemia. West of Scotland Coronary Prevention Study Group. N Engl J Med. 1995 Nov 16;333(20):1301– 7.  
27. Downs JR, Clearfield M, Weis S, Whitney E, Shapiro DR, Beere PA, et al. Primary prevention of acute coronary events with lovastatin in men and women with average cholesterol levels: results of AFCAPS/TexCAPS. Air Force/Texas Coronary Atherosclerosis Prevention Study. JAMA. 1998 May 27;279(20):1615–22.  
28. Navaneethan SD, Nigwekar SU, Perkovic V, Johnson DW, Craig JC, Strippoli GF. HMG CoA reductase inhibitors (statins) for dialysis patients. Cochrane Database Syst Rev. 2009 Apr 15;(2):CD004289.  
29. Baigent C, Keech A, Kearney PM, Blackwell L, Buck G, Pollicino C, et al. Efficacy and safety of cholesterollowering treatment: prospective meta-analysis of data from 90,056 participants in 14 randomised trials of statins. Lancet. 2005  
Oct 8;366(9493):1267–78.  
30. Studer M, Briel M, Leimenstoll B, Glass TR, Bucher HC. Effect of different antilipidemic agents and diets on  
mortality: a systematic review. Arch Intern Med. 2005 Apr 11;165(7):725–30.  
31. Walsh JME, Pignone M. Drug treatment of hyperlipidemia in women. JAMA. 2004 May 12;291(18):2243–52.  
32. Wang C-P, Lorenzo C, Habib SL, Jo B, Espinoza SE. Differential effects of metformin on age related comorbidities  
in older men with type 2 diabetes. J Diabetes Complicat. 2017 Apr;31(4):679–86.  
33. Navaneethan SD, Pansini F, Perkovic V, Manno C, Pellegrini F, Johnson DW, et al. HMG CoA reductase inhibitors  
(statins) for people with chronic kidney disease not requiring dialysis. Cochrane Database Syst Rev. 2009 Apr 15;(2):CD007784.  
34. Tonelli M, Lloyd A, Clement F, Conly J, Husereau D, Hemmelgarn B, et al. Efficacy of statins for primary  
prevention in people at low cardiovascular risk: a meta-analysis. CMAJ. 2011 Nov 8;183(16):E1189-1202.  
35. Cholesterol Treatment Trialists’ (CTT), Mihaylova B, Emberson J, Blackwell L, Keech A, Simes J, et al. The effects of lowering LDL cholesterol with statin therapy in people at low risk of vascular disease: meta-analysis of individual data from 27 randomised trials. Lancet. 2012 Aug 11;380(9841):581–90.  
36. Chou R, Dana T, Blazina I, Daeges M, Jeanne TL. Statins for Prevention of Cardiovascular Disease in Adults:  
Evidence Report and Systematic Review for the US Preventive Services Task Force. JAMA. 2016 Nov 15;316(19):2008–24.  
37. Helfand M, Carson S, Kelley C. Drug Class Review on HMG-CoA Reductase Inhibitors (Statins) [Internet]. Oregon  
Evidence-based Practice Center; 2006 Aug. p. 76. Report No.: Final Report Update 4. Disponível em: http://www.ohsu.edu/drugeffectiveness/reports/final.cfm  
38. Cannon CP, Braunwald E, McCabe CH, Rader DJ, Rouleau JL, Belder R, et al. Intensive versus moderate lipid  
lowering with statins after acute coronary syndromes. N Engl J Med. 2004 Apr 8;350(15):1495–504.  
39. LaRosa JC, Grundy SM, Waters DD, Shear C, Barter P, Fruchart J-C, et al. Intensive lipid lowering with atorvastatin  
in patients with stable coronary disease. N Engl J Med. 2005 Apr 7;352(14):1425–35.  
40. Heart Protection Study Collaborative Group. MRC/BHF Heart Protection Study of cholesterol lowering with  
simvastatin in 20,536 high-risk individuals: a randomised placebo-controlled trial. Lancet. 2002 July 6;360(9326):7–22.  
41. Sever PS, Dahlöf B, Poulter NR, Wedel H, Beevers G, Caulfield M, et al. Prevention of coronary and stroke events  
with atorvastatin in hypertensive patients who have average or lower-than-average cholesterol concentrations, in the AngloScandinavian Cardiac Outcomes Trial--Lipid Lowering Arm (ASCOT-LLA): a multicentre randomised controlled trial. Lancet. 2003 Apr 5;361(9364):1149–58.  
42. Pedersen TR, Faergeman O, Kastelein JJP, Olsson AG, Tikkanen MJ, Holme I, et al. High-dose atorvastatin vs  
usual-dose simvastatin for secondary prevention after myocardial infarction: the IDEAL study: a randomized controlled trial. JAMA. 2005 Nov 16;294(19):2437–45.  
43.Ridker PM, Danielson E, Fonseca FAH, Genest J, Gotto AM, Kastelein JJP, et al. Rosuvastatin to prevent vascular events in men and women with elevated C-reactive protein. N Engl J Med. 2008 Nov 20;359(21):2195–207.  
44.de Lorgeril M, Salen P, Abramson J, Dodin S, Hamazaki T, Kostucki W, et al. Cholesterol lowering, cardiovascular diseases, and the rosuvastatin-JUPITER controversy: a critical reappraisal. Arch Intern Med. 2010 June 28;170(12):1032–6.  
45.Kaul S, Morrissey RP, Diamond GA. By Jove! What is a clinician to make of JUPITER? Arch Intern Med. 2010 June 28;170(12):1073–7.  
46.Sattar N, Preiss D, Murray HM, Welsh P, Buckley BM, de Craen AJM, et al. Statins and risk of incident diabetes: a collaborative meta-analysis of randomised statin trials. Lancet. 2010 Feb 27;375(9716):735–42.  
47.Han BH, Sutin D, Williamson JD, Davis BR, Piller LB, Pervin H, et al. Effect of Statin Treatment vs Usual Care on Primary Cardiovascular Prevention Among Older Adults: The ALLHAT-LLT Randomized Clinical Trial. JAMA Intern Med.  
2017 July 1;177(7):955–65.  
48. Sabatine MS, Giugliano RP, Keech AC, Honarpour N, Wiviott SD, Murphy SA, et al. Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease. N Engl J Med. 2017 May 4;376(18):1713–22.  
49. Ridker PM, Amarenco P, Brunell R, Glynn RJ, Jukema JW, Kastelein JJP, et al. Evaluating bococizumab, a monoclonal antibody to PCSK9, on lipid levels and clinical events in broad patient groups with and without prior cardiovascular events: Rationale and design of the Studies of PCSK9 Inhibition and the Reduction of vascular Events (SPIRE) Lipid Lowering and SPIRE Cardiovascular Outcomes Trials. Am Heart J. 2016 Aug;178:135–44.  
50. Dewland TA, Soliman EZ, Davis BR, Magnani JW, Yamal J-M, Piller LB, et al. Effect of the Antihypertensive and Lipid-Lowering Treatment to Prevent Heart Attack Trial (ALLHAT) on Conduction System Disease. JAMA Intern Med. 2016 Aug 1;176(8):1085–92.  
51. Vallejo-Vaz AJ, Robertson M, Catapano AL, Watts GF, Kastelein JJ, Packard CJ, et al. Low-Density Lipoprotein Cholesterol Lowering for the Primary Prevention of Cardiovascular Disease Among Men With Primary Elevations of LowDensity Lipoprotein Cholesterol Levels of 190 mg/dL or Above: Analyses From the WOSCOPS (West of Scotland Coronary Prevention Study) 5-Year Randomized Trial and 20-Year Observational Follow-Up. Circulation. 2017 Nov 14;136(20):1878– 91.  
52. Yusuf S, Bosch J, Dagenais G, Zhu J, Xavier D, Liu L, et al. Cholesterol Lowering in Intermediate-Risk Persons without Cardiovascular Disease. N Engl J Med. 2016 May 26;374(21):2021–31.  
53. Cholesterol Treatment Trialists’ (CTT), Baigent C, Blackwell L, Emberson J, Holland LE, Reith C, et al. Efficacy and safety of more intensive lowering of LDL cholesterol: a meta-analysis of data from 170,000 participants in 26 randomised trials. Lancet. 2010 Nov 13;376(9753):1670–81.  
54. Mills EJ, O’Regan C, Eyawo O, Wu P, Mills F, Berwanger O, et al. Intensive statin therapy compared with moderate dosing for prevention of cardiovascular events: a meta- analysis of >40 000 patients. Eur Heart J. 2011 June;32(11):1409–15.  
55. Study of the Effectiveness of Additional Reductions in Cholesterol and Homocysteine (SEARCH) Collaborative Group, Armitage J, Bowman L, Wallendszus K, Bulbulia R, Rahimi K, et al. Intensive lowering of LDL cholesterol with 80 mg versus 20 mg simvastatin daily in 12,064 survivors of myocardial infarction: a double-blind randomised trial. Lancet. 2010 Nov 13;376(9753):1658–69.  
56. Preiss D, Seshasai SRK, Welsh P, Murphy SA, Ho JE, Waters DD, et al. Risk of  incident diabetes with intensivedose compared with moderate-dose statin therapy: a meta-analysis. JAMA. 2011 June 22;305(24):2556–64.  
57. Kostis WJ, Cheng JQ, Dobrzynski JM, Cabrera J, Kostis JB. Meta-analysis of statin effects in women versus men. J Am Coll Cardiol. 2012 Feb 7;59(6):572–82.  
58. Brunton LL, Knollmann BC, Hilal-Dandan R, organizadores. Goodman & Gilman’s the pharmacological basis of therapeutics. 13<sup>a</sup> ed. New York: McGraw Hill Medical; 2018.  
59. Frick MH, Elo O, Haapa K, Heinonen OP, Heinsalmi P, Helo P, et al. Helsinki Heart Study: primary-prevention trial with gemfibrozil in middle-aged men with dyslipidemia. Safety of treatment, changes in risk factors, and incidence of coronary heart disease. N Engl J Med. 1987 Nov 12;317(20):1237–45.  
60. Rubins HB, Robins SJ, Collins D, Fye CL, Anderson JW, Elam MB, et al. Gemfibrozil for the secondary prevention of coronary heart disease in men with low levels of high- density lipoprotein cholesterol. Veterans Affairs High-Density Lipoprotein Cholesterol Intervention Trial Study Group. N Engl J Med. 1999 Aug 5;341(6):410–8.  
61. Abourbih S, Filion KB, Joseph L, Schiffrin EL, Rinfret S, Poirier P, et al. Effect of fibrates on lipid profiles and cardiovascular outcomes: a systematic review. Am J Med. 2009 Oct;122(10):962.e1-8.  
62. Jun M, Foote C, Lv J, Neal B, Patel A, Nicholls SJ, et al. Effects of fibrates on cardiovascular outcomes: a systematic  
review and meta-analysis. Lancet. 2010 May 29;375(9729):1875–84.  
63. Tsuang W, Navaneethan U, Ruiz L, Palascak JB, Gelrud A. Hypertriglyceridemic pancreatitis: presentation and management. Am J Gastroenterol. 2009 Apr;104(4):984– 91.  
64. Clofibrate and niacin in coronary heart disease. JAMA. 1975 Jan 27;231(4):360–81.  
65. Canner PL, Berge KG, Wenger NK, Stamler J, Friedman L, Prineas RJ, et al. Fifteen year mortality in Coronary Drug Project patients: long-term benefit with niacin. J Am Coll Cardiol. 1986 Dec;8(6):1245–55.  
66. HPS2-THRIVE Collaborative Group, Landray MJ, Haynes R, Hopewell JC, Parish S, Aung T, et al. Effects of extended-release niacin with laropiprant in high-risk patients. N Engl J Med. 2014 July 17;371(3):203–12.  
67. Upadhyay A, Earley A, Lamont JL, Haynes S, Wanner C, Balk EM. Lipid-lowering therapy in persons with chronic kidney disease: a systematic review and meta-analysis. Ann Intern Med. 2012 Aug 21;157(4):251–62.  
68. Landray M, Baigent C, Leaper C, Adu D, Altmann P, Armitage J, et al. The second United Kingdom Heart and Renal Protection (UK-HARP-II) Study: a randomized controlled study of the biochemical safety and efficacy of adding ezetimibe to simvastatin as initial therapy among patients with CKD. Am J Kidney Dis. 2006 Mar;47(3):385–95.  
69. Baigent C, Landray MJ, Reith C, Emberson J, Wheeler DC, Tomson C, et al. The effects of lowering LDL cholesterol with simvastatin plus ezetimibe in patients with chronic kidney disease (Study of Heart and Renal Protection): a randomised placebo-controlled trial. Lancet. 2011 June 25;377(9784):2181–92.  
70. Cannon CP, Blazing MA, Giugliano RP, McCagg A, White JA, Theroux P, et al. Ezetimibe Added to Statin Therapy after Acute Coronary Syndromes. N Engl J Med. 2015 June 18;372(25):2387–97.  
71. Bohula EA, Giugliano RP, Cannon CP, Zhou J, Murphy SA, White JA, et al. Achievement of dual low-density lipoprotein cholesterol and high-sensitivity C-reactive protein targets more frequent with the addition of ezetimibe to simvastatin and associated with better outcomes in IMPROVE-IT. Circulation. 2015 Sept 29;132(13):1224–33.  
72. Murphy SA, Cannon CP, Blazing MA, Giugliano RP, White JA, Lokhnygina Y, et al. Reduction in Total Cardiovascular Events With Ezetimibe/Simvastatin Post-Acute Coronary Syndrome: The IMPROVE-IT Trial. J Am Coll Cardiol. 2016 Feb 2;67(4):353–61.  
73. Bohula EA, Morrow DA, Giugliano RP, Blazing MA, He P, Park J-G, et al. Atherothrombotic Risk Stratification and Ezetimibe for Secondary Prevention. J Am Coll Cardiol. 2017 feb 28;69(8):911–21.  
74. Lozano P, Henrikson NB, Dunn J, Morrison CC, Nguyen M, Blasi PR, et al. Lipid Screening in Childhood and Adolescence for Detection of Familial Hypercholesterolemia: Evidence Report and Systematic Review for the US Preventive Services Task Force. JAMA. 2016 Aug 9;316(6):645.  
75. van der Graaf A, Cuffie-Jackson C, Vissers MN, Trip MD, Gagné C, Shi G, et al. Efficacy and Safety of Coadministration of Ezetimibe and Simvastatin in Adolescents With Heterozygous Familial Hypercholesterolemia. J Am Coll Cardiol. 2008 Oct;52(17):1421–9.  
76. Kusters DM, Caceres M, Coll M, Cuffie C, Gagné C, Jacobson MS, et al. Efficacy and Safety of Ezetimibe Monotherapy in Children with Heterozygous Familial or Nonfamilial Hypercholesterolemia. J Pediatr. 2015 June;166(6):13771384.e3.  
77. Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Relatório de Recomendação: Ezetimiba no tratamento da dislipidemia [Internet]. Brasília, DF; 2018 abr. 46 p. Disponível em: http://conitec.gov.br/images/Consultas/Relatorios/2018/Relatorio_Ezetimiba_Dislipidem ias_CP17_2018.pdf  
78. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Portaria nº 34, de 28 de agosto de 2018. Torna pública a decisão de não incorporar o ezetimiba no tratamento da dislipidemia no âmbito do Sistema Único de Saúde -SUS [Internet]. Diário Oficial da União; 29 ago 2018[acesso em 3 set 2018]; 157(Seção 1):  
37. Disponível em: http://conitec.gov.br/images/Relatorios/Portaria/2018/PortariasSCTIE- 30e32a36_2018.pdf  
79. Raal FJ, Giugliano RP, Sabatine MS, Koren MJ, Langslet G, Bays H, et al. Reduction in lipoprotein(a) with PCSK9 monoclonal antibody evolocumab (AMG 145): a pooled analysis of more than 1,300 patients in 4 phase II trials. J Am Coll Cardiol. 2014 Apr 8;63(13):1278–88.Desai NR, Giugliano RP, Zhou J, Kohli P, Somaratne R, Hoffman E, et al. AMG 145, a monoclonal antibody against PCSK9, facilitates achievement of national cholesterol education program-adult treatment panel III low-density lipoprotein cholesterol goals among high-risk patients: an analysis from the LAPLACE-TIMI 57 trial (LDL-C assessment with PCSK9 monoclonal antibody inhibition combined with statin therapy- thrombolysis in myocardial infarction 57). J Am Coll Cardiol. 2014 Feb 11;63(5):430–3.  
80. Desai NR, Giugliano RP, Zhou J, Kohli P, Somaratne R, Hoffman E, et al. AMG 145, a monoclonal antibody against PCSK9, facilitates achievement of national cholesterol education program-adult treatment panel III low-density lipoprotein cholesterol goals among high-risk patients: an analysis from the LAPLACE-TIMI 57 trial (LDL-C assessment with PCSK9 monoclonal antibody inhibition combined with statin therapy- thrombolysis in myocardial infarction 57). J Am Coll Cardiol. 2014 Feb 11;63(5):430–3  
81. Stein EA, Honarpour N, Wasserman SM, Xu F, Scott R, Raal FJ. Effect of the proprotein convertase subtilisin/kexin 9 monoclonal antibody, AMG 145, in homozygous familial hypercholesterolemia. Circulation. 2013 Nov 5;128(19):2113–20.  
82. Desai NR, Kohli P, Giugliano RP, O’Donoghue ML, Somaratne R, Zhou J, et al. AMG145, a monoclonal antibody against proprotein convertase subtilisin kexin type 9, significantly reduces lipoprotein(a) in hypercholesterolemic patients receiving statin therapy: an analysis from the LDL-C Assessment with Proprotein Convertase Subtilisin Kexin Type 9 Monoclonal Antibody Inhibition Combined with Statin Therapy (LAPLACE)-Thrombolysis in Myocardial Infarction (TIMI) 57 trial. Circulation. 2013 Aug 27;128(9):962–9.  
83. Giugliano RP, Desai NR, Kohli P, Rogers WJ, Somaratne R, Huang F, et al. Efficacy, safety, and tolerability of a monoclonal antibody to proprotein convertase subtilisin/kexin type 9 in combination with a statin in patients with hypercholesterolaemia (LAPLACE-TIMI 57): a randomised, placebo-controlled, dose- ranging, phase 2 study. Lancet. 2012 Dec 8;380(9858):2007–17.  
84. Koren MJ, Scott R, Kim JB, Knusel B, Liu T, Lei L, et al. Efficacy, safety, and tolerability of a monoclonal antibody to proprotein convertase subtilisin/kexin type 9 as monotherapy in patients with hypercholesterolaemia (MENDEL): a randomised, double- blind, placebo-controlled, phase 2 study. Lancet. 2012 Dec 8;380(9858):1995–2006.  
85. Raal F, Scott R, Somaratne R, Bridges I, Li G, Wasserman SM, et al. Low-density lipoprotein cholesterol-lowering effects of AMG 145, a monoclonal antibody to proprotein convertase subtilisin/kexin type 9 serine protease in patients with heterozygous familial hypercholesterolemia: the Reduction of LDL-C with PCSK9 Inhibition in Heterozygous Familial Hypercholesterolemia Disorder  (RUTHERFORD) randomized trial. Circulation. 2012 Nov 13;126(20):2408–17. 86. Sullivan D, Olsson AG, Scott R, Kim JB, Xue A, Gebski V, et al. Effect of a monoclonal antibody to PCSK9 on low-density lipoprotein cholesterol levels in statin-intolerant patients: the GAUSS randomized trial. JAMA. 2012 Dec 19;308(23):2497–506.  
87. Dias CS, Shaywitz AJ, Wasserman SM, Smith BP, Gao B, Stolman DS, et al. Effects of AMG 145 on low-density lipoprotein cholesterol levels: results from 2 randomized, double-blind, placebo-controlled, ascending-dose phase 1 studies in healthy volunteers and hypercholesterolemic subjects on statins. J Am Coll Cardiol. 2012 Nov 6;60(19):1888–98.  
88. Conitec (Comissão Nacional de Incorporação de Tecnologias no SUS). Evolocumabe para tratamento de pacientes com hipercolesterolemia familiar homozigótica: Relatório de Recomendação, Jan 2018.[Internet]. Ministério da Saúde, 2018[acesso em 12 set 2018]. Disponível em: <u>http://conitec.gov.br/images/Consultas/Relatorios/2018/Relatorio_Evolucumabe_CP01_ 2018.pdf.</u>  
89. Farnier M, Jones P, Severance R, Averna M, Steinhagen-Thiessen E, Colhoun HM, et al. Efficacy and safety of adding alirocumab to rosuvastatin versus adding ezetimibe or doubling the rosuvastatin dose in high cardiovascular-risk patients: The ODYSSEY OPTIONS II randomized trial. Atherosclerosis. 2016 Jan;244:138–46.  
90. Bays H, Gaudet D, Weiss R, Ruiz JL, Watts GF, Gouni-Berthold I, et al. Alirocumab as Add-On to Atorvastatin Versus Other Lipid Treatment Strategies: ODYSSEY OPTIONS I Randomized Trial. J Clin Endocrinol Metab. 2015 Aug;100(8):3140–8.  
91. Roth EM, Taskinen M-R, Ginsberg HN, Kastelein JJP, Colhoun HM, Robinson JG, et al. Monotherapy with the PCSK9 inhibitor alirocumab versus ezetimibe in patients with hypercholesterolemia: results of a 24 week, double-blind, randomized Phase 3 trial. Int J Cardiol. 2014 Sept;176(1):55–61.  
92. Cannon CP, Cariou B, Blom D, McKenney JM, Lorenzato C, Pordy R, et al. Efficacy and safety of alirocumab in high cardiovascular risk patients with inadequately controlled hypercholesterolaemia on maximally tolerated doses of statins: the ODYSSEY COMBO II randomized controlled trial. Eur Heart J. 2015 may 14;36(19):1186–94.  
93. Kereiakes DJ, Robinson JG, Cannon CP, Lorenzato C, Pordy R, Chaudhari U, et al. Efficacy and safety of the proprotein convertase subtilisin/kexin type 9 inhibitor alirocumab among high cardiovascular risk patients on maximally tolerated statin therapy: The ODYSSEY COMBO I study. Am Heart J. 2015 June;169(6):906-915.e13.  
94. Kastelein JJP, Ginsberg HN, Langslet G, Hovingh GK, Ceska R, Dufour R, et al. ODYSSEY FH I and FH II: 78 week results with alirocumab treatment in 735 patients with heterozygous familial hypercholesterolaemia. Eur Heart J. 2015 Nov 14;36(43):2996–3003.  
95. Robinson JG, Farnier M, Krempf M, Bergeron J, Luc G, Averna M, et al. Efficacy and safety of alirocumab in reducing lipids and cardiovascular events. N Engl J Med. 2015 Apr 16;372(16):1489–99.  
96. Ginsberg HN, Rader DJ, Raal FJ, Guyton JR, Baccara-Dinet MT, Lorenzato C, et al. Efficacy and Safety of Alirocumab in Patients with Heterozygous Familial Hypercholesterolemia and LDL-C of 160 mg/dl or Higher. Cardiovasc Drugs Ther. 2016 Oct;30(5):473–83.  
97. Cardiovascular Outcomes with Alirocumab After Acute Coronary Syndrome: Results of the ODYSSEY Outcomes  
Trial, ACC2018 [Internet]. 2018 [citado 23 de abril de 2018]. Disponível em: https://accscientificsession.acc.org/features/2018/03/video-sanofi- regeneron  
98. Guo J, Meng F, Ma N, Li C, Ding Z, Wang H, et al. Meta-analysis of safety of the coadministration of statin with fenofibrate in patients with combined hyperlipidemia. Am J Cardiol. 2012 Nov 1;110(9):1296–301.  
99. Goldie C, Taylor AJ, Nguyen P, McCoy C, Zhao X-Q, Preiss D. Niacin therapy and the risk of new-onset diabetes: a meta-analysis of randomised controlled trials. Heart. 2016 Feb;102(3):198–203.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **11 REFERÊNCIAS** -->
ESTATINAS: ATORVASTATINA, PRAVASTATINA E SINVASTATINA; FIBRATOS: BEZAFIBRATO, CIPROFIBRATO, ETOFIBRATO, FENOFIBRATO E  
GENFIBROZILA; E ÁCIDO NICOTÍNICO.  
Eu, ___________________________________________________________________________(nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados  
ao uso de **estatinas** , **fibratos** e **ácido nicotínico** , indicados para o tratamento da **dislipidemia** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico ____________________________  
___________________________________________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que os medicamentos que passo a receber podem trazer as seguintes melhoras:  
- estatinas: prevenção de eventos cardiovasculares maiores, incluindo morte, infarto agudo do miocárdio (IAM), acidente vascular cerebral (AVC) e revascularização, entre outros;  
- fibratos: prevenção de pancreatite aguda;  
- ácido nicotínico: prevenção de eventos cardiovasculares maiores.  
Fui também claramente informado(a) a respeito das seguintes contraindicações **,** potenciais efeitos adversos e riscos do  
uso destes medicamentos:  
- as estatinas não devem ser utilizadas durante a gestação; em doses usuais são bem toleradas, com baixa incidência de efeitos adversos;  
- os efeitos adversos mais frequentes das estatinas são prisão de ventre, diarreia, gases, dor de estômago, tontura, dor de cabeça, náusea, alergias de pele; efeitos menos frequentes (necessitam, porém, de atenção médica imediata, podendo ser fatais) são dores musculares, cãibras, febre, cansaço, fraqueza, que caracterizam a mialgia ou rabdomiólise; e efeitos mais raros são impotência, insônia;  
- não se sabe ao certo os riscos do uso de fibratos na gravidez; portanto, caso engravide, comunicarei o médico imediatamente;  
- os fibratos podem induzir o aparecimento de cálculos biliares, estando contraindicados para pacientes com esta doença;  
- os efeitos adversos dos fibratos são desordens no sangue (anemia, leucopenia, trombocitopenia), angina, arritmias cardíacas, pancreatite, cálculos biliares, problemas no fígado e nos rins, sintomas gripais, piora de úlcera, coceiras e alergia de pele;  
- não há relatos de efeitos do uso de ácido nicotínico na gravidez;  
- os efeitos adversos do ácido nicotínico (com doses mais altas) são arritmias cardíacas, diarreia, tonturas, secura dos olhos e de pele, aumento de glicose no sangue, náusea, vômitos, dor de estômago, coceiras; e são efeitos de menor incidência dor de cabeça, calorões no rosto e no pescoço;  
 o risco de rabdomiólise aumenta com o uso concomitante dos medicamentos.  
Estou ciente de que o uso destes medicamentos não substitui outras medidas para diminuição dos níveis de colesterol e triglicerídeos, tais como dieta adequada, controle do peso corporal e prática de atividade física.  
Estou também ciente de que o medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso  
não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. ( ) Sim ( ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- ( ) atorvastatina ( ) bezafibrato ( ) ciprofibrato ( ) etofibrato ( )  ácido nicotínico ( ) sinvastatina ( ) fenofibrato ( ) pravastatina  
- ( ) genfibrozila  
|Local:|Data:|
|---|---|
|Nome do paciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||  
Documento de identificação do responsável legal:  
|Assinatura do paciente ou do responsável legal|||
|---|---|---|
|Médico responsável:<br>Assinatura e carimbo do médico Data:|CRM:|UF:|  
**NOTA:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **11 REFERÊNCIAS** -->
Este PCDT se destina a profissionais da saúde, pacientes com Dislipidemia e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde. Depois da publicação, em 30/07/2019, da Portaria Conjunta SAES/SCTIE n<sup>o</sup> 8, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia, pela necessidade de se excluírem apresentações farmacêuticas que ficaram sem registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). Para tal, foi também adequado o Relatório de Recomendação n.º 451/2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
À 104ª Reunião Ordinária da Conitec, realizada dia 09/12/2021, havia sido analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários caducaram ou foram cancelados no Brasil. Àquela ocasião, foi deliberado, por unanimidade, recomendar a exclusão de ácido nicotínico em comprimidos de 250mg e 750mg de liberação prolongada, fluvastatina em cápsulas de 20mg e 40mg e lovastatina em comprimidos de 10mg, 20mg e 40mg. A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE/MS nº 83, de 29/12/2021. Por fim, o tema foi apresentado como informe à 96ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22/02/2022 e também à 106ª Reunião Ordinária da Conitec, em 10/03/2022.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **1) LEVANTAMENTO DE INFORMAÇÕES PARA PLANEJAMENTO DA REUNIÃO COM OS ESPECIALISTAS** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), sítio da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), Sistema de gerenciamento da tabela de procedimentos, medicamentos e órteses, próteses e materiais do SUS (SigTAP) e o Protocolo Clínico e Diretriz Terapêutica (PCDT) de Dislipidemia vigente para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar:  
- O tratamento no SUS segue o orientado no PCDT Dislipidemia: prevenção de eventos cardiovasculares e pancreatite,  
- conforme a Portaria SAS/MS nº. 200, de 25 de fevereiro de 2013.  
- Os medicamentos atualmente disponíveis são: atorvastatina, , pravastatina, sinvastatina, bezafibrato, ciprofibrato,  
- etofibrato, fenofibrato, genfibrozila e ácido nicotínico.  
- Não há solicitação de nenhuma nova tecnologia na CONITEC.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **2) REUNIÃO COM ESPECIALISTAS** -->
Foi realizada reunião com o consultor especialista e metodologistas do comitê elaborador dos PCDT, na qual foram apresentados os resultados do levantamento de informações realizado pelos metodologistas. Os consultores especialistas indicaram a necessidade de avaliação de inclusão de ezetimiba.  
Sendo assim, foi estabelecido que o Protocolo se destina a pacientes com dislipidemia, de ambos os sexos, sem restrição de idade, e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.

---

<!-- METADADOS: doenca: Dislipidemia | secao: **3) BUSCAS NA LITERATURA PARA ATUALIZAÇÃO DO PCDT** -->
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre **intervenções terapêuticas** definidas pela pergunta PICO estabelecida no **Quadro A** .  
**Quadro A –** Pergunta PICO – intervenções terapêuticas  
|População|Pacientes com dislipidemia|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Sem restrição de comparadores|
|Desfechos|Segurança e eficácia – mortalidade total e cardiovascular; pancreatite|
|Tipos de estudos|Meta-análises e ensaios clínicos|  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Publicados em periódicos de alto impacto ou prestígio a partir de 1º de setembro de 2012.  
O **Quadro B** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados. Os artigos relacionados ao medicamento ezetimiba foram avaliados em parecer técnico científico (PTC) submetido à CONITEC, que deliberou pela sua não incorporação<sup>77</sup> .  
**Quadro B –** Buscas sobre intervenções terapêuticas: meta-análises.  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via<br>PubMed)|(("dyslipidemias"[MeSH Terms] OR<br>"dyslipidemias"[All Fields]) OR ("hyperlipidaemia"[All<br>Fields] OR "hyperlipidemias"[MeSH Terms] OR|19|Incluídos: 8<br>Excluídos: 11|
|Data da busca:<br>22/05/2018|"hyperlipidemias"[All Fields] OR "hyperlipidemia"[All<br>Fields]) OR ("hypercholesterolaemia"[All Fields] OR<br>"hypercholesterolemia"[MeSH Terms] OR<br>"hypercholesterolemia"[All Fields]) OR<br>("hypertriglyceridaemia"[All Fields] OR<br>"hypertriglyceridemia"[MeSH Terms] OR<br>"hypertriglyceridemia"[All Fields]) OR<br>("hyperlipoproteinaemia"[All Fields] OR<br>"hyperlipoproteinemias"[MeSH Terms] OR<br>"hyperlipoproteinemias"[All Fields] OR<br>"hyperlipoproteinemia"[All Fields]) OR<br>("hypolipoproteinaemia"[All Fields] OR<br>"hypolipoproteinemias"[MeSH Terms] OR<br>"hypolipoproteinemias"[All Fields] OR<br>"hypolipoproteinemia"[All Fields])) AND<br>(("antilipaemic agents"[All Fields] OR "hypolipidemic<br>agents"[Pharmacological Action] OR "hypolipidemic<br>agents"[MeSH Terms] OR ("hypolipidemic"[All Fields]||-<br>2 não estudaram a<br>população de interesse;<br>-<br>1 estudo sem<br>resultados publicados;<br>-<br>1 não é ensaio clínico<br>nem meta- análise;<br>-<br>6 não avaliaram<br>intervenção de interesse;<br>-<br>1 não avaliou<br>desfecho de interesse.|  
||AND "agents"[All Fields]) OR "hypolipidemic<br>agents"[All Fields] OR ("antilipemic"[All Fields] AND<br>"agents"[All Fields]) OR "antilipemic agents"[All<br>Fields]) OR ("anticholesteremic<br>agents"[Pharmacological Action] OR "anticholesteremic<br>agents"[MeSH Terms] OR ("anticholesteremic"[All<br>Fields] AND "agents"[All Fields]) OR<br>"anticholesteremic agents"[All Fields]) OR<br>(hydroxymethylglutarylcoa[All Fields] AND<br>("oxidoreductases"[MeSH Terms] OR<br>"oxidoreductases"[All Fields] OR "reductase"[All<br>Fields]) AND ("antagonists and inhibitors"[Subheading]<br>OR ("antagonists"[All Fields] AND "inhibitors"[All<br>Fields]) OR "antagonists and inhibitors"[All Fields] OR<br>"inhibitors"[All Fields])) OR ("lovastatin"[MeSH<br>Terms] OR "lovastatin"[All Fields]) OR<br>("simvastatin"[MeSH Terms] OR "simvastatin"[All<br>Fields]) OR ("pravastatin"[MeSH Terms] OR<br>"pravastatin"[All Fields]) OR ("atorvastatin<br>calcium"[MeSH Terms] OR ("atorvastatin"[All Fields]<br>AND "calcium"[All Fields]) OR "atorvastatin<br>calcium"[All Fields] OR "atorvastatin"[All Fields]) OR<br>("rosuvastatin calcium"[MeSH Terms] OR<br>("rosuvastatin"[All Fields] AND "calcium"[All Fields])<br>OR "rosuvastatin calcium"[All Fields] OR<br>"rosuvastatin"[All Fields]) OR<br>("fluvastatin"[Supplementary Concept] OR<br>"fluvastatin"[All Fields])) AND<br>("mortality"[Subheading] OR "mortality"[All Fields]<br>OR "mortality"[MeSH Terms]) AND ((Clinical<br>Trial[ptyp] OR Meta- Analysis[ptyp]) AND<br>("2012/09/01"[PDAT] : "3000/12/31"[PDAT]) AND<br>jsubsetaim[text])||
|---|---|---|
|Medline (via<br>PubMed)<br>Data da busca:<br>22/05/2018|(("dyslipidemias"[MeSH Terms] OR<br>"dyslipidemias"[All Fields]) OR ("hyperlipidaemia"[All<br>Fields] OR "hyperlipidemias"[MeSH Terms] OR<br>"hyperlipidemias"[All Fields] OR "hyperlipidemia"[All<br>Fields]) OR ("hypercholesterolaemia"[All Fields] OR<br>"hypercholesterolemia"[MeSH Terms] OR<br>"hypercholesterolemia"[All Fields]) OR<br>("hypertriglyceridaemia"[All Fields] OR|2<br>Incluídos: 2|  
||"hypertriglyceridemia"[MeSH Terms] OR<br>"hypertriglyceridemia"[All Fields]) OR<br>("hyperlipoproteinaemia"[All Fields] OR<br>"hyperlipoproteinemias"[MeSH Terms] OR<br>"hyperlipoproteinemias"[All Fields] OR<br>"hyperlipoproteinemia"[All Fields]) OR<br>("hypolipoproteinemias"[MeSH Terms] OR<br>"hypolipoproteinemias"[All Fields])) AND<br>(("clofibrate"[MeSH Terms] OR "clofibrate"[All<br>Fields]) OR ("bezafibrate"[MeSH Terms] OR<br>"bezafibrate"[All Fields]) OR ("gemfibrozil"[MeSH<br>Terms] OR "gemfibrozil"[All Fields]) OR<br>("fenofibrate"[MeSH Terms] OR "fenofibrate"[All<br>Fields] OR "procetofen"[All Fields]) OR<br>("fenofibrate"[MeSH Terms] OR "fenofibrate"[All<br>Fields]) OR ("clofibric acid"[MeSH Terms] OR<br>("clofibric"[All Fields] AND "acid"[All Fields]) OR<br>"clofibric acid"[All Fields]) OR<br>("etofibrate"[Supplementary Concept] OR<br>"etofibrate"[All Fields]) OR<br>("ciprofibrate"[Supplementary Concept] OR<br>"ciprofibrate"[All Fields])) AND ((Clinical Trial[ptyp]<br>OR Meta-Analysis[ptyp]) AND ("2012/09/01"[PDAT] :<br>"3000/12/31"[PDAT])<br>AND jsubsetaim[text])|||
|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da busca:<br>22/05/2018|(("dyslipidemias"[MeSH Terms] OR<br>"dyslipidemias"[All Fields]) OR ("hyperlipidaemia"[All<br>Fields] OR "hyperlipidemias"[MeSH Terms] OR<br>"hyperlipidemias"[All Fields] OR "hyperlipidemia"[All<br>Fields]) OR ("hypercholesterolaemia"[All Fields] OR<br>"hypercholesterolemia"[MeSH Terms] OR<br>"hypercholesterolemia"[All Fields]) OR<br>("hypertriglyceridaemia"[All Fields] OR<br>"hypertriglyceridemia"[MeSH Terms] OR<br>"hypertriglyceridemia"[All Fields]) OR<br>("hyperlipoproteinaemia"[All Fields] OR<br>"hyperlipoproteinemias"[MeSH Terms] OR<br>"hyperlipoproteinemias"[All Fields] OR<br>"hyperlipoproteinemia"[All Fields]) OR<br>("hypolipoproteinemias"[MeSH Terms] OR<br>"hypolipoproteinemias"[All Fields])) AND|8|Incluído: 1<br>Excluídos: 7<br>-<br>4 não avaliaram<br>desfecho de interesse;<br>-<br>2 não avaliaram<br>intervenção de interesse;<br>-<br>1 não avaliou<br>população de interesse.|  
||("niacin"[MeSH Terms] OR "niacin"[All Fields]) AND<br>((Clinical Trial[ptyp] OR Meta- Analysis[ptyp]) AND<br>("2012/09/01"[PDAT] : "3000/12/31"[PDAT]) AND<br>jsubsetaim[text])|||
|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da busca:<br>22/05/2018|(("dyslipidemias"[MeSH Terms] OR<br>"dyslipidemias"[All Fields]) OR ("hyperlipidaemia"[All<br>Fields] OR "hyperlipidemias"[MeSH Terms] OR<br>"hyperlipidemias"[All Fields] OR "hyperlipidemia"[All<br>Fields]) OR ("hypercholesterolaemia"[All Fields] OR<br>"hypercholesterolemia"[MeSH Terms] OR<br>"hypercholesterolemia"[All Fields]) OR<br>("hypertriglyceridaemia"[All Fields] OR<br>"hypertriglyceridemia"[MeSH Terms] OR<br>"hypertriglyceridemia"[All Fields]) OR<br>("hyperlipoproteinaemia"[All Fields] OR<br>"hyperlipoproteinemias"[MeSH Terms] OR<br>"hyperlipoproteinemias"[All Fields] OR<br>"hyperlipoproteinemia"[All Fields]) OR<br>("hypolipoproteinaemia"[All Fields] OR<br>"hypolipoproteinemias"[MeSH Terms] OR<br>"hypolipoproteinemias"[All Fields] OR<br>"hypolipoproteinemia"[All Fields])) AND<br>("evolocumab"[Supplementary Concept] OR<br>"evolocumab"[All Fields]) AND ((Clinical Trial[ptyp]<br>OR Meta-Analysis[ptyp]) AND ("2012/09/01"[PDAT] :<br>"3000/12/31"[PDAT])<br>AND jsubsetaim[text])|19|Incluído: 1<br>Excluídos: 18<br>- 18 não avaliaram<br>desfechos clínicos<br>relevantes.|  
|Embase|('dyslipidemias'/exp OR dyslipidemias OR|17|Incluídos: 4|
|---|---|---|---|
||'hyperlipidemia'/exp OR hyperlipidemia OR|||
|Data da busca:<br>22/05/2018|'hypercholesterolemia'/exp OR hypercholesterolemia<br>OR 'hypertriglyceridemia'/exp OR hypertriglyceridemia<br>OR 'hyperlipoproteinemia'/exp OR<br>hyperlipoproteinemia OR 'hypolipoproteinemia'/exp OR<br>hypolipoproteinemia) AND ((antilipemic AND agents<br>OR anticholesteremic) AND agents OR<br>'hydroxymethylglutarylcoa reductase inhibitors' OR<br>'lovastatin'/exp OR lovastatin OR 'simvastatin'/exp OR<br>simvastatin OR 'pravastatin'/exp OR pravastatin OR<br>'atorvastatin'/exp OR atorvastatin OR 'rosuvastatin'/exp<br>OR rosuvastatin OR 'fluvastatin'/exp OR fluvastatin)<br>AND ('mortality'/exp OR mortality) AND ([meta<br>analysis]/lim OR [controlled clinical trial]/lim) AND [1-<br>9-2012]/sd AND ([meta analysis]/lim OR [randomized<br>controlled trial]/lim) AND [priority journals]/lim||Excluídos: 13<br>-<br>5 não avaliaram<br>desfechos duros;<br>-<br>2 não estudaram a<br>população de interesse;<br>-<br>3 não são ensaio<br>clínico nem meta- análise;<br>-<br>3 não avaliaram<br>intervenção de interesse.|
|Embase|(dyslipidemias OR hyperlipidemia OR<br>hypercholesterolemia OR hypertriglyceridemia OR|11|Incluídos: 2|
|Data da busca:<br>22/05/2018|hyperlipoproteinemia OR hypolipoproteinemias) AND<br>((clofibrate OR bezafibrate OR gemfibrozil OR<br>procetofen OR fenofibrate OR clofibric) AND acid OR<br>etofibrate OR ciprofibrate) AND ([meta analysis]/lim<br>OR [randomized controlled trial]/lim) AND [1-9-<br>2012]/sd AND [priority journals]/lim||Excluídos: 9<br>-<br>1 não avaliou a<br>população de interesse;<br>-<br>1 não avaliou<br>desfecho de interesse;<br>-<br>6 não avaliaram<br>desfechos duros;<br>-<br>1 não avaliou<br>intervenção de interesse.|
|Embase<br>Data da busca:<br>22/05/2018|(dyslipidemias OR hyperlipidemia OR<br>hypercholesterolemia OR hypertriglyceridemia OR<br>hyperlipoproteinemia OR hypolipoproteinemias) AND<br>niacin AND [priority journals]/lim AND ([meta<br>analysis]/lim OR [randomized controlled trial]/lim)<br>AND [1-9-2012]/sd|0|0|  
|Embase|(dyslipidemias OR hyperlipidemia OR<br>hypercholesterolemia OR hypertriglyceridemia OR|23|Incluído: 1|
|---|---|---|---|
|Data da busca:|hyperlipoproteinemia OR hypolipoproteinemia) AND||Excluídos: 22|
|22/05/2018|evolocumab AND [1-9-2012]/sd AND [priority||- 22 não avaliaram|
||journals]/lim AND ([meta analysis]/lim OR<br>[randomized controlled trial]/lim)||desfechos clínicos<br>relevantes ou já haviam<br>sido encontrados na busca<br>do PubMed (duplicata).|  
**APÊNDICE 2 – Escore de risco de Framingham**  
|||Homens||||||Mulheres||||
|---|---|---|---|---|---|---|---|---|---|---|---|
|Ida|de (em anos)|||Pontos||Idade|||Po|ntos||
||20-34|||-9||20-34||||-7||
||35-39|||-4||35-39||||-3||
||40-44|||0||40-44||||0||
||45-49|||3||45-49||||3||
||50-54|||6||50-54||||6||
||55-59|||8||55-59||||8||
||60-64|||10||60-64||||10||
||65-69|||11||65-69||||12||
||70-74|||12||70-74||||14||
||75-79|||13||75-79||||16||
|Colesterol|idade|idade|idade|idade|idade|Colesterol|idade|idade|idade|idade|idade|
|Total, mg/dL|20-39|40-49|50-59|60-69|70-79|Total, mg/dL|20-39|40-49|50-59|60-69|70-79|
|Até 160|0|0|0|0|0|Até 160|0|0|0|0|0|
|160-199|4|3|2|1|0|160-199|4|3|2|1|1|
|200-239|7|5|3|1|0|200-239|8|6|4|2|1|
|240-279|9|6|4|2|1|240-279|11|8|5|3|2|
|280 ou mais|11|8|5|3|1|280 ou mais|13|10|7|4|2|  
<!-- Start of picture text -->
20-39 40-49 50-S9 60-69 70-79 20-39 40-49 50-59 60-69 70-79<br>“Nio————<C~CS 0 0) 0 0) Nao 0 0 0) 0 0)<br>se | 8 | 5 | 3 | 1 | 1 Sim | 9 | 7 | 4 | 2 | 1<br><!-- End of picture text -->  
|HDL colesterol (mg/dL)<br>~~a~~||Pontos<br>|HDL colesterol (mg/dL)<br>|<br>|Pontos<br>||
|---|---|---|---|---|---|---|
|60 ou mais<br><br>||-1<br><br>|60 ou mais<br><br>||-1<br><br>||
|50-59<br><br>~~a~~||0<br>|50-59<br>||0<br>||
|40-49<br><br>~~a~~||1|40-49||1||
|menos de 40<br>||2|menos de 40||2||
|PA (sist. mm Hg)<br>~~a~~<br>|não tratada<br><br>|tratada<br><br>|PA (sist. mm Hg)|não tratada||tratada|
|menor que 120<br><br>|0<br> <br>|0<br> <br>|menor que 120|0||0|
|120-129<br><br><br>~~a~~|0<br> <br>|1<br> <br>|120-129|1||3|
|130-139<br><br>~~a ~~|1<br>|2<br>|130-139<br>|2<br>||4<br>|
|140-159<br> <br><br>|1<br> <br>|2<br> <br><br>|140-159<br> <br>|3<br> <br>|<br>|5<br> <br>|
|160 ou maior<br><br>~~a~~|2<br>|3<br><br>~~Ge~~|160 ou maior<br>|4<br>||6<br>|  
|Total de pontos|Risco absoluto em 10 anos (%)|Total de pontos|Risco absoluto em 10 anos (%)|
|---|---|---|---|
|menos de 0|Menos de 1|Menos de 9|Menos de 0|
|0|1|9|1|
|1|1|10|1|
|2|1|11|1|
|3|1|12|1|
|4|1|13|2|
|5|2|14|2|
|6|2|15|3|
|7|3|16|4|
|8|4|17|5|
|9|5|18|6|
|10|6|19|8|
|11|8|20|11|
|12|10|21|14|
|13|12|22|17|
|14|16|23|22|
|15|20|24|27|
|16|25|25 ou mais|30 ou mais|
|17 ou mais|30 ou mais|||  
Extraído de IV Diretrizes Brasileiras de Dislipidemia<sup>9</sup> .

---

