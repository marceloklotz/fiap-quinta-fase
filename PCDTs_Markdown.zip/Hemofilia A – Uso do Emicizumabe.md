<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 12, DE 09 DE OUTUBRO DE 2024.  
Aprova o Protocolo de Uso de Emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos de uso de tecnologias em saúde são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 923/2024 e o Relatório de Recomendação nº 926 de agosto de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo de Uso – de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito do uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria Conjunta SAES/SECTICS nº 15, de 26 de agosto de 2021, publicada no Diário Oficial da União nº 164, de 30 de agosto de 2021, seção 1, pág. 158.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: ADRIANO MASSUDA -->
CARLOS AUGUSTO GRABOIS GADELHA  
1

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **PROTOCOLO DE USO** -->
EMICIZUMABE PARA TRATAMENTO DE INDIVÍDUOS COM HEMOFILIA A MODERADA E GRAVE E INIBIDORES DO FATOR VIII DA COAGULAÇÃO SANGUÍNEA

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **INTRODUÇÃO** -->
As hemofilias são doenças hemorrágicas hereditárias, ligadas ao cromossomo X e transmitidas quase que exclusivamente a indivíduos do sexo masculino, em cerca de 70% dos casos, por mães portadoras da mutação. As hemofilias são classificadas conforme a deficiência do fator de coagulação em tipo A (deficiência do fator VIII) e tipo B (deficiência do fator IX), sendo a hemofilia A cinco vezes mais prevalente que a hemofilia B.  
Clinicamente, as hemofilias A e B são semelhantes, e categorizadas de acordo com o nível plasmático de atividade coagulante do fator deficiente em leve (maior que 5% a 40% ou maior que 0,05 unidades a 0,40 unidades internacionais [UI/mL]), moderada (de 1% a 5% ou de 0,01 UI/mL a 0,05 UI/mL) ou grave (inferior a 1% ou inferior a 0,01 UI/mL)<sup>1</sup> . Devido à redução da atividade destes fatores da coagulação, a principal manifestação clínica são hemorragias espontâneas ou pós-traumáticas, que ocorrem mais comumente nas articulações e músculos, mas que podem comprometer qualquer órgão. Há uma forte correlação entre a atividade do fator deficiente e a gravidade destes sangramentos, com pacientes com as formas graves apresentando mais sangramentos espontâneos, enquanto as formas leves apresentem mais sangramentos pós-trauma.  
Conforme fisiopatologia da doença, o tratamento das hemofilias consiste principalmente na reposição do fator de coagulação deficiente, por meio dos fatores de coagulação de origem plasmática ou recombinante. Contudo, uma principal complicação do tratamento da hemofilia é o desenvolvimento de inibidores, que são aloanticorpos direcionados contra o fator de coagulação infundido durante o tratamento de reposição.  
No tratamento da hemofilia A a incidência cumulativa de inibidor do fator de coagulação é de 20% a 35%, sendo mais incidente em pacientes com a forma grave da doença. Uma vez presentes, os inibidores interferem na resposta aos sangramentos, levando à ineficiência do fator VIII de coagulação. Nestes casos, o único tratamento capaz de erradicar 60% a 80% dos inibidores é a imunotolerância, que requer a infusão periódica de altas doses do fator VIII de coagulação por longo tempo. Dessa forma, o tratamento requer o uso de agentes de _bypassing_ – concentrado de complexo protrombínico parcialmente ativado (CCPa) ou concentrado de fator VII de coagulação ativado recombinante (rFVIIa). Como 20% a 40% dos pacientes podem não responder ao tratamento inicial de imunotolerância, estes necessitam de uso contínuo de agentes de _bypassing_ , menos eficientes e mais onerosos. Além disso, deve-se considerar que os inibidores podem recidivar após o tratamento de imunotolerância<sup>2,3</sup> .  
Nesse sentido, o medicamento emicizumabe, aprovado para profilaxia de hemorragias em pacientes com hemofilia A congênita com e sem inibidor do fator VIII da coagulação<sup>4,5</sup> foi inicialmente incorporado para pacientes do Sistema Único de Saúde (SUS) por meio da Portaria SECTICS/MS n<sup>o.</sup> 62, de 26 de novembro de 2019 para pacientes com hemofilia A e inibidores contra o fator VIII que não responderam ao tratamento de imunotolerância<sup>6</sup> . A Portaria SECTICS/MS nº 55, de 5 de outubro de 2023<sup>7</sup> ampliou o  
2  
acesso a este medicamento para pacientes com hemofilia A, moderada ou grave, e inibidores contra o fator VIII, independente da resposta à imunotolerância.  
Esse medicamento é um anticorpo tipo imunoglobulina (Ig) G4 monoclonal humanizado com estrutura de dupla especificidade (anticorpo biespecífico), que se liga ao fator IX ativado e ao fator X. É produzido por tecnologia de ácido nucleico recombinante, em células de ovário de hamster chinês (do inglês _chinese hamster ovary cells_ , células CHO). O emicizumabe tem a capacidade de ligar o fator IX ativado ao fator X, restaurando a função deficiente do fator VIII ativado, necessária para a hemostasia<sup>4</sup> .  
O modo de ação e regulação do emicizumabe é muito diferente do fator VIII. Além de ser capaz de se ligar ao fator IX ativado e ao fator X, o emicizumabe é capaz de se ligar ao zimogênio fator IX e ao fator X ativado. Além disso, como anticorpo biespecífico, o emicizumabe não é regulado pelos mecanismos de ativação e inativação que regulam a atividade do fator VIII<sup>5,8,9</sup> . O uso do emicizumabe para profilaxia de rotina em pacientes com hemofilia A, com ou sem inibidores<sup>10–12</sup> resultou na redução quase total dos sangramentos. Em comparação com os agentes _bypassing_ , o emicizumabe apresentou alta efetividade na redução dos eventos hemorrágicos nos pacientes com hemofilia A e inibidores. Os esquemas de tratamento com emicizumabe recomendados resultam em níveis estáveis e prolongados do medicamento, com uma meia-vida descrita de, aproximadamente, 30 dias, e persistindo na circulação muitos meses após a última dose.  
Contudo, hemorragias podem ocorrer durante o uso profilático de emicizumabe, o que requer o tratamento hemostático adicional com fator VIII de coagulação ou agentes _bypassing_ . Além disso, a hemostasia alcançada com o emicizumabe pode não ser suficiente para controle de sangramentos mais graves e em cirurgias de grande porte, podendo, nestes casos, ser necessária reposição com agentes _bypassing_ ou fator VIII de coagulação<sup>10–12</sup> .  
Este Protocolo visa a regulamentar os critérios e procedimentos de uso do emicizumabe por pacientes com hemofilia A e inibidores do fator VIII de coagulação. O público-alvo deste Protocolo são profissionais da saúde envolvidos no cuidado integral desses indivíduos, no âmbito da atenção primária e da atenção especializada à saúde, bem como, gestores da saúde, com vistas a subsidiar as decisões clínicas e otimizar a qualidade do cuidado ofertado a esses pacientes.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D66 Deficiência hereditária do fator VIII  
- D68.3 Transtorno hemorrágico devido a anticoagulantes circulantes

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 3.1. **Diagnóstico clínico** -->
A suspeita clínica de inibidores contra o fator VIII da coagulação ocorre quando um paciente com hemofilia A passa a responder de forma inadequada à reposição com o concentrado de fator VIII da coagulação, seja durante a profilaxia ou durante o tratamento de um sangramento agudo. Em pacientes sem inibidores esta reposição deve ser suficiente para prevenir a quase totalidade dos sangramentos espontâneos,  
3  
e a controlar rapidamente quadros de sangramento agudo. Qualquer resposta distinta desta deve suscitar a suspeita clínica, e a realização de testes laboratoriais específicos para este fim<sup>1,2</sup> .

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 3.2. **Diagnóstico laboratorial** -->
O teste laboratorial capaz de identificar a presença de inibidores é conhecido como “Teste de Bethesda modificado” ou “quantificação de inibidores”, que determina os títulos de anticorpos inibitórios no plasma do paciente. O resultado é liberado em Unidades Bethesda (UB/mL). Valores até 0,6 UB/mL são considerados negativos<sup>2</sup> . Detalhes adicionais sobre a realização e interpretação deste ensaio podem ser encontrados no Manual de Diagnóstico Laboratorial das Coagulopatias Hereditárias e Plaquetopatias<sup>14</sup> .

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **CRITÉRIOS DE INCLUSÃO** -->
A seguir apresentamos os critérios de inclusão que tornam elegíveis os pacientes para este Protocolo. Como parte dos pacientes com inibidores contra o fator VIII podem fazer parte do programa de imunotolerância, e esta participação pode modificar os critérios de inclusão, torna-se necessário que os critérios de inclusão sejam apresentados separadamente para estes dois grupos.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 4.1. **Critérios de inclusão para pacientes em imunotolerância** -->
Paciente com hemofilia A congênita, moderada ou grave, com inibidores, em tratamento de imunotolerância no momento da solicitação, independentemente do título de inibidor atual.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 4.2. **Critérios de inclusão para pacientes que não estão realizando imunotolerância** -->
Paciente com hemofilia A congênita, moderada ou grave, com inibidores clinicamente relevantes, definidos neste Protocolo como: (a) título no momento da entrada no protocolo acima de 2UB/mL; e (b) com necessidade documentada de uso de agentes de _bypassing_ antes da inclusão.  
Observação: pacientes com títulos de inibidores entre 0,6 UB/mL e 2 UB/mL devem ser reexpostos ao fator VIII para confirmação da resposta anamnéstica, independente de caracterização anterior de títulos acima de 2 UB/mL. Caso estes pacientes tenham dosagem acima de 2 UB/mL nos 6 meses anteriores, e o critério de inclusão (b) esteja contemplado, o paciente poderá ser incluído sem necessidade de reexposição.  
Nota 1: a quantificação de inibidor deve ser documentada através de laudo laboratorial completo (com timbre e assinatura do responsável técnico), com data de até 3 meses antes da solicitação de inclusão. E os demais critérios de inclusão devem ser evidenciados e justificados através de relatório médico solicitando e justificando a inclusão do paciente neste protocolo.  
Nota 2: a reexposição ao fator VIII para pacientes com títulos entre 0,6 UB/mL e 2 UB/mL deverá ser feita através da infusão de 25 U/kg a 50 U/kg de fator VIII (preferencialmente aquele associado ao desenvolvimento do inibidor), seguido pela coleta de nova quantificação de inibidor de fator VIII, após 1 semana a 4 semanas desta infusão, a critério de cada Centro de Tratamento de Hemofilia (CTH). Esta verificação da presença de resposta anamnéstica pode ser feita sempre que indicada pela equipe médica.  
Nota 3: pacientes cujo diagnóstico inicial da presença do inibidor for feito posteriormente à implementação deste Protocolo de Uso poderão ser incluídos sem a necessidade de documentação do uso prévio de agentes de _bypassing_ , desde que haja evidência da relevância clínica do inibidor, que pode ser atestada pela redução ou perda da resposta ao fator VIII ou pela persistência de títulos acima de 2UB/mL em mais de uma quantificação.  
4

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação ao emicizumabe  
deverão ser excluídos ao uso do medicamento.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.1. **Avaliação clínica e laboratorial prévia à terapia com emicizumabe** -->
Devido a especificidades do uso de emicizumabe, a avaliação clínica e laboratorial prévia à terapia  
com este medicamento deverá contemplar:  
- Revisão do histórico médico concernente à hemofilia A e suas complicações;  
- Revisão de qualquer outro histórico médico – clínico e laboratorial - relevante;  
- Revisão de qualquer histórico pessoal ou familiar que sugira risco aumentado de microangiopatia  
- trombótica e/ou outros eventos tromboembólicos e;  
- Título do inibidor (teste de Bethesda modificado) de, no máximo, 90 dias antes da solicitação do emicizumabe.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Inclusão do paciente no sistema informatizado** -->
O Sistema HemovidaWeb Coagulopatias (HWC) do Ministério da Saúde, por meio do qual são acompanhadas todas as dispensações e infusões de emicizumabe pela CGSH/Ministério da Saúde, foi parametrizado para organizar a inclusão, exclusão, acompanhamento dos pacientes e prescrição de emicizumabe.  
O médico deverá solicitar a inclusão do paciente para uso do emicizumabe por meio do preenchimento do formulário próprio do HWC. A solicitação deverá incluir o _upload_ do relatório médico com laudo laboratorial completo que comprova a presença do inibidor, nos títulos determinados para inclusão. Para inclusão do paciente, a solicitação será validada pelo Comitê Técnico de Assessoramento (CTA) do Ministério da Saúde.  
Além disso, os seguintes critérios devem ser obrigatoriamente observados para na solicitação de inclusão do paciente:  
- Cadastro ativo do paciente no sistema HWC do Ministério da Saúde;  
- Avaliação favorável da equipe multidisciplinar do CTH e existência de condição para transporte, armazenamento e aplicação do medicamento, com base no checklist fornecido por este protocolo (Apêndice 1), e documentada pela assinatura do Termo de anuência específico (Apêndice 2).  
- Assinatura de termo de esclarecimento e responsabilidade pelo paciente ou seu responsável  
- (Apêndice 3).  
- Compromisso do paciente, pais ou responsáveis a registrar todas as infusões em planilha específica ou similar/diário de infusão (Apêndice 4) e apresentá-la ao CTH até, no máximo, a cada 2 meses, assim como a devolução dos frascos do medicamento para garantia do descarte adequado e adesão ao tratamento,  
que são condições essenciais para liberação de novos tratamentos.  
5  
A seguir, em posse destes documentos, o CTH deverá fazer o _upload_ dos formulários de anuência e consentimento (Apêndices 2 e 3) no sistema HWC. Estes deverão ser completamente preenchidos, assinados e armazenados no CTH. Somente após esse processo, o paciente estará apto a receber o medicamento.  
Salienta-se que o sistema HWC permitirá a inclusão de um único arquivo. Logo, o solicitante deverá unir todos os arquivos em um único documento: termo de anuência da equipe multiprofissional (Apêndice 2), termo de esclarecimento e responsabilidade (Apêndice 3), além do laudo laboratorial e relatório médico demonstrando a presença de inibidor (Nota 1 do item 5 deste Protocolo), de acordo com os parâmetros estabelecidos no sistema HWC.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Cuidados relacionados ao uso prévio de agentes** **_bypassing_** -->
O CCPa não deve ser dispensado a nenhum paciente que estiver em uso ou for iniciar o uso de emicizumabe. Por isso, antes de iniciar o uso de emicizumabe, todos os pacientes deverão ter utilizado todos os frascos de CCPa que estiverem em sua posse, seja em seu domicílio, trabalho, unidade básica de saúde, pronto atendimento ou em qualquer outro local. O CTH deverá se responsabilizar pela estrita observação e controle de devolução de todos os frascos de CCPa e registrar essa devolução e se responsabilizar pelo seu processamento. Os agentes _bypassing_ (CCPa e rFVIIa) devem ser interrompidos, pelo menos, 24 horas antes do início do tratamento com emicizumabe.  
Todo paciente, antes de iniciar o uso de emicizumabe, deverá receber um plano de tratamento individualizado para episódios hemorrágicos enquanto estiver em tratamento com emicizumabe (Apêndice 5), com os contatos com o CTH ou serviço de emergência em caso de urgência.  
O setor de farmácia do CTH poderá dispensar, juntamente com o emicizumabe, uma (1) dose de rFVIIa (90 mcg/kg), que deverá ser utilizada por infusão intravenosa no caso de haver hemorragia persistente.  
Excepcionalmente, caso o paciente resida a mais de 3 horas do Centro de Hemofilia ou Hospital, este poderá dispensar duas (2) doses de rFVIIa (90 mcg/kg) (conforme seção Início do tratamento).

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.3. **Início do tratamento com emicizumabe** -->
Antes da primeira aplicação do emicizumabe, o médico e o profissional de enfermagem deverão se informar com o paciente ou seu responsável sobre a data da última infusão de CCPa (que deverá ser anotada no prontuário) e controlar a devolução de todos os frascos que estiverem em sua posse, que deverá ser registrada pela equipe multidisciplinar.  
O emicizumabe deverá ser administrado no CTH nas semanas 1 e 5 do início do tratamento. Nas semanas 2 a 4 de tratamento, o emicizumabe poderá ser administrado em alguma unidade de saúde, mediante acordo estabelecido com o CTH.  
Ressalta-se que, nas primeiras 4 semanas de tratamento, o paciente deve utilizar a dose de ataque, que consistem em 3 mg/kg a cada semana. Os pacientes serão observados por pelo menos 30 minutos após a primeira infusão.  
6  
Nas semanas 2, 3 e 4 de tratamento, os pacientes ou seus responsáveis, respectivamente, deverão aprender como autoadministrar ou administrar o medicamento. A autoaplicação não é recomendada para crianças menores de 7 anos de idade<sup>15</sup> . Mas sempre que possível, a administração do medicamento deve prezar pela independência do indivíduo. Quando estas aplicações ocorrerem em outra unidade de saúde, cabe ao CTH garantir que o medicamento e o treinamento sejam feitos em conformidade com os padrões do CTH.  
Na semana 5, o paciente ou um responsável deverá proceder à aplicação sob observação de um profissional de enfermagem, no CTH, e eles deverão ser instruídos sobre o volume da dose de manutenção em termos de peso e periodicidade, de acordo com as tabelas 1, 2 e 3 do Apêndice 6. Caso a equipe multidisciplinar julgue necessário, novas infusões no CTH podem ser programadas antes da liberação para tratamento domiciliar.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.4. **Tratamento de episódios hemorrágicos durante o uso do emicizumabe** -->
A ocorrência de episódios hemorrágicos durante a profilaxia com emicizumabe pode ser decorrente das seguintes situações: (i) uso inadequado do medicamento, por dose incorreta ou falha de administração (falta de adesão ao tratamento); (ii) grande necessidade de hemostasia, como na ocorrência de trauma ou atividade que necessite de níveis hemostáticos maiores; ou (iii) desenvolvimento de anticorpo antimedicamento (ADA), ou seja, aparecimento de um anticorpo capaz de inibir a função do emicizumabe, complicação aparentemente rara. Nesta última situação, é recomendável o monitoramento da ação hemostática do emicizumabe ou a dosagem do medicamento (vide seção Critérios de interrupção)<sup>16,17</sup> .  
Embora os episódios hemorrágicos sejam drasticamente reduzidos nos pacientes em uso do emicizumabe, estes ainda podem ocorrer. Por isso, recomenda-se não iniciar o tratamento da suposta hemorragia (em especial das hemartroses e hematomas musculares não volumosos) imediatamente após a suspeita de sangramento, mas tratá-las apenas se os sintomas progredirem.  
No caso de sangramentos leves (sangramento discreto de pele e mucosas, após pequenos traumas e cortes, ou sangramento dentário) e moderados (hematoma muscular ou hemartrose), que progrediram ou não cessaram com medidas locais, os pacientes são instruídos a se administrar uma dose de 50 mcg/kg a 90 mcg/kg de rFVIIa e contatar imediatamente o CTH. Esta mesma dose poderá ser repetida de 2 horas a 4 horas, se o sangramento não tiver cessado. As infusões e os detalhes do sangramento deverão ser registrados na planilha de aplicação (Apêndice 4 ou planilha de registro similar).  
No caso de sangramentos graves (hemartrose volumosa, hematoma muscular em ílio-psoas ou com risco de síndrome de compartimento, hemorragia intracraniana, hemorragia grave após trauma, em pescoço ou garganta, e hemorragia gastrointestinal), os pacientes devem auto-administrar uma dose de 50 mcg/kg a 90 mcg/kg de rFVIIa e entrar em contato imediato com o Centro de Hemofilia ou o hospital de referência para admissão imediata. No caso de sangramentos graves, é crítico saber o título de inibidor do fator VIII, para a decisão terapêutica hemostática adjuvante, ou seja, se será administrado fator VIII da coagulação sanguínea ou agentes de _bypassing_ (rFVIIa)<sup>18</sup> .  
Para sangramentos mucosos menos graves, apenas o ácido tranexâmico pode ser suficiente. O ácido tranexâmico não deve ser usado em conjunto com o CCPa, mas pode ser usado concomitantemente com o rFVIIa.  
7  
O tratamento com CCPa deve ser sempre evitado e será usado somente se não houver outra opção; por exemplo, diante da inexistência ou falta de resposta do sangramento ao rFVIIa. Neste caso, a dose de CCPa deve ser bem inferior à utilizada normalmente em pacientes com hemofilia. Alguns estudos demonstraram boa resposta com doses de 20 UI a 30 UI por kg por dose, podendo chegar a, no máximo, 50 UI por kg por dose, mas não devendo ultrapassar 100 UI por kg por dia. A infusão de CCPa, nesses casos, deverá ser realizada no CTH ou em ambiente hospitalar preparado para atender urgências e emergências. Ademais, recomenda-se o monitoramento e vigilância de eventos tromboembólicos e da ocorrência de microangiopatia trombótica (ver Notas abaixo).  
Recomenda-se que todas as decisões de tratamento referentes ao sangramento em pacientes em uso de emicizumabe sejam tomadas em conjunto com o médico do Centro de Hemofilia responsável e treinado para o atendimento aos pacientes que tenham inibidor e documentadas nas anotações médicas do paciente. Os pacientes em uso de emicizumabe deverão receber um plano de tratamento individual com orientação sobre como se conduzir na eventualidade de um sangramento agudo (Apêndice 5) e, como já destacado, poderão ter disponíveis doses de concentrado de rFVIIa para tratamento o emergencial em seu domicílio, dependendo da avaliação do médico responsável. Esta disponibilidade pode ser revisada após 6 meses de uso de emicizumabe.  
Nota 1: os casos de suspeita de anticorpos anti-droga (ADA) serão discutidos com a equipe do Ministério da Saúde, tanto para diagnóstico quanto para continuidade de tratamento.  
Nota 2: Diante da suspeita clínica de microangiopatia trombótica, a avaliação clínica e laboratorial deve seguir os procedimentos preconizados pela boa prática médica, devendo incluir: hemograma com hematoscopia; contagem de reticulócitos; provas da função renal; provas de hemólise (LDH, bilirrubina e haptoglobina); e outros exames conforme necessidade específica de cada caso (Tempo de tromboplastina parcial ativada (TTPa), Tempo de protrombina (TP), fibrinogênio, D-dímero, entre outros).

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Planejamento cirúrgico** -->
A literatura existente sobre intervenção cirúrgica em pacientes em uso de emicizumabe ainda é limitada<sup>16,19–22</sup> . Todos os procedimentos cirúrgicos, por menores que sejam, devem ser discutidos previamente com médicos experientes na prestação de assistência à saúde de pacientes com hemofilia e inibidores e devem ser realizados em um hospital com suporte da equipe de especialistas do Centro de Hemofilia. Os casos devem ser avaliados individualmente quanto ao risco hemorrágico, porte da cirurgia e fatores locais e sistêmicos associados, além da resposta aos tratamentos hemostáticos adjuvantes. Um plano de tratamento escrito e individualizado deve ser discutido com o paciente e a família e disponibilizado a todos os médicos, incluindo a equipe do laboratório e demais envolvidos na cirurgia.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Terapia de reposição em procedimentos cirúrgicos** -->
As recomendações a seguir poderão ser alteradas, à medida que houver mais evidências disponíveis  
na literatura. De maneira geral, as recomendações incluem:  
**Em cirurgias de pequeno porte (incluindo retirada de cateter venoso central) e procedimentos odontológicos não complicados:**  
8  
O uso concomitante de antifibrinolítico (ácido tranexâmico) sistêmico ou local pode ser o suficiente. A dose do ácido tranexâmico deverá ser de 15 mg/kg/dose a 25 mg/kg/dose em adultos, e 10 mg/kg/dose em crianças a partir de 1 ano de idade, por via oral a cada 8 horas. No caso de uso intravenoso do ácido tranexâmico, deve-se administrar 10 mg/kg/dose 2 vezes a 3 vezes ao dia. No entanto, para procedimentos com maior risco hemorrágico, ou sangramento periprocedimento, deve-se considerar o uso associado de rFVIIa na dose de 90 mcg/kg, sendo que uma única dose pode ser suficiente. Pacientes com baixos títulos de inibidor podem utilizar fator VIII de coagulação. No entanto, neste caso, recomenda-se o monitoramento laboratorial, conforme recomendações para cirurgias de médio e grande porte.  
**Em cirurgias de médio e grande porte** (incluindo grandes cirurgias ortopédicas)<sup>19–22</sup> :  
Nos pacientes com baixos títulos de inibidor contra o fator VIII (isto é, menor que 5 UB/mL), devese usar fator VIII de coagulação. Entretanto, nesse caso é imprescindível o monitoramento clínico e laboratorial do nível plasmático do fator VIII (que deve ser feito pelo método cromogênico com reagentes bovinos, conforme seção Monitoramento laboratorial), para garantir que se obtenha o nível alvo de fator VIII, de acordo com tipo de procedimento, além da titulação do inibidor contra o fator VIII, pelo menos, a cada 3 dias. O monitoramento laboratorial também auxilia no caso de perda ou ausência de resposta clínica com o uso do fator VIII de coagulação. Nesse caso, deve-se suspender o seu uso e iniciar rFVIIa. Na impossibilidade de monitoramento dos títulos de inibidor antes e durante o procedimento, a reposição poderá ser feita utilizando rFVIIa, conforme recomendações para pacientes com altos títulos de inibidor.  
Nos pacientes com altos títulos de inibidor no momento da cirurgia (maior que 5 UB/mL) ou sem resposta ao fator VIII de coagulação, deve-se administrar rFVIIa na dose de 90 mcg/kg a 120 mcg/kg na indução anestésica, seguida de 50 mcg/kg a 90 mcg/kg a cada 3 horas nos primeiros 3 dias, a cada 4 horas a 6 horas do 4º dia ao 7º dia e a cada 8 horas a 12 horas entre o 8º dia e 14º dia de tratamento. O tempo de reposição deve ser decidido com base na natureza do procedimento. Nesse caso, é imprescindível o monitoramento do sangramento e também de fenômenos tromboembólicos, incluindo a microangiopatia trombótica. Para isso, é fundamental que, durante o uso do rFVIIa, o paciente seja reavaliado periodicamente para o ajuste da dose.  
Os pacientes que não apresentarem resposta hemostática adequada ao fator VIII de coagulação nem ao rFVIIa devem ser cuidadosamente avaliados quanto aos riscos e benefícios do procedimento cirúrgico, e o caso deve ser discutido individualmente para a conduta adequada, sendo recomendado o encaminhamento para avaliação do Ministério da Saúde.  
Assim, no caso de cirurgias de médio e grande porte, é de fundamental importância saber o título de inibidor do fator VIII de coagulação para a decisão sobre a terapêutica hemostática adjuvante mais adequada, se uso de fator VIII de coagulação ou rFVIIa.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.6. **Tratamento em populações específicas**<sup>**15**</sup> -->
- Uso durante gravidez e lactação: não há estudos clínicos sobre o uso de emicizumabe em gestantes. Emicizumabe deve ser utilizado durante a gravidez somente se o potencial benefício para a mãe exceder o potencial risco ao feto. Deve-se considerar que durante a gravidez e após o parto, o risco de trombose é aumentado e que várias complicações da gravidez estão associadas a um aumento do risco de coagulação intravascular disseminada. Além disso, não se sabe se emicizumabe é excretado no leite humano. Os  
9  
benefícios da amamentação no desenvolvimento e na saúde do lactente devem ser considerados, juntamente com a necessidade clínica de emicizumabe pela mãe, além de qualquer potencial efeito adverso. Mulheres em idade fértil em uso de emicizumabe devem usar contracepção efetiva durante e por, pelo menos, seis meses depois da interrupção do tratamento com o medicamento.  
- Uso geriátrico: a segurança e a eficácia de emicizumabe não foram testadas especificamente em população geriátrica. A biodisponibilidade relativa diminuiu em pacientes com a idade mais avançada, mas não foram observadas diferenças clinicamente significativas na farmacocinética do emicizumabe entre pacientes < 65 anos e pacientes ≥ 65 anos.  
- Uso em indivíduos com insuficiência renal: não existem dados disponíveis sobre o uso de emicizumabe em pacientes com insuficiência renal grave, e os dados são limitados em pacientes com insuficiência renal leve a moderada. Como emicizumabe é um anticorpo monoclonal e é eliminado por catabolismo e não por excreção renal, não se espera que seja necessária alteração da dose para pacientes com insuficiência renal.  
- Uso em indivíduos com insuficiência hepática: a segurança e a eficácia de emicizumabe não foram testadas especificamente em pacientes com insuficiência hepática. Como emicizumabe é um anticorpo monoclonal e é eliminado por catabolismo e não por metabolismo hepático, não se espera que seja necessária alteração da dose para pacientes com insuficiência hepática.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.7. **Medicamentos** -->
Emicizumabe: solução injetável com 30 mg/mL (frasco-ampola de dose única de 30 mg em 1,0 mL) e 150 mg/mL (frasco-ampola de dose única de 60 mg em 0,4 mL; 105 mg em 0,7 mL ou 150 mg em 1,0 mL).

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.8. **Esquemas de administração** -->
Durante as primeiras quatro (4) semanas de uso do emicizumabe, deve-se ficar mais vigilante com a ocorrência de sangramento, uma vez que o início da ação do medicamento pode levar alguns dias a semanas. Caso ocorra sangramento durante o uso de emicizumabe, deve-se seguir as orientações do item Tratamento de episódios hemorrágicos durante o uso do emicizumabe.  
O emicizumabe é administrado por via subcutânea. Recomenda-se que sua aplicação ocorra nos seguintes locais: parte inferior do abdômen, parte superior externa dos braços e coxas. Deve-se alternar o local da aplicação para evitar ou reduzir as reações locais. A aplicação subcutânea não deve ser realizada em áreas nas quais a pele esteja eritematosa, com hematoma, sensível ou endurecida ou em áreas nas quais existam manchas ou cicatrizes. Durante o tratamento com emicizumabe, outros medicamentos para administração subcutânea devem, preferivelmente, ser administrados em regiões anatômicas diferentes das utilizadas para a aplicação do emicizumabe.  
Ainda, ressalta-se que o emicizumabe é indicado somente para a profilaxia de sangramentos e não para tratamento das hemorragias após estas terem ocorrido.  
A dose recomendada de emicizumabe é administrada como aplicação subcutânea de 3 mg/kg, uma vez por semana, durante as primeiras 4 semanas (dose de ataque), seguido da dose de manutenção que  
10  
poderá ser distribuída como 1,5 mg/kg, uma vez por semana, 3,0 mg/kg a cada duas semanas, ou ainda 6 mg/kg a cada 4 semanas.  
A escolha do regime de doses levará em conta o peso do paciente e a economicidade de uso (Apêndice 6). Para volumes subcutâneos maiores (acima de 2 mL), pode ser necessário dividir a dose do medicamento em duas (2) injeções subcutâneas.  
Devido à concentração diferente (menor) da apresentação de 30 mg/mL esta apresentação não pode ser utilizada na mesma aplicação (seringa) que as demais apresentações. As apresentações de 150 mg/mL podem ser utilizadas na mesma aplicação (seringa). Por exemplo, um paciente de 40 kg em uso de 1,5 mg/kg, uma vez por semana (dose de 60 mg), poderia usar 2 frascos de 30 mg/mL em uma mesma aplicação/seringa. Já um paciente de 60 kg em uso de 3 mg/kg de emicizumabe a cada 2 semanas (dose de 180 mg) usaria 1 frasco de 150 mg/mL + 1 frasco de 30 mg/mL em duas aplicações/seringas diferentes.  
Deve-se priorizar esquemas de dose administrados a cada 1 semana ou 2 semanas. A disponibilidade de apresentações para aplicação a cada 4 semanas fica condicionada à avaliação da gestão do programa no Ministério da Saúde.  
O emicizumabe destina-se ao tratamento profilático de longa duração. Não são recomendados ajustes da dose do medicamento. Se um paciente deixar de receber uma injeção subcutânea programada, ele deve entrar em contato com o CTH para orientações. A superdosagem acidental pode resultar em hipercoagulabilidade, e os pacientes devem entrar em contato com seu médico imediatamente e serem monitorados.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 6.9. **Critérios de interrupção do tratamento** -->
O tratamento com emicizumabe deverá ser descontinuado nas seguintes situações:  
- Quando a avaliação médica concluir que o risco tromboembólico do uso de emicizumabe supera os benefícios. Esta condição deve ser considerada nos casos em que os pacientes apresentam eventos tromboembólicos durante o uso de emicizumabe, levando em conta a presença ou não de outros fatores de risco, bem como a reversibilidade ou não dos mesmos.  
- Demonstração da ocorrência de ADA associados à perda de eficácia do tratamento (por exemplo, aumento de eventos de sangramento de escape).  
- Ocorrência de outros eventos adversos graves que permitam a conclusão que os riscos superam os benefícios.  
Em todos estes casos, é recomendada a interação com o Ministério da Saúde, que poderá acionar o CTA para suporte à decisão dos CTH.  
Quando indicada, a interrupção do tratamento deverá ser comunicada ao Ministério da Saúde para avaliação do caso e exclusão no sistema HWC. Diante da interrupção do tratamento, o paciente deverá voltar a usar os agentes de _bypassing_ . Entretanto, devido à meia-vida longa do emicizumabe, a recomendação do uso preferencial do rFVIIa para o tratamento das hemorragias deve ser seguida por 6 meses após a interrupção do emicizumabe.  
Em caso de abandono ao tratamento por parte do paciente, o Centro de Hemofilia deve enviar ao Ministério da Saúde um relatório contendo justificativa detalhada dos motivos do abandono, assim como a ciência do paciente ou responsável em relação às implicações da mesma para seu tratamento.  
11

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **MONITORAMENTO** -->
Recomenda-se que as consultas médicas ocorram a cada 2 meses nos primeiros seis meses do uso do emicizumabe; a cada 3 meses, entre 6 meses e 12 meses de uso; e a partir do segundo ano, a cada 6 meses a 12 meses.  
Devido à complexidade dos pacientes e do seu tratamento, a assistência a pacientes com hemofilia e inibidor, o tratamento de imunotolerância e o monitoramento de uso do emicizumabe devem ser realizados nos CTH de maior complexidade (centro de referência do Estado) por equipe experiente no cuidado destes pacientes. Caso o paciente seja acompanhado no centro de hemofilia regional, o centro de referência do Estado deverá se responsabilizar pelo treinamento, monitoramento e supervisão do uso e da dispensação do medicamento pela equipe técnica daquele centro, prestando consultorias periódicas e sempre que necessário.  
Todas as doses de emicizumabe, assim como o uso de qualquer outro medicamento procoagulante (incluindo agentes _bypassing_ ), devem ser cuidadosamente registradas durante o tratamento, tanto hospitalar quanto domiciliar. De particular importância, nas novas terapias, a vigilância e notificação de qualquer evento adverso é essencial. Assim, os pacientes ou seus responsáveis deverão registrar todas as infusões de emicizumabe, bem como o uso de quaisquer outros procoagulantes e agentes _bypassing_ , utilizando o Apêndice 4 ou planilha similar, que deve retornar ao Centro de Hemofilia antes da próxima dispensação. As dispensações do emicizumabe somente poderão ser feitas mediante a apresentação do Apêndice 4 ou planilha similar preenchida e conferida pelo Centro de Hemofilia, assim como a devolução dos materiais perfuro-cortantes e frascos de emicizumabe.  
Cabe ainda ao CTH o monitoramento da adesão ao tratamento, e a tomada de medidas com o objetivo de garantir que o tratamento seja realizado em conformidade com este Protocolo de Uso. A constatação sistematizada de dificuldades de adesão por parte de pacientes deverá ser tratada individualmente pelas equipes multiprofissionais de cada CTH, às quais caberão a implementação das medidas que promovam o tratamento adequado, em conformidade com este protocolo.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 7.1. **Monitoramento laboratorial** -->
O monitoramento da resposta ao emicizumabe é essencialmente clínico e, na maior parte dos casos, não há necessidade de acompanhamento laboratorial. No entanto, em situações excepcionais o monitoramento laboratorial da resposta hemostática deste tratamento pode ser necessário<sup>23</sup> . As situações em que isso pode ser necessário são:  
- Diante da ocorrência de episódios hemorrágicos recorrentes durante a profilaxia com emicizumabe, uma vez excluída o uso inadequado do medicamento, ou seja, dose incorreta ou baixa adesão; ou  
- Vigência de grande desafio hemostático, ou seja, trauma, cirurgia de grande porte ou sangramentos graves, uma vez que o conhecimento sobre o título de inibidor do fator VIII é fundamental para a decisão de administrar pro-coagulantes adjuvantes, ou seja, se fator VIII de coagulação ou agentes de _bypassing_ , conforme descrito anteriormente<sup>23</sup> .  
12  
- Em pacientes que realizam tratamento de indução de imunotolerância, que demanda testes específicos elencados no protocolo para imunotolerância nestes pacientes.  
Este monitoramento possui especificidades técnicas quanto aos procedimentos laboratoriais, as quais serão descritas a seguir<sup>23–26</sup>

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Tipo de amostra e testes de triagem da coagulação** -->
A coleta, processamento e armazenamento de amostras de sangue de pacientes em terapia com emicizumabe devem ser os mesmos usados para determinações de tempo de tromboplastina parcialmente ativada (TTPA). Entretanto, o emicizumabe interfere com o teste de TTPa e dosagem da atividade plasmática do fator VIII da coagulação (método coagulométrico ou de 1-estágio) e demais testes baseados no TTPa. O emicizumabe encurta o TTPA e, por isso, o resultado pode ser normal ou abaixo do limite inferior do normal, mesmo após uma única dose. Isso ocorre com todos os métodos usados para determinação de TTPA até agora estudados, incluindo aqueles realizados com diferentes ativadores e fosfolipídios. O emicizumabe não tem efeito clinicamente relevante no tempo de protrombina (TP) ou nos testes de fator com base no TP, independentemente do método usado. Também não afeta o tempo de trombina nem as determinações de fibrinogênio.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Determinação do nível plasmático do fator VIII** -->
A dosagem coagulométrica da atividade de fator VIII é feita por um método que se baseia no TTPa e, portanto, não pode ser usada para medir o fator VIII em pacientes em uso de emicizumabe, mesmo após uma única dose. No entanto, o emicizumabe não afeta a determinação da atividade plasmática do fator VIII, se esta for feita usando a metodologia cromogênica com reagente de origem bovina. É importante ressaltar que os testes cromogênicos para determinação de fator VIII que usam reagentes de origem humana não são específicos para a avaliação da atividade do fator VIII se o emicizumabe estiver presente. Qualquer atividade detectada em tais testes será afetada pelo mínimo de emicizumabe presente.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Quantificação do inibidor do fator VIII** -->
O método recomendado para a determinação de inibidor do fator VIII é o teste de Bethesda Modificado, que se baseia em dosagens seriadas da atividade do fator VIII. Assim, como já explicado, este teste só pode ser usado em pacientes em uso de emicizumabe se for usada a metodologia cromogênica, com reagentes de origem bovina na sua composição<sup>23,25,26</sup> .

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Determinação da concentração de emicizumabe no plasma** -->
A concentração de emicizumabe no plasma pode ser determinada usando um teste coagulométrico modificado para atividade de fator VIII, associado a calibradores específicos de emicizumabe, cujos reagentes ainda não estão disponíveis no Brasil.  
13

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 7.2. **Avaliação de eventos adversos** -->
Os eventos adversos notificados com mais frequência e observadas em pelo menos 10% dos pacientes tratados com, ao menos, uma dose de emicizumabe foram: reações no local de aplicação, cefaleia e artralgia. Os sintomas comumente descritos de reações no local de aplicação foram eritema no local da aplicação, dor e prurido no local da aplicação. No total, quatro pacientes (1%) que participavam de estudos clínicos fase III de profilaxia com emicizumabe foram retirados do tratamento por eventos adversos, tais como microangiopatia trombótica, necrose cutânea e tromboflebite superficial, cefaleia e reação no local da aplicação. Um paciente foi retirado do estudo depois de desenvolver anticorpo neutralizante antiemicizumabe associado à perda de eficácia<sup>27</sup> .  
Durante os estudos pivotais, foram relatados casos de microangiopatia trombótica e tromboembolismo venoso quando o emicizumabe foi usado juntamente com o CCPa em doses superiores a 100 UI/kg/24 horas. Por isso, o CCPa não deve ser utilizado concomitantemente com o emicizumabe, exceto em casos estritamente necessários como, por exemplo, devido à ausência de resposta ao rFVIIa ou inexistência deste<sup>27</sup> .  
Os CTH deverão ter fluxo implantado e definido sobre notificação de eventos adversos ao emicizumabe para garantir a segurança no uso do medicamento. Quaisquer eventos adversos relacionados ao uso de emicizumabe deverão ser notificados no sistema VigiMed e no sistema de informação vigente do Programa do Ministério da Saúde (no presente, HWC) no campo próprio para registro de reações à medicamentos (acesso via dados complementares no perfil de assistência 3, para inclusão das informações de reação a medicamentos pro-coagulantes).  
Uma cópia da notificação deverá ser enviada à Coordenação Geral do Sangue e Hemoderivados (sangue@saude.gov.br) e, concomitantemente, deve-se relatar qualquer evento adverso à Agência Nacional de Vigilância Sanitária (Anvisa).

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 7.3. **Interações medicamentosas** -->
Existem poucos estudos sobre interação medicamentosa com o emicizumabe. A experiência clínica sugere a existência de interação medicamentosa entre emicizumabe e CCPa. Existe uma possibilidade de hipercoagulabilidade com o uso concomitante de rFVIIa ou fator VIII com o emicizumabe com base em experimentos pré-clínicos, embora a relevância clínica desses dados não seja conhecida. Como o emicizumabe aumenta o potencial de coagulação, a dose necessária para atingir a hemostasia durante o tratamento com o FVIIa ou FVIII pode ser mais baixa<sup>15</sup> .

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 7.4. **Manutenção de registros e dispensação do medicamento** -->
A prescrição do emicizumabe deverá ser feita e assinada pelo médico assistente. A dispensação deve ocorrer na farmácia do CTH, ao paciente ou a seu responsável, em doses suficientes para uso por 1 mês a 2 meses, no máximo, conforme a disponibilidade e seguindo o fluxo local. O médico se responsabiliza pela prescrição a cada 1 mês ou 2 meses, de acordo com as condições de cada paciente. Ao retirar o medicamento na farmácia do CTH, o paciente ou seu responsável deverá assinar documento que informe as quantidades  
14  
dispensadas e se responsabilizar pela guarda adequada e uso racional do produto, tal como orientado pela equipe multiprofissional. Antes de cada dispensação, o peso do paciente deve ser conferido e anotado e a dose recalculada, quando aplicável.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: 7.5. **Orientações sobre armazenamento do emicizumabe** -->
O emicizumabe deve ser armazenado sob refrigeração (temperatura entre 2ºC a 8ºC) e não pode ser congelado, devendo ser mantido dentro do cartucho para protegê-lo da luz. Não se deve agitar o frasco. Após retirados da refrigeração, os frascos que não forem abertos podem ser mantidos em temperatura ambiente (abaixo de 30ºC) por até sete dias. Depois de armazenados em temperatura ambiente, os frascos não abertos podem voltar à refrigeração. O tempo de armazenamento cumulativo em temperatura ambiente não deve exceder sete dias.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão dos pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com hemofilia A devem ser atendidos em serviços especializados em hemofilia, os CTH, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com hemofilia A devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de efeitos adversos.  
O emicizumabe deverá ser dispensado por farmacêutico, no âmbito do CTH.  
A fim de melhorar a rastreabilidade de medicamentos biológicos, a marca e o número do lote do produto administrado devem ser claramente registrados (ou declarados) em arquivo associado ao paciente.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
15

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **REFERÊNCIAS** -->
1. Srivastava A, Santagostino E, Dougall A, Kitchen S, Sutherland M, Pipe SW, et al. WFH Guidelines for the Management of Hemophilia, 3rd edition. Haemophilia. 2020 Aug 1;26(S6):1– 158.  
2. Collins PW, Chalmers E, Hart DP, Liesner R, Rangarajan S, Talks K, et al. Diagnosis and treatment of factor VIII and IX inhibitors in congenital haemophilia: (4th edition). Br J Haematol. 2013 Jan;160(2):153–70.  
3. Collins P, Chalmers E, Alamelu J, Hay C, Liesner R, Makris M, et al. First-line immune tolerance induction for children with severe haemophilia A: A protocol from the UK Haemophilia Centre Doctors’ Organisation Inhibitor and Paediatric Working Parties. Haemophilia. 2017 Sep 1;23(5):654–9.  
4. European Medicines Agency. Summary of Product Characteristics [Internet]. 2018 [cited 2024 May 11]. Available from: https://www.ema.europa.eu/en/medicines/human/EPAR/hemlibra  
5. NHSE. Clinical Commissioning Policy: Emicizumab as prophylaxis in people with congenital haemophilia A with factor VIII inhibitors (all ages). 2018 [cited 2024 May 11]; Available from: chrome-extension://efaidnbmnnnibpcajpcglclefindmkaj/https://www.england.nhs.uk/wpcontent/uploads/2018/07/1717-emicizumab.pdf  
6. Portaria SCTIE No. 62 de 26 de novembro de 2019 [Internet]. 2019 [cited 2024 May 11]. Available from: https://www.gov.br/conitec/pt-  
- br/midias/relatorios/portaria/2019/portariasctie_62_2019.pdf/view  
7. Portaria SECTICS No. 55, de 5 de outubro de 2023 [Internet]. 2023 [cited 2024 May 11]. Available from: https://www.gov.br/conitec/pt-br/midias/relatorios/portaria/2023/portaria-sectics-ms-n55.pdf/view  
8. Kitazawa T, Igawa T, Sampei Z, Muto A, Kojima T, Soeda T, et al. A bispecific antibody to factors IXa and X restores factor VIII hemostatic activity in a hemophilia A model. Nat Med. 2012 Oct;18(10):1570–4.  
9. Shima M, Hanabusa H, Taki M, Matsushita T, Sato T, Fukutake K, et al. Factor VIII–Mimetic Function of Humanized Bispecific Antibody in Hemophilia A. New England Journal of Medicine. 2016 May 26;374(21):2044–53.  
10. Uchida N, Sambe T, Yoneyama K, Fukazawa N, Kawanishi T, Kobayashi S, et al. A first-in-human phase 1 study of ACE910, a novel factor VIII-mimetic bispecific antibody, in healthy subjects. Blood. 2016 Mar 31;127(13):1633–41.  
11. Mahlangu J, Oldenburg J, Paz-Priel I, Negrier C, Niggli M, Mancuso ME, et al. Emicizumab Prophylaxis in Patients Who Have Hemophilia A without Inhibitors. New England Journal of Medicine. 2018 Aug 30;379(9):811–22.  
12. Mahlangu J, Oldenburg J, Paz-Priel I, Negrier C, Niggli M, Mancuso ME, et al. Emicizumab Prophylaxis in Patients Who Have Hemophilia A without Inhibitors. New England Journal of Medicine. 2018 Aug 30;379(9):811–22.  
16  
13. Conitec. Relatório de recomendação No. 841/23 [Internet]. 2023 [cited 2024 May 11]. Available from: chrome-extension://efaidnbmnnnibpcajpcglclefindmkaj/https://www.gov.br/conitec/ptbr/midias/relatorios/2023/relatorio_final_emicizumabe_com-inibidores_hemofilia_841_2023.pdf  
14. Ministério da Saúde. Manual de Diagnóstico Laboratorial das Coagulopatias Hereditárias e Plaquetopatias [Internet]. 2016 [cited 2024 May 11]. Available from: chromeextension://efaidnbmnnnibpcajpcglclefindmkaj/https://bvsms.saude.gov.br/bvs/publicacoes/manu al_diagnostico_coagulopatias_hereditarias_plaqueopatias.pdf  
15. Bula emicizumabe (Hemcibra) para profissionais da saúde [Internet]. 2023 [cited 2024 May 11]. Available from: chromeextension://efaidnbmnnnibpcajpcglclefindmkaj/https://dialogoroche.com.br/content/dam/rochedialogo/dialogo-brazil-assets/downloadable-  
assets/produtos/bulas/hemcibra/Hemcibra_Bula_Profissional.pdf  
16. Castaman G, Santoro C, Coppola A, Mancuso ME, Santoro RC, Bernardini S, et al. Emergency management in patients with haemophilia A and inhibitors on prophylaxis with emicizumab: AICE practical guidance in collaboration with SIBioC, SIMEU, SIMEUP, SIPMeL and SISET. Blood Transfusion. 2020 Mar 1;18(2):143–51.  
17. Escuriola-Ettingshausen C, Auerswald G, Königs C, Kurnik K, Scholz U, Klamroth R, et al. Optimizing the management of patients with haemophilia A and inhibitors in the era of emicizumab: Recommendations from a German expert panel. Haemophilia. 2021 May 1;27(3):e305–13.  
18. Collins PW, Liesner R, Makris M, Talks K, Chowdary P, Chalmers E, et al. Treatment of bleeding episodes in haemophilia A complicated by a factor VIII inhibitor in patients receiving Emicizumab. Interim guidance from UKHCDO Inhibitor Working Party and Executive Committee. Haemophilia. 2018 May 1;24(3):344–7.  
19. Seaman CD, Ragni M V. Emicizumab use in major orthopedic surgery. Blood Adv. 2019 Jun 11;3(11):1722–4.  
20. Kruse-Jarres R, Peyvandi F, Oldenburg J, Chang T, Chebon S, Doral MY, et al. Surgical outcomes in people with hemophilia A taking emicizumab prophylaxis: experience from the HAVEN 1-4 studies. Blood Adv. 2022 Dec 27;6(24):6140–50.  
21. Santagostino E, Mancuso ME, Novembrino C, Solimeno LP, Tripodi A, Peyvandi F. Rescue factor VIII replacement to secure hemostasis in a patient with hemophilia A and inhibitors on emicizumab prophylaxis undergoing hip replacement. Haematologica. 2019 Jul 31;104(8):e380–2.  
22. Susen S, Gruel Y, Godier A, Harroche A, Chambost H, Lasne D, et al. Management of bleeding and invasive procedures in haemophilia A patients with inhibitor treated with emicizumab (Hemlibra®): Proposals from the French network on inherited bleeding disorders (MHEMO), the French Reference Centre on Haemophilia, in collaboration with the French Working Group on Perioperative Haemostasis (GIHP). Haemophilia. 2019 Sep 1;25(5):731–7.  
23. Jenkins PV, Bowyer A, Burgess C, Gray E, Kitchen S, Murphy P, et al. Laboratory coagulation tests and emicizumab treatment A United Kingdom Haemophilia Centre Doctors’ Organisation guideline. Haemophilia. 2020 Jan 1;26(1):151–5.  
17  
24. Bowyer A, Kitchen S, Maclean R. Effects of emicizumab on APTT, one-stage and chromogenic assays of factor VIII in artificially spiked plasma and in samples from haemophilia A patients with inhibitors. Haemophilia. 2020 May 1;26(3):536–42.  
25. Adamkewicz JI, Kiialainen A, Paz-Priel I. Effects and interferences of emicizumab, a humanized bispecific antibody mimicking activated factor VIII cofactor function, on lupus anticoagulant assays. Int J Lab Hematol. 2020 Apr 1;42(2):e71–5.  
26. HEMLIBRA interferes with certain laboratory assays [Internet]. 2023 [cited 2024 May 11]. Available from: https://www.hemlibra.com/hcp/safety-side-effects/lab-monitoring.html  
27. Levy GG, Asikanius E, Kuebler P, Benchikh El Fegoun S, Esbjerg S, Seremetis S. Safety analysis of rFVIIa with emicizumab dosing in congenital hemophilia A with inhibitors: Experience from the HAVEN clinical program. Journal of Thrombosis and Haemostasis. 2019 Sep 1;17(9):1470–7.  
28. PORTARIA CONJUNTA N<sup>o</sup> 15, DE 26 DE AGOSTO DE 2021 [Internet]. 2021 [cited 2024 May 11]. Available from:  
https://bvsms.saude.gov.br/bvs/saudelegis/Saes/2021/poc0015_30_08_2021.html  
18

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **APÊNDICE 1** -->
ITENS A SEREM CHECADOS (“CHECKLIST”) PELA EQUIPE MULTIPROFISSIONAL ANTES DO INÍCIO DO TRATAMENTO COM EMICIZUMABE

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe médica** -->
- Orientação sobre as repercussões clínicas da presença de inibidores no que diz respeito ao risco de sangramentos e às mudanças no tratamento;  
- Orientação sobre o que é o emicizumabe e sua indicação (seu papel no tratamento da hemofilia);  
- Orientação sobre dose, via de aplicação, armazenamento e uso de medicações concomitantes ao  
- emicizumabe;  
- Orientação sobre eventos adversos potenciais e sobre motivos que exigiriam descontinuação;  
- Orientação sobre como proceder em caso de sangramento agudo e/ou procedimentos invasivos;  
- O paciente recebeu uma prescrição com orientações sobre as doses a serem utilizadas em caso de  
- sangramentos agudos, assim como os contatos para o caso de urgência;  
- Confirmação de que pacientes e familiares compreendem que o registro de infusões e sangramentos, assim como a devolução dos frascos utilizados são condição _sine qua non_ para manutenção do tratamento.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe de enfermagem** -->
- Confirmação de que o paciente ou responsável tem condições de ser treinado para aplicação  
subcutânea domiciliar;  
- Confirmação de que o paciente ou responsável compreende a importância da adesão ao tratamento;  
- Confirmação de que o paciente ou responsável estão de acordo em realizar o tratamento em  
conformidade com o Protocolo do Ministério da Saúde;  
- Confirmação de que pacientes e familiares compreendem que o registro de infusões e sangramentos, assim como a devolução dos frascos utilizados são condição _sine qua non_ para manutenção do tratamento.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe de serviço social** -->
- Avaliação quanto à necessidade de visita domiciliar;  
- Tomada de ações necessárias conforme visita domiciliar;  
- Confirmação de condições para armazenamento do emicizumabe (o medicamento deve ser  
armazenado  sob refrigeração entre 2ºC a 8°C, não pode ser congelado nem agitado e deve ser mantido  
dentro do cartucho para proteger da luz);  
- Confirmação de alternativas para armazenamento quando não houver condições no domicílio.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe de psicologia** -->
- Avaliação quanto à presença de qualquer aspecto psicológico relacionado ao paciente ou  
responsável que impeça o uso adequado do emicizumabe.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe de farmácia** -->
- Verificação da quantidade de frascos de complexo protrombínico que o paciente possuía no  
domicílio;  
19  
- Confirmação de que todos os frascos de complexo protrombínico que estavam de posse do paciente foram devolvidos;  
- Confirmação de que pacientes e familiares compreendem que o registro de infusões e sangramentos, assim como a devolução dos frascos utilizados são condição _sine qua non_ para manutenção do tratamento.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **APÊNDICE 2** -->
TERMO DE ANUÊNCIA DA EQUIPE MULTIPROFISSIONAL PARA INCLUSÃO PACIENTES COM HEMOFILIA A E INIBIDORES NO TRATAMENTO COM EMICIZUMABE  
A equipe multiprofissional, abaixo discriminada, está de acordo e aprovou a inclusão do paciente  
______________________________________________________________________________, data de nascimento:___/____/_____, filho de (nome da mãe): _______________________________ ________________________________________________________________________________ no  
programa de uso de emicizumabe por pacientes com hemofilia A e inibidores. Ao assinar este  
documento, a equipe assume que o paciente preencheu todos os critérios de inclusão do paciente no programa, de acordo com o protocolo vigente do Ministério da Saúde.  
|**Profissional**|**Nome**|**Registro no**<br>**conselho (no)**|**Data**|**Assinatura**|
|---|---|---|---|---|
|Médico(a)|||||
|Enfermeiro(a)|||||
|Assistente social|||||
|Psicólogo(a)|||||
|Farmacêutico(a)|||||  
20

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **APÊNDICE 3** -->
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE QUANTO AO USO DE MICIZUMABE PARA O TRATAMENTO DE PACIENTES COM HEMOFILIA A E INIBIDORES  
Eu, _________________________________________________________________________  
_______________________________________________________________________ fui informado  
(a) sobre a indicação de utilizar o medicamento emicizumabe porque tenho hemofilia A com inibidores que prejudicam meu tratamento com concentrados de fator VIII. Para começar a receber o medicamento, preciso ler, compreender e assinar este termo, estando ciente de que não se trata de um projeto de pesquisa.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **IDENTIFICAÇÃO** -->
Centro de Hemofilia: __________________________________________________________________ Nome completo do paciente: ____________________________________________________________ Data de nascimento: ____/_____/______ Número do registro no Hemovidaweb Coagulopatias: ________________________________________

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **O que é o emicizumabe?** -->
O emicizumabe é um medicamento que se liga ao fator IX e ao fator X da coagulação, exercendo a mesma função que o fator VIII, que nas pessoas com hemofilia é produzido em quantidades insuficientes para a coagulação. Ele é produzido em laboratório, usando tecnologia genética, e não é um fator da coagulação. É um produto para o tratamento da hemofilia com inibidores, que é injetado sob a pele (por via subcutânea).  
O emicizumabe age na prevenção dos sangramentos e não é indicado para tratamento de sangramento agudo.  
O emicizumabe é comprado pelo Ministério da Saúde e enviado aos centros de hemofilia, para o tratamento de pacientes com hemofilia A e inibidores do fator VIII.  
**Por que eu preciso usar o emicizumabe?**  
O emicizumabe está sendo oferecido a você porque você tem hemofilia A com inibidores persistentes contra o fator VIII, o que reduz ou elimina a efetividade do tratamento com concentrados de fator VIII da coagulação. O uso regular de emicizumabe tem como objetivo prevenir sangramentos, ou seja, atuar sob a forma de profilaxia.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Quando se usa o emicizumabe?** -->
O emicizumabe é um medicamento que é utilizado para evitar o sangramento e não para tratar o sangramento.   É muito importante que você entenda isso! Assim, você deverá receber o emicizumabe a cada 1, 2 ou 4 semanas (de acordo com a avaliação do seu médico) para prevenir os sangramentos. Caso você tenha um sangramento durante o uso do emicizumabe (o que é bastante incomum), você não poderá usar o emicizumabe para tratar o sangramento, mas, sim, usar o concentrado de fator VIII ou o concentrado de fator VII recombinante ativado. Por isso, o paciente poderá ter, a critério do seu médico, doses do rFVIIa em sua casa para uso no caso de um sangramento. O paciente ou seu responsável deverá conferir constantemente a data de validade do rFVIIa para evitar que o  
21  
medicamento tenha o seu prazo vencido. Assim, três meses antes do vencimento o paciente deve retornar o medicamento ao Centro de Hemofilia. O rFVIIa só deve ser usado em caso de um sangramento.  
**Importante** : Sob nenhuma hipótese deve-se usar o concentrado de complexo protrombínico parcialmente ativado (CPPa) enquanto se estiver em uso do emicizumabe, a não ser em casos específicos (por exemplo, na falta de resposta ao uso de rFVIIa), e sempre após a indicação expressa de seu médico do Centro de Hemofilia. Isto decorre do risco aumentado de efeitos colaterais quando estes dois medicamentos são usados ao mesmo tempo. Por isso, antes de iniciar o uso do emicizumabe todos os frascos de CPPa que estão com o paciente, em sua casa, trabalho etc. deverão ser devolvidos ao Centro de Tratamento.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Como o emicizumabe deve ser utilizado?** -->
O emicizumabe é utilizado por aplicação subcutânea, isto é debaixo da pele. Assim, seu uso não requer punção da veia. Entretanto, o paciente ou seu responsável deverão aprender a técnica correta para a aplicação subcutânea do emicizumabe durante treinamento que será agendado para você no Centro de Hemofilia.  
A dose de emicizumabe é calculada com base em seu peso, de modo que você deverá ser pesado sempre que retornar ao centro para pegar novas doses do medicamento, isto é, no máximo a cada 2 meses. Para evitar desperdícios, a equipe do Centro de Tratamentoi irá calcular a melhor dose pra você e também o intervalo de dose que é mais econômico, sem riscos para sua eficácia.  
O paciente deverá ser avaliado periodicamente pela equipe do centro para verificar se o tratamento está adequado. A cada visita médica, o paciente ou seu responsável deverá trazer a ficha de uso do medicamento devidamente preenchida com todas as informações solicitadas, constando data e horário das aplicações, ocorrência e local do sangramento e tratamento realizado. Caso o tratamento seja realizado na casa do paciente, ele deverá retornar ao Centro os frascos vazios do medicamento usado, assim como os equipos, agulhas e seringas usados, para descarte como lixo hospitalar.  
**Quais são as vantagens do uso do emicizumabe?**  
O emicizumabe é um medicamento eficaz em evitar os sangramentos nos pacientes com hemofilia A com inibidores do Fator VIII. Assim, espera-se uma significativa redução do número de sangramentos, e uma melhora na sua qualidade de vida, podendo exercer melhor as suas atividades diárias de trabalho e de estudo, entre outras. Além disso, por sua meia-vida mais longa (isto é, a duração do medicamento no organismo), a frequência de infusões é bem menor.  
**Quais são as desvantagens e efeitos colaterais do uso do emicizumabe?**  
Alguns pacientes que usaram emicizumabe nos estudos clínicos realizados desenvolveram trombose e microangiopatia trombótica. Isso ocorreu quando os pacientes usaram o emicizumabe juntamente com o CPPa. Por esse motivo, o CPPa e o emicizumabe não devem ser usados conjuntamente. Também já foi descrito a ocorrência de anticorpo anti-emicizumabe, que, apesar de raros, tornam o medicamento menos eficiente. Nesse caso, os sangramentos podem reiniciar ou aumentar. O emicizumabe é um medicamento novo e, como todo medicamento novo, você deve  estar atento a qualquer sinal ou sintoma que ocorra durante o seu uso e informar ao seu médico do Centro de Tratamento de Hemofilia.  
**O que acontece se o paciente ou seu responsável recusar o uso do emicizumabe?**  
22  
O paciente continuará a ser atendido normalmente no Centro de Hemofilia, independentemente da concordância ou não de usar o emicizumabe. Entretanto, o paciente ou seu responsável deverá estar ciente de que está recusando um medicamento eficiente no tratamento da hemofilia A com inibidores do Fator VIII. Neste caso, os sangramentos do paciente serão tratados com CPPa ou rFVIIa. Neste caso, o paciente ou seu responsável deverá assinar que a ele foi dada a oportunidade de uso do emicizumabe, que foi por ele recusada, não cabendo ao Ministério da Saúde nem ao Centro de Hemofilia serem responsabilizados por esta recusa no futuro. A qualquer momento, caso o paciente ou responsável mude de ideia, o uso de emicizumabe pode ser solicitado.  
O tratamento com emicizumabe não faz parte de um projeto de pesquisa.  
- Ao assinar este documento, o paciente ou seu responsável declara que:  
- Foi devidamente orientado e compreendeu o que é o emicizumabe e qual é a sua indicação;  
- Está ciente dos benefícios, das potenciais complicações do tratamento e de suas  
- responsabilidades quanto ao uso e retorno, três meses antes do vencimento, de medicamento não utilizado; e  
- Se compromete a cumprir todas as regras do tratamento, incluindo comparecer às consultas agendadas, coletar sangue para exames, devolver ao Centro de Hemofilia todos os frascos de CPPa antes do início do tratamento, devolver ao centro todo material das infusões domiciliares (frascos, seringas e agulhas) e não suspender o tratamento sem recomendação médica.  
Declaro que entendi as informações dadas e informo que:  
- (  ) Sim, aceito o tratamento com o emicizumabe  
- (  ) Não, não aceito o tratamento com o emicizumabe  
- (  ) Sou o paciente (   ) Sou o responsável pelo paciente  
Nome legível: ________________________________________________________  
Data: _____/_____/_______  
Assinatura: __________________________________________________________  
23

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: CONTROLE DA APLICAÇÃO DOMICILIAR DE EMICIZUMABE -->
Nome completo do paciente: ______________________________________________________________________________________________________________  
Centro de Tratamento: __________________________________________________________________________________ Data nascimento: ___/___/_____  
|**Dad**|**os gerais**|||**Emicizumabe**|||**H**|**emorragia***||**Assinatura**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Data**|**Hora**|**Peso**|**Dose em mg**|**Quantidade em mL**|**Lote**|**Local**<sup>**#**</sup>|**Lado**<sup>**&**</sup>|**Produto utilizado**<sup>**§**</sup>|**Dose**<sup>**¤**</sup>||  
***** Hemorragia: art=articular; musc=muscular; out=outros.  
**#** Local: **articular:** joelho=J; cotovelo=C; tornozelo=T; ombro=O; punho=P; quadril=Q; outros. **Muscular:** panturrilha=pant.; antebraço=anteb.; coxa; perna;glúteo; mão; pé; outros. **Outros:** sistema nervoso central=SNC; cavidade oral=CO; outros.  
**&** Lado: direito=D; esquerdo=E; não sabe ou não se aplica=NA  
**§** Produto utilizado: Se concentrado de fator VIII (FVIII), concentrado de fator VII ativado recombinante (rFVIIa) ou concentrado de complexo protrombínico parcialmente ativado(CCPa);  
**¤** Dose: Em UI  (FVIII e CCPa) ou mg/KUI (rFVIIa)  
24

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: SANGRAMENTOS AGUDOS -->
**O que fazer se houver suspeita de sangramento durante o uso de emicizumabe?**  
- Se não houver certeza de que se trata de um sangramento, você deverá aguardar e observar a evolução do quadro clínico nas próximas horas. Se se observar piora, iniciar o tratamento com concentrado de fator VII recombinante ativado (rFVIIa), como descrito no item 2.  
- Se houver certeza de que se trata de um sangramento e ele não parece ser grave, iniciar o uso de medidas locais (compressão, colocação de gelo) para controle do sangramento. Caso estas não resolvam o sangramento, utilizar o rFVIIa conforme a prescrição de seu médico. A primeira dose de rFVIIa a se administrar é de 50 microgramas a 90 microgramas por kg. Se o sangramento não estiver melhorando, uma segunda dose pode ser necessária, após 3 horas. Se após duas doses de rFVIIa o sangramento não estiver melhorando, entrar em contato com o Centro de Hemofilia ou o hospital, para orientação.  
- Se você suspeitar de um sangramento grave, você deve infundir imediatamente uma dose de 90 microgramas por kg de rFVIIa e logo após entrar em contato com o Centro de Hemofilia ou o hospital para orientações adicionais.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Quando considerar um sangramento como grave?** -->
Sangramentos musculares; sangramentos fora das articulações (pescoço, garganta, face, barriga); sangramentos muito extensos em articulações; sangramentos relacionados a traumas na cabeça  
Observações importantes:  
- O concentrado de complexo protrombínico parcialmente ativado (CPPa) não deve ser usado enquanto estiver em uso de emicizumabe, a não ser em situações extremas e prescrito pelo médico do Centro de Hemofilia.  
- Após o controle dos sangramentos, na primeira oportunidade, entrar em contato com o Centro de Hemofilia para informar sobre a ocorrência do sangramento.  
Com quem entrar em contato no Centro de Hemofilia?  
Escrever abaixo os horários de atendimento, telefone e a quem procurar:  
25  
Com quem entrar em contato no hospital?  
Escrever abaixo os horários de atendimento, telefone e a quem procurar:  
Ao realizar qualquer contato, informar ao médico de plantão o diagnóstico de hemofilia A e inibidores de Fator VIII, assim como o uso de um novo medicamento chamado emicizumabe. Dizer que foi orientado a telefonar para pedir orientação, em caso de sangramento que não esteja melhorando com as medidas usuais tomadas em casa.  
26

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: CÁLCULO DA DOSE DE MANUTENÇÃO DO EMICIZUMABE -->
**Tabela 1** - Dose de manutenção do emicizumabe de acordo com o peso e frequência de administração  
|**Peso**<br>**Mínimo**|**Peso**<br>**Máximo**|**Dose e Frequência**|**Apresentação**|**Volume****|
|---|---|---|---|---|
|**(em kg)**|**(em kg)**||||
|Até 9|9|3 mg/kg a cada 2<br>semanas|30mg/1mL|Administrar o volume correspondente à dose<br>calculada em mg|
|10|11|3 mg/kg a cada 2<br>semanas|30mg/1mL|Administrar todo o conteúdo do frasco- ampola<br>de 1mL (30mg).|
|11,1|22|1,5 mg/kg por semana|30mg/1mL|Administrar 1,5 mg/kg por semana e<br>descartar todo o volume restante.|
|22,1|33|3 mg/kg a cada 2<br>semanas|30mg/1mL +<br>60mg/0,4mL|Administrar todo o conteúdo do frasco-ampola<br>de 60mg/0.4mL e o restante da dose da<br>apresentação de 30mg/1mL para um total de 3<br>mg/kg.<br>Descartar todo o volume restante.|
|33,1|38|3 mg/kg a cada 2<br>semanas|105mg/0,7mL|Administrar 3 mg/kg do frasco-ampola de<br>0,7mL e descartar todo volume restante.|
|38,1|44|1,5 mg/kg por semana|60mg/0,4mL|Administrar 1.5 mg/kg do frasco- ampola de<br>0,4mL e descartar todo o volume restante.|
|44,1|49|3 mg/kg a cada 2<br>semanas|30mg/1mL +<br>105mg/0,7mL|Administrar todo o conteúdo do frasco- ampola<br>de 105mg/0,7mL e o restante da dose da<br>apresentaçãode 30mg/1mL para um total de 3<br>mg/kg.|
|||||Descartar todo o volume restante.|
|49,1|53|3 mg/kg a cada 2<br>semanas|150mg/1mL|Administrar 3 mg/kg do frasco-ampola de<br>150mg/1mL e descartar todo o volume restante.|
|53,1|66|1,5 mg/kg porsemana|30mg/1mL +<br>60mg/0,4mL|Administrar todo o conteúdo do frasco-ampola<br>de 60mg/0.4mL e o restante da dose da<br>apresentação de 30mg/1mL para um total de 3<br>mg/kg.<br>Descartar todo o volume restante.|  
27  
|**Peso**<br>**Mínimo**<br>**(em kg)**|**Peso**<br>**Máximo**<br>**(em kg)**|**Dose e Frequência**|**Apresentação**|**Volume****|
|---|---|---|---|---|
|66,1|76|1,5 mg/kg por semana|105mg/0,7mL|Administrar 1,5 mg/kg do frasco- ampola de<br>0,7mL e descartar todo o volume restante.|
|76,1|86|1,5 mg/kg porsemana|60mg/0,4mL x2|total de 1,5 mg/kg.<br>Descartar todo o volume restante.|
|86,1|96|1,5 mg/kg porsemana|30mg/1mL +<br>105mg/0.7mL|Administrar todo o conteúdo dofrasco- ampola<br>de 105mg/0.7mL e o restante da dose da<br>apresentação do frasco-ampola de 30mg/1mL<br>para um total de 1.5 mg/kg.<br>Descartar todo o volume restante.|
|96,1|100*|1,5 mg/kg porsemana|150mg/1mL|Administrar 1.5 mg/kg do frasco- ampola de<br>150mg/1mL e descartar todo o volume restante.|  
**Fonte:** NHSE/UKHCDO _Emicizumab dosing guide_  
*Pacientes com peso acima de 100 kg devem receber dose de 150 mg por semana.  
**Se o volume a ser injetado for igual ou menor que 1 mL, deve-se usar seringa de 1 mL. Se o volume a ser injetado for maior que 1 mL, deve-se usar seringa de 2 a 3 mL.  
**Tabela 2** - Orientações para o arredondamento do volume menor que 1mL de emicizumabe  
|**Volume calculado (mL)**|**Volume arredondado (mL)**|
|---|---|
|0,011|0,01|
|0,012|0,01|
|0,013|0,01|
|0,014|0,02|
|0,015|0,02|
|0,016|0,02|
|0,017|0,02|
|0,018|0,02|
|0,019|0,02|
|Usar seringa de 1mL para volumes menores que 1mL||
|Por exemplo: 0,673 mL - arredondado para 0,67 mL;||
|0,674 mL - arredondado para 0,68 mL.||  
28  
**Tabela 3** - Orientações para o arredondamento do volume maior que 1mL de emicizumabe  
|**Volume calculado (mL)**|**Volume arredondado (mL)**|
|---|---|
|1,11|1,1|
|1,12|1,1|
|1,13|1,1|
|1,14|1,2|
|1,15|1,2|
|1,16|1,2|
|1,17|1,2|
|1,18|1,2|
|1,19|1,2|
|Se volume total > 1mL- 2mL usar seringa de 3 mL.||
|Por exemplo: 1,63 mL - arredondado para 1,6 mL;||
|1,64 mL - arredondado para 1,7mL||  
29

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo de Uso de emicizumabe no tratamento de indivíduos com hemofilia A moderada e grave e inibidores ao fator VIII de coagulação contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do Protocolo de Uso, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação da Coordenação-Geral de Sangue e Hemoderivados (CGSH/DAET/SAES/MS). O painel de especialistas incluiu médicos hematologistas e hematopediatras.  
Todos os participantes do processo de elaboração do Protocolo de Uso preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Equipe de elaboração e partes interessadas** -->
Equipe multiprofissional incluindo médicos hematologistas, hemopediatras, farmacêuticos, enfermeiras, outros profissionais da saúde, Coordenação-Geral de Sangue e Hemoderivados (CGSH/DAET/SAES/MS), e Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS).

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Etapas do processo de elaboração** -->
Inicialmente foi constituído um grupo de trabalho especificamente para este fim, composto por hematologistas e hematopediatras com experiência clínica no tratamento de pacientes com hemofilia e inibidores do fator de coagulação. As atividades ocorreram entre novembro de 2023 e fevereiro de 2024.  
O grupo de trabalho inicialmente se reuniu para análise do Relatório de Recomendação nº 841/2023 da Conitec<sup>13</sup> , que embasou a definição deste Protocolo. Em seguida procedeu-se à análise de um protocolo atualmente vigente sobre o uso de emicizumabe em hemofilia A (Uso de emicizumabe para tratamento de indivídios com hemofilia A e inibidores do fator VIII refratários ao tratamento de imunotolerância)<sup>28</sup> , sobre o qual as discussões se basearam na medida em que a nova incorporação amplia as indicações daquele documento. Procedeu-se então à ampliação da base de referências bibliográficas daquele protocolo, com foco em artigos científicos relatando a experiência clínica com emicizumabe em pacientes com hemofilia A e inibidores do fator VIII de coagulação, sem relação com o critério anteriormente usado, de refratariedade à imunotolerância. A busca na literatura utilizou a base de dados Pubmed. Foram ainda considerados documentos da própria empresa fabricante do medicamento.  
As reuniões do grupo de trabalho abordaram principalmente os seguintes aspectos: (a) critérios de inclusão e exclusão; (b) especificidades do uso de emicizumabe em pacientes que participam do tratamento  
30  
de imunotolerância; (c) monitoramento laboratorial; (d) manejo de sangramentos e cirurgias durante o tratamento; (e) aspectos operacionais do programa.  
O texto foi inicialmente escrito, discutido, revisado e aprovado pelo grupo de trabalho de especialistas.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea foi apresentada na 116ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 11 de junho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O Protocolo de Uso foi aprovado para avaliação da Conitec e a proposta foi inicialmente apresentada aos membros do Comitê de PCDT da Conitec em sua 131ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto, e deliberaram, por unanimidade, recomendar a atualização do Protocolo na 19ª Reunião Extraordinária da Conitec.

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: Consulta pública -->
A Consulta Pública nº 47/2024, para a atualização do Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea foi realizada entre os dias 15 de julho de 2024 a 24 de julho de 2024. Foram recebidas 467 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/cp_conitec_047_2024_protocolo_de_uso.pdf .

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: **Busca da evidência e recomendações** -->
As evidências foram obtidas por meio da plataforma Pubmed. Este Protocolo de Uso foi desenvolvido conforme processos preconizados pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. Este documento se baseou no Relatório de Recomendação nº 841/2023 da Conitec<sup>13</sup> , que recomenda a incorporação do emicizumabe para tratamento profilático de indivíduos com hemofilia A moderada ou grave, e anticorpos inibidores do fator VIII, sem restrição de faixa etária.  
A relatoria das seções do documento foi atribuída a um dos especialistas que atuou como coordenador das discussões. As recomendações foram realizadas pelo painel de especialistas, responsáveis pela redação da primeira versão do texto.  
31

---

<!-- METADADOS: doenca: Hemofilia A – Uso do Emicizumabe | secao: HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do Relatório**||**Tecnologias av**|**aliadas pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**|**Principais**|||
|**(Conitec) ou Portaria**<br>**de Publicação**|<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não alteração no**<br>**SUS**|
|Relatório<br>de<br>Recomendação<br>nº<br>923/2024|Ampliação<br>de<br>uso<br>do<br>emicizumabe|Emicizumabe<br>para<br>tratamento<br>profilático de pessoas com hemofilia<br>A, moderada ou grave, e anticorpos<br>inibidores do Fator VIII, sem<br>restrição de faixa etária [Relatório de<br>Recomendação nº 841/2023; Portaria<br>SECTICS/MS nº 55, de 5 de outubro<br>de 2023]|Emicizumabe para tratamento profilático<br>de pacientes de até 12 anos de idade com<br>hemofilia A, moderada ou grave, sem<br>inibidores do Fator VIII [Relatório de<br>Recomendação nº 840/2023; Portaria<br>SECTICS/MS nº 52, de 5 de outubro de<br>2023)|
|Portaria<br>Conjunta<br>SAES-SCTIE/MS nº 15,<br>de 26 de agosto de 2021<br>[Relatório<br>de<br>Recomendação<br>nº<br>15/2021]|Primeira versão<br>do Protocolo|Emicizumabe para tratamento de<br>indivíduos com hemofilia A e<br>inibidores ao fator VIII refratários ao<br>tratamento<br>de<br>imunotolerância<br>[Relatório de Recomendação nº<br>500/2019; Portaria SCTIE/MS nº 62,<br>de 26 de novembro de 2019)|-|  
32

---

