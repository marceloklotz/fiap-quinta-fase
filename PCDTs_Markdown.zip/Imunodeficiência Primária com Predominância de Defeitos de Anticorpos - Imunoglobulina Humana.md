<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a importância do papel que desempenham os Protocolos Clínicos e Diretrizes Terapêuticas para a melhoria da qualidade dos processos de atenção à saúde, para a prescrição segura e eficaz, para a democratização do conhecimento médico, para o aperfeiçoamento da educação médica continuada, para a melhoria da qualidade da informação prestada aos pacientes sobre as opções terapêuticas existentes nas diversas situações clínicas tornando-os partícipes das decisões a serem tomadas e para a melhoria dos processos gerenciais dos programas assistenciais;  
Considerando a necessidade de estabelecer Protocolos Clínicos e Diretrizes Terapêuticas para as diversas doenças, que contenham critérios de diagnóstico e tratamento, e, observando ética e tecnicamente a prescrição médica, racionalizem a dispensação dos medicamentos preconizados para o tratamento das doenças, regulamentem suas indicações e seus esquemas terapêuticos e estabeleçam mecanismos de acompanhamento de uso e de avaliação de resultados, garantindo assim a prescrição segura e eficaz;  
Considerando a Consulta Pública a que foi submetido o Protocolo Clínico e Diretrizes Terapêuticas – IMUNODEFICIÊNCIA PRIMÁRIA COM PREDOMINÂNCIA DE DEFEITOS DE ANTICORPOS – Imunoglobulina Humana, por meio da Consulta Pública SCTIE/MS nº 004/2004, de 07 de julho de 2004, que promoveu sua ampla discussão e possibilitou a participação efetiva da comunidade técnico científica, sociedades médicas, profissionais de saúde e gestores do Sistema Único de Saúde na sua formulação; e,  
Considerando as sugestões apresentadas ao Ministério da Saúde no processo de Consulta Pública acima referido, resolve:  
Art. 1º - Aprovar, na forma do Anexo desta Portaria, o PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS – IMUNODEFICIÊNCIA PRIMÁRIA COM PREDOMINÂNCIA DE DEFEITOS DE ANTICORPOS – Imunoglobulina Humana e seu respectivo Termo de Consentimento Informado, na forma do Anexo desta Portaria  
- § 1º O Protocolo de que trata este artigo, que contém o conceito geral da doença, os critérios de inclusão/exclusão  
- de pacientes no tratamento, critérios de diagnóstico, esquema terapêutico preconizado e mecanismos de acompanhamento e avaliação deste tratamento, é de caráter nacional, devendo ser utilizado pelas Secretarias de Saúde dos estados, do Distrito Federal e dos municípios na regulação da assistência a ser prestada e da dispensação do medicamento nele previsto;  
- § 2º As Secretarias que já tenham definido Protocolo próprio com a mesma finalidade deverão adequá-lo de forma a observar a totalidade dos critérios técnicos estabelecidos no Protocolo aprovado pela presente Portaria;  
- § 3º É obrigatória a observância deste Protocolo para fins de dispensação do medicamento nele previsto;  
§ 4º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais benefícios, efeitos colaterais, contra-indicações e riscos relacionados ao uso do medicamento preconizado para o tratamento da Imunodeficiência Primária com predominância de defeitos de Anticorpos, o que deverá ser formalizado através da assinatura do respectivo Termo de Consentimento Informado, conforme modelo integrante do Protocolo de que trata esta Portaria.  
Art. 2º - Esta Portaria entra em vigor na data de sua publicação.  
JOSÉ CARVALHO DE NORONHA

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Protocolo Clínico e Diretrizes Terapêuticas  
Imunodeficiência Primária com predominância de defeitos de anticorpos  
Imunoglobulina humana

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
As imunodeficiências primárias (IP) são doenças genéticas raras, associadas ao desenvolvimento e/ou maturação anormais das células do sistema imunológico e ao conseqüente aumento da susceptibilidade a infecções.1 A incidência deste grupo de doenças é estimada em 1/10.000 recém-nascidos vivos (RNs), excluindose os casos com deficiência de imunoglobulina A (IgA) assintomática.2-4 As IP com predominância de defeitos de anticorpos fazem parte do grupo de IP associadas à presença de defeitos nos linfócitos B (imunidade humoral) e ao conseqüente prejuízo da produção ou da função de um ou mais tipos de imunoglobulinas5; o comprometimento da imunidade celular é mínimo ou ausente, e o prejuízo da produção ou da função das imunoglobulinas não deve ser secundário a outras doenças.5 A classificação das IP, com a freqüência relativa dos seus tipos, é mostrada no quadro I.  
Quadro I – Classificação das imunodeficiências primárias e freqüência relativa dos seus tipos2,6  
1. Defeitos na função linfocitária (70%)  
- Defeitos de anticorpos (imunodeficiência humoral ou de linfócitos B) (40%)  
- Defeitos na imunidade celular (ou de linfócitos T) (10%)  
- Deficiência combinada (20%)  
2. Defeitos dos fagócitos (18%)  
3. Deficiências do sistema complemento (2%)  
As IP com predominância de defeitos de anticorpos constituem-se no tipo de IP mais freqüentemente diagnosticado. Englobam entidades como a deficiência de IgA, a imunodeficiência comum variável (também denominada hipogamaglobulinemia de início tardio, hipogamaglobulinemia com início na idade adulta, imunodeficiência adquirida, hipogamaglobulinemia adquirida) e a agamaglobulinemia ligada ao X (ou agamaglobulinemia de Bruton). Estas três entidades correspondem a 70-90% dos casos de IP com predominância de defeitos de anticorpos7,8 e são brevemente descritas abaixo:  
- Deficiência de IgA5,9: tem incidência estimada em 1/320-800 RNs. As manifestações clínicas caracterizam-se por processos infecciosos de repetição e doenças autoimunes, sendo que cerca de 50% dos casos podem ser assintomáticos. Os portadores desta condição devem ser amplamente avaliados do ponto de vista imunológico, pois pode ocorrer evolução para imunodeficiência comum variável; além disso, já foram relatados casos de deficiência de IgA e de imunodeficiência comum variável em uma mesma família, e aproximadamente 25% dos indivíduos com deficiência de IgA podem apresentar deficiência concomitante de alguma subclasse de IgG.  
- Imunodeficiência comum variável 1,9-11: tem incidência estimada em 1/50.000 RNs. Este termo é utilizado para descrever um grupo heterogêneo de IP com predominância de defeitos de anticorpos onde existe um número detectável de linfócitos B (geralmente normal) e acentuada redução de pelo menos duas das três classes  
principais de imunoglobulinas (IgM, IgG e IgA). A maioria dos pacientes apresenta níveis de IgG significativamente diminuídos (<250mg/dL). O padrão de herança é multifatorial e o diagnóstico é definido após exclusão de outras causas de IP com predominância de defeitos de anticorpos. A faixa etária mais comum de apresentação é a segunda ou terceira décadas.  
- Agamaglobulinemia ligada ao X 1,9,11-13: tem incidência estimada em 1/100.000 RNs. Caracteriza-se pela ocorrência de infecções bacterianas recorrentes em indivíduos do sexo masculino, com início durante os dois primeiros anos de vida. É causada pela presença de mutações no gene BTK (do inglês Bruton’s tyrosine kinase), localizado em Xq21.3-q22. A proteína BTK tem função primordial na diferenciação e ativação dos linfócitos B. Os pacientes apresentam redução importante de todos os tipos de imunoglobulinas séricas (IgG <200mg/dL, IgM e IgA <20mg/dL). O número de linfócitos B é geralmente inferior a 1% do valor normal.  
O presente protocolo baseia-se nas duas formas mais freqüentes de IP com predominância de defeitos de anticorpos que cursam com deficiência de IgG: a agamaglobulinemia ligada ao X e a imunodeficiência comum variável. Em ambas situações, o tratamento com imunoglobulina humana (IGH) tem sua eficácia demonstrada por pelo menos séries de casos ou ensaios clínicos não-controlados. Nos outros casos de IP com predominância de defeitos de anticorpos, a eficácia da IGH não está adequadamente estabelecida, sendo a sua indicação baseada na opinião e experiência de especialistas.5,6,14-19 No entanto, da mesma forma que para as duas principais causas de IP que serão discutidas, a história inequívoca de infecções recorrentes e os critérios diagnósticos propostos devem estar rigorosamente presentes (item 3). O presente protocolo não inclui as IP com predominância de defeitos da imunidade celular como indicações para o uso da IGH, uma vez que o comprometimento principal, neste caso, é o da imunidade celular. Também não serão discutidas as imunodeficiências secundárias.  
2. Classificação – CID 10  
· D80.0 - Hipogamaglobulinemia hereditária (agamaglobulinemia autossômica recessiva, agamaglobulinemia ligada ao X, agamaglobulinemia ligada ao X com deficiência de hormônio de crescimento)  
· D80.1 – Hipogamaglobulinemia não familiar (agamaglobulinemia com linfócitos B portadores de imunoglobulina, agamaglobulinemia de variável comum, hipogamaglobulinemia SOE)  
· D80.3 - Deficiência seletiva de subclasses de imunoglobulina G (IgG)  
· D80.5 – Imunodeficiência com aumento de imunoglobulina M (IgM)  
· D80.6 – Deficiência de anticorpos com imunoglobulinas próximas do normal ou com hiperimunoglobulinemia  
· D80.7 – Hipogamaglobulinemia transitória da infância  
- D80.8 – Outras imunodeficiências com predominância de defeitos de anticorpos (deficiência de cadeia leve  
- kappa)  
- D83.0 - Imunodeficiência comum variável com predominância de anormalidades do número e da função  
- das células B  
· D83.2 - Imunodeficiência comum variável com auto-anticorpos às células B ou T  
· D83.8 - Outras imunodeficiências comuns variáveis  
3. Diagnóstico

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
História familiar de infecções de repetição ou refratárias ao tratamento, mortes prematuras, consangüinidade ou heredograma sugestivo de herança ligada ao X recessiva são comuns nos pacientes com IP. As manifestações clínicas, caracterizadas especialmente por processos infecciosos de repetição de vias aéreas superiores, são, na maioria das vezes, de leve a moderada intensidade, com esporádicos casos de maior gravidade ou óbito em idade precoce.21  
Com relação às infecções, estas costumam incidir geralmente após o 7° mês de vida, devido à perda da proteção inicial decorrente dos anticorpos maternos recebidos durante o último trimestre da gestação (a IgG é o único tipo de imunoglobulina que cruza a barreira transplacentária). As infecções são causadas por bactérias encapsuladas, como Streptococcus pneumoniae e Haemophillus influenzae tipo b ou Staphylococcus aureus e Neisseria meningitidis. Nos casos de IP combinada, os sintomas costumam iniciar em idade mais precoce, geralmente antes do 6° mês de vida, com infecções virais, bacterianas, fúngicas e por protozoários.  
Outras manifestações clínicas incluem má-absorção, anemia ferropriva, atraso de crescimento, hepatoesplenomegalia e artralgias sem causa aparente18. Na agamaglobulinemia ligada ao X, pode ser encontrada ausência de tonsilas e de outros tecidos linfóides. Os pacientes com imunodeficiência comum variável têm risco aumentado de desenvolver hiperplasia nodular linfóide, doença granulomatosa, doenças autoimunes e neoplasias. 5

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Embora a suspeita de uma imunodeficiência seja baseada em dados clínicos, o diagnóstico definitivo depende da realização de exames complementares. De uma maneira geral, a avaliação deve iniciar nos laboratórios de centros de saúde primários e, dependendo destes resultados, o paciente deve ser encaminhado a um centro de referência para investigação mais detalhada. No quadro III estão listados os testes essenciais para a avaliação da imunidade humoral.  
Os primeiros exames a serem solicitados frente à suspeita clínica de IP com predominância de defeitos de anticorpos são o hemograma (geralmente normal) e a dosagem das imunoglobulinas (geralmente diminuídas). A avaliação da imunidade humoral não se restringe à dosagem dos níveis das imunoglobinas; é importante verificar, também, se estas proteínas são funcionalmente adequadas. Isto se faz através da pesquisa de anticorpos naturais ou ativamente produzidos (avaliação da síntese ativa dos anticorpos). Mesmo que haja diminuição significativa das imunoglobulinas, deve ser determinada a capacidade do paciente sintetizar ativamente os anticorpos. Assim, todo o diagnóstico de IP com predominância de defeitos de anticorpos deve ser confirmado mediante esta avaliação.2  
Quadro III – Testes essenciais para a avaliação da imunidade humoral em indivíduos com suspeita clínica de imunodeficiência primária  
- Dosagem de imunoglobulinas (soro): IgG total, IgA, IgM;  
- Avaliação da síntese ativa de anticorpos (uma das três):  
1. dosagem das isohemaglutininas anti-A e anti-B,  
2. dosagem dos anticorpos pós-vacinais (anti-tétano, anti-difteria), anti-rubéola, anti-hepatite B, anti-  
sarampo  
3. dosagem de anticorpos anti-polissacárides do pneumococo (pré e pós-vacinais).  
Em relação ao diagnóstico das IP com predominância de defeitos de anticorpos, é importante salientar que16,18,19:  
· a concentração sérica das imunoglobulinas não deve ser usada como o único critério para o diagnóstico de IP. A história de infecções de repetição é uma condição indispensável para a formulação diagnóstica. Níveis diminuídos de imunoglobulinas podem também ser secundários a um aumento da sua perda (como, por exemplo, em decorrência de síndrome nefrótica). Um indicativo de que está havendo perda é a diminuição concomitante dos níveis séricos de albumina;  
· as concentrações séricas das imunoglobulinas devem ser comparadas com os valores normais para a idade do paciente e, idealmente, com curvas que também levem em consideração o seu sexo e procedência;  
· concentração normal de IgG não exclui o seu diagnóstico. Neste caso, a confirmação do diagnóstico de imunodeficiência humoral depende dos testes funcionais;  
· apesar da disponibilidade da dosagem das subclasses de IgG, existem controvérsias a respeito da significância clínica de níveis baixos destes anticorpos, havendo questionamento se a deficiência de subclasse de IgG representa uma imunodeficiência propriamente dita22,23 ou se está associada a existência de outras doenças como outras imunodeficiências primárias, ataxia-telangiectasia, epilepsia intratável, diabetes ou doenças autoimunes.24

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Serão incluídos neste protocolo de tratamento todos os pacientes que apresentarem o diagnóstico de agamoglobulinemia ligada ao X, imunodeficiência comum variável ou outro tipo de IP com predominância de defeitos de anticorpos, conforme o item 3 acima, bem como comprovação através de laudos médicos e exames complementares da ocorrência de infecções de repetição típicas de IP com predominância de defeitos de anticorpos.16,18  
4.1. Sumário das avaliações necessárias para o uso da IGH  
Para o diagnóstico específico:  
- concentração sérica das imunoglobulinas (IgG total, IgA, IgM);  
- avaliação da síntese ativa de anticorpos;  
· laudos médicos/exames que comprovem a ocorrência de infecções típicas de IP com predominância de defeitos de anticorpos;  
- concentração sérica das subclasses de IgG (quando indicado).  
Para exclusão de outras condições ou contra-indicações ao uso de IGH:  
- hemograma;  
- provas de função renal (uréia e creatinina) e hepática (TGO, TGP, TP e albumina).  
5. Critérios de Exclusão  
Serão excluídos deste protocolo todos os pacientes que apresentarem pelo menos um dos seguintes critérios:  
- infecção ativa e/ou neoplasia;  
- insuficiência renal ou hepática;

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
- diagnóstico laboratorial incidental de IP com predominância de defeitos de anticorpos, sem história de  
- infecções de repetição ameaçadoras da vida;  
- deficiência de IgA somente;  
- deficiência de IgM somente;  
- deficiência de IgD somente;  
- imunodeficiência predominantemente celular.  
6. Tratamento  
O manejo dos pacientes com deficiência de anticorpos inclui tratamento de suporte com antibióticos e medidas de higiene pulmonar para melhora da mobilização de secreções. Infecções individuais devem ser tratadas precocemente com drogas antimicrobianas nas doses plenas, evitando as de amplo espectro. Antibióticos profiláticos não são recomendados a todos os pacientes, pelo risco de infecções fúngicas ou de germes resistentes16, podendo ser indicada concomitantemente com a IGH em casos específicos.  
A IGH tem sido o maior avanço no tratamento destes pacientes, especialmente após o advento de formulações mais seguras quanto ao risco de contágio de hepatites.15  
A decisão sobre o início da reposição de imunoglobulina não deve basear-se somente na concentração sérica exata da IgG, e sim na evidência de que o indivíduo está tendo infecções típicas de IP com predominância de defeitos de anticorpos e de que não é capaz de produzir anticorpos antígeno-específicos.9 Não existem recomendações claras e bem definidas sobre a monitorização e ajuste de doses da IGH nos pacientes com IP com predominância de anticorpos. O presente protocolo reuniu dados procedentes de ensaios clínicos de melhor evidência e informações complementares em livros-texto específicos.  
Vários artigos de revisão indicam o uso da IGH nas IP com predominância de defeitos de anticorpos.5,6,14,15,17 No entanto, ao se posicionar sobre a eficácia da IGH na prevenção de infecções intercorrentes nos pacientes com IP, estes autores baseiam-se apenas em outros artigos de revisão25, nos ensaios que avaliam a eficácia da IGH para imunodeficiências secundárias18,26 ou em estudos tipo série de casos27,28 e ensaios cruzados29-31 que comparam doses diferentes sem presença de grupo controle. Da mesma forma, Chapel (1994)18, ao elaborar documento de consenso diagnóstico e de manejo das IP no British Medical Journal, faz referência a apenas um artigo não-controlado, não-randomizado e não-específico para as IP.32 Experimentalmente, Busse e cols. (2002)28 ao analisarem 50 pacientes portadores de imunodeficiência comum variável, evidenciaram que a IGH na dose de 300 a 400mg/kg a cada 3 a 4 semanas previne significativamente (62%) a incidência de pneumonia. No entanto, além das limitações intrínsecas do próprio delineamento (série de casos), o estudo apresentou problemas metodológicos limitantes, tais como tempo de seguimento insuficiente e má definição dos desfechos de interesse. Da mesma forma, outras séries de casos evidenciaram uma menor taxa de infecções após a administração da IGH, todos favorecendo o uso da forma intravenosa em comparação com a intramuscular.33-35 No entanto, tais estudos não especificaram os tipos de IP que foram analisados. Não existem ensaios clínicos contra-placebo avaliando a eficácia da IGH nas IP com predomínio de defeitos na produção de anticorpos. Roifman e cols (1987)29 encontraram alguma evidência através de um estudo randomizado, cruzado com apenas 12 pacientes de que a IGH em altas doses pudesse ser eficaz na melhora da função pulmonar aferida através de avaliações espirométricas regulares. Por fim, a melhor evidência disponível de sua eficácia foi obtida através de um estudo randomizado, duplo-cego, cruzado, que avaliou 43 pacientes com diagnóstico firmado de agamaglobulinemia ligada ao X e imunodeficiência comum variável.36 Este estudo comparou a dose padrão da IGH (300mg/kg a cada 4 semanas para os adultos e 400mg/kg a cada 4 semanas para as crianças) versus o dobro da dose. Após 3 meses de tratamento inicial, seguido por 3 meses de pausa para “wash-out” e mais 9 meses com o tratamento cruzado, os autores concluíram que no grupo da IGH em altas doses houve redução mínima, embora estatisticamente significativa, do número e  
duração das “infecções” (de natureza não especificada, apenas descritas como sendo na maioria delas, IVAS ou “bronquite”). Tais achados são discrepantes com os obtidos por Pruzanski e cols. (1996)31 que, através de estudo semelhante, não encontraram nenhuma diferença de eficácia com doses distintas.  
Assim, baseado em estudos de evidência nível II, respaldado pelo último relatório da Organização Mundial da Saúde16, o uso da IGH como agente profilático de infecções intercorrentes pode ser recomendado naqueles pacientes com IP com predominância de defeitos de anticorpos, especialmente nos casos de agamoglobulinemia ligada ao X ou imunodeficiência comum variável, desde que respeitando as condições propostas no item 3. Não existem evidências epidemiológicas consistentes de que a IGH seja benéfica nos outros tipos de IP com predominância no defeito na produção de anticorpos, como por exemplo, na deficiência de subclasse de IgG, existindo apenas estudos de metodologia inadequada sobre esta questão.34,37 No entanto, é consenso na literatura especializada de que a IGH deva ser benéfica mesmo nestes casos.5,6,14-19

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
A IGH é uma preparação terapêutica de IgG poliespecífica. As subclasses de IgG estão presentes em proporções fisiológicas. A IgA e IgM estão presentes somente em pequenas quantidades.  
As seguintes apresentações são disponíveis:  
apresentações intravenosas: frascos-ampola de 0,5; 1,0; 2,5; 3,0; 5,0; 6,0g;

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
A dose IV recomendada para início de tratamento é de 300 a 400mg/kg a cada 3 semanas ou 400500mg/kg a cada 4 semanas38. A dose máxima recomendada é de 600mg/kg a cada 3 semanas ou 800mg/kg a cada 4 semanas38.

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
O ajuste de doses ou do intervalo de infusões deve ser guiado pelos níveis séricos de IgG e pela condição clínica global do paciente, incluindo piora ou melhora da função pulmonar, número de dias perdidos na escola ou no trabalho, dias de hospitalização e necessidade do uso de antibióticos nos 3 meses anteriores.41

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
· Diminuição da freqüência e duração de infecções anuais, medidos através do número de dias perdidos na escola ou no trabalho, dias de hospitalização e da necessidade do uso de antibióticos.  
Os benefícios do tratamento com IGH podem levar 4-6 semanas até tornarem-se aparentes17, devendo também ser monitorizados através da dosagem sérica de IgG, além da avaliação clínica global (ver monitorização).

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Este tratamento deverá ser contínuo, na ausência de efeitos adversos ou surgimento de situações que contra-indiquem o uso da IGH.

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Recomenda-se a realização de monitorização clínica e laboratorial através de18:  
· uso de diário de sintomas sugestivos de infecção;  
· trimestralmente: hemograma, EQU, provas de função renal (uréia e creatinina) e hepáticas (TGO, TGP, TP e albumina);  
· no dia da aplicação: excluir infecção ativa através de anamnese/exame físico;  
· antes de cada aplicação: dosagem de IgG sérica. Embora um dos objetivos do tratamento com IGH seja manter a IgG sérica acima de 500mg/dL27,29, este tratamento visa principalmente a melhorar o controle dos quadros infecciosos apresentados pelos pacientes.

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
Todos os pacientes com suspeita de IP devem ser encaminhados a um Centro de Referência para avaliação e tratamento específicos com imunologista e geneticista. Para tal, recomenda-se a organização de centros de referência a serem habilitados e cadastrados pelo Gestor Estadual para avaliação médica e planejamento de estratégias diagnósticas e terapêuticas aos pacientes com IP.

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
É obrigatória a cientificação do paciente, ou de seu responsável legal, acerca dos potenciais benefícios, efeitos colaterais, contra-indicações e riscos relacionados ao uso do medicamento preconizado neste protocolo, o que deverá ser formalizado por meio da assinatura de Termo de Consentimento Informado.

---

<!-- METADADOS: doenca: Imunodeficiência Primária com Predominância de Defeitos de Anticorpos - Imunoglobulina Humana | secao: PORTARIA Nº 495, DE 11 DE SETEMBRO DE 2007 -->
1. Rosen FS, Cooper MD, Wedgwood RJP. The primary immunodeficiencies. N Engl J Med 1995;333(7):431-40.  
2. Noroski LM, Shearer WT. Short Analytical Review: screening for prymary immunodeficiencies in the clinical immunology laboratory. Clinical Immunol and Immunopathol 1998;86(3):237-45.  
3. Matamoros FN, Mila LJ, Espanol BT, Raga BS, Fontan CG. Primary immunodeficiency syndrome in Spain: first report of the National Registry in Children and Adults. J Clin Immunol 1997;17:333-9.  
4. Fasth A. Primary immunodeficiency in Sweden: cases among children 1974-1979. J Clin Immunol 1982;2:86-92.  
5. Spickett GP, Misbah AS, Chapel HM. Primary antibody deficiency in adults. Lancet 1991;337:281-4.  
6. Bonilla FA, Geha RS. Primary imunodeficiencies. J Allergy Clin Immunol 2003;111:S571-81.  
7. Grumach AS, Duarte AJS, Bellinati-Pires R, Pastorino AC, Jacob CMA, Diogo CL, et al. Brazilian report on primary immunodeficiencies in children: 166 cases studied over a follow-up time of 15 years. J Clin Immunol 1997;17(4):340-5. 8. Llambí JM, Galdos AE, Florí NM. Registro espanol de inmunodeficiencias primarias (REDIP). Allergol et Immnopathol 2001;29(3):101-25.  
9. Conley, ME. Antibody deficiencies. In: Scriver, CR; Beaudet, AL. Sly, WS, Valle, D. The Metabolic & Molecular Bases of Inherited Disease. 8 a ed. McGraw-Hill, 2001. Pg. 4731-50.  
10. Alzueta, JI, Florí, NM. Inmunodficiencia variable común. Revisión. Allergol et Immunopathol 2001;29(3):101-25.  
11. OMIM: On Line Mendelian Inheritance in Man, 2003. www.ncbi.nlm.nih.gov/omim/  
12. Gene Clinics, 2003. www.geneclinics.org  
13. Rodrigues MCG, Granados EL, Martínez RC, Cerdán AF, Casariego GF. Diagnóstico molecular de inmunodeficiencias primarias. Allergol et Immunopahtol 2001;29(3):101-25.  
14. Tellier Z, Mouthon L. Les indications thérapeutiques des immunoglobulines intraveineuses. Transfusion clinique et Biologique 2003;10:179-84.  
15. Ballow M. Primary immunodeficiency disorders: antibody deficiency. J Allergy Clin Immunol 2001;109:581-91.  
16. Rosen F e cols. Primary immunodeficiency diseases – Report of a WHO scientific group. Immunodeficiency Reviews 1992;3:195-236.  
17. Haeney M. Intravenous immune globulin in primary immunodeficiency. Clin Exp Immunol 1994;97(suppl I):11-5.  
18. Chapel, HM. Consensus on diagnosis and management of primary antibody deficiencies. BMJ 1994; 308:581-5.  
19. IUIS Scientific Group. Primary immunodeficiency diseases. Clin Exp Immunol 1999;118:supl1:1-28.  
20. Rosen FS, Cooper MD, Wedgwood RJP. The primmary immunodeficiencies. N Engl J Med 1994;331(4):235-42.  
21. Folds DJ, Schmitz JL. Clinical and laboratory assessment of immunity. J Allergy Clin Immunol 2003;111:S702-11  
22. Shackelford P, Granoff D, Madassery J, Scott M, Nahm M. Clinical and immunologic characteristics of healthy children of subnormal serum concentrations of IgG2. Pediatr Res 1990;27:16-21.  
23. Morell A. IgG subclass deficiency: a personal viewpoint. Pediatr Infect Dis J 1990;9:S4-8.  
24. Söderstrom T. Söderström R, Enskog A. Immunoglobulin subclasses and prophylactic use of immunoglobulin in immunoglobulin G subclass deficiency. Cancer 1991;68:1426-9.  
25. Pirofski B. Intravenous immune globulin therapy in hypogammaglobulinemia. A review. Am J Med 1984;76(3A):53-60.  
26. Mofenson LM, Moye J Jr, Hirschhorns R, Jordan C, Nugent R. Prophylatic intravenous immunoglobulin in HIV-infected children with CD4+ counts of 0.20 x 10(9)/L or more. Effect on viral, opportunistic, and bacterial infections. The National Institute of Child Health and Human Development Intravenous Immunoglobulin Clinical Trial Study Group. JAMA 1992;264(4):483-8.  
27. Liese JG, Wintergerst U, Tympner KD, Belohradsky BH. High- vs low-dose immunoglobulin therapy in the long-term treatment of X-linked agammaglobulinemia. Am J Dis Child. 1992 Mar;146(3):335-9.  
28. Busse PJ, Razvi S, Cunningham-Rundles C. Efficacy of intravenous immunoglobulin in the prevention of pneumonia in patients with common variable immunodeficiency. J Allergy Clin Immunolol 2002;109:1001-4.  
29. Roifman CM, Levison H, Gelfand EW. High-dose versus low-dose intravenous immunoglobulin in hypgammaglobulinaemia and chronic lung disease. Lancet 1987;i:1075-7.  
30. Nolte MT, Pirofsky B, Gerritz GA, Golding B. Intravenous immunoglobulin therapy for antibody deficiency. Clin Exp Immunol 1979;36(2):237-43.  
31. Pruzanski W, Sussman G, Dorian W, Van T, Ibanez D, Redelmeier D. Relationship of the dose of intravenous gammaglobulin to the prevention of infections in adults with common variable immunodeficiency. Inflammation 1996;20(4):353-9.  
32. National Institute of Child Health, Intravenous Immunoglobulin Study Group. Intravenous immune globulin for the prevention of bacterial infections in children with symptomatic human immunodeficiency virus infection. N Engl J Med 1991;325:73-80.  
33. Ammann AJ, Ashman RF, Buckley RH, Hardie WR, Krantmann HJ, Nelson J, Ochs H, Stiehm ER, Tiller T, Wara DW, Wedgwood R. Use of intravenous gamma-globulin in antibody immunodeficiency: results of a multicenter controlled trial.Clin Immunol Immunopathol 1982;22(1):60-7.  
34. Cunningham-Rundles C, Siegal FP, Smithwick EM, Lion-Boule A, Cunningham-Rundles S, O'Malley J, et al. Efficacy of intravenous immunoglobulin in primary humoral immunodeficiency disease. Ann Intern Med. 1984;101(4):435-9.  
35. Roifman CM, Lederman HM, Lavi S, Stein LD, Levison H, Gelfand EW. Benefit of intravenous IgG replacement in hypogammaglobulinemic patients with chronic sinopulmonary disease. Am J Med 1985;79(2):171-4.  
36. Eijkhout HW, van der Meer JW, Kallenberg CG, Weening RS, Dissel JT et al. The effect of two different dosages on intravenous immunoglobulin on the incidence of reccurent infections in patients with primary hypogammaglobulinemia. Ann Intern Med 2001;135:165-74. 37. Knutsen AP. Patients with IgG subclass and/or selective antobody deficiency to polyssacharide antigens: initiation of a controlled clinical trial of intravenous immune globulin. J Allergy Clin Immunol 1989;84:640-7.  
38. Bonilla FA, Berstein IL, Khan DA, Ballas ZK, Chinen J, Frank MM, Kobrynski LJ, Levinson AI, Mazer B, Nelson RP, Orange JS, Routes JM, Shearer WT, Sorensen RU. Practice parameter for the diagnosis and management of primary immunodeficiency. Ann All Asth Immunol 2005; 94: S1-S63.  
39. Gardulf A, Andersen V, Björkander J, Ericson D, Froland S, Gustafson R, et al. Subcutaneous immunoglobulin replacement in patients with primary antibody deficiencies: safety and costs. Lancet 1995;345:3659.  
40. Chapel HM, Spickett GP, Ericson D, Engl W, Eibl MM, Bjorkander J. The comparison of the efficacy and safety of intravenous versus subcutaneous immunoglobulin replacement therapy. J Clin Immunol 2000;20(2):94100.  
41. Kishiyama, J e Adelman, D. Allergic & Immunologic Disorders. In: Tierney, LMJ; McPhee, SJ; Papadakis, MA. Current Medical Diagnosis & Treatment 2003. 42 edição. Lange Medical Books/McGraw-Hill. pg.759-82.  
Termo de Consentimento Informado  
imunoglobulina humana  
Eu, __________________________, (nome do(a) paciente), abaixo identificado(a) e firmado(a), declaro ter sido informado(a) claramente sobre todas as indicações, contra-indicações, principais efeitos colaterais e riscos  
relacionados ao uso do medicamento imunoglobulina humana, indicado para o tratamento da imunodeficiência primária com predominância de defeitos de anticorpos.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvêlo caso o tratamento seja interrompido.  
Os termos médicos foram explicados e todas as minhas dúvidas foram esclarecidas pelo médico ___________________ (nome do médico que prescreve).  
Expresso também minha concordância e espontânea vontade em submeter-me ao referido tratamento, assumindo a responsabilidade e os riscos por eventuais efeitos indesejáveis.  
Assim, declaro que:  
Fui claramente informado(a) de que os medicamentos que passo a receber podem trazer os seguintes benefícios:  
- diminuição da freqüência e duração de infecções anuais.  
Fui também claramente informado(a) a respeito das seguintes contra-indicações, potenciais efeitos colaterais e riscos:  
· medicamento classificado na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos)  
· os efeitos colaterais já relatados são: dor de cabeça, calafrios, febre, reações no local de aplicação da injeção que incluem dor, coceira e vermelhidão, aumento de creatinina e uréia no sangue, seguido de oligúria e anúria, insuficiência renal aguda, necrose tubular aguda, nefropatia tubular proximal, nefrose osmótica.  
- medicamento contra-indicados em casos de hipersensibilidade (alergia) ao fármaco;  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que posso suspender o tratamento a qualquer momento, sem que este fato implique qualquer forma de constrangimento entre mim e meu médico, que se dispõe a continuar me tratando em quaisquer circunstâncias. Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento desde que assegurado o anonimato.  
Declaro, finalmente, ter compreendido e concordado com todos os termos deste Consentimento Informado.  
Assim, o faço por livre e espontânea vontade e por decisão conjunta, minha e de meu médico.  
|Paciente:|
|---|
|Documento de identidade:|
|Sexo:<br>Masculino( )Feminino( )<br>Idade:|
|Endereço:|
|Cidade:<br>CEP:<br>Telefone:( )|
|Responsável legal(quando for o caso):|
|Documento de identidade do responsável legal:|  
|Assinatura do|paciente ou do r|esponsável leg|al|
|---|---|---|---|
|Médico Responsável:|||CRM:<br>UF:|
|Endereço:||||
|Cidade:|CEP:||Telefone:( )|
|Assinatura e carimbo do médico||Data||  
Observações:  
O preenchimento completo deste Termo e sua respectiva assinatura são imprescindíveis para o fornecimento do medicamento.  
Este Termo será preenchido em duas vias: uma será arquivada na farmácia responsável pela dispensação dos medicamentos e a outra será entregue ao paciente.

---

