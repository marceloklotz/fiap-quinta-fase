<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
PORTARIA Nº 307, DE 29 DE MARÇO DE 2016  
Aprova o Protocolo de Uso de marca-passos cardíacos implantáveis e ressincronizadores.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre os marca-passos cardíacos implantáveis e ressincronizadores e diretrizes nacionais para a sua utilização e acompanhamento dos doentes submetidos a esses dispositivos;  
Considerando o Relatório Final do Grupo de Trabalho Interinstitucional sobre órteses, próteses e materiais especiais (GTI-OPME), instituído pela Portaria Interministerial Nº 38, de 8 de janeiro de 2015;  
Considerando as contribuições dadas à Consulta Pública SCTIE/MS n<sup>o</sup> 28, de 30 de setembro de 2015, sobre o Protocolo de Uso de Marcapassos Cardíacos e Ressincronizadores, com base na recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e o Registro de Deliberação no 158, de 04 de novembro de 2015, desta Comissão; e  
Considerando a avaliação técnica da CONITEC, do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Instituto Nacional de Cardiologia (INC/SAS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º  Fica aprovado, na forma do anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo de Uso de Marca-passos Cardíacos Implantáveis e Ressincronizadores.  
Parágrafo único. O Prototoclo de que trata o caput, que contém as bases técnicas e os critérios de utilização de marca-passos cardíacos implantáveis e ressincronizadores, deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 3º  Ficam revogados o Art. 1º e o Anexo I da Portaria Nº 725/SAS/MS, de 6 de dezembro de 1999, publicada no Diário Oficial da União nº 233E, de 7 de dezembro de 1999, Seção 1, página 12, e o Anexo I da Portaria Nº 987/SAS/MS, de 17 de dezembro de 2002, publicada no Diário Oficial da União nº 244, de 18 de dezembro de 2002, Seção 1, pág. 59-63.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O objetivo deste texto consiste na padronização da utilização dos dispositivos somáticos, fornecidos pelo SUS, que tenham como função estabelecer e manter atividade rítmica do coração, baseando-se em estudos de eficácia, segurança e custo-efetividade. Como existe uma grande variedade de modelos, optou-se, para fins deste Protocolo, pela utilização das codificações revisadas pelo NASPE/BPEG - _North American Society of Pacing and Electrophysiology e British Pacing and Electrophysiology Group_ - para marcapassos antibradicardia (1) (Quadro 1). Justifica-se esta escolha pela inclusão, em suas definições, dos dispositivos com frequência adaptativa e daqueles passíveis de programação (posição IV) e estimulação multissítio (posição V).  
Para melhor entendimento dos códigos pertinentes aos inúmeros dispositivos, cabe aqui uma pormenorização da sua sintaxe. O código sugerido pela NASPE/BPEG consiste, conforme mostrado na Quadro 1, na combinação que, na prática, pode variar de três a cinco letras. A primeira letra diz respeito ao(s) sítio(s) de estimulação do marca-passo. Pode o estímulo elétrico ocorrer no átrio (A), ventrículo (V) ou em ambas (D). A segunda letra diz o local onde o estímulo elétrico fisiológico - proveniente do paciente - pode ser “sentido” (captado) pelo marca-passo. Novamente, isto pode ocorrer no átrio (A), ventrículo (V) ou em ambas as câmaras (D). Uma vez “sentida” a presença do batimento fisiológico, o marca-passo pode apenas deflagrar um estímulo artificial (T) ou apenas inibi-lo (I) Há ainda a possibilidade de estimular ou inibir a deflagração do estímulo artificial conforme a situação (D).  
Os dispositivos com frequência adaptativa, indicados pela presença da quarta letra, implicam que a frequência de estimulação é modulada com base em um sensor interno capaz de detectar a presença do exercício ou a necessidade metabólica. Os sensores mais usualmente utilizados detectam a vibração associada com a atividade física ou detectam a ventilação-minuto.  
Na circunstância específica da estimulação multissítio, representada pela presença da quinta letra, tem-se a possibilidade de estimulação atrial e biventricular, com eletrodos posicionados no átrio direito, ventrículo direito e outro estimulando o ventrículo esquerdo através do seio coronário.  
Exemplificando: um paciente com marca-passo DDD teria um dispositivo de duplacâmara com capacidade de estimular artificialmente tanto o átrio direito quanto o ventrículo direito. Pode ainda detectar estímulos fisiológicos tanto no átrio quanto no ventrículo. Com isso, ele deflagraria, ou não, um estímulo artificial, dada ausência ou presença de batimento fisiológico.  
Por outro lado, um dispositivo DDDR teria as características acima adicionadas a presença de dispositivo de modulação de frequência.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
||I|II|POSIÇ<br>III|ÃO<br>IV|V|
|---|---|---|---|---|---|
||CÂMARA<br>ESTIMULADA|CÂMARA<br>MONITORADA|MODO DE<br>RESPOSTA|MODULAÇÃO DE<br>FREQUÊNCIA|ESTIMULAÇÃO MULTISSÍTIO|
||O = Nenhum|O = Nenhum|O = Nenhum|O = Nenhum|O = Nenhum|
|CATEGORIA|A = Átrio|A = Átrio|T = Estimula<br>(“trigged”)||A = Átrio|
||V = Ventrículo|V = Ventrículo|I = Inibe|R = Modulação por<br>frequência (“rate”)|V = Ventrículo|
||D = A+V (“Dual”)|D = A+V (“Dual”)|D = T+I<br>(“Dual”)||D = A+V (“Dual”)|  
QUADRO **Erro! Nenhuma sequência foi especificada. -** Código genérico para utilização de marca-passo antibradicardia - _Committee On The Development Of Position Statements_ (CDPS) _Of The North American Society Of Pacing And Electrophysiology (_ NASPE _) E British Pacing And Electrophysiology Group_ (BPEG).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Mesmo não sendo o motivo primário deste trabalho a discussão das indicações de marca-passo definitivo, permitir-se-á este preâmbulo para melhor compreensão da escolha do tipo de dispositivo em relação à doença abordada. Iniciaremos, então, com os principais distúrbios que motivam a sua colocação.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Esta entidade nosológica engloba grande diversidade de condições cujas nomenclaturas, eventualmente, são utilizadas de modo intercambiável. Como exemplo, citam-se a síndrome bradicardia-taquicardia, bradicardia sinusal sintomática, incompetência cronotrópica e síndrome do seio carotídeo doente.  
O limiar de indicação de marca-passo é controverso, dado que não há certeza se o dispositivo prolonga a vida desses pacientes. De qualquer forma, considera-se sua colocação quando se tem frequência cardíaca abaixo de 40 batimentos/minuto, mormente durante caminhada, se associada a sintomas clínicos de tonteira ou fadiga. Para tal grupo, acredita-se,

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
segundo consenso de especialistas, que há elevada probabilidade de benefício na qualidade de vida do doente. Todavia, nem sempre é possível estabelecer uma relação de causalidade entre os sintomas, por vezes pouco específicos, e frequência cardíaca.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Em oposição à disfunção do nó sinusal, os bloqueios atrioventriculares adquiridos (BAV) podem necessitar de marca-passo por razões exclusivamente prognósticas, o que dispensaria a presença de sintomas. A despeito do fato de não existirem ensaios clínicos randomizados em pacientes com BAV de segundo grau tipo II e de terceiro grau, existe consenso, baseado em estudos observacionais, de que o tratamento com marca-passo reduz a incidência de síncope e pode reduzir a mortalidade cardiovascular. No caso de BAV de primeiro grau, pode-se, em casos selecionados, indicar quando há sintomas ou quando o bloqueio se dá em nível infra-feixe de His, conforme estudo eletrofisiológico.  
A síncope, quando associada a bloqueio bifascicular ou trifascicular crônico, apresenta mortalidade elevada. Nesse caso, indica-se, profilaticamente, o marca-passo (MP) definitivo, mesmo na ausência de relação direta entre a síncope e o bloqueio. A presença de arritmias ventriculares deve, neste contexto, ser excluída, posto que indicariam a colocação de cardioversor desfibrilador implantável (CDI), conforme Protocolo de Uso específico do Ministério da Saúde, aprovado pela Portaria N<sup>o</sup> 1 SAS / MS, de 02 / 01 / 2014, retificada em 16 / 01 / 2014.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Há consenso de que os pacientes com BAV de segundo grau persistente, juntamente com bloqueio de ramo bilateral ou BAV completo, quer em nível nodal, quer em nível infraHis, seguindo-se a fase aguda de infarto agudo do miocárdio, têm indicação de tratamento com marca-passo, independentemente da presença de sintomas, dada a alta prevalência de síncope e mortalidade cardiovascular elevada. Novamente, a despeito da indicação se basear em estudos observacionais, acredita-se que beneficio tangível existe.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico de síncope neurocardiogênica baseia-se na história clínica e reprodução dos sintomas no teste de inclinação ( _tilt test_ ), após a exclusão de doenças cardíacas estruturais. Na presença de síndrome do seio carotídeo, indica-se implante de marca-passo em pacientes com respostas predominante cardioinibitória e mistas à estimulação carotídea, associada à síncope recorrente.  
A hipersensibilidade do seio carotídeo é causa pouco prevalente de síncope. A indicação do marca-passo se faz no situação exclusiva da alta probabilidade do componente

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
cardioinibitório como predominante na gênese dos sintomas. Isto geralmente pode ser testado no _tilt teste_ ou no estudo eletrofisiológico (EEF).  
No caso das síndromes neurogenicamente mediadas (p. ex., síncope vasovagal), a importância do componente vasopressor leva a frequente falha na melhora dos sintomas com a colocação do MP. Mesmo nos casos que se acompanham de bradicardia e assistolia, 25% deles ainda podem ter sintomas por componente vasopressor. Desta forma, o MP é considerado se houver pausa superior a 3 segundos à estimulação carotídea ou se houver resposta cardioinibitória a testes provocativos. Ainda, se, ao EEF, demonstrar-se disfunção sinusal ou do nó AV, indica-se a colocação do MP. O grau de evidência é baixo, mas há consenso entre os especialistas (2-10,25-29).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A indicação de implante de marca-passo no grupo de pacientes com cardiomiopatia se interpõe com aquelas referentes às bradiarritimias. Tal regra aplica-se tanto no âmbito da cardiopatia hipertrófica quanto da miocardiopatia dilatada. Diferenciam-se, no entanto, os indivíduos deste segundo grupo, quando se trata de um dispositivo que tenha função de ressincronização. Neste caso específico, deve-se considerar o implante de MP átriobiventricular nos pacientes com sintomas de insuficiência cardíaca, refratários à terapêutica plena e que apresentem intervalo QRS prolongado e fração de ejeção ventricular esquerda (FEVE) inferior a 35%, conforme conduta abaixo.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Uma vez estabelecida a indicação de implante do marca-passo, urgirá a seleção da modalidade apropriada ao paciente, à doença de base e aos problemas médicos associados. No que tange ao paciente, fatores concernentes ao ritmo de base, resposta inotrópica ao exercício, história social e a qualidade de vida devem ser trazidos à tona no momento da escolha do dispositivo (2).  
Se, historicamente, o desenvolvimento de tecnologia que permitiu regular o ritmo cardíaco se deu na segunda metade do século XX, nos idos de 1958, com o implante por Elmqvist e Senning do primeiro marca-passo por toracotomia (3), foi após as décadas de 1980-1990 que se iniciaram os esforços para, por meio da estimulação artificial atrial e ventricular, mimetizar a fisiologia normal da contração cardíaca. Ainda, foi a partir dessa ocasião, com o advento da tecnologia de modulação de frequência, que se iniciaram estudos observacionais visando a ampla utilização dos novos dispositivos. No entanto, uma parcela dos especialistas em marca-passo opunha-se à realização de ensaios clínicos randomizados por não acharem necessário a demonstração de ganho incremental, quer na prevenção de eventos clínicos, quer na melhora na qualidade de vida (4). Ainda, a rápida evolução das tecnologias, progressivamente mais sofisticadas, se deu, de certa forma, dissociada de estudos controlados, o que tornam, pois, as evidências de efeitos relevantes, tanto do ponto de vista clínico quanto da perspectiva de saúde pública, plausíveis, mas pouco precisas.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Considerando-se a evolução dos ensaios clínicos, a primeira assertiva que se tem é a superioridade dos dispositivos sequenciais atrioventriculares. Certamente, em oposição ao modo de estimulação unicameral VVI, a presença da sístole atrial sincronizada do modo DDD aumenta o volume sistólico ventricular esquerdo, concomitante à redução da pressão capilar pulmonar e pressão atrial direita, parâmetros fisiológicos desejáveis no tratamento das bradiarritimias (5). Entretanto, não há consenso no que tange à acurácia na determinação do grupo de pacientes que haveriam de obter maior benefício da estimulação bicameral. Postulase que a heterogeneidade da resposta do débito cardíaco à estimulação atrioventricular sincrônica, em comparação à estimulação ventricular, se deve primariamente à dependência das pressões de enchimento ventricular esquerdo. Pacientes com menores pressões de enchimento parecem tirar maior proveito do modo de estimulação DDD, dado que trabalham no ramo ascendente da curva de Frank-Starling (6). Contemplando-se então os dados fisiológicos positivos, no todo consistentes, no aumento do débito cardíaco, infere-se que a estimulação sequencial poderia reduzir o risco de insuficiência cardíaca, diminuir a mortalidade e melhorar a qualidade de vida do doente. De fato, o uso disseminado dos marcapassos bicamerais aliado a alguns ensaios epidemiológicos observacionais tornaram os estudos de sobrevida mera formalidade, na opinião de alguns especialistas, o que não foi compactuado por toda comunidade científica (2,7).  
No ano de 1994 foi realizado o primeiro ensaio clínico randomizado, comparando-se dois marca-passos unicamerais AAI e VVI. Na publicação, com seguimento de 3,3 anos, não houve nenhum benefício em termos de mortalidade (8). Entretanto, um segundo estudo realizado em 1998 demonstra, em longo prazo, melhor classe funcional dos pacientes tratados com estimulação atrial (9). Contrariando impressões de outrora, o estudo _Pacemaker Selection in the Elderly_ (PASE), comparando os dispositivos DDDR e VVVIR, não foi capaz de reproduzir nenhum benefício clínico, o que incluiu morte, acidente vascular cerebral (AVC) ou internação por insuficiência cardíaca (IC) (10).  
Percebe-se, pelo exposto, uma dicotomia no que se refere aos dados fisiológicos - que claramente apontavam para um benefício tangível com relação ao aumento no débito cardíaco nos pacientes tratados com dispositivos de estimulação atrial (DDD ou DDI) -, e os ensaios clínicos, que não demonstraram aumento de sobrevida ou redução na incidência de AVC ou <u>internação por IC.</u>  
Posteriormente, na tentativa de se dirimirem quaisquer incertezas acerca da possível superioridade da estimulação atrial (ou bicameral) sobre a ventricular, dois grandes estudos, o _Canadian Trial of Physiological Pacing_ (CTOPP) e o _Mode Selection Trial in Sinus Node Dysfunction_ (MOST) foram respectivamente publicados em 2000 e 2002 (11,12). No primeiro estudo, CTOPP, um total de 2.568 pacientes com bradicardia sintomática foram randomizados a receber dispositivos de estimulação atrial (AAI, AAIR, DDD ou DDDR) ou ventricular (VVI ou VVIR). Dados analisados após seguimento de três e oito anos foram similares, não refletindo impacto na mortalidade cardiovascular ou nos desfechos AVC e

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
internação por IC (11). O segundo estudo, MOST, comparou duas modalidades diferentes de marca-passo, VVVIR e DDDR, em 2.010 pacientes com disfunção de nó sinusal, pelo período médio de 2,7 anos. Não houve diferença no desfecho primário, que englobava mortalidade total e AVC não fatal. Entretanto, viram-se menos hospitalizações por IC no grupo que utilizou marca-passo bicameral (10,3% versus 12,3%, p = 0,021) (12).  
O real benefício desses dispositivos se vê, em realidade, na redução da prevalência da síndrome de marca-passo e na prevenção da fibrilação atrial em pacientes com doença do nó sinusal. Há de se considerar, então, neste contexto, tal benefício frente ao maior custo e maior probabilidade de complicações, inerentes à colocação de marca-passo bicameral. Em tese, os indivíduos com doença do nó sinusal que tenham, no estudo eletrofisiológico, função do nó AV normal, poderiam receber dispositivo AAI ou AAIR (unicameral). Na prática, pela possibilidade de desenvolvimento de bloqueio atrioventricular com evolução da doença, alguns especialistas indicam a colocação de dispositivos bicamerais (DDD ou DDDR).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Um dado digno de nota, comum a diversos estudos, consiste na redução, em longo prazo, da incidência de fibrilação atrial (FA) nos pacientes com disfunção do nó sinusal em uso de dispositivos de estimulação atrial (AAI, AAIR, DDD ou DDDR). Há muitas teorias acerca do motivo deste achado, mas nenhuma definitiva. De qualquer forma, esta informação deve ser considerada no processo de escolha do dispositivo de estimulação cardíaca, posto que condições como a disfunção do nó sinusal se associam a elevada probabilidade de desenvolvimento de FA (8,10,11,12).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Outro fator a se considerar na escolha da modalidade do marca-passo é a possibilidade da síndrome de marca-passo. Descrita pela primeira vez em 1969, define-se como um conjunto de sinais e sintomas que podem ocorrer em pacientes após estimulação ventricular (13). Tal síndrome pode ser dividida, para fins didáticos, em três diferentes polos: congestivo, associado à hipotensão e inespecífico. No primeiro caso, o paciente desenvolve sintomas clássicos de IC congestiva. No segundo, síncope e lipotímia, associadas à hipotensão postural dominam o quadro. No polo inespecífico, sintomas como cefaleia, fadiga e mal-estar são as queixas principais. A etiologia da síndrome de marca-passo é complexa e abrange, por um lado, a perda da sincronia atrioventricular - que se demonstra pela presença de ondas “A” em canhão no pulso venoso – e, por outro, uma resposta neuro-humoral, vascular e autonômica desencadeada por reflexo cardioinibitório exacerbado, possivelmente secundária a distensão das câmaras atriais. No estudo norte-americano MOST (12), a síndrome de marca-passo foi a principal causa de _crossover_ - 18,3% dos 996 pacientes do grupo com estimulação ventricular (VVI, VVIR) migraram para o grupo de estimulação bicameral, o que geralmente ocorreu nos primeiros três meses após o implante do marca-passo. Por outro lado, o estudo canadense (CTOPP) (11) e o estudo publicado por Andersen _et al_ (8) obtiveram resultados opostos, com

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
taxas de _crossover_ de 5% e 1,8% respectivamente. Possivelmente, o fato da randomização nesses dois estudos serem de _hardware_ , ou seja, o _crossover_ implica obrigatoriamente na troca do dispositivo (o que significa novo procedimento cirúrgico), em oposição ao estudo MOST, em que haveria apenas reprogramação do modo de estimulação, pode, de certa forma, justificar as discrepâncias dos dados. De qualquer modo, infere-se que cerca de um quarto dos pacientes com marca-passo VVI desenvolvem a síndrome de marca-passo o que foi tratado, _a posteriori_ , com programação bicameral (17).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Mais recentemente, os marca-passos com modulação de frequência foram introduzidos como o propósito de tornar mais fisiológica a estimulação cardíaca, tendo em vista o fato de que o incremento na frequência cardíaca é responsável por 75% do incremento do débito cardíaco. A despeito disso, os diversos ensaios clínicos publicados mostraram-se dissonantes com os estudos experimentais em laboratório, em relação à melhora da capacidade funcional, comparando-se os dispositivos DDD e DDDR (14,15). Em contrapartida, o estudo _Rate Modulated Pacing and Quality of Life_ (RAMP) sugere que os pacientes que alcançam 60% ou mais da frequência cardíaca predita pela idade após a colocação do DDDR teriam melhor qualidade de vida (2). Pequenos estudos de _crossover_ , da mesma forma, ratificam os resultados do RAMP (16). Face às controvérsias e inconsistências, a indicação disseminada dos marca-passos com modulação de frequência não se sustenta. Possivelmente, em algum grupo específico de pacientes, o aumento da frequência cardíaca é contrabalançado com o já descrito fenômeno da perda de sincronia V-V.  
A utilização da modulação de frequência e do tipo de marca-passo se baseará, então, no seguinte tripé: (1) nível de esforço exercido pelo paciente em suas atividades; (2) deficiência cronotrópica do nó sinusal comprovada; e (3) bloqueio do nó AV. Primeiramente, demonstra-se a necessidade de ajuste de frequência cardíaca, a exemplo: indivíduo jovem, fisicamente ativo e com deficiência cronotrópica. Se, neste contexto, a função do nó AV encontra-se preservada, utilizar-se-ia o AAIR, mantendo-se a sincronia AV. Se houver disfunção do nó AV, o modo DDDR seria o mais indicado.  
Há consenso entre especialistas de que os pacientes com FA permanente e bloqueio AV de alto grau que necessite de suporte cronotrópico se beneficiaria da modulação de frequência, com modo de estimulação VVIR (17), no que diz respeito à redução nos sintomas de falta de ar e cansaço, assim como melhora na qualidade de vida  
As principais indicações dos diferentes tipos de dispositivos foram resumidas nos quadros 2, 3 e 4. A Figura 1 apresenta um algoritmo para escolha do modo de estimulação baseados nos sintomas clínicos e a Figura 2, segundo o distúrbio de ritmo diagnosticado.  
<!-- Start of picture text -->
@<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
||CONFIANÇA DAS<br>EVIDÊNCIAS<br>|GRAU DE RECOMENDAÇÃO<br>|REFERÊNCIAS<br>|
|---|---|---|---|
|DISFUNÇÃO DO NÓ SINUSAL: Marca-<br>passo indicado quando os sintomas<br>são certamente atribuíveis à<br>bradicardia.<br>~~t~~<br>|Moderada<br><br>|Forte - a favor<br>~~T~~<br>|8-9.<br><br>|
|DISFUNÇÃO DO NÓ SINUSAL: Marca-<br>passo indicado quando os sintomas<br>são provavelmente atribuíveis à<br>bradicardia.<br>~~A~~<br>|Baixa<br><br>|Fraca - a favor<br>~~=~~<br>|8-9.<br><br>|
|DISFUNÇÃO DO NÓ SINUSAL:<br>Bradicardia assintomática ou<br>desencadeada porcausas<br>reversíveis.<br><br>|Alta<br><br>|Forte - Contraindicado<br><br>|8-9.<br><br>|
|BLOQUEIOAVADQUIRIDO: Marca-<br>passo indicado nos casos de BAV de<br>2° grau tipo II ou BAV de 3° grau,<br>independente de sintomas.<br><br>|Baixa<br><br>|Forte - a favor<br><br>|2,3,4,17.<br><br>|
|BLOQUEIOAVADQUIRIDO: Marca-<br>passo pode ser considerado nos<br>casos de BAV de 2° grau tipo I ou<br>BAV de 1° grau sintomático ou<br>quando o bloqueio é infra-His no<br>estudo eletrofisiológico ou quando<br>há necessidade de utilização de<br>medicamentos com ação inibitória<br>no nó AV (a exemplo de<br>betabloqueadores).<br>~~p~~<br>|Baixa<br><br>|Forte - a favor<br>~~t~~<br>|2,3,4,7,17.<br>~~}~~<br>|
|BLOQUEIOAVADQUIRIDO: BAV<br>desencadeado porcausas<br>reversíveis.<br>|Baixa<br>|Forte - Contraindicado<br>|2,3,4,7,17.<br>|
|BLOQUEIOAVALTERNANTE:<br>Marca-passo pode ser considerado<br>nos casos de BAV alternante (BRD<br>– bloqueio de ramo direito<br>alternando com BRE – bloqueio de<br>ramo esquerdo).<br><br>~~P~~|Baixa<br><br>|Forte - a favor<br><br>~~=~~|2,3,4,7,17.<br><br>|  
QUADRO 2 **-** Indicações de marca-passo em pacientes com bradicardia persistente.  
||CONFIANÇA DAS<br>EVIDÊNCIAS|GRAU DE RECOMENDAÇÃO|REFERÊNCIAS|
|---|---|---|---|
|DISFUNÇÃO DO NÓ SINUSAL: Marca-<br>passo bicameral, mantendo-se<br>condução AV.|Moderada|Forte - a favor|8-9.|
|DISFUNÇÃO DO NÓ SINUSAL: Marca-<br>passo com modulação de frequência<br>em pacientes jovens e fisicamente<br>ativos com deficiência cronotrópica<br>comprovada.|Baixa|Fraca - a favor|8-9.|
|BLOQUEIOAVADQUIRIDO: Marca-<br>passo bicameral deve ser indicado<br>com a finalidade de evitar-se a<br>síndrome de marca-passo e<br>melhorar a qualidade de vida do<br>doente.|Baixa|Forte - a favor|8,11,12,17.|
|BLOQUEIOAVADQUIRIDO EFA<br>PERMANENTE: Há indicação do<br>modo de estimulação VVIR.|Baixa|Forte - a favor|8,11,12,17.|  
QUADRO 3 - Escolha do modo de estimulação conforme a doença ou síndrome tratada.  
||CONFIANÇA DAS<br>EVIDÊNCIAS|GRAU DE RECOMENDAÇÃO|REFERÊNCIAS|
|---|---|---|---|
|Marca-passo bicameral indicado<br>para prevenção de FA em pacientes<br>com doença do nó sinusal.|Moderada|Forte - a favor|8,9,17.|
|Marca-passo bicameral indicado<br>para prevenção de síndrome de|Baixa|Forte - a favor|8,11,12.|
|marca-passo.||||  
<!-- Start of picture text -->
Ny<br><!-- End of picture text -->  
|Marca-passo bicameral indicado<br>para prevenção de IC - não inclui<br>ressincronização.|Baixa|Fraca - Contraindicada|2,4,5,7,8.|
|---|---|---|---|
|Marca-passo bicameral indicado<br>para aumento de sobrevida.|Moderado|Forte - Contraindicado|2,4,5,7,8.|
|Marca-passo bicameral indicado<br>para prevenção de AVC.|Moderado|Forte - Contraindicado|2,4,5,7,8.|  
QUADRO 4 - Resumo das indicações dos dispositivos de estimulação bicameral conforme objetivo fim do procedimento.  
<!-- Start of picture text -->
desintométicaBradicardia altoriscoevento oude<br>Necessidade de woe<br>estimulacdosequencialAV noHarca-passo indicado<br>{_preservado ajustede FC<br>ppp Condugao AV a +<br>140 opm wR wi<br>Necessidadeajuste de FC de Necessidaceajustede FCde<br>AAIR’ AAI’ DDDR DDD<br><!-- End of picture text -->  
FIGURA **Erro! Nenhuma sequência foi especificada.** - Algoritmo para seleção de modo de estimulação do marca-passo baseado apenas nos sintomas.  
† A forma VVI não tem sido mais utilizada de rotina.  
*As formas unicamerais atriais ficariam a critério exclusivo dos eletrofisiologistas. Deve ser considerado que a função normal do nó AV deve ser garantida. Ainda, existem casos de doença de nó sinusal em que acometimento do nó AV pode se desenvolver no futuro, de forma imprevisível.  
<!-- Start of picture text -->
aN<br><!-- End of picture text -->  
<!-- Start of picture text -->
16 sinusal<br>GixiunZaes | BloqueioAV<br>| Persistente l Intermitente ! Persistente U Intermitente<br>Incopeténcopeténca incopeténctaser aropstope | |  Disfunctodisfuncéio ee distungoser  do Fibrilacbri Eg m=<br>U crenotropica | (° cronotrépica pppiR = nesinusal | nsinusal | ata (wins<br>22 opgdo fibrilagdo<br>s AAIR atrial)<br>1 opgao. 1 opie. S<br>1 Boned,opgfo 1 2 opgao,ope’ DOOR DDD WIR<br>DDDR DDD 7 a<br>2? opcfo 2? opgao.. 2?pppop¢io 2?vobop¢ao<br>AAIR® AAI’ 2? op¢o~ 3? op¢o8<br>WIR VWIR<br><!-- End of picture text -->  
FIGURA 1 - Algoritmo de escolha do tipo de marca-passo conforme o distúrbio.  
*As formas unicamerais atriais ficariam a critério exclusivo dos eletrofisiologistas. Deve ser considerado que a função normal do nó AV deve ser garantida. Ainda, existem casos de doença de nó sinusal em que acometimento do nó AV pode se desenvolver no futuro, de forma imprevisível.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Os estudos da fisiologia apontam para o fato de que a sincronia atrioventricular não é a única e primordial variável quando se tenta substituir artificialmente o batimento cardíaco. Postula-se então que a sequência fisiológica de ativação ventricular, aqui denominada sincronia de ativação ventricular direito-esquerdo (sincronia VD-VE) poderia, teoricamente, ser essencial para manutenção do débito cardíaco normal. Na realidade, a estimulação apical ventricular direita, como é habitualmente feita pelo marca-passo VVI, induz uma contração anômala do coração, dado que o estímulo elétrico se faz, de forma lenta, pelo músculo cardíaco, e não pelos feixes de condução rápida do sistema His-Purkinje. Esta assunção se torna pedra fundamental nos dispositivos de ressincronização utilizados nos pacientes com IC que tenham no eletrocardiograma (ECG) aumento na duração do complexo QRS (despolarização ventricular acima de 150 milissegundos) e FEVE a 35%. De fato, a presença, no ECG de superfície, de alargamento do complexo QRS acima de 120 milissegundos, com ou sem atraso na condução AV, é marcador isolado para possibilidade de assincronia interventricular (VD-VE) e intraventricular (VE-VE) (18). A ativação anormal causada pelos bloqueios de ramo resulta em queda na eficiência cardíaca com diminuição do volume sistólico, aumento nas pressões do átrio esquerdo e capilar pulmonar e disfunção de músculo papilar com regurgitação mitral. A ressincronização cardíaca poderia, em tese, reverter tais alterações, de modo a proporcionar o remodelamento reverso, leia-se diminuição das cavidades cardíacas e melhora da função biventricular. Infelizmente, os mecanismos predominantes do benefício variam muito entre pacientes, o que nos impede de discernir com

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
precisão o grupo que se beneficiaria mais da ressincronização, ou seja, os “respondedores”, do grupo cuja resposta se encontraria aquém daquela desejada (“não respondedores”) (17-19). Como a história repetidamente nos mostra uma grande distância entre constructos teóricos e resultados práticos, apresenta-se, a seguir, o que há de evidências palpáveis.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Desde os idos de 2001, os estudos para regulamentação da terapia com o dispositivo com ressincronizador se tornaram frequentes, porém, não menos conflitantes (18,20-24). A heterogeneidade dos grupos no que diz respeito ao perfil das classes funcionais assim como ao perfil dos desfechos estudados limitaram de certa forma uma análise pormenorizada das evidências. Os primeiros ensaios realmente apontavam tendência na direção de aumento na capacidade funcional assim como na redução nas dimensões ventriculares esquerdas, o que seria, _a posteriori_ , denominada de remodelamento reverso (21-24). Quando se analisa metaanálise, que compila dados advindos de diversos estudos, tiram-se algumas conclusões.  A despeito do que se é dito, o número de pacientes em classe funcional IV de NYHA  é pouco representativo, ao menos de forma estatisticamente relevante. Foram, pois, representados por uma classe criada de pacientes denominada “classe IV ambulatorial”, possivelmente uma interseção de pacientes que transitam entre classes III e IV de NYHA (25). Para tanto, neste Protocolo, os pacientes classificados como classe IV ambulatorial serão tratados como indivíduos em classe funcional III.  Dito isso, os pacientes que mais obtiveram benefício, segundo talvez por terem sido mais bem representados, foram aqueles em **classe funcional III** de NYHA, com **FEVE a 35%** , com **bloqueio de ramo esquerdo** e duração de **QRS superior a 150 milissegundos** . Os pacientes que se enquadrem neste perfil e que não possuam nenhuma condição que lhes confira expectativa de sobrevida inferior a um ano, a exemplo de neoplasias malignas graves, têm elevada probabilidade de se beneficiar da colocação do ressincronizador, tanto para aumento na sobrevida quanto na melhora na qualidade de vida por aumento na capacidade funcional. Os pacientes em **classe funcional III** que têm no ECG morfologia de **BRE** , porém uma duração de QRS situada entre **120 e 149 milissegundos** , se encontram em uma situação especial. Há consenso entre os especialistas de que pode haver benefício na instalação do ressincronizador, especialmente na redução dos sintomas e diminuição do número de internações, mas possivelmente não tão marcante, pois que aparentemente existe uma associação direta entre a duração do QRS e a intensidade da resposta a partir de 120 milissegundos (20).  
Neste ponto, as maiores controvérsias se colocam nas “regiões fronteiriças”, em que extrapolações estatísticas se fazem comumente e, por vezes, com sofismas deveras convincentes. Os indivíduos em **classe funcional II** de NYHA possuem grande apelo no que tange a evolução quase que inexorável de doença. Nesses casos, advoga-se que, nas circunstancias de FEVE inferior a 35% e BRE com QRS de duração superior a 150 milissegundos, a colocação do ressincronizador poderia, em tese, estabilizar o desenvolvimento da doença (26). Outro ponto de controvérsia reside nos pacientes em **classe funcional IV** , de NYHA, que foram pouco representados nos estudos (21-24). Na realidade, parte dos benefícios obtidos e descritos foi extrapolada de subgrupos de pacientes denominados de “ **grupo IV ambulatorial** ”, ou como especificado - “ _defined as class IV_

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
_heart failure with: 1) no active acute coronary syndrome; 2) no inotropes; and 3) on guideline-directed medical therapy”_ , o que poderia ser interpretado como um paciente que transita entre classe III e classe IV de NYHA (26). Em suma, ainda não há como indicar, com base nos dados atuais, implante do ressincronizador nos pacientes em classe funcional I e IV de NYHA, independentemente da FEVE ou da duração do QRS. No caso específico dos indivíduos em classe funcional II, existe consenso dos especialistas na indicação do dispositivo, desde que em conjunto com fração de ejeção ventricular esquerda inferior a 35%, com BRE e duração de QRS superior a 150 milissegundos.  
Outro ponto de extenso debate envolve, como já dito, a duração do QRS. A associação entre o benefício e a duração é bem estudada nos pacientes com morfologia de BRE, possivelmente por sua maior prevalência nos estudos (17). Ainda, pacientes com QRS alargado e padrão não BRE são estatisticamente mais graves. Desta forma, a despeito da falta de dados conclusivos, baseando-se em resultados anedóticos, relatos de casos e estudos não controlados indica-se a ressincronização nos pacientes em classe funcional III não BRE com duração de QRS acima de 150 milissegundos e FEVE inferior a 35% (18,19,21,22).

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Os pacientes com FA e IC com necessidade de ressincronização acabaram por formar um grupo mal estudado por serem minoria nos ensaios clínicos. Ainda, para que a terapia seja eficiente e eficaz, é imperativa a ablação do nó atrioventricular de modo que 95% dos batimentos cardíacos se façam pelo ressincronizador. A ausência, até o presente momento, de um ensaio clínico específico deste tratamento em caso de IC torna contraindicado o seu uso. O Quadro 5 resume as principais indicações da ressincronização.  
|INDICAÇÃO|CONFIANÇA DAS<br>EVIDÊNCIAS|GRAU DE RECOMENDAÇÃO|REFERÊNCIAS|
|---|---|---|---|
|BRECOM DURAÇÃO DOQRS ≥<br>150MILISSEGUNDOS:<br>Ressincronização é<br>recomendada aos pacientes com<br>insuficiência cardíaca congestiva<br>(ICC) crônica e FEVE< 35%<br>que persistem emclasse<br>funcional IIIde NYHA a<br>despeito de terapia<br>farmacológicaplena.|Alta|Forte - a favor|17-26.|
|BRECOM DURAÇÃO DOQRS<br>120-150MILISSEGUNDOS:<br>Ressincronização é||||
|recomendada aos pacientes com<br>ICC crônica e FEVE ≤ 35% que<br>persistem emclasse funcional III<br>de NYHA a despeito de terapia<br>farmacológicaplena.|Baixa|Forte - a favor|17-26.|

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|NÃOBRE COM DURAÇÃO DO||||
|---|---|---|---|
|QRS ≥ 150MILISSEGUNDOS:<br>Ressincronização éconsiderada<br>nos pacientes com ICC crônica e<br>FEVE ≤ 35% que persistem em<br>classe funcional IIIde NYHA a<br>despeito de terapia<br>farmacológicaplena.|Fraca|Fraca - a favor|17-26.|
|NÃOBRECOM DURAÇÃO DO<br>QRS 120-150MILISSEGUNDOS:<br>Ressincronização é||||
|recomendada aos pacientes com<br>ICC crônica e FEVE ≤ 35% que<br>persistem em classe funcional III<br>de NYHA a despeito de terapia<br>farmacológicaplena.|Fraca|Fraca - contra|17-26.|
|DURAÇÃO DOQRS < 120||||
|MILISSEGUNDOS:<br>Ressincronização não é<br>recomendada.|Alta|Forte - contra|17-26.|
|PACIENTES EM CLASSE<br>FUNCIONALII: Ressincronização||||
|indicada em pacientes em classe<br>funcional II de NYHA em uso|Baixa|Fraca - a favor|17-26.|
|de terapia farmacológicaplena.||||
|PACIENTES EM CLASSE<br>FUNCIONALIV:||||
|Ressincronização não indicada<br>em pacientes em classe|Baixa|Fraca - contra|17-26.|
|funcional IV de NYHA em uso||||
|de terapia farmacológicaplena.||||  
QUADRO 5 - Indicação de terapia de ressincronização em pacientes com ritmo sinusal e insuficiência cardíaca.  
5- DA INDICAÇÃO DE TERAPIA COMBINADA DE RESSINCRONIZAÇÃO CARDÍACA (TRC) E DE CARDIOVERSOR-DESFIBRILADOR IMPLANTÁVEL (CDI) - TRC-D  
Forte é o apelo pela colocação de um dispositivo cardioversor-desfibrilador em um paciente com insuficiência cardíaca que tem, primariamente, indicação de terapia de ressincronização, posto que a morte elétrica é, de certa forma, prevalente nessa população. Tal possibilidade tornou-se, na última década, tema de muitas discussões, infelizmente baseadas em ensaios que não foram desenhados para esta finalidade (17,27,28). Uma metaanálise bayesiana que englobou 8.307 pacientes e 1.636 eventos não foi capaz de demonstrar superioridade da TRC associado ao CDI (TRC-D) relativamente a TRC isolada (29) (Quadro  
6). Dito isso, tem-se que, atualmente, a indicação da TRC-D se torna terapia de exceção e engloba indivíduos com critérios claros para ambas as terapias. A principal indicação de implante de CDI inclui a profilaxia secundária de eventos arrítmicos fatais, ou seja, refere-se a pacientes que sobreviveram à morte súbita por fibrilação ventricular ou taquicardia ventricular sustentada (TVS). E se os critérios que justifiquem a TRC se somarem àqueles da indicação do CDI, indica-se, então, a TRC/CDI – terapia combinada. Deve-se ter em mente que, no caso do CDI, os melhores resultados se dão na presença de disfunção ventricular e tratamento cardiovascular pleno – o que deve incluir medicação betabloqueadora e supressão da isquemia, quer por tratamento de revascularização, quer por tratamento clínico. Neste caso, como se pode perceber, a indicação primária é do CDI e a TRC pode ser considerada como adjuvante.  
Por outro lado, a profilaxia primária para eventos arrítmicos fatais visa a evitar morte súbita em pacientes selecionados como alto risco para tal evento. Assim, tem-se indivíduos com indicação de TRC que, em tese, se beneficiariam da terapia combinada, não tendo sofrido, por pressuposto, evento arrítmico fatal, posto que se enquadrem em profilaxia primária para eventos arrítmicos fatais.  
No que diz respeito à prevenção primária, há muita discussão em torno das evidências para utilização do CDI. Os ensaios clínicos envolveram pacientes com disfunção ventricular (FEVE inferior a 30%-40%), mas as informações acerca da presença de isquemia não eram claras nas análises realizadas.  
Desta forma, o nível de evidência para utilização do CDI na prevenção primária de morte súbita em pacientes com doença coronariana é baixo, mesmo na presença de disfunção ventricular. Indica-se CDI, ainda que com baixo nível de evidência, nos casos que apresentem arritmia ventricular frequente e indução de fibrilação ou taquicardia ventricular em estudo eletrofisiológico. No que diz respeito à redução de mortalidade, em se tratando de pacientes com cardiopatia isquêmica, o mais importante é a utilização de medicação betabloqueadora e tratamento pleno da insuficiência cardíaca e, quer com revascularização, quer com tratamento clínico, da isquemia miocárdica.  
|INDICAÇÃO|CONFIANÇA DAS<br>EVIDÊNCIAS|GRAU DE RECOMENDAÇÃO|REFERÊNCIAS|
|---|---|---|---|
|Pacientes com indicação de<br>ressincronizador que têm história<br>de fibrilação ventricular.|Baixa|Fraca - a favor|29|  
QUADRO 6 - Indicação de TRC-D.  
Na prática, o dispositivo combinado cardioversor desfibrilador implantável-ressincronizador deve ser usado em pacientes que, além da clara indicação de TRC, preencha os critérios de utilização do CDI aprovados pela Portaria N<sup>o</sup> 1 / SAS / MS, de 2 de janeiro de 2014, a qual atualiza, em seu anexo, o protocolo de uso do CDI nos estabelecimentos de saúde credenciados no SUS.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes com indicação de implante de marca-passo cardíaco e ressincronizador devem ser atendidos em Centro de Referência em Alta Complexidade Cardiovascular habilitados pelo Ministério a Saúde, conforme definido na Portaria Nº 210 / SAS/MS, de 15 de junho de 2004, e com porte tecnológico suficiente para avaliar e realizar os procedimentos e o acompanhamento dos indivíduos implantados.  
Além da familiaridade que esses hospitais guardam com o diagnóstico, o tratamento e o acompanhamento de cardiopatas, eles, a par de toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios, devem também dispor, no próprio Hospital, de laboratório de eletrofisiologia invasiva e serviço de avaliação de programação de marca-passos, ressincronizadores e cardioversores desfibriladores implantáveis - tudo isso necessário para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos), entre outras. Ações de auditoria devem verificar _in loco_ , por exemplo, a observância deste Protocolo; regulação do acesso assistencial; qualidade da autorização; a conformidade da indicação de marcapasso, ressincronizador e cardioversor e do acompanhamento; compatibilidade do procedimento codificado com o diagnóstico; a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Constam da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS os seguintes procedimentos relacionáveis especificamente com marcapassos, ressincronizadores e cardioversores desfibriladores implantáveis, que guardam compatibilidade com as respectivas OPME (dispositivos), conforme se pode verificar no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP), disponível em <u>http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp</u> e atualizado mensalmente:

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
04.06.01.056-0 Implante de cardioversor desfibrilador de câmara única transvenoso  
04.06.01.057-9 Implante de cardioversor desfibrilador (CDI) multi-sítio 04.06.01.058-7 Implante de cardioversor desfibrilador de câmara dupla transvenoso 04.06.01.059-5 Implante de cardioversor desfibrilador multi-sítio endocavitário c/ reversão para epimiocárdico por toracotomia  
04.06.01.060-9 Implante de cardioversor-desfibrilador (CDI) multi-sítio transvenoso  
04.06.01.061-7 Implante de marcapasso cardíaco multi-sítio endocavitário c/ reversão p/ epimiocárdico (por toracotomia)  
04.06.01.062-5 Implante de marcapasso cardíaco multi-sítio epimiocárdico por implante de marcapasso cardíaco multi-sítio transvenoso 04.06.01.063-3 Implante de marca-passo multi-sítio transvenoso 04.06.01.064-1 Implante de marcapasso de câmara dupla epimiocárdico 04.06.01.065-0 Implante de marca-passo de câmara dupla transvenoso 04.06.01.066-8 implante de marcapasso de câmara única epimiocárdico 04.06.01.067-6 Implante de marca-passo de câmara única transvenoso 04.06.01.068-4 Implante de marcapasso temporário transvenoso 04.06.01.085-4 Reposicionamento de eletrodos de cardioversor desfibrilador 04.06.01.086-2 Reposicionamento de eletrodos de marcapasso 04.06.01.087-0 Reposicionamento de eletrodos de marcapasso multi-sítio 04.06.01.103-6 Troca de eletrodos de marcapasso de câmara dupla 04.06.01.104-4 Troca de eletrodos de marcapasso de câmara única 04.06.01.105-2 Troca de eletrodos de marcapasso em cardio-desfibrilador de câmara dupla transvenoso 04.06.01.107-9 Troca de eletrodos de marcapasso no cardio-desfibrilador multi-sítio 04.06.01.108-7 Troca de eletrodos de marcapasso no marcapasso multi-sítio 04.06.01.112-5 Troca de gerador de marcapasso de câmara dupla 04.06.01.113-3 Troca de gerador de marcapasso de câmara única 04.06.01.114-1 Troca de gerador de marcapasso multi-sítio 04.06.01.115-0 Troca de gerador e de eletrodo de marcapasso de câmara única 04.06.01.118-4 Troca de gerador e de eletrodos de marcapasso de câmara dupla 04.06.01.119-2 Troca de gerador e de eletrodos no marcapasso multi-sítio  
DISPOSITIVOS 07.02.04.004-5 Cardioversor-desfibrilador (CDI) com marcapasso multi-sítio 07.02.04.005-3 Cardioversor desfibrilador implantável (CDI) - gerador 07.02.04.006-1 Cardioversor-desfibrilador implantável (CDI) 07.02.04.023-1 Eletrodo de cardioversor desfibrilador 07.02.04.026-6 Eletrodo p/ marcapasso temporário endocárdico 07.02.04.027-4 Eletrodo p/ marcapasso temporário epicárdico 07.02.04.041-0 Marcapasso cardíaco multiprogramável de câmara dupla 07.02.04.042-8 Marcapasso cardíaco multiprogramável de câmara única 07.02.04.043-6 Marcapasso multi-sítio  
Cada hospital deve coletar rotineiramente seus dados e computar os resultados, detectando possíveis nichos suspeitos de resultados piores para análise detalhada de suas causas, pois os dados negativos podem apenas sugerir um pior resultado associado, por exemplo, a um perfil assistencial de pacientes mais graves.  
Esses dados devem ficar disponíveis aos gestores do SUS, para efeito de avaliação e auditoria, sempre que solicitados.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
É obrigatória a informação ao paciente, ou a seu responsável legal, dos potenciais riscos, benefícios e eventos adversos relacionados ao uso de marca-passo, ressincronizador e cardioversor, o que deverá ser obrigatoriamente formalizado por meio da assinatura de Termo de Esclarecimento e Responsabilidade, quando se tratar de cardioversor desfibrilador implantável.

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1- Bernstein, AD et al. THE REVISED NASPE/BPEG GENERIC CODE FOR ANTIBRADYCARDIA, ADAPTIVE-RATE, AND MULTISITE PACING. PACE 2002; 25:260–264. 2- Lamas GA, Ellenbogen KA, Hennekens CH, Montanez A. EVIDENCE BASE FOR PACEMAKER MODE SELECTION FROM PHYSIOLOGY TO RANDOMIZED TRIALS _._ Circulation. 2004;109:443-451.  
3- Elmqvist R, Senning Å. IMPLANTABLE PACEMAKER FOR THE HEART. In: Smyth CN, ed. Medical Electronics: Proceedings of the Second International Conference on Medical Electronics, Paris, 24–27 June 1959. London, UK: Iliffe and Sons; 1960:253–254.  
4- Ovsyshcher IE, Hayes DL, Furman S. DUAL-CHAMBER PACING IS SUPERIOR TO VENTRICULAR PACING: FACT OR CONTROVERSY?Circulation. 1998;97:2368–2370. doi: 10.1161/01.CIR.94.3.578doi: 10.1161/01.CIR.94.3.578.  
5- Lamas GA. PHYSIOLOGICAL CONSEQUENCES OF NORMAL ATRIOVENTRICULAR CONDUCTION: APPLICABILITY TO MODERN CARDIAC PACING. J Card Surg. 1989;4:89–98.  
6- Greenberg B, Chatterjee K, Parmley WW, et al. THE INFLUENCE OF LEFT VENTRICULAR FILLING PRESSURE ON ATRIAL CONTRIBUTION TO CARDIAC OUTPUT. Am Heart J. 1979;98:742– 751.  
7- Lamas GA. PACEMAKER MODE SELECTION AND SURVIVAL: A PLEA TO APPLY THE PRINCIPLES OF EVIDENCE BASED MEDICINE TO CARDIAC PACING PRACTICE. Heart. 997;78:218– 220.  
8- Andersen HR, Thuesen L, Bagger JP, et al. PROSPECTIVE RANDOMISED TRIAL OF ATRIAL VERSUS VENTRICULAR PACING IN SICK-SINUS SYNDROME. Lancet. 1994; 344:1523–1528.  
9- Nielsen JC, Andersen HR, Thomilissegundosen PE, et al. HEART FAILURE AND ECHOCARDIOGRAPHIC CHANGES DURING LONG-TERM FOLLOW-UP OF PATIENTS WITH SICK SINUS

---

<!-- METADADOS: doenca: Marca-passos cardíacos implantáveis e ressincronizadores | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
SYNDROME RANDOMIZED TO SINGLE-CHAMBER ATRIAL OR VENTRICULAR PACING. Circulation. 1998;97:987–995.  
10- Lamas GA, Orav EJ, Stambler BS, et al. QUALITY OF LIFE AND CLINICAL OUTCOMES IN ELDERLY PATIENTS TREATED WITH VENTRICULAR PACING AS COMPARED WITH DUAL-CHAMBER PACING. N Engl J Med. 1998;338:1097–104.  
11- Connolly SJ, Kerr CR, Gent M, et al. EFFECTS OF PHYSIOLOGIC PACING VERSUS VENTRICULAR PACING ON THE RISK OF STROKE AND DEATH DUE TO CARDIOVASCULAR CAUSES. N Engl J Med. 2000;342:1385–1391.  
12- Lamas GA, Lee KL, Sweeney MO, et al. VENTRICULAR PACING OR DUAL CHAMBER PACING FOR SINUS-NODE DYSFUNCTION. N Engl J Med. 2002;346:1854–1862.  
13- Ausubel K, Furman S. THE PACEMAKER SYNDROME. Ann Intern Med. 1985;103:420– 429.  
14- Capucci A, Boriani G, Specchia S. EVALUATION OF DDDR VERSUS DDD PACING. PACING CLIN ELECTROPHYSIOL. 1992;15:1908–1913.  
15- Jutzy RV, Florio J, Isaeff DM, et al. COMPARATIVE EVALUATION OF RATE MODULATED DUAL CHAMBER AND VVIR PACING. Pacing Clin Electrophysiol. 1990;13:1838–1846.  
16- Sulke N, Chambers J, Dritsas A, et al. A RANDOMIZED DOUBLE-BLIND CROSSOVER COMPARISON OF FOUR RATE RESPONSIVE PACING MODES. J Am Coll Cardiol. 1991;17:696–706. 17- Brignole M, Auricchio A, Baron-Esquivias G, et al. 2013 ESC GUIDELINES ON CARDIAC PACING AND CARDIAC RESYNCHRONIZATION THERAPY. The Task Force on cardiac pacing and resynchronization therapy of the European Society of Cardiology (ESC). Developed in collaboration with the European Heart Rhythm Association (EHRA). European Heart Journal (2013) 34, 2281–2329. doi:10.1093/eurheartj/eht150.  
18- Abraham WT, Fisher WG, Smith AL, Delurgio DB, Leon AR, Loh E, Kocovic DZ, Packer M, Clavell AL, Hayes DL, Ellestad M, Trupp RJ, Underwood J, Pickering F, Truex C, McAtee P, Messenger J. CARDIAC RESYNCHRONIZATION IN CHRONIC HEART FAILURE. N Engl J Med 2002;346:1845–1853.  
19- Zareba W, Klein H, Cygankiewicz I, Hall WJ, McNitt S, Brown M et al. EFFECTIVENESS OF CARDIAC RESYNCHRONIZATION THERAPY BY QRS MORPHOLOGY IN THE MULTICENTER AUTOMATIC DEFIBRILLATOR IMPLANTATION TRIAL-CARDIAC RESYNCHRONIZATION THERAPY (MADIT-CRT). Circulation 2011;123:1061–1072.  
20- Moss AJ, Hall WJ, Cannom DS, Klein H, Brown MW, Daubert JP, Estes NA 3rd, Foster E, Greenberg H, Higgins SL, Pfeffer MA, Solomon SD, Wilber D, ZarebaW. CARDIAC-RESYNCHRONIZATION THERAPY FOR THE PREVENTION OF HEART-FAILURE EVENTS. N Engl J Med 2009;361:1329–1338.  
21- Auricchio A, Stellbrink C, Butter C, Sack S, Vogt J, Misier AR, Bocker D, Block M, Kirkels JH, Kramer A, Huvelle E. CLINICAL EFFICACY OF CARDIAC RESYNCHRONIZATION THERAPY USING LEFT VENTRICULAR PACING IN HEART FAILURE PATIENTS STRATIFIED BY SEVERITY OF VENTRICULAR CONDUCTION DELAY. J Am Coll Cardiol 2003;42:2109–2116.  
22- Cazeau S, Leclercq C, Lavergne T, Walker S, Varma C, Linde C, Garrigue S, Kappenberger L, Haywood GA, Santini M, Bailleul C, Daubert JC. EFFECTS OF MULTISITE BIVENTRICULAR PACING IN PATIENTS WITH HEART FAILURE AND INTRAVENTRICULAR CONDUCTION DELAY. N Engl J Med 2001;344:873–880.  
23- Higgins SL, Hummel JD, Niazi IK, Giudici MC, Worley SJ, Saxon LA, Boehmer JP, Higginbotham MB, De Marco T, Foster E, Yong PG. CARDIAC RESYNCHRONIZATION THERAPY FOR THE TREATMENT OF HEART FAILURE IN PATIENTS WITH INTRAVENTRICULAR CONDUCTION DELAY AND MALIGNANT VENTRICULAR TACHYARRHYTHMIAS. J Am Coll Cardiol 2003;42:1454–1459.  
24- Young JB, Abraham WT, Smith AL, Leon AR, Lieberman R, Wilkoff B, Canby RC, Schroeder JS, Liem LB, Hall S, Wheelan K. COMBINED CARDIAC RESYNCHRONIZATION AND IMPLANTABLE CARDIOVERSION DEFIBRILLATION IN ADVANCED CHRONIC HEART FAILURE: THE MIRACLE ICD TRIAL. JAMA 2003;289:2685–2694.  
25- Al-Majed NS, McAlister FA, Bakal JA, Ezekowitz JA. META-ANALYSIS: CARDIAC RESYNCHRONIZATION THERAPY FOR PATIENTS WITH LESS SYMPTOMATIC HEART FAILURE. Ann Intern Med 2011;154:401–412.  
26Andrea M Russo, Raymond F. Stainback, et al. ACCF/HRS/AHA/ASE/HFSA/SCAI/SCCT/SCMR 2013. APPROPRIATE USE CRITERIA FOR IMPLANTABLE CARDIOVERTER- DEFIBRILLATORS AND CARDIAC RESYNCHRONIZATION THERAPY A REPORT OF THE AMERICAN COLLEGE OF CARDIOLOGY FOUNDATION APPROPRIATE USE CRITERIA TASK FORCE, HEART RHYTHM SOCIETY, AMERICAN HEART ASSOCIATION, AMERICAN SOCIETY OF  ECHOCARDIOGRAPHY, HEART FAILURE SOCIETY OF AMERICA, SOCIETY FOR CARDIOVASCULAR ANGIOGRAPHY AND INTERVENTIONS, SOCIETY OF CARDIOVASCULAR COMPUTED TOMOGRAPHY, AND SOCIETY FOR CARDIOVASCULAR MAGNETIC RESONANCE ENDORSED BY THE AMERICAN GERIATRICS SOCIETY. Journal of the American College of Cardiology Vol. 61, No. 12, 2013 Published by Elsevier Inc. <u>(http://dx.doi.org/10.1016/j.jacc.2012.12.017).</u>  
27- Bristow MR, Saxon LA, Boehmer J, Krueger S, Kass DA, De Marco T, Carson P, DiCarlo L, DeMets D, White BG, DeVries DW, Feldman AM.Bristow MR, Saxon LA, Boehmer J, Krueger S, Kass DA, De Marco T, Carson P, DiCarlo L, DeMets D, White BG, DeVries DW, Feldman AM. CARDIAC-RESYNCHRONIZATION THERAPY WITH OR WITHOUT AN IMPLANTABLE DEFIBRILLATOR IN ADVANCED CHRONIC HEART FAILURE. N Engl J Med 2004;350:2140–2150.  
28- Connolly SJ1, Hallstrom AP, Cappato R, Schron EB, Kuck KH, Zipes DP, Greene HL, Boczor S, Domanski M, Follmann D, Gent M, Roberts RS. META-ANALYSIS OF THE IMPLANTABLE CARDIOVERTER DEFIBRILLATOR SECONDARY PREVENTION TRIALS. European Heart Journal (2000) 21, 2071–2078.doi.10.1053/euhj.2000.2476.  
29- Lam SK, Owen A. COMBINED RESYNCHRONISATION AND IMPLANTABLE THERAPY IN LEFT VENTRICULAR DYSFUNCTION: BAYESIAN NETWORK META-ANALYSIS OF RANDOMIZED CONTROLLED TRIALS. BMJ 2007;335:925.

---

