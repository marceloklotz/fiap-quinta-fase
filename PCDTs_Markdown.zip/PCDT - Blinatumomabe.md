<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: Geral -->
<!-- Start of picture text -->
aE:<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
<mark>SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE</mark>

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: PORTARIA CONJUNTA SAES/SECTICS Nº 33, DE 20 DE DEZEMBRO DE 2023. -->
Aprova o Protocolo de Uso do Blinatumomabe para Leucemia Linfoblástica Aguda (LLA) B Derivada Pediátrica em Primeira Recidiva Medular de Alto Risco.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o <mark>SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE,</mark> no uso das atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos de uso de tecnologias em saúde são resultado de consenso técnico-científico e são formulados conforme rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 803/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 806 – Março de 2023 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo de Uso – Blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito da leucemia linfoblástica aguda (LLA) B derivada pediátrica e do uso do blinatumomabe em primeira recidiva medular de alto risco da doença, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao blinatumomabe.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **1. INTRODUÇÃO** -->
A leucemia linfoblástica aguda (LLA) é uma neoplasia maligna comum na infância, classificada em 20 subtipos que variam de acordo com a idade de aparecimento e com os distintos perfis de expressão gênica<sup>1,2</sup> .  
De acordo com o Instituto Nacional do Câncer (INCA), são esperados 10.810 novos casos de leucemia no Brasil na população infantil, adolescente e adulta, para cada ano do triênio 2020-2022, sendo 5.920, em homens e 4.890, em mulheres<sup>3</sup> . Esses valores correspondem a um risco estimado de 5,55 casos novos para cada 100 mil homens e 4,56 casos novos para cada 100 mil mulheres<sup>3,4</sup> . Na população pediátrica, a LLA se desenvolve mais frequentemente em meninos do que em meninas (relação homem:mulher 55% a 45%)<sup>5</sup> .  A LLA é responsável por 25% dos cânceres infantis<sup>1</sup> e representa cerca de 75%-80% das leucemias agudas em crianças<sup>6</sup> .  
A leucemia linfoblástica aguda B derivada (LLA-B) é o tipo mais comum de LLA (85%), caracterizada pela proliferação clonal anômala de células precursoras linfoides B e pela predominância em pacientes pediátricos<sup>7–9</sup> . O **Quadro 1** apresenta a classificação da LLA-B.  
**Quadro 1** - Classificação da leucemia linfoblástica aguda B derivada.  
**Linfoma/leucemia linfoblástica de células B, sem outra especificação Linfoma/leucemia linfoblástica de células B, com anormalidades genéticas recorrentes** - Linfoma/leucemia linfoblástica de células B com hipodiploidia - Linfoma/leucemia linfoblástica de células B com hiperdiploidia - Linfoma/leucemia linfoblástica de células B com t(9;22)(q34;q11.2)[BCR-ABL1] - Linfoma/leucemia linfoblástica de células B com t(v11q23)[rearranjo MLL] - Linfoma/leucemia linfoblástica de células B com t(12;21)(p13;q22)[ETV6-RUNX1] - Linfoma/leucemia linfoblástica de células B com t(1;19)(q23;p13.3)[TCF3-PBX1] - Linfoma/leucemia linfoblástica de células B com t(5;14)(q31;q32)[IL3-IGH] - Linfoma/leucemia linfoblástica de células B com amplificação intracromossomial do cromossomo 21 (iAMP21) b - Linfoma/leucemia linfoblástica de células B com translocações envolvendo tirosina quinase ou receptores de citocinas (‘BCR-ABL1) b  
As alterações e translocações cromossômicas envolvidas fornecem informações sobre a patogênese da LLA-B. As translocações comuns em crianças com a doença incluem t(12;21) [ETV6-RUNX1], presente em 25% da população; t(1;19) [TCF3-PBX1], presente em 5% dos casos; t(9;11) [BCR- ABL1], presente em 3% dos casos; e translocações envolvendo o gene KMT2A ( _MLL gene - leucemia mieloide/linfoide ou de linhagem mista),_ com vários genes parceiros de fusão, presente em 5% dos casos<sup>1</sup> . A LLA-B tipo cromossomo Philadelfia positivo é responsável por 15% a 30% dos casos de LLA-B. Em crianças com idade avançada e adolescentes, a presença do cromossomo Philadelfia está associada a altas taxas de falha do tratamento convencional e recaídas<sup>10</sup> . Vários fatores genéticos, mais proeminentemente a síndrome de Down, estão associados a um risco aumentado de LLA, mas a maioria dos pacientes não têm fatores hereditários conhecidos<sup>11,12</sup> .  
Na LLA B derivada, além das anormalidades genéticas, outros fatores prognósticos, como idade, número total de leucócitos no sangue periférico e resposta à quimioterapia, são utilizados para estimar o risco da doença, o que possibilita a classificação em estágios de risco, de baixo a muito alto. O baixo risco está associado à idade menor do que 10 anos, contagem de células brancas menor do que 50.000/µL, presença de alterações citogenéticas favoráveis, como trissomia dos cromossomos 4 e 10 ou presença de ETV6-RUNX1 ou hiperploidia, e resposta rápida ao tratamento. No outro extremo está classificada como de alto risco a LLA B derivada em que se identifica falha ao tratamento inicial, presença de rearranjo MLL, hipodiploidia extrema (menos de 44 cromossomos), cromossomo Philadelfia positivo (com rearranjo BCR-ABL-1), amplificação intracromossômica do cromossomo 21 e idade superior a 13 anos. Nesse último caso a conduta terapêutica pode incluir tratamento medicamentoso agressivo seguido por transplante de células hematopoiéticas<sup>13</sup> . Crianças menores de 1 ano são um subgrupo especial de pacientes com piores desfechos<sup>14</sup> .  
A resposta e o tempo de resposta ao tratamento são fatores prognósticos importantes. A remissão completa, desejável após o tratamento, é definida como a presença de menos do que 5% de blastos na medula óssea e sinal de recuperação hematopoiética. Há casos em que a remissão clínica ocorre, mas uma pequena quantidade de blastos disfuncionais permanece na medula óssea. A presença dessa doença residual mínima (DRM) pode ser detectada por citometria de fluxo e reação em cadeia da polimerase (PCR) em vários momentos durante o tratamento. A sobrevida livre de recidivas em longo prazo está diretamente relacionada à presença e quantificação da DRM em estágios mais precoces ou tardios do tratamento. A detecção de menos do que 0,01% de blastos residuais durante o tratamento está relacionada, como fator preditivo isolado, a maior risco de recidiva precoce e menores sobrevida livre de doença e sobrevida global. A quantificação da DRM é utilizada para a estratificação dos tratamentos pós-remissão utilizados em crianças<sup>13</sup> .  
Entre os pacientes pediátricos, mais de 95% atingem remissão completa com o primeiro tratamento e 75% a 85% permanecem livre de doença por cinco anos após o diagnóstico. Em torno de 15% a 20% sofrem recidiva. O prognóstico para pacientes que sofreram recidiva depende do tempo entre o diagnóstico e a recidiva, do local da recidiva e de características citogenéticas e imunofenotípicas<sup>14</sup> . De acordo com essas características as recidivas são classificadas em risco padrão ou alto risco. O **Quadro 2** apresenta os critérios considerados na classificação de risco da recidiva.  
**Quadro 2 -** Definição do tempo até recidiva conforme o grupo _Berlin-Frankfurt-Munster Relapse Study Group e o International study for the treatment of childhood relapsed ALL – IntReALL_ .  
|**Tempo**|**Depois do diagnóstico primário**|**Depois de completar a terapia primária**|
|---|---|---|
|Muito precoce|< 18 meses|-|
|Precoce|> 18 meses|< 6 meses|
|Tardio|-|> 6 meses|  
Fonte: Adaptado de Locatelli et al., (2012)<sup>15</sup> e Blincyto, 2022<sup>16</sup> .  
O **Quadro 3** apresenta a classificação de risco da recidiva, contemplando tempo, local e imunofenótipo.  
**Quadro 3** - Classificação de risco de recidiva segundo o grupo estudo _Berlin-Frankfurt-Münster_ e o _International study for the treatment of childhood relapsed ALL – IntReALL._  
||**LOCAL DE RECIDIVA**||**TEMPO AT**|**É RECIDIVA**||
|---|---|---|---|---|---|
|**Parâmetros**|**Medula óssea**|**Extramedular**|**Muito**<br>**precoce**|**Precoce**|**Tardio**|
|MOI|✓<br>≥ 25% blastos|-|AR|AR|RP|
|EMI|-|✓||||
|EMI<br>e<br>MOI<br>combinados|✓<br>≥ 5% < 25% de blastos|✓|AR|RP|RP|  
Legenda: MOI – Medula óssea isolada; EMI – Extramedular isolada; AR – alto risco; RP – risco padrão. Fonte: Parker et al., (2010)<sup>17</sup> e Locatelli et al., (2021)<sup>14</sup> .  
Em crianças com primeira recidiva medular muito precoce e tardia as sobrevidas globais são de 20% e 40%-50%, respectivamente. A recidiva após o tratamento inicial é a segunda maior causa de mortalidade relacionada ao câncer em crianças. Para pacientes com primeira recidiva de alto risco, as taxas de sobrevida são menores que as observadas para pacientes com risco padrão. Crianças que apresentam recidiva ao tratamento inicial são candidatas ao transplante de células hematopoiéticas após atingirem uma segunda remissão completa<sup>13,14</sup> .  
Pacientes em primeira recidiva requerem quimioterapia agressiva com uma fase inicial de indução, seguida por três blocos de quimioterapia de consolidação. Pacientes em recidiva de alto risco não respondem bem ao tratamento com quimioterápicos. Cerca de 20% das crianças em primeira recidiva morrem devido à resistência ao tratamento ou devido aos eventos adversos agudos ou em longo prazo da quimioterapia<sup>13,14</sup> . Para pacientes em primeira recidiva, além da quimioterapia, há diferentes opções de tratamento com imunoterápicos, entre eles, o blinatumomabe.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da LLA-B derivada, com cromossomo Philadélfia negativo, em primeira recidiva de alto risco, em crianças e adolescentes. A elaboração deste Protocolo de Uso teve como base os resultados advindos da busca bibliográfica realizada na plataforma PubMed/Medline e do Relatório de Recomendação nº 725, de maio de 2022. A metodologia de busca e avaliação das evidências está detalhada no **Apêndice 2** . Além disso, o histórico de alterações deste Protocolo encontra-se descrito no **Apêndice 3** .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C91.0 - Leucemia linfoblástica aguda  
- C83.5 - Linfoma linfoblástico  
**Nota:** A LLA e o linfoma linfoblástico (LLb) são entidades nosológicas equivalentes, diferenciando-se somente pelo local primário da doença e sua forma de apresentação.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **3. DIAGNÓSTICO** -->
A avaliação diagnóstica para pacientes em primeira recidiva compreende:  
- Imunofenotipagem das células blásticas do sangue periférico, medula óssea ou líquor (o perfil antigênico típico é CD10+,  
- CD19+ e TdT+, com expressão mais frequente dos marcadores mieloides CD13 e CD33)<sup>18</sup> .  
- Biópsia de medula óssea com imuno-histoquímica, indicada em caso de aspirado medular "seco" e em caso de  
- quantidade de blastos insuficientes no sangue periférico para a realização da imunofenotipagem;  
- Identificação do cromossomo Philadelfia no sangue periférico ou na medula óssea por exame de citogenética  
- convencional ou FISH<sup>19,20</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que preencherem os seguintes critérios:  
- Idade até 18 anos de idade (19 anos incompletos);  
- Diagnóstico inicial e de primeira recidiva por imunofenotipagem com confirmação da presença da linhagem linfoide e  
- exclusão da linhagem mieloide. A origem da linhagem linfoide deve ser diferenciada entre as linhagens B (B derivada, CD19+);  
- Primeira recidiva do tratamento para LLA-B classificada como medular de alto risco ( **Quadros 2 e 3** ), após tratamento  
- de primeira linha com quimioterapia de indução, seguida por dois ciclos de quimioterapia de consolidação;  
- Cromossomo Philadelfia negativo.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que preencherem os critérios a seguir:  
- Pacientes com intolerância, hipersensibilidade ou contraindicação conhecida ao fármaco ou aos componentes da fórmula (mono-hidrato de ácido cítrico, di-hidrato de trealose, cloridrato de lisina, polissorbato 80 e hidróxido de sódio) do medicamento preconizado neste Protocolo.  
**Nota:** O tratamento de crianças e adolescentes diagnosticados com LLA cromossomo Philadelfia positivo deve ser realizado conforme as respectivas Diretrizes Diagnósticas e Terapêuticas.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **6. CASOS ESPECIAIS** -->
São considerados casos especiais pacientes nas seguintes situações:  
- Gravidez: não foram estabelecidas a segurança e a eficácia do blinatumomabe em mulheres grávidas. O blinatumomabe se insere na categoria B para gravidez e, portanto, não há estudos adequados em mulheres e nem todos os desfechos relacionados à segurança foram avaliados em animais durante a gravidez. Assim, é necessário avaliar o comprometimento de adolescentes em idade reprodutiva em usar método anticoncepcional com eficácia confirmada durante a terapia antineoplásica.  
- Amamentação: ainda não se sabe se o blinatumomabe pode ser excretado pelo leite materno durante a lactação. Lactantes em uso de blinatumomabe devem suspender a amamentação durante tratamento e por pelo menos 48 horas após o uso do medicamento.  
- Imunização: não foi estudada a segurança da imunização com vacinas contendo vírus vivos durante ou após o uso do blinatumomabe. Não é recomendada a imunização com esse tipo de vacina pelo menos duas semanas antes do início do tratamento, durante o tratamento e até o retorno dos linfócitos B aos valores normais após o último ciclo com blinatumomabe.  
- Histórico ou doença do sistema nervoso central (SNC): há experiência limitada em pacientes com LLA ativa no SNC ou histórico de eventos neurológicos. Os pacientes com histórico ou presença de doença do SNC clinicamente relevante foram excluídos dos estudos clínicos.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.1 Quimioterapia** -->
O tratamento da LLA-B é definido pelo protocolo terapêutico adotado no hospital em que o paciente é acompanhado.  
Os esquemas terapêuticos e de resgate para pacientes com primeira recidiva medular de alto risco envolvem esquemas quimioterápicos que antecedem o tratamento com blinatumomabe. Para esses pacientes, deve ser administrada quimioterapia de indução e dois ciclos de consolidação. O blinatumomabe é utilizado no 3º ciclo de consolidação. A avaliação da doença residual mínima (DRM) é necessária para acompanhar a resposta em cada ciclo e para a evolução para as etapas seguintes do tratamento.  
● 4ª semana - _no final do ciclo de indução_ deve ser realizado o acompanhamento da DRM, considerando como nível mínimo de doença residual menos de 10<sup>-3</sup> blastos na medula;  
● 7ª e 10ª semanas - _no final dos 1º e 2º ciclos de consolidação_ , deve ser realizado o acompanhamento da DRM, considerando como nível mínimo de doença residual menos de 10<sup>-3</sup> blastos na medula.  
● 14ª semana - _no final do 3º ciclo de consolidação_ com blinatumomabe deverá ser realizado um novo acompanhamento, que consiste na verificação de DRM, definida como menos de 10<sup>-4</sup> células blásticas ( **Figura 1** ).  
**Figura 1 -** Esquema de tratamento para LLA-B derivada, primeira recidiva medular de alto risco.  
<!-- Start of picture text -->
a en a<br>Paciente com 12<br>recidiva medular<br>de alto risco<br>— Avaliar oon |r<br>[|__semana [aeeeee[2] 3] 4] s[e6[7] 89 fo] 3] 12] 13] 14]<br><!-- End of picture text -->  
Legenda: DRM: Doença residual mínima. Fonte: Adaptado de Locatelli et al. (2021)<sup>14</sup> .  
Os pacientes incluídos deverão ser registrados e acompanhados regularmente por um hospital especializado em oncologia e ter assinado o Termo de Esclarecimento e Responsabilidade **.**

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2 Tratamento com blinatumomabe** -->
O blinatumomabe é uma molécula ativadora de células T com dois sítios específicos (BiTE<sup>®</sup> ) que promove a ligação simultânea ao CD3 expresso na superfície das células T e ao CD19 expresso na superfície das células B<sup>16,21,22</sup> . A atividade antitumoral da imunoterapia com blinatumomabe não é dependente das células T contendo um TCR específico ou de antígenos peptídicos apresentados pelas células cancerosas, mas é de natureza policlonal e independente das moléculas do antígeno leucocitário humano (HLA) das células-alvo<sup>22</sup> . O blinatumomabe atua como mediador para a formação de uma sinapse citolítica entre a célula T e a célula tumoral, liberando enzimas proteolíticas para matar tanto as células-alvo em proliferação, quanto as que estão em repouso. O blinatumomabe é associado à regulação positiva transitória das moléculas de adesão celular, produção  
de proteínas citolíticas, liberação de citocinas inflamatórias e proliferação de células T, que resulta na eliminação de células CD19+<sup>22</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.1 Medicamento** -->
- Blinatumomabe: pó liofilizado para solução injetável contendo 38,5 mcg e 10 mL de solução estabilizante intravenosa.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.2 Esquemas de administração** -->
Este Protocolo preconiza o uso de blinatumomabe como terceiro ciclo de consolidação, posterior a um ciclo de indução e dois ciclos de consolidação com quimioterapia.  
A dose a ser administrada varia e deve ser calculada de acordo com as características de cada paciente, conforme **Quadro 4** . Pacientes com peso igual ou superior a 45 kg devem receber uma dose fixa. Já pacientes com peso menor que 45 kg devem receber dose calculada segundo sua área de superfície corporal (ASC), até o limite definido. O medicamento deve ser administrado sob infusão intravenosa contínua, à taxa de fluxo constante e em bomba de infusão contínua.  
**Quadro 4** - Dose preconizada de blinatumomabe para tratamento de LLA-B derivada em 1ª recidiva medular de alto risco.  
|**CICLO**|**DIA**|**PACIENTE COM PESO MENOR**<br>**QUE 45 kg**|**PACIENTE COM PESO MAIOR**<br>**OU IGUAL A 45 kg**|
|---|---|---|---|
|3º<br>_ciclo_<br>_de_|01 - 28|15 mcg/m²/dia_(não exceder 28_<br>_mcg/dia)_|28 mcg/dia|
|_consolidação_||||
||29 - 42|Intervalo de 14 dias livres de tratamento||  
Fonte: Locatelli _et al_ . (2021)<sup>14</sup> .  
A administração pode ser realizada, preferencialmente, em ambiente hospitalar – pelo menos nos primeiros dias de tratamento, e a solução deve ser infundida em bomba de infusão sob fluxo constante. A bomba de infusão deve ser programável, bloqueável, não elastomérica e possuir alarme.  
O blinatumomabe deve ser administrado por cateter com lúmen exclusivo. As bolsas de infusão devem ser infundidas durante tempos de infusão definidos no **Quadro 5** . Ao final da infusão, qualquer solução de blinatumomabe não utilizada no equipo ou bolsa de infusão deve ser descartada.  
**Quadro 5** - Taxas de infusão a serem programadas de acordo com o tempo de infusão  
|**TEMPO DE INFUSÃO**|**TAXA DE INFUSÃO**|
|---|---|
|10 mL/hora|24 horas|
|5 mL/hora|48 horas|
|3,3 mL/hora|72 horas|
|2,5 mL/hora|96 horas|  
**Fonte:** Blincyto, 2022<sup>22</sup> .  
O registro do medicamento recomenda a hospitalização do paciente no mínimo nos primeiros 9 dias do primeiro ciclo com blinatumomabe (3º ciclo de consolidação)<sup>16</sup> . Além disso, recomenda que o paciente seja acompanhado por um profissional  
de saúde durante todo o período de administração do medicamento. A necessidade de manutenção da internação deve ser avaliada pela equipe profissional responsável pelo paciente.  
A quimioterapia intratecal profilática é preconizada antes e durante a terapia com blinatumomabe, a fim de prevenir a recidiva de LLA no sistema nervoso central<sup>16,22,23</sup> .  
Preconiza-se a utilização de dexametasona na dose de 10 mg/m² (não excedendo 20 mg), via oral ou intravenosa, 6 a 12 horas antes do início de blinatumomabe (dia 1), seguido de 5 mg/m<sup>2</sup> de dexametasona, via oral ou intravenosa, em até 30 minutos do início de blinatumomabe (dia 1).

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.3 Preparo do medicamento** -->
Todo o preparo do blinatumomabe, da reconstituição à administração, deve estar de acordo com as boas práticas vigentes,  
com especial atenção à assepsia, já que o medicamento não contém antimicrobianos.  
Além do frasco que contém 38,5 mcg de blinatumomabe na forma de pó liofilizado para solução injetável, o medicamento  
contém um frasco com 10 mL de solução estabilizante intravenosa (IV). Esta solução não deve ser utilizada para reconstituir o blinatumomabe e sua função é garantir a estabilidade do medicamento na bolsa de infusão IV<sup>16</sup> .  
_Instruções para reconstituição:_  
- 1) Adicionar 3 mL de água estéril para injetáveis sem conservantes ao longo das paredes do frasco. Não adicionar  
- diretamente sobre o pó liofilizado.  
- 2) Girar suavemente o conteúdo do frasco. Não agitar. Evitar formação de espuma em excesso.  
- 3) A solução deve estar totalmente reconstituída, límpida a discretamente opalescente e de incolor a discretamente  
amarela. A solução não deve ser utilizada caso se apresente turva ou com precipitado.  
- 4) O volume final após reconstituição será de 3,1 mL. A concentração final será de 12,5 mcg/mL. É importante utilizar  
- esses valores para cálculo de dose e evitar subdose ou sobredose.  
_Preparo da bolsa de infusão:_  
- 1) Adicionar assepticamente 270 mL de cloreto de sódio 0,9% à bolsa de infusão IV vazia. Caso já esteja preenchida, o  
- volume inicial deve ser ajustado para 270 mL, adicionando o que falta ou removendo o excesso de cloreto de sódio 0,9%.  
- 2) Transferir assepticamente 5,5 mL da solução estabilizante IV à bolsa de infusão IV (com cloreto de sódio 0,9%).  
Misturar delicadamente a bolsa para evitar formação de espuma.  
- 3) Transferir assepticamente o blinatumomabe reconstituído para a bolsa de infusão IV que contém a mistura cloreto de  
- sódio 0,9% + solução estabilizante IV. Misturar delicadamente a bolsa para evitar formação de espuma.  
- 4) Acoplar assepticamente o equipo de infusão compatível à bolsa (de infusão IV preenchida) com o filtro de linha estéril  
- apirogênico e de baixa ligação a proteínas de 0,2 micra.  
- 5) Remover o ar da bolsa. Não preencher o equipo com nenhuma outra solução, a não ser a solução contida dentro da  
- bolsa.  
**Nota:** Para o preparo da bolsa de infusão de pacientes com peso inferior e superior a 45kg, seguir as orientações dos **Quadros 6 e 7** .  
**Quadro 6 -** Volumes para adicionar à bolsa IV para pacientes com peso maior ou igual a 45 kg.  
|**Cloreto de sódi**|**o 0,9% (volume inicial)**|||270 mL|
|---|---|---|---|---|
|**Solução Estabi**|**lizante IV**|||5,5 mL|
|**Dose**|**Duração da infusão**|**Taxa de infusão**|**Blinatum**|**omabe reconstituído**|
|28 mcg/dia|24 horas<br>48 horas|10 mL/hora<br>5 mL/hora|2,6 mL<sup>a</sup><br>5,2 mL<sup>b</sup>||  
|72 horas|3,3 mL/hora|8 mL<sup>c</sup>|
|---|---|---|
|96 horas|2,5 mL/hora|10,7 mL<sup>d</sup>|  
ASC: área da superfície corporal. Legenda: a. Um frasco de blinatumomabe é necessário para a preparação de todas essas doses. b. Dois frascos de blinatumomabe são necessários para a preparação da dose de 28 mcg/dia infundida durante 48 horas a uma taxa de 5 mL/hora. c. Três frascos de blinatumomabe são necessários para a preparação da dose de 28 mcg/dia infundida durante 72 horas a uma taxa de 3,3 mL/hora. d. Quatro frascos de blinatumomabe são necessários para a preparação da dose de 28 mcg/dia infundida durante 96 horas a uma dose de 2,5 mL/hora. Fonte: Adaptado de Blincyto, 2022<sup>22</sup> .  
**Quadro 7** - Volumes para adicionar à bolsa IV para pacientes com peso inferior a 45 kg.  
|**Cloreto de sódio 0,**|**9% (volume inicial)**|||270 mL|
|---|---|---|---|---|
|**Solução Estabilizan**|**te IV**|||5,5 mL|
|||||**Blinatumomabe**|
|**Dose**|**Duração da infusão**|**Taxa de infusão**|**ASC (m²)**|**reconstituído**|
||||1,5 – 1,59|2,1 mL<sup>a</sup>|
||||1,4 – 1,49|2 mL<sup>a</sup>|
||||1,3 – 1,39|1,8 mL<sup>a</sup>|
||||1,2 – 1,29|1,7 mL<sup>a</sup>|
||||1,1 – 1,19|1,6 mL<sup>a</sup>|
||24 horas|10 mL/hora|1 – 1,09|1,4 mL<sup>a</sup>|
||||0,9 – 0,99|1,3 mL<sup>a</sup>|
||||0,8 – 0,89|1,1 mL<sup>a</sup>|
||||0,7 – 0,79|1 mL<sup>a</sup>|
||||0,6 – 0,69|0,86 mL<sup>a</sup>|
||||0,5 – 0,59|0,72 mL<sup>a</sup>|
||||0,4 – 0,49|0,59 mL<sup>a</sup>|
||||1,5 – 1,59|4,2 mL<sup>b</sup>|
|**15 mcg/m²/dia**|||1,4 – 1,49|3,9 mL<sup>b</sup>|
||||1,3 – 1,39|3,7 mL<sup>b</sup>|
||||1,2 – 1,29|3,4 mL<sup>b</sup>|
||||1,1 – 1,19|3,1 mL<sup>b</sup>|
||48 horas|5 mL/hora|1 – 1,09|2.8 mL<sup>a</sup>|
||||0,9 – 0,99|2,6 mL<sup>a</sup>|
||||0,8 – 0,89|2,3 mL<sup>a</sup>|
||||0,7 – 0,79|2 mL<sup>a</sup>|
||||0,6 – 0,69|1,7 mL<sup>a</sup>|
||||0,5 – 0,59|1,4 mL<sup>a</sup>|
||||0,4 – 0,49|1,2 mL<sup>a</sup>|
||||1,5 – 1,59|6,3 mL<sup>c</sup>|
||72 horas|3,3 mL/hora|1,4 – 1,49|5,9 mL<sup>c</sup>|
||||1,3 – 1,39|5,5 mL<sup>d</sup>|  
|||1,2 – 1,29|5,1 mL<sup>d</sup>|
|---|---|---|---|
|||1,1 – 1,19|4,7 mL<sup>d</sup>|
|||1 – 1,09|4,2 mL<sup>d</sup>|
|||0,9 – 0,99|3,8 mL<sup>d</sup>|
|||0,8 – 0,89|3,4 mL<sup>d</sup>|
|||0,7 – 0,79|3 mL<sup>d</sup>|
|||0,6 – 0,69|2,6 mL<sup>a</sup>|
|||0,5 – 0,59|2,2 mL<sup>a</sup>|
|||0,4 – 0,49|1,8 mL<sup>a</sup>|
|||1,5 – 1,59|8,4 mL<sup>e</sup>|
|||1,4 – 1,49|7,9 mL<sup>e</sup>|
|||1,3 – 1,39|7,3 mL<sup>e</sup>|
|||1,2 – 1,29|6,8 mL<sup>e</sup>|
|||1,1 – 1,19|6,2 mL<sup>e</sup>|
|96 horas|25 mL/hora|1 – 1,09|5,7 mL<sup>e</sup>|
||,|0,9 – 0,99|5,1 mL<sup>f</sup>|
|||0,8 – 0,89|4,6 mL<sup>f</sup>|
|||0,7 – 0,79|4 mL<sup>f</sup>|
|||0,6 – 0,69|3,4 mL<sup>f</sup>|
|||0,5 – 0,59|2,9 mL<sup>f</sup>|
|||0,4 – 0,49|2,3 mL<sup>a</sup>|  
ASC: área da superfície corporal. Legenda: a. Um frasco de blinatumomabe é necessário para a preparação de todas essas doses. b. Dois frascos de blinatumomabe são necessários para a preparação da dose de 15 mcg/m<sup>2</sup> /dia infundida durante 48 horas a uma taxa de 5 mL/hora para pacientes de ASC superior a 1,09 m<sup>2</sup> . c. Três frascos de blinatumomabe são necessários para a preparação da dose de 15 mcg/m<sup>2</sup> /dia infundida durante 72 horas a uma taxa de 3,3 mL/hora para pacientes com ASC superior a 1,39 m<sup>2</sup> . d. Dois frascos de blinatumomabe são necessários para a preparação da dose de 15 mcg/m<sup>2</sup> /dia infundida durante 72 horas a uma taxa de 3,3 mL/hora para pacientes com ASC de 0,70 m<sup>2</sup> a 1,39 m<sup>2</sup> . e. Três frascos de blinatumomabe são necessários para a preparação da dose de 15 mcg/m<sup>2</sup> /dia infundida durante 96 horas a uma taxa de 2,5 mL/hora para pacientes com ASC superior a 0,99 m<sup>2</sup> . f. Dois frascos de blinatumomabe são necessários para a preparação da dose de 15 mcg/m<sup>2</sup> /dia infundida durante 96 horas a uma taxa de 2,5 mL/hora para pacientes com ASC de 0,50 m<sup>2</sup> a 0,99 m<sup>2</sup> . Fonte: Adaptado de Blincyto, 2022<sup>22</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.4 Armazenamento e estabilidade** -->
As condições de armazenamento e o tempo de estabilidade do blinatumomabe estão descritos no **Quadro 8**<sup>16</sup> .  
**Quadro 8 -** Condições de armazenamento e estabilidade.  
|**Solução**|**Temperatura**|**Estabilidade**<sup>1</sup>|
|---|---|---|
|Conteúdo do frasco lacrado|Entre 2°C e 8°C|60 meses|
||Entre 2°C e 8°C|24 horas|
|Conteúdo do frasco reconstituído|||
||30°C|04 horas|
||Entre 2°C e 8°C|10 dias|  
|**Solução**|**Temperatura**||**Estabilidade**<sup>1</sup>|
|---|---|---|---|
|Conteúdo da bolsa IV (considerar o tempo de<br>infusão)|30°C|96 horas||  
Nota: Independentemente da temperatura de armazenamento, sempre proteger da luz os frascos e bolsas. Legenda:<sup>1</sup> Após data de fabricação.  
Fonte: Blincyto, 2022<sup>22</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.5 Eventos adversos** -->
A equipe assistente deve estar ciente dos eventos adversos, principalmente os de maior gravidade ( **Tabela 1** ) e mais frequentes ( **Tabela 2** ), de modo a oferecer o cuidado clínico pertinente, inclusive com potencial suspensão do tratamento ( **Apêndice 1** ).  
**Tabela 1** - Ocorrência dos eventos adversos graves.  
|**Eventos adversos graves**|**Frequência de ocorrência**|
|---|---|
|Infecções|24,8%|
|Eventos neurológicos|13,8%|
|Neutropenia/neutropenia febril|10,1%|
|Síndrome de liberação de citocinas|3,3%|
|Síndrome de lise tumoral|0,7%|  
**Tabela 2** - Ocorrência dos eventos adversos frequentes.  
|**Eventos adversos frequentes**|**Frequência de ocorrência**|
|---|---|
|Pirexia|69,2%|
|Reações relacionadas à infusão|43,4%|
|Infecções – agente patogênico não especificado|42,1%|
|Dor de cabeça|32,9%|
|Anemia|22,8%|
|Trombocitopenia|20,9%|
|Neutropenia febril|20,2%|
|Edema|20,0%|
|Neutropenia|19,7%|
|Erupção cutânea|16,7%|  
|**Eventos adversos frequentes**|**Frequência de ocorrência**|
|---|---|
|Aumento de enzimas hepáticas|16,1%|
|Doenças infecciosas causadas por bactérias|15,4%|
|Tremor|15,2%|
|Tosse|15,1%|
|Leucopenia|13,4%|
|Dor nas costas|13,3%|
|Calafrios|13,0%|
|Hipotensão|12,8%|
|Viroses infeciosas|12,7%|
|Imunoglobulinas diminuídas|12,5%|
|Síndrome de liberação de citocinas|11,6%|
|Taquicardia|11,3%|
|Insônia|10,7%|
|Doenças infecciosas causadas por fungos|10,6%|
|Dor nas extremidades|10,2%|

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.6 Critérios de interrupção** -->
O paciente deve ser avaliado pela equipe médica assistente e conforme o protocolo de tratamento do hospital, para verificar a necessidade de interromper o tratamento. Os principais motivos de interrupção temporária ou suspensão do tratamento envolvem eventos adversos neurológicos. A síndrome de liberação de citocinas, quando identificada, pode requerer a interrupção temporária ou suspensão do tratamento. O mesmo se aplica à ocorrência de reações à infusão, síndrome de lise tumoral e pancreatite<sup>16,21</sup> **_._** O **Apêndice 1** apresenta as diretrizes para o monitoramento e tratamento destes eventos adversos.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.7 Benefícios esperados** -->
O tratamento medicamentoso busca os seguintes benefícios:  
- **Aumento da sobrevida global (SG)** - tempo decorrido entre o início do tratamento até óbito por qualquer causa,  
- independente da condição clínica na última avaliação do paciente, transplantado ou não, quer tenha recidivado ou não<sup>14,24,25</sup> ;  
- **Aumento da sobrevida livre de doença (SLD)** - tempo decorrido do início do tratamento até a ocorrência de blastos leucêmicos detectados por citologia no sangue periférico, medula óssea ou em sítio extramedular<sup>14,24,25</sup> ;  
- **Diminuição da doença residual mínima em todas as fases da terapia**<sup>14,24,26</sup> - a doença residual mínima (DRM) é relacionada à presença de células leucêmicas sobreviventes à quimioterapia ou radioterapia, que resulta na recidiva da doença e ocorre quando são encontradas células leucêmicas (blastos) na medula óssea e, mais raramente, no sangue periférico<sup>26</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.8 Monitoramento da doença mínima residual (DRM)** -->
O principal objetivo clínico do monitoramento da DRM é determinar a resposta ao tratamento e o risco de recidiva da doença. Sua mensuração pode ser realizada por meio da citometria de fluxo (imunofenotipagem) e de reação em cadeia da polimerase (PCR)<sup>26</sup> . A detecção da DRM é determinante para se prever o desempenho dos tratamentos já empregados e para a definição de estratégias terapêuticas adicionais.  
A obtenção de um status de DRM negativa por citometria de fluxo multiparâmetro pode estar associada a uma melhora significativa da sobrevida. Além disso, foi demonstrado que a DRM é um preditor de recidiva da doença<sup>14,18,24</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.9 Avaliação da remissão** -->
A remissão completa ocorre quando a presença de blastos na medula for menor que 5% e a hematopoiese estiver em regeneração<sup>17</sup> . A doença residual mínima indetectável, que caracteriza a remissão, é definida por citometria de fluxo com sensibilidade de pelo menos 10<sup>-4</sup> após um ciclo do medicamento<sup>14,17,25</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.10 Detecção de falha terapêutica** -->
Considera-se falha terapêutica quando, após o 3º ciclo de consolidação com o uso de blinatumomabe, o paciente apresentar DRM igual ou maior a 10<sup>-4</sup> blastos<sup>14</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **7.2.11 Critérios de resposta** -->
- Ao final dos ciclos de indução e dos 1º e 2º ciclos de consolidação, é considerada resposta ao tratamento, quando o paciente apresenta DRM ≤10<sup>–3</sup> blastos<sup>14,24,25</sup> .  
- Ao final do 3º ciclo de consolidação, é considerada resposta ao tratamento com blinatumomabe, quando o paciente apresenta DRM ≤10<sup>–4</sup> blastos<sup>14,24–26</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **8. TRANSPLANTE DE CÉLULAS-TRONCO HEMATOPOÉTICAS ALOGÊNICO (TCTH-ALO)** -->
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
**Nota:** É preconizado que seja identificado e contatado um centro transplantador para realização do TCTH-ALO posterior ao tratamento com blinatumomabe.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **9. MONITORAMENTO** -->
Devem ser realizados exames antes e durante o tratamento com blinatumomabe, conforme **Quadro 9** .  
**Quadro 9 -** Monitoramento clínico dos pacientes com LLA-B em uso de blinatumomabe.  
|**Item**|**Avaliação inicial**|**Após cada ciclo**<sup>**a**</sup>|
|---|---|---|
|Citometria de fluxo, citogenética, biologia molecular para identificação do<br>tipo de mutação; cromossomo Philadelfia|X||
|Hemograma com contagem de plaquetas|X|X|
|Contagem de blastos|X|X|
|Exames sorológicos para hepatites B e C e para HIV|X||
|Dosagem sérica das enzimas alanina aminotransferase (ALT), aspartato|||
|aminotransferase (AST), gama-glutamil transferase (GGT), bilirrubina total|X||
|sanguínea, fosfatase alcalina e desidrogenase láctica (DHL)|||
|Citometria de fluxo (imunofenotipagem) ou PCR|X|X|
|Dosagem sérica de glicose, ureia e creatinina|X||
|Dosagem sérica dos íons sódio, potássio, fósforo, cálcio e magnésio|X||
|Dosagem sérica do ácido úrico|X||
|Estudo da coagulação sanguínea|X||
|Exame parasitológico de fezes|X||
|Análise sumária de urina|X||
|Dosagem sérica de gonadotrofina coriônica (beta-hCG), em mulheres após a<br>primeira menarca|X|X|
|História clínica recente|X||  
a conforme recomendado pelo estudo de fase 3 do medicamento25.  Nota: para a monitorização laboratorial devem ser realizados os exames previstos na conduta ou protocolos utilizados no hospital, incluindo as avaliações do mielograma, da imunofenotipagem, dos achados citogenéticos e moleculares, idealmente com determinação quantitativa DRM na medula óssea<sup>28</sup> .  
O êxito ao tratamento não depende somente do uso do medicamento, mas também de quão orientados e apoiados estão os responsáveis por estes pacientes durante os cuidados domiciliares. É necessário que a equipe multidisciplinar esteja preparada para dar suporte aos cuidadores.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
Casos de pacientes pediátricos com até 18 anos de idade (ou 19 anos incompletos) diagnosticados com LLA-B e em primeira recidiva devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, estadiar, tratar e acompanhar os pacientes.  
Além da familiaridade que tais hospitais guardam com o estadiamento, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
Pacientes diagnosticados com LLA-B e em primeira recidiva devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Diante dos eventos adversos relacionados ao uso do blinatumomabe, o acompanhamento e a internação hospitalar devem ocorrer para o devido cuidado, oferecendo suporte multiprofissional e de laboratórios necessários para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e a garantia do atendimento aos pacientes e muito facilita as ações de controle e avaliação. Entre tais ações incluem-se a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES), a autorização prévia dos procedimentos, o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos) e a verificação dos percentuais da frequência dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda e segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou do protocolo adotados no hospital, a regulação do acesso assistencial, a qualidade da autorização, a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses), a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod), a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais e o grau de satisfação dos doentes.  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a poliquimioterapia do linfoma folicular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama, que são adquiridos pelo Ministério da Saúde e fornecidos aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde. Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais as terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados pelo SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento.  
Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento de medicamento antineoplásico é do hospital, seja ele público ou privado, com ou sem fins lucrativos. Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos (Grupo 03, Subgrupo 04), cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, devendo todos os potenciais receptores estar inscritos no Sistema Nacional de Transplantes (SNT).  
Para a autorização do TCTH alogênico não aparentado, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores submetidos a TCTH originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **11. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **12. REFERÊNCIAS** -->
1. Bhojwani D, Yang JJ, Pui CH. Biology of Childhood Acute Lymphoblastic Leukemia. Pediatr Clin North Am [Internet]. 2015 Nov 4;62(1):47–60. Available from: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4250840/  
2. Inaba H, Mullighan CG. Pediatric acute lymphoblastic leukemia. Haematologica. 2020;105(11):2524–39.  
3. Instituto Nacional de Câncer José Alencar Gomes da Silva. Estimativa 2020 - Incidência de Câncer no Brasil [Internet]. 2019. 2019 [cited 2022 Sep 21]. p. 1–122. Available from: https://www.inca.gov.br/sites/ufu.sti.inca.local/files/media/document/estimativa-2020-incidencia-de-cancer-no-brasil.pdf  
4. Bray F, Ferlay J, Soerjomataram I, Siegel RL, Torre LA, Jemal A. Global cancer statistics 2018: GLOBOCAN estimates of incidence and mortality worldwide for 36 cancers in 185 countries. CA Cancer J Clin [Internet]. 2018 Nov 1 [cited 2022 Sep 21];68(6):394–424. Available from: https://onlinelibrary.wiley.com/doi/full/10.3322/caac.21492  
5. Hunger SP, Mullighan CG. Acute Lymphoblastic Leukemia in Children. N Engl J Med [Internet]. 2015;373(16):1541– 52. Available from: http://files/30/Hunger e Mullighan - 2015 - Acute Lymphoblastic Leukemia in Children.pdf  
6. Ching-Hon Pui, William E. Evans. Treatment of Acute Lymphoblastic Leukemia. https://doi.org/101056/NEJMra052603 [Internet]. 2006 Jan 12 [cited 2023 Jan 26];5(354):166–78. Available from: https://www.nejm.org/doi/10.1056/NEJMra052603  
7. Moorman A V. New and emerging prognostic and predictive genetic biomarkers in B-cell precursor acute lymphoblastic leukemia. Haematologica [Internet]. 2016 Mar 31 [cited 2022 Sep 22];101(4):407. Available from: /pmc/articles/PMC5004393/  
8. Zerbini MCN, Soares FA, Paes RP. World Health Organization Classification of tumors of hematopoietic and lymphoid tissues, 4th edition, 2008 – major changes from the 3rd edition, 200. Rev Assoc Med Bras [Internet]. 2008;8. Available from: http://files/101/Zerbini et al. - 2008 - World Health Organization Classification of tumors.pdf  
9. Irving JAE, Enshaei A, Parker CA, Sutton R, Kuiper RP, Erhorn A, et al. Integration of genetic and clinical risk factors improves prognostication in relapsed childhood B-cell precursor acute lymphoblastic leukemia. Blood [Internet]. 2016;128(7):911–22. Available from: http://files/38/Irving et al. - 2016 - Integration of genetic and clinical risk factors i.pdf  
10. Harvey RC, Tasian SK. Clinical diagnostics and treatment strategies for Philadelphia chromosome-like acute lymphoblastic leukemia. Blood Adv [Internet]. 2020;4(1):218–28. Available from: http://files/41/Harvey e Tasian - 2020 - Clinical diagnostics and treatment strategies for .pdf  
11. Buitenkamp TD, Izraeli S, Zimmermann M, Forestier E, Heerema NA, Van Den Heuvel-Eibrink MM, et al. Acute lymphoblastic leukemia in children with Down syndrome: a retrospective analysis from the Ponte di Legno study group. Blood [Internet]. 2014 Jan 2 [cited 2022 Sep 21];123(1):70–7. Available from: https://pubmed.ncbi.nlm.nih.gov/24222333/  
12. Queudeville M, Ebinger M. Blinatumomab in Pediatric Acute Lymphoblastic Leukemia—From Salvage to First Line Therapy (A Systematic Review). J Clin Med [Internet]. 2021 Nov 4;10(12):2544. Available from: https://www.mdpi.com/20770383/10/12/2544  
13. Horton TM SC. Risk group stratification and prognosis for acute lymphoblastic leukemia/lymphoblastic lymphoma in children and adolescents. uptodate [Internet]. 2022;[Internet]. Available from: https://www.uptodate.com/contents/risk-groupstratification-and-prognosis-for-acutelymphoblastic-leukemia-lymphoblastic-lymphoma-in-children-andadolescents?search=acute lymphoblastic%0Aleukemia risk&topicRef=6245&source=see_link  
14. Locatelli F, Zugmaier G, Rizzari C, Morris JD, Gruhn B, Klingebiel T, et al. Effect of Blinatumomab vs Chemotherapy on Event-Free Survival Among Children With High-risk First-Relapse B-Cell Acute Lymphoblastic Leukemia: a Randomized  
Clinical Trial. JAMA [Internet]. 2021;325(9):843‐854. Available from:  
https://www.cochranelibrary.com/central/doi/10.1002/central/CN-02248616/full  
15. Locatelli F, Schrappe M, Bernardo ME, Rutella S. How I treat relapsed childhood acute lymphoblastic leukemia. Blood [Internet]. 2012 Jan 19;120(14):2807–16. Available from: https://doi.org/10.1182/blood-2012-02-265884  
16. Amgen. Phase 3 Trial to Investigate the Efficacy, Safety, and Tolerability of Blinatumomab as Consolidation Therapy Versus Conventional Consolidation Chemotherapy in Pediatric Subjects With HR First Relapse B-precursor ALL [Internet]. clinicaltrials.gov; 2022 Nov. Available from: https://clinicaltrials.gov/ct2/show/NCT02393859  
17. Parker C, Waters R, Leighton C, Hancock J, Sutton R, Moorman A V., et al. Effect of mitoxantrone on outcome of children with first relapse of acute lymphoblastic leukaemia (ALL R3): an open-label randomised trial. Lancet [Internet]. 2010 Dec 12 [cited 2022 Sep 22];376(9757):2009. Available from: /pmc/articles/PMC3010035/  
18. Locatelli F, Zugmaier G, Mergen N, Bader P, Jeha S, Schlegel PG, et al. Blinatumomab in pediatric relapsed/refractory B-cell acute lymphoblastic  leukemia: RIALTO expanded access study final analysis. Blood Adv. 2022 Feb;6(3):1004–14.  
19. Jain S, Abraham A. BCR-ABL1–like B-Acute Lymphoblastic Leukemia/Lymphoma: A Comprehensive Review. Arch Pathol Lab Med [Internet]. 2020 Feb 1 [cited 2022 Sep 21];144(2):150–5. Available from: https://meridian.allenpress.com/aplm/article/144/2/150/433665/BCR-ABL1-like-B-Acute-Lymphoblastic-Leukemia  
20. Farias MG, Castro SM de. Diagnóstico laboratorial das leucemias linfóides agudas. J Bras Patol e Med Lab [Internet]. 2004 Apr [cited 2022 Sep 21];40(2):91–8. Available from: http://www.scielo.br/j/jbpml/a/hqbmPwpLN5tLzxRX3kdnSpg/abstract/?lang=pt  
21. Einsele H, Borghaei H, Orlowski RZ, Subklewe M, Roboz GJ, Zugmaier G, et al. The BiTE (bispecific T-cell engager) platform: Development and future potential of a targeted immuno-oncology therapy across tumor types. Cancer. 2020 Jul 15;126(14):3192–201.  
22. Blincyto® (blinatumomabe). Amgen Biotecnologia do Brasil Ltda [Internet]. 2022. Available from: https://www.amgen.com.br/~/media/Themes/CorporateAffairs/amgen-com-br/amgen-combr/PDF/Products/br_blincyto_pt_pi_resubmission_cds-v12-and-cpil-v10_clean.ashx?la=pt-  
BR&hash=551DEFBE0B1D1CCA5D6B5C08D8043C31  
23. Hatta Y, Hayakawa F, Yamazaki E. JSH practical guidelines for hematological malignancies, 2018: I. leukemia-3. acute lymphoblastic leukemia/lymphoblastic lymphoma (ALL/LBL). Int J Hematol [Internet]. 2020;112(4):439–58. Available from: http://www.ncbi.nlm.nih.gov/pubmed/32812190  
24. Locatelli F, Eckert C, Hrusak O, Buldini B, Sartor M, Zugmaier G, et al. Blinatumomab overcomes poor prognostic impact of measurable residual disease in  pediatric high-risk first relapse B-cell precursor acute lymphoblastic leukemia. Pediatr Blood Cancer. 2022 Aug;69(8):e29715.  
25. Jabbour EJ, Short NJ, Jain N, Jammal N, Jorgensen J, Wang S, et al. Blinatumomab is associated with favorable outcomes in patients with B-cell lineage acute lymphoblastic leukemia and positive measurable residual disease at a threshold of 10−4 and higher. Am J Hematol [Internet]. 2022 Sep 1 [cited 2022 Sep 21];97(9):1135–41. Available from: https://onlinelibrary.wiley.com/doi/full/10.1002/ajh.26634  
26. Kruse A, Abdel-Azim N, Kim HN, Ruan Y, Phan V, Ogana H, et al. Minimal Residual Disease Detection in Acute Lymphoblastic Leukemia. Int J Mol Sci [Internet]. 2020 Feb 1 [cited 2022 Sep 21];21(3). Available from: /pmc/articles/PMC7037356/

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **BLINATUMOMABE** -->
Eu,___________________________________________________________________________ (nome do[a] paciente),  
declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de blinatumomabe, indicado para o tratamento de leucemia linfoblástica aguda B derivada pediátrica em primeira recidiva medular de alto risco.  
|Os<br>_________|termos<br>________|médicos<br>__________|foram<br>_______|explicados<br>e<br>todas<br>______________________|as<br>____|dúvidas<br>_________|foram<br>______|esclarecidas<br>(nome do (a)|pelo<br>médico|médico<br>(a) que|
|---|---|---|---|---|---|---|---|---|---|---|  
prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Maior sobrevida global;  
- Maior sobrevida livre de doença;  
- Menos eventos adversos, se comparado à quimioterapia.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Medicamento classificado na gestação como categoria B.  
• Os eventos adversos mais comuns do blinatumomabe são: pirexia, infecções, reações relacionadas à infusão, dor de cabeça, anemia, trombocitopenia, efeitos neurológicos, edema, erupção cutânea, elevação das enzimas hepáticas, tremor, tosse, dor nas costas, calafrios, hipotensão, viroses, diminuição de imunoglobulinas, taquicardia, insônia, dor nas extremidades e doenças infecciosas causadas por fungos.  
• Os eventos adversos graves são: infecções (sepse, pneumonia, bacteremia, infecções oportunistas, e infecções no local do cateter), eventos neurológicos (encefalopatia, convulsões, distúrbios da fala, perturbações da consciência, confusão e desorientação, e distúrbios de coordenação e de equilíbrio), neutropenia/neutropenia febril, síndrome de liberação de citocinas, síndrome de lise tumoral e pancreatite. Consultas e exames durante o tratamento são necessários.  
- Este medicamento é contraindicado em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da  
fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) Blinatumomabe  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: OCORRÊNCIA DE EVENTOS ADVERSOS E CRITÉRIOS DE INTERRUPÇÃO DO TRATAMENTO COM BLINATUMOMABE -->
|**Evento**|**Grau ou sua caracterização (quando**|**Co**<br>|**nduta**|
|---|---|---|---|
||**disponível)**|**Pacientes com menos de 45**<br>**kg**|**Pacientes com 45 kg ou mais**|
|Síndrome de<br>Liberação de|Grau 3 - Febre, com hipotensão com<br>necessidade de vasopressores (com ou<br>sem vasopressina) ou hipóxia que<br>requer cânula nasal de alto fluxo,<br>máscara facial, máscara sem respirador<br>ou oxigenoterapia com máscara de<br>Venturi.|Interromper o uso do<br>medicamento até resolução.<br>Reiniciar blinatumomabe 5<br>mcg/m<sup>2</sup>/dia.<br>Aumentar para 15<br>mcg/m<sup>2</sup>/dia após 7 dias caso<br>a toxicidade não recorra.|Interromper o uso do<br>medicamento até resolução.<br>Reiniciar blinatumomabe 9<br>mcg/dia.<br>Aumentar para 28 mcg/dia<br>após 7 dias caso a toxicidade<br>não recorra.|
|Citocina (SLC)|Grau 4 - Febre, com hipotensão<br>requerendo múltiplos vasopressores<br>(excluindo vasopressina) ou hipóxia<br>requerendo ventilação com pressão<br>positiva utilizando CPAP, BiPAP,<br>intubação ou ventilação mecânica.|Interromper o uso de blina|tumomabe permanentemente.|
|Eventos<br>neurológicos|Convulsão<br>Grau 3 - Eventos graves e significantes,<br>mas que não representam risco à vida. É<br>indicada hospitalização ou<br>prolongamento desta, é incapacitante e<br>provoca limitação do autocuidado nas<br>atividades cotidianas.|Interromper o uso de blinatu<br>ocorra mais de<br>Interromper o uso de<br>blinatumomabe até que o<br>evento neurológico seja, no<br>máximo, grau 1 (leve) por<br>pelo menos 3 dias. Reiniciar<br>o uso do medicamento a 5<br>mcg/m²/dia.<br>Aumentar para 15<br>mcg/m²/dias após 7 dias<br>caso a toxicidade não<br>recorra.<br>Considerar uso de<br>anticonvulsivante<br>apropriado.<br>Se a toxicidade ocorreu com<br>o uso de 5 mcg/m²/dia ou se|momabe permanentemente caso<br>uma convulsão.<br>Interromper o uso de<br>blinatumomabe até que o<br>evento neurológico seja, no<br>máximo, grau 1 (leve) por pelo<br>menos 3 dias. Reiniciar o uso<br>do medicamento a 28 mcg/dia<br>após 7 dias, caso a toxicidade<br>não recorra. Para o reinício,<br>use 24 mg de dexametasona<br>com redução gradual em 4<br>dias. Como profilaxia<br>secundária, considerar o uso<br>de anticonvulsivante<br>apropriado. Se a toxicidade<br>ocorreu com o uso de 9<br>mcg/dia ou se resolver após|  
|**Evento**|**Grau ou sua caracterização (quando**<br>|**Co**<br>**Pit   d 45**|**nduta**|
|---|---|---|---|
||**disponível)**|**acenes com menos e**<br>**kg**|**Pacientes com 45 kg ou mais**|
|||resolver após mais de 7 dias,<br>interromper o medicamento<br>permanentemente.|mais de 7 dias, interromper o<br>medicamento<br>permanentemente|
||Grau 4 – Eventos com consequências<br>que representam risco de morte, quando<br>é indicada intervenção urgente.|Interromper o medica|mento permanentemente.|
|Outras reações<br>clinicamente<br>relevantes|Grau 3 (excluindo infecções)<br>Grau 4 (excluindo infecções)|Interromper o uso de<br>blinatumomabe até que a<br>reação adversa seja no<br>máximo grau 1 (leve).<br>Reiniciar o uso do<br>medicamento a 5<br>mcg/m<sup>2</sup>/dia. Aumentar para<br>15 mcg/m<sup>2</sup>/dia após 7 dias<br>se paciente não apresentar<br>nova toxicidade.<br>Considerar a interrupção p|Interromper o uso de<br>blinatumomabe até que a<br>reação adversa seja no máximo<br>grau 1 (leve). Reiniciar o uso<br>do medicamento a 9<br>mcg/m<sup>2</sup>/dia. Aumentar para 28<br>mcg/dia após 7 dias se<br>paciente não apresentar nova<br>toxicidade.<br>ermanente do medicamento.|  
Legenda: BiPAP - pressão positiva nas vias aéreas em dois níveis; CPAP - pressão positiva contínua nas vias aéreas. Nota: evento neurológico Grau 1: leve; assintomático ou leve sintoma; apenas observações clínicas ou de diagnóstico; sem indicação de intervenção. Fonte: SOBRAFO (2011)<sup>1</sup> ; Lee et al. (2019)<sup>2</sup> .

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Referências** -->
1 - Sociedade Brasileira de Farmacêuticos Oncologistas - SOBRAFO. Guia para Notificação de Reações Adversas em Oncologia [Internet]. 2011 [citado 7 de novembro de 2022]. Disponível em: https://sobrafo.org.br/wpcontent/uploads/2022/01/Guia-para-Notificacao-de-Reacoes-Adversas-em-Oncologia.pdf 2 - Lee DW, Santomasso BD, Locke FL, Ghobadi A, Turtle CJ, Brudno JN, et al. ASTCT Consensus Grading for Cytokine Release Syndrome and Neurologic Toxicity Associated with Immune Effector Cells. Biol Blood Marrow Transplant [Internet]. 1o de abril de 2019 [citado 7 de novembro de 2022];25(4):625–38. Disponível em: https://www.sciencedirect.com/science/article/pii/S1083879118316914

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador do Protocolo de Uso do blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do Protocolo, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
A elaboração deste Protocolo de uso iniciou-se com a incorporação do medicamento blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco, conforme Portaria SCTIE/MS nº 51, de 1º de junho de 2022.  
Sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde do Ministério da Saúde (DGITS/SECTICS/MS), foi elaborado o protocolo de uso do blinatumomabe, de acordo com as evidências disponíveis. Todos os participantes do processo de elaboração preencheram o formulário de Declaração de Conflitos de Interesse.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor deste Protocolo de Uso foi composto por metodologistas do Centro Colaborador do SUS para Avaliação de Tecnologias e Excelência em Saúde (CCATES/UFMG), sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde do Ministério da Saúde (DGITS/SETICS/MS) e revisão externa de especialista. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e o termo de confidencialidade.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de elaboração do Protocolo de Uso do blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco foi apresentada na 104ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 22 de novembro de 2022. Participaram desta reunião representantes da Secretaria de Atenção Especializada em Saúde (SAES/MS), da Secretaria de Vigilância em Saúde (SVS/MS), da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE), do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE), do Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS) e do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS). Os membros da Subcomissão presentes na reunião recomendaram pautar a apreciação do documento na Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec).

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Consulta pública** -->
A Consulta Pública nº 90/2022, para a elaboração do Protocolo de Uso do blinatumomabe para leucemia linfoblástica aguda (LLA) B derivada pediátrica em primeira recidiva medular de alto risco, foi realizada entre os dias 07/12/2022 e 26/12/2022. Foram recebidas 117 contribuições, que podem ser verificadas em https://www.gov.br/participamaisbrasil/anexoscp-conitec-sctie-n-90-2022-protocolo-de-uso-do-blinatumomabe-para-leucemia-linfoblastica-aguda-lla-b-derivada-pediatricaem-primeira-recidiva-medular-de-alto-risco.

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Busca da evidência e recomendações** -->
Em 28 de julho de 2022, foi atualizada a busca realizada pelos autores do relatório de recomendação do blinatumomabe em 19/11/2021 a fim de verificar novos estudos clínicos randomizados avaliando a eficácia e a segurança do medicamento. Não foi identificada nenhuma nova publicação.  
Dessa forma, foram elaboradas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT) para cada questão PICO, sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente do da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão.  
Na sequência, é apresentada para a questão clínica, os métodos e resultados das buscas.  
**QUESTÃO 1:** Qual a efetividade e a segurança do blinatumomabe, em comparação com quimioterapia atualmente  
preconizada nos protocolos hospitalares, em pacientes pediátricos com LLA em primeira recidiva, de alto risco?  
**<u>Recomendação da Conitec:</u>** utilizar o blinatumomabe para leucemia linfoblástica aguda B derivada (LLA-B) pediátrica em primeira recidiva medular de alto risco, conforme protocolo estabelecido pelo Ministério da Saúde.  
A estrutura PICO para esta pergunta foi:  
**População:** pacientes pediátricos com leucemia linfoblástica aguda (LLA), em primeira recaída, de alto risco. **Intervenção:** blinatumomabe.  
**Comparador:** quimioterapia padrão.  
**Desfechos:** sobrevida global, sobrevida livre de eventos, taxa de resposta completa ( _complete response rate_ - CRR),  
duração da remissão, qualidade de vida, eventos adversos.  
**Métodos e resultados da busca:**  
Foi realizada, em 28/07/2022, a atualização da busca realizada pelos autores do relatório de recomendação do blinatumomabe, a fim de verificar novos estudos clínicos randomizados avaliando a eficácia e a segurança do medicamento. Não foi identificada nenhuma nova publicação. As estratégias de busca para cada base estão descritas no **Quadro A** .  
**Quadro A** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou estudos clínicos sobre o uso de blinatumomabe.  
|**Base de**<br>**dados**|**Estratégia**|**Resultado**|
|---|---|---|
|PUBMED|(((((leukem* and (lymphoblast* or lymphoid* or lymphocyt* or lymphat*) and<br>(acut*))) or ("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh])) or<br>(Precursor Cell Lymphoblastic Leukemia Lymphoma OR Leukemia, Acute<br>Lymphoblastic OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic<br>OR Leukemia, Lymphoblastic, Acute OR Leukemia, Lymphocytic, Acute OR<br>Lymphoblastic Leukemia OR Lymphoblastic Leukemia, Acute OR Lymphoblastic<br>Lymphoma OR Lymphocytic Leukemia, Acute OR Acute Lymphocytic Leukemia<br>OR Leukemia, Acute Lymphocytic OR Lymphoma, Lymphoblastic OR Acute<br>Lymphoid Leukemia OR Leukemia, Acute Lymphoid OR Lymphoid Leukemia,<br>Acute OR Leukemia, Lymphoid, Acute OR Leukemia, Lymphocytic, Acute, L1 OR<br>Lymphocytic Leukemia, L1 OR L1 Lymphocytic Leukemia OR Leukemia, L1<br>Lymphocytic OR Lymphoblastic Leukemia, Acute, Childhood OR Lymphoblastic<br>Leukemia, Acute, L1 OR ALL, Childhood OR Childhood ALL OR Leukemia,|336 Resultados<br>28/07/2022|  
|**Base de**<br>**dados**|**Estratégia**|**Resultado**|
|---|---|---|
||Lymphoblastic, Acute, L1 OR Leukemia, Lymphocytic, Acute, L2 OR Lymphocytic<br>Leukemia, L2 OR L2 Lymphocytic Leukemia OR Leukemia, L2 Lymphocytic OR<br>Lymphoblastic Leukemia, Acute, L2 OR Leukemia, Lymphoblastic, Acute, L2 OR<br>Leukemia, Lymphoblastic, Acute, Philadelphia-Positive)) AND (("blinatumomab"<br>[Supplementary Concept]) or (Blinatumomab or MT-103 antibody OR antibody<br>MT-103 OR Blincyto OR MEDI-538 OR bscCD19xCD3 OR MT103))) AND<br>((randomized controlled trial[pt] OR controlled clinical trial[pt] OR<br>randomized[tiab] OR placebo[tiab] OR drug therapy[sh] OR randomly[tiab] OR<br>trial[tiab] OR groups[tiab] NOT (animals [mh] NOT humans [mh])))||
|EMBASE|('acute lymphoid leukemia cell line'/exp OR 'precursor cell lymphoblastic<br>leukemia lymphoma'/exp OR 'precursor cell lymphoblastic leukemia lymphoma'<br>OR 'leukemia, acute lymphoblastic'/exp OR 'acute lymphoblastic leukemia'/exp<br>OR 'leukemia, lymphoblastic' OR 'leukemia, lymphoblastic, acute' OR 'leukemia,<br>lymphocytic, acute'/exp OR 'lymphoblastic leukemia'/exp OR 'lymphoblastic<br>leukemia, acute'/exp OR 'lymphoblastic lymphoma'/exp OR 'lymphocytic<br>leukemia, acute' OR 'acute lymphocytic leukemia'/exp OR 'leukemia, acute<br>lymphocytic' OR 'lymphoma, lymphoblastic'/exp OR 'acute lymphoid<br>leukemia'/exp OR 'leukemia, acute lymphoid' OR 'lymphoid leukemia, acute' OR<br>'leukemia, lymphoid, acute' OR 'leukemia, lymphocytic, acute, l1'/exp OR<br>'lymphocytic leukemia, l1' OR 'l1 lymphocytic leukemia' OR 'leukemia, l1<br>lymphocytic' OR 'lymphoblastic leukemia, acute, childhood' OR 'lymphoblastic<br>leukemia, acute, l1' OR 'all, childhood' OR 'childhood all' OR 'leukemia,<br>lymphoblastic, acute, l1' OR 'leukemia, lymphocytic, acute, l2'/exp OR<br>'lymphocytic leukemia, l2' OR 'l2 lymphocytic leukemia' OR 'leukemia, l2<br>lymphocytic' OR 'lymphoblastic leukemia, acute, l2' OR 'leukemia,<br>lymphoblastic, acute, l2' OR 'leukemia, lymphoblastic, acute, philadelphia-<br>positive' OR (leukem* AND (lymphoblast* OR lymphoid* OR lymphocyt* OR<br>lymphat*) AND acut*)) AND ('blinatumomab'/exp OR (('mt 103' AND antibody<br>OR antibody) AND 'mt 103') OR blincyto OR 'medi 538' OR bsccd19xcd3 OR<br>mt103 OR gtpl7384) AND ('crossover procedure':de OR 'double-blind<br>procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de<br>OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross<br>NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1<br>blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR<br>allocat*:de,ab,ti OR volunteer*:de,ab,ti)|250 Resultados<br>28/07/2022|
|Cochrane|Blinatumomabe|97 Resultados|
|Lilacs|(Leukem$ OR leucem$ OR lymphoblast$ OR lymphoid$|2 Resultados|  
|**Base de**<br>**dados**|**Estratégia**|**Resultado**|
|---|---|---|
||OR lymphocyt$ OR lymphat$ OR linfoblást$ OR linfoid$ OR|28/07/2022|
||linfocít$) and (Blinatumomab OR blinatumomabe)||
|Clinical Trials|Blinatumomab|18 Resultados de<br>estudos completos|
|Total||703|

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: <u>Resultados da busca</u> -->
Não foram identificados novos estudos na atualização da busca além daqueles recuperados na busca inicial realizada pelos autores do Relatório de Recomendação nº 725.  
**Quadro B** - Estudos incluídos pelo demandante.  
|**Estudos selecionados pelo**|**Avaliação da Secretaria - Executiva da Conitec**|
|---|---|
|**demandante**|**Incluídos**<br>**Excluídos - Motivos**|
|Brown et al., 2021 (NCT02101853)|x|
|Locatelli et al., 2021 (NCT02393859)|x|

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Resumo das evidências:** -->
Em uma população mista de crianças e adolescentes diagnosticados com LLA-B em primeira recidiva medular de alto risco, em estado leucêmico M1 e doença residual mínima após terapia de indução e dois ciclos de terapia de consolidação, tratamento com blinatumomabe na dose de 15 μg/m<sup>2</sup> /dia por via endovenosa durante 28 dias, no terceiro ciclo de consolidação, em relação à quimioterapia segundo protocolo IntReALL HR 2010, diminui em 67%, em média, o risco de recidiva, falha ao tratamento ou morte, aumentando a sobrevida livre de doença em tempo de acompanhamento com mediana de 19,5 meses (HR 0,33; IC95% 0,18-0,61; P<0,001). Após 30 meses de acompanhamento, tratamento com blinatumomabe foi associado a um risco de morte em média 67% menor que tratamento com quimioterapia (HR 0,33; IC95% 0,15-0,72). Nessa mesma população, o grupo tratado com blinatumomabe apresentou maior taxa de negativação de doença residual mínima, em média 35% a mais, em relação ao tratado com quimioterapia (diferença absoluta 35,6%; IC95% 15,6%-52,5%; P<0,001), e menor risco de recidiva em até 24 meses (HR 0,24; IC95% 0,13-0,46). O uso do medicamento está associado à incidência de síndrome de liberação de citocinas, toxicidade neurológica e reativação de infecção pelo vírus JC (John Cunningham). A avaliação do risco de eventos adversos deve considerar a gravidade e alto risco da doença nessa população de indivíduos.  
O risco de viés dos estudos incluídos foi avaliado pelos autores do Relatório de Recomendação segundo a ferramenta para a avaliação de estudos controlados randomizados ( **Figura 1** ). O estudo de Brown e colaboradores (2021) foi considerado de alto risco de viés devido à perda significativa de pacientes no grupo que recebeu quimioterapia. Em determinado tempo de seguimento do estudo, a randomização foi interrompida e todos os pacientes remanescentes foram incluídos somente no grupo que recebeu blinatumomabe. Não houve cegamento de pacientes, profissionais de saúde e avaliadores de desfechos, exceto para a avaliação de DRM por citometria de fluxo. Como os desfechos principais são avaliados de forma objetiva, é possível que não haja viés de performance e detecção, entretanto, para esses domínios, os riscos de viés foram considerados incertos.  
O estudo de Locatelli e colaboradores foi classificado como risco de viés incerto devido ao não cegamento dos pacientes, profissionais de saúde e avaliadores de desfecho. Como no estudo de Brown, é possível que a falta de cegamento não tenha introduzido viés, pois os desfechos principais são avaliados de forma objetiva, por isso, o risco é considerado incerto.  
Não foi realizada meta-análise.  
**Figura 1** - Avaliação do risco de viés segundo ferramenta Cochrane apresentada no Relatório de Recomendação n°725.  
<!-- Start of picture text -->
s2<br>=<br>°<br>2s<br>2 3<br>g ae<br>s = 5<br>5 es<br>Se2B8 ea<br>3 s 2 a 4<br>S$ 2 -€ Ss 2<br>&£Sss ==6&888 Seg€&§ ££3Ss a8<br>® 2 egeeée<br>5222§ 29&gs =<br>5& £25 2 86 8 2=<br>2 &— €2eg<br>8s Se S<br>esa=88252868=¢&282 523 =5S<br>6 25s 6 2 ® @<br>—€Eesaazee?eees<br>a=s #28:8 s so £ c== 3=<br>&§ 8 £&eegeege<br>© 2 os @ = & 5<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: **Referências** -->
1 - Brown, Patrick A., Lingyun Ji, Xinxin Xu, Meenakshi Devidas, Laura E. Hogan, Michael J. Borowitz, Elizabeth A. Raetz, et al. “Effect of Postreinduction Therapy Consolidation With Blinatumomab vs Chemotherapy on Disease-Free Survival in Children, Adolescents, and Young Adults With First Relapse of B-Cell Acute Lymphoblastic Leukemia: A Randomized Clinical Trial”. JAMA 325, no 9 (2 de março de 2021): 833–42. https://doi.org/10.1001/jama.2021.0669.  
2 - Locatelli, Franco, Gerhard Zugmaier, Carmelo Rizzari, Joan D. Morris, Bernd Gruhn, Thomas Klingebiel, Rosanna Parasole, et al. “Effect of Blinatumomab vs Chemotherapy on Event-Free Survival Among Children With High-Risk FirstRelapse B-Cell Acute Lymphoblastic Leukemia: A Randomized Clinical Trial”. JAMA 325, no 9 (2 de março de 2021): 843– 54. https://doi.org/10.1001/jama.2021.0987.  
3 - Higgins JPT, Altman DG, Gøtzsche PC, Jüni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. BMJ. 2011 Oct;343:d5928

---

<!-- METADADOS: doenca: PCDT - Blinatumomabe | secao: HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do**|**Relatório**||**Tecnologias aval**|**iadas pela Conitec**||
|---|---|---|---|---|---|
|**da**<br>**diretriz**<br>**(Conitec) ou**<br>**de Publicação**|**clínica**<br>**Portaria**<br>|**Principais alterações**|**Incorporação ou**<br>**no SUS**|**alteração do uso**|**Não incorporação ou**<br>**não alteração no SUS**|
|Relatório nº 80|6/2023|Primeira versão do Protocolo de<br>Uso do blinatumomabe para<br>leucemia<br>linfoblástica<br>aguda<br>(LLA) B derivada pediátrica em<br>primeira recidiva medular de alto<br>risco|Blinatumomabe<br>linfoblástica agud<br>pediátrica<br>em<br>medular<br>de<br>[Relatório<br>de<br>nº 725/2022 e Por<br>51/2022]|para<br>leucemia<br>a (LLA) B derivada<br>primeira<br>recidiva<br>alto<br>risco<br> <br>Recomendação<br>taria SCTIE/MS nº|Não possui|

---

