<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 8, DE 14 DE ABRIL DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome Nefrótica Primária em Adultos.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a Síndrome Nefrótica Primária em Adultos no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 503/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 512 - Fevereiro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas - Síndrome Nefrótica Primária em Adultos.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Síndrome Nefrótica Primária em Adultos, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Síndrome Nefrótica Primária em Adultos.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria no 1.320/SAS/MS, de 25 de novembro de 2013, publicada no Diário Oficial da União nº 230, de 27 de novembro de 2013, seção 1, página 143.  
FRANCISCO DE ASSIS FIGUEIREDO  
DENIZAR VIANNA  
**ANEXO**

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **1. INTRODUÇÃO** -->
A Síndrome Nefrótica (SN) é definida pela presença de proteinúria (>3,0-3,5 g/1,73m<sup>2</sup> /dia em adultos), hipoalbuminemia (<3,0 g/dl) e edema, frequentemente acompanhada de hiperlipidemia, hipercoagulabilidade e outras alterações clínico-laboratoriais. Diversas lesões glomerulares podem desencadear a SN, sendo as condições mais comuns as glomerulopatias primárias e as formas secundárias de glomerulonefrite associadas a doenças sistêmicas<sup>1</sup> . Para muitos pacientes, a SN é uma condição recidivante e crônica, cuja evolução varia de acordo com a glomerulopatia subjacente, impondo risco de progressão para doença renal crônica terminal (DRCT) e necessidade de terapia de substituição de função renal<sup>1</sup> .  
Nas fases iniciais da SN, as principais manifestações são hiperlipidemia, hipercoagulabilidade, com aumento do risco de trombose venosa ou arterial, hipertensão arterial sistêmica, insuficiência renal aguda e infecções. Na fase crônica, outras complicações podem ocorrer, sendo a mais grave a evolução para doença renal crônica por não resposta ao tratamento imunossupressor, com progressão da doença glomerular e dano crônico renal irreversível.  
A prevalência da SN varia com a idade, a etnia e a população em estudo. No âmbito nacional, as doenças glomerulares primárias e secundárias foram associadas a 51% e 22,6% dos diagnósticos, respectivamente<sup>2</sup> . Entre as causas primárias de SN, a glomeruloesclerose segmentar e focal (GESF, 24,6%) e a glomerulopatia membranosa (GNM, 20,7%) foram as mais prevalentes, seguidas de nefropatia por IgA (NIgA, 20,1%), alterações glomerulares mínimas (AGM, 15,5%) e glomerulonefrite membranoproliferativa (GNMP, 4,2%)<sup>2</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da síndrome nefrótica primária em adulto. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS COM A SAÚDE (CID-10)**  
- N04.0 Síndrome nefrótica - anormalidade glomerular _minor_  
- N04.1 Síndrome nefrótica - lesões glomerulares focais e segmentares  
- N04.2 Síndrome nefrótica - glomerulonefrite membranosa difusa  
- N04.3 Síndrome nefrótica - glomerulonefrite proliferativa mesangial difusa  
- N04.4 Síndrome nefrótica - glomerulonefrite proliferativa endocapilar difusa  
- N04.5 Síndrome nefrótica – glomerulonefrite mesangiocapilar difusa  
- N04.6 Síndrome nefrótica - doença de depósito denso  
- N04.7 Síndrome nefrótica - glomerulonefrite difusa em crescente  
- N04.8 Síndrome nefrótica – outras  
- N04.9 Síndrome nefrótica – não especificada

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes adultos com mais de 18 anos, que apresentarem os seguintes critérios:  
- Síndrome nefrótica definida pela presença de proteinúria (>3,0-3,5 g/1,73m2/dia em adultos), hipoalbuminemia (<3,0 g/dl) e edema, frequentemente de hiperlipidemia, hipercoagulabilidade e outras alterações clÍnico-laboratoriais; e  
- diagnóstico histopatológico de material obtido por biopsia renal referentes aos  
- diagnósticos especificados no item 2, acima (códigos de N04.0 a N04.9 da CID-10).  
Outros critérios que justificam a inclusão:  
- presença de proteinúria nefrótica (>3,0-3,5 g/1,73m<sup>2</sup> de superfície corporal/dia), mesmo  
- sem o quadro completo de síndrome nefrótica, sem diagnóstico histopatológico;  
- forma rapidamente progressiva de glomerulopatia, com perda aguda de função renal de rápida evolução, ao longo de dias ou semanas, geralmente em associação a manifestações de síndrome nefrítica aguda, sem diagnóstico histopatológico;  
- após o tratamento imunossupressor inicial da glomerulopatia primária, em que o paciente apresente posteriormente a uma resposta total ou parcial (ver adiante os critérios de resposta ao tratamento): recidivas frequentes, dependência ao uso de corticosteróide (prednisona), dependência ao uso de outros imunossupressores (ciclofosfamida, ciclosporina) ou resistência ou intolerância ao tratamento inicial com prednisona ou outro imunossupressor, em que a mudança do medicamento é fundamental para tratamento e controle da doença, e para nefroproteção; ou  
- pacientes com síndrome nefrótica primária nos quais a contraindicação para realização de biopsia renal seja absoluta (p. ex., coagulopatia, anticoagulação plena) ou relativa (rim único, hipertensão arterial resistente ao tratamento, gestação, infecção do trato urinário persistente), quando se pode dispensar a biopsia e incluir o paciente em protocolo de tratamento baseado nos achados clínicos e nos exames laboratoriais.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **4. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem uma das condições abaixo, e estes critérios devem ser individualizados e sempre avaliados pela equipe assistente e pela urgência do tratamento:  
- Hipersensibilidade ou contraindicações clínicas para o uso de prednisona ououtros imunossupressores (ciclofosfamida, ciclosporina);  
- neoplasia maligna em atividade (de pulmão, pele – exceto carcinoma de células escamosas, mama e cólon, entre outras);  
- creatinina sérica superior a 3,5mg/dl, com doença renal crônica estágio 4 (taxa de filtração glomerular entre 15 e 29 ml/min /1,73 m<sup>2</sup> SC) ou estágio 5 (taxa de filtração glomerular < 15 ml/min /1,73 m<sup>2</sup> SC), com ou sem evidência de rins diminuídos ou contraídos (< 9 cm) – porém com o caso sendo individualizado e atentando-se para a elevação de creatinina sérica por insuficiência renal aguda; ou  
- contraindicações específicas para uso de ciclofosfamida: qualquer uma das seguintes evidências de disfunção da medula óssea: a) contagem de leucócitos abaixo de 3.000/mm<sup>3</sup> ; b) contagem de neutrófilos abaixo de 1.500/mm<sup>3</sup> ; ou c) contagem de plaquetas abaixo de 50.000/mm<sup>3</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **5.1. Considerações clínicas e histopatológicas** -->
A síndrome nefrótica é caracterizada por:  
- Critérios clínicos: edema, urina espumosa; e  
- critérios laboratoriais: proteinúria, hipoalbuminemia associada ou não a dislipidemia<sup>1</sup> .  
Em adultos, sempre que necessário para a confirmação diagnóstica, deve haver estudo do tecido renal que confirma a presença da lesão glomerular, guia a decisão terapêutica e, em cerca de 25% dos casos, permite diagnosticar causas secundárias de síndrome nefrótica<sup>2</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **5.1.1.          Diagnóstico clínico:** -->
Os principais sinais e sintomas observados nos pacientes com síndrome nefrótica são<sup>1-3</sup> :  
**Edema** , que pode ser leve a grave (generalizado até anasarca), em geral, apresentando-se de forma insidiosa, pela manhã, mais intenso na face e dorso, e à tarde, nos membros inferiores.  
**Presença de urina espumosa** , que traduz a perda anormal de proteína na urina. **Manifestações clínicas que decorrem de complicações comuns** , como perda aguda da função renal, fenômenos tromboembólicos e infecções, que podem estar presentes na abertura do quadro ou durante a evolução clínica. A hipertensão arterial sistêmica pode estar presente, com frequência variável de acordo com o tipo histopatológico da doença glomerular.  
**Manifestações da doença de base** , que, na avaliação inicial, a história e o exame clínico permitem levantar suspeitas de causas secundárias, como diabetes, lúpus, infecções bacterianas ou virais, uso de medicamentos e neoplasias, entre outras.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **5.1.2.          Diagnóstico laboratorial** -->
**Exame de urina:** proteinúria sempre presente;  
**Proteinúria de 24h na síndrome nefrótica:** a excreção urinária de proteínas acima de 3,0g/24h ou 3,5 g/1,73m<sup>2</sup> /dia de superfície corporal em 24 horas fazem parte da definição da síndrome nefrótica; Além destas medidas, a relação proteína/creatinina em amostra aleatória de urina igual ou acima de 3, com sensibilidade próxima a 90% em qualquer nível de função renal, é opção para o diagnóstico de “proteinúria nefrótica”<sup>1-4</sup> . Durante o acompanhamento do tratamento, a relação proteína/creatinina pode ser utilizada em substituição a proteinúria de 24 horas;  
**Hipoalbuminemia:** Albumina sérica (dosagem de proteínas totais e frações) abaixo de 3,5 g/dl;  
**Dislipidemia** : Colesterol total ou colesterol de baixa densidade (LDL) ou triglicerídeos elevados, presentes na maioria dos pacientes nefróticos;  
**Diagnóstico histopatológico:** Em todos os casos de síndrome nefrótica primária em adultos, e na maioria dos casos de síndrome nefrótica secundária, o exame histopatológico define o plano terapêutico, auxilia a definição do diagnóstico etiológico e do prognóstico. Mesmo assim, algumas pessoas podem apresentar proteinúria característica de síndrome nefrótica ou agudização súbita e progressiva para as quais o exame histopatológico não é necessariamente indicado, pois o quadro clínico já sugere dano renal. Adicionalmente, pacientes com contraindicação à biópsia (como no caso de rim único ou de coagulopatia) podem ser diagnosticados com base nos achados clínico-laboratoriais.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **5.2.      Diagnóstico etiológico** -->
Outros exames são necessários para afirmar ou excluir condições ou doenças sistêmicas subjacentes, como diabete melito, hepatites virais, soro positividade para HIV, sífilis e colagenoses como lúpus eritematoso sistêmico, crioglobulinemia e vasculites sistêmicas anti-citoplasma de neutrófilos (ANCA) positivas (poliangeíte com granulomatose, poliangeíte microscópica). Como o diagnóstico definitivo da glomerulopatia é estabelecido pelo exame histopatológico, a maioria dos casos deve ter estudo do tecido renal. Para a realização deste último, são necessários hemograma, provas de coagulação e exame de imagem renal pré-biopsia<sup>5</sup> .  
Os exames que contemplam o diagnóstico das condições ou doenças mais comumente associadas são: hemograma com plaquetas, creatinina sérica, glicemia, exame de urina, teste antiHIV, teste anti-HCV, HbsAg, anti-HBc total, exame sorológico para para sífilis, fator antinuclear e dosagem de complemento (C3, C4)<sup>5</sup> .  
Conforme o quadro clínico, podem ser solicitados, em caráter complementar e se disponíveis, anti-DNA dupla hélice, crioglobulinas, anticorpo anticitoplasma de neutrófilo [ANCAc (citoplasmático)] e ANCAp (perinuclear), entre outros<sup>1, 2</sup>

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6. TRATAMENTO** -->
O tratamento de pacientes adultos com SN é amplo e inclui o tratamento do edema nefrótico, o controle da pressão arterial e da dislipidemia, a profilaxia de infecções e a prevenção dos fenômenos tromboembólicos, por meio de medidas medicamentosas e não medicamentosas. A proteinúria, além de ser um marcador de lesão renal, também é um fator de risco significativo para progressão das doenças glomerulares. Quanto maior a proteinúria, maior será o risco de piora progressiva da função renal e evolução para doença renal crônica (DRC)<sup>6- 8</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.1.1.       Orientação Dietética Geral** -->
O suporte nutricional é uma das principais medidas para o adequado controle das complicações clínicas e laboratoriais do estado nefrótico. Quanto maior for a perda de proteína na urina, maiores serão as complicações relacionadas à função renal, dislipidemia, fenômenos tromboembólicos e infecções. A diminuição do apetite e o edema da mucosa intestinal agravam a condição nutricional desses pacientes. Dessa forma, o aporte calórico-proteico adequado é fundamental para manutenção do estado nutricional diminuindo assim o risco de complicações associadas a SN<sup>1, 9</sup> .  
A restrição de líquidos nem sempre é recomendada, mas deve ser feita na presença de hiponatremia e hiposmolaridade sérica e evitada quando há sinais clínicos de hipovolemia e hipoperfusão renal<sup>1, 9</sup> .  
O controle do peso diário e a medida do volume urinário de 24 horas são medidas simples e muito efetivas para avaliar a diminuição do volume corporal e a resposta ao tratamento. O objetivo é um balanço negativo de sódio e um balanço hídrico controlado<sup>1, 9</sup> .  
A elevação dos membros inferiores no repouso é útil. Também é importante evitar agentes nefrotóxicos, como anti-inflamatórios e contrastes iodados e ajustar a dose de antibióticos<sup>1, 9</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: _<u>Ingestão de Sódio</u>_ -->
O edema do paciente com SN é secundário a um balanço positivo de sódio e água. A restrição de sódio é fundamental para o controle do edema, sendo preconizado o uso de 2 g de sódio ao dia, ou cloreto de sódio (NaCl, sal de cozinha) 3-3,5 g/por dia. Isto é possível reduzindo-se a quantidade de sal na preparação dos alimentos e evitando-se o uso de sal adicional durante as refeições. Preconiza-se também evitar alimentos industrializados e embutidos<sup>1, 6, 9</sup> . _<u>Proteínas</u>_  
Inexiste consenso em relação a quantidade de proteínas de alto valor biológico a ser prescrita. Porém, naqueles doentes com taxa de filtração glomerular normal, preconiza-se uma dieta normoproteica, usualmente com 0,8-1,0 g/kg/dia<sup>1, 5, 8</sup> . A dieta hiperproteica não oferece benefício, pois não aumenta o nível de albumina sérica e não protege o indivíduo das complicações do estado nefrótico. É importante se manter uma dieta com alto conteúdo de carboidratos para maximizar a utilização das proteínas.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.1.2.       Tabaco e álcool e demais fatores** -->
Riscos adicionais para a progressão da DRC são o uso contínuo de tabaco e de álcool, obesidade e uso crônico de medicamentos e drogas ilícitas. Para além desses,  a presença das variantes de risco do gene da apolipoproteina L1 (APOL1) em pacientes afrodescendentes com GESF esporádica<sup>1, 6-8</sup> .  
O tratamento destas condições inclui dieta com restrição de sal, perda de peso, evitar o consumo de tabaco e álcool e também de descongestionantes, anfetaminas, esteróides anabólicos, anti-inflamatórios e cocaína associada ou não a levamisol<sup>10</sup> . Estas medidas devem ser prescritas e monitoradas como parte do tratamento não imunossupressor nos pacientes com glomerulopatia proteinúrica<sup>1, 6,7</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2. Fármacos utilizados no tratamento da Síndrome Nefrótica Primária em Adulto** -->
- Prednisona: comprimidos de 5 e 20 mg.  
- Ciclosporina: cápsulas de 10, 25, 50 e 100 mg.  
- Ciclofosfamida: drágeas de 50 mg.  
- Ciclofosfamida: solução injetável 50 mg.  
- Enalapril: comprimidos de 5, 10 e 20 mg.  
- Captopril: comprimidos de 25mg.  
- Losartana potássica: comprimidos de 50 mg.  
- Hidroclorotiazida: comprimidos de 12,5 e 25 mg.  
- Espironolactona: comprimido de 25 e 100mg.  
- Furosemida: comprimidos de 40mg e solução injetável de 10mg/ml.  
- Albumina humana: solução injetável de 0,2 g/mL (20%) – uso hospitalar.  
**Nota** : As posologias desses fármacos, e de outros utilizados no tratamento de pacientes  
com síndrome nefrótica primária em adulto, estão especificadas a seguir, nos respectivos tópicos.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.1.         Diuréticos** -->
Os diuréticos devem ser usados com cautela, especialmente quando existe a suspeita de hipovolemia e risco de induzir perda aguda de função renal. Nos pacientes com hipervolemia, o  
uso vigoroso de diuréticos é de grande relevância para o aumento da excreção de sódio e água e redução do volume intravascular. O uso mais agressivo de diuréticos irá depender do grau de edema e da resposta individual do paciente. Como os diuréticos atuam em diferentes sítios no néfron, sua associação pode contribuir para o aumento da natriurese e do volume urinário e, assim, proporcionar uma maior eficácia do tratamento<sup>5, 6, 9, 11-13</sup> , conforme mostra a **Tabela 1** .  
O diurético de alça mais utilizado no tratamento do edema nefrótico é a furosemida, devido a sua curta duração de ação. Deve ser usado 2 a 3 vezes ao dia (40 a 120 mg por dose). Se a resposta for insuficiente, deve-se aumentar a dose oral até alcançar a dose máxima (360 mg/dia). Se não houver resposta terapêutica adequada, está indicado iniciar furosemida por via endovenosa. A dose inicial de 1 mg/kg dividida em 2 a 3 vezes ao dia é preconizada, podendo ser aumentada até 0,5 a 1 mg/kg a cada 6, 8 ou 12 horas (80 a 320 mg/dia). Pode-se aplicar furosemida em bolus ou em infusão contínua, na dose de até 500 mg/dia<sup>1, 5, 6, 9, 13</sup> .  
A combinação de diuréticos com ação em diferentes sítios do néfron é uma conduta útil para induzir aumento da natriurese e da diurese, principalmente quando ocorre resistência ao diurético de alça. Os diuréticos tiazídicos (ex. hidroclorotiazida) ou os bloqueadores do sistema renina-angiotensina-aldosterona (BSRA) (ex. losartana potássica) promovem um bloqueio sequencial do néfron e induzem uma “sinergia” de diuréticos que pode efetivamente aumentar a excreção de sódio e a diurese, quando comparado ao uso isolado do diurético de alça, como mostra a **Tabela 1**<sup>12, 14-17</sup> .  
Como rotina, preconiza-se monitorizar a hipocalemia e a alcalose metabólica, quando do uso da associação de diuréticos<sup>1, 9, 13, 15, 16</sup> . A perda de peso corporal ponderal diária não deve ultrapassar 1,5-2,0 kg, pois, além disso, existe o risco de marcada hipovolemia induzindo insuficiência renal aguda, principalmente em indivíduos idosos.  
Os mecanismos de resistência aos diuréticos podem ser múltiplos, devendo-se afastar a má adesão aos medicamentos e à restrição de sódio, o que pode ser confirmado pela dosagem de sódio urinário de 24 h. O edema de alça intestinal com absorção errática no uso oral, pode também ser um fator de resistência.  Além disso, um dos principais fatores de resistência à ação da furosemida decorre do fato de que, sendo este medicamento mais de 90% ligado à albumina, não é secretado em quantidade suficiente no lúmen do túbulo proximal quando há hipoalbuminemia sérica<sup>14, 15</sup> .  
**Tabela 1 -** Tipos de diuréticos e mecanismos de ação nos diferentes sítios do néfron  
|**Classe**|**Mecanismo de ação**|**Medicamento/dose diária**|**Duração**<br>**(horas)**|**da ação**|
|---|---|---|---|---|
|Diuréticos de|Inibem o co-transporte|Furosemida (40-240 mg)|6||
|alça|de Na<sup>+</sup>/K<sup>+</sup>/2Cl<sup>-</sup>na alça<br>ascendente de Henle||||  
|Tiazídicos|Inibem o co-transporte<br>de<br>Na<sup>+</sup><br>na<br>porção<br>proximal do TCD|Hidroclorotiazida (25-50 mg)|12-24|
|---|---|---|---|
|Bloqueadores<br>do|Bloqueio do estímulo à<br>reabsorção Na<sup>+</sup>TCP|Espironolactona (25-200 mg)|24|
|SRAA|(ATII)<br>e<br>TCD<br>(aldosterona)|||  
TCD: túbulo contorcido distal; TCP: túbulo contorcido proximal; SRAA: sistema reninaangiotensina-aldosterona; ATII: angiotensina II. Adaptado das referências<sup>1, 13</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.2.        Albumina humana** -->
A indicação de albumina humana no edema nefrótico grave deve ser individualizada, não sendo possível recomendar o seu uso sistemático. A definição correta de resistência aos diuréticos deve ser primeiramente feita e, se presente, deve-se considerar que nos pacientes hipovolêmicos com maior grau de hipoalbuminemia o uso de albumina pode ter benefício terapêutico<sup>11, 14, 16</sup> .  
A infusão de albumina humana pode ser combinada ao diurético de alça ou mesmo ser administrada isoladamente<sup>9, 13</sup> . Entretanto, ainda é controverso se esta conduta é eficaz<sup>14</sup> . A infusão de albumina em pacientes hipervolêmicos deve ser feita com cautela, pois pode exacerbar a volemia, causando edema pulmonar e piora da hipertensão arterial. Já nos nefróticos hipovolêmicos com hipoalbuminemia grave, estão descritos benefícios com o seu uso, potencializando o efeito da furosemida com aumento da natriurese e do volume urinário, e redução significativa do peso corporal. Nos pacientes oligúricos e com perda aguda ou crônica de função renal, o uso de albumina deve ser criterioso, pelo risco de edema pulmonar agudo<sup>14</sup> .  
Em geral, a ocorrência de anasarca com ascite tensa, derrame pleural com disfunção respiratória, edema cutâneo grave com ruptura da pele e insuficiência renal aguda oligúrica são indicações clínicas para o uso de albumina humana. A dose preconizada de albumina humana a 20% ou 25% (20 g ou 25 g/100 ml) é 0,5 g/kg de peso infundida por via endovenosa em 1 hora, 2 a 3 vezes por dia. No final da infusão de albumina, administra-se 1 a 2 ampolas de furosemida 20 mg por via endovenoso para promover excreção de sódio e aumento da diurese<sup>11-14,16</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.3.        Ultrafiltração isolada e hemofiltração** -->
A ultrafiltração emula o processo natural de filtração que seria feito pela cápsula glomerular. Sendo assim, a ultrafiltração ocorre em um hemofiltro nas máquinas de hemodiálise, quando a pressão sanguínea é maior que a pressão dializada [ a diferença é a pressão transmembranar (TMP)]. Isso remove o fluido do sangue, mantendo intactas as células sanguíneas 18,19. A ultrafiltração está indicada nos raros casos de edema nefrótico refratário às medidas citadas acima explicitadas, em que o paciente permanece com disfunções graves pelo edema maciço, inclusive insuficiência renal aguda, e nos casos resistentes à terapia imunossupressora em que o edema nefrótico persiste por tempo prolongado. Relatos de caso e pequenas séries de casos têm  
mostrado remoção efetiva de líquido com a ultrafiltração isolada, havendo uma boa tolerância hemodinâmica e melhora clínica progressiva<sup>1, 17</sup> . Após algumas sessões de ultrafiltração, muitos pacientes passam a ter resposta ao diurético endovenoso, sugerindo que a remoção de fluídos reduz a pressão intersticial intra-renal com aumento do fluxo glomerular e tubular, melhorando a função renal<sup>17</sup> . A hemofiltração intermitente ou contínua poderia também ser usada, com efeitos semelhantes aos da ultrafiltração sobre a remoção do edema, inclusive com maior tolerância hemodinâmica e maior taxa de reenchimento plasmático. Durante a hemofiltração, o sangue do paciente é passado através de um conjunto de tubos (um circuito de filtração) para uma membrana semipermeável (o filtro), onde os resíduos e a água (no todo chamados de ultrafiltrados) são removidos por convecção. É então adicionado líquido de reposição e o sangue é devolvido ao paciente<sup>20, 21</sup> . A indicação de ultrafiltração isolada ou hemofiltração contínua deve ser individualizada, considerando o _status_ cardiovascular do paciente e a gravidade do edema<sup>17</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.4.         Controle da pressão arterial** -->
Nos pacientes com SN, o controle da pressão arterial é primordial para diminuir o índice de eventos adversos renais, principalmente a progressão para DRC e DRC terminal, e reduzir o nível de proteinúria, especialmente naqueles com proteinúria > 1,0 g/24 h<sup>6</sup> . O controle rigoroso da pressão arterial também tem um papel relevante na redução de eventos cardiovasculares, pois, além da dislipidemia, pacientes adultos e idosos com SN apresentam outros fatores de risco para doença aterosclerótica.  
No estudo “ _Modification of Diet in Renal Disease”_ (MDRD)<sup>22</sup> , pacientes com proteinúria >1 g/dia tiveram melhores desfechos renais com pressão arterial até 125/75 mmHg,  comparado a 140/90 mmHg. As diretrizes atuais do KDIGO ( _Kidney Disease: Improving Global Outcomes_ ) recomendam um alvo de pressão arterial abaixo de 130/80 mmHg em pacientes proteinúricos<sup>23</sup> . Estudos clínicos robustos justificam o uso dos inibidores da enzima de conversão da angiotensina (iECA) e dos bloqueadores do receptor 1 da angiotensina II (BRAs) como terapia de primeira escolha nestes casos<sup>24, 25</sup> . A associação com antagonistas do cálcio, beta-bloqueadores ou vasodilatadores diretos deve ser individualizada, visando ao controle ideal da pressão arterial.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.5.       Controle da dislipidemia** -->
A dislipidemia, em especial a hipercolesterolemia (aumento do colesterol LDL), a hipertrigliceridemia e o aumento da lipoproteína (a), são manifestações clínico-laboratoriais da SN que se resolvem quando o paciente apresenta resposta total ou parcial ao tratamento imunossupressor. A apolipopreína (a) (Lp(a) é um complexo macromolecular de estrutura esférica de cerca de 25 nm de diâmetro, na faixa de densidade de 1,05 a 1,12 g/mL. A estrutura da Lp(a) assemelha-se à das Lipoproteína de Baixa Densidade (LDL), pelo tamanho e pela composição lipídica das partículas e pela presença da Apolipoproteína B100 (apo B100). Portanto, pode ser  
utilizada como um indicador de hipercolesterolemia<sup>26</sup> . No entanto, nos pacientes com SN prolongada e resistente ao tratamento e naqueles com outros fatores de risco cardiovascular, como hipertensão, diabete melito, obesidade, tabagismo e DRC, o tratamento da dislipidemia pode trazer benefícios na redução da taxa de eventos cardiovasculares, assim como na população geral. Primeiramente, indica-se o uso dos inibidores da HMG-CoA redutase (estatinas) por sua melhor tolerância<sup>1,27</sup> . Com nível de triglicerídeos acima de 500 mg/dL, preconiza-se o uso de fibrato (p. ex., fenofibrato, ciprofibrato ou genfibrozila) para reduzir o risco de pancreatite. Entretanto, o benefício em longo prazo do tratamento com hipolipemiantes sobre a progressão da doença renal e complicações cardiovasculares não foi confirmado em meta-análise recente<sup>28</sup> . Para maiores informação e orientação,ver o PCDT da Dislipidemia - prevenção de eventos cardiovasculares e pancreatite<sup>29</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.6.       Uso de anti-proteinúricos** -->
Em pacientes com glomerulopatia primária, a redução da proteinúria < 0,5  a < 1,0 g/dia) diminui a progressão da doença renal e pode ser alcançada por meio do uso de inibidores da enzima conversora de angiotensina iECAs (p. ex., enalapril, captopril) ou dos BRAs (p. ex. losartana)<sup>1, 5, 6,</sup> 9. Mesmo em pacientes normotensos, esses medicamentos devem ser usados para redução da proteinúria, mas com cautela, pelo potencial que têm de reduzir a filtração glomerular causando insuficiência renal<sup>9</sup> .  
As demais classes de anti-hipertensivos reduzem a pressão pré-glomerular, algumas induzindo vasodilatação da arteríola aferente, e agregam na proteção renal pelo controle da hipertensão. Os antagonistas do cálcio dihidropiridínicos (p. ex., anlodipina, nifedipina) aumentam a pressão intra-glomerular e, assim, podem piorar a proteinúria, devendo ser evitados ou usados com cautela se necessários para controle da pressão arterial<sup>1, 6</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.7.       Prevenção de fenômenos tromboembólicos** -->
Os eventos tromboembólicos venosos (ETV) são mais comuns na glomerulonefrite membranosa e na glomeruloesclerose segmentar e focal. Geralmente, os ETV ocorrem na presença de albumina sérica < 2,5 g/dl. O desenvolvimento do estado pró-coagulante em pacientes com SN é o resultado da perda de fatores antitrombóticos na urina (anti-trombina III, proteína C, proteína S) associada ao aumento de cofatores plasmáticos pro-coagulantes (fatores V e VIII), além do aumento dos níveis de fibrinogênio<sup>9,.30, 31</sup> .  
A indicação de anticoagulação profilática é controversa e não existem estudos clínicos de longo prazo, sendo que sua prática não é uniforme entre os centros de tratamento. Estudos sugerem a necessidade de se estabelecer um nível de risco de sangramento antes de se proceder à anticoagulação nos casos de maior risco, ou seja, aqueles com albumina < 2,0-2,5 g/dl e proteinúria persistente > 10g/dia<sup>31</sup> . Além disso, fatores como sexo masculino, hipovolemia clínica e ETV  
prévios também aumentam o risco de um novo ETV (25). Neste caso, preconiza-se o uso de anticoagulante oral (p. ex. varfarina sódica) para manter a razão normalizada internacional (INR) entre 2-3 enquanto persistir o estado nefrótico. O uso de anticoagulação profilática com heparina subcutânea (5.000 U SC cada 8-12 h) está indicado em internações por doenças intercorrentes e necessidade de repouso no leito<sup>31</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.8.1.     Profilaxia de infecções** -->
Em adultos, complicação infecciosa parece ser menos frequente do que em crianças. Porém, o risco de sepse está presente, principalmente durante hospitalizações, uso de acesso venoso, exposição a germes multirresistentes, ruptura de pele e celulite<sup>9</sup> . Inexistem estudos clínicos consistentes para indicar antibioticoterapia profilática em adultos com SN<sup>32</sup> . Em pacientes sob imunossupressão com citotóxicos como a ciclofosfamida, preconiza-se o uso de sulfametoxazol+trimetoprima profilático (400mg + 80mg por dia) para prevenção de pneumocistose<sup>9, 32</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.8.2.     Vacinação** -->
Pacientes com SN estão expostos a maior risco de infecções bacterianas e virais pelo estado nefrótico e pelo uso de terapia imunossupressora<sup>9</sup> . As vacinas disponíveis no Programa Nacional de Imunizações estão indicadas: vacina Haemophilus influenzae tipo b (conjugada) - contida na pentavalente: tríplice bacteriana de células inteiras, hepatite B e Hib – DTPw-HB/Hib -, pneumocócica polissacarídica (Pneumo 23), varicela e influenza. No entanto é importante salientar que a vacina contra a varicela e as demais vacinas contendo agentes vivos atenuados [contra a poliomielite (oral), febre amarela, sarampo, caxumba, rubéola e tuberculose] são contraindicadas em pacientes em uso de imunossupressores, a depender dos seus tipo e doses. Desta forma, pessoas imunossuprimidas devem ser avaliadas pelo médico quanto ao risco da interrupção do tratamento e o intervalo mínimo (que depende do medicamento em uso) necessário para a aplicação dessas vacinas. Os pacientes com SN devem receber as vacinas indicadas, sempre que possível, previamente ao início da imunossupressão<sup>9, 32</sup> .Para recomendações atualizadas, consultar o Manual dos Centros de Referência para Imunobiológicos Especiais, do Ministério da Saúde.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.8.3.     Profilaxia de parasitoses** -->
As parasitoses intestinais - helmintíases e protozooses - são doenças com maior prevalência em regiões tropicais. Os parasitas intestinais mais frequentemente encontrados em seres humanos são: _Ascaris lumbricoides, Trichuris trichiura_ e os ancilostomídeos _Necator americanus_ e _Ancylostoma duodenale_ . Entre os protozoários, destacam-se a _Entamoeba histolytica_ e a _Giardia intestinalis_ . Pacientes nefropatas, incluindo aqueles com SN associada a glomerulopatia primária,  
e que necessitam imunossupressão prolongada, apresentam maior risco de ocorrência de manifestações graves das parasitoses intestinais. O quadro clínico é de sintomas inespecíficos, tais como anorexia, irritabilidade, distúrbios do sono, náusea, vômitos, dor abdominal e diarreia. Os quadros graves ocorrem mais em pacientes com maior carga parasitária, nos imunodeprimidos e em desnutridos<sup>33</sup> .  
<u>Tratamento:</u>  
**Ascaridíase:** O tratamento da infestação por nematódeos transmitidos pelo solo, tais como _Ascaris lumbricoides_ e ancilostomídeos, inclui os benzimidazois, agentes de amplo espectro, por exemplo o albendazol<sup>33</sup> .  
**Estrongiloidíase** : O tratamento da estrongiloidíase inclui fármacos do grupo dos benzimidazois, como, por exemplo, o albendazol, e a ivermectina. A ivermectina está associada a maior erradicação das larvas do _Strongyloides stercoralis_ quando comparada com albendazol<sup>34</sup> e apresenta menos efeitos colaterais do que medicamentos daquele grupo.  
<u>Posologia:</u>  
**Albendazol:** É utilizado na dose de 400 mg por via oral por 5 dias.  
**Ivermectina:** Embora um esquema profilático não tenha sido definido, a ivermectina é utilizada em dose única de de 0,2 mg/kg, nos dias 1 e 15. Essa prescrição deve ser repetida a cada seis meses, caso o paciente esteja ainda na vigência de imunossupressão, principalmente se reside permanentemente em área endêmica<sup>35</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.2.8.4. Suplementação de Cálcio e Vitamina D** -->
O uso de corticosteroides está associado com osteopenia e osteoporose. Baixos níveis de 25-hidroxicolecalciferol são encontrados em pacientes com SN devido à perda urinária desta vitamina e de sua proteína carreadora. A suplementação de vitamina D deve ser considerada nos pacientes com deficiência de vitamina D e para aqueles com redução da densidade mineral óssea (osteopenia, osteoporose) documentada na densitometria<sup>8</sup> .  
Nos surtos nefróticos de curta duração não é necessário o uso de cálcio ou vitamina D. Nos pacientes com dependência ou resistência ao corticosteroide, em que se prevê o seu uso prolongado por mais de 12-16 semanas, deve-se iniciar carbonato de cálcio (1 g/dia) e Colecalciferol (400 UI/dia); se houver hipocalcemia persistente associada ao estado nefrótico (p. ex., resistência ao corticosteróide), pode-se associar calcitriol oral na dose de 0,25 g/dia<sup>6, 8</sup> .  
Deve ser observado o PCDT do Distúrbio Mineral Ósseo na Doença Renal, do Ministério da Saúde<sup>36</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.1. Alterações glomerulares mínimas - AGM (doença de lesões mínimas)** -->
**6.3.1.1. Considerações clínicas e histopatológicas**  
A síndrome nefrótica é a apresentação clínica característica da AGM. Uma das peculiaridades dessa condição é a proteinúria seletiva e que, em geral, não é acompanhada de hematúria e nem de hipertensão arterial<sup>37-39</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.1.2. Tratamento da síndrome nefrótica causada pela AGM** -->
Há poucos estudos sobre o tratamento da AGM em adultos. A seleção dos fármacos e a base científica para a sua indicação em adultos têm como referência, sobretudo, os estudos realizados em crianças com síndrome nefrótica idiopática. Segue-se a linha geral de tratamento semelhante à adotada na nefrologia pediátrica<sup>39-41</sup> .  
**Prednisona** : É o tratamento de escolha para a AGM, administrada por via oral, uma vez ao dia, no período da manhã. A dose recomendada é de 1 mg/kg/dia (máximo de 80 mg/dia) por no mínimo 4 semanas, usualmente 8 semanas, podendo chegar até 16 semanas, com retirada escalonada em todos os esquemas terapêuticos, em geral em seis meses. A recidiva esporádica deve ser tratada com um novo ciclo deste corticoide na mesma dose, mas diminuindo-a lentamente assim que ocorrer a negativação da proteinúria<sup>40-42</sup> .  
**Ciclofosfamida** : É indicada em casos de dependência de corticoide ou de recidivas frequentes.  
A ciclofosfamida é utilizada na dose 2 mg/kg/dia, por via oral, uma vez ao dia, pela manhã, por doze semanas<sup>40-42</sup> .  
**Ciclosporina** : É utilizada na de 3 a 5 mg/kg/dia, por via oral, dividida em duas tomadas (de 12/12 h), nos primeiros seis meses e depois reduzir a dose, conforme a resposta ao tratamento. Opta-se pela ciclosporina como segunda escolha do tratamento da SN por AGM em jovens ou naquelas mulheres que desejam engravidar, devido ao risco de infertilidade inerente à ciclofosfamida<sup>40,44</sup> . .A dependência de ciclosporina é frequente. A ciclosporina é indicada para os casos de resistência ao tratamento anterior ou de efeitos adversos intensos da corticoterapia<sup>40-42</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.2.1. Considerações clínicas e histopatológicas** -->
A síndrome nefrótica é uma das apresentações clínicas da GESF.  Uma das peculiaridades dessa condição é a proteinúria não seletiva e que, em geral, pode acompanhar-se de algum grau de hematúria microscópica e de hipertensão arterial. O tratamento “específico” (imunossupressor) deve ser realizado apenas nos pacientes com GESF que se apresentam com síndrome nefrótica.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.2.2. Tratamento da síndrome nefrótica causada pela GESF** -->
**Prednisona:** É também o tratamento de primeira escolha para a GESF, administrada por via oral, uma vez ao dia, no período da manhã. A dose utilizada é de 1 mg/kg/dia (máximo de 80 mg/dia) por 16 semanas. A recidiva esporádica deve ser tratada com um novo ciclo deste corticoide  
na mesma dose, mas opta-se por diminuí-la lentamente assim que ocorrer a negativação da proteinúria (34).  
**Ciclosporina** : Utilizada na dose de 3 a 5 mg/kg/dia, por via oral, dividida em duas tomadas (de 12/12 h) nos primeiros seis meses, deve depois desses meses ter a dose reduzida conforme a resposta ao tratamento. O nível sérico da ciclosporina deve ser medido nos casos que não apresentarem resposta ao tratamento, com o intuito de se certificar de que existe nível terapêutico (deve ser de 100 a 200ng/mL). Se houver persistência da síndrome nefrótica, considerar resistência a ciclosporina após 16 semanas consecutivas de tratamento com nível sérico adequado deste imunossupressor<sup>40</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.3.1. Considerações clínicas e histopatológicas** -->
A GNM apresenta evolução variável, desde remissão espontânea da proteinúria à progressão para DRC em estágio terminal, sendo essa mais provável em pacientes com proteinúria persistente<sup>45</sup> .  
Na GNM, como em todas as glomerulopatias que se manifestam como síndrome nefrótica, devem ser investigadas as suas possíveis etiologias e, não se evidenciando uma causa, a GNM será classificada como idiopática, o que soi acontecer em 75% dos pacientes<sup>37</sup> .  
No que se refere à investigação etiológica da GNM, são consideradas como doenças subjacentes mais frequentes, entre outras: hepatite B, lúpus eritematoso sistêmico, neoplasias, artrite reumatoide, sífilis e malária. Por vezes, a GNM também é secundária ao uso de determinados medicacamentos<sup>37</sup> .  
Dosagens de autoanticorpos envolvidos na patogênese da GNM (anti-DNA dupla hélice, crioglobulinas, anticorpo anticitoplasma de neutrófilo (ANCA)) podem auxiliar no diagnóstico diferencial entre formas primárias e secundárias, assim como no acompanhamento do tratamento 46.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.3.2. Tratamento da síndrome nefrótica causada por GNM** -->
A utilização da terapia imunossupressora nessa condição deve ser ponderada em relação a quando deve ser iniciado o tratamento imunossupressor ou similar, ressaltando-se que a escolha do momento e do medicamento para tratar a GNM vem sendo motivo de controvérsias nas últimas décadas<sup>37</sup> .  
Entre as recomendações mais aceitas para o tratamento de adultos com GNM idiopática, é imprescindível que se diagnostique síndrome nefrótica vigente e que, pelo menos, uma das seguintes condições esteja presente<sup>8</sup> :  
- Excreção urinária de proteínas persistentemente superior a 4g/dia, que se mantenha acima de 50% do valor basal, sem apresentar declínio progressivo, durante terapia antihipertensiva e antiproteinúrica ao longo de um período de observação de pelo menos seis meses;  
- presença de sintomas relacionados à síndrome nefrótica que se mostrem graves ou incapacitantes ou que se constituam em ameaça à vida; ou  
- aumento da creatinina sérica em 30% ou mais dentro de 6 a 12 meses a partir do diagnóstico, desde que a TFG estimada não seja inferior a 25–30mL/min/1,73m<sup>2</sup> e esta alteração não seja explicada por complicações superpostas.  
É recomendado que não se use terapia imunossupressora em pacientes com creatinina sérica persistentemente maior que 3,5mg/dL (ou TFGe <30mL/min/1,73m<sup>2</sup> ) e redução do tamanho renal ao exame de ultrassonografia ou em pacientes com infecções concomitantes graves ou que se constituam em potencial ameaça à vida<sup>8, 37.</sup>

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.3.2.1. Esquemas terapêuticos para GNM idiopática** -->
Diferentemente do que acontece com outras doenças glomerulares que se manifestam como síndrome nefrótica, não é recomendável que a GNM idiopática seja tratada inicialmente com monoterapia com corticosteroide<sup>47-53</sup> .  
Os dois esquemas principais em uso para o tratamento da GNM idiopática são:.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Esquema de** **_Ponticelli_** -->
Preconiza-se como terapia inicial o esquema de _Ponticelli_ , que corresponde a seis meses de tratamento, em que se alternam pulsoterapia com metilprednisolona nos meses 1, 3 e 5 com corticosteroide VO e agente alquilante (ciclofosfamida) VO nos meses 2, 4 e 6<sup>23, 37, 54</sup> .  
Cuidados especiais com esse esquema se devem ao uso dos agentes alquilantes. Preconizase usar ciclofosfamida (2mg/kg/dia por via oral)<sup>55,37</sup> **.** Esse medicamento deve ser suspenso se a contagem total de leucócitos chegar a níveis inferiores a 3.500/mm<sup>3</sup> até que se recupere, tornandose superior a 4.000/mm<sup>3 55-60</sup> .  
A resposta ao tratamento pode não ser imediata, de modo que se recomenda que os pacientes sejam conduzidos de forma conservadora por pelo menos seis meses após esse esquema terapêutico ser completado, antes que se considere que houve falha terapêutica se não tiver ocorrido remissão, a menos que a função renal esteja se deteriorando ou haja sintomas graves, incapacitantes ou que potencialmente ameacem a vida relacionados à síndrome nefrótica<sup>56-59</sup> .  
Também é descrito que o uso diário contínuo (não cíclico) de agentes alquilantes VO é efetivo, mas pode associar-se a maior risco de toxicidade, particularmente quando administrado por mais de seis meses<sup>61-63</sup> . Portanto, seu uso deve ser recomendado caso a caso e os pacientes monitorados quanto à manifestação de toxicidade.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Inibidores de calcineurina (ICN)** -->
Caso haja contraindicação ao uso do esquema de _Ponticelli_ ou o paciente não aceite fazer o tratamento com ele, uma terapia alternativa é tratar com ciclosporina, por um período de pelo menos 6 meses<sup>64-68</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: <u>Posologia:</u> -->
Ciclosporina: Dose de 3,5–5,0mg/kg/dia VO dividada em duas doses iguais, tomadas de 12 em 12 horas, associada a prednisona 0,15mg/kg/dia, ambas por um período de 6 meses.  
Preconiza-se iniciar a ciclosporina com a dose na faixa mais baixa e aumenta-la gradualmente, se necessário, para evitar nefrotoxicidade aguda<sup>69,70</sup> .  
A ciclosporina deve ser suspensa em pacientes que não alcançam remissão completa ou parcial após seis meses de tratamento<sup>57, 64-66, 71, 72</sup> .  
A dose dose de ciclosporina deve reduzida a intervalos de 4–8 semanas para níveis de cerca de 50% da dose inicial, desde que a remissão seja mantida e não haja nefrotoxicidade relacionada ao seu uso que limite o tratamento, e a dose reduzida deve ser mantida por pelo menos 12 meses<sup>44,</sup> 68, 73.  
Em caso de recidiva de síndrome nefrótica em adultos com GNM idiopática, preconiza-se que se utilize novamente a mesma terapia que resultou na remissão inicial e, no caso do esquema de _Ponticelli_ , que esse esquema terapêutico seja repetido apenas uma vez<sup>60, 74, 75</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.1. Considerações clínicas e histopatológicas** -->
A NIgA é considerada a glomerulopatia mais comum em todo o mundo. Manifesta-se sobretudo na forma de hematúria, mas essa doença apresenta-se clinicamente das formas mais variadas, incluindo a síndrome nefrótica e até a glomerulonefrite rapidamente progressiva<sup>37</sup> . Como nas demais glomerulopatias, faz-se necessário afastar possíveis doenças associadas que possam ser determinantes da NIgA.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.2. Tratamento da síndrome nefrótica causada por NIgA** -->
Apesar de sua frequência e dos numerosos estudos sobre o assunto, ainda existem muitas controvérsias em relação a medidas terapêuticas específicas para a síndrome nefrótica causada por IgA. Mais recentemente, tratamentos direcionados a alvos específicos definidos em estudos de sua patogênese têm apresentado resultados promissores<sup>76</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.2.1. Tratamento antiproteinúrico** -->
Recomenda-se tratamento de longo prazo com inibidor da enzima de conversão da angiotensina (iECA) ou bloqueador do receptor 1 da angiotensina II (BRA) quando a proteinúria é >1g/dia, com aumento gradual da dose na dependência da pressão arterial<sup>77-79</sup> .  
Preconiza-se o tratamento com IECA ou BRA se a proteinúria estiver entre 0,5 e 1g/dia<sup>77-</sup> 79.  
As doses de IECA ou BRA serão aumentadas gradualmente na medida em que sejam toleradas, para alcançar proteinúria <1g/dia<sup>77-79</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.2.2. Controle da pressão arterial** -->
Em casos de NIgA, devem-se considerar como metas de controle da pressão arterial:  
- Quando a proteinúria inicial é < /dia: < 130/80mmHg e  
- quando a proteinúria inicial é > 1g/dia: < 125/75mmHg<sup>25, 80</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.2.3. Corticoterapia** -->
Preconiza-se que pacientes com proteinúria persistentemente ≥ 1g/dia, apesar de 3–6 meses de cuidados de suporte otimizados (inclusive IECA ou BRA e controle de pressão arterial), e taxa de filtração glomerular (TFG) < 50mL/min/1,73m<sup>2</sup> , recebam um curso de seis meses de corticoterapia com prednisona<sup>81-84</sup> .  
Recomenda-se tratar como AGM a NIgA com padrão de AGM, ou seja, os pacientes com síndrome nefrótica com achados histopatológicos de AGM e depósitos mesangiais de IgA na biopsia<sup>85, 86</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.4.2.4. Outros agentes imunossupressores** -->
Preconiza-se tratar a NIgA com corticosteroides combinados com ciclofosfamida (2mg/kg/dia via oral) apenas em caso de NIgA crescêntica com deterioração rápida da função renal 87-91.  
A terapia imunossupressora não deve utilizada por pacientes com TFG <30mL/min/1,73m<sup>2</sup> , exceto em caso de NIgA crescêntica com deterioração rápida da função renal 87, 88, 92-94.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.5.1. Considerações clínicas e histopatológicas** -->
A denominação glomerulonefrite membranoproliferativa (GNMP) atualmente se refere a um padrão histopatológico proliferativo de membrana, definido por achados de microscopia óptica, e compartilhado por algumas doenças distintas<sup>37</sup> .  
Comumente, apresenta-se como síndrome nefrótica associada a hematúria, mas em alguns pacientes a sua apresentação pode ser como síndrome nefrítica aguda, ou hematúria acompanhada ou não de proteinúria de pequena monta<sup>37</sup> .  
A classificação da GNMP é baseada sobretudo nos achados de imunofluorescência, subdividindo-a em dois grupos principais:  
- GNMP com depósitos de imunoglobulinas com ou sem complemento (compreendendo GNMP I e III da antiga classificação); e  
- GNMP com depósitos apenas de complemento (como as glomerulopatias do C3, que englobam doença de depósitos densos ou DDD e glomerulonefrite por C3)<sup>37</sup> , correspondendo à GNMP do tipo II da antiga classificação.  
Deve-se ressaltar, entretanto, que a denominação de glomerulopatia do C3 atualmente abrange um conjunto de condições definidas independentemente dos achados das microscopias óptica e eletrônica<sup>37</sup> , que vão além do padrão membranoproliferativo aqui em destaque.  
Essa proposta de classificação da GNMP, baseada nos achados de imunofluorescência do material obtido pela biopsia renal, tem implicações na investigação laboratorial à qual deverá ser submetido o paciente, uma vez definido o diagnóstico histopatológico. Assim, quando detectadas imunoglobulinas na imunofluorescência, a avaliação deve concentrar-se na pesquisa de infecções, doenças autoimunes e gamopatias monoclonais, sem esquecer a possibilidade de crioglobulinemia. Quando a GNMP é mediada por imunoglobulinas, também pode ocorrer deposição de frações do complemento, C3 e mesmo C4 ao longo das paredes capilares por ativação da via clássica. Por outro lado, nas formas mediadas por complemento, a imunofluorescência revela predominantemente C3 e não se observa ou inexiste deposição significativa de imunoglobulinas<sup>37</sup> . Importa destacar a associação da GNMP tipo I com infecções, em particular com hepatite C e, por vezes, com hepatite C e crioglobulinemia. Também são descritas associações com endocardite bacteriana e outras infecções bacterianas crônicas<sup>95</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.5.2. Tratamento da síndrome nefrótica causada por GNMP** -->
Em se tratando de GNMP, mais que em outras doenças glomerulares, antes de se optar por imunossupressão, a investigação de possível doença subjacente deve ser realizada, com especial atenção a infecções, em particular a hepatite C<sup>37</sup> .  
Inexiste clareza quanto ao melhor tratamento para a GNMP. Deve-se, como em outras glomerulopatias, instituir medidas de proteção da função renal o quanto antes, incluindo o bloqueio do sistema renina-angiotensina-aldosterona como recurso antiproteinúrico e para controle de pressão arterial, para o qual podem ser usados adicionalmente outros anti-hipertensivos; e medidas para tratamento de outros distúrbios, como a dislipidemia, também devem ser iniciadas<sup>37</sup> .  
Em se tratando de GNMP secundária, o tratamento deve ser direcionado inicialmente à doença de base, ainda que em algumas situações a imunossupressão também precise ser considerada<sup>37</sup> .  
É descrito que o tratamento de adultos com GNMP idiopática frequentemente não é bem sucedido e que a progressão para DRC em estágio terminal ocorre em 60% dos pacientes dentro de 10 anos. Embora crianças com GNMP idiopática possam responder a corticoterapia, não há relato de benefício expressivo no caso dos adultos<sup>96</sup> . Ainda que não exista um esquema ideal, preconizase que adultos com GNMP idiopática que se manifeste com síndrome nefrótica e declínio progressivo da função renal sejam tratados com ciclofosfamida 2mg/kg/dia VO, associada a corticosteroide em baixa dose, em dias alternados ou diariamente, com duração do tratamento inicial de menos de seis meses<sup>40, 96.</sup>

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **6.3.6. Tratamento de SN independentemente do tipo histológico** -->
Embora, em geral, o tratamento da síndrome nefrótica em adulto seja definido com base no diagnóstico histológico, alguns estudos foram direcionados ao tratamento da condição nefrótica independentemente do tipo histológico<sup>9, 44, 72, 73, 97-100.</sup>  
Na prática, esses resultados podem ser úteis para orientar situações em que o diagnóstico não ficou claro, mesmo com a realização da biopsia renal e o exame histopatológico do material obtido, ou em que não foi possível realizar a biopsia, por motivos diversos, como falta de recursos materiais e humanose, mas, sobretudo, por contra-indicação absoluta à realização do procedimento de biopsia, em razão de condições específicas do paciente.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **7.1 Monitorização da resposta ao tratamento** -->
A monitorização da resposta à terapia imunossupressora será realizada por critérios clínicos e laboratoriais, visando a uma resposta total ou parcial (vide critérios de resposta ao tratamento).  
Os exames laboratoriais devem ser solicitados mensalmente e incluem a dosagem de creatinina sérica, proteinúria de 24 horas ou o índice proteína/creatinina em amostra de urina aleatória, albumina sérica, exame de urina (físico, químico e sedimento urinário), hemograma, plaquetas, glicemia e dosagem de hemoglobina glicada<sup>101</sup> .  
O perfil lipídico (colesterol total, colesterol LDL, colesterol HDL e triglicerídeos) deve ser solicitado ao término do tratamento, para verificar sua normalização.  
Para controle e correção dos efeitos adversos do estado nefrótico (e também nos casos de recidiva da SN após resposta inicial) e das intervenções terapêuticas, como do uso de diuréticos de alça (furosemida), inibidores da enzima conversora da angiotensina e bloqueador do receptor da angiotensina, deve-se proceder à dosagem sérica de sódio, potássio, reserva alcalina (bicarbonato)  
e cálcio<sup>101</sup> . O controle da hipertensão arterial sistêmica associada a doença parenquimatosa renal ou aos eventos adversos dos imunossupressores como corticosteroides e inibidores de calcineurina deve ser rigoroso, e a pressão arterial deve ser verificada a cada consulta.  
Nos casos de GNMP primária com consumo de C3, a dosagem sérica de C3 deve ser feita para monitorizar a sua normalização ou nova queda.  
Nos pacientes em uso de ciclosporina, a dosagem de creatinina sérica e a medida sérica do nível deste medicamento deverão ser realizadas a cada quatro semanas, ou sempre que indicado, para evitar nefrotoxicidade aguda ou crônica associada ao inibidor da calcineurina (ver reações adversas a seguir), pois esses medicamentos podem causar fibrose intersticial e atrofia tubular renal, induzindo insuficiência renal progressiva. O nível terapêutico desejado de ciclosporina é estabelecido pelo “nível de vale”, quando o sangue para dosagem do medicamento é coletado 1 hora antes de o paciente ingerir a próxima dose (p. ex., coletar o sangue às 8 horas e tomar o medicamento às 9 h). Na fase inicial do tratamento, para ciclosporina considera-se um nível aceitável a concentração de 100-200 ng/mL<sup>40</sup> . Deve-se ajustar a dose diária sempre em bases individuais, pois o metabolismo hepático do medicamento é extremamente variável.  
A solicitação de outros exames deve ser individualizada de acordo com a evolução clínica do paciente, eventuais intercorrências, complicações do estado nefrótico ou aquelas relacionadas às comorbidades que o paciente apresenta. Como exemplos, radiografia simples de tórax, ecografia de vias urinárias, urocultura com antibiograma, provas de função hepática, dosagem sérica de  ácido úrico e exames cardiovasculares, entre outros.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **7.2 Monitorização das reações adversas aos imunossupressoras** -->
O tratamento da SN primária com imunossupressores está associado a eventos adversos de gravidade variável, pois os esquemas terapêuticos estendem-se por meses ou mesmo anos de uso contínuo desses medicamentos.  
Os eventos adversos e a conduta recomendada no seu tratamento serão discriminados a seguir, por medicamento:  
**Prednisona:** Fácies cushingoide, hirsutismo, acne, fadiga, miopatia, hipertensão arterial, diabete melito, dislipidemia, aumento do risco de infecções, aumento de peso, leucocitose, linfopenia, úlcera péptica, pancreatite, transtornos psiquiátricos, equimoses, osteoporose, necrose asséptica, catarata e glaucoma<sup>102</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tratamento clínico de acordo com o evento adverso:** -->
- Uso estrito da prednisona conforme preconizado com redução da dose até manutenção  
- com dose mínima e suspensão logo que possível;  
- -a suspensão da prednisona deve ser lenta para evitar insuficiência adrenal;  
- uso preventivo de bloqueador de bomba de prótons se história prévia de úlcera péptica;  
- controle da pressão arterial e do diabete;  
- orientação nutricional para perda de peso; e  
- suspensão da prednisona e tentativa com tratamento alternativo na presença de eventos adversos graves (p. ex., úlcera péptica, infecção sistêmica, diabete descompensado, necrose asséptica e glaucoma).  
**Ciclofosfamida:** Alopecia, infertilidade, amenorreia, náusea, vômitos, mucosite, cistite hemorrágica, leucopenia, anemia, trombocitopenia (pancitopenia); reações incomuns: neoplasias (síndrome mielodisplásica, leucemia mielóide aguda e carcinoma transicional de bexiga e de ureter ou de pelve renal), disfunção ventricular, cardiotoxicidade (miocardite), reação anafilática, hepatite tóxica, reativação de hepatite viral, fibrose pulmonar e hiperuricemia<sup>30,102</sup> .  
Controle de mielotoxicidade: Nos casos de paciente em uso de ciclofosfamida deverá ser realizado hemograma quinzenalmente nos dois primeiros meses e após, mensalmente. Em caso de redução da contagem de leucócitos, a dose da ciclofosfamida deverá ser reduzida em 50%. Se a contagem de leucócitos estiver abaixo de 3.000/mm<sup>3</sup> , os neutrófilos abaixo de 1.500/mm<sup>3</sup> ou as plaquetas abaixo de 100.000/mm<sup>3</sup> , o medicamento deverá ser suspenso<sup>9, 40</sup> .  
Hidratação adequada e uso de mesna quando a ciclofosfamida for administrada por infusão endovenosa em pulsoterapia, para prevenir irritação vesical e cistite hemorrágica.  
Dosagens séricas de aspartatoaminotransferase (AST/TGO) e alaninoaminotransferase (ALT/TGP) deverão ser realizadas mensalmente. Se os valores das aminotransferases/transaminases forem superiores a 2,0 a 2,5 vezes o valor basal (os limites superiores variam conforme o laboratório), a ciclofosfamida deve ser suspensa.  
**Ciclosporina:** Nefrotoxicidade aguda ou crônica, hirsutismo, hipertrofia gengival, neurotoxicidade (tremor fino de extremidades), hipertensão arterial, hiperlipidemia, diabete melito, piora do diabete prévio, hiperuricemia, rabdomiólise (principalmente quando associada a estatina) e microangiopatia trombótica/síndrome hemolítico-urêmica<sup>102</sup> .  
Monitorização seriada do nível sérico _de vale_ da ciclosporina (ver acima), com adequação da dose (se nível elevado, redução da dose e re-dosagem). Se o evento adverso não é controlado ou se for de maior gravidade, ou se houver intolerância ao medicamento, optar por suspender a ciclosporina e iniciar outro imunossupressor do esquema específico da glomerulopatia em tratamento.  
**7.3 Periodicidade das consultas médicas e exames laboratoriais**  
As periodicidades das consultas médicas e da realização dos exames dependem da fase do tratamento. Na fase inicial, enquanto se mantiver o tratamento imunossupressor em doses altas e permanência da síndrome nefrótica, as avaliações devem ser mensais, ou em intervalos quinzenais nos pacientes em uso de citotóxico, principalmente para detecção imediata de leucopenia ou pancitopenia, quando o medicamento deve ser suspenso pelo risco de infecções bacterianas, virais ou fúngicas oportunistas, complicações essas associadas a grande potencial de morbidade e mortalidade no paciente nefrótico.  
Nos pacientes que entram em remissão da glomerulopatia com resposta total (proteinúria < 0,2 g/24h ou IPC < 0,3 com albumina > 3,5 g/dl) ou parcial (proteinúria 0,2 a 3,0 g/24h ou IPC entre 0,3 e 3,0), as consultas serão a cada 60 ou 90 dias até o final do primeiro ano. Transcorrido esse período, o paciente deverá ser reavaliado a cada 4 meses no segundo ano e a cada 6 meses, no terceiro ano. Após 4 a 5 anos, se o paciente não apresentou recidiva da síndrome nefrótica e encontra-se clinicamente estável, as consultas são realizadas a cada 12 meses.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas, a adequação de uso do medicamento e o acompanhamento pós-tratamento. Os doentes de síndrome nefrótica primária devem ser atendidos, especialmente na fase aguda, em serviços especializados, para seu adequado diagnóstico e inclusão no tratamento.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levandose em consideração as informações contidas no TER.  
Para orientar os trabalhos na Assistência Farmacêutica nas secretarias de saúde, seguem-se ao TER deste Protocolo os fluxogramas de tratamento e de dispensação de ciclosporina e ciclofosfamida ( **Figura 1** ), para a dispensação de prednisona ( **Figura 2** ) e de atendimento na Assistência Farmacêutica da Secretaria de Saúde ( **Figura 3** ), assim como a Ficha Farmacoterapêutica e o Guia de Orientação ao Paciente.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **10. REFERÊNCIAS** -->
1. J. F. Introduction to glomerular disease: clinical presentations. In: Saunders E, editor. Johnson RJ, Feehally J, Floege J, eds Comprehensive Clinical Nephrology. 5th ed. Philadelphia, PA2015. p. 182-94.  
2. Polito MG, de Moura LA, Kirsztajn GM. An overview on frequency of renal biopsy diagnosis in Brazil: clinical and pathological patterns based on 9,617 native kidney biopsies. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2010;25(2):490-6.  
3. Malafronte P, Mastroianni-Kirsztajn G, Betonico GN, Romao JE, Jr., Alves MA, Carvalho MF, et al. Paulista Registry of glomerulonephritis: 5-year data report. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2006;21(11):3098-105.  
4. Costa DM, Valente LM, Gouveia PA, Sarinho FW, Fernandes GV, Cavalcante MA, et al. Comparative analysis of primary and secondary glomerulopathies in the northeast of Brazil: data from the Pernambuco Registry of Glomerulopathies - REPEG. Jornal brasileiro de nefrologia : 'orgao oficial de Sociedades Brasileira e Latino-Americana de Nefrologia. 2017;39(1):29-35.  
5. Kodner C. Diagnosis and Management of Nephrotic Syndrome in Adults. American family physician. 2016;93(6):479-85.  
6. Wilmer WA, Rovin BH, Hebert CJ, Rao SV, Kumor K, Hebert LA. Management of glomerular proteinuria: a commentary. Journal of the American Society of Nephrology : JASN. 2003;14(12):3217-32.  
7. Floege J, Amann K. Primary glomerulonephritides. Lancet (London, England). 2016;387(10032):2036-48.  
8. Radhakrishnan J, Cattran DC. The KDIGO practice guideline on glomerulonephritis: reading between the (guide)lines&#x2014;application to the individual patient. Kidney International.82(8):840-56.  
9. Charlesworth JA, Gracey DM, Pussell BA. Adult nephrotic syndrome: non-specific strategies for treatment. Nephrology (Carlton, Vic). 2008;13(1):45-50.  
10. Veronese FV, Dode RS, Friderichs M, Thome GG, da Silva DR, Schaefer PG, et al. Cocaine/levamisole-induced systemic vasculitis with retiform purpura and pauci-immune glomerulonephritis. Brazilian journal of medical and biological research = Revista brasileira de pesquisas medicas e biologicas. 2016;49(5):e5244.  
11. Siddall EC, Radhakrishnan J. The pathophysiology of edema formation in the nephrotic syndrome. Kidney Int. 2012;82(6):635-42.  
12. Cadnapaphornchai MA, Tkachenko O, Shchekochikhin D, Schrier RW. The nephrotic syndrome: pathogenesis and treatment of edema formation and secondary complications. Pediatric nephrology (Berlin, Germany). 2014;29(7):1159-67.  
13. Ellis D. Pathophysiology, Evaluation, and Management of Edema in Childhood Nephrotic Syndrome. Frontiers in pediatrics. 2015;3:111.  
14. Duffy M, Jain S, Harrell N, Kothari N, Reddi AS. Albumin and Furosemide Combination for Management of Edema in Nephrotic Syndrome: A Review of Clinical Studies. Cells. 2015;4(4):622-30.  
15. Tanaka M, Oida E, Nomura K, Nogaki F, Fukatsu A, Uemura K, et al. The Na+-excreting efficacy of indapamide in combination with furosemide in massive edema. Clinical and experimental nephrology. 2005;9(2):122-6.  
16. Kapur G, Valentini RP, Imam AA, Mattoo TK. Treatment of severe edema in children with nephrotic syndrome with diuretics alone--a prospective study. Clinical journal of the American Society of Nephrology : CJASN. 2009;4(5):907-13.  
17. Davenport A. Ultrafiltration in diuretic-resistant volume overload in nephrotic syndrome and patients with ascites due to chronic liver disease. Cardiology. 2001;96(3-4):190-5.  
18. Ronco C, Bellomo R, Ricci Z. Hemodynamic response to fluid withdrawal in overhydrated patients treated with intermittent ultrafiltration and slow continuous ultrafiltration: role of blood volume monitoring. Cardiology. 2001;96(3-4):196-201.  
19. E Koushanpour, Esmail. Renal Physiology - Principles, Structure, and Function. New York: Springer-Verlag; 1986. 53–72 p.  
20. Cruz D, Bellomo R, Kellum JA, de Cal M, Ronco C. The future of extracorporeal support. Crit Care Med. 2008;36(4 Suppl):S243-52.  
21. Hoffmann JN, Faist E. Removal of mediators by continuous hemofiltration in septic patients. World J Surg. 2001;25(5):651-9.  
22. Klahr S, Levey AS, Beck GJ, Caggiula AW, Hunsicker L, Kusek JW, et al. The effects of dietary protein restriction and blood-pressure control on the progression of chronic renal disease. Modification of Diet in Renal Disease Study Group. The New England journal of medicine. 1994;330(13):877-84.  
23. KDIGO. Clinical practice guideline for the evaluation and management of chronic kidney disease. Kidney International. 2013;3(suppl. 1).  
24. Randomised placebo-controlled trial of effect of ramipril on decline in glomerular filtration rate and risk of terminal renal failure in proteinuric, non-diabetic nephropathy. The GISEN Group (Gruppo Italiano di Studi Epidemiologici in Nefrologia). Lancet (London, England). 1997;349(9069):1857-63.  
25. Jafar TH, Schmid CH, Landa M, Giatras I, Toto R, Remuzzi G, et al. Angiotensinconverting enzyme inhibitors and progression of nondiabetic renal disease. A meta-analysis of patient-level data. Annals of internal medicine. 2001;135(2):73-87.  
26. Maranhao RC, Carvalho PO, Strunz CC, Pileggi F. Lipoprotein (a): structure, pathophysiology and clinical implications. Arq Bras Cardiol. 2014;103(1):76-84.  
27. Thomas ME, Harris KP, Ramaswamy C, Hattersley JM, Wheeler DC, Varghese Z, et al. Simvastatin therapy for hypercholesterolemic patients with nephrotic syndrome or significant proteinuria. Kidney Int. 1993;44(5):1124-9.  
28. Kong X, Yuan H, Fan J, Li Z, Wu T, Jiang L. Lipid-lowering agents for nephrotic syndrome. The Cochrane database of systematic reviews. 2013(12):Cd005425.  
29. BRASIL. PORTARIA CONJUNTA Nº 8, de 30 de julho de 2019. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite. 2019.  
30. Barbour SJ, Greenwald A, Djurdjev O, Levin A, Hladunewich MA, Nachman PH, et al. Disease-specific risk of venous thromboembolic events is increased in idiopathic glomerulonephritis. Kidney Int. 2012;81(2):190-5.  
31. Lee T, Biddle AK, Lionaki S, Derebail VK, Barbour SJ, Tannous S, et al. Personalized prophylactic anticoagulation decision analysis in patients with membranous nephropathy. Kidney Int. 2014;85(6):1412-20.  
32. Wu HM, Tang JL, Cao L, Sha ZH, Li Y. Interventions for preventing infection in nephrotic syndrome. The Cochrane database of systematic reviews. 2012(4):Cd003964.  
33. Braz AS, de Andrade CA, da Mota LM, Lima CM. [Recommendations from the Brazilian Society of Rheumatology on the diagnosis and treatment of intestinal parasitic infections in patients with autoimmune rheumatic disorders]. Revista brasileira de reumatologia. 2015;55(4):368-80.  
34. Suputtamongkol Y, Premasathian N, Bhumimuang K, Waywa D, Nilganuwong S, Karuphong E, et al. Efficacy and Safety of Single and Double Doses of Ivermectin versus 7-Day High Dose Albendazole for Chronic Strongyloidiasis. PLoS Neglected Tropical Diseases. 2011;5(5).  
35. Santiago M, Leitao B. Prevention of strongyloides hyperinfection syndrome: a rheumatological point of view. European journal of internal medicine. 2009;20(8):744-8.  
36. Brasil. Ministério da Saúde. Portaria Nº 801, de 25 de abril de 2017. Aprova o Protocolo Clínico e Diretrizes Terapêuticas TGP do Distúrbio Mineral Ósseo na Doença Renal Crônica. In: Saúde Md, editor. Brasília. 2017.  
37. G MK. Glomerulopatias: Manual prático. 2ª ed. São Paulo: Editora Balieiro; 2017.  
38. Skorecki K CG, Marsden PA, Taal MW, Yu ASL. Brenner and Rector’s The Kidney. 10th ed. Elsevier, editor. Philadelphia2016.  
39. Waldman M, Crew RJ, Valeri A, Busch J, Stokes B, Markowitz G, et al. Adult minimalchange disease: clinical characteristics, treatment, and outcomes. Clinical journal of the American Society of Nephrology : CJASN. 2007;2(3):445-53.  
40. KDIGO. The 2012 KDIGO practice guideline on glomerulonephritis. Kidney International. 2012;2012 suppls.  
41. Hogan J, Radhakrishnan J. The treatment of minimal change disease in adults. Journal of the American Society of Nephrology : JASN. 2013;24(5):702-11.  
42. Vivarelli M, Massella L, Ruggiero B, Emma F. Minimal Change Disease. Clinical journal of the American Society of Nephrology : CJASN. 2017;12(2):332-45.  
43. Rydel JJ, Korbet SM, Borok RZ, Schwartz MM. Focal segmental glomerular sclerosis in adults: presentation, course, and response to treatment. American journal of kidney diseases : the official journal of the National Kidney Foundation. 1995;25(4):534-42.  
44. Cattran DC, Alexopoulos E, Heering P, Hoyer PF, Johnston A, Meyrier A, et al. Cyclosporin in idiopathic glomerular disease associated with the nephrotic syndrome : workshop recommendations. Kidney Int. 2007;72(12):1429-47.  
45. Li S, Wang L, Zhang M, Zhou W, Fang W, Wang Q, et al. Clinical Predictors of Response to Prednisone Plus Cyclophosphamide in Patients with Idiopathic Membranous Nephropathy. Nephron. 2017;135(2):87-96.  
46. Mastroianni-Kirsztajn G, Hornig N, Schlumberger W. Autoantibodies in renal diseases - clinical significance and recent developments in serological detection. Frontiers in immunology. 2015;6:221.  
47. A controlled study of short-term prednisone treatment in adults with membranous nephropathy. Collaborative Study of the Adult Idiopathic Nephrotic Syndrome. The New England journal of medicine. 1979;301(24):1301-6.  
48. Cattran DC, Delmore T, Roscoe J, Cole E, Cardella C, Charron R, et al. A randomized controlled trial of prednisone in patients with idiopathic membranous nephropathy. The New England journal of medicine. 1989;320(4):210-5.  
49. Shiiki H, Saito T, Nishitani Y, Mitarai T, Yorioka N, Yoshimura A, et al. Prognosis and risk factors for idiopathic membranous nephropathy with nephrotic syndrome in Japan. Kidney Int. 2004;65(4):1400-7.  
50. Branten AJ, du Buf-Vereijken PW, Vervloet M, Wetzels JF. Mycophenolate mofetil in idiopathic membranous nephropathy: a clinical trial with comparison to a historic control group treated with cyclophosphamide. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2007;50(2):248-56.  
51. Chan TM, Lin AW, Tang SC, Qian JQ, Lam MF, Ho YW, et al. Prospective controlled study on mycophenolate mofetil and prednisolone in the treatment of membranous nephropathy with nephrotic syndrome. Nephrology (Carlton, Vic). 2007;12(6):576-81.  
52. Senthil Nayagam L, Ganguli A, Rathi M, Kohli HS, Gupta KL, Joshi K, et al. Mycophenolate mofetil or standard therapy for membranous nephropathy and focal segmental glomerulosclerosis: a pilot study. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2008;23(6):1926-30.  
53. Dussol B, Morange S, Burtey S, Indreies M, Cassuto E, Mourad G, et al. Mycophenolate mofetil monotherapy in membranous nephropathy: a 1-year randomized controlled trial. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2008;52(4):699705.  
54. Ramachandran R, Yadav AK, Kumar V, Siva Tez Pinnamaneni V, Nada R, Ghosh R, et al. Two-Year Follow-up Study of Membranous Nephropathy Treated With Tacrolimus and Corticosteroids Versus Cyclical Corticosteroids and Cyclophosphamide. Kidney International Reports. 2017;2(4):610-6.  
55. Ponticelli C, Altieri P, Scolari F, Passerini P, Roccatello D, Cesana B, et al. A randomized study comparing methylprednisolone plus chlorambucil versus methylprednisolone plus cyclophosphamide in idiopathic membranous nephropathy. Journal of the American Society of Nephrology : JASN. 1998;9(3):444-50.  
56. Ponticelli C, Zucchelli P, Passerini P, Cesana B, Locatelli F, Pasquali S, et al. A 10-year follow-up of a randomized study with methylprednisolone and chlorambucil in membranous nephropathy. Kidney Int. 1995;48(5):1600-4.  
57. Ponticelli C, Zucchelli P, Imbasciati E, Cagnoli L, Pozzi C, Passerini P, et al. Controlled trial of methylprednisolone and chlorambucil in idiopathic membranous nephropathy. The New England journal of medicine. 1984;310(15):946-50.  
58. Ponticelli C, Zucchelli P, Passerini P, Cesana B. Methylprednisolone plus chlorambucil as compared with methylprednisolone alone for the treatment of idiopathic membranous nephropathy. The Italian Idiopathic Membranous Nephropathy Treatment Study Group. The New England journal of medicine. 1992;327(9):599-603.  
59. Ponticelli C, Zucchelli P, Passerini P, Cagnoli L, Cesana B, Pozzi C, et al. A randomized trial of methylprednisolone and chlorambucil in idiopathic membranous nephropathy. The New England journal of medicine. 1989;320(1):8-13.  
60. Ponticelli C, Passerini P, Altieri P, Locatelli F, Pappalettera M. Remissions and relapses in idiopathic membranous nephropathy. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 1992;7 Suppl 1:85-90.  
61. Hofstra JM, Branten AJ, Wirtz JJ, Noordzij TC, du Buf-Vereijken PW, Wetzels JF. Early versus late start of immunosuppressive therapy in idiopathic membranous nephropathy: a randomized controlled trial. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2010;25(1):129-36.  
62. Branten AJ, Reichert LJ, Koene RA, Wetzels JF. Oral cyclophosphamide versus chlorambucil in the treatment of patients with membranous nephropathy and renal insufficiency. QJM : monthly journal of the Association of Physicians. 1998;91(5):359-66.  
63. du Buf-Vereijken PW, Branten AJ, Wetzels JF. Cytotoxic therapy for membranous nephropathy and renal insufficiency: improved renal survival but high relapse rate. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2004;19(5):1142-8.  
64. Ambalavanan S, Fauvel JP, Sibley RK, Myers BD. Mechanism of the antiproteinuric effect of cyclosporine in membranous nephropathy. Journal of the American Society of Nephrology : JASN. 1996;7(2):290-8.  
65. Guasch A, Suranyi M, Newton L, Hall BM, Myers BD. Short-term responsiveness of membranous glomerulopathy to cyclosporine. American journal of kidney diseases : the official journal of the National Kidney Foundation. 1992;20(5):472-81.  
66. Cattran DC, Appel GB, Hebert LA, Hunsicker LG, Pohl MA, Hoy WE, et al. Cyclosporine in patients with steroid-resistant membranous nephropathy: a randomized trial. Kidney Int. 2001;59(4):1484-90.  
67. Alexopoulos E, Papagianni A, Tsamelashvili M, Leontsini M, Memmos D. Induction and long-term treatment with cyclosporine in membranous nephropathy with the nephrotic syndrome. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2006;21(11):3127-32.  
68. Praga M, Barrio V, Juarez GF, Luno J. Tacrolimus monotherapy in membranous nephropathy: a randomized controlled trial. Kidney Int. 2007;71(9):924-30.  
69. Li QH, Yang ZJ, Li L, Gou R, Guo YY, Yin LL, et al. Comparison of efficacy and safety between tacrolimus and cyclosporine combined with corticosteroids in patients with idiopathic membranous nephropathy: A randomized controlled trial. International Journal of Clinical and Experimental Medicine. 2017;10(6):9764-70.  
70. Omrani H, Golmohamadi S, Hichi F, Sadeghi M. Comparison of the efficacy of tacrolimus versus cyclosporine in the treatment of idiopathic membranous nephropathy. Nephro-Urology Monthly. 2017;9(1).  
71. Donadio JV, Jr., Holley KE, Anderson CF, Taylor WF. Controlled trial of cyclophosphamide in idiopathic membranous nephropathy. Kidney Int. 1974;6(6):431-9.  
72. Murphy BF, McDonald I, Fairley KF, Kincaid-Smith PS. Randomized controlled trial of cyclophosphamide, warfarin and dipyridamole in idiopathic membranous glomerulonephritis. Clinical nephrology. 1992;37(5):229-34.  
73. Meyrier A, Noel LH, Auriche P, Callard P. Long-term renal tolerance of cyclosporin A treatment in adult idiopathic nephrotic syndrome. Collaborative Group of the Societe de Nephrologie. Kidney Int. 1994;45(5):1446-56.  
74. Waldman M, Austin HA, 3rd. Controversies in the treatment of idiopathic membranous nephropathy. Nature reviews Nephrology. 2009;5(8):469-79.  
75. Suki WN, Trimarchi H, Frommer JP. Relapsing membranous nephropathy. Response to therapy of relapses compared to that of the original disease. American journal of nephrology. 1999;19(4):474-9.  
76. Fellstrom BC, Barratt J, Cook H, Coppo R, Feehally J, de Fijter JW, et al. Targeted-release budesonide versus placebo in patients with IgA nephropathy (NEFIGAN): a double-blind, randomised, placebo-controlled phase 2b trial. Lancet (London, England). 2017;389(10084):211727.  
77. Coppo R, Peruzzi L, Amore A, Piccoli A, Cochat P, Stone R, et al. IgACE: a placebocontrolled, randomized trial of angiotensin-converting enzyme inhibitors in children and young people with IgA nephropathy and moderate proteinuria. Journal of the American Society of Nephrology : JASN. 2007;18(6):1880-8.  
78. Li PK, Leung CB, Chow KM, Cheng YL, Fung SK, Mak SK, et al. Hong Kong study using valsartan in IgA nephropathy (HKVIN): a double-blind, randomized, placebo-controlled study. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2006;47(5):751-60.  
79. Praga M, Gutierrez E, Gonzalez E, Morales E, Hernandez E. Treatment of IgA nephropathy with ACE inhibitors: a randomized and controlled trial. Journal of the American Society of Nephrology : JASN. 2003;14(6):1578-83.  
80. Sarafidis PA, Khosla N, Bakris GL. Antihypertensive therapy in the presence of proteinuria. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2007;49(1):12-26. 81. Pozzi C, Bolasco PG, Fogazzi GB, Andrulli S, Altieri P, Ponticelli C, et al. Corticosteroids in IgA nephropathy: a randomised controlled trial. Lancet (London, England). 1999;353(9156):883-7.  
82. Manno C, Torres DD, Rossini M, Pesce F, Schena FP. Randomized controlled clinical trial of corticosteroids plus ACE-inhibitors with long-term follow-up in proteinuric IgA nephropathy. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2009;24(12):3694-701.  
83. Lv J, Zhang H, Chen Y, Li G, Jiang L, Singh AK, et al. Combination therapy of prednisone and ACE inhibitor versus ACE-inhibitor therapy alone in patients with IgA nephropathy: a randomized controlled trial. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2009;53(1):26-32.  
84. Manno C, Gesualdo L, D'Altri C, Rossini M, Grandaliano G, Schena FP. Prospective randomized controlled multicenter trial on steroids plus ramipril in proteinuric IgA nephropathy. Journal of nephrology. 2001;14(4):248-52.  
85. Kim SM, Moon KC, Oh KH, Joo KW, Kim YS, Ahn C, et al. Clinicopathologic Characteristics of IgA Nephropathy with Steroid-responsive Nephrotic Syndrome. Journal of Korean Medical Science. 2009;24(Suppl 1):S44-9.  
86. Lai KN, Lai FM, Chan KW, Ho CP, Leung AC, Vallance-Owen J. An overlapping syndrome of IgA nephropathy and lipoid nephrosis. American journal of clinical pathology. 1986;86(6):716-23.  
87. Walker RG, Yu SH, Owen JE, Kincaid-Smith P. The treatment of mesangial IgA nephropathy with cyclophosphamide, dipyridamole and warfarin: a two-year prospective trial. Clinical nephrology. 1990;34(3):103-7.  
88. Woo KT, Lee GS. The treatment of mesangial IgA nephropathy with cyclophosphamide, dipyridamole and warfarin. Clinical nephrology. 1991;35(4):184. 89. Pankhurst T, Lepenies J, Nightingale P, Howie AJ, Adu D, Harper L. Vasculitic IgA nephropathy: prognosis and outcome. Nephron Clinical practice. 2009;112(1):c16-24. 90. Tang Z, Wu Y, Wang QW, Yu YS, Hu WX, Yao XD, et al. Idiopathic IgA nephropathy with diffuse crescent formation. American journal of nephrology. 2002;22(5-6):480-6. 91. Tumlin JA, Lohavichan V, Hennigar R. Crescentic, proliferative IgA nephropathy: clinical and histological response to methylprednisolone and intravenous cyclophosphamide. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2003;18(7):1321-9.  
92. Yoshikawa N, Ito H, Sakai T, Takekoshi Y, Honda M, Awazu M, et al. A controlled trial of combined therapy for newly diagnosed severe childhood IgA nephropathy. The Japanese Pediatric IgA Nephropathy Treatment Study Group. Journal of the American Society of Nephrology : JASN. 1999;10(1):101-9.  
93. Maes BD, Oyen R, Claes K, Evenepoel P, Kuypers D, Vanwalleghem J, et al. Mycophenolate mofetil in IgA nephropathy: results of a 3-year prospective placebo-controlled randomized study. Kidney Int. 2004;65(5):1842-9.  
94. Harmankaya O, Ozturk Y, Basturk T, Obek A, Kilicarslan I. Efficacy of immunosuppressive therapy in IgA nephropathy presenting with isolated hematuria. International urology and nephrology. 2002;33(1):167-71.  
95. Dillon JJ, Hladunewich M, Haley WE, Reich HN, Cattran DC, Fervenza FC. Rituximab therapy for Type I membranoproliferative glomerulonephritis. Clinical nephrology. 2012;77(4):290-5.  
96. Jones G, Juszczak M, Kingdon E, Harber M, Sweny P, Burns A. Treatment of idiopathic membranoproliferative glomerulonephritis with mycophenolate mofetil and steroids. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2004;19(12):3160-4.  
97. Sandoval D, Poveda R, Draibe J, Perez-Oller L, Diaz M, Ballarin J, et al. Efficacy of mycophenolate treatment in adults with steroid-dependent/frequently relapsing idiopathic nephrotic syndrome. Clin Kidney J. 2017;10(5):632-8.  
98. Jha V, Ganguli A, Saha TK, Kohli HS, Sud K, Gupta KL, et al. A randomized, controlled trial of steroids and cyclophosphamide in adults with nephrotic syndrome caused by idiopathic membranous nephropathy. Journal of the American Society of Nephrology : JASN. 2007;18(6):1899-904.  
99. Ruggenenti P, Ruggiero B, Cravedi P, Vivarelli M, Massella L, Marasa M, et al. Rituximab in steroid-dependent or frequently relapsing idiopathic nephrotic syndrome. Journal of the American Society of Nephrology : JASN. 2014;25(4):850-63.  
100. Fan L, Liu Q, Liao Y, Li Z, Ji Y, Yang Z, et al. Tacrolimus is an alternative therapy option for the treatment of adult steroid-resistant nephrotic syndrome: a prospective, multicenter clinical trial. International urology and nephrology. 2013;45(2):459-68.  
101. Barros RT R-AM, Dantas M, Kirsztajn GM, Sens YA. Glomerulopatias. Patogenia, Clínica e Tratamento. Sarvier, editor. São Paulo2012.  
102. EG B. Medicamentos de A a Z. ARTMED, editor. Porto Alegre 2012.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
PREDNISONA,CICLOSPORINA, CICLOFOSFAMIDA, ENALAPRIL, CAPTOPRIL, LOSARTANA POTÁSSICA, HIDROCLOROTIAZIDA, ESPIRONOLACTONA E  
FUROSEMIDA.  
Eu,______________________________________________________________ (nome do(a)  
paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de ciclofosfamida e ciclosporina, indicadas para o tratamento da síndrome nefrótica primária em adultos. Os termos médicos foram explicados e todas  
as dúvidas foram resolvidas pelo médico  
(nome do médico que prescreve). Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- dos sintomas e sinais do “estado nefrótico”;  
- da quantidade de proteínas na urina;  
- prevenção da insuficiência renal aguda e da insuficiência renal crônica progressiva.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- os riscos do uso da ciclosporina na gravidez ainda não são bem conhecidos; portanto, caso engravide, devo avisar imediatamente o médico;  
- a ciclofosfamida não deve ser usada durante a gestação pelo risco de má formação do feto;  
- efeitos adversos comuns da ciclofosfamida: náusea, vômitos, queda de cabelo, risco aumentado de infecções, anemia, toxicidade para o fígado e medula óssea, infecções na bexiga, risco de sangramento (redução do número de plaquetas);  
- efeitos adversos comuns da ciclosporina: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, crescimento da gengiva, aumento do colesterol e triglicerídios, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas;  
- o uso de corticosteroides, como a prednisona, pode gerar acúmulo localizado de gordura, estrias na pele, síndrome de cushing, alterações hormonais, irregularidade menstrual, facilitar infecções, sangramento gastrintestinal, hipertensão, insônia e nervosismo;  
- o captropil e o enalapril podem causar cefaleia e tosse, mais comumente. Outros efeitos menos comuns são febre, fadiga, calafrios, ansiedade, vertigem, náusea, diarreia, vômito e hipotensão;  
- a losartana potássica pode causar cefaleia, mais frequentemente. Outros eventos menos frequentes incluem tontura, fadiga, congestão nasal, infecção respiratória superior, hipotensão ortostática, náusea e diarreia;  
- a hidroclorotiazida pode causar, mais frequentemente, astenia, vertigem, fadiga, hiperglicemia, hiperuricemia, desequilíbrio hidroeletrolítico; alcalose hipoclrêmica, hipopotassemia e hiponatremia;  
- a espironolactona pode causar eventos adversos como irritação gastrintestinal e  
- hipopotassemia;  
- efeitos como hipotensão postural, náusea, glicosúria e exantema podem ser causados pelo uso  
- de furosemida;  
- contraindicações em casos de hipersensibilidade (alergia) aos fármacos;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que o medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.     (   ) Sim     (   ) Não  
Meu tratamento constará do seguinte medicamento:  
- (   ) captopril  
- (   ) ciclofosfamida  
- (   ) ciclosporina  
- (   ) enalapril  
- (   ) espironolactona  
- (   ) furosemida  
- (   ) hidroclorotiazida  
- (   ) losartana potássica  
<!-- Start of picture text -->
Local: _____________________________________ Data: _________________________<br>Nome do paciente: ________________________________________________________<br>Cartão Nacional de Saúde: __________________________________________________<br>Nome do Responsável legal: _________________________________________________<br>Documento de identificação do Resp. Legal: ____________________________________<br>______________________________________________<br>Assinatura do responsável legal ou do paciente<br>Médico Responsável: ________________________________CRM: __________UF:_____<br>______________________________________________<br>Assinatura e carimbo do médico<br><!-- End of picture text -->  
- (   ) prednisona  
<u>Nota 1 - Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente</u> em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
<u>Nota 2</u> - A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
<u>Nota 3 - A administração endovenosa de ciclofosfamida é compatível com o procedimentos</u>  
03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
<!-- Start of picture text -->
FLUXOGRAMA DE TRATAMENTO<br>SINDROME NEFROTICA PRIMARIA EM ADULTOS<br>“ee ceyetetca pra [ [Piaanéstico: clinico + laboratorial + anatomopatolégico + diferencial L]<br>Acompanhamento em Servico ‘MYr e didasstricSogeraisde sal, de tratamento:uso judcioso de diurético para tratamento de|<br>Especializado em Nefrologia jedema, Coe eencimaoreo oe epeiecnality<br>fr atcoanuerae 0 da proteiniria,  no oo de de estatinas ondmoms para uaabe tratamento  erbbkcos da dslipidemia|<br>Sequir medidas gerais de tratamento de<br>‘acordo como. meo doenca priméria a =<br>¥presenca de edema, dslpidemia e excreqiourindriaacim de 39<br>aaa u9  indoe_proteinalcredde proteina por 173 4 horas ou acin i ninade 80 malkg/24 Noras<br>|acima de 3.<br>No= critériosincluso?by de Sim [Ciitérios de exclu sao (PC) em amostra aederis de wing<br>ExctusdoEy, |, seraji jimpossibiidadeV Hipersensibilidadede adesoou e acompanhamentocontraindicaco continuo.aos medicamentos,|<br>exclusao? imedcamento*.VObservar também critérios de exclusdo especificos de cada|<br>Bo<br>ca [sar]<br>Médoriscoou dealto Forma Forma<br>progresso para rapidamente rapidamente<br>Noo \ insuficiéncia sim \__progressva? | prosressva?<br>renal? Ne Ne. sim<br>+ prednisona + corticoide<br>sim sim -<br>Nao.<rsoa > a>, pulsoterapia<br>Manter Novo curso de it Manter Resisténcia?<br>tratamento corticoide || “iclosponna tratamentoe| —[ :<br> monitorar| monitorar | Nao<br>Recidivas<br>dependéncia, tratamento e<br>a Intoler&nciaresisténcia oua0 ‘sim monitorar<br>corticoide?<br>tratamentoMarke, Associarem baixacorticoide dosea<br>monitorar e ciclofosfamidaciclosporina ou<br>paleYpaa Eicopomna:Sdospy neo:ceeasia em atividade,das hiperten:hipertensioevidéncias dearterialCb0Inarnino controlada,da.medula taxaaxadssea de fitraco( contagemglomerularde leucécitoslar abatko abalko abaiode 40 mide<br>Bouinet nouvetios Sans ds0, 00mm 1 ou Hacuctse aban 6 100 0 ia m 0<br><!-- End of picture text -->  
**Figura 1 -** Fluxograma de tratamento e de dispensação de ciclosporina e de ciclofosfamida  
<!-- Start of picture text -->
Paciente solicita o  CID-10:  N04.0, N04.1, N04.2, N04.3, N04,4,<br>N04.5, N04.6, N04.7, N04.8, N04.9<br>medicamento<br>Exame:<br>übiópsia renal<br>ücreatinina sérica<br>üproteinúria de 24h ou índice de proteína/<br>creatinina em amostra de urina aleatória<br>ücolesterol total<br>Possui LME  üLDL<br>corretamente  üHDL<br>ütriglicerídeos<br>preenchido e demais<br>üglicemia de jejum<br>Não documentos exigidos? Sim Para ciclofosfamida ainda:<br>ühemograma<br>ü β -HCG para mulheres em idade fértil<br>Dose:<br>ü Ciclofosfamida:  1,5-3 mg/kg/dia, VO<br>ü Ciclosporina:  3-5 mg/kg/dia, VO<br>Orientar o<br>CID-10, exames e<br>paciente dose estão de acordo<br>Não Sim<br>com o preconizado<br>pelo PCDT?<br>Encaminhar o<br>Realizar entrevista<br>paciente ao<br>farmacoterapêutica inicial<br>médico assistente<br>com o farmacêutico<br>Processo<br>Não Sim<br>deferido?<br>Exames necessários para monitorização:<br>ücreatinina sérica, proteinúria 24 horas ou índice proteína/ Não dispensar e<br>Orientar o<br>creatinina em amostra de urina aleatória, albumina sérica,  justificar ao<br>colesterol total, LDH, HDL, triglicerídeos, EQU, hemograma  paciente<br>e glicose.  Periodicidade:  a cada 3 a 6 meses para  paciente<br>pacientes em remissão e mensal para os pacientes com<br>doença ativa<br>Para ciclofosfamida ainda:<br>ühemograma  e plaquetas.  Periodicidade:  a cada semana<br>üTGO e TGP.  Periodicidade:  a cada mês  Dispensação a cada mês de<br>Para ciclosporina ainda:  tratamento<br>ücreatinina sérica, nível sérico de ciclosporina.  Entrevista<br>Periodicidade: mês  a cada semana no 1° mês e após a cada  farmacoterapêutica de<br>monitorização<br>Paciente apresentou alteração<br>nos exames não compatível<br>Sim com o curso do tratamento ou  Não<br>eventos adversos<br>significativos?<br>Dispensar e solicitar parecer<br>Dispensar<br>do médico assistente<br><!-- End of picture text -->  
**Figura 2 -** Fluxograma para dispensação de prednisona  
<!-- Start of picture text -->
Paciente solicita o<br>medicamento<br>CID-10:  N04.0, N04.1, N04.2, N04.3, N04,4,<br>N04.5, N04.6, N04.7, N04.8, N04.9<br>Dose:<br>ü  Prednisona:  0,5 a 3 mg/kg/dia, VO<br>Possui receita médica<br>atual e a dose está de<br>Não acordo com o PCDT? Sim<br>Orientar o<br>Realizar entrevista<br>paciente<br>farmacoterapêutica inicial<br>com o farmacêutico<br>Orientar o<br>paciente<br>Dispensação a cada mês de<br>tratamento<br>Entrevista<br>farmacoterapêutica de<br>monitorização<br>Paciente apresentou eventos<br>adversos significativos?<br>Sim Não<br>Dispensar e solicitar<br>Dispensar<br>parecer do médico<br>assistente<br><!-- End of picture text -->  
**Figura 3 –** Fluxograma de atendimemto na Assistência Farmacêutica da Secretaria de  
Saúde

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **FICHA FARMACOTERAPÊUTICA** -->
SÍNDROME NEFRÓTICA PRIMÁRIA EM ADULTOS

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **1 DADOS DO PACIENTE** -->
Nome: __________________________________________________________________ CNS:______________________________RG:__________________________________ DN: ___/___/____  Idade: _____  Peso: __________   Altura: _________ Sexo:  F  M Endereço: _______________________________________________________________ Telefones:_______________________________________________________________ Médico assistente: ____________________________________________  CRM:_______ Telefones: _______________________________________________________________ Nome do cuidador: ________________________________________________________ Cartão Nacional de Saúde: ___________________ RG:__________________________

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2 AVALIAÇÃO FARMACOTERAPÊUTICA** -->
- 2.1 Quais as causas da síndrome nefrótica primária?  
- glomeruloesclerose segmentar e focal (GESF)  
- glomerulonefrite membranosa idiopática (GNMI)  
- alterações glomerulares mínimas (AGM)  
- glomerulonefrite membranoproliferativa (GNMP)  
- glomerulonefrite por IgA (GNIgA)  
- 2.2 Apresenta outras doenças diagnosticadas?  
- não  
- sim  Quais?__________________________________________________________  
2.3 Faz uso de outros medicamentos?  não  sim <u> Quais?</u>  
|**Nome comercial**|**Nome genérico**|**Dose total/dia; Via**|**Data de**<br>**início**|**Prescrito**|
|---|---|---|---|---|
|||||nãosim|
|||||nãosim|
|||||nãosim|
|||||nãosim|  
- 2.4 Já apresentou reação alérgica a medicamentos?  
- não  
- sim  Quais reações? ____________________________  A que medicamentos?________________________________________

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3 MONITORIZAÇÃO DO TRATAMENTO** **<u>Exames laboratoriais</u>** -->
||**Inicial **|**1° mês**|**2° mês**|**3° mês**|**4°mês**|**5° mês**|**6° mês**|
|---|---|---|---|---|---|---|---|
|Dataprevista*||||||||
|Data||||||||
|Hemoglobina||||||||
|Leucócitos||||||||
|Neutrófilos||||||||  
|Linfócitos|||||||
|---|---|---|---|---|---|---|
|Plaquetas|||||||
|ALT|||||||
|AST|||||||
|Albumina|||||||
|Glicose|||||||
|Creatinina|||||||
|Colesterol total|||||||
|HDL|||||||
|LDL|||||||
|Triglicerídeos|||||||
|EQU**|||||||
|Ciclosporina sérica|||||||
||**7° mês**|**8° mês**|**9° mês**|**10° mês**|**11°mês**|**12° mês**|
|Dataprevista*|||||||
|Data|||||||
|Hemoglobina|||||||
|Leucócitos|||||||
|Neutrófilos|||||||
|Linfócitos|||||||
|Plaquetas|||||||
|ALT|||||||
|AST|||||||
|Albumina|||||||
|Glicose|||||||
|Creatinina|||||||
|Colesterol total|||||||
|HDL|||||||
|LDL|||||||
|Triglicerídeos|||||||
|EQU**|||||||
|Ciclosporina sérica|||||||  
*Os exames e a sua periodicidade variam conforme o medicamento. Os pacientes em uso de ciclofosfamida deverão realizar hemograma semanalmente durante o tratamento. **EQU - Exame Qualitativo da Urina

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: 3.1 Houve alteração significativa dos exames? -->
não  Dispensar o(s) medicamento(s)sim  Dispensar e encaminhar o paciente ao médico assistente (a dose deve ser reavaliada ou o medicamento, suspenso)  
3.2 Apresentou sintomas que indiquem eventos adversos? (Ver o TER.) não  Dispensar o(s) medicamento(s) sim  Passar para pergunta 3.3

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: 3.3 O(s) evento(s) adverso(s) necessita(m) de avaliação do médico assistente? -->
não  Dispensar o(s) medicamento(s)sim  Dispensar e encaminhar o paciente ao médico assistente.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **SÍNDROME NEFRÓTICA PRIMÁRIA EM ADULTOS** -->
 CICLOFOSFAMIDA  CICLOSPORINA  PREDNISONA  FUROSEMIDA   
ESPIRONOLACTONA  ENALAPRIL  CAPTOPRIL  LOSARTANA  HIDROCLOROTIAZIDA  
ESTE É UM GUIA QUE CONTÉM ORIENTAÇÕES SOBRE SUA DOENÇA E O MEDICAMENTO QUE VOCÊ  
ESTÁ RECEBENDO GRATUITAMENTE PELO SUS.  
SEGUINDO AS ORIENTAÇÕES, VOCÊ TERÁ MAIS CHANCE DE SE BENEFICIAR COM O TRATAMENTO.  
- **1 DOENÇA**  
- É uma doença que afeta primeiramente os rins, sendo caracterizada por um conjunto de sinais e sintomas que incluem inchaço, perda anormal de proteína na urina e aumento de colesterol e triglicerídeos no sangue.  
- As complicações da doença incluem infecções, formação de coágulos nas veias ou artérias (trombose venosa ou arterial), insuficiência renal aguda ou crônica, desnutrição e alterações hormonais, entre outras.  
- **2 MEDICAMENTO**  
- Estes medicamentos não curam a doença, porém melhoram os sinais e sintomas e previnem a insuficiência renal.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3 GUARDA DO MEDICAMENTO** -->
- Conserve os medicamentos na embalagem original, bem fechados.  
- Mantenha os medicamentos fora do alcance das crianças.  
- Guarde o medicamento protegido do calor, ou seja, evite lugares onde exista variação de temperatura (cozinha e banheiro).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **4 ADMINISTRAÇÃO DO MEDICAMENTO** -->
- Tome as drágeas/cápsulas/comprimidos com água, sem mastigar, abrir ou triturar, de preferência durante as refeições.  
- Tome exatamente a dose e nos dias que o médico indicou, estabelecendo um mesmo horário todos os dias.  
- Em caso de esquecimento de uma dose tome assim que lembrar. Não tome a dose em dobro para compensar a que foi esquecida.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **5 REAÇÕES ADVERSAS** -->
- Apesar dos benefícios que o medicamento pode trazer, é possível que apareçam algumas reações adversas, desagradáveis, que variam de acordo com o medicamento, tais como dor de cabeça, náusea, vômitos, diarreia, perda de cabelo, perda de apetite, reações alérgicas, febre, calafrios, falta de ar, entre outras  
- Se houver algum destes ou outros sinais/sintomas comunique-se com o médico ou farmacêutico.  
- Ver as reações adversas que constam no Termo de Esclarecimento e Responsabilidade, documento assinado por você, ou seu responsável legal, e pelo médico.  
- **6 USO DE OUTROS MEDICAMENTOS**  
- Não faça uso de outros medicamentos sem o conhecimento do médico ou orientação de um profissional de saúde.  
- **7 REALIZAÇÃO DOS EXAMES DE LABORATÓRIO**  
- A realização dos exames garante uma correta avaliação sobre o que o medicamento está fazendo no seu organismo. Em alguns casos pode ser necessário ajustar a dose ou até interromper o tratamento.  
- **8 OUTRAS INFORMAÇÕES IMPORTANTES**  
- **Ciclosporina:** os riscos de uso na gravidez ainda não são bem conhecidos; portanto, caso engravide, avise imediatamente ao médico;  
- **Ciclofosfamida:** não deve ser usada durante a gestação pelo risco de má formação do feto.  
- Estes medicamentos diminuem as defesas do organismo, por isso, evite contato com pessoas com doenças infecciosas.  
- **9 RENOVAÇÃO DA CONTINUIDADE DO TRATAMENTO**  
- Converse com o farmacêutico do SUS para saber quais os documentos e exames são necessários para continuar recebendo os medicamentos.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **10 EM CASO DE DÚVIDAS** -->
- Se você tiver qualquer dúvida que não esteja esclarecida neste guia, antes de tomar qualquer atitude, procure orientação com o médico ou farmacêutico do SUS.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **11 OUTRAS INFORMAÇÕES** -->
______________________________________________________________________________ ______________________________________________________________________________ ______________________________________________________________________________ ______________________________________________________________________________  
SE, POR ALGUM MOTIVO, NÃO USAR O MEDICAMENTO, DEVOLVA-O À FARMÁCIA DO SUS DE ONDE O RETIROU.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **A) Metodologia** -->
Com a presença de sete membros do Grupo Elaborador, sendo três especialistas e quatro metodologistas, e dois representantes do Comitê Gestor, uma reunião presencial para definição do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Síndrome Nefrótica em Adulto foi conduzida. Todos os componentes do Grupo Elaborador preencheram os formulários de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde, como parte dos resultados.  
Inicialmente, a macroestrutura do PCDT foi estabelecida considerando a Portaria N° 375/SAS/MS, de 10 de novembro de 2009(97), como roteiro para elaboração dos PCDT, e as seções do documento foram definidas.  
Após essa definição, cada seção foi detalhada e discutida entre os integrantes do Grupo Elaborador, com o objetivo de discutir as condutas clínicas e identificar as tecnologias que seriam consideradas. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema do presente PCDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
<!-- Start of picture text -->
•População ou condição clínica<br>P<br>•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos<br>observacionais<br>I<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>•Controle, de acordo com tratamento/níveis de<br>C exposição do fator/exames disponíveis no SUS<br>•Desfechos: sempre que possível, definidos a<br>O priori, de acordo com sua importância<br><!-- End of picture text -->  
**Figura A –** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
Ao final dessa dinâmica, 14 questões de pesquisa foram definidas para o presente PCDT ( **Quadro A** ).  
**Quadro A –** Questões de pesquisa elencadas pelo Grupo Elaborador do Protocolo Clínico e Diretrizes Terapêuticas  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Qual o desempenho diagnóstico do exame<br>P/C(Razão proteína/creatinina) em amostra isolada<br>de urina em relação a proteinúria em 24h?|Diagnóstico|
|**2**|Qual a eficácia e a segurança do rituximabe (RTX)<br>para o tratamento de Alterações Glomerulares<br>Mínimas<br>(AGM)<br>com<br>recidivas<br>frequentes,<br>resistência<br>aos<br>tratamentos<br>anteriores<br>ou<br>imunossupressão dependente? (Avaliar também a<br>indicação de uso do RTX)|Tratamento<br>Medicamentoso|
|**3**|Qual a eficácia e a segurança do micofenolato<br>(sódico e mofetila) (MMF) para o tratamento de<br>Alterações Glomerulares Mínimas (AGM) com<br>recidivas frequentes, resistência aos tratamentos<br>anteriores ou imunossupressão dependente?|Tratamento<br>Medicamentoso|
|**4**|Qual a eficácia e a segurança do tacrolimo (TAC)<br>para o tratamento de Alterações Glomerulares<br>Mínimas<br>(AGM)<br>com<br>recidivas<br>frequentes,|Tratamento<br>Medicamentoso|  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
||resistência<br>aos<br>tratamentos<br>anteriores<br>ou<br>imunossupressão dependente?||
||Qual a eficácia e a segurança do Rituximabe (RTX)<br> <br> <br>||
|**5**|para<br>o<br>tratamento<br>de<br>Glomeruloesclerose<br>Segmentar e Focal (GESF) com recidivas<br>frequentes, resistência aos tratamentos anteriores ou<br>imunossupressão dependente? (Avaliar indicação<br>de uso do RTX)|Tratamento<br>Medicamentoso|
|**6**|Qual a eficácia e a segurança do micofenolato<br>(sódico e mofetila) para o tratamento de<br>Glomeruloesclerose Segmentar e Focal (GESF)<br>com<br>recidivas<br>frequentes,<br>resistência<br>aos<br>tratamentos<br>anteriores<br>ou<br>imunossupressão<br>dependente?|Tratamento<br>Medicamentoso|
|**7**|Qual a eficácia e a segurança do tacrolimo (TAC)<br>para<br>o<br>tratamento<br>de<br>Glomeruloesclerose<br>Segmentar e Focal (GESF) com recidivas<br>frequentes, resistência aos tratamentos anteriores ou<br>imunossupressão dependente?|Tratamento<br>Medicamentoso|
|**8**|Qual a eficácia e segurança do clorambucila em<br>relação a ciclofosfamida (ambos associados à<br>prednisona<br>ou<br>metilprednisolona)<br>para<br>Glomerulonefrite Membranosa?|Tratamento<br>Medicamentoso|
|**9**|Qual a eficácia e a segurança do uso de<br>ciclofosfamida ev e oral (ambos associados à<br>prednisona<br>ou<br>metilprednisolona)<br>para<br>Glomerulonefrite Membranosa?|Tratamento<br>Medicamentoso|
|**10**|Qual a eficácia e a segurança do Rituximabe para o<br>tratamento de Glomerulonefrite Membranosa com<br>recidivas frequentes, resistência aos tratamentos<br>anteriores ou imunossupressão dependente?|Tratamento<br>Medicamentoso|
|**11**|Qual a eficácia e a segurança do tacrolimo em<br>relação à ciclosporina para o tratamento de<br>Glomerulonefrite Membranosa com recidivas|Tratamento<br>Medicamentoso|  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
||frequentes, resistência aos tratamentos anteriores ou<br>imunossupressão dependente?||
|**12**|Qual a eficácia e a segurança das terapias<br>imunossupressoras (tacrolimo, rituximabe, ácido<br>micofenólico e prednisona) para o tratamento de<br>glomerulonefrite<br>membranoproliferativa<br>ou<br>mesangiocapilar (primárias ou idiopáticas) tipo I em<br>adultos?|Tratamento<br>Medicamentoso|
|**13**|Quais as terapias imunossupressoras para o<br>tratamento de nefropatia por IgA(NIgA) em<br>adultos?<br>(Considerar<br>TAC,<br>prednisona<br>e<br>metilprednisolona,<br>MMF,<br>ciclofosfamida,<br>azatioprina)|Tratamento<br>Medicamentoso|
|**14**|Qual a utilidade da contagem de linfócitos B CD19<br>no monitoramento da eficácia do rituximabe para o<br>tratamento da glomerulonefrite membranosa?|Diagnóstico/monitorização|  
Consideraram-se neste documento para análise aquelas tecnologias com indicação de uso específico para Síndrome Nefrótica em bula. De toda maneira, todas as questões, mesmo aquelas referentes a tecnologias _off-label_ , foram utilizadas para dar subsídio à escrita do texto do presente PCDT.  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa  
forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com metaanálise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiuse considerar os estudos originais dessas revisões, por serem mais completos em relação às descrições das variáveis clínico-demográficas e desfechos de eficácia e segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados, prospectivos e depois os retrospectivos, e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo de 10 incluídos no estudo. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias, em formato PDF correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do processo de elaboração do PCDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. Essa extração foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que  
estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (98); os ensaios clínicos randomizados, pela ferramenta de risco de viés da Cochrane(99); os estudos observacionais, pela ferramenta Newcastle-Ottawa(100); e os estudos de acurácia diagnóstica, pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2) (101). Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas _a priori_ como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo deste Apêndice.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **B) Questões de Pesquisa** -->
**Questão de Pesquisa 1 -** Qual o desempenho diagnóstico do exame P/C (protein/creatinine ratio) em amostra isolada de urina em relação a proteinúria em 24 h?

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
(((("Nephrotic Syndrome"[Mesh] OR nephrotic syndrome OR nephrotic proteinuria OR primary glomerulopathies)) AND ((((protein-to-creatinine ratio OR protein/creatinine ratio OR protein creatinine ratio))) AND ("Proteinuria"[Mesh] OR proteinuria OR 24 hour proteinuria OR 24h proteinuria OR 24-h proteinuria OR urinary protein excretion))))  
Resultados: 197 referências Data de acesso:28/09/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Embase:** -->
(('nephrotic syndrome'/exp OR 'nephrotic syndrome' OR 'primary glomerulonephritis'/exp OR 'primary glomerulonephritis' OR 'nephrotic proteinuria' OR 'primary glomerulopathies') AND [embase]/lim) AND (('protein-to-creatinine ratio' OR 'protein/creatinine ratio' OR 'protein creatinine ratio'/exp OR 'protein creatinine ratio') AND [embase]/lim) AND (('proteinuria'/exp OR 'proteinuria' OR '24 hour proteinuria' OR '24h proteinuria' OR '24-h proteinuria' OR 'urinary protein excretion') AND [embase]/lim)  
Resultados: 174 referências  
Data de acesso: 28/09/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
Por meio das estratégias de busca acima foram recuperadas 371 referências. Após a remoção de 67 duplicatas, 304 artigos foram avaliados por meio da leitura de títulos e resumos. Duzentos e noventa e quatro artigos foram excluídos nessa etapa. Sete<sup>102-108</sup> referências foram consideradas elegíveis.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela 1** . A **Tabela 2** apresenta os desfechos  
de acurácia diagnóstica reportados nos estudos.  
**Tabela 1 –** Descrição das características dos participantes e dos estudosque compararam a relação proteína-creatinina e proteinúria na urina de 24 horas  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**estudo**|**Objetivo**|**Amostra**<br>|**Índice**|**Referên**<br>**cia**|**Idade,**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**|**Variáveis basais**<br>**relevantes da**<br>**população, mediana**<br>**(IQR)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|**Hogan**<br>**et al.**<br>**2016(10**<br>**2)**|Transver<br>sal|Compreender<br>a relação entre<br>UPCR e<br>P24hem<br>amostras<br>aleatórias de<br>urina|Coorte de<br>pacientes com<br>doenças<br>glomerulares;<br>n: 226<br>pacientes<br>adultos/ 666<br>amostras;|UPCRa<br>mostras<br>aleatóri<br>as de<br>urina|P24h|Adultos<br>com ≥18<br>anos: 226|192 (64) de<br>302 (adultos<br>e pediátricos)|P24h (g): 1,0 (0,3; 2,3)<br>Cr na urina 24h (g): 0,8<br>(0,5; 1,1)<br>UPCR 24h: 1.4 (0,4;<br>2,9)|Moderado<br>Diferença substancial de<br>pacientes iniciais e<br>incluídos na análise de<br>acurácia|
|**Monteir**<br>**o et al.**<br>**2012(10**<br>**3)**|Transver<br>sal|Verificar se<br>UPCR está<br>correlacionad<br>o com P24h|Pacientes com<br>diferentes<br>graus de<br>falência renal;<br>n: 159|UPCR<br>amostr<br>as<br>únicasd<br>e urina|P24h|59.7<br>(14.7)|93 (58.4)|P24h (mg), média<br>(variação): 550 (33-<br>17168)<br>Crsérica (mg/dl), média<br>(DP):1.96 (1.59)<br>UPCR 24h, média<br>(variação): 492.42<br>(36.35-11652.41)|Alto (não é possível saber<br>se o teste índice foi<br>realizado sem o<br>conhecimento do<br>resultado do teste padrão<br>e vice-versa).|
|**Sadjadi**<br>**eJaipau**<br>**l, 2010**<br>**(104)**|Transver<br>sal|Testara<br>hipótese de<br>que a força da<br>correlação<br>entre UPCR e<br>a P24h<br>variaria de<br>acordo com o<br>nível de<br>atividade|Pacientes<br>ambulatoriais,<br>com<br>proteinúria,clin<br>icamente<br>estáveis<br>veteranos dos<br>Estados<br>Unidos; n:48|UPCR<br>amostr<br>as<br>aleatóri<br>as de<br>urina|P24h|Total:64.<br>5 (12.1)<br>FI:69.8<br>(13.1)<br>FSA:<br>65.8 (5.7)<br>FA: 61<br>(11.1)|FI:7 (90)<br>FSA: 15<br>(100)<br>FA: 25 (100)|Depuração de Cr<br>(mg/min), média (DP):<br>FI:53.7 (40.3)<br>FSA: 45 (33.1)<br>FA: 60.9 (35.2)|Baixo|  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**estudo**|**Objetivo**<br>|**Amostra**|**Índice**|**Referên**<br>**cia**|**Idade,**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**|**Variáveis basais**<br>**relevantes da**<br>**população, mediana**<br>**(IQR)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|||física do<br>paciente||||||||
|**Antune**<br>**s et al.**<br>**2008**<br>**(105)**|Transver<br>sal|Compreender<br>a relação entre<br>UPCR e P24h|Pacientes com<br>glomerulopatia<br>s primárias sob<br>tto com<br>imunossupress<br>ores ou IECA;<br>n:41 pacientes|UPCR|P24h|38 (17)|25 (61)|P24h (g), mediana (mín;<br>máx): 6.7 (0.5–28.0)<br>Depuração de Cr<br>(mg/min), média (DP):<br>77.8 (36.2)<br>UPCR 24h, mediana<br>(mín; máx):5.0 (0.35–<br>13.0)|Baixo|
|**Morales**<br>**et al.**<br>**2004**<br>**(106)**|Transver<br>sal|Determinar se<br>UPCR<br>fornece uma<br>quantificação<br>precisa da<br>excreção de<br>P24h|Pacientes<br>ambulatoriais<br>com<br>glomerulonefrit<br>e primária e<br>diferentes<br>níveis de<br>função renal;<br>n:172|UPCR<br>amostr<br>as<br>únicas<br>de<br>urina|P24h|42 (15)|92 (54)|Todos<br>P24h (g), média (DP):<br>3.2 (4.2)<br>Creatinina na urina 24h<br>(g), média (DP): 1.26<br>(0.31)<br>Grupo 1, 2 e 3*<br>respectivamente:<br>P24h (g), média (DP):<br>3.0 (4.4);3.8 (5.1);2.9<br>(3.0)<br>Cr na urina 24h (g),<br>média (DP): 1.33 (0.30);<br>1.29 (0.34);1.17 (0.26);<br>p: 0.011|Baixo|  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**estudo**|**Objetivo**|**Amostra**|**Índice**|**Referên**<br>**cia**|**Idade,**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**|**Variáveis basais**<br>**relevantes da**<br>**população, mediana**<br>**(IQR)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|||Analisar a<br>viabilidade de|Pacientes com|||||||
|**Kristal**||usar amostras|diferentes|||53.6||||
|**et al.**<br>**1988**<br>**(107)**|Transver<br>sal|de urina<br>UPCR para<br>analisar a<br>quantidade de<br>proteinúria|níveis de<br>função renal e<br>proteinúria; n:<br>51|UPCR|P24h|(min-<br>máx.: 15-<br>75)|30 (59)|NR|Baixo|
||||Casos:<br>Pacientes com<br>doenças renais<br>com função<br>renal estável;|UPCR||Casos: 43<br>(min-<br>máx.: 13-|Casos: 22|Casos Cr sérica normal<br>(1.5mg/dl), n: 26<br>Casos Cr sérica<br>moderadamente|Alto<br>Caso-controle; população<br>não está descrita<br>adequadamente; não é<br>possível saber se a|
|**Gisberg**<br>**et al.**<br>**1983(10**|Caso-<br>controle|Compreender<br>a relação entre<br>UPCR  P24h|n:46|amostr<br>as<br>aleatóri|P24h|76)<br>Controles|(48)|comprometida (1.5- 4<br>mg/dl), n: 13|amostra foi randômica ou<br>de pacientes consecutivos;<br>não é possível ter certeza|
|**8)**||e|Controle: sem<br>evidência<br>clínica ou<br>histórico de<br>doença renal;<br>n: 30|as de<br>urina||: NR<br>(min-<br>máx.: 26-<br>57)|Controles: 10<br>(33)|Casos Cr sérica<br>gravemente<br>comprometida-falência<br>renal avançada (> 4<br>mg/dl), n: 7|se houve mascaramento<br>dos avaliadores dos<br>resultados dos testes de<br>referência e índice;<br>coletas de urina em dias<br>diferentes|  
UPCR: relação proteína-creatinina; P24H:proteinúria de 24 horas; Cr: creatinina; tto: tratamento; IECA: inibidores da enzima conversora da angiotensina; FI: fisicamente inativos; FSA: fisicamente semi- ativos; FA; fisicamente ativos;*grupo 1: pacientes com função renal normal (Ccr ≥90 ml/min), n: 53; grupo 2: falência renal moderada (40 ≤ Ccr<90 ml/min), n:56; grupo 3: função renal moderadamente ou gravemente comprometida (10 ≤ Ccr <40 ml/min), n:63.  
**Tabela 2 –** Desfechos de acurácia diagnóstico reportados nos estudos que compararam a relação proteína-creatinina e proteinúria de 24 horas  
|**Autor,**<br>**ano**|**População**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||Detectar proteinúria:|Detectar<br>proteinúria:|Detectar<br>proteinúria:<br>>0.5 g:0.91<br>>1.0 g:|Detectar<br>proteinúria:<br>>0.5 g:0.89<br>>1.0 g:||Detectar<br>proteinúria:<br>>0.5 g:<br>0,85|<br>Detectar<br>proteinúria:<br>>0.5 g:<br>0.91<br>>10 g:|
|**Hogan et**|Adultos com<br>doenças|||>0.5 g:0.98<br>>1.0 g: 0.91|<br>>0.5 g:0.59<br>>10 : 072|0.88<br>>2.0 g:|0.79<br>>2.0 g:||>1.0 g:<br>0,90|.<br>0.86<br>>20 :|
|**al. 2016**<br>**(102)**|glomerulares<br>(N:152)|UPCR|P24h|>2.0 g: 0.91<br>>3.0 g: 0.59|. g .<br>>2.0 g: 0.70<br>>30 : 092|0.76<br>>3.0 g:|0.88<br>>3.0 g:|r: 0.60|>2.0 g:<br>0,85|. g<br>0.81<br>>30 :|
|||||>6.0 g: 0.35|. g .<br>>60 g: 097|0.78|0.83||>3.0 g:|. g<br>082|
|||||>10.0 g: 0.50|.  .<br>>10.0 g: 0.99|>6.0 g:<br>0.67<br>>10.0 g:<br>0.83|>6.0 g:<br>0.89<br>>10.0 g:<br>0.97||0.87<br>>6.0 g:<br>0.87|.<br>>6.0 g:<br>0.88<br>>10.0 g:<br>0.96|
|||||||||Todos (n:159):|||
|**Monteiro**<br>**et al.**<br>**2012**<br>**(103)**|Pacientes com<br>diferentes graus<br>de falência<br>renal; n: 159|UPCR|P24h|NR|NR|NR|NR|r: 0.91; p<0.05<br>Proteinúria<br>24h <300 mg<br>(n: 60):<br>r: 0.498;<br>p<0.001|NR|NR|  
|**Autor,**<br>**ano**|**População**|**Índice**<br>**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||Proteinúria<br>24h 300-3499<br>mg (n: 77):<br>r: 0.828;<br>p<0.001<br>Proteinúria<br>24h >3500 mg<br>(n: 22):|||
||||||||r: 0.181; p:<br>0.420|||
||||||||**De acordo**<br>**com TFGe**<br>**(ml/min/1.73**<br>**m**<sup>**2**</sup>**):**<br>TFGe≥ 60<br>(n:62):|||
||||||||r: 0.88; p<<br>0.001|||
||||||||TFGe59-30 (n:<br>49):<br>r: 0.899;|||
||||||||p<0.001<br>TFGe< 30 (n:|||
||||||||39):|||  
|**Autor,**<br>**ano**|**População**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**<br>r: 0.901;<br>p<0.001|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Sadjadi**<br>**eJaipaul,**<br>**2010**<br>**(104)**|Pacientes<br>ambulatoriais<br>clinicamente<br>estáveis<br>veteranos dos<br>Estados Unidos;<br>n:48|UPCR|P24h|NR|NR|NR|NR|**Geral:**r: 0.75;<br>p<0.01<br>**P24h**<br>**mg/dia/1.73m**<sup>**2**</sup><br>**>3500:**<br>Todos: r: 0.45,<br>p<0.05;<br>FI: r:0.99,<br>p<0.001;<br>FSA: r: 0.44;<br>FA: r: 0.44<br>**P24h**<br>**mg/dia/1.73m**<sup>**2**</sup><br>**<3500:**<br>Todos: r: 0.63,<br>p<0.001;|NR|NR|  
|**Autor,**<br>**ano**|**População**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**dtiã **|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||**eermnaço **|||
|||||||||FI: r:0.95,<br>p<0.01;<br>FSA: r: 0.54;<br>FA: r: 0.59,<br>p<0.05|||
|||||||||Basal: r: 0.90<br>1° mês: r: 0.90|||
|||||||||2° mês: r: 0.92<br>3° mês: r:<br>0.89|||
|||||||||4° mês: r:|||
|||||||||0.91|**P24 > 0.20**||
|||||||||5° mês: r: 0.93|**g**: 0.99 (IC||
|**Antunes**<br>**et al.**<br>**2008**<br>**(105)**|Pacientes com<br>glomerulopatias<br>primárias (n: 41)|UPCR|P24h|NR|NR|NR|NR|6° mês: r: 0.94<br>< 0.001 para<br>todas as<br>correlações<br>**Coeficientes**<br>**de correlação**<br>**intra-**<br>**individual:**<br>UPCR: 25%<br>P24h: 24%<br>**Coeficientes**|95%: 0.97–<br>1.00)<br>**P24 > 3.5**<br>**g:**0.99 (IC<br>95%: 0.99–<br>1.00)|NR|
|||||||||**Kappa:**<br>Basal: 1|||  
|**Autor,**<br>**ano**|**População**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||Aos 6 meses:<br>0.86|||
|**Morales**<br>**et al.**<br>**2004**<br>**(106)**|Pacientes<br>ambulatoriais<br>com<br>glomerulonefrite<br>primária e<br>diferentes níveis<br>de função renal;<br>n:172|UPCR|P24h|**P24h ≥0.20**<br>**(Proteinúria**<br>**anormal)**<br>**Valor-limite* 0.20,**<br>**0.25 e 0.30:**<br>Todos: 99, 97, 93<br>Grupo 1: 98, 95,93<br>Grupo 2: 98, 94, 92<br>Grupo 3: 100, 100,<br>93<br>**P24h ≥3.5**<br>**(Proteinúria**<br>**nefrótica)**<br>**Valor-limite*2.6,**<br>**3.0 e 3.5:**<br>Todos: 100, 89, 81<br>Grupo 1: 100, 86, 79<br>Grupo 2: 100, 84, 79<br>Grupo 3: 100, 95, 84|**P24h ≥0.20**<br>**(Proteinúria**<br>**anormal)**<br>**Valor-limite***<br>**0.20, 0.25 e 0.30:**<br>Todos:<br>96,100,100<br>Grupo 1: 92, 100,<br>100<br>Grupo 2:<br>100,100,100<br>Grupo 3:<br>100,100,100<br>**P24h ≥3.5**<br>**(Proteinúria**<br>**nefrótica)**<br>**Valor-limite*2.6,**<br>**3.0 e 3.5:**<br>Todos: 93, 97, 98<br>Grupo 1: 92,<br>95,97<br>Grupo 2: 95,100,<br>100|NR|NR|**Grupo 1:**<br>r:0.91, R<sup>2</sup>:<br>0.84; P<0.001<br>**Grupo 2:**<br>r:0.95, R<sup>2</sup>:<br>0.90; P<0.001<br>**Grupo 3**:<br>r:0.98, R<sup>2</sup>:<br>0.96; P<0.001|NR|NR|  
|**Autor,**<br>**ano**|**População**|**Índice**<br>**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|  
Grupo 3: 91, 96,  
98  
||Pacientes com<br>diferentes níveis||||||**UPCR as 8hϮ:**<br>Média (DP):<br>2.627 (1.994)<br>R<sup>2</sup>:0.879|||
|---|---|---|---|---|---|---|---|---|---|
|**Kristal et**<br>**al. 1988**<br>**(107)**|de função renal<br>e proteinúria; n:<br>51 (foram<br>excluídos 3<br>outliers n:48)<br>UPCR|P24h|NR|NR|NR|NR|**UPCR as**<br>**12hϮ:**Média<br>(DP): 2.665<br>(2.033)<br>R<sup>2</sup>: 0.900|NR|NR|
||||||||**UPCR as**|||
||||||||**16hϮ:**|||  
|**Autor,**<br>**ano**|**População**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**dtiã **|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||**eermnaço **|||
|||||||||Média (DP):<br>2.378 (1.726)<br>R<sup>2</sup>: 0.726<br>P<0.025|||
|||||||||UPCR as 16h|||
|||||||||vs. 08h e 12h<br>40 de 48|||
|||||||||pacientes|||
|||||||||foram|||
|||||||||classificados|||
|||||||||corretamente|||
|||||||||baseado UPCR<br>as 8hϮ|||
|||||||||39 de 48|||
|||||||||pacientes|||
|||||||||foram|||
|||||||||classificados|||
|||||||||corretamente|||
|||||||||baseado UPCR|||
|||||||||as 12 e 16hϮ|||
||Casos: Pacientes|||||||**Geral:**|||
|**Gisberg**<br>**et al.**<br>**1983(108)**|com doenças<br>renais com<br>função renal|UPCR|P24h|NR|NR|NR|NR|r:0.97<br>**Grupo A†:**<br>r:0.78|NR|NR|
||estável; n:46|||||||**Grupo B:**<br>r:0.96|||  
|**Autor,**<br>**ano**|**População**|**Índice**<br>**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||**Grupo C:**<br>r: 0.93<br>**Grupo D:**<br>r: 0.94<br>**Grupo E:**<br>r:0.83|||
||||||||p <0.05 grupos<br>D e E vs. A, B<br>e C<br>**Grupo Cr F:**<br>r: 0.82|||
||||||||Média<br>Ccr/24h: 0.756<br>(0.20)<br>**Grupo Cr G**:<br>r: 0.90|||
||||||||Média<br>Ccr/24h: 1.232<br>(0.16)<br>**Grupo Cr H:**<br>r: 0.97|||
||||||||Média|||
||||||||Ccr/24h:|||
||||||||1.8532 (0.26)|||  
|**Autor,**<br>**ano**|**População**|**Índice**<br>**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade**<br>**(%) (IC95%)**|**VPP**|**VPN**|**Coeficiente de**<br>**correlação/**<br>**determinação**|**AUC**|**Acurácia**<br>**geral (%)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||**UPCR**<br>**Controle:**|||
||||||||Média:0.033<br>(0.022)|||  
UPCR: relação proteína-creatinina; P24H: proteinúria de 24 horas; Cr: creatinina;r: coeficiente de correlação; R<sup>2</sup> : coeficiente de determinação; AUC: valor da área sob a curva; TFGe: taxa de filtração glomerular estimada; FI: fisicamente inativos; FSA: fisicamente semi- ativos; FA; fisicamente ativos; Ccr: depuração de creatinina;* valor limite paraUPCR da manhã;  grupo 1: pacientes com função renal normal (Ccr ≥90 ml/min), n: 53;  grupo 2: falência renal moderada (40 ≤ Ccr<90 ml/min), n:56; grupo 3: função renal moderadamente ou gravemente comprometida (10 ≤ Ccr <40 ml/min), n:63; Ϯ horário em que foi coletado a amostra de urina; †grupo A:primeiras amostras colhidas ao se levantar; grupo B: amostras colhidas após as amostras do grupo A e antes de 12h; grupo C: amostras colhidas entre 12h e 18h; grupo D:amostras colhidas entre 18h e 00h; grupo E:amostras colhidas entre 00h e amostras do grupo A; GrupoCr F: excreção de Cr 24h < 1g, n: 16; Grupo Cr G: excreção de Cr 24h 1 – 1.5 g, n: 18; Grupo Cr H: excreção de Cr 24h >1.5 g, n: 11;  
**Questão de Pesquisa 2 -** Qual a eficácia e a segurança do rituximabe (RTX) para o tratamento de Alterações Glomerulares Mínimas (AGM) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente? (Avaliar também a indicação de uso do RTX)  
**Questão de Pesquisa 3 -** Qual a eficácia e a segurança do micofenolato (sódico e mofetila) (MMF) para o tratamento de AGM com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Questão de Pesquisa 4 -** Qual a eficácia e a segurança do tacrolimo (TAC) para o tratamento de AGM com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
((("Nephrotic Syndrome"[Mesh] OR ("nephrotic syndrome"[MeSH Terms] OR ("nephrotic"[All Fields] AND "syndrome"[All Fields]) OR "nephrotic syndrome"[All Fields] OR ("nephrotic"[All Fields] AND "syndromes"[All Fields]) OR "nephrotic syndromes"[All Fields])) OR ("Nephrosis, Lipoid"[Mesh] OR ("nephrosis, lipoid"[MeSH Terms] OR ("nephrosis"[All Fields] AND "lipoid"[All Fields]) OR "lipoid nephrosis"[All Fields] OR ("minimal"[All Fields] AND "change"[All Fields] AND "glomerulopathy"[All Fields]) OR "minimal change glomerulopathy"[All Fields]))) NOT ("child"[MeSH Terms] OR "child"[All Fields])) AND (((("Rituximab"[Mesh] OR ("rituximab"[MeSH Terms] OR "rituximab"[All Fields])) OR ("Mycophenolic Acid"[Mesh] OR ("mycophenolic acid"[MeSH Terms] OR ("mycophenolic"[All Fields] AND "acid"[All Fields]) OR "mycophenolic acid"[All Fields] OR ("mycophenolate"[All Fields] AND "mofetil"[All Fields]) OR "mycophenolate mofetil"[All Fields]))) OR ("Mycophenolic Acid"[Mesh] OR ("mycophenolic acid"[MeSH Terms] OR ("mycophenolic"[All Fields] AND "acid"[All Fields]) OR "mycophenolic acid"[All Fields] OR ("mycophenolate"[All Fields] AND "sodium"[All Fields]) OR "mycophenolate sodium"[All Fields]))) OR ("Tacrolimus"[Mesh] OR ("tacrolimus"[MeSH Terms] OR "tacrolimus"[All Fields]))) Total de referências: 475 referências Data de acesso: 25/09/2017  
**EMBASE:** ('nephrotic syndrome'/exp OR 'nephrotic syndrome') AND [embase]/lim OR ('minimal change glomerulonephritis'/exp OR 'minimal change glomerulonephritis') AND [embase]/lim  
AND  
('rituximab'/exp OR 'rituximab') AND [embase]/lim OR ('tacrolimus'/exp OR 'tacrolimus') AND [embase]/lim OR ('mycophenolate mofetil'/exp OR 'mycophenolate mofetil') AND [embase]/lim OR ('mycophenolic acid'/exp OR 'mycophenolic acid') AND [embase]/lim OR ('immunosuppressive agent'/exp OR 'immunosuppressive agent') AND [embase]/lim AND ([adult]/lim OR [aged]/lim OR [middle aged]/lim OR [very elderly]/lim OR [young adult]/lim)  
Total: 799 referências Data de acesso: 25/09/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 1274 referências (475 no MEDLINE e 799 no Embase). Destas, 126 foram excluídas por estarem duplicadas.  
Um mil cento e quarenta e oito referências foram triadas por meio da leitura de título e resumos, das quais 30 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Dezoito estudos foram excluídos: uma revisão sistemática por avaliar esteróides, ciclofosfamida e ciclosporina; 2 (dois) ensaios clínicos por incluir síndrome nefrótica secundária e avaliar a ciclofosfamida; doze estudos observacionais por conter em sua população e resultados crianças e adolescentes e avaliar esteróides e outros imunossupressores; 3 estudos por não abordar desfechos de interesse.  
No final, sete estudos foram considerados elegíveis para a questão de pesquisa 2<sup>109-115</sup> . Para a questão de pesquisa 3, foi incluído somente um estudo<sup>116.</sup>  
Foram considerados elegíveis quatro estudos<sup>117-120</sup> para responder a questão de pesquisa  
4.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos estudos e seus resultados** -->
A seguir serão apresentadas as descrições dos estudos e seus resultados para cada questão de pesquisa, relativamente a caracterização dos pacientes, desfechos de segurança e eficácia e medicamentos, respectivamente a Alterações Glomerulares Míninas ( **tabelas 3 a 14** ), Glomeruloesclerose Segmentar e Focal ( **tabelas 15 a 26** ) e Glomerulonefrite Membranosa ( **tabelas 27 a 42** ).  
**Questão de Pesquisa 2 -** Qual a eficácia e a segurança do rituximabe (RTX) para o tratamento deAlterações Glomerulares Mínimas (AGM) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente? (Avaliar também a indicação de uso do RTX)  
**Tabela 3 –** Descrição dos estudos que analisaram o rituximabepara o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**<br>|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Iwabuchi et**<br>**al. 2014;**<br>**Takei et al.**<br>**2012(109,**<br>**110)**|Estudo<br>observacional<br>prospectivo,<br>não<br>comparativo|Avaliar a eficácia e<br>segurança de uma<br>única dose de RTX|Adultos com AGM<br>ET-dependentes|Única dose de RTX (375 mg/m<sup>2</sup>)<br>repetida 4 vezes com intervalo de 6<br>meses: aos 6 meses, 12 meses e18<br>meses após a primeira infusão + ET£<br>**(RTX)**|NA|Alto<br>(Não comparativo,<br>amostra pequena)|
|**Brown et al.**<br>**2017 (111)**|Observacional.<br>Série de casos|Descrever o curso<br>clínico de pacientes<br>com AGM e ET<br>dependentes ou<br>resistentes tratados<br>com RTX|Pacientes adultos<br>(≥ 18 anos) com<br>AGM ET-<br>dependente (n:5)<br>ou ET-resistentes<br>(n:5)|8 pacientes tomaram 2 doses de<br>RTX(1000 mg) com intervalo de 2 a<br>3 semanas (esquema de 2 doses) e 2<br>pacientes tomaram 4 doses de RTX<br>i.v. (375 mg/m<sup>2</sup>) com intervalo de 1<br>semana (esquemas de 4 doses)+ ET*<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**King et al.**<br>**2016 (112)**|Observacional.<br>Série de casos|Descrevero uso de<br>RTX em pacientes<br>adultos com AGM|Pacientes adultos<br>(≥ 18 anos) com<br>SN frequentemente<br>redicivante (taxa de<br>recidiva média<br>de≥2/ano)<br>secundário a AGM|13 pacientes tratados com 2 × 1 g<br>infusões de RTX com intervalos de<br>2 semanas; 1 paciente tratado com 4<br>× 500 mg infusões de RTX com<br>intervalos semanais<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Guitard et al.**<br>**2014 (113)**|Observacional.<br>Série de casos|Analisar a<br>prescrição, eficácia<br>e tolerabilidade de<br>RTX em pacientes<br>com AGM|Pacientes adultos<br>com AGM|21 pacientes receberam 1g de RTX<br>nos dias 1 e 15; 12 receberam quatro<br>infusões semanais de RTX (375<br>mg/m<sup>2</sup>); 1 recebeu 1 g de RTX uma<br>vez; 5 receberam 2 infusões semanais<br>de de RTX(375 mg/m<sup>2</sup>);e 2|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||receberam 3 infusões semanais de<br>375 mg/m<sup>2</sup>+ ETϮ<br>**(RTX)**|||
|**Bruchfeld et**<br>**al. 2014 (114)**|Observacional.<br>Série de casos|Apresentar dados a<br>longo prazo do uso<br>do RTX|Adultos (19- 73<br>anos) com AGM<br>ET-dependentes (n<br>:13) ou resistentes<br>(n: 1) ou com<br>multirelapsos (n:2)|RTX 500 mg com 2 semanas de<br>intervalo para os nove primeiros<br>pacientes com exceção de um<br>paciente que recebeu 1000 mg 2<br>semanas de intervalo. Um<br>pacienterecebeu RTX 375 mg/m<sup>2</sup>em<br>três momentos, com uma dose total<br>de 1500 mg. Três pacientes<br>receberam uma dose de RTX de 375<br>mg / m2 uma vez por semana durante<br>4 semanas, enquanto que dois<br>pacientes preferiram ser tratados com<br>1000 mg com 2 semanas de<br>intervalo+ ET ε<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Munyentwali**<br>**et al. 2013**<br>**(115)**|Observacional.<br>Série de casos|Avaliar<br>retrospectivamente<br>a eficácia e<br>segurança de uma<br>única dose de RTX|Adultos com AGM<br>e SN<br>frequentemente<br>redicivante (n: 2)<br>ou ET-dependentes<br>(15)|RTX foi dada depois de pelo menos<br>dois episódios de relapsos;<br>15 pacientes receberam uma (n:1),<br>duas (n:7), três (n:4) ou quatro (n:3)<br>infusões semanais de RTX 375<br>mg/m<sup>2</sup>;2 pacientes foram tratados<br>com duas doses fixas de RTZ<br>1000mg no dia 1 e 15 +ETα<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
AGM: alterações glomerulares mínimas; RXT: rituximabe; ET: corticosteroides; Pt: proteinúria; Ab: albumina; Cr: creatinina; SN: síndrome nefrótica; i.v.: intravenoso; tto: tratamento; *pacientes pré-medicados com metilprednisolona em todas as infusões; Ϯ pacientes pré-medicados com metilprednisolona bolus (2 mg/kg), acetaminofeno (1g) e hidroxizina (50 mg) antes das infusões; £ pacientes pré-medicados com 4 mg betametasona, 20 mg glicirrizinato monoamônico e 20 mg acetaminofeno; α pacientes pré-medicados com metilprednisolona (40-100mg); ε uso concomitante com glicocorticoide (20-60mg/dia);  
**Tabela 4 –** Caraterísticas dos pacientes incluídos nos estudos que analisaram o rituximabe para o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade Intervenção**<br>**Mediana (min-**<br>**máx.)**|**Idade**<br>**Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de**<br>**seguimentomediana**<br>**(mín-máx.)**|
|---|---|---|---|---|---|---|---|
|**Iwabuchi et al. 2014;**<br>**Takei et al. 2012(109,**<br>**110)**|RTX (25)|NA|29 (DP: 12)|NA|21 (84)|NA|Pelo menos 36<br>meses|
|**Brown et al. 2017**<br>**(111)**|RTX (10)|NA|54 (20-78)|NA|8 (80)|NA|40 meses (20–80)|
|**King et al. 2016 (112)**|RTX (13)|NA|23 (19–83)|NA|10 (80)|NA|20 meses (6–85)|
|**Guitard et al. 2014**<br>**(113)**|RTX (41)|NA|26 (15–83)|NA|30 (73)|NA|44 meses (6–82)|
|**Bruchfeld et al. 2014**<br>**(114)**|RTX (16)|NA|NR (19-73)|NA|7 (43)|NA|44 meses (12-70)|
|**Munyentwali et al.**<br>**2013 (115)**|RTX (17)|NA|29.4 (18.5–65)|NA|13 (76)|NA|29.5 meses (5.1–82)|  
RXT: rituximabe; DP: desvio padrão; min-máx.: valores mínimo e máximoNA: não se aplica.  
**Tabela 5 –** Desfechos de eficácia reportados nos estudos queanalisaram o rituximabe para o tratamento de Alterações Glomerulares Mínimas  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
|**Iwabuchi**|**Número de relapsos, média (DP):**|<0.05|**Proteína na urina (g/dia),**||**Células CD19+/ CD20+, média (DP):**|*<0.05|
|**et al. 2014;**|24 meses antes de RTX:4.3 (2.8)||**média (DP):**|*<0.05|Basal, 1° dose de RTX:98 (104) /101(97)|vs. basal|
|**Takei et al.**|24 meses depois de RTX: 0.3 (0.5)||Basal, 1° dose de RTX:2.5 (4.9);|vs.|1° mês:2.5 (2.6) * / 1.8 (1.2) *||
|**2012(109,**|||1° mês:0.1 (0.3) *; aos 6 meses,|basal|Aos 6 meses, 2° dose: 26(37) * / 27 (36)||
|**110)**|**RC:**||2° dose: 1.8(4.0)*;||*;||  
|**Autor**<br>**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**<br>**Outros desfechos**|**Valor p**|
|---|---|---|---|---|
|**1° mês:**100% dos 7 pacientes com SN<br>na linha de bases<br>||Aos 12 meses, 3° dose:1.3 (4.8);<br>aos 18 meses, 4° dose:0 (0) *;|Aos 12 meses, 3° dose:4.3 31(89) */ 33<br>(78) *;||
|**24 meses após 1° dose de RTX:**100%<br>dos 25 pacientes||Aos 24 meses: 0 (0) *; aos 36<br>meses: 0 (0) *|Aos 18 meses, 4° dose: 13 (29) * /13 (36)<br>*;<br>Aos 24 meses: 11 (17) * /11 (19) *;||
|**Grupo que continuou o tto:**<br>4 suspenderam após 5° infusão de RTX;||**Albumina sérica (g/dL), média**<br>**(DP):**|Aos 36 meses: 21 (45) *; 22 (47) *||
|2 d após 6° infusão;||Basal, 1° dose de RTX:3.6 (0.8);|**Depleção de células B, n:**|**<0.001|
|RC foi mantida em todos os 20 pacientes<br>por 36-54 meses após1° dose de RTX<br>**Grupo que suspendeu o tto:**<br>1 desenvolveu relapso com depleção de<br>células B depois de 8 meses;||1° mês:4.0 (0.6) *; aos 6 meses,<br>2° dose: 4.0 (0.7) *;<br>Aos 12 meses, 3° dose:4.3 (0.7)<br>*; aos 18 meses, 4° dose: 4.5<br>(0.3) *;<br>Aos 24 meses: 4.6 (0.3) *; aos 36|Basal, 1° dose de RTX:0<br>1° mês:25<br>Aos 6 meses, 2° dose: 18;<br>Aos 12 meses, 3° dose:18;<br>Aos 18 meses, 4° dose: 22;<br>Aos 24 meses: 21;|vs. basal|
|4 não relapso||meses: 4.5 (0.3) *|Aos 36 meses: 21||
|||**Creatinina sérica (g/dL):**<br>Basal, 1° dose de RTX:0.7 (0.2);<br>1° mês:0.7 (0.1); aos 6 meses, 2°<br>dose: 0.7 (0.2);<br>Aos 12 meses, 3° dose:0.7 (0.2);|**Número de pacientes recebendo ET;**<br>**dose média de ET (DP):**<br>**Basal, 1° dose de RTX vs. 24 meses**<br>**após RTX**<br>28 vs. 4 **;||
|||aos 18 meses, 4° dose: 0.7 (0.1);<br>Aos 24 meses: 0.7 (0.1); aos 36<br>meses: 0.7 (0.1)|24.2 (12.4) vs. 0.6 (1.3) mg/dia **<br>**Número de pacientes recebendo CA;**<br>**dose média de CA (DP.):**<br>**Basal, 1° dose de RTX vs. 24 meses**<br>**após RTX**<br>20 vs. 5**;||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
|**Brown et**<br>**al. 2017**<br>**(111)**|**Remissão (Pt<0.3 g, Ab >3.5 g/dl e Cr**<br>**normalizada)**<br>n (%): 10 (100)<br>**Tempo do uso do RTX e remissão,**<br>**mediana (min-máx.):**<br>2 meses (1–32)|NR|**Creatinina sérica (mg/dl),**<br>**mediana (min-máx.):**<br>Média basal de 7 pacientes: 0.94<br>3 pacientes insuficiência renal<br>Após remissão: 0.88 (0.5–1.5)<br>**Albumina sérica (g/dl),**<br>**mediana (min-máx.):**<br>Basal:2.5 (1.9–4)<br>Após remissão: 4.1 (3.7–4.5)|NR|**Tempo de suspensão de ET, mediana**<br>**(min-máx.):**<br>9 pacientes; 3.5 meses (1–6).|NR|
||**Relapso:**3 pacientes||**UPCR basal mediana (min-**<br>**máx.):**<br>6.5(0.44–15.75)||||
|**King et al.**<br>**2016 (112)**|**Número de relapsos, mediana (min-**<br>**máx.):**<br>Antes de RTX:4 (2–6)<br>Depois de RTX: 0.4 (0–0.9)<br>Desde o início do RTX: 1 (0–5)<br>**Tempo até o primeiro relapso,**<br>**mediana (min-máx.):**<br>10 meses (1–11)<br>**Em remissão na última visita:**<br>n:13|p≤ 0.05<br>antes<br>vs.<br>depois<br>de RTX|NR|NR|**Mediana (min-máx.) do número de**<br>**doses de RTX:**<br>1 (1–5)<br>**Tempo (mediana; min-máx.) até a**<br>**suspensão de ET para pacientes**<br>**dependentes de ET:**4.5 meses (2–31)<br>**Número médio de imunossupressores**<br>**(incluindo ET):**<br>Antes de RTX:2 (1–4)<br>Depois de RTX: 0 (0–1)|NR|
||**Duração da remissão, mediana (min-**<br>**máx.):**11 (1–38)||||**Número pacientes ET-dependentes:**<br>Antes de RTX:10<br>Depois de RTX: 2||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||Dos 6 pacientes que eram proteinúricos<br>no momento de iniciação de RTX, 5<br>conseguiram remissão completa após<br>RTX.||||**Número pacientes tratados com anti-**<br>**hipertensivos:**<br>Antes de RTX:5; Depois de RTX: 2||
|**Guitard et**<br>**al. 2014**|**Resposta clínica completa (RC e**<br>**retirada de todos ET)**<br>Geral: 25 (61%)<br>Grupo 1:12 (60%)<br>Grupo 2a*:10 (56%)<br>Grupo 2b*: 3 (100%)<br>Última visita (39 meses depois da<br>primeira infusão e 18 meses após a<br>última infusão): 41 (100%)|NR|**UPCR (g/g), mediana (mín;**<br>**máx)**<br>Basalgeral: 1.3 (0–23.0)<br>Após RTX: NR<br>**Albumina sérica (g/L), média**<br>**(DP)**<br>Basalgeral:32 ± 9<br>Após RTX: NR|NR|**Número (%) de pacientes e o tempo**<br>**(mediana; min-máx.) que suspenderam**<br>**a) ET; b)CNI e c)MMF:**<br>20 pacientes (60%); a) 6 meses (1-30); b)<br>4 meses (0-19); c) 0.5 meses (0-36)|<br>NR|
|**(113)**|**Resposta clínica Parcial (RC e**<br>**retirada de pelos menos 1 ET)**<br>Geral: 7 (17%)<br>Grupo 1:5 (25%)<br>Grupo 2a*: 2 (11%)<br>Grupo 2b*: 0<br>**Sem resposta clínica (falha do RTX)**||**Creatinina sérica (μmol/l),**<br>**média (DP)**<br>Basalgeral:92 ± 26<br>Após RTX: NR<br>**eGFR (μmol/l), média (DP)**<br>Basalgeral:93 ± 25<br>Após RTX: NR||**Tempo pararesposta clínica completa**<br>**(mediana; min-máx.):**<br>Grupo 2:32 dias (15–90)<br>Grupo 2b: 60 dias (30–75||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||Geral: 9 (22%)<br>Grupo 1:3 (15%)<br>Grupo 2a*:6 (33%)<br>Grupo 2b*: 0<br>**Relapso, n:**<br>18. Desses, 12 tiveram SN e 6<br>proteinúria não nefrótica<br>Desses, 16 (89%) tiveram recuperação<br>das células B CD19+ em 2 meses (0-14)||||||
||**Tempo até relapsos (mediana; min-**<br>**máx.):**<br>18 meses(3–36)||||||
||**RC (redução total de proteinúria e**<br>**albumina normalizada):**<br>n:13 de 16||||||
|**Bruchfeld**<br>**et al. 2014**<br>**(114)**|**Tempo para RC, média (variação):**<br>1.4 meses (0.5–2)<br>**RP (70-50% de redução de**<br>**proteinúria)**<br>n:6/14<br>**Não reposta**<br>n:1|NR|**Foi fornecido os valores para**<br>**cada paciente, mas não uma**<br>**média ou mediana para**<br>**população**|NA|**As doses de ET após a resposta ao**<br>**RTX foram significativamente**<br>**menores nos 12 meses de seguimento**<br>**do que quando os relapsos ocorreram**<br>**no passado**<br>**Na última visita, 66% de todos**<br>**respondentes não utilizavam nenhum**<br>**imunodepressor**|<0.001<br>NR|
||**Relapsos após 9-28 meses:**<br>n:7||||||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Número de relapso por ano, média**<br>**(DP):**<br>Antes de RTX:1.32 (0.85)<br>Depois de RTX: 0.16 (0.21)|<0.05|||**Uso de predsinona:**<br>**Linha de base vs. 1 ano, média (mín;**<br>**máx)**<br>40 mg/dia (10–70) vs. 5.2 mg/dia (0–30)<br>**Uso de outros imunodepressores:**<br>10 de 13 pacientes pararam o uso de||
||**Não relapso após seguimento de 26.7**||||outros imunodepressores||
||**meses**||||||
||**(5–82) após 1° infusão**||||**Uso de ET e outros imunodepressores:**||
||n: 11||||ET e todos os agentes imunodepressores||
|**Munyentw**<br>**ali et al.**<br>**2013 (115)**|**Pelo menos 1 relapso ocorreu em 11.4**<br>**meses (4.8–16.3):**<br>n:6 (39%)||**Foi fornecido os valores para**<br>**cada paciente, mas não uma**<br>**média ou mediana para**<br>**população**|NA|foram retirados em 9 dos 11 pacientes<br>que não recaíram após 1 curso de RTX.<br>Na última visita, 12 (70%) pacientes não<br>faziam mais uso de ET e<br>**imunodepressores**|NR|
||**Tempo médio para o primeiro**<br>**relapso, média (mín; máx):**6.3<br>meses(4.8–7.9)||||**Uso de MMF:**<br>9 dos 17 pacientes usaram antes de RTX<br>e interrompido após o 1° curso de||
||**Pacientes (n) com relapsos:**<br>Aos 3 meses: 0<br>Aos 6 meses: 1<br>Aos 9 meses: 3||||RTX em 7 pacientes e suspenso após 6-<br>27 meses nos 2 pacientes restantes.<br>**Uso de CNI:**||
||Aos 12 meses: 3||||7 dos 17 pacientes usaram antes de RTX.<br>No mês 12,havia 2pacientes em uso||  
RXT: rituximabe; ET: esteroides;CNI: inibidores da calcineurina; MMF: micofenolato de mofetil; CA: ciclosporina;AGM: alterações glomerulares mínimas; SN: síndrome nefrótica; tto: tratamento; RC: remissão completa; RP: remissão parcial;eGFR: taxa de filtração glomerular estimada;  grupo 1: pacientes que tiveram suspenso o ET, n:20; grupo 2: pacientes com SN frequentemente redicivante; isto é ≥2 recaídas observadas nos últimos 6 meses ou ≥4 recaídas observadas durante qualquer período de 12 meses) ou com contraindicação para ET de longo prazo ou uso de CNI; *grupo 2a: pacientes do grupo 2 que receberam RTX e imunossupressores, n:18; grupos 2b: pacientes do grupo 2 que receberam somente RTX, n: 3; grupo de continuação do tto: grupo pacientes que continuaram a receber  
as infusões de RTX de 6/6 meses após 24 meses, n:20; grupo em que se suspendeu o tto de RTX: n:5;IC 95%: intervalo de confiança de 95%; DP: desvio padrão; minmax: mínimo e máximo; NR: não reportado; NS: não significativo; NA: não se aplica.  
**Tabela 6 –** Desfechos de eficácia reportados nos estudos que analisaram o rituximabe para o tratamento de Alterações Glomerulares Mínimas  
|**Evento adversos**|**Iwabuchi e**<br>**Takei et al.**<br>**11**|**t al. 2014;**<br>**2012(109,**<br>**0)**|**Brown**<br>**2017(**|**et al.**<br>**111)**|**King**<br>**2016**|**et al.**<br>**(112)**|**Guitar**<br>**2014(**|**d et al.**<br>**113)**|**Bruchfel**<br>**2014(**|**d et al.**<br>**114)**|**Munyent**<br>**2013(**|**wali et al.**<br>**115)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Grupo**|**RTX**|**NA **|**RTX**|**NA **|**RTX**|**NA **|**RTX**|**NA **|**RTX**|**NA **|**RTX**|**NA **|
|Infecção do trato<br>respiratório|NR|NA|2|NA|0|NA|0|NA|0|NA|0|NA|
|EA não sérios|13|NA|5|NA|0|NA|4|NA|3|NA|0|NA|
|EA sérios|0|NA|NR|NA|1|NA|0|NA|NR|NA|0|NA|
|Morte|0|NA|0|NA|0|NA|0|NA|0|NA|0|NA|  
RXT: rituximabe; EA: eventos adversos; NA: não se aplica.  
**Questão de Pesquisa 3 -** Qual a eficácia e a segurança do micofenolato (sódico e mofetila) (MMF) para o tratamento de AGM com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 7 –** Descrição do estudo que analisou o micofenolato de mofetila para o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Pesavento et**<br>**al. 2004 (116)**|Relato de<br>casos|Descrever o uso da<br>terapia com MMF|Adultos com AGM<br>frequentemente<br>redicivante que<br>respondem aos<br>esteroides eque a|MMF (Dose inicial/ dose final),<br>mg/d, doses divididas:<br>Paciente 1: 1000 / 1000<br>Paciente 2: 1500 / 1500<br>Paciente 3: 1500 / 1500|NA|Alto<br>(Relatos de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||terapia com<br>ciclofosfamida<br>falhou|Paciente 4: 1500 / 1000|||  
MMF: micofenolato de mofetila; AGM: alterações glomerulares mínimas.  
**Tabela 8 –** Caraterísticas dos pacientes incluídos no estudo que analisou o micofenolato de mofetila para o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade Intervenção**<br>**(anos)**|**Gênero**|**Dose (mg) de CF utilizada**<br>**anterior ao tto com MMF**|**Período de seguimento**|
|---|---|---|---|---|---|---|
||||Paciente 1: 78|Paciente 1: feminino|Paciente 1: 2100|6 meses|
|**Pesavento et al. 2004**<br>**(116)**|MMF (4)|NA|Paciente 2: 61<br>Paciente 3: 33|Paciente 2: masculino<br>Paciente 3: feminino|Paciente 2: 13825<br>Paciente 3: 7000||
||||Paciente 4: 53|Paciente 4: feminino|Paciente 4: 16800||  
MMF: micofenolato de mofetila; CF: ciclofosfamida;tto: tratamento; NA: não se aplica.  
**Tabela 9 –** Desfechos de eficácia reportados noestudo que analisou o micofenolato de mofetila para o tratamento de Alterações Glomerulares Mínimas  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
|**Pesavento**<br>**et al. 2004**<br>**(116)**|**Número de relapsos:**<br>Antes de MMF vs. depois de MMF<br>Paciente 1: 2 vs. 1<br>Paciente 2: 4 vs. 0<br>Paciente 3: 4 vs. 0<br>Paciente 4: 3 vs. 0<br>**Meses em remissão:**|NR|**Proteinúria (g/24h)**<br>Antes de MMF vs. depois de<br>MMF<br>Paciente 1: 7.2 vs. 0.16<br>Paciente 2: 6.0 vs. 0.06<br>Paciente 3: 5.0 vs. 0<br>Paciente 4: 14.8 vs. 0|NR|**Dose de prednisona (mg/d):**<br>Antes de MMF vs. depois de MMF<br>Paciente 1: 30 vs. 10<br>Paciente 2: 0 vs. 0<br>Paciente 3: 30 vs. 5<br>Paciente 4: 60 vs. 10|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||Paciente 1: 19; Paciente 2: 42<br>Paciente 3: 32; Paciente 4: 27<br>**RC ou RP após MMF:**<br>Paciente 1: RP em 3 meses e RC em 6<br>meses<br>Paciente 2: RP em 4 meses<br>Paciente 3: RP em 3 meses<br>Paciente 4: RP em 6 meses||**Creatinina sérica (mg/dl)**<br>Depois de MMF<br>Paciente 1: 0.9;<br>Paciente 2: 0.8<br>Paciente 3: 0.6;<br>Paciente 4:  1.1||||
|MMF:micof|enolato de mofetila;RC: remissão completa;|RP: remis|são parcial.||||  
**Tabela 10 –** Desfechos de segurança reportados no estudo que analisou o micofenolato de mofetila para o tratamento de Alterações Glomerulares Mínimas  
|**Evento adversos**|**Pesavento et al. 2004 (116)**|
|---|---|
|**Grupo**|**MMF**|
|Infecção do trato respiratório|0|
|EA não sérios|0|
|EA sérios|0|
|Morte|0|
|EA: eventos adversos; MMF:micofenolato de mofetila.||  
**Questão de Pesquisa 4 -** Qual a eficácia e a segurança do tacrolimo (TAC) para o tratamento de AGM com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 11 –** Descrição dos estudos que analisaram o tacrolimo para o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Li et al. 2012**<br>**(117)**|Estudo<br>observacional<br>prospectivo|Avaliar a eficácia e<br>segurança do TAC<br>vs. CF IV.|Adultos com AGM<br>ET-resistentes|TAC oral inicial de 0,05<br>mg/kg /d, dividido em 2<br>doses ao longo de<br>intervalos de 12 horas, e a<br>dose foi ajustada para<br>manter um alvo no nível<br>sanguíneo de 5 para10 ng /<br>mL durante 12 meses + ET<sup>1</sup><br>**(TAC)**|CF IV pulso 1 g /1,73<br>m<sup>2</sup>de superfície<br>corporal mensalmente<br>por 6 meses e depois a<br>cada 2 meses por um<br>adicional de 6 meses,<br>com uma dose total de<br>10 g /1,73 m<sup>2</sup>. + ET<sup>1</sup><br>**(CF)**|Alto<br>(Não controla<br>confundidores, não<br>apresenta cálculo<br>amostral)|
|**Li et al. 2008**<br>**(118)**|Estudo<br>observacional<br>prospectivo|Avaliar a eficácia e<br>segurança do TAC<br>vs. CPA IV|Adultos com AGM<br>ET-resistentes|TAC oral inicial de 0,05<br>mg/kg /d, dividido em 2<br>doses ao longo de<br>intervalos de 12 horas; a<br>dose foi ajustada para<br>manter um alvo no nível<br>sanguíneo de 4-8ng/mL por<br>24 semanas + ET<sup>1</sup><br>**(TAC)**|CPA 750 mg/m<sup>2</sup>de<br>superfície corporal a<br>cada 4 semanas por 24<br>semanas+ ET<sup>1</sup><br>**(CPA)**|Alto<br>(Não controla<br>confundidores, não<br>apresenta cálculo<br>amostral)|
|**Kim et al.**<br>**2012 (119)**|Observacional,<br>serie de casos|Avaliar a eficácia e<br>segurança do TAC|Adultos com AGM e<br>intervalo de<br>proteinúria nefrótico|TAC (Prograf ®)<br>0.05mg/kg duas vezes ao<br>dia e ET<sup>1</sup><br>**(TAC)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Xu et al. 2017**<br>**(120)**|Observacional,<br>serie de casos|Avaliar a eficácia e<br>segurança do<br>TACem pacientes<br>com AGM CPA-<br>dependentes ou<br>resistentes|Adultos com AGM<br>CPA-dependentes<br>(n:4) ou resistentes<br>(n:7)|O TAC 0,05-0,1 mg/kg /dia<br>em duas doses divididas em<br>intervalos de 12 horas por 6<br>meses. A dose foi ajustada<br>para atingir um nível alvo<br>de 5-10ng/mL. + ET<sup>1</sup>|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||**(TAC)**|||  
TAC: tacrolimo; CF: ciclofosfamida; CPA: ciclosporina; ET: esteroides;AGM: alterações glomerulares mínimas; IV: intravenoso; ET<sup>1</sup> : prednisolona oral 0.05 mg/kg/dia (dose máxima de 40 mg); NA: não se aplica.  
**Tabela 12 –** Caraterísticas dos pacientes incluídos nos estudos que analisaram o tacrolimopara o tratamento de Alterações Glomerulares Mínimas  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade, anos**<br>**Intervenção**<br>**Média (DP)**|**Idade, anos**<br>**Controle**<br>**Média (DP)**|**n (%)sexo masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|
|**Li et al. 2012 (117)**|TAC (19)|CF (14)|29.6 (11.0)|35.9 (12.7)|12 (63)|8 (57)|12 meses|
|**Li et al. 2008 (118)**|TAC (12)|CPA (14)|25.0 (10.5)|33.8 (12.1)|8 (67)|9 (64)|Tto: 24 semanas<br>Após tto:<br>TAC:23.7 (DP:<br>10.7)<br>CPA:22.2 (DP:<br>9.9)|
|**Kim et al. 2012 (119)**|TAC (14)|NA|33.8(20–72)|NA|10 (71)|NA|16 semanas|
|**Xu et al. 2017 (120)**|TAC (11)|NA|30.18 (14.35)|NA|7 (64)|NA|Tto: 6 meses<br>Após tto:<br>25.82 meses (DP:<br>19.26)|  
TAC: tacrolimo; CF: ciclofosfamida;CPA: ciclosporina; DP: desvio padrão; tto: tratamento; NA: não se aplica.  
**Tabela 13 –** Desfechos de eficácia reportados nos estudos que analisaram o tacrolimo para o tratamento de Alterações Glomerulares Mínimas  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Taxa de remissão (TAC vs. CF):**<br>Aos 2 meses:57.9% vs. 14.3%<br>Aos 4 meses:73.7% vs. 42.9%<br>Aos 6 meses: 78.9% vs. 50.0%|< 0.05<br><0.001TAC<br>vs. CF<br>durante a tto|||||
|**Li et al.**<br>**2012 (117)**|**Tempo necessário até a remissão,**<br>**média (DP), (TAC vs. CF):**<br>48.7 dias (36.0) vs. 85.3 dias (40.6)<br>**Relapso, n/N (TAC vs. CF):**<br>A) Durante o tto: 1/15 vs. 0/7<br>B) Imediato (<1 mês) após tto: 1/15 vs.<br>0/7<br>C) Durante o primeiro ano de<br>seguimento:5/15 vs.1/7<br>D) Total ocorrido durante tto e<br>seguimento:6/15 vs.1/7|e o<br>seguimento<br><0.05<br>NS<br>NS<br>NS<br>NS|Não foram encontradas<br>diferenças de creatinina<br>sérica ou eGFR entre os<br>grupos TAC e CF em<br>qualquer momento do<br>seguimento|NS|**Dose média de TAC:**<br>2.61 mg/d (IC 95%: 2.18–3.03)|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**RC**<br>TAC:90.9% de 11<br>CPA:76.9% de 13||||||
||**Tempo necessário até a remissão,**<br>**média (DP), (TAC vs. CPA):**<br>31.5 dias (25.8)vs. 59.9 (28.3)|0.031|**Albumina sérica**<br>NR valores<br>TAC apresentou níveis||||
||**1 paciente do grupo TAC e 1 paciente**<br>**do grupo CPA permaneceram em RP**<br>**por 24 semanas de tto, que foi**<br>**estendido por mais 12 semanas, mas**<br>**esses pacientes não atingiram RC**||significantemente menores<br>do que CPA em 2,4 e 12<br>semanas<br>**Proteinúria**|0.012,<br>0.002,0<br>.005|**Dose média (DP) de TAC:**<br>3.1 mg/d (1.1)<br>**Dose média (DP) de prednisolona:**||
||||NR valores||TAC:50.6 (25.0)|NS|
|**Li et al.**<br>**2008 (118)**|**Sem resposta**<br>TAC:0; CPA: 2 (15.4%)<br>**% de pacientes que permaneceram**<br>**em remissão a) no fim da tto; b) em 24**||TAC apresentou níveis<br>significantemente menores<br>do que CPA em 2 e 8<br>semanas|0.034,<br>0.026|CPA:66.3 (23.1)<br>**Retirada de ET por mais de 2 semanas**<br>**(status de dependência de ET à**<br>**remissão sustentada)**|NS|
||**semanas de seguimento; c) em 48**<br>**semanas de seguimento; d)**<br>**seguimento final pós tto (23.0 ±**<br>**10.1 meses**<br>**(TAC vs. CPA):**<br>a) 80% vs. 80%;<br>b) 60% vs. 70%<br>c) 50% vs. 60%<br>d) 50% vs. 60%||**Creatinina sérica e**<br>**depuração de creatinina**<br>NR valores; não foram<br>encontradas diferenças<br>significativa entre os grupos|NS|TAC: 8 de 11 (72.7%):<br>CPA:8 de 13 (61.5%)||
||**Ocorrência de pelo menos 1**<br>**relapsonos pacientes(TAC vs. CPA):**|NS|||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||50% vs. 40%||||||  
||**RC (16 semanas de tto)**<br>13/14 (92.9%)||**Albumina sérica (g/dl)**|<0.05|**Dose média (DP) de TAC:**<br>0.096 mg/kg/dia (0.02)||
|---|---|---|---|---|---|---|
||1 paciente atingiu RC após 20 semanas||Os níveis aumentaram||||
|**Ki t l**|de tto||comparado a linha de base||**Dose média (DP) de prednisolona:**||
|**m e a.**<br>**2012 (119)**|**Tempo necessário até RC, média**|NR|Níveis basais:2.2 (0.5)<br>NR valores||31.5 mg/dia (6.5)|NR|
||**(DP):**|||<0.05|Taxa de aderência de TAC e||
||4.64 semanas (5.11)||**Colesterol total**||prednisolona:<br>96.5% (4.4%); 99.9% (0.5%)||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Taxa de RC cumulativa:**<br>Em 1 semana:7.7%(1/14)<br>Em 2 semanas: 64.2%(9/14)<br>Em 4 semanas:71.3%(10/14<br>Em 8 semanas:92.9%(13/14)<br>Em 20 semanas:100%||Os níveis diminuíram nas<br>semanas 4,8,12 e 16<br>comparado a linha de base<br>Níveis basais:360 (104)<br>NR valores<br>**Excreção de proteína na**<br>**urina**<br>Os níveis diminuíram<br>comparado a linha de base<br>NR valores|<0.05<br>NS|||
||||**eGFR (ml/min/1.73m**<sup>**2**</sup>**)**<br>Basal: 109.2 (30.4)<br>Em 16semanas:106.5 (8.1)||||
|**Xu et al.**<br>**2017 (120)**|**Remissão de proteinúria**<br>10 de 11<br>**RC**: 8<br>**RP**: 2<br>**Sem resposta**: 1<br>**Tempo necessário até RC:**<br>1-2 meses<br>**Relapsos**<br>n:5 pacientes<br>Média (DP):1.1 (1.66)|NR|**Excreção de proteína na**<br>**urina (g/dia), média (DP)**<br>**Linha de base vs. 6 meses**<br>5.65 (0.83) vs. 1.73 (1.25)<br>**Albumina sérica (g/dl),**<br>**média (DP)**<br>**Linha de base vs. 6 meses**<br>17.55 (1.32) vs. 38.18 (3.12)|0.018<br><0.001|**Dose de manutenção de TAC, média**<br>**(DP)**<br>1.05 mg/dia (0.44)|NR|
||7 pacientes permaneceram em remissão<br>somente com o tto de TAC; 3 pacientes||||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||permaneceram em remissão com a<br>combinação TAC + prednisolona||||||
||Pacientes CPA- dependentes (n:4)<br>atingiram remissão em menos de 2<br>meses com TAC||||||
||4 pacientes CPA- resistentes (n:7)<br>atingiram remissão em menos de 2<br>meses com TAC; 1 paciente CPA-<br>resistentes atingiram remissão em 5-6<br>meses; 1 paciente CPA- resistentes<br>demonstrou resistência ao TAC||||||  
TAC: tacrolimo; CF: ciclofosfamida; CPA: ciclosporina; tto: tratamento;eGFR: taxa de filtração glomerular estimada; RC: remissão completa; RP: remissão parcial; NS: valor de p não significante; NA: não se aplica; NR: não reportado; DP: desvio padrão.  
**Tabela 14 –** Desfechos de segurança reportados nos estudos que analisaram o tacrolimo para o tratamento de Alterações Glomerulares Mínimas  
|**Evento adversos**|**Li et al. 2**|**012 (117)**|**Li et al.**|**2008(118)**|**Kim et al. 2**|**012 (119)**|**Xu et al. 2**|**017 (120)**|
|---|---|---|---|---|---|---|---|---|
|**Grupo**|**TAC**|**CF**|**TAC**|**CPA**|**TAC**|**NA**|**TAC**|**NA**|
|Leucopenia|NR|NR|0|2(14.3%)|0|NA|NR|NA|
|Infecções|NA|NA|3 (25.0%)|4(28.6%)|0|NA|1|NA|
|Injúrias renais agudas|2|1|NR|NR|NA|NA|NR|NA|
|Infecçãopulmonar|3|3|NR|NR|NA|NA|NR|NA|
|Náusea|2|3|NA|NA|NR|NA|NR|NA|
|Vômito|0|2|NA|NA|NR|NA|NR|NA|  
|**Evento adversos**|**Li et al. 2**|**012 (117)**|**Li et al.**|**2008(118)**|**Kim et al. 2**|**012 (119)**|**Xu et al. 2**|**017 (120)**|
|---|---|---|---|---|---|---|---|---|
|**Grupo**|**TAC**|**CF**|**TAC**|**CPA**|**TAC**|**NA**|**TAC**|**NA**|
|Diarreia|0|1|NA|NA|1|NA|3|NA|
|Intolerância àglicose|1|0|NA|NA|NR|NA|NR|NA|
|Sintomasgastrointestinais|NA|NA|2(16.7%)|2(14.3%)|NR|NA|NR|NA|
|Hipertensão|NR|NR|1(8.3%)|0|0|NA|1|NA|
|Suspensão/ interrupção|1|0|1|1|0|NA|0|NA|
|Hepatotoxicidade|1|0|1(8.3%)|4(28.6%)|0|NA|0|NA|  
EA: eventos adversos; TAC: tacrolimo; CF: ciclofosfamida; CPA: ciclosporina;NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 5 -** Qual a eficácia e a segurança do Rituximabe (RTX) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente? (Avaliar indicação de uso do RTX)  
**Questão de Pesquisa 6 -** Qual a eficácia e a segurança do micofenolato (sódico e mofetila) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Questão de Pesquisa 7 -** Qual a eficácia e a segurança do tacrolimo (TAC) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
(("Glomerulosclerosis, Focal Segmental"[Mesh] OR Focal SegmentarGlomerulosclerosis)) AND (((("Tacrolimus"[Mesh] OR tacrolimus)) OR ("Mycophenolic Acid"[Mesh] OR Mycophenolate Mofetil OR Sodium Mycophenolate)) OR ("Rituximab"[Mesh] OR rituximab)) Resultados: 343 referências Data de acesso: 02/10/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **EMBASE:** -->
('focal glomerulosclerosis'/exp OR 'focal glomerulosclerosis' OR 'focal segmentarglomerulosclerosis'/exp OR 'focal segmentarglomerulosclerosis') AND ((('rituximab'/exp OR 'rituximab') AND [embase]/lim) OR (('mycophenolate mofetil'/exp OR 'mycophenolate mofetil' OR 'sodium mycophenolate'/exp OR 'sodium mycophenolate') AND [embase]/lim) OR (('tacrolimus'/exp OR 'tacrolimus') AND [embase]/lim)) Resultado: 1197 referências Data de acesso: 02/10/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
Foram obtidas 1.540 referências pelas estratégias de buscanas bases MEDLINE (via PubMed) e Embase. Foram excluídas 269 duplicatas. Dessa forma, 1271 referências foram triadas por título e resumo. Após essa etapa, 1260referências foram excluídas.  
Para a questão de pesquisa 5, cinco estudos foram considerados elegíveis<sup>121-125</sup> . Dois estudos<sup>126,</sup> 127 foram considerados elegíveis para responder à questão de pesquisa 6. Por fim, para responder à questão de pesquisa 7, foram considerados quatro estudos<sup>128-131</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos estudos e seus resultados** -->
A seguir serão apresentadas as descrições dos estudos e seus resultados para cada questão de pesquisa.  
**Questão de Pesquisa 5 -** Qual a eficácia e a segurança do Rituximabe (RTX) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente? (Avaliar indicação de uso do RTX)  
**Tabela 15 –** Descrição dos estudos que analisaram o rituximabe para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**El-Reshaid**<br>**et al. 2012**<br>**(121)**|Série de<br>casos<br>prospectiva|Avaliar o papel<br>do RTX no<br>tratamento de<br>pacientes<br>resistentesàET<br>e inibidores de<br>calcineurina<br>ou± cellcept<br>SN idiopática|Pacientes adultos e<br>pediátricos com SN<br>idiopática resistente com<br>lesões histopatológicas do<br>tipo DLM, GESF e GM;<br>SN resistente a pelo menos<br>4 meses de tto com ET (1<br>mg/kg/dia) e refratária<br>(relapso ou dependente) ou<br>resistente aos<br>iCALmonoterapia ou<br>combinado comcellcept;<br>todos os pacientes<br>receberam três doses<br>mensais de citoxano IV<br>(0,75 g / m2) sem<br>benefício.|RTX (1mg/ml) infusões semanais por<br>4 semanas<br>**(RTX)**<br>**Subgrupos: RTX DLM,**<br>**RTX GESF e RTX GM;**|NA|Alto<br>(Estudo não randomizado,<br>não comparativo para<br>avaliar eficácia)|
|**Rao et al.**<br>**2016 (122)**|Série de<br>casos<br>prospectiva|Avaliara<br>eficácia e<br>segurança do<br>RTX|Pacientes com SN DLM ou<br>GESF e ET-dependentes ou<br>ET- resistentes|RTX 375 mg/m<sup>2</sup>semanalmente<br>(máximo de 4 doses; níveis de<br>CD19<5/μl<br>**(RTX)**|NA|Alto<br>(Resumo de congresso,<br>não contém todas as<br>informações para<br>julgamento; estudo não<br>randomizado, não<br>comparativo para avaliar<br>eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Fernandez-**<br>**Fresnedo**<br>**et al. 2009**<br>**(123)**|Série de<br>casos<br>prospectivos|Reportar o uso<br>de RTX em<br>adultos|Pacientes com GESF<br>primário e SN ET-<br>resistentes e à outros<br>imunodepressores|Pacientes1 a 5 receberam RTX 375<br>mg/m<sup>2</sup>infusões semanais por 4<br>semanas; pacientes 6 e 7 receberam 4<br>infusões consecutivas semanais (375<br>mg/m<sup>2</sup>) na linha de base, seguido de<br>mais 4 infusões aos 12 meses (paciente<br>6) e mais duas infusões aos 6 meses<br>(paciente 7); paciente 8 recebeu oito<br>infusões consecutivas semanais de<br>375mg/m<sup>2</sup>na linha de base.|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|||||**(RTX)**|||
|**Rizzo et al.**<br>**2016 (124)**|<br>Série de<br>casos<br>prospectivos|Avaliara<br>eficácia do<br>RTX|Pacientes com GESF e SN<br>ET- resistentes e iCAL-<br>resistentes|RTX 1g, duas vezes em duas semanas<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Ochi et al.**<br>**2012 (125)**|Relato de<br>casos|Descrever o tto<br>com RTX em<br>4 pacientes|Pacientes com GESF que<br>falharam ou demonstraram<br>intolerância com terapia de<br>imunossupressores padrões|Paciente 1: única infusão de RTX 375<br>mg/m<sup>2</sup>: 500 mg<br>Paciente 2: única infusão de RTX 375<br>mg/m<sup>2</sup>: 500 mg; administrado 4 vezes<br>após relapsos<br>Paciente 3: RTX 375 mg/m<sup>2</sup>: 500 mg<br>Paciente 4: única infusão de RTX 375<br>mg/m<sup>2</sup>: 500 mg; administrado 3 vezes<br>após relapsos<br>**(RTX)**|NA|Alto<br>(Relato de casos para<br>avaliar eficácia)|  
SN: síndrome nefrótica; GESF; glomeruloesclerose segmentar focal; DLM: doença de lesão mínima;GM: glomerulopatia membranosa; RTX: rituximabe; iCAL: inibidores de calcineurina; ET: esteroides; NA: não se aplica.  
**Tabela 16 –** Caraterísticas dos pacientes incluídos nos estudos que analisaram o rituximabe para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor, ano**|**Intervenção (n)**|**Controle**<br>**(n)**|**Idade, anos**<br>**Intervenção**<br>**Média (DP)**|**Idade, anos**<br>**Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|
||RTX DLM (23<br>adultos + 9<br>pediátricos)||Adultos: 22 (4)<br>Pediátricos: 7 (4)||Adultos: 14 (57)<br>Pediátricos: 6 (67)|||
|**El-Reshaid et al.**<br>**2012 (121)**|RTX GESF (16<br>adultos + 2<br>pediátricos)|NA|Adultos: 29 (10)<br>Pediátricos: 4 (1)|NA|Adultos: 11 (69)<br>Pediátricos: 1 (50)|NA|12 meses|
||RTX GM (28)||Adultos: 36 (9)||Adultos: 16 (61)|||
|**Rao et al. 2016**<br>**(122)**|RTX (22)|NA|22.77 (7.45)|NA|NR|NA|6 meses|
|**Fernandez-**<br>**Fresnedo et al.**<br>**2009 (123)**|RTX (8)|NA|31 (14)|NA|7 (88)|NA|1,6 e 12 meses<br>Após tto:<br>16.4 meses (DP:<br>5.1)|
||||Idade no|||||
|**Rizzo et al.  2016**<br>**(124)**|RTX (5)|NA|diagnóstico:26.2<br>(min.-max.:2- 38)|NA|5 (100)|NA|Após tto:<br>18.8 meses (9-29)|
|**Ochi et al. 2012**<br>**(125)**|RTX (4)|NA|Paciente 1: 25<br>Paciente 2: 27<br>Paciente 3: 21<br>Paciente 4: 26|NA|1 (25)|NA|NR|  
RTX: rituximabe; GESF; glomeruloesclerose segmentar focal; DLM: doença de lesão mínima; GM: glomerulopatia membranosa; RTX: rituximabe; tto: tratamento; DP: desvio padrão; min.-max.: valores mínimos e máximos; NA: não se aplica; NR: não reportado _._  
**Tabela 17 –** Desfechos de eficácia reportados nos estudos que analisaram o rituximabe para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**RC (n) em a) antes do tto com RTX;**<br>**b) 8 meses após RTX;) 12 meses**<br>**após RTX**<br>RTX DLM: a)24; b) 32; c) 29;<br>RTX GESF: a) 0; b) 0; c) 0;<br>RTX GM: a) 6; b) 24; c) 12||||||
|**El-Reshaid**<br>**et al. 2012**<br>**(121)**|**RP (n) em a) antes do tto com RTX;**<br>**b) 8 meses após RTX;) 12 meses**<br>**após RTX**<br>RTX DLM: a)6; b) 0; c) 2;<br>RTX GESF: a)10; b) 17; c) 17;<br>RTX GM: a)10; b) 2; c) 14;|NR|NR|NR|**Tempo de resposta ao RTX**<br>RTX DLM: 1° mês<br>RTX GESF: 3° mês (gradualmente)<br>RTX GM: 3° mês (gradualmente)|NR|
||**Sem resposta (n) em a) antes do tto**<br>**com RTX; b) 8 meses após RTX;)**<br>**12 meses após RTX**<br>RTX DLM: a)2; b) 0; c) 1;<br>RTX GESF: a)8; b) 1; c) 1;<br>RTXGM:a)12;b)2;c)2;||||||
|**Rao et al.**<br>**2016 (122)**|**RC e RP:**16 (84.2%) de 19 pacientes<br>**RC:**10 (52.6%) de 19 pacientes<br>**RP:**6 (31.6%) de 19 pacientes<br>**Sem resposta:**3(15.8%) de 19<br>pacientes||NR|NR|**Doses de RTX:**<br>Média acumulada:900<br>(600-2400) mg<br>Pacientes n(%) que precisaram de dose<br>adicional: 1052.6%<br>**Tempo para reconstituição de CD19:**<br>4.7 meses<br>**Uso de imunossupressores**|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Relapso**: 1<br>**RP e RC em pacientes com SN ET-**<br>**dependentes versus SN ET-**<br>**resistente:**<br>100% vs. 62.5%|0.06|||Basal:16<br>Aos 6 meses: 1||
|**Fernandez**<br>**-Fresnedo**<br>**et al. 2009**<br>**(123)**|**2 pacientes de 8 demonstraram uma**<br>**melhora sustentada após o uso do**<br>**RTX**|NR|**Creatinina sérica (mg/dl),**<br>**basal vs. última visita do**<br>**seguimento:**<br>Paciente 1:1.2 vs.1.4<br>Paciente 2: 0.9 vs. 1.1<br>Paciente 3:1.4 vs.1.2<br>Paciente 4: 0.9 vs.6.5<br>Paciente 5:0.9 vs.1.9<br>Paciente 6: 2.3 vs.3.2<br>Paciente 7: 1.7 vs.1.4<br>Paciente 8: 1.9 vs.1.0<br>Todos: 1.4 (DP: 0.5) vs. 2.2<br>(DP: 1.8)<br>**Proteinúria (g/24h), basal vs.**<br>**última visita do seguimento:**<br>Paciente 1:16vs.15.0<br>Paciente 2: 16.5vs. 15.8<br>Paciente 3:9.4vs.9.8<br>Paciente 4: 12.0vs.14.0<br>Paciente 5:9.8vs.13.3<br>Paciente 6: 12.7vs.9.0<br>Paciente 7: 12.9vs.3.2|NR|**Todos os pacientes utilizavam**<br>**imunossupressores na linha de base e**<br>**mantiveram após o uso do RTX**<br>**Tempo para recuperar células CD20+:**<br>9.7 (2.1)|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||Paciente 8: 23.0vs.3.9<br>Todos: 14.0 (DP: 4.4) vs.10.5<br>(DP:4.9)||||
|**Rizzo et al.**<br>**2016 (124)**|**RC (excreção de proteína na urina**<br>**<0.3 g/dia):**1 paciente|NR|**Proteinúria (g/24h), basal vs.**<br>**última visita do seguimento:**<br>Paciente 1:3.9 vs.0.15<br>Paciente 2: 6.2 vs. 12.7<br>Paciente 3:11 vs.8<br>Paciente 4: 11 vs.10<br>Paciente5:9.4vs.6.5|NR|NR|NR|
||**Remissão:**<br>Paciente 1:Não<br>Paciente 2: Sim||||||
||Paciente 3:Não<br>Paciente 4: Sim||||**Uso de prednisolona (mg/dia)**<br>Paciente 1:5 vs.0.1||
|**Ochi et al.**<br>**2012 (125)**|**Relapso**<br>**Antes de RTX vs. depois de RTX**<br>Paciente 1:0 vs.0<br>Paciente 2: 6 vs. 1.5<br>Paciente 3:0 vs.0<br>Paciente 4: 3 vs.0.5|NR|NR|NR|Paciente 2: 20 vs. 9<br>Paciente 3: 20 vs. 30<br>Paciente 4: 29 vs.19|NR|  
RTX: rituximabe;RC: remissão completa; RP:remissão parcial;GESF; glomeruloesclerose segmentar focal; DLM: doença de lesão mínima; GM: glomerulopatia membranosa;eGFR: taxa de filtração glomerular estimada; DP: desvio padrão; NA: não se aplica; NR: não reportado.  
**Tabela 18 –** Desfechos de segurança reportados nos estudos que analisaram o rituximabe para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Evento adversos**|**El-Reshai**<br>**2012(**|**d et al.**<br>**121)**|**Rao et**<br>**(12**|**al. 2016**<br>**2)**|**Fernandez-F**<br>**2009 **|**resnedo et al.**<br> **(123)**|**Rizzo et**<br>**(1**|**al.  2016**<br>**24)**|**Ochi et al.**|**2012 (125)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Grupo **|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|
|Infecções Respiratória|NR|NA|1|NA|NR|NA|0|NA|NR|NA|
|Reações às infusões|5|NA|3|NA|NR|NA|0|NA|NR|NA|
|EA não sérios|3|NA|NR|NA|NR|NA|0|NA|NR|NA|
|Interrupção/suspensão do<br>tratamento|5|NA|1|NA|NR|NA|0|NA|NR|NA|  
RXT: rituximabe; EA: eventos adversos; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 6 -** Qual a eficácia e a segurança do micofenolato (sódico e mofetila) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 19 –** Descrição do estudo que analisaram o micofenolato de mofetila para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor,**<br>**ano**|**Desenho do estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Dimkovic**<br>**et al.**<br>**2009**<br>**(126)**|Série de casos<br>prospectiva|Determinar a eficácia<br>e segurança do MMF<br>como terapia de<br>resgate|GESF, GM,<br>GNMP,GNMSP e<br>DLM; pacientes que<br>não atingiram remissão<br>com imunossupressores,<br>ET- dependentes ou<br>ET-resistentes; todos<br>pacientes haviam<br>recebido ET e CF no<br>passado|500 mg de MMF 2 vezes por dia<br>nas primeiras 2 semanas, no total<br>1500 mg MMF nas próximas duas<br>semanas e então 1000 mg 2x ao dia;<br>pacientes com falência renal crônica<br>dose máxima de 1500 mg + ET de<br>baixa dose**(MMF)**|NA|Alto<br>(Estudo não<br>randomizado, não<br>comparativo para<br>avaliar eficácia)|  
|**Autor,**<br>**ano**|**Desenho do estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Choi et**<br>**al. 2002**<br>**(127)**|Série de casos<br>retrospectiva|Avaliamos o uso de<br>MMF para tto<br>empírico de<br>glomerulopatias<br>primárias|GESF, DML, GNMP,<br>NIgA, GN;pacientes<br>que não atingiram<br>remissão com<br>imunossupressores, ET-<br>dependentes ou ET-<br>resistentes; que<br>receberam MMF por<br>pelo menos 3 meses<br>como tto primária ou<br>adjuvante|A maioria dos pacientes receberam<br>MMF inicial de 0.5-0.75g BID<br>eavançou conforme apropriado ou<br>como tolerado para 0.5g TID ou<br>1.0g BID, 1 paciente recebeu 1.5g<br>BID + ET<br>**(MMF)**|NA|Alto<br>(Série de casospara<br>avaliar eficácia)|  
MMF: micofenolato de mofetila; ET: esteroides; CF: ciclofosfamida; GESF; glomeruloesclerose segmentar focal; GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa;NIgA:nefropatia por IgA; DLM: doença de lesão mínima; tto: tratamento; NA: não se aplica.  
**Tabela 20 –** Caraterísticas dos pacientes incluídos nos estudos que analisaram o micofenolato de mofetila para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle**<br>**(n)**|**Causas da SN**|**Idade**<br>**Intervenção**<br>**(anos), média**<br>**(DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**Medicamentos utilizados**<br>**anteriormente ou concomitante ao**<br>**MMF (n pacientes)**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|
|**Dimkovic**<br>**et al. 2009**<br>**(126)**|MMF (51)|NA|GM (n = 12), GNMP(n = 15),<br>GNMSP (n = 10), GESF (n = 13) e<br>DLM (n =1);|41.2(13.6)|30 (59)|**Medicamentos utilizados**<br>**anteriormente ***<br>ET:51; CF: 17<br>AZA: 5; CPA: 6|12 meses|
|**Choi et al.**<br>**2002 (127)**|MMF (46)|NA|GESF (n:18; 39.1%); DML (n:7;<br>15.2%);GNMP (n:17; 37%);NIgA (n:<br>3)/GN(n:1): 4(8.7%)|45.5 (16.4)|28 (61)|**Medicamentos concomitante**<br>ET:31; CF: 1<br>AZA: 1;CPA: 5|6 meses|  
MMF: micofenolato de mofetila;GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa GESF; glomeruloesclerose segmentar focal; NIgA: nefropatia por IgA DLM: doença de lesão mínima; tto; tratamento; * suspensão antes do início do tto com MMF; DP: desvio padrão.  
**Tabela 21 –** Desfechos de eficácia reportados nos estudos que analisaram o micofenolato de mofetilapara o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**33 (47%) daqueles que completaram o**<br>**estudo responderam a terapia:**<br>RC: 14<br>RP: 20||**UPCRbasal vs. 12 meses nos**<br>**subgrupos, mediana (IQ):**<br>Geral: 3.72 (2.13–6.48) vs. 0.84|<0.001|**Dose de ET (mg/d), mediana (IQ):**<br>Antes de MMF vs. depois de MMF<br>20 mg (I20–25) vs. 15 mg (10–20)|< 0.001|
||**RC nos subgrupos:**<br>GESF: 3 de 13<br>GM: 4 de 11<br>GNMP: 3 de 13<br>GNMSP: 3 de 9||(0.42–2.01)<br>GM: 3.52 (2.61–5.08) vs. 1.52<br>(0.06–1.78)<br>GNMP: 4.31 (1.59–6.53) vs. 1.03<br>(0.45–3.54)<br>GNMSP: 4.97 (1.14–10.28) vs.||**Dose de MMF durante o estudo,**<br>**mediana (IQ):**<br>Baseline: 1,000 mg (1,000–1,500)<br>Aos 12 meses**:**2,000 mg (1,500–2,000)<br>**Taxa de sedimentação de eritrócitos,**|< 0.001|
|**Dimkovic**<br>**et al. 2009**<br>**(126)**|**RP nos subgrupos:**<br>GESF: 5 de 13<br>GM: 5 de 11<br>GNMP: 5 de 13<br>GNMSP: 4 de 9<br>DML:1<br>**Não atingiu remissão nos subgrupos:**<br>GESF: 2 de 13<br>GM: 2 de 11<br>GNMP: 1 de 13<br>GNMSP: 1 de 9||0.51 (0.34–0.94)<br>GESF: 3.26 (1.52–7.92) vs. 0.86<br>(0.45–2.07)<br>**Proteinúria (g/24h), mediana**<br>**(IQ):**<br>Baseline:4.9 (2.9–8.4)<br>Aos 3 meses:3.0 (1.69–4.8)<br>Aos 6 meses:1.8 (0.49–3.62)<br>Aos 9 meses:1.07 (0.4–3.22)<br>Aos 12 meses:1.28 (0.5–2.9)<br>**Proteinúria nos subgrupos**<br>**basal vs. 12 meses:**|0.000<br>basal<br>vs. 12<br>meses|**mediana (IQ):**<br>Baseline:39 (16.0–58.3)<br>Aos 3 meses:32 (10.0–53.5)<br>Aos 6 meses: 27 (15.7–51.2)<br>Aos 9 meses:20 (10.0–37.3)<br>Aos 12 meses:17 (8.0–40.5)<br>**Pressão Arterial Sistólica, media (DP):**<br>Baseline:135.3 (17.8)<br>Aos 3 meses:130.5 (14.4)<br>Aos 6 meses: 132.1 (15.5)<br>Aos 9 meses:131.2 (14.5)<br>Aos 12 meses:129.5 (14.4)|0.000<br>basal vs.<br>12 meses<br>0.018<br>basal vs.<br>12 meses|  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Preditores de RC:**<br>Idade RR: 0.94 (IC 95%: 0.88–0.99)<br>**Preditores de RP:**<br>Idade RR: 0.95 (IC 95%: 0.91–0.99)|0.036<br>0.047|GESF: 5.1 (2.7–8.9) vs. 1.9<br>(0.56–3.05)<br>GM: 4.7 (3.12–6.57) vs. 1.4<br>(0.11–2.7)<br>GNMP: 5.3 (3.19–8.6) vs. 1.92<br>(0.5–4.2)<br>GNMSP: 7.03 (1.6–12.23) vs.<br>0.76 (0.45–1.34)|<0.001|||
||||**ProteinúriaAUC, entre basal e**|<0.001|||
||||**3 meses vs. AUC entre 9 e 12**<br>**meses, média (DP):**<br>Geral: 4.99 (3.46) vs. 2.16 (2.46)<br>GESF: 4.44 (2.73) vs. 2.51 (3.05)<br>GM:3.79 (1.25) vs. 1.67 (1.61)<br>GNMP: 5.38 (4.3) vs. 2.76 (2.47)<br>GNMSP: 4.40 (3.25) vs. 1.52|<0.001<br><0.001<br><0.001<br>0.000<br>basal|||
||||(2.57)|vs. 12|||
|||||meses|||
||||**Proteínas totais (g/l), média**<br>**(DP):**<br>Baseline:54.1 (9.10)<br>Aos 3 meses:58.4 (9.4)<br>Aos 6 meses:59.2 (8.9)|0.000|||
||||Aos 9 meses:61.2 (7.2)<br>Aos 12 meses:62.3 (9.4)<br>**Albumina (g/l), média (DP):**<br>Baseline:30.8 (7.8)<br>Aos 3 meses:33.8 (7.6)<br>Aos 6 meses:36.3(8.1)|basal<br>vs. 12<br>meses|||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||Aos 9 meses:37.5 (8.0)<br>Aos 12 meses:37.8 (8.2)<br>**Colesterol (g/l), média (DP):**<br>Baseline:9.2 (3.0)<br>Aos 3 meses:8.4 (2.8)<br>Aos 6 meses:7.6 (2.4)<br>Aos 9 meses:6.9 (1.9)<br>Aos 12 meses:7.1 (2.3)<br>**eGFR (ml/min)basal e 12 meses**<br>**nos subgrupos, média (DP)**:<br>Geral: 62.1 (31.8) vs. 65.3 (31.8)<br>GESF: 56.2 (33.2) vs. 70.7 (39.6)<br>GM: 55.5 (21.1) vs. 62.2 (19.6)<br>GNMP: 64.7 (40.5) vs. 59.9<br>(34.4)<br>GNMSP: 71.6 (26.3) vs. 69.1<br>(32.2)|0.000<br>basal<br>vs. 12<br>meses<br>NS|||
|**Choi et al.**<br>**2002 (127)**|**RC:**<br>Geral:7 (15.6%) de 46; média de<br>redução de proteína de 98%<br>DLM: 3 de 5 pacientes inicialmente<br>nefróticos, sendo que 1 paciente sofreu 2<br>relapsos<br>GESF: 2<br>GM: 2<br>**RP:**17 (37.8%) de 46; média de redução<br>de proteína de 74%<br>GESF: 6||**UPCR pré vs. pós MMF,**<br>**mediana (min.-máx.):**<br>Geral: 4.7 (<0.1, 20.3) vs. 1.1<br>(<0.1, 14.3)<br>GESF: 2.7 (0.1, 20.3) vs. 0.8<br>(0.1, 8.2)<br>DLM: 4.6 (0.1, 6.0) vs. 0.1 (0.1,<br>5.8)<br>GM: 7.3 (0.1, 18.5) vs. 1.5 (0.1,<br>14.3)|<0.001<br>0.001<br>0.05<br>0.001<br><0.001<br>0.01|**Dose de MMF (g/d), mediana (min.-**<br>**max.):**<br>2 (0.75, 3.00)<br>**Duração da tto com MMF mediana**<br>**(min.-max.):**<br>8 meses (3, 26)<br>Uso de<br>**Mudança mediana (min.-máx.) na**<br>**pressão arterial:**<br>- 5.3 (-32, 19.3) mm Hg|0.008|  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||GM: 8<br>NIgA: 1 (sofreu relapso depois)<br>GNMP:1<br>**Não atingiu remissão (aumento de**<br>**proteinúria):**<br>Geral:5 (11%)<br>GESF: 2 (11.1%)<br>GM: 2||**Albumina sérica (g/l), pré vs.**<br>**pós MMF, mediana (min.-**<br>**máx.):**<br>Geral (n:39): 3.4 (1.4, 4.6) vs. 4.1<br>(1.7, 4.8)<br>GESF: 3.7 (1.4, 4.6) vs. 4.2 (2.7,<br>4.8)<br>DLM: 3.5 (1.4, 4.6) vs. 4.2 (1.7,<br>4.6)<br>GM: 2.95 (2.10, 4.50) vs. 3.6<br>(2.2, 4.6)<br>**Creatinina séricamg/dL, pré vs.**<br>**pós MMF, média (DP):**<br>Geral: 1.8 (1.2) vs. 1.8 (1.4)<br>GESF:2.3 (1.5) vs. 2.5 (1.9)<br>DLM:1.07 (0.35) vs. 1.0 (0.3)<br>GM:1.5 (0.8) vs. 1.3 (0.7)<br>**Colesterol sérico (mg/dl),**<br>**mediana (min.-máx.):**<br>Geral (n:29): 275 (168, 795) vs.<br>218 (140,309)<br>**GFRml/min/1.73 m**<sup>**2**</sup><br>Geral: 59.4 (11.4, 191.0) vs. 67.3<br>(10.3, 191.0)|NS<br>0.006<br>NS<br>NS<br>NS<br>0.03<br><0.001<br>0.032|**GERAL:**<br>16 dos 31 (51,6%) pacientes inicialmente<br>nefróticos melhoraram a o limite de<br>proteinúria para não nefrótico no final do<br>estudo<br>4 dos 23 (17.4%) pacientes inicialmente<br>com insuficiência renal foram resolvidas<br>7 de 46 (15.2%) tiveram suspenso o<br>IECA/BRAs, sendo que 28 (60.9%)<br>continuaram a mesma dose e 11 (23.9%)<br>aumentaram a dose<br>**GESF:**<br>12 pacientes com insuficiência renal<br>inicial:<br>1 foi resolvido; 2 experenciaram uma<br>melhora da função renal; em 3 a função<br>renal continuou deteriorada; outros 7<br>pacientes a função renal estabilizaram em<br>4-12 meses;<br>De 17 pacientes recebendo IECA/BRAs,<br>4 aumentaram a dose;7 continuaram a<br>mesma dose e 6 diminuíram a dose<br>De 12 pacientes recebendo ET, em 8<br>foram retirados o ET sem relapso;<br>1 paciente teve relapso e os ET foram<br>retomados; 3 continuaram com baixa<br>dose||  
|**Autor**|**Remissão/ Relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor**<br>**p**<br>**Outros desfechos**<br>**Valor p**|
|---|---|---|---|---|
|||||3 pacientes CF-dependentes e 1 paciente|
|||||AZA-dependente não necessitou utilizá-<br>los mais.|  
MMF:micofenolato de mofetila;ET: esteroides; CF: ciclofosfamida; AZA: azatioprina; IECA: inibidor da enzima conversora da angiotensina; BRAs: bloqueadores dos receptores da angiotensina II; RC: remissão completa; RP: remissão parcial; UPCR: relação proteína/ creatinina; AUC: área sob a curva;eGFR: taxa de filtração glomerular estimada;GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa; GESF; glomeruloesclerose segmentar focal; DLM: doença de lesão mínima;tto: tratamento; RR: risco relativo; IQ: intervalo interquartil; DP: desvio padrão; min.-máx.: valores mínimo e máximo; IC95%: intervalo de confiança de 95%; NS: estatisticamente não significante; NR: não reportado.  
**Tabela 22–** Desfechos de segurança reportados nos estudos que analisaram o micofenolato de mofetila para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Evento adversos**|**Dimkovic et al. 2009 (126)**|**Choi et al. 2002 (127)**|
|---|---|---|
|**Grupo**|**MMF**|**MMF**|
|Leucopenia|NR|2|
|EAgastrointestinais|Frequente,mas valores NR|Frequente,mas valores NR|
|EA sérios|NR|1(linfoma)|
|Suspensão do tto|3|5|
|Morte|1|NR|  
EA: eventos adversos; MMF:micofenolato de mofetila; NR: não reportado.  
- **Questão de Pesquisa 7 -** Qual a eficácia e a segurança do tacrolimo (TAC) para o tratamento de Glomeruloesclerose Segmentar e Focal (GESF) com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 23 –** Descrição dos estudos que analisaram o tacrolimo para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ren et al. 2013**<br>**(128)**|ECR, aberto|Comparar a<br>eficácia do TAC e<br>CF|GESF; adultos<br>(>18-75 anos) ET-<br>resistentes (não<br>atingiu remissão<br>apóstto de 12<br>semanas de 1,0<br>mg/kg /dia de ET<sup>1</sup>)<br>ou ET-dependentes<br>(relapso com dose<br>máxima)|TAC (0.01 mg/kg/d) + ET<sup>1</sup>0.5<br>mg/kg/dia; dose foi ajustada<br>atingir níveis entre 5 e 10 ng / ml.<br>Após 8 semanas de tto, diminuiu-<br>se 5 mg de ET<sup>1</sup>a cada 2 semanas<br>até atingir 15 mg/dia e mantida<br>durante 8 semanas para retirada<br>gradual<br>**(TAC)**|CF (0.5-0.75<br>g/m<sup>2</sup>) + E<sup>1</sup><br>0.8 mg/kg/dia<br>**(CF)**|Alto<br>Métodos de randomização e<br>sigilo de alocação não<br>reportados, não foi utilizado<br>método de correção das perdas<br>de seguimento.|
|**Fan et al. 2013**<br>**(129)**|Série de<br>casos<br>prospectiva|Analisar a<br>eficácia e<br>segurança do<br>TAC|GESF; DLM;<br>GNMSP;<br>NIgA;GNMP;<br>adultos (>18-65<br>anos) ET-<br>resistentes (falha de<br>resposta apóstto de<br>8 semanas de 1,0<br>mg/kg /dia de<br>ET<sup>1</sup>durante 16<br>semanas|TAC (0.05-0.1 mg/kg/d) dividido<br>em duas doses de 12/12h e a dose<br>foi titulada para atingir<br>concentrações sanguíneas de 5-10<br>ng / ml durante os primeiros 6<br>meses e, em seguida, reduzida<br>para atingir níveis de 4-6 ng / ml<br>nos subsequentes 6 meses. + ET<sup>1</sup><br>**(TAC)**|NA|Alto<br>(Série de casospara avaliar<br>eficácia)|
|**Ramachandran**<br>**et al. 2014**<br>**(130)**|Série de<br>casos<br>prospectiva|Analisar a<br>eficácia e<br>segurança do<br>TAC|GESF; adultos<br>(>18-60 anos)ET-<br>resistentes|TAC (0.01 mg/kg/d) atéatingir<br>níveis entre 5 e 10 ng/ml + ET<br>reduzidos para 0.05 mg/kg/d ao<br>longi de 4- 6 semanas<br>**(TAC)**|NA|Alto<br>(Série de casos para avaliar<br>eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Li et al.  2009**<br>**(131)**|Série de<br>casos<br>prospectiva|Reportar o uso de<br>TAC em<br>pacientes que não<br>responderam à CF|GESF; DLM;<br>GNMSP;pacientes<br>(>16 anos) ET-<br>resistentes (não<br>atingiu remissão<br>apóstto de pelo<br>menos 3 meses de<br>1,0 mg/kg /dia de<br>ET<sup>1</sup>) que não<br>responderam à CF<br>com uma dose total<br>de pelo menos 6g|TAC (0.05-0.1 mg/kg/d) dividido<br>em duas doses de 12/12h; dose foi<br>ajustada até atingir concentrações<br>sanguíneas de 5-10 ng / ml + ET<sup>1</sup><br>inicial a 0,5 mg/kg/d e mantida<br>durante 8 a 12 semanas de acordo<br>com a resposta. Após, a dose de<br>ET<sup>1</sup>foi reduzida em 5 mg a cada 2<br>semanas a 20 mg em dias<br>alternados e mantidos por 8<br>semanas, seguido de redução de<br>8 a 16 semanas até a retirada<br>completa.<br>**(TAC)**|NA|Alto<br>(Estudo não comparativo,<br>amostra pequena para avaliar<br>eficácia)|  
TAC: tacrolimo; CF: ciclofosfamida; ET: esteroides; ET<sup>1</sup> : prednisona; GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa; GESF; glomeruloesclerose segmentar focal; NIgA: nefropatia por IgA; DLM: doença de lesão mínima; ECR: ensaio clínico randomizado; tto; tratamento; NA: não se aplica.  
**Tabela 24 –** Características dos pacientes incluídos nos estudos que analisaram o tacrolimo para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Causas da SN**|**Idade**<br>**Intervenção**<br>**Média (DP)**|**Idade Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|
|**Ren et al. 2013**<br>**(128)**|TAC (15)|CF (18)|GESF (100%)|32 (83)|31 (83)|11 (73)|13 (72)|12 meses|  
|**Fan et al. 2013**<br>**(129)**|TAC (24)|NA|GESF: 7<br>(29.2%)<br>DLM: 8<br>(33.3%)<br>GNMSP: 6<br>(25.0%)<br>NIgA:2 (8.3%)<br>GNMP: 1<br>(4.2%)|28.2 (12.4)|NA|16 (67)|NA|Tto: 6 meses<br>Após tto: 6<br>meses|
|---|---|---|---|---|---|---|---|---|
|**Ramachandran**<br>**et al. 2014**<br>**(130)**|TAC (44)|NA|GESF (100%);<br>Variações de<br>GESF:<br>NOS: 33<br>(75%);<br>CEL: 8<br>(18,1%);TIP: 3<br>(6,8%)|25.1 (8.2)|NA|33 (75)|NA|76.64 semanas<br>(16.86)<br>Tto: 48<br>semanas<br>Após tto: 12<br>semanas|
|**Li et al.  2009**<br>**(131)**|TAC (19)|NA|GESF: 8<br>DLM: 6<br>GNMSP: 5|27.1 (9.4)|NA|13 (68)|NA|Tto: pelo<br>menos 24<br>semanas<br>Total: 37.6<br>meses(13.4)|  
TAC: tacrolimo; CF: ciclofosfamida; GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa; GESF; glomeruloesclerose segmentar focal; NIgA: nefropatia por IgA; DLM: doença de lesão mínima; tto; tratamento;NOS: variações sem especificação; TIP: forma com lesão no polo urinário; CEL: variante celular; DP: desvio padrão; min-max: mínimo e máximo; NA: não se aplica.  
**Tabela 25 –** Desfechos de eficácia reportados nos estudos que analisaram o tacrolimopara o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Ren et**<br>**al.**<br>**2013(128**<br>**)**|**TAC vs. CF**|**RC**+**RP**,**n (%), TAC vs.**<br>**CF:**<br>Aos 6 meses:10 (66.7) vs.10<br>(55.6)<br>Aos 12 meses:11 (73.3) vs. 12<br>(66.7)<br>**RC**,**n (%), TAC vs. CF:**<br>Aos 6 meses: 7 (46.7) vs. 7<br>(38.9)<br>Aos 12 meses:6 (40.0) vs.9<br>(50.0)<br>**RP**,**n (%), TAC vs. CF:**<br>Aos 6 meses:3 (20.0) vs. 3<br>(16.7)<br>Aos 12 meses:5 (33.3) vs. 3<br>(16.7)|NS|**Creatinina sérica (μmol/l),**<br>**média (DP), basal vs. 6**<br>**meses vs. 12 meses**<br>TAC: 86 (7) vs.89.7 (7.8) ¥<br>vs. 94.4 (11.8) ¥<br>CF:114 (13) vs. 101.5<br>(12.1) vs.103.7 (10.9)<br>**Proteinúria (g/dia),**<br>**mediana (min-máx) ou**<br>**média (DP)**<br>**Basal vs. 6 meses vs. 12**<br>**meses**<br>TAC: 4.1 (0.5) vs. 0.72<br>(0.08–3.06) *, ¥ vs. 0.11<br>(0.06–1.28) *, ¥<br>CF:3.7 (0.5) vs. 0.79 (0–<br>3.48) * vs.  0.16 (0.05–|¥ NS TAC<br>vs. CS<br>* <0.05 vs.<br>basal|**Dose inicial e concentração de TAC**<br>**após 2 semanas, média (DP):**<br>0.089 (0.004) mg/kg/dia; 8.7 (0.5)<br>ng/ml|NR|
|||**Sem resposta, TAC vs. CF:**<br>Aos 6 meses:5 (33.3) vs. 8<br>(44.4)<br>Aos 12 meses:4 (26.7) vs. 6<br>(33.3)<br>**Relapso**,**n (%), TAC vs.**<br>**CF:**<br>26.7% vs. 27.8%||4.45) *<br>**Albumina sérica (g/l,**<br>**mediana (min-máx) ou**<br>**média (DP),**<br>**Basal vs. 6 meses vs. 12**<br>**meses**<br>TAC: 25 (2) vs. 39.7 (0.9)<br>*¥ vs. 38 (9–45) *¥||||  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||CF:24 (2) vs. 37.5 (1.8) *<br>vs.38 (9–45) *||||
|**Fan et**<br>**al.**<br>**2013(129**<br>**)**|**TAC**<br>**(Não**<br>**comparativ**<br>**o)**|**RCGera**l,**n (%):**<br>Aos 6 meses: 14 (58.3%)<br>Aos 12 meses: 11 (45.8%)<br>**RP Gera**l**, n (%):**<br>Aos 6 meses: 4 (16.7)<br>Tempo para atingir RC, média<br>(DP): 80.0 dias (46.4)<br>Aos 12 meses: 5 (20.8)<br>**RC+ RP Gera**l**, n (%):**<br>Aos 6 meses: 18 (75.0)<br>Aos 12 meses: 16 (66.7)<br>**Relapso Gera**l**, n (%):**<br>Aos 12 meses: 2 (8.3)<br>**RC + RP por subgrupo, n:**<br>GESF: 6; DLM: 6;<br>GNMSP: 4; NIgA:2;<br>GNMP: 0|NS|**Creatinina sérica (mg/l),**<br>**média (DP), basal vs. 6**<br>**meses:**<br>Geral: 0.92 (0.33) vs. 1.08<br>(0.39)<br>**eGFR (ml/min)**,**média (DP),**<br>**basal vs. 6 meses:**<br>Geral: 98.6 (42.7) vs. 97.2<br>(44.3)<br>**Albumina sérica (g/l),**<br>**média (DP), basal vs. 6**<br>**meses:**<br>Geral: 2.3 (0.9) vs. 4.3 (0.7)<br>**Proteinúria (g/dia), média**<br>**(min-máx.) Basal vs. 6**<br>**meses:**Geral: 4.2 (3.5, 5.8)<br>vs. 0.3 (0.1, 1.6)|NS<br>NS<br><0.001<br><0.001<br><0.001|**Nível efetivo de TAC**<br>**(ng / ml, média ± DP):**<br>Aos 6 meses:7.1 ± 3.4<br>Aos 12 meses: 5.6 ± 1.8<br>**Dose eficaz de TAC (mg / dia,**<br>**média ± DP)**<br>Aos 6 meses:5.0 ± 1.3<br>Aos 12 meses:3.5 ± 1.4|NR|
|||**RC por subgrupo, n:**<br>GESF: 3; DLM: 6;<br>GNMSP: 3; NIgA:2;|NS|**Colesterol (mmol/l),**<br>**média (DP), Basal vs. 6**<br>**meses:**||||  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||GNMP: 0<br>**RP por subgrupo, n:**<br>GESF: 3; DLM: 0;<br>GNMSP: 1; NIgA:0<br>GNMP: 0|NS|Geral: 11.0 (4.1) vs. 5.3<br>(1.5)||||
|||**Relapso por subgrupo, n:**<br>GESF: 1; DLM: 0;<br>GNMSP: 1; NIgA:0<br>GNMP: 0|NS|||||  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Ramach**<br>**andran**<br>**et al.**<br>**2014(130**<br>**)**|**TAC**<br>**(Não**<br>**comparativ**<br>**o)**|**RC + RPGera**l,**n (%):**<br>23 (52.2%)<br>**RCGera**l,**n (%):**<br>17 (38.6%)<br>**RP Gera**l,**n (%):**<br>6 (13.6%)<br>**Tempo para remissão,**<br>**média (DP):**<br>15.28 (6)<br>**Relapsos, n (%):**<br>Durante a redução:5 (21.7%)<br>Após tto: 7 (30.4%)<br>**Variações de GESF,**<br>**TAC sensitivo vs. TAC**<br>**resistente:**<br>GESF NOS: 18 (54.5%) vs.<br>15 (45.4%)<br>GESF CEL: 3 (37.5%) vs. 5<br>(62.5%)<br>GESF TIP: 2 (66.7%) vs. 1<br>(33%)|NR|**Creatinina sérica (mg/l),**<br>**média (DP), basal vs. 24**<br>**semanas vs. 48 semanas**<br>Geral: 0.89 (0.15) vs.1.18<br>(0.60) * vs. 0.95 (0.17) *<br>TAC sensitivo:0.90 (0.17)<br>vs. 0.94 (0.19) * vs. 0.95<br>(0.17) *<br>TAC resistente: 0.87 (0.13)<br>vs.1.43 (0.78) *<br>**eGFR (ml/min/ 1.73 m**<sup>**2**</sup>**)**,<br>**média (DP), basal vs. 24**<br>**semanas vs. 48 semanas**<br>Geral: 101.6 (24.40) vs.<br>84.22 (29.43) * vs. 91.87<br>(21.63) *<br>TAC sensitivo: 98.42 ±<br>22.37) vs.94.33 (22.27) vs.<br>91.87 (21.63)<br>TAC resistente: 105.1<br>(21.56) vs. 73.15 (32.71) *<br>**Albumina sérica (g/l),**<br>**média (DP), basal vs. 24**<br>**semanas vs. 48 semanas**<br>Geral: 2.25 (0.83) vs. 3.01<br>(1.04)* vs. 4.04(0.34)*|*<0.05 vs.<br>basal|NR|NR|  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||TAC sensitivo:2.28 (0.81)<br>vs. 3.88 (0.43)* vs. 4.04<br>(0.34) *<br>TAC resistente: 2.21 (0.86)<br>vs.2.04 (0.53)||||
|||||**Proteinúria (g/dia), média**<br>**(DP), basal vs. 24 semanas**<br>**vs. 48 semanas**<br>Geral: 4.57 (3.60) vs.2.67<br>(3.11) * vs. 0.52 (0.50) *<br>TAC sensitivo:4.57 (4.16)<br>vs.1.05 (1) * vs. 0.52 (0.50)<br>*<br>TAC resistente: 4.57 (2.98)<br>vs.4.43 (3.66)||||  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**RC**,**n (%):**<br>Geral:11 (64.7)<br>GESF:  3 (42.9)<br>DLM: 5 (100)<br>GNMSP: 3 (60)<br>**RP**,**n (%):**<br>Geral:3 (17.6)<br>GESF: 1 (14.3)<br>DLM: 0 (0)<br>GNMSP: 2 (40)||**Proteinúria (g/dia),**<br>**mediana (IQ) basal vs. 24**<br>**semanas vs. 48 semanas**<br>Geral:6.7 (4.5-12.9) vs. 0.2<br>(0.1-6.3) * vs.0.2 (0.1-6.7)<br>*<br>GESF: 7.0 (4.5-8.5) vs. 0.9||||
|**Li et al.**<br>**2009(131**<br>**)**|**TAC**<br>**(Não**<br>**comparativ**<br>**o)**|**Sem resposta**,**n (%):**<br>Geral:3 (17.6)<br>GESF: 3 (42.9)<br>DLM: 0 (0)<br>GNMSP: 0 (0)<br>**Tempo para remissão,**<br>**semanas, média (DP):**<br>Geral: RC:5.6 (1.4); RP:8.0<br>(5.1)<br>GESF: 5.8 (1.3)<br>DLM: 4.4 (0.9)<br>GNMSP: 5.2 (2.3)|0.05<br>GESF<br>vs.<br>DLM|(0.1-6.3) vs. 1.4 (0.1-6.7)<br>DLM: 6.4 (5.4-6.8) vs. 0.1<br>(0.1-0.2) vs. 0.1 (0.1-0.2)<br>GNMSP: 7.5 (5.3-12.9)<br>vs.0.2 (0.1-1.8) vs.  0.1<br>(0.1-2.3)<br>**Albumina sérica (g/l),**<br>**mediana (IQ) basal vs. 24**<br>**semanas vs. 48 semanas**<br>Geral:17.5 (7.4, 26.3) vs.<br>42.4 (8.7, 48.1) * vs. 42.4<br>(15.4, 45.6) *|*<0.00<br>1 vs.<br>basal|**Dose média (DP) de TAC**<br>**(mg/kg/d):**<br>Nas primeiras 24 semanas: 0,06 (0,01)<br>Nas 24 seguintes:  0,04 (0,01)|NR|
|||**Relapsos, n:**<br>Geral:5<br>GESF: 1<br>DLM: 2||||||  
|**Autor**|**Grupos de**<br>**comparaçã**<br>**o**|**Remissão/ relapso**|**Valor**<br>**p**|**Desfechos bioquímicos**<br>**relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||GNMSP: 2||||||
|||**Tempo médio (DP) para**<br>**relapso:**<br>37.6 meses(13.4)||||||  
TAC: tacrolimo; CF: ciclofosfamida; GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa; GESF; glomeruloesclerose segmentar e focal; NIgA: nefropatia por IgA; DLM: doença de lesão mínima; tto; tratamento; NOS: variações sem especificação; TIP: forma com lesão no polo urinário; CEL: variante celular; IQ: intervalo interquartil; IC 95%: intervalo de confiança de 95%; DP: desvio padrão; min.-máx.: valores mínimo e máximo;NS: estatisticamente não significante; NR: não reportado; NA: não se aplica.  
**Tabela 26 –** Desfechos de segurança reportados nos estudos que analisaram o tacrolimo para o tratamento de Glomeruloesclerose Segmentar e Focal  
|**Evento adversos**|**Fan et al. 20**|**13(129)**|**Ren et al. 2**|**013(128)**|**Ramachandra**<br>**2014(130**|**n et al.**<br>**)**|**Li et al.  200**|**9(131)**|
|---|---|---|---|---|---|---|---|---|
|**Grupo **|**TAC, n(%)**|**NA**|**TAC, n(%)**|**CF, n(%)**|**TAC, n(%)**|**NA**|**TAC, n**|**NA**|
|Tremor nas mãos|2(8.3)|NA|NR|NR|5(11.3%)|NA|NR|NA|
|Nefrototoxicidade reversível<br>aguda|3 (12.5)|NA|NR|NR|9 (20.4%)|NA|1|NA|
||||||||Geral:9 (47.4)<br>GESF: 5<br>(62.5)||
|1 ou + EA|NR|NA|NR|NR|29 (65.9%)|NA|DLM: 2<br>(33.3)<br>GNMSP: 2<br>(40.0)|NA|
|Nefrototoxicidadepersistente|1(4.2)|NA|NR|NR|2(04.5%)|NA|NR|NA|
|Hepatotoxicidade|NR|NA|NR|NR|NR|NA|2|NA|  
|**Evento adversos**|**Fan et al. 20**|**13(129)**|**Ren et al. 2**|**013(128)**|**Ramachandr**<br>**2014(13**|**an et al.**<br>**0)**|**Li et al.  2**|**009(131)**|
|---|---|---|---|---|---|---|---|---|
|**Grupo **|**TAC, n(%)**|**NA**|**TAC, n(%)**|**CF, n(%)**|**TAC, n(%)**|**NA**|**TAC, n**|**NA**|
|Diarreia|3(12.5)|NA|NR|NR|10(22.7%)|NA|1|NA|
|Náusea/vômito|NR|NA|0|2(11.1%)|1(2.2%)|NA|1|NA|
|Palpitação|1(4.2)|NA|NR|NR|NR|NA|NR|NA|
|**Infecção**|NR|NA|2 (13.3%)*|9 (50.0%)|19 (43.1%)|NA|4|NA|
|Pneumonia|1 (4.2)|NA|NR|NR|NR|NA|2|NA|
|Infecção respiratória superior|2 (8.3)|NA|0|2|NR|NA|NR|NA|
|Infecção trato urinário|1 (4.2)|NA|0|4|NR|NA|2|NA|
|Sepse|NR|NA|1|0|NR|NA|NR|NA|
|Pulmão|NR|NA|1|2|NR|NA|NR|NA|
|Herpes Zoster|NR|NA|0|1|NR|NA|NR|NA|
|Glicose elevada|NR|NA|4(26.7%)*|0|2(04.5%)|NA|NR|NA|
|Diabetes Mellitus|NR|NA|NR|NA|8(18.0%)|NA|1|NA|
|Perfil lipídico com deficiência|NR|NA|NR|NA|4(09%)|NA|NR|NA|
|Novo início / piora de<br>hipertensãopreexistente|NR|NA|NR|NA|9 (20.4%)|NA|5|NA|
|Suspensão do tto|4(14.8)|NA|1|0|0|NA|1|NA|  
TAC: tacrolimo; CF: ciclofosfamida; EA: eventos adversos; * p<0.05 TAC vs. CF; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 8 -** Qual a eficácia e segurança do clorambucila em relação a ciclofosfamida (ambos associados à prednisona ou metilprednisolona) para Glomerulonefrite Membranosa? **Questão de Pesquisa 9 -** Qual a eficácia e a segurança do uso de ciclofosfamida ev e oral (ambos associados à prednisona ou metilprednisolona) para Glomerulonefrite Membranosa? **Questão de Pesquisa 10 -** Qual a eficácia e a segurança do Rituximabe para o tratamento de Glomerulonefrite Membranosa com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Questão de Pesquisa 11 -** Qual a eficácia e a segurança do tacrolimo em relação à ciclosporina para o tratamento de Glomerulonefrite Membranosa com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
(((("Rituximab"[Mesh] OR ("rituximab"[MeSH Terms] OR "rituximab"[All Fields])) OR ("Tacrolimus"[Mesh] OR ("tacrolimus"[MeSH Terms] OR "tacrolimus"[All Fields]))) OR (("Chlorambucil"[Mesh] OR ("chlorambucil"[MeSH Terms] OR "chlorambucil"[All Fields])) OR ("Cyclophosphamide"[Mesh] OR ("cyclophosphamide"[MeSH Terms] OR "cyclophosphamide"[All Fields])))) AND (("Glomerulonephritis, Membranous"[Mesh] OR ("glomerulonephritis, membranous"[MeSH Terms] OR ("glomerulonephritis"[All Fields] AND "membranous"[All Fields]) OR "membranous glomerulonephritis"[All Fields] OR ("membranous"[All Fields] AND "glomerulonephritis"[All Fields]))) OR ("Nephrotic Syndrome"[Mesh] OR ("nephrotic syndrome"[MeSH Terms] OR ("nephrotic"[All Fields] AND "syndrome"[All Fields]) OR "nephrotic syndrome"[All Fields])))) AND (randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR "drug therapy"[Subheading] OR randomly[tiab] OR trial[tiab] OR groups[tiab] NOT ("animals"[MeSH Terms] NOT "humans"[MeSH Terms]))  
Total: 1698 referências  
Data de acesso: 09/10/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **EMBASE:** -->
('nephrotic syndrome'/exp OR 'nephrotic syndrome' OR 'membranous glomerulonephritis'/exp OR 'membranous glomerulonephritis') AND [embase]/lim  
AND  
('cyclophosphamide' OR 'cyclophosphamide'/exp OR cyclophosphamide OR 'chlorambucil' OR ' chlorambucil'/exp OR chlorambucil) AND [embase]/lim OR ('rituximab' OR 'rituximab'/exp OR rituximab OR 'tacrolimus' OR 'tacrolimus'/exp OR tacrolimus) AND [embase]/lim  
AND  
('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim Total:  490 referências Data de acesso: 09/10/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 2188 referências (1698 no MEDLINE e 490 no Embase). Destas, 243 foram excluídas por estarem duplicadas.  
Um mil novecentos e quarenta e cinco referências foram triadas por meio da leitura de título e resumos, das quais 51 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
No total, 33 estudos foram excluídos: duas revisões sistemáticas – 1) por avaliar esteroides, ciclofosfamida e ciclosporina e 2) por incluir pacientes portadores de nefropatia secundária em sua população de estudo; oito estudos (seis ensaios e dois observacionais) por analisar o Tacrolimo ou conjugado com outro imunossupressor, exceto a ciclosporina; três estudos (um ensaio clínico e dois observacionais) por conter criança em sua população e não estratificar os resultados por idade; quatro ensaios clínicos por analisar a eficácia do clorambucila com os esteroides; duas cartas ao editor/ comentários; dois estudos por analisar eficácia da ciclofosfamida; um ensaio clínico por analisar a ciclosporina vs. esteroides e dois estudos séries de casos; nove por não abordar desfechos de interesse.  
Foram incluídos três estudospara a questão de pesquisa 8<sup>49, 56, 132</sup> , sendo um por busca manual<sup>132</sup> .  
Foram incluídos cinco estudos de seis referências<sup>55, 92, 133-135</sup> para a questão de pesquisa 9, sendo três por busca manual<sup>92, 133-135</sup> .  
Foram incluídos sete estudos para a questão de pesquisa 10<sup>121, 136-141</sup> , sendo quatro por busca manual<sup>136, 139-141</sup> .  
Foram incluídos dois estudos para a questão de pesquisa 11<sup>63, 64</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos estudos e seus resultados** -->
A seguir serão apresentadas as descrições dos estudos e seus resultados para cada questão de pesquisa.  
**Questão de Pesquisa 8 -** Qual a eficácia e segurança de clorambucila em relação a ciclofosfamida (ambos associados à prednisona ou metilprednisolona) para Glomerulonefrite Membranosa?  
**Tabela 27 –** Descrição dos estudos que compararam clorambucila e ciclofosfamida para o tratamento de Glomerulonefrite Membranosa **.**  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ponticelli et al.**<br>**1998 (49)**|ECR, aberto|Avaliar se os<br>agentes<br>alquilantes tem<br>efeitos similares<br>quando<br>alternados com<br>corticoides|Adultos (>18<br>anos) com<br>nefropatia<br>membranosa<br>idiopática|CA0.2 mg/kg por dia<br>/ ciclo de 1 mês<br>durante 6 meses +<br>corticosteroides**<br>**(CA)**|CF oral 2,5 mg/kg<br>diário durante 6<br>meses +<br>corticosteroides**<br>**(CF)**|Moderado<br>Análise não foi por intenção de<br>tratar (perdas não computadas na<br>análise final)|
|**Reichert et al.**<br>**1994 (132)**|ECR|Comparar<br>clorambucila oral<br>com<br>ciclofosfamida<br>intravenosa|Adultos (>18<br>anos) com<br>nefropatia<br>membranosa<br>idiopática e<br>função renal<br>deteriorada|CA 0.15 mg/kg por<br>dia; ciclo de 1 mês<br>durante 6 meses +<br>corticosteroides*<br>**(CA)**|CF intravenoso750<br>mg/m<sup>2</sup>em intervalos<br>mensais durante 6<br>meses +<br>corticosteroides***<br>**(CF)**|Alto<br>Método de randomização, sigilo<br>de alocação e cegamento não<br>reportados, análise não foi por<br>intenção de tratar|
|**Branten et al.**<br>**1998 (56)**|Estudo<br>observacional<br>prospectivo|Comparar o uso<br>de<br>ciclofosfamida<br>com<br>corticosteroides<br>versus<br>clorambucila<br>com<br>corticosteroides|Pacientes entre<br>14-65 anos com<br>nefropatia<br>membranosa<br>idiopática|CA 0.15 mg/kg por<br>dia; ciclo de 1 mês<br>durante 6 meses +<br>corticosteroides*<br>**(CA)**|CF oral 1,5-2 mg/kg<br>diário durante 1 ano<br>+ corticosteroides*<br>**(CF)**|Alto<br>Não possível garantir que os<br>grupos vieram da mesma<br>população localidade; Não houve<br>o controle de confundidores;<br>amostra pequena|  
CA: clorambucila; CF: ciclofosfamida; ECR: ensaio clínico randomizado; * 3 ciclos de 3 dias de 1 g metilprednisolona seguido de 0,5mg/kg de prednisona por 27 dias; ** 3 ciclos de 3 dias de 1g metilprednisolona seguido de 0,4 mg/kg de metilprednisolona por 27 dias; ** 3 ciclos de 3 dias de 1 g metilprednisolona a cada dois meses.  
**Tabela 28 –** Características dos pacientes incluídos nos estudos que compararam clorambucila e ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade**<br>**Intervenção**<br>**Média**|**Idade Controle**<br>**Média**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de estudo**|
|---|---|---|---|---|---|---|---|
|**Ponticelli et al.**<br>**1998 (49)**|CA (50)|CF (45)|Mediana (min-<br>máx.):<br>50 (18-65)|Mediana (min-<br>máx.):<br>48 (17-55)|37 (74)|29 (64)|Mediana (mín, máx): Todos<br>por pelo menos 1 ano (12-78)<br>CA: 36 meses (12-78); CF: 42<br>meses(12-72)|
|**Reichert et al.**<br>**1994 (132)**|CA (9)|CF (9)|45 (min-máx.:<br>31-65)|49 (min-máx.:<br>24-65)|9 (100)|8 (88)|6-12 meses|
|**Branten et al.**<br>**1998 (56)**|CA (15)|CF (17)|51 (DP: 12)|53 (DP: 14)|15 (100)|15 (88)|CA: 26 meses (5-16); CF: 38<br>meses(8–71)|  
CA: clorambucila; CF: ciclofosfamida; DP: desvio padrão; min-max: mínimo e máximo.  
**Tabela 29 –** Desfechos de eficácia reportados nos estudos que compararam clorambucila e ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Creatinina Sérica**|**Valor p**|**Albumina Sérica (g/l)**|**Valor p**|**Proteinúria (g/10 mmol**<br>**creatinina)**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**∆ basal e 6, 12 meses: NR**<br>**Média mg/dl (DP):**|<0.0055|||**Remissão completa ou**<br>**parcial**<br>CA: 36 (82%; IC 95%:<br>67.3, 91.8%)<br>CF:40 (93%; IC 95%:<br>80.9, 98.5%)0<br>**Remissão Completa (n)**<br>CA: 12<br>CF: 16<br>**Remissão Parcial (n)**<br>CA: 12<br>CF: 24|CA vs. CF: 0.116|
|**Ponticelli**<br>**et al.**<br>||**A) basal**<br>CA: 1.06 (0.27), n:50<br>CF: 1.04 (0.27), n:45||NR|NR|**Relapso:**<br>CA: 11||
|**1998(49)**||<br>**B) na última visita**<br>CA:1.25 (1.37), n:44<br>CF:1.32 (1.72), n: 43||||CF: 10<br>**∆ basal e 12, 24 e 36**<br>**meses: NR**|0.0001|
|||||||**Média g/d (DP):**<br>**A) basal**<br>CA: 7.96 (5.19), n:50<br>CF: 6.85 (3.51), n:45<br>**B) última visita**<br>CA:2.11 (2.89), n:44<br>CF:1.69 (2.36),n: 43||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Creatinina Sérica**|**Valor p**|**Albumina Sérica (g/l)**|**Valor p**|**Proteinúria (g/10 mmol**<br>**creatinina)**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**∆ basal e 6 meses (μmol/l),**<br>**média (IC 95%):**<br>CA: -74 (-19, -175), n:9<br>CF:+79 (-67, 204), n:7|0.003|**∆ basal e 6 meses,**<br>**média (IC 95%):**<br>CA: 9.4 (4.1, 14.8)||**∆ basal e 6 meses, média**<br>**(IC 95%):**<br>CA: -2.6 (-5.7, 0.6)<br>CF:-3.1 (-6.3, 0.0)|0.05|
|**Reichert**<br>**et al.**<br>**1994**<br>**(132)**||**∆ basal e 12 meses (μmol/l),**<br>**média (IC 95%):**<br>CA: -38 (-19, -175), n:9<br>CF:**+**322 (44, 600)|0.02<br>CA vs. CF:<br><0.001<br>0.05|<br>CF:6.3 (-1.1, 13.7)<br>**∆ basal e 12 meses.**<br>**média (IC 95%):**<br>CA: 10.8 (5.1,16.5)<br>CF:9.0 (-6.3, 24.3)|_<_0.005<br>_<_0.005|**∆ basal e 12 meses, média**<br>**(IC 95%):**<br>CA: -2.8 (-6.8, 1.2)<br>CF:-2.9 (-9.9, 4.1)<br>**Remissão Completa (n)**<br>CA: 1<br>CF: 2||
|||**ERSD:**<br>CA:1; CF:4||||**Remissão Parcial (n)**<br>CA: 3; CF:1||
|||**Média (μmol/l) (DP), aos a)**<br>**0 meses, b) 3 meses, c) 6**<br>**meses e d) 12 meses:**||**Média (DP), aos a) 0**<br>**meses, b) 3 meses, c) 6**<br>**meses e d) 12 meses:**|_*_0.01 vs. 0<br>meses|**Média (DP), aos a) 0**<br>**meses, b) 3 meses, c) 6**<br>**meses e d) 12 meses:**|_*_0.01 vs. 0 meses|
|||**CA:**||**CA:**||**CA:**||
|||a)219 (73);|_*_0.01 vs. 0|a)22 (5.6);|_**_0.001 vs. 0|a)9.1 (2.6);|_**_0.001 vs. 0|
|||b) 165 (56) *;|meses|b) 26 (6.0) *;|meses|b) 8.3 (5.9);|meses|
|**Branten**||c) 166 (54) *;||c) 31 (6.2) **;||c) 6.5 (3.9) ***;||
|**et al.**|CA vs. CF|d) 216 (99) *|_**_0.001 vs. 0|d) 32 (6.8) **||d) 6.8 (4.4)|*** 0.05 vs. 0|
|**1998 (56)**||**CF:**<br>a)274 (126);|meses|**CF:**<br>a)22 (6.0);||**CF:**<br>a)11.2 (5.3);|meses|
|||<br>b) 171 (82) **;||<br>b) 29 (5.1) **;||<br>b) 4.9 (2.3) **;||
|||<br>c) 165 (80) **;||<br>c) 34 (5.2) **;||<br>c) 3.0 (2.3) **;||
|||<br>d) 174 (78) **|∆0 e 12 meses|<br>d) 40 (4.7) **||<br>d) 2.0 (3.0) *||
|||**∆0 e 12 meses:**<br>**CA:**–6.3(IC95%: –65,52)|CA vs. CF:<br><0.01|||||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Creatinina Sérica**|**Valor p**|**Albumina Sérica (g/l)**|**Valor p**|**Proteinúria (g/10 mmol**<br>**creatinina)**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**CF:**–121 (IC 95%: –166, -<br>76)<br>**Creatinina Sérica/1000:**<br>**1. CA**||||**Remissão de proteinúria,**<br>**n (%)**<br>**A) Parcial**<br>CA: 5 (33%)<br>CF: 15 (91%)|<0.01<br><0.01|
|||**6 meses antes do**<br>**tratamento:**||||**B) Total**<br>CA: 0 (0%)||
|||-0,38 (IC 95%: –0.48, –0.29)<br>**6 meses após o tratamento:**||||CF: 6 (35%)||
|||0.29 (IC 95%: 0.13, 0.44)<br>**∆ 6 e 12 meses:**–0.16(IC<br>95%: –0.24, 0.08)<br>**2. CF**<br>**6 meses antes do**<br>**tratamento:**<br>-0,53 (IC 95%: –0.75,–0.30)<br>**6 meses após o tratamento:**<br>0.40 (IC 95%: 0.21, 0.58)<br>**∆ 6 e 12**<br>**meses:**0.00(IC 95%:<br>–0.11, 0.11)|∆ 6 e 12<br>meses CA vs.<br>CF: <0.05|||**Intervalo de tempo entre**<br>**o início do tratamento e o**<br>**desenvolvimento de**<br>**remissão parcial**<br>CA: 6 meses (1-24)<br>CF: 12 meses (1-24)||
|||**ERSD (n)**<br>CA:4; CF:1||||||  
CA: clorambucila; CF: ciclofosfamida; ERSD: doença renal em estágio final; IC 95%: intervalo de confiança de 95%; DP: desvio padrão; min-max: mínimo e máximo; ∆: diferença; NR: não reportado.  
**Tabela 30 –** Desfechos de segurança reportados nos estudos que compararam clorambucila e ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Evento adversos**|**Ponticelli et**|**al. 1998(49)**|**Reichert et a**|**l. 1994 (132)**|**Branten et**|**al. 1998 (56)**|
|---|---|---|---|---|---|---|
|**Grupo**|CA (n)|CF (n)|CA (n)|CF (n)|CA (n)|CF (n)|
|Leucopenia|2|0|3|NR|9|3|
|Infecção do trato respiratório|2|0|4|NR|4|5|
|Trombocitopenia|1|0|NR|NR|3|0|
|Náusea|1|1|3|7|1|2|
|Herpes zoster|4|0|NR|NR|1|0|
|Nenhum EA|NA|NA|NR|NR|1|9*|
|Tratamento reduzido,|||||||
|temporariamente interrompido ou<br>paradoprematuramente|6|2|NR|NR|11|6**|  
*p <0.01; ** p <0.05; CA: Clorambucila; CF: Ciclofosfamida; EA: eventos adversos; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 9 -** Qual a eficácia e a segurança do uso de ciclofosfamida ev e oral (ambos associados à prednisona ou metilprednisolona) para Glomerulonefrite Membranosa?  
**Tabela 31 –** Descrição dos estudos que analisaram ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hofstra et al.**<br>**2010 (55)**|ECR, aberto|Analisar se o<br>início precoce da<br>terapia é mais<br>eficaz e/ou|Adultos (>18-75<br>anos) com<br>nefropatia<br>membranosa|CF1.5 mg/kg por dia<br>oral / durante 12<br>meses +<br>corticosteroides*|CF1.5 mg/kg por<br>diaoral / durante 12<br>meses +<br>corticosteroides*|Alto<br>Estudo aberto, métodos de<br>randomização e sigilo de|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||menos tóxico do<br>que o início<br>tardio|idiopática, com<br>função renal<br>normal e com<br>risco de ERSD (|início imediato após<br>a randomização Ϯ:<br>**(CF início)**|iniciada após<br>detecção de função<br>renal deteriorada Ϯ:<br>**(CF tardio)**|alocação não reportados, análise<br>não foi por intenção de tratar|
|**Jha et al.**<br>**2007;Wetzels et**<br>**al.2007(92, 133)**|ECR, aberto|Comparar o<br>efeito de uso de<br>CF alternados<br>com<br>prednisolona em<br>6 meses de<br>tratamento com<br>tratamento de<br>suporte|Adultos (≥16<br>anos) com<br>nefropatia<br>membranosa<br>idiopática de<br>pelo menos 6<br>meses de duração|CF2 mg/kg via<br>oralno segundo,<br>quarto e sexto mês +<br>corticosteroides**<br>**(CF)**|Terapia de suporte<br>(restrição dietética de<br>sódio, diuréticos e<br>agentes anti-<br>hipertensivos)<br>**(TS)**|Alto<br>Estudo aberto, análise não foi por<br>intenção de tratar, sem cálculo<br>amostral e não foi descrito<br>método de sigilo de alocação.|
|**Eriguchiet al.**<br>**2009(134)**|Série de casos|Analisar os<br>resultados a<br>longo prazo de<br>baixa dose de CF<br>e prednisolona<br>em pacientes<br>japoneses|Japoneses com<br>nefropatia<br>membranosa<br>idiopática|CF50 mg/dia via oral<br>por 3 meses e 25 ou<br>50 mg/dia de dois em<br>dois dias por 3 meses<br>+ corticoides***<br>**(CF)**|NA|Alto<br>Série de casos para avaliar<br>eficácia|
|**West et al.**<br>**1987(135)**|Estudo de coorte<br>retrospectiva|Determinar<br>potenciais<br>benefícios da<br>terapia com CF|Pacientes com<br>nefropatia<br>membranosa|Pacientes com<br>nefropatia<br>membranosa,<br>proteinúria nefrótica<br>e terapia CF 2<br>mg/kg/dia<br>**(CF)**|Pacientes com<br>nefropatia<br>membranosa sem uso<br>de CF<br>**(Controle)**|Alto<br>(Sem determinação amostral,<br>sem ajuste de variáveis<br>relevantes)|  
CF: ciclofosfamida; TS: terapia de suporte; ECR: ensaio clínico randomizado; * 1 g metilprednisolona nos dias 1, 2, 3, 60, 61, 62, 120, 121 e 122 seguido de 0,5mg/kg de prednisona por 6 mesese subsequentemente diminuindo a dose em 5 mg/ semana.; Ϯ foi utilizado famotidina 1 dd 20 mg para prevenir sintomas gástricos e  
trimetoprim- sulfametoxazol 480 mg/dia nos primeiros 4–6 meses para prevenir pneumonia;** 3 ciclos de 3 dias de 1 g metilprednisolona seguido de 0,5mg/kg de prednisona por 27 diasno primeiro, terceiro e quinto mês; ***prednisolona oral 30mg/dia na primeira semana e foi reduzido para 20 mg/dianas próximas 2 semanas, 15 mg/diapor 1 mês, 10 mg/dia por 6 meses, 5 mg/diapor 6–12 meses e 2.5 mg/dia for 6–12 meses; NA: não se aplica.  
**Tabela 32 –** Características dos pacientes incluídos nos estudos que analisaram ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade**<br>**Intervenção**<br>**Média**|**Idade Controle**<br>**Média**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Período de estudo**|
|---|---|---|---|---|---|---|---|
|**Hofstra et al.**<br>**2010 (55)**|CF início<br>Randomizados:<br>15<br>Analisado: 14|CF tardio<br>Randomizados:<br>14<br>Analisado: 12;<br>desses 8<br>receberam o<br>tratamento<br>(FRD)|48 (DP: 13)|49 (DP: 10)|13 (88)|11 (88)|CF início: 73 meses (DP: 20)<br>CF tardio: 71 meses (DP: 26)|
|**Jha et al.**<br>**2007;Wetzels et**<br>**al.2007(92, 133)**|CF (46)|TS (47)|37.2 (DP: 12.4)|38.0 (DP: 13.6)|27 (59)|30 (64)|11 anos (min-máx.:10.5-12)|
|**Eriguchiet al.**<br>**2009(134)**|CF (103)|NA|59.0 (DP: 13.6)|NA|53 (51)|NA|8.5 anos (min-máx.: 0.2–<br>20.3)|
|**West et al. 1987**<br>**(135)**|CF (9)|Controle (17)|48 (DP: 5)|52 (DP: 3)|7 (78)|15 (87)|Observação pós-biopsia:<br>CF: 49 meses (DP: 10)<br>Controle: 50 meses (DP: 6)<br>Observação pós-início da<br>terapia<br>CF: 33 meses (DP: 5)<br>Controle: 36 meses(DP: 4)|  
CF: ciclofosfamida; TS: terapia de suporte; DP: desvio padrão; min-max: mínimo e máximo;NA: não se aplica.  
**Tabela 33 –** Desfechos de eficácia reportados nos estudos que analisaram ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão da SN**<br>|**Valor**<br>**p**|**Creatinina Sérica**|**Valor p**|**Outros parâmetros relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Hofstra**<br>**et al.**<br>**2010 (55)**|CF início<br>vs. CF<br>tardio|**Índice de proteína-creatinina**<br>**(gramas por 10 mmol de**<br>**creatinina)**<br>**Remissão no primeiro ano**<br>CF início: 71%<br>CF tardio: 8%<br>**Remissão parcial ou completa**<br>CF início:12 (86%); incidência<br>cumulada: 93%<br>CF tardio: 8 (67%); incidência<br>cumulada: 92%<br>**Remissão parcial**<br>CF início: 4 (29%)<br>CF tardio: dos 8 que tiveram FRD e<br>foram tratados tardiamente, 3<br>(37.5%) tiveram remissão parcial<br>**Remissão completa**<br>CF início: 6 (43%)<br>CF tardio: 7 (58); 4 (33%) sofreram<br>remissão espontânea; dos 8 que<br>tiveram FRD e foram tratados<br>tardiamente, 4 (50%) tiveram<br>remissão total|< 0.001<br>0.003|**Aumento**<br>**(temporário) de**<br>**25% durante o**<br>**seguimento:**<br>CF início: 21%<br>CF tardio: 75%<br>**Mediana (min-**<br>**máx.):**<br>**Basal vs. no**<br>**último**<br>**seguimento:**<br>CF início:<br>94 (68–122) vs. 93<br>(64–487);<br>CF tardio: 101<br>(75–126) vs. 105<br>(79–264)|0.005|**Albumina Sérica (g/l)**<br>**Média (DP):**<br>**Basal vs. último seguimento**<br>CF início: 22.6 (4.8) vs. 37.9 (5.4)<br>CF tardio:22.3 (3.8) vs.40.5 (6.9)<br>**Proteinúria (g/10 mmol**<br>**Creatinina)**<br>**Mediana (min-máx.):**<br>**Basal vs. último seguimento**<br>CF início:9.6 (5.9–14.4) vs. 0.77<br>(0.08–5.41)<br>CF tardio:12.0 (5.6–17.2) vs.0.18<br>(0–7.12)<br>**Taxa de filtração glomerular**<br>**estimada**<br>**Média (DP):**<br>**Basal vs. último seguimento**<br>CF início: 81 (17) vs. 76 (25)<br>CF tardio:76 (13) vs.68 (18)|NR<br>NS<br>NS|
|||**Relapso para SN**<br>CF início:3 (23%); 36 meses após<br>tratamento(25–106)||||||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão da SN**|**Valor**<br>**p**|**Creatinina Sérica**|**Valor p**|**Outros parâmetros relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||CF tardio: 3 (27%); 38 meses após<br>tratamento (13–76)<br>**ESRD**<br>CF início: 1 (7%)<br>CF tardio: 0<br>**Duração da SN no período de**<br>**tempo entre o início do estudo e a**<br>**ocorrência da remissão primária**<br>CF início: 6 meses(1–25)<br>CF tardio:15meses(2–46)|0.009|||||
|||**Remissão Completa (proteinúria**<br>||||**Sobrevivência livre de diálise em**<br>||
|||**<200 mg)**<br>TS: 5<br>CF: 15||||**10 anos**<br>CF: 89%<br>TS: 65%|0.016|
|**Jha et al.**||**Remissão Parcial (proteinúria**<br>**>200 mg/d, mas <2 g/d ou <50%**|CF vs.<br>TF:|||**Probabilidade de sobrevivência**<br>**sem atingir desfechos principais**|0.0006|
|**2007;**||**da linha de base)**|<0.000|||CF: 79%||
|**Wetzels**<br>**et**|CF vs. TS|TS: 11<br>CF: 19|1|NR|NR|TS: 44%||
|**al.2007(9**||||||**Hipertensão**||
|**2, 133)**||**Remissão dentro de 1 ano:**<br>TS: 5<br>CF: 15||||**Basal; 1, 2, 5 e 10 anos:**<br>TS: 7; 13, 19, 26, 35<br>CF: 5; 6, 8*, 11*, 16**|* CF vs. TF:<br><0.05<br>** CF vs. TF:|
|||**Relapsos depois de 5.4 meses:**||||**Edema**|<0.01|
|||TS: 4<br>CF: 8||||**Basal; 1, 2, 5 e 10 anos:**<br>TS: 44;30,28,24,22||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão da SN**|**Valor**<br>**p**|**Creatinina Sérica**|**Valor p**|**Outros parâmetros relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||||CF: 43;19 **,10**,7**, 8**<br>**Hipoalbuminemia**<br>**Basal; 1, 2, 5 e 10 anos:**<br>TS: 46; 33,26,24,180<br>CF: 46;20 **,10**,8**, 7**||
|||||||**Hipercolesterolemia**<br>**e / ou Terapia de estatinas**<br>**Basal; 1, 2, 5 e 10 anos:**<br>TS: 44; 36,31,34,33<br>CF: 42;24*,18**,17**, 20**||
|||||||**Uso de IECA ouBRA**<br>**Basal; 1, 2, 5 e 10 anos:**<br>TS: 0; 0,17,28,32<br>CF: 0;0,6**,9**, 13**||
|||||||**Qualidade de vida- escala visual**<br>**analógica, média (DP)**<br>**Basal; 1, 2, 5 e 10 anos:**<br>TS: 4.41 (1.19); 5.69 (1.32),6.18<br>(1.04),6.43 (1.12),6.61 (1.08)<br>SF: 4.76 (1.07);6.95 (1.4) **,7.12<br>(1.09) **,7.26 (0.82) **, 7.31 (0.76)<br>**||
|**Eriguchie**<br>**t al.**<br>**2009(134)**|<br>**CF**|**_1. Durante o período de_**<br>**_observação_**<br>**Remissão completa ou incompleta**<br>**(proteinúria <1g/g): **90(87.4%)||NR|NR|<br>**Função renal**<br>Normal: 91 (88.3%)<br>Insuficiência: 8 (7.8%)<br>Falência: 2(1.9%)||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão da SN**|**Valor**<br>**p**|**Creatinina Sérica**|**Valor p**|**Outros parâmetros relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Remissão completa(proteinúria**<br>**<0.2 g/g):**78 (75.7%)<br>**Incidência acumulada de**<br>**remissão completa em 2, 5 e 8**<br>**anos:**60.8, 76.1 e 82.5%||||Morte: 2 (1.9%)<br>**Fatores de risco para prognóstico**<br>**renal**<br>Taxa de não remissão>80%<br>RR:12.3 (IC 95%:2.35–63.9)|0.003|
|||**Incidência acumulada de**<br>**remissão completa ou**<br>**incompleta em 2, 5 e 8**<br>**anos:**80.5, 89.5 e 93.5%||||**Fatores relacionados a não**<br>**remissão**<br>Proteinúria: β:0.210<br>Lesão segmentar: β:0.390|0.03<br><0.001|
|||**% de pacientes com**<br>**remissãocompleta ou**<br>**incompleta (proteinúria <1g/g)**<br>**em 1 e 2 anos**: 67% e 78%<br>(desses||||**Fatores relacionados à taxa de**<br>**progressão da disfunção renal**<br>Taxa de filtração glomerular<br>estimada basal: β: 0.2589|0.02<br>0.03|
|||74–88% permaneceu em<br>remissão)||||Fibrose intersticial: β:−0.256<br>Taxa de não remissãoβ:−0.296|0.008|
|||**_2. Na última observação_**<br>**Remissão completa ou incompleta**<br>**(proteinúria <1g/g):**88 (83.5%);<br>remissão completa: 64 e remissão<br>incompleta: 22||||||
|||**Relapsos:**40em30 pacientes||||||  
|**Autor**<br>**West et**<br>**al.**<br>**1987(135)**|**Grupos de**<br>**comparaç**<br>**ão**<br> <br>**CF vs.**<br>**Controle**|**Remissão da SN**<br>**Escala Nefrótica**<br>CF: 0<br>Controle: 11 (65%)<br>**Remissão Parcial**<br>CF: 5 (56%)<br>Controle: 6 (35%)<br>**Remissão Total**<br>CF: 4 (45%)<br>Controle: 0|**Valor**<br>**p**<br><0.001<br><0.001<br><0.001|**Creatinina Sérica**<br>**Média, DP**<br>Início do<br>tratamento vs.<br>Observação final:<br>CF: 222(31) vs.<br>173 (24)<br>Controle: 216 (19)<br>vs. 433 (72)|**Valor p**<br>CF vs.<br>controle:<br>0.02|**Outros parâmetros relevantes**<br>**Excreção de proteína de urina 24**<br>**horas g / dia**<br>Início do tratamento vs. Observação<br>final:<br>CF: 11.0 (2.6) vs. 0.9 (0.3)<br>Controle: 10.9 (2.6) vs. 6.9 (1.2)<br>**Albumina sérica**<br>Início do tratamento vs. Observação<br>final:<br>CF: 28(3) vs. 40 (2)<br>Controle: 28(2)vs. 33(2)|**Valor p**<br>CF início vs.<br>final: <0.01<br>CF vs. controle:<br><0.01<br>CF início vs.<br>final: <0.02<br>CF vs. controle:<br><0.05|
|---|---|---|---|---|---|---|---|  
CF: ciclofosfamida; TS: terapia de suporte; SN: síndrome nefrótica; IECA: inibidor da enzima conversora da angiotensina; BRA: bloqueador dos receptores da angiotensina II; ERSD: doença renal em estágio final; IC 95%: intervalo de confiança de 95%; RR: risco relativo; DP: desvio padrão; min-max: mínimo e máximo; NR: não reportado; NA: não se aplica.  
**Tabela 34 –** Desfechos de segurança reportados nos estudos que analisaram ciclofosfamida para o tratamento de Glomerulonefrite Membranosa  
|**Evento adversos**|**Hofstra e**|**t al. 2010 (55)**|**Jha et al. 20**<br>**et al.2007**|**07; Wetzels**<br>**(92, 133)**|**West et**|**al. 1987 (135)**|**Eriguchi et al**|**. 2009(134)**|
|---|---|---|---|---|---|---|---|---|
|**Grupo**|CF início, n<br>(%)|CF tardio, n (%)|CF oral|TS|CF|Controle|CF oral|NA|
|**Relacionados ao tratamento**|||||||||
|Leucocitopenia|2(14)|1(8)|3|NR|0|NR|1|NA|
|Anemia|3(21)|0(0)|NR|NR|3|NR|NR|NA|  
|**Evento adversos**|**Hofstra et**|**al. 2010 (55)**|**Jha et al. 20**<br>**et al.2007**|**07; Wetzels**<br>**(92, 133)**|**West et a**|**l. 1987 (135)**|**Eriguchi et al**|**. 2009(134)**|
|---|---|---|---|---|---|---|---|---|
||CF início n||||||||
|**Grupo**|,<br>(%)|CF tardio, n (%)|CF oral|TS|CF|Controle|CF oral|NA|
|Infecções Respiratória|1(7)|1(8)|3|5|1|NR|5|NA|
|Outras infecções|4(29)|5(42)|7|9|2|NR|11|NA|
|Mal-estar / artralgia|3(21)|0(0)|NR|NR|NR|NR|NR|NA|
|Anormalidades do teste do<br>fígado/hepatite|0 (0)|2 (17)|NR|NR|NR|NR|NR|NA|
|Diabetes induzida por<br>esteroides|1 (7)|0 (0)|NR|NR|NR|NR|NR|NA|
|Outras|1(7)|0(0)|NR|NR|NR|NR|3|NA|
|**Relacionados à SN**|||||||||
|Trombose da veia renal|1(7)|1(8)|NR|NR|NR|NR|NR|NA|
|Outro tromboembolismo<br>venoso|1 (7)|0 (0)|3|4|NR|NR|2|NA|
|Infarto do miocardio|0(0)|1(8)|NR|NR|1|NR|4|NA|
|**Total**|||||||||
|Com um ou mais EA|9(64)|6(50)|NR|NR|NR|NR|NR|NA|
|Necessitaram de diminuição<br>da dose|4 (29)|6 (50)|NR|NR|NR|NR|NR|NA|
|Hospitalizações|2(14)|6(50)|2|NR|NR|NR|NR|NA|
|Morte|0|0|1|3|1|2|2|NA|
|Interrupção/suspensão do<br>tratamento|NR|NR|5|0|7|NR|3|NA|  
CF: ciclofosfamida; TS: terapia de suporte; SN: síndrome nefrótica; EA: eventos adversos; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 10 -** Qual a eficácia e a segurança do Rituximabe para o tratamento de Glomerulonefrite Membranosa com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 35 –** Descrição dos estudos que analisaram o rituximabe para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Cravedi et al.**<br>**2011 (136)**|Coorte<br>prospectiva|Avaliar se o RTX é<br>igualmente eficaz<br>em pacientes que<br>não responderam<br>ao tratamento<br>imunossupressor<br>prévio|Pacientes com nefropatia<br>membranosa<br>idiopáticacom uma<br>proteinúria de 24<br>hpersistente>3,5 g apesar<br>de ter utilizado pelo<br>menos 6 meses de tto com<br>inibidores IECA ou BRA<br>e depuração de creatinina<br>>20 ml/min/1,73 m<sup>2</sup>.|RTX(375 mg/m<sup>2</sup>) de<br>resgate para SN<br>persistente ou<br>redicivante após<br>tratamento prévio com<br>CT administrados<br>isoladamente ou em<br>combinação com<br>agentes alquilantes,<br>ciclosporina ou<br>imunoglobulina G|RTX (375 mg/m<sup>2</sup>)<br>como primeira<br>linha<br>**(RTX 1° linha)**|Baixo<br>(Amostra pequena)|
|||||**(RTXtto prévio)**|||
|**van den**<br>**Brand et al.**<br>**2017(137)**|Coorte<br>retrospectiva<br>(análise<br>conjunta de 2<br>coortes)|Comparar terapia<br>de CF +<br>corticosteroides<br>versus RTX.|Pacientes com nefropatia<br>membranosa idiopática e<br>SN persistente|**RTX**|**CF + CT**|Moderado<br>(Dados retrospectivos,<br>coortes independentes)|
|**Roccatello et**<br>**al. 2016 (138)**|Série de casos<br>prospectiva|Avaliar se, em<br>pacientes com<br>nefropatia<br>membranosa<br>idiopática e<br>alterações iniciais<br>noperfil de|Pacientes com nefropatia<br>membranosa idiopática;<br>depuração da creatinina ≥<br>30 mL / min /<br>1,73 m2; proteinúria<br>persistente >3,5 g/24 h<br>apesar do uso máximo|RTX, 375 mg/<br>m<sup>2</sup>(intravenoso) no dia<br>1, 8, 15 e 22.<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||linfócitos e nível de<br>IL-35, poderia<br>prever a resposta do<br>RTX|tolerado deIECA por pelo<br>menos 4 meses||||
|**Busch et al.**<br>**2013(139)**|Série de casos<br>prospectiva|Analisar se o RTX<br>é uma potencial<br>opção como<br>segunda ou terceira<br>linha de tto para<br>nefropatia<br>membranosa<br>idiopática|Pacientes com nefropatia<br>membranosa idiopática<br>com SN recorrente ou<br>terapia refratária e<br>tratados com RXT|RTX, 375 mg/m a cada<br>4 semanas no dia 1, 30,<br>60e 90.<br>**(RTX)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**El-Reshaid et**<br>**al. 2012 (121)**|Série de casos<br>prospectiva|Avaliar o papel do<br>RTX no tratamento<br>de pacientes<br>resistentesàCT e<br>inibidores de<br>calcineurina ou±<br>cellcept<br>SN idiopática|Pacientes adultos e<br>pediátricos com SN<br>idiopática resistente com<br>lesões histopatológicas do<br>tipo DLM, GESF e GM;<br>SN resistente a pelo<br>menos 4 meses de tto com<br>CT (1 mg/kg/dia) e<br>refratária (relapso ou<br>dependente) ou resistente<br>aos inibidores de<br>calcineurina monoterapia<br>ou combinado<br>comcellcept; todos os<br>pacientes receberam três<br>doses mensais de citoxano|RTX (1mg/ml) infusões<br>semanais por 4 semanas<br>**(RTX)**<br>**Subgrupos: RTX**<br>**DLM,**<br>**RTX GESF e RTX**<br>**GM;**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>IV (0,75 g / m2) sem<br>benefício.|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ruggenenti et**<br>**al. 2012 (141)**<br>**Ruggenenti et**<br>**al. 2003 (140)**|Série de casos<br>prospectiva<br>Série de casos<br>prospectiva|Descrever os<br>desfechos de 100<br>pacientes<br>monitorados<br>prospectivamente<br>por mais de 10 anos<br>depois do uso do<br>RTX<br>Analisar o efeito do<br>RTX em um ano de<br>seguimento|Pacientes com nefropatia<br>membranosa idiopática;<br>utilizaram RTX como<br>primeira ou segunda linha<br>de tto<br>Pacientes com nefropatia<br>membranosa<br>idiopática,depuração de<br>creatinina>20 ml/min por<br>1,73 m<sup>2</sup>e taxa de<br>excreção de proteína<br>urinária persistente >3,5<br>g/24 h durante pelo menos<br>6 meses, uso deIECA de<br>dose completa (Ramipril,<br>5 a 10 mg/ d),equem|**(RTX)**<br>RTX, 375 mg/ m<sup>2</sup><br>infusões semanais por 4<br>semanas + terapia<br>conservadora<br>**(RTX)**|NA<br>NA|Alto<br>(Série de casos para<br>avaliar eficácia)<br>Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||não teve remissão da<br>doença||||  
RXT: rituximabe; CF: ciclofosfamida; CT: corticosteroides; SN: síndrome nefrótica; tto: tratamento;IECA: inibidor da enzima conversora da angiotensina; BRA: bloqueador dos receptores da angiotensina II; DLM: doença de lesão mínima; GESF: glomeruloesclerose segmentar e focal; GM: glomerulopatia membranosa.  
**Tabela 36 –** Características dos pacientes incluídos nos estudos que analisaram o rituximabe para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade**<br>**Intervenção**<br>**Média (DP)**|**Idade Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo masculino**<br>**Controle**|**Período de estudo**|
|---|---|---|---|---|---|---|---|
|**Cravedi et al.**<br>**2011 (136)**|RTX tto prévio<br>(11)|RTX 1° linha<br>(11)|48.68 (13.9)|50.18 (12.3)|10 (88)|10 (88)|2 anos|
|**van den Brand**<br>**et al. 2017(137)**|RTX (100)|CF+CT (103)|51.5 (15.9)|55.3 (12.7)|72%|76%|Mediana: 40 meses<br>(18–60)|
|**Roccatello et al.**<br>**2016 (138)**|RTX (17)|NA|67 (min-máx.:<br>29–86)|NA|11 (64)|NA|24 meses|
|**Busch et al.**<br>**2013(139)**|RTX (14)|NA|47 (14)|NA|10 (71%)|NA|Mediana: 3 anos (1<br>– 6)|
|**El-Reshaid et al.**<br>**2012 (121)**|RTX DLM (23<br>adultos + 9<br>pediátricos)|NA|Adultos: 22 (4)<br>Pediátricos: 7 (4)|NA|Adultos: 14 (57)<br>Pediátricos: 6 (67)|NA|12|
||RTX GESF (16<br>adultos + 2<br>pediátricos)||Adultos: 29 (10)<br>Pediátricos: 4 (1)||Adultos: 11 (69)<br>Pediátricos: 1 (50)||meses|  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade**<br>**Intervenção**<br>**Média (DP)**|**Idade Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo masculino**<br>**Controle**|**Período de estudo**|
|---|---|---|---|---|---|---|---|
||RTX GM (28)<br>adultos||Adultos: 36 (9)||Adultos: 16 (61)|||
|**Ruggenenti et al.**<br>**2012 (141)**|RTX (100)|NA|51.5 (5.9)|NA|72 (72)|NA|Mediana: 29 meses<br>(6-121)|
|**Ruggenenti et al.**<br>**2003 (140)**|RTX (8)|NA|52.8 (19.6)|NA|3 (37.5)|NA|12 meses|  
RXT: rituximabe; CF: ciclofosfamida;CT: corticosteroides; tto: tratamento; DLM: doença de lesão mínima; GESF: glomeruloesclerose segmentar e focal; GM: glomerulopatia membranosa; DP: desvio padrão; min-max: mínimo e máximo; NA: não se aplica.  
**Tabela 37 –** Desfechos de eficácia reportados nos estudos que analisaram o rituximabe para o tratamento de Glomerulonefrite Membranosa  
|**Autor**<br>**Cravedi et**<br>**al. 2011**<br>**(136)**|**Grupos de**<br>**comparaç**<br>**ão**<br>RTX tto<br>prévio vs.<br>RTX 1°<br>linha|**Remissão**<br>**Remissão Parcial (n) em**<br>**a)0; b) 3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX tto prévio:<br>a)0; b) 0; c) 0; d)5; e)5<br>RTX 1° linha:<br>a)0; b) 0; c) 0; d)5; e)5<br>**Remissão completa (n)  em**<br>**a)0; b) 3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX ttoprévio:|**Valor p**<br>NS|**Desfechos relevantes**<br>**Creatinina sérica**<br>**(mg/dl), média (DP) em**<br>**a)0; b) 3; c) 6; d)12 e e)**<br>**24 meses**<br>RTX tto prévio:<br>a)1.38 (0.5); b) 1.28<br>(0.6);<br>c) 1.18 (0.7); d)1.48<br>(0.7);<br>e)1.58 (0.7)<br>RTX 1° linha:|**Valor p**<br>* p < 0.05 vs.<br>mês 0;<br>** p < 0.01 vs.<br>mês 0;<br>*** p < 0.05 vs.<br>RTX 1° linha,no<br>mesmo tempo|**Outros desfechos**<br>**Colesterol sérico**<br>**(mg/dl), média (DP) em**<br>**a)0; b) 3; c) 6; d)12 e e)**<br>**24 meses**<br>RTX tto prévio:<br>a)289.78 (65.9); b)<br>283.28 (73.0);<br>c) 246.28 (39.9);<br>d)216.08 (33.7) **;<br>e)217.58 (31.0) **, ***<br>RTX 1° linha:|**Valor p**<br>* p < 0.05 vs.<br>mês 0;<br>** p < 0.01 vs.<br>mês 0;<br>*** p < 0.05<br>vs. RTX 1°<br>linha,no<br>mesmo tempo|
|---|---|---|---|---|---|---|---|  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||a)0; b) 0; c) 0; d)2; e)2<br>RTX 1° linha:<br>a)0; b) 0; c) 0; d)2; e)3||a)1.18 (0.4); b) 1.18<br>(0.3);<br>c) 1.18 (0.2); d)1.28<br>(0.4);<br>e)1.28 (0.4)||a)269.78 (62.0); b)<br>240.98 (48.0) *;<br>c) 211.78 (41.9) **;<br>d)190.88 (39.7) **;<br>e)182.78 (30.9) **||
|||||**Proteinúria 24h (g/24h),**<br>**média (IQR) em a)0; b)**<br>**3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX tto prévio:<br>a)10.9 (6.6–18.6); b) 10.4<br>(3.3–18.1) **;<br>c) 4.9 (2.7–9.4) **; d)4.9<br>(3.8–7.7) **;<br>e)3.5 (2.1–4.0) **<br>RTX 1° linha:<br>a)10.3 (5.8–13.8); b) 7.5<br>(3.1–11.4) **;<br>c) 5.6 (2.7–10.2) **;<br>d)5.1 (1.7–8.8) **;<br>e)3.5 (2.0–6.6) **<br>**Albumina sérica (g/dl),**<br>**média (DP) em a)0; b)**<br>**3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX tto prévio:<br>a)2.28 (0.8); b) 2.78 (0.7)<br>**;||**Pressão Arterial**<br>**Sistólica (mmHg),**<br>**média (DP) em a)0; b)**<br>**3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX tto prévio:<br>a)129.88 (11.4); b)<br>123.38 (10.7) *;<br>c) 123.18 (13.9);<br>d128.78 (10.2);<br>e)125.78 (10.4)<br>RTX 1° linha:<br>a)131.7 (87.0); b) 123.58<br>(14.5);<br>c) 121.78 (12.7) *;<br>d)125.08 (11.6);<br>e)124.08 (10.1) *<br>**Pressão Arterial**<br>**Diastólica (mmHg),**<br>**média (DP) em a)0; b)**<br>**3; c) 6; d)12 e e) 24**<br>**meses**<br>RTX ttoprévio:||  
**<mark>Grupos de</mark> Remissão Autor comparaç Valor p Desfechos relevantes Valor p Outros desfechos Valor p** **<u>ão</u>** c) 2.88 (0.9) **; d)3.18 a)82.38 (8.7); b) 77.18 (0.6) **; (9.2); e)3.18 (0.6) ** c) 72.48 (8.8) **; RTX 1° linha: d)78.88 (8.7); a)2.18 (0.6); b) 2.48 (0.7) e)76.58 (6.9) **; RTX 1° linha: c) 2.88 (0.7) **; d) 3.28 a)81.78 (8.8); b) 73.78 (0.7) **; (9.1) *; e)3.18 (0.8) ** c) 73.98 (12.1); d)76.38 (8.4); e)76.38 (5.8) **Remissão Parcial** RTX: n: 64; 70.6% (IC 95%: 60.1, 80.4%) CF-CT: 89; 94.8% (IC 95%: 88.4, 98.3%) RTX vs. CFHR: 0.63 (IC 95%: 0.45CT: 0.01 0.89) **Taxas de incidência cumulada de desfechos van den finais Ϯ: Brand et** RTX vs. **Remissão Completa** NR NR RTX: 17.9%; (IC 95%: NR **al.** CF-CT RTX vs. CFRTX: n: 26; 40.3% (IC 10.0, 30.8%) **2017(137)** CT: 0.95 95%: 28.7, 54.5%) CF-CT:21.8%; (IC 95%: CF-CT: n: 34; 41.5% (IC 13.7, 33.4%) 95%: 31.4, 53.3%) HR: 0.88 (IC 95%: 0.501.54) **Falência renal** RTX: n: 11  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**<br>CF-CT: n: 17<br>HR: 0.94 (IC 95%: 0.42-<br>2.09)|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|**Roccatello**<br>**et al. 2016**<br>**(138)**|RTX|**Remissão completa (n)**<br>**a) aos 6 meses; b) 24**<br>**meses**<br>a) 7; b) 14<br>**Remissão parcial (n) a)**<br>**aos 6 meses; b) 24 meses**<br>a) 4; b) 1<br>**Sem resposta (n) a) aos 6**<br>**meses; b) 24 meses**||**Proteinúriag/24, média**<br>**(min-máx.)**<br>Basal:5.6 (3.5–8)<br>Aos 6 meses: 2.4 (0.06–<br>13)<br>Aos 12 meses: 1.3 (0.06–<br>8)<br>**Proteinúriamg/dl,**<br>**média (min-máx.)**<br>Basal:1 (0.5–2.4)<br>Aos 12 meses: 1 (0.7–<br>1.6)<br>Aos 24 meses: 1.1 (0.7–<br>1.7)|<0.05<br><0.01|**Necessidade de outras**<br>**doses de RTX**<br>n:4<br>**Aumento de Treg**<br>**(CD4+ CD25+ FOXP3**<br>**+), média (DP)**<br>Basal: 1,2 (0,6%)<br>Aos 12 meses: 5,8<br>(0,7%)<br>Respondentes (remissão<br>completa e parcial): 5.5<br>(0.6%)<br>Não respondentes: 1.1<br>(0.6%)|0,02 basal vs.<br>12 meses<br>Respondentes<br>vs. não<br>respondentes:<br>0.04<br>0.043<br>0.05, basal vs.<br>6e 12 meses|  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||||**Níveis de HLA-**<br>**DR+CD8+, média (DP)**<br>Basal: 6 (1.1%)<br>Aos 6 meses: 4.7 (1.7%)<br>Aos 12 meses: 1.5<br>(1.4%)|respectivament<br>e<br>0.04, 6 meses<br>vs. basal|
|||||||**Níveis de IL35,pg/ml**<br>Basal:162.37 (99.2–<br>247.1)<br>Aos 6 meses:74.63<br>(49.96–111.96)||
|**Busch et**<br>**al.**<br>**2013(139)**|RTX|**Remissão completa, n**<br>**(%) em a) basal (n:14);**<br>**b) 3 meses (n:14); c) 6**<br>**meses (n:14); d) 1 ano**<br>**(n:14); e) 2 anos (n:10);**<br>**f) 3 anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)0; b) 2 (14.3%);<br>c) 3 (21.4%); d) 3<br>(21.4%);<br>e) 3 (30.0%); f) 2<br>(25.0%);<br>g) 2 (50.0%); h) 1<br>(33.3%);<br>i) 1<br>**Remissão Parcial, n (%)**<br>**em a) basal (n:14); b) 3**||**Proteinúria (mg/24h),**<br>**média (DP), em a) basal**<br>**(n:14); b) 3 meses**<br>**(n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)6,025 (3,007); b)<br>2,939 (3,151) *;<br>c) 2,440 (2,526) *; d)<br>2,489 (3,033) *;<br>e) 2,200 (2,547) *; f)<br>2,059 (2,664) *;<br>g)1,105 (1,165); h)<br>1,933 (1,299);<br>i)290|*≤ 0.017 vs.<br>basal|**Dose acumulada de**<br>**RTX:**3 mg (2.640-<br>3.460)<br>**Leucócitos (Gpt/l),**<br>**média (DP), em a) basal**<br>**(n:14); b) 3 meses**<br>**(n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)7.6 (1.8); b) 6.5<br>(1.8);<br>c) 6.5 (2.0); d) 6.9<br>(2.0);||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**meses (n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)0; b) 7 (50.0%);<br>c) 6 (42.9%); d) 7<br>(50.0%);<br>e) 5 (50.0%); f) 5<br>(62.5%);<br>g)2 (50.0%); h) 2<br>(66.6%);<br>i) 0;<br>**Sem resposta, n (%) em**<br>**a) basal (n:14); b) 3**<br>**meses (n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)0; b) 5 (35.7%);<br>c) 5 (35.7%); d) 3<br>(21.4%);<br>e) 2 (20.0%); f) 1<br>(12.5%);<br>g)0 (0.0%); h) 0 (0.0%);<br>i)0(0.0%).||**Depuração de**<br>**creatinina (ml/min),**<br>**média (DP), em a) basal**<br>**(n:14); b) 3 meses**<br>**(n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)74 (46); b) 71 (42);<br>c) 84 (39); d) 73 (39);<br>e) 62 (32); f) 61 (33);<br>g)48 (13); h) 65 (12);<br>i) 65<br>**Albumina sérica (g/l),**<br>**média (DP), em a) basal**<br>**(n:14); b) 3 meses**<br>**(n:14); c) 6 meses**<br>**(n:14); d) 1 ano (n:14);**<br>**e) 2 anos (n:10); f) 3**<br>**anos (n:8); g) 4 anos**<br>**(n:4); h) 5 anos (n:3); i)**<br>**6 anos (n:1):**<br>a)28 (6); b) 36 (6) **;<br>c) 39 (5) **; d) 38 (7)<br>**;<br>e)37(6)**;f)34(8);|**≤ 0.012 vs.<br>basal|e) 7.3 (2.0); f) 7.5<br>(2.0);<br>g)7.7 (2.0); h) 9.3<br>(2.1);<br>i) 6.5||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Relapso**<br>No primeiro ano: 1<br>Entre 3-4 anos: 1||g)36 (7); h) 65 (12); i)<br>41||||
|**El-Reshaid**<br>**et al. 2012**<br>**(121)**|RTX|**Remissão completa (n)**<br>**em a) antes do tto com**<br>**RTX; b) 8 meses após**<br>**RTX;) 12 meses após**<br>**RTX**<br>RTX DLM: a)24; b) 32;<br>c) 29;<br>RTX GESF: a) 0; b) 0; c)<br>0;<br>RTX GM: a) 6; b) 24; c)<br>12<br>**Remissão Parcial (n) em**<br>**a) antes do tto com**<br>**RTX; b) 8 meses após**<br>**RTX;) 12 meses após**<br>**RTX**<br>RTX DLM: a)6; b) 0; c)<br>2;<br>RTX GESF: a)10; b) 17;<br>c) 17;<br>RTX GM: a)10; b) 2; c)<br>14;|NR|NR|NR|**Tempo de resposta ao**<br>**RTX**<br>RTX DLM: 1° mês<br>RTX GESF: 3° mês<br>(gradualmente)<br>RTX GM: 3° mês<br>(gradualmente)|NR|  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Sem resposta (n) em a)**<br>**antes do tto com RTX;**<br>**b) 8 meses após RTX;)**<br>**12 meses após RTX**<br>RTX DLM: a)2; b) 0; c)<br>1;<br>RTX GESF: a)8; b) 1; c)<br>1;<br>RTXGM:a)12;b)2;c)2;||||||
|||**Remissão completa ou**<br>**parcial (n) em29 meses (6–**||Em 20 de 35 pacientes<br>sem resposta, observou-<br>se uma redução de 50%||**Taxa de filtração**<br>**glomerularml/min por**<br>**1.73 m**<sup>**2**</sup>**:**<br>Média, DP: 6.46 (20.7)||
|||**121):**65<br>**Tempo para remissão:**7.1<br>meses (IQ: 3.2-12)<br>**Remissão completa ou**||da excreção de proteína<br>urinária em relação à<br>linha de base<br>**Diminuição da**||Remissão<br>completa:13.26 (19.6)<br>Remissão parcial: 3.86<br>(11.1)|0.021|
|**Ruggenent**||**parcial daqueles que**||**Proteinúria**||||
|**i et al. 2012**<br>**(141)**|RTX|**tomaram RTX como:**<br>1°linha:47 de 68<br>2° linha: 18 de 32<br>**Relapso:**18 pacientes.||NR (figuras)<br>**Aumento da albumina**<br>**sérica**<br>NR (figuras)|<0.0001<br><0.0001|**Variáveis preditoras**<br>**para remissão completa**<br>Gênero:HR: 1.591 (IC<br>95%: 0.913-2.772)<br>Creatinina sérica: HR:<br>0.42 (IC 95%: 0.196-|0.03<br>0.09<br>0.03|
|||Desses, 4 tiveram remissão<br>completa e 7 parcial.||**Aumento da creatinina**<br>**sérica**||0.897)<br>Proteinúria: HR:||
|||**Progressão para ESRD:**4||>50%: 13||0.365(IC 95%: 0.147-||
|||||>100%: 5||0.908)|0.101|  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**|**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||||**Variáveis preditoras**<br>**para remissão completa**<br>**ou parcial**<br>Gênero:HR: 2.496 (IC<br>95%: 1.095-5.690)<br>Creatinina sérica: HR:<br>0.275(IC 95%: 0.062-<br>1.221)<br>Proteinúria: HR0.19 (IC<br>95%: 0.107-0.338)|0.025<br><0.0001|
|**Ruggenent**<br>**i et al. 2003**<br>**(140)**||**Remissão completa:**2<br>**Remissão parcial:**4|NR|**Redução de proteinúria**<br>**aos 12 meses em relação**<br>**à linha de base:**66%<br>**Redução de depuração**<br>**de albumina fracionada**<br>**aos 12 meses em relação**<br>**à linha de base:**76%<br>**Aumento de albumina**<br>**sérica aos 12 meses em**<br>**relação à linha de base:**<br>41%<br>**Creatinina sérica,**<br>**média (DP) em a) basal;**<br>**b) 1 mes; c) 2 meses; d)**<br>**3 meses; e) 6 meses; f) 9**<br>**meses; g) 12 meses:**<br>a) 1.5(0.9);b)1.5(0.8);|<br> <br> <br> <br><0.05<br>* <0.01 vs. mês 0<br>** <0.05 vs. mês<br>0<br>c|**Função renal**<br>**estabilizou em todos os**<br>**pacientes, média (DP):**<br>▲1/creatinina: +0.002<br>(0.007)<br>**Células CD20(8 to**<br>**16%), média (DP) em a)**<br>**basal; b) 1 mês; c) 2**<br>**meses; d) 3 meses; e) 6**<br>**meses; f) 12 meses:**<br>a) 9.3 (2.8); b)0.0<br>(0.0) *;<br>) 0.4 (1.1) **; d) 1.5 (2.1)<br>**;<br>e)3.6 (2.8) **; f) 6.3<br>(3.8)||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor p**<br>**Desfechos relevantes**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||c) 1.4 (0.7); d)1.4<br>(0.8);<br>e) 1.4 (0.8); f)1.3<br>(0.7);<br>g)1.4 (0.7)||||
||||**Excreção de proteína**<br>**na urina, média (DP)**<br>**em a) basal; b) 1 mês;**<br>**c) 2 meses; d) 3 meses;**<br>**e) 6 meses; f) 9 meses;**<br>**g) 12 meses:**<br>a) 8.6 (4.2); b)3.7 (2.4) *;<br>) 4.1 (2.5) *; d) 4.3 (3.3) *;<br>e)4.1 (3.1) *; f) 3.6<br>(2.7) *;<br>g)3.0 (2.5) *||||
||||**Albumina sérica, média**<br>**(DP) em a) basal; b) 1**<br>**mês; c) 2 meses; d) 3**<br>**meses; e) 6 meses; f) 9**<br>**meses; g) 12 meses:**<br>b) 2.7 (0.5); b)3.0 (0.4) *;<br>c) 3.1 (0.3) **; d) 3.1 (0.3)<br>**;<br>e)3.3 (0.3) *; f) 3.4<br>(0.3) **;<br>g) 3.5(0.4)**||||  
RXT: rituximabe; CF: ciclofosfamida; CT: corticosteroides; ERSD: doença renal em estágio final; DLM: doença de lesão mínima; GESF: glomeruloesclerose segmentar e focal; GM: glomerulopatia membranosa.Ϯ:definido como duplicação da creatinina sérica; ESRD, a necessidade de terapia de substituição renal crônica ou morte por qualquer causa; IC 95%: intervalo de confiança de 95%; IQ: intervalo interquartil; DP: desvio padrão; min-max: mínimo e máximo; HR: hazard ratio; NR: não reportado; NS: não significativo.  
**Tabela 38 –** Desfechos de segurança reportados nos estudos que analisaram o rituximabe para o tratamento de Glomerulonefrite Membranosa  
|**Evento adversos**|**Crav**<br>**201**|**edi et al.**<br>**1 (136)**|**van den B**|**rand et al. 2017**<br>**(137)**|**Rocca**<br>**et al.**<br>**(13**|**tello**<br>**2016**<br>**8)**|**El-Res**<br>**al. 2012**|**haid et**<br>**(121)**|**Busch**<br>**2013**|**et al.**<br>**(139)**|**Ruggen**<br>**al. 2012**|**enti et**<br>**(141)**|**Ruggen**<br>**al. 2003**|**enti et**<br>**(140)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Grupo**|**RTX**<br>**tto**<br>**prévi**<br>**o**|**RTX 1°**<br>**linha**|**RTX**|**CF-CT**|**RT**<br>**X**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|
|Mielotoxicidade|<br>NR|NR|Sério: 0|Sério: 6**|NR|NA|NR|NA|NR|NA|0|NA|NR|NA|
|Leucocitopenia|NR|NR|Sérios: 0<br>Não sérios:<br>0|Sérios: 6 *<br>Não sérios: 35|NR|NA|NR|NA|NR|NA|0|NA|NR|NA|
|Anemia|NR|NR|Sérios: 0<br>Não sérios:<br>0|Sérios: 1<br>Não sérios: 11|NR|NA|NR|NA|NR|NA|NR|NA|NR|NA|
|Infecções<br>Respiratória|0|0|Sérios: 0<br>Não sérios:<br>4|Sérios: 3<br>Não sérios: 15|2|NA|NR|NA|1|NA|0|NA|NR|NA|
|Outras infecções|0|0|Sérios: 0<br>Não sérios:<br>3|Sérios: 5<br>Não sérios: 22|1|NA|NR|NA|2|NA|0|NA|NR|NA|
|Doenças malignas|NR|NR|Sérios:2|Sérios: 6|1|NA|NR|NA|NR|NA|3|NA|NR|NA|  
|**Evento adversos**|**Crav**<br>**201**|**edi et al.**<br>**1 (136)**|**van den**|**Brand et al. 2017**<br>**(137)**|**Rocc**<br>**et al.**<br>**(13**|**atello**<br>**2016**<br>**8)**|**El-Res**<br>**al. 2012**|**haid et**<br>**(121)**|**Busch**<br>**2013**|**et al.**<br>**(139)**|**Ruggene**<br>**al. 2012**|**nti et**<br>**(141)**|**Ruggene**<br>**al. 2003**|**nti et**<br>**(140)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**RTX**||||||||||||||
|**Grupo**|**tto**<br>**prévi**<br>**o**|**RTX 1°**<br>**linha**|**RTX**|**CF-CT**|**RT**<br>**X**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|
|Eventos<br>cardiovasculares<br>maiores|NR|NR|Sérios: 5|Sérios: 4|2|NA|NR|NA|NR|NA|8|NA|NR|NA|
|Eventos<br>tromboembólicos|NR|NR|Sérios: 0|Sérios: 7*|nr|NA|NR|NA|NR|NA|NR|NA|NR|NA|
|Outros eventos|NR|NR|Sérios: 0|Sérios: 6|27|NA|3|NA|NR|NA|Alergia:<br>8|NA|3|NA|
|**Total **|||||||||||||||
||||**Tempo pa**|**ra o primeiro EA**|||||||||0|NA|
||||35% (IC<br>95%: 24.3,<br>49.7%)|69.0% (IC 95%:<br>59.1, 78.3%)*|||||||||||
|EA sérios|NR|NR|HR: 0.27(I<br>**EA observ**<br>**o s**<br>n eventos<br>sérios:<br>11|C 95%: 0.16–0.44)<br>**ados durante todo**<br>**eguimento**<br>n eventos sérios:<br>46|NR|NA|NR|NA|0|NA|11|NA|||
|EA sérios fatal e não<br>fatal|NR|NR|**Tempo pa**<br>16.4% (IC<br>95%: 8.4,<br>30.4%)<br>HR: 0.32(I<br>**EA observ**<br>**o s**|**ra o primeiro EA**<br>30.2% (IC 95%:<br>21.1, 41.9%)**<br>C 95%: 0.15–0.68)<br>**ados durante todo**<br>**eguimento**|NR|NA|NR|NA|NR|NA|Fatal: 4<br>Não<br>fatal:  7|NA|Faltal:0<br>Não<br>fatal: 3|NA|  
|**Evento adversos**|**Crav**<br>**201**|**edi et al.**<br>**1 (136)**|**van den**|**Brand et al. 2017**<br>**(137)**|**Roccatello**<br>**et al. 2016**<br>**(138)**|**El-Resh**<br>**al. 2012**|**aid et**<br>**(121)**|**Busch**<br>**2013 (**|**et al.**<br>**139)**|**Ruggen**<br>**al. 2012**|**enti et**<br>**(141)**|**Ruggen**<br>**al. 2003**|**enti et**<br>**(140)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Grupo**|**RTX**<br>**tto**<br>**prévi**<br>**o**|**RTX 1°**<br>**linha**|**RTX**|**CF-CT**|**RT**<br>**X**<br>**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|**RTX**|**NA**|
||||n eventos:<br>Fatal: 4<br>Fatal<br>relacionad<br>o ao<br>tratamento<br>: 0<br>n eventos:<br>Não fatal:<br>7|n eventos:<br>Fatal: 9<br>Fatal relacionado<br>ao tratamento: 5<br>n eventos:<br>Não fatal: 37***||||||||||
|EA não sérios|NR|NR|**Tempo pa**<br>23.6% (IC<br>95%: 14.9,<br>36.1%)<br>HR: 0.23(I<br>**EA observ**<br>**o s**<br>n eventos:<br>52|**ra o primeiro EA**<br>60.8% (IC 95%:<br>50.8, 70.9%)**<br>C95%: 0.13 – 0.41)<br>**ados durante todo**<br>**eguimento**<br>n eventos:<br>127|NR<br>NA|3|NA|NR|NA|27|NA|3|NA|
|Interrupção/suspens<br>ão do tratamento|NR|NR|NR|NR|NR<br>NA|5|NA|NR|NA|NR|NA|NR|NA|  
*p<0.001; **p <0.01; ***p<0.05; RXT: rituximabe; CF:ciclofosfamida; CT: corticosteroides; EA: eventos adversos; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 11 -** Qual a eficácia e a segurança do tacrolimo em relação à ciclosporina para o tratamento de Glomerulonefrite Membranosa com recidivas frequentes, resistência aos tratamentos anteriores ou imunossupressão dependente?  
**Tabela 39 –** Descrição dos estudos que analisaram o tacrolimo _versus_ ciclosporina para o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Li et al. 2017 (63)**|ECR|Analisar se o<br>TAC + TC é<br>mais efetivo e<br>seguro que o<br>CsA combinado<br>com CT|Adultos (>18-60<br>anos) com<br>nefropatia<br>membranosa<br>idiopática<br>(estágio I-IV), Pt<br>persistente<br>>8g/d; Cr <133<br>umol/L.|TAC (0.05-0.1<br>mg/kg/d) dividido<br>em duas doses de<br>12/12h + CT*<br>**(TAC)**|CsA (3-5 mg/kg/d)<br>dividido em duas<br>doses de 12/12h +<br>CT*<br>**(CsA)**|Alto<br>Amostra pequena, método de<br>sigilo de alocação não<br>reportados, não está claro se<br>houve mascaramento dos<br>participantes e avaliadores dos<br>desfechos|
|**Omrani et al.**<br>**2017 (64)**|ECR, aberto|Comparar a<br>eficácia do TAC<br>e CsA|Pacientes(15-70<br>anos) com<br>nefropatia<br>membranosa<br>idiopática|TAC (0.05 mg/kg/d)<br>+ CT**<br>**(TAC)**|CsA (3-6 mg/kg/d) +<br>CT**<br>**(CsA)**|Alto<br>Amostra pequena, método de<br>randomização e sigilo de<br>alocação não reportados, viés de<br>relato seletivo|  
TAC: tacrolimo; CsA: ciclosporina; CT: corticosteroides; Cr: creatinina sérica; Pt: proteína; * prednisolona dose de 0.5 mg/kg/dia; ** baixa dose de prednisolona.  
**Tabela 40 –** Características dos pacientes incluídos nos estudos queanalisaramo tacrolimo versus ciclosporinapara o tratamento de Glomerulonefrite Membranosa  
|**Autor, ano**|**Intervenção**<br>**(n)**|**Controle (n)**|**Idade**<br>**Intervenção**<br>**Média (DP)**|**Idade Controle**<br>**Média (DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**<br>**n (%) sexo masculino**<br>**Controle**|**Período de estudo**|
|---|---|---|---|---|---|---|  
|**Li et al. 2017**<br>**(63)**|TAC (16)|CsA (15)|39.4 (8.8)|42.8 (8.1)|12 (75)|13 (87)|6 meses|
|---|---|---|---|---|---|---|---|
|**Omrani et al.**<br>**2017(64)**|TAC (34)|CsA (34)|39.4 (13.5)|36.2 (14.3)|13 (38.2)|16 (47)|6 meses|  
TAC: tacrolimo; CsA: ciclosporina; DP: desvio padrão; min-max: mínimo e máximo; NA: não se aplica.  
**Tabela 41 –** Desfechos de eficácia reportados nos estudos que analisaram o tacrolimo versus ciclosporina para o tratamento de Glomerulonefrite Membranosa  
|**Autor**|<br>**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor**<br>**p**|**Desfechos urinários**|**Valor p**|**Desfechos laboratoriais relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**(TAC vs. CsA)**||||||
|||**% Remissão completa ou**<br>**parcial:**<br>1° mês: 31.3% vs. 6.7%<br>2° mês:50.0% vs. 20.0%<br>3° mês:75.0% vs. 33.4%<br>4° mês:81.3% vs. 53.3%<br>5° mês:87.5% vs. 66.7%|0.083<br>0.081<br>0.020<br>0.097<br>0.166<br>0.318|||||
|**Li et**||6° mês:87.5% vs. 73.3%|0.116|||||
|**al.**<br>**2017(**<br>**63)**|**TAC vs.**<br>**CsA**|**Probabilidade de remissão**<br>**completa ou parcial**<br>**% Remissão Completa:**<br>1° mês: 6.3% vs. 0.0%,|0.325<br>0.583|NR|NR|NR||
|||2° mês:12.5% vs. 6.7%<br>3° mês:25.0% vs. 6.7%<br>4° mês:37.5% vs. 13.3%|0.165<br>0.124<br>0.474|||||
|||5° mês:31.3% vs. 20.0%<br>6° mês:43.8% vs. 33.3%<br>**Probabilidade de remissão**<br>**completa**|0.552<br>0.438|||||  
|**Autor**|**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor**<br>**p**|**Desfechos urinários**|**Valor p**|**Desfechos laboratoriais relevantes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Sem resposta**<br>2 vs.4<br>**Tempo para remissão**<br>**parcial:**<br>2.4 meses (1.3) vs. 3.5 meses<br>(1.6)|0.045|||||
|**Omra**<br>**ni et**<br>**al.**<br>**2017(**<br>**64)**|**TAC vs.**<br>**CsA**|NR|NR|**Proteína na urina 24h**<br>Basal TAC: 3899.3<br>(1102.0); Basal CsA:<br>3917.8 (1499.2)<br>Aos 3 meses TAC: 1968.0;<br>aos 3 meses CsA:2406.3|<0.001 vs.<br>basal; <0.001<br>vs. basal|**Colesterol**<br>Basal TAC: 251.1 (42.0); Basal<br>CsA: 282.5 (123.2)<br>Aos 3 meses TAC: 225.3; aos 3 meses<br>CsA:227.6<br>Aos 6 meses TAC:208.4; aos 6<br>meses CsA:196.5|0.002 vs.<br>basal; 0.001<br>vs. basal|  
|**Autor**<br>**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor**<br>**p**|**Desfechos urinários**|**Valor p**|**Desfechos laboratoriais relevantes**|**Valor p**|
|---|---|---|---|---|---|---|
||||Aos 6 meses TAC:1433.4;<br>aos 6 meses CsA:1783.3|<0.001 vs.<br>basal; <0.001<br>vs. basal<br>3 vs. 6° mês<br>TAC:0.210;|**Triglicerídeos**<br>Basal TAC: 240.9 (88.9); Basal|0.001 vs.<br>basal; 0.001<br>vs. basal<br>3 vs. 6° mês<br>TAC:0.001;<br>3 vs. 6° mês|
||||**Depuração de creatinina**<br>Basal TAC: 77.2 (21.8);<br>Basal CsA: 73.2 (33.3)|3 vs. 6° mês<br>CsA: 0.110|CsA: 251.0 (114.9)<br>Aos 3 meses TAC: 210.2; aos 3<br>meses CsA:245.3|CsA:<0.001|
||||Aos 3 meses TAC: 79.2;||Aos 6 meses TAC:211.6; aos 6 meses|0.028 vs.|
||||aos 3 meses CsA:80.2<br>Aos 6 meses TAC:93.6; aos<br>6 meses CsA:93<br>|0.420 vs.<br>basal; 0.670<br>vs. basal<br>0.002vs.<br>basal;<br>0.080vs. basal|CsA:208.0<br>**Glicose de jejum**<br>Basal TAC: 94.9 (14.5); Basal CsA:|basal; 0.210<br>vs. basal<br>0.035 vs.<br>basal; 0.004<br>vs. basal<br>3 vs. 6° mês|
||||**Ácido úrico**|3 vs. 6° mês|91.9 (13.6)|TAC:0.530|
||||Basal TAC: 77.2 (21.8);|TAC:0.006; 3||3 vs. 6° mês|
||||Basal CsA: 73.2 (33.3)<br>Aos 3 meses TAC: 6.6; aos<br>3 meses CsA:6.7|vs. 6° mês<br>CsA:0.080|Aos 3 meses TAC: 104.4; aos 3<br>meses CsA:100.5<br>Aos 6 meses TAC:111.3; aos 6 meses<br>CsA:100.6|CsA:0.010<br>0.001 vs.|
||||Aos 6 meses TAC:6.9; aos|0.009 vs.||basal; 0.002|
||||6 meses CsA:6.4|basal; 0.310<br>vs. basal||vs. basal|  
|**Autor**|<br>**Grupos de**<br>**comparaç**<br>**ão**|**Remissão**|**Valor**<br>**p**|**Desfechos urinários**<br>**Valor p**|**Desfechos laboratoriais relevantes**|**Valor p**|
|---|---|---|---|---|---|---|
|||||0.005vs.||<0.001 vs.|
|||||basal;||basal; 0.001|
|||||0.900vs. basal||vs. basal|
|||||3 vs. 6° mês||3 vs. 6° mês|
|||||TAC:0.040; 3||TAC:0.020|
|||||vs. 6° mês||3 vs. 6° mês|
|||||CsA:0.250||CsA:0.930|  
TAC: tacrolimo; CsA: ciclosporina; IC 95%: intervalo de confiança de 95%; DP: desvio padrão; NR: não reportado; NA: não se aplica.  
**Tabela 42 –** Desfechos de segurança reportados nos estudos que analisaram o tacrolimo _versus_ ciclosporina para o tratamento de Glomerulonefrite Membranosa  
|**Evento adversos**|**Li et**|**al. 2017 (63)**||**Omra**|**ni et al. 2017(64)**||
|---|---|---|---|---|---|---|
|**Grupo**|**TAC, n (%)**|**CsA, n**<br>**(%)**|**Valor**<br>**p**|**TAC, n (%)**|**CsA, n (%)**|**Valor**<br>**p**|
|Pneumonia|1(6.3%)|1(6.7%)|0.962|NR|NR|NR|
|Hepatotoxicidade|3(18.8%)|3(20.0%)|0.930|NR|NR|NR|
|Diarreia|2(12.5%)|1(6.7%)|0.583|NR|NR|NR|
|Hiperglicemia|3(18.8%)|2(13.3%)|0.682|NR|NR|NR|
|Piora da hipertensão|1(6.3%)|2(13.3%)|0.505|NR|NR|NR|
|Tremor nas mãos|4(25.0%)|1(6.7%)|0.165|NR|NR|NR|
|Hipertricosis|0(0.0%)|12(80.0%)|<0.001|NR|NR|NR|
|Hiperplasiagengival|1(6.3%)|8(53.3%)|0.004|NR|NR|NR|
|Nefrotoxicidade<br>reversível|1 (6.3%)|1 (6.7%)|0.962|NR|NR|NR|
|Hiperuricemia|8(50.0%)|5(33.3%)|0.347|NR|NR|NR|
|EA totais|NR|NR|NR|Aos 3 meses: 9<br>(26.5)<br>Aos 6 meses: 21<br>(61.7)|Aos 3 meses: 11<br>(32.3)<br>Aos 6 meses: 16<br>(47.3)|0.590<br>0.220|  
TAC: tacrolimo; CsA: ciclosporina; EA: eventos adversos; NA: não se aplica; NR: não reportado.  
**Questão de Pesquisa 12 -** Qual a eficácia e a segurança das terapias imunossupressoras (tacrolimo,rituximabe, ácido micofenólico e prednisona) para o tratamento de glomerulonefrite membranoproliferativa ou mesangiocapilar (primárias ou idiopáticas) tipo I em adultos?

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
((((("Mycophenolic Acid"[Mesh] OR Mycophenolate Sodium OR Mycophenolate Mofetil)) OR (("Prednisone"[Mesh]) OR prednisone OR methylprednisolone OR "methylprednisolone acetate" [Supplementary Concept] OR corticosteroid)) OR ("Tacrolimus"[Mesh] OR tacrolimus))) AND ("Glomerulonephritis, Membranoproliferative"[Mesh] OR Membranoproliferative Glomerulonephritis OR MPGN OR Mesangiocapillary Glomerulonephritis)  
Data de acesso: 25/10/2017  
Total: 489 referências

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **EMBASE:** -->
(('mesangiocapillary glomerulonephritis'/exp OR 'mesangiocapillary glomerulonephritis' OR 'membranoproliferative glomerulonephritis'/exp OR 'membranoproliferative glomerulonephritis' OR 'mpgn') AND [embase]/lim) AND (('tacrolimus'/exp OR 'tacrolimus' OR 'prednisone'/exp OR  
'prednisone' OR 'methylprednisolone acetate'/exp OR 'methylprednisolone acetate' OR 'methylprednisolone'/exp OR 'methylprednisolone' OR 'mycophenolic acid'/exp OR 'mycophenolic acid' OR 'mycophenolate mofetil'/exp OR 'mycophenolate mofetil' OR 'mycophenolate sodium'/exp OR 'mycophenolate sodium') AND [embase]/lim)  
Data de acesso: 25/10/2017  
Total: 939 referências

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
Apenas foram selecionados estudos que apresentassem resultados para a população adulta e com GNMP. Estudos que analisaram várias glomerulonefrites de forma conjunta só foram incluídos caso apresentassem resultados estratificados para GNMP.  
Foram recuperadas 1.428 referências pelas estratégias de busca (489 MEDLINE e 939 EMBASE). Foram retiradas 179 duplicatas, restando 1.249 referências a serem analisadas por título e resumo. Após essa etapa, 15 referências tiveram os textos completos lidos e dessas, seis foram excluídas, sendo uma por se tratar de população pediátrica e 5 por não descrever resultados clínicos apenas para GNMP.  
Foram recuperadas 1.428 referências pelas estratégias de busca (489 MEDLINE e 939 EMBASE). Foram retiradas 179 duplicatas, restando 1.249 referências a serem analisadas por título e resumo. Após essa etapa, 15 referências tiveram os textos completos lidos e dessas, nove foram excluídas, sendo uma por se tratar de população pediátrica e 8 por não descrever resultados clínicos apenas para GNMP. Dessa forma, 6 referências foram selecionadas<sup>89, 90, 126, 131, 142, 143</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela 43** . A **Tabela 44** apresenta as características dos participantes. A **Tabela 45** apresenta os desfechos de eficácia reportados nos estudos e a **Tabela 46** apresenta os desfechos de segurança.  
**Tabela 43 – Descrição dos estudos que analisaram terapias imunossupressoras para o tratamento de glomerulonefrite membranoproliferativa ou mesangiocapilar (primárias ou idiopáticas) tipo I.**  
|**Autor,**<br>**ano**|**Desenho do estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Micofenolato de m**|**ofetila**|||
|**Dimkovic**<br>**et al.**<br>**2009(126)**|Série de casos<br>prospectivas|Determinar a eficácia<br>e segurança do MMF<br>como terapia de<br>resgate|GESF, GM, GNMP,<br>GNMSP e DLM; pacientes<br>que não atingiram<br>remissão com<br>imunossupressores, ET-<br>dependentes ou ET-<br>resistentes; todos pacientes<br>haviam recebido ET e CF<br>nopassado|500 mg de MMF 2 vezes por dia<br>nas primeiras 2 semanas, no total<br>1500 mg MMF nas próximas<br>duas semanas e então 1000 mg<br>2x ao dia; pacientes com falência<br>renal crônica dose máxima de<br>1500 mg + ET de baixa dose<br>**(MMF)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Yuan et**<br>**al. 2010**<br>**(142)**|Série de casos<br>prospectivas|Avaliar a eficácia do<br>MMF em pacientes<br>com GNMP ET-<br>resistentes|GNMP ET<sup>1</sup>- resistentes 1.0<br>mg/kg/d por pelo menos 8<br>semanas)|1) Monoterapia de ET<sup>1</sup>1.0<br>mg/kg/d por 8 semanas ou<br>mais, depois gradualmente<br>diminuindo para 30 mg/d<br>**(Monoterapia de ET**<sup>**1**</sup>**)**<br>2) Resistência à ET1, então<br>MMF (1.5 g/d) foi<br>iniciadoea dose de ET<sup>1</sup>foi<br>gradualmente reduzida até<br>chegar nos níveis 5 – 10<br>mg/d<br>**(MMF)**|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|
|**Sahin et**<br>**al.**<br>**2007(143)**|Série de casos<br>retrospectiva|Reportar o uso de<br>MMF em pacientes<br>com glomerulopatias<br>resistentes a terapias<br>convencionais|Glomerupatias primárias<br>refratárias; GM, GNMP,<br>NIgA, GESF, NLES,<br>GNPI; pacientes (>16<br>anos)ET-resistentes ounão|O MMF foi iniciado em 0,5-0,75<br>g BID e avançado como tolerado<br>para<br>0,5 g TID ou 1 g BID + ET<sup>2</sup>4-12<br>mg|NA|Alto<br>(Série de casos<br>retrospectiva para<br>avaliar eficácia)|  
|**Autor,**<br>**ano**|**Desenho do estudo**|**Objetivo**|**População**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||responderam a um agente<br>citotóxico e / ou um<br>tratamento com inibidor de<br>calcineurina.|**(MMF)**|||
|**Jones et**<br>**al.2004**<br>**(90)**|Estudo de coorte<br>retrospectiva|Investigar se o MMF<br>em combinação com<br>ET<sup>3</sup>poderia melhorar<br>os desfechos renais<br>.|GNMP idiopática;<br>pacientes (>17 anos)|60 mg de ET<sup>3</sup>oral, diminuindo<br>para 20 mg dentro de 2 meses e<br>retirado em 1 ano. O MMF foi<br>iniciado a 500 mg/dia e<br>aumentou gradualmente<br>dependendo da resposta ou no<br>máximo 2g/dia<br>**(MMF + ET**<sup>**3**</sup>**)**|Não<br>receberam<br>MMF + ET<sup>3</sup><br>**(Controle)**|Alto<br>(Não houve<br>validação<br>independente dos<br>casos ou pareamento,<br>não foi relatado se a<br>amostra é<br>representativa;<br>amostra pequena;<br>não houve ajuste<br>para confundidores)|
||||**Tacrolimo**||||
|**Li et al.**<br>**2009**<br>**(131)**|Série de caso<br>prospectiva|Reportar o uso de<br>TAC em pacientes<br>que não responderam<br>à CF|GESF; DLM; GNMSP;<br>pacientes (>16 anos) ET-<br>resistentes (não atingiu<br>remissão após tto de pelo<br>menos 3 meses de 1,0<br>mg/kg /dia de ET<sup>1</sup>) que não<br>responderam à CF com<br>uma dose total de pelo<br>menos 6g|TAC (0.05-0.1 mg/kg/d)<br>dividido em duas doses de<br>12/12h; dose foi ajustada até<br>atingir concentrações sanguíneas<br>de 5-10 ng / ml + ET<sup>1</sup>inicial a<br>0,5 mg/kg/d e mantida durante 8<br>a 12 semanas de acordo com a<br>resposta. Após, a dose de ET<sup>1</sup>foi<br>reduzida em 5 mg a cada 2<br>semanas a 20 mg em dias<br>alternados e mantidos por 8<br>semanas,seguido de redução de|NA|Alto<br>(Série de casos para<br>avaliar eficácia)|  
|**Autor,**<br>**ano**|**Desenho do estudo**|<br>**Objetivo**<br>**População**|**Intervenção**|**Compara**|**dor**<br>**Risco de viés**|
|---|---|---|---|---|---|
||||8 a 16 semanas até a retirada<br>completa.<br>**(TAC)**|||
|||**Rituximabe**||||
|**Dillon et**<br>**al. 2012**<br>**(89)**|Série de casos<br>prospectiva (Fase<br>II)|Testar a hipótese de<br>que a doença<br>responderia à<br>depleção de células<br>B com RTX<br>GNMP tipo 1; pacientes<br>(≥18 anos)|Intravenoso RTX 1,000 mg no<br>dia 1 e no dia 15; pacientes<br>foram pré-medicados com ET<sup>2</sup><br>100mg, difenidramina 50 mg<br>e acetaminofeno 1000 mg<br>**(RTX)**|NA|Alto (Série de casos<br>para avaliar eficácia)|
|MMF: mico<br>glomeruloes<br>mesangiopro|fenolato de mofetil<br>clerose segmentar<br>liferativa;NIgA:nefro|a; TAC: tacrolimo; RTX: rituximabe; ET: esteroides;<br>focal; GM: glomerulopatia membranosa; GNMP:<br>patia por IgA; DLM: doença de lesão mínima; NLES: ne|ET<sup>1</sup>: prednisona; ET<sup>2</sup>: metilpre<br>glomerulonefrite membranopro<br>frite lúpus eritematoso sistêmica;|dnisolona;<br>liferativa;<br>GNPI: glom|ET<sup>3</sup>: prednisolona; GESF;<br>GNMSP: glomerulonefrite<br>erulonefritepauci-imune;|  
**Tabela 44 – Caraterísticas dos pacientes incluídos nos estudos que analisaram terapias imunossupressoras para o tratamento de glomerulonefrite membranoproliferativa ou mesangiocapilar (primárias ou idiopáticas) tipo I.**  
|**Autor,**<br>**ano**|**Intervenção**<br>**(n)**|**Controle**<br>**(n)**|**Causas da SN**<br>**(n)**|**Idade**<br>**Intervenção**<br>**(anos),**<br>**média (DP)**|**Idade**<br>**Controle**<br>**(anos),**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)sexo**<br>**masculino**<br>**Controle**|**Imunossupressores**<br>**utilizados**<br>**anteriormente à**<br>**intervenção (n**<br>**pacientes)**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|||||**Mi**|**cofenolato de**|**mofetila**||||
|**Dimkovic**<br>**et al.**<br>**2009(126)**|<br>MMF (51)|NA|GM (n = 12),<br>GNMP<br>(n = 15),<br>GNMSP (n =<br>10),GESF(n =|41.2(13.6)|NA|30 (59)|NA|ET:51 *; CF: 17*<br>AZA: 5*; CPA: 6*|12 meses|  
|**Autor,**<br>**ano**|**Intervenção**<br>**(n)**|**Controle**<br>**(n)**|**Causas da SN**<br>**(n)**|**Idade**<br>**Intervenção**<br>**(anos),**<br>**média (DP)**|**Idade**<br>**Controle**<br>**(anos),**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)sexo**<br>**masculino**<br>**Controle**|**Imunossupressores**<br>**utilizados**<br>**anteriormente à**<br>**intervenção (n**<br>**pacientes)**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||||13) e DLM (n<br>=1);|||||||
|**Yuan et**<br>**al. 2010**<br>**(142)**|ET1 e<br>depois<br>MMF (13)|NA|GNMP (13)|39.5 (9.5)|NA|8 (61)|NA|ET<sup>1</sup>:13|Média de tto com<br>de ET<sup>1</sup>: 4 meses;<br>Tto com MMF:12<br>meses|
|**Sahin et**<br>**al.**<br>**2007(143)**|<br>MMF (43)|NA|GM (n = 8),<br>GNMP<br>(n = 10), GESF<br>(n = 4), NIgA (n<br>= 6),NLES (n =<br>11),GNPI(n = 4)|30.2 (11)|NA|23 (53)|NA|ET:43; CF: 16<br>CPA: 5|28.9 meses (12)|
||||GNMP (11);|||||Grupo MMF + ET<sup>3</sup>:<br>||
|**Jones et**<br>**al.2004**<br>**(90)**|MMF + ET<sup>3</sup><br>(n:5)|Controle<br>(n:6)|GNMP tipo 1 no<br>grupo MMF +<br>ET<sup>3</sup>: 4<br>GNMP tipo 1 no<br>grupo controle: 5|32.1 (11.6)|25.2 (10.9)|1 (17)|2 (40)|monoterapia de ET<sup>3</sup>:<br>2<br>AZA + ET<sup>3</sup>: 1<br>Grupo Controle:<br>AZA + ET<sup>3</sup>: 1|18 meses|
||||||**Tacrolim**|**o**||||
||||||||||Tto: pelo mesmo|
|**Li et al.**|||GESF: 8||||||24 semanas;|
|**2009**<br>**(131)**|TAC (19)|NA|DLM: 6<br>GNMSP: 5|27.1 (9.4)|NA<br>**Rituximab**|13 (68)<br>**e**|NA|NR|Total, média<br>(DP): 37.6 meses<br>(13.4)|  
|**Autor,**<br>**ano**|**Intervenção**<br>**(n)**|**Controle**<br>**(n)**|**Causas da SN**<br>**(n)**|**Idade**<br>**Intervenção**<br>**(anos),**<br>**média (DP)**|**Idade**<br>**Controle**<br>**(anos),**<br>**média**<br>**(DP)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)sexo**<br>**masculino**<br>**Controle**|**Imunossupressores**<br>**utilizados**<br>**anteriormente à**<br>**intervenção (n**<br>**pacientes)**|**Período de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||||GNMSP: 6;<br>GNMSP|||||||
|**Dillon et**|||idiopática: 4|||||Não foram utilizados||
|**al. 2012**<br>**(89)**|RTX (6)|NA|GNMSP com<br>crioglobulinemia:<br>2|57 (19)|NA|3 (50)|NA|imunossupressores<br>antes da terapia|12 meses|  
MMF: micofenolato de mofetila; TAC: tacrolimo; RTX: rituximabe;ET: esteroides;ET<sup>1</sup> : prednisona; ET<sup>2</sup> : metilprednisolona; ET<sup>3</sup> : prednisolona; AZA: azatioprina; CPA: ciclosporina; CF: ciclofosfamida; GM: glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomerulonefrite mesangioproliferativa GESF; glomeruloesclerose segmentar focal; NIgA: nefropatia por IgA; DLM: doença de lesão mínima;NLES: nefrite lúpus eritematoso sistêmica; GNPI: glomerulonefritepauci-imune; tto; tratamento; DP: desvio padrão; NA: não se aplica; NR: não reportado.  
**Tabela 45 – Desfechos de eficácia reportados nos estudos que analisaram terapias imunossupressoras para o tratamento de glomerulonefrite membranoproliferativa ou mesangiocapilar (primárias ou idiopáticas) tipo I.**  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**<br>**Micofenolato de mofetila**|<br>**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**33 (47%) daqueles que**<br>**completaram o estudo**<br>**responderam a terapia:**||**UPCRbasal vs. 12 meses nos**<br>**subgrupos, mediana (IQ):**||||
||RC: 14||Geral: 3.72 (2.13–6.48) vs. 0.84||||
||RP: 20||(0.42–2.01) **||**Dose de ET (mg/d), mediana (IQ):**||
||||GM: 3.52 (2.61–5.08) vs. 1.52||Antes de MMF vs. depois de MMF||
||**RC nos subgrupos:**||(0.06–1.78)||20 mg (I20–25) vs. 15 mg (10–20)|< 0.001|
||GESF: 3 de 13||GNMP: 4.31 (1.59–6.53) vs. 1.03||||
||GM: 4 de 11||(0.45–3.54)||**Dose de MMF durante o estudo,**||
||GNMP: 3 de 13||GNMSP: 4.97 (1.14–10.28) vs. 0.51||**mediana (IQ):**|< 0.001|
||GNMSP: 3 de 9||(0.34–0.94)||Baseline: 1,000 mg (1,000–1,500)||
||||GESF: 3.26 (1.52–7.92) vs. 0.86||Aos 12 meses**:**2,000 mg (1,500–2,000)||
||**RP nos subgrupos:**||(0.45–2.07)|*<0.00|||
||GESF: 5 de 13|||1 basal|**Taxa de sedimentação de eritrócitos,**||
|**Dimkovic**|GM: 5 de 11||**Proteinúria (g/24h), mediana (IQ):**|vs. 12|**mediana (IQ):**||
|**et al. 2009**|GNMP: 5 de 13||Baseline:4.9 (2.9–8.4)|meses|Baseline:39 (16.0–58.3)|0.000|
|**(126)**|GNMSP: 4 de 9||Aos 3 meses:3.0 (1.69–4.8)||Aos 3 meses:32 (10.0–53.5)|basal vs.|
||DML:1||Aos 6 meses:1.8 (0.49–3.62)||Aos 6 meses: 27 (15.7–51.2)|12 meses|
||||Aos 9 meses:1.07 (0.4–3.22)||Aos 9 meses:20 (10.0–37.3)||
||**Não atingiu remissão nos**||Aos 12 meses:1.28 (0.5–2.9) **|**|Aos 12 meses:17 (8.0–40.5)||
||**subgrupos:**||**Proteinúria nos subgrupos basal**|<0.001|||
||GESF: 2 de 13||**vs. 12 meses¥, mediana (IQ):**||**Pressão Arterial Sistólica, media (DP):**||
||GM: 2 de 11||GESF: 5.1 (2.7–8.9) vs. 1.9 (0.56–|¥ NS|Baseline:135.3 (17.8)|0.018|
||GNMP: 1 de 13||3.05)|entre|Aos 3 meses:130.5 (14.4)|basal vs.|
||GNMSP: 1 de 9||GM: 4.7 (3.12–6.57) vs. 1.4 (0.11–|grupos|Aos 6 meses: 132.1 (15.5)|12 meses|
||||2.7)||Aos 9 meses:131.2 (14.5)||
||||<br>GNMP: 5.3 (3.19–8.6) vs. 1.92 (0.5–||<br>Aos 12 meses:129.5 (14.4)||
||**Preditores de RC:**|0.036|4.2)||||
||Idade RR: 0.94 (IC 95%: 0.88–||GNMSP: 7.03 (1.6–12.23) vs. 0.76||||
||0.99)<br>**Preditores de RP:**|0.047|(0.45–1.34)||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||Idade RR: 0.95 (IC 95%: 0.91–<br>0.99)||**ProteinúriaAUC, entre basal e 3**<br>**meses vs. AUC entre 9 e 12 meses,**<br>**média (DP):**<br>Geral: 4.99 (3.46) vs. 2.16 (2.46) **<br>GESF: 4.44 (2.73) vs. 2.51 (3.05) **<br>GM:3.79 (1.25) vs. 1.67 (1.61) **<br>GNMP: 5.38 (4.3) vs. 2.76 (2.47) **<br>GNMSP: 4.40 (3.25) vs. 1.52 (2.57)<br>**||||
||||**Proteínas totais (g/l), média (DP):**<br>Baseline:54.1 (9.10)<br>Aos 3 meses:58.4 (9.4)<br>Aos 6 meses:59.2 (8.9)<br>Aos 9 meses:61.2 (7.2)<br>Aos 12 meses:62.3 (9.4) *||||
||||**Albumina (g/l), média (DP):**<br>Baseline:30.8 (7.8)<br>Aos 3 meses:33.8 (7.6)<br>Aos 6 meses:36.3 (8.1)<br>Aos 9 meses:37.5 (8.0)<br>Aos 12 meses:37.8 (8.2) *||||
||||**Colesterol (g/l), média (DP):**<br>Baseline:9.2 (3.0)<br>Aos 3 meses:8.4 (2.8)<br>Aos 6 meses:7.6 (2.4)<br>Aos 9 meses:6.9 (1.9)<br>Aos 12 meses:7.1 (2.3) *||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||**eGFR (ml/min)basal e 12 meses**<br>**nos subgrupos, média (DP)**¥:<br>Geral: 62.1 (31.8) vs. 65.3 (31.8)<br>GESF: 56.2 (33.2) vs. 70.7 (39.6)<br>GM: 55.5 (21.1) vs. 62.2 (19.6)<br>GNMP: 64.7 (40.5) vs. 59.9 (34.4)<br>GNMSP: 71.6 (26.3) vs. 69.1 (32.2)||||
||||**Eficácia da monoterapia de ET**<sup>**1**</sup>**,**<br>**média (DP)**||||
|**Yuan et al.**<br>**2010(142)**|NR|NR|**Proteinúria (g/24h), antes vs.**<br>**depois da monoterapia de ET**<sup>**1**</sup>**:**<br>4.1 (1.4) vs. 4.2 (1.5)<br>**Albumina sérica (g/l), antes vs.**<br>**depois da monoterapia de ET**<sup>**1**</sup>**:**<br>29.5 (4.2) vs. 28.4 (4.8)|NS<br>NS|NR|NR|
||||**Creatinina sérica(μmol/l), depois**<br>**da monoterapia de ET**<sup>**1**</sup>**:**<br>131.0 (44.9) vs.133.2(52.8)|NS|||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||**eGFR**(**ml/min/1.73m**<sup>**2**</sup>**), depois da**<br>**monoterapia de ET**<sup>**1**</sup>**:**<br>63.3 (26.8) vs. 63.3 (27.1)<br>**Eficácia do MMF, média (DP)**|NS|||
||||**Proteinúria (g/24h)**<br>Antes de MMF:4.2 (1.5)<br>Aos 3 meses:3.8 (1.2) *<br>Aos 6 meses:2.5 (0.9) ¥<br>Aos 9 meses:1.8 (0.7) ¥<br>Aos 12 meses:1.5 (0.6) ¥|*<0.05<br>vs.|||
||||**eGFR**(**ml/min/1.73m**<sup>**2**</sup>**):**<br>Antes de MMF:63.3 (27.1)|antes<br>de|||
||||Aos 3 meses:65.7 (26.8) *<br>Aos 6 meses:72.9 (25.3) ¥|MMF|||
||||Aos 9 meses:81.3 (24.2) ¥|¥<0.01|||
||||Aos 12 meses:81.2 (23.8) ¥<br>**Creatinina sérica(μmol/l):**<br>Antes de MMF: 133.2 (52.8)<br>Aos 3 meses:127.3 (43.7) *<br>Aos 6 meses: 97.2 (27.3) ¥|vs.<br>antes<br>de<br>MMF|||
||||Aos 12 meses:95.9 (22.5) ¥||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**RC, n (%):**<br>Geral:27 (63)<br>GNMP:8 (80); GM:5 (63)<br>GESF: 1 (25); NIgA:2 (33)<br>NLES: 8 (73); GNPI:3 (75)<br>**RP, n (%):**||**Proteína na urina, antes vs. depois**<br>**de MMF:**<br>3.26 (2.6) vs. 0.87 (1.1)<br>**Albumina sérica, antes vs. depois**<br>**de MMF:**<br>3.7 (0.7) vs. 4.3 (0.5)|0.02<br>0.01|**Pressão Arterial Sistólica, antes vs.**<br>**depois de MMF:**<br>132 (17) vs. 126 (11)|0.02|
|**Sahin et al.**<br>**2007 (143)**|Geral:10 (23)<br>GNMP:1 (10); GM:3 (37)<br>GESF: 1 (25); NIgA:2 (33)<br>NLES: 2 (18); GNPI:1 (25)<br>**Falha do MMF, n (%):**<br>Geral:6 (14)<br>GNMP:1 (10); GM:0<br>GESF: 2 (50); NIgA:2 (33)<br>NLES: 1 (9); GNPI:0|NR|**Creatinina sérica, antes vs. depois**<br>**de MMF:**<br>1.29 (0.55) vs. 1.14 (0.38)<br>**GFR, antes vs. depois de MMF:**<br>71.5 (28) vs. 78.1 (27)<br>**Colesterol sérico, antes vs. depois**<br>**de MMF:**<br>247 (95) vs. 193 (75)|0.04<br>0.021<br>0.001|Insuficiência renal foi resolvida em 7 dos<br>11 (63,6%) pacientes com insuficiência<br>renal inicialmente, 2 com GNMP, 2 com<br>GM, 1 com GESF, 4 com GN crescente,<br>2 com NLES e em 2 insuficiência renal<br>de novo desenvolvida.||
|**Jones et al.**<br>**2004 (90)**|NR|NR|**Proteinúria (g/24h), média:**<br>**Grupo MMF + ET3:**<br>Basal:5.09<br>Aos 6 meses:1.97 *<br>Aos 12 meses:1.96 *<br>Aos 18 meses:2.59 *<br>**Grupo Controle**<br>Basal:5.98<br>Aos 6 meses:4.77▲<br>Aos 12 meses:6.61▲|*<0.00<br>5 vs.<br>basal<br>▲ NS<br>vs.<br>basal|NR|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||Aos 18 meses:6.34▲<br>**Grupo Controle vs. Grupo MMF**<br>**+ ET3: ¥**<br>**Albumina sérica (g/l), média:**<br>**Grupo MMF + ET3:**<br>Basal:29|<br>**¥**0.003<br>control<br>e vs.<br>Grupo<br>MMF +<br>ET<sup>3</sup>,<br>aos 18|||
||||Aos 6 meses:36.6▲<br>Aos 12 meses:38.2▲<br>Aos 18 meses:37▲<br>**Grupo Controle**<br>Basal:30.8|meses|||
||||Aos 6 meses:33.7▲||||
||||Aos 12 meses:34.5▲<br>Aos 18 meses:33.5▲||||
||||**Creatinina sérica (μmol/l), média:**<br>**Grupo MMF + ET3:**<br>Basal:101.4<br>Aos 6 meses:86.4▲<br>Aos 12 meses:92.8▲||||
||||Aos 18 meses:103▲<br>**Grupo Controle**<br>Basal:103.2<br>Aos 6 meses:132.3▲<br>Aos 12 meses:133.7▲<br>Aos 18 meses:155.8*<br>**Grupo Controle vs. Grupo MMF**<br>**+ ET3:**NS aos 18 meses||||  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||||**Depuração de creatinina ml/min,**<br>**média:**<br>**Grupo MMF + ET3:**<br>Basal:105.3<br>Aos 6 meses:112.4▲<br>Aos 12 meses:106.4▲<br>Aos 18 meses:99.04▲<br>**Grupo Controle**<br>Basal:108.4<br>Aos 6 meses:80.3*<br>Aos 12 meses:81.31*<br>Aos 18 meses:66.83*<br>**Grupo Controle vs. Grupo MMF**<br>**+ ET3:**NS aos 18 meses||||
||||**Tacrolimo**||||
|**Li et al.**<br>**2009 (131)**|**RC**,**n (%):**<br>Geral:11 (64.7)<br>GESF:  3 (42.9); DLM: 5 (100)<br>GNMSP: 3 (60)<br>**RP**,**n (%):**<br>Geral:3 (17.6)<br>GESF: 1 (14.3); DLM: 0 (0)<br>GNMSP: 2 (40)<br>**Sem resposta**,**n (%):**<br>Geral:3 (17.6)<br>GESF: 3 (42.9); DLM: 0 (0)<br>GNMSP: 0 (0)|Alcance de<br>remissão:<br>0.05 GESF<br>vs. DLM|**Proteinúria (g/dia), mediana**<br>**(IQ) basal vs. 24 semanas vs. 48**<br>**semanas**<br>Geral:6.7 (4.5-12.9) vs. 0.2 (0.1-<br>6.3) * vs.0.2 (0.1-6.7) *<br>GESF: 7.0 (4.5-8.5) vs. 0.9 (0.1-6.3)<br>vs. 1.4 (0.1-6.7)<br>DLM: 6.4 (5.4-6.8) vs. 0.1 (0.1-0.2)<br>vs. 0.1 (0.1-0.2)<br>GNMSP: 7.5 (5.3-12.9) vs.0.2<br>(0.1-1.8) vs.  0.1 (0.1-2.3)<br>**Albumina sérica (g/l), mediana**<br>**(IQ) basal vs. 24 semanas vs. 48**<br>**semanas**|*<0.00<br>1 vs.<br>basal|**Dose média (DP) de TAC (mg/kg/d):**<br>Nas primeiras 24 semanas: 0,06 (0,01)<br>Nas 24 seguintes:  0,04 (0,01)|NR|  
|**Autor**|**Remissão/ Relapso**|**Valor p**|**Desfechos bioquímicos relevantes**|**Valor**<br>**p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|
||**Tempo para remissão, semanas,**<br>**média (DP):**<br>Geral: RC:5.6 (1.4); RP:8.0 (5.1)<br>GESF: 5.8 (1.3); DLM: 4.4 (0.9)<br>GNMSP: 5.2 (2.3)||Geral:17.5 (7.4, 26.3) vs. 42.4 (8.7,<br>48.1) * vs. 42.4 (15.4, 45.6) *||||
||**Relapsos, n:**<br>Geral:5; GESF: 1<br>DLM: 2; GNMSP: 2||||||
||**Tempo médio (DP) para**<br>**relapso:**<br>37.6meses(13.4)||||||
||||**Rituximabe**||||
||**RC, n:**<br>2 (ambos com crioglobulinemia)<br>**RP, n:**<br>||**Proteinúria (g/dia), média (DP):**<br>Basal:3.9 (2.0)<br>Aos 3 meses:2.4 (2.1)<br>Aos 6 meses:1.8 (1.4)*<br>Aos 9 meses:1.4 (1.4) *<br>Aos 12 meses:2.1 (2.3) *|*<0.05<br>vs.<br>basal|||
|**Dillon et**<br>**al. 2012**<br>**(89)**|3<br>**Não resposta, n:**<br>1<br>**Relapso: 1**|NR|**Células B (células/μl), média (DP):**<br>Basal: 210 (130)<br>Aos 3 meses: 4 (5) *<br>Aos 6 meses: 14 (9) *<br>Aos 9 meses: 24 (19) *<br>Aos 12 meses: 47 (38) *||**Nível sérico, média (DP) de RTX**<br>**depois da segunda dose:**<br>252 ± 85 μg / ml|NR|
||||**Creatinina sérica (mg/dl), média**<br>**(DP):**<br>Basal: 1.7(0.5)|NS|||  
|**Autor**<br>**Remissão/ Relapso**<br>**Valor p**<br>**Desfechos bioquímicos relevantes**|**Valor**<br>**p**<br>**Outros desfechos**<br>**Valor p**|
|---|---|
|Aos 12 meses: 1.7 (NR)<br>**Depuração de creatinina**<br>**ml/min/1.73 m**<sup>**2**</sup>**, média:**<br>Basal: 48 (13); aos12 meses: 48<br>(NR)|NS|
|MMF: micofenolato de mofetila; TAC: tacrolimo; RTX: rituximabe; ET1: prednisona; ET2: metilp<br>remissão parcial; UPCR: relação proteína/ creatinina; AUC: área sob a curva;eGFR: taxa de filtraçã<br>glomerulopatia membranosa; GNMP: glomerulonefrite membranoproliferativa; GNMSP: glomer<br>segmentar focal; DLM: doença de lesão mínima;NIgA: nefropatia por IgA; RR: risco relativo; IQ: inter<br>e máximo; IC95%: intervalo de confiança de 95%; NS: estatisticamente não significante; NR: não rep|rednisolona; ET3: prednisolona; RC: remissão completa; RP:<br>o glomerular estimada;GFR:taxa de filtração glomerular;GM:<br>ulonefrite mesangioproliferativa; GESF; glomeruloesclerose<br>valo interquartil; DP: desvio padrão; min.-máx.: valores mínimo<br>ortado.|  
**Tabela 46 – Desfechos de segurança reportados nos estudos que analisaram terapias imunossupressoras para o tratamento de glomerulonefrite membranoproliferativa ou mesangiocapilar (primárias ou idiopáticas) tipo I.**  
|**Evento adversos**|**Dimkovic et al.**<br>**2009 (126)**|**Sahin et al. 2007**<br>**(143)**|**Yuan et al.**<br>**2010(142)**|**Jones et a**|**l. 2004(90)**|**Li et al.  2009 (131)**|**Dillon et al. 2012**<br>**(89)**|
|---|---|---|---|---|---|---|---|
|**Grupo**|**MMF, n**|**MMF, n**|**MMF, n**|**MMF, n**|**Controle,**<br>**n**|**TAC, n**|**RTX, n**|
|Leucopenia|NR|NR|NR|1|NR|NR|NR|
|Diarreia|NR|4|1|NR|NR|1|NR|
|Náusea/vômito|NR|NR||NR|NR|1|NR|
|1 ou + EA|NR|NR|NR|NR|NR|Geral: 9 (47.4)<br>GESF: 5 (62.5)<br>DLM: 2 (33.3)<br>GNMSP:2(40.0)|0|
|EA sérios|NR|NR|0|1|NR|NR|0|
|Nefrototoxicidade<br>reversível aguda|NR|NR|NR|NR|NR|1|NR|
|Hepatotoxicidade|NR|3|NR|NR|NR|2|NR|  
|**Evento adversos**|**Dimkovic et al.**<br>**2009 (126)**|**Sahin et al. 2007**<br>**(143)**|**Yuan et al.**<br>**2010(142)**|**Jones et a**|**l. 2004(90)**|**Li et al.  2009 (131)**|**Dillon et al. 2012**<br>**(89)**|
|---|---|---|---|---|---|---|---|
|**Grupo**|**MMF, n**|**MMF, n**|**MMF, n**|**MMF, n**|**Controle,**<br>**n**|**TAC, n**|**RTX, n**|
|Novo início / piora de<br>hipertensãopreexistente|NR|NR|NR|NR|NR|5|NR|
|Diabetes Mellitus|NR|NR|NR|NR|NR|1|NR|
|Infecções|NR|NR|NR|1|NR|4|NR|
|Infecção trato respiratório<br>superior|NR|NR|NR|1|NR|NR|NR|
|Pneumonia|NR|NR|NR|NR|NR|2|NR|
|Infecção trato urinário|NR|NR|NR|NR|NR|2|NR|
|Supressão da medula óssea|NR|NR|NR|NR|NR|3|NR|
|Linfoma|NR|NR|NR|NR|NR|1|NR|
|Suspensão/interrupção do<br>tto|3|NR|NR|1|NR|1|0|
|Morte|1|1|0|0|NR|0|0|  
EA: eventos adversos; MMF:micofenolato de mofetila;TAC: tacrolimo; RTX: rituximabe NR: não reporta  
**Diretrizes diagnósticas e terapêuticas da Síndrome Nefrótica em Adulto**  
**Questão de Pesquisa 13 -** Quais as terapias imunossupressoras para o tratamento de NIgA em adultos? (Considerar TAC, prednisona e metilprednisolona, MMF, ciclofosfamida, azatioprina)

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **MEDLINE via Pubmed:** -->
((((("Prednisone"[Mesh] OR "Methylprednisolone"[Mesh] OR ("prednisone"[MeSH Terms] OR "prednisone"[All Fields]) OR ("methylprednisolone"[MeSH Terms] OR "methylprednisolone"[All Fields]) OR ("adrenal cortex hormones"[Pharmacological Action] OR "adrenal cortex hormones"[MeSH Terms] OR ("adrenal"[All Fields] AND "cortex"[All Fields] AND "hormones"[All Fields]) OR "adrenal cortex hormones"[All Fields] OR "corticosteroid"[All Fields])) OR ("Tacrolimus"[Mesh] OR ("tacrolimus"[MeSH Terms] OR "tacrolimus"[All Fields]) OR ("tacrolimus"[MeSH Terms] OR "tacrolimus"[All Fields] OR "fk506"[All Fields]) OR ("calcineurin inhibitors"[Pharmacological Action] OR "calcineurin inhibitors"[MeSH Terms] OR ("calcineurin"[All Fields] AND "inhibitors"[All Fields]) OR "calcineurin inhibitors"[All Fields]))) OR ("Azathioprine"[Mesh] OR ("azathioprine"[MeSH Terms] OR "azathioprine"[All Fields]))) OR ("Cyclophosphamide"[Mesh] OR ("cyclophosphamide"[MeSH Terms] OR "cyclophosphamide"[All Fields]))) OR ("Mycophenolic Acid"[Mesh] OR ("mycophenolic acid"[MeSH Terms] OR ("mycophenolic"[All Fields] AND "acid"[All Fields]) OR "mycophenolic acid"[All Fields] OR ("mycophenolate"[All Fields] AND "mofetil"[All Fields]) OR "mycophenolate mofetil"[All Fields]) OR ("mycophenolic acid"[MeSH Terms] OR ("mycophenolic"[All Fields] AND "acid"[All Fields]) OR "mycophenolic acid"[All Fields] OR ("mycophenolate"[All Fields] AND "sodium"[All Fields]) OR "mycophenolate sodium"[All Fields]))) AND ("Glomerulonephritis, IGA"[Mesh] OR ("glomerulonephritis, iga"[MeSH Terms] OR ("glomerulonephritis"[All Fields] AND "iga"[All Fields]) OR "iga glomerulonephritis"[All Fields] OR ("iga"[All Fields] AND "nephropathy"[All Fields]) OR "iga nephropathy"[All Fields]) OR ("glomerulonephritis, iga"[MeSH Terms] OR ("glomerulonephritis"[All Fields] AND "iga"[All Fields]) OR "iga glomerulonephritis"[All Fields] OR ("iga"[All Fields] AND "glomerulonephritis"[All Fields]))) Total de referências: 921 referências Data de acesso: 01/11/2017  
**EMBASE:**  
('prednisone'/exp OR 'prednisone' OR 'methylprednisolone'/exp OR 'methylprednisolone' OR 'tacrolimus'/exp OR 'tacrolimus' OR 'azathioprine'/exp OR 'azathioprine' OR 'cyclophosphamide'/exp OR 'cyclophosphamide' OR 'mycophenolate mofetil'/exp OR 'mycophenolate mofetil' OR 'mycophenolic acid'/exp OR 'mycophenolic acid' OR 'mycophenolate sodium'/exp OR 'mycophenolate sodium') AND ('immunoglobulin a nephropathy'/exp OR  
'immunoglobulin a nephropathy' OR 'iga nephropathy'/exp OR 'iga nephropathy' OR 'iga glomerulonephritis') AND [embase]/lim  
Total:  1660 referências  
Data de acesso: 01/11/2017

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das Evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 2581 referências (921 no MEDLINE e 1660 no Embase). Destas, 300 foram excluídas por estarem duplicadas.  
Duas mil duzentos e oitenta e uma referências foram triadas por meio da leitura de título e resumos, das quais 55 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Trinta e nove estudos foram excluídos: uma revisão sistemática e um ensaio clínico por incluir crianças em sua população de estudo; quatro revisões sistemáticas por incluírem estudos originais semelhantes à outras revisões sistemáticas mais recentes, já incluídas neste documento, 20 ensaios clínicos por estarem incluídos nas revisões sistemáticas; três ensaios clínicos por analisar os efeitos da tonsilectomia vs. imunossupressão; três séries de casos e um estudo observacional; cinco estudos por não abordarem desfechos de interesse, um por avaliar os efeitos da losartana.  
Dezesseis estudos foram incluídos: sete revisões sistemáticas<sup>144-150</sup> , oito ensaios clínicos randomizados<sup>151-158</sup> e um estudo comparativo quase experimental<sup>85</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos Estudos e seus Resultados** -->
A descrição sumária dos estudos encontra-se nas tabelas a seguir, divididas por intervenções avaliadas nos estudos.  
**3.1 Estudos que avaliaram a eficácia e segurança da azatioprina (AZA) ou ciclofosfamida (CTX), em monoterapia ou em combinação com corticoides (metilprednisolona, prednisolona ou prednisona)**

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 47 - Características gerais dos estudos incluídos.** -->
|**Autor, ano**|**Desenho do estudo**|**Objetivo do**<br>**estudo**|**População estudada**|<br>**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Liu et al.**<br>**2016(145)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em setembro de<br>2013|Avaliar a eficácia e<br>segurança de<br>imunossupressores<br>no tratamento de<br>pacientes chineses<br>com NIgA|29 ECRs, com total<br>de 1466 pacientes<br>chineses|6 ECRs: MMF 1 - 2 g/dia<br>vs corticoides;<br>5 ECRs: AZA 2 - 5<br>mg/kg/dia vs corticoides;<br>4 ECRs: LET 20 mg/dia<br>vs CTX;<br>2 ECRs: CTX 0,5 - 0,75<br>g/m2 vs corticoides;<br>13 ECRs: LET 20 - 30<br>mg/dia vs corticoides|Corticoides ou CTX|Alto (validade externa<br>baixa: apenas pacientes<br>chineses; Apenas 4<br>estudos com qualidade<br>razoável; não foi feita<br>nenhuma análise de<br>subgrupo; Uma das<br>análises utilizou modelo<br>de efeitos fixos para uma<br>heterogeneidade<br>considerável)|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do**<br>**estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Tian et al.**<br>**2015(149)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em agosto de 2014|Avaliar a eficácia e<br>segurança de<br>imunossupressores<br>para o tratamento<br>de NIgA, em<br>estudos de mais de<br>5 anos de<br>seguimento|6 ECRs e 1 quase-<br>experimental, com<br>total de 471<br>participantes|Intervenções diferentes<br>para cada estudo:<br>- prednisolona +<br>dipiridamol<br>- metilprednisolona + tto<br>suporte<br>- prednisona + AZA +<br>heparina/varfarina +<br>dipiridamol<br>- prednisolona +<br>dipiridamol + anti-<br>inflamatórios<br>- Prednisolona +<br>CTX/AZA<br>- MMF|Dipiridamol, tto suporte,<br>heparina/varfarina,<br>controles (sem uso de<br>imunossupressores)|Moderado (apenas<br>estudos em inglês, avalia<br>conjuntamente ECR e<br>estudos observacionais)|
|**Samuels et**<br>**al.**<br>**2004(147)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em 2002|Avaliar os efeitos<br>dos<br>imunossupressores<br>no tratamento da<br>NIgA|13 estudos, com total<br>de 623 participantes|Corticoides<br>(metilprednisolona,<br>prednisolona ou<br>prednisona)<br>Imunossupressores<br>(AZA, CsA, CTX)<br>Combinação de<br>imunossupressores e<br>corticoides|Dipiridamol, heparina,<br>placebo ou ausência de<br>tto|Alto: análise conjunta de<br>ECRs e estudos não<br>randomizados, não avalia<br>viés de publicação, não<br>reporta o uso de<br>protocolo prévio, não<br>houve descrição completa<br>dos participantes dos<br>estudos incluídos, como<br>desenho do estudo, idade,<br>sexo, ferramenta para a<br>avaliação de viés dos<br>estudos individuais<br>inadequada.|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do**<br>**estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Rauen et al.**<br>**2017(157)**|STOP IgAN trial:<br>ECR, aberto,<br>multicêntrico na<br>Alemanha, com<br>amostra subdividida<br>em grupo TFG alto<br>(≥60<br>mL/min/1,73m2) e<br>em grupo TFG<br>baixo (30 - 59<br>mL/min/1,73m2)|Avaliar desfechos<br>renais em pacientes<br>com TFG similar<br>tratados com<br>imunossupressor<br>comparado com<br>corticoides e tto de<br>suporte|Pacientes com NIgA<br>confirmada por<br>biopsia, proteinúria<br>>0,75 g/dia e <3,5<br>g/dia|Monoterapia com<br>corticoides ou<br>prednisolona + CTX por<br>3 meses, seguido de AZA<br>por 33 meses, ambos<br>combinado com tto<br>suporte|Tto de suporte|Moderado: Análise<br>secundária de ECR<br>(perda de randomização<br>original)|
|**Rauen et al.**<br>**2015(156)**|STOP IgAN trial:<br>ECR, aberto,<br>multicêntrico na<br>Alemanha, com<br>amostra subdividida<br>em grupo TFG alto<br>(≥60<br>mL/min/1,73m2) e<br>em grupo TFG<br>baixo (30 - 59<br>mL/min/1,73m2)|Avaliar desfechos<br>renais em pacientes<br>com TFG similar<br>tratados com<br>imunossupressor<br>comparado com<br>corticoides e tto de<br>suporte|Pacientes com NIgA<br>confirmada por<br>biopsia, proteinúria<br>>0,75 g/dia e <3,5<br>g/dia|Monoterapia com<br>corticoides ou<br>prednisolona + CTX por<br>3 meses, seguido de AZA<br>por 33 meses, ambos<br>combinado com tto<br>suporte|Tto de suporte|Baixo|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do**<br>**estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Pozzi et al.**<br>**2013(155)**|ECR|Avaliar o<br>tratamento com<br>corticoides + AZA<br>em pacientes com<br>NIgA e DRCT<br>estádio 3/4|Pacientes com NIgA,<br>com creatinina sérica<br>>2,0 mg/dL e<br>proteinúria ≥1 g/dia|Mpred 1 g por 3 dias<br>consecutivos, nos meses<br>1, 3 e 5, com prednisona<br>oral 0,5 mg/kg dia<br>sim/dia não + AZA 1,5<br>mg/kg/dia por 6 meses,<br>seguido de prednisona<br>0,2 mg/kg dia sim/dia<br>não + AZA 50 mg/dia<br>por mais 6 meses|Corticoides em<br>monoterapia|Alto: não reporta método<br>de randomização, sigilo<br>de alocação, cegamento,<br>não apresenta cálculo<br>amostral.|
|**Stangou et**<br>**al.**<br>**2011(158)**|ECR|Avaliar os efeitos<br>do tratamento com<br>corticoides ou<br>corticoides + AZA<br>em pacientes com<br>NIgA que não<br>responderam a<br>iSRAA + ácidos<br>graxos poli-<br>insaturados|Pacientes com NIgA<br>confirmada por<br>biopsia, proteinúria<br>≥1 g/dia, TFGe ≥30<br>mL/min/1,73m2, que<br>não responderam ao<br>tratamento prévio<br>com iSRAA + ácidos<br>graxos poli-<br>insaturados|AZA 1 mg/kg/dia +<br>Mpred 0,6 mg/kg em<br>duas doses, reduzindo<br>por 4 mg a cada 15 dias<br>até chegar em 8 mg|Mpred 0,6 mg/kg em duas<br>doses, reduzindo por 4<br>mg a cada 15 dias até<br>chegar em 8 mg|Alto: sigilo de alocação,<br>não houve cálculo<br>amostral e a amostra é<br>muito pequena|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do**<br>**estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Pozzi et al.**<br>**2010(154)**|ECR, aberto,<br>multicêntrico (27<br>centros na Itália e<br>Suíça)|Avaliar eficácia e<br>segurança do<br>tratamento de<br>AZA+corticoides<br>em pacientes com<br>NIgA|Pacientes adultos<br>com NIgA,<br>creatinina sérica<br>≤2,0 mg/dL,<br>proteinúria ≥1,0<br>g/dia, por 3 meses|Mpred 1 g por 3 dias<br>consecutivos, nos meses<br>1, 3 e 5, com prednisona<br>oral 0,5 mg/kg dia<br>sim/dia não + AZA 1,5<br>mg/kg/dia por 6 meses,<br>seguido de prednisona<br>0,2 mg/kg dia sim/dia<br>não + AZA 50 mg/dia<br>por mais 6 meses|Corticoides em<br>monoterapia|Baixo|
|**Tumlin et**<br>**al. 2003(85)**|Estudo<br>observacional<br>prospectivo com<br>controle histórico|Avaliar a eficácia<br>da CTX em<br>pacientes com<br>NIgA crescêntica|Pacientes com NIgA<br>crescêntica,<br>hipertensos (PA<br>>140/90 mmHg),<br>proteinúria >1,0<br>g/dia|Mpred IV 15 mg/kg/dia<br>por 3 dias + prednisona<br>VO 1 mg/kg/dia por 60<br>dias, reduzindo para 0,6<br>mg/kg/dia por 60 dias,<br>reduzindo para 0,3<br>mg/kg/dia, e então para<br>0,15 mg/kg/dia + CTX<br>IV 0,5 - 0,75 g/m2<br>mensalmente por 6 meses|Controle histórico,<br>pacientes com NIgA não<br>tratados. Dados<br>retrospectivos|Alto: estudo com controle<br>histórico, não houve<br>nenhum tipo de análise<br>de covariância por<br>variáveis basais|  
NIgA: nefropatia por Imunoglobulina A; ECR: ensaio clínico randomizado; MMF: micofenolato de mofetila; AZA: azatioprina; LET: leflunomida; CTX: ciclofosfamida; tto: tratamento; CsA: ciclosporina A; TFG: taxa de filtração glomerular; DRCT: doença renal crônica terminal; Mpred: metilprednisolona; iSRAA: inibidores do sistema renina-angiotensina-aldosterona; TFGe: taxa de filtração glomerular estimada; PA: pressão arterial.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 48 - Características dos participantes incluídos nos estudos.** -->
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ±**<br>**DP**|**Sexo, n (%)**<br>**feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
||Total|1466|NR|NR|NR|3 - 24 meses|
||AZA|292|NR|NR|NR|6 - 24 meses|
|**Liu et al.**|MMF|253|NR|NR|NR|3 - 6 meses|
|**2016(145)**|LEF vs corticoide|623|NR|NR|NR|3 meses|
||CTX|72|NR|NR|NR|12 meses|
||LEF vs CTX|226|NR|NR|NR|3 meses|
|**Tian et al.**<br>**2015(149)**|Total|471|11,6 - 45|NR|NR|60 - 120 meses|
|**Samuels et**<br>**al.**<br>**2004(147)**|Total|623|NR|NR|NR|3 - 120 meses|
||TFG alto: tto<br>suporte|54|45,6 ± 11,9|7 (13%)|**Creatinina plasmática (mg/dL):**<br>1,4 ± 0,5<br>**TFGe (mL/min/1,73m2):**<br>88,2 ± 28,6<br>**Proteína urinária (g/dia):**||
|**Rauen et al.**|||||1,6 ± 0,7|36|
|**2017(157)**|TFG alto:<br>corticoide|55|41,7 ± 13,3|13 (24%)|**Creatinina plasmática (mg/dL):**<br>1,3 ± 0,4<br>**TFGe (mL/min/1,73m2):**<br>94,2 ± 32,2<br>**Proteína urinária (g/dia):**<br>1,6 ± 0,8|meses|  
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ±**<br>**DP**|**Sexo, n (%)**<br>**feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
||TFG baixo: tto<br>suporte|26|46,0 ± 14,0|8 (31%)|**Creatinina plasmática (mg/dL):**<br>2,0 ± 0,6<br>**TFGe (mL/min/1,73m2):**<br>49,9 ± 17,5<br>**Proteína urinária (g/dia):**<br>1,7 ± 0,7||
||TFG baixo:<br>imunossupressor|27|45,1 ± 12,8|7 (26%)|**Creatinina plasmática (mg/dL):**<br>2,2 ± 0,7<br>**TFGe (mL/min/1,73m2):**<br>42,4 ± 11,4<br>**Proteína urinária (g/dia):**<br>2,0 ± 0,8||
|**Rauen et al.**|<br>Corticoide ou<br>imunossupressores|82|42,8 ± 13,1|20 (24%)|**Creatinina plasmática (mg/dL):**<br>1,6 ± 0,7<br>**TFGe (mL/min/1,73m2):**<br>61,1 ± 29,0<br>**Proteína urinária (g/dia):**<br>1,8 ± 0,8|36|
|**2015(156)**|Tto suporte|80|45,8 ± 12,5|15 (19%)|**Creatinina plasmática (mg/dL):**<br>1,6 ± 0,6<br>**TFGe (mL/min/1,73m2):**<br>57,4 ± 24,9<br>**Proteína urinária (g/dia):**<br>1,6 ± 0,7|meses|  
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ±**<br>**DP**|**Sexo, n (%)**<br>**feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
|**Pozzi et al.**|AZA|20|Mediana (IQR):<br>43,0 (32,6 - 52,4)|3 (15%)|**Creatinina plasmática (mg/dL):**<br>mediana (IQR): 2,60 (2,37 - 3,04)<br>**TFGe (mL/min/1,73m2):**<br>mediana (IQR): 36 (29 - 43)<br>**Proteína urinária (g/dia):**<br>mediana (IQR): 3,2 (1,7 - 5,5)|Mdi d 45|
|**2013(155)**|Corticoides|26|Mediana (IQR):<br>37,3 (32,7 - 52,3)|6 (23%)|**Creatinina plasmática (mg/dL):**<br>mediana (IQR): 2,85 (2,38 - 3,55)<br>**TFGe (mL/min/1,73m2):**<br>mediana (IQR): 33 (24 - 40)<br>**Proteína urinária (g/dia):**<br>mediana (IQR): 2,0 (1,5 - 3,2)|eana e , anos|
|**Stangou et**<br>|AZA+Mpred|12|46.6 ± 12,1|4 (33%)|**TFGe (mL/min/1,73m2):**<br>57,4 ± 28,7<br>**Proteína urinária (g/dia):**<br>2,4 ± 1,0|12|
|**al.**<br>**2011(158)**|Mpred|10|51,3 ± 9,1|4 (40%)|**TFGe (mL/min/1,73m2):**<br>52,0 ± 26,7<br>**Proteína urinária (g/dia):**<br>2,4 ± 0,9|meses|
|**Pozzi et al.**<br>**2010(154)**|AZA|101|Mediana (IQR):<br>34,8 (27,7 - 43,9)|25 (25%)|**Creatinina plasmática (mg/dL):**<br>mediana (IQR): 1,20 (1,00 - 1,50<br>**TFGe (mL/min/1,73m2):**<br>mediana (IQR): 72 (53 - 88)<br>**Proteína urinária (g/dia):**<br>mediana (IQR): 2,1 (1,5 - 3,5)|mediana de 4,9 anos|  
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ±**<br>**DP**|**Sexo, n (%)**<br>**feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
||Controle|106|Mediana (IQR):<br>40,5 (30,3 - 51,3)|31 (29%)|**Creatinina plasmática (mg/dL):**<br>mediana (IQR): 1,28 (1,00 - 1,66)<br>**TFGe (mL/min/1,73m2):**<br>mediana (IQR): 63 (44 - 85)<br>**Proteína urinária (g/dia):**<br>mediana (IQR): 2,0 (1,5 - 2,7)||
|**Tumlin et**<br>**al. 2003(85)**|CTX|12|44|8 (66%)|**Creatinina plasmática (mg/dL):**<br>1,49 ± 0,2<br>**Proteína urinária (g/dia):**<br>3,70 ± 2,70|36 meses|
||Controle histórico|12|43|4 (33%)|**Creatinina plasmática (mg/dL):**<br>1,72 ± 0,3||  
DP: desvio padrão; AZA: azatioprina; MMF: micofenolato de mofetila; LEF: leflunomida; CTX: ciclofosfamida; TFGe: taxa de filtração glomerular estimada; tto: tratamento; Mpred: metilprednisolona; IQR: intervalo interquartil; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 49 -  Desfechos reportados nos estudos incluídos.** -->
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
|**Liu et al.**<br>**2016*(145)**|AZA vs corticoides|**Remissão da proteinúria:**<br>OR: 3,43 (IC 95% 1,92;<br>6,12), p<0,0001 [favorece<br>corticoides]. 5 ECRs,<br>n=292, I2: 5%, p=NS|NR|NR|NR|  
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
||MMF vs corticoides|**Remissão da proteinúria:**<br>OR: 2,19 (IC 95% 1,25;<br>3,85), p=0,006 [favorece<br>corticoides]. 6 ECRs,<br>n=247, I2: 30%, p=NS|NR|NR|NR|
||LEF vs corticoides|**Remissão da proteinúria:**<br>OR: 2,64 (IC 95% 1,80;<br>3,86), p<0,0001. 13 ECRs,<br>n=613, I2: 24%, p=NS|NR|NR|NR|
||CTX vs corticoides|**Remissão da proteinúria:**<br>OR: 0,91 (IC 95% 0,41;<br>1,41), p=0,0004 [favorece<br>corticoides]. 2 ECRs, n=72,<br>I2: 72%, p=NS|NR|NR|NR|
||LEF vs CTX|**Remissão da proteinúria:**<br>OR: 2,01 (IC 95% 1,08;<br>3,75), p=0,03 [favorece<br>corticoides] . 4 ECRs,<br>n=224, I2: 0%, p=NS|NR|NR|NR|
|**Tian et al.**<br>**2015(149)**|Imunossupressores vs<br>controles|**Deterioração da função**<br>**renal:**<br>RR: 0,19 (IC 95% 0,07;<br>0,54), p=0,002. 3 estudos,<br>n=257, I2: 0%, p=NS|NR|NR|RR: 0,30 (IC 95% 0,19;<br>0,48), p<0,00001 [favorece<br>imuno]. 7 estudos, n=471,<br>I2=0%, p=NS|  
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
||Corticoides vs placebo ou<br>ausência de tto|NR|**Proteinúria de 24h:**<br>DMP: -0,58 (IC 95% -0,95;<br>-0,21), p=0,002. 5 estudos,<br>n=244, I2: 0%, p=NS<br>**TFGe:**<br>DMP: 21,66 (IC 95% 7,87;<br>35, 35,44), p=0,002. 3<br>estudos, n=119, I2: 51,8%,<br>p=NS|**Duplicação da creatinina**<br>**plasmática:**<br>RR: 0,45 (IC 95% 0,29;<br>0,69), p=0,0003. 6 estudos,<br>n=341, I2: 0%, p=NS|RR: 0,44 (IC 95% 0,25;<br>0,80), p=0,007. 6 estudos,<br>n=341, I2: 0%, p=NS|
|**Samuels et**|||**Proteinúria de 24h:**<br>DMP: -0,42 (IC 95% -0,72;<br>-0,12), p=0,007. 1 estudo,<br>n=19|||
|**al.**<br>**2004(147)**|Corticoides vs dipiridamol|NR|**TFGe:**<br>DMP: 2,50 (IC 95% -19,46;<br>24,46), p=NS. 1 estudo,<br>n=19|NR|NR|
||Imunossupressores citotóxicos<br>vs placebo ou ausência de tto|NR|**Proteinúria de 24h:**<br>DMP: -0,74 (IC 95% -0,95;<br>-0,54), p<0,00001. 2<br>estudos, n=100, I2: 0%,<br>p=NS|NR|RR: 0,35 (IC 95% 0,04;<br>3,22), p=NS. 2 estudos,<br>n=106|
||CsA vs placebo ou ausência de<br>tto|NR|**Proteinúria de 24h:**<br>DMP: -1,60 (IC 95% -2,43;<br>-0,77), p=0,0002. 1 estudo,<br>n=22|NR|NR|  
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
||Imunossupressores+corticoides<br>vs placebo ou ausência de tto|NR|**Proteinúria de 24h:**<br>DMP: -1,25 (IC 95% -2,71;<br>0,21), p=NS. 3 estudos,<br>n=154, I2: 97,3%,<br>p<0,00001|NR|RR: 0,59 (IC 95% 0,06;<br>6,03), p=NS. 2 estudos,<br>n=152|
|**Rauen et**<br>**al 2017**|TFG alto: corticoides vs tto<br>suporte|**Remissão completa:**<br>OR: 5,31 (IC 95% 1,07;<br>26,36), p=0,02|**TFGe:**<br>**Redução ≥15**<br>**mL/min/1,73m2**<br>OR: 0,64 (IC 95% 0,24;<br>1,75), p=NS|NR|NR|
|**.**<br>**(157)**|TFG baixo: imunossupressores<br>vs tto suporte|**Remissão completa:**<br>OR: 3,58 (IC 95% 0,26;<br>55,89), p=NS|**TFGe:**<br>**Redução ≥15**<br>**mL/min/1,73m2**<br>OR: 1,67 (IC 95% 0,41;<br>6,79), p=NS|NR|NR|
|**Rauen et**<br>**al.**<br>**2015(156)**|Corticoide ou<br>imunossupressores vs tto<br>suporte|**Remissão completa:**<br>OR: 4,82 (IC 95% 1,43;<br>16,30), p=0,01|**TFGe:**<br>**Redução ≥15**<br>**mL/min/1,73m2**<br>OR: 0,89 (IC 95% 0,44;<br>1,81), p=NS|NR|NR|  
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
|**Pozzi et al.**<br>**2013(155)**|AZA+corticoides vs<br>corticoides|NR|**Proteinúria de 24h:**<br>**AZA, mediana (IQR)**<br>Basal: 3,20 (1,74 - 5,54)<br>Final: 2,73 (0,82 - 4,13)<br>**Corticoides, mediana**<br>**(IQR)**<br>Basal: 2,00 (1,50 - 3,23)<br>Final: 1,05 (0,53 - 1,47)|**Creatinina plasmática:**<br>**Aumento de 50%**<br>AZA: 10/20 (50%)<br>Corticoides: 11/26 (42%)<br>RR: 0,08 (IC 95% 0,01;<br>0,44), p=0,004|NR|
|**Stangou et**<br>**l**|AZA+Mpred|**Relapso de proteinúria:**<br>após 12 meses: 6 (50%)|**Proteinúria de 24h:**<br>Basal: 2,4 ± 1,0<br>12 meses: 0,7 ± 0,7<br>p<0,001<br>**TFGe:**<br>Basal: 57,4 ± 28,7<br>12 meses: 66,0 ± 31,0<br>p=NS|NR|NR|
|**a.**<br>**2011(158)**|Mpred|**Remissão parcial:**<br>12 meses: 4 (40%)<br>**Relapso de proteinúria:**<br>após 12 meses: 5 (50%)|**Proteinúria de 24h:**<br>Basal: 2,4 ± 0,9<br>12 meses: 0,8 ± 0,5<br>p<0,001<br>**TFGe:**<br>Basal: 52,0 ± 26,7<br>12 meses: 53,6 ± 27,3<br>p=NS|NR|NR|  
|**Autor, ano**|**Grupos comparados**|**Desfechos clínicos**<br>**primários**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
|**Pozzi et al.**<br>**2010(154)**|AZA vs controle|NR|NR|**Creatinina plasmática:**<br>**Aumento de 50%:**<br>AZA: 13 (12,9%, IC 95%<br>7,5;20,9)<br>Controle: 12 (11,3%, IC<br>95% 6,5; 18,9)<br>p=NS<br>RR: 0,63 (IC 95% 0,23;<br>1,72), p=NS|NR|
|**Tumlin et**<br>**l**|CTX|NR|**Proteinúria de 24h:**<br>Basal: 3,70 ± 2,70<br>6 meses: 1,35 ± 1,43<br>36 meses: 1,46 ± 2,26|**Creatinina plasmática:**<br>Basal: 1,49 ± 0,84<br>6 meses: 1,51 ± 0,38<br>36 meses: 1,85 ± 1,54|Após 36 meses: 1 (8,3%)|
|**a.**<br>**2003(85)**|Controle histórico|NR|**Proteinúria de 24h:**<br>Basal: 4,73 ± 3,76<br>36 meses: 4,33 ± 2,50|**Creatinina plasmática:**<br>Basal: 1,72 ± 1,01<br>6 meses: 5,15 ± 3,18<br>36 meses: 4,33 ± 3,35|Após 36 meses: 5 (42%)|  
DRCT: doença renal crônica terminal; AZA: azatioprina; MMF: micofenolato de mofetila; LEF: leflunomida; CTX: ciclofosfamida; OR: _odds ratio_ ; IC: intervalo de confiança; ECR: ensaio clínico randomizado; RR: risco relativo; tto: tratamento; DMP: diferença média ponderada; TFGe: taxa de filtração glomerular estimada; CsA: ciclosporina A; IQR: intervalo interquartil; Mpred: metilprednisolona; NS: não significativo; NR: não reportado.*Resultados da comparação entre CTX e corticosteroides, para o desfecho redução na excreção de proteína urinária, favoreceram os corticosteroides, mas não foram relatados, pois o método de análise foi inadequado e alta heterogeneidade.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 50 - Eventos adversos reportados nas revisões sistemáticas incluídas.** -->
|||**Liu et al.**|**2016(145)**||**Tian et al. 2015(149)**|
|---|---|---|---|---|---|
|**Evento adverso**|AZA<br>(n=143)|MMF<br>(n=108)|LEF<br>(n=267)|LET vs CTX|Imunossupressores<br>(n=351)|
|Qualquer EA|79 (0.55%)|NR|NR|NR|39 (0,11%)<br>RR: 2,13 (IC 95% 1,17; 3,86), p=0,01|
|Mielossupressão|5 (0.03%)|NR|NR|NR|NR|
|Disfunção hepática|6 (0.04%)|4 (0.04%)|13 (0.05%)|LET: 9<br>CTX 13|NR|
|Sintomas digestivos|8 (0.06%)|16 (0.15%)|10 (0.04%)|LET: 3<br>CTX: 1|NR|
|Infecção|14 (0.1%)|NR|NR|NR|NR|
|Leucopenia|NR|NR|NR|LET: 0<br>CTX: 6|NR|
|Alopecia|NR|NR|NR|LET: 5<br>CTX: 0|NR|  
AZA: azatioprina; MMF: micofenolato de mofetila; LEF: leflunomida; CTX: ciclofosfamida; EA: evento adverso; RR: risco relativo; IC: intervalo de confiança; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 51 - Eventos adversos reportados nos ensaios clínicos randomizados incluídos.** -->
||**Rauen et al. 201**|**7(157)**|**Rauen et al.**|**2015(156)**||**Pozzi et al**|**. 2013(155)**||**Stangou e**<br>**2011(15**|**t al.**<br>**8)**|**Pozzi et**|**al. 2010(154**|**)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|Imunossupressores|Tto<br>t<br>|Corticoides ou<br>|Tto<br>t||AZA+corticoides|<br>Corticoides||AZA+Mpred|<br>Mpred<br>|AZA+corticoide|s<br>Corticoide|s<br>|
||n=55|supore<br>n=54<br>|munossupressores<br>n=55|supore<br>n=54|p|n=20|n=26|p|n=12|n=10|n=20|n=26|p|
|Qualquer EA|NR|NR|NR|NR|NR|16 (80%)|14 (54%)|NS|NR|NR|43|38|NS|
|EA grave|17|6|33|29|NS|NR|NR|NR|NR|NR|NR|NR|NR|
|Óbito|1|0|1|1|NS|NR|NR|NR|NR|NR|1|3|NR|
|Suspensão do<br>tratamento|NR|NR|NR|NR|NR|7 (35%)|4 (15%)|NS|NR|NR|15|3|0,002|
|Infecção|59 (eventos)|48<br>(eventos)|174 (eventos)|111<br>(eventos)|<sup>NS</sup>|0|2|NR|2 (17%)|1<br>(10%)|5|3|NR|
|Distúrbios ósseos|0|0|0|0|NS|NR|NR|NR|NR|NR|NR|NR|NR|
|Aumento de<br>enzimas<br>hepáticas|5|2|13|12|NS|1|0|NR|0|0|NR|NR|NR|
|Hepatotoxicidade|<br>NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|5|0|NR|  
||**Rauen et al. 2017**|**(157)**|**Rauen et al. 2**|**015(156)**||**Pozzi et a**|**l. 2013(155)**||**Stangou e**<br>**2011(15**|**t al.**<br>**8)**|**Pozzi et**|**al. 2010(154)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|Imunossupressores|Tto<br>|Corticoides ou<br>|Tto<br>||AZA+corticoide|s<br>Corticoides|<br>|AZA+Mpred|<br>Mpred|AZA+corticoide|s<br>Corticoides||
||<br>n=55|suporte<br>n=54|imunossupressores<br>n=55|suporte<br>n=54|p|n=20|n=26|p|<br>n=12|<br> <br>n=10|n=20|n=26|p|
|Leucopenia|1|0|2|3|NS|1|0|NR|0|0|3|0|NR|
|Neoplasia<br>maligna|2|0|2|0|NS|NR|NR|NR|NR|NR|NR|NR|NR|
|Diabetes mellitus|1|1|9|1|0,02|1|0|NR|NR|NR|1|2|NR|
|Sangramento<br>gastrointestinal|0|0|0|0|NS|1|0|NR|NR|NR|NR|NR|NR|
|Fratura|0|0|1|0|NS|NR|NR|NR|NR|NR|NR|NR|NR|
|Hipertensão<br>arterial|NR|NR|NR|NR|NR|1|1|NR|NR|NR|0|1|NR|
|Depressão|NR|NR|NR|NR|NR|1|0|NR|NR|NR|NR|NR|NR|
|Mialgia|NR|NR|NR|NR|NR|0|1|NR|NR|NR|NR|NR|NR|
|Fraqueza<br>muscular|NR|NR|NR|NR|NR|NR|NR|NR|7 (58,3%)|5<br>(50%)|NR|NR|NR|
|Ganho de peso<br>(≥5 kg no<br>primeiro ano)|5|2|14|5|NS|NR|NR|NR|NR|NR|NR|NR|NR|
|Ganho de peso<br>(≥5 kg durante o<br>estudo)|6|5|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Ganho de peso<br>(≥10 kg durante<br>o estudo)|3|2|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
||**Rauen et al. 201**|**7(157)**|**Rauen et al. 2**|**015(156)**|**Pozzi et a**|**l. 2013(155)**||**Stangou**<br>**2011(1**|**et al.**<br>**58)**|**Pozzi et a**|**l. 2010(154)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|Imunossupressores<br>n=55|Tto<br>suporte<br>n=54|Corticoides ou<br>imunossupressores<br>n=55|Tto<br>suporte<br>n=54|p<br>AZA+corticoide<br>n=20|s<br>Corticoides<br>n=26|p|AZA+Mpred<br>n=12|<br>Mpred<br>n=10|AZA+corticoides<br>n=20|<br>Corticoides<br>n=26|p|
|Inserção de<br>cateter peritoneal|NR|NR|NR|NR|NR<br>0|1|NR|<br>NR|NR|NR|NR|NR|
|Diálise|NR|NR|NR|NR|NR<br>9 (45%)|10 (39%)|NS|<br>NR|NR|6|4|NR|  
Tto: tratamento; AZA: azatioprina; Mpred: metilprednisolona; EA: evento adverso; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 52 - Características gerais dos estudos incluídos.** -->
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**População estudada**<br>|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Song et al.**<br>**2017(148)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em julho de 2016|Avaliar os<br>benefícios e riscos<br>do tratamento com<br>iCN comparado a<br>corticoides ou<br>placebo em<br>pacientes com<br>NIgA|7 ECRs, com total de<br>374 pacientes com<br>NIgA e proteinúria|5 ECRs: CsA ±<br>metilprednisolona ou<br>prednisolona;<br>2 ECRs: TAC ±<br>prednisolona|2 ECRs: placebo;<br>3 ECRs: prednisolona<br>2 ECRs:<br>metilprednisolona|Alto: dados do texto e<br>gráficos não condizentes;<br>avaliação do risco de viés<br>dos estudos incluídos<br>inadequada (Jadad > 2);<br>apenas dois estudos com<br>qualidade alta|
|**Peng et al.**<br>**2016(146)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em janeiro de 2016|Avaliar a eficácia e<br>segurança de iCN,<br>comparado aos<br>corticoides, para o<br>tratamento da NIgA|5 ECRs e 2 quase-<br>experimentais, com<br>total de 370<br>participantes|2 estudos: CsA +<br>prednisona<br>2 estudos: CsA +<br>metilprednisolona<br>3 estudos: TAC +<br>prednisona|Prednisona ou<br>metilprednisolona|Alto: inclusão, análise<br>conjunta de ECRs e<br>estudos não<br>randomizados, sem<br>análise de sensibilidade;<br>não realiza análise de<br>sensibilidade para avaliar<br>o impacto da qualidade<br>dos estudos; utilizou a<br>ferramenta da Cochrane<br>para avaliar viés de<br>estudo não randomizado;<br>baixa qualidade<br>metodológica dos estudos<br>incluídos|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|<br>**Risco de viés**|
|---|---|---|---|---|---|---|
|**Cruzado et**<br>**al. 2011**<br>**(151)**|ECR, aberto,<br>multicêntrico|Avaliar a eficácia e<br>segurança do SRL<br>em pacientes com<br>NIgA|Pacientes com NIgA<br>confirmada por<br>biopsia, TFGe entre<br>30 - 60<br>mL/min/1,73m2,<br>idade entre 18 - 70<br>anos, proteinúria > 1<br>g/dia|SRL 1 mg (seguido de<br>ajuste de acordo com<br>nível sérico) + enalapril<br>+ atorvastatina|enalapril + atorvastatina|Alto: Estudo piloto com<br>amostra pequena e sem<br>cálculo amostral; Não foi<br>relatado o método de<br>sigilo de alocação;<br>recrutamento<br>interrompido sem<br>critérios definidos a<br>priori.|
|iCN: inibidores<br>TFGe: taxa de|de calcineurina; NIgA<br>filtração glomerular es|: nefropatia por Imun<br>timada.|oglobulina A; ECR: en|saio clínico randomizado; C|sA: ciclosporina A; TAC: t|acrolimo; SRL: sirolimo;|

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 53 - Características dos participantes incluídos nos estudos.** -->
|**Autor, ano**|**Grupo**|**Tamanho amostral, n**|**Idade, média ±**<br>**DP**|**Sexo, n (%) feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
|**Song et al.**<br>**2017(148)**|Total|374|NR|NR|NR|NR|
|**Peng et al.**<br>**2016(146)**|Total|370|30 - 42,4|NR|NR|2 - 12 meses|
|**Cruzado et**<br>**al. 2011(151)**|SRL|14|42 ± 11|2 (14%)|**Creatinina plasmática (µmol/L):**<br>157 ± 30<br>**TFGe (mL/min/1,73m2):**<br>50 ± 11<br>**Proteína urinária ≥1 g/dia:**<br>71%|12 meses|  
|**Autor, ano**|**Grupo**|**Tamanho amostral, n**|**Idade, média ±**<br>**DP**|**Sexo, n (%) feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
||Controle|9|50 ± 9|2 (22%)|**Creatinina plasmática (µmol/L):**<br>161 ± 41<br>**TFGe (mL/min/1,73m2):**<br>49 ± 11||
||||||**Proteína urinária ≥1 g/dia:**<br>78%||  
DP: desvio padrão; SRL: sirolimo; TFGe: taxa de filtração glomerular estimada; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 54 - Desfechos reportados nos estudos incluídos.** -->
|**Autor, ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos laboratoriais e**<br>**outros**|
|---|---|---|---|---|
|**Song et al.**<br>**2017(148)**|iCN vs controle|**Remissão da proteinúria**:<br>Remissão completa:<br>RR: 2,51 (IC 95% 1,25; 5,04), p=0,010. 5 ECRs,<br>n=225, I2: 29%, p=NS<br>Remissão parcial:<br>RR: 0,87 (IC 95% 0,32; 2,38), p=NS. 5 ECRs, n=<br>244, I2: 66%, p=0,02|**Proteinúria em 24h:**<br>DMP: -0,30 (IC 95% -0,50; -<br>0,09), p=0,006. 4 ECRs,<br>n=225,I2:76%, p=0,006<br>**TFGe:**<br>DMP: 1,13 (IC 95% -4,05; 6,32),<br>p=NS. 5 ECRs, n=265, I2: 12%,<br>p=NS|**Creatinina plasmática**:<br>DMP: 0,57 (IC 95% -4,05; 5,19),<br>p=NS. 5ECRs, n=307, I2: 0%,<br>p=NS|
|**Peng et al.**<br>**2016(146)**|iCN vs corticoides|**Remissão completa:**<br>RR: 1,09 (IC 95% 0,93; 1,29), p=NS<br>**Remissão da proteinúria**:<br>Remissão completa:<br>RR: 1,56 (IC 95% 1,18; 2,07), p=0,002<br>Remissão parcial:<br>RR: 0,82 (IC 95% 0,62; 1,07), p=NS|**Proteinúria em 24h:**<br>DMP: 0,34 (IC 95% 0,13; 0,55),<br>p=0,002<br>**TFGe:**<br>DMP: -2,59 (IC 95% -9,94; 4,76),<br>p=NS|**Creatinina plasmática**:<br>DMP: -1,04 (IC 95% -4,72;<br>2,64), p=NS<br>**Albumina plasmática:**<br>DMP: 1,89 (IC 95% 0,39; 3,39),<br>p=0,01|  
|**Autor, ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos laboratoriais e**<br>**outros**|
|---|---|---|---|---|
||SRL|NR|**Proteinúria em 24h:**<br>Basal: 2,9 ± 1,8<br>6 meses: 1,8 ± 1,3<br>12 meses: 2,0 ± 0,9<br>**Hematúria, número de**<br>**episódios, n =0/1/2/3/4**<br>Basal: 0/3/3/3/5<br>6 meses: 1/3/1/3/6<br>12 meses: 1/3/3/2/5|**PAM, mmHg, média ± DP**<br>Basal: 96 ± 7<br>6 meses: 98 ± 10<br>12 meses: 96 ± 10|
|**Cruzado et al.**<br>**2011(151)**|||**Proteinúria em 24h:**<br>Basal: 3,7 ± 1,6<br>6 meses: 2,8 ± 1,1||
||||12 meses: 2,8 ± 1,4<br>p=NS (SRL vs controle)|**PAM, mmHg, média ± DP**<br>Basal: 102 ± 10|
||Controle|NR|**Hematúria, número de**<br>**episódios, n=0/1/2/3/4**<br>Basal: 0/3/1/4/1<br>6 meses: 0/1/3/0/5<br>12 meses: 0/1/1/2/5<br>p=NS (SRL vs controle)|6 meses: 101 ± 13<br>12 meses: 100 ± 13<br>p=NS (SRL vs controle)|  
iCN: inibidores de calcineurina; RR: risco relativo; IC: intervalo de confiança; ECR: ensaio clínico randomizado; DMP: diferença média ponderada; TFGe: taxa de filtração glomerular estimada; SRL: sirolimo; PAM: pressão arterial média; NS: não significativo; NR: não reportado.  
**Tabela 55 - Eventos adversos reportados nos estudos.**  
||**Song et al. 2017(148)**|**Peng et al. 2016(146)**|**Cruzado et**|**al. 2011 (151)**|
|---|---|---|---|---|
|**Evento adverso**|iCN vs controle|iCN vs corticoides|SRL<br>n=14|Controle<br>n=9|
|Infecção|OR: 0,76 (IC 95% 0,32; 1,82), p=NS. 5<br>ECRs, n=265, I2: 5%, p=NS|RR: 1,24 (IC 95% 0,63; 2,44), p=0,53. 6<br>estudos, I2: 0%, p=NS|NR|NR|
|Hiperglicemia|OR: 0,36 (IC 95% 0,14; 0,92), p=0,03. 5<br>ECRs, n=265, I2: 12%, p=NS|RR: 1,69 (IC 95% 0,87; 3,25), p=NS. 6<br>estudos, I2: 0%, p=NS|NR|NR|
|Desconforto gastrointestinal<br>ou alteração da função<br>hepática|OR: 28,89 (IC 95% 5,35; 155,96),<br>p<0,0001. 3 ECRs, n=155, I2: 3%, p=NS|NR|NR|NR|
|Disfunção hepática|NR|RR: 0,34 (IC 95% 0,07; 1,67), p=NS. 3<br>estudos, I2: 0%, p=NS|NR|NR|
|Sintomas musculoesqueléticos<br>ou neurológicos|OR: 9,80 (IC 95% 2,50; 38,36), p=0,001.<br>2 ECRs, n=65, I2: 0%, p=NS|NR|NR|NR|
|Hipertensão|OR: 1,55 (IC 95% 0,55; 4,37), p=NS. 3<br>ECRs, n=155, I2: 22%, p=NS|NR|NR|NR|
|Hirsutismo ou hiperplasia<br>gengival|OR: 11,65 (IC 95% 2,68; 50,61), p=0,001.<br>3 ECRs, n=155, I2: 25%, p=NS|NR|NR|NR|
|Redução da TFG maior que<br>25% do valor basal|OR: 4,62 (IC 95% 0,48; 44,12), p=NS. 2<br>ECRs, n=65, I2: 0%, p=NS|NR|NR|NR|
|Suspensão do tratamento|NR|NR|0|0|
|Óbito|NR|NR|0|0|
|Febre|NR|NR|0|1|
|Hipercalemia|NR|NR|1|1|
|Síndrome prostática|NR|NR|1|0|  
||**Song et al. 2017(148)**|**Peng et al. 2016(146)**|**Cruzado et**|**al. 2011 (151)**|
|---|---|---|---|---|
|**Evento adverso**|iCN vs controle|iCN vs corticoides|SRL<br>n=14|Controle<br>n=9|
|Gastrite aguda|NR|NR|1|0|
|Hipercolesterolemia|NR|NR|2|0|
|Anemia|NR|NR|1|0|
|Edema|NR|NR|2|0|
|Erupção cutânea facial|NR|NR|2|0|
|Macrohematúria|NR|NR|0|0|
|Diálise|NR|NR|0|0|
|Diabetes mellitus|NR|NR|0|0|  
iCN: inibidores de calcineurina; SRL: sirolimo; OR: _odds ratio_ ; IC: intervalo de confiança; ECR: ensaio clínico randomizado; RR: risco relativo; TFG: taxa de filtração glomerular; NS: não significativo; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 56 - Características gerais dos estudos incluídos.** -->
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Du et al.**<br>**2017(144)**|Revisão sistemática<br>com meta-análise.<br>Última atualização|Avaliar a eficácia e<br>segurança do MMF|8 estudos, com total<br>de 347 pacientes<br>com NIgA|5 ECRs: monoterapia<br>com MMF (1,5 - 2,0<br>g/dia);|4 ECRs: placebo;<br>1 ECR: prednisona;<br>2 ECRs: ciclofosfamida +|Alto: resultados de texto<br>e gráficos contraditórios;<br>utilização de|  
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||em dezembro de<br>2015|para o tratamento<br>da NIgA||3 ECRs: MMF (1,5 - 2,0<br>g/dia) + prednisona|prednisona;<br>1 ECR: leflunomida +<br>prednisona|classificação de risco de<br>viés inadequada; estudos<br>incluídos de baixa<br>qualidade metodológica;<br>análise de viés de<br>publicação inadequada<br>(menos de 10 estudos no<br>funnel plot).|
|**Liu et al.**<br>**2016(145)**|Revisão sistemática<br>com meta-análise.<br>Última atualização<br>em setembro de<br>2013|Avaliar a eficácia e<br>segurança de<br>imunossupressores<br>no tratamento de<br>pacientes chineses<br>com NIgA|29 ECRs, com total<br>de 1466 pacientes<br>chineses|6 ECRs: MMF 1 - 2 g/dia<br>vs corticoides;<br>5 ECRs: AZA 2 - 5<br>mg/kg/dia vs corticoides;<br>4 ECRs: LEF 20 mg/dia<br>vs CTX;<br>2 ECRs: CTX 0,5 - 0,75<br>g/m2 vs corticoides;<br>13 ECRs: LEF 20 - 30<br>mg/dia vs corticoides|Corticoides ou CTX|Alto (validade externa<br>baixa: apenas pacientes<br>chineses; Apenas 4<br>estudos com qualidade<br>razoável; não foi feita<br>nenhuma análise de<br>subgrupo; Uma das<br>análises utilizou modelo<br>de efeitos fixos para uma<br>heterogeneidade<br>considerável)|
|**Hou et al.**<br>**2017(152)**|ECR multicêntrico<br>(5 centros na<br>China), aberto|Avaliar a eficácia e<br>segurança do MMF<br>+ prednisona<br>comparado à<br>prednisona para<br>tratamento da NIgA<br>com lesão<br>proliferativa ativa|Pacientes com NIgA<br>confirmada por<br>biopsia, idade 18 -<br>65 anos, excreção de<br>proteína urinária ≥1<br>g/24 h em 2 medidas<br>consecutivas dentro<br>de 1 semana|MMF 0,75 g 12/12h por<br>6 meses + prednisona<br>0,4-0,6 mg/kg/dia por 2<br>meses, com redução de<br>20% da dose a cada mês<br>por 4 meses|Prednisona 0,8-1,0<br>mg/kg/dia por 2 meses,<br>com redução de 20% da<br>dose a cada mês por 4<br>meses|Baixo (desenho aberto<br>não é capaz de<br>influenciar nos<br>desfechos)|  
MMF: micofenolato de mofetila; NIgA: nefropatia por Imunoglobulina A; ECR: ensaio clínico randomizado; AZA: azatioprina; LEF: leflunomida; CTX: ciclofosfamida.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 57 - Características dos participantes incluídos nos estudos.** -->
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ±**<br>**DP**|**Sexo, n (%)**<br>**feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
||Total|347|NR|NR|NR||
|**Du et al.**<br>**2017(144)**|MMF|178|NR|NR|NR|6 - 36 meses|
||Controle|169|NR|NR|NR||
||Total|1466|NR|NR|NR|3 - 24 meses|
||AZA|292|NR|NR|NR|6 - 24 meses|
|**Liu et al.**|MMF|253|NR|NR|NR|3 - 6 meses|
|**2016(145)**|LEF vs corticoide|623|NR|NR|NR|3 meses|
||CTX|72|NR|NR|NR|12 meses|
||LEF vs CTX|226|NR|NR|NR|3 meses|
||MMF+prednisona|86|Mediana (IQR):<br>30,5 (25 - 37)|47 (55%)|**Creatinina plasmática (µmol/L):**<br>mediana: 85,4 (IQR 68,1 - 109,6)<br>**TFGe (mL/min/1,73m2):**<br>mediana: 90,2 (IQR 64,4 - 109,6)<br>**Proteína urinária (g/24h):**||
|**Hou et al.**|||||média ± DP: 2,37 ± 1,23|12|
|**2017(152)**|Prednisona|88|Mediana (IQR):<br>32,5 (25 - 43)|50 (57%)|**Creatinina plasmática (µmol/L):**<br>mediana: 80,4 (IQR 64,1 - 105,7)<br>**TFGe (mL/min/1,73m2):**<br>mediana: 94,3 (IQR 72,2 - 111,4)<br>**Proteína urinária (g/24h):**<br>média ± DP: 2,47 ± 2,01|meses|  
DP: desvio padrão; MMF: micofenolato de mofetila; AZA: azatioprina; LEF: leflunomida; CTX: ciclofosfamida; IQR: intervalo interquartil; TFGe: taxa de filtração glomerular estimada; NR: não reportado.  
**Tabela 58 - Desfechos reportados nos estudos.**  
|**Autor,**<br>**ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos**<br>**laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
||MMF ou<br>MMF+prednisona<br>vs placebo ou<br>prednisona|**Remissão completa:**<br>OR: 2,43 (IC 95% 1,48; 3,98), p=0,0004. 8<br>ECRs, I2: 49%, p=0,05|NR|NR|NR|
|**Du et al.**<br>**2017(144)**|<br>MMF vs placebo<br>ou prednisona|**Remissão completa:**<br>Caucasianos:<br>OR: 0,67 (IC 95% 0,18; 2,47), p=NS. 2 ECRs,<br>I2: 1%, p=NS<br>Asiáticos:<br>OR: 7,14 (IC 95% 2,36; 21,64), p=0,0005. 2<br>ECRs, I2: 0%, p=NS<br>Etnias mistas:<br>OR: 1,86 (IC 95% 0,39; 8,99), p=NS. 1 ECR|**Proteinúria de 24h:**<br>Caucasianos:<br>DMP: 0,58 (IC 95% 0,18;<br>0,99), p=0,005. 2 ECRs, I2:<br>0%, p=NS<br>Asiáticos:<br>DMP: -0,88 (IC 95% -1,36;<br>-0,40), p=0,0003. 2 ECRs,<br>I2: 0%, p=NS|**Duplicação da**<br>**creatinina**<br>**plasmática:**<br>Caucasianos:<br>OR: 3,32 (IC 95%<br>0,71; 15,60), p=NS. 2<br>ECRs, I2: 0%, p=NS<br>Asiáticos:<br>OR: 0,30 (IC 95%<br>0,03; 3,15), p=NS. 1<br>ECR|Caucasianos:<br>OR: 2,91 (IC 95% 0,61;<br>13,95), p=NS. 2 ECRs, I2:<br>0%, p=NS|
||MMF+prednisona<br>vs<br>CTX+prednisona|**Remissão completa:**<br>OR: 4,58 (IC 95% 1,77; 11,86), p=0,002. 2<br>ECRs, I2: 0%, p=NS|**Proteinúria de 24h:**<br>DMP: -0,72 (IC 95% -0,97;<br>-0,46), p<0,00001. 2 ECRs,<br>I2: 39%, p=NS|**Duplicação da**<br>**creatinina**<br>**plasmática:**<br>OR: 0,12 (IC 95%<br>0,04; 0,37), p=0,0002.<br>2 ECRs, I2: 0%,<br>p=NS|NR|  
|**Autor,**<br>**ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos**<br>**laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
||MMF+prednisona<br>vs<br>LEF+prednisona|**Remissão completa:**<br>OR: 0,81 (IC 95% 0,22; 2,91), p=NS. 1 ECR|**Proteinúria de 24h:**<br>DMP: -0,02 (IC 95% -0,20;<br>0,16), p=NS. 1 ECR|**Duplicação da**<br>**creatinina**<br>**plasmática:**<br>OR: 0,47 (IC 95%<br>0,04; 5,69), p=NS. 1<br>ECR|NR|
||AZA vs<br>corticoides|**Remissão da proteinúria**:<br>OR: 3,43 (IC 95% 1,92; 6,12), p<0,0001. 5<br>ECRs, n=292, I2: 5%, p=NS|NR|NR|NR|
||MMF vs<br>corticoides|**Remissão da proteinúria**:<br>OR: 2,19 (IC 95% 1,25; 3,85), p=0,006. 6 ECRs,<br>n=247, I2: 30%, p=NS|NR|NR|NR|
|**Liu et al.**<br>**2016(145)**|LET vs<br>corticoides|**Remissão da proteinúria**:<br>OR: 2,64 (IC 95% 1,80; 3,86), p<0,0001. 13<br>ECRs, n=613, I2: 24%, p=NS|NR|NR|NR|
||CTX vs<br>corticoides|**Remissão da proteinúria**:<br>OR: 0,91 (IC 95% 0,41; 1,41), p=0,0004. 2<br>ECRs, n=72, I2: 72%, p=NS|NR|NR|NR|
||LET vs CTX|**Remissão da proteinúria**:<br>OR: 2,01 (IC 95% 1,08; 3,75), p=0,03. 4 ECRs,<br>n=224, I2: 0%, p=NS|NR|NR|NR|  
|**Autor,**<br>**ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos**<br>**laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
|**Hou et al.**<br>**2017(152)**|MMF+prednisona<br>(n=86) vs<br>prednisona<br>(n=88) em 6<br>meses|**Remissão completa em 6 meses:**<br>MMF: 37% (IC 95% 27; 48)<br>Prednisona: 38% (IC 95% 27; 49)<br>p=NS<br>**Remissão completa+parcial em 6 meses:**<br>MMF: 76% (IC 95% 61; 80)<br>Prednisona: 81% (IC 95% 71; 89)<br>p=NS<br>**Tempo até remissão completa**:<br>MMF: 8,7 meses (IC 95% 6,0; 9,3)<br>Prednisona: 8,5 meses (IC 95% 4,2; 9,3)<br>p=NS|NR|**Duplicação da**<br>**creatinina**<br>**plasmática:**<br>MMF: 0<br>Prednisona: 1 (1,1%)|**Progressão para DRCT:**<br>MMF: 0<br>Prednisona: 1 (1,1%)<br>**Esclerose glomerular**<br>**global**:<br>MMF: mediana (IQR)<br>Basal: 8,7% (2,7; 35,1)<br>6 meses: 23,3 (6,7; 36,4)<br>p=0,04<br>Prednisona: mediana<br>(IQR)<br>Basal: 11,9% (5,0; 21,4)<br>6 meses: 18,0% (8,1;<br>27,8)<br>p=NS|  
|**Autor,**<br>**ano**|**Grupos**<br>**comparados**|**Desfechos clínicos primários**|**Desfechos urinários**|**Desfechos**<br>**laboratoriais**|**Progressão para DRCT**|
|---|---|---|---|---|---|
|||**Remissão completa em 12 meses:**<br>MMF: 48% (IC 95% 36; 60)<br>Prednisona: 53% (IC 95% 41; 65)<br>p=NS||||
|||**Remissão completa+parcial em 12 meses:**<br>MMF: 82% (IC 95% 72; 90)<br>Prednisona: 85% (IC 95% 74; 92)<br>p=NS||||
||MMF+prednisona<br>(n=74) vs<br>prednisona<br>(n=72) em 12<br>meses|**Remissão completa em 12 meses nos pacientes**<br>**com remissão parcial em 6 meses:**<br>MMF: 62%% (IC 95% 42; 79)<br>Prednisona: 58% (IC 95% 39; 76)<br>p=NS<br>**Remissão completa+parcial em 12 meses nos**<br>**pacientes sem resposta em 6 meses:**<br>MMF: 48% (IC 95% 28; 69)<br>Prednisona: 50% (IC 95% 29; 71)<br>p=NS|NR|**Duplicação da**<br>**creatinina**<br>**plasmática:**<br>MMF: 0<br>Prednisona: 1 (1,4%)|**Progressão para DRCT:**<br>MMF: 0<br>Prednisona: 1 (1,4%)|
|||**Taxa de relapso:**<br>MMF: 7% (IC 95% 2; 15)<br>Prednisona: 7% (IC 95% 2; 16)<br>p=NS||||  
DRCT: doença renal crônica terminal; MMF: micofenolato de mofetila; OR: _odds ratio_ ; IC: intervalo de confiança; ECR: ensaio clínico randomizado; I2: medida de heterogeneidade; DMP: diferença média ponderada; CTX: ciclofosfamida; LEF: leflunomida; AZA: azatioprina; NS: não significativo; NR: não reportado.  
**Tabela 59 - Eventos adversos reportados nos estudos.**  
|**Eventos**||**Du et**|**al. 2017(144**<br>MMF +|**)**<br>CTX +|LEF +|**Li**|**u et al. 2**|**016 (145**|**)**<br>LEF|**Hou et a**|**l. 2017 (152**|**)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**|MMF<br>n=81|Placebo<br>n=75|<br>prednisona<br>n=81|<br> <br>prednisona<br>n=60|<br>prednisona<br>n=20|<br>AZA<br>(n=143)|MMF<br>(n=108)|<br>LEF<br>(n=267)|<br> <br>vs<br>CTX|MMF+prednisona<br>n=87|<br>Prednisona<br>n=88|<br>p|
|Infecção|4 (4.9%)|0|4 (4.9%)|5 (8.3%)|0|14<br>(0.1%)|NR|NR|NR|NR|NR|NR|
|Sintomas<br>gastrointestinais|8 (9.9%)|3 (4%)|2 (2.5%)|7 (11.7%)|1 (5%)|8<br>(0.06%)|16<br>(0.15%)|<br>10<br>(0.04%)|<br>LET:<br>3<br>CTX:<br>1|NR|NR|NR|
|Enzimas<br>hepáticas<br>elevadas|0|0|1 (1.2%)|2 (3.3%)|1 (5%)|NR|NR|NR|NR|NR|NR|NR|
|Alterações<br>hematológicas|3 (3.7%)|1 (1.3%)|1 (1.2%)|3 (5%)|0|NR|NR|NR|NR|NR|NR|NR|
||||||||||LET:<br>||||
|Alopécia|0|0|0|3 (5%)|0|NR|NR|NR|5<br>CTX:<br>0|NR|NR|NR|
|Menstruação<br>irregular|0|0|0|5 (8.3%)|0|NR|NR|NR|NR|NR|NR|NR|
|Total de EA|15 (18.5%)|4 (5.3%)|8 (9.9%)|24 (40%)|2 (10%)|NR|NR|NR|NR|NR|NR|NR|
|Mielossupressão|NR|NR|NR|NR|NR|5<br>(0.03%)|NR|NR|NR|NR|NR|NR|  
|**Eventos**||**Du et**<br>|**al. 2017(144)**<br>MMF +|CTX +|LEF +|**L**<br>|**iu et al. 2**<br>|**016 (145)**<br>|<br>LEF|**Hou et**<br>|**al. 2017 (152**<br> <br>|**)**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**|MMF<br>n=81|Placebo<br>n=75|prednisona<br>n=81|prednisona<br>n=60|prednisona<br>n=20|<br>AZA<br>(n=143)|MMF<br>(n=108)|LEF<br>(n=267)|<br>vs<br>CTX|MMF+prednisona<br>n=87|<br>Prednisona<br>n=88|<br>p|
|Disfunção<br>hepática|NR|NR|NR|NR|NR|6<br>(0.04%)|4<br>(0.04%)|13<br>(0.05%)|<br>LET:<br>9<br>CTX<br>13|NR|NR|NR|
||||||||||LET:||||
|Leucopenia|NR|NR|NR|NR|NR|NR|NR|NR|0<br>CTX:<br>6|NR|NR|NR|
|Qualquer EA|NR|NR|NR|NR|NR|79<br>(0.55%)|NR|NR|NR|68 (78%)|68 (77%)|p=NS|
|EA grave|NR|NR|NR|NR|NR|NR|NR|NR|NR|5 (6%)|6 (7%)|p=NS|
|Óbito|NR|NR|NR|NR|NR|NR|NR|NR|NR|0|0|p=NS|
|Síndrome de<br>Cushing|NR|NR|NR|NR|NR|NR|NR|NR|NR|16 (18%)|42 (48%)|p<0,001|
|Diabetes<br>mellitus|NR|NR|NR|NR|NR|NR|NR|NR|NR|1 (1%)|12 (14%)|p=0,002|  
MMF: micofenolato de mofetila; CTX: ciclofosfamida; LEF: leflunomida; AZA: azatioprina; EA: evento adverso; NS: não significativo; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 60 - Características gerais dos estudos incluídos.** -->
|**Autor, ano**|**Desenho do estudo**|**Objetivo do estudo**|**População estudada**|**Detalhes da intervenção**|**Detalhes do comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||Revisão sistemática|Avaliar a eficácia e||Metilprednisolona (4<br>estudos), prednisolona|Antiplaquetários,|Alta: não reporta o uso de<br>protocolo prévio, não<br>houve descrição completa<br>dos participantes dos<br>estudos incluídos, como<br>desenho do estudo, idade,<br>sexo. Análise conjunta de|
|**Zhou et al.**<br>**2011(150)**|com meta-análise.<br>Última atualização<br>em abril de 2010|segurança de<br>corticoides no<br>tratamento da NIgA|15 estudos, com total<br>de 1542 participantes|(11 estudos, 1 deles<br>incluiu metilprednisolona<br>e prednisolona) ou<br>prednisona (1 estudos)|antihipertensivos, AINEs,<br>placebo, tto suporte ou<br>ausência de tto|ECRs e estudos não<br>randomizados, não<br>reporta heterogeneidade<br>nas meta-análises;<br>avaliação de risco de viés<br>inadequada e não<br>analisou o viés de<br>publicação (mesmo tendo<br>15 estudos incluídos).|
||TESTING study:||||||
|**Lv et al.**<br>**2017(153)**|ECR multicêntrico<br>(centros na China,<br>Austrália, Índia,<br>Canadá e Malásia),<br>duplo-cego. Estudo<br>interrompido na fase<br>de recrutamento<br>devido ao excesso<br>de eventos adversos|Avaliar eficácia e<br>segurança da<br>metilprednisolona<br>oral no tratamento<br>de NIgA|Pacientes com NIgA<br>confirmada por<br>biopsia, TFGe entre<br>20 - 120<br>mL/min/1,73m2,<br>excreção de proteína<br>urinária >1 g/dia|Metilprednisolona oral<br>0,6 - 0,8 mg/kg/dia por 2<br>meses, com redução de 8<br>mg a cada mês, com<br>período total de<br>tratamento de 6 meses|Placebo|Baixo|

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Autor, ano Desenho do estudo Objetivo do estudo População estudada Detalhes da intervenção Detalhes do comparador Risco de viés** -->
graves no grupo de

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: intervenção -->
NIgA: nefropatia por Imunoglobulina A; AINEs: anti-inflamatórios não-esteroidais; tto: tratamento; ECR: ensaio clínico randomizado; TFGe: taxa de filtração glomerular estimada.  
**Tabela 61 - Características dos participantes incluídos nos estudos.**  
|**Autor, ano**|**Grupo**|**Tamanho amostral, n**|**Idade, média ±**<br>**DP**|**Sexo, n (%) feminino**|**Desfechos bioquímicos relevantes**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|
|**Zhou et al.**<br>**2011(150)**|Total|1542|NR|NR|NR|3 - 281 meses|
||Mpred|136|38,6 ± 11,5|50 (36,8%)|**Creatinina plasmática (mg/dL):**<br>1,5 ± 0,6<br>**TFGe (mL/min/1,73m2):**<br>60,0 ± 24,8<br>**Proteína urinária (g/dia):**||
|**Lv et al.**|||||2,55 ± 2,45|mediana: 25 meses (min:|
|**2017(153)**|||||**Creatinina plasmática (mg/dL):**<br>1,6 ± 0,6|5,7 - max: 45,3|
||Placebo|126|38,6 ± 10,7|46 (36,5%)|**TFGe (mL/min/1,73m2):**<br>58,6 ± 25,2<br>**Proteína urinária (g/dia):**<br>2,23 ± 1,11||  
DP: desvio padrão; Mpred: metilprednisolona; TFGe: taxa de filtração glomerular estimada; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 62 - Desfechos reportados nos estudos.** -->
|**Autor, ano**|**Grupos**<br>**comparados**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|**Desfechos compostos**|
|---|---|---|---|---|---|
||Corticoides vs<br>qualquer tto|**Proteinúria em 24h:**<br>DM: -0,47 (IC 95% -0,64; -<br>0,31), p<0,001. 9 estudos|**Duplicação da creatinina**<br>**plasmática:**<br>RR: 0,34 (IC 95% 0,15;<br>0,77), p=0,009. 5 estudos|**Progressão para DRCT**:<br>RR: 0,46 (IC 95% 0,27;<br>0,79), p=0,004. 10 estudos|NR|
||Corticoides vs<br>antiplaquetários|**Proteinúria em 24h:**<br>DM: -0,27 (IC 95% -1,21;<br>0,67), p=NS. 1 estudo|NR|**Progressão para DRCT**:<br>RR: 1,02 (IC 95% 0,67;<br>1,56), p=NS. 1 estudo|NR|
|**Zhou et al.**<br>**2011(150)**|Corticoides vs<br>AINEs|**Proteinúria em 24h:**<br>DM: -0,41 (IC 95% -0,61; -<br>0,21), p<0,001. 4 estudos|**Duplicação da creatinina**<br>**plasmática:**<br>RR: 0,51 (IC 95% 0,21;<br>1,23), p=NS. 2 estudos|**Progressão para DRCT**:<br>RR: 0,54 (IC 95% 0,33;<br>0,88), p=0,014. 3 estudos|NR|
||Corticoides vs tto<br>suporte|**Proteinúria em 24h:**<br>DM: -0,62 (IC 95% -0,92; -<br>0,33), p<0,001. 3 estudos|**Duplicação da creatinina**<br>**plasmática:**<br>RR: 0,10 (IC 95% 0,02;<br>0,41), P=0,001. 2 estuos|**Progressão para DRCT**:<br>RR: 0,16 (IC 95% 0,07;<br>0,41), p<0,001. 5 estudos|NR|
||Corticoides vs<br>placebo ou<br>ausência de tto|**Proteinúria em 24h:**<br>DM: -0,50 (IC 95% -2,02;<br>1,02), p=NS. 1 estudo|**Duplicação da creatinina**<br>**plasmática:**<br>RR: 0,47 (IC 95% 0,05;<br>4,74), p=NS. 1 estudo|**Progressão para DRCT**:<br>RR: 0,47 (IC 95% 0,05;<br>4,74), p=NS. 1 estudo|NR|  
|**Autor, ano**|**Grupos**<br>**comparados**|**Desfechos urinários**|**Desfechos laboratoriais**|**Progressão para DRCT**|**Desfechos compostos**|
|---|---|---|---|---|---|
|**Lv et al.**<br>**2017(153)**|Mpred vs placebo|**Redução de 40% da**<br>**TFGe:**<br>Mpred: 7 (5,1%)<br>Placebo: 16 (12,7%),<br>p=0,05<br>**Redução de 50% da**<br>**TFGe:**<br>Mpred: 7 (5,1%)<br>Placebo: 11 (8,7%), p=NS|NR|**DRCT ou óbito por**<br>**insuficiência renal:**<br>Mpred: 4 (2,9%)<br>Placebo: 10 (7,9%), p=NS|**40% de redução na TFGe,**<br>**progressão para DRCT ou óbito**<br>**por insuficiência renal:**<br>Mpred: 8 (5,9%)<br>Placebo: 20 (15,9%)<br>HR: 0,37 (IC 95% 0,17; 0,85), p=0,02|  
DRCT: doença renal crônica terminal; tto: tratamento; DM: diferença média; IC: intervalo de confiança; RR: risco relativo; AINEs: anti-inflamatórios nãoesteroidais; Mpred: metilprednisolona; TFGe: taxa de filtração glomerular estimada; HR: _hazard ratio_ ; NS: não significativo; NR: não reportado.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 63 - Eventos adversos reportados nos estudos.** -->
|||**Lv et al. 2017(153)**||
|---|---|---|---|
|**Evento adverso**|Mpred<br>n=136|Placebo<br>n=126|p|
|EA grave|20|4|0,001|
|Óbito|NR|NR|NR|
|Infecção|11|0|<0,001|
|EA gastrointestinal|4|1|NS|  
|||**Lv et al. 2017(153)**||
|---|---|---|---|
|**Evento adverso**|Mpred<br>n=136|Placebo<br>n=126|p|
|Distúrbios ósseos|3|0|NS|
|Outros EAs|5|3|NS|  
EA: evento adverso; NS: não significativo; NR: não reportado.  
**<mark>PCDT – Síndrome Nefrótica Primária em Adultos</mark>**  
**Questão 14: Qual a utilidade da contagem de linfócitos B CD19 no monitoramento da eficácia do rituximabe para o tratamento da glomerulonefrite membranosa?**

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **1) Estratégia de busca** -->
Medline (via Pubmed) ((("Glomerulonephritis, Membranous"[Mesh] OR membranous nephropathy)) AND ("Rituximab"[Mesh] OR rituximab)) AND (("CD19 molecule, human" [Supplementary Concept]) OR "Antigens, CD19"[Mesh] OR CD19 lymphocyte OR CD19 B cell) Resultado: 7 referências Data da busca: 05/03/2018  
Embase  
(('cd19 b lymphocyte'/exp OR 'cd19 b lymphocyte' OR 'cd19 b cell'/exp OR 'cd19 b cell') AND [embase]/lim) AND (('rituximab'/exp OR 'rituximab') AND [embase]/lim) AND (('membranous glomerulonephritis'/exp OR 'membranous glomerulonephritis' OR 'membranous nephropathy'/exp OR 'membranous nephropathy') AND [embase]/lim) Resultado: 2 estudos Data da busca: 05/03/2018

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **2) Seleção das evidências** -->
Foram recuperadas nove referências (7 Medline e 2 Embase) por meio das estratégias de busca acima descritas. Nenhuma duplicata foi retirada. Após a leitura de títulos e resumos seis referências foram excluídas, restando três referências a serem analisadas por meio da leitura completa. Todas essas três referências foram inclusas, sendo as três séries de casos<sup>159-161</sup> . Adicionais três referências, as quais foram adquiridas por busca manual, foram incluídas, sendo um ensaio clínico randomizado<sup>162</sup> e duas séries de casos<sup>163, 164</sup> .

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **3) Descrição dos Resultados** -->
As características dos estudos incluídos estão detalhadas na Tabela 1 a seguir. A Tabela 2 exibe as características basais dos participantes de cada estudo. Os Principais desfechos de eficácia e segurança estão descritos, respectivamente, nas Tabelas 3 e 4.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 64 - Características dos estudos incluídos** -->
|Autor/ano|Desenho de<br>estudo|População e objetivo|Intervenção|Controle|Risco de viés|
|---|---|---|---|---|---|
|Dahan et al.,<br>2017(162)|ECR|Pacientes adultos com nefropatia<br>membranosa primária e síndrome<br>nefrótica após 6 meses de terapia anti<br>proteinúrica não imunossupressora<br>(TAPN). Objetivo: avaliar a eficácia<br>do rituximabe|TAPN + rituximabe<br>(375 mg/m<sup>2</sup>, i.v.<br>nos dias 1 e 8).|TAPN|Alto (não descreve métodos de<br>randomização e sigilo de alocação; não<br>utiliza corretamente definição de<br>intenção de tratar)|
|Fiorentino et<br>al.,<br>2016(163)|Série de<br>casos|Pacientes adultos com GM idiopática,<br>que já haviam recebido tratamento<br>conservador. Objetivo: Avaliar a<br>eficácia e a segurança do rituximabe|Rituximabe (375<br>mg/m2), i.v., em<br>intervalos de quatro<br>semanas|NA|Alto (Série de casos)|
|Sugiura et<br>al.,<br>2011(159)|Série de<br>casos|Pacientes adultos com<br>glomerulonefrites primárias (GNM,<br>NIgA, GNFS, GM, GNMP) em uso de<br>rituximabe. Objetivo: avaliar a<br>eficácia do rituximabe|Rituximabe (375<br>mg/m<sup>2</sup>), i.v.|NA|Alto (Série de casos)|
|Fervenza et<br>al.,<br>2010(160)|Série de<br>casos|Pacientes adultos com GM e<br>proteinúria > 5g/24 h. Objetivo:<br>avaliar o impacto do uso de<br>rituximave na redução de células B e<br>nos desfechos clínicos daGM|Rituximabe (375<br>mg/m2), i.v.|NA|Alto (Série de casos)|
|Fervenza<br>et<br>al.,<br>2008(164)|Série de casos|Pacientes adultos com GM idiopática,<br>refratários ao tratamento conservador.<br>Objetivo: avaliar a eficácia e a<br>segurança do rituximabe|rituximabe<br>1000<br>mg, i.v., em duas<br>infusões nos dias 1 e<br>15|NA|Alto (Série de casos)|
|Ruggenenti<br>et<br>al.,<br>2006(161)|Série de casos|Pacientes adultos com GM, proteinúria<br>> 3,5g/24 h e Escore tubulointersticial<br>< 7,1. Objetivo: avaliar o impacto do<br>uso de rituximabe na redução da<br>proteinúria|Rituximabe<br>(375<br>mg/m2), i.v., em<br>intervalos de quatro<br>semanas|NA|Alto (Série de casos)|  
ECR: Ensaio clínico randomizado; TAPN: Terapia anti-proteinúrica não imunossupressora; GM: Glomerulonefrite membranoproliferativa; NA: Não se aplica

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 65 - Principais características de base dos participantes dos estudos incluídos** -->
|Autor/ano|N<br>intervenção|N<br>comparador|Sexo masc.<br>Intervenção, n<br>(%)|Sexo masc.<br>comparador, n<br>(%)|Idade, média<br>(DP), anos,<br>intervenção|Idade, média<br>(DP), anos,<br>comparador|GM, n<br>(%)|Seguimento|
|---|---|---|---|---|---|---|---|---|
|Dahan et al.,<br>2017|37|38|28 (75,7)|24 (63,2)|Mediana (IQR):<br>53 (42; 63)|Mediana (IQR):<br>58,5 (43; 64)|75 (100)|6 meses*|
|Fiorentino<br>et<br>al., 2016|<br>38|NA|23 (60,5)|NA|RTX em 1ª linha:<br>56,77<br>(15,44)<br>RTX em 2ª linha:<br>55,4(19,33)|NA|38 (100)|Mediana<br>(IQR):<br>15<br>meses<br>(7,7;<br>30,2)|
|Sugiura et al.,<br>2011|24|NA|14 (58)|NA|37,8 (10,9)|NA|4 (16,7)|6 meses|
|Fervenza et<br>al.,2010|20|NA|17 (0,85)|NA|48 (13)|NA|20 (100)|24 meses|
|Fervenza et<br>al.,2008|15|NA|13 (86,7)|NA|47 (8,0)|NA|15 (100)|12 meses|
|Ruggenenti et<br>al.,2006|9|NA|4 (44,4)|NA|51,2 (13,2)|NA|9 (100)|12 meses|  
*Fase randomizada; NA: Não se aplica; DP: Desvio padrão; GM: Glomerulonefrite membranoproliferativa; IQR: Intervalo interquartil.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 66 - Principais resultados de eficácia para os estudos incluídos** -->
|Autor/ano|Grupo|Excreção de<br>proteína|Valor p|Creatinina sérica<br>(g/dL), média (DP)|Valor p|Albumina<br>sérica (g/dL),|Valor p|Contagem<br>linf. B CD19|Valor p|Resposta<br>clínica, n|
|---|---|---|---|---|---|---|---|---|---|---|
|||urina (g/dia),<br>média(DP)||||média (DP)||(%), média<br>(DP)||(%)|
|Dahan et|TAPN +|NR|NA|**µmol/L (mediana -**|NS|**Mediana**|p<0,03|**cels/µL**,|NR|13 (35,1)*|
|al., 2017|RTX|||**IQR):**<br>Basal: 98,1 (82,2;<br>122,9)|entre<br>grupos<br>p/|**(IQR):**<br>Basal: 2,2<br>(1,8; 2,5)|entre<br>grupos<br>aos 6|**mediana**<br>**(IQR):**<br>Basal: NR|||
|||||3 meses: 94,6 (78,7;<br>114,0)|qualque<br>r|3 meses: 2,7<br>(2,1; 3,1)|meses|3 meses: 11<br>(2,0; 22,0)|||
|||||6 meses: 94,6 (75,1;<br>130,8)|período|6 meses: 3,0<br>(2,6;3,4)||6 meses: 61<br>(34,0;100)|||
||TAPN|NR||**µmol/L (mediana -**<br>**IQR):**<br>Basal: 91,1 (74,3;||**Mediana**<br>**(IQR):**<br>Basal: 2,2||NR||8 (21,1)*|
|||||122,0)||(2,0; 2,6)|||||
|||||3 meses: 100,8 (81,3;<br>115,8)||3 meses: 2,3<br>(1,9; 2,7)|||||
|||||6 meses: 72,5 (52,4;||6 meses: 2,4|||||
|||||89,7)||(2,0;2,9)|||||
|Fiorentino<br>et al., 2016|Rituximab<br>e|Mediana<br>(IQR)|p<0,05<br>p/ todos|**Mediana (IQR)**<br>Basal: 1,10 (0,80;|NS para<br>todos os|Basal: 2,6<br>(0,5)|p<0,05<br>p/ todos|Basal: 10,1<br>(3,95)|p<0,05<br>p/3, 6,|RC: 15<br>(39,5)|
|||Basal: 6,2|os|1,51)|período|3 meses: 3,0|os|3 meses:|9, 12 e|RP: 14|
|||(4,3; 8,7)|períodos|3 meses: 1,10 (0,80;|s|(0,5)|período|0,61 (1,28)|24|(36,8)|
|||3 meses: 2,2|vs. basal|1,65)||6 meses: 3,2|s vs.|6 meses:|meses||
|||(0,7; 5,7)||6 meses: 1,10 (0,93;||(0,6)|basal|2,11 (301)|vs.||
|||6 meses: 1,2||2,03)||9 meses: 3,3||9 meses:|basal||
|||(0,4; 4,8)||9 meses: 1,10 (0,90;||(0,6)||3,43 (3,11)|||
|||9 meses: 1,0||2,05)||12 meses: 3,3||12 meses:|||
|||(0,3;3,9)||12 meses: 1,09 (0,87;||(0,7)||3,62(3,04)|||  
|Autor/ano|Grupo|Excreção de<br>proteína<br>urina (g/dia),<br>média(DP)|Valor p|Creatinina sérica<br>(g/dL), média (DP)|Valor p|Albumina<br>sérica (g/dL),<br>média (DP)|Valor p|Contagem<br>linf. B CD19<br>(%), média<br>(DP)|Valor p|Resposta<br>clínica, n<br>(%)|
|---|---|---|---|---|---|---|---|---|---|---|
|||12 meses:||1,83)||24 meses: 3,4||24 meses:|||
|||1,4 (0,3; 4,7)||24 meses: 1,05 (0,80;||(0,7)||3,48 (3,12)|||
|||24 meses:||1,61)||36 meses: 3,8||36 meses:|||
|||2,0 (0,2; 3,6)<br>36 meses:<br>1,0 (0,2; 1,7)||36 meses: 1,09 (0,88;<br>1,57)||(0,8)||5,92 (3,49)|||  
|Sugiura et|Rituximab|Geral|p<0,05|**Geral**|NS|**Geral**|NS|**Geral**|p < 0,05|NR|
|---|---|---|---|---|---|---|---|---|---|---|
|al., 2011|e|Basal: 3,7|p/ 3 e 6|Basal: 1,0 (0,4)||Basal: 2,9||Basal: 7,1|p/ 3 e 6||
|||(3,4)<br>3 meses: 1,3|meses<br>vs. basal|3 meses: 1,0 (0,4)<br>6 meses: 0,9 (0,4)||(0,8)<br>3 meses: 3,7||(4,4)<br>3 meses: 0,5|meses<br>vs.||
|||(2,0)||||(0,6)||(0,7)|basal||
|||6 meses: 1,3|NS|**GM**|NS|6 meses: 3,7|p < 0,05|6 meses: 1,2|||
|||(2,0)||Basal: 1,1 (0,4)||(0,7)|p/ 3 e 6|(2,2)|p < 0,05||
|||||3 meses: 1,2 (0,5)|||meses||p/ 3 e 6||
|||GM||6 meses: 1,1 (0,3)||**GM**|vs.|**GM**|meses||
|||Basal: 4,3||||Basal: 2,8|basal|Basal: 7,7|vs.||
|||(2,6)||||(0,5)||(5,6)|basal||
|||3 meses: 2,6<br>(2,7)||||3 meses: 3,3<br>(0,7)||3 meses: 0,5<br>(0,4)|||
|||6 meses: 2,9<br>(3,2)||||6 meses: 3,4<br>(0,6)||6 meses: 0,3<br>(0,3)|||  
|Autor/ano|Grupo|Excreção de<br>proteína<br>urina (g/dia),<br>média(DP)|Valor p|Creatinina sérica<br>(g/dL), média (DP)|Valor p|Albumina<br>sérica (g/dL),<br>média (DP)|Valor p|Contagem<br>linf. B CD19<br>(%), média<br>(DP)|Valor p|Resposta<br>clínica, n<br>(%)|
|---|---|---|---|---|---|---|---|---|---|---|
|Fervenza<br>et al., 2010|Rituximab<br>e|Basal: 11,85<br>(4,85)<br>3 meses:|p<0,001<br>p/ 12 e<br>24|Basal: 1,5 (0,5)<br>3 meses: 1,5 (0,6)<br>6 meses: 1,5 (0,5)|p<0,05<br>p/ 12<br>meses|Basal: 2,7<br>(0,6)<br>3 meses: 3,0|p<0,05<br>p/ todos<br>os|cels/µL<br>(DP):<br>Basal: 193,4|p<0,05<br>para<br>todos os|RC: 4 (20)<br>RP: 12<br>(60)|
|||7,34 (4,11)<br>6 meses:<br>6,63 (5,28)|meses<br>vs. basal<br>(NR|9 meses: 1,4 (0,6)<br>12 meses: 1,3 (0,4)<br>18 meses: 1,4 (0,5)|vs.<br>basal|(0,6)<br>6 meses: 3,2<br>(0,6)|tempos<br>vs.<br>basal|(104,3)<br>1 mês: 1,05<br>(1,20|tempos<br>vs.<br>basal|RL: 1 (5)<br>Relapso: 1<br>(5)|
|||9 meses:<br>4,13 (3,44)|para os<br>demais|24 meses: 1,3 (0,3)||9 meses: 3,5<br>(0,5)||6 meses:<br>51,0 (86,3)|||
|||12 meses:<br>4,22 (3,78)<br>18 meses:<br>2,74 (2,84)<br>24 meses:<br>2,03 (1,71)|períodos<br>)|||12 meses: 3,7<br>(0,4)<br>18 meses: 3,8<br>(0,5)<br>24 meses: 4,0<br>(0,5)||12 meses:<br>32,3 (43,4)<br>18 meses:<br>98,2 (81,4)|||
|Fervenza<br>et al., 2008|Rituximab<br>e|Basal: 13<br>(5,7)|p<0,05|Basal: 1,4 (0,5)<br>28 dias: 1,05 (0,5)|NS para<br>todos os|Basal: 2,3<br>(0,6)|p<0,05<br>p/ todos|**Cels./µL**<br>Basal: 308|P<0,05<br>p/ todos|Após 12<br>meses:|
|||12 meses:||3 meses: 1,5 (0,6)|período|28 dias: 2,7|os|(203)|os|RC: 2|
|||6,0 (7,3)||6 meses: 1,5 (0,8)<br>9 meses: 1,4 (0,7)|s|(0,5)<br>3 meses: 2,9|período<br>s vs.|1 mês: 5,6<br>(6,7)|período<br>s vs.|(14,3)<br>RP: 6|
|||||12 meses: 1,6 (1,0)||(0,7)<br>6 meses: 3,0<br>(0,8)<br>9 meses: 3,2<br>(0,9)<br>12 meses: 3,5<br>(0,8)|basal|3 meses: 36<br>(46)<br>6 meses: 110<br>(97)<br>9 meses: 88<br>(77)<br>12 meses:<br>103(108)|basal.|(43,0)|  
|Autor/ano|Grupo|Excreção de<br>proteína<br>urina (g/dia),<br>média(DP)|Valor p|Creatinina sérica<br>(g/dL), média (DP)|Valor p|Albumina<br>sérica (g/dL),<br>média (DP)|Valor p|Contagem<br>linf. B CD19<br>(%), média<br>(DP)|Valor p|Resposta<br>clínica, n<br>(%)|
|---|---|---|---|---|---|---|---|---|---|---|
|Ruggenent<br>i et al.,<br>2006|Rituximab<br>e|Basal: 8,9<br>(5,3)<br>1 mês: 6,5<br>(35)<br>2 meses: 5,4<br>(3,9)<br>3 meses: 4,9<br>(3,9)<br>12 meses:<br>2,0 (2,3)|p<0,05<br>para<br>todos os<br>tempos<br>vs. basal|Basal: 1,0 (0,3)<br>1 mês: 1,0 (0,2)<br>2 meses: 1,0 (0,3)<br>3 meses: 1,0 (0,2)<br>12 meses: 1,0 (0,3)|NS vs.<br>basal|Basal: 2,2<br>(0,6)<br>1 mês: 2,5<br>(0,4)<br>2 meses: 2,6<br>(0,6)<br>3 meses: 2,8<br>(0,5)<br>12 meses: 3,4<br>(0,4)|p<0,05<br>para<br>todos os<br>tempos<br>vs.<br>basal|Basal: 15,5<br>(6,4)<br>1 mês: 0,5<br>(0,8)<br>2 meses: 0,6<br>(0,5)<br>3 meses: 1,2<br>(1,2)<br>6 meses: 0,6<br>(0,5)<br>12 meses:<br>3,5(3,5)|NR|NR|  
*Resposta completa e parcial juntas; NA: não se aplica; DP: Desvio padrão; IQR: Intervalo interquartil; TAPN: Terapia anti-proteinúrica não imunossupressora; RTX: rituximabe; NR: Não relatado; RC: Remissão completa; Remissão parcial; RL: Resposta limitada.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Tabela 67 - Principais desfechos de segurança relatados pelos estudos incluídos** -->
|||||Autor/ano|||
|---|---|---|---|---|---|---|
|Evento|Dahan et al.|, 2017|Fiorentino et<br>al,2016|Sugiura et al.,<br>2011|Fervenza et al.,<br>2010|Fervenza et al.,<br>2008|
||TAPN +<br>RTX|RTX|Rituximabe|Rituximabe|Rituximabe|Rituximabe|
|Reativação viral herpes, n (%)|NR|NR|NR|NR|NR|1 (7,1)|
|Neoplasia, n (%)|NR|NR|NR|NR|NR|1 (7,1)|  
|Alopecia, n (%)|NR|NR|NR|NR|NR|2 (14,3)|
|---|---|---|---|---|---|---|
|Dor muscular, n (%)|NR|NR|NR|NR|NR|1 (7,1)|
|Dor ou coceira na garganta, n (%)|NR|NR|NR|NR|NR|3 (21,4)|
|Dispineia, n (%)|NR|NR|1 (2,6)|NR|NR|NR|
|H1N1, n (%)|NR|NR|1 (2,6)|NR|NR|NR|
|Erupção cutânea, n (%)|NR|NR|NR|1 (4,2)|NR|NR|
|Reações relacionadas à infusão,<br>|NR|NR|NR|NR|3 (15)|NR|
|n(%)|||||||
|Aintomas de resfriado, n (%)|NR|NR|NR|NR|4 (20)|NR|
|Rash cutâneo/alergia, n(%)|NR|NR|NR|NR|2 (10)|3 (21,4)|
|Gosto metálico na boca, n(%)|NR|NR|NR|NR|1 (5)|NR|
|Pneumonia, n (%)|NR|NR|NR|NR|1 (5)|1 (7,1)|
|IAM, n (%)|1 (2,7)|1 (2,6)|NR|NR|1 (5)|NR|
|Falha renal aguda, n (%)|0|2 (5,3)|NR|NR|NR|NR|
|Prostatite, n (%)|1 (2,7)|0|NR|NR|NR|NR|
|Efusão pleural, n (%)|0|1 (2,6)|NR|NR|NR|NR|
|Cancer, n (%)|0|1 (2,6)|NR|NR|NR|NR|
|Edema, n (%)|1 (2,7)|1 (2,6)|NR|NR|NR|NR|
|Dor e febre, n (%)|1 (2,7)|0|NR|NR|NR|NR|
|Diarreia, n (%)|1 (2,7)|0|NR|NR|NR|NR|
|Asma,n(%)|0|1(2,6)|NR|NR|NR|NR|  
NR: Não relatado; RTX: rituximabe; IAM: Infarto agudo do miocárdio; H1N1: Influenza H1N1.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Adultos | secao: **Referências** -->
1. J. F. Introduction to glomerular disease: clinical presentations. In: Saunders E, editor. Johnson RJ, Feehally J, Floege J, eds Comprehensive Clinical Nephrology. 5th ed. Philadelphia, PA2015. p. 182-94.  
2. Polito MG, de Moura LA, Kirsztajn GM. An overview on frequency of renal biopsy diagnosis in Brazil: clinical and pathological patterns based on 9,617 native kidney biopsies. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2010;25(2):490-6.  
3. Malafronte P, Mastroianni-Kirsztajn G, Betonico GN, Romao JE, Jr., Alves MA, Carvalho MF, et al. Paulista Registry of glomerulonephritis: 5-year data report. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2006;21(11):3098-105.  
4. Costa DM, Valente LM, Gouveia PA, Sarinho FW, Fernandes GV, Cavalcante MA, et al. Comparative analysis of primary and secondary glomerulopathies in the northeast of Brazil: data from the Pernambuco Registry of Glomerulopathies - REPEG. Jornal brasileiro de nefrologia : 'orgao oficial de Sociedades Brasileira e Latino-Americana de Nefrologia. 2017;39(1):29-35.  
5. Kodner C. Diagnosis and Management of Nephrotic Syndrome in Adults. American family physician. 2016;93(6):479-85.  
6. Wilmer WA, Rovin BH, Hebert CJ, Rao SV, Kumor K, Hebert LA. Management of glomerular proteinuria: a commentary. Journal of the American Society of Nephrology : JASN. 2003;14(12):3217-32.  
7. Floege J, Amann K. Primary glomerulonephritides. Lancet (London, England). 2016;387(10032):2036-48.  
8. Radhakrishnan J, Cattran DC. The KDIGO practice guideline on glomerulonephritis: reading between the (guide)lines&#x2014;application to the individual patient. Kidney International.82(8):840-56.  
9. Charlesworth JA, Gracey DM, Pussell BA. Adult nephrotic syndrome: non-specific strategies for treatment. Nephrology (Carlton, Vic). 2008;13(1):45-50.  
10. Veronese FV, Dode RS, Friderichs M, Thome GG, da Silva DR, Schaefer PG, et al. Cocaine/levamisole-induced systemic vasculitis with retiform purpura and pauci-immune glomerulonephritis. Brazilian journal of medical and biological research = Revista brasileira de pesquisas medicas e biologicas. 2016;49(5):e5244.  
11. Siddall EC, Radhakrishnan J. The pathophysiology of edema formation in the nephrotic syndrome. Kidney Int. 2012;82(6):635-42.  
12. Cadnapaphornchai MA, Tkachenko O, Shchekochikhin D, Schrier RW. The nephrotic syndrome: pathogenesis and treatment of edema formation and secondary complications. Pediatric nephrology (Berlin, Germany). 2014;29(7):1159-67.  
13. Ellis D. Pathophysiology, Evaluation, and Management of Edema in Childhood Nephrotic Syndrome. Frontiers in pediatrics. 2015;3:111.  
210  
14. Duffy M, Jain S, Harrell N, Kothari N, Reddi AS. Albumin and Furosemide Combination for Management of Edema in Nephrotic Syndrome: A Review of Clinical Studies. Cells. 2015;4(4):622-30.  
15. Tanaka M, Oida E, Nomura K, Nogaki F, Fukatsu A, Uemura K, et al. The Na+-excreting efficacy of indapamide in combination with furosemide in massive edema. Clinical and experimental nephrology. 2005;9(2):122-6.  
16. Kapur G, Valentini RP, Imam AA, Mattoo TK. Treatment of severe edema in children with nephrotic syndrome with diuretics alone--a prospective study. Clinical journal of the American Society of Nephrology : CJASN. 2009;4(5):907-13.  
17. Davenport A. Ultrafiltration in diuretic-resistant volume overload in nephrotic syndrome and patients with ascites due to chronic liver disease. Cardiology. 2001;96(3-4):190-5.  
18. Ronco C, Bellomo R, Ricci Z. Hemodynamic response to fluid withdrawal in overhydrated patients treated with intermittent ultrafiltration and slow continuous ultrafiltration: role of blood volume monitoring. Cardiology. 2001;96(3-4):196-201.  
19. E Koushanpour, Esmail. Renal Physiology - Principles, Structure, and Function. New York: Springer-Verlag; 1986. 53–72 p.  
20. Cruz D, Bellomo R, Kellum JA, de Cal M, Ronco C. The future of extracorporeal support. Crit Care Med. 2008;36(4 Suppl):S243-52.  
21. Hoffmann JN, Faist E. Removal of mediators by continuous hemofiltration in septic patients. World J Surg. 2001;25(5):651-9.  
22. Klahr S, Levey AS, Beck GJ, Caggiula AW, Hunsicker L, Kusek JW, et al. The effects of dietary protein restriction and blood-pressure control on the progression of chronic renal disease. Modification of Diet in Renal Disease Study Group. The New England journal of medicine. 1994;330(13):877-84.  
23. KDIGO. Clinical practice guideline for the evaluation and management of chronic kidney disease. Kidney International. 2013;3(suppl. 1).  
24. Randomised placebo-controlled trial of effect of ramipril on decline in glomerular filtration rate and risk of terminal renal failure in proteinuric, non-diabetic nephropathy. The GISEN Group (Gruppo Italiano di Studi Epidemiologici in Nefrologia). Lancet (London, England). 1997;349(9069):1857-63.  
25. Jafar TH, Schmid CH, Landa M, Giatras I, Toto R, Remuzzi G, et al. Angiotensinconverting enzyme inhibitors and progression of nondiabetic renal disease. A meta-analysis of patient-level data. Annals of internal medicine. 2001;135(2):73-87.  
26. Maranhao RC, Carvalho PO, Strunz CC, Pileggi F. Lipoprotein (a): structure, pathophysiology and clinical implications. Arq Bras Cardiol. 2014;103(1):76-84.  
27. Thomas ME, Harris KP, Ramaswamy C, Hattersley JM, Wheeler DC, Varghese Z, et al. Simvastatin therapy for hypercholesterolemic patients with nephrotic syndrome or significant proteinuria. Kidney Int. 1993;44(5):1124-9.  
28. Kong X, Yuan H, Fan J, Li Z, Wu T, Jiang L. Lipid-lowering agents for nephrotic syndrome. The Cochrane database of systematic reviews. 2013(12):Cd005425.  
211  
29. BRASIL. PORTARIA CONJUNTA Nº 8, de 30 de julho de 2019. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite. 2019.  
30. Barbour SJ, Greenwald A, Djurdjev O, Levin A, Hladunewich MA, Nachman PH, et al. Disease-specific risk of venous thromboembolic events is increased in idiopathic glomerulonephritis. Kidney Int. 2012;81(2):190-5.  
31. Lee T, Biddle AK, Lionaki S, Derebail VK, Barbour SJ, Tannous S, et al. Personalized prophylactic anticoagulation decision analysis in patients with membranous nephropathy. Kidney Int. 2014;85(6):1412-20.  
32. Wu HM, Tang JL, Cao L, Sha ZH, Li Y. Interventions for preventing infection in nephrotic syndrome. The Cochrane database of systematic reviews. 2012(4):Cd003964.  
33. Braz AS, de Andrade CA, da Mota LM, Lima CM. [Recommendations from the Brazilian Society of Rheumatology on the diagnosis and treatment of intestinal parasitic infections in patients with autoimmune rheumatic disorders]. Revista brasileira de reumatologia. 2015;55(4):368-80.  
34. Suputtamongkol Y, Premasathian N, Bhumimuang K, Waywa D, Nilganuwong S, Karuphong E, et al. Efficacy and Safety of Single and Double Doses of Ivermectin versus 7-Day High Dose Albendazole for Chronic Strongyloidiasis. PLoS Neglected Tropical Diseases. 2011;5(5).  
35. Santiago M, Leitao B. Prevention of strongyloides hyperinfection syndrome: a rheumatological point of view. European journal of internal medicine. 2009;20(8):744-8.  
36. Brasil. Ministério da Saúde. Portaria Nº 801, de 25 de abril de 2017. Aprova o Protocolo Clínico e Diretrizes Terapêuticas TGP do Distúrbio Mineral Ósseo na Doença Renal Crônica. In: Saúde Md, editor. Brasília. 2017.  
37. G MK. Glomerulopatias: Manual prático. 2ª ed. São Paulo: Editora Balieiro; 2017.  
38. Skorecki K CG, Marsden PA, Taal MW, Yu ASL. Brenner and Rector’s The Kidney. 10th ed. Elsevier, editor. Philadelphia2016.  
39. Waldman M, Crew RJ, Valeri A, Busch J, Stokes B, Markowitz G, et al. Adult minimalchange disease: clinical characteristics, treatment, and outcomes. Clinical journal of the American Society of Nephrology : CJASN. 2007;2(3):445-53.  
40. KDIGO. The 2012 KDIGO practice guideline on glomerulonephritis. Kidney International. 2012;2012 suppls.  
41. Hogan J, Radhakrishnan J. The treatment of minimal change disease in adults. Journal of the American Society of Nephrology : JASN. 2013;24(5):702-11.  
42. Vivarelli M, Massella L, Ruggiero B, Emma F. Minimal Change Disease. Clinical journal of the American Society of Nephrology : CJASN. 2017;12(2):332-45.  
43. Rydel JJ, Korbet SM, Borok RZ, Schwartz MM. Focal segmental glomerular sclerosis in adults: presentation, course, and response to treatment. American journal of kidney diseases : the official journal of the National Kidney Foundation. 1995;25(4):534-42.  
44. Cattran DC, Alexopoulos E, Heering P, Hoyer PF, Johnston A, Meyrier A, et al. Cyclosporin in idiopathic glomerular disease associated with the nephrotic syndrome : workshop recommendations. Kidney Int. 2007;72(12):1429-47.  
212  
45. Li S, Wang L, Zhang M, Zhou W, Fang W, Wang Q, et al. Clinical Predictors of Response to Prednisone Plus Cyclophosphamide in Patients with Idiopathic Membranous Nephropathy. Nephron. 2017;135(2):87-96.  
46. Mastroianni-Kirsztajn G, Hornig N, Schlumberger W. Autoantibodies in renal diseases - clinical significance and recent developments in serological detection. Frontiers in immunology. 2015;6:221.  
47. A controlled study of short-term prednisone treatment in adults with membranous nephropathy. Collaborative Study of the Adult Idiopathic Nephrotic Syndrome. The New England journal of medicine. 1979;301(24):1301-6.  
48. Cattran DC, Delmore T, Roscoe J, Cole E, Cardella C, Charron R, et al. A randomized controlled trial of prednisone in patients with idiopathic membranous nephropathy. The New England journal of medicine. 1989;320(4):210-5.  
49. Shiiki H, Saito T, Nishitani Y, Mitarai T, Yorioka N, Yoshimura A, et al. Prognosis and risk factors for idiopathic membranous nephropathy with nephrotic syndrome in Japan. Kidney Int. 2004;65(4):1400-7.  
50. Branten AJ, du Buf-Vereijken PW, Vervloet M, Wetzels JF. Mycophenolate mofetil in idiopathic membranous nephropathy: a clinical trial with comparison to a historic control group treated with cyclophosphamide. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2007;50(2):248-56.  
51. Chan TM, Lin AW, Tang SC, Qian JQ, Lam MF, Ho YW, et al. Prospective controlled study on mycophenolate mofetil and prednisolone in the treatment of membranous nephropathy with nephrotic syndrome. Nephrology (Carlton, Vic). 2007;12(6):576-81.  
52. Senthil Nayagam L, Ganguli A, Rathi M, Kohli HS, Gupta KL, Joshi K, et al. Mycophenolate mofetil or standard therapy for membranous nephropathy and focal segmental glomerulosclerosis: a pilot study. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2008;23(6):1926-30.  
53. Dussol B, Morange S, Burtey S, Indreies M, Cassuto E, Mourad G, et al. Mycophenolate mofetil monotherapy in membranous nephropathy: a 1-year randomized controlled trial. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2008;52(4):699705.  
54. Ramachandran R, Yadav AK, Kumar V, Siva Tez Pinnamaneni V, Nada R, Ghosh R, et al. Two-Year Follow-up Study of Membranous Nephropathy Treated With Tacrolimus and Corticosteroids Versus Cyclical Corticosteroids and Cyclophosphamide. Kidney International Reports. 2017;2(4):610-6.  
55. Ponticelli C, Altieri P, Scolari F, Passerini P, Roccatello D, Cesana B, et al. A randomized study comparing methylprednisolone plus chlorambucil versus methylprednisolone plus cyclophosphamide in idiopathic membranous nephropathy. Journal of the American Society of Nephrology : JASN. 1998;9(3):444-50.  
56. Ponticelli C, Zucchelli P, Passerini P, Cesana B, Locatelli F, Pasquali S, et al. A 10-year follow-up of a randomized study with methylprednisolone and chlorambucil in membranous nephropathy. Kidney Int. 1995;48(5):1600-4.  
213  
57. Ponticelli C, Zucchelli P, Imbasciati E, Cagnoli L, Pozzi C, Passerini P, et al. Controlled trial of methylprednisolone and chlorambucil in idiopathic membranous nephropathy. The New England journal of medicine. 1984;310(15):946-50.  
58. Ponticelli C, Zucchelli P, Passerini P, Cesana B. Methylprednisolone plus chlorambucil as compared with methylprednisolone alone for the treatment of idiopathic membranous nephropathy. The Italian Idiopathic Membranous Nephropathy Treatment Study Group. The New England journal of medicine. 1992;327(9):599-603.  
59. Ponticelli C, Zucchelli P, Passerini P, Cagnoli L, Cesana B, Pozzi C, et al. A randomized trial of methylprednisolone and chlorambucil in idiopathic membranous nephropathy. The New England journal of medicine. 1989;320(1):8-13.  
60. Ponticelli C, Passerini P, Altieri P, Locatelli F, Pappalettera M. Remissions and relapses in idiopathic membranous nephropathy. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 1992;7 Suppl 1:85-90.  
61. Hofstra JM, Branten AJ, Wirtz JJ, Noordzij TC, du Buf-Vereijken PW, Wetzels JF. Early versus late start of immunosuppressive therapy in idiopathic membranous nephropathy: a randomized controlled trial. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2010;25(1):129-36.  
62. Branten AJ, Reichert LJ, Koene RA, Wetzels JF. Oral cyclophosphamide versus chlorambucil in the treatment of patients with membranous nephropathy and renal insufficiency. QJM : monthly journal of the Association of Physicians. 1998;91(5):359-66.  
63. du Buf-Vereijken PW, Branten AJ, Wetzels JF. Cytotoxic therapy for membranous nephropathy and renal insufficiency: improved renal survival but high relapse rate. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2004;19(5):1142-8.  
64. Ambalavanan S, Fauvel JP, Sibley RK, Myers BD. Mechanism of the antiproteinuric effect of cyclosporine in membranous nephropathy. Journal of the American Society of Nephrology : JASN. 1996;7(2):290-8.  
65. Guasch A, Suranyi M, Newton L, Hall BM, Myers BD. Short-term responsiveness of membranous glomerulopathy to cyclosporine. American journal of kidney diseases : the official journal of the National Kidney Foundation. 1992;20(5):472-81.  
66. Cattran DC, Appel GB, Hebert LA, Hunsicker LG, Pohl MA, Hoy WE, et al. Cyclosporine in patients with steroid-resistant membranous nephropathy: a randomized trial. Kidney Int. 2001;59(4):1484-90.  
67. Alexopoulos E, Papagianni A, Tsamelashvili M, Leontsini M, Memmos D. Induction and long-term treatment with cyclosporine in membranous nephropathy with the nephrotic syndrome. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2006;21(11):3127-32.  
68. Praga M, Barrio V, Juarez GF, Luno J. Tacrolimus monotherapy in membranous nephropathy: a randomized controlled trial. Kidney Int. 2007;71(9):924-30.  
69. Li QH, Yang ZJ, Li L, Gou R, Guo YY, Yin LL, et al. Comparison of efficacy and safety between tacrolimus and cyclosporine combined with corticosteroids in patients with idiopathic  
214  
membranous nephropathy: A randomized controlled trial. International Journal of Clinical and Experimental Medicine. 2017;10(6):9764-70.  
70. Omrani H, Golmohamadi S, Hichi F, Sadeghi M. Comparison of the efficacy of tacrolimus versus cyclosporine in the treatment of idiopathic membranous nephropathy. Nephro-Urology Monthly. 2017;9(1).  
71. Donadio JV, Jr., Holley KE, Anderson CF, Taylor WF. Controlled trial of cyclophosphamide in idiopathic membranous nephropathy. Kidney Int. 1974;6(6):431-9.  
72. Murphy BF, McDonald I, Fairley KF, Kincaid-Smith PS. Randomized controlled trial of cyclophosphamide, warfarin and dipyridamole in idiopathic membranous glomerulonephritis. Clinical nephrology. 1992;37(5):229-34.  
73. Meyrier A, Noel LH, Auriche P, Callard P. Long-term renal tolerance of cyclosporin A treatment in adult idiopathic nephrotic syndrome. Collaborative Group of the Societe de Nephrologie. Kidney Int. 1994;45(5):1446-56.  
74. Waldman M, Austin HA, 3rd. Controversies in the treatment of idiopathic membranous nephropathy. Nature reviews Nephrology. 2009;5(8):469-79.  
75. Suki WN, Trimarchi H, Frommer JP. Relapsing membranous nephropathy. Response to therapy of relapses compared to that of the original disease. American journal of nephrology. 1999;19(4):474-9.  
76. Fellstrom BC, Barratt J, Cook H, Coppo R, Feehally J, de Fijter JW, et al. Targeted-release budesonide versus placebo in patients with IgA nephropathy (NEFIGAN): a double-blind, randomised, placebo-controlled phase 2b trial. Lancet (London, England). 2017;389(10084):211727.  
77. Coppo R, Peruzzi L, Amore A, Piccoli A, Cochat P, Stone R, et al. IgACE: a placebocontrolled, randomized trial of angiotensin-converting enzyme inhibitors in children and young people with IgA nephropathy and moderate proteinuria. Journal of the American Society of Nephrology : JASN. 2007;18(6):1880-8.  
78. Li PK, Leung CB, Chow KM, Cheng YL, Fung SK, Mak SK, et al. Hong Kong study using valsartan in IgA nephropathy (HKVIN): a double-blind, randomized, placebo-controlled study. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2006;47(5):751-60.  
79. Praga M, Gutierrez E, Gonzalez E, Morales E, Hernandez E. Treatment of IgA nephropathy with ACE inhibitors: a randomized and controlled trial. Journal of the American Society of Nephrology : JASN. 2003;14(6):1578-83.  
80. Sarafidis PA, Khosla N, Bakris GL. Antihypertensive therapy in the presence of proteinuria. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2007;49(1):12-26.  
81. Pozzi C, Bolasco PG, Fogazzi GB, Andrulli S, Altieri P, Ponticelli C, et al. Corticosteroids in IgA nephropathy: a randomised controlled trial. Lancet (London, England). 1999;353(9156):883-7.  
82. Manno C, Torres DD, Rossini M, Pesce F, Schena FP. Randomized controlled clinical trial of corticosteroids plus ACE-inhibitors with long-term follow-up in proteinuric IgA nephropathy. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2009;24(12):3694-701.  
215  
83. Lv J, Zhang H, Chen Y, Li G, Jiang L, Singh AK, et al. Combination therapy of prednisone and ACE inhibitor versus ACE-inhibitor therapy alone in patients with IgA nephropathy: a randomized controlled trial. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2009;53(1):26-32.  
84. Manno C, Gesualdo L, D'Altri C, Rossini M, Grandaliano G, Schena FP. Prospective randomized controlled multicenter trial on steroids plus ramipril in proteinuric IgA nephropathy. Journal of nephrology. 2001;14(4):248-52.  
85. Kim SM, Moon KC, Oh KH, Joo KW, Kim YS, Ahn C, et al. Clinicopathologic Characteristics of IgA Nephropathy with Steroid-responsive Nephrotic Syndrome. Journal of Korean Medical Science. 2009;24(Suppl 1):S44-9.  
86. Lai KN, Lai FM, Chan KW, Ho CP, Leung AC, Vallance-Owen J. An overlapping syndrome of IgA nephropathy and lipoid nephrosis. American journal of clinical pathology. 1986;86(6):716-23.  
87. Walker RG, Yu SH, Owen JE, Kincaid-Smith P. The treatment of mesangial IgA nephropathy with cyclophosphamide, dipyridamole and warfarin: a two-year prospective trial. Clinical nephrology. 1990;34(3):103-7.  
88. Woo KT, Lee GS. The treatment of mesangial IgA nephropathy with cyclophosphamide, dipyridamole and warfarin. Clinical nephrology. 1991;35(4):184.  
89. Pankhurst T, Lepenies J, Nightingale P, Howie AJ, Adu D, Harper L. Vasculitic IgA nephropathy: prognosis and outcome. Nephron Clinical practice. 2009;112(1):c16-24.  
90. Tang Z, Wu Y, Wang QW, Yu YS, Hu WX, Yao XD, et al. Idiopathic IgA nephropathy with diffuse crescent formation. American journal of nephrology. 2002;22(5-6):480-6.  
91. Tumlin JA, Lohavichan V, Hennigar R. Crescentic, proliferative IgA nephropathy: clinical and histological response to methylprednisolone and intravenous cyclophosphamide. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2003;18(7):1321-9.  
92. Yoshikawa N, Ito H, Sakai T, Takekoshi Y, Honda M, Awazu M, et al. A controlled trial of combined therapy for newly diagnosed severe childhood IgA nephropathy. The Japanese Pediatric IgA Nephropathy Treatment Study Group. Journal of the American Society of Nephrology : JASN. 1999;10(1):101-9.  
93. Maes BD, Oyen R, Claes K, Evenepoel P, Kuypers D, Vanwalleghem J, et al. Mycophenolate mofetil in IgA nephropathy: results of a 3-year prospective placebo-controlled randomized study. Kidney Int. 2004;65(5):1842-9.  
94. Harmankaya O, Ozturk Y, Basturk T, Obek A, Kilicarslan I. Efficacy of immunosuppressive therapy in IgA nephropathy presenting with isolated hematuria. International urology and nephrology. 2002;33(1):167-71. 95. Dillon JJ, Hladunewich M, Haley WE, Reich HN, Cattran DC, Fervenza FC. Rituximab therapy for Type I membranoproliferative glomerulonephritis. Clinical nephrology. 2012;77(4):290-5.  
96. Jones G, Juszczak M, Kingdon E, Harber M, Sweny P, Burns A. Treatment of idiopathic membranoproliferative glomerulonephritis with mycophenolate mofetil and steroids. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2004;19(12):3160-4.  
216  
97. Sandoval D, Poveda R, Draibe J, Perez-Oller L, Diaz M, Ballarin J, et al. Efficacy of mycophenolate treatment in adults with steroid-dependent/frequently relapsing idiopathic nephrotic syndrome. Clin Kidney J. 2017;10(5):632-8.  
98. Jha V, Ganguli A, Saha TK, Kohli HS, Sud K, Gupta KL, et al. A randomized, controlled trial of steroids and cyclophosphamide in adults with nephrotic syndrome caused by idiopathic membranous nephropathy. Journal of the American Society of Nephrology : JASN. 2007;18(6):1899-904.  
99. Ruggenenti P, Ruggiero B, Cravedi P, Vivarelli M, Massella L, Marasa M, et al. Rituximab in steroid-dependent or frequently relapsing idiopathic nephrotic syndrome. Journal of the American Society of Nephrology : JASN. 2014;25(4):850-63.  
100. Fan L, Liu Q, Liao Y, Li Z, Ji Y, Yang Z, et al. Tacrolimus is an alternative therapy option for the treatment of adult steroid-resistant nephrotic syndrome: a prospective, multicenter clinical trial. International urology and nephrology. 2013;45(2):459-68.  
101. Barros RT R-AM, Dantas M, Kirsztajn GM, Sens YA. Glomerulopatias. Patogenia, Clínica e Tratamento. Sarvier, editor. São Paulo2012.  
102. EG B. Medicamentos de A a Z. ARTMED, editor. Porto Alegre2012.  
103. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília2009.  
104. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008.  
105. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011.  
106. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The NewcastleOttawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
107. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36.  
108. Hogan MC, Reich HN, Nelson PJ, Adler SG, Cattran DC, Appel GB, et al. The relatively poor correlation between random and 24-hour urine protein excretion in patients with biopsyproven glomerular diseases. Kidney International. 2016;90(5):1080-9.  
109. Montero N, Soler MJ, Pascual MJ, Barrios C, Marquez E, Rodriguez E, et al. Correlation between the protein/creatinine ratio in spot urine and 24-hour urine protein. Nefrologia : publicacion oficial de la Sociedad Espanola Nefrologia. 2012;32(4):494-501.  
110. Sadjadi SA, Jaipaul N. Correlation of random urine protein creatinine (P-C) ratio with 24hour urine protein and P-C ratio, based on physical activity: a pilot study. Therapeutics and clinical risk management. 2010;6:351-7.  
111. Antunes VV, Veronese FJ, Morales JV. Diagnostic accuracy of the protein/creatinine ratio in urine samples to estimate 24-h proteinuria in patients with primary glomerulopathies: a longitudinal study. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2008;23(7):2242-6.  
217  
112. Morales JV WR, Wagner MB, Barros EJ. Is morning urinary protein/creatinine ratio a reliable estimator of 24-hour proteinuria in patients with glomerulonephritis and different levels of renal function? Journal of nephrology. 2004;17(5):666-72.  
113. Kristal B, Shasha M, Labin L, Cohen A. Estimation of quantitative proteinuria by using the protein-creatinine ratio in random urine samples. American journal of nephrology. 1988;8(3):198-203.  
114. Ginsberg JM, Chang BS, Matarese RA, Garella S. Use of single voided urine samples to estimate quantitative proteinuria. The New England journal of medicine. 1983;309(25):1543-6.  
115. Iwabuchi Y, Takei T, Moriyama T, Itabashi M, Nitta K. Long-term prognosis of adult patients with steroid-dependent minimal change nephrotic syndrome following rituximab treatment. Medicine (Baltimore). 2014;93(29):e300.  
116. Takei T IM, Moriyama T, Kojima C, Shiohira S, Shimizu A, Tsuruta Y, Ochi A, Amemiya N, Mochizuki T, Uchida K. Effect of single-dose rituximab on steroid-dependent minimal-change nephrotic syndrome in adults. Nephrology Dialysis Transplantation. 2012;28(5):1225-32.  
117. Brown LC JM, Schober FP, Chang EH, Falk RJ, Nachman PH, Pendergraft WF. The Evolving Role of Rituximab in Adult Minimal Change Glomerulopathy. American journal of nephrology. 2017;45(4):365-72.  
118. King C, Logan S, Smith SW, Hewins P. The efficacy of rituximab in adult frequently relapsing minimal change disease. Clin Kidney J. 2016;10(1):16-9.  
119. Guitard J, Hebral AL, Fakhouri F, Joly D, Daugas E, Rivalan J, et al. Rituximab for minimal-change nephrotic syndrome in adulthood: predictive factors for response, long-term outcomes and tolerance. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2014;29(11):2084-91.  
120. Bruchfeld A, Benedek S, Hilderman M, Medin C, Snaedal-Jonsdottir S, Korkeila M. Rituximab for minimal change disease in adults: long-term follow-up. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2014;29(4):851-6.  
121. Munyentwali H BK, Audard V, Remy P, Lang P, Mojaat R, Deschênes G, Ronco PM, Plaisier EM, Dahan KY. . Munyentwali H, Bouachi K, Audard V, Remy P, Lang P, Mojaat R, Deschênes G, Ronco PM, Plaisier EM, Dahan KY. Rituximab is an efficient and safe treatment in adults with steroid-dependent minimal change disease. Kidney international. 2013;83(3):511-6.  
122. Pesavento TE BW, Agarwal G, Hernandez RA, Hebert LA. . Mycophenolate therapy in frequently relapsing minimal change disease that has failed cyclophosphamide therapy. American Journal of Kidney Diseases. 2004;43(3):e10-1.  
123. Li H SX, Shen H, Li X, Wang H, Li H, Xu G, Chen J. . Tacrolimus versus intravenous pulse cyclophosphamide therapy in Chinese adults with steroid-resistant idiopathic minimal change nephropathy: a multicenter, open-label, nonrandomized cohort trial. Clinical therapeutics. 2012;34(5):1112-20.  
124. Li X, Li H, Chen J, He Q, Lv R, Lin W, et al. Tacrolimus as a steroid-sparing agent for adults with steroid-dependent minimal change nephrotic syndrome. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2008;23(6):1919-25.  
218  
125. Kim YC, Lee TW, Lee H, Koo HS, Oh KH, Joo KW, et al. Complete remission induced by tacrolimus and low-dose prednisolone in adult minimal change nephrotic syndrome: A pilot study. Kidney Res Clin Pract. 2012;31(2):112-7.  
126. Xu D GX, Bian R, Mei C, Xu C. . Tacrolimus improves proteinuria remission in adults with cyclosporine A‐resistant or‐dependent minimal change disease. Nephrology. 2017;22(3):2516.  
127. El-Reshaid K, Sallam HT, Hakim AA, Al-Attiyah R. Rituximab in treatment of idiopathic glomerulopathy. Saudi journal of kidney diseases and transplantation : an official publication of the Saudi Center for Organ Transplantation, Saudi Arabia. 2012;23(5):973-8.  
128. Rao IR KH, Ramachandran R, Gupta KL, Minz RW. Rituximab Is An Effective Therapy For Calcineurin Inhibitor Resistant/Dependent Or Intolerant Nephrotic Syndrome Due To Idiopathic Minimal Change Disease And Focal Segmental Glomerulosclerosis In Adults. Nephrology Dialysis Transplantation. 2016;Suppl 1:i126–i42.  
129. Fernandez-Fresnedo G, Segarra A, Gonzalez E, Alexandru S, Delgado R, Ramos N, et al. Rituximab treatment of adult patients with steroid-resistant focal segmental glomerulosclerosis. Clinical journal of the American Society of Nephrology : CJASN. 2009;4(8):1317-23.  
130. Rizzo R DSL, Catapano F, Santostefano M, Mancini E. Rituximab In Resistant Or Frequently Relapsing Focal Segmental Glomerulosclerosis In Adult Patients: Not Always A Smash Result. Nephrology Dialysis Transplantation. 2016;Suppl 1:i126–i42.  
131. Ochi A, Takei T, Nakayama K, Iwasaki C, Kamei D, Tsuruta Y, et al. Rituximab treatment for adult patients with focal segmental glomerulosclerosis. Intern Med. 2012;51(7):759-62.  
132. Dimkovic N, Jovanovic D, Kovacevic Z, Rabrenovic V, Nesic V, Savin M, et al. Mycophenolate mofetil in high-risk patients with primary glomerulonephritis: results of a 1-year prospective study. Nephron Clinical practice. 2009;111(3):c189-96.  
133. Choi MJ, Eustace JA, Gimenez LF, Atta MG, Scheel PJ, Sothinathan R, et al. Mycophenolate mofetil treatment for primary glomerular diseases. Kidney Int. 2002;61(3):1098114.  
134. Ren H SP, Li X, Pan X, Zhang W, Chen N. Tacrolimus versus cyclophosphamide in steroid-dependent or steroid-resistant focal segmental glomerulosclerosis: a randomized controlled trial. American journal of nephrology. 2013;37(1):84-90.  
135. Fan L LQ, Liao Y, Li Z, Ji Y, Yang Z, Chen J, Fu J, Zhang J, Kong Y, Fu P. Tacrolimus is an alternative therapy option for the treatment of adult steroid-resistant nephrotic syndrome: a prospective, multicenter clinical trial. International urology and nephrology. 2013;45(2):459-68.  
136. Ramachandran R KV, Rathi M, Nada R, Jha V, Gupta KL, Sakhuja V, Kohli HS. Tacrolimus therapy in adult-onset steroid-resistant nephrotic syndrome due to a focal segmental glomerulosclerosis single-center experience. Nephrology Dialysis Transplantation. 2014;29(10):1918-24.  
137. Li X LH, Ye H, Li Q, He X, Zhang X, Chen Y, Han F, He Q, Wang H, Chen J. . Tacrolimus therapy in adults with steroid-and cyclophosphamide-resistant nephrotic syndrome and normal or mildly reduced GFR. American Journal of Kidney Diseases. 2009;54(1):51-8.  
138. Reichert LJ HF, Assmann K, Koene RA, Wetzels JF. Preserving renal function in patients with membranous nephropathy: daily oral chlorambucil compared with intermittent monthly pulses of cyclophosphamide. Annals of internal medicine. 1994 121(5):328-33.  
219  
139. Wetzels JF. Cyclophosphamide plus steroids for membranous nephropathy with nephrotic syndrome: long-term outcomes. Nat Clin Pract Nephrol. 2007;3(10):534-5.  
140. Eriguchi M, Oka H, Mizobuchi T, Kamimura T, Sugawara K, Harada A. Long-term outcomes of idiopathic membranous nephropathy in Japanese patients treated with low-dose cyclophosphamide and prednisolone. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2009;24(10):3082-8.  
141. West ML, Jindal KK, Bear RA, Goldstein MB. A controlled trial of cyclophosphamide in patients with membranous glomerulonephritis. Kidney Int. 1987;32(4):579-84.  
142. Cravedi P, Sghirlanzoni MC, Marasa M, Salerno A, Remuzzi G, Ruggenenti P. Efficacy and safety of rituximab second-line therapy for membranous nephropathy: a prospective, matchedcohort study. American journal of nephrology. 2011;33(5):461-8.  
143. van den Brand J, Ruggenenti P, Chianca A, Hofstra JM, Perna A, Ruggiero B, et al. Safety of Rituximab Compared with Steroids and Cyclophosphamide for Idiopathic Membranous Nephropathy. Journal of the American Society of Nephrology : JASN. 2017;28(9):2729-37.  
144. Roccatello D, Sciascia S, Di Simone D, Solfietti L, Naretto C, Fenoglio R, et al. New insights into immune mechanisms underlying response to Rituximab in patients with membranous nephropathy: A prospective study and a review of the literature. Autoimmunity reviews. 2016;15(6):529-38.  
145. Busch M, Ruster C, Schinkothe C, Gerth J, Wolf G. Rituximab for the second- and thirdline therapy of idiopathic membranous nephropathy: a prospective single center study using a new treatment strategy. Clinical nephrology. 2013;80(2):105-13.  
146. Ruggenenti P, Chiurchiu C, Brusegan V, Abbate M, Perna A, Filippi C, et al. Rituximab in idiopathic membranous nephropathy: a one-year prospective study. Journal of the American Society of Nephrology : JASN. 2003;14(7):1851-7.  
147. Ruggenenti P, Cravedi P, Chianca A, Perna A, Ruggiero B, Gaspari F, et al. Rituximab in idiopathic membranous nephropathy. Journal of the American Society of Nephrology : JASN. 2012;23(8):1416-25.  
148. Yuan M, Zou J, Zhang X, Liu H, Teng J, Zhong Y, et al. Combination therapy with mycophenolate mofetil and prednisone in steroid-resistant idiopathic membranoproliferative glomerulonephritis. Clinical nephrology. 2010;73(5):354-9.  
149. Sahin GM, Sahin S, Kantarci G, Ergin H. Mycophenolate mofetil treatment for therapyresistant glomerulopathies. Nephrology (Carlton, Vic). 2007;12(3):285-8.  
150. Du B, Jia Y, Zhou W, Min X, Miao L, Cui W. Efficacy and safety of mycophenolate mofetil in patients with IgA nephropathy: an update meta-analysis. BMC nephrology. 2017;18(1):245.  
151. Liu Y, Xiao J, Shi X, Hao G, Chen Q, Zhou J, et al. Immunosuppressive agents versus steroids in the treatment of IgA nephropathy-induced proteinuria: A meta-analysis. Experimental and therapeutic medicine. 2016;11(1):49-56.  
152. Peng W, Tang Y, Jiang Z, Li Z, Mi X, Qin W. The effect of calcineurin inhibitors in the treatment of IgA nephropathy: A systematic review and meta-analysis (PRISMA). Medicine (Baltimore). 2016;95(35):e4731.  
220  
153. Samuels JA SG, Craig JC, Schena FP, Molony DA. Immunosuppressive treatments for immunoglobulin A nephropathy: A meta‐analysis of randomized controlled trials. Nephrology 2004;9(4):177-85.  
154. Song YH, Cai GY, Xiao YF, Wang YP, Yuan BS, Xia YY, et al. Efficacy and safety of calcineurin inhibitor treatment for IgA nephropathy: a meta-analysis. BMC nephrology. 2017;18(1):61.  
155. Tian L, Shao X, Xie Y, Wang L, Wang Q, Che X, et al. The long-term efficacy and safety of immunosuppressive therapy on the progression of IgA nephropathy: a meta-analysis of controlled clinical trials with more than 5-year follow-up. Expert opinion on pharmacotherapy. 2015;16(8):1137-47.  
156. Zhou YH, Tang LG, Guo SL, Jin ZC, Wu MJ, Zang JJ, et al. Steroids in the treatment of IgA nephropathy to the improvement of renal survival: a systematic review and meta-analysis. PloS one. 2011;6(4):e18788.  
157. Cruzado JM, Poveda R, Ibernon M, Diaz M, Fulladosa X, Carrera M, et al. Low-dose sirolimus combined with angiotensin-converting enzyme inhibitor and statin stabilizes renal function and reduces glomerular proliferation in poor prognosis IgA nephropathy. Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association. 2011;26(11):3596-602.  
158. Hou JH, Le WB, Chen N, Wang WM, Liu ZS, Liu D, et al. Mycophenolate Mofetil Combined With Prednisone Versus Full-Dose Prednisone in IgA Nephropathy With Active Proliferative Lesions: A Randomized Controlled Trial. American journal of kidney diseases : the official journal of the National Kidney Foundation. 2017;69(6):788-95.  
159. Lv J, Zhang H, Wong MG, Jardine MJ, Hladunewich M, Jha V, et al. Effect of Oral Methylprednisolone on Clinical Outcomes in Patients With IgA Nephropathy: The TESTING Randomized Clinical Trial. Jama. 2017;318(5):432-42.  
160. Pozzi C, Andrulli S, Pani A, Scaini P, Del Vecchio L, Fogazzi G, et al. Addition of azathioprine to corticosteroids does not benefit patients with IgA nephropathy. Journal of the American Society of Nephrology : JASN. 2010;21(10):1783-90.  
161. Pozzi C, Andrulli S, Pani A, Scaini P, Roccatello D, Fogazzi G, et al. IgA nephropathy with severe chronic renal failure: a randomized controlled trial of corticosteroids and azathioprine. Journal of nephrology. 2013;26(1):86-93.  
162. Rauen T, Eitner F, Fitzner C, Sommerer C, Zeier M, Otte B, et al. Intensive Supportive Care plus Immunosuppression in IgA Nephropathy. The New England journal of medicine. 2015;373(23):2225-36.  
163. Rauen T, Fitzner C, Eitner F, Sommerer C, Zeier M, Otte B, et al. Effects of Two Immunosuppressive Treatment Protocols for IgA Nephropathy. Journal of the American Society of Nephrology : JASN. 2017.  
164. Stangou M, Ekonomidou D, Giamalis P, Liakou H, Tsiantoulas A, Pantzaki A, et al. Steroids and azathioprine in the treatment of IgA nephropathy. Clinical and experimental nephrology. 2011;15(3):373-80.  
165. Sugiura H, Takei T, Itabashi M, Tsukada M, Moriyama T, Kojima C, et al. Effect of singledose rituximab on primary glomerular diseases. Nephron Clinical practice. 2011;117(2):c98-105.  
221  
166. Fervenza FC, Abraham RS, Erickson SB, Irazabal MV, Eirin A, Specks U, et al. Rituximab therapy in idiopathic membranous nephropathy: a 2-year study. Clinical journal of the American Society of Nephrology : CJASN. 2010;5(12):2188-98.  
167. Ruggenenti P, Chiurchiu C, Abbate M, Perna A, Cravedi P, Bontempelli M, et al. Rituximab for idiopathic membranous nephropathy: who can benefit? Clinical journal of the American Society of Nephrology : CJASN. 2006;1(4):738-48.  
168. Dahan K, Debiec H, Plaisier E, Cachanado M, Rousseau A, Wakselman L, et al. Rituximab for Severe Membranous Nephropathy: A 6-Month Trial with Extended Follow-Up. Journal of the American Society of Nephrology : JASN. 2017;28(1):348-58.  
169. Fiorentino M, Tondolo F, Bruno F, Infante B, Grandaliano G, Gesualdo L, et al. Treatment with rituximab in idiopathic membranous nephropathy. Clinical Kidney Journal. 2016;9(6):788-93.  
170. Fervenza FC, Cosio FG, Erickson SB, Specks U, Herzenberg AM, Dillon JJ, et al. Rituximab treatment of idiopathic membranous nephropathy. Kidney Int. 2008;73(1):117-25.  
222

---

