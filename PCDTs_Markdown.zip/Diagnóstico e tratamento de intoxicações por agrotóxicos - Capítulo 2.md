<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **PORTARIA Nº 79, DE 14 DE DEZEMBRO DE 2018**  
Torna pública a decisão de aprovar as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - capítulo 2, no âmbito do Sistema Único de Saúde - SUS.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS DO MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art.1º Fica aprovada as Diretrizes Brasileiras para tratamento de intoxicações por agrotóxicos - Capítulo 2, no âmbito do Sistema Único de Saúde - SUS.  
Art.2º Conforme determina o art. 25 do Decreto 7.646/2011, o prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art.3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: <u>http://conitec.gov.br/.</u>  
Art.4º Esta Portaria entra em vigor na data de sua publicação.  
#### MARCO ANTONIO DE ARAUJO FIREMAN  
1

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
DIRETRIZES BRASILEIRAS PARA DIAGNÓSTICO E TRATAMENTO DAS INTOXICAÇÕES POR AGROTÓXICOS - CAPÍTULO 2  
Segundo o boletim disponibilizado pelo Instituto Brasileiro do Meio Ambiente (IBAMA) referente a 2016, dentre os dez ingredientes ativos utilizados para a fabricação de agrotóxicos mais vendidos no Brasil, é possível identificar, pelo menos, um organofosforado e um carbamato 1.  
Os agrotóxicos classificados como inibidores de colinesterase, dos quais fazem parte organofosforados e carbamatos, constituem um grupo de substâncias amplamente utilizadas como inseticidas, nematicidas, larvicidas e acaricidas sistêmicos ou para controle de pragas na agropecuária, desinsetização urbana e doméstica e controle de vetores. Esses compostos também são utilizados na fabricação de armas químicas e de alguns produtos farmacológicos. Os organofosforados englobam os derivados de ácido fosfórico e seus homólogos. Os carbamatos, por sua vez, são ésteres do ácido carbâmico ou do ácido N-metil-carbâmico. Dessa forma, esse grupo inclui somente os derivados alquila ou arila, não englobando os tiocarbamatos<sup>2</sup> .  
Os inibidores de colinesterase exercem sua ação tóxica, principalmente por meio da inibição das esterases e, mais especificamente, a acetilcolinesterase. Esta, responsável pela degradação da acetilcolina, que é o mediador químico de sinapses do Sistema Nervoso Central (SNC), Sistema Nervoso Periférico (SNP) e junções neuro-musculares. Portanto, a inibição da acetilcolinesterase resulta no acúmulo desse neurotransmissor nas terminações nervosas, resultando nas manifestações tóxicas da denominada **_toxíndrome colinérgica_ ou** **_anticolinesterásica_**<sup>2,3</sup>  
As colinesterases são esterases que reagem com os compostos organofosforados, ficando firmemente e, em alguns casos, irreversivelmente fosforiladas e, portanto, inibidas. No caso dos carbamatos, se observa também uma inibição da acetilcolinesterase, mas a reativação é rápida e espontânea<sup>4,5</sup> .  
Alguns organofosforados podem levar ao desenvolvimento de uma neuropatia tardia, independente da inibição da acetilcolinesterase. Trata-se da fosforilação de uma esterase específica do tecido nervoso, denominada esterase alvo neuropática (Neuropathy Target Esterase - NTE). Após esta fosforilação, há um segundo passo, que é a transformação do alvo fosforilado numa forma envelhecida<sup>6</sup> . A reação de envelhecimento é tempo-dependente e ocorre somente com certos organofosforados dos grupos dos fosfatos, dos fosfonatos e dos fosforamidatos<sup>7</sup> .  
Embora a função bioquímica da NTE seja de uma fosfolipase/lisofosfolipase ainda não foram claramente definidas sua fisiologia e fisiopatologia. No homem está presente no tecido nervoso, no fígado, no tecido linfático, nos linfócitos e nas plaquetas<sup>7</sup> .  
**_Diagnóstico nas intoxicações agudas por inibidores de colinesterase_**  
O diagnóstico de intoxicações agudas por inibidores de colinesterase é basicamente clínico, sendo assim fundamental uma anamnese completa, que deixe clara a caracterização da exposição atual e anteriores.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Na assistência a uma pessoa intoxicada por inibidores de colinesterase, o prognóstico se mostra mais favorável quando, no atendimento inicial, é possível: identificar o agente tóxico, estimar a quantidade absorvida, determinar a via de exposição e o tempo transcorrido desde a exposição até  
2  
o atendimento. Estas informações favorecem um diagnóstico mais preciso, o qual, por sua vez, direciona as decisões terapêuticas e resulta em um melhor prognóstico<sup>8</sup> .  
#### **<mark>Ponto de Boa Prática</mark>**  
**Durante a avaliação inicial do paciente, colete o maior número de informações no menor tempo possível**<sup>8</sup> **.**  
**São Informações essenciais**<sup>9</sup> **:**  
- **_Quem?_**  
- Nome, idade, ocupação, sexo, gravidez, histórico (uso de medicamentos, doenças agudas e crônicas, uso de álcool, drogas ilícitas).  
- **_O que foi utilizado e quanto?_**  
- Agente e quantidade utilizada. Verificar a disponibilidade da embalagem e bula do produto.  
- **Qual a via de exposição?**  
- Via oral, dérmica, inalatória, e outras menos frequentes como retal, vaginal, oftálmica e endovenosa  
- **_Onde?_**  
Obter dados sobre o local de exposição. Sendo a exposição no local de trabalho, solicitar informações sobre o controle médico ocupacional do exposto e de como a empresa procede nos casos de intoxicação ocupacional.  
- **_Como?_**  
Determinar a circunstância na qual ocorreu a exposição, se essa foi acidental, ocupacional, tentativa de suicídio, agressão, ambiental (vazamentos ou deriva de pulverização durante a aplicação). E a intenção de uso do produto.  
- **Há quanto tempo?** Estabelecer o lapso temporal entre a exposição e o atendimento.  
#### **<mark>Ponto de Boa Prática</mark>**  
Colete informações junto aos acompanhantes ou familiares das vítimas de intoxicações por agrotóxicos, especialmente quando são crianças ou pacientes inconscientes<sup>9</sup> <u>.</u>  
#### **<mark>Ponto de Boa Prática</mark>**  
Ligue para o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para orientações sobre suspeita de intoxicações com manifestações clínicas atípicas,  quadros iniciais de difícil identificação ou caso haja qualquer dúvida em relação à intoxicação<sup>9,10</sup> .  
No site: <u>http://portal.anvisa.gov.br/disqueintoxicacao estão disponíveis os números de contato</u> dos diferentes centros de informação e assistência toxicológica da Rede Nacional de Centros de Informação e Assistência Toxicológica (Renaciat). O número gratuito do serviço Disqueintoxicação é **0800 722 6001.**  
No site http://abracit.org.br/wp/centros/ estão disponíveis os contatos dos centros de intoxicação da Associação Brasileira de Centros de Informação e Assistência Toxicológica (Abracit).  
Consulte também a Ficha de Informações de Segurança do Produto Químico (FISPQ), o rótulo e a bula do produto para mais informações<sup>8</sup> <u>.</u>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
As manifestações clínicas observadas nas intoxicações com inibidores da colinesterase dependem do mecanismo e da intensidade com a qual os diversos receptores colinérgicos, presentes em diferentes órgãos e tecidos, são estimulados. Esses receptores são classificados em muscarínicos e nicotínicos. Os primeiros, de uma forma geral, fazem parte da inervação parassimpática de diversos órgãos e tecidos, sendo também encontrados no sistema nervoso central (SNC) e em  
3  
glândulas exócrinas parassimpáticas. Por outro lado, receptores nicotínicos estão localizados na medula adrenal, na junção mioneural e em neurônios pós-ganglionares de cadeias parassimpáticas e simpáticas<sup>2</sup> .  
Os primeiros sinais e sintomas da intoxicação por inibidores de colinesterase podem surgir nos primeiros minutos ou até duas horas após a exposição. Os efeitos nicotínicos resultam em fraqueza muscular, paralisia e predispõem a insuficiência respiratória. Por outro lado, a atividade parassimpática muscarínica aumentada ocasiona um aumento das secreções glandulares e brônquicas, bem como bradicardia e broncoespasmos. Outros tipos de receptores têm sido também relacionados com manifestações no SNC<sup>2,11</sup> .  
A intoxicação progride estabelecendo um quadro de Síndrome Colinérgica Aguda, cujas manifestações podem ser do tipo muscarínicas, nicotínicas ou neurológicas, de acordo com os receptores colinérgicos correspondentes. A aparição e intensidade dos sintomas depende de vários fatores como princípio ativo, formulação comercial, quantidade e duração da exposição, normalmente, as secreções abundantes decorrentes da hiperestimulação muscarínica são características, entretanto nos quadros mais graves, os sintomas nicotínicos são os primeiros a aparecer<sup>2</sup> .  
A via de exposição também pode influenciarno espectro das manifestações clínicas. As vias de absorção mais frequentes dos inibidores de colinesterase, dependendo da circunstância da exposição da população exposta, incluem a oral, inalatória e dérmica.<sup>12</sup> .  
#### **Ponto de Boa Prática**  
Faça rapidamente o exame inicial do paciente, sem comprometer ou atrasar a sua estabilização.  
Atente para a presença de odores aliáceos (semelhantes a alho e cebola), característicos das intoxicações por organofosforados<sup>12</sup> .  
Observe também a presença de odores característicos de solventes químicos na boca, na pele e na roupa do paciente<sup>12</sup> .  
#### **Ponto de boa prática**  
Considere os seguintes critérios para definir a presença da **toxíndrome colinérgica** : miose, sudorese excessiva, hipoventilação pulmonar secundária à broncorreia e broncoespasmo, bradicardia e hipotensão<sup>13</sup> .  
#### **Ponto de boa prática**  
**Identifique as principais manifestações da intoxicação aguda por inibidores de colinesterase**<sup>2,4,8,14</sup> **:**  
**Manifestações muscarínicas** : bradicardia, hipotensão, miose, visão turva, sialorreia, lacrimejamento, rinorreia, broncorreia, broncoespasmos, vômito e diarreia, incontinência urinária, dispneia, dor abdominal, fadiga respiratória, disúria.  
**Manifestações nicotínicas** : midríase, taquicardia, hipertensão, fasciculações musculares, cãibras, fraqueza, espasmos, paralisia, vasoconstrição periférica.  
Considere a possibilidade dos sintomas nicotínicos e muscarínicos se apresentarem simultaneamente o que pode dificultar o diagnóstico da intoxicação por inibidores de colinesterase.  
4  
**Manifestações Sistema Nervoso Central:** cefaleia, tonturas, desconforto, agitação, ansiedade, tremores. Podem ser seguidos de ataxia, dificuldade para se sentar ou ficar em pé, vertigem, confusão mental, torpor e coma. Também, hipotermia e depressão do centro respiratório.  
**Manifestações tardias (meses depois de exposição aguda a níveis elevados de organofosforados ou exposições repetidas)** : cefaleia persistente, perda da memória, desorientação, confusão, fadiga, letargia, ansiedade, mudanças de humor, labilidade emocional, a irritabilidade, depressão, fadiga e sonolência. Tais manifestações podem estar associadas ao Trantorno Neuropsiquiátrico Crônico Induzido por Intoxicações Agudas por Organofosforados ( _Chronic organophosphate induced neuropsychiatric_ – COPIND)<sup>15–17</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Dependendo das características e propriedades do agente, são observadas três fases nas intoxicações por alguns organofosforados: a da síndrome colinérgica aguda, a da síndrome intermediária e a da neuropatia tardia<sup>5,18,19</sup> .  
Entretanto, é preciso considerar que em alguns casos há uma possibilidade de superposição de sinais e sintomas<sup>19</sup> .  
Alguns autores mencionam ainda uma quarta fase denominada “Transtorno Neuropsiquiátrico Crônico Induzido por Intoxicações Agudas por Organofosforados”<sup>15–17,20</sup> .  
#### **Ponto de boa prática**  
Considere o possivel desenvolvimento da síndrome intermediária, da neuropatia tardia e do transtorno neuropsiquiátrico crônico induzido por organofosforados após intoxicações agudas por organofosforados<sup>5,7,8,15,17,18,21</sup> .  
#### **Síndrome intermediária**<sup>2,8,13,18,22–26</sup>  
A síndrome intermediária é considerada como uma complicação comum (7,75-84 %), principalmente observada em pacientes expostos a organofosforados altamente lipofílicos*. Acredita-se que suas manifestações sejam puramente nicotínicas, sendo observada fraqueza muscular difusa, a qual afeta principalmente músculos respiratórios e músculos proximais de membros, podendo evoluir rapidamente para uma falência respiratória e óbito.  
Em pacientes intoxicados com organofosforados ela se manifesta entre 24 e 96 horas após a recuperação do quadro muscarínico. A debilidade e a paralisia comumente melhoram em um período de 4 a 20 dias, sem deixar sequelas. Em geral, os sintomas regridem espontaneamente e desaparecem completamente nos dias subsequentes.  
O seu tratamento é fundamentado no suporte vital, atentando para o monitoramento da função respiratória e do equilíbrio hidroeletrolítico.  É preciso realizar uma abordagem multiprofissional considerando a possibilidade de complicações resultantes do longo período de restrição no leito e de intubação prolongada<sup>6</sup>  
*Alguns exemplos de organofosforados altamente lipofílicos: fention, dimetoato, monocrotofos, metamidofos, diazinon, triclorfon, malation, sumition e metil paration  
5  
**(Poli) Neuropatia tardia induzida por organofosforados**<sup>3,15,19</sup> .  
Considere o diagnóstico em pacientes com história de intoxicação aguda ou crônica por inibidores de colinesterase que evoluam entre 6-21 dias, podendo variar até 5 semanas, com dormência distal e parestesias, seguida de fraqueza progressiva e diminuição dos reflexos tendinosos e posteriormente com ataxia, flacidez muscular distal que, em casos graves, também acomete membros superiores (tetraplegia). O quadro patológico é típico de uma axonopatia distal com degeneração nervosa proximal.  
O quadro tem início, após uma exposição aguda, por qualquer via, a determinados organofosforados<sup>**</sup> . A neuropatia tardia pode também ser observada em alguns casos de intoxicações crônicas, após, pelo menos, um episódio de intoxicação aguda.  
Observe que com o tempo, pode haver uma recuperação significativa da função periférica. Contudo, dependendo do grau de envolvimento piramidal, a ataxia pode ser um desfecho permanente nos casos graves. Assim, ainda que cessada a exposição, raramente há uma recuperação completa da função. A recuperação pode ser lenta (semanas a meses) e incompleta.  
** Exemplo de inibidores relacionados com neuropatia tardia induzida por organofosforados: clorofos, clorpirifos, diclorvos, dipterex, fosfonotioato, fention, isofenfos, leptofos, malation, mecarbam, merfos, metamidofos, mipafox, triclorofon, tricloronato, tri-orto-cresil fosfato/ TOCP) e alguns carbamatos (carbaril, carbofuran e m-toluil metil carbamatos.  
#### **Transtorno neuropsiquiátrico crônico**<sup>15,17,18</sup>  
Considere esse transtorno em pacientes que, meses depois da intoxicação aguda com doses elevadas de organofosforados ou por exposições repetidas a esses compostos, manifestem cefaleia persistente, perda da memória, confusão, fadiga, letargia, ansiedade, labilidade emocional, irritabilidade e depressão.  
#### **Recomendação**  
Considere maior possibilidade de desenvolvimento da síndrome intermediária, caso o paciente intoxicado com inibidores da colinesterase apresente algumas das seguintes características:  
- Intoxicação por dimetil organofosforados; ou  
- Paciente com idade acima de 45 anos;  
- Fraqueza muscular do pescoço como característica inicial; ou  
- Avaliação na escala de Glasgow ≤ 10; ou  
- Escore obtido na escala do Programa Internacional para a Classificação de Gravidade de Intoxicação e Segurança Química (IPCS PSS) > 2  
Avaliação de gravidade  
#### **Ponto de boa prática**  
Considere uma intoxicação moderada ou grave nos seguintes casos<sup>28–30</sup> :  
- Sinais de distúrbios do sistema nervoso central, incluindo alterações no estado de alerta (em especial uma pontuação na escala Glasgow ≤ 13);  
- Sinais de alterações na função respiratória (movimentos respiratórios; ruídos respiratórios; alterações na oximetria de pulso, gasometria e na capacidade vital forçada ou o volume expiratório forçado em um segundo, na espirometria);  
6  
- Fasciculações ou debilidade muscular;  
- Frequência cardíaca menor de 60 bpm ou maior que 100 bpm;  
- Hipotensão arterial;  
- Exposição intencional ao agrotóxico (tentativas de suicídio).  
Dentro dos sintomas observados alguns podem ser associados à gravidade da intoxicação, considerando:  
**Sintomas leves** : cefaleia, sialorreia, enjoo, náusea, miose, broncoespasmo leve, tosse, fraqueza, dor abdominal e vômitos.  
**Sintomas moderados** : tremor, fasciculações, bradicardia, taquicardia, dispneia, bradipneia, hipoxemia, confusão, ansiedade, broncorreia e extrassístoles.  
Considere o uso de escalas de avaliação de gravidade como IPSC PSS, Peradeniya e Apache. Ver anexos 2A, 2B, 2C.  
A avaliação da gravidade da intoxicação é fundamental para a determinação das condutas terapêuticas a serem estabelecidas.  
Recomendação forte a favor da intervenção (Anexo II.6)  
#### **Evidências**  
Em estudo realizado com 176 pacientes, dos quais 31 desenvolveram a síndrome intermediária, foi observado que a maioria apresentou fraqueza muscular no pescoço como característica inicial, sendo que esse mesmo grupo evoluiu para insuficiência respiratória (20/26). Idade acima de 45 anos (Risco Relativo -RR 2,23; Intervalo de Confiança -IC 95% 1,14 - 4,38) e intoxicação por dimetil organofosforados (RR 4,87; IC 95% 1,82 - 13,04) foram fatores associados ao desenvolvimento da síndrome intermediária. O escore obtido na escala de intoxicação IPCS PSS e na escala de Glasgow são preditores de agravamento e mortalidade. A mortalidade, no geral, foi de 28,4% (n= 50/176); sendo que 40% (n =20/50) ocorreu entre pacientes que desenvolveram a síndrome intermediária e insuficiência respiratória<sup>27</sup> .  
Nível de evidência: Moderado (idade ≥45 anos e intoxicação por dimetil organofosforados) e Baixo (IPCS PSS, GCS≤10 e fraqueza muscular) – Anexo II.5

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Ponto de boa prática**  
Considere uma intoxicação moderada ou grave nos seguintes casos<sup>28–30</sup> :  
- Sinais de distúrbios do sistema nervoso central, incluindo alterações no estado de alerta (em especial uma pontuação na escala Glasgow ≤ 13);  
- Sinais de alterações na função respiratória (movimentos respiratórios; ruídos respiratórios; alterações na oximetria de pulso, gasometria e na capacidade vital forçada ou o volume expiratório forçado em um segundo, na espirometria);  
- Fasciculações ou debilidade muscular;  
- Frequência cardíaca menor de 60 bpm ou maior que 100 bpm;  
- Hipotensão arterial;  
- Exposição intencional ao agrotóxico (tentativas de suicídio).  
7  
Dentro dos sintomas observados alguns podem ser associados à gravidade da intoxicação, considerando:  
**Sintomas leves** : cefaleia, sialorreia, enjoo, náusea, miose, broncoespasmo leve, tosse, fraqueza, dor abdominal e vômitos. **Sintomas moderados** : tremor, fasciculações, bradicardia, taquicardia, dispneia, bradipneia, hipoxemia, confusão, ansiedade, broncorreia e extrassístoles.  
Considere o uso de escalas de avaliação de gravidade como IPSC PSS, Peradeniya e Apache. Ver anexos 2A, 2B, 2C.  
A avaliação da gravidade da intoxicação é fundamental para a determinação das condutas terapêuticas a serem estabelecidas.  
#### **Ponto de boa prática**  
Não se basear somente na intensidade da miose eoutras manifestações colinérgicas como salivação, a diaforese, a polaciúria e o lacrimejamento para a avaliação da gravidade da intoxicação, pois essas não guardam relação com o prognóstico<sup>3</sup> .  
A escala de Peradeniya consiste em uma escala clínica para avaliar a gravidade das intoxicações por organofosforados. Ela contempla cinco manifestações clínicas comuns observadas em pacientes intoxicados por esses compostos (Erro! Fonte de referência não encontrada. **2B** ). Ao final da avaliação, o grau de intoxicação é definido como leve (pontuação 0-3), moderado (pontuação 4-7) ou grave (pontuação 8-11). A sua aplicação é recomendada no momento da avaliação inicial do paciente, pois os escores obtidos na admissão são preditores da sua evolução clínica<sup>23,31,32</sup> .  
#### **Recomendação**  
Na admissão de pacientes com suspeita de exposição a organofosforados, utilize a Escala de Peradeniya (EP) para categorizar a gravidade da intoxicação.  
Recomendação forte a favor da intervenção (Anexo II.6).  
#### **Evidências**  
A Escala de Peradeniya (EP) foi aplicada em 50 pacientes intoxicados por organofosforados, admitidos em uma unidade de saúde, sendo 66% desses do sexo masculino ~~,~~ a maioria com idade inferior a 39 anos. Os desfechos avaliados pelo estudo foram morbidade e mortalidade. Na admissão, os pacientes foram classificados de acordo com a EP como apresentando uma intoxicação leve (50%), moderada (44%) e grave (6%). Nos pacientes graves foi observada uma incidência significativamente maior de insuficiência respiratória (100%), um maior tempo de internação na Unidade de Terapia Intensiva e maior percentual de óbito do que nos demais grupos. Esses mesmos desfechos foram gradualmente menores nos demais grupos<sup>31</sup> _._  
Nível de evidência: Baixa (tempo de permanência na UTI); Alta (mortalidade) e Muito Baixa (IR) - Anexo II.5  
Há estudos que apontam o percentual de gordura corpórea, indicado pelo Índice de Massa Corporal (IMC), como um fator que aumenta a susceptibilidade de complicações diversas observadas em vítimas de intoxicações por organofosforados<sup>33</sup> .  
8  
Apesar de os mecanismos cardiotóxicos dos inibidores de colinesterase não estarem totalmente esclarecidos, presume-se que as alterações cardíacas decorrentes da intoxicação aguda por esses compostos sejam consequência de distúrbios eletrolíticos que interferem nas atividades simpáticas e parassimpáticas no músculo cardíaco<sup>34</sup> .  A detecção precoce dessas alterações é útil para o manejo adequado de outras complicações. Assim, uma abordagem inicial na qual se faz possível o monitoramento cardíaco do paciente contribui para um melhor prognóstico para as vítimas das intoxicações agudas por inibidores da colinesterase<sup>32</sup> .  
#### **Recomendação**  
Para uma estimativa de prognóstico de pacientes adultos intoxicados por organofosforados, admitidos na unidade de terapia intensiva, determine o escore APACHE II (anexo 2C).  
Recomendação forte a favor da intervenção (Anexo II.6)  
Numa análise multivariada de regressão logística, os níveis de bicarbonato sérico e o escore do paciente na escala de APACHE II foram fatores importantes para a determinação do prognóstico de pacientes vítimas de intoxicação por inibidores de colinesterase. A idade média dos pacientes incluídos foi de 56 anos (faixa, 16-88), sendo o grupo constituído por 57 (62%) homens e 35 (38%) mulheres. Na comparação entre as características clínicas do grupo sobrevivente (n = 81, 88%) e do não sobrevivente (n = 11, 12%), não foram observadas diferenças nos parâmetros relacionados com a função renal, enzimas pancreáticas ou nível sérico de acetilcolinesterase eritrocitária (AChE) e o escore de APACHE II. Os níveis de bicarbonato sérico foram menores nos não sobreviventes do que nos sobreviventes (12,45 ± 2,84 vs. 18,36 ± 4,73, P <0,01). O escore de APACHE II foi maior nos não sobreviventes do que nos sobreviventes (24,36 ± 5,22 vs. 12,07 ± 6,67, P <0,01). O desenvolvimento de pneumonia durante a hospitalização foi maior nos não sobreviventes do que nos sobreviventes (n = 9, 82% vs. n = 31, 38%, P <0,01). Na análise de regressão logística múltipla, a concentração sérica de bicarbonato, o escore APACHE II e a pneumonia durante a hospitalização foram fatores prognósticos importantes em pacientes vítimas de intoxicação por inibidores da colinesterase (Sun et al, 2015).  
Nível de evidência: Moderado - Anexo II.5  
#### **Ponto de boa prática**  
Os pacientes intoxicados graves atendidos em unidades que não contam com pessoal suficientemente treinado em suporte vital avançado ou quando não constam na unidade de saúde os antídotos preconizados para os casos de intoxicação por inibidores de colinesterase, devem ser transferidos rapidamente para o hospital mais próximo.  
Para avaliação de gravidade nas unidades de terapia intensiva, as evidencias apresentadas se restringem à escala mencionada. Não significa que as que são utilizadas rotineiramente nessas unidades não sejam validas para acompanhamento de pacientes graves.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
As particularidades intrínsecas do agente influenciam nos efeitos biológicos observados, considerando que  diferentes organofosforados podem alterar a atividade enzimática da colinesterase eritrocitária (AChE) e da colinesterase plasmática (BChE) de diversas formas e intensidade<sup>35</sup> . Há ainda os que inibem preferencialmente a BChE em detrimento da AChE, havendo também indícios que a inibição da AChE é mais sensível do que a da BChE, mesmo nos casos de exposições crônicas<sup>2,36,37</sup> .  
9  
Apesar da possibilidade de correlacionar o grau de inibição enzimática da BChE com a intensidade e duração da exposição a determinados compostos, ela não reflete alguns efeitos observados, por exemplo, no sistema nervoso. Razão essa pela qual, a determinação da AChE tem se mostrado útil para algumas avaliações prognósticas podendo até mesmo auxiliar no estabelecimento de possíveis implicações legais, como as que se relacionam a exposições ocupacionais, mesmo sabendo que outras condições ou comorbidades podem contribuir para alterações nas propriedades cinéticas da AChE<sup>2,37–39</sup> .  
#### **Ponto de Boa Prática**  
Devido a reversibilidade da ligação entre as colinesterases com carbamatos, observada também _in vitro_ , a análise da amostra deve ser realizada logo após a coleta, para evitar um resultado falso negativo. Além disso, na impossibilidade de saber se o agrotóxico envolvido na intoxicação é organofosforado ou carbamato, a avaliação da AChE a cada 2h, durante as 12 - 24 h iniciais, permite confirmar a classe do agente envolvido<sup>40</sup>  
É possível que alguns serviços de emergência não disponibilizem testes laboratoriais para a determinação da atividade enzimática da AChE. De fato, essa não é considerada essencial para o diagnóstico e atendimento inicial de vítimas de intoxicação por inibidores de colinesterase. A experiência clínica do profissional é fundamental para o reconhecimento das intoxicações por esses compostos.  
#### **Ponto de boa prática**  
#### **Priorize a avaliação clinica do paciente para realizar o diagnóstico**  
A solicitação da atividade da colinesterase eritrocitária (AChE) e da colinesterase plasmática (BChE) é indicada para:  
- Auxiliar no diagnóstico das intoxicações;  
- Auxiliar na análise da evolução do paciente intoxicado;  
- Realizar o monitoramento da exposição a inibidores da colinesterase em trabalhadores agrícolas ou aqueles que lidam rotineiramente com a venda/dispensação desses compostos, principalmente nos municípios que apresentam um maior risco de exposição a organofosforados e carbamatos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Os testes laboratoriais, apesar de não serem imprescindíveis para a elaboração do diagnóstico de intoxicações por inibidores de colinesterase, podem ser valiosos para o acompanhamento da evolução do paciente intoxicado por esses agentes.  
#### **Ponto de boa prática**  
Considere realizar os seguintes exames de acordo com a avaliação clínica e a experiência do profissional responsável pelo atendimento inicial de pacientes intoxicados por inibidores da colinesterase,<sup>23,34,41–44</sup> :  
- Hemograma;  
10  
- Ionograma (eletrólitos);  
- Gasometria (atentando para alterações de HCO3);  
- Glicemia;  
- Marcadores de função hepática;  
- Marcadores de função cardíaca*;  
- Lipidograma  
- Amilase sérica  
- Fatores de coagulação;  
Outros exames:  
- Eletrocardiograma*;  
- Raio X do tórax.  
*Complicações cardíacas, quando ocorrem, são observadas nas primeiras horas após a exposição, devendo ser considerados alguns fatores predisponentes, tais como: hipoxemia, acidose e distúrbios eletrolíticos<sup>34</sup> .  
Estudos também apontam para a alteração de algumas enzimas séricas, como é o caso da amilase sérica,  e outros parâmetros bioquímicos como indicadores de nefrotoxicidade<sup>42</sup> e preditores da necessidade de transferência do paciente para uma unidade de terapia intensiva e de ventilação assistida<sup>23</sup> .  
**_Tratamento inicial para o paciente intoxicado com inibidores da colinesterase_**  
O tratamento das intoxicações agudas por inibidores da colinesterase é definido de acordo com a gravidade do quadro apresentado pelo paciente dando sempre prioridade ao suporte vital.  
Nos casos de intoxicações mais leves, recomenda-se a descontaminação, a administração de atropina e evitar exposições adicionais. Para intoxicações graves, além da necessidade de descontaminação, estabilização do paciente e tratamento com antídotos, outras abordagens podem ser necessárias, conforme descrito neste Capítulo.  
Além disso, para todos os casos, é fundamental que se faça o seguimento, considerando as perspectivas da atenção integral e da vigilância a saúde, principalmente nos casos de exposição ocupacional ou relacionada a uma circunstância de violência auto-praticada (tentativa de suicídio).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
**Os fluxogramas de atendimento e de procedimentos utilizados na abordagem inicial para o atendimento nos casos de suspeita de intoxicação por agrotóxicos encontram-se** **<u>apresentados nos anexos 2D e 2E.</u>**  
#### **Ponto de boa prática**  
Realize suporte vital, considerando as avaliações primária e secundária, o ABCD de reanimação, bem como estratégias de descontaminação, eliminação, controle das convulsões - que porventura ocorram - e o uso de antídotos, quando indicado<sup>45</sup> .  
**Ponto de boa prática**  
11  
Dentro do suporte básico e concomitantemente ao tratamento específico, o monitoramento rigoroso do equilíbrio de fluidos e eletrólitos nos pacientes com intoxicação por inibidores da colinesterase é fundamental. Deve ser considerada a administração de fluidos intravenosos no intuito de estabelecer o equilíbrio hidroeletrolítico e a reposição das perdas por diaforese, psialorreia, broncorreia, polaciúria e diarreia, que costumam ser profusas nesses pacientes 24,46.  
Agentes vasoativos também podem ser utilizados, considerando a possibilidade de outros fatores também contribuírem para o desenvolvimento de um quadro hipotensivo<sup>47</sup> .  
Desde o início do atendimento do paciente no serviço de emergência devem ser instalados dois acessos intravenosos: um para a reposição de líquidos e administração de medicamentos, e outro **exclusivamente** para a infusão de atropina<sup>13</sup> .  
#### **Ponto de boa prática**  
Consulte o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para esclarecimentos sobre o tratamento inicial e orientações acerca das especificidades no tratamento subsequente, considerando o agente tóxico relacionado.  
Disque-intoxicação: 0800 722 6001  
#### **Ponto de boa prática**  
Considere a possibilidade de intoxicação por diferentes produtos e associações de agrotóxicos formulados com diversos princípios ativos, ingredientes e solventes, os quais podem alterar o quadro clínico e comprometer a efetividade do tratamento de escolha.  
#### **Ponto de boa prática**  
A avaliação e o atendimento inicial do paciente intoxicado com inibidores de colinesterase pela equipe de saúde deve ser feita utilizando equipamentos de proteção individual (EPI), materiais biológicos e físicos (contaminados) devem ser descartados conforme normas de biosegurança.  
#### **Ponto de boa prática**  
Todos os pacientes com intoxicação moderada ou grave por organofosforados devem ser encaminhados para uma unidade de cuidados intensivos, no menor tempo possível, após realizados todos os procedimentos de reanimação e alcançada a sua estabilização<sup>48</sup> .  
A gravidade dos quadros apresentados nas intoxicações agudas por organofosforados determina o prognóstico e a evolução dos casos.  
Nas intoxicações leves, a recuperação geralmente é rápida, se o tratamento adequado é prontamente realizado numa unidade de saúde. No entanto, casos moderados ou graves podem apresentar complicações, as quais podem gerar sequelas neurológicas.  
#### **Ponto de boa prática**<sup>3,46</sup>  
Realize uma triagem rápida, seguida de uma anamnese detalhada para uma adequada avaliação do risco da gravidade da intoxicação.  
12  
Pacientes assintomáticos ou que apresentem sintomas leves, normalmente não requerem hospitalização.  
Proceda com a descontaminação cutânea, quando for o caso, lavando toda a superfície corporal com água e sabão. Considere que toda a roupa do paciente deve ser trocada.  
O paciente deve ser monitorado durante um período mínimo de 6 a 12 horas. Esse monitoramento deve incluir a avaliação dos seguintes parâmetros:  
- estado de alerta;  
- sinais neurológicos;  
- sinais vitais;  
- se possível, oximetria de pulso;  
- se possível, medir a atividade da acetilcolinesterase ou butilcolinesterase.  
Após a alta, assegurar que o paciente seja orientado para sinais de alerta e tenha acesso a serviço de saúde.  Ele deve retornar ao serviço de saúde caso apresente algum sintoma.  
A ausência de sinais e sintomas, após 12 h, reduz a probabilidade de sua ocorrência. Contudo, é preciso atentar para os casos de intoxicações com inibidores de colinesterease desconhecidos ou com compostos organofosforados altamente lipofílicos, como é o caso do fethion. Esses compostos podem produzir os primeiros sinais de debilidade muscular e insuficiência respiratória mesmo depois de 48 h da exposição.  
**Medidas de descontaminação em pacientes com intoxicação aguda por inibidores de colinesterase**  
#### **Ponto de boa prática**  
Realize as medidas de descontaminação, no menor tempo possível – considerando o lapso temporal entre a exposição e o atendimento, tendo em conta a via de exposição e as substâncias envolvidas, a fase da toxicocinética do agente tóxico conforme o tempo de exposição, bem como os benefícios e efeitos adversos de cada técnica.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Ponto de boa prática**  
A realização das manobras de descontaminação não deve interferir com a reanimação e estabilização do paciente, as quais são prioritárias.  
A absorção dérmica de inibidores de colinesterase é determinada por diversos fatores. Alguns deles relacionados às propriedades físico-químicas do produto e ao solvente utilizado. Outros associados à temperatura do ambiente e às características intrínsecas da própria pele da vítima. Apesar de estudos mais antigos, realizados em voluntários, indicarem uma baixa absorção cutânea de inibidores de colinesterase, é preciso considerar que a lipossolubidade desses agentes aumenta a possibilidade de absorção por essa via<sup>14 Apud Griffin 1999, Wester 1993, Krieger 2000</sup> .  
Dessa forma, é razoável a adoção de práticas de descontaminação dérmica e ocular no atendimento inicial de vítimas de intoxicação por esses compostos.  
13  
#### **Ponto de boa prática**  
Realize a descontaminação dérmica e ocular considerando a possível absorção dos inibidores de colinesterase por essas vias (vide anexo 2E)

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Ponto de boa prática**  
Deve ser proscrita a prática de oferta de leite, outras bebibas ou outros remédios caseiros imediatamente após a ingestão de inibidores de colinesterase.  
Apesar da ingestão de remédios caseiros imediatamente após a ingestão de inibidores de colinesterase ser uma prática adotada em diversas partes do mundo, não foram encontrados estudos que estimulem a adoção dessa prática. É preciso, inclusive, considerar que alguns problemas podem ocorrer quando grandes volumes de líquido são administrados oralmente "para diluir o veneno" ou para induzir a êmese. Aumentar o volume de líquido no estômago pode aumentar a taxa de esvaziamento do intestino delgado e acelerar a absorção e favorecer a intoxicação antes que a pessoa chegue a um serviço de saúde<sup>14,49</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Recomendação**  
Não é recomendável a indução do  vômito em paciente intoxicado com inibidores de colinesterase. Entretanto, também não é indicada a sua inibição, caso ele ocorra de forma espontânea em pacientes intoxicados.  
(Verificar as considerações do Capítulo 1 das presentes diretrizes)

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
**Recomendações**  
Não é recomendado o uso rotineiro de carvão ativado para intoxicação por agrotóxicos. Recomendação condicional contra a intervenção – Anexo II.6  
#### **Evidências**  
Em um ensaio clínico, 1.310 pacientes, maiores de 14 anos, intoxicados com inibidores de colinesterase, foram randomizados em três grupos: um que recebeu dose única de carvão ativado (440), um que recebeu múltiplas doses (429) e o último que não recebeu nenhuma dose (441). O histórico de êmese antes do atendimento, êmese forçada ou lavagem gástrica foi semelhante entre os grupos.  
Foi observado que não houve redução significativa da mortalidade nos grupos que receberam dose única (OR 0,94, IC 95% 0,63-1,41) ou múltiplas doses (OR 0,78, 95% IC 95% 0,511,19) de carvão ativado quando comparados com o grupo que não recebeu a intervenção. Tampouco se observaram diferenças significativas quando feita comparações dessse desfecho nos grupos intervencionais.  
Não foi evidenciada nenhuma redução significativa na necessidade de intubação, no desenvolvimento de convulsões, no tempo até a morte ou agravamento clínico com o uso de  
14  
carvão ativado em doses múltiplas ou única. A duração média da ventilação (excluindo as mortes) foi semelhante no grupo que recebeu doses múltiplas  e no grupo que não recebeu a intervenção. Contudo, essa foi mais longa nos pacientes tratados com dose única de carvão ativado.  
Não houve diferenças significativas quando o carvão ativado foi administrado antes ou após duas horas da ingestão. Contudo, deve-se considerar que somente um número pequeno de pacientes chegaram ao local de atendimento antes de transcorridas duas horas da exposição. O IC estreito (IC 95% 0,61 a 2,38,) sugere pouco benefício da intervenção<sup>50</sup> .  
Nível de Evidência: alto - Anexo II.5  
#### **Ponto de Boa Prática**  
Pode ser considerado o uso do carvão ativado somente em pessoas que ingeriram uma grande quantidade de agrotóxicos altamente tóxicos, que são adsorvidos<sup>1</sup> pelo carvão ativado e que forem atendidas nos primeiros 60 minutos após a exposição.  
Apesar de haver indícios de que uma única dose de carvão ativado pode ser uma estratégia de descontaminação útil para os casos de intoxicação por organofosforados, não há evidências suficientes que indiquem uma redução da mortalidade nos casos de intoxicação aguda por esses agentes pelo uso dessa intervenção<sup>51,52</sup> .  
Além disso, há estudos que indicam que a baixa efetividade da sua utilização em pacientes intoxicados pode estar relacionada à velocidade de absorção desses agentes<sup>53</sup> .  
Entretanto, mesmo que sejam poucos os benefícios do uso de carvão ativado em vítimas de intoxicação com agrotóxicos, alguns guias recomendam o seu uso **em dose única,  até 60 minutos após a exposição ao agente** , **quando há ingestão de quantidades potencialmente letais**<sup>51</sup> .  
#### **Ponto de boa prática**  
Considere as complicações e riscos associados ao uso do carvão ativado. Nos casos em que os benefícios da sua administração superem os riscos, estando o paciente consciente, essa poderá ser realizada por via oral ou sonda enteral.  
Caso seja indicada a intubação orotraqueal em pacientes com alteração do estado de consciência, hemodinamicamente instáveis ou convulsionando, é necessária a proteção da via aérea antes da administração de carvão ativado.  
As **complicações** associadas ao uso do carvão ativado, ou a técnica, são: pneumonia aspirativa<sup>54–</sup> 63; empiema 64;  pneumotórax65; bronquiolite obliterante66, insuficiência respiratória59,67,68; cavernas pulmonares<sup>68</sup> ; mediastinite<sup>69</sup> ; doença pulmonar crônica<sup>70</sup> ; Síndrome da Angústia Respiratória Aguda - SARA<sup>71</sup> , linfangioleiomiomatose pulmonar<sup>72</sup> , granuloma,<sup>73</sup> , constipação<sup>58</sup> infecção respiratória<sup>74</sup> , abrasão corneana<sup>56,75</sup> êmese<sup>58,76–78</sup> e alterações hidroeletrolíticas<sup>56</sup> .  
São **contraindicações** para o uso do carvão ativado: nível de capacitação ou treinamento inadequado do executor para a realização segura do procedimento, diminuição do peristaltismo, íleo paralítico, obstrução intestinal, comprometimento ou potencial comprometimento da via aérea, hemorragia ou perfuração gastrintestinal<sup>51,79</sup> .  
> 1 Informações adicionais em relação à toxicidade e uso do carvão ativado são descritas nas bulas dos produtos.  
15

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Recomendações**  
Não é recomendável o uso rotineiro de lavagem gástrica em pacientes intoxicados por inibidores de colinesterase  
Recomendação forte contra a intervenção (Anexo II.6)  
#### **Evidências**  
Foi encontrada uma revisão sistemática na qual foram avaliados 56 estudos de metodologias diversas. Desses, 23 eram ensaios clínicos controlados e randomizados, que avaliaram a eficácia e a segurança de utilização da lavagem gástrica para intoxicações com organofosforados diversos. Desses, por sua vez, foram selecionados 6 estudos nos quais todos os pacientes receberam como procedimento de base a lavagem gástrica na sua forma múltipla ou única. Nenhum dos estudos comparou a referida intervenção com a sua não realização. No geral, nenhum dos estudos indicou se houve ou não uma remoção significativa do agente tóxico no lavado gástrico. Os benefícios do procedimento foram incertos, com a perspectiva de que talvez lavagens múltiplas contribuíssem para a redução da mortalidade e para o desenvolvimento de insuficiência respiratória. Assim, apesar do uso generalizado de lavagens gástricas múltiplas para o tratamento de intoxicação por organofosforados em alguns países, não há, atualmente, nenhuma evidência de alta qualidade para apoiar sua eficácia clínica<sup>80</sup> .  
Nível de evidência: muito baixa - Anexo II.5  
#### **Ponto de Boa Prática**  
Pode ser considerado o uso da lavagem gástrica somente nos casos de ingestão de dose potencialmente letal de agrotóxicos em que a exposição tenha ocorrido 60 minutos (até 1 hora) antes do atendimento, desde que eles não tenham sido diluídos em solventes orgânicos e corrosivos<sup>2</sup> . Caso opte pela sua realização, proteja a via aérea do paciente.  
O procedimento deve ser realizado, em pacientes conscientes e que consentem a sua realização.  
Não foram encontrados ensaios clinicos que comparassem a efetividade da lavagem gástrica versus ausência da intervenção. Também não há evidência suficiente para recomendar ou desencorajar o uso rotineiro de múltiplas lavagens gástricas como tratamento para pacientes intoxicados por inibidores de colinesterase, considerando o desfecho mortalidade. Mas alguns estudos mostram benefícios da intervenção para outros desfechos como o desenvolvimento de insuficiência respiratória tardia e síndrome intermediaria<sup>81</sup> .  
Além disso, é incerto o período de tempo no qual os agrotóxicos permanecem no estômago após a sua ingestão. Apesar da taxa de absorção dos inibidores de colinesterase ser desconhecida, há indícios de que ela ocorra de forma rápida<sup>81</sup> .  
Alguns estudos são unânimes ao recomendar a realização da lavagem gástrica somente para os casos em que o atendimento médico ocorreu dentro da primeira à segunda hora depois da ingestão do agrotóxico<sup>12,50,82</sup> . Por outro lado, outros sugerem que nos casos de intoxicação decorrentes da ingestão de uma grande quantidade de agente, há benefícios se a intervenção é realizada dentro das duas primeiras horas após a exposição<sup>3,14</sup> .  
> 2Entre em contato com o CIATOX da sua região para a obtenção de mais informações.  
16  
#### **Ponto de Boa Prática**  
Caso considere a realização da lavagem gástrica, avalie as contraindicações, os potenciais benefícios e riscos da técnica e priorize o suporte vital e tratamento específico.  
Em pacientes com deterioração do estado de alerta ou que apresentam risco de depressão do Sistema Nervoso Central ou ausência de reflexo de vômito, proteger a via área com intubação orotraqueal ou nasotraqueal antes do procedimento.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
**Recomendação**  
**Não se recomenda o uso** de catárticos como medida de eliminação para o tratamento do paciente intoxicado por inibidores de colinesterase  
Recomendação forte contra a intervenção - Anexo II.6  
**Evidências**  
Não foram encontrados ensaios clínicos comparativos sobre a utilização de catárticos _versus_ placebo para o tratamento de pacientes vítimas de intoxicação aguda por inibidores da colinesterase. Visto que esses compostos por si só causam diarreia, o que pode levar a um desequilíbrio eletrolítico, tal condição pode ser exarcebada pela administração de **catárticos** , sugerindo que o risco de dano pode superar seus potenciais benefícios<sup>14</sup> Nível de evidência: muito baixa - Anexo II.5

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **<mark>Ponto de boa prática</mark>**  
Utilize técnicas de eliminação extracorpórea, se disponíveis, considerando as propriedades toxicocinéticas e toxicodinâmicas próprias da substância envolvida, assim como a gravidade clínica do paciente, além das seguintes condições<sup>83</sup> :  
- Ingestão e provável absorção de uma dose potencialmente letal;  
- Concentrações plasmáticas muito altas (se tal análise for possível), conforme avaliado pela experiência prévia de risco de morte e sequelas clínicas graves;  
- Deterioração clínica progressiva, apesar da terapia de suporte intensivo e manejo clínico adequado;  
- Intoxicação grave com sinais vitais anormais, incluindo depressão da função do SNC, resultando em hipoventilação ou apneia, grave hipotermia e hipotensão;  
- Intoxicação com uma substância extraível que pode ser removida a uma taxa superior à eliminação endógena pelo fígado ou rim;  
- Presença na formulação de agentes com efeito metabólico ou tardio, tais como metanol e etilenoglicol;  
- Coma prolongado (graus III e IV) e ventilação assistida prolongada, por mais de 48h;  
17  
- Insuficiência renal aguda causada por um agente (potencialmente) nefrotóxico;  
- Comprometimento do metabolismo e excreção da substância tóxica na presença de insuficiência hepática, cardíaca ou renal.  
A utilização das técnicas de eliminação extracorpórea deve ser feita em combinação com as demais práticas indicadas para o tratamento de pacientes intoxicados por agrotóxicos, tais como suporte vital, métodos de descontaminação, outros métodos de eliminação e antídotos.  
A eficácia das medidas de eliminação extracorpóreas depende do volume de distribuição de cada agrotóxico. Além disso, no caso específico dos organofosforados, ela provavelmente está relacionada à solubilidade lipídica do composto. Assim, essas intervenções podem ser úteis para a depuração de organofosforados não-lipossolúveis, como é o caso do dimetoato e do metamidofós. Contudo, são pouco efetivas para os casos de intoxicação com organofosforados muito lipossolúveis, como o fention<sup>14</sup> .  
#### **Recomendação**  
Considere a utilização de técnicas de eliminação extracorpórea para os casos de ingestão de organofosforados lipossolúveis e sempre que a dose ingerida de agente for muito alta ou considerada letal.  
Recomendação condicional a favor da intervenção (Anexo II.6)  
#### **Evidências**  
Foram encontrados quatro estudos que avaliaram a utilização de técnicas de eliminação extracorpórea para o tratamento de pacientes com intoxicação aguda por organofosforados<sup>84–87</sup> . Um deles comparou pacientes tratados com hemoperfusão (grupo experimental) com um grupo controle (p<0,05).  As taxas de hospitalização foram maiores no grupo experimental (p<0,01). Além disso, não houve diferença significativa (p>0,05) na taxa de mortalidade entre o grupo controle<sup>84</sup> .  
Em outro estudo realizado com 260 pacientes com intoxicação aguda grave por organofosforados, o grupo que recebeu a hemoperfusão teve uma redução significativa (p<0,05) na incidência de síndrome intermediária (5/130 vs. 14/130), na mortalidade (12/130 vs. 25/130) e no tempo de recuperação de 50% da AChE (5,0 ± 3,2 vs. 5,8 ± 2,4 dias) em relação ao grupo controle<sup>85</sup> .  
Para a comparação entre técnicas de eliminação combinadas (hemoperfusão mais hemofiltração contínua e hemoperfusão mais hemodiálise sustentada de baixa eficiência), 56 pacientes também gravemente intoxicados por organofosforados foram distribuídos em dois grupos de tratamento. Não foi observada diferença estatisticamente significativa em relação ao tempo de internação hospitalar ou em relação aos indicadores bioquímicos e parâmetros hemodinâmicos; na taxa de sobrevivência ou na taxa de mortalidade (p>0,05) entre os grupos<sup>86</sup> .  
Por fim, em um estudo clínico aberto não randomizado, onde 68 pacientes com intoxicação grave por organofosforados foram avaliados, as taxas de mortalidade (1/34) e de rebote (1/34) foram significativamente (p<0,05) menores no grupo que recebeu hemoperfusão e hemodiálise do que no grupo controle (6/34 e 4/34, respectivamente). Os tempos de atropinização, de recuperação da atividade de colinesterase, de recuperação de consciência, de extubação e de hospitalização foram todos menores no grupo tratamento, assim como o uso total de atropina (p<0,05). No entanto, a falta de randomização e o efetivo reduzido de pacientes torna a potência do estudo insuficiente<sup>87</sup> .  
Nível de Evidência: muito baixa (somente hemoperfusão) e muito baixa (técnicas combinadas) - Anexo II.5  
18  
A relação risco-benefício do aumento da eliminação em casos de intoxicação parece menor quando o agente tóxico está associado com morbidade significativa, quando se carece de terapias alternativas, e quando o tóxico é passível de eliminação por meio de técnicas corpóreas ou extracorpóreas (ex.: essas técnicas contribuem para uma grande proporção de eliminação total do corpo)<sup>88</sup> .  
#### **Ponto de boa prática**  
Entre imediatamente em contato com o Centro de Informação e Assistência Toxicológica para discutir as medidas de eliminação para cada intoxicação em particular, caso opte pela sua utilização como parte do tratamento de pacientes intoxicados por inibidores de colinesterase.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Visto que alguns organofosforados inativam a AChE por meio de ligação irreversível, a administração de AChE recombinante ou plasma fresco congelado , o qual é rico em butirilcolinesterase, pode auxiliar na neutralização do agente tóxico livre<sup>89</sup> . A transfusão de hemácias também tem sido proposta como terapia alternativa para a reposição da enzima na sua forma ativa. Inclusive, há indícios de que essa intervenção melhora alguns desfechos, como é o caso do tempo de internação hospitalar<sup>90</sup> .  
Os efeitos e mecanismos de ação dessas terapias para o tratamento de intoxicações por inibidores de colinesterase, no entanto, ainda não são totalmente compreendidos. Além disso, a qualidade das evidências apresentadas não é suficientemente robusta para subsidiar a recomendação de seu uso rotineiro para o tratamento de pacientes intoxicados por inibidores de colinesterase<sup>90</sup> . O mesmo para o uso de PFC<sup>89</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Intervenções consideradas:**  
- Antidototerapia com atropina  
- Antidototerapia com oximas  
- Terapia com benzodiazepínicos  
- Terapia com sulfato de magnésio  
- Outros agentes

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
O tratamento imediato de intoxicações com inibidores de colinesterase, posterior ao suporte vital, baseia-se na avaliação do risco e nas observações realizadas durante o monitoramento clínico contínuo. O uso de antídotos pressupõe o conhecimento da dose ingerida, do tempo transcorrido desde a ingestão, as características clínicas, os fatores intrínsecos do paciente e a disponibilidade de recursos médicos.  
19

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
A atropina é um antagonista competitivo do receptor **muscarínico** da acetilcolina, com boa penetração no sistema nervoso central. Ela é efetiva na reversão da bradicardia, da hipotensão da broncorreia e dos broncoespasmos secundários à intoxicação por inibidores de colinesterase. O processo de reversão das manifestações muscarínicas da intoxicação por inibidores de colinesterase com o uso de atropina é denominado "atropinização"<sup>91</sup> .  
#### **Ponto de boa prática**  
Administre atropina rapidamente após o diagnóstico clínico da síndrome colinérgica relacionada à intoxicação por organofosforados ou carbamatos, para reverter os efeitos muscarínicos da intoxicação<sup>13</sup> .  
Não foram encontrados ensaios clínicos que avaliem o uso de atropina versus a sua não utilização. Contudo, diversos autores e consensos sustentam sua efetividade na reversão dos efeitos muscarínicos observados inicialmente nas intoxicações por inibidores de colinesterase<sup>3,13,14,92</sup> .  
A dose de atropina é variável entre indivíduos, sendo também determinada de acordo com o agente tóxico e  a realização concomitante de outras intervenções<sup>52,93</sup> . Dessa forma, são utilizados diferentes regimes de atropina para o tratamento da intoxicação por inibidores de colinesterase. As duas formas mais frequentes de administração são em bolus e incremental<sup>93</sup> .  
#### **Recomendações**  
Realizar a administração de atropina em doses incrementais até que se alcance a atropinização. Recomendação forte a favor da intervenção (Anexo II.6)  
#### **Evidências**  
Um ensaio clínico randomizado comparou  o uso de atropina em bolus com a sua administração incremental em pacientes intoxicados por organofosforados<sup>94</sup> .  
O primeiro grupo (n= 81) recebeu bolus de 2-5 mg de atropina IV a cada 10-15 min, até atingir a atropinização; depois, a atropinização foi mantida reduzindo-se a dose ou aumentando a duração entre as doses de atropina. O segundo grupo (n= 75) recebeu uma dose inicial de 1,8-3,0 mg de atropina IV, dobrando a dose inicial a cada 5 min até atropinização; sendo em seguida administrado, a cada hora, de 10-20% da dose requerida para atropinização. Os pacientes de ambos os grupos que, apresentavam menos de 36 h da intoxicação, receberam também pralidoxima.  
Os pacientes do segundo grupo, apresentaram menor mortalidade (6/75 vs. 18/80; p<0,05), menor duração de tempo média para a atropinização (23,90 vs. 151,74 min; p<0,001) e menor toxicidade por atropina (12,0 vs. 28,4 %; p<0,05), em comparação com o primeiro grupo. A incidência de síndrome intermediária (4% vs. 13,6%, p<0,05) e a necessidade de suporte respiratório (8% vs. 24,7%, p<0,05) também foram menores nesse grupo.  
Nível de Evidência: Moderada - Anexo II.5  
Um ensaio clínico, randomizado, com 60 pacientes diagnosticados com intoxicação aguda grave por organofosforados mostrou que a infusão contínua de atropina combinada com cloreto de pralidoxima é mais eficaz do que a administração em bolus repetidos de atropina  Foram utilizados  
20  
como desfechos o tempo (min) e a dose (mg) para a atropinização, o tempo para recuperação da atividade enzimática, a gravidade da evolução pela escala de APACHE II e a mortalidade<sup>95</sup> .  
Não foram encontrados estudos que comparassem essa intervenção com a infusão incremental. Além disso, há necessidade de mais estudos clínicos para determinar o regime de dosagem adequada de atropina para o alcance de uma atropinização mais rápida e segura, considerando os desfechos clínicos críticos nesses pacientes e os diferentes tipos de inibidores de colinesterase.  
#### **<u><mark>DOSE INCREMENTAL DE ATROPINA</mark></u>** <u><mark>:</mark></u><sup>13,93,96</sup>  
- Dar uma dose de ataque, em bolus, de 0,6 a 3 mg, rapidamente, via IV;  
- Dobrar a dose a cada 5 min, até o paciente estar atropinizado (frequência cardíaca acima de 80 bpm; pressão arterial sistólica acima de 80 mmHg; ausculta pulmonar limpa)  
- Após alcançar a atropinização, administrar por meio de infusão contínua de 10-20% da dose total de atropina requerida para atropinização a cada hora em solução salina 0,9%;  
- **Monitorar o paciente cuidadosamente para toxicidade colinérgica recorrente ou começo da toxicidade por atropina, a qual se manifesta por meio de taquicardia, ausência de sons intestinais, hipertermia, delírio e retenção urinária** ;  
- Se os sintomas colinérgicos reaparecerem a qualquer momento, recomeçar as doses em bolus até o paciente estar atropinizado novamente e aumentar a taxa de infusão em 20% por hora.  
<u>Ver fluxograma anexo 2F</u>  
A dose de atropina em crianças é 0,01-0,06mg/Kg/dose. Repetir a cada 5-15 minutos até atropinização. Em crianças, a atropinização tem desfechos semelhantes aos observados em adultos<sup>3</sup>  
Não foram encontradas evidencias sobre uso de atropina em doses incrementais em crianças intoxicadas com inibidores de colinesterase.  
A ausculta deve ser usada para confirmar a ausência de sibilância e crepitações. Alguns autores consideram também como sinal de atropinização as axilas secas, já que a transpiração é um dos primeiros sintomas revertidos pela administração da atropina<sup>3,15,46</sup> .  
Por outro lado, a reversão da constrição pupilar pode ser um efeito tardio<sup>61,96</sup> e estar associada à exposição ocular direta, especialmente quando for unilateral.  Dessa forma, ela não deve ser usada para determinar a continuidade ou não da administração da atropina.  
#### **Ponto de boa prática**  
_Monitorize os Sinais de toxicidade por atropina_<sup>13</sup> :  
- Taquicardia grave;  
- Ausência de ruídos peristálticos;  
- Hipertermia;  
- Delírio ou confusão mental;  
- Retenção urinária.  
21  
A presença de três dos sinais acima descritos indica a necessidade de pausar a infusão de atropina, devendo ser o paciente monitorado a cada 30 minutos.  
Havendo remissão dos sinais de toxicidade por atropina, deve-se reiniciar a sua administração 80% da última dose de infusão e continuar o monitoramento.  
A taquicardia isolada não indica a necessidade de suspender a atropina. Essa pode estar associada ao uso de outros medicamentos e a possíveis quadros de  pneumonia, hipovolemia e hipóxia<sup>13</sup> .  
Durante a reanimação de pacientes vítimas de intoxicação aguda por inibidores de colinesterase, o excesso de atropina e sua toxicidade são considerados como eventos de menor importância. Contudo, após a reanimação inicial é importante que os pacientes não permaneçam em condição antimuscarínica, devido ao risco de agitação aumentada e colapso cardiovascular<sup>96</sup> .  
#### **Ponto de boa prática**  
A partir da dose inicial e ao longo da administração de atropina, utilize um formulário específico para registrar (Modelo de formulário – Anexo 2G), a cada cinco minutos, os seguintes parâmetros clínicos<sup>13</sup> :  
- Ausculta pulmonar (crepitações ou sibilâncias);  
- Pressão arterial;  
- Frequência cardíaca;  
- Tamanho da pupila;  
- Secura axilar;  
- Ruídos peristálticos abdominais;  
- Temperatura;  
- Dose de atropina em infusão;  
- Dose de atropina em bolus.  
#### **Ponto de boa prática**  
A administração de oxigênio não é uma condição prévia para utilizar atropina. Um ensaio clínico não achou evidência que possa apoiar que o oxigênio deva ser administrado antes da atropina<sup>97</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
O uso de **oximas** como antídoto complementar para o tratamento de intoxicação aguda com organofosforados tem sido convencionalmente parte de alguns protocolos já estabelecidos por algumas unidades de saúde. Devido ao seu papel na reativação da acetilcolinesterase, a variabilidade nas respostas clínicas obtidas após sua utilização e a ausência de um regime de dosagem definido faz com que as oximas levantem controvérsias em relação à sua eficácia<sup>12,98</sup> .  
Apesar de existirem diferentes tipos de oximas (pralidoxima, obidoxima e tribedoxima), a mais utilizada é a pralidoxima. No Brasil, a última atualização do elenco da Relação Nacional de Medicamentos Essenciais apresenta o mesilato de pralidoxima como a forma disponibilizada pelas unidades do Sistema Único de Saúde<sup>99</sup> .  
**Recomendação**  
22  
Não se recomenda o uso de oximas na intoxicação por inibidores de colinesterase. Recomendação condicional contra a intervenção (Anexo II.6)  
#### **Evidências**  
A avaliação de cinco ensaios clínicos randomizados sobre uso de pralidoxima em intoxicações por organofosforados não mostrou benefícios da intervenção na redução da mortalidade, necessidade de ventilação mecânica ou síndrome intermediaria. Esses estudos foram realizados com diferentes doses de pralidoxima e diferentes tipos de organofosforados<sup>100–103</sup> . Nível de evidência: muito baixa - Anexo II.5  
Foram conduzidos ensaios clínicos com oximas avaliando outros desfechos, como reativação da butirilcolinesterase. Contudo, essa classe de compostos não se mostrou clinicamente relevante para os casos de intoxicações agudas por inibidores de colinesterase<sup>104</sup> .  
A condução de Estudos Clínicos Randomizados adicionais auxiliaria na determinação de possíveis estratégias e regimes que comprovem o benefício do uso das oximas em alguns casos. Contudo, atualmente, há controvérsias em relação a esses compostos, havendo indícios de que além de não serem úteis, as oximas podem ser prejudiciais quando utilizadas em pacientes vítimas de auto-envenenamento severo, particularmente os com manifestações tardias, como é o caso das intoxicações com dimetil-OP<sup>98</sup> Ressalta-se que as oximas também são contraindicadas para os casos de intoxicação por carbamatos .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### _<u>Terapia com benzodiazepínicos</u>_  
As convulsões são consideradas complicações tidas como relativamente incomuns em pacientes intoxicados com inibidores de colinesterase<sup>14,96</sup> .  
#### **Ponto de boa prática**  
Não existem estudos com evidência de qualidade para recomendar o uso rotineiro de benzodiazepínicos em pacientes intoxicados com inibidores de colinesterase. Contudo, os benzodiazepínicos têm sido utilizados para o controle de convulsões ou de fasciculações musculares pronunciadas, observadas nas intoxicações por organofosforados.<sup>105</sup> . Para intoxicações por carbamatos o tratamento  é similar<sup>3</sup>  
A administração endovenosa de benzodiazepínicos, caso necessário, deve considerar protocolo adotado pela unidade de saúde  
#### _<u>Terapia com sulfato de magnésio</u>_  
O sulfato de magnésio é um inibidor da liberação de acetilcolina no SNC e nas sinapses periféricas simpáticas e parassimpáticas<sup>14,96</sup> . Dois estudos clínicos muito pequenos sugeriram uma melhora na função neuromuscular<sup>106</sup> e redução da mortalidade<sup>107</sup> em pacientes com intoxicação aguda por organofosforados, que receberam sulfato de magnésio.  No entanto, como os estudos não foram randomizados, tiveram pequeno tamanho amostral e apresentaram falhas na descrição da metodologia eles não são suficientes para subsidiar a recomendação do uso do referido produto para os casos de intoxicação por inibidores de colinesterase.  
23  
#### _<u>Outros agentes</u>_  
Até o presente momento, não foi possível identificar estudos que forneçam evidências suficientes que justifiquem o uso das seguintes intervenções no tratamento para a intoxicação aguda por inibidores de colinesterase<sup>14,96</sup> .  
- Brometo de ipratrópio  
- Infusão de lipídeos  
- Terapia com receptores adrenérgicos  
- Terapia com substituição de butirilcolinesterase  
- Terapia com antagonistas do receptor de N-metil-D-aspartato  
- Terapia com hidrolases  
- Terapia com bicarbonato de sódio  
#### **Ponto de boa prática**  
Na intoxicação por organofosforados e carbamatos, estão contraindicados: morfina, succinilcolina, suxametônio e demais relaxantes musculares despolarizantes, teofilina, fenotiazinas e reserpina<sup>24,45,46</sup> .  
Os inseticidas organofosforados são comumente formulados com solventes e surfactantes para melhorar a sua efetividade e uso agrícola em diversas culturas. No entanto, o efeito desses solventes nas intoxicações por inibidores de colinesterase ainda não foi esclarecido.  
O tipo e a quantidade de solvente nas formulações variam de acordo com o fabricante e o ingrediente ativo. Sendo assim, deve-se considerar que as vítimas de intoxicações por inibidores de colinesterase também são expostas a essas combinações de substâncias, cuja toxicidade pode influenciar nos desfechos observados e comprometer a efetividade de alguns antídotos durante o atendimento. Há, portanto, a necessidade de uma maior compreensão em relação aos efeitos tóxicos dessas misturas para que se possa propor mudanças na formulação de alguns produtos<sup>96</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Pacientes com histórico de exposição a inibidores de colinesterase devem ser acompanhados, considerando o risco de desenvolvimento de diversas neuropatias associadas a esse tipo de intoxicação.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Ponto de Boa Prática**  
Pacientes que desenvolvem neuropatia tardia induzida por organofosforados devem receber tratamento de suporte baseado em analgésicos e fisioterapia<sup>12</sup> .  
A presença de ataxia espástica é um indicador de sequelas permanentes derivada da neuropatia por organofosforados. O grau de comprometimento piramidal irá determinar o grau de recuperação funcional<sup>6</sup>  
De acordo com a gravidade do quadro, pode ser necessário tratamento prolongado e apoio psicológico para lidar com as sequelas derivadas do quadro.  
24  
Atualmente, não há evidências suficientes que permitam o estabelecimento de um tratamento específico para a neuropatia tardia induzida por organofosforados. Há trabalhos que sugerem o uso de tiamina, de capsaicina, bem como de outras drogas psicoativas, como é o caso da amitriptilina e carbamazepina, para o tratamento da hiperestesia observada na referida condição. Contudo, até o momento, não há dados que apoiem a eficácia de tal conduta<sup>108</sup> .  
Além da inibição da esterase susceptível à neuropatia (NTE), mencionados na introdução do presente capítulo, estudos experimentais propõem outros mecanismos relacionados ao desequilíbrio homeostático de cálcio. A fosforilação exarcebada e o acúmulo de proteínas estruturais no citosol de células sinápticas, fenômeno comumente observado em quadros neurodegenerativos, seria uma consequência do estímulo de “quinases cálcio-calmodulina dependentes” ocasionados pela presença do organofosforado. Sendo assim, o uso de bloqueadores de canal de cálcio pode representar, uma alternativa para a prevenção das neuropatias induzidas por organofosforados. Contudo, ainda não há evidências que confirmem a sua efetividade<sup>109</sup> .  
#### **Ponto de Boa Prática**  
A reabilitação de trabalhadores intoxicados acometidos por polineuropatia periférica em decorrência da exposição a inibidores de colinesterase, deve prever a execução de estratégias e de ações simultâneas que considerem<sup>12</sup>  
- A promoção da saúde;  
- Diagnóstico precoce e seguimento ambulatorial;  
- A prevenção da incapacidade  
- O desenvolvimento, recuperação e manutenção funcional;  
- A reintegração sócio-ocupacional  
- Processo de reabilitação integral

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Como o diagnóstico desse transtorno é essencialmente clínico, o reconhecimento de que ele se relaciona à exposição a organofosforados é fundamental para que os pacientes recebam os benefícios de um acompanhamento oportuno<sup>110</sup> .  
#### **<mark>Ponto de Boa Prática</mark>**  
O diagnóstico precoce do transtorno neuropsiquiátrico crônico induzido por organofosforados é fundamental para o estabelecimento de um plano terapêutico adequado. Critérios diagnósticos utilizados para o transtorno neuropsiquiátrico crônico induzido por organofosforados<sup>111</sup>  
1. Exposição repetida a organofosforados  
2. Pelo menos quatro dos seguintes:  
- mudança de personalidade e desestabilização de humor  
- deficiência de concentração e memória  
- tolerância ao exercício prejudicada  
- redução da tolerância ao álcool  
- maior sensibilidade aos organofosfatos.  
3. Pelo menos três dos seguintes:  
- exacerbação da "gripe dos nadadores"  
- pensamento suicida impulsivo  
- distúrbio de linguagem  
- olfato intensificado  
- deterioração da caligrafia  
25  
#### **Ponto de Boa Pratica**  
Pacientes diagnosticados com transtornos neuropsquiátricos crônicos induzidos por organofosforados necessitam do estabelecimento de um plano terapêutico que inclua interrupção da exposição, seguimento ambulatorial, a utilização de fármacos antidepressivos (quando necessário) e o acompanhamento no âmbito da Saúde Mental<sup>17</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
Diversos estudos apontam que a depressão e as chances de ideação suicida são associadas aos efeitos da exposição prolongada a agrotóxicos. O histórico de exposições agudas a esses compostos tem sido relacionado a quadros de depressão e de ideação suicida e implica numa influência mais direta sobre a saúde, tal qual as exposições crônicas.  
#### **Ponto de Boa Prática**  
Se identificada a circunstância de intoxicação por tentativa de suicídio, deve-se encaminhar o paciente à Rede de Atenção Psicossocial (RAPS).  
Para conhecer mais sobre a RAPS acesse o endereço eletrônico do Portal da Saúde:  
http://portalsaude.saude.gov.br/index.php/o-ministerio/principal/secretarias/sas/daet/saudemental

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
#### **Ponto de Boa Prática**  
Uma vez finalizada a atenção inicial e estabilizado o paciente, deve-se realizar a respectiva notificação do caso, utilizando o formato de notificação de intoxicações apropriado.  
Notifique todos os casos suspeitos de intoxicação exógena no Sistema de Informação de Agravos de Notificação (Sinan). Ela é obrigatória a todos os profissionais de saúde (anexo D e E), e é um fator determinante para medidas de vigilância.  
Existe também a possibilidade da comunicação pelos cidadãos ou estabelecimentos educacionais por meio do Disque Notifica: 0800-644-6645 ou notifica@saude.gov.br.  
**(Verificar o Capítulo 1 das presentes diretrizes para maiores detalhes em relação á obrigatoriedade da notificação compulsória dos casos de suspeita de intoxicação exógena)**  
#### **Ponto de Boa Prática**  
Em caso de ser uma intoxicação exógena por agrotóxicos relacionada ao trabalho, de acordo com a Lei 8.213/1991; Portaria GM/MS de Consolidação nº 2 de 2017, anexo XV (origem: PRT MS 1.823/2012); Portaria GM/MS de Consolidação nº 5 de 2017, art. 422 e Anexo LXXIX (origem: PRT MS 3.120/1998)<sup>112</sup> ; Lei 6.015/1973; Portaria GM/MS de Consolidação nº 4 de 2017, anexo V (Origem: PRT MS/GM 204/2016)<sup>113</sup> ; o médico ou profissional de saúde deve:  
26  
- Emitir a Comunicação de Acidente de Trabalho (CAT) para os trabalhadores que contribuem com o INSS e os segurados especiais (a exemplo de agricultores e pescadores);  
- Referenciar o trabalhador, para a atenção básica, caso o primeiro atendimento seja realizado em serviços de média ou alta complexidade com o objetivo de dar continuidade ao cuidado;  
- Acionar o Centros de Referência em Saúde do Trabalhador (Cerest) ou equipe de vigilância em saúde para realizar vigilância de ambiente e processo de trabalho referente ao caso, com o objetivo de intervir, minimizando ou eliminando a exposição de trabalhadores aos agrotóxicos;  
- Notificar o caso na ficha de investigação de **Intoxicação Exógena do Sinan** e sempre preencher os campos: 32-Ocupação, 36-Atividade Econômica (CNAE), 34-Local de ocorrência da exposição como “ambiente de trabalho”, 56-A exposição/contaminação foi decorrente do trabalho/ ocupação? Como “Sim”;  
- Em caso de **óbito** , incluindo suicídio, por intoxicação por agrotóxicos relacionada ao trabalho, preencher um dos campos de causa do óbito da Declaração de Óbito (DO) com o CID-10, Y96-Circunstâncias relativas às condições de trabalho. E ainda assinalar o campo acidente de trabalho como “sim” na parte de causas externas da DO.  
( **Verificar o anexo D, do Capítulo 1, o qual apresenta o fluxograma para o atendimento** **<u>de trabalhadores com suspeita de intoxicação por agrotóxicos</u>** <u>)</u>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: Geral -->
1. Ministério do Meio Ambiente I. Relatórios de comercialização de agrotóxicos - Boletim 2016 [Internet]. Barsília; 2018. Available from:  
- http://www.ibama.gov.br/agrotoxicos/relatorios-de-comercializacao-deagrotoxicos#boletinsanuais  
2. King AM, Aaron CK. Organophosphate and C a r b a m a t e Po i s o n i n g. 2015;33:133–51.  
3. Roberts DM, Aaron CK. Management of acute organophosphorus pesticide poisoning. Bmj. 2007;334(7594):629–34.  
4. Peter J, Sudarsan TI, Moran JL. Clinical features of organophosphate poisoning: A review of different classification systems and approaches. Indian J Crit Care Med. 2014;18(11):735–46.  
5. King AM, Aaron CK. Organophosphate and Carbamate Poisoning. Emergency Medicine Clinics of North America. 2015.  
6. Lotti M, Moretto A. Organophosphate-induced delayed polyneuropathy. Toxicol Rev. 2005;24(1):37–49.  
7. Moretto A LM. Poisoning by organophosphorus insecticide and sensory neuropathy. J Neurol Neurosurgery, Psychiatry 1998; 64 463-468. 1998;64:463–8.  
8. Roberts JR, Reigart JR. Recognition and Management of Nonrelaxing. United States  
27  
Environmental Protection Agency. 2013.  
9. Erickson TB, Thompson TM, Lu JJ. The Approach to the Patient with an Unknown Overdose. Emerg Med Clin North Am. 2007;25(2):249–81.  
10. Brasil. Ministério da Saúde. Protocolos de Suporte Avançado de Vida. 2<sup>a</sup> . Urgência. P de I para o S 192-S de AM de, editor. Brasilia: Secretaria de Atenção à Saúde; 2016.  
11. Pohanka M. Cholinesterases, a target of pharmacology and toxicology. Biomed Pap. 2011;155(3):219–30.  
12. Colômbia M de la PS. Guía de Atención Integral de Salud Ocupacional Basada en la Evidencia para Trabajadores Expuestos a Plaguicidas Inhibidores de la Colinestarasa (Organofosforados y Carbamatos). 2008.  
13. Eddleston M, Dawson A, Karalliedde L, Dissanayake W, Hittarage A, Azher S, et al. Early management after self-poisoning with an organophosphorus or carbamate pesticide - a treatment protocol for junior doctors. Crit Care. 2004 Dec;8(6):R391-7.  
14. Blain PG. Organophosphorus poisoning (acute). BMJ Clin Evid. 2011 May;2011.  
15. Singh S, Sharma N. Neurological syndromes following organophosphate poisoning. Neurol India [Internet]. 2000;48(4):308–13. Available from: http://www.ncbi.nlm.nih.gov/pubmed/11146591  
16. Jamal F, Haque QS, Singh S. Interrelation of Glycemic Status and Neuropsychiatric Disturbances in Farmers with Organophosphorus Pesticide Toxicity. Open Biochem J [Internet]. 2016;10(1):27–34. Available from:  
- http://benthamopen.com/ABSTRACT/TOBIOCJ-10-27  
17. Ghimire SR, Parajuli S. Chronic organophosphate-induced neuropsychiatric disorder: A case report. Neuropsychiatr Dis Treat. 2016;12:275–7.  
18. Jayawardane P, Dawson AH, Weerasinghe V, Karalliedde L, Buckley NA, Senanayake N. The spectrum of intermediate syndrome following acute organophosphate poisoning: A prospective cohort study from Sri Lanka. PLoS Med. 2008;5(7):1143–53.  
19. Vasconcellos LFR, Leite AC, Nascimento OJM. Organophosphate-induced delayed neuropathy: Case report. Arq Neuropsiquiatr. 2002;60(4):1003–7.  
20. Beard JD, Umbach DM, Hoppin JA, Richards M, Alavanja MCR, Blair A, et al. Pesticides and depression in male applicators. Environ Health Perspect. 2014;122(9):984–91.  
21. World Health Organization. WHO human health risk assessment toolkit : chemical hazards. IPCS Harmon Proj Doc. 2010;xv, 87 p.  
22. Lee BK, Jeung KW, Lee HY, Jung YH. Mortality rate and pattern following carbamate methomyl poisoning. Comparison with organophosphate poisoning of comparable toxicity. Clin Toxicol. 2011;49:828–33.  
23. Dubey TN, Yadav S, Kawre KK. Correlation of Severity of Organophoshorus Poisoning as Assessed by Peradeniya Organophosphorus Poisoning Scale with Serum Amylase and CPK Level. Int J Contemp Med Res. 2016;3(9):2534–7.  
24. Karalliedde L, Baker D, Marrs TC. Organophosphate-induced intermediate syndrome: Aetiology and relationships with myopathy. Toxicol Rev. 2006;25(1):1–14.  
25. Palimar V. Intermediate Syndrome in. 2005;27(1):971–3.  
26. Palimar V. REVIEW OF INTERMEDIATE SYNDROME IN. 2006;34–5.  
27. Indira M, Andrews MA, Rakesh TP. Incidence, predictors, and outcome of intermediate syndrome in cholinergic insecticide poisoning: A prospective observational cohort study. Clin Toxicol. 2013;51(9):838–45.  
28  
28. NK Sundaray KR. Organophosphorus Poisoning : Current management guidelines. Med Updat. 2010;5:420–5.  
29. Clinical MOH, Guidelines P. Management of Poisoning. 2011.  
30. Palaniappen V. Current Concepts in the Management of Organophosphorus Compound Poisoning. In: Current Concepts in the Management of Organophosphorus. 2013. p. 427–33.  
31. Vernekar P V, Shivaraj K. Peradeniya organophosphorus poisoning scale (POP) as a predictor of respiratory failure and mortality in organophosphorus poisoning. Sch J Appl Med Sci [Internet]. 2017;5(5B):852–6. Available from: https://www.google.co.id/url?sa=t&rct=j&q=&esrc=s&source=web&cd=8&cad=rja&ua ct=8&ved=0ahUKEwitua3S_o_NAhXCKo8KHZVXC6MQFgheMAc&url=http://eprint s.manipal.edu/3264/1/POTJ_YOGA__STUDY.pdf&usg=AFQjCNEKL1MlYpHrOdhr8 gGHJQgoTRvK-w&sig2=FnuqPDZOyQMVsAcKwAGoHA&bvm  
32. Laudari S. Cardiovascular Effects of OP Poisoning Cardiovascular Effects of Acute Organophosphate Poisoning. Asia Pac J Med Toxicol [Internet]. 2014;3(June):64–7. Available from:  
http://apjmt.mums.ac.ir/pdf_3045_da121c2958d222d201ff1c762c96db75.html  
33. Lee DH, Jung KY, Choi YH, Cheon YJ. Body mass index as a prognostic factor in organophosphate-poisoned patients. Am J Emerg Med [Internet]. 2014;32(7):693–6. Available from: http://dx.doi.org/10.1016/j.ajem.2014.04.030  
34. Saadeh AM, Farsakh NA, Al-Ali MK, Basma P. Cardiac manifestations of acute carbamate and organophosphate poisoning. Heart. 1997;77:461–4.  
35. Prasad M, Gouda HS, Hallikeri VR. Case Report Plasma cholinesterase : double-edged parameter in the diagnosis of acute organophosphorus poisoning. Med Sci Law. 2010;50:159–60.  
36. Dawson AH, Eddleston M, Senarathna L, Mohamed F, Gawarammana I, Bowe SJ, et al. Acute human lethal toxicity of agricultural pesticides: A prospective cohort study. PLoS Med. 2010;7(10):10–1.  
37. Lionetto MG, Caricato R, Calisi A, Giordano ME, Schettino T. Acetylcholinesterase as a biomarker in environmental and occupational medicine: new insights and future perspectives. BioMed Res iIternational. 2013;2013(1):8.  
38. Kachaiyaphum P, Howteerakul N, Sujirarat D, Siri S, Suwannapong N. Serum cholinesterase levels of Thai chilli-farm workers exposed to chemical pesticides: Prevalence estimates and associated factors. J Occup Health. 2010;52(1):89–98.  
39. Pearson M, Metcalfe C, Jayamanne S, Gunnell D, Weerasinghe M, Pieris R, et al. Effectiveness of household lockable pesticide storage to reduce pesticide self-poisoning in rural Asia: a community-based, cluster-randomised controlled trial. Lancet (London, England). 2017 Oct;390(10105):1863–72.  
40. Abdullat IM, Battah AH, Hadidi KA. The use of serial measurement of plasma cholinesterase in the management of acute poisoning with organophosphates and carbamates. Forensic Sci Int. 2006;162(1–3):126–30.  
41. Shadnia S, Okazi A, Akhlaghi N, Sasanian G, Abdollahi M. Prognostic value of long QT interval in acute and severe organophosphate poisoning. J Med Toxicol. 2009;5(4):196– 9.  
42. Hernández AF, Amparo Gómez M, Pérez V, García-Lario J V., Pena G, Gil F, et al. Influence of exposure to pesticides on serum components and enzyme activities of cytotoxicity among intensive agriculture farmers. Environ Res. 2006;102(1):70–6.  
43. Laudari S. Cardiovascular Effects of OP Poisoning Cardiovascular Effects of Acute  
29  
Organophosphate Poisoning. Asia Pac J Med Toxicol. 2014;3(June):64–7.  
44. Sun IO, Yoon HJ, Lee KY. Prognostic Factors in Cholinesterase Inhibitor Poisoning. Med Sci Monit [Internet]. 2015;21:2900–4. Available from: http://www.medscimonit.com/abstract/index/idArt/894287  
45. Lindell AR of C, Bernier GM( U of TMB. National Pesticide Practice Skills Guidelines for Medical & Nursing. The National Environmental Educatiion & Training Fundation, editor. Washington, DC; 2003.  
46. CENETEC. De La Intoxicación Aguda Por Agroquímicos En El Primer Nivel De Atención De La Intoxicación Aguda Por Agroquímicos En El Primer Nivel De Atención. 2008;1–50.  
47. Davies J, Roberts D, Eyer P, Buckley N, Eddleston M. Hypotension in severe dimethoate self-poisoning. Clin Toxicol (Phila). 2008 Nov;46(9):880–4.  
48. Van Hoving DJ, Veale DJH, Muller GF. Clinical Review: Emergency management of acute poisoning. African J Emerg Med. 2011;1(2):69–78.  
49. Eddleston M. The pathophysiology of organophosphorus pesticide self-poisoning is not so simple. Neth J Med. 2008;66(4):146–8.  
50. Eddleston M, Juszczak E, Buckley NA, Senarathna L, Mohamed F, Dissanayake W, et al. Multiple-dose activated charcoal in acute self-poisoning: a randomised controlled trial. Lancet (London, England). 2008 Feb;371(9612):579–87.  
51. Bouchard. Guidelines Update. Adv Skin Wound Care. 2010;18(4):221–3.  
52. Blain PG. Organophosphorus poisoning ( acute ) Search date April 2010 Organophosphorus poisoning ( acute ). 2011;(April 2010):1–17.  
53. Eddleston M, Buckley NA, Eyer P, Dawson AH. Management of acute organophosphorus pesticide poisoning. Lancet. 2008;371(9612):597–607.  
54. Amigó M, Nogué S, Mir Ò̀. Carb??n activado en 575 casos de intoxicaciones agudas. Seguridad y factores asociados a las reacciones adversas. Med Clin (Barc). 2010;135(6):243–9.  
55. Bosse GM, Barefoot JA, Pfeifer MP, Rodgers GC. Comparison of three methods of gut decontamination in tricyclic antidepressant overdose. J Emerg Med. 1995;13(2):203–9.  
56. Dorrington CL, Johnson DW, Brant R, Berlin R, Daya M, Purssell R, et al. The frequency of complications associated with the use of multiple-dose activated charcoal. Ann Emerg Med. 2003;41(3):370–7.  
57. Bairral B. Activated charcoal bronchial aspiration. J Bras Pneumol. 2012;43(6):236–8.  
58. Osterhoudt KC, Alpern ER, Durbin D, Nadel F, Henretig FM. Activated charcoal administration in a pediatric emergency department. Pediatr Emerg Care. 2004;20(8):493–8.  
59. Golej J, Boigner H, Burda G, Hermon M, Trittenwein G. Severe respiratory failure following charcoal application in a toddler. Resuscitation. 2001;49(3):315–8.  
60. Menzies D. Fatal pulmonary aspiration of oral activated charcoal. 1988;297:459–60.  
61. Harris CR, Filandrinos D. Accidental administration of activated charcoal into the lung: aspiration by proxy. Ann Emerg Med. 1993 Sep;22(9):1470–3.  
62. Pollack MM, Dunbar BS, Holbrook PR, Fields AI. Aspiration of activated charcoal and gastric contents. Ann Emerg Med. 1981 Oct;10(10):528–9.  
63. Silberman H, Davis SM, Lee A. Activated charcoal aspiration. N C Med J. 1990 Feb;51(2):79–80.  
30  
64. Justiniani FR, Hippalgaonkar R, Martinez LO. Charcoal-containing empyema complicating treatment for overdose. Chest. 1985 Mar;87(3):404–5.  
65. Thomas B, Cummin D, Falcone RE. Accidental Pneumothorax from a Nasogastric Tube. N Engl J Med. 1996 Oct;335(17):1325–6.  
66. Elliott CG, Colby T V, Kelly TM, Hicks HG. Charcoal lung. Bronchiolitis obliterans after aspiration of activated charcoal. Chest. 1989 Sep;96(3):672–4.  
67. Gutiérrez GC, Bossert T, Espinosa JQ. Guía Metodológica para la elaboración de Guías de Atención Integral en el Sistema General de Seguridad Social en Salud Colombiano. 2010. 2013.  
68. Francis RCE, Schefold JC, Bercker S, Temmesfeld-Wollbrück B, Weichert W, Spies CD, et al. Acute respiratory failure after aspiration of activated charcoal with recurrent deposition and release from an intrapulmonary cavern. Intensive Care Med. 2009 Feb;35(2):360–3.  
69. Caravati EM, Knight HH, Linscott MS, Stringham JC. Esophageal laceration and charcoal mediastinum complicating gastric lavage. J Emerg Med. 2001;20(3):273–6.  
70. Graff. Chronic lung disease after activated charcoal aspiration. 2002;109(5).  
71. De Weerdt A, Snoeckx A, Germonpré P, Jorens PG. Rapid-onset adult respiratory distress syndrome after activated charcoal aspiration. A pitch-black tale of a potential to kill. Am J Respir Crit Care Med. 2015 Feb;191(3):344–5.  
72. Huber M, Pohl W, Reinisch G, Attems J, Pescosta S, Lintner F. Lung disease 35 years after aspiration of activated charcoal in combination with pulmonary lymphangioleiomyomatosis: A histological and clinicopathological study with scanning electron microscopic evaluation and element analysis. Virchows Arch. 2006;449(2):225– 9.  
73. Seder DB, Christman RA, Quinn MO, Knauft ME. Case Reports A 45-Year-Old Man With a Lung Mass and History of Charcoal Aspiration. 2006;1251–4.  
74. George. Contaminated Commerical Charcoal.pdf. 1991.  
75. McKinney PE, Phillips S, Gomez HF, Brent J. Corneal abrasions secondary to activated charcoal. Am J Emerg Med. 1993 Sep;11(5):562.  
76. Boyd R, Hanson J. Prospective single blinded randomised controlled trial of two orally administered activated charcoal preparations. J Accid Emerg Med. 1999;16(1):24–5.  
77. Crockett R, Krishel SJ, Manoguerra A, Williams SR, Clark RF. Prehospital use of activated charcoal: A pilot study. J Emerg Med. 1996;14(3):335–8.  
78. Merigian. Prospective evaluation of gastric emptying in the self-poisoned patients. 1990.  
79. Chyka PA, Seger D, Krenzelok EP, Vale JA, American Academy of Clinical Toxicology, European Association of Poisons Centres and Clinical Toxicologists. Position paper: Single-dose activated charcoal. Clin Toxicol (Phila). 2005;43(2):61–87.  
80. Li Y, Tse ML, Gawarammana I, Buckley N, Eddleston M. Systematic review of controlled clinical trials of gastric lavage in acute organophosphorus pesticide poisoning. Clin Toxicol Philadelphia Pa. 2009;47(3):179–92.  
81. Andrews M. Outcome of Patients with Cholinergic Insecticide Poisoning Treated with Gastric Lavage: A Prospective Observational Cohort Study. Asia Pacific J Med Toxicol. 2014;3(4):146–51.  
82. Li Y, Yu X, Wang Z, Wang H, Zhao X, Cao Y, et al. Gastric lavage in Acute organophosphorus pesticide poisoning (GLAOP) - A randomised controlled trial of multiple vs. single gastric lavage in unselected acute organophosphorus pesticide  
31  
poisoning. BMC Emerg Med. 2006;6:1–7.  
83. Mendonca S, Gupta S, Gupta A. Extracorporeal management of poisonings. Saudi J Kidney Dis Transplant. 2012;23(1):1.  
84. Liang MJ, Zhang Y. Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in the treatment of acute severe organophosphorus pesticide poisoning. Genet Mol Res. 2015;14(2):4914–9.  
85. Li Z, Wang G, Zhen G, Zhang Y, Liu J, Liu S. Application of hemoperfusion in severe acute organophosphorus pesticide poisoning. Turkish J Med Sci. 2017;47(4):1277–81.  
86. Hu SL, Wang D, Jiang H, Lei QF, Zhu XH, Cheng JZ. Therapeutic effectiveness of sustained low-efficiency hemodialysis plus hemoperfusion and continuous hemofiltration plus hemoperfusion for acute severe organophosphate poisoning. Artif Organs. 2014;38(2):121–4.  
87. Dong H, Weng YB, Zhen GS, Li FJ, Jin AC, Liu J, et al. Clinical emergency treatment of 68 critical patients with severe organophosphorus poisoning and prognosis analysis after rescue. Med (United States). 2017;96(25):9–12.  
88. Ghannoum M, Gosselin S. Enhanced poison elimination in critical care. Adv Chronic Kidney Dis. 2013;20(1):94–101.  
89. Pichamuthu K, Jerobin J, Nair A, John G, Kamalesh J, Thomas K, et al. Bioscavenger therapy for organophosphate poisoning an open-labeled pilot randomized trial comparing fresh frozen plasma or albumin with saline in acute organophosphate poisoning in humans. Clin Toxicol. 2010;48(8):813–9.  
90. Bao H-X, Tong P-J, Li C-X, Du J, Chen B-Y, Huang Z-H, et al. Efficacy of fresh packed red blood transfusion in organophosphate poisoning. Medicine (Baltimore). 2017;96(11):e6375.  
91. Chowdhary S, Bhattacharyya R, Banerjee D. Acute organophosphorus poisoning. Clin Chim Acta. 2014;431:66–76.  
92. Omoike OE, Lewis RC, Meeker JD. Association between urinary biomarkers of exposure to organophosphate insecticides and serum reproductive hormones in men from NHANES 1999-2002. Reprod Toxicol. 2015;  
93. Connors NJ, Harnett ZH, Hoffman RS. Comparison of Current Recommended Regimens of Atropinization in Organophosphate Poisoning. J Med Toxicol. 2014;10(2):143–7.  
94. Abedin MJ, Sayeed AA, Basher A, Maude RJ, Hoque G, Faiz MA. Open-Label Randomized Clinical Trial of Atropine Bolus Injection Versus Incremental Boluses Plus Infusion for Organophosphate Poisoning in Bangladesh. J Med Toxicol. 2012;8(2):108– 17.  
95. Liu H-X, Liu C-F, Yang W-H. Clinical study of continuous micropump infusion of atropine and pralidoxime chloride for treatment of severe acute organophosphorus insecticide poisoning. J Chinese Med Assoc. 2015;78(12):709–13.  
96. Eddleston M, Chowdhury FR. Pharmacological treatment of organophosphorus insecticide poisoning: The old and the (possible) new. Br J Clin Pharmacol. 2016;81(3):462–70.  
97. Konickx LA, Bingham K, Eddleston M. Is oxygen required before atropine administration in organophosphorus or carbamate pesticide poisoning?-A cohort study. Clin Toxicol. 2014;52(5):531–7.  
98. Buckley NA, Eddleston M, Li Y, Bevan M, Robertson J. Oximes for acute organophosphate pesticide poisoning. Cochrane Database Syst Rev [Internet]. 2011;(2). Available from: http://doi.wiley.com/10.1002/14651858.CD005085.pub2  
32  
99. BRASIL M da S. Relação Nacional de Medicamentos Essenciais. 2017. 1-12 p.  
100.  Banerjee I, Roy As, Tripathi S. Efficacy of pralidoxime in organophosphorus poisoning: Revisiting the controversy in Indian setting. J Postgrad Med [Internet]. 2014;60(1):27. Available from: http://www.jpgmonline.com/text.asp?2014/60/1/27/128803  
101.  Eddleston M, Eyer P, Worek F, Juszczak E, Alder N, Mohamed F, et al. Pralidoxime in acute organophosphorus insecticide poisoning - A randomised controlled trial. PLoS Med. 2009;6(6).  
102.  Cherian MA, Roshini C, Visalakshi J, Jeyaseelan L, Cherian AM. Biochemical and clinical profile after organophosphorus poisoning--a placebo-controlled trial using pralidoxime. J Assoc Physicians India. 2005;53:427–31.  
103.  Wani T, Gurcoo S, Farooqui A, Nisa W, Sofi K, Syed S. Is the World Health Organization-recommended dose of pralidoxime effective in the treatment of organophosphorus poisoning? A randomized, double-blinded and placebo-controlled trial. Saudi J Anaesth [Internet]. 2015;9(1):49. Available from: http://www.saudija.org/text.asp?2015/9/1/49/146306  
104.  Konickx LA, Worek F, Jayamanne S, Thiermann H, Buckley NA, Eddleston M. Reactivation of plasma butyrylcholinesterase by pralidoxime chloride in patients poisoned by WHO class II toxicity organophosphorus insecticides. Toxicol Sci. 2013;136(2):274–83.  
105.  Marrs TC. Diazepam in the treatment of organophosphorus ester pesticide poisoning. Toxicol Rev. 2003;22(2):75–81.  
106.  Singh G, Avasthi G, Khurana D, Whig J, Mahajan R. Neurophysiological monitoring of pharmacological manipulation in acute organophosphate (OP) poisoning. The effects of pralidoxime, magnesium sulphate and pancuronium. Electroencephalogr Clin Neurophysiol. 1998;107(2):140–8.  
107.  Pajoumand A, Shadńia S, Rezaie A, Abdi M, Abdollahi M. Benefits of magnesium sulfate in the management of acute human poisoning by organophosphorus insecticides. Hum Exp Toxicol. 2004;23(12):565–9.  
108.  Colômbia M de la PS. Guía de Atención Integral de Salud Ocupacional Basada en la Evidencia para Trabajadores Expuestos a Plaguicidas Inhibidores de la Colinestarasa (Organofosforados y Carbamatos). Social C de la P, editor. Bogotá; 2008.  
109.  Emerick GL, Deoliveira GH, Dos Santos AC, Ehrich M. Mechanisms for consideration for intervention in the development of organophosphorus-induced delayed neuropathy. Chem Biol Interact. 2012;199(3):177–84.  
110.  Davies R. Psychiatric aspects of chronic exposure to organophosphates: diagnosis and management. Adv Psychiatr Treat [Internet]. 2000;6(5):356–61. Available from: http://apt.rcpsych.org/cgi/doi/10.1192/apt.6.5.356  
111.  M. AHMED AND DR DAVIES G. Chronic organophosphate exposure: towards the definition of a neuropsychiatric syndrome. J Nutr Environ Med. 1997;7(3):169–76.  
112.  Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 5/2017. 5 Brasília; 2017.  
113.  Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 4/2017. Ministério da Saúde, Gabinete do Ministro, Brasília, DF, Brasil Brasília; 2017 p. 288p.  
114.  Ministério da Saúde; Secretaria de Atenção Básica; Departamento de Atenção Básica. Procedimentos 30 30. 2011. 65 p.  
33  
34

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
35  
**Anexo 2A: Escala para avaliação da gravidade de intoxicações em crianças e adultos.**  
||**_Nenhum_**<br>**_0_**|**_Leve_**<br>**_1_**|**_Moderada_**<br>**_2_**|**_Grave_**<br>**_3_**|**_Fatal_**<br>**_4_**|
|---|---|---|---|---|---|
|**_Órgão/Sistema_**|**_Nenhum_**<br>**_sinal ou_**<br>**_sintoma_**|**_Sinais ou Sintomas leves,_**<br>**_autoresolutivos ou_**<br>**_transitórios_**|**_Sinais ou sintomas_**<br>**_pronunciados ou prolongados_**|**_Sinais e sintomas que_**<br>**_ameaçam a vida do paciente_**|**_Morte_**|
|_Gastrintestinal_||_Vômito, diarreia, dor_<br>_Irritação, queimaduras de 1º_<br>_grau_<br>_Pequenas ulcerações na_<br>_boca_<br>**_Endoscopia_**_: eritema, edema_|_Vômito pronunciado ou_<br>_prolongado, diarreia, dor_<br>_Queimaduras de 1º grau de_<br>_localização crítica ou_<br>_Queimaduras de 2º e 3º graus_<br>_em  áreas retritas_<br>_Disfagia_<br>**_Endoscopia_**_: lesões_<br>_transmucosa ulcerativa_|_Hemorragia maciça,_<br>_perfuração_<br>_Queimaduras de 2º e 3º graus_<br>_mais disseminadas_<br>_Disfagia severa_<br>**_Endoscopia_**_: lesões_<br>_transmurais ulcerativas, lesões_<br>_circunferenciais, perfurações._||
|_Respiratório_||_Irritação, tosse, falta de ar,_<br>_dispneia leve,_<br>_broncoespasmo leve_<br>**_Radiografia de tórax_**_:_<br>_anormalidades menores ou_<br>_sem sintomas._|_Tosse prolongada,_<br>_broncoespasmo, dispneia,_<br>_estridor, hipoxemia que requer_<br>_oxigenoterapia_<br>**_Radiografia de tórax_**_: anormal_<br>_com sintomas moderados._|_Insuficiência respiratória_<br>_manifesta (devido a, por_<br>_exemplo, broncoespasmo_<br>_grave, obstrução de via aérea,_<br>_edema glótico, SDRA,_<br>_pneumonite, pneumonia,_<br>_pneumotórax)_<br>**_Radiografia de tórax_**_: anormal_<br>_com sintomas severos_||
|_Nervoso_||_Sonolência, vertigem,_<br>_zumbido, ataxia, inquietação_<br>_Sintomas extrapiramidais_<br>_leves_<br>_Sintomas colinérgicos /_<br>_anticolinérgicos leves_<br>_Parestesia_<br>_Distúrbios visuais ou_<br>_auditivos leves_|_Inconsciência com resposta à_<br>_dor_<br>_Apneia breve, bradipneia_<br>_Confusão, agitação,_<br>_alucinações, delírio_<br>_Convulsões infrequentes,_<br>_generalizadas ou locais_<br>_Sintomas extrapiramidais_<br>_pronunciados_<br>_Sintomas colinérgicos /_<br>_anticolinérgicos pronunciados_<br>_Paralisia localizada que não_<br>_afeta a vitalidade funcional_<br>_Distúrbios visuais e auditivos_|<br>_Coma profundo com resposta_<br>_inadequada a dor ou não_<br>_responder à dor_<br>_Depressão respiratória com_<br>_insuficiência, extrema agitação_<br>_Convulsões freqüentes e_<br>_generalizadas, status_<br>_epilepticus, opistótono_<br>_Paralisia generalizada ou_<br>_paralisia afetando funções_<br>_vitais_<br>_Cegueira, surdez_||
|_Cardiovascular_||_Extrassístoles isoladas_<br>_Hipoglicemia/ hipertensão_<br>_leves e transitórias_|_Bradicardia sinusal (HR ~ 40-_<br>_50 em adultos, 60-80 em bebês_<br>_e crianças, 80-90 neonatos)_<br>_Taquicardia sinusal (HR ~_<br>_140-180 em adultos, 160-190_<br>_em bebês e crianças, 160-200_<br>_em neonatos)_<br>_Extrassístoles frequentes,_<br>_fibrilação atrial/ flutter,_<br>_bloqueio AV I-II, prolongado_<br>_QRS e QTc-time, anomalias de_<br>_repolarização_<br>_Isquemia miocárdica_<br>_Hipo / hipertensão mais_<br>_pronunciada_|_Bradicardia sinusal severa_<br>_(HR ~ <40 em adultos, <60 em_<br>_lactentes e crianças, <80 em_<br>_neonatos)_<br>_Taquicardia sinusal severa_<br>_(HR ~> 180 em adultos, > 190_<br>_em bebês e crianças, > 200 em_<br>_neonatos)_<br>_Disritmias ventriculares com_<br>_risco de vida, Bloqueio AV III,_<br>_assistolia_<br>_Infarto do miocárdio_<br>_Choque, crise hipertensiva_||
|_Metabolismo_||_Pequenas alterações ácido-_<br>_base (HCO3 ~ 15-20 ou 30-_<br>_40 mmol / l;pH ~ 7,25-7,32_<br>_ou 7,50-7,59)_<br>_Alterações eletrolíticas_<br>_discretas (K_<sup>_+_</sup>_3.0-3.4 ou 5.2-_<br>_5.9 mmol / l)_<br>_Hipoglicemia discreta (~ 50-_<br>_70 mg / dl ou 2,8-3,9 mmol /_<br>_l em adultos)_<br>_Hipertermia de curta_<br>_duração_|_Alterações ácido-base mais_<br>_pronunciadas (HCO3 ~ 10-14_<br>_ou> 40 mmol / l; pH ~ 7,15-_<br>_7,24 ou 7,60-7,69)_<br>_Alterações eletrolíticas_<br>_Eletrólito mais pronunciadas_<br>_(K_<sup>_+_</sup>_2.5-2.9 ou 6.0-6.9 mmol /_<br>_l)_<br>_Hipoglicemia mais_<br>_pronunciada (~ 30-50 mg / dl_<br>_ou 1,7-2,8 mmol / l em adultos)_<br>_Hipertermia de longa duração_|_Graves perturbações ácido-_<br>_base (HCO3 ~ <10 mmol / l;_<br>_pH ~ <7,15 ou> 7,7)_<br>_Distúrbios graves de_<br>_eletrólitos e fluidos (K_<sup>_+_</sup>_<2,5_<br>_ou> 7,0 mmol / l)_<br>_Hipoglicemia grave (~ <30 mg_<br>_/ dl ou   1,7 mmol / l em_<br>_adultos)_<br>_Hipo ou hipertermia perigosa_||
|_Fígado_||_Aumento discreto de enzimas_<br>_séricas_<br>_(ASAT, ALT ~ 2-5 x normal)_|<br>_Aumento das enzimas séricas_<br>_(ASAT, ALT~ 5-50 x normal)_<br>_mas nenhum diagnóstico_<br>_bioquímico (por exemplo,_<br>_amônia, fatores de_<br>_coagulação) ou evidência_<br>_clínica de disfunção_|_Aumento das enzimas séricas_<br>_(~> 50 x normal) ou_<br>_Bioquímica (por exemplo,_<br>_amônia, fatores de_<br>_coagulação) ou evidência_<br>_clínica de insuficiência_<br>_hepática_||  
36  
|_Rins_|_Discreta hematúria e_<br>_proteinúria_|_Proteinúria / hematúria_<br>_maciça_<br>_Insuficiência renal (por_<br>_exemplo, oligúria,_<br>_poliúria,creatinina sérica de ~_<br>_1,3 mg /dL)_|_Insuficiência renal (por_<br>_exemplo, anúria, creatinina_<br>_sérica> 1,6mg / dL)_|
|---|---|---|---|
|_Hematologia_|_Hemólise discreta_<br>_Metemoglobinemia discreta_<br>_(metHb ~ 10-30%)_|_Hemólise_<br>_Metahemoglobinemia mais_<br>_pronunciada (metHb ~ 30-_<br>_50%)_<br>_Distúrbios de coagulação sem_<br>_sangramento_<br>_Anemia, leucopenia,_<br>_trombocitopenia_|_Hemólise maciça_<br>_Metemoglobinemia grave_<br>_(metHb> 50%)_<br>_Distúrbios de coagulação com_<br>_sangramento_<br>_Anemia grave, leucopenia,_<br>_trombocitopenia._|
|_Sistema_<br>_Muscular_|_Dor leve, sensibilidade_<br>_CPK ~ 250-1.500 iu / l_|_Dor, rigidez, cólicas e_<br>_fasciculação_<br>_Rabdomiólise, CPK ~ 1.500-_<br>_10.000 iu / l_|_Dor intensa, extrema rigidez,_<br>_cólicas e fasciculação extensa_<br>_Rabdomiólise com_<br>_complicações, CPK~> 10.000_<br>_iu / l Síndrome compartimental_|
|_Pele_|_Irritação, queimaduras de 1º_<br>_grau(vermelhidão) ou_<br>_queimaduras de 2º grau_<br>_<10% da área da superfície_<br>_corporal_|_Queimaduras de 2º grau em_<br>_10-50% da superfície corporal_<br>_(crianças: 10-30%) ou 3º grau_<br>_em <2% da área da superfície_<br>_corporal_|_Queimaduras de 2º grau em>_<br>_50% da superfície corporal_<br>_(crianças:> 30%) ou_<br>_queimaduras de 3º grau > 2%_<br>_da área de superfície corporal_|
|_Olhos_|_Irritação, eritema,_<br>_lacrimejamento,_<br>_edema palpebral discreto_|_Irritação intensa, abrasão_<br>_corneana_<br>_Úlceras corneanas menores_<br>_(puntiformes)_|_Úlceras corneanas com_<br>_perfuração_<br>_Dano ocular permanente_|
|_Efeitos locais_<br>_de_<br>_picadas/ferrões_|_Prurido, ardor discreto, dor_<br>_leve_|_Edema envolvendo toda a_<br>_extremidade, necrose local e_<br>_dor moderada_|_Edema envolvendo toda a_<br>_extremidade e partes_<br>_significativas da área_<br>_adjacente ao local da picada,_<br>_necrose extensa_<br>_Edema de vias aéreas_<br>_Dor extrema_|  
_Fonte:_ Traduzido de _POISONING SEVERITY SCORE (PSS) IPCS/EAPCCT._  
_http://www.who.int/ipcs/poisons/pss.pdf_  
37  
**Anexo 2B: Escala de Paradeniya (Traduzidode Dubey, Yadav, & Kawre, 2016; Vernekar & Shivaraj, 2017).**  
|**Parâmetros**|**Critérios**|**Valor **|
|---|---|---|
||≥2 mm|0|
|**Tamanho da pupila**|<2 mm|1|
||puntiforme|2|
||<20/min|0|
|**Frequência respiratória**|≥20/min|1|
||≥20/mincomcianose|2|
||>60/min|0|
|**Frequência cardíaca**|41-60/min|1|
||<40/min|2|
||ausente|0|
|**Fasciculação**|Presente-generalizado**ou**contínuo|1|
||Presente-generalizado**e**contínuo|2|
||Consciente e racional|0|
|**Nível de consciência**|Respostaprejudicada ao comando verbal|1|
||Não há resposta ao comandoverbal|2|
|**Clõ**|Ausente|0|
|**onvuses**|Presente|1|
|**0-3**: intoxicação lev|e; **4-7**: intoxicação moderada; **8-11**: intoxicaçãograve||  
38

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
|||||**Pon**<br>|**tuação AP**<br>|**ACHE II**<br>|||||
|---|---|---|---|---|---|---|---|---|---|---|
|**E**|**FA**|**4**|**3**|**2**|**1**|**0**|**1**|**2**|**3**|**4**|
|**Treta**|**l(°C)**|>40,9|39-40,9||38,5-38,9|**0**|34-35,9|32-33,9|30-31,9|<30|
|**P**|**AM**|>159|130-<br>159|110-129||**70-109**||50-69||<50|
|**F**|**C**|>179|140-<br>179|110-129||**70-109**||55-69|40-54|<40|
|**F**|**R**|>49|35-49||25-34|**12-24**|10-11|6-9|||
|**Oxigenaçã**<br>**Se Fi**<br>**S Fi**|**o**<br>**O2≥0,5**<br>|>499|350-<br>499|200-349||**<200**|||||
|**e**|**2≤0,5**|||||**>70**|61-70||56-60|<56|
|**pH a**|**rterial**|>7,69|7,60-<br>7,69||7,50-7,59|**7,33-7,49**||7,25-7,32|7,15-7,24|<7,15|
|**Na (m**|**mol/L)**|>179|160-<br>179|155-159|150-154|**130-149**||120-129|111-119|<111|
|<br>**(mm**|**K**<br>**ol/L)**|>6,9|6,0-6,9||5,5-5,9|**3,5-5,4**|3,0-3,4|2,5-2,9||<2,5|
|**Creat**<br>**(mg**|**inina***<br>**/dL)**|>3,4|2-3,4|1,5-1,9||**0,6-1,4**||<0,6|||
|**Hemató**|**crito (%)**|>59,9||50-59,9|46-49,9|**30-45,9**||20-29,9||<20|
|**Leucócit**|**os (x1000)**|>39,9||20-39,9|15-19,9|**3-14,9**||1-2,9||<1|
|**Som**|**a APS**||||||||||
|**Total**<br>**APS**|||||||||||
|**Glasgow**|||||||||||
|**Idade**|**Pontuação**||||||||||
||||||Pontos|Pontos|Pontos||Pontos||
|**≤44**|**0**||**Doença**|**Crônica**|<br>EFA<br> (A)|<br>Glasgow<br>(B)|<br>Idade<br>(C)||<br>Doença Prévia<br> (D)||
|**45-54**|**2**||Pós-<br>|<br>|||||||
||||operatóri|o<br>2|||||||
|**55-64**|**3**||<br>programa|<br>do||**TOTAL DE**|**PONTOS (**|**A+B+C+D)**|||
|**65-74**|**5**||Pós-||**Doença Crô**<br>Cirrose Hep|**nica**:<br>ática, hiperten|são portal ou|episódio pré|vio de falência|hepática|
|**≥ 75**|**6**||operatóri<br>urgante|o<br> <br>5|Dispneia ou<br>hipertensão<br>tratamento i|angina (repou<br>pulmonar; Ins<br>munossupress|so) ;DPOC g<br>ufiência Ren<br>or|rave com hip<br>al Crônica; Im|ercapnia, polici<br>unodeficiência|temia ou<br>Crônica;|  
39

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
<!-- Start of picture text -->
= Suspeitadeintoxicag’opor SS<br>—_ agrotoxicos __<br>“Sintomatolo Sim Exposicéo. a<br>gia aguda aguda | ]<br>Nao /Use equipamentosde — /<br>| protecdo individual /<br>f<br>AvaliagSoclinicae / (EPI) |<br>examescomplementares | avaliag3o | /<br>eatendimentoou clinica inicial | Senecessio<br>encaminhamentode / / — unidadedemaiorencaminhar pare //<br>acordo com protocolos complexidade |<br>de cadaunidade l /<br>sim Ethel N30<br>Manter12 horas. sobConsiderarobservaciomedidas por6 a Suporte vital basico<br>de descontaminaczo° @ avancado<br>; . Descontaminagéo mucocuténea egastrica*, Eliminac300u<br>Estavel N&O Antidoto, de acordodo coma agente clinica dopacientee caracteristicas<br>e da exposicSo.<br>. Solicita¢do de examescomplementares,senecessario.<br>sim<br>Altaprevencoeacompanhamento ambulatorialpara Continuidade do atendimento de acordo com evolucgo:<br>sequelas. de novas intoxicacées, tratamento de dS e  alta,novasacompanhamento intoxicacées, tratamento ambulatorial de sequelas. para prevenco<br>Se tentative de suicidio, encaminharpara RAPS. Se tentativa de suicidio, encaminharparaRAPS.<br>| Priorize o suporte vital basico  proteja<br>| Ligue para o CIATox 0800 722 6001viaaéreapara emesclarecer pacientesas comindicacdes alteragdes deconsciéncia.dos métodos de | |<br>|| descontaminacaoeeliminac3o paracadasubstancia. ||<br>| *Em pacientes atendidos em até 60 minutos apés a exposicio, avaliando se os beneficios<br>teéricos superam os possiveis danos, garantindo a protegéo da via aérea. |<br>| 1. Considere lavagem géstrica quando houver ingesto de grande quantidade de agrotoxicos |<br>| altamente toxicos que no sejam diluidos em solventes organicse corrosivos. |<br>| 2. Considere utilizar uma dose tinica de carvlo ativado quando houver ingest3o de grande |<br>| quantidade de agrotéxicos altamente téxicosque s80 adsorvidospelcarvao ativad o . |<br>|<br>Notifique todos os casos, suspeitos ou confirmados, na ficha de intoxicacSoexogenadoSinan; |<br>| Notifique na ficha de Violéncia, se suspeita de maltrato, tentativa de suicidioouhomicidio; |<br>|| Preencha a ComunicagdoDeclarac&ode Acidentede obito dequando Trabalho,aplicavel.se exposi¢S0 ocupacional; | |<br>Ce<br><!-- End of picture text -->  
40

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
#### **Antes da realização dos procedimentos ora descritos, considere** :  
- a) A obrigatoriedade do uso de Equipamentos de Proteção Individual pela equipe de saúde;  
- b) O descarte adequado do material contaminado, considerando as rotinas estabelecidas na unidade e as normas de biossegurança vigentes.  
#### **<mark>Descontaminação Cutânea/Dérmica</mark>**<sup>10</sup>  
- Considerar cobrir ferimentos antes de iniciar a lavagem corporal;  
- Remover as vestes ou equipamentos contaminados, com especial cuidado para não agravar a contaminação de áreas corpóreas, em especial a face. Cortar as vestes é mais seguro;  
- Se o agente for pó ou sólido, retirar o excesso com pano seco ou compressa, antes de lavar;  
- Realizar lavagem da área afetada ou corporal com com água fria e sabão neutro, com especial atenção para cabelos, axilas, umbigo, região genital e subungueal. Não esfregar a pele com força.  
- Evitar hipotermia  
#### **Descontaminação dos Olhos**<sup>10</sup>  
- Na exposição ocular, lavar com água ou solução salina morna, com fluxo contínuo, com as pálpebras abertas, a partir do canto do olho (próximo ao nariz) para a lateral da face, por no mínimo, 20 minutos.  
- Pode ser usado colírio anestésico previamente para facilitar procedimento.  
- Se um único olho for acometido, lateralizar a cabeça mantendo para baixo o olho acometido para realizar a lavagem, evitando contaminar o olho sadio.  
- Se os dois olhos forem acometidos, lavá-los com fluxo contínuo de soro fisiológico ou água, do centro ou região entre os olhos para as laterais.  
- Proteja o restante da face com compressas.  
Uma forma improvisada que pode ser útil é a utilização de cateter para O2, tipo óculos, colocando a dupla saída sobre a parte superior do nariz, próxima ao canto dos olhos, mantendo uma saída de cada lado do nariz e direcionada para cada olho. Conecte o cateter a um frasco de SF e mantenha fluxo contínuo.  
#### **<mark>Lavagem Gástrica</mark>**<sup>114</sup>  
Colocar o paciente, preferencialmente, em decúbito lateral esquerdo com a cabeça em nível inferior ao corpo.  
Se possível, explicar ao paciente o procedimento. Pacientes comatosos devem ser intubados antes do procedimento. Medir o comprimento da sonda (lóbulo da orelha, ponta do nariz, apêndice xifoide) Colocar lidocaína gel na extremidade distal e na narina escolhida. Deve-se confirmar a presença da sonda para assegurar o posicionamento. Habitualmente, insufla-se ar por meio de uma seringa ao mesmo tempo em que se ausculta a região epigástrica.  
Em adultos, uma lavagem gástrica bemsucedida necessita de uma média de 6 a 8 litros de líquido (soro fisiológico ou água). Administram-se pequenas quantidades (máximo 250 ml/vez), visto que volumes maiores podem “empurrar” o toxicante para o duodeno.  
41  
Em crianças, utilizam-se 5-10 mL/kg até o máximo de 250 mL/ vez. Volume total usado em média para neonatos 500 mL; lactentes 2-3 L; escolares 4-5 L. Repete-se esse procedimento várias vezes (mínimo oito). O volume retornado sempre deve ser próximo ao volume ofertado e observar atentamente o conteúdo que retorna, na procura de restos do agente tóxico. Após cerca de 2.000 mLde líquido e esse retornando límpido, <u>pode-se parar o procedimento</u>  
#### **<mark>Carvão ativado</mark>**<sup>10</sup>  
- Separar a quantidade total a ser utilizada, sendo 1 g/Kg, no máximo 50 g;  
- Diluir na proporção de 8 mL de soro fisiológico ou água potável para cada grama do carvão ativado.  
- Introduzir a diluição pela SNG e anotar o horário;  
- Manter o paciente em decúbito lateral esquerdo com o objetivo de retardar o esvaziamento gástrico;  Após cerca de 30 minutos, esvaziar o estômago pela sonda nasogástrica;  
42

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
<!-- Start of picture text -->
Ale hina de expos e presence de<br>resco, hotest sudres, mio, bronco<br>Montoro<br>-sropna em bls de 6 93 m9<br>rrodomente 10<br>Dobra dose a ad S mn, até pacente ear atropnzndo<br>Feequtncncordocs sera ce 80 Spm<br>pres ater tien soma de 80 rg<br>Buseitogie re<br>Apso=pecans ropaexer requerdastopnando,adminsrr prs aropngarSo codaums infusb hors emV sugde 10-20% sanada0%dos ta<br>Tote<br>ropa<br>ouenun<br>‘© aumentarattecomesar a0 taxa paoente deas as infuseestardomesose em em om 20%atopoebolus por hora sm Tovodaterecorrentecolnergica usin« equcard,ds‘elino: snsiresinasea sm comasnenoamantecompara infusos por 30omain, eto dos 20%‘  menor<br><!-- End of picture text -->  
43

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
**<u>Nome do Paciente: Data de Nascimento:</u>**  
**Nº do prontuário:** Data e horário da admissão:  
#### **Horário do Início da administração de atropina** : ____________________  
#### **Dose inicial** : ______________  
|**Hora**|**Dose bolus**|**Ausculta**|**FC***|**PAS***|**T**|**Ruídos**|**Confusão**|**Tamanho**|**Axilas**|
|---|---|---|---|---|---|---|---|---|---|
||**(mg)**<br>**/infusão**<br>**(mg/h)**|**Pulmonar***<br>**(C/S/L)**|**(bpm)**|**(mmHg)**|**(°C)**|**Peristálticos**<br>**(A/R/N/Au)**|**mental**<br>**(S/N)**|**da pupila**|**secas**<br>**(S/N)**|  
C = creptação; S = sibilância; L= limpa; A = ausentes; R = reduzidos; N = normais; Au = aumentados; S= Sim, N= Não  
(*)Considerar como critérios de atropinização: FC > 80 bpm; PAS > 80 mm de Hg e Ausculta Pulmonar Limpa.  
44

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
**Quadro III.3.1.** Artigos resultantes da busca sistemática no site **Pubmed** , para as perguntas PICO sobre a intoxicação por inibidores de colinesterase e a análise de inclusão do artigo.  
#### **Busca - pergunta PICO 1 (22 resultados)**  
|**Busca**|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para**<br>**descarga**|
|---|---|---|---|---|---|
|1a|Developmental neurotoxicity of the organophosphorus insecticide<br>chlorpyrifos: from clinical findings to preclinical models and<br>potential mechanisms.|Burke RD, Todd SW, Lumsden E,<br>Mullins RJ, Mamczarz J, Fawcett<br>WP, Gullapalli RP, Randall WR,<br>Pereira EFR, Albuquerque EX|2017|Não é escopo|-|
|1a|Impairment of liver synthetic function and the production of<br>plasma proteins in primary breast cancer patients on<br>doxorubicincyclophosphamide (AC) protocol.|Saleem Z, Ahmad M, Hashmi FK,<br>Saeed H, Aziz MT.|2016|Não é escopo|-|
|1a|Outcome of patients supported by extracorporeal membrane<br>oxygenation for aluminum phosphide poisoning: An observational<br>study.|Mohan B, Singh B, Gupta V, Ralhan<br>S, Gupta D, Puri S, Goyal A, Aslam<br>N, Tandon R, Wander GS.|2016|Não é escopo|-|
|1a|Tipranavir/Ritonavir (500/200 mg and 500/100 mg) Was<br>Virologically Non-Inferior to Lopinavir/Ritonavir (400/100 mg)<br>at Week 48 in Treatment-Naïve HIV-1-Infected Patients: A<br>Randomized, Multinational, Multicenter Trial.|Cooper DA, Cordery DV, Zajdenverg<br>R, Ruxrungtham K, Arastéh K,<br>Bergmann F, Neto JL, Scherer J,<br>Chaves RL, Robinson P; studyteam.|2016|Não é escopo|-|
|1a|Home-based community health worker intervention to reduce<br>pesticide exposures to farmworkers'children: A**randomized-**<br>**controlled trial**.|Salvatore AL, Castorina R, Camacho<br>J, Morga N, López J, Nishioka M,<br>Barr DB, Eskenazi B, Bradman A.|2015|Não fala do<br>tratamento|-|  
45  
|1a|Efficacy and safety of pulse immunosuppressive**therapy**with<br>glucocorticoid and cyclophosphamide in patients with<br>paraquat**poisoning**: A**meta-analysis**.|He F, Xu P, Zhang J, Zhang Q, Gu S,<br>Liu Y, Wang J.|2015|Não é escopo|-|
|---|---|---|---|---|---|
||Clinical analysis of penehyclidine hydrochloride combined with|||||
|1a|hemoperfusion in the treatment of acute severe organophosphorus<br>pesticide**poisoning**.|Liang MJ, Zhang Y.|2015|**Sim**|Sim|
||Liver and renal safety of tenofovir disoproxil fumarate in|Mandala J, Nanda K, Wang M, De<br>Baetselier I Deese J Lombaard J||||
|1a|combination with emtricitabine among African women in a pre-<br>exposure prophylaxis trial.|,  ,  ,<br>Owino F, Malahleha M, Manongi R,<br>Taylor D, Van Damme L.|2014|Não é escopo|-|
||Safety and clinical activity of 5-aza-2'-deoxycytidine (decitabine)|Benton CB, Thomas DA, Yang H,<br>Ravandi F, Rytting M, O'Brien S,||||
|1a|with or without Hyper-CVAD in relapsed/refractory acute<br>lymphocytic leukaemia.|Franklin AR, Borthakur G, Dara S,<br>Kwari M, Pierce SR, Jabbour E,<br>Kantarjian H, Garcia-Manero G.|2014|Não é escopo|-|
||Utility of red blood cell acetylcholinesterase measurement in|||||
|1a|mechanically ventilated subjects after**organophosphate**<br>**poisoning**.|Moon J, Chun B.|2014|**Sim**|Sim|
|1a|Glucocorticoid with cyclophosphamide for paraquat-induced lung<br>fibrosis.|Li LR, Sydenham E, Chaudhary B,<br>Beecher D, You C.|2014|Não é escopo|Sim|
||Is oxygen required before atropine administration in|Kik LA Bih K Eddlt||||
|1a|organophosphorus or carbamate pesticide**poisoning**?-A cohort<br>study.|oncx , ngam , eson<br>M.|2014|**Sim**|Sim|
||Organophosphate-pyrethroid combination pesticides may be|Iyyadurai R, Peter JV, Immanuel S,||||
|1a|associated with increased toxicity in human**poisoning**compared<br>to either pesticide alone.|Begum A, Zachariah A, Jasmine S,<br>Abhilash KP.|2014|**Sim**|Sim|
|1a|A**systematic**review on the nerve-muscle electrophysiology in<br>human organophosphorus pesticide exposure.|Karami-Mohajeri S, Nikfar S,<br>Abdollahi M.|2014|Não fala do<br>tratamento|Sim|  
46  
|1a|Glucocorticoid with cyclophosphamide for paraquat-induced lung<br>fibrosis.|Li LR, Sydenham E, Chaudhary B,<br>You C.|2012|Não é escopo|Sim|
|---|---|---|---|---|---|
|1a|Cytisin amidophosphate--the new cytoprotector.|Zhumadilov Z, Nurgozhin T,<br>Gulyaev A, Zhaugasheva S,<br>Gazaliyev A, Ermekbayeva B,<br>Abuova G, KenessaryA.|2012|Não é escopo|-|
|1a|Clofarabine, cyclophosphamide and etoposide for the treatment of<br>relapsed or resistant acute leukemia in pediatric patients.|Miano M, Pistorio A, Putti MC,<br>Dufour C, Messina C, Barisone E,<br>Ziino O, Parasole R, Luciani M, Lo<br>Nigro L, De Rossi G, Varotto S,<br>Bertorello N, Petruzziello F, Calvillo<br>M, Micalizzi C.|2012|Não é escopo|-|
|1a|Liver toxicity of antiretroviral combinations including<br>fosamprenavir plus ritonavir 1400/100 mg once daily in<br>HIV/hepatitis C virus-coinfected patients.|Merchante N, López-Cortés LF,<br>Delgado-Fernández M, Ríos-Villegas<br>MJ, Márquez-Solero M, Merino D,<br>Pasquau J, García-Figueras C,<br>Martínez-Pérez MA, Omar M, Rivero<br>A, Macías J, Mata R, Pineda JA;<br>Grupo Andaluz para el Estudio de las<br>Hepatitis Vıricas (HEPAVIR) de la<br>Sociedad Andaluza de Enfermedades<br>Infecciosas (SAEI).|2011|Não é escopo|-|
|1a|A phase I trial of high-dose clofarabine, etoposide, and<br>cyclophosphamide and autologous peripheral blood stem cell<br>transplantation in patients with primary refractory and relapsed<br>and refractory non-Hodgkin lymphoma.|Srivastava S, Jones D, Wood LL,<br>Schwartz JE, Nelson RP Jr, Abonour<br>R, Secrest A, Cox E, Baute J,<br>Sullivan C, Kane K, Robertson MJ,<br>FaragSS.|2011|Não é escopo|-|  
47  
|1a|Randomized trial to compare LSA2L2-type maintenance**therapy**<br>to daily 6-mercaptopurine and weekly methotrexate with<br>vincristine and dexamethasone pulse for children with acute<br>lymphoblastic leukemia.|Nagatoshi Y, Matsuzaki A, Suminoe<br>A, Inada H, Ueda K, Kawakami K,<br>Yanai F, Nakayama H, Moritake H,<br>Itonaga N, Hotta N, Fujita K, Hidaka<br>Y, Yamanaka T, Kawano Y,<br>Okamura J.|2010|Não é escopo|<br>-|
|---|---|---|---|---|---|
||Glucocorticoid with cyclophosphamide for paraquat-induced lung|Li LR Sydenham E Chaudhary B||||
|1a|<br>fibrosis.|,  ,  ,<br>You C.|2010|Não é escopo|<br>Sim|
|1a|Timing and frequency of physostigmine redosing for<br>tiii tiit|Rosenbaum C, Bird SB.|2010|Não é escopo|<br>-|
||anmuscarnc oxcy.<br>**Busca - pergunta**|**PICO 2 (240 resultados)**||**Etd**|**Disponível**|
|**Busca**|**Título**|**Autor**|**Ano**|**suo**<br>**considerado**|**para**<br>**descarga**|
|2a|Developmental neurotoxicity of the organophosphorus insecticide<br>chlorpyrifos: from clinical findings to preclinical models and<br>potential mechanisms.|Burke RD, Todd SW, Lumsden E,<br>Mullins RJ, Mamczarz J, Fawcett<br>WP, Gullapalli RP, Randall WR,<br>Pereira EFR, Albuquerque EX|2017|Não é escopo<br>(Repetido)|-|
||Outcome of patients supported by extracorporeal membrane|Mohan B, Singh B, Gupta V, Ralhan||||
|2a|oxygenation for aluminum phosphide poisoning: An observational<br>study.|S, Gupta D, Puri S, Goyal A, Aslam<br>N, Tandon R, Wander GS.|2016|Não é escopo|-|
|2a|N-acetylcysteine in Acute Organophosphorus Pesticide Poisoning:<br>A Randomized, Clinical Trial.|El-Ebiary AA, Elsharkawy RE,<br>Soliman NA, Soliman MA, Hashem<br>AA.|2016|**Sim**|Sim|
||**Clinical study**of continuous micropump infusion|||||
|2a|of**atropine**and pralidoxime chloride for treatment of severe<br>acute organophosphorus insecticide poisoning.|Liu HX, Liu CF, Yang WH.|2015|**Sim**|Sim|  
48  
|2a|Clinical analysis of penehyclidine hydrochloride combined with<br>hemoperfusion in the treatment of acute severe organophosphorus<br>pesticide poisoning.|Liang MJ, Zhang Y.|2015|**Sim**<br>(Repetido)|Sim|
|---|---|---|---|---|---|
||An exploratory study; the therapeutic effects of premixed|||||
|2a|activated**charcoal**-sorbitol administration in patients poisoned<br>with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|**Sim**|Sim|
|2a|Is oxygen required before**atropine**administration in<br>organophosphorus or carbamate pesticide poisoning?-A cohort<br>study.|Konickx LA, Bingham K, Eddleston<br>M.|2014|**Sim**<br>(Repetido)|Sim|
|2a|Organophosphate-pyrethroid combination pesticides may be<br>associated with increased toxicity in human poisoning compared<br>to either pesticide alone.|Iyyadurai R, Peter JV, Immanuel S,<br>Begum A, Zachariah A, Jasmine S,<br>Abhilash KP.|2014|**Sim**<br>(Repetido)|Sim|
||Reactivation of plasma butyrylcholinesterase by pralidoxime|Konickx LA, Worek F, Jayamanne S,||||
|2a|chloride in patients poisoned by WHO class II toxicity<br>organophosphorus insecticides.|Thiermann H, Buckley NA,<br>Eddleston M.|2013|**Sim**|Sim|
|2a|Organophosphorus poisoning (acute).|Blain PG.|2011|**Sim**|Sim|
|2a|**Oximes**for acute organophosphate pesticide poisoning.|Buckley NA, Eddleston M, Li Y,<br>Bevan M, Robertson J.|2011|**Sim**|Sim|
|2a|Clinical and bioavailability studies of sublingually administered<br>**atropine**sulfate.|Rajpal S, Ali R, Bhatnagar A,<br>Bhandari SK, Mittal G.|2010|**Sim**|Sim|
|2b|Developmental neurotoxicity of the organophosphorus insecticide<br>chlorpyrifos: from clinical findings to preclinical models and<br>potential mechanisms.|Burke RD, Todd SW, Lumsden E,<br>Mullins RJ, Mamczarz J, Fawcett<br>WP, Gullapalli RP, Randall WR,<br>Pereira EFR, Albuquerque EX|2017|Não é escopo<br>(Repetido)|-|
|2b|Clinical emergency treatment of 68 critical patients with severe<br>organophosphorus poisoning and prognosis analysis after rescue.|Dong H, Weng YB, Zhen GS, Li FJ,<br>Jin AC, Liu J.|2017|**Sim**|Sim|
|2b|Early Response-Based**Therapy**Stratification Improves Survival<br>in Adult Early Thymic Precursor Acute Lymphoblastic Leukemia:|Bond J, Graux C, Lhermitte L, Lara<br>D, Cluzeau T, LeguayT, Cieslak A,|2017|Não é escopo|-|  
49  
||A Group for Research on Adult Acute Lymphoblastic Leukemia<br>Study.|Trinquand A, Pastoret C, Belhocine<br>M, Spicuglia S, Lheritier V, Leprêtre<br>S, Thomas X, Huguet F, Ifrah N,<br>Dombret H, Macintyre E, Boissel N,<br>Asnafi V.||||
|---|---|---|---|---|---|
|2b|Adding Celecoxib With or Without Zoledronic Acid for<br>Hormone-Naïve Prostate Cancer: Long-Term Survival Results<br>From an Adaptive, Multiarm, Multistage, Platform,**Randomized**<br>**Controlled Trial**.|Mason MD, Clarke NW, James ND,<br>Dearnaley DP, Spears MR, Ritchie<br>AWS, Attard G, Cross W, Jones RJ,<br>Parker CC, Russell JM, Thalmann<br>GN, Schiavone F, Cassoly E,<br>Matheson D, Millman R, Rentsch<br>CA, Barber J, Gilson C, Ibrahim A,<br>Logue J, Lydon A, Nikapota AD,<br>O'Sullivan JM, Porfiri E, Protheroe<br>A, Srihari NN, Tsang D, Wagstaff J,<br>Wallace J, Walmsley C, Parmar<br>MKB, Sydes MR; STAMPEDE<br>Investigators.|2017|Não é escopo|-|
|2b|Efficacy of fresh packed red blood transfusion<br>in**organophosphate poisoning**.|Bao HX, Tong PJ, Li CX, Du J, Chen<br>BY, HuangZH, WangY.|2017|**Sim**|Sim|
||A Comparative Study of Intravenous Injection Form and Oral|Kunisaki C, Tanaka Y, Kosaka T,<br>Miyamoto H, Sato S, Suematsu H,||||
|2b|Jelly Form of Alendronate Sodium Hydrate for Bone Mineral<br>Disorder after Gastrectomy.|Yukawa N, Sato K, Izumisawa Y,<br>Akiyama H, Taguri M, Yamanaka T,<br>Endo I.|2017|Não é escopo|-|
|2b|A comparison of sugammadex and neostigmine for reversal of<br>rocuronium-induced neuromuscular blockade in children.|Ammar AS, Mahmoud KM, Kasemy<br>ZA.|2017|Não é escopo|-|  
50  
|2b|Long-term Results of the Risk-adapted Treatment for Childhood<br>B-Cell Acute Lymphoblastic Leukemia: Report From the Japan<br>Association of Childhood Leukemia Study ALL-97 Trial.|Horibe K, Yumura-Yagi K, Kudoh T,<br>Nishimura S, Oda M, Yoshida M,<br>Komada Y, Hara J, Tawa A, Usami I,<br>Tanizawa A, Kato K, Kobayashi R,<br>Matsuo K, Hori H; Japan Association<br>of Childhood Leukemia Study<br>(JACLS), Japan.|2017|Não é escopo|-|
|---|---|---|---|---|---|
|2b|The effectiveness of patient-tailored treatment for<br>acute**organophosphate poisoning**.|Lin CC, Hung DZ, Chen HY, Hsu<br>KH.|2016|**Sim**|Sim|
|2b|Disease Systems Analysis of Bone Mineral Density and Bone<br>Turnover Markers in Response to Alendronate, Placebo, and<br>Washout in Postmenopausal Women.|Berkhout J, Stone JA, Verhamme<br>KM, Danhof M, Post TM.|2016|Não é escopo|-|
|2b|A Combined Intervention of**Zinc**, Multiple Micronutrients, and<br>Albendazole Does Not Ameliorate Environmental Enteric<br>Dysfunction or Stunting in Rural Malawian Children in a Double-<br>Blind**Randomized Controlled Trial**.|Wang AZ, Shulman RJ, Crocker AH,<br>Thakwalakwa C, Maleta KM,<br>Devaraj S, Manary MJ, Trehan I.|2016|Não é escopo|-|
|2b|High hyperdiploid acute lymphoblastic leukemia (ALL)-A 25-<br>year population-based survey of the Austrian ALL-BFM (Berlin-<br>Frankfurt-Münster) Study Group.|Reismüller B, Steiner M, Pichler H,<br>Dworzak M, Urban C, Meister B,<br>Schmitt K, Pötschger U, König M,<br>Mann G, Haas OA, Attarbaschi A;<br>Austrian ALL-BFM (Berlin-<br>Frankfurt-Münster) StudyGroup.|2016|Não é escopo|-|
|2b|Optimal anesthetic regimen for ambulatory laser microlaryngeal<br>surgery.|Huh H, Park SJ, Lim HH, Jung KY,<br>Baek SK, Yoon SZ, Lee HW, Lim<br>HJ, Cho JE.|2016|Não é escopo||
|2b|The effect of sugammadex on steroid hormones: A<br>randomized**clinical study**.|Gunduz Gul G, Ozer AB, Demirel I,<br>Aksu A, Erhan OL.|2016|Não é escopo|-|  
51  
|2b|Community acquired respiratory virus infections in cancer<br>patients-Guideline on diagnosis and management by the<br>Infectious Diseases Working Party of the German Society for<br>haematology and Medical Oncology.|von Lilienfeld-Toal M, Berger A,<br>Christopeit M, Hentrich M, Heussel<br>CP, Kalkreuth J, Klein M, Kochanek<br>M, Penack O, Hauf E, Rieger C,<br>Silling G, Vehreschild M, Weber T,<br>Wolf HH, Lehners N, Schalk E,<br>Mayer K.|2016|Não é escopo|-|
|---|---|---|---|---|---|
|2b|A phase III multicenter, randomized, controlled study of<br>combined androgen blockade with versus without zoledronic acid<br>in prostate cancer patients with metastatic bone disease: results of<br>the ZAPCA trial.|Kamba T, Kamoto T, Maruo S,<br>Kikuchi T, Shimizu Y, Namiki S,<br>Fujimoto K, Kawanishi H, Sato F,<br>Narita S, Satoh T, Saito H, Sugimoto<br>M, Teishima J, Masumori N, Egawa<br>S, Sakai H, Okada Y, Terachi T,<br>Ogawa O; ZAPCA StudyGroup.|2016|Não é escopo|-|
|2b|Anti-Dementia Drugs, Gait Performance and Mental Imagery of<br>Gait: A Non-Randomized Open-Label Trial.|Beauchet O, Barden J, Liu-Ambrose<br>T, Chester VL, Annweiler C, Szturm<br>T, Grenier S, Léonard G, Bherer L,<br>Allali G; Canadian Gait Consortium.|2016|Não é escopo|-|
|2b|Efficacy of Sofosbuvir, Velpatasvir, and GS-9857 in Patients<br>With Genotype 1 Hepatitis C Virus Infection in an Open-Label,<br>Phase 2 Trial.|Lawitz E, Reau N, Hinestrosa F,<br>Rabinovitz M, Schiff E, Sheikh A,<br>Younes Z, Herring R Jr, Reddy KR,<br>Tran T, Bennett M, Nahass R, Yang<br>JC, Lu S, Dvory-Sobol H, Stamm<br>LM, Brainard DM, McHutchison JG,<br>Pearlman B, Shiffman M, Hawkins<br>T, CurryM, Jacobson I.|2016|Não é escopo|-|
|2b|Efficacy of Sofosbuvir, Velpatasvir, and GS-9857 in Patients<br>With Hepatitis C Virus Genotype 2, 3, 4, or 6 Infections in an<br>Open-Label, Phase 2 Trial.|Gane EJ, Kowdley KV, Pound D,<br>Stedman CA, Davis M, Etzkorn K,<br>Gordon SC, Bernstein D, Everson G,|2016|Não é escopo|-|  
52  
|||Rodriguez-Torres M, Tsai N, Khalid<br>O, Yang JC, Lu S, Dvory-Sobol H,<br>Stamm LM, Brainard DM,<br>McHutchison JG, Tong M, Chung<br>RT, Beavers K, Poulos JE, Kwo PY,<br>Nguyen MH.||||
|---|---|---|---|---|---|
|2b|Metronomic cyclophosphamide**therapy**in hormone-naive<br>patients with non-metastatic biochemical recurrent prostate<br>cancer: a phase II trial.|Calcagno F, Mouillet G, Adotevi O,<br>Maurina T, Nguyen T, Montcuquet P,<br>Curtit E, Kleinclauss F, Pivot X,<br>BorgC, Thiery-Vuillemin A.|2016|Não é escopo|-|
||Outcome of patients supported by extracorporeal membrane|Mohan B, Singh B, Gupta V, Ralhan||||
|2b|oxygenation for aluminum phosphide poisoning:<br>An**observational study**.|S, Gupta D, Puri S, Goyal A, Aslam<br>N, Tandon R, Wander GS.|2016|Não é escopo|-|
|2b|Extended versus standard azathioprine maintenance**therapy**in<br>newly diagnosed proteinase-3 anti-neutrophil cytoplasmic<br>antibody-associated vasculitis patients who remain cytoplasmic<br>anti-neutrophil cytoplasmic antibody-positive after induction of<br>remission: a randomized**clinical trial**.|Sanders JS, de Joode AA, DeSevaux<br>RG, Broekroelofs J, Voskuyl AE, van<br>Paassen P, Kallenberg CG, Tervaert<br>JW, Stegeman CA.|2016|Não é escopo|-|
|2b|Efficacy of the Combination of Sofosbuvir, Velpatasvir, and the<br>NS3/4A Protease Inhibitor GS-9857 in Treatment-Naïve or<br>Previously Treated Patients With Hepatitis C Virus Genotype 1 or<br>3 Infections.|Gane EJ, Schwabe C, Hyland RH,<br>Yang Y, Svarovskaia E, Stamm LM,<br>Brainard DM, McHutchison JG,<br>Stedman CA.|2016|Não é escopo|-|
|2b|Pharmacokinetics of once-daily darunavir/ritonavir in HIV-1-<br>infected pregnant women.|Crauwels HM, Kakuda TN, Ryan B,<br>Zorrilla C, Osiyemi OO, Yasin S,<br>Brown K, Verboven P, Hillewaert V,<br>Baugh B.|2016|Não é escopo|-|  
53  
||Primary NK/T-cell lymphoma of the larynx: Report of 2 cases and<br>|Zhu SY, Yuan Y, Liu K, Zeng L,||||
|---|---|---|---|---|---|
|2b|review of the**English**-, Japanese-, and Chinese-language<br>literature.|<br>Zhou JM, Lu QH, Huang ZJ.|2016|Não é escopo|-|
|2b|Prognostic factors and risk stratification in patients with<br>castration-resistant prostate cancer receiving docetaxel-based<br>chemotherapy.|Yamashita S, Kohjimoto Y, Iguchi T,<br>Koike H, Kusumoto H, Iba A,<br>Kikkawa K, Kodama Y, Matsumura<br>N, Hara I.|2016|Não é escopo|-|
|2b|Low-Dose or High-Dose Rocuronium Reversed with Neostigmine<br>or Sugammadex for Cesarean Delivery Anesthesia: A<br>Randomized Controlled Noninferiority Trial of Time to Tracheal<br>Intubation and Extubation.|Stourac P, Adamus M, Seidlova D,<br>Pavlik T, Janku P, Krikava I, Mrozek<br>Z, Prochazka M, Klucka J, Stoudek<br>R, Bartikova I, Kosinova M, Harazim<br>H, Robotkova H, Hejduk K, Hodicka<br>Z, Kirchnerova M, Francakova J,<br>Obare Pyszkova L, Hlozkova J,<br>Sevcik P.|2016|Não é escopo|-|
|2b|A phase II study of everolimus (RAD001), an mTOR inhibitor<br>plus CHOP for newly diagnosed peripheral T-cell lymphomas.|Kim SJ, Shin DY, Kim JS, Yoon DH,<br>Lee WS, Lee H, Do YR, Kang HJ,<br>Eom HS, Ko YH, Lee SH, Yoo HY,<br>HongM, Suh C, Kim WS.|2016|Não é escopo|-|
|2b|Management of Neuropsychiatric Systemic Lupus Erythematosus:<br>Current Approaches and Future Perspectives.|Magro-Checa C, Zirkzee EJ,<br>Huizinga TW, Steup-Beekman GM.|2016|Não é escopo|-|
|2b|N-acetylcysteine in Acute Organophosphorus Pesticide Poisoning:<br>A Randomized,**Clinical Trial**.|El-Ebiary AA, Elsharkawy RE,<br>Soliman NA, Soliman MA, Hashem<br>AA.|2016|**Sim**<br>(Repetido)|Sim|
|2b|Anxiety, pain, and nausea during the treatment of standard-risk<br>childhood acute lymphoblastic leukemia: A prospective,<br>longitudinal study from the Children's Oncology Group.|Dupuis LL, Lu X, Mitchell HR, Sung<br>L, Devidas M, Mattano LA Jr,<br>Carroll WL, Winick N, Hunger SP,<br>MaloneyKW, Kadan-Lottick NS.|2016|Não é escopo|-|  
54  
|2b|Extrapyramidal effects of acute**organophosphate poisoning**.|Reji KK, Mathew V, Zachariah A,<br>Patil AK, Hansdak SG, Ralph R,<br>Peter JV.|2016|**Sim**|Sim|
|---|---|---|---|---|---|
|2b|Glycemic Status in Organophosphorus Poisoning.|Panda S, Nanda R, Mangaraj M,<br>Rathod PK, Mishra PK.|2015|**Sim**||
|2b|[Clinical**practice guideline**for ANCA-associated vasculitis with<br>renal involvement].|Vazquez V, Fayad A, González G,<br>Smuclir Quevedo A, Robaina Sindín<br>J; Consejo de Glomerulopatías de la<br>Asociación Nefrológica de Buenos<br>Aires, Sociedad Argentina de<br>Nefrología.|2015|Não é escopo|-|
||Effects of Fresh Yellow Onion Consumption on CEA, CA125 and|Jafarpour-Sadegh F, Montazeri V,||||
|2b|Hepatic Enzymes in Breast Cancer Patients: A Double-Blind<br>Randomized Controlled**Clinical Trial**.|Adili A, Esfehani A, Rashidi MR,<br>Mesgari M, Pirouzpanah S.|2015|Não é escopo|-|
|2b|Clinical outcomes of treatment of anti-neutrophil cytoplasmic<br>antibody (ANCA)-associated vasculitis based on ANCA type.|Unizony S, Villarreal M, Miloslavsky<br>EM, Lu N, Merkel PA, Spiera R, Seo<br>P, Langford CA, Hoffman GS,<br>Kallenberg CM, St Clair EW, Ikle D,<br>Tchao NK, Ding L, Brunetta P, Choi<br>HK, Monach PA, Fervenza F, Stone<br>JH, Specks U; RAVE-ITN Research<br>Group.|2016|Não é escopo|-|
|2b|Risk Model-Guided Antiemetic Prophylaxis vs Physician's Choice<br>in Patients Receiving Chemotherapy for Early-Stage Breast<br>Cancer: A Randomized**Clinical Trial**.|Clemons M, Bouganim N, Smith S,<br>Mazzarello S, Vandermeer L, Segal<br>R, Dent S, Gertler S, Song X,<br>Wheatley-Price P, Dranitsaris G.|2016|Não é escopo|-|  
55  
|2b|**Clinical study**of continuous micropump infusion<br>of**atropine**and pralidoxime chloride for treatment of severe<br>acute organophosphorus insecticide poisoning.|Liu HX, Liu CF, Yang WH.|2015|**Sim**<br>(Repetido)|Sim|
|---|---|---|---|---|---|
|2b|Validation of contemporary guidelines for bone scintigraphy in<br>prostate cancer staging: A prospective study in patients<br>undergoing radical prostatectomy.|Zacho HD, Barsi T, Mortensen JC,<br>Bertelsen H, Petersen LJ.|2016|Não é escopo|-|
|2b|Clinical Efficacy and Safety Comparison of 177Lu-EDTMP with<br>153Sm-EDTMP on an Equidose Basis in Patients with Painful<br>Skeletal Metastases.|Thapa P, Nikam D, Das T, Sonawane<br>G, Agarwal JP, Basu S.|2015|Não é escopo|-|
|2b|**Systematic**Review of Diffuse Alveolar Hemorrhage in Systemic<br>Lupus Erythematosus: Focus on Outcome and**Therapy**.|Ednalino C, Yip J, Carsons SE.|2015|Não é escopo|-|
|2b|Is a New Protocol for Acute Lymphoblastic Leukemia Research<br>or Standard**Therapy**?|Dekking SA, van der Graaf R, de<br>Vries MC, Bierings MB, van Delden<br>JJ, Kodish E, Lantos JD.|2015|Não é escopo|-|
|2b|A Phase 1 Randomized, Blinded Comparison of the<br>Pharmacokinetics and Colonic Distribution of Three Candidate<br>Rectal Microbicide Formulations of Tenofovir 1% Gel with<br>Simulated Unprotected Sex (CHARM-02).|Hiruy H, Fuchs EJ, Marzinke MA,<br>Bakshi RP, Breakey JC, Aung WS,<br>Manohar M, Yue C, Caffo BS, Du Y,<br>Abebe KZ, Spiegel HM, Rohan LC,<br>McGowan I, Hendrix CW.|2015|Não é escopo|-|
|2b|ANCA positive crescentic glomerulonephritis outcome in a<br>Central East European cohort: a retrospective study.|Andreiana I, Stancu S, Avram A,<br>Taran L, Mircescu G.|2015|Não é escopo|-|
||The effect of routine reversal of neuromuscular blockade on|||||
|2b|adequacy of recurrent laryngeal nerve stimulation during thyroid<br>surgery.|Marshall SD, Boden E, Serpell J.|2015|Não é escopo|-|
||Preclinical and first-in-human evaluation of PRX-105, a|Atsmon J, Brill-Almon E, Nadri-<br>Sha C Chertkoff R Alon S||||
|2b|PEGylated, plant-derived, recombinant human<br>acetylcholinesterase-R.|y ,  ,  ,<br>Shaikevich D, Volokhov I, Haim KY,<br>Bartfeld D, Shulman A, Ruderfer I,|2015|Não é escopo|-|  
56  
|||Ben-Moshe T, Shilovitzky O, Soreq<br>H, Shaaltiel Y.||||
|---|---|---|---|---|---|
|2b|Bone turnover markers in Paget's disease of the bone:<br>A**Systematic**review and**meta-analysis**.|Al Nofal AA, Altayar O, BenKhadra<br>K, Qasim Agha OQ, Asi N, Nabhan<br>M, ProkopLJ, Tebben P, Murad MH.|2015|Não é escopo|-|
|2b|Clinical analysis of penehyclidine hydrochloride combined with<br>hemoperfusion in the treatment of acute severe organophosphorus<br>pesticide poisoning.|Liang MJ, Zhang Y.|2015|**Sim**<br>(Repetido)|Sim|
|2b|Pharmacologic prevention and treatment of delirium in intensive<br>care patients: A**systematic**review.|Serafim RB, Bozza FA, Soares M, do<br>Brasil PE, Tura BR, Ely EW, Salluh<br>JI.|2015|Não é escopo|-|
|2b|**Plasma**and Intracellular Pharmacokinetics of Tenofovir<br>Disoproxil Fumarate 300 mg Every 48 Hours vs 150 mg Once<br>Daily in HIV-Infected Adults With Moderate Renal Function<br>Impairment.|ressey TR, Avihingsanon A, Halue<br>G, Leenasirimakul P, Sukrakanchana<br>PO, Tawon Y, Jaisieng N, Jourdain<br>G, Podany AT, Fletcher CV,<br>Klinbuayaem V, Bowonwatanuwong<br>C.|2015|Não é escopo|-|
|2b|Effects of Emtricitabine/Tenofovir on Bone Mineral Density in<br>HIV-Negative Persons in a Randomized, Double-Blind, Placebo-<br>Controlled Trial.|Mulligan K, Glidden DV, Anderson<br>PL, Liu A, McMahan V, Gonzales P,<br>Ramirez-Cardich ME,<br>Namwongprom S, Chodacki P, de<br>Mendonca LM, Wang F, Lama JR,<br>Chariyalertsak S, Guanira JV,<br>Buchbinder S, Bekker LG, Schechter<br>M, Veloso VG, Grant RM;<br>Preexposure Prophylaxis Initiative<br>StudyTeam.|2015|Não é escopo|-|  
57  
|2b|Fosfomycin versus meropenem in bacteraemic urinary tract<br>infections caused by extended-spectrum β-lactamase-producing<br>Escherichia coli (FOREST): study protocol for an investigator-<br>driven randomised controlled trial.|Rosso-Fernández C, Sojo-Dorado J,<br>Barriga A, Lavín-Alconero L,<br>Palacios Z, López-Hernández I,<br>Merino V, Camean M, Pascual A,<br>Rodríguez-Baño J; FOREST Study<br>Group.|2015|Não é escopo|-|
|---|---|---|---|---|---|
|2b|A Phase I/II Trial of BNC105P with Everolimus in Metastatic<br>Renal Cell Carcinoma.|Pal S, Azad A, Bhatia S, Drabkin H,<br>Costello B, Sarantopoulos J,<br>Kanesvaran R, Lauer R, Starodub A,<br>Hauke R, Sweeney CJ, Hahn NM,<br>Sonpavde G, Richey S, Breen T,<br>Kremmidiotis G, Leske A, Doolin E,<br>Bibby DC, Simpson J, Iglesias J,<br>Hutson T.|2015|Não é escopo|-|
|2b|Outcomes of nonsevere relapses in antineutrophil cytoplasmic<br>antibody-associated vasculitis treated with glucocorticoids.|Miloslavsky EM, Specks U, Merkel<br>PA, Seo P, Spiera R, Langford CA,<br>Hoffman GS, Kallenberg CG, St<br>Clair EW, Tchao NK, Ding L, Iklé D,<br>Villareal M, Lim N, Brunetta P,<br>Fervenza FC, Monach PA, Stone JH;<br>Rituximab in ANCA-Associated<br>Vasculitis-Immune Tolerance<br>Network Research Group.|2015|Não é escopo|-|
|2b|Pharmacological interventions for pain in children and<br>adolescents with life-limiting conditions.|Beecham E, Candy B, Howard R,<br>McCulloch R, Laddie J, Rees H,<br>Vickerstaff V, Bluebond-Langner M,<br>Jones L.|2015|Não é escopo|-|
|2b|Long-term results of the AIEOP LNH-97 protocol for childhood<br>lymphoblastic lymphoma.|Pillon M, Aricò M, Mussolin L,<br>Carraro E, Conter V, Sala A,|2015|Não é escopo|-|  
58  
|||Buffardi S, Garaventa A, D'Angelo<br>P, Lo Nigro L, Santoro N, Piglione<br>M, Lombardi A, Porta F, Cesaro S,<br>Moleti ML, Casale F, Mura R,<br>d'Amore ES, Basso G, Rosolen A.||||
|---|---|---|---|---|---|
||Safety and immunogenicity of a modified vaccinia Ankara-based|Mothe B, Climent N, Plana M, Rosàs<br>M, Jiménez JL, Muñoz-Fernández<br>MÁ, Puertas MC, Carrillo J,<br>Gonzalez N, León A, Pich J, Arnaiz<br>JA, Gatell JM, Clotet B, Blanco J,<br>Alcamí J, Martinez-Picado J,||||
|2b|HIV-1 vaccine (MVA-B) in HIV-1-infected patients alone or in<br>combination with a drug to reactivate latent HIV-1.|Alvarez-Fernández C, Sánchez-<br>Palomino S, Guardo AC, Peña J,<br>Benito JM, Rallón N, Gómez CE,<br>Perdiguero B, García-Arriaza J,<br>Esteban M, López Bernaldo de<br>Quirós JC, Brander C, García F;<br>RISVAC-03 StudyGroup.|2015|Não é escopo|-|
|2b|Steady-state pharmacokinetics of rilpivirine under different meal<br>conditions in HIV-1-infected Ugandan adults.|Lamorde M, Walimbwa S, Byakika-<br>Kibwika P, Katwere M, Mukisa L,<br>Sempa JB, Else L, Back DJ, Khoo<br>SH, MerryC.|2015|Não é escopo|-|
|2b|Lenalidomide and cyclophosphamide immunoregulation in<br>patients with metastatic, castration-resistant prostate cancer.|Wang J, McGuire TR, Britton HC,<br>Schwarz JK, Loberiza FR Jr, Meza<br>JL, Talmadge JE.|2015|Não é escopo|-|
|2b|An exploratory study; the therapeutic effects of premixed<br>activated**charcoal**-sorbitol administration in patients poisoned<br>with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|**Sim**<br>(Repetido)|Sim|  
59  
||Antiviral activity and CSF concentrations of 600/100 mg of|Di Yacovo MS, Moltó J, Ferrer E,<br>Curran A, Else L, Gisslén M, Clotet||||
|---|---|---|---|---|---|
|2b|darunavir/ritonavir once daily in HIV-1 patients with**plasma**viral<br>suppression.|B, Tiraboschi JM, Niubò J, Vila A,<br>Zetterberg H, Back D, Podzamczer<br>D.|2015|Não é escopo|-|
|2b|Randomized intubation with polyurethane or conical cuffs to<br>prevent pneumonia in ventilated patients.|Philippart F, Gaudry S, Quinquis L,<br>Lau N, Ouanes I, Touati S, Nguyen<br>JC, Branger C, Faibis F, Mastouri M,<br>Forceville X, Abroug F, Ricard JD,<br>Grabar S, Misset B; TOP-Cuff Study<br>Group.|2015|Não é escopo|-|
|2b|Tenofovir**plasma**concentrations related to estimated glomerular<br>filtration rate changes in first-line regimens in African HIV-<br>infected patients: ANRS 12115 DAYANA substudy.|Lê MP, Landman R, Koulla-Shiro S,<br>Charpentier C, Sow PS, Diallo MB,<br>Ngom Gueye NF, Ngolle M, Le<br>Moing V, Eymard-Duvernay S,<br>Benalycherif A, Delaporte E, Girard<br>PM, Peytavin G; DAYANA Study<br>Group.|2015|Não é escopo|-|
|2b|No relationship between drug transporter genetic variants and<br>tenofovir**plasma**concentrations or changes in glomerular<br>filtration rate in HIV-infected adults.|Sirirungsi W, Urien S, Harrison L,<br>Kamkon J, Tawon Y, Luekamlung N,<br>Thongpaen S, Nilmanat A, Jourdain<br>G, Lallemant M, Le Coeur S, Ngo-<br>Giang-Huong N, Owen A, Cressey<br>TR.|2015|Não é escopo|-|
|2b|Application of the perineal ostomy in severe organophosphate<br>poisoned patients after catharsis.|Zhang DM, Xiao Q.|2014|**Sim**|Sim|  
60  
|2b|Reduced darunavir dose is as effective in maintaining HIV<br>suppression as the standard dose in virologically suppressed HIV-<br>infected patients: a randomized**clinical trial**.|Moltó J, Valle M, Ferrer E, Domingo<br>P, Curran A, Santos JR, Mateo MG,<br>Di Yacovo MS, Miranda C,<br>Podzamczer D, Clotet B; DRV600<br>StudyGroup.|2015|Não é escopo|-|
|---|---|---|---|---|---|
|2b|[Latrepirdine: a**systematic**review of the preclinical studies].|Cano-Cuenca N, Solís-García del<br>Pozo J, Jordán J.|2015|Não é escopo|-|
|2b|Drug resistance and**plasma**viral RNA level after ineffective use<br>of oral pre-exposure prophylaxis in women.|Grant RM, Liegler T, Defechereux P,<br>Kashuba AD, Taylor D, Abdel-<br>Mohsen M, Deese J, Fransen K, De<br>Baetselier I, Crucitti T, Bentley G,<br>Agingu W, Ahmed K, Damme LV.|2015|Não é escopo|-|
||Bone-related Parameters are the Main Prognostic Factors for|Fizazi K, Massard C, Smith M, Rader<br>M, Brown J, Milecki P, Shore N,||||
|2b|Overall Survival in Men with Bone Metastases from Castration-<br>resistant Prostate Cancer.|Oudard S, Karsh L, Carducci M,<br>Damião R, Wang H, Ying W, Goessl<br>C.|2014|Não é escopo|-|
|2b|Topotecan combined with Ifosfamide, Etoposide, and L-<br>asparaginase (TIEL) regimen improves outcomes in aggressive T-<br>cell lymphoma.|Shao Y, Guan M, Chen S, Jia N,<br>Wang Y.|2014|Não é escopo|-|
|2b|Young patients with non-germinal center B-cell-like diffuse large<br>B-cell lymphoma benefit from intensified chemotherapy with<br>ACVBP plus rituximab compared with CHOP plus rituximab:<br>analysis of data from the Groupe d'Etudes des Lymphomes de<br>l'Adulte/lymphoma study association phase III trial LNH 03-2B.|Molina TJ, Canioni D, Copie-<br>Bergman C, Recher C, Brière J,<br>Haioun C, Berger F, Fermé C, Copin<br>MC, Casasnovas O, Thieblemont C,<br>Petrella T, Leroy K, Salles G, Fabiani<br>B, Morschauser F, Mounier N,<br>Coiffier B, Jardin F, Gaulard P, Jais<br>JP, TillyH.|2014|Não é escopo|-|  
61  
|2b|Effect of rivastigmine or memantine add-on**therapy**is affected<br>by**butyrylcholinesterase**genotype in patients with probable<br>Alzheimer's disease.|Han HJ, Kwon JC, Kim JE, Kim SG,<br>Park JM, Park KW, Park KC, Park<br>KH, Moon SY, Seo SW, Choi SH,<br>Cho SJ.|2014|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Significance of baseline bone markers on disease progression and<br>survival in hormone-sensitive prostate cancer with bone<br>metastasis.|Nozawa M, Hara I, Matsuyama H,<br>Iki M, Nagao K, Nishioka T, Komura<br>T, Esa A, Uejima S, Imanishi M,<br>Uekado Y, Ogawa T, Kajikawa H,<br>Uemura H.|2014|Não é escopo|-|
||Increased post-induction intensification improves outcome in<br>children and adolescents with a markedly elevated white blood|Hastings C, Gaynon PS, Nachman||||
|2b|cell count (≥200 × 10(9) /l) with T cell acute lymphoblastic<br>leukaemia but not B cell disease: a report from the Children's<br>Oncology Group.|JB, Sather HN, Lu X, Devidas M,<br>Seibel NL.|2014|Não é escopo|-|
|2b|Docetaxel with or without zoledronic acid for castration-resistant<br>prostate cancer.|Pan Y, Jin H, Chen W, Yu Z, Ye T,<br>ZhengY, WengZ, WangF.|2014|Não é escopo|-|
|||Griz L, Fontan D, Mesquita P,<br>Lazaretti-Castro M, Borba VZ,||||
|2b|Diagnosis and management of Paget's disease of bone.|Borges JL, Fontenele T, Maia J,<br>Bandeira F; Brazilian Society of<br>Endocrinologyand Metabolism.|2014|Não é escopo|-|
|2b|Differential subcutaneous adipose tissue gene expression patterns<br>in a randomized**clinical trial**of efavirenz or lopinavir-ritonavir in<br>antiretroviral-naive patients.|Egaña-Gorroño L, Martínez E,<br>Domingo P, Loncà M, Escribà T,<br>Fontdevila J, Vidal F, Negredo E,<br>Gatell JM, Arnedo M.|2014|Não é escopo|-|
||Short-term androgen suppression and radiotherapy versus|Denham JW, Joseph D, Lamb DS,||||
|2b|intermediate-term androgen suppression and radiotherapy, with or<br>without zoledronic acid, in men with locally advanced prostate|Spry NA, Duchesne G, Matthews J,<br>Atkinson C, Tai KH, Christie D,|2014|Não é escopo|-|  
62  
||cancer (TROG 03.04 RADAR): an open-label, randomised, phase<br>3 factorial trial.|Kenny L, Turner S, Gogna NK,<br>Diamond T, Delahunt B, Oldmeadow<br>C, Attia J, Steigler A.||||
|---|---|---|---|---|---|
|2b|Association among duration of mechanical ventilation, cuff<br>material of endotracheal tube, and postoperative nosocomial<br>pneumonia in cardiac surgical patients: a prospective study.|Poelaert J, Haentjens P, Blot S.|2014|Não é escopo|-|
|2b|Zoledronic acid improves clinical outcomes in patients with bone<br>metastatic hormone-naïve prostate cancer in a multicenter**clinical**<br>**trial**.|Okegawa T, Higaki M, Matsumoto T,<br>Kase H, Murata A, Noda K, Noda H,<br>Asaoka H, Oshi M, Tomoishi J,<br>Uchida H, Higashihara E, Nutahara<br>K; Bone Metastasis Prostate Cancer<br>Group.|2014|Não é escopo|-|
|2b|Augmented post-remission**therapy**for a minimal residual<br>disease-defined high-risk subgroup of children and young people<br>with clinical standard-risk and intermediate-risk acute<br>lymphoblastic leukaemia (UKALL 2003): a randomised<br>controlled trial.|Vora A, Goulden N, Mitchell C,<br>Hancock J, Hough R, Rowntree C,<br>Moorman AV, Wade R.|2014|Não é escopo|-|
||A phase I-II study of the histone deacetylase inhibitor vorinostat|Tu Y, Hershman DL, Bhalla K,<br>Fiskus W, Pellegrino CM,<br>Andreopoulou E, Makower D,||||
|2b|plus sequential weekly paclitaxel and doxorubicin-<br>cyclophosphamide in locally advanced breast cancer.|Kalinsky K, Fehn K, Fineberg S,<br>Negassa A, Montgomery LL,<br>Wiechmann LS, Alpaugh RK, Huang<br>M, Sparano JA.|2014|Não é escopo|-|
|2b|Utility of red blood cell acetylcholinesterase measurement in<br>mechanically ventilated subjects after**organophosphate**<br>**poisoning**.|Moon J, Chun B.|2014|**Sim**<br>(Repetido)|Sim|  
63  
|2b|Association between alendronate, serum alkaline phosphatase<br>level, and heterotopic ossification in individuals with spinal cord<br>injury.<br>|Ploumis A, Donovan JM, Olurinde<br>MO, Clark DM, Wu JC, Sohn DJ,<br>O'Connor KC.|2014|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Midtreatment¹⁸F-FDG PET/CT Scan for Early Response<br>Assessment of SMILE**Therapy**in Natural Killer/T-Cell<br>Lymphoma: A Prospective Study from a Single Center.|Khong PL, Huang B, Lee EY, Chan<br>WK, Kwong YL.|2014|Não é escopo|-|
|2b|Is oxygen required before**atropine**administration in<br>organophosphorus or carbamate pesticide poisoning?-A cohort<br>study.|Konickx LA, Bingham K, Eddleston<br>M.|2014|**Sim**<br>(Repetido)|Sim|
|2b|Fracture prediction after discontinuation of 4 to 5 years of<br>alendronate**therapy**: the FLEX study.|Bauer DC, Schwartz A, Palermo L,<br>Cauley J, Hochberg M, Santora A,<br>Cummings SR, Black DM.|2014|Não é escopo|-|
||Bone density and bone turnover marker monitoring after|||||
|2b|discontinuation of alendronate**therapy**: an evidence-based<br>decision to do less.|Gourlay ML, Ensrud KE.|2014|Não é escopo|-|
|2b|Organophosphate-pyrethroid combination pesticides may be<br>associated with increased toxicity in human poisoning compared<br>to either pesticide alone.|Iyyadurai R, Peter JV, Immanuel S,<br>Begum A, Zachariah A, Jasmine S,<br>Abhilash KP.|2014|**Sim**<br>(Repetido)|Sim|
|2b|Curative effect of combined lamivudine, adefovir dipivoxil, and<br>stem cell transplantation on decompensated hepatitis B cirrhosis.|Liu L, Yan Y, Zhou J, Huang LW,<br>He CP, Ling K, Zhou HC, Wen QM,<br>WangXM.|2014|Não é escopo|-|
||Prevention of bone metastases in patients with high-risk|Wirth M, Tammela T, Cicalese V,<br>Gomez Veiga F, Delaere K, Miller K,||||
|2b|nonmetastatic prostate cancer treated with zoledronic acid:<br>efficacy and safety results of the Zometa European Study (ZEUS).|Tubaro A, Schulze M, Debruyne F,<br>Huland H, Patel A, Lecouvet F, Caris<br>C, Witjes W.|2014|Não é escopo|-|
|2b|Efficacy of pralidoxime in organophosphorus poisoning:<br>revisiting the controversy in Indian setting.|Banerjee I, Tripathi SK, Roy AS.|2014|**Sim**|Sim|  
64  
|2b|MASCC/ISOO clinical practice guidelines for the management of<br>mucositis secondary to cancer**therapy**.|Lalla RV, Bowen J, Barasch A,<br>Elting L, Epstein J, Keefe DM,<br>McGuire DB, Migliorati C,<br>Nicolatou-Galitis O, Peterson DE,<br>Raber-Durlacher JE, Sonis ST, Elad<br>S; Mucositis Guidelines Leadership<br>Group of the Multinational<br>Association of Supportive Care in<br>Cancer and International Society of<br>Oral Oncology(MASCC/ISOO).|2014|Não é escopo|-|
|---|---|---|---|---|---|
|2b|High-circulating Tie2 Is Associated With Pathologic Complete<br>Response to Chemotherapy and Antiangiogenic**Therapy**in<br>Breast Cancer.|Makhoul I, Griffin RJ, Siegel E, Lee<br>J, Dhakal I, Raj V, Jamshidi-Parsian<br>A, Klimberg S, Hutchins LF,<br>Kadlubar S.|2016|Não é escopo|-|
|2b|Zoledronic acid treatment for cancerous bone metastases: a phase<br>IV study in Taiwan.|Chiang PH, Wang HC, Lai YL, Chen<br>SC, Yen-Hwa W, Kok CK, Ou YC,<br>HuangJS, HuangTC, Chao TY.|2013|Não é escopo|-|
|2b|Factors associated with bisphosphonate treatment failure in<br>postmenopausal women with primary osteoporosis.|Cairoli E, Eller-Vainicher C, Ulivieri<br>FM, Zhukouskaya VV, Palmieri S,<br>Morelli V, Beck-Peccoz P, Chiodini<br>I|2014|Não é escopo|-|
|2b|A prospective study of anxiety, depression, and behavioral<br>changes in the first year after a diagnosis of childhood acute<br>lymphoblastic leukemia: a report from the Children's Oncology<br>Group.|.<br>Myers RM, Balsamo L, Lu X,<br>Devidas M, Hunger SP, Carroll WL,<br>Winick NJ, Maloney KW, Kadan-<br>Lottick NS.|2014|Não é escopo|-|
|2b|**Zinc**or albendazole attenuates the progression of environmental<br>enteropathy: a**randomized controlled trial**.|Ryan KN, Stephenson KB, Trehan I,<br>Shulman RJ, Thakwalakwa C,<br>MurrayE, Maleta K, ManaryMJ.|2014|Não é escopo|-|  
65  
|2b|Bone turnover markers and pharmacokinetics of a new sustained-<br>release formulation of the cathepsin K inhibitor, ONO-5334, in<br>healthy post-menopausal women.|Nagase S, Ohyama M, Hashimoto Y,<br>Small M, Sharpe J, Manako J,<br>Kuwayama T, Deacon S.|2014|Não é escopo|-|
|---|---|---|---|---|---|
|2b|A randomized double-blind placebo-controlled dose-escalation<br>phase 1 study of aerosolized amikacin and fosfomycin delivered<br>via the PARI investigational eFlow® inline nebulizer system in<br>mechanically ventilated patients.|Montgomery AB, Vallance S, Abuan<br>T, Tservistas M, Davies A.|2014|Não é escopo|-|
|2b|Effects of switching from efavirenz to raltegravir on endothelial<br>function, bone mineral metabolism, inflammation, and renal<br>function: a randomized, controlled trial.|Gupta SK, Mi D, Moe SM, Dubé<br>MP, Liu Z.|2013|Não é escopo|-|
|2b|Pharmacodynamics of**cholinesterase inhibitors**suggests add-<br>on**therapy**with a low-dose carbamylating inhibitor in patients on<br>long-term treatment with rapidly reversible inhibitors.|Darreh-Shori T, Hosseini SM,<br>Nordberg A.|2014|Não é escopo|-|
||Failure to suppress markers of bone turnover on first-line|Hahn NM, Yiannoutsos CT,||||
|2b|hormone**therapy**for metastatic prostate cancer is associated with<br>shorter time to skeletal-related event.|Kirkpatrick K, Sharma J, Sweeney<br>CJ.|2014|Não é escopo|-|
|2b|A Surgeon's guide to advances in the pharmacological<br>management of acute Charcot neuroarthropathy.|Al-Nammari SS, Timothy T, Afsie S.|2013|Não é escopo|-|
|2b|Effects of odanacatib on BMD and safety in the treatment of<br>osteoporosis in postmenopausal women previously treated with<br>alendronate: a randomized placebo-controlled trial.|Bonnick S, De Villiers T, Odio A,<br>Palacios S, Chapurlat R, DaSilva C,<br>Scott BB, Le Bailly De Tilleghem C,<br>LeungAT, Gurner D.|2013|Não é escopo|-|
|2b|Reactivation of**plasma** **butyrylcholinesterase**by pralidoxime<br>chloride in patients poisoned by WHO class II toxicity<br>organophosphorus insecticides.|Konickx LA, Worek F, Jayamanne S,<br>Thiermann H, Buckley NA,<br>Eddleston M.|2013|**Sim**<br>(Repetido)|Sim|
|2b|New pharmacological options for treating advanced Parkinson's<br>disease.|Devos D, Moreau C, Dujardin K,<br>Cabantchik I, Defebvre L, Bordet R.|2013|Não é escopo|-|  
66  
|2b|Pharmacodynamic study of disulfiram in men with non-metastatic|Schweizer MT, Lin J, Blackford A,<br>Bardia A, King S, Armstrong AJ,|2013|Não é escoo|-|
|---|---|---|---|---|---|
||recurrent prostate cancer.|Rudek MA, Yegnasubramanian S,<br>Carducci MA.||p||
|2b|Comparison of prophylactic effects of polyurethane cylindrical or<br>tapered cuff and polyvinyl chloride cuff endotracheal tubes on<br>ventilator-associated pneumonia.|Mahmoodpoor A, Peyrovi-far A,<br>Hamishehkar H, Bakhtyiari Z,<br>Mirinezhad MM, Hamidi M, Golzari<br>SE.|2013|Não é escopo|-|
|2b|Risedronate in children with osteogenesis imperfecta: a<br>randomised, double-blind, placebo-controlled trial.|Bishop N, Adami S, Ahmed SF,<br>Antón J, Arundel P, Burren CP,<br>Devogelaer JP, Hangartner T, Hosszú<br>E, Lane JM, Lorenc R, Mäkitie O,<br>Munns CF, Paredes A, Pavlov H,<br>Plotkin H, Raggio CL, Reyes ML,<br>Schoenau E, Semler O, Sillence DO,<br>Steiner RD.|2013|Não é escopo|-|
||Phase II trial of zoledronic acid combined with androgen-|Nozawa M, Inagaki T, Nagao K,<br>Nishioka T, Komura T, Esa A,||||
|2b|deprivation**therapy**for treatment-naïve prostate cancer with bone<br>metastasis.|Kitagawa M, Imanishi M, Uekado Y,<br>Ogawa T, Kajikawa H, Uejima S,<br>Matsuyama H, Hara I, Uemura H.|2014|Não é escopo|-|
||A negative feedback model for a mechanism based description of|||||
|2b|longitudinal observations. Application for bone turnover<br>biomarkers.|Boroujerdi MA, Schmidt S.|2013|Não é escopo|-|
||Effect of ONO-5334 on bone mineral density and biochemical|Eastell R, Nagase S, Small M,||||
|2b|markers of bone turnover in postmenopausal osteoporosis: 2-year<br>results from the OCEAN study.|Boonen S, Spector T, Ohyama M,<br>Kuwayama T, Deacon S.|2014|Não é escopo|-|  
67  
|2b|A randomized phase II trial evaluating different schedules of<br>zoledronic acid on bone mineral density in patients with prostate<br>cancer beginning androgen deprivation**therapy**.|Lang JM, Wallace M, Becker JT,<br>Eickhoff JC, Buehring B, Binkley N,<br>Staab MJ, Wilding G, Liu G,<br>MalkovskyM, McNeel DG.|2013|Não é escopo|-|
|---|---|---|---|---|---|
||A prospective phase II study of L-asparaginase-CHOP plus|Lin N, Song Y, Zheng W, Tu M, Xie||||
|2b|radiation in newly diagnosed extranodal NK/T-cell lymphoma,<br>nasal type.|Y, Wang X, Ping L, Ying Z, Zhang<br>C, DengL, Liu W, Zhu J.|2013|Não é escopo|-|
|2b|Early changes in 25-hydroxyvitamin D levels and bone markers<br>after monthly risedronate with cholecalciferol in Korean patients<br>with osteoporosis.|Chung HY, Koo J, Kwon SK, Kang<br>MI, Moon SH, Park JY, Shin CS,<br>Yoon BK, Yoon HK, Chang JS,<br>ChungYS, Park HM.|2013|Não é escopo|-|
|2b|Lineage classification of childhood acute lymphoblastic leukemia<br>according to the EGIL recommendations: results of the ALL-<br>BFM 2000 trial.|Ratei R, Schabath R, Karawajew L,<br>Zimmermann M, Möricke A,<br>Schrappe M, LudwigWD.|2013|Não é escopo|-|
|2b|Prediction of outcome by early response in childhood acute<br>lymphoblastic leukemia.|Möricke A, Lauten M, Beier R,<br>Odenwald E, Stanulla M,<br>Zimmermann M, Attarbaschi A,<br>Niggli F, Schrappe M.|2013|Não é escopo|-|
|2b|Effectiveness of therapeutic**plasma**exchange in patients with<br>intermediate syndrome due to organophosphate intoxication.|Yilmaz M, Sebe A, Ay MO,<br>Gumusay U, Topal M, Atli M, Icme<br>F, Satar S.|2013|**Sim**|Sim|
|2b|Impact of PTEN protein expression on benefit from adjuvant<br>trastuzumab in early-stage human epidermal growth factor<br>receptor 2-positive breast cancer in the North Central Cancer<br>Treatment Group N9831 trial.|Perez EA, Dueck AC, McCullough<br>AE, Chen B, Geiger XJ, Jenkins RB,<br>Lingle WL, Davidson NE, Martino S,<br>Kaufman PA, Kutteh LA, Sledge<br>GW, Harris LN, Gralow JR, Reinholz<br>MM.|2013|Não é escopo|-|  
68  
|2b|Single dose pharmacokinetics of oral tenofovir in**plasma**,<br>peripheral blood mononuclear cells, colonic tissue, and vaginal<br>tissue.|Louissaint NA, Cao YJ, Skipper PL,<br>Liberman RG, Tannenbaum SR,<br>Nimmagadda S, Anderson JR, Everts<br>S, Bakshi R, Fuchs EJ, Hendrix CW.|2013|Não é escopo|-|
|---|---|---|---|---|---|
||ERCC1/BRCA1 expression and gene polymorphisms as|Tiseo M, Bordi P, Bortesi B, Boni L,<br>Boni C, Baldini E, Grossi F, Recchia||||
|2b|prognostic and predictive factors in advanced NSCLC treated<br>with or without cisplatin.|F, Zanelli F, Fontanini G, Naldi N,<br>Campanini N, Azzoni C, Bordi C,<br>Ardizzoni A; Bio-FAST trialgroup.|2013|Não é escopo|-|
||Bronchodilation and safety of supratherapeutic doses of|||||
|2b|salbutamol or**ipratropium**bromide added to single dose<br>GSK961081 in patients with moderate to severe COPD.|Norris V, Ambery C.|2013|Não é escopo|-|
|2b|Polyurethane does not protect better than polyvinyl cuffed<br>tracheal tubes from microaspirations.|Bulpa P, Evrard P, Bouhon S,<br>Schryvers F, Jamart J, Michaux I,<br>Dive A, Vander Borght T, KrugB.|2013|Não é escopo|-|
|2b|Ten-year analysis of the prospective multicentre Chemo-N0 trial<br>validates American Society of Clinical Oncology (ASCO)-<br>recommended biomarkers uPA and PAI-1 for**therapy**decision<br>making in node-negative breast cancer patients.|Harbeck N, Schmitt M, Meisner C,<br>Friedel C, Untch M, Schmidt M,<br>Sweep CG, Lisboa BW, Lux MP,<br>Beck T, Hasmüller S, Kiechle M,<br>Jänicke F, Thomssen C; Chemo-N 0<br>StudyGroup.|2013|Não é escopo|-|
||Low dose chromium-polynicotinate or policosanol is effective in|Martino F, Puddu PE, Pannarale G,||||
|2b|hypercholesterolemic children only in combination with<br>glucomannan.|Colantoni C, Martino E, Niglio T,<br>Zanoni C, Barillà F.|2013|Não é escopo|-|
|2b|Is retention of zoledronic acid onto bone different in multiple<br>myeloma and breast cancer patients with bone metastasis?|Søe K, Plesner T, Jakobsen EH,<br>Hansen CT, Jørgensen HB, Delaissé<br>JM.|2013|Não é escopo|-|  
69  
|2b|High-risk childhood acute lymphoblastic leukemia in first<br>remission treated with novel intensive chemotherapy and<br>allogeneic transplantation.|Marshall GM, Dalla Pozza L, Sutton<br>R, Ng A, de Groot-Kruseman HA,<br>van der Velden VH, Venn NC, van<br>den Berg H, de Bont ES, Maarten<br>Egeler R, Hoogerbrugge PM,<br>Kaspers GJ, Bierings MB, van der<br>Schoot E, van Dongen J, Law T,<br>Cross S, Mueller H, de Haas V,<br>Haber M, Révész T, Alvaro F,<br>Suppiah R, Norris MD, Pieters R.|2013|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Treatment reduction for children and young adults with low-risk<br>acute lymphoblastic leukaemia defined by minimal residual<br>disease (UKALL 2003): a randomised controlled trial.|Vora A, Goulden N, Wade R,<br>Mitchell C, Hancock J, Hough R,<br>Rowntree C, Richards S.|2013|Não é escopo|-|
|2b|Anti-glomerular basement membrane antibody disease treated<br>with rituximab: A case-based review.|Syeda UA, Singer NG, Magrey M.|2013|Não é escopo|-|
||The use of olanzapine versus metoclopramide for the treatment of|||||
|2b|breakthrough chemotherapy-induced nausea and vomiting in<br>patients receiving highly emetogenic chemotherapy.|Navari RM, Nagy CK, Gray SE.|2013|Não é escopo|-|
|2b|Phase II study of**magnesium sulfate**in acute organophosphate<br>pesticide poisoning.|Basher A, Rahman SH, Ghose A,<br>Arif SM, Faiz MA, Dawson AH.|2013|**Sim**|Sim|
||Evolution of the evidence on the effectiveness and cost-|Hyde C, Peters J, Bond M, Rogers G,||||
|2b|effectiveness of acetylcholinesterase inhibitors and memantine for<br>Alzheimer's disease:**systematic**review and economic model.|Hoyle M, Anderson R, Jeffreys M,<br>Davis S, Thokala P, Moxham T.|2013|Não é escopo|-|
|2b|High-dose calcitriol, docetaxel and zoledronic acid in patients<br>with castration-resistant prostate cancer: a phase II study.|Shamseddine A, Farhat FS, Elias E,<br>Khauli RB, Saleh A, Bulbul MA.|2013|Não é escopo|-|
|2b|Midterm outcome of risedronate**therapy**for patients with Paget's<br>disease of bone in the central part of Japan.|Nishida Y, Yamada Y, Tsukushi S,<br>Sugiura H, Urakawa H, Ishiguro N.|2013|Não é escopo|-|  
70  
|2b|A randomized phase I study of methanesulfonyl fluoride, an<br>irreversible cholinesterase inhibitor, for the treatment of<br>Alzheimer's disease.|Moss DE, Fariello RG, Sahlmann J,<br>Sumaya I, Pericle F, Braglia E.|2013|Não é escopo|-|
|---|---|---|---|---|---|
|2b|The clinical significance of NOTCH1 and SF3B1 mutations in the<br>UK LRF CLL4 trial.|Oscier DG, Rose-Zerilli MJ,<br>Winkelmann N, Gonzalez de Castro<br>D, Gomez B, Forster J, Parker H,<br>Parker A, Gardiner A, Collins A,<br>Else M, Cross NC, Catovsky D,<br>Strefford JC.|2013|Não é escopo|-|
|2b|Oral alendronate can suppress bone turnover but not fracture in<br>kidney transplantation recipients with hyperparathyroidism and<br>chronic kidney disease.|Yamamoto S, Suzuki A, Sasaki H,<br>Sekiguchi-Ueda S, Asano S, Shibata<br>M, Hayakawa N, Hashimoto S,<br>Hoshinaga K, Itoh M.|2013|Não é escopo|-|
|2b|No reduction in circulating preosteoclasts 18 months after<br>treatment with zoledronate: analysis from a randomized placebo<br>controlled trial.|Dalbeth N, Pool B, Stewart A, Horne<br>A, House ME, Cornish J, Reid IR.|2013|Não é escopo|-|
|2b|Ketamine combinations for the field treatment of soman-induced<br>self-sustaining status epilepticus. Review of current data and<br>perspectives.|Dorandeu F, Barbier L, Dhote F,<br>Testylier G, Carpentier P.|2013|Não é escopo|-|
||A phase 3, double-blind, randomised, parallel-group, placebo-<br>controlled study of oral weekly alendronate for the prevention of|Klotz LH, McNeill IY, Kebabdjian||||
|2b|androgen deprivation bone loss in nonmetastatic prostate cancer:<br>the Cancer and Osteoporosis Research with Alendronate and<br>Leuprolide (CORAL) study.|M, Zhang L, Chin JL; Canadian<br>Urology Research Consortium.|2013|Não é escopo|-|
|2b|Multitargeted tyrosine kinase inhibition produces discordant<br>changes between 99mTc-MDP bone scans and other disease<br>biomarkers: analysis of a phase II study of sunitinib for metastatic<br>castration-resistant prostate cancer.|Saylor PJ, Mahmood U, Kunawudhi<br>A, Smith MR, Palmer EL,<br>Michaelson MD.|2012|Não é escopo|-|  
71  
|2b|The effect of the combination of bisphosphonates and<br>conventional chemotherapy on bone metabolic markers in<br>multiple myeloma patients.|Zhang X, Chang C, Zhao Y, Wu L,<br>Zhang Z, Li X.|2012|Não é escopo|-|
|---|---|---|---|---|---|
||Comparison of oral**midazolam**with oral tramadol, triclofos and|||||
|2b|zolpidem in the sedation of pediatric dental patients: an in vivo<br>study.|Bhatnagar S, Das UM, Bhatnagar G.|2012|Não é escopo|-|
|2b|No additional benefit of adding ifosfamide to docetaxel in<br>castration-resistant metastatic prostate cancer.|Hervonen P, Tulijoki T, Kellokumpu-<br>Lehtinen P.|2012|Não é escopo|-|
|2b|What is the role of hyperbaric oxygen in the management of<br>bisphosphonate-related osteonecrosis of the jaw: a**randomized**<br>**controlled trial**of hyperbaric oxygen as an adjunct to surgery<br>and antibiotics.|Freiberger JJ, Padilla-Burgos R,<br>McGraw T, Suliman HB, Kraft KH,<br>Stolp BW, Moon RE, Piantadosi CA.|2012|Não é escopo|-|
||Randomised phase II/III study of docetaxel with or without|Meulenbeld HJ, van Werkhoven ED,<br>Coenen JL, Creemers GJ, Loosveld||||
|2b|risedronate in patients with metastatic Castration Resistant<br>Prostate Cancer (CRPC), the Netherlands Prostate Study (NePro).|OJ, de Jong PC, Ten Tije AJ, Fosså<br>SD, Polee M, Gerritsen W, Dalesio<br>O, de Wit R.|2012|Não é escopo|-|
||Pretreatment EBV-DNA copy number is predictive of response|Ito Y, Kimura H, Maeda Y,<br>Hashimoto C, Ishida F, Izutsu K,<br>Fukushima N, Isobe Y, Takizawa J,||||
|2b|and toxicities to SMILE chemotherapy for extranodal NK/T-cell<br>lymphoma, nasal type.|Hasegawa Y, Kobayashi H, Okamura<br>S, Kobayashi H, Yamaguchi M,<br>Suzumiya J, Hyo R, Nakamura S,<br>Kawa K, Oshimi K, Suzuki R.|2012|Não é escopo|-|
|2b|A combination of galantamine and memantine modifies cognitive<br>function in subjects with amnestic MCI.|Peters O, Lorenz D, Fesche A,<br>Schmidtke K, Hüll M, Perneczky R,<br>Rüther E, Möller HJ, Jessen F, Maier<br>W, Kornhuber J, Jahn H, Luckhaus|2012|Não é escopo|-|  
72  
|||C, Gertz HJ, Schröder J, Pantel J,<br>Teipel S, Wellek S, Frölich L, Heuser<br>I.||||
|---|---|---|---|---|---|
|2b|Prostate-specific antigen kinetics and outcomes in patients with<br>bone metastases from castration-resistant prostate cancer treated<br>with or without zoledronic acid.|Saad F, Segal S, Eastham J.|2014|Não é escopo|-|
|2b|Successful treatment of calcific uraemic arteriolopathy with<br>bisphosphonates.|Torregrosa JV, Durán CE, Barros X,<br>Blasco M, Arias M, Cases A,<br>Campistol JM.|2012|Não é escopo|-|
|2b|Neridronate improves bone mineral density and reduces back pain<br>in β-thalassaemia patients with osteoporosis: results from a phase<br>2, randomized, parallel-arm, open-label study.|Forni GL, Perrotta S, Giusti A,<br>Quarta G, Pitrolo L, Cappellini MD,<br>D'Ascola DG, Borgna Pignatti C,<br>Rigano P, Filosa A, Iolascon G,<br>Nobili B, Baldini M, Rosa A, Pinto<br>V, Palummeri E.|2012|Não é escopo|-|
|2b|Possible anti-tumor activity of initial treatment with zoledronic<br>acid with hormonal**therapy**for bone-metastatic prostate cancer<br>in multicenter**clinical trial**.|Uemura H, Yanagisawa M, Ikeda I,<br>Fujinami K, Iwasaki A, Noguchi S,<br>Noguchi K, Kubota Y; Yokohama<br>Bone Metastasis StudyGroup.|2013|Não é escopo|-|
|2b|Comparison of bone and renal effects in HIV-infected adults<br>switching to abacavir or tenofovir based**therapy**in a randomized<br>trial.|Rasmussen TA, Jensen D, Tolstrup<br>M, Nielsen US, Erlandsen EJ, Birn<br>H, Østergaard L, Langdahl BL,<br>Laursen AL.|2012|Não é escopo|-|
||Platelet-rich**plasma**improves wound healing in multiple|Coviello V, Peluso F, Dehkhargani||||
|2b|myeloma bisphosphonate-associated osteonecrosis of the jaw<br>patients.|SZ, Verdugo F, Raffaelli L,<br>Manicone PF, D' Addona A.|2012|Não é escopo|-|
|2b|Donepezil and memantine for moderate-to-severe Alzheimer's<br>disease.|Howard R, McShane R, Lindesay J,<br>Ritchie C, Baldwin A, Barber R,|2012|Não é escopo|-|  
73  
|||Burns A, Dening T, Findlay D,<br>Holmes C, Hughes A, Jacoby R,<br>Jones R, Jones R, McKeith I,<br>Macharouthu A, O'Brien J, Passmore<br>P, Sheehan B, Juszczak E, Katona C,<br>Hills R, Knapp M, Ballard C, Brown<br>R, Banerjee S, Onions C, Griffin M,<br>Adams J, Gray R, Johnson T,<br>Bentham P, Phillips P.||||
|---|---|---|---|---|---|
|2b|Open-label randomized**clinical trial**of**atropine**bolus injection<br>versus incremental boluses plus infusion for**organophosphate**<br>**poisoning**in Bangladesh.|Abedin MJ, Sayeed AA, Basher A,<br>Maude RJ, Hoque G, Faiz MA.|2012|**Sim**|Sim|
|2b|Prediction of outcome by early bone marrow response in<br>childhood acute lymphoblastic leukemia treated in the ALL-BFM<br>95 trial: differential effects in precursor B-cell and T-cell<br>leukemia.|Lauten M, Möricke A, Beier R,<br>Zimmermann M, Stanulla M,<br>Meissner B, Odenwald E, Attarbaschi<br>A, Niemeyer C, Niggli F, Riehm H,<br>Schrappe M.|2012|Não é escopo|-|
|2b|Bortezomib in combination with rituximab, dexamethasone,<br>ifosfamide, cisplatin and etoposide chemoimmunotherapy in<br>patients with relapsed and primary refractory diffuse large B-cell<br>lymphoma.|Elstrom RL, Andemariam B, Martin<br>P, Ruan J, Shore TB, Coleman M,<br>Leonard JP, Furman RR.|2012|Não é escopo|-|
|2b|Bisphosphonate treatment of postmenopausal osteoporosis is<br>associated with a dose dependent increase in serum sclerostin.|Gatti D, Viapiana O, Adami S,<br>Idolazzi L, Fracassi E, Rossini M.|2012|Não é escopo|-|
|2b|A**randomized controlled trial**of rituximab for the treatment of<br>severe cryoglobulinemic vasculitis.|De Vita S, Quartuccio L, Isola M,<br>Mazzaro C, Scaini P, Lenzi M,<br>Campanini M, Naclerio C, Tavoni A,<br>Pietrogrande M, Ferri C, Mascia MT,<br>Masolini P, Zabotti A, Maset M,|2012|Não é escopo|-|  
74  
|||Roccatello D, Zignego AL, Pioltelli<br>P, Gabrielli A, Filippini D, Perrella<br>O, Migliaresi S, Galli M,<br>Bombardieri S, Monti G.||||
|---|---|---|---|---|---|
|2b|Long-term outcomes of children and adolescents who had<br>cerebral palsy with secondary osteoporosis.|Iwasaki T, Nonoda Y, Ishii M.|2012|Não é escopo|-|
|2b|Anesthesia and myasthenia gravis.|Blichfeldt-Lauridsen L, Hansen BD.|2012|Não é escopo|-|
|2b|Evaluation of cardiovascular biomarkers in HIV-infected patients<br>switching to abacavir or tenofovir based**therapy**.|Rasmussen TA, Tolstrup M,<br>Melchjorsen J, Frederiksen CA,<br>Nielsen US, Langdahl BL,<br>Østergaard L, Laursen AL.|2011|Não é escopo|-|
|2b|CD24 Ala57Val polymorphism predicts pathologic complete<br>response to sequential anthracycline-and taxane-based<br>neoadjuvant chemotherapy for primary breast cancer.|Marmé F, Werft W, Walter A, Keller<br>S, Wang X, Benner A, Burwinkel B,<br>Sinn P, Hug S, Sohn C, Bretz N,<br>Moldenhauer G, Rupp C, Rupp AK,<br>Biakhov MY, Bottini A, Friedrichs<br>K, Khailenko VA, Manikhas GM,<br>Ruiz A, Sánchez-Rovira P, Santoro<br>A, Segui MA, Villena C, Lichter P,<br>Kristiansen G, Altevogt P,<br>Schneeweiss A.|2012|Não é escopo|-|
|2b|The potential value of monitoring bone turnover markers among<br>women on alendronate.|Bell KJ, Hayen A, Irwig L, Hochberg<br>MC, Ensrud KE, Cummings SR,<br>Bauer DC.|2012|Não é escopo|-|
|2b|Evidence-based treatments in pemphigus vulgaris and pemphigus<br>foliaceus.|Frew JW, Martin LK, Murrell DF.|2011|Não é escopo|-|  
75  
|2b|Low-density lipoprotein size and lipoprotein-associated<br>phospholipase A2 in HIV-infected patients switching to abacavir<br>or tenofovir.|Saumoy M, Ordoñez-Llanos J,<br>Martínez E, Barragán P, Ribera E,<br>Bonet R, Knobel H, Negredo E,<br>Loncá M, Curran A, Gatell JM,<br>Podzamczer D; Bicombo-met<br>SubstudyTeam.|2011|Não é escopo|-|
|---|---|---|---|---|---|
|2b|The safety and efficacy of early-stage bi-weekly alendronate to<br>improve bone mineral density and bone turnover in chinese post-<br>menopausal women at risk of osteoporosis.|You L, Sheng ZY, Chen JY, Pan L,<br>Chen L.|2011|Não é escopo|-|
||Greater responsiveness to donepezil in Alzheimer patients with|Kasuya M, Meguro K, Okamura N,||||
|2b|higher levels of acetylcholinesterase based on attention task<br>scores and a donepezil PET study.|Funaki Y, Ishikawa H, Tanaka N,<br>Iwata R, Yanai K.|2012|Não é escopo|-|
||Treatment of low-risk prostate cancer with radical|Koukourakis MI, Kyrgias G,<br>Papadopoulou A, Panteliadou M,||||
|2b|hypofractionated accelerated radiotherapy with cytoprotection<br>(HypoARC): an interim analysis of toxicity and efficacy.|Giatromanolaki A, Sivridis E,<br>Mavropoulou S, Kalogeris K, Nassos<br>P, Milioudis N, Touloupidis S.|2011|Não é escopo|-|
|2b|Continuous low-dose cyclophosphamide and methotrexate<br>combined with celecoxib for patients with advanced cancer.|Khan OA, Blann AD, Payne MJ,<br>Middleton MR, Protheroe AS, Talbot<br>DC, Taylor M, Kirichek O, Han C,<br>Patil M, Harris AL.|2011|Não é escopo|-|
|2b|Organophosphorus poisoning (acute).|Blain PG.|2011|**Sim**<br>(Repetido)|Sim|
||Significant and continuous improvement in bone mineral density|Elstein D, Foldes AJ, Zahrieh D,||||
|2b|among type 1 Gaucher disease patients treated with velaglucerase<br>alfa: 69-month experience, including dose reduction.|Cohn GM, Djordjevic M, Brutaru C,<br>Zimran A.|2011|Não é escopo|-|  
76  
|2b|Efficacy of risedronate with cholecalciferol on 25-hydroxyvitamin<br>D level and bone turnover in Korean patients with osteoporosis.|Chung HY, Chin SO, Kang MI, Koh<br>JM, Moon SH, Yoon BK, Yoon HK,<br>ChungYS, Park HM.|2011|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Prospective evaluation of prognostic factors uPA/PAI-1 in node-<br>negative breast cancer: phase III NNBC3-Europe trial (AGO,<br>GBG, EORTC-PBG) comparing 6×FEC versus<br>3×FEC/3×Docetaxel.|Kantelhardt EJ, Vetter M, Schmidt<br>M, Veyret C, Augustin D, Hanf V,<br>Meisner C, Paepke D, Schmitt M,<br>Sweep F, von Minckwitz G, Martin<br>PM, Jaenicke F, Thomssen C,<br>Harbeck N.|2011|Não é escopo|-|
|2b|Impact of chemotherapy on thrombin generation and on the<br>protein C pathway in breast cancer patients.|Mukherjee SD, Swystun LL,<br>Mackman N, Wang JG, Pond G,<br>Levine MN, Liaw PC.|2011|Não é escopo|-|
||Risedronate prevents persistent bone loss in prostate cancer|Izumi K, Mizokami A, Sugimoto K,||||
|2b|patients treated with androgen deprivation**therapy**: results of a 2-<br>year follow-up study.|Narimoto K, Kitagawa Y, Koh E,<br>Namiki M.|2011|Não é escopo|-|
|2b|Augmented**therapy**improves outcome for pediatric high risk<br>acute lymphocytic leukemia: results of Children's Oncology<br>Group trial P9906.|Bowman WP, Larsen EL, Devidas<br>M, Linda SB, Blach L, Carroll AJ,<br>Carroll WL, Pullen DJ, Shuster J,<br>Willman CL, Winick N, Camitta BM,<br>Hunger SP, Borowitz MJ.|2011|Não é escopo|-|
|2b|**Oximes**for acute organophosphate pesticide poisoning.|Buckley NA, Eddleston M, Li Y,<br>Bevan M, Robertson J.|2011|**Sim**<br>(Repetido)|Sim|
||Enhancing recovery after acute ischemic stroke with donepezil as|Barrett KM, Brott TG, Brown RD Jr,<br>Carter RE, Geske JR, Graff-Radford||||
|2b|an adjuvant**therapy**to standard medical care: results of a phase<br>IIA**clinical trial**.|NR, McNeil RB, Meschia JF; Mayo<br>Acute Stroke Trial for Enhancing<br>Recovery(MASTER) StudyGroup.|2011|Não é escopo|-|  
77  
|2b|Pharmacokinetics of cyclophosphamide enantiomers in patients<br>with breast cancer.|Fernandes BJ, Silva Cde M, Andrade<br>JM, Matthes Ado C, Coelho EB,<br>Lanchote VL.|2011|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Effects of intravenous zoledronic acid and oral ibandronate on<br>early changes in markers of bone turnover in patients with bone<br>metastases from non-small cell lung cancer.|Francini F, Pascucci A, Bargagli G,<br>Francini E, Conca R, Miano ST,<br>Martellucci I, Migali C, Gotti G,<br>Fiaschi AI, Cozzolino A, Petrioli R.|2011|Não é escopo|-|
|2b|Comparison of oral**midazolam**and triclofos in conscious<br>sedation of uncooperative children.|Shabbir A, Bhat SS, Sundeep Hegde<br>K, Salman M.|2011|Não é escopo|-|
|2b|Effect of denosumab on bone mineral density and biochemical<br>markers of bone turnover: six-year results of a phase 2**clinical**<br>**trial**.|Miller PD, Wagman RB, Peacock M,<br>Lewiecki EM, Bolognese MA,<br>Weinstein RL, Ding B, San Martin J,<br>McClungMR.|2011|Não é escopo|-|
|2b|In vitro susceptibility and virological outcome to darunavir and<br>lopinavir are independent of HIV type-1 subtype in treatment-<br>naive patients.|Dierynck I, De Meyer S, Lathouwers<br>E, Vanden Abeele C, Van De<br>Casteele T, Spinosa-Guzman S, de<br>Béthune MP, Picchio G.|2010|Não é escopo|-|
||The cathepsin K inhibitor odanacatib suppresses bone resorption|Jensen AB, Wynne C, Ramirez G, He||||
|2b|in women with breast cancer and established bone metastases:<br>results of a 4-week, double-blind, randomized, controlled trial.|W, Song Y, Berd Y, Wang H, Mehta<br>A, Lombardi A.|2010|Não é escopo|-|
||Effect of mitoxantrone on outcome of children with first relapse|Parker C, Waters R, Leighton C,<br>Hancock J, Sutton R, Moorman AV,||||
|2b|of acute lymphoblastic leukaemia (ALL R3): an open-label<br>randomised trial.|Ancliff P, Morgan M, Masurekar A,<br>Goulden N, Green N, Révész T,<br>Darbyshire P, Love S, Saha V.|2010|Não é escopo|-|
|2b|Alendronate is more effective than elcatonin in improving pain<br>and quality of life in postmenopausal women with osteoporosis.|Iwamoto J, Makita K, Sato Y,<br>Takeda T, Matsumoto H.|2011|Não é escopo|-|  
78  
|2b|Consistency of bone turnover marker and calcium responses to<br>parathyroid hormone (1-84)**therapy**in postmenopausal<br>osteoporosis.|Schafer AL, Palermo L, Bauer DC,<br>Bilezikian JP, Sellmeyer DE, Black<br>DM.|2011|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Clinical utility of biochemical bone turnover markers in children<br>and adolescents with osteosarcoma.|Ambroszkiewicz J, Gajewska J,<br>Klepacka T, Chełchowska M,<br>Laskowska-Klita T, Woźniak W.|2010|Não é escopo|-|
|2b|A 48-week pilot study switching suppressed patients to<br>darunavir/ritonavir and etravirine from enfuvirtide, protease<br>inhibitor(s), and non-nucleoside reverse transcriptase inhibitor(s).|Ruane P, Alas B, Ryan R, Perniciaro<br>A, Witek J.|2010|Não é escopo|-|
|2b|Metronomic oral cyclophosphamide prednisolone chemotherapy<br>is an effective treatment for metastatic hormone-refractory<br>prostate cancer after docetaxel failure.|Ladoire S, Eymard JC, Zanetta S,<br>Mignot G, Martin E, Kermarrec I,<br>Mourey E, Michel F, Cormier L,<br>Ghiringhelli F.|2010|Não é escopo|-|
|2b|Sugammadex for reversal of neuromuscular block after rapid<br>sequence intubation: a**systematic**review and economic<br>assessment.|Chambers D, Paulden M, Paton F,<br>Heirs M, Duffy S, Hunter JM,<br>Sculpher M, Woolacott N.|2010|Não é escopo|-|
|2b|Bioscavenger**therapy**for**organophosphate poisoning** -an<br>open-labeled pilot randomized trial comparing fresh<br>frozen**plasma**or albumin with saline in acute**organophosphate**<br>**poisoning**in**humans**.|Pichamuthu K, Jerobin J, Nair A,<br>John G, Kamalesh J, Thomas K, Jose<br>A, Fleming JJ, Zachariah A, David<br>SS, Daniel D, Peter JV.|2010|**Sim**|Sim|
|2b|Changes in CSF acetyl-and**butyrylcholinesterase**activity after<br>long-term treatment with AChE inhibitors in Alzheimer's disease.|Parnetti L, Chiasserini D, Andreasson<br>U, Ohlson M, Hüls C, Zetterberg H,<br>Minthon L, Wallin AK, Andreasen<br>N, Talesa VN, Blennow K.|2011|Não é escopo|-|
|2b|Comparison of intravenous and intramuscular neridronate<br>regimens for the treatment of Paget disease of bone.|Merlotti D, Rendina D, Gennari L,<br>Mossetti G, Gianfrancesco F, Martini<br>G, De Filippo G, Avanzati A, Franci|2011|Não é escopo|-|  
79  
|||B, Campagna MS, Strazzullo P, Nuti<br>R.||||
|---|---|---|---|---|---|
|2b|Low frequency of intermittent HIV-1 semen excretion in patients<br>treated with darunavir-ritonavir at 600/100 milligrams twice a day<br>plus two nucleoside reverse transcriptase inhibitors or<br>monotherapy.|Lambert-Niclot S, Peytavin G,<br>Duvivier C, Poirot C, Algarte-Genin<br>M, Pakianather S, Meynard JL,<br>Valantin MA, Molina JM, Flandre P,<br>Katlama C, Calvez V, Marcelin AG.|2010|Não é escopo|-|
||Clinical, radiologic, and therapeutic analysis of 14 patients with|||||
|2b|transverse myelitis associated with antiphospholipid syndrome:<br>report of 4 cases and review of the literature.|Rodrigues CE, de Carvalho JF.|2011|Não é escopo|-|
|2b|Pharmacokinetics and bioavailability of an integrase and novel<br>pharmacoenhancer-containing single-tablet fixed-dose<br>combination regimen for the treatment of HIV.|German P, Warren D, West S, Hui J,<br>Kearney BP.|2010|Não é escopo|-|
|2b|Influence on Busilvex pharmacokinetics of clonazepam compared<br>to previous phenytoin historical data.|Carreras E, Cahn JY, Puozzo C,<br>Kröger N, Sanz G, Buzyn A,<br>Bacigalupo A, Vernant JP.|2010|Não é escopo|-|
||Metronomic administration of zoledronic acid and taxotere|Facchini G, Caraglia M, Morabito A,<br>Marra M, Piccirillo MC, Bochicchio<br>AM, Striano S, Marra L, Nasti G,||||
|2b|combination in castration resistant prostate cancer patients: phase<br>I ZANTE trial.|Ferrari E, Leopardo D, Vitale G,<br>Gentilini D, Tortoriello A, Catalano<br>A, Budillon A, Perrone F, Iaffaioli<br>RV.|2010|Não é escopo|-|
||Systemic chemotherapy-induced microsatellite instability in the|Pinto JL, Fonseca FL, Marsicano SR,||||
|2b|mononuclear cell fraction of women with breast cancer can be<br>reproduced in vitro and abrogated by amifostine.|Delgado PO, Sant'anna AV, Coelho<br>PG, Maeda P, Del Giglio A.|2010|Não é escopo|-|  
80  
|2b|Phase I study of decitabine with doxorubicin and<br>cyclophosphamide in children with neuroblastoma and other solid<br>tumors: a Children's Oncology Group study.|George RE, Lahti JM, Adamson PC,<br>Zhu K, Finkelstein D, Ingle AM,<br>Reid JM, Krailo M, Neuberg D,<br>BlaneySM, Diller L.|2010|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Independence of exogenous insulin following immunoablation<br>and stem cell reconstitution in newly diagnosed diabetes type I.|Snarski E, Milczarczyk A, Torosian<br>T, Paluszewska M, Urbanowska E,<br>Król M, Boguradzki P, Jedynasty K,<br>Franek E, Wiktor-Jedrzejczak W.|2011|Não é escopo|-|
|2b|Effects of continuous combined hormone<br>replacement**therapy**and clodronate on bone mineral density in<br>osteoporotic postmenopausal women: a 5-year follow-up.|Tuppurainen M, Härmä K,<br>Komulainen M, Kiviniemi V, Kröger<br>H, Honkanen R, Alhava E, Jurvelin J,<br>Saarikoski S.|2010|Não é escopo|-|
|2b|Preliminary study of etidronate for prevention of corticosteroid-<br>induced osteoporosis caused by oral glucocorticoid**therapy**.|Furukawa F, Kaminaka C, Ikeda T,<br>Kanazawa N, Yamamoto Y, Ohta C,<br>Nishide T, Tsujioka K, Hattori M,<br>Uede K, Hata M; Wakayama Study<br>Group on Dermatological Use of<br>Bisphosphonates.|2011|Não é escopo|-|
|2b|In vivo manipulation of Vgamma9Vdelta2 T cells with<br>zoledronate and low-dose interleukin-2 for immunotherapy of<br>advanced breast cancer patients.|Meraviglia S, Eberl M, Vermijlen D,<br>Todaro M, Buccheri S, Cicero G, La<br>Mendola C, Guggino G, D'Asaro M,<br>Orlando V, Scarpa F, Roberts A,<br>Caccamo N, Stassi G, Dieli F,<br>HaydayAC.|2010|Não é escopo|-|
|2b|Effect of combined angiotensin-converting enzyme and<br>aldosterone inhibition on**plasma**plasminogen activator inhibitor<br>type 1 levels in chronic hypertensive patients.|Tiryaki O, Usalan C, Buyukhatipoglu<br>H.|2010|Não é escopo|-|  
81  
|2b|A Phase I trial of samarium-153-lexidronam complex for<br>treatment of clinically nonmetastatic high-risk prostate cancer:<br>first report of a completed study.|Valicenti RK, Trabulsi E, Intenzo C,<br>Lavarino J, Xu Y, Chervoneva I.|2011|Não é escopo|-|
|---|---|---|---|---|---|
|2b|Relationships between serum adiponectin, leptin concentrations<br>and bone mineral density, and bone biochemical markers in<br>Chinese women.|Wu N, Wang QP, Li H, Wu XP, Sun<br>ZQ, Luo XH.|2010|Não é escopo|-|
|2b|Clinical and bioavailability studies of sublingually<br>administered**atropine**sulfate.|Rajpal S, Ali R, Bhatnagar A,<br>Bhandari SK, Mittal G.|2010|**Sim**<br>(Repetido)|Sim|
|2b|Treatment of osteoporosis after liver transplantation with<br>ibandronate.|Kaemmerer D, Lehmann G, Wolf G,<br>Settmacher U, Hommann M.|2010|Não é escopo|-|
|2b|Efficacy and safety of monthly ibandronate in men with low bone<br>density.|Orwoll ES, Binkley NC, Lewiecki<br>EM, Gruntmanis U, Fries MA, Dasic<br>G.|2010|Não é escopo|-|
||Correlations between biochemical markers of bone turnover and|Burshell AL, Möricke R, Correa-||||
|2b|bone density responses in patients with glucocorticoid-induced<br>osteoporosis treated with teriparatide or alendronate.|Rotter R, Chen P, Warner MR,<br>DalskyGP, Taylor KA, Krege JH.|2010|Não é escopo|-|
|2b|Pitavastatin decreases the expression of endothelial lipase both in<br>vitro and in vivo.|Kojima Y, Ishida T, Sun L, Yasuda<br>T, Toh R, Rikitake Y, Fukuda A,<br>Kume N, Koshiyama H, Taniguchi<br>A, Hirata K.|2010|Não é escopo|-|
||Activity and safety of combination chemotherapy with|Tsukune Y, Isobe Y, Yasuda H,||||
|2b|methotrexate, ifosfamide, l-asparaginase and dexamethasone<br>(MILD) for refractory lymphoid malignancies: a pilot study.|Shimizu S, Katsuoka Y, Hosone M,<br>Oshimi K, Komatsu N, Sugimoto K.|2010|Não é escopo|-|
|2b|The effects of weekly alendronate**therapy**in Taiwanese males<br>with osteoporosis.|Hwang JS, Liou MJ, Ho C, Lin JD,<br>Huang YY, Wang CJ, Tsai KS, Chen<br>JF.|2010|Não é escopo|-|  
82  
||Phase I trial with a combination of docetaxel and¹⁵³Sm-|Lin J, Sinibaldi VJ, Carducci MA,||||
|---|---|---|---|---|---|
|2b|lexidronam in patients with castration-resistant metastatic prostate<br>cancer.|Denmeade S, Song D, Deweese T,<br>Eisenberger MA.|2011|Não é escopo|-|
|2b|Estimation of**plasma**IC50 of donepezil for cerebral<br>acetylcholinesterase inhibition in patients with Alzheimer disease<br>using positron emission tomography.|Ota T, Shinotoh H, Fukushi K,<br>Kikuchi T, Sato K, Tanaka N,<br>Shimada H, Hirano S, Miyoshi M,<br>Arai H, Suhara T, Irie T.|2010|Não é escopo|-|
|2b|Assessment of regional changes in skeletal metabolism following<br>3 and 18 months of teriparatide treatment.|Moore AE, Blake GM, Taylor KA,<br>Rana AE, Wong M, Chen P,<br>Fogelman I.|2010|Não é escopo|-|
||Infusion of ibandronate once every 3 months effectively decreases|Li M, Xing XP, Zhang ZL, Liu JL,||||
|2b|bone resorption markers and increases bone mineral density in<br>Chinese postmenopausal osteoporotic women: a 1-year study.|Zhang ZL, Liu DG, Xia WB, Meng<br>XW.|2010|Não é escopo|-|
|||Polyzos SA, Anastasilakis AD,<br>Efstathiadou Z, Litsas I, Kita M,||||
|2b|Serum homocysteine, folate and vitamin B12 in patients with<br>Paget's disease of bone: the effect of zoledronic acid.|Panagiotou A, Papatheodorou A,<br>Arsos G, Moralidis E, Barmpalios G,<br>Zafeiriadou E, Triantafillidou E,<br>Makrigiannaki E, Terpos E.|2010|Não é escopo|-|
|2b|Immunomodulatory therapies in neurologic critical care.|McDaneld LM, Fields JD, Bourdette<br>DN, BhardwajA.|2010|Não é escopo|-|
|2b|Effect of alendronate on bone mineral density and bone turnover<br>markers in post-gastrectomy osteoporotic patients.|Iwamoto J, Uzawa M, Sato Y,<br>Takeda T, Matsumoto H.|2010|Não é escopo|-|
|2b|Impact of bisphosphonate wash-out prior to<br>teriparatide**therapy**in clinical practice.|Keel C, Kraenzlin ME, Kraenzlin<br>CA, Müller B, Meier C.|2010|Não é escopo|-|
|2b|Randomized trial of intensive bisphosphonate treatment versus<br>symptomatic management in Paget's disease of bone.|Langston AL, Campbell MK, Fraser<br>WD, MacLennan GS, Selby PL,<br>Ralston SH; PRISM Trial Group.|2010|Não é escopo|-|  
83  
|2b|Cocktail**therapy**for femoral head necrosis of the hip.|Hsu SL, Wang CJ, Lee MS, Chan<br>YS Huan CC Yan KD|2010|Não é escopo|-|
|---|---|---|---|---|---|
||**Busca - pergunta PICO**|, g , g .<br>**5 (13 resultados)**|||**Disponível**|
|||||**Estudo**||
|**Busca**|**Título**|**Autor**|**Ano**|<br>**considerado**|**para**<br>**descarga**|
|5a|Adjuvant treatment with crude rhubarb for patients with acute<br>organophosphorus pesticide poisoning: A**meta-analysis**of<br>randomized controlled trials.|Wang L, Pan S.|2015|**Sim**|Sim|
||A**systematic**review on the nerve-muscle electrophysiology in|Karami-Mohajeri S, Nikfar S, Abdollahi||Não fala do||
|5a|human organophosphorus pesticide exposure.|M.|2014|tratamento<br>(Repetido)|Sim|
||Incidence, predictors, and outcome of**intermediate** **syndrome**in|Indira M, Andrews MA, Rakesh TP.||||
|5a|cholinergic insecticide**poisoning**: a prospective observational<br>cohort study.||2013|**Sim**|Sim|
|5a|Effectiveness of therapeutic**plasma**exchange in patients with<br>intermediate syndrome due to organophosphate intoxication.|Yilmaz M, Sebe A, Ay MO, Gumusay U,<br>Topal M, Atli M, Icme F, Satar S.|2013|**Sim**<br>(Repetido)|Sim|
|5a|Open-label randomized**clinical trial**of**atropine**bolus injection<br>versus incremental boluses plus infusion for**organophosphate**<br>**poisoning**in Bangladesh.|Abedin MJ, Sayeed AA, Basher A, Maude<br>RJ, Hoque G, Faiz MA.|2012|**Sim**<br>(Repetido)|Sim|
|5a|A comprehensive review on experimental and clinical findings in<br>intermediate syndrome caused by**organophosphate**poisoning.|Abdollahi M, Karami-Mohajeri S.|2012|**Sim**|Sim|
|5a|Bioscavenger therapy for**organophosphate poisoning** -an open-<br>labeled pilot randomized trial comparing fresh frozen plasma or<br>albumin with saline in acute**organophosphate**<br>**poisoning**in**humans**.|Pichamuthu K, Jerobin J, Nair A, John G,<br>Kamalesh J, Thomas K, Jose A, Fleming<br>JJ, Zachariah A, David SS, Daniel D, Peter<br>JV.|2010|**Sim**<br>(Repetido)|Sim|  
84  
|5b|Chronic exposure to organophosphate (OP) pesticides and<br>neuropsychological functioning in farm workers: a review.|Muñoz-Quezada MT, Lucero BA, Iglesias<br>VP, Muñoz MP, Cornejo CA, Achu E,<br>Baumert B, Hanchey A, Concha C, Brito<br>AM, Villalobos M.|2016|**Sim**|Sim|
|---|---|---|---|---|---|
|5b|[Characterization of pesticide exposures reported between 2006<br>and 2013 to apoison information center in Chile].|Gutiérrez W, Cerda P, Plaza-Plaza JC,<br>Mieres JJ, Paris E, Ríos JC.|2015|Não fala do<br>tratamento|Sim|
|5b|Clinical study of continuous micropump infusion of atropine and<br>pralidoxime chloride for treatment of severe acute<br>organophosphorus insecticidepoisoning.|Liu HX, Liu CF, Yang WH.|2015|**Sim**<br>(Repetido)|Sim|
|5b|Pesticide exposure and neurodevelopmental outcomes: review of<br>the epidemiologic and animal studies.|Burns CJ, McIntosh LJ, Mink PJ, Jurek<br>AM, Li AA.|2013|Não fala do<br>tratamento|-|
|5b|A systematic review on the nerve-muscle electrophysiology in<br>human organophosphorus pesticide exposure.|Karami-Mohajeri S, Nikfar S, Abdollahi<br>M.|2014|Não fala do<br>tratamento<br>(Repetido)|-|
|5b|Toxic influence of organophosphate, carbamate, and<br>organochlorine pesticides on cellular metabolism of lipids,<br>proteins, and carbohydrates: a systematic review.|Karami-Mohajeri S, Abdollahi M.|2011|Não é escopo|-|  
85  
**Quadro III.3.2.** Artigos resultantes da busca sistemática no site **Cochrane Library** para as perguntas PICO sobre a intoxicação por inibidores de colinesterase e a análise de inclusão do artigo.  
|**Busca -**|**pergunta PICO 1 (6 resultados)**||||
|---|---|---|---|---|
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para descarga**|
|Clinical analysis of penehyclidine hydrochloride combined with<br>hemoperfusion in the treatment of acute severe organophosphorus<br>pesticide**poisoning**|Liang MJ and Zhang Y|2015|**Sim**<br>(Repetido)|Sim|
|Comparison of single-dose pralidoxime and pralidoxime infusions<br>for the treatment of organophosphatepoisoning|Kozaci N , Gokel Y , Acikalin A and Icme<br>F|2012|**Sim**|Sim|
|Efficacy of pralidoxime in organophosphorus poisoning: Revisiting<br>the controversyin Indian setting|<br>Banerjee I , Tripathi SK and Roy A|2014|**Sim**|Sim|
|A study on comparative evaluation of add-on pralidoxime therapy<br>over atropine in the management of organophosphorus poisoning<br>in a tertiarycare hospital.|Banerjee I , Tripathi SK and Sinha Roy A|2011|**Sim**|Sim|
|Is the World Health Organization-recommended dose of<br>pralidoxime effective in the treatment of organophosphorus<br>poisoning? A randomized, double-blinded and placebo-controlled<br>trial.|Syed S , Gurcoo SA , Farooqui A , Nisa<br>W , Sofi K and Wani TM|2015|**Sim**|Sim|
|Is rivastigmine safe as pretreatment against nerve agents<br>poisoning? A pharmacological, physiological and cognitive<br>assessment in healthy young adult volunteers.|Lavon O , Eisenkraft A , Blanca M ,<br>Raveh L , Ramaty E , Krivoy A , Atsmon<br>J , Grauer E and Brandeis R|2015|Não é escopo|-|
|**Busca - pergun**|**ta PICO 2 (3 resultados)**||||  
|**Título**|**Autor**|**Ano**|**Estudo**<br>|**Disponível**<br>|
|---|---|---|---|---|
||||**considerado**|**para descarga**|  
86  
|N-acetylcysteine in Acute Organophosphorus Pesticide Poisoning:<br>a Randomized, Clinical Trial|El-Ebiary AA , Elsharkawy RE , Soliman<br>NA , Soliman MA and Hashem AA|2016|**Sim**<br>(Repetido)|Sim|
|---|---|---|---|---|
|Clinical analysis of penehyclidine hydrochloride combined with<br>hemoperfusion in the treatment of acute severe organophosphorus<br>pesticidepoisoning.|Liang MJ, Zhang Y.|2015|**Sim**<br>(Repetido)|Sim|
|N-acetylcysteine a novel treatment for acute human<br>organophosphate poisoning<br>**Busca -**|Shadnia S , Ashrafivand S , Mostafalou S<br>and Abdollahi M<br>**pergunta PICO 5 (3 resultados)**|2011|**Sim**|Sim|
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para descarga**|
|Open-label randomized clinical trial of atropine bolus injection<br>versus incremental boluses plus infusion for organophosphate<br>poisoningin Bangladesh.|Abedin MJ, Sayeed AA, Basher A, Maude<br>RJ, Hoque G, Faiz MA.|2012|**Sim**<br>(Repetido)|Sim|
|Effectiveness of therapeutic plasma exchange in patients with<br>intermediate syndrome due to organophosphate intoxication.|Yilmaz M, Sebe A, Ay MO, Gumusay U,<br>Topal M, Atli M, Icme F, Satar S.|2013|**Sim**<br>(Repetido)|Sim|
|Acetylcholinesterase inhibitors for schizophrenia|Jasvinder Singh , Kamalpreet Kour and<br>Mahesh B Jayaram|2012|Não é escopo|-|  
87  
**Quadro III.3.3.** Artigos resultantes da busca sistemática no site **BVS** para as perguntas PICO sobre a intoxicação por inibidores de colinesterase e a análise de inclusão do artigo. A busca foi feita no idioma português e espanhol, com filtro de data (publicações de 2010 a 2017).  
|**Busca**|**Busca - pergunta PICO 1 (8 resulta**<br> <br>**Título**|**dos)**<br>**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para**<br>**descarga**|
|---|---|---|---|---|---|
|1a|Management of exogenous intoxication by carbamates and organophosphates at an<br>emergency unit / Manejo de intoxicação exógena por carbamatos e organofosforados em<br>uma unidade de emergência|Leão, Sydney Correia;<br>Queiroz, Alex André<br>Ferreira; Silveira,<br>Alessandro Rodrigues;<br>Araújo, José Fernandes de;<br>Rodrigues, Tânia Maria de<br>Andrade; Maciel, Diego<br>Carvalho; Almeida,<br>Rodrigo Oliveira; Souto,<br>Maria Júlia Silveira|2015|**Sim**|Sim|
|1a|A reduced grade of liver fibros-steatosis after raltegravir, maraviroc and fosamprenavir in<br>an HIV/HCV co-infected patient with chronic hepatitis, cardiomyopathy, intolerance to<br>nelfinavir and a marked increase of serum creatine phosphokinase levels probably related<br>to integrase inhibitor use / Grado reducido de fibroesteatosis tras la administración de<br>raltegravir, maraviroc y fosamprenavir en un paciente co-infectado de VIH/VHC con<br>hepatitis crónica, cardiomiopatía, intolerancia al nelfinavir y un aumento pronunciado de<br>los niveles de creatina fosfoquinasa sérica probablemente debido al uso del inhibidor de la<br>integrasa|Antoni, A Degli; Fragola,<br>V; Manfredi, R; Weimer,<br>LE; Ferrari, C.|2012|Não é escopo|-|
|1a|Intoxicación aguda por organofosforados. A propósito de un caso / Acute intoxication due<br>to organophosphates. A case report|Rives Ferreiro, M. T;<br>Rodríguez Ozcoidi, J;<br>Calderón Llopis, B; Dorao|2010|**Sim**|-|  
88  
|||Martínez-Romillo, P; Ruza<br>Tarrio, F. J.||||
|---|---|---|---|---|---|
|1b|Asociación de la exposición ocupacional a plaguicidas organofosforados con el daño<br>oxidativo y actividad de acetilcolinesterasa / Association of occupational exposure to<br>pesticides organophosphate oxidative damage and activity acetylcholinesterase|Ortega Freyre, EG; Carrera<br>Gracia, MA; Delgadillo<br>Guzmán, D; Intriago<br>Ortega, MP; Lares<br>Bayona, EF; Quintanar<br>Escorza, MA.|2016|Não é escopo|-|
|1b|Management of exogenous intoxication by carbamates and organophosphates at an<br>emergency unit / Manejo de intoxicação exógena por carbamatos e organofosforados em<br>uma unidade de emergência|Leão, Sydney Correia;<br>Queiroz, Alex André<br>Ferreira; Silveira,<br>Alessandro Rodrigues;<br>Araújo, José Fernandes de;<br>Rodrigues, Tânia Maria de<br>Andrade; Maciel, Diego<br>Carvalho; Almeida,<br>Rodrigo Oliveira; Souto,<br>Maria Júlia Silveira|2015|**Sim**<br>(Repetido)|Sim|
|1b|Intoxicación con rodenticidas: casos reportados al Centro de Información, Gestión e<br>Investigación en Toxicología de la Universidad Nacional de Colombia / Rodenticide<br>poisoning: cases reported to the Toxicology Research, Management and Information<br>Center, National Universityof Colombia|Galofre-Ruiz, Mario<br>David; Padilla-Castañeda,<br>Édgar Iván.|2014|**Sim**|Sim|
|1b|A reduced grade of liver fibros-steatosis after raltegravir, maraviroc and fosamprenavir in<br>an HIV/HCV co-infected patient with chronic hepatitis, cardiomyopathy, intolerance to<br>nelfinavir and a marked increase of serum creatine phosphokinase levels probably related<br>to integrase inhibitor use / Grado reducido de fibroesteatosis tras la administración de<br>raltegravir, maraviroc y fosamprenavir en un paciente co-infectado de VIH/VHC con<br>hepatitis crónica, cardiomiopatía, intolerancia al nelfinaviryun aumentopronunciado de|Antoni, A Degli; Fragola,<br>V; Manfredi, R; Weimer,<br>LE; Ferrari, C.|2012|Não é escopo|-|  
89  
||los niveles de creatina fosfoquinasa sérica probablemente debido al uso del inhibidor de la<br>integrasa|||||
|---|---|---|---|---|---|
|1b|Intoxicación aguda por organofosforados. A propósito de un caso / Acute intoxication due<br>to organophosphates. A case report<br>**Busca - pergunta PICO 2 (44 resulta**|Rives Ferreiro, M. T;<br>Rodríguez Ozcoidi, J;<br>Calderón Llopis, B; Dorao<br>Martínez-Romillo, P; Ruza<br>Tarrio, F. J.<br>**dos)**|2010|**Sim**<br>(Repetido)|-|
|**Busca**|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para**<br>**descarga**|
|2b/2d|Manejo odontológico del paciente con Miastenia Gravis / Dental treatment in patients with<br>myasthenia gravis|Cadenas Vacas,<br>Guillermo; Sanz Alonso,<br>Javier; Buesa Bárez, José<br>María; Barona Dorado,<br>Cristina; Martínez<br>González, José María.|2017|Não é escopo|-|
|2b/2d|Asociación de la exposición ocupacional a plaguicidas organofosforados con el daño<br>oxidativo y actividad de acetilcolinesterasa / Association of occupational exposure to<br>pesticides organophosphate oxidative damage and activity acetylcholinesterase|Ortega Freyre, EG; Carrera<br>Gracia, MA; Delgadillo<br>Guzmán, D; Intriago<br>Ortega, MP; Lares<br>Bayona, EF; Quintanar<br>Escorza, MA.|2016|Não fala do<br>tratamento|-|
|2b/2d|Galantamine protects against lipopolysaccharide-induced acute lung injury in rats|Li, G.; Zou, HD.; Zhou,<br>QS.; Zhou, CL..|2016|Não é escopo|-|  
90  
|2b/2d|Manejo actual de las intoxicaciones agudas por inhibidores de la colinesterasa: conceptos|Virú Loza, Manuel André.||||
|---|---|---|---|---|---|
||erróneos y necesidad de guías peruanas actualizadas / Current treatment of cholinesterase<br>inhibitorspoisoning: misconceptions and need for updated Peruvianguidelines||2015|**Sim**|Sim|
|2b/2d|Management of exogenous intoxication by carbamates and organophosphates at an<br>emergency unit / Manejo de intoxicação exógena por carbamatos e organofosforados em<br>uma unidade de emergência|Leão, Sydney Correia;<br>Queiroz, Alex André<br>Ferreira; Silveira,<br>Alessandro Rodrigues;<br>Araújo, José Fernandes de;<br>Rodrigues, Tânia Maria de<br>Andrade; Maciel, Diego<br>Carvalho; Almeida,<br>Rodrigo Oliveira; Souto,<br>Maria Júlia Silveira|2015|**Sim**<br>(Repetido)|Sim|
|2b/2d|Laboratory genetic-based reference values for cholinesterase activity in a Colombian<br>population: A step forward in personalized diagnostics / Valores de referencia basados en<br>el contexto genético de la actividad enzimática de la colinesterasa en una población<br>colombiana: un paso hacia el diagnóstico personalizado|Sánchez, Luz Helena;<br>González, Clara Isabel;<br>Flórez-Vargas, Óscar;<br>Gómez, Guillermo;<br>Medina, Olga Marcela.|2015|Não fala do<br>tratamento|-|
|2b|Alterações bioquímicas e toxicológicas de agricultores familiares da região do Alto Jacuí,<br>Rio Grande do Sul / Biochemical and toxicological changes among family farmers from<br>the Alto Jacui region, Rio Grande do Sul state, Brazil|Mori, Natacha Cossettin;<br>Horn, Roberta Cattaneo;<br>Oliveira, Caroline; Leal,<br>Paola Ariane Pereira;<br>Golle, Diego Pascoal;<br>Koefender, Jana; Josiane,<br>Bortolotto; Dias, Helena<br>Matielo.|2015|Não fala do<br>tratamento|-|
|2b/2d|Determinação da atividade de colinesterase plasmática e eritrocitária após exposição aguda<br>a organofosforados e carbamatos em agricultores do município de Chapada, RS /|Oliveira, Greice Haeffner<br>de; Ehrhardt, Alexandre.|2015|Não fala do<br>tratamento|-|  
91  
||Determination of plasma and erythrocyte cholinesterase activity after acute exposure to<br>organophosphates and carbamates in farmers from Chapada municipality, RS|||||
|---|---|---|---|---|---|
|2b|Pesticide use and cholinesterase inhibition in small-scale agricultural workers in southern<br>Brazil|Nerilo, Samuel Botião;<br>Mossini, Simone<br>Aparecida Galerani;<br>Nishiyama, Paula; Janeiro,<br>Vanderly; Machinski<br>Junior, Miguel; Rocha,<br>Gustavo Henrique<br>Oliveira; Endo, Renan<br>Yoshio; Nerilo, Luciana<br>Botião; Salvadego, Valter<br>Eduardo Cocco; Martins,<br>Fernanda Andrade.|2014|Não é escopo|-|
|2b/2d|Prescripciones inconvenientes en el tratamiento del paciente con deterioro cognitivo /<br>Inappropriate treatments forpatients with cognitive decline|Robles Bayón, A; Gude<br>Sampedro, F.|2014|Não é escopo|-|
|2b/2d|Uso inadequado de organofosforados: uma prática de risco para bovinos no Sul do Rio<br>Grande do Sul / Misuse of organophosphate: potential risk to cattle in Southern Brazil|Santos, Bianca L;<br>Marcolongo-Pereira,<br>Clairton; Stigger, Adriana<br>L; Coelho, Ana Carolina<br>B; Schild, Ana Lucia;<br>Barreto, Fabiano; Soares,<br>Mauro P; Sallis, Eliza S.<br>V.|2014|Não é escopo|-|
|2b/2d|Intoxicação aguda por triclorfon em caprinos tratados com a dose terapêutica / Acute<br>poisoning by trichlorfon in goats given a therapeutic dose|Lopes, Welber Daniel<br>Zanetti; Gracioli, Diogo<br>dos Passos; Oliveira, Pedro<br>Victor; Pereira,<br>Valdomiro; Carvalho,|2014|Não é escopo|-|  
92  
|||Rafael Silveira;<br>Mazzucatto, Barbara<br>Cristina; Martinez,<br>Antônio Campanha.||||
|---|---|---|---|---|---|
|2b/2d|Niveles de Colinesterasa Plasmática en mujeres embarazadas y no embarazadas expuestas<br>a plaguicidas en la zona del Páramo: Mérida-Venezuela / Plasma Cholinesterase levels<br>pregnant and non-pregnant women exposed to pesticides Páramo area: Mérida-Venezuela|Rojas de M, Tibisay del C;<br>Ramírez C, Yelitza I;<br>Marín R, Carlos E;<br>Hernández, Morelia del P.|2013|Não fala do<br>tratamento|-|
|2b/2d|Afectación de las funciones cognitivas y motoras en niños residentes de zonas rurales de<br>Jujuy y su relación con plaguicidas inhibidores de la colinesterasa: Un estudio piloto /<br>Impairment of cognitive and motor functions in children from rural areas of Jujuy, and its<br>relationship with cholinesterase inhibitor pesticides: A pilot study|Martos Mula, Ana J; Ávila<br>Carreras, Natalia M; Bovi<br>Mitre, María G; Bonillo,<br>Mario C; Tschambler,<br>Javier A; Ruggeri, María<br>A; Wierna, Norma R;<br>Saavedra, Olga N.|2013|Não fala do<br>tratamento|-|
|2b/2d|Delirium en el hospital, una revisión narrativa / Delirium in the hospital, a narrative review|Martínez Lomakin, Felipe;<br>Fuentes Rojas, Paola;<br>Tobar Bustos, Catalina|2013|Não é escopo|-|
|2b/2d|Comparación de tres métodos de determinación de la actividad colinesterasa plasmática en<br>perro / Comparison of three methods for the determination of plasma cholinesterase<br>activityin dog|Maia, A. R; Pérez López,<br>M; Soler Rodríguez, F.|2012|Não é escopo|-|
|2b/2d|Estrategia educativa: prácticas agrícolas ysu relación con la salud humana, dirigida a<br>agricultores de la zona norte de Cartago, Costa Rica / Educational strategy: farming<br>practices and their relation to human health", directed to farmers of northern Cartago, Costa<br>Rica / Estratégia educativa: prácticas agrícolas y su relación con la salud humana, destinada<br>a agricultores da zona norte de Cartago, Costa Rica|Montero, Paula Alfaro;<br>Hidalgo, Karla Ruiz; Diaz,<br>Manuel Jiménez; Alfaro,<br>Laura Brenes.|2012|Não é escopo|-|
|2b/2d|Síndrome intermedio en intoxicación aguda por organofosforados: reporte de caso /<br>Intermediate syndrome in acute organophosphoruspoisoning: a case report|Barguil Díaz, Ivón Cecilia;<br>Pinto Maquilón, Julieth|2012|**Sim**|-|  
93  
|||Katerine; Lozano<br>Mosquera, Nadia;<br>Aristizábal Hernández,<br>José Julián.||||
|---|---|---|---|---|---|
|2b/2d|Papel de las colinesterasas plasmáticas. Actualización / Update on the current role of<br>plasma cholinesterase|Fernández Prieto, R. M;<br>Ramallo Bravo, A;<br>Carmona Carmona, G;<br>Carrasco Jiménez, M. S.|2011|Não é escopo|-|
|2b/2d|Efectos de exposición ocupacional a plaguicidas sobre la integridad de la cromatina<br>espermática|Gómez-Pérez, Roald;<br>Miranda-Contreras,<br>Leticia; Rojas, Gerardo;<br>Cruz, Ibis; Berrueta,<br>Lisbeth; Balza, Alirio;<br>Contreras, Carlos A;<br>Salmen, Siham; Zavala,<br>Leisalba; Colmenares,<br>Melisa; Osuna, Jesús A;<br>Morales, Yasmín; Barreto,<br>Silvio.|2011|Não é escopo|-|
|2b/2d|Alteración de la actividad de la butirilcolinesterasa en pacientes con enfermedad de<br>Alzheimer tratados con inhibidores de la acetylcolinesterasa / Changes in<br>butyrylcholinesterase activity in patients with Alzheimer disease treated with<br>acetylcholinesterase inhibitors|Sánchez Morillo, J;<br>Estruch Pérez, M. J;<br>Barber Ballester, G;<br>Pertusa Collado, V.|2011|Não é escopo|-|
|2b/2d|Intoxicación aguda por organofosforados. A propósito de un caso / Acute intoxication due<br>to organophosphates. A case report|Rives Ferreiro, M. T;<br>Rodríguez Ozcoidi, J;<br>Calderón Llopis, B; Dorao<br>Martínez-Romillo, P; Ruza<br>Tarrio, F. J.|2010|**Sim**<br>(Repetido)|-|  
94  
|2d|Actividad neuroprotectora del aceite esencial de_Salvia lavandulifolia_Vahl /<br>Neuroprotective activity of_Salvia lavandulifolia_Vahl. Essential oil|Porres-Martínez M,<br>González-Burgos E,<br>Carretero ME, Gómez-<br>Serranillos MP.|2010|Não é escopo|-|
|---|---|---|---|---|---|
|2c|Asociación de la exposición ocupacional a plaguicidas organofosforados con el daño<br>oxidativo y actividad de acetilcolinesterasa / Association of occupational exposure to<br>pesticides organophosphate oxidative damage and activity acetylcholinesterase|Ortega Freyre, EG; Carrera<br>Gracia, MA; Delgadillo<br>Guzmán, D; Intriago<br>Ortega, MP; Lares<br>Bayona, EF; Quintanar<br>Escorza, MA.|2016|Não fala do<br>tratamento<br>(Repetido)|-|  
#### **Busca - pergunta PICO 5 (2 resultados)**  
|**Busca**|<br>**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|**Disponível**<br>**para**<br>**descarga**|
|---|---|---|---|---|---|
|5b|Síndrome colinérgico y síndrome intermedio confluyentes en una intoxicación por<br>organofosforados / Simultaneous cholinergic and intermediate syndromes in<br>organophosphatepoisoning|Delgado, M; Masclans, J;<br>Catalán, I; Mas, A.|2010|**Sim**|Sim|
|5b|Espontánea reversibilidad de un síndrome de parkinson tardío y de alteraciones cognitivas<br>frontales; después de una intoxicación aguda con órganofosforados / Reversible parkinson<br>syndrome and cognitive impairments due organophosphate acutepoisoning|Toledo L., Paola;<br>Bustamante F., Gonzalo;<br>Cartier R., Luis.|2010|Não é escopo|-|  
95

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
**Quadro III.1.1. Síntese de evidências para a intervenção “Atropina (regime de dosagem)” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**Tempo para**<br>**atropinização;**<br>**Toxicidade;**<br>**Síndrome**<br>**intermediária;**<br>**Necessidade**<br>**de suporte**<br>**respiratório**|**Atropina**|**Total de 156 pacientes**. Dois grupos de pacientes intoxicados por<br>organofosforados foram analisados no Chittagong Medical College Hospital<br>(CMCH), em Bangladesh, de junho a setembro de 2006. O objetivo foi comparar<br>a eficácia e segurança, para o tratamento da intoxicação, dedoses em bolus do<br>tratamento convencional (grupo A, n=81)comdoses incrementais<br>individualizadas de atropina para atropinização seguida por infusão contínua de<br>atropina (grupo B, n=75). Os pacientes foram observados por pelo menos 96 h. O<br>grupo A recebeu 2-5 mg de atropina IV a cada 10-15 min, até atingir a<br>atropinização; depois, a atropinização foi mantida reduzindo-se a dose ou<br>aumentando a duração entre as doses de atropina. Por sua vez, o grupo B recebeu<br>uma dose inicial de 1,8-3,0 mg de atropina IV, com repetição da dose de atropina<br>a cada 5 min dobrando-se a dose cada vez até a atropinização; então, 10-20% da<br>dose de atropina requerida para atropinização foi dada a cada hora por infusão IV.<br>Os pacientes de ambos os grupos que apresentavam menos de 36 h da intoxicação,<br>receberam também pralidoxima 1-2 g IV em adultos (30 mg/kg) a uma taxa lenta<br>máxima de 0,5 g/min, com repetição da dose depois de 1 h caso não tivesse<br>melhoras e, então, a cada 8-12 h.<br>**A mortalidade no grupo A (18/80 ou 22,5%) foi maior que no grupo B (6/75**<br>**ou 8%) (p<0,05). A duração média para a atropinização no grupo A foi de**<br>**151,74 min, em comparação com 23,90 min do grupo B (p<0,001). Mais**<br>**pacientes dogrupo A tiveram toxicidadepor atropina (28,4%) em**|**Abedin**MJ<br>et al.,**2012**.<br>Open-label<br>randomized c<br>linical<br>trial of atropi<br>ne bolus<br>injection<br>versus<br>incremental<br>boluses plus<br>infusion<br>for organoph<br>osphate<br>poisoning in<br>Bangladesh.<br>Busca<br>Sistemática|Ensaio<br>clínico<br>randomizad<br>o<br>(_open-label_<br>_unblinded_<br>_randomized_<br>_clinical_<br>_trial_)|Grave (-<br>1)|  
96  
||||**comparação com o grupo B (12,0%) (p<0,05). A ocorrência de síndrome**<br>**intermediária foi maior no grupo A que no B (13,6% vs. 4%, p<0,05).**<br>**Suporte respiratório foi requerido mais frequentemente pelos pacientes do**<br>**grupo A do que no B (24,7% vs. 8%, p<0,05).**<br>Das 18 mortes no grupo A, 13 (72%) foram foi falha respiratória, e 5 (27,8%)<br>foram devido à falha circulatória. Das 6 mortes no grupo B, 3 (50%) foram por<br>falha respiratória, 2 (33%) por falha circulatória, e 1 (16,7%) devido à diarreia<br>complicada por choque.<br>**Conclusão:**O modelo de administração de atropina usada no grupo B (atropina<br>incremental e infusão) deveria ser o tratamento padrão para intoxicação por<br>organofosfatos. Dada a escassez de dados existentes, mais estudos clínicos devem<br>ser realizados para determinar o regime de dosagem ótima de atropina que mais<br>rapidamente e de forma segura atinge atropinização nestes pacientes.||||
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Dose de**<br>**atropina**<br>**requerida**<br>**para**<br>**atropinização,**<br>**tempo para**<br>**atropinização,**<br>**tempo para**<br>**recuperação**<br>**da AChE.**|**Atropina e**<br>**pralidoxim**<br>**a: infusão**<br>**contínua ou**<br>**em**<br>**múltiplas**<br>**doses em**<br>**bolus**|Um total de**60 pacientes**com intoxicação severa aguda por organofosforados,<br>definida por crise colinérgica com falha respiratória e edema cerebral, foram<br>randomizados em dois grupos. Esse estudo ocorreu entre julho de 2007 a maio de<br>2012 na China. Todos os pacientes foram submetidos inicialmente ao tratamento<br>de rotina, com intubação intratraqueal e ventilação mecânica, lavagem gástrica e<br>cápsulas de carvão ativado. Além disso, receberam tratamento de suporte, com<br>hepatoproteção, hidratação, diurese e hemoperfusão (recebida logo após a<br>admissão, 2 vezes diárias por 2 dias). Todos os pacientes receberam uma dose de<br>carga de 20 mg de atropina e 2 g de cloreto de pralidoxima IV.<br>Grupo experimental (n=30): infusão contínua (_continuous micropump_) IV de|**Liu**HX et<br>al.,**2015**.<br>Clinical<br>study of<br>continuous<br>micropump<br>infusion<br>of atropine a<br>nd<br>pralidoxime|Estudo<br>clínico<br>randomizad<br>o<br>controlado|Grave (-<br>1)|
||**Desfechos**<br>**secundários:**<br>**taxa de**<br>**letalidade**||atropina, a uma taxa de 20 mg/h, a fim de manter o paciente atropinizado sem<br>atingir concentrações tóxicas; frequentemente a dose era ajustada (dose ajustada a<br>cada 5 min a uma taxa de 2 mg/h, reduzindo-a conforme os sintomas do paciente).<br>Quando o paciente atingia a maioria dos pontos alvo (pelo menos 4 de 5:<br>frequência cardíaca > 80 bpm, pupila dilatada, axilas secas, pressão sanguínea|chloride for<br>treatment of<br>severe acute<br>organophosp<br>horus|||  
97  
|sistólica >80 mmHg, peito com ausência de sibilância) para a terapia com<br>atropina, uma infusão da dose mínima de atropina era mantida.Em adição à<br>atropina, havia uma infusão contínua de cloreto de pralidoxima,a uma taxa de 8<br>mg/kg/h até que as taxas de AChE fossem recuperadas para 60% da taxa normal.<br>Grupo controle (n=30): injeções intermitentes em bolus de atropina (5 mg a cada<br>10 min até atingir atropinização)e cloreto de pralidoxima(1 g a cada 6 h até que<br>as taxas de AChE fossem recuperadas para 60% da taxa normal).|insecticide<br>poisoning.<br>Busca<br>Sistemática|
|---|---|
|**O tempo para atropinização (49,3 ± 26,5 min) e o tempo para recuperação da**<br>**AChE (3,5 ± 0,8 dias) foram menores no grupo experimental (p<0,05),**<br>**levando a uma menor dose de atropina (40,3 ± 6,0 mg) requerida para a**<br>**atropinização em comparação com o grupo controle (64,5 ± 29,5 min, 5,8 ±**<br>**0,4 dias e 53,5 ± 7,3 mg, respectivamente). O escore APACHE II (comumente**<br>**usado para avaliar a gravidade de pacientes criticamente doentes) na**<br>**atropinização no grupo experimental (10,2 ± 2,0) foi menor que no grupo**<br>**controle (19,3 ± 6,0) (p<0,05), sugerindo que a manutenção da atropina de**<br>**forma sustentada ajuda a estabilizar a progressão da doença. A taxa de**<br>**letalidade no grupo experimental foi menor do que o grupo controle (10% vs**<br>**26,7%, p <0,05).**||
|**Conclusão:**O estudo sugere que a infusão contínua (_continuous micropump_) de<br>atropina e cloreto de pralidoxima combinada é mais eficaz do que o uso de injeção<br>de bolus repetidos no tratamento de intoxicação aguda grave por<br>organofosforados.||
|Limitações: O estudo avaliou poucos pacientes, de forma que o menor tamanho de<br>amostra calculada  seria de 50 pacientes por grupo. Não foi avaliada a relação<br>entre a concentração de atropina plasmática e/ou pralidoxima e os desfechos. As<br>concentrações séricas/urinárias do organofosforado não foram monitoradas. Não<br>foi realizado um exame toxicológico completo para avaliar as possibilidades de<br>exposição a mais de um agente tóxico.||  
98  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Biodisponibili**<br>**dade do**<br>**sulfato de**<br>**atropina**|**Sulfato de**<br>**atropina**|**Estudo feito em Delhi, na Índia, com objetivo de criar uma injeção sublingual**<br>**de sulfato de atropina e descrever sua biodisponibilidade para avaliar seu uso**<br>**em campo (principalmente em caso de intoxicação massiva por ataques**<br>**terroristas). Um objetivo secundário foi usar técnicas de cintilografia no**<br>**processo de desenvolvimento da formulação sublingual.**Sulfato de atropina<br>(2% wt/vol) foi dissolvido em água bidestilada, cloreto de sódio (0,9% wt/vol) foi<br>adicionado para tornar a solução isotônica. A farmacocinética e a análise de<br>toxicidade-eficácia foi realizada em 6 voluntários masculinos saudáveis, após<br>administração de 2 mg/0,1 mL de sulfato de atropina por injeção sublingual em<br>única dose. Amostras de sangue dos voluntários foram recolhidas após 10, 15, 30,<br>60 e 120 minutos. A frequência cardíaca e o nível de oxigenação sanguínea foram<br>medidos com um oxímetro de pulso, a dilatação da pupila foi observada e o<br>aparecimento de efeitos colaterais como boca seca e visão embaçada foi<br>registrado. O radionuclídeo Tc 99m foi utilizado para a cintilografia: 2 gotas<br>foram adicionadas à formulação administrada aos voluntários e a absorção foi<br>comparada a outro voluntário de um estudo paralelo diferente que recebeu o<br>mesmo radionuclídeo por via intramuscular na região glútea.<br>Os voluntários tinham 20.8 ± 2.17 anos, pesavam 59.67 ± 4.76 kg e tinham 164.01<br>± 3.99 cm de altura, em média. Análise cintilográfica mostrou que 85% da droga<br>foram liberados do local de injeção em 10 minutos, enquanto a absorção da região<br>glútea foi de 24%. A maior variação da frequência cardíaca entre os voluntários<br>foi observada após 10 minutos (aumento de 61.98% ± 5.81%), não houve<br>diferença na saturação de oxigênio, o aumento máximo da dilatação da pupila<br>aconteceu após 15 minutos (aumento de 58.33% ± 20.97%). Em 10 minutos após<br>a aplicação sublingual, a concentração sanguínea medida foi superior a 14 ng/mL,<br>com pico máximo de 20 ng/mL em 15 minutos, enquanto o pico terapêutico de<br>administração intramuscular é de 6 a 8 ng/mL, em 30 minutos. Todos os|**Rajpal**S et<br>al.,**2010**.<br>Clinical and<br>bioavailabilit<br>y studies of<br>sublingually<br>administered<br>atropine<br>sulfate.<br>Busca<br>Sistemática|Fase 1 de<br>ensaio<br>clínico|_-_|
|---|---|---|---|---|---|---|  
99  
|voluntários apresentaram sintomas precoces de atropinização como boca seca,<br>visão embaçada e sede após 15 a 30 minutos.|
|---|
|**Conclusão**: Os autores sugerem que a via de injeção sublingual deva ser<br>considerada nos casos de intoxicação grave por organofosforados, principalmente<br>para intoxicações em massa. Entretanto, a via de administração pode não ser tão<br>bem aceita como as vias convencionais. Além disso, os autores citam aperto entre<br>os dentes como possível efeito da intoxicação por organofosforados, limitando sua<br>utilização nesses casos.|  
**Quadro III.1.2.Síntese de evidências para a intervenção “Atropina (necessidade de oxigênio)” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|1.<br>Trata<br>mento<br>não<br>farma<br>cológi<br>co|**Mortes**<br>**precoces**|**Oxigênio**|Uma das motivações para este estudo foi a frequente indisponibilidade de suporte<br>de oxigênio em hospitais distritais na Ásia rural, onde a maioria das intoxicações<br>com inseticidas ocorrem. Além disso, os autores realizaram uma revisão na<br>literatura e encontraram 28 publicações do período entre 1959 e 2012 que<br>afirmavam que a atropina (i) não deveria ser administrada antes do oxigênio, ou<br>que (ii) deveria idealmente não ser administrada antes do oxigênio devido ao risco<br>de provocar disritmias ventriculares em pacientes hipóxicos intoxicados por<br>organofosforados. Porém, apenas 2 desses artigos apresentavam evidência de<br>disritmia ventricular após a administração de atropina, mas não havia uma<br>correlação estatística.<br>Assim, foi feita uma coorte prospectiva de todos pacientes intoxicados com<br>organofosforados e carbamatos tratados com atropina inicial, sem o benefício do<br>oxigênio, em dois hospitais do Sri Lanka de março de 2002 a setembro de 2005.|**Konickx**LA<br>et al.,**2014**.<br>Is oxygen<br>required<br>before<br>atropine<br>administratio<br>n in<br>organophosp<br>horus or<br>carbamate<br>pesticide<br>poisoning?-|Coorte|Não grave|  
100  
|Este estudo englobou dois estudos clínicos randomizados controlados. A|A cohort|
|---|---|
|incidência de paradas cardíacas primárias fatais dentro de 3 h da admissão foi<br>usada como um marcador sensível (mas não específico) de possíveis disritmias<br>ventriculares. Todos os pacientes receberam tratamento de rotina, incluindo<br>atropina, carvão ativado e/ou pralidoxima ou não (dependendo do grupo nos<br>estudos clínicos); nenhum paciente recebeu êmese forçada; pacientes que<br>admitidos dentro de 1 h e com ingestão potencialmente fatal e que forneceram<br>consenso receberam lavagem gástrica.|study.<br>Busca<br>Sistemática|
|O estudo avaliou**1957 pacientes**.**A incidência de óbitos por parada cardíaca**<br>**dentro de 3 h da administração de atropina foi 4/1957 (0,2%). A maioria dos**<br>**óbitos ocorreu posteriormente por complicações respiratórias da intoxicação.**<br>||
|É possível que a atual incidência de disritmias ventriculares não fatais seja maior<br>que essa; porém, os dados sugerem que as graves disritmias induzidas por<br>atropina não são um grande problema clínico.||
|**Conclusão:**Não foram encontradas evidências de um alto número de mortes<br>precoces em 1957 pacientes que receberam atropina antes do suporte com<br>oxigênio que possam suportar que o oxigênio deva ser administrado antes da<br>atropina. A literatura indica que a administração inicial e rápida de atropina<br>durante a ressuscitação é crítica para a vida do paciente. Assim, o estudo sugere<br>que havendo oxigênio ou não, a atropinização do paciente intoxicado com<br>organofosforados ou carbamatos deve ser realizada.||  
**Quadro III.1.3.Síntese de evidências para a intervenção “Oximas” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
101  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**incidência de**<br>**síndrome**<br>**intermediária;**<br>**necessidade**<br>**de ventilação**|**Oxima**|7 ensaios clínico randomizados,**total de 845 pacientes**. Essa revisão teve como<br>objetivo quantificar a eficácia e segurança da administração de oximas em<br>pacientes com intoxicação aguda por organofosforados.<br>Os sete ensaios clínicos analisados obtiveram resultados díspares, com os efeitos<br>do tratamento variando de benefícios a danos. No entanto, muitos estudos não<br>consideraram várias questões importantes para os desfechos: as características<br>basais não foram balanceadas, as doses variaram muito, houve atraso substancial<br>para o tratamento, o tipo de organofosforado não foi considerado, dentre outras.<br>Apenas um RCT comparou a dose recomendada pela OMS com doses placebo.<br>Esse ensaio não mostrou benefícios clínicos, e houve uma tendência para danos<br>em todos os subgrupos, apesar da clara evidência que as doses utilizadas<br>reativaram acetilcolinesterase no sangue.<br>Oxima vs. placebo<br>● Desfecho 1: morte<br>Total de eventos: 47/186 no tratamento vs. 22/180 no controle<br>OR = 2,68 [0,93 – 7,72 ]<br>Heterogeneidade: Tau<sup>2</sup>= 0,42; Chi<sup>2</sup>= 3,82, df = 2 (P = 0,15); I<sup>2</sup>=48%<br>● Desfecho 2: síndrome intermediária<br>Total de eventos: 36/55 no tratamento vs. 19/55 no controle<br>OR = 3,59 (1,64 – 7,88)<br>Heterogeneidade: não aplicável<br>● Desfecho 3: ventilação<br>Total de eventos: 70/186 no tratamento vs. 50/180 no controle<br>OR = 2,0 (0,81 – 4,95)|**Buckley**NA<br>et al.,**2011**.<br>Oximes for<br>acute<br>organophosp<br>hate<br>pesticide<br>poisoning.<br>Busca<br>Sistemática|Metanálise|Não grave|  
102  
||||Heterogeneidade: Tau<sup>2</sup>= 0,39; Chi<sup>2</sup>= 5,62, df = 2 (P = 0,06); I<sup>2</sup>=64%<br>Alta dose vs. baixa dose<br>● Desfecho 1: morte<br>Total de eventos: 13/256 com alta dose vs. 25/223 com baixa dose<br>OR = 0,38 [0,10 – 1,47]<br>Heterogeneidade: Tau<sup>2</sup>= 1,14; Chi<sup>2</sup>= 7,83, df = 3 (P = 0,05); I<sup>2</sup>=62%<br>● Desfecho 2: síndrome intermediária<br>Total de eventos: 32/160 com alta dose vs. 30/123 com baixa dose<br>OR = 0,94 [0,24 – 3,62]<br>Heterogeneidade: Tau<sup>2</sup>= 0,92; Chi<sup>2</sup>= 7,06, df = 2 (P = 0,03); I<sup>2</sup>=72%<br>● Desfecho 3: ventilação<br>Total de eventos: 88/136 com alta dose vs. 105/136 com baixa dose<br>OR = 0,72 [0,08 – 6,35]<br>Heterogeneidade: Tau<sup>2</sup>= 2,28; Chi<sup>2</sup>= 13,18, df = 1 (P = 0,00028); I<sup>2</sup>=92%<br>Todos os desfechos foram avaliados como “qualidade muito baixa” de evidência<br>pela metodologia GRADE.||||
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Reativação**<br>**da BuChE**|**Pralidoxim**<br>**a**|**Estudo com objetivo de examinar a reativação da butirilcolinesterase**<br>**(BuChE) em pacientes de dois estudos prévios realizados no Sri Lanka, um**<br>**estudo de coorte e um ensaio clínico controlado randomizado.**Em ambos os<br>estudos, amostras de sangue foram recolhidas antes e depois da administração de<br>pralidoxima; foram medidas a atividade plasmática da BuChE e as concentrações<br>de pralidoxima e do organofosforado envolvido na intoxicação. Os valores médios<br>de controle da AChE e da BuChE foram 586 (SD 5) mU/mmol Hb e 5932 (SD 33)<br>mU/mL, respectivamente, e o limite inferior normal da BuChE foi de 3000<br>mU/mL.|**Konickx**LA<br>et al.,**2013**.<br>Reactivation<br>of plasma<br>butyrylcholin<br>esterase by<br>pralidoxime<br>chloride in<br>patients<br>poisoned by|Metanálise|Muitos<br>pacientes<br>foram<br>excluídos<br>por não<br>atenderem<br>os<br>critérios,<br>inclusive<br>do estudo<br>controlad|  
103  
|**Foram observadas diferenças na atividade da BuChE no momento da**<br>**admissão nos dois estudos, e essas diferenças foram atribuídas ao tipo de**<br>**agente intoxicante: pacientes com intoxicação por clorpirifós tiveram menor**<br>**atividade (p<0,001) quando comparados aos com intoxicação por dimetoato.**<br>**Houve menos pacientes com intoxicação por fention e quinalfos, mas ambos**<br>**causaram maior inibição da atividade da BuChE em comparação ao**<br>**dimetoato (p = 0,002 e p = 0,001, respectivamente).**<br>**No ECR, os pacientes receberam inicialmente uma dose de 2 g de**<br>**pralidoxima durante 20 minutos, seguida por infusão contínua à taxa de**|WHO class<br>II toxicity<br>organophosp<br>horus<br>insecticides.<br>Busca<br>Sistemática|o<br>randomiz<br>ado|
|---|---|---|
|**0,5g/h.**A concentração máxima de pralidoxima 1h depois da aplicação foi de 250<br>µmol/L e a concentração estacionária foi de aproximadamente 100 µmol/L.**As**<br>**concentrações não foram medidas no estudo de coorte, mas os autores**<br>**estimam que a administração rápida (tipicamente <1 min) de 1 g de**<br>**pralidoxima geraria uma concentração máxima superior que a dose de 2 g**,<br>mas a queda de concentração seria mais rápida e com meia-vida inferior a 1h.<br>**Ambos os regimes reativaram a atividade da AChE: 1 ou 2 g de pralidoxima**<br>**seguido de infusão a 0,5 g/h aumentaram a atividade média de AChE após 1h**<br>**em 139 (95% IC 94-184, p<0,001) e 170 (95% IC 134-205, p<0,001) mU/µmol**<br>**Hb, respectivamente.**|||
|**Considerando a população total da coorte, o tratamento com bolus de 1 g de**<br>**pralidoxima não reativou a atividade da BuChE após 1h (diferença média de**<br>**55 mU/ml [95% IC −64 a 174, p = .36]), os bolus seguintes a cada 6h não**<br>**tiveram efeito aparente nas primeiras 24h. A população total do ECR que**<br>**recebeu dose inicial de 2 g em 20 minutos seguida de 0,5 mg/h apresentou**<br>**reativação significativa da BuChE na primeira hora, em que a foi diferença**<br>**máxima (diferença média de 416 mU/ml [95% IC 262 a 571, p < .001]), que**<br>**decaiu ao longo das 48h seguintes até ser inibida novamente. A AChE foi**<br>**reativada de maneira sustentada ao longo do tempo.**|||  
104  
|Para intoxicação com dimetoato na coorte / no ECR:|
|---|
|A atividade da BuChE diminuiu de maneira não significativa na primeira hora<br>(diferença média de −59 mU/ml [95% IC −395 a 278, p = 0,69]) / não houve<br>reativação significativa (diferença média de 22 mU/ml [95% IC −142 a 186, p =<br>0,79])|
|Para intoxicação com clorpirifós na coorte / no ECR:|
|Não houve reativação significativa (diferença média de 50 mU/ ml [95% IC −96 a<br>195, p = 0,50]) / pequena reativação (a 17% do limite normal inferior; diferença<br>média de 513 mU/ml [95% IC 310 a 716, p < 0,001])|
|Para intoxicação com quinalfos na coorte / no ECR:|
|Não houve reativação significativa (diferença média de 338 mU/ml [95% IC −567<br>a 1244, p = 0,36]) / pequena reativação (a 36% do limite normal inferior;<br>diferença média de 1076 mU/ml [95% IC −320 a 2472, p = 0,10]).|
|Para intoxicação com fention na coorte / no ECR:|
|Não houve reativação significativa (diferença média de 5 mU/ml [95% IC −25 a<br>34, p = 0,66]) / não houve reativação significativa (diferença média de 0 mU/ml<br>[95% IC −59 a 58, p = 0,99]).|
|**Conclusão**: Os autores mostram que um bolus de 1 g de pralidoxima não reativa a<br>BuChE para todos os intoxicantes estudados, enquanto o regime 2 g em 20<br>minutos seguida por infusão de 0,5 mg/h reativa a BuChE, mas de maneira não<br>sustentada, para intoxicantes do subgrupo dietil de organofosforados. Eles<br>sugerem que o uso da reativação da BuChE como marcador da dose de<br>pralidoxima - e de sua eficácia - não é um critério relevante, mas sim a atividade<br>da AChE. Como esta pode não ser clinicamente relevante, eles sugerem que<br>marcadores clínicos, como testes neurofisiológicos da função da junção<br>neuromuscular, possam ser mais úteis na dosagem de pralidoxima (e outras<br>formas de oxima) doque marcadores bioquímicos. Também afirmamque a|  
105  
||||reativação da BuChE causada por pralidoxima é altamente variável com a dose, o<br>tipo de intoxicante e o paciente envolvidos.|||
|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**Necessidade**<br>**de ventilação;**<br>**Tempo de**<br>**permanência**<br>**no hospital**|**Pralidoxim**<br>**a**|**Total de 120 pacientes.**Os pacientes foram atendidos em um hospital de<br>tratamento terciário em West Bengal, na Índia, por um período de dois anos a<br>partir de junho de 2008. Todos os pacientes possuíam mais de 12 anos de idade,<br>eram de ambos os sexos, de idades variadas, e apresentaram-se ao hospital dentro<br>de 24 h a partir da exposição ao composto organofosforados (pacientes expostos a<br>pesticidas carbamatos foram excluídos).<br>Os 120 pacientes foram divididos em dois grupos homogêneos (n=60 cada) e<br>receberam tratamento com apenas**atropina (controle)**ou com**atropina mais**<br>**pralidoxima**. A atropina foi administrada na dose ataque de 2 mg IV seguida de 2<br>mg IV a cada 5-10 min até a atropinização. Então, o intervalo entre as doses foi<br>aumentado de forma a manter a atropinização adequada. A atropina foi lentamente<br>retirada em um período de 5 dias. No grupo tratado com pralidoxima, a atropina<br>foi dada da mesma maneira do grupo controle, com adição de cloreto de<br>pralidoxima em uma dose de 1 g IV a cada 6 h por um período de 5 dias.<br>**O tratamento com adição de pralidoxima não forneceu nenhum benefício**<br>**considerável em relação ao tratamento com atropina sozinha em termos de**<br>**reduzir a mortalidade [18,33% (11/60) vs. 13,33% (8/60); atropina mais**<br>**pralidoxima vs. atropina] ou a necessidade de ventilação [5% (3/60) vs.**<br>**8,33% (5/60)].** **Além disso, os pacientes com tratamento adicional de**<br>**pralidoxima tiveram maior período de permanência no hospital (7,02 ± 1,12**<br>**dias) que o grupo controle (5,68 ± 1,87 dias) (P < 0,001).**Nenhuma reação<br>adversa significante foi reportada em nenhum dos braços de tratamento.<br>Neste estudo, 19 dos 120 pacientes morreram durante a permanência no hospital,<br>resultando em uma taxa de mortalidade de 15,83%.<br>**Conclusão:**O estudo sugere que a adição de pralidoxima no tratamento com<br>atropina não fornece nenhum benefício considerável, em termos de reduzir a taxa|**Banerjee**I et<br>al.,**2014**.<br>Efficacy of<br>pralidoxime<br>in<br>organophosp<br>horus<br>poisoning:<br>revisiting the<br>controversy<br>in Indian<br>setting.<br>Busca<br>Sistemática|Ensaio<br>clínico<br>randomizad<br>o<br>(_open-_<br>_label,_<br>_parallel_<br>_group,_<br>_randomized_<br>_clinical_<br>_trial_)|  
106  
|||de mortalidade e a necessidade por ventilação, em comparação com o tratamento<br>apenas com atropina na gestão de pacientes intoxicados com organofosforados.<br>Porém, mais ensaios clínicos são necessários para explorar os diferentes regimes<br>de dosagem da pralidoxima a fim de determinar sua eficácia no tratamento desse<br>tipo de intoxicação.||||
|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade,**<br>**taxa de**<br>**intubação,**<br>**síndrome**<br>**intermediária**|**Total de 46 pacientes com idade >16 anos apresentando evidências de**<br>**envenenamento por organofosforados,**recebidos entre agosto de 2010 e julho<br>de 2013 em Taiwan, randomizados em 2 grupos, 24 no grupo controle e 22 no<br>grupo experimental. A identificação do envenenamento foi baseada em histórico<br>de exposição, aspectos clínicos e queda da atividade da butirilcolinesterase<br>(BuChE), definida como menor que 3000 U/L. O estudo excluiu pacientes com<br>histórico incerto de exposição, envenenamento por carbamato, ingestão de outros<br>intoxicantes fatais, intoxicação superior a 24h e mulheres grávidas. Todos os<br>pacientes receberam lavagem gástrica, administração de carvão ativado quando<br>não havia contraindicação, proteção das vias respiratórias e outros tratamentos de<br>suporte, como intubação, quando necessário. Atropina foi administrada em doses<br>de 1 mg a cada 10 minutos, e todos os pacientes receberam inicialmente uma dose<br>de 2 mg de pralidoxima. Ogrupo controlefoi tratado de acordo com a<br>recomendação da OMS para o uso da pralidoxima, 500 mg/h.<br>Ogrupo experimentalfoi tratado de acordo com o escore APACHE II de cada<br>paciente e as mudanças dinâmicas na atividade da BuChE. Se o escore era≥26<br>ou, caso o escore fosse <26 e não houvesse aumento da atividade da BuChE na<br>12ª hora, comparada com a 6ª hora ([BuChE]12- [BuChE]6/[BuChE]12< 5%),<br>doses de 1 g/h de pralidoxima eram dadas. Essas doses eram descontinuadas caso<br>os sintomas de intoxicação desapareciam ou o paciente dava sinais de fracasso no<br>tratamento. Para o escore <26, pralidoxima era administrada à taxa de 500 mg/h<br>até a 12ª hora, quando era checada a atividade da BuChE.|**Lin**CC et<br>al.,**2016**.<br>The<br>effectiveness<br>of patient-<br>tailored<br>treatment for<br>acute organo<br>phosphate<br>poisoning.<br>Busca<br>Sistemática|Estudo<br>clínico<br>randomizad<br>o<br>controlado<br>não cego<br>(_randomize_<br>_d open-_<br>_label_<br>_controlled_<br>_study_)|Aberto,<br>apenas<br>dois<br>centros|  
107  
|Não houve diferenças entre características dos grupos. Também não houve|
|---|
|diferença inicial entre as doses de atropina ou de pralidoxima recebidas pelos|
|grupos, mas as doses de pralidoxima foram maiores no grupo experimental nas<br>48h após o tratamento [31,55 ± 10,20 vs 22,27 ± 5,87 mg, p = 0,0001].**A taxa de**|
|**intubação e a ocorrência de síndrome intermediária não apresentaram**<br>**diferenças entre os grupos. A mortalidade total do estudo foi de 8/46**<br>**(17,39%), e foi maior no grupo controle (7/24, 29,17%) que no grupo**<br>**experimental (1/22, 4,55%). A taxa de risco (HR) de morte obtida por ajuste**<br>**multivariado no grupo controle foi 111,15 (95%CI = 1,71-10617,45; p = 0,04)**<br>**em relação ao grupo experimental. Os autores sugerem que a taxa**<br>**respiratória e o**escore**APACHE II foram associados com a mortalidade. As**<br>**taxas de risco para taxa respiratória e**escore**APACHE II **≥**26 foram 0,42**<br>**(95%CI = 0,23-0,76; p = 0,004) e 7,82 (95%CI = 1,01-60,33; p = 0,05),**<br>**respectivamente.**|
|As mudanças de atividade da BuChE não foram associadas ao tempo e não foram|
|diferentes entre grupos nas primeiras 48h após tratamento com pralidoxima.**As**<br>**mudanças na RBC (red blood cell) AChE foram significativamente diferentes**<br>**entre grupos: foi observado um aumento no grupo experimental (inclinação**<br>**de 0,207) e uma diminuição no grupo controle (inclinação de -0,34).**|
|**Todos os pacientes tiveram concentração sérica de pralidoxima superior a 4**<br>**mg/L**e não houve diferenças entre grupos. Não foram detectados danos ao fígado<br>em nenhum dos grupos.**Pacientes do grupo experimental apresentaram maior**<br>**pressão arterial sistólica nas primeiras 24h (124,77 ± 40,71/82,27 ± 23,10 vs**<br>**148 ± 28,83/87,14 ± 17,98, p = 0,59), que se normalizou no período de 48h**<br>**(128,73 ± 23,82/71,73 ± 15,99 vs 126,90 ± 23,34/74,70 ± 16,36, p = 0,80).**|
|**Conclusão**: Os autores sugerem que o uso de doses flexíveis de pralidoxima, de<br>acordo com indicadores de prognóstico apresentados pelo paciente, pode ser uma<br>melhor alternativa ao uso de doses fixas deste medicamento no caso de|  
108  
||||envenenamento por organofosforados, considerando a mortalidade como critério<br>de julgamento principal. Para todos os outros critérios, não houve diferenças entre<br>grupos. Entretanto, ambos os grupos do estudo tiveram número reduzido de<br>pacientes, tendo o grupo controle apenas 22 pacientes.|||
|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade,**<br>**necessidade**<br>**de intubação,**<br>**necessidade**<br>**de ventilação**<br>**e duração,**<br>**tempo de**<br>**permanência**<br>**na UTI,**<br>**necessidade**<br>**de**<br>**traqueostomia**<br>**, incidência de**<br>**síndrome**<br>**intermediária,**<br>**infecções e**<br>**outras**<br>**complicações**|**Pralidoxim**<br>**a**|A OMS recomenda o uso de pralidoxima para pacientes com intoxicação aguda<br>por organofosforados, mas estudos que mostram sua eficácia são inconclusivos. O<br>estudo de Pawar et al. (2006) mostrou diminuição da morbidade e mortalidade<br>usando regime de pralidoxima de alta dose, enquanto que estudo de Eddleston et<br>al. (2009) concluiu que o uso de pralidoxima estava associado ao aumento da<br>mortalidade. Assim, este estudo teve como objetivo avaliar a efetividade da<br>pralidoxima, e foi conduzido no Departamento de Anestesiologia e Cuidado<br>Crítico em Kashmir, Índia, de julho de 2010 a agosto de 2012. Foram incluídos<br>**100 pacientes**com intoxicação moderada a severa por organofosforados, entre 14<br>e 60 anos, admitidos antes das 12 h após a exposição.<br>Todos os pacientes receberam o tratamento de rotina para organofosforados, que<br>incluiu descontaminação e ressuscitação para a via aérea, respiração e circulação.<br>A atropina foi administrada em bolus IV de 2-3 mg, e a dose foi dobrada a cada 5<br>min até a atropinização. Posteriormente, a atropina continuou como uma infusão à<br>razão de 20-80 μg/kg/min e foi titulada para as doses finais de terapia com<br>atropina (frequência cardíaca >100 bpm, boca seca, pulmões claros na<br>auscultação, normalização dos sons intestinais, pupilas dilatadas).A atropina foi<br>retirada lentamente durante um período de 3-5 dias.<br>Grupo AP: os pacientes receberam pralidoximaconforme as indicações da OMS -<br>30 mg/kg de dose de carga ao longo de 30 min seguido de infusão contínua de 8<br>mg/kg/h por um máximo de 7 dias, presumindo que este seria o período máximo<br>de inibição ativa da AChE na maioria dos pacientes, ou até a melhora clínica.<br>Grupo placebo (A): recebeu solução salina IV.|**Syed**S et al.,<br>**2015**. Is the<br>World<br>Health<br>Organization<br>-<br>recommende<br>d dose of<br>pralidoxime<br>effective in<br>the treatment<br>of<br>organophosp<br>horus<br>poisoning? A<br>randomized,<br>double-<br>blinded and<br>placebo-<br>controlled<br>trial.|Estudo<br>clínico<br>randomizad<br>o<br>controlado<br>duplo cego|  
109  
||||Os níveis de pseudocolinesterase foram medidos no momento da admissão, após<br>24, 72 e 120 h, e no dia da alta ou último nível medido antes da morte.<br>Não houve diferenças significativas nos compostos OP ingeridos entre os dois<br>grupos (P> 0,05).**Não houve diferença significativas nas taxas de mortalidade,**<br>**necessidade de atropina e incidência de síndrome intermediária entre os**<br>**grupos AP e A (p>0,5). A necessidade de suporte ventilatório (62% no grupo**<br>**AP****_vs_58% no grupo A), a duração média da ventilação (3,5 ± 4,6 no grupo**<br>**AP****_vs_3,6 ± 4,4 no grupo A) e a permanência na UTI (7,1 ± 5,4 no grupo AP**<br>**_vs_6,8 ± 4,7 no grupo A) foi comparável e sem diferença estatística entre os**<br>**grupos (p>0,05). Os dois grupos também não diferiram significativamente em**<br>**relação às complicações (p>0,05).**<br>As concentrações séricas de sódio na admissão apresentaram correlação com a<br>mortalidade, com maiores concentrações associadas a piores desfechos. A<br>correlação entre hipernatremia e mortalidade foi estatisticamente significativa<br>(p<0,05).<br>**Conclusão:**O estudo sugere que a terapia adicional com pralidoxima<br>recomendada pela OMS não oferece nenhum benefício sobre a monoterapia com<br>atropina. A adição de pralidoxima não parece ser benéfica e, ao mesmo tempo,<br>não resulta em taxas de mortalidade aumentadas. Essa prática, adotada pelos<br>autores, reduziu o custo do tratamento.|Busca<br>Sistemática|||
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Duração da**<br>**hospitalização**<br>**, necessidade**<br>**de ventilação**<br>**mecânica,**<br>**redução do**<br>**tempo de**|**Pralidoxim**<br>**a**|**Total de 34 pacientes**recebidos entre março de 2004 e setembro de 2005 em<br>Adana, na Turquia, intoxicados com organofosforados, foram randomizados em 2<br>grupos (n=17 cada): o grupo 1 recebeu uma única dose de 2 g de pralidoxima<br>durante 20 minutos, enquanto o grupo 2 recebeu a dose inicial de 2 g de<br>pralidoxima seguida de infusão de pralidoxima à taxa de 6 g/24h. Todos os<br>pacientes foram avaliados pela escala GCS e uma solução salina de 3000 mL/m2<br>e 5% de dextrose foi administrada diariamente, também foi realizada lavagem<br>gástrica e administração de carvão ativado. Pacientes com SaO2≤90% e GCS≤8|**Kozaci**N et<br>al.,**2012**.<br>Comparison<br>of single-<br>dose<br>pralidoxime<br>and<br>pralidoxime|Ensaio<br>clínico<br>controlado<br>randomizad<br>o aberto<br>monocêntri<br>co|Estudo<br>aberto,<br>autores<br>não<br>explicam<br>como foi<br>feita a<br>randomiz|  
110  
|**ventilação**<br>**mecânica**|foram intubados e receberam ventilação mecânica. Um catéter urinário foi<br>inserido e os pacientes recebiam fluidos de acordo com a excreção urinária, 1<br>mg/kg/dia de atropina foi administrado em infusão contínua até que sintomas<br>anticolinérgicos fossem observados nos pacientes.<br>Não houve diferenças significativas nas características dos grupos. Não houve<br>diferença no tempo de atropinização, dose total de atropina nem no tempo total de<br>tratamento com atropina. Também não houve diferença significativa no tempo de<br>hospitalização. Foi medido o nível sérico de butirilcolinesterase (BCHE) na<br>chegada ao hospital e todos os pacientes apresentavam níveis inferiores a 3200<br>U/L, sem diferença entre grupos (p<0,05). Na alta hospitalar, 12 pacientes do<br>grupo 1 e 10 pacientes do grupo 2 ainda apresentavam níveis séricos de BCHE <<br>3200 U/L.<br>**Conclusão**: Os autores não encontraram associação entre a forma de<br>administração de pralidoxima e o prognóstico dos pacientes, nem encontraram<br>relação entre os níveis de BCHE e a severidade dos sintomas da intoxicação. Eles<br>sugerem que a terapia de infusão de pralidoxima não oferece nenhuma vantagem<br>em relação à terapia de dose única, mas indicam que estudos com efetivo maior de<br>pacientes são necessários para obter resultados mais precisos.|infusions for<br>the treatment<br>of<br>organophosp<br>hate<br>poisoning.<br>Busca<br>Sistemática|ação,<br>estudo<br>pequeno e<br>monocênt<br>rico|
|---|---|---|---|  
**Quadro III.1.4.Síntese de evidências para a intervenção “Carvão ativado” para o tratamento inicial farmacológico de pacientes com intoxicação aguda** **<u>por PIC.</u>**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|  
111  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade**;<br>**desenvolvime**<br>**nto de** **falha**<br>**respiratória;**<br>**duração da**<br>**ventilação**<br>**mecânica.**|**Carvão**<br>**ativado +**<br>**catártico**|**Total de 198 pacientes**. O objetivo deste estudo foi avaliar o efeito da<br>administração de carvão ativado-sorbitol de acordo com o intervalo de tempo<br>entre a ingestão de organofosforado e a administração do tratamento.<br>Foram incluídos pacientes que não receberam carvão ativado-sorbitol ou que<br>receberam uma dose única de carvão-sorbitol dentro de 24 h após a ingestão de<br>organofosforado. Os pacientes foram divididos em 3 grupos:<br>1. Sem tratamento com carvão ativado-sorbitol (n=133)<br>2. pacientes que receberam carvão ativado-sorbitol dentro de 1 h da ingestão de<br>organofosforado (n=14)|**Moon**J et<br>al.,**2015**.An<br>exploratory<br>study; the<br>therapeutic<br>effects of<br>premixed<br>activated cha<br>rcoal-sorbitol<br>administratio|Observacio<br>nal (Série<br>de casos<br>retrospectiv<br>a)|Grave (-<br>1)|
|---|---|---|---|---|---|---|
||||3. pacientes que receberam carvão ativado-sorbitol após 1 h da ingestão de<br>organofosforado (n=51)<br>Um total de 155 pacientes (78,3%) desenvolveram falha respiratória e<br>necessitaram de ventilação mecânica por uma média de 9,4±0,9 dias. A taxa de<br>mortalidade foi de 14,6%. Independentemente do tempo de ingestão do OP para a<br>administração do tratamento,**a administração de carvão ativado-sorbitol não**<br>**exerceu efeitos benéficos sobre os desfechos de pacientes intoxicados com OP**<br>**em relação ao grupo controle, nem aumentou significativamente a**<br>**pneumonia aspirativa ou desequilíbrio eletrolítico**.<br>Mortalidade<br>·         controle vs. tratamento <1h: OR, 1,062 [95% CI, 0,221 – 5,108]<br>·         controle vs. tratamento >1h: OR, 1,113 [95% CI, 0,440 – 2,816]<br>·         tratamento < 1h vs. tratamento > 1h: OR, 1,408 [95% CI, 0,192 –<br>5,713]|n in patients<br>poisoned<br>with<br>organophosp<br>hate<br>pesticide.<br>Busca<br>Sistemática|||
||||Falha respiratória<br>·         controle vs. tratamento <1h: OR, 2,286 [95% CI, 0,707 – 7,398||||  
112  
|·         controle vs. tratamento >1h: OR, 1,266 [95% CI, 0,583 – 2,751]<br>·         tratamento <1h vs. tratamento >1h: OR, 0,554 [95% CI, 0,155 –<br>1,973])|
|---|
|Duração da ventilação mecânica|
|·         controle: 5 dias (0,0 – 11,0)<br>·         tratamento <1h: 5 dias (0,0 – 9,5)<br>·         tratamento <1h: 7 dias (0,0 – 18,0)|
|**Observação:**o estudo teve um pequeno número de pacientes que receberam<br>carvão - sorbitol; novos estudos qualificados envolvendo um número maior de<br>pacientes, portanto, são necessários.|  
#### **Quadro III.1.5.Síntese de evidências para a intervenção “Terapia com substituição de butirilcolinesterase (troca de plasma)” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**Incidência de**<br>**síndrome**<br>**intermediária;**<br>**necessidade**<br>**de ventilação**<br>**mecânica;**<br>**exigência de**<br>**atropina.**|**Plasma**<br>**Fresco**<br>**Congelado**|**Total de 70 pacientes.**Os pacientes foram admitidos em uma unidade de<br>tratamento terciário em um hospital universitário na Índia entre outubro de 2007 e<br>dezembro de 2008. Os pacientes apresentavam sinais de intoxicação significativa<br>dentro de 12 h da ingestão de organofosfatos, com supressão da atividade de<br>pseudocolinesterase (<1.000 U/L). Eles foram randomizados em três grupos para<br>receber, em adição à atropina e tratamento de suporte: (i)**Plasma Fresco**<br>**Congelado**(8 bolsas, 250 mL cada, durante 3 dias; n=19); (ii)**albumina**humana<br>20% (4 x 100 mL durante 3 dias; n=20); ou (iii)**salina**(2.000 mL durante 3 dias;|**Pichamuthu**<br>K et al.,<br>**2010**.<br>Bioscavenger<br>therapy for o<br>rganophosph<br>ate<br>poisoning-<br>an open-|Estudo<br>clínico<br>randomizad<br>o<br>controlado<br>(_open label,_<br>_three-arm,_<br>_randomized_|Não grave|  
113  
|n=19). Os níveis de pseudocolinesterase e organofosfato foram medidos antes do<br>tratamento, após a infusão (dias 2 e 3) e antes da alta médica.|labeled pilot<br>randomized|_controlled_<br>_study_)|
|---|---|---|
|O Plasma Fresco Congelado (PFC) aumentou os níveis de pseudocolinesterase|trial<br>||
|(250 ± 44–1.241 ± 364 U/L) significativamente (p = 0,007). Pequenos aumentos|comparing||
|não significativos foram observados com albumina (146 ± 18–220 ± 61) e salina|fresh||
|(160 ± 30–259 ± 78). Os níveis de organofosfatos reduziram nos três grupos.|frozen plasm||
|**Foram observados mais casos de síndrome intermediária com PFC [10/19**|a or albumin<br>||
|**(53%)] do que com albumina [5/20 (25%)] ou salina [5/19 (26%)] (p = 0,15).**<br>**As intervenções não afetaram as exigências ventilatórias (14/19 vs. 15/20 vs.**<br>**14/19) ou evitaram intubação tardia**.**Não houve diferença estatística na**<br>**exigência de atropina (em mg) nos 3 primeiros dias (536 ± 132 vs. 361 ± 125**<br>**vs. 789 ± 334), na duração (em dias) da ventilação (10,0 ± 2,1 vs. 7,1 ± 1,5 vs.**|with saline in<br>acute organo<br>phosphate<br>poisoning in<br>humans.||
|**7,5 ± 1,5) ou na permanência no hospital (12,4 ± 2,2 vs. 9,8 ± 1,4 vs. 9,8 ± 1,6).**|||
|Dois pacientes desenvolveram efeitos adversos com PFC.**A taxa de mortalidade**<br>**foi semelhante (4/19 vs. 5/20 vs. 2/19, p = 0,6).**|Busca<br>Sistemática||
|Apesar do aumento significativo dos níveis de pseudocolinesterase, esse estudo<br>não demonstrou tendências favoráveis nos desfechos clínicos com Plasma Fresco|||
|Congelado ou albumina para o tratamento de intoxicação aguda por<br>organofosfatos.|||  
#### **Quadro III.1.6.Síntese de evidências para a intervenção “Terapia de transfusão de hemácias” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|  
114  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Níveis**<br>**sanguíneos de**<br>**AChE; tempo**<br>**médio para**<br>**recuperação**<br>**de AChE;**<br>**quantidade de**<br>**atropina e seu**<br>**período de**<br>**uso; duração**<br>**do uso de**<br>**pralidoxima;**<br>**período de**<br>**permanência**<br>**no hospital**|**Transfusão**<br>**de glóbulos**<br>**vermelhos -**<br>**_Packed red_**<br>**_blood cell_**<br>**_(RBC)_**<br>**_transfusion_**|Total de**80 pacientes**com intoxicação por organofosforados atendidos em uma<br>clínica de emergência e no hospital da província de Zhejiang, na China, entre<br>janeiro de 2014 a janeiro de 2016. Todos os pacientes receberam tratamento de<br>rotina: lavagem gástrica, atropina intravenosa (começando com 1 mg/kg por dia),<br>pralidoxima (IV, 2 g dose única) e cuidado de suporte, como ventilação mecânica,<br>se necessário.<br>Os pacientes foram randomizados em:<br>Grupo com transfusão de RBC:glóbulos vermelhos sanguíneos foram<br>transfundidos 3 h após a intoxicação. 10 h depois da intoxicação, se o paciente<br>ainda não estivesse atropinizado ou tivesse um baixo nível sanguíneo de ChE,<br>outra transfusão de 200 a 400 mL de RBC era realizada. Todas as RBCs foram<br>administradas dentro de 72 h após a intoxicação. 1.RBCs frescas(n=27) referem-<br>se às células estocadas por 10 ou menos dias. 2.RBCs de longo-armazenamento<br>(n=23)  referem-se às células estocadas entre 11 e 35 dias.<br>3.grupo sem transfusão(n=30)<br>Não houve diferença estatística entre os grupos em relação à idade, sexo, níveis<br>médios de AChE, severidade da intoxicação e tempo para admissão na<br>emergência. A via de exposição em todos os pacientes foi oral. 22 pacientes foram<br>intoxicados com diclorvos, 17 com malation, 13 com dimetoato, 12 com<br>metamidofós, 9 com paration e 7 com triclorfon. A duração para a admissão na<br>emergência foi em média 2 h (0,5 a 3,4 h). Os níveis de AChE foram medidos<br>antes e 6 h depois da transfusão de RBC.<br>**No grupo com transfusão de RBC frescas, os níveis sanguíneos de AChE**<br>**foram significativamente maiores (p<0,01), comparando antes e 6 h depois da**<br>**transfusão**(_valores não apresentados, somente em tabela_). Esse aumento deve-se<br>à suplementação de AChE proveniente das células sanguíneas frescas. A diferença<br>não foi significativa em relação à transfusão de RBC de longo-armazenamento.|**Bao**HX et<br>al.,**2017**.<br>Efficacy of<br>fresh packed<br>red blood<br>transfusion<br>in organopho<br>sphate<br>poisoning.<br>Busca<br>Sistemática|Estudo<br>clínico<br>randomizad<br>o<br>controlado<br>(Método de<br>randomizaç<br>ão não<br>descrito)|Grave (-<br>1)|
|---|---|---|---|---|---|---|  
115  
|**O tempo médio para recuperação de AChE para os níveis de 70%**|
|---|
|**(2800KU/L) e 90% (3600KU/L) foi reduzido com a transfusão de RBC:**<br>RBC frescas (em horas): 48,8 ±16,4 (70%) e 105,2 ± 9,2 (90%) (p<0,05 em<br>relação ao controle)|
|RBC de longo armazenamento (em h): 57,7 ± 14,5 (70%) e 115,5 ± 7,8 (90%)<br>(p<0,01 em relação ao controle)|
|Controle (em h): 68,1 ± 17,2 (70%) e 158,5 ± 15,5 (90%)|
|**A transfusão de RBC reduziu a quantidade de atropina e seu período de uso**<br>**nos pacientes intoxicados em comparação ao grupo sem transfusão.**A<br>transfusão de RBC frescas reduziu tanto o uso de atropina por dia (75,8±24,1<br>mg/dia; p<0,05) quanto total (425,8±50,8 mg; p<0,05), assim como a duração do<br>uso de atropina (151,2±16,4 h; p<0,05). A transfusão de RBC de longo<br>armazenamento reduziu apenas o período de utilização da atropina (158,4±21,9 h;<br>p<0,05).|
|Controle: 97,6±27,8 mg/dia; 657,8±62,2 mg total; 172,8±17,5 h.<br>**Adicionalmente, a transfusão de RBC reduziu de forma significativa a**<br>**duração do uso de pralidoxima**: 96,2±8,8 h para RBC frescas (p<0,05);<br>107,1±9,1 h para RBC de longo armazenamento (p<0,05); 135,6±11,8 h para<br>controle.|
|**O período de permanência no hospital foi reduzido pela transfusão de RBC**<br>**frescas**: 12,4±2,7 dias (p<0,05) em relação ao controle sem transfusão (15,5±3,5).<br>O nível do indicador APACHE II (Acute Physiology and<br>Chronic Health Examination II), usado para prever a gravidade em pacientes que<br>requerem intubação, não foi alterado com o tratamento.|  
116  
#### **Quadro III.1.7.Síntese de evidências para a intervenção “Sulfato de Magnésio” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade,**<br>**quantidade de**<br>**atropina**|**Sulfato de**<br>**magnésio**|**Total de 50 pacientes.**O estudo foi realizado em uma unidade médica na Índia,<br>de julho de 2006 a junho de 2007. Foram admitidos pacientes de 12 a 60 anos de<br>idade, com histórico de ingestão de organofosforados e apresentando sintomas<br>típicos de síndrome colinérgica, que não receberam tratamento prévio, como<br>administração de antídotos específicos ou ventilação mecânica, e que se<br>encontravam dentro das 24 h a partir da exposição ao pesticida. Todos os<br>pacientes receberam cuidados básicos com lavagem gástrica, atropina (1,8-3 mg<br>bolus, dobrando a dose a cada 5 min até a atropinização; depois, infusão contendo<br>10-20% da dose inicial para atropinização com redução gradual da dose a uma<br>taxa de 70-80% da dose prévia) e pralidoxima (30 mg/kg por 60 min seguido de 8<br>mg/kg/h até recuperação ou morte).<br>O ensaio foi realizado em quatro grupos sequenciais de pacientes. Os participantes<br>de cada grupo receberam uma dose diferente de sulfato de magnésio<br>(MgSO4.7H2O) 20% administrado como doses em bolus intermitentes (4 g a cada<br>4 h) infundidas IV de 10-15 min ou solução salina (controle) durante as 24 h<br>iniciais. Para cada 4 pacientes que receberam sulfato de magnésio, havia um<br>paciente controle.<br>Grupo A (n=16) recebeu um total de 4 g de magnésio em um bolus único.<br>Grupo B (n=8) recebeu 8 g (2 doses de 4 g a cada 4 h).<br>Grupo C (n=8) recebeu 12 g (3 doses de 4 g a cada 4 h).<br>Grupo D (n=8) recebeu 16 g (4 doses de 4 g a cada 4 h).<br>Controle (n=10) recebeu placebo (salina).|**Basher**A et<br>al.,**2013**.<br>Phase II<br>study<br>of magnesiu<br>m sulfate in<br>acute<br>organophosp<br>hate<br>pesticide<br>poisoning.<br>Busca<br>Sistemática|Estudo<br>clínico fase<br>II|Muito<br>grave (-2)|  
117  
||||O magnésio pareceu ser bem tolerado em todas as doses administradas. Não<br>foram observadas reações adversas imediatas ao sulfato de magnésio, como<br>hipotensão ou diminuição do reflexo do joelho. Não houve diferença<br>estatisticamente significativa, entre os grupos, nos níveis de Na<sup>+</sup>, K<sup>+</sup>, Cl<sup>-</sup>, HCO3<sup>-</sup>,<br>ureia e creatinina, que encontravam-se dentro da faixa esperada, exceto em casos<br>mais graves com falência de órgãos.<br>A concentração média de magnésio urinário no período de 24 h foi<br>estatisticamente diferente entre 16 g (234,74 ± 74,18 mg/dl) e controle (118,06 ±<br>30,76 mg/dl) (p = 0,019), sem variar significativamente entre os grupos tratados<br>com diferentes concentrações de magnésio (p=0,617). Seis pacientes morreram no<br>grupo controle, comparado com 3 no grupo de 4 g, 2 no grupo de 8 g e 1 no de 12<br>g. Não houve mortalidade no grupo de 16 g.**A relação de risco (RR) para morte**<br>**nos pacientes que receberam magnésio foi de 0,25 (95%IC: 0,10-0,61),**<br>**porém, não houve diferença nos pacientes com toxicidade grave. Nos casos de**<br>**toxicidade moderada, a relação de risco para morte foi de 0,35 (95%IC: 0,04-**<br>**3,31).**<br>A dose inicial de atropina requerida foi maior no grupo controle do que nos<br>grupos com magnésio.**Não houve diferença significativa nas doses médias**<br>**totais de atropina requeridas (teste KW: p=0,342) ou nas doses subsequentes**<br>**de infusão de atropina (teste KW: p=0.185).**<br>Conclusão: O magnésio pareceu ser bem tolerado em todas as doses<br>administradas. O estudo apresentou diversas limitações metodológicas, e os<br>resultados são inconclusivos. Maiores estudos são necessários para avaliar a<br>eficácia do sulfato de magnésio na intoxicaçãopor organofosforados.||||
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol|**Mortalidade,**<br>**quantidade de**<br>**atropina,**<br>**número de**|**Sulfato de**<br>**magnésio**|O estudo foi conduzido entre maio de 2014 e maio de 2015, em Karnataka, Índia,<br>e**envolveu 110 pacientes randomizados**em dois grupos, com idade entre 18 e<br>60 anos, com histórico e síndrome clínica de intoxicação por organofosforados,<br>admitidos em até 24h após a exposição, com níveis de pseudocolinesterase < 5320<br>IU/L.|Vijayakumar<br>HN et al.,<br>2017. Study<br>of Effect of<br>Magnesium|Estudo<br>clínico<br>randomizad<br>o|Grave (-<br>1)|  
118  
|ógico<br>inicial|**pacientes em**<br>**ventilação**<br>**mecânica, dia**<br>**da intubação,**<br>**duração da**<br>**ventilação**<br>**mecânica,**<br>**duração da**<br>**hospitalização**<br>**intensiva**|Como procedimento de rotina, os pacientes receberam descontaminação de pele e<br>do trato gastrointestinal, injeção de atropina em bolus de 2 mg, até que sinais de<br>atropinização fossem observados (frequência cardíaca superior a 80 bpm, pressão<br>sistólica arterial superior a 90 mm de Hg, parada de secreções orais e<br>traqueobronquiais), em seguida em infusão contínua de 8-10 mg/kg/h por 48h.<br>Pacientes que apresentaram falência respiratória aguda e fraqueza neuromuscular<br>foram intubados e receberam ventilação mecânica.<br>Os pacientes foram alocados em dois grupos.**Na admissão, o grupo M recebeu**<br>**uma injeção de sulfato de magnésio a 20% 4 g (diluído em 50 mL de solução**<br>**salina), em infusão de 30 min. O grupo C recebeu uma solução placebo, em**<br>**seguida foram extensivamente monitorados na unidade de terapia intensiva.**<br>Pacientes com SaO2 < 90%, GCS < 8 ou fraqueza muscular no pescoço foram<br>intubados e colocados em ventilação mecânica. Os níveis séricos de magnésio<br>foram medidos na admissão e 24h depois; os níveis de pseudocolinesterase foram<br>monitorados em dias alternados e outras investigações foram feitas conforme o<br>estado do paciente.<br>Não houve diferenças nas características demográficas e níveis de<br>pseudocolinesterase entre grupos.**A necessidade média de atropina foi maior**<br>**no grupo C (74,82 ± 22,39 mg/paciente/dia) comparado ao grupo M (53,11 ±**<br>**45,83 mg/paciente/dia), p < 0,001. O número de pacientes que precisaram de**<br>**intubação foi maior no grupo C, 33 pacientes, contra 23 no grupo M (p =**<br>**0,043). Dezessete pacientes no grupo C e 16 no grupo M precisaram de**<br>**intubação nas primeiras 24h após a admissão (p = 0,83); após 24h, outros 16**<br>**pacientes do grupo C foram colocados em ventilação mecânica, contra 7 no**<br>**grupo M, o que foi tanto clinicamente quanto estatisticamente significativo (p**<br>**= 0,012). O número mediano de dias de ventilação foi 4 dias (variação**<br>**interquartil [IQR] 0-14) no grupo C, enquanto no grupo M foi de 3 (IQR 0-**<br>**8). A duração média da ventilação mecânica foi de 4,51 ± 2 dias no grupo C e**<br>**4,13 ± 1,6 dias nogrupo M(p = 0,45). A média de duração da hospitalização**|Sulphate in<br>Management<br>of Acute<br>Organophosp<br>horous<br>Pesticide<br>Poisoning.<br>Adição<br>manual|controlado<br>duplo-cego|
|---|---|---|---|---|  
119  
|**na unidade intensiva foi maior no grupo C (5,36 ± 2,018 dias) do que no**<br>**grupo M (4,54 ± 1,581 dias), p = 0,026; os níveis séricos de**|
|---|
|**pseudocolinesterase também foram diferentes, 2,116 ± 0,2385 mg/dl no grupo**<br>**C e 2,246 ± 0,3189 mg/dl no grupo M, com p = 0,023. Quatro pacientes no**<br>**grupo C e três no grupo M morreram (p = 0,695) (razão de probabilidade**<br>**0,734, 95% IC 0,15-3,46).**|
|**Conclusão:**O estudo mostrou que houve diferença significativa na quantidade de<br>atropina administrada, na necessidade de intubação e na duração da hospitalização|
|na unidade intensiva entre o grupo que recebeu sulfato de magnésio e o grupo que<br>recebeu tratamento controle. No entanto, não houve diferença na duração da|
|ventilação mecânica nem na mortalidade entre os grupos. Nenhum dos pacientes<br>que receberam magnésio apresentaram sintomas indesejáveis ligados à<br>administração. Os autores sugerem que estudos multicêntricos que analisem mais|
|frequentemente os níveis de magnésiopodem ajudar a esclarecer seu efeito.|  
**Quadro III.1.8.Síntese de evidências para a intervenção “N-acetilcisteína” para o tratamento inicial farmacológico de pacientes com intoxicação aguda** **<u>por PIC.</u>**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**exigência de**<br>**atropina e**<br>**pralidoxima;**<br>**tempo de**<br>**hospitalização**|**N-**<br>**acetilcisteín**<br>**a**|**Total de 24 pacientes.**O estudo foi conduzido na Unidade de Cuidado Intensivo<br>do Loghman Hakim Hospital Poison Centre (LHHPC) durante um período de 12<br>meses. Foram recrutados pacientes adultos (>12 anos), com intoxicação aguda por<br>organofosforados confirmada, sem histórico de doenças graves e que não<br>receberam atendimento prévio para a intoxicação.**Doze pacientes receberam N-**<br>**acetilcisteína (NAC) via IV**(140 mg/kg como dose inicial, seguido por 70<br>mg/kg/4 h para 17 doses) e**12 formaram o grupo controle**. Ambos os grupos|**Shadnia**S et<br>al.,**2011**. N-<br>acetylcystein<br>e a novel<br>treatment for<br>acute human<br>organophosp|Ensaio<br>clínico<br>randomizado<br>(_single blind_)|Grave (-<br>1)|  
120  
|receberam o tratamento básico de atropina e pralidoxima. Os dois grupos eram|hate|
|---|---|
|homogêneos em relação a sexo e idade.|poisoning.|
|Não houve diferença estatística entre a média dos níveis de PChE (KU/L) no<br>tratamento (326,5±101,3) e controle (340,3±92) no momento de admissão. Os<br>níveis de PChE estavam na faixa normal no momento de alta médica dos<br>pacientes nos dois grupos.**O período de hospitalização no grupo tratado com**<br>**NAC e no controle foi, respectivamente, de 2,7±1,1 e 5,3±2,2 dias (p=0,003).**<br>**Assim, o tratamento com NAC reduziu o período de hospitalização para**<br>**50,9% do período do grupo controle.**|Busca<br>Sistemática|
|**A média dadose de atropinapor dia de hospitalização foi 9,1±7,2 e 38,9±28,8**<br>**mg nos grupos com NAC e controle, respectivamente (p=0,002); ou seja, o**<br>**tratamento com NAC reduziu necessidade de atropina em 23,4% em relação**<br>**ao grupo controle.**||
|Não se observou diferença estatisticamente significativa entre as doses totais de<br>pralidoxima entre os dois grupos (p=0,81). A taxa de mortalidade foi de 20,8%,<br>com uma morte no grupo com NAC e 4 no grupo controle.**A redução na taxa de**<br>**mortalidade no tratamento com NAC não foi estatisticamente significativa**<br>**(p=0,32).**||
|**Conclusão: Os resultados indicam que a N-acetilcisteína possui efeitos**<br>**benéficos no tratamento de intoxicação aguda por organofosforados.**A<br>necessidade por atropina, mas não pralidoxima, foi reduzida no grupo NAC. O<br>período de hospitalização foi menor no grupo NAC. Considerando a alta taxa de<br>mortalidade e o alto custo de tratamento de pacientes intoxicados com<br>organofosforados, e o baixo custo de NAC, sua disponibilidade em hospitais e os<br>efeitos benéficos, adicionar NAC ao tratamento padrão de intoxicação aguda por<br>organofosforados pode conferir benefícios. O pequeno tamanho amostral foi uma<br>limitação desse estudo, assim, mais ensaios clínicos randomizados com grupos<br>maiores depacientes são necessáriospara mostrar a eficácia desse tratamento.||  
121  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade;**<br>**Dose total de**<br>**atropina**<br>**administrada;**<br>**Tempo de**<br>**hospitalização**<br>**; Necessidade**<br>**de admissão**<br>**na UTI;**<br>**Ventilação**<br>**mecânica**|**N-**<br>**acetilcisteín**<br>**a (NAC)**_-_<br>_conhecida_<br>_por sua_<br>_ação_<br>_antioxidante_|Total de**30 pacientes**com intoxicação aguda por organofosforados, que foram<br>atendidos no_Poison Control Center_de um hospital universitário no Egito entre<br>abril e setembro de 2014; todos os pacientes foram admitidos dentro de 12 h após<br>a intoxicação.<br>Grupo A (n=15): N-acetilcisteína(600 mg via oral três vezes por dia por 3 dias)<br>em adição ao tratamento convencional<br>Grupo B (n=15): Placebo em adição ao tratamento convencional,que pode incluir<br>ressuscitação, descontaminação, administração de atropina e obidoxima. Pacientes<br>que se apresentaram dentro de 2 h da ingestão receberam lavagem gástrica. Todos<br>os pacientes com exposição oral receberam uma dose única (50 g) de carvão<br>ativado. Qualquer material contaminado foi descartado e a descontaminação<br>dérmica foi feita com água e sabão, se necessário. A atropina foi dada em doses<br>em bolus 2-5 mg IV e repetida a cada 10-15 min até as secreções brônquicas<br>estarem secas e, então, a atropina foi administrada intermitentemente quando<br>necessário. A obidoxima foi dada em bolus, com uma dose de carga de 250 mg IV<br>e repetida a cada 8 h até no mínimo 12 h após a atropina não ser mais necessária.<br>Os grupos eram homogêneos em relação à idade e gênero, e continham números<br>comparáveis de casos de intoxicação média e moderada, mas havia apenas um<br>caso severo no grupo A. Não houve diferença significativa entre os dois grupos<br>quanto à natureza ou gravidade das manifestações clínicas iniciais.**Nenhum**<br>**efeito adverso importante para NAC foi relatado.**O vômito não foi<br>significativamente diferente entre os pacientes que receberam NAC em<br>comparação com o grupo controle. Em apenas alguns casos, o OP envolvido foi<br>identificado como clorpirifós ou malation. No entanto, a maioria dos casos não<br>pôde ser identificada devido à falta de informação dos pacientes e seus atendentes.<br>As diferenças entre a atividade da butilcolinesterase sérica antes e após o<br>tratamento dentro de cada grupo foram significativas, mas não diferiram entre os<br>grupos (p=0,768). Observaram-se diferenças estatisticamente significativas entre|**El-Ebiary**<br>AA et al.,<br>**2016**. N-<br>acetylcystein<br>e in Acute<br>Organophosp<br>horus<br>Pesticide<br>Poisoning: A<br>Randomized,<br>Clinical<br>Trial.<br>Busca<br>Sistemática|Estudo<br>clínico<br>randomizado<br>controlado<br>(fase II)<br>Duplo cego|Grave (-<br>1)|
|---|---|---|---|---|---|---|  
122  
|os dois grupos nos níveis séricos de cada um dos biomarcadores de estresse<br>oxidativo MDA e GSH (p<0,01).**Nem a mortalidade nem a necessidade de**<br>**admissão na UTI e/ou ventilação mecânica foram registradas em qualquer**<br>**grupo. Os pacientes com terapia NAC necessitaram significativamente menos**<br>**doses de atropina do que aqueles que receberam apenas tratamento**<br>**convencional (p=0,003). No entanto, a duração da permanência no hospital**<br>**não apresentou diferença significativa entre os dois grupos (p=0,143).**|
|---|
|**Conclusão:**O estudo concluiu que a N-acetilcisteína pode ser utilizada como um<br>tratamento adjuvante aparentemente seguro, e que pode reduzir a necessidade de<br>atropina. No entanto, poucos pacientes foram analisados, requerendo mais estudos<br>clínicos que analisem a eficácia da N-acetilcisteína.|  
**Quadro III.1.9.Síntese de evidências para a intervenção “Circulação Extracorpórea” para o tratamento inicial farmacológico de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Efetividade**<br>- tempo de<br>recuperação de<br>coma<br>- tempo de<br>ventilação<br>mecânica<br>- tempo de<br>cicatrização|**Hemoperfu**<br>**são**|**Objetivo:**Observar o efeito clínico do_penehyclidine hydrochloride_(PHC)<br>combinado com**hemoperfusão**no tratamento de evenenamento severo agudo (via<br>oral) por agrotóxicos**organofosforados**. O PHC faz parte de uma nova geração de<br>antagonista colinérgico; tem um tempo de início rápido, longa meia-vida, é<br>administrado por via intramuscular, excretado em pequenas quantidades por<br>adsorção de hemoperfusão e não requer administração de altas doses.<br>**Metodologia:**61 pacientes com intoxicação por pesticidas organofosforados foram<br>divididos em um grupo experimental (n = 31) e um grupo controle (n = 30) e<br>comparou-se o tempo de recuperação de coma, tempo de ventilação mecânica,<br>tempo de cicatrização, despesas hospitalares e mortalidade entre os dois grupos.|**Liang**MJ,<br>**Zhang**Y.,<br>**2015**.<br>Clinical<br>analysis of<br>penehyclidin<br>e<br>hydrochlorid<br>e combined<br>with|Estudo<br>clínico<br>controlado<br>randomizad<br>o<br>(método de<br>randomizaç<br>ão não foi<br>detalhado)||  
123  
||- taxa de<br>hospitalização<br>- taxa de<br>mortalidade||Todos os pacientes receberam previamente lavagem gástrica, diferentes<br>tratamentos de suporte (a depender de seu estado clínico), pralidoxima e PHC.**A**<br>**hemoperfusão foi administrada aos pacientes do grupo experimenta**l usando a<br>terapia de reposição renal contínua (Baxter, Alemanha) e o cartucho de resina de<br>hemoperfusão de tipo HA330 descartável. Um cateter de duplo lúmen foi inserido<br>na veia femoral direita por punção venosa para configurar um canal vascular;<br>velocidade do fluxo sanguíneo de 160-200 mL/min, e tempo de perfusão de 120-<br>150 min. Os pacientes foram perfundidos 1 ou 2 vezes conforme sua condição. Os<br>pacientes foram transferidos da UTI para a enfermaria quando recuperaram a<br>consciência e foram removidos com sucesso da ventilação mecânica, apresentando<br>pressão arterial estável, correção de choque e sinais vitais estáveis.<br>**Resultados:** **O tempo de recuperação de coma, o tempo de ventilação**<br>**mecânica, e o tempo de cicatrização foram menores no grupo experimental do**<br>**que no grupo controle (P<0,05), enquanto as taxas de hospitalização foram**<br>**maiores no grupo experimental do que no grupo controle (P<0,01). Além disso,**<br>**não houve diferença significativa (P>0,05) na taxa de mortalidade entre o**<br>**grupo controle (5/30) e o experimental (6/31)**. Assim, o PHC combinado com<br>hemoperfusão exerce um melhor efeito terapêutico em intoxicação aguda por<br>pesticidas organofosforados do que o PHC sozinho.<br>Embora o tratamento com hemoperfusão tenha um efeito curativo, ele apenas<br>remove o agente tóxico, não corrigindo as alterações fisiopatológicas causadas pelo<br>pesticida organofosforado. Portanto, a hemoperfusão deve ser realizada em<br>combinação com o tratamento com fármacos anticolinérgicos e outras medidas de<br>tratamento abrangentes devem ser tomadas para apoiar a função respiratória e<br>circulatória.|hemoperfusi<br>on in the<br>treatment of<br>acute severe<br>organophosp<br>horus<br>pesticide<br>poisoning.<br>Busca<br>Sistemática||
|---|---|---|---|---|---|
|**2.**<br>Tratame<br>nto|**Recuperação**<br>**de 50% da**<br>**atividade da**|**Hemoperfu**<br>**são**|O objetivo do estudo foi investigar a eficácia clínica da hemoperfusão no<br>tratamento de intoxicação severa aguda por organofosforados, pela observação<br>dos dados de atividade da colinesterase e de concentrações sanguíneas do|**Li Z**et al.,<br>**2017.**|Sem<br>randomiz<br>ação, sem|  
124  
|farmacol<br>ógico<br>inicial|**colinesterase,**<br>**mortalidade,**<br>**síndrome**<br>**intermediária**|intoxicante nos pacientes. Pacientes admitidos entre janeiro de 2011 e dezembro<br>de 2015 em Linyi, na China, foram selecionados e divididos em dois grupos, o<br>grupo 1 recebeu o tratamento de rotina e hemoperfusão e o grupo 2 recebeu<br>apenas o tratamento de rotina.<br>O tratamento de rotina consistiu em retirar as roupas contaminadas, realizar<br>repetidas lavagens gástricas, administrar carvão ativado e catárticos. Nos estágios<br>iniciais da intoxicação, os pacientes receberam medicamentos anticolinérgicos,<br>reativadores de colinesterase, correção do desequilíbrio ácido-base, controle de<br>infecções e ventilação mecânica. O grupo 1 recebeu hemoperfusão em até 3h após<br>a intoxicação e depois uma vez por dia por 3 dias; o acesso vascular foi<br>estabelecido via catéter venoso central de iluminação dupla e catéter na veia<br>subclávia, e foi feita a 150-200 mL/min por 2h. Foi administrada heparina como<br>anticoagulante e ar foi usado para retornar o sangue tratado após o processo. A<br>atividade da colinesterase foi medida antes do procedimento e nos 3 dias<br>seguintes. O tempo de recuperação de 50% da atividade foi registrado.<br>**O estudo envolveu um total de 260 pacientes, 130 em cada grupo; não houve**<br>**diferenças entre as características dos grupos. Observou-se, no grupo tratado**<br>**com hemoperfusão, uma redução significativa (p<0,05) na incidência de**<br>**síndrome intermediária (5/130 vs. 14/130), na mortalidade (12/130 vs. 25/130)**<br>**e no tempo de recuperação de 50% da colinesterase (5,0 ± 3,2 vs. 5,8 ± 2,4**<br>**dias) em relação ao grupo controle.**<br>**Conclusão:**Os autores sugerem que a hemoperfusão pode melhorar a recuperação<br>da atividade da colinesterase e diminuir a mortalidade e a incidência de síndrome<br>intermediária. Entretanto, os critérios de inclusão nos grupos, além da realização<br>ou não do procedimento de hemoperfusão, não são claros. O estudo não apresenta<br>informações necessárias para julgar se as evidências são clinicamente<br>significativas, além de não detalhar o tratamento de rotina.|Application<br>of<br>hemoperfusi<br>on in severe<br>acute<br>organophosp<br>horus<br>pesticide<br>poisoning<br>Adição<br>manual|critérios<br>claros de<br>inclusão/e<br>xclusão;<br>monocênt<br>rico|
|---|---|---|---|---|  
125  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Efetividade**<br>- cura<br>- melhora<br>- taxa de<br>mortalidade|**Hemoperfu**<br>**são**<br>**mais**<br>**Hemofiltra**<br>**ção**<br>**contínua ou**<br>**Hemodiális**<br>**e**<br>**sustentada**<br>**de**<br>**baixa**<br>**eficiência**|Um total de 56 pacientes com intoxicação aguda severa por pesticidas<br>**organofosforados** foram divididos nos grupos:<br>- hemofiltração contínua mais hemoperfusão (CHF + HP) (n=28)<br>- hemodiálise sustentada de baixa eficiência (SLED) mais hemoperfusão (SLED +<br>HP) (n=28)<br>Ambos os grupos receberam os tratamentos de rotina: lavagem gástrica, atropina e<br>pralidoxima intravenosa, e medidas de suporte quando necessárias. Os desfechos<br>analisados foram cura, melhora ou morte.<br>Os dois grupos não apresentaram diferença estatística em relação ao tempo de<br>permanência no hospital e tempo para tratamento, ou em relação aos indicadores<br>bioquímicos e parâmetros hemodinâmicos antes do tratamento (P>0,05).<br>Em ambos os grupos após o tratamento, os níveis séricos de isoenzima creatina<br>quinase MB, creatinina quinase, creatinina, transaminase glutâmico-oxalacética e<br>transaminase glutâmico pirúvica, e os escores APACHE II (Avaliação de Saúde<br>Crônica e Fisiologia Aguda II) no primeiro, segundo e sétimo dia diminuíram<br>(P<0,05), enquanto que os níveis de acetilcolinesterase sérica aumentaram.<br>**Os dois grupos não mostraram diferenças estatísticas no período de**<br>**permanência no hospital, nos indicadores bioquímicos, no escore APACHE II,**<br>**nos parâmetros hemodinâmicos, na taxa de sobrevivência ou na taxa de**<br>**mortalidade (P>0,05). Em conclusão, a hemodiálise sustentada de baixa**<br>**eficiência (SLED) tem estabilidade hemodinâmica similar à hemofiltração**<br>**contínua (CHF) e os dois métodos de tratamento têm efeitos semelhantes em**<br>**pacientes com intoxicação aguda severa por pesticidas organofosforados.**<br>Hemodiálise sustentada de baixa eficiência (SLED) mais hemoperfusão (SLED +<br>HP) é um tratamento relativamente econômico e conveniente para pacientes com<br>intoxicação aguda severa por pesticidas organofosforados na prática clínica.|**Hu SL et al.**<br>Artif. Organs<br>**2014**; 38:<br>121-124.<br>Adição<br>manual<br>(Retirado de<br>Liang &<br>Zhang, 2015<br>– Busca<br>sistemática)|Estudo<br>clínico não<br>randomizad<br>o|
|---|---|---|---|---|---|  
126  
|**2.**<br>Tratame<br>nto<br>farmacol<br>ógico<br>inicial|**Mortalidade,**<br>**complicações**<br>**pós-**<br>**tratamento,**<br>**falência de**<br>**órgãos,**<br>**duração da**<br>**hospitalização**<br>**, indicadores**<br>**de**<br>**prognóstico**<br>**APACHE II e**<br>**GCS**|**Hemoperfu**<br>**são e**<br>**hemodiálise**|**68 pacientes**em estado crítico por intoxicação severa por organofosforados,<br>admitidos entre abril 2013 e abril 2014 na emergência do Hospital Beijing Luhe,<br>em Beijing, China, alocados em2 grupos, sem randomização, de 34 pacientes<br>cada. Grupo controle recebeu o tratamento de rotina:lavagem gástrica,<br>esvaziamento do intestino, reidratação, manutenção do equilíbrio hidroeletrolítico,<br>tratamento anti-infecção, atropina combinada com pralidoxima (1,2 a 1,6 g de<br>pralidoxima por via intravenosa inicialmente, outra injeção meia hora depois, e a<br>injeção intravenosa era mantida a taxa de 0,6 g/h por pelo menos um dia; a dose<br>era diminuída pela metade a cada dia, com uso de 2 a 3 dias. A dose de atropina<br>era ajustada a cada 5 a 20 minutos), ventilação mecânica quando necessário.<br>Grupo tratamento recebeu, além do tratamento de rotina, hemodiálise e<br>hemoperfusão. Grupo tratamento com média de idade de 46,6 ± 5,8 anos;<br>quantidade média de toxicante de 123,6 ± 45,3 mL; agentes tóxicos: dipterex,<br>metil paration, metamidofós e diclorvos. Grupo controle com média de idade de<br>45,9 ± 5,5 anos; quantidade média de toxicante de 124,3 ± 41,2 mL; mesmos<br>agentes tóxicos.<br>Não houve diferença significativa entre as características dos grupos.**Dos 34**<br>**pacientes que receberam hemodiálise e hemoperfusão, 25 tiveram**<br>**complicações**(12 apresentaram hipotensão, 4 hemorragia do trato digestório, 4<br>infecções, 2 hipertensão resistente, 1 coagulação, 1 arritmia, 4 sangramento).**Nos**<br>**34 pacientes do grupo controle,**4 apresentaram falência renal, contra 1 no grupo<br>tratamento; 1 apresentou falência cardíaca, contra 3 no grupo tratamento; e 6,<br>falência respiratória, número igual no grupo tratamento.<br>A taxa de mortalidade (1/34) e de rebote (1/34) foram significativamente (p<0,05)<br>menores no grupo com tratamento do que no grupo controle (6/34 e 4/34,<br>respectivamente). Os tempos de atropinização [2,8 ± 0,5 vs. 6,4 ± 1,1 h], de<br>recuperação da atividade de colinesterase [7,9 ± 1,4 vs. 18,8 ± 3,2 dias], de<br>recuperação de consciência [3,5 ± 1,0 vs. 14,4 ± 2,5 h], de extubação [2,3 ± 1,1|**Dong**H et<br>al.,**2017**.<br>Clinical<br>emergency<br>treatment of<br>68 critical<br>patients with<br>severe<br>organophosp<br>horus<br>poisoning<br>and<br>prognosis<br>analysis after<br>rescue.<br>Busca<br>Sistemática|Estudo<br>observacio<br>nal,<br>retrospectiv<br>o<br>Não<br>randomizad<br>o, aberto,<br>monocêntri<br>co,<br>retrospectiv<br>o|
|---|---|---|---|---|---|  
127  
vs. 7,4 ± 2,5 dias] e de hospitalização [11,2 ± 1,4 vs. 18,3 ± 3,5 dias] foram todos menores no grupo tratamento, assim como o uso total de atropina [119,3 ± 22,5 vs. 485,4 ± 64,4 mg]; p<0,05 em todos os casos. **Conclusão:** O estudo sugere que hemoperfusão e hemodiálise devam ser adicionadas ao tratamento de rotina de pacientes em estado crítico por envenenamento severo por organofosforados. No entanto, o caráter retrospectivo, a falta de randomização e o efetivo reduzido de pacientes torna a potência do estudo insuficiente.  
**Quadro III.1.10.Síntese de evidências para “Síndrome intermediária e manifestações secundárias da intoxicação” de pacientes com intoxicação aguda por PIC.**  
|**PICO**|**DESFECHO**|**TIPO DA**<br>**INTERVE**<br>**NÇÃO**|**EVIDÊNCIAS**|**AUTORES**|**DELINEA**<br>**MENTO**|**RISCO**<br>**DE VIÉS**|
|---|---|---|---|---|---|---|
|**5.**<br>Tratame<br>nto do<br>paciente<br>com<br>intoxicaç<br>ão<br>crônica<br>por<br>inibidore|**Níveis**<br>**plasmáticos**<br>**de intoxicante,**<br>**níveis séricos**<br>**de PChE**|**Terapia de**<br>**troca de**<br>**plasma**|O estudo tem como objetivo determinar a efetividade de terapia de troca de<br>plasma (TPE) em pacientes com síndrome intermediária de intoxicação com<br>organofosforados.**Os 17 pacientes**foram selecionados entre outubro de 2008 e<br>dezembro de 2010 na Turquia. Os dados recolhidos incluíam informação<br>demográfica, nível de pseudocolinesterase (PChE), tempo entre admissão e o<br>procedimento de TPE, fosfato orgânico e níveis séricos de PChE antes e depois da<br>TPE e níveis séricos de TPE antes da alta hospitalar.**Todos os pacientes**<br>**receberam tratamento de rotina que consistiu em inserção de um tubo**<br>**nasogástrico, lavagem gástrica com 2000 mL de solução salina a 0,9%,**<br>**inserção de cateter venoso periférico e infusão de solução salina a 0,9% e 5%**|**Yilmaz**M et<br>al.,**2013**.<br>Effectiveness<br>of<br>therapeutic p<br>lasma exchan<br>ge in patients<br>with<br>intermediate<br>syndrome|Estudo<br>quasi-<br>experiment<br>al<br>(não há<br>grupo<br>controle)|Muito<br>grave (-2)|
|s de|||**de dextrose a 2000 mL/m² por dia. Atropina foi administrada em bolus até**|due to|||
|colineste<br>rase|||**que as secreções dos pacientes parassem, depois era administrada em infusão**<br>**contínua a 1 mg/kg por dia e recebiam dose única de 2g de pralidoxima.**|organophosp|||  
128  
A TPE era feita com PFC como fluido de reposição e era repetida dependendo da <u>hate</u> melhoria do estado clínico do paciente (perda de força muscular proximal e <u>intoxication.</u> padrão respiratório). Os pacientes tinham média de idade de 50,59 ±20,16 anos, 4 mulheres e 13 Busca homens. Seis pacientes apresentavam intoxicação por diazinon (35,2%), 5 por Sistemática clorpirifós (29,4%), 1 (5,9%) com trimetil fosfato e em 5 pacientes (29,4%) o intoxicante não foi identificado. A média de tempo até o primeiro procedimento de TPE desses pacientes com intoxicante não identificado foi de 8,62 ± 4,94 dias, dos outros pacientes foi de 4,93 ± 4,08 dias. Dos 17 pacientes, 8 passaram por apenas 1 sessão de TPE, 7 passaram por 2 sessões e 2, por 4. A média de quantidade de intoxicante no plasma dos pacientes antes da TPE era de 0,72 ± 1,83 mg/L, enquanto a média após o procedimento foi de 0,37 ± 0,82 mg/L (p = 0,012). O nível plasmático médio de PChE na admissão foi de 331,06 ± 570,62 IU/L, antes da TPE foi de 219,4 ± 463,82 IU/L, 607,30 ± 1148,87 IU/L depois (p = 0,014) e na alta hospitalar foi de 859,65 ± 1176,90 IU/L (níveis considerados normais entre 6400 e 15500 IU/L). O nível de intoxicante no resíduo de plasma coletado no dispositivo de TPE foi igual a 0,48 ± 1,12 mg/L, logo parte do intoxicante é excretada durante a TPE. Dos 17 pacientes, 15 precisaram de ventilação mecânica. Destes, 11 tiveram uma média de 9,2 (0-37) dias de ventilação mecânica; 4 tiveram uma média de 57,25 (17-150) dias de ventilação mecânica e foram a óbito. **Conclusão:** Os autores sugerem que a TPE pode reduzir significativamente os níveis plasmáticos do intoxicante e pode aumentar a PChE, se feita precocemente nos casos de síndrome intermediária causada por intoxicação com organofosforados. Entretanto, o pequeno efetivo e a falta de grupo de comparação impedem que esses resultados sejam validados.  
129  
|**5.**<br>Tratame<br>nto do<br>paciente|**Síndrome**<br>**intermediária,**<br>**mortalidade**|**Tratament**<br>**o de rotina**|**Total de 176 pacientes**admitidos entre abril de 2011 e março de 2012 na Índia.<br>Síndrome intermediária foi definida como fraqueza muscular no pescoço e<br>músculos proximais e/ou sinais de falência respiratória na ausência de sinais<br>colinérgicos.|**Indira**M et<br>al.,**2013**.<br>Incidence,<br>predictors,|Coorte<br>_-_|
|---|---|---|---|---|---|
|com<br>intoxicaç<br>ão<br>crônica<br>por<br>inibidore<br>s de<br>colineste<br>rase|||Todos os pacientes receberam o tratamento de rotina: dose inicial em bolus de 4-8<br>mg de atropina, repetida a cada 5-10 minutos até que os sinais colinérgicos<br>desaparecessem. A partir de então, 10-20% da dose era dada por meio de infusão<br>durante os 3-7 dias seguintes, de acordo com o estado clínico do paciente. Para<br>pacientes intoxicados por organofosforados, pralidoxima foi administrada em 1 g<br>de bolus seguido de 500 mg/h por 48h. Pralidoxima não foi administrada a<br>pacientes intoxicados por carbamatos ou por intoxicante desconhecido. Os<br>pacientes também receberam lavagem gástrica, mesmo que já tivessem passado<br>pelo procedimento de lavagem em hospitais periféricos, o que ocasionou<br>múltiplas lavagens em alguns pacientes.<br>Do total dos pacientes, 76 (43,2%) ingeriram organofosforados, 67 (38,1%)<br>carbamato, e 32 (18,3%) apresentaram intoxicação colinérgica não identificada.<br>Compostos comuns ingeridos foram carbofuran, clorpirifós e quinalfos. Dos<br>organofosforados, 73 (96,1%) foram compostos dietil e três (3,9%) dimetil;<br>apenas 10 foram tratados com pralidoxima, pois a identificação do restante foi<br>tardia.<br>**A incidência de síndrome intermediária foi de 17,6% (n = 31), com tempo**<br>**médio de aparecimento de 44,5**±**22,1 h após a exposição (entre 26h e 5 dias),**<br>**e foi causada tanto por organofosforados quanto carbamatos (38,7% e**<br>**41,9%) e duraram entre 1 e 7 dias.**Todos os pacientes apresentaram os<br>sintomas da síndrome intermediária e fraqueza do músculo do pescoço foi a<br>característica inicial na maioria dos pacientes com falência respiratória (n =<br>20/26), 6 pacientes apresentaram falência respiratória como característica inicial.<br>Dificuldades respiratórias apareceram entre 0 e 8h (média 3,1±2,5 h) após a|and outcome<br>of intermedia<br>te syndrome i<br>n cholinergic<br>insecticide<br>poisoning: a<br>prospective<br>observational<br>cohort study.<br>Busca<br>Sistemática||  
130  
|fraqueza do músculo do pescoço. Paralisia extraocular foi observada em 15|
|---|
|pacientes, mas não como sintoma inicial.|
|**Do total, 48 pacientes receberam lavagem gástrica precoce (**≤**1h) e 119,**<br>**tardia (>1h); 9 pacientes não puderam receber a lavagem por apresentarem**<br>**estados clínicos instáveis. Não houve correlação entre o tempo da lavagem**<br>**gástrica e a ocorrência da síndrome intermediária. Oitenta pacientes**<br>**receberam uma lavagem e 87, duas.**Dos 31 pacientes que apresentaram a<br>síndrome, 12 (38,7%) foram expostos a organofosforados, 13 (41,9%),<br>carbamatos e 6 (19,4%) a outros intoxicantes não identificados. Dois terços dos<br>pacientes expostos a compostos dimetil (carbofuran (n = 13), clorpirifós (n = 6),<br>quinalfos (n = 4), dimetoato (n = 1), e metil paration (n = 1)) tiveram a síndrome<br>(RR 4,87, 95% IC 1,82 – 13,04, p = 0,01), e, entre estes, dois terços morreram<br>(RR 1,24, 95% ,CCI 0,48 – 3,19, p = 0,05); 7 em 13 pacientes expostos a<br>compostos dietil também morreram.|
|A severidade da intoxicação foi avaliada usando IPCS PSS e GCS; nenhum<br>paciente com intoxicação leve sofreu síndrome intermediária, enquanto 2<br>pacientes com intoxicação moderada e 29 com intoxicação severa apresentaram a<br>síndrome.|
|**Idade**≥**45 (RR 2,23, 95% IC 1,14 – 4,38, p = 0,02) e compostos do subgrupo**<br>**dimetil (RR 4,87, 95% IC 1,82 – 13,04, p = 0,01) foram associados com o**<br>**desenvolvimento da síndrome, enquanto múltiplas lavagens gástricas tiveram**<br>**efeito protetor (RR 0,44, 95% IC 0,22 – 0,87, p = 0,001).**Curvas ROC foram<br>plotadas por IPCS PSS e GCS na admissão do paciente|
|(AUC/sensibilidade/especificidade 0,77/0,94/0,6 para IPCS PSS > 2 and<br>0.64/0.71/0.65 for GCS≤10). A mortalidade geral foi de 28,4% (n = 50); 40% (n<br>= 20/50) aconteceram entre pacientes com falência respiratória causada pela<br>síndrome intermediária, fortemente associada com a mortalidade (RR 3,12, 95%|  
131  
||||IC 2,07 – 4,71, p = 0,0001), especialmente em homens (n = 19, RR 5,54, 95% IC<br>0,9 – 34,4, p = 0,004).<br>**Conclusão:**Os autores observaram a ocorrência de síndrome intermediária em<br>pacientes intoxicados por organofosforados e também por carbamatos, e o risco<br>pode aumentar com a idade (≥45), e com as características clínicas observadas<br>(severidade da intoxicação). O diagnóstico pode ser feito pela identificação de<br>fraqueza muscular no pescoço, o que pode auxiliar a detecção precoce de falência<br>respiratória. Também observaram que múltiplas lavagens gástricas podem ter<br>efeito protetor, mas outros estudos controlados e randomizados, com maior<br>efetivo de pacientes, devem ser feitos para confirmar esse efeito.|||
|---|---|---|---|---|---|
|**6.**<br>Acompa<br>nhament<br>o,<br>seguime<br>nto e<br>reabilitaç<br>ão|**Mortalidade;**<br>**período de**<br>**ventilação;**<br>**período de**<br>**permanência**<br>**no hospital**|**Tratament**<br>**o de rotina**<br>**com**<br>**observação**<br>**das**<br>**manifestaç**<br>**ões**<br>**extrapiram**<br>**idais**|De 77 pacientes admitidos, 32 foram incluídos neste estudo realizado durante 8<br>meses (abril a novembro de 2013) na Índia.**Todos eram adultos (>18 anos) e**<br>**tiveram intoxicação por organofosforados.**A maioria dos pacientes (81%)<br>havia recebido tratamento em um centro primário ou secundário externo, que<br>incluía lavagem gástrica e atropina antes da transferência para o hospital de<br>referência; 4 pacientes tinham recebido oximas. O tratamento no hospital de<br>referência incluiu atropina e cuidados de suporte (ventilação e inotrópicos quando<br>indicado); não houve administração de oximas. A presença de manifestações<br>extrapiramidais foi correlacionada com o período de ventilação, período de<br>permanência no hospital e mortalidade.<br>Dos**32 pacientes**do estudo, 28 (87,5%) necessitaram de admissão na UTI, 27<br>(84,4%) necessitaram de ventilação mecânica, 11 (34,4%) desenvolveram<br>síndrome intermediária e 2 (6,3%) morreram. Um total de**17 (53,1%) pacientes**<br>**desenvolveram manifestações extrapiramidais que incluíram rigidez (94,1%),**<br>**tremor (58,8%) e distonia (58,8%).**O tempo médio (intervalo interquartil) de<br>começo dos sintomas foi de 8 (5-11). Esses sintomas extrapiramidais melhoraram<br>em 11 dias (6-17). A duração média de permanência no cuidado intensivo em<br>pacientesque não desenvolveram sintomas extrapiramidais foi de 6 (2-8) dias,|**Reji**KK et<br>al.,**2016**.<br>Extrapyrami<br>dal effects of<br>acute organo<br>phosphate<br>poisoning.<br>Busca<br>Sistemática|Estudo<br>observacio<br>nal<br>prospectivo<br>- Coorte<br>_-_|  
132  
|indicando que a maioria desses pacientes se recuperaram mesmo antes do começo<br>dos sintomas nos pacientes que desenvolveram manifestações extrapiramidais.<br>O desenvolvimento de manifestações extrapiramidais não foi correlacionado com<br>a classe química do organofosforado, nível de pseudocolinesterase na admissão ou<br>com o tratamento recebido (p>0.5). Embora as manifestações extrapiramidais não<br>tenham sido associadas com aumento da necessidade de ventilação ou da taxa de<br>mortalidade,**nos pacientes que necessitaram de ventilação mecânica,**<br>**observou-se maior duração da ventilação**(16_vs_5 dias; p<0,01)**e menor**<br>**quantidade de dias sem ventilador**(12_vs_23 dias; p<0,05) em comparação aos<br>pacientes que não desenvolveram manifestações extrapiramidais. As<br>manifestações extrapiramidais também foram correlacionadas com**maior**<br>**desenvolvimento de síndrome intermediária**(9_vs_2%; p<0,05),**maior**<br>**necessidade de** **traqueostomia**(13_vs_1%; p<0,01) e**maior período de**<br>**permanência no hospital**(21_vs_8 dias; p<0,01) e**UTI**(14_vs_6 dias; p<0,01).<br>**Conclusão:**As manifestações extrapiramidais são comuns em casos de<br>intoxicação por organofosforados e tendem a ocorrer na segunda semana após a<br>exposição. Conforme o estudo, essas manifestações são autolimitantes e<br>costumam melhorar após 1-2 semanas. Ainda que essas manifestações não tenham<br>sido associadas com aumento de mortalidade, elas foram associadas com<br>significante morbidade.|||
|---|---|---|
|(_Artigo sobre mecanismos da síndrome, não sobre tratamento_)<br>O objetivo do estudo é recolher toda a informação disponível relacionada à<br>síndrome intermediária e mudanças eletromiográficas que possam ocorrer após<br>intoxicação por organofosforados para esclarecer os mecanismos envolvidos. Um<br>total de 58 estudos (clínicos e animais) foi analisado.|**Abdollahi**M<br>et al.,**2012**.<br>A<br>comprehensi<br>ve review on|Revisão<br>sistemática<br>_-_|
|A causa mais importante de morbidade na intoxicação por organofosforados é a<br>síndrome intermediária, que ocorre entre 24 e 96h após a exposição, em<br>aproximadamente 20% dospacientes. Seus sintomas clínicos são fraqueza nos|experimental<br>and clinical<br>findings in||  
133  
|nervos cranianos, fraqueza nos músculos respiratórios, do pescoço e outros<br>músculos proximais; são apresentados dois tipos de paralisia: tipo 1, que responde<br>à atropina, e o tipo 2, que não responde.|intermediate<br>syndrome<br>caused by|||
|---|---|---|---|
|Os efeitos neurotóxicos da síndrome intermediária em humanos variam de<br>mudanças eletroencefalográficas e no comportamento neural a aumento na<br>latência do potencial de ação (PA) em músculos esqueléticos. Efeitos tardios<br>desse tipo de intoxicação podem envolver, além da síndrome intermediária, crises<br>colinérgicas e neuropatia tardia.<br>Nos estudos analisados, a síndrome aconteceu após intoxicação por fention,<br>monocrotofós, dimetoato, metil paration, fosmete, clorpirifós, fentoato, diclorvós<br>e metamidofós; a ocorrência variou entre 20 e 65,55%.<br>A falência respiratória causada pela síndrome é descrita como consequência da<br>paralisia nicotínica dos músculos respiratórios, sendo o diafragma o músculo mais<br>atingido; também pode ser causada por hiperatividade muscarínica, que pode<br>levar a secreções excessivas nas vias aéreas e depressão respiratória central.|organophosp<br>hate poisonin<br>g.<br>Busca<br>Sistemática|||
|Paciente feminina de 16 anos admitida com síndrome colinérgica aguda, na<br>Clínica Universitária Bolivariana, na Colômbia. Foi tratada com atropina e<br>suporte ventilatório; apresentou QTc prolongado no primeiro eletrocardiograma.<br>Precisou de altas doses de vasoconstritor e bolus de cristaloides, a infusão de<br>atropina teve de ser reiniciada depois que sintomas colinérgicos voltaram a<br>aparecer. Divalproato foi administrado para neuroproteção, mais tarde substituído<br>por fenitoína; apresentou sinais de pneumonia provavelmente causada pelo<br>suporte respiratório. Apresentou melhora neurológica após 1 semana, se queixou<br>de dores nos membros inferiores, sinal compatível com eventos neuropáticos, que<br>foram manejados com carbamazepina e analgésicos opióides. Após 20 dias, teve<br>significativa melhora e conseguiu manter-se sentada sem instabilidade no tronco.<br>Após melhoria respiratória, foi retirada a cânula de traqueostomia.**Recebeu**<br>**fisioterapia durante a evolução doquadro neurológico**e apresentou neuropatia|**Díaz**, IC et<br>al.,**2012**.<br>Síndrome<br>intermedio<br>en<br>intoxicación<br>aguda por<br>organofosfor<br>ados: reporte<br>de caso.|Relato de<br>caso|Muito<br>grave (-2)|  
134  
<!-- Start of picture text -->
motora axonal nas quatro extremidades, diagnosticada por eletromiografia. Saiu  Busca<br>da unidade de tratamento intensivo após 4 semanas e recebeu alta 5 dias depois de  Sistemática<br>ser transferida para o quarto,  com prescrição de fisioterapia.<br>Paciente masculino de 71 anos , admitido depois de 24h desaparecido. Depois de  Delgado , M  Relato de  Muito<br>descartadas outras causas, é diagnosticada intoxicação por organofosforados e  et al.,  2010 .  caso  grave (-2)<br>síndrome colinérgica pela medida da atividade de colinesterase sérica. O  Síndrome<br>tratamento foi iniciado com pralidoxima e o paciente foi extubado no 5º dia;  colinérgico y<br>apresentou piora e deterioração clínica muscular, foi intubado novamente e  síndrome<br>recebeu tratamento para a crise colinérgica, apresentou bradicardia extrema  intermedio<br>refratária depois de reanimação e foi a óbito.  confluyentes<br>en una<br>intoxicación<br>por<br>organofosfor<br>ados.<br>Busca<br>Sistemática<br><!-- End of picture text -->  
135

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
**Quadro II.5.1.1.** Avaliação das evidências pelo método GRADE sobre a associação do risco de Síndrome Intermediária Tardia (SIT) em pacientes intoxicados com inibidores de colinesterase com idade acima de 45 anos. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQu **|**alidade**|||**№ depa **|**cientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>Desenvo|**Delineamento**<br>**do estudo**<br>lvimento da SIT|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a idade**<br>**acima de**<br>**45 anos**<br>**como fator**<br>**preditor**|**idade**<br>**menor do**<br>**que 45**<br>**anos**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|1|estudos<br>observacionais|não grave|não grave|não grave|não grave|todos os<br>potenciais fatores<br>de confusão<br>reduziriam o<br>efeito<br>demonstrado|16/31<br>(51.6%)|15/31<br>(48.4%)|**RR 4.87**<br>(1.14 para<br>4.38)|**1.000**<br>**mais por**<br>**1.000**<br>(de 68<br>mais para<br>1.000<br>mais)|⨁⨁⨁`◯`<br>MODERADA||  
CI: Intervalo de Confiança; RR: Razão de Risco  
**Referência:** Indira, M., Andrews, M. A., & Rakesh, T. P. (2013). Incidence, predictors, and outcome of intermediate syndrome in cholinergic insecticide poisoning: A prospective observational cohort study. Clinical Toxicology, 51(9), 838–845. https://doi.org/10.3109/15563650.2013.837915  
136  
**Quadro II.5.1.2.** Avaliação das evidências pelo método GRADE sobre a associação do risco de Síndrome Intermediária Tardia (SIT) em pacientes intoxicados com dimetil organofosforados (DOF). Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação dequ **|**alidade**|||**№ depacie**|**ntes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineament**<br>**o do estudo**|**Risc**<br>**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**a intoxicação com**<br>**dimetilorganofosforado**<br>**s como fator**<br>**predisponente**|**outros**<br>**inseticidas**<br>**organofosforado**<br>**s e carbamatos**|**Relativ**<br>**o**<br>**(95%**<br>**CI)**|**Absolut**<br>**o**<br>**(95%**<br>**CI)**|**Qualidade**|**Importânci**<br>**a**|
|Sindrom|e Intermediária T|ardia|||||||||||
|1|estudos<br>observacionai<br>s|não<br>grave|<br>não grave|não grave|não grave<sup>a</sup>|todos os<br>potenciais<br>fatores de<br>confusão<br>reduziriam o<br>efeito<br>demonstrado|2/3 (66.7%)|10/73 (13.7%)|**RR 4.87**<br>(1.82<br>para<br>13.04)|**530 mais**<br>**por**<br>**1.000**<br>(de 112<br>mais para<br>1.000<br>mais)|⨁⨁⨁`◯`<br>MODERAD<br>A||  
CI: Intervalo de Confiança; RR: Razão de Risco  
a. O número de pacientes intoxicados por dimetilfosforados representa um número muito pequeno da amostra analisada.  
**Referência:** Indira, M., Andrews, M. A., & Rakesh, T. P. (2013). Incidence, predictors, and outcome of intermediate syndrome in cholinergic insecticide poisoning: A prospective observational cohort study. Clinical Toxicology, 51(9), 838–845. https://doi.org/10.3109/15563650.2013.837915.  
137  
**Quadro II.5.1.3.** Avaliação das evidências pelo método GRADE sobre a associação do risco de Síndrome Intermediária Tardia (SIT) com fraqueza muscular no pescoço em pacientes intoxicados com inibidores de colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
<!-- Start of picture text -->
Avalia ç ão da  Q ualidade  № de  p acientes  Efeito<br>a fraqueza<br>muscular no<br>№ dos  Delineamento  Risco de  Evidência  Outras  pescoço  outros  Relativo  Absoluto  Qualidade  Importância<br>Inconsistência  Imprecisão  (95%<br>estudos  do estudo  viés  indireta  considerações  como  sintomas  (95% CI)<br>CI)<br>característica<br>inicial<br>Sindrome Intermediária Tardia<br>1   estudos  grave  a grave  a não grave  não grave   todos os  25/31 (80.6%)   6/31  80.6 -- por  ⨁⨁ ◯◯ IMPORTANTE<br>observacionais   potenciais  (19.4%)   (66.3 para  100 BAIXA<br>fatores de  95.4)   (de --<br>confusão  para --)<br>reduziriam o<br>efeito<br>demonstrado<br>gradiente de<br>dose-resposta<br><!-- End of picture text -->  
CI: Intervalo de Confiança  
a. A avaliação da fraqueza muscular localizada de pescoço somente é possível em pacientes que estejam conscientes. Mesmo em pacientes com estado de consciência preservado, há um risco de confundimento dessa manifestação com outras. A percepção, por ser parte da vítima, aumenta a subjetividade da avaliação  
**Referência:** Indira, M., Andrews, M. A., & Rakesh, T. P. (2013). Incidence, predictors, and outcome of intermediate syndrome in cholinergic insecticide poisoning: A prospective observational cohort study. Clinical Toxicology, 51(9), 838–845. https://doi.org/10.3109/15563650.2013.837915.  
138  
**Quadro II.5.1.4.** Avaliação das evidências pelo método GRADE sobre a associação do risco de Síndrome Intermediária Tardia (SIT) com a avaliação na escala de Glasgow ≤ 10, em pacientes intoxicados com inibidores de colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQua**|**lidade**<br>|||**Impacto**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**||||
|Síndrom<br>|e Intermediária T<br>|ardia<br>||||||||
|1|estudos<br>observacionais|<br>não<br>grave|não grave|não grave|grave<sup>a</sup>|todos os<br>potenciais<br>fatores de<br>confusão<br>reduziriam o<br>efeito<br>demonstrado|Em estudo realizado com 176 pacientes, dos quais 31<br>desenvolveram a SIT, foi observado que a maioria deles<br>apresentou fraqueza muscular no pescoço como<br>característica inicial, sendo que esse mesmo grupo evoluiu<br>para insuficiência respiratória (20/26). Idade acima de 45<br>anos (RR 2,23; IC 95% 1,14 - 4,38, p< 0,02) e intoxicação<br>por DOF (RR 4,87; IC 95% 1,82 - 13,04, p< 0,01) foram<br>fatores associados ao desenvolvimento da SIT. Curvas<br>ROC foram estabelecidas para avaliar se o escore na<br>escala<br>de<br>intoxicação<br>proposta<br>pelo<br>Programa<br>Internacional sobre Classificação de Gravidade de<br>Intoxicação e Segurança Química (IPCS PSS) e pela<br>escala de coma de Glasgow (GCS), estabelecidos na<br>admissão, são preditores de agravamento e mortalidade.<br>Os valores encontrados, respectivamente, para a AUC, a<br>sensibilidade e a especificidade foram: 0,77 / 0,94 / 0,6<br>para IPCS PSS> 2 e 0,64 / 0,71 / 0,65 para GCS≤10. A<br>mortalidade, no geral, foi de 28,4% (n= 50); sendo que<br>40%<br>(n<br>=20/50)<br>ocorreu<br>entre<br>pacientes<br>que<br>desenvolveram a SIT e insuficiência respiratória (Indira,<br>Andrews, & Rakesh, 2013).|⨁⨁`◯◯`<br>BAIXA|IMPORTANTE|  
a. Em outros estudos, escalas como APACHE II, escala de Namba, GCS, SAPS II e PSS foram utilizadas para avaliar a gravidade e resultado de envenenamento e não para risco de síndrome intermediária. Em serviços de saúde com precariedade de recursos, a escala de Glasgow pode ser uma ferramenta útil para avaliar o risco de complicações relacionadas à intoxicação. Contudo, o estudo indica que o estabelecimento de uma PSS maior que 2 é mais sensível (93,5%) na predição da síndrome intermediária, embora menos específica do que a escala de Glasgow, cuja sensibilidade era de 71% e especificidade de 65%.  
**Referência:** Indira, M., Andrews, M. A., & Rakesh, T. P. (2013). Incidence, predictors, and outcome of intermediate syndrome in cholinergic insecticide poisoning: A prospective observational cohort study. Clinical Toxicology, 51(9), 838–845. https://doi.org/10.3109/15563650.2013.837915.  
139  
**Quadro II.5.2.1.** Avaliação das evidências pelo método GRADE sobre o uso de escala de APACHE II como preditora de agravamento em pacientes intoxicados com inibidores de colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQua**|**lidade**<br>|||**Imacto**|**Qualidade**|**Imortância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**p**||**p**|
|Mortalid<br>|ade<br>|||||||||
|1|estudos<br>observacionais|não<br>grave|não grave|não grave|não grave|forte associação|Numa análise multivariada de regressão logística, os níveis<br>de bicarbonato sérico e o escore do paciente na escala de<br>APACHE<br>II<br>foram<br>fatores<br>importantes<br>para<br>a<br>determinação do prognóstico de pacientes vítimas de<br>intoxicação por IC. A idade média dos pacientes incluídos<br>foi de 56 anos (faixa, 16-88), sendo o grupo constituído por<br>57 (62%) homens e 35 (38%) mulheres. Comparações<br>entre as características clínicas do grupo sobrevivente (n =<br>81, 88%) e do não sobrevivente (n = 11, 12%), não foram<br>observadas diferenças de parâmetros relacionados à função<br>renal, às enzimas pancreáticas ou ao nível sérico de AChE<br>e o escore de APACHE II. Tal fato não ocorreu ao se<br>correlacionar esse índice com os níveis de bicarbonato<br>sérico. Este foi menor nos não sobreviventes do que nos<br>sobreviventes (12,45 ± 2,84 vs. 18,36 ± 4,73, P <0,01). O<br>escore de APACHE II foi maior nos não sobreviventes do<br>que nos sobreviventes (24,36 ± 5,22 vs. 12,07 ± 6,67, P<br><0,01). O desenvolvimento de pneumonia durante a<br>hospitalização foi maior nos não sobreviventes do que nos<br>sobreviventes (n = 9, 82% vs. n = 31, 38%, P <0,01). Na<br>análise de regressão logística múltipla, a concentração<br>sérica de bicarbonato, o escore APACHE II e a pneumonia<br>durante a hospitalização foram fatores prognósticos<br>importantes em pacientes vítimas de intoxicação por IC<br>(Sun et al, 2015)|⨁⨁⨁`◯`<br>MODERADA|<br>CRÍTICO|  
**Referências** : Sun, I. O., Yoon, H. J., & Lee, K. Y. (2015). Prognostic Factors in Cholinesterase Inhibitor Poisoning. Medical Science Monitor, 21, 2900–2904. <u>https://doi.org/10.12659/MSM.894287</u>  
140  
**Quadro II.5.3.1.** Avaliação das evidências pelo método GRADE sobre a gravidade estimada pela escala de Peradeniya comparado a nada para categorizar e prever alterações que contribuem para o agravamento de pacientes intoxicados por organofosforados em diferentes graus de gravidade. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQu **|**alidade**|||**№ depac**|**ientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a**<br>**gravidade**<br>**estimada**<br>**pela escala**<br>**de**<br>**Paradeniya **|**nada**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|Desenvo|lvimento de Insuf|iciência Re|spiratória/Necessi|dade de Supo|rte Ventilatór|io|||||||
|1|estudos<br>observacionais|grave a|grave b|não grave|não grave|forte associação|23/50<br>(46.0%)||não<br>estimável||⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|Tempo d|e Permanência na|UTI|||||||||||  
141  
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Avaliação deQu **<br>**Inconsistência**|**alidade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ depacientes**<br>**Efe**<br>**a**<br>**gravidade**<br>**estimada**<br>**pela escala**<br>**de**<br>**Paradeniya **<br>**nada**<br>**Relativo**<br>**(95% CI)**|**ito**<br>**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|
|1<br>Mortali|estudos<br>observacionais<br>dade|grave a|grave c|não grave|não grave|forte associação<br>todos os<br>potenciais fatores<br>de confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito foi<br>observado.|A escala de Peradeniya (EP) foi aplic<br>pacientes intoxicados por OF, admitido<br>unidade de saúde, sendo 66% desse<br>masculino (66%), com idade inferior a<br>idade. Os desfechos avaliados pelo es<br>morbidade e mortalidade. Na admissão, o<br>foram classificados de acordo com a<br>apresentando uma intoxicação leve (50%)<br>(44%) e grave (6%). Nos pacientes c<br>como graves<br>foi observada uma<br>significativamente<br>maior<br>de<br>in<br>respiratória (100%), um maior tempo de<br>na Unidade de Terapia Intensiva e pe<br>óbito do que nos demais grupos. Ess<br>desfechos foram gradualmente menores<br>grupos (Vernekar & Shivaraj, 2017)|ada em 50<br>s em uma<br>s do sexo<br>30 anos de<br>tudo foram<br>s pacientes<br>EP como<br>, moderada<br>lassificados<br>incidência<br>suficiência<br>internação<br>rcentual de<br>es mesmos<br>nos demais|⨁⨁`◯◯`<br>BAIXA|IMPORTANTE|  
142  
<!-- Start of picture text -->
Avalia ç ão de  Q ualidade  № de  p acientes  Efeito<br>a<br>gravidade<br>№ dos  Delineamento  Risco de  Evidência  Outras  estimada  Relativo  Absoluto  Qualidade  Importância<br>Inconsistência  Imprecisão  nada  (95%<br>estudos  do estudo  viés  indireta  considerações  pela escala  (95% CI)<br>CI)<br>de<br>Paradeni y a<br>1   estudos  grave a  não grave   não grave  não grave   forte associação  6/25  não  ⨁⨁⨁⨁ CRÍTICO<br>observacionais   todos os  (24.0%)   estimável   ALTA<br>potenciais fatores<br>de confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito foi<br>observado.<br>gradiente de<br>dose-resposta<br><!-- End of picture text -->  
**Referência:** Vernekar, P. V, & Shivaraj, K. (2017). Peradeniya organophosphorus poisoning scale (POP) as a predictor of respiratory failure and mortality in organophosphorus poisoning. Scholars Journal of Applied Medical Sciences (SJAMS), 5(5B), 852–856. https://doi.org/10.21276/sjams  
143  
**Quadro II.5.4.1.** Avaliação das evidências pelo método GRADE sobre “Carvão Ativado” como medida de descontaminação ou eliminação para pacientes com intoxicação aguda por agrotóxicos. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação da Ev**|**Uso de uma**<br>**idência**|**única dose d**|**e carvão ativado co**|**mparando co**<br>**№ dep **|**m a não utiliz**<br>**acientes**|**ação**<br>**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**uma única**<br>**dose de**<br>**carvão**<br>**ativado**|**nenhuma**<br>**dose de**<br>**carvão**<br>**ativado**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Desfecho|: Mortalidade||||||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<br>a,b,c,d,e|não grave|não grave|não grave|todos os<br>potenciais fatores<br>de confusão<br>reduziriam o<br>efeito<br>demonstrado|109/1544<br>(7.1%)|105/1554<br>(6.8%)|OR 1.05<br>(0.79 para<br>1.40)|3 mais por<br>1.000<br>(de 13 menos<br>para 25<br>mais)|⨁⨁⨁⨁<br>ALTA|CRÍTICO|  
##### **Usos de múlti** **<mark>p</mark> las doses de carvão ativado com** **<mark>p</mark> arando com o uso de uma única dose**  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**múltiplas**<br>**doses de**<br>**carvão**<br>**ativado**|**dose única**<br>**de carvão**<br>**ativado**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Desfech|o: Mortalidade||||||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<br>1,a,b,c,d|não grave|não grave|não grave|todos os<br>potenciais fatores<br>de confusão<br>reduziriam o<br>efeito<br>demonstrado|97/1531<br>(6.3%)|109/1544<br>(7.1%)|OR 0.89<br>(0.66 para<br>1.19)|7 menos por<br>1.000<br>(de 12 mais<br>para 23<br>menos)|⨁⨁⨁⨁<br>ALTA|CRÍTICO|  
144  
<!-- Start of picture text -->
Usos de múlti p las doses de carvão ativado com p arando com a não utiliza ç ão<br>múltiplas<br>№ dos  Delineamento  Risco de  Evidência  Outras  doses de  nenhuma  Relativo  Absoluto<br>Inconsistência  Imprecisão  Evidência  Importância<br>estudos  do estudo  viés  indireta  considerações  carvão  dose  (95% CI)  (95% CI)<br>ativado<br>Desfecho: Mortalidade<br>1   ensaios clínicos  grave a,b não grave   não grave  não grave   todos os  97/1531  105/1554  OR 0.93  4 menos por  ⨁⨁⨁⨁ CRÍTICO<br>randomizados   potenciais  (6.3%)   (6.8%)   (0.69  1.000  ALTA<br>fatores de  (de 15 mais<br>confusão  para  para 20<br>reduziriam o  1.25) menos)<br>efeito<br>demonstrado<br><!-- End of picture text -->  
- _a._ Não cegamento da avaliação do desfecho  
- _b._ Estudo aberto  
- c. Tempo de admissão dos pacientes na unidade era variável, o que poderia reduzir a efetividade da intervenção  
- d. Protocolo institucional prevê lavagem gástrica em pacientes intoxicados  
**Referências:** Eddleston M, Juszczak E, Buckley NA, Senarathna L, Mohamed F, Dissanayake W, et al. Multiple-dose activated charcoal in acute selfpoisoning: a randomised controlled trial. Lancet (London, England). England; 2008 Feb;371(9612):579–87.  
145  
**Quadro II.5.5.1.** Avaliação das evidências pelo método GRADE sobre “lavagem gástrica” como medida de descontaminação ou eliminação para pacientes com intoxicação aguda por agrotóxicos inibidores de colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
<!-- Start of picture text -->
Avalia ç ão da  Q ualidade  № de  p acientes  Efeito<br>№ dos  Delineamento  Risco de  Evidência  Outras  lavagem  lavagem  Relativo  Absoluto  Qualidade  Importância<br>Inconsistência  Imprecisão  gástrica  gástrica  (95%<br>estudos  do estudo  viés  indireta  considerações  (95% CI)<br>multi p la  sim p les  CI)<br>Mortalidade (avaliado com: Pro p or ç ão)<br>6  ensaios  muito  muito grave  b grave  c grave  d forte associação  22/302  64/284  não  ⨁ ◯◯◯ CRÍTICO<br>1,2,3,4,5,6 clínicos  grave  a todos os  (7.3%)   (22.5%)   estimável   MUITO<br>randomizados   potenciais fatores  BAIXA<br>de confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito foi<br>observado.<br>Insuficiência res p iratória (avaliado com: Pro p or ç ão)<br>2  1,5 ensaios  muito  muito grave  b grave  e grave  d forte associação  10/253  25/241  não  ⨁ ◯◯◯ CRÍTICO<br>clínicos  grave  1,5,a todos os  (4.0%)   (10.4%)   estimável   MUITO<br>randomizados   potenciais fatores  BAIXA<br>de confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito foi<br>observado.<br><!-- End of picture text -->  
CI: Intervalo de Confiança  
- a. Estudos de uma mesma revisão sistemática com intervenções diversas com metodologias descritas inadequadamente e erros metodológicos segundo o autor da revisão. Não foram localizados os artigos primários.  
- b. Diferenças importantes nas estimativas de efeito  
- c. Estudos realizados para avalição de lavagem gástrica múltipla  
- d. Pequenos tamanhos de amostra  
146  
#### e. Estudos realizados para avalição de lavagem gástrica múltipla  
#### **Referências:**  
1. xX, Ji. The impact of different gastric lavage on the mortality of acute organophosphate poisoning. Med Theory Pract; 2000.  
2. You LH, Zeng Q. The experience of repeated gastric lavage in acute organophosphate poisoning. Sichuan Med; 2002.  
3. Luo QH, Liao LQ,He B,Liao J,Lu WH. The observation of multiple gastric lavages in acute organophosphates posioning. Sichuan Med J; 2002.  
4. Li YH, Zhang YX,. Effect of repeated gastric lavage on the blood cholinesterase activity in organophosphorus pesticide poisoning. Nurs Mag; 2000.  
5. Zhang PY, Seng MQ,Dong XQ,Yao YC,Wang XZ. The analysis of different gastric lavages in treatment of acute organophosphate poisoning. J Pract Nur; 2002.  
6. Luo FQ, Xie LW,Teng XL. Research on multiple gastric lavages in severe organphosphate poiosoning. China J Mod Med; 2005.  
**Quadro II.5.5.2.** Avaliação do risco de viés para o desfecho mortalidade relacionada a “lavagem gástrica” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos. Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de…<br>Sigilo da sequência de alocação (viés de…<br>Cegamento dos participantes (viés de…<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
147  
**Quadro II.5.6.1.** Avaliação das evidências pelo método GRADE sobre “Catárticos” como medida de eliminação para pacientes com intoxicação aguda por agrotóxicos. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|||**A**|**valiação da quali**|**dade**||||**Qualidade**|
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**consideraçõe**<br>**s**|**Sumário de Resultados**||
|**Efetividade**|**na redução da a**|**bsorção -Cat**|**árticos sozinhos**||||||
|5<sup>1,2,3</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|Muito grave<br>b|grave<sup>c</sup>|nenhum|Três estudos clínicos randomizados em voluntários<br>(_randomized crossover protocol_) envolvendo outros<br>agentes tóxicos, e não agrotóxicos, foram encontrados a<br>partir de revisão sistemática (Barceloux 2004) com<br>evidências sobre o uso de catártico sozinho como medida<br>de eliminação corpórea. Todos eles mostraram que o<br>catártico sozinho não reduz absorção do agente tóxico.<br>Total de 40 voluntários.|⨁`◯◯◯`<br>MUITO<br>BAIXA|  
a. São todos estudos com voluntários, e poucas informações são fornecidas sobre a randomização e aleatorização.  
b. Estudos com fármacos de liberação sustentada ou retardada, e não com agrotóxicos.  
c. Grupos pequenos.  
#### **Referências:**  
1. Sorensen PN. The effect of magnesium sulfate on the absorption of acetylsalicylic acid and lithium carbonate from the human intestine. Arch Toxicol. Springer;1975;34(2):121-7.  
2. Al-Shareef AH, Buss DC, Allen EM, Routledge PA. The effects of charcoal and sorbitol (alone and in combination) on plasma theophylline concentrations after a sustained-release formulation. Hum Exp Toxicol. Sage Publications Sage CA: Thousand Oaks, CA; 1990;9(3):179–82.  
3. Minton NA, Hentry JA. Prevention of drug absorption in simulated theophylline overdose. J Toxicol Clin Toxicol. Taylor & Francis; 1995;33(1):43–9.  
148  
**Quadro II.5.6.2.** Avaliação do risco de viés sobre a efetividade na redução da absorção após o uso de Catárticos sozinhos como medida de eliminação para pacientes com intoxicação aguda por agrotóxicos. Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de…<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
149  
**Quadro II.5.7.1.1** Avaliação das evidências pelo método GRADE sobre Circulação Extracorpórea com o uso de somente hemoperfusão para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação daQua**|**lidade**|||||
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário de Resultados**|**Qualidade**|
|**Mortalid**|**ade**||||||||
|2<sup>1,2</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|Um dos estudos (um ECR obtido por meio da busca sistemática) mostrou<br>ausência de diferença significativa na taxa de mortalidade entre os<br>grupos (6/31 no grupo experimental vs. 5/30 no grupo controle) (Liang<br>& Zhang, 2015) e o outro (obtido por busca não sistemática) mostrou<br>uma redução da mortalidade no grupo que recebeu a intervenção (12/130<br>no grupo experimental vs. 25/130 no grupo controle, p=0,023). No<br>entanto, o estudo que mostrou diferença significativa não foi<br>randomizado e carece de detalhes metodológicos necessários para julgar<br>se as evidências são clinicamente significativas.|⨁`◯◯◯`<br>MUITO<br>BAIXA|  
a. Um dos estudos é um ECR sem detalhes sobre randomização e alocação. Outro apresenta poucos detalhes metodológicos e parece ser um quasi-experimental, controlado, mas sem randomização.  
b. Em um dos estudos houve redução da mortalidade; no outro não houve.  
c. O ECR contou com apenas 61 pacientes. O outro estudo contou com 260 pacientes, mas a carência de detalhes metodológicos e a ausência de randomização fizeram com que a análise por GRADE fosse mais baseada no ECR.  
#### **_Referências_**  
1. Liang MJ, Zhang Y. Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in the treatment of acute severe organophosphorus pesticide poisoning. Genet Mol Res; 2015.  
2. Li Z, Wang G,Zhen G,Zhang Y,Liu J,Liu S. Application of hemoperfusion in severe acute organophosphorus pesticide poisoning. Turkish Journal of Medical Sciences; 2017.  
150  
**Quadro II.5.7.1.2.** Avaliação do risco de viés sobre a efetividade na redução da absorção após o uso de somente hemoperfusão para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de seleção)<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
151  
**Quadro II.5.7.2.1.** Avaliação das evidências pelo método GRADE sobre Circulação Extracorpórea com o uso de técnica combinada hemoperfusão associada a hemodiálise para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Certainty assess**|**ment**|||**№ depac**|**ientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**hemoperfusão**<br>**juntamente**<br>**com**<br>**hemodiálise**|**não**<br>**intervenção**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Certainty**|**Importância**|
|Mortalid|ade||||||||||||
|1|Estudo<br>observacional|Muito<br>grave<sup>a,b</sup>|não grave|não grave|não grave|forte associação<br>todos os<br>potenciais<br>fatores de<br>confusão<br>reduziriam o<br>efeito<br>demonstrado|1/34 (2.9%)|6/34<br>(17.6%)|não<br>estimável||⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|Tempo|de internação (dia|s)|||||||||||
|1|Estudo<br>observacional|Muito<br>grave<sup>a,b</sup>|não grave|não grave|não grave|nenhum|11.2|18.3|-|**0**<br>(0 para 0<br>)|⨁`◯◯◯`<br>MUITO<br>BAIXA|IMPORTANTE|
|Insufici|ência respiratória||||||||||||
|1|Estudo<br>observacional|Muito<br>grave<sup>a,b</sup>|não grave|não grave|não grave|nenhum|6/34 (17.6%)|6/34<br>(17.6%)|não<br>estimável||⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|  
CI: Intervalo de Confiança  
**Explicações**  
a. Número de pacientes limitado.  
152  
b. Estudo aberto e não randomizado, no qual o paciente, de acordo com a sua decisão de tratamento, é alocado em um dos grupos.  
**Referência** : DONG, Hui et al. Clinical emergency treatment of 68 critical patients with severe organophosphorus poisoning and prognosis analysis after rescue. Medicine (United States) v. 96, n. 25, p. 9–12 , 2017.  
**Quadro II.5.7.3.1.** Avaliação das evidências pelo método GRADE sobre Circulação Extracorpórea com o uso de técnicas combinadas hemoperfusão associada a hemodiálise  
versus hemoperfusão associada a filtração contínua para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQu **|**alidade**|||**№ depa **|**cientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>Mortalid|**Delineamento**<br>**do estudo**<br>ade|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**hemodiálise**<br>**sustentada de**<br>**baixa**<br>**eficiência**<br>**associada a**<br>**hemoperfusão**|**filtração**<br>**contínua**<br>**associada**<br>**com**<br>**hemoperfusão**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|1|ensaios<br>aleatórios|Muito<br>grave<br>1,a,b,c|não grave|não grave|não grave|nenhum|1/28|2/28|não<br>estimável||⨁⨁`◯◯`<br>BAIXA|CRÍTICO|
|Tempo d|e internação (dia|s)|||||||||||
|1|ensaios<br>aleatórios|Muito<br>grave<br>1,a,b,c|não grave|não grave|não grave|nenhum|O tempo de int<br>hemodialise as<br>no grupo de filtr|ernação foi 11.5<br>sociada a hemope<br>ação continua ass|dias ± 7.1 no<br>rfusão e 9.4<br>ociada a hem|grupo de<br>dias ± 5.3<br>operfusão|⨁⨁`◯◯`<br>BAIXA|CRÍTICO|  
CI: Intervalo de confiança  
#### **Explicações**  
a. Estudo monocêntrico com número restrito de pacientes.  
b. Não está claro o método de randomização  
c. Não define os critérios de exclusão.  
153  
#### **References**  
1. Shou-liang Hu, Dan Wang, Hong Jiang, Qing-feng Lei, Xiao-hua Zhu, and Jun-zhang Cheng. Therapeutic Effectiveness of Sustained Low-Efficiency Hemodialysis Plus Hemoperfusion and Continuous Hemofiltration Plus Hemoperfusion for Acute Severe Organophosphate Poisoning. Artificial Organs; 2014.  
**Quadro II.5.8.1.** Avaliação das evidências pelo método GRADE sobre “Atropina (doses incrementais Vs dose-resposta)” para o tratamento farmacológico inicial para pacientes intoxicados com organofosforados. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação daQu **|**alidade**|||**№ depa **|**cientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Atropina**<br>**incremental**|**Atropina**<br>**Dose-**<br>**resposta**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|Mortalid|ade||||||||||||
|1<sup>1</sup>|ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a,b</sup>|não grave|não grave|grave<sup>c</sup>|todos os<br>potenciais fatores<br>de confusão<br>reduziriam o<br>efeito<br>demonstrado|3/75 (4.0%)|18/81<br>(22.2%)|**RR 0.18**<br>(0.06 para<br>0.59)|**182**<br>**menos**<br>**por**<br>**1.000**<br>(de 91<br>menos<br>para 209<br>menos)|⨁⨁`◯◯`<br>BAIXA||
|Síndrom|e intermediaria||||||||||||
|1<sup>1</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|grave<sup>c</sup>|todos os<br>potenciais fatores<br>de confusão<br>reduziriam o<br>efeito<br>demonstrado|6/75 (8.0%)|11/81<br>(13.6%)|**RR 0.59**<br>(0.23 para<br>1.51)|**56**<br>**menos**<br>**por**<br>**1.000**<br>(de 69<br>mais<br>para 105<br>menos)|⨁⨁⨁`◯`<br>MODERADA||  
**CI:** Intervalo de Confiança; **RR:** Razão de Risco  
a. Estudo aberto, desenho não permite cegamento.  
154  
b. Houve falta de recursos para fornecer suporte ventilatório a todos os pacientes que precisavam. Não é claro a qual grupo pertenciam os que receberam essa intervenção.  
c. Pequeno tamanho de amostra  
**Referências:** 1. Abedin, . Open-Label Randomized Clinical Trial of Atropine Bolus Injection Versus Incremental Boluses Plus Infusion for Organophosphate Poisoning in Bangladesh. J. Med. Toxicol; 2012.  
**Quadro II.5.9.1.** Avaliação das evidências pelo método GRADE sobre “Oximas” para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**Avaliação deQu **|**alidade**|||**№ depa **|**cientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Pralidoxima**|**ausencia da**<br>**intervenção**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI**|**Qualidade**|**Importância**|
|Mortalid|ade (avaliado co|m: RR)||||||||**)**|||
|5|ensaios<br>clínicos<br>randomizados<br>1,2,3,4,5|grave<sup>a</sup>|não grave|não grave|muito<br>grave<sup>b</sup>|nenhum|72/296<br>(24.3%)|43/290<br>(14.8%)|**RR 1.58**<br>(1.00 para<br>2.49)|**86 mais**<br>**por**<br>**1.000**<br>(de 0<br>menos<br>para 221<br>mais)|⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|Necessi|dade de ventilação||||||||||||
|5|ensaios<br>clínicos<br>randomizados<br>1,2,3,4,5|grave<sup>a</sup>|não grave|não grave|muito<br>grave<sup>b</sup>|nenhum|104/296<br>(35.1%)|84/290<br>(29.0%)|**RR 1.25**<br>(0.94 para<br>1.66)|**72 mais**<br>**por**<br>**1.000**<br>(de 17<br>menos<br>para 191<br>mais)|⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|Síndrom|e intermediaria (a|valiado com|: RR)||||||||||  
155  
||||**Avaliação deQu **|**alidade**|||**№ depa **|**cientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|<br>**Imprecisão**|**Outras**<br>**considerações**|**Pralidoxima**|**ausencia da**<br>**intervenção**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|2<br>Síndrom|ensaios<br>clínicos<br>randomizados<br>2,5<br>e intermediaria c|grave<sup>c</sup><br>om 9|não grave|não grave|muito<br>grave<sup>d</sup>|nenhum|46/105<br>(43.8%)|27/105<br>(25.7%)|**RR 2.30**<br>(0.86 para<br>6.12)|**334 mais**<br>**por**<br>**1.000**<br>(de 36<br>menos<br>para<br>1.000<br>mais)|⨁`◯◯◯`<br>MUITO<br>BAIXA|IMPORTANTE|
|2|ensaios<br>clínicos<br>randomizados<br>2,5|grave<sup>c</sup>|não grave|não grave|muito<br>grave<sup>d</sup>|nenhum|46/105<br>(43.8%)|28/105<br>(26.7%)|**RR 2.11**<br>(0.96 para<br>6.48)|**296 mais**<br>**por**<br>**1.000**<br>(de 11<br>menos<br>para<br>1.000<br>mais)|⨁`◯◯◯`<br>MUITO<br>BAIXA||  
**CI:** Intervalo de Confiança; **RR:** Razão de Risco  
a. Um dos estudos é aberto de dois braços com randomização inadequada. Dois estudos não têm dados suficientes para avaliar o risco de viés. São poucos estudos para avaliação de viés de publicação.  
b. Os intervalos de confiança cruzam os limites de decisão clínica. Apesar do intervalo de confiança ser estreito o tamanho da amostra e o número de eventos é pequeno  
c. Desfechos com avaliação subjetiva, São poucos estudos para avaliação de viés de publicação.  
d. Os intervalos de confiança cruzam os limites de decisão clínica. O intervalo de confiança é largo. O tamanho da amostra e o número de eventos é pequeno.  
#### **Referências:**  
1. Benerjee, . Efficacy of pralidoxime in organophosphorus poisoning: Revisiting the controversy in Indian setting. J Postgrad Med [serial online] 2014; 2014. 2. Cherian, . Pralidoxime in organophosphate poisoning - a randomized controlled trial. Journal of Clinical Epidemiology; 1996.  
156  
3. Cherian MA, Roshini C,Visalakshi J,Jeyaseelan L,. Biochemical and clinical profile after organophosphorus poisoning--a placebo-controlled trial using pralidoxime.. Journal of the Association of Physicians of India; 2005.  
4. Eddleston M, Eyer P,Worek F,Juszczak E,Alder N,Mohamed F,et al.. Pralidoxime in acute organophosphorus insecticide poisoning--a randomised controlled trial.. PLoS. Medicine / Public Library of Science ; 2009.  
5. Syed, S.,Gurcoo,S. A.,Farooqui,A. K.,Nisa,W.,Sofi,K.,& Wani,T. M.. Is the World Health Organization-recommended dose of pralidoxime effective in the treatment of organophosphorus poisoning? A randomized, double-blinded and placebo-controlled trial. . Saudi journal of anaesthesia; 2015.  
**Quadro II.5.9.2.** Avaliação do risco de viés sobre “Oximas” para o tratamento farmacológico inicial para pacientes intoxicados com inibidores da colinesterase. Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de seleção)<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
157

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 2 | secao: ANEXOS -->
#### **ANEXO II.6.1 – Diagnóstico**  
**QUADRO II.6.1** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para o diagnóstico de Intoxicações por agrotóxicos inibidores de colinesterase.  
|**PERGUN**<br>**intermedi**|**TA: Quais os sinais apresentados pelos pacientes**<br>**ária tardia?**|**intoxicados por inibidores de colinesterase aumentam a**|**s chances de síndrome**|
|---|---|---|---|
|**P**Populaçã<br>|o intoxicada com Inibidores de colinesterase<br>|||
|**I/E** Sinais|e sintomas|||
|**C**Ausênci<br>**O** Síndrom<br>|a da intervenção<br>e Intermediária tardia<br>|||
|**S**Clínicos|e observacionais<br>|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☒Baixa (GCS)<br>☒Moderada (Idade e DOF)<br>☐Alta|Em estudo realizado com 176 pacientes, dos quais 31<br>desenvolveram a SIT, foi observado que a maioria<br>deles apresentou fraqueza muscular no pescoço como<br>característica inicial, sendo que esse mesmo grupo<br>evoluiu para insuficiência respiratória (20/26). Idade<br>acima de 45 anos (RR 2,23; IC 95% 1,14 - 4,38, p<<br>0,02) e intoxicação por DOF (RR 4,87; IC 95% 1,82<br>- 13,04, p< 0,01) foram fatores associados ao<br>desenvolvimento da SIT. Curvas ROC foram<br>utilizadas para avalar se o escore obtido na escala de<br>intoxicação e na escala de Glasgow (GCS) são<br>preditores de agravamento e mortalidade.  Os valores<br>encontrados, respectivamente, para a AUC, a<br>sensibilidade e a especificidade foram: 0,77 / 0,94 /<br>0,6 para IPCS PSS> 2 e 0,64 / 0,71 / 0,65 para<br>GCS≤10.   A mortalidade, no geral, foi de 28,4% (n=<br>50); sendo que 40% (n =20/50) ocorreu entre<br>pacientes<br>que<br>desenvolveram<br>a<br>síndrome||  
158  
|||intermediária e insuficiência respiratória (INDIRA;<br>ANDREWS; RAKESH, 2013).|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito||
||**Os custos associados à intervenção são**<br>**pequenos?**||
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||  
159  
||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|---|---|
|**ade**|☐Não|
|**Aceitabilid**|☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||A opção é viável para implementar?|
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recomendação**|Considere a possibilidade de<br>por IC apresente algumas da<br><br>Intoxicação por dim<br><br>Paciente com idade<br><br>Fraqueza muscular d|desenvolvimento da síndrome inte<br>s seguintes características:<br>etil organofosforados (DOF); ou<br>acima de 45 anos; ou<br>opescoço como característica inic|rmediária tardia, caso o pacie<br>ial;ou|nte especialmente intoxicado|  
160  
||<br>Avaliação na escala de Glasgow ≤ 10; ou<br><br>Escore obtido na escala do Programa Internacional para a Classificação de G<br>Química (IPCS PSS) > 2|ravidade de Intoxicação e Segurança|
|---|---|---|
|**Justificativa**|||
|**Considerações subgrupo**|||
|**Considerações implementação**|||
|**Monitoramento e avaliação**|||
|**Prioridades de pesquisa**|||
|**PERGUNTA: Qual a melhor escala**<br>**P**População intoxicada com inibidore|**para categorizar a gravidade da intoxicação por Inibidores de colinesterase?**<br>s de colinesterase||
|**I**Escala Paradeniya|||
|**C**Ausência da intervenção|||
|**O**Redução da mortalidade|||
|**S**Clínicos e observacionais|||
|**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios**<br>**e riscos**<br>**Qual a qualidade da E**<br>☐Sem estudos<br>☒Muito baixa (IR)|**vidência**<br>A escala de Peradeniya (EP) foi aplicada em 50<br>pacientes<br>intoxicados<br>por<br>organofosforados,<br>admitidos em uma unidade de saúde, sendo 66%<br>desses do sexo masculino (66%), com idade inferior a<br>30 anos de idade. Os desfechos avaliadospelo estudo||  
161  
||☒Baixa (Tempo UTI)<br>☐Moderada<br>☒Alta (mortalidade)|foram morbidade e mortalidade. Na admissão, os<br>pacientes foram classificados de acordo com a EP<br>como apresentando uma intoxicação leve (50%),<br>moderada (44%) e grave (6%). Nos pacientes<br>classificados como graves foi observada uma<br>incidência significativamente maior de insuficiência<br>respiratória (100%), um maior tempo de internação na<br>Unidade de Terapia Intensiva e percentual de óbito do<br>que nos demais grupos. Esses mesmos desfechos<br>foram gradualmente menores nos demais grupos<br>(VERNEKAR; SHIVARAJ, 2017)_._|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito||  
162  
||Os custos associados à intervenção são pequenos?||
|---|---|---|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||**A opção é aceitável para as principais partes**<br>**interessadas?**||
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||A opção é viável para implementar?||
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
|||**Conclusão**|  
163  
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|---|---|---|---|---|
|**Recomendação**|Na admissão de pacientes<br>categorizar a gravidade da i<br>Solicite análises de CPK e a|com suspeita de exposição a org<br>ntoxicação.<br>milase sérica e correlacione os resu|anofosforados, utilize a esca<br>ltados com a EP.|la de Peradeniya (EP) para|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: O uso de escala de**|**APACHE II para estimar o**|**prognóstico dos pacientes intoxic**|**ados por Inibidores de colin**|**esterase**|
|<br>**P**População intoxicada com inibid|<br>ores de colinesterase||||
|**I**escala de APACHE II|||||
|**C**Ausência da intervenção|||||
|**O**Redução da mortalidade|||||
|**S** Clínicos e observacionais|||||
|**Julgamento**||**Evidências**|**Consi**|**derações adicionais**|
|**Benefícios**<br>**e riscos**<br>**Qual a qualidade da**|**Evidência**|Numa análise multivariada de r<br>níveis de bicarbonato sérico e o|egressão logística, os<br>escore do paciente na||
|☐Sem estudos||escala de APACHE II foram fat|ores importantespara||  
164  
|☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☐Alta|a determinação do prognóstico de pacientes vítimas de<br>intoxicação por IC. A idade média dos pacientes<br>incluídos foi de 56 anos (faixa, 16-88), sendo o grupo<br>constituído por 57 (62%) homens e 35 (38%)<br>mulheres. Na comparação entre as características<br>clínicas do grupo sobrevivente (n = 81, 88%) e do não<br>sobrevivente (n = 11, 12%), não foi observada<br>diferenças de parâmetros relacionados à função renal,<br>às enzimas pancreáticas ou ao nível sérico de AChE e<br>o escore de APACHE II. Os níveis de bicarbonato<br>sérico foram menores nos não sobreviventes do que<br>nos sobreviventes (12,45 ± 2,84 vs. 18,36 ± 4,73, P<br><0,01). O escore de APACHE II foi maior nos não<br>sobreviventes do que nos sobreviventes (24,36 ± 5,22<br>vs. 12,07 ± 6,67, P <0,01). O desenvolvimento de<br>pneumonia durante a hospitalização foi maior nos não<br>sobreviventes do que nos sobreviventes (n = 9, 82%<br>vs. n = 31, 38%, P <0,01). Na análise de regressão<br>logística<br>múltipla,<br>a<br>concentração<br>sérica<br>de<br>bicarbonato, o escore APACHE II e a pneumonia<br>durante a hospitalização foram fatores prognósticos<br>importantes em pacientes vítimas de intoxicação por<br>IC (Sun et al,2015).|
|---|---|
|**Há balanço entre os riscos e benefícios**||
|`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||  
165  
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|
||**Os custos associados à intervenção são**<br>**pequenos?**|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|**ade**|☐Não|
|**tabilid**|☐Provavelmente não<br>☐Incerto|
|**Acei**|☐Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
166  
||A opção é viável para|implementar?||||
|---|---|---|---|---|---|
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|||||
||||**Conclusão**|||
|**Tipo de r**|**ecomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação condicional**<br>**a favor da intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recomen**|**dação**|Para uma estimativa de pro<br>escore APACHE II.|gnóstico de pacientes intoxicado|s por organofosforados, admitid|os na unidade, determine o|
|**Justificat**|**iva**|||||
|**Consider**|**ações subgrupo**|||||
|**Consider**|**ações implementação**|||||
|**Monitora**|**mento e avaliação**|||||
|**Priorida**|**des de pesquisa**|||||
|**PERGU**<br>**colineste**|**NTA: Deve-se usar os nív**<br>**rase?**|**eis de acetilcolinesterase e**|**butirilcolinesterase como bioma**|**rcadores para intoxicação ou e**|**xposição por inibidores de**|
|**P**Popula|ção intoxicada com inibido|res de colinesterase||||
|**I**nível d|e acetilcolinestersase e but|irilcolinesterase||||
|**C**Ausênc|ia da intervenção|||||
|**O**Reduçã|o da mortalidade|||||
|**S** Clínico|s e observacionais|||||
||**Julgamento**||**Evidências**|**Consid**|**erações adicionais**|  
167  
|**Qual a qualidade da Evidência**|Estudo retrospectivo realizado a partir de dados<br>coletados de 102 prontuários de pacientes intoxicados|
|---|---|
|☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☒Alta|por IC. A idade média dos pacientes era de 56 anos<br>(faixa, 16-88), sendo 57 (62%) homens e 35 (38%)<br>mulheres. Na comparação das características clínicas<br>entre o grupo sobrevivente (n = 81, 88%) e o grupo não<br>sobrevivente (n = 11, 12%), não foram observadas<br>diferenças na função renal, enzimas pancreáticas ou<br>nível sérico da AChE. Diferenças, contudo, foram<br>significativas entre o nível sérico de bicarbonato e do<br>escore APACHE II. Os autores correlacionaram os<br>níveis de BChE com o escore APACHEII e sugerem<br>que a redução na atividade dessa enzima pode ser<br>utilizada como critério de avaliação da gravidade da<br>intoxicação (SUN; YOON; LEE, 2015).<br>Para examinar a correlação entre 25 sintomas<br>neurológicos auto-relatados por 95 adolescentes, do<br>sexo masculino com alguns biomarcadores de<br>exposição ao clorpirifos (CPF), dentre eles a AChE e<br>a BChE, foi realizado um estudo transversal em dois<br>distritos agrícolas do Egito, na estação aplicação de<br>agrotóxicos. Os participantes foram divididos em<br>dois grupos: aplicadores de CPF (n = 57) e não<br>aplicadores (n = 38). Foi observado que a BChE é<br>mais sensível à exposição ao CPF do que a AChE,<br>com a atividade mediana reduzida em 37% da linha<br>de base em aplicadores e 13% em não aplicadores<br>durante o período de aplicação do CPF. As<br>associações significativas (p = 0,03-0,07) entre a<br>mudança na atividade da BChE desde a pré-aplicação<br>até a estação pós-aplicação e vários domínios de<br>sintomas neurológicos também foram encontradas,|  
168  
|||mesmo depois de ajustar as covariáveis potenciais<br>(KHAN_et al._,2014).|
|---|---|---|
||**Qual a qualidade da Evidência**||
||☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta||
||**Há balanço entre os riscos e benefícios**||
||`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito||  
169  
||**Os custos associados à intervenção são**<br>**pequenos?**||
|---|---|---|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||**A opção é aceitável para as principais partes**<br>**interessadas?**||
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||A opção é viável para implementar?||
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
|||**Conclusão**|  
170  
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação condicional**<br>**a favor da intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|---|---|---|---|---|
|**Recomendação**|Utilize os níveis de acetilc<br>intoxicação e exposição ac<br>compostos,mas as manifesta|olinesterase (AChE) e butirilcol<br>idental a organofosforadosou c<br>ções clínicas nãopermitem um di|inesterase (BChE) como bioma<br>arbamatos, quando há suspeita<br>agnóstico conclusivo.|rcadores para os casos de<br>de intoxicação por esses|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||  
**QUADRO II.6.2** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para o tratamento de Intoxicações por agrotóxicos inibidores de colinesterase.  
**<u><mark>PERGUNTA: Deve-se usar Carvão Ativado como medida de descontaminação no tratamento de intoxicações por inibidores de colinesterase?</mark></u>** **<mark>P</mark>** <mark>População intoxicada com agrotóxicos</mark> **<mark>I</mark>** <mark>Carvão ativado</mark> **<u><mark>C</mark></u>** <mark>Ausência da intervenção</mark>  
171  
|**O**Reduç|ão da mortalidade|||
|---|---|---|---|
|**S**Clínico|s e observacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
||**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☐Baixa|Em um ensaio clínico, 1.310 pacientes, maiores de 14 anos,<br>intoxicados com inibidores de colinesterase foram<br>randomizados em três grupos: um de dose única de carvão<br>ativado (440), um de doses múltiplas (429) e um sem carvão<br>ativado (441). A história de êmese antes do atendimento,<br>êmese forçada ou lavagem gástrica foi semelhante entre os||
||☒Moderada<br>☐Alta|grupos.<br>Não houve redução significativa da mortalidade nos grupos<br>avaliados, tanto no de dose única (OR 0,94, IC 95% 0,63-<br>1,41), como no de doses múltiplas (OR 0.78, 95% IC 95%<br>0,51-1,19) quando comparados com o grupo que não<br>recebeu a intervenção. Tampouco se observaram diferenças<br> <br> <br>||
|**scos**||significativas<br>quando<br>comparados<br>os<br>grupos<br>intervencionais.||
|**Benefícios e ri**||Não foi Evidênciada uma redução significativa na<br>necessidade de intubação, a apresentação de convulsões, o<br>tempo até a morte ou o agravamento clínico com o uso de<br>carvão ativado em doses múltiplas ou única.  A duração<br>média da ventilação (excluindo as mortes) foi semelhante<br>no grupo que recebeu doses múltiplas, quando comparado<br>com o grupo sem intervenção. Contudo, essa foi mais longa<br>nos pacientes tratados com dose única de carvão ativado.<br>Não houve diferenças significativas quando o carvão<br>ativado foi administrado antes ou após duas horas da<br>ingestão. Contudo, deve-se considerar que somente um<br>número pequeno de pacientes chegaram ao local de<br>atendimento antes de transcorridas duas horas da exposição.<br>O IC estreito (IC 95% 0,61 a 2,38,) sugere pouco benefício<br>(Eddleston,Juszczak,et al. 2008).||
||**Há balanço entre os riscos e benefícios**|Os**efeitos adversos**associados ao uso carvão<br>ativado são: pneumonia aspirativa (Amigó, Nogué, and Mir<br>2010;Bairral 2012;Bosse et al. 1995;Dorrington et al.||  
172  
||`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|2003; Golej et al. 2001; Harris and Filandrinos 1993;<br>Menzies 1988; Osterhoudt et al. 2004; Pollack et al. 1981;<br>Silberman, Davis, and Lee 1990); empiema (Justiniani,<br>Hippalgaonkar, and Martinez 1985);  pneumotórax<br>(Thomas, Cummin, and Falcone 1996); bronquiolite<br>obliterante (Elliott et al. 1989), insuficiência respiratória<br>(Francis et al. 2009; Golej et al. 2001; Gutiérrez, Bossert,<br>and Espinosa 2013); cavernas pulmonares (Francis et al.<br>2009); mediastinite (Caravati et al. 2001); doença pulmonar<br>crônica (Graff 2002) SARA (De Weerdt et al. 2015),<br>linfangioleiomiomatose pulmonar(Huber et al. 2006),<br>granuloma, (Seder et al. 2006), constipação (Osterhoudt et<br>al. 2004) infeção respiratória (George 1991), abrasão<br>corneana (Dorrington et al. 2003; McKinney et al. 1993)<br>êmese (Boyd and Hanson 1999; Crockett et al. 1996;<br>Merigian 1990; Osterhoudt et al. 2004), dificuldade de<br>visualização dos procedimentos (Lopes de Freitas, Ferreira,<br>and Brito 1997; Moore and Davies 1996) e alterações<br>hidroeletrolíticas (Dorrington et al. 2003).|
|---|---|---|
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☒Mal aceito||  
173  
||Os custos associados à intervenção são pequenos?|Dificuldade na logística|
|---|---|---|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☒Sim<br>☐Há variabilidade||
||**A opção é aceitável para as principais partes**<br>**interessadas?**||
|**Aceitabilidade**|☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||A opção é viável para implementar?||
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☒Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
|||**Conclusão**|  
174  
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☒|**Recomendação condicional**<br>**a favor da intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|---|---|---|---|---|
|**Recomendação**|Não recomendamos o uso ro|tineiro de carvão ativadopara into|xicaçãopor agrotóxicos.||
|**Justificativa**|Maior risco que benefício||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|Logística de distribuição||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|Em ambientes hospitalares e|com agrotóxicos em menos de 1|h||
|**PERGUNTA: Deve-se realizar**|**a lavagem gástrica em pacien**|**tes intoxicados por inibidores d**|**e colinesterase?**||
|**P**População intoxicada com agrot|óxicos inibidores de colinester|ase|||
|**I**Lavagemgástrica|||||
|**C**Ausência da intervenção|||||
|**O**Redução da mortalidade|||||
|**S**Clínicos e observacionais|||||
|**Julgamento**||**Evidências**|**Consid**|**erações adicionais**|
|**Be**<br>**ne**<br>**fíc**<br>**ios**<br>**Qual a qualidade da**|**Evidência**|Foi encontrada uma revisão sist<br>avaliados 56 estudos de m|emática na qual foram<br>etodologias diversas.||  
175  
|☐Sem estudos<br>☒Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta|Desses, 23 eram ensaios clínicos controlados e<br>randomizados, que avaliaram a eficácia e a segurança<br>de utilização da lavagem gástrica para intoxicações<br>com organofosforados diversos. Desses, por sua vez,<br>foram selecionados 6 estudos nos quais todos os<br>pacientes receberam como procedimento de base a<br>lavagem gástrica na sua forma múltipla ou única.<br>Nenhum dos estudos comparou a referida intervenção<br>com a sua não realização. No geral, nenhum dos<br>estudos indicou se houve ou não uma remoção<br>significativa do agente tóxico no lavado gástrico. Os<br>benefícios do procedimento foram incertos, com a<br>perspectiva de que talvez lavagens múltiplas<br>contribuíssem para a redução da mortalidade e para o<br>desenvolvimento de insuficiência respiratória. Assim,<br>apesar do uso generalizado de lavagens gástricas<br>múltiplas para o tratamento de intoxicação por<br>organofosforados<br>em<br>alguns<br>países,<br>não<br>há,<br>atualmente, nenhuma evidência de alta qualidade para<br>apoiar sua eficácia clínica(LI,YI_et al._,2009).|
|---|---|
|**Há balanço entre os riscos e benefícios**||
|`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios||
|`☐`Riscos sobrepõem os benefícios||  
176  
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|
||**Os custos associados à intervenção são**<br>**pequenos?**|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
177  
||A opção é viável para i|mplementar?||||
|---|---|---|---|---|---|
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|||||
||||**Conclusão**|||
|**Tipo de r**|**ecomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação condicional**<br>**a favor da intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recomen**|**dação**|Não é recomendável a realiza|ção lavagemgástrica empacient|es intoxicadospor inibidores de c|olinesterase|
|**Justificat**|**iva**|||||
|**Consider**|**ações subgrupo**|||||
|**Consider**|**ações implementação**|||||
|**Monitor**|**amento e avaliação**|||||
|**Priorida**|**des de pesquisa**|||||
|**PERGU**|**NTA: Deve-se usar cartá**|**ticos como forma de elimina**|**ção no tratamento de pacientes**|**intoxicados por agrotóxicos in**|**ibidores de colinesterase?**|
|**P**Popula|ção intoxicada com agrotó|xicos||||
|**I**catártic|o|||||  
178  
|**C**Ausê|ncia da intervenção|||
|---|---|---|---|
|**O**Redu|ção da mortalidade|||
|**S** Clínic|os e observacionais<br>|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**cios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta|Não foram encontrados ensaios clínicos randomizados<br>controlados sobre a utilização de catárticos para o tratamento<br>de pacientes com intoxicação aguda por agrotóxicos. Por<br>outro lado, a partir de revisão sistemática (Barceloux 2004),<br>três estudos clínicos randomizados com evidências sobre o<br>uso de catártico sozinho como medida de eliminação<br>corpórea de medicamentos emergiram na busca. Todos eles<br>antigos, com um número muito limitado de voluntários, e<br>que mostraram que o catártico sozinho não reduz a absorção<br>do agente (Al-Shareef et al. 1990; Minton and Hentry 1995;<br>Sørensen 1975).||
|**Benefí**|**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|As complicações do uso de catártico são (Barceloux 2004):<br><br>Dose única: cólicas abdominais, náuseas, vômitos,<br>diaforese, hipotensão.<br><br>Doses múltiplas ou excessivas: desidratação;<br>hipernatremia em pacientes que recebem catártico<br>contendo sódio ou doses excessivas de sorbitol;<br>hipermagnesemia em pacientes que recebem<br>catártico contendo magnésio.||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☒Mal aceito|||  
179  
||**Os custos associados à intervenção são pequenos?**||
|---|---|---|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☒Sim<br>☐Há variabilidade||
||**A opção é aceitável para as principais partes**<br>**interessadas?**||
|**Aceitabilidade**|☒Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||A opção é viável para implementar?||
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☒Sim<br>☐Há variabilidade||
|||**Conclusão**|  
180  
|**Tipo de recomendação**|**Recomendação forte contra**<br>**a intervenção**|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**|**Recomendação condicional**<br>**a favor da intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
|---|---|---|---|---|
||☒|☐|☐|☐|
|**Recomendação**|Não se recomenda o uso de catárti<br>colinesterase|cos como medida de eliminação pa|ra o tratamento do paciente intoxicad|o por inibidores de|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações**<br>**implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Deve-se usar té**|**cnicas de eliminação extracorp**|**órea para tratamento de intoxi**|**cações por inibidores de colines**|**terase?**|
|**P**População intoxicada com ag|rotóxicos inibidores de colinester|ase|||
|**I**eliminação extracorpórea|||||
|**C**Ausência da intervenção|||||
|**O**Redução da mortalidade|||||
|**S** Clínicos e observacionais|||||
|**Julgamento**||**Evidências**|**Consid**|**erações adicionais**|  
181  
|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa|Foram encontrados quatro estudos que avaliaram a<br>utilização de técnicas de eliminação extracorpórea para<br>o tratamento de pacientes com intoxicação aguda por<br>organofosforados (DONG_et al._, 2017; HU_et al._, 2014;|
|---|---|
|☐Baixa|LI, ZHENHE_et al._, 2017; LIANG; ZHANG, 2015).|
|☐Moderada<br>☐Alta|Apenas um deles randomizado e controlado, realizado<br>com 61 vítimas intoxicação severa aguda por<br>organofosforados. Nele, foi observado que o tempo de<br>recuperação do coma, o tempo de ventilação mecânica,<br>e o tempo de cicatrização foram menores nos pacientes<br>tratados com hemoperfusão (grupo experimental) do<br>que no grupo controle (p<0,05). Contudo, as taxas de<br>hospitalização foram maiores no grupo experimental<br>(p<0,01). Além disso, não houve diferença significativa<br>(p>0,05) na taxa de mortalidade entre o grupo controle<br>(5/30) e o experimental (6/31). Todos os pacientes<br>também receberam antagonista colinérgico como parte<br>do tratamento (LIANG; ZHANG, 2015).<br>Em outro estudo realizado com 260 pacientes com<br>intoxicação aguda severa por organofosforados, o<br>grupo que recebeu a hemoperfusão teve uma redução<br>significativa (p<0,05) na incidência de síndrome<br>intermediária (5/130 vs. 14/130), na mortalidade<br>(12/130 vs. 25/130) e no tempo de recuperação de 50%<br>da AChE (5,0 ± 3,2 vs. 5,8 ± 2,4 dias) em relação ao<br>grupo controle (LI, ZHENHE_et al._, 2017).<br>Para a comparação entre técnicas de eliminação<br>combinadas<br>(hemoperfusão<br>mais<br>hemofiltração<br>contínua e hemoperfusão mais hemodiálise sustentada<br>de baixa eficiência), 56 pacientes também gravemente<br>intoxicados por organofosforados foram distribuídos<br>em doisgrupos de tratamento. Não foi observada|  
182  
||diferença estatisticamente significativa em relação ao<br>tempo de internação hospitalar ou em relação aos<br>indicadores bioquímicos e parâmetros hemodinâmicos;<br>na taxa de sobrevivência ou na taxa de mortalidade<br>(p>0,05) entre os grupos (HU_et al._, 2014).<br>Por fim, em um estudo clínico aberto não randomizado,<br>onde 68 pacientes com intoxicação grave por<br>organofosforados foram avaliados, as taxas de<br>mortalidade (1/34) e de rebote (1/34) foram<br>significativamente (p<0,05) menores no grupo que<br>recebeu hemoperfusão e hemodiálise do que no grupo<br>controle (6/34 e 4/34, respectivamente). Os tempos de<br>atropinização, de recuperação da atividade de<br>colinesterase, de recuperação de consciência, de<br>extubação e de hospitalização foram todos menores no<br>grupo tratamento, assim como o uso total de atropina<br>(p<0,05). No entanto, a falta de randomização e o<br>efetivo reduzido de pacientes torna a potência do estudo<br>insuficiente (DONG_et al._, 2017).|
|---|---|
|**Há balanço entre os riscos e benefícios**||
|`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||  
183  
|**Valores  e**|**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|---|
|||**Os custos associados à intervenção são pequenos?**|
|**Custos**||☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
|||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|**Aceitabilidade**||☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim|
|||☐Há variabilidade|  
184  
||A opção é viável para i|mplementar?||||
|---|---|---|---|---|---|
|**Viabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|||||
||||**Conclusão**|||
|**Tipo d**|**e recomendação**|**Recomendação forte contra**<br>**a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação condicional**<br>**a favor da intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recom**|**endação**|Considere a utilização de técni<br>sempre que a dose ingerida de a|cas de eliminação extracorpórea<br>gente for muito alta ou consider|para os casos de ingestão de orga<br>ada letal.|nofosforados lipossolúveis e|
|**Justifi**|**cativa**|||||
|**Consi**|**derações subgrupo**|||||
|**Consi**<br>**imple**|**derações**<br>**mentação**|||||
|**Monit**|**oramento e avaliação**|||||  
185  
|**Prioridades**<br>**PERGUNTA**|**de pesquisa**<br>**: Deve-se realizar a administração de atro**|**pina em pacientes intoxicados por inibidores de colinesterase**|**?**|
|---|---|---|---|
|**P**pacientes in|toxicadospor agrotóxicos inibidores de coli|nesterase||
|**I**atropina<br>||||
|**C**Ausência d|a intervenção|||
|**O**mortalidad|e|||
|**S**Clínicos e o|bservacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
||**Qual a qualidade da evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☐Alta|Um ensaio clínico randomizado comparou  o uso de<br>atropina em bolus com a sua administração<br>incremental<br>em<br>pacientes<br>intoxicados<br>por<br>organofosforados (ABEDIN_et al._, 2012).<br>O primeiro grupo (n= 81) recebeu bolus de 2-5 mg de<br>atropina IV a cada 10-15 min, até atingir a<br>atropinização; depois, a atropinização foi mantida||
|**Benefícios e riscos**||reduzindo-se a dose ou aumentando a duração entre<br>as doses de atropina. O segundo grupo (n= 75)<br>recebeu uma dose inicial de 1,8-3,0 mg de atropina<br>IV, dobrando a dose inicial a cada 5 min até<br>atropinização; sendo em seguida administrado, a<br>cada hora, de 10-20% da dose requerida para<br>atropinização. Os pacientes de ambos os grupos que,<br>apresentavam menos de 36 h da intoxicação,<br>receberam também pralidoxima.<br>Os pacientes do segundo grupo, apresentaram menor<br>mortalidade (6/75 vs. 18/80; p<0,05), menor duração<br>de tempo média para a atropinização (23,90 vs.<br>151,74 min; p<0,001) e menor toxicidade por<br>atropina (12,0 vs. 28,4 %; p<0,05), em comparação<br>com oprimeirogrupo. A incidência de síndrome||  
186  
|||intermediária (4% vs. 13,6%, p<0,05) e a necessidade<br>de suporte respiratório (8% vs. 24,7%, p<0,05)<br>também foram menores nesse grupo.|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferências**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito||
||**Os custos associados à intervenção são**<br>**pequenos?**||
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim||
||☐Há variabilidade||  
187  
||**A opção é aceitável p**<br>**interessadas?**|**ara as principais partes**||||
|---|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|||||
|**Viabilidade**|A opção é viável para<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|implementar?<br>||||
||||**Conclusão**|||
|**Tipo de recom**<br>**Cobertura**<br>**Recomendaçã**|**endação**<br>**o**|**Recomendação forte**<br>**contra a intervenção**<br>☐<br>Sugere-se realizar a adminis|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐<br>tração de atropina em doses incre|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐<br>mentais até que se alcance a a|**Recomendação forte a**<br>**favor da intervenção**<br>☐<br>tropinização.|
|**Justificativa**||||||
|**Consideraçõe**|**s subgrupo**|||||  
188  
|**Considera**|**ções implementação**||
|---|---|---|
|**Monitora**|**mento e avaliação**||
|**Prioridad**|**es de pesquisa**||
|**PERGUN**<br>**P**paciente|**TA: Deve-se usar oximas no tratamento de pacie**<br>s intoxicadospor inibidores de colinesterase|**ntes intoxicados por agrotóxicos inibidores de colinesterase?**|
|**I**oximas|||
|**C**Ausênci|a da intervenção||
|**O**mortalid|ade||
|**S**Clínicos|e observacionais<br>|<br>|
||**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☐Alta|A avaliação de cinco ensaios clínicos randomizados<br>sobre uso de pralidoxima em intoxicações por<br>organofosforados<br>não<br>mostrou<br>benefícios<br>da<br>intervenção na redução da mortalidade, necessidade<br>de ventilação mecânica e síndrome intermediaria.<br>Esses estudos foram realizados com diferentes doses<br>de pralidoxima e diferentes tipos de organofosforados<br>(BANERJEE; ROY; TRIPATHI, 2014; CHERIAN_et_<br>_al._, 2005; EDDLESTON, MICHAEL_et al._, 2009;<br>WANI_et al._, 2015).|
||**Há balanço entre os riscos e benefícios**||  
189  
||`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios|
|---|---|
|**Valores  e**<br>**preferências**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|**Custos**|**Os custos associados à intervenção são**<br>**pequenos?**<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
190  
||**A opção é aceitável para as principais partes**<br>**interessadas?**||||
|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|**Viabilidade**|A opção é viável para implementar?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|||**Conclusão**|||
|**Tipo de reco**<br>**Cobertura**|**mendação**<br>**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra a**<br>**intervenção**<br>☐|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recomendaç**|**ão**<br>Não se recomenda o uso de|oximas na intoxicação por inibido|res de colinesterase.||
|**Justificativa**|||||
|**Consideraçõ**|**es subgrupo**||||  
191  
|**Considerações implementação**|
|---|
|**Monitoramento e avaliação**|
|**Prioridades de pesquisa**|  
192

---

