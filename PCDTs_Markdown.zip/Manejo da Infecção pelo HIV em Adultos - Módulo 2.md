<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
<!-- Start of picture text -->
2<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 2 - Coinfecções e Infecções Oportunistas.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.358, de 1º de janeiro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 2 Coinfecções e Infecções Oportunistas.  
Art. 2º. Ficam atualizados, no âmbito do SUS, os capítulos 24 a 40 do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos, conforme consta do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 1 - Tratamento.  
Art. 3º. O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA MANEJO DA INFECÇÃO PELO HIV EM ADULTOS - MÓDULO 2: COINFECÇÕES E INFECÇÕES OPORTUNISTAS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Um marco na direção do acesso universal e gratuito à terapia antirretroviral no Brasil foi a Lei Federal nº 9.313, promulgada em 13 de novembro de 1996. Foi construída pela aliança entre a sociedade civil organizada, pesquisadores e gestores comprometidos com o enfrentamento da epidemia de Aids. Essa estratégia contribuiu para modificar o cenário epidemiológico da doença no país, aumentou a expectativa e melhorou a qualidade de vida das pessoas vivendo com HIV e Aids (PVHA). A construção conjunta baseada no princípio da universalidade, associada ao protagonismo comunitário proporcionou avanços e fortaleceu o Sistema Único de Saúde, ao mesmo tempo que direcionou a resposta brasileira para a equidade.  
Entretanto, novas e antigas barreiras permanecem como desafio para a garantia da universalidade.  A pandemia de Covid-19 acarretou redução de renda e teve impacto negativo no acesso à serviços de saúde. Além disso, questões de estigma e discriminação contra populações vulnerabilizadas foram amplamente difundidos no Brasil, agravando o contexto sanitário das doenças transmissíveis e das condições crônicas não transmissíveis.  
O diagnóstico de Aids e a presença de coinfecções e infecções oportunistas, ainda fazem parte do cotidiano dos serviços de saúde do país. Buscando fortalecer a resposta brasileira e reduzir a mortalidade pela Aids, o Departamento de HIV/Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis desenvolveu - com o apoio técnico do Grupo de Trabalho para Terapia Antirretroviral em Adultos Infectados pelo HIV - o módulo 2 do Protocolo Clínico e Diretrizes Terapêuticas para Adultos que Vivem com HIV.  
Este Protocolo apresenta as estratégias, atualizações e recomendações para o diagnóstico, tratamento e profilaxia das principais condições associadas a Aids. Dentre essas atualizações, destacam-se: a oferta de testes para diagnóstico e rastreio da infecção latente pelo _Mycobacterium tuberculosis (ILTB)_ , da tuberculose ativa e da criptococose.  
O teste de liberação de interferon-gama (do inglês _Interferon Gamma Release Assays-_ IGRA) e o teste de fluxo lateral para detecção de lipoarabinomanano em urina (LF-LAM) apoiam respectivamente, a identificação de Infecção Tuberculosa Latente (ILTB) e o diagnóstico da Tuberculose Ativa. Já o teste de fluxo lateral para diagnóstico da criptococose (do inglês _Cryptococcal Antigen Lateral Flow Assay_ – LF-CrAg) é utilizado para o diagnóstico de Criptococose. Tais tecnologias ampliam acesso e possibilitam a rápida identificação e tratamento destas doenças.  
- O presente documento também destaca:  
- a) o novo esquema para tratamento da ILTB (rifapentina e isoniazida), o qual reduz a toxicidade e o tempo de tratamento.  
- b) as formulações lipídicas de anfotericina que integram o conjunto de opções para tratamento de micoses sistêmicas e leishmaniose.  
Ao final do Protocolo, estão descritas as principais orientações para profilaxia primária e secundária das Infecções Oportunistas e o fluxo para solicitação da anfotericina nas formulações lipídicas para PVHA.  
Com esta atualização, espera-se proporcionar uma ampliação do cuidado integral às PVHA, contribuindo assim, para a redução da morbimortalidade, do sofrimento e subsidiando ações das equipes multidisciplinares no enfrentamento da doença e suas vulnerabilidades. Estas diretrizes tem o objetivo de contribuir para um futuro de maior esperança e qualidade de vida para às PVHA.  
Ainda, os medicamentos preconizados neste Protocolo estão descritos no **Apêndice A** .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para o tratamento da hepatite B. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Sendo a TB uma infecção de alta prevalência entre PVHA, sua presença deve ser investigada em todas as oportunidades de atendimento a esse grupo. Também é necessário realizar o teste para diagnóstico de infecção pelo HIV em todas as pessoas com diagnóstico de TB.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A tuberculose é a doença infecciosa definida de maior mortalidade entre as PVHA. Em 2020, registraram-se 10,6 milhões de casos de TB em todo o mundo, segundo a OMS, sendo que, destes, 703 mil casos ocorreram em PVHA<sup>1</sup> . A partir de 2014, observa-se uma redução consistente na proporção de casos novos com coinfecção TB-HIV no total de casos novos de TB, que passou de 12,2% (8.548 casos) em 2014 para 10,2% (7.038 casos) em 2020<sup>2</sup> . Com a ampliação da TARV, diminuíram os casos de coinfecção TB-HIV ao longo dos anos.  
Desde 1998, recomenda-se testar o usuário imediatamente para infecção pelo HIV assim que for realizado o diagnóstico de TB, possibilitando o início imediato da TARV. A partir de 2013, com a disponibilidade ampliada de testes imunocromatográficos para diagnóstico da infecção pelo HIV (teste rápido), estes passaram a ser o método preferencial para testagem de pessoas com diagnóstico recente de TB<sup>3</sup> , evitando com isso retardar o início da TARV.  
É importante destacar que, segundo a OMS, o Brasil encontra-se entre os 30 países com alta carga para TB e TB-HIV, sendo necessárias medidas estritas para o controle da doença<sup>1,2</sup> .  
As ações prioritárias destinadas às pessoas com TB e às PVHA são:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- Acesso oportuno ao diagnóstico da infecção pelo HIV por meio da oferta da testagem, preferencialmente utilizando o teste rápido;  
- Acesso oportuno à TARV, preferencialmente nos Serviços de Atendimento Especializados (SAE) ou demais serviços que realizem o acompanhamento de PVHA.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- Identificação precoce dos sintomas de TB com seu diagnóstico e instituição do tratamento oportunamente.  
- Realização da prova tuberculínica ou IGRA anual (conforme suas indicações);  
- Acesso oportuno ao tratamento da infecção latente pelo _Mycobacterium tuberculosis;_  
- Tratamento da ILTB para PVHA.  
O início célere da TARV nas PVHA é também uma estratégia de prevenção da TB, uma vez que a terapia diminui a incidência de TB nessa população, devendo ser instituída sem demora 4.  
O diagnóstico e o tratamento da ILTB em PVHA é essencial para minimizar o risco de adoecimento. A estratégia de controle da coinfecção TB-HIV está pautada no diagnóstico precoce de ambas as afecções e na garantia de tratamento adequado à pessoa, de forma oportuna.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A TB deve ser investigada em todas as visitas das PVHA aos serviços de saúde. A presença de febre, sudorese noturna, emagrecimento e/ou tosse, independentemente do tempo de duração, deve ser avaliada em todas as consultas de rotina.  
Nas pessoas com imunossupressão grave, as formas extrapulmonares e disseminadas da TB devem fazer parte das investigações sobre IO.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O teste rápido molecular para TB (TRM-TB) e a baciloscopia devem sempre ser acompanhados da realização de cultura, identificação da espécie e realização de teste de sensibilidade (TS) frente à suspeita de TB pulmonar ou extrapulmonar, utilizando, quando necessário, o escarro induzido ou exame de broncoscopia para coleta de lavado broncoalveolar.  
Em PVHA, o TRM-TB apresenta sensibilidade de 69% em pacientes com baciloscopia negativa e 97% em pacientes com baciloscopia positiva<sup>5</sup> . Já o TRM-TB ultra apresenta sensibilidade de 88% e especificidade de 95%<sup>6</sup> .  
O TRM-TB é um método molecular com base na reação em cadeia da polimerase (PCR). O teste detecta simultaneamente o DNA do _Mycobacterium tuberculosis_ e a resistência à  
rifampicina, diretamente da amostra clínica, em aproximadamente uma hora e meia. Esse método está indicado para o diagnóstico da TB, podendo ser utilizadas amostras pulmonares, como escarro, escarro induzido, lavado broncoalveolar e lavado gástrico, e também amostras extrapulmonares, como líquido cefalorraquidiano, linfonodos (punção ou macerado), macerado de tecidos, líquido sinovial, líquido peritoneal, líquido pericárdico, líquido pleural e urina. Também pode ser utilizado na triagem da resistência à rifampicina, nos casos de retratamento, falência ao tratamento da TB ou em suspeita de resistência à rifampicina.  
**Para o acompanhamento do tratamento da TB, deve-se realizar baciloscopia e não o TRM-TB.**  
Para mais informações sobre o TRM-TB consultar:  
<u>https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/svsa/tuberculose/teste-rapido-molecular-para-tuberculose-trm-tb</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O teste de fluxo lateral para detecção do antígeno lipoarabinomanano em urina (LF-LAM) é um teste rápido utilizando a amostra de urina do paciente e o resultado fica disponível em 25 minutos, sem a necessidade de processamento em laboratório<sup>7</sup> .  Pode ser utilizado para auxiliar no diagnóstico de tuberculose pulmonar e extrapulmonar nas seguintes situações:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- PVHA assintomáticas com LT-CD4 < 100 células/mm<sup>3</sup> ;  
- PVHA com sinais e/ou sintomas de TB pulmonar ou extrapulmonar, independentemente da contagem de LT-CD4;  
- PVHA gravemente doentes, independentemente da contagem de LT-CD4.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- PVHA assintomáticos LT-CD4 < 200 células/mm<sup>3</sup> ;  
- PVHA com sinais e/ou sintomas de TB pulmonar ou extrapulmonar, independentemente da contagem de LT-CD4;  
- PVHA gravemente doentes, independentemente da contagem de LT-CD4.  
Diante da sensibilidade e especificidade do LF-LAM, há necessidade de incluí-lo em um conjunto de ações para o rastreio e diagnóstico de tuberculose. A indicação seguindo a contagem de LT-CD4 tem como objetivo aumentar a sensibilidade do teste.  
São consideradas PVHA gravemente doentes, aqueles que apresentarem: frequência respiratória ≥30 respirações/minuto; frequência cardíaca ≥ 120 batimentos/minuto; incapacidade para deambular sem auxílio; temperatura corporal ≥ 39°C, considerando a epidemiologia local e julgamento clínico, independentemente da contagem de LT-CD4+.  
Deve-se instituir o tratamento para TB nos casos LF-LAM reagente e complementar a investigação com teste rápido molecular ou baciloscopia<sup>8,9</sup> . O teste pode ser reagente para microbactérias não tuberculosas. Nos casos de suspeita clínica de tuberculose e teste não reagente, prosseguir com a investigação diagnóstica para tuberculose. Se LF-LAM, baciloscopia e/ou teste molecular para tuberculose com resultado não reagente/negativo, investigar outras micobactérias.  
Para a investigação das formas extrapulmonares e disseminadas, é frequente a necessidade de complementação diagnóstica com procedimentos invasivos e de maior complexidade, conforme a avaliação do indivíduo<sup>3</sup> ( **Quadro 1** ).  
**Quadro 1** : Métodos diagnósticos para tuberculose em amostras biológicas  
|**MÉTODO DIAGNÓSTICO**|**MATERIAL**|
|---|---|
|Baciloscopia|Escarro<br>(espontâneo<br>ou<br>induzido),<br>lavado<br>broncoalveolar,<br>aspirado<br>transtraqueal,<br>lavado<br>gástrico, tecido, urina, líquidos (pleural, sinovial,<br>peritoneal, pericárdico, ascítico e cefalorraquidiano),<br>fragmento<br>de<br>órgãos,<br>fragmentos<br>cutâneos,<br>fragmentos ósseos, sangue, aspirados (de medula, de<br>linfonodos, detumores),fezes, pus e secreções|
|Teste<br>rápido<br>molecular<br>para<br>tuberculose<sup>(a)</sup>|Escarro, escarro induzido, lavado broncoalveolar,<br>lavado<br>gástrico,<br>líquido<br>cefalorraquidiano,<br>linfonodos (punção ou macerado), macerado de<br>tecidos, líquido sinovial, líquido peritoneal, líquido<br>pericárdico,líquido pleurale urina.|
|Teste lipoarabinomanano de fluxo<br>lateral naurina(LF- LAM) <sup>(b)</sup>|Urina|
|PCR<br>para<br>_Mycobacterium_<br>_tuberculosis_|Qualquer amostra biológica|
|Cultura|Escarro (espontâneo ou induzido), lavado brônquico,<br>lavado broncoalveolar, aspirado transtraqueal, lavado<br>gástrico, urina, líquidos (pleural, sinovial, peritoneal,<br>pericárdico, ascítico e cefalorraquidiano), fragmento<br>de órgãos, fragmentos cutâneos, fragmentos ósseos,<br>sangue, aspirados (de medula, de linfonodos, de<br>tumores),fezes, pus e secreções.|
|Adenosinadeaminase (ADA)<sup>(c)</sup>|Líquido pleural,líquido pericárdico|
|**Em PVHA, para todas as amostras b**<br>**se realizar a cultura para****_Mycobacter_**|**iológicas obtidas na investigação de TB recomenda-**<br>**_ium tuberculosis_ com teste de sensibilidade.**|  
Fonte: CGTM/SVSA/MS.  
(a) O teste rápido molecular para tuberculose é um teste baseado na reação em cadeia da polimerase. Difere do PCR convencional por ser em tempo real. É capaz de amplificar o DNA de micobactérias vivas e mortas.  
(b) PVHA com sintomas sugestivos de TB pulmonar e/ou extrapulmonar seguindo os critérios para solicitação do LF-LAM.  
(c) O ADA é considerado um exame auxiliar no diagnóstico da TB pleural. Baseia-se na determinação da atividade da adenosina-deaminase.  
Para excluir ou identificar outros diagnósticos diferenciais, recomenda-se solicitar na(s) amostra(s) coletada(s):  
- Exame direto e cultura para fungos;  
- Cultura para outras micobactérias;  
- - Exame histopatológico <u>de amostras de tecido.</u>  
**3.2.3. Infecção latente pelo Mycobacterium tuberculosis**  
As PVHA estão entre os grupos de maior risco para adoecimento por TB<sup>1,2</sup> . Em PVHA, a instituição do tratamento da ILTB reduz o risco da progressão para a doença<sup>10</sup> . **O tratamento da ILTB reduz significativamente o risco, nos anos seguintes, de desenvolvimento de tuberculose em PVHA com PT positiva ou IGRA positivo**<sup>11,12</sup> . O tratamento da ILTB associado à TARV é o cenário de maior benefício para a proteção.  
A ILTB pode ser identificada por meio da realização da PT, mediante a inoculação do derivado proteico purificado (PPD). A PT é considerada positiva se o resultado da leitura for igual ou maior que 5 mm.  
Outro método para detecção de ILTB é a realização do teste de liberação interferon-gama (do inglês _interferon gamma release assay_ - IGRA) IGRA, que faz a detecção de interferon-gama liberado pelas células T após exposição aos antígenos do _M. tuberculosis_ in vitro. O resultado pode ser reagente, não reagente ou indeterminado e está indicado para PVHA com contagem de LT-CD4 acima de 350 células/mm³, assim como a realização da PT.  
As indicações para tratamento da ILTB, após exclusão de tuberculose ativa, estão resumidas no **Quadro 2** . Pessoas com histórico prévio de tuberculose e de tratamento para ILTB não necessitam novo tratamento, exceto quando identificada nova exposição de risco, como ser contato de pessoa com TB ativa. Nessa situação não há necessidade de realizar a PT ou o IGRA, afastada a TB ativa, realizar o tratamento da ILTB.  
**Quadro 2:** Indicação de tratamento para ILTB em PVHA  
Contatos de TB pulmonar com confirmação laboratorial.  
Contagem de células CD4+ menor ou igual a 350 células/mm<sup>3</sup> Registro documental de ter tido PT igual ou maior que 5 mm ou IGRA positivo e não submetido ao tratamento da ILTB na ocasião  
Radiografia de tórax com cicatriz radiológica de TB, sem tratamento anterior para TB  
PT maior ou igual a 5 mm ou IGRA positivo em PVHA com contagem de LT-CD4+ maior que 350 células/mm<sup>3</sup>  
Fonte: CGTM/SVSA/MS.  
Os dois testes não fazem distinção entre a forma ativa e a forma latente da tuberculose, assim como um resultado negativo (IGRA negativo e PT menor que 5 mm) não exclui doença ativa.  
Todas as PVHA com contagem de LT-CD4+ menor ou igual a 350 célular/mm<sup>3</sup> tem indicação de tratamento para ILTB, sem necessidade da realização de PT ou IGRA.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os esquemas disponíveis para tratamento da ILTB são:  
- Isoniazida + rifapentina (3HP)<sup>1</sup>  
- Isoniazida (H)<sup>2</sup>  
- Rifampicina (4R)<sup>1</sup>  
Quando comparado aos demais esquemas para tratamento disponíveis no SUS, a isoniazida + rifapentina (3HP) possui melhor comodidade posológica para o paciente, por ser utilizado em doses semanais durante 3 meses (12 doses), o que favorece a adesão ao tratamento.  
**Considerando essas vantagens e a disponibilidade do tratamento, o esquema isoniazida + rifapentina (3HP) é o esquema preferencial para tratar a ILTB**<sup>13</sup> .  
O **Quadro 3** reúne as orientações para o tratamento da ILTB.  
**Quadro 3:** Esquemas de tratamento da ILTB disponíveis no SUS  
|**Características**|**Esquemas de tratamento**<br>**6H**<sup>**1**</sup><br>**9H**<sup>**1**</sup>|**3HP**<sup>**1**</sup>|**4R**<sup>**1**</sup>|
|---|---|---|---|
|**Medicamentos**|**Isoniazida (H)**<sup>**2**</sup>|**Isoniazida**<br>**(H)**<br>**+**<br>**Rifapentina (P)**<sup>**2**</sup>|**Rifampicina (R)**<sup>**2**</sup>|
|**Tempo**<br>**de**<br>**tratamento**|6 meses<br>9 meses|3 meses|4 meses|
|**Número de doses**|180<br>doses<br>diárias entre 6<br>a9meses<br>270<br>doses<br>diárias entre 9<br>a 12 meses<sup>3</sup>|12<br>doses<br>semanais<br>entre 12 a 15 semanas|120 doses diárias entre<br>4 a 6 meses|
|**Posologia**|5 a 10 mg/kg de peso até a dose<br>máxima de 300 mg/dia<sup>2</sup>.|**Em adultos (a partir**<br>**de 30 kg):**<br>-<br>Isoniazida: 900<br>mg/semana<br>-<br>Rifapentina: 900<br>mg/semana|**Em adultos:**<br>10 mg/kg de peso, até<br>a dose máxima de 600<br>mg/dia|
|**Indicação**|Todas as indicações da ILTB,<br>exceto efeitos adversos graves<br>com isoniazida, contatos de<br>monorresistentes à isoniazida,<br>hepatopatas e pessoas acima de<br>50 anos.|Todas as indicações<br>da ILTB, incluindo<br>PVHA (ver interações<br>com antirretrovirais),<br>sob tratamento<br>diretamente observado<br>(TDO) durante todo o<br>tratamento ou com<br>tratamento<br>autoadministrado<br>sendo organizadas<br>estratégias de adesão<sup>4</sup>.<br>Não utilizar em<br>contatos de pessoas<br>com TB<br>monoressistência à<br>isoniazida ou à<br>rifampicina e<br>intolerância à<br>isoniazida.|Indivíduos com mais<br>de<br>50<br>anos**,**<br>hepatopatas, contatos<br>de pessoas com TB<br>monorresistente<br>à<br>isoniazida<br>e<br>intolerância<br>à<br>isoniazida.|
|**Uso**<br>**em**<br>**gestantes**<sup>**5**</sup>|Pode ser usada com segurança<br>nagestação,incluirdurantetodo|Não recomendada a<br>sua<br>utilização<br>na|Pode ser usado com<br>segurança nagestação.|  
|**Características**|**Esquemas de tratamento**<br><br>|||
|---|---|---|---|
||**6H**<sup>**1**</sup><br>**9H**<sup>**1**</sup>|**3HP**<sup>**1**</sup>|**4R**<sup>**1**</sup>|
||o tratamento o uso de piridoxina<br>(Vit B6)entre 50 a 100 mg/dia.|gestação por falta de<br>estudos comgestantes.||
|**Interações com**<br>**antirretrovirais**|Sem<br>interações<br>importantes,<br>usar na dose habitual.|Contraindicado o uso<br>com<br>inibidores<br>de<br>protease<br>(IP),<br>nevirapina e tenofovir<br>alafenamida.<br>Pode ser usado com<br>Tenofovir,<br>efavirenz,<br>dolutegravir<br>e<br>raltegravir<br>sem<br>necessidade de ajuste<br>dadose.|Contraindicada<br>com<br>IP,<br>nevirapina<br>e<br>tenofovir alafenamida.<br>Pode ser usada com<br>dolutegravir<br>e<br>raltegravir com ajuste<br>da dose<sup>6</sup>.|
|**Reações**<br>**adversas**<br>**mais**<br>**frequentes**|Hepatotoxicidade,<br>neuropatia<br>periférica, rash cutâneo, náuseas|Reações<br>de<br>hipersensibilidade,<br>hepatotoxicidade<br>(menos<br>frequente),<br>cefaleia, rash cutâneo,<br>náuseas,<br>coloração<br>avermelhada de suor,<br>urina e lágrima.|Reações<br>de<br>hipersensibilidade,<br>hepatoxicidade (menos<br>frequente),<br>plaquetopenia,<br>rash<br>cutâneo,<br>náuseas,<br>coloração avermelhada<br>de<br>suor,<br>urina<br>e<br>lágrima.|  
Fonte: CGTM/SVSA/MS  
1- 6H: 6 meses de isoniazida; 9H: 9 meses de isoniazida; 3HP: 3 meses de rifapentina mais isoniazida; 4R: 4 meses de rifampicina.  
2- Isoniazida (H): disponível em comprimidos de 100 e 300 mg (uso restrito); Rifampicina (R): disponível 300 mg em cápsula; Rifapentina (P): disponível comprimido 150 mg.  
3- O esquema com 270 doses possui melhor eficácia quando comparado com o esquema 180 doses  
4- Quando em tratamento autoadministrado, utilizar alternativas para estimular e monitorar a adesão ao tratamento, como ligações telefônicas, mensagens de celular, chamadas de vídeo, contagem dos comprimidos ao retorno às consultas e quando possível, o apoio de familiares. Nessa situação, preferir consultas mensais para avaliação.  
5- Ver indicações para o tratamento da ILTB em gestantes no Manual de Recomendações para o Controle da Tuberculose no Brasil (2ª edição atualizada, 2019).  
6- Ajuste da dose: dolutegravir 50 mg de 12/12h; raltegravir 800 mg de 12/12h. Considera-se abandono de tratamento nas seguintes situações:  
- Rifampicina - dois meses, consecutivos ou não, sem uso do medicamento ou;  
- Isoniazida - três meses, consecutivos ou não, sem uso do medicamento ou;  
- 3HP (rifapentina + isoniazida) - perda de três doses semanais, consecutivas ou não.  
**Vale salientar que o mais importante é o número de doses e não somente o tempo de tratamento** .  
**3.4. Tratamento da coinfecção TB-HIV**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O tratamento da TB em PVHA é semelhante ao recomendado para a população geral, embora a taxa de falha terapêutica, resistência aos fármacos e recidiva da TB sejam maiores nas PVHA<sup>3</sup> .  
O esquema preconizado consiste na utilização de RHZE – rifampicina (R), isoniazida (H), pirazinamida (Z) e etambutol – em formulações com doses fixas combinadas (4 em 1) por dois meses (fase intensiva), seguidos de quatro meses de rifampicina e isoniazida também em doses fixas combinadas (2 em 1), totalizando seis meses de tratamento ( **Quadro 4** ).  
Recomenda-se extensão para 12 meses de tratamento nos casos de comprometimento do SNC e TB osteoarticular, sendo 2 meses da fase intensiva e 10 meses da fase de manutenção.  
**Quadro 4:** Esquema básico para tratamento da TB em adultos  
|**FASES**<br>**DO**<br>**TRATAMENTO**|**MEDICAMENTOS**|**FAIXA DE PESO**|**UNIDADE/DO**|**SE**|**MESES**|
|---|---|---|---|---|---|
||RHZE|20a35kg|2comprimidos|||
|**Intensiva**|150/75/400/275 mg|36 a 50 kg|3 comprimidos||2|
|**(2RHZE)**<sup>**(a)**</sup>|Comprimido em dose<br>|51 a 70 kg|4 comprimidos|||
||fixa combinada|Acima de 70 kg|5 comprimidos|||
|||20 a 35 kg|1<br>comprimid<br>300/150<br>mg<br>comprimidos de<br>mg|o<br>de<br>ou<br>2<br>150/75||
|**Manutenção**<br>**(4RH)**<sup>**(b)**</sup>|RH 300/150 mg ou<br>150/75 mg<br>Comprimido em dose<br>fixa combinada|36 a 50 kg<br>51 a 70 kg|1<br>comprimid<br>300/150<br>mg<br>comprimido de<br>mg ou 3 de comp<br>de150/75mg<br>2<br>comprimid<br>300/150<br>mg<br>comprimidos de<br>mg|o<br>de<br>+<br>1<br>150/75<br>rimidos<br>os<br>de<br>ou<br>4<br>150/75|4|
|||Acima de 70 kg|2<br>comprimid<br>300/150<br>mg<br>comprimido de<br>mg ou 5 compri<br>150/75 mg|os<br>de<br>+<br>1<br>150/75<br>midos de||  
Fonte: CGTM/SVSA/MS.  
(a) RHZE: combinação de rifampicina (R), isoniazida (H), pirazinamida (Z) e etambutol (E).  
(b) RH: combinação de rifampicina (R) e isoniazida (H).  
O **Quadro 5** descreve os esquemas de tratamento da TB meningoencefálica.  
**Quadro 5:** Esquema para tratamento da TB meningoencefálica e osteoarticular em adultos  
|**FASES DO**<br>**TRATAMENTO**|**MEDICAMENTOS**|**FAIXA DE**<br>**PESO**|**UNIDADE/DOSE**|**MESES**|
|---|---|---|---|---|
||RHZE|20a35kg<br>|2comprimidos<br>||
|**Intensiva**<br>|150/75/400/275 mg|36 a 50 kg|3 comprimidos|2|
|**(2RHZE)**<sup>**(a)**</sup>|Comprimido em dose<br>|51 a 70 kg|4 comprimidos||
||fixa combinada|Acima de 70 kg|5 comprimidos||
|||20 a 35 kg|1 comprimido 300/150<br>mg ou 2 comprimidos<br>de150/75mg||
||RH 300/150 mg ou<br>|36 a 50 kg|1<br>comprimido<br>de<br>300/150<br>mg<br>+<br>1<br>comprimido de 150/75<br>mg ou 3 comprimidos<br>de150/75mg||
|**Manutenção**<br>**(10RH)**<sup>**(b)**</sup>|150/75 mg<br>Comprimido em dose<br>fixa combinada|51 a 70 kg|2<br>comprimidos<br>de<br>300/150<br>mg<br>ou<br>4<br>comprimidos<br>de<br>150/75 mg|10|
|||Acima de 70 kg|2<br>comprimidos<br>de<br>300/75<br>mg<br>+<br>1<br>comprimido de 150/75<br>mg ou 5 comprimidos<br>de 150/75 mg||  
Nos casos de meningoencefalite:  
• Associar corticoide: prednisona (1 a 2 mg/kg/dia) por quatro semanas ou, nos casos graves de meningite tuberculosa, dexametasona injetável (0,3 a 0,4 mg/kg/dia), por quatro a oito semanas, com redução gradual da dose nas quatro semanas subsequentes.  
• Para evitar sequelas, recomenda-se que seja iniciada a fisioterapia, em casos de meningite tuberculose, o mais cedo possível  
Fonte: CGTM/SVSA/MS.  
(a) RHZE: combinação de rifampicina (R), isoniazida (H), pirazinamida (Z) e etambutol (E).  
(b) RH: combinação de rifampicina (R) e isoniazida (H).  
A **rifampicina** é o principal medicamento para o tratamento da TB e sua utilização deve ser priorizada.  
A rifampicina possui eficácia comprovada e extensa experiência de uso no tratamento da TB, devendo fazer parte do esquema preferencial de tratamento para TB. Além disso, permite a utilização da formulação com doses fixas combinadas (RHZE e RH), otimizando a adesão.  
A rifabutina está recomendada em substituição à rifampicina quando é necessário associar ou manter o IP + RTV no esquema antirretroviral. A rifabutina é menos ativa que a rifampicina na indução do sistema enzimático P-450 CYP3A e, por esse motivo, parece exercer menor redução dos níveis séricos dos ARV. Contudo, os ARV podem ocasionar oscilação nos níveis séricos da rifabutina, aumentando o risco de toxicidade ou, no caso de baixa adesão à TARV, redução dos níveis da rifabutina, o que pode levar a resistência a rifamicinas. O uso da rifabutina não permite doses fixas combinadas. **A dose da rifabutina é de 150 mg/dia** .  
**O uso da rifabutina em associação com IP deverá ser indicado apenas quando existir contraindicação a demais esquemas de ARV que permitem o uso da rifampicina.**  
O uso da rifabutina não permite a utilização dos comprimidos em doses fixas combinadas para tratamento da TB.  
O **Quadro 6** descreve o esquema com rifabutina.  
**Quadro 6** : Esquema com rifabutina para tratamento de adultos  
|**Fases**<br>**do**|||**Dose (mg/**<br>|**dia) para c**<br>|**ada faixa d**<br>|**e peso (kg**<br>|**)**<br>|
|---|---|---|---|---|---|---|---|
|<br> <br>**tratamento**|**Medicamento**|**Dose**|**30 a 35**<br>**kg**|**36 a 45**<br>**kg**|**46 a 55**<br>**kg**|**56 a 70**<br>**kg**|**Acima de**<br>**70 kg**|
||Rifabutina|2,5<br>a<br>5<br>mg/kg|150|150|150|150|150|
|Fase de<br>t|Isoniazida|4<br>a<br>6<br>mg/kg/dia|150|200|300|300|300|
|aaque<br>(2 meses)|Pirazinamida|20<br>a<br>30<br>mg/kg/dia|1000|1000|1000 a<br>1500|1500|2000|
||Etambutol|15<br>a<br>25<br>mg/kg/dia|800|800|800 a<br>1200|1200|1200|
|Fase de<br>tã|Rifabutina|2,5<br>a<br>5<br>mg/kg|150|150|150|150|150|
|manuenço<br>(4 meses)|Isoniazida|4<br>a<br>6<br>mg/kg/dia|150|200|300|300|300|  
Fonte: CGTM/SVSA/MS  
Na indisponibilidade da rifabutina, deve-se substituir por levofloxacino e estender a fase de manutenção até completar doze meses de tratamento. Sendo 2 meses de levofloxacino, isoniazida, etambutol e pirazinamida seguidos de 10 meses de levofloxacino, isoniazida e etambutol.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A TARV é recomendada a todos as pessoas com TB-HIV, independentemente da forma clínica de apresentação da TB.  
O melhor momento para o início da TARV, em pessoas coinfectadas por TB-HIV, foi avaliado por ensaios clínicos multicêntricos e uma recente revisão sistemática.  
Recomenda-se o início da terapia antirretroviral em **ATÉ** sete dias após o início do tratamento para TB, independentemente da contagem de LT-CD4.  
Revisão sistemática recente<sup>14</sup> mostrou que a introdução rápida da TARV reduz a mortalidade em PVHA com contagem de CD4 menor ou igual a 50 células/mm<sup>3</sup> . Os resultados mostraram que a síndrome inflamatória da reconstituição imune (SIRI) foi mais frequente nessas pessoas, porém a mortalidade relacionada a SIRI não foi comum.  
Nos casos de meningite tuberculosa, recomenda-se que o início da TARV ocorra, preferencialmente, entre a 4ª e a 6ª semana do início do tratamento para a tuberculose  
Podem-se encontrar três cenários na coinfecção TB-HIV:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Nesse cenário, há indicação de tratamento da TB e ARV. O tratamento para tuberculose deverá ser instituído imediatamente e o tratamento ARV deve ser instituído em até uma semana para PVHA sem evidência de meningite tuberculosa.  
Nos casos de meningite tuberculosa, o início da TARV deve ocorrer, usualmente, após a 4ª semana de tratamento para a tuberculose. Em locais que disponham de especialistas e acompanhamento frequente para avaliação de eventos adversos e SIRI, a introdução da TARV pode ser mais precoce, principalmente nas PVHA com CD4 <50 células/mm<sup>3</sup> . Por outro lado, locais com dificuldade para acessar serviços e profissionais especializados, o tempo pode ser estendido. (Informações complementares estão disponíveis no Módulo 1 do PCDT).  
- **II. Pessoas em que inicialmente se realiza o diagnóstico da TB e, durante o tratamento, ocorre o diagnóstico do HIV:**  
No **cenário II** , os pacientes têm indicação de início **da TARV semelhante ao do cenário**  
- **I.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
No **cenário III** , os pacientes devem **iniciar imediatamente o tratamento para TB** . Entretanto, é importante avaliar a TARV em uso quanto à compatibilidade (interações medicamentosas) com os medicamentos da TB. Se necessário, a substituição de ARV deve ser realizada para garantir o tratamento da TB e a manutenção de esquema antirretroviral eficaz.  
Os benefícios do início precoce da TARV superam o risco da SIRI. O receio da ocorrência da SIRI não deve retardar o início da TARV.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O dolutegravir associado a tenofovir/lamivudina é a opção preferencial para o tratamento para pessoas com TB-HIV. Devido à interação com rifampicina, a dose de dolutegravir deve ser aumentada para 50 mg 12/12h, em razão do efeito de indução no metalismo. Somente após duas semanas do término do tratamento da tuberculose (rifampicina), a dose única habitual pode ser retomada.  
A genotipagem pré-tratamento está indicada para as pessoas vivendo com TB e HIV (virgem de TARV) de forma a orientar o esquema terapêutico. Contudo, ressalta-se que o início da TARV não deve ser adiado pela não obtenção do resultado desse exame.  
Os esquemas de TARV inicial preferencial para pessoas coinfectadas TB-HIV estão descritos no **Quadro 7** .  
**Quadro 7:** Esquemas de TARV inicial preferencial para pessoas coinfectadas TB-HIV  
|**SITUAÇÃO**|**TARV**|**DOSE DIÁRIA**|**OBSERVAÇÃO**|
|---|---|---|---|  
|Coinfecção TB-HIV<br><br>Preferencial|Tenofovir<sup>(a)</sup>/<br>lamivudina<br>+<br>dolutegravir|(300 mg/300 mg)<br>“2 x 1” 1x/dia<br>+<br>dolutegravir 50 mg<br>12/12h|Após o término do tratamento<br>para TB, continuar por mais 15<br>dias com a dose de dolutegravir<br>duas vezes ao dia|
|---|---|---|---|
|Coinfecção<br>TB-<br>HIV<sup>(a)</sup><br><br>Alternativo|Tenofovir<sup>(a)</sup><br>/<br>lamivudina<br>/<br>efavirenz<sup>(b)</sup>|(300 mg / 300 mg +<br>600 mg) 1x/dia|Após o término do tratamento<br>para TB, deverá ser avaliada a<br>troca<br>de<br>efavirenz<br>para<br>dolutegravir|  
Fonte: DATHI/SVSA/MS.  
(a) Tenofovir é contraindicado como terapia inicial em pacientes com disfunção renal pré-existente, TFGe abaixo de 60 mL/minuto ou insuficiência renal. Usar com precaução em pacientes com osteoporose/osteopenia, hipertensão arterial sistêmica e diabetes melito não controladas. Se usado, ajustar dose quando TFGe estiver abaixo de 50 mL/min.  
(b) Realizar exame de genotipagem pré-tratamento e iniciar TARV, de forma a orientar o esquema terapêutico  
O esquema de TARV composto por raltegravir associado a tenofovir/lamivudina é uma opção alternativa de tratamento para pessoas com TB-HIV. O raltegravir apresenta menor interação medicamentosa com a rifampicina. A dose de raltegravir recomendada para o uso concomitante com a rifampicina é 400 mg, duas vezes ao dia<sup>15,16</sup> .  
Nos casos de pacientes em falha de tratamento com dolutegravir e as PVHA com resistência no gene da integrase, um IP + RTV em geral é necessário para compor um esquema de resgate eficaz. Este deve ser baseado no histórico de ARV, nos testes de genotipagem e nos princípios de resgate. A inclusão de um IP + RTV contraindica o uso de rifampicina, que deve ser substituída por rifabutina ( **Quadro 6** ).  
O **Quadro 8** descreve as opções de TARV para pessoas com coinfecção TB-HIV em tratamento para TB.  
**Quadro 8:** Opções de esquema de ARV para pessoas coinfectadas com TB-HIV em tratamento para TB  
|**SITUAÇÃO**|**RECOMENDAÇÃO**|
|---|---|
|PVHA com TB, virgem de<br>tratamento para HIV|Iniciar tratamento para TB com RHZE e iniciar TARV, em ordem de<br>prioridade:<br>1. Tenofovir<sup>(a)</sup>/lamivudina + dolutegravir 12/12h (preferencial)<br>2. Tenofovir<sup>(a)</sup>/lamivudina/efavirenz(segenotipagempré tratamento)|
|PVHA com TB, em TARV|Iniciar tratamento para TB com RHZE e, caso necessário, adequar<br>TARV individualizando a avaliação. Considerar histórico de uso de<br>ARV,<br>toxicidades,<br>contraindicações,<br>falhas<br>virológicas<br>e<br>genotipagens prévias (se disponíveis)<sup>(b)</sup>|
|PVHA com TB, em perda<br>de seguimento|Tenofovir<sup>(a)</sup>/lamivudina + dolutegravir 12/12h|
|Presença<br>de<br>reações<br>adversas graves, falha ao<br>tratamento para TB ou<br>medicamento resistente à<br>TB|Encaminhar aos serviços de referência em TB, para avaliação por<br>especialista e uso de esquemas especiais. Deverá haver um<br>seguimento cooperado entre as equipes de atenção à PVHA|  
Fonte: DATHI/SVSA/MS.  
(a) Em caso de contraindicação ao tenofovir, ver item Como iniciar.  
(b) IP + RTV não é recomendado em PVHA em uso de rifampicina. Nos casos de necessidade de uso de IP + RTV, manter IP + RTV na dose habitual e substituir a rifampicina pela rifabutina.  
PVHA em interrupção de tratamento de tratamento, que retornam para acompanhamento e PVHA em falha virológica que apresentam coinfecção com tuberculose devem seguir as recomendações abordadas no Módulo 1 do PCDT para manejo do HIV.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A SIRI pode ocorrer em pessoas com coinfecção TB-HIV que iniciam TARV. É um evento relativamente comum, podendo estar presente entre 8% e 43% dos casos no início da TARV<sup>17</sup> .  
Pode ocorrer por resposta paradoxal ou desmascaramento, levando a uma resposta inflamatória exacerbada, a qual estimula a formação de granulomas, resultando em agravamento de lesões pré-existentes ou aparecimento de novos sinais, sintomas ou achados radiológicos de novas lesões, tais como linfadenomegalias com sinais flogísticos, que podem evoluir para fistulização e compressão de estruturas nobres ou levar à perfuração de órgãos (como o intestino). Esse fenômeno ocorre em resposta a antígenos micobacterianos e não caracteriza falha no tratamento da TB nem no da TARV<sup>18–21</sup> .  
O diagnóstico de SIRI pressupõe a exclusão de fatores como: resistência aos medicamentos para tratamento da TB, baixa adesão ao tratamento e outros diagnósticos diferenciais definidores de aids.  
O tratamento da SIRI é feito com corticoterapia nos casos moderados a graves. A dose de prednisona mais frequentemente utilizada é de 1 a 2 mg/kg dia, por um período de duas semanas, seguida de uma redução de 0,75 mg/kg/dia por mais duas semanas<sup>22,23</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O início concomitante do tratamento da TB e da TARV continua sendo contraindicado, uma vez que pode aumentar o risco de intolerância e toxicidade, dificultando a identificação de medicamentos envolvidos e piorando a adesão.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O tratamento concomitante para TB e HIV apresenta aspectos peculiares, em decorrência do grande número de medicamentos e da sobreposição dos efeitos adversos. O **Quadro 9** descreve as principais reações adversas associadas ao tratamento de TB e ARV.  
**Quadro 9:** Principais reações adversas associadas ao tratamento de TB e ARV  
|**REAÇÕES**<br>**ADVERSAS**|**TARV**|**TB**|**OBSERVAÇÕES**|
|---|---|---|---|
|**Confusão**<br>**mental,**<br>**insônia, pesadelos,**<br>**tonturas**|Efavirenz|Terizidona,<br>isoniazida,<br>etionamida<br>e<br>fluoroquinolonas|Sintomas transitórios (2-<br>3 semanas); se não<br>houver<br>melhora,<br>considerar a substituição<br>demedicamentos|
|**Depressão**|Efavirenz|Terizidona,<br>fluoroquinolonas,|Avaliar a influência de<br>circunstâncias<br>socioeconômicas;|  
|**REAÇÕES**<br>**ADVERSAS**|**TARV**|**TB**|**OBSERVAÇÕES**|
|---|---|---|---|
|||etionamida,<br>isoniazida|antidepressivos; reduzir<br>a<br>dosagem<br>de<br>medicamentos;<br>se<br>possível,<br>avaliar<br>a<br>substituição<br>de<br>medicamentos|
|**Cefaleia**|Zidovudina,<br>Efavirenz,<br>Atazanavir<br>+<br>Ritonavir,<br>Lopinavir/ritonavir,<br>Tipranavir,<br>Raltegravir|Terizidona,<br>fluoroquinolonas|Diagnóstico diferencial<br>com<br>outras<br>doenças<br>infecciosas;<br>sintomáticos;<br>autolimitada|
|**Náuseas e vômitos**|Atazanavir<br>+<br>Ritonavir,<br>Darunavir<br>+<br>ritonavir,<br>Raltegravir|Etionamida, ácido<br>paraminossalissílic<br>o<br>(PAS),<br>fluoroquinolonas,<br>pirazinamida,<br>isoniazida e outros|Hidratação;<br>sintomáticos;<br>a<br>necessidade de retirada<br>do<br>medicamento<br>é<br>incomum;<br>avaliar<br>a<br>função hepática|
|**Dor abdominal**|Todos|Clofazimina,<br>etionamida, PAS|Avaliar<br>pancreatite,<br>hepatotoxicidade<br>e<br>acidoselática|
|**Hepatotoxicidade**|Efavirenz,<br>Atazanavir<br>+<br>Ritonavir,<br>Etravirina,<br>Darunavir<br>+<br>Ritonavir|Pirazinamida,<br>rifampicina,<br>isoniazida,<br>PAS,<br>etionamida,<br>fluoroquinolonas|Interrupção<br>até<br>a<br>resolução;<br>considerar<br>substituir<br>os<br>medicamentos<br>mais<br>hepatotóxicas|
|**Rash cutâneo**|Abacavir,<br>Efavirenz,<br>Atazanavir<br>+<br>Ritonavir,<br>Entravirina,<br>Enfuvirtida,<br>Maraviroque|Isoniazida,<br>rifampicina,<br>pirazinamida, ácido<br>paraminossalissílic<br>o<br>(PAS),<br>fluoroquinolonas e<br>outros|Suspender o esquema;<br>sintomáticos;<br>reintrodução do abacavir<br>sempre contraindicada|
|**Acidose lática**|Zidovudina,<br>Lamiduvina|Linezolida|Suspender<br>os<br>medicamentos|
|**Nefrotoxicidade**|Tenofovir|Aminoglicosídeos|Suspender<br>os<br>medicamentos; reajustar<br>as doses dos demais de<br>acordo com o_clearance_<br>de creatinina|
|**Mielodepressão**|Zidovudina|Linezolida,<br>rifampicina (rara),<br>isoniazida (rara)|Suspender<br>os<br>medicamentos<br>mais<br>agressivos (zidovudina e<br>linezolida);<br>monitorar<br>hemograma|  
Fonte: DATHI/SVSA/MS.  
Para mais informações referente ao tratamento, manejo de eventos adversos e acompanhamento dos pacientes com tuberculose consultar o **<u>MANUAL DE RECOMENDAÇÕES PARA O CONTROLE DA TUBERCULOSE NO BRASIL, vigente do MS.</u>**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A coinfecção HIV-vírus da hepatite C (HCV) foi responsável por 8,3% (17.788) dos casos notificados de HCV entre os anos de 2007 a 2021, observando redução no percentual de coinfecção ao longo do período, sendo de 7,6% em 2021<sup>24</sup> .  
As principais formas de transmissão do HCV são<sup>25–32</sup> :  
- <u>Via parenteral:</u>  
- Compartilhamento de agulhas, seringas  
- Falha na esterilização de equipamentos  
- Reutilização de materiais  
- Sangue e derivados  
- <u>Transmissão sexual (sem uso de preservativo): mais comumente observada entre homens</u> que fazem sexo com homens (HSH), especialmente naqueles com HIV.  
**Todas as PVHA que iniciam o tratamento devem ser testadas para hepatite C e a triagem deve ser anual ou com intervalos menores nos casos em que há exposição de risco.**  
Pessoas coinfectadas com HCV-HIV devem ser vacinadas contra hepatite A e B, se suscetíveis a essas doenças, considerando os ajustes de doses e a realização da sorologia pósvacinação para hepatite B.  
Paciente com histórico de tratamento para HCV com resposta virológica sustentada (RVS) devem ser monitorados por meio da avaliação das transaminases (ALT e AST). Nos casos em que há exposição sexual desprotegida, outra vulnerabilidade para a aquisição de hepatite C ou alteração laboratorial, recomenda-se avaliação anual de reinfecção e coleta de HCV-RNA<sup>33</sup> .  
O tratamento da infecção pelo vírus da hepatite C está em rápida evolução. Os dados sugerem que os pacientes coinfectados com HIV-HCV tratados com os novos esquemas de medicamentos orais têm taxas de RVS comparáveis às dos pacientes monoinfectados com HCV 4,34.  
As atuais alternativas terapêuticas disponíveis para o tratamento da hepatite C apresentam alta efetividade terapêutica e são comparáveis entre si em situações clínicas semelhantes. Apenas algumas características as diferenciam, tais como: indicações para determinadas populações, diferenças inerentes à comodidade posológica e o preço praticado pelas indústrias fabricantes.  
São priorizadas alternativas com menor impacto financeiro ao sistema, sem deixar de garantir o acesso a terapias seguras e eficazes às pessoas com hepatite C.  
O tratamento da hepatite C crônica está indicado a todos os pacientes adultos coinfectados pelo HIV, independentemente <u>da contagem de LT-CD4+ ou do grau de fibrose hepática.</u>  
**Para a escolha dos medicamentos para tratamento e retratamento da hepatite C em PVHA, consultar as orientações técnicas vigentes acerca das tecnologias disponíveis no SUS - https://www.gov.br/aids/pt-br/centrais-de-conteudo** <u>.</u>  
É aconselhável iniciar primeiramente o tratamento para o HIV e atingir a supressão virológica antes de iniciar o tratamento da hepatite C, principalmente nas PVHA com contagem de CD4 abaixo de 200 células/mm<sup>3 33,35,36</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Todas as PVHA devem ser triadas para infecção pelo vírus da Hepatite B (HBV) e vacinadas se susceptíveis a essa infecção. Portadores de coinfecção HIV-HBV devem ser orientados a evitar o consumo de álcool e outras substâncias hepatotóxicas. Pacientes portadores de coinfecção HIV-HBV que sejam susceptíveis à infecção pelo vírus da hepatite A (HAV) devem ser vacinados.  
A coinfecção pelo HIV tem um profundo impacto no curso da infecção pelo HBV, influenciando na história natural da doença. Há uma progressão mais rápida para cirrose e carcinoma hepatocelular (CHC), maior mortalidade relacionada à doença hepática e pior resposta ao tratamento em comparação com pessoas vivendo com HBV não infectadas pelo HIV<sup>4,36</sup> .  
Em pacientes coinfectados, o HIV aumenta a replicação do HBV, levando à forma mais grave de doença hepática. Uma vez portador do HBV, o indivíduo tende a evoluir com menores taxas de soroconversão espontânea do HBeAg/anti-HBe e HBsAg/anti-HBs, além de apresentar altas taxas de replicação viral<sup>37–39</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O tenofovir é um ARV com atividade contra o HIV e contra o HBV, diminuindo o risco de progressão para cirrose e CHC.  
Pacientes portadores de coinfecção HIV-HBV devem ter sua TARV estruturada com tenofovir.  
Se houver contraindicação para o uso de tenofovir, pode-se fazer uso do tenofovir alafenamida ou entecavir. Ressalta-se que o entecavir não deve ser considerado parte do esquema de TARV, devendo a substituição do tenofovir ser feita por ARV com atividade supressiva plena contra o HIV.  
**Para mais informações consultar o PCDT de Hepatite B e coinfecções vigente.**  
Nos casos de modificação de TARV por falha virológica ao HIV, o tenofovir deverá ser mantido como tratamento contra o HBV, em combinação com outros ARV com atividade adequada à supressão viral do HIV.  
A descontinuação de agentes com atividade anti-HBV pode causar dano hepatocelular grave, resultante da reativação do HBV. Deve-se aconselhar os pacientes a não interromper esses medicamentos e monitorá-los cuidadosamente durante eventuais interrupções da TARV e do tratamento do HBV<sup>40</sup> .  
Alguns ARV podem aumentar os níveis de transaminases. Os valores e a magnitude desses aumentos são maiores na coinfecção HIV-HBV do que na monoinfecção pelo HIV<sup>41–43</sup> .  
A etiologia e as consequências dessas alterações nos testes de função hepática não são claras, uma vez que essas mudanças podem se resolver com a continuidade da TARV. No entanto, sugere-se suspender o medicamento suspeito pela alteração em caso de aumento do nível sérico da ALT acima de 5 a 10 vezes o limite superior da normalidade. Contudo, a elevação dos níveis séricos das transaminases em pessoas coinfectadas com HIV/HBV pode indicar soroconversão do HBeAg pela reconstituição imunológica. Assim, a causa das elevações deve ser investigada antes da interrupção dado medicamento.  
Pacientes coinfectados HIV/HBV podem evoluir com “HBV oculto”<sup>44</sup> , caracterizado por baixa carga viral (CV)-HBV e HBsAg não reagente, estando autorizada a realização semestral de exame para quantificação da CV-HBV para elucidação diagnóstica<sup>45</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A sífilis é uma infecção bacteriana de caráter sistêmico, causada pelo _Treponema pallidum_ , uma bactéria Gram-negativa do grupo das espiroquetas. É transmitida principalmente por via sexual ou vertical.  
Nos últimos anos, a sífilis vem apresentando tendência de crescimento na maioria dos países de renda média, como é o caso brasileiro<sup>46,47</sup> .  
A prevalência de sífilis é maior entre as PVHA que entre as pessoas negativas para o HIV e a coinfecção está associada com aumento no risco tanto da aquisição, quanto da transmissão do HIV. Úlceras genitais podem facilitar a transmissão sexual e perinatal do HIV. A quebra da integridade do epitélio mucoso ocasiona uma via de entrada para o vírus. Além disso, há um influxo local de LT-CD4+ e aumento da expressão de correceptores CCR5 em macrófagos, aumentando a probabilidade de aquisição do HIV<sup>48</sup> .  
A aquisição de sífilis e outras infecções sexualmente transmissíveis (IST) em PVHA confirma a vulnerabilidade e a falha na adesão às orientações de prevenção. Pessoas com comportamento sexual de alto risco muitas vezes têm acesso limitado aos cuidados de saúde, devido a questões econômicas e/ou estigmatização social<sup>49</sup> .  
Entre as PVHA, infecção pela sífilis pode apresentar espectro de sinais e sintomas amplo. Além disso, nesses casos, a coinfecção sífilis-HIV pode alterar a história natural do agravo, o diagnóstico e manejo<sup>50–54</sup> . A presença de _T. pallidum_ no organismo também acelera a evolução da infecção pelo HIV para a síndrome da imunodeficiência adquirida<sup>55</sup> .  
A infecção por sífilis está relacionada, independentemente da TARV, com aumento transitório da CV-HIV e redução da contagem de LT-CD4+. Portanto, caso a PVHA previamente estável apresente elevações súbitas da CV-HIV, deve-se considerar a infecção por sífilis no diagnóstico diferencial<sup>56–58</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Todas as PVHA com vida sexual ativa devem ser rastreadas a cada seis meses para sífilis. Em pessoas com prática sexual de risco (múltiplos parceiros, abuso de drogas lícitas ou ilícitas, parcerias anônimos e/ou desconhecidos, troca de sexo por dinheiro)<sup>56</sup> .  
O rastreamento deve ser realizado com o teste disponível no local e seguir os fluxogramas disponíveis no Manual técnico para diagnóstico da sífilis vigente<sup>59</sup> <u>.</u>  
O TR disponibilizado pelo Ministério da Saúde é do tipo treponêmico, os quais são os mais indicados para iniciar a investigação de sífilis, por serem os primeiros testes imunológicos a se tornarem reagentes. No entanto, para avaliar a atividade da doença, os testes treponêmicos são insuficientes, sendo necessária a complementação por meio de teste não treponêmico (ex: VDRL, RPR).  
EO diagnóstico de sífilis sinaliza a necessidade de avaliação para outras IST e hepatites virais.  
Os TR são práticos e de fácil execução, com leitura do resultado em, no máximo, 30 minutos. Podem ser realizados com amostras de sangue total colhidas por punção digital ou venosa. Têm a vantagem de serem realizados no momento da consulta, possibilitando tratamento imediato.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
As manifestações clínicas da sífilis nas PVHA são geralmente semelhantes às das pessoas sem infecção pelo HIV, com algumas particularidades que serão abordadas no **Quadro 10.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A úlcera genital da sífilis primária é tipicamente indolor, por vezes não é percebida, devido à localização de difícil visualização (como por exemplo: vagina, colo do útero, ânus, reto, cavidade oral). Essas características contribuem para a persistência da sua transmissão, pois é nos estágios mais precoces (sífilis primária e secundária) que se observa maior infectividade.  
A infecção pela sífilis é dividida em estágios baseados em achados clínicos, que orientam tanto o tratamento como o seguimento dos infectados.  
**Quadro 10:** Estágios clínicos da sífilis.  
|**Estágio**|**Duração**|**Manifestações clínicas**<sup>60–64</sup>|
|---|---|---|
|**Primária**|10 – 90 dias<br>(média 21<br>dias)|-<br>Cancro duro: nódulo indolor único no local do contato, que se<br>ulcera rapidamente. Pode ser observado na genitália, períneo, ânus, reto,<br>orofaringe, lábios, mãos;<br>-<br>A lesão é rica em treponemas<br>-<br>Particularidades em PVHA: Nódulos múltiplos ou atípicos;<br>eventual ausência de manifestação inicial|
|**Secundária**|<sup>6 a 8</sup><br>semanas|-<br>Sinais e sintomas sistêmicos: febre, perda ponderal, mialgia,<br>linfonodomegalia, mal-estar, adinamia;<br>-<br>Rash cutâneo: morfologia variada, pode ser disseminado,<br>acomete principalmente na palma das mãos e planta dos pés;<br>-<br>Condiloma plano ou condiloma lata: lesões pápulo-hipertróficas<br>nas mucosas ou pregas cutâneas;<br>-<br>Alopecias e madarose<br>-<br>Particularidades em PVHA: Progressão mais rápida e/ou extensa;<br>“Sífilis maligna” ou sífilis ulceronodular.|
||Recente<br>(até 1 ano)|-<br>Assintomática;<br>-<br>Podem ocorrer relapsos de lesões de secundarismo;|
|**Latente**|Tardia<br>(Maior que<br>1 ano)|-<br>Grande parte dos diagnósticos ocorre nesse estágio, observando<br>reatividade dos testes imunológicos que detectam anticorpos.|  
|**Estágio**|**Duração**|**Manifestações clínicas **<sup>60–64</sup>|
|---|---|---|
|**Terciária**|Mais que 1<br>ano até<br>décadas<br>após a|-<br>Neurossífilis: paresias,_tabes dorsalis_, perda de visão, perda<br>auditiva e alterações psiquiátricas.<br>-<br>Sífilis ocular;<br>-<br>Cardiovascular: dilatação aórtica, regurgitação aórtica, estenose<br>do óstio carotídeo;|
||infecção<br>primária|-<br>Goma sifilítica: tumorações (com tendência a liquefação) na pele,<br>mucosas, ossos ou qualquer tecido|
|||-<br>ParticularidadesPVHA: Uveíte oumeningite sãomais comuns|  
Fonte: DATHI/SVSA/MS  
Quando não há sinais e sintomas de sífilis (sem evidência de infecção primária, secundária ou terciária), o diagnóstico só pode ser realizado por testes imunológicos. Nesse caso, a sífilis passa a ser dividida pelo tempo de infecção:  
- Sífilis latente recente: menos de 1 ano de evolução;  
- Sífilis latente tardia: mais de um ano de evolução.  
**Diante de um indivíduo com diagnóstico confirmado de sífilis em que não seja possível inferir a duração da infecção, deve-se tratar o caso como sífilis latente tardia.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A neurossífilis ocorre em qualquer fase da sífilis, com diferentes apresentações clínicas. O _T. pallidum_ pode invadir precocemente o sistema nervoso central (SNC) e a neuroinvasão pode ser transitória. Os preditores da persistência do _T. pallidum_ no SNC e o início de sinais e sintomas clínicos não estão bem estabelecidos<sup>65</sup> .  
A **neurossífilis recente** é um estágio que coexiste com a infecção primária, secundária ou latente precoce ou até 1 – 2 anos após a infecção primária, com ou sem sintomas. A neurossífilis recente pode se apresentar como meningite assintomática ou sintomática. Os sintomas, podem se manifestar como meningite sifilítica (cefaleia, meningismo e/ou alteração de nervos cranianos, causando diminuição da acuidade visual e/ou auditiva) ou sífilis meningovascular (acidente vascular encefálico)<sup>66</sup> .  
A **neurossífilis tardia** afeta principalmente o parênquima do SNC e ocorre anos ou décadas após a infecção inicial.  
Os casos de “neurorrecaída”, que significa a apresentação de neurossífilis sintomática após tratamento de sífilis precoce, são mais relatados em pessoas coinfectadas com HIV.  
A investigação de sinais e sintomas neurológicos deve ser realizada em todas as PVHA coinfectadas com sífilis.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O diagnóstico da infecção pela sífilis exige uma correlação entre dados clínicos, resultados de testes laboratoriais, histórico de infecções passadas e investigação de exposição recente.  
Os testes laboratoriais utilizados para o diagnóstico da sífilis são divididos em duas categorias: exames diretos e testes imunológicos. No momento da escolha dos testes, é importante considerar não somente os testes disponíveis, mas também o provável estágio da sífilis a ser diagnosticado. Os testes imunológicos são os mais utilizados na prática clínica.  
O **Quadro 11** apresenta os principais testes laboratoriais empregados no diagnóstico da infecção por sífilis e suas categorias.  
**Quadro 11** : Principais testes laboratoriais empregados no diagnóstico da infecção por  
sífilis  
||Microscopia<br>em<br>campo escuro|-<br>Recomendado<br>para<br>estágios<br>clínicos sintomáticos (sífilis primária e|
|---|---|---|
|**Exames diretos**|Pesquisa direta com<br>material corado|secundária).<br>-<br>Não recomendado para lesões de<br>cavidade oral.|
||VDRL|-<br>Detectam<br>anticorpos|
||RPR|anticardiolipina, que não são específicos|
|**Não**|TRUST|para os antígenos do_T. pallidum._|
|<br>**treponêmicos**|USR|-<br>Quantificáveis (ex.: 1:2, 1:4, 1:8).<br>-<br>Importantes para o diagnóstico e<br>monitoramento<br>da<br>resposta<br>ao<br>tratamento.|
||Teste rápido|-<br>Detectam anticorpos específicos|
|**Testes**<br>|FTA-Abs|para os antígenos do_T. pallidum._|
|**imunológicos**<br>**Treponêmicos**|ELISA/EQL/CMIA<br>TPHA/TTPA/MHA-<br>TP|-<br>São os primeiros a se tornarem<br>reagentes.<br>-<br>Na<br>maioria<br>das<br>vezes,<br>permanecem positivos mesmo após o<br>tratamento, pelo resto da vida da pessoa.<br>-<br>São<br>importantes<br>para<br>o<br>diagnóstico, mas não são indicados para<br>o<br>monitoramento<br>da<br>resposta<br>ao<br>tratamento.|  
Fonte: DATHI/SVSA/MS.  
Para estabelecer o diagnóstico, são necessários, pelo menos, dois testes imunológicos. As possíveis interpretações relacionadas aos testes diagnósticos são abordadas no **Quadro 12** .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
|**PRIMEIRO**<br>**TESTE**|**+**<br>**TESTE**<br>**COMPLEMENTAR**|**POSSÍVEIS INTERPRETAÇÕES**|**CONDUTA**|
|---|---|---|---|
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|Diagnóstico de sífilis.<br><br>Classificação do estágio clínico a ser<br>definida de acordo com o tempo de infecção e o<br>histórico de tratamento.<br>Cicatriz sorológica: tratamento anterior documentado com<br>quedada titulação empelomenos duas diluições.|Quando sífilis: tratar, realizar monitoramento com<br>teste não treponêmico e notificar o caso de sífilis.<br>Quando confirmado caso de cicatriz sorológica:<br>apenas orientar.|
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste**<br>**não**<br>**treponêmico:**<br>**não reagente**|Realiza-se um**terceiro teste**treponêmico com metodologia<br>diferente do primeiro.<br><br>Se**reagente:**diagnóstico de sífilis ou<br>cicatriz sorológica.<br><br>Se**não reagente:**considera-se resultado<br>falso-reagente para o primeiro teste, sendo excluído<br>o diagnóstico de sífilis.<br>Se o terceiro teste treponêmico não estiver disponível,<br>avaliar exposição de risco, sinais e sintomas e histórico de<br>tratamento paradefinição de conduta.|Quando sífilis: tratar, realizar monitoramento com<br>teste não treponêmico e avaliar critério de notificação<br>de sífilis.<br>Quando confirmado caso de cicatriz sorológica:<br>apenas orientar.<br>Para os casos concluídos como ausência de sífilis:<br>apenas orientar.|
|**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste treponêmico:**<br>**reagente**|Diagnóstico de sífilis.<br><br>Classificação do estágio clínico a ser<br>definida de acordo com o tempo de infecção e o<br>histórico de tratamento.<br>Cicatriz sorológica: tratamento anterior documentado com<br>queda da titulação empelo menos duas diluições.|Quando sífilis: tratar, realizar monitoramento com<br>teste não treponêmico e notificar o caso de sífilis.<br>Quando confirmado caso de cicatriz sorológica:<br>apenas orientar.|  
|**PRIMEIRO**<br>**TESTE**|**+**<br>**TESTE**<br>**COMPLEMENTAR**|**POSSÍVEIS INTERPRETAÇÕES**|**CONDUTA**|
|---|---|---|---|
|**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste treponêmico:**<br>**não reagente**|Realiza-se um**terceiro teste**treponêmico com metodologia<br>diferente do primeiro.<br>O resultado final do fluxograma será definido pelo resultado<br>desse**terceiro teste.**<br><br>Se**reagente**, diagnóstico de sífilis ou<br>cicatriz sorológica.<br><br>Se**não reagente**, considera-se resultado<br>falso-reagente para o primeiro teste, sendo excluído<br>o diagnóstico de sífilis.<br>Se o terceiro teste treponêmico não estiver disponível,<br>avaliar exposição de risco, sinais e sintomas e histórico de<br>tratamentopara definição de conduta.|Quando sífilis: tratar, realizar monitoramento com<br>teste não treponêmico e avaliar critério de notificação<br>de sífilis.<br>Quando confirmado caso de cicatriz sorológica:<br>apenas orientar.<br>Para os casos concluídos como ausência de sífilis:<br>apenas orientar.|
|**Teste**<br>**não**<br>**treponêmico:**<br>**não reagente**<br>**ou**<br>**Teste**<br>**treponêmico:**<br>**não reagente**|**+**<br>Não<br>realizar<br>teste<br>complementar se o<br>primeiro teste for**não**<br>**reagente**e se não<br>houver<br>suspeita<br>clínica<br>de<br>sífilis<br>primária|Ausência de infecção ou período de incubação (janela<br>imunológica) de sífilis recente.|Em caso de suspeita clínica e/ou epidemiológica,<br>solicitar nova coleta de amostra em 30 dias.<br>Isso não deve, no entanto, retardar a instituição do<br>tratamento, caso o diagnóstico de sífilis seja o mais<br>provável (ex.: visualização de úlcera anogenital) ou o<br>retorno da pessoa ao serviço de saúde não possa ser<br>garantido.|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Para pacientes com testes não treponêmicos reagentes com títulos baixos, normalmente menor ou igual a 1:4, se faz necessária a diferenciação entre: diagnóstico de sífilis, resposta imunológica benigna (cicatriz sorológica) ou teste falso positivo.  
- **Cicatriz sorológica:** persistência de resultados reagentes nos testes treponêmicos e/ou nos testes não treponêmicos com baixa titulação após o tratamento adequado para sífilis, afastada a possibilidade de reinfecção. Utilizado para as situações em que a pessoa, comprovadamente tratada, apresenta queda da titulação em duas diluições, mas ainda mostra reatividade nos testes. Nesses casos, os testes treponêmicos tendem a ser reagentes, e os testes não treponêmicos quantitativos apresentam baixos títulos (menor ou igual a 1:4).  
- **Teste falso-reagente:** algumas situações podem gerar quadros de testes não treponêmicos falso-reagentes, os quais podem ser transitórios ou permanentes.  
|**Situações que podem gerar resultados**<br>**falso-reagentes transitórios**|**Situações que podem gerar resultados**<br>**falso- reagentes permanentes**|
|---|---|
|- Algumas doenças infecciosas febris (ex:<br>malária, hepatite, varicela e sarampo);<br>- Após imunizações;<br>- Após infarto do miocárdio;<br>- Gravidez.|- Infecção pelo HIV;<br>- Hepatite crônica;<br>- Doenças autoimunes;<br>- Uso de drogas injetáveis;<br>- Hanseníase;<br>- Idadeavançada.|  
Fonte: Adaptado de Manual técnico para diagnóstico da sífilis, 2021.  
- **Diagnóstico:** recomenda-se investigar sinais e sintomas, avaliar histórico de tratamento e, em alguns casos, repetir o teste não treponêmico para avaliar possível aumento da titulação.  
A interpretação como sífilis recente (“aguda”) ou tardia (“crônica”) com base nas porções IgM e IgG dos testes treponêmicos é equivocada, uma vez que na infecção pelo _T. pallidum_ tal correlação não é válida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- Maior frequência de altas diluições ao diagnóstico;  
- Maior frequência de resultados falso-reagentes (efeito prozona **)**<sup>67</sup>  
**Efeito Prozona:** relação desproporcional entre as quantidades de antígenos e anticorpos resentes na reação não treponêmica, gerando resultados falso-não reagentes. Por esse motivo, é fundamental que, todas as vezes que se realizar qualquer teste não treponêmico, a amostra seja sempre testada pura e na  
diluição 1:8.  
Deve-se buscar o diagnóstico por formas alternativas e solicitar testes treponêmicos (teste rápido), bem como eventuais exames diretos da lesão. O fenômeno de prozona não ocorre nos testes treponêmicos.  
Mais informações sobre testes diagnósticos de sífilis podem ser encontradas no “Manual técnico para o diagnóstico da sífilis”, disponíveis em: https://www.gov.br/aids/pt-br/centrais-de- <u>conteudo/manuais-tecnicos-para-diagnostico.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Para o diagnóstico de neurossífilis, deve-se considerar: história clínica, presença de sinais e/ou sintomas neurológicos, testes imunológicos e avaliação liquórica<sup>68–71</sup> .  
Há indicação para realização de punção lombar para pesquisa de neurossífilis quando  
ocorre:  
- presença de sintomas neurológicos ou oftalmológicos;  
- Evidência de sífilis terciária ativa;  
- Após falha ao tratamento clínico sem reexposição sexual. Para PVHA, a punção lombar está indicada após falha de tratamento, independentemente da história sexual.  
A avaliação do líquor pode ser considerada para PVHA assintomáticos com contagem de LT-CD4 ≤ 350 células/mm<sup>3</sup> e/ou presença de títulos maior ou igual a 1:32 no teste não treponêmico sérico e sem uso de TARV. No entanto, há controvérsias sobre os benefícios de realizar rotineiramente a punção lombar, sem sinais ou sintomas neurológicos.  
Os achados mais frequentes no líquido cefalorraquidiano (LCR) nos pacientes com neurossífilis podem ser encontrados em indivíduos com HIV mesmo sem neurossíflis, o que dificulta o diagnóstico e incluem:  
- Celularidade: pleocitose (6 a 200 células/mm³) com predomínio linfomonocitário.  
- Proteína: contagem normal ou elevação moderada.  
- Testes não treponêmicos: VDRL reagente no líquor é o mais específico para sífilis.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Não há particularidades para o início de TARV em pacientes coinfectados com sífilis. O tratamento para sífilis não difere entre PVHA e pessoas sem infecção pelo HIV, inclusive gestantes vivendo com HIV<sup>48</sup> .  
O **Quadro 13** descreve os esquemas terapêuticas para sífilis e os testes para seguimento do paciente.  
**Quadro 13:** Resumo dos esquemas terapêuticos para sífilis e seguimento  
|**ESTADIAMENTO**|**ESQUEMA**<br>**TERAPÊUTICO**|**ALTERNATIVA**<sup>**(a)**</sup>|**SEGUIMENTO**<br>**(teste não**<br>**treponêmico)**|
|---|---|---|---|
|Sífilis recente: primária,<br>secundária<br>e<br>latente<br>recente (Menos de 1 ano<br>de evolução)|Benzilpenicilina<br>benzatina 2,4 milhões<br>UI, via intramuscular<br>(IM), dose única (1,2<br>milhão UI em cada<br>glúteo)|Doxiciclina 100 mg,<br>VO, 12/12 horas, por 15<br>dias (exceto gestantes)|Teste não treponêmico<br>trimestral (em gestantes,<br>o controle deve ser<br>mensal)|
|Sífilis<br>tardia:<br>latente<br>tardia (Mais de1 de ano<br>de evolução) ou latente<br>com duração ignorada e<br>sífilis terciária|Benzilpenicilina<br>benzatina 2,4 milhões<br>UI,<br>via<br>IM,<br>dose<br>semanal, por 3 semanas.<br>Dose total: 7,2 milhões<br>UI,IM|Doxiciclina 100 mg,<br>VO, 12/12 horas, por 30<br>dias (exceto gestantes)|Teste não treponêmico<br>trimestral (em gestantes,<br>o controle deve ser<br>mensal)|
|Neurossífilis|Benzilpenicilina<br>potássica/cristalina 18 a<br>24<br>milhões<br>UI/dia,<br>1x/dia,<br>por<br>via<br>intravenosa<br>(IV),<br>administrada em doses<br>de 3 a 4 milhões UI, a<br>cada 4 horas, por 14 dias|Ceftriaxona 2 g, via IV,<br>1x/dia, por 10 a 14 dias|Exame de LCR a cada 6<br>meses até normalização|  
Fonte: DATHI/SVSA/MS  
(a) A benzilpenicilina benzatina é a única opção segura e eficaz para o tratamento adequado das gestantes. Em não gestantes, o intervalo entre doses não deve ultrapassar 14 dias. Caso isso ocorra, o esquema deve ser reiniciado.  
Para o tratamento de sífilis em gestantes consultar o protocolo clínico e diretrizes Terapêuticas para Atenção integral às pessoas com infecções Sexualmente Transmissíveis (IST) e as orientações vigentes: <u>https://www.gov.br/aids/pt-br/centrais-deconteudo/pcdts/2022/ist/pcdt-ist-2022_isbn-1.pdf/view</u>  
A benzilpenicilina benzatina é a única opção segura e eficaz para o tratamento adequado das gestantes. Qualquer outro tratamento realizado durante a gestação, para fins de definição de caso e abordagem terapêutica de sífilis congênita, é considerado tratamento não adequado da mãe; por conseguinte, o recém-nascido será notificado como caso de sífilis congênita e submetido à avaliação clínica e laboratorial.  
Esquemas alternativos à benzilpenicilina benzatina não foram bem estudados em PVHA com sífilis. A reação alérgica grave (anafilaxia) ao medicamento é muito rara e pessoas que se enquadrarem nesses casos devem ser cuidadosamente avaliadas quanto à necessidade de receber outro medicamento que não a penicilina.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A reação anafilática à administração de benzilpenicilina benzatina é rara<sup>72,73</sup> . Conforme Relatório de Recomendação nº 25/2015, elaborado pela Comissão Nacional de Incorporação de Tecnologia no SUS – Conitec, a possibilidade de reação anafilática à administração do medicamento é de 0,002%<sup>74</sup> .  
O receio de ocorrência de reações adversas não é impeditivo para a administração de benzilpenicilina benzatina nos serviços de saúde, especialmente na Atenção Primária à Saúde – APS. A anafilaxia não é exclusiva das penicilinas e, portanto, os serviços devem estar cientes dos procedimentos a serem adotados em tal situação. A epinefrina (adrenalina) é o medicamento de escolha para o manejo dessa intercorrência.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Ocorre nas primeiras 24 a 48 horas após o tratamento para sífilis e caracteriza-se por reação febril, que pode ser acompanhada de cefaleia, mialgia, sudorese, hipotensão e **piora das lesões de pele se inicialmente presentes.** A reação normalmente é autolimitada e resolve-se dentro de 12 a 24 horas. Ocorre mais frequentemente após o tratamento da sífilis recente. A coinfecção com HIV não altera o tipo e intensidade da reação. Não há como prevenir a reação, mas podem ser orientados cuidados sintomáticos com antipiréticos<sup>75,76</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Para o seguimento do paciente, os testes não treponêmicos (ex.: VDRL) devem ser realizados mensalmente nas gestantes e, nos demais casos (incluindo PVHA), a cada três meses até um ano de acompanhamento do paciente (3, 6, 9, 12 meses).  
**O monitoramento deve ser realizado com teste não treponêmico e, sempre que possível, com o mesmo método diagnóstico. Por exemplo: se o diagnóstico for realizado por VDRL, fazer o seguimento com VDRL. Em caso de diagnóstico realizado por RPR, fazer o seguimento com RPR.**  
O monitoramento é fundamental para avaliar a resposta ao tratamento e definir a conduta mais correta para cada caso.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Tradicionalmente, é indicação de sucesso de tratamento a diminuição da titulação em duas diluições dos testes não treponêmicos em até três meses e quatro diluições até seis meses, com evolução até a sororreversão (teste não treponêmico não reagente)<sup>77,78</sup> . Essa resposta é mais comum em pessoas de menos idade, títulos não treponêmicos mais altos no início do tratamento e em estágios mais recentes da infecção (sífilis primária, secundária e latente recente)<sup>79</sup> . Mesmo que ocorra resposta adequada ao tratamento, o seguimento clínico deve continuar, com o objetivo de monitorar possível reativação ou reinfecção.  
**Atualmente, para a definição de resposta imunológica adequada, utiliza-se o teste não treponêmico não reagente ou uma queda na titulação em duas diluições em até seis meses para sífilis recente e queda na titulação em duas diluições em até 12 meses para sífilis tardia**<sup>80–82</sup> .  
Quanto mais precoce for o diagnóstico e tratamento, mais rapidamente haverá desaparecimento dos anticorpos circulantes e consequente negativação dos testes não treponêmicos, ou, ainda, sua estabilização em títulos baixos.  
Deve-se realizar a coleta do teste não treponêmico no início do tratamento (idealmente, no primeiro dia de tratamento), uma vez que os títulos podem aumentar significativamente após alguns dias entre o diagnóstico de sífilis e o início de tratamento. Isso é importante para a documentação da titulação no momento do início do tratamento e servirá como base para o monitoramento clínico.  
Os testes treponêmicos não devem ser utilizados para o monitoramento da resposta ao tratamento. Esses testes não permitem a realização de titulação e espera-se que permaneçam reagentes por toda a vida do indivíduo, sem, contudo, indicar falha do tratamento.  
Indivíduos tratados para neurossífilis devem ser submetidos à punção liquórica de controle após seis meses do término do tratamento. Na persistência de alterações liquóricas, recomenda-se o retratamento e punções de controle em intervalos de seis meses, até a normalização da celularidade e resultado não reagente no VDRL. Em PVHA, essa resposta pode ser mais lenta, sendo necessária uma avaliação caso a caso<sup>80</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Muitas vezes, em situações que não se enquadram como resposta imunológica adequada, é difícil diferenciar a reinfecção, a reativação e a resposta imunológica benigna, sendo fundamental a avaliação da presença de sinais ou sintomas clínicos novos, epidemiologia (reexposição, comorbidades), histórico do tratamento (duração, adesão e medicamentos utilizados) e exames laboratoriais prévios, para facilitar a elucidação diagnóstica. Caso ainda haja suspeita de infecção ativa pela sífilis, o retratamento deve ser instituído.  
São critérios de retratamento e necessitam de conduta ativa do profissional de saúde:  
- Ausência de redução da titulação em duas diluições no intervalo de seis meses (sífilis recente, primária e secundária) ou 12 meses (sífilis tardia) após o tratamento adequado (ex.: de 1:32 para maior que 1:8, ou de 1:128 para maior que 1:32); ou  
- Aumento da titulação em duas diluições ou mais (ex.: de 1:16 para 1:64, ou de 1:4 para 1:16); ou  
- Persistência ou recorrência de sinais ou sintomas de sífilis.  
Para PVHA, a investigação de neurossífilis por meio de punção lombar é recomendada em todos os casos de retratamento, independentemente de haver ocorrido ou não nova exposição.  
Em caso de exame de LCR compatível com neurossífilis, tratar conforme esquemas terapêuticos para sífilis **(Quadro 13)** e seguimento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Um terço das parcerias de pessoas com sífilis desenvolverão a infecção dentro de 30 dias da exposição. Portanto, além da avaliação clínica e do seguimento laboratorial, se houve exposição à pessoa com sífilis (até os 90 dias anteriores), recomenda-se oferta de tratamento presuntivo a esses parceiros sexuais (independentemente do estágio clínico ou sinais e sintomas), com dose de benzilpenicilina benzatina 2,4 milhões UI, via IM (1,2 milhão UI em cada glúteo).  
Todas as parcerias devem ser testadas. Quando o teste de sífilis for reagente, recomendase tratamento de sífilis adquirida no adulto, de acordo com o estágio clínico.  
A avaliação e tratamento das parcerias sexuais são cruciais para interromper a cadeia de transmissão.  
Mais informações sobre o manejo da sífilis adquirida e sífilis em gestante podem ser encontradas no “Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis” e “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais”, disponíveis em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts/2022/ist/pcdt-ist-2022_isbn1.pdf/view.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A doença de Chagas é uma das consequências da infecção humana pelo protozoário _Trypanosoma cruzi_ , transmitido ao ser humano pelas vias vetorial, transfusional/transplante, vertical, oral ou acidental<sup>83,84</sup> .  
Mantém-se como um processo infeccioso crônico relevante: estimam-se entre 6 milhões de indivíduos infectados no mundo, e os relatos mais frequentes em áreas tradicionalmente não endêmicas são resultado do processo de migração internacional<sup>85</sup> .  
A síndrome clínica é multissistêmica, com duas fases clínicas da doença: uma aguda, identificada em apenas 5% dos casos, podendo evoluir para uma segunda fase, crônica. Na fase crônica, a forma indeterminada, sem expressão clínica, é mais frequente (60% a 70%)<sup>86</sup> . As formas determinadas (30 a 40% dos casos) potencialmente fatais que ocorrem após décadas da infecção inicial, nas formas cardíacas, digestivas, neurológicas ou mistas, que podem demandar tratamento etiológico<sup>83, 84</sup> .  
No Brasil, estimam-se 1,9 a 4,6 milhões de indivíduos na fase crônica, com uma média aproximada de 4.400 óbitos anuais como causa básica, gerando alta carga de morbimortalidade<sup>83</sup> . Entretanto, estima-se que somente cerca de 10 a 30% das pessoas acometidas sabem do seu diagnóstico, o que contribui para que somente 1% daquelas que necessitam de tratamento  
etiológico tenha acesso de fato, mantendo o elevado impacto de morbimortalidade e de custo social, com limitação da qualidade de vida<sup>84</sup> .  
As mudanças na epidemiologia da doença de Chagas devem ser consideradas: maior sobrevida, processos migratórios nas últimas cinco décadas, urbanização, entre outras. Ampliase, portanto, a probabilidade de ocorrência de comorbidades, infecciosas ou não, incluindo a coinfecção do HIV com T. _cruzi_ , fato que reforça a importância do diagnóstico oportuno.  
Como em outras doenças infecciosas, o _T. cruzi_ comporta-se, potencialmente, como microrganismo oportunista em indivíduos com imunossupressão.  No Brasil, estima-se a prevalência da coinfecção _T. cruzi_ /HIV em 1,3% a 5%<sup>87,88</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A imunossupressão associada à infecção por HIV representa um fator de risco importante para reativação da doença<sup>89</sup> . A reativação caracteriza-se pela agudização da infecção crônica por _T. cruzi_ e aumento da parasitemia, semelhante ao quadro clínico da doença na fase aguda, e pela incapacidade do sistema imune de controlar a infecção<sup>90</sup> . Está associada à elevada morbimortalidade em virtude da infecção no SNC e da miocardite, impactando criticamente também a qualidade de vida<sup>84</sup> .  
Na doença de Chagas, vários tecidos e órgãos apresentam lesões cuja patogênese está ligada à ação do microrganismo ou do hospedeiro. A expressão da resposta imune no mecanismo fisiopatogênico reflete-se em reações inflamatórias focais ou difusas.  
Em pacientes coinfectados, estima-se uma frequência de 20% a 40% de reativação da doença de Chagas<sup>84</sup> . A elevada frequência de casos com reativação apresentando níveis de LTCD4+ inferiores a 200 céls/mm<sup>3</sup> sugere a importância do grau de imunodepressão na reativação<sup>88</sup> . Além disso, dados recentes evidenciam que menores contagens de LT-CD4 no momento do diagnóstico da coinfecção estão relacionadas a reativação e ao óbito decorrente da reativação<sup>91</sup> .  
Há relação direta entre nível de parasitemia (por PCR quantitativa) e CV e relação inversa entre parasitemia e nível de LT-CD4+ ou relação CD4+/CD8+ em indivíduos coinfectados, com ou sem reativação<sup>88</sup> .  
A elevada letalidade registrada, particularmente na presença de meningoencefalite, reforça a necessidade de rápida identificação, diagnóstico e manejo da coinfecção, a fim de evitar desfechos desfavoráveis.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Recomenda-se que a solicitação de teste de anticorpos anti- _T. cruzi_ esteja disponível para toda PVHA, com base na existência de antecedente epidemiológico, conforme descrição prévia.  
A testagem deve incluir dois métodos de princípios distintos ou com diferentes preparações antigênicas para detecção de IgG (hemaglutinação indireta, imunofluorescência indireta, ELISA e quimioluminescência). A avaliação sorológica é o padrão-ouro para diagnóstico da doença de Chagas na fase crônica, apesar de não confirmar o diagnóstico da reativação<sup>83,92</sup> .  
A reativação da doença de Chagas em PVHA faz parte das doenças definidoras de aids, a partir do diagnóstico definitivo de meningoencefalite e/ou miocardite.  
Para a fase crônica, devem ser considerados os seguintes fatores epidemiológicos associados a maior risco de possuir a infecção por _T. cruzi_ , independentemente de quadro clínico sugestivo:  
- Indivíduos que residiram na infância ou residem em área rural com relato de presença do triatomineo e/ou residindo em habitações onde possa ter ocorrido o convívio com vetor (principalmente casas de estuque, taipa sem reboco, sapê, pau-a-pique, de madeira e suspensas em rios nos cenários ribeirinhos da Amazônia);  
- Indivíduos residentes em (ou procedentes de) áreas com registro de transmissão ativa e com histórico epidemiológico sugestivo da ocorrência da transmissão da doença, como consumo frequente de frutos in natura ou carne de caça no contexto da Região Amazônica;  
- Indivíduos que realizaram transfusão sanguínea antes de 1992;  
- Indivíduos com parentes ou pessoas do convívio que tenham diagnóstico de Chagas, em especial filhos de mães com a infecção comprovada por _T. cruzi._  
**Na maioria dos casos, a reativação foi descrita no SNC, seguido pelo coração** , e caracterizada clinicamente por **sinais de doença aguda** , sendo a febre a principal manifestação.  
O quadro clínico focal de cada órgão acometido é inespecífico, incluindo, para o SNC, cefaleia, sinais de hipertensão intracraniana, convulsões, localização motora e coma, gerando confusão diagnóstica, principalmente com meningoencefalite por toxoplasmose e tumores do SNC (em especial linfomas). Entre as principais características diferenciais da meningoencefalite por _T. cruzi_ em relação àquela por _Toxoplasma gondii_ incluem-se: sede das lesões mais frequente na substância branca que na cinzenta, sem descrição nos núcleos da base; hemorragia difusa das áreas necróticas; grande presença de parasitos nos tecidos; lesões mielínicas frequentes e de maior intensidade; leptomeninges com acometimento difuso e de intensidade variável; menor frequência e intensidade de vasculite necrosante e trombose<sup>93–95</sup> .  
Para complementação diagnóstica, são indicados métodos de imagem, nos quais se verifica a presença de lesões iso ou hipodensas únicas ou múltiplas, de aspecto pseudotumoral, com ou sem reforço anelar de após contraste venoso, podendo apresentar ou não efeito de massa. Assim, em contextos epidemiológicos favoráveis à doença de Chagas, todos os casos com lesões cerebrais com efeito de massa devem ser avaliados quanto à possibilidade de infecção por _T. cruzi_ reativada.  
No coração, a reativação consiste em desencadeamento ou exacerbação de insuficiência cardíaca congestiva, arritmias, bloqueios atrioventriculares, de ramo e fasciculares. Outros locais menos comuns de reativação foram pericárdio, peritônio, pele, intestino e colo uterino.  
Nos casos de reativação, o parasita é facilmente encontrado por métodos diretos no sangue periférico, no LCR e/ou em outros fluidos corporais (líquidos ascítico e pericárdico). A presença de tripomastigotas de _T. cruzi_ ao exame microscópico caracteriza, portanto, a reativação da doença. Como métodos diretos no sangue, estão disponíveis a pesquisa em creme leucocitário e o micro-hematócrito. No LCR, o parasita é pesquisado no precipitado de material centrifugado 93.  
Diante da suspeita clínica, a negatividade da pesquisa direta do parasita não exclui possibilidade de reativação da doença de Chagas, devendo, nesses casos, ser realizadas pesquisas repetidas no sangue e no LCR<sup>93,95</sup> .  
A positividade do xenodiagnóstico, da hemocultura e da pesquisa de DNA do parasita por PCR não deve ser considerada como evidência de reativação, uma vez que, na fase crônica da doença em pacientes imunocompetentes, a parasitemia pode ser demonstrada por esses métodos.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Caso ocorra reativação, deve-se iniciar o tratamento etiológico indicado para a fase aguda da doença de Chagas. Apesar de o nível de evidência ser moderado, a recomendação é classificada como forte, pois os medicamentos antiparasitários podem apresentar benefícios potenciais na prevenção da ocorrência de reativações e suas consequências, assim como no seu controle e mesmo quanto à sua recorrência<sup>83</sup> .  
A evidência de reativação parasitária deve ser abordada com internação hospitalar e instituição de tratamento. As orientações para a escolha do tratamento são apresentadas no **Quadro 14**<sup>83</sup> .  
**Quadro 14:** Tratamento da reativação da doença de Chagas  
|**Medicamento**|**Público**|**Posologia**|
|---|---|---|
|Benznidazol (primeira escolha)<br>Comprimidos de 100 mg|Adulto|(1) 5 mg/kg/dia, 1 a 2 x/dia, por 60 dias<br>OU<br>(2) 300 mg/dia, em 2 a 3 tomadas diárias,<br>pelo número de dias equivalente ao peso<br>do indivíduo (máximo 80 dias)|
|Nifurtimox (alternativa a<br>intolerância ou que não respondam<br>ao tratamento com benznidazol)<br>Comprimidos de 120 mg|Adulto|10 mg/kg/dia, 3 x/dia, por 60 dias|  
Fonte: Brasil, 2018  
Sugere-se tratar, preferencialmente com benznidazol, PVHA com doença de Chagas crônica sem reativação e sem tratamento etiológico prévio. Para a decisão de tratamento, devem ser levados em consideração fatores como o status imunológico do caso, em especial devido ao risco de síndrome de reconstituição imunológica. A identificação precoce da reativação em sua fase assintomática e o monitoramento clínico por meio de PCR quantitativa não é recomendada de rotina, tendo em vista a ausência de estudos sobre o tópico e as limitações em relação à disponibilidade dos exames e à padronização das técnicas laboratoriais<sup>83</sup> .  
Em pacientes com disfagia importante devido ao megaesôfago, recomenda-se realizar tratamento sintomático. O tratamento não deve ser instituído em gestantes e lactantes, exceto em quadros agudos e graves de reativação. Uma elevada frequência de transmissão congênita de _T. cruzi_ tem sido relatada em mães coinfectadas, observando-se, nos recém-nascidos, quadros graves  
de meningoencefalite, miocardite e doença disseminada, com elevada mortalidade. Aconselha-se seguimento criterioso com avaliação clínica e pesquisa direta do parasita em gestantes coinfectadas.  
A grande maioria dos pacientes tratados precocemente apresenta boa resposta, com remissão clínica da doença, que pode ser documentada após alguns dias do início do tratamento específico, com desaparecimento da febre e de outros sintomas, além de melhora dos sinais neurológicos e de arritmias e/ou da insuficiência cardíaca.  
Recomenda-se que os pacientes sejam encaminhados para centros de referência para avaliação e acompanhamento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Embora a literatura seja escassa e não haja consenso quanto ao momento adequado para iniciar a TARV, a suspeição assim como o diagnóstico precoce serão fundamentais para reduzir a letalidade dessa condição clínica. Desse modo, é necessário individualizar cada caso e considerar a introdução da TARV oportunamente, considerando o risco de SIRI, principalmente se acometimento do sistema nervoso central<sup>96–98</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Não foram encontrados estudos avaliando a efetividade da profilaxia primária com antiparasitários em pacientes com coinfecção HIV- _T. cruzi_ .  
Na literatura, há recomendações sugerindo profilaxia secundária, em casos tratados por reativação seguida de remissão clínica e negativação parasitológica, quando os níveis de LTCD4+ forem menores que 200 células/mm<sup>3</sup> . Contudo, essa recomendação precisa ser validada em estudos prospectivos, uma vez que não há dados embasando seu uso.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
No Brasil, a doença de Chagas na fase aguda está tradicionalmente inserida como doença de notificação compulsória (http://www.portalsinan.saude.gov.br/doenca-de-chagas-aguda). A Portaria GM/MS nº 1.061, de 18 de maio de 2020, incluiu a doença de Chagas na fase crônica na Lista Nacional de Notificação Compulsória de doenças, agravos e eventos de saúde pública, enquanto a disponibilização de instrumentos e de referencial de sistema de informação ocorreu em janeiro de 2023 (https://datasus.saude.gov.br/notifica/ e https://www.gov.br/saude/ptbr/assuntos/saude-de-a-a-z/d/doenca-de-chagas/arquivos/2023/).  
A forma reativada da doença é considerada, no Brasil, como doença indicativa de imunodeficiência grave em indivíduos com 13 anos de idade ou mais para definição de caso de aids desde janeiro de 2004 para fins de vigilância epidemiológica. Somente são considerados casos de reativação aqueles que apresentarem diagnóstico definitivo de infecção por _T. cruzi_ e meningoencefalite e/ou miocardite aguda.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A hanseníase é uma doença infecciosa de evolução crônica, que embora curável, ainda permanece endêmica em várias regiões do mundo, principalmente na Índia, Brasil e Indonésia. No Brasil ainda é considerada um importante desafio em saúde pública. É causada pelo _Mycobacterium leprae_ ( _M. leprae_ ), um bacilo álcool-ácido-resistente, de multiplicação lenta e não cultivável _in vitro._ A transmissão ocorre pelo contato direto, prolongado, pessoa a pessoa, e é facilitada pelo convívio de doentes não tratados com indivíduos susceptíveis. A doença cursa com neuropatia em graus variados podendo causar incapacidades físicas e perda funcional, especialmente nas mãos, nos pés e nos olhos, que pode ser muito grave em casos com diagnóstico tardio<sup>99</sup> .  
Pode acometer qualquer indivíduo, porém, dados epidemiológicos demonstram o predomínio em homens pretos, de 30 a 59 anos e com baixa escolaridade, principalmente nas regiões Norte, Nordeste e Centro-Oeste<sup>100</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
As primeiras publicações da era pré-TARV demonstraram paradoxo da resposta imunecelular efetiva, em casos com manifestação de hanseníase tuberculoide e aids em estágio avançado, com baixa contagem de LT-CD4+.  
A maioria das publicações da era TARV demonstra o potencial dessa terapia, mediante a SIRI, em desencadear a síndrome clínica da hanseníase e/ou de reação hansênica do tipo I ou reação reversa (RR)<sup>101</sup> . Nesse caso, a RR confunde-se com a própria SIRI. Estudos mais recentes ressaltam o efeito _booster_ do fenômeno SIRI em casos do grupo Dimorfo (Dimorfo Dimorfo – DD, Dimorfo Virchowiano – DV), apresentando reversão para Dimorfo Tuberculoide (DT). Em síntese, todo o espectro de manifestações clínicas da hanseníase é contemplado na coinfecção, mas predominam as formas com resposta imunocelular presente e efetiva<sup>102</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A manifestação clínica da coinfecção não é homogênea ou constante. Na maioria das vezes – como nos indivíduos não imunossuprimidos – apresenta-se como placas infiltradas, eritematosas ou hipocrômicas, associadas a alterações de sensibilidade térmica e/ou tátil e/ou dolorosa. Entretanto, lesões neurais isoladas, como “ilhas” hipo ou anestésicas podem ocorrer acompanhadas ou não de nervos periféricos espessados e/ou dolorosos. Essas áreas cutâneas podem também apresentar aspecto xerótico/ictiósico (escamas de peixe) pela hipo e/ou anidrose, devido à destruição de filetes nervosos autonômicos. Lesões ulcero-necróticas também podem ser observadas. A amiotrofia tem característica assimétrica e periférica. Também há casos de neuropatia periférica associada ao HIV ou como efeito adverso da TARV, que devem ser lembrados como potenciais diagnósticos diferenciais<sup>99,103,104</sup> .  
A definição de caso, conforme PCDT de Hanseníase, está descrita no **Quadro 15** .  
**Quadro 15:** Definição de caso de hanseníase vigente  
O Ministério da Saúde define um caso de hanseníase pela presença de pelo menos um ou mais dos seguintes critérios, conhecidos como sinais cardinais da hanseníase:  
1) Lesão(ões) e/ou áreas(s) da pele com alteração de sensibilidade térmica e/ou dolorosa e/ou tátil;  
2) Espessamento de nervo periférico, associado a alterações sensitivas e/ou motoras e/ou autonômicas;  
<u>3) Presença do</u> _M._ _<u>leprae</u>_ <u>, confirmada na baciloscopia de esfregaço intradérmico ou na biópsia de pele.</u> Fonte: Protocolo Clínico e Diretrizes Terapêuticas da Hanseníase (BRASIL, 2022)

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O esquema farmacológico de primeira linha recomendado para tratamento é a poliquimioterapia única da hanseníase (PQT-U), que leva à cura em até 98% dos casos. Consiste numa associação de três antimicrobianos (rifampicina, dapsona e clofazimina), sendo o tempo de duração determinado pela classificação operacional da doença, podendo variar de seis a doze meses, conforme abaixo:  
- Hanseníase paucibacilar (PB): PQT-U por seis 06 meses;  
- Hanseníase multibacilar (MB): PQT-U por doze 12 meses.  
Os medicamentos a serem utilizados na PQT-U são descritos no **Quadro 16** :  
**Quadro 16** : Esquemas de primeira linha para o tratamento de hanseníase paucibacilar e multibacilar.  
|**Faixa etária e**<br>**peso corporal **|**Apresentação**|**Posologia**|**Duração d**<br>**MB**|**o tratamento**<br>**PB**|
|---|---|---|---|---|
|**Pacientes**<br>**com**||**Dose**<br>**mensal**<br>**supervisionada:**<br>•<br>Rifampicina 600 mg<br>•<br>Clofazimina 300 mg<br>•<br>Dapsona 100 mg|||
|**peso acima de 50**<br>**kg**|PQT-U Adulto|**Dose**<br>**diária**<br>**autoadministrada:**<br>•<br>Clofazimina 50 mg<br>diariamente|12 meses|6 meses|
|||•<br>Dapsona<br>100<br>mg<br>diariamente|||  
Fonte: Protocolo Clínico e Diretrizes Terapêuticas da Hanseníase (BRASIL, 2022)  
Apesar de a rifampicina não estar indicada em concomitância com inibidores de protease, essa interação fica minimizada pelo uso intermitente (apenas uma dose mensal).  
Os demais componentes do tratamento PQT-U não apresentam interações relevantes com a TARV. De forma mais específica:  
- **Dapsona** – Interação em potencial. Podem requerer monitorização e alteração da dosagem de fármacos ou do esquema de administração: zidovudina.  
- **Rifampicina** – Fármacos que não devem ser coadministrados: atazanavir, darunavir, lopinavir/ritonavir, ritonavir, tipranavir, etravirina e nevirapina. Interação em potencial – podem requerer monitorização, alteração da dosagem de fármacos ou do esquema de administração: abacavir, dolutegravir, efavirenz, maraviroque, raltegravir, zidovudina.  
- **Clofazimina** – Interação em potencial. Podem requerer monitorização, alteração da dosagem de fármacos ou do esquema de administração: atazanavir e lopinavir/ritonavir.  
Para checar as interações medicamentosas entre a PQT-U e os ARV consultar: <u>https://interacoeshiv.huesped.org.ar/</u>  
Para mais informações referentes ao tratamento da hanseníase, dos casos de reação hansênica e possíveis eventos adversos consultar o PCDT de Hanseníase, disponível em: <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Não é indicada profilaxia primária ou secundária da hanseníase para pacientes infectados pelo HIV.  
O tratamento de TB latente para os contatos intradomiciliares, com maior risco de adoecer, ainda é objeto de pesquisa em hanseníase. Entretanto, recomenda-se uma dose da vacina BCG, caso nunca tenham sido vacinados ou tenham recebido apenas uma dose neonatal.  
Recomenda-se cuidado na avaliação de cada caso, de modo a evitar vacinar contatos positivos para o HIV.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A hanseníase é doença de investigação e notificação compulsória em todo país, assim como a infecção pelo HIV e a aids (http://portalsinan.saude.gov.br/doencas-e-agravos). A busca ativa de casos novos, a avaliação dos contatos e a aplicação da vacina BCG constituem importantes ações de vigilância epidemiológica. Não menos importante é a vigilância do potencial incapacitante da doença, que persiste pós-alta, nos casos reacionais.  
Recomenda-se ofertar imunoprofilaxia com vacina BCG aos contatos de pacientes com hanseníase, maiores de um ano de idade, não vacinados ou que receberam apenas uma dose da vacina. A comprovação da vacinação prévia deve ser feita por meio do cartão de vacina ou da presença de cicatriz vacinal.  
Todo contato de hanseníase deve ser orientado quanto ao risco de adoecer ao longo de sua vida e quanto ao fato de que a vacina BCG não é específica para a doença. Entretanto, é importante considerar a situação de risco dos contatos possivelmente expostos ao HIV e outras situações de imunodepressão, incluindo corticoterapia. Assim, para PVHA, seguir as recomendações específicas para imunização com agentes biológicos vivos ou atenuados, apresentadas no “Manual de Vacinação do Ministério da Saúde”, disponível em: <u>http://bvsms.saude.gov.br/bvs/publicacoes/manual_procedimentos_vacinacao.pdf</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os HTLV 1 e 2 pertencem à família _Retroviridae_ , e a infecção não implica, necessariamente, o desenvolvimento de processos patogênicos. As vias de transmissão são a sexual, parenteral e vertical (gestação, parto e principalmente pelo aleitamento materno)<sup>105,106</sup> . A taxa de coinfecção HTLV-HIV depende da região, população e fatores como uso de droga injetável. No Brasil, o estado da Bahia apresenta-se como uma das áreas de maior prevalência de infecção pelo HTLV<sup>107,108</sup> .  
Dos pacientes infectados por HTLV-1/2, aproximadamente 5% apresentam risco de desenvolvimento de paraparesia espástica tropical ou leucemia/linfoma associada ao HTLV-1<sup>109</sup> .  
O HTLV-1 infecta preferencialmente células linfoides T periféricas, principalmente LTCD4+ de memória e LT-CD8+, e estimula a proliferação de linfócitos, enquanto o HIV apresenta intensa depleção linfocitária<sup>110</sup> .  
A linfoproliferação induzida pelo HTLV-1 pode aumentar a contagem de linfócitos T CD4+ no sangue periférico, mas essas células são disfuncionais, e não proporcionam proteção contra as infecções oportunistas, podendo induzir o médico a retardar o início da terapia antirretroviral, por subestimar as alterações imunológicas<sup>48</sup> .  
O impacto da coinfecção do HTLV-1 e HIV pode se expressar por meio de alterações laboratoriais, em que o valor de LT-CD4+ não corresponde ao estágio real de imunossupressão do paciente. A recomendação atual de tratamento para todas as PVHA minimiza o impacto da possibilidade de retardo no início de tratamento, mas pede atenção na instituição das profilaxias e avaliação de risco para as infecções oportunistas (IO).  
Alguns estudos sugerem que indivíduos coinfectados pelo HTLV-1 e HIV têm um risco maior de rápida progressão da doença e desenvolvimento de doenças associadas ao HTLV-1 (doenças dermatológicas, neurológicas e oftalmológicas, além de leucemia/linfoma associada ao HTLV-1)<sup>111,112</sup> .  
O Brasil é considerado uma área endêmica para o HTLV, sendo as regiões Norte e Nordeste com a maior prevalência da doença. Também é importante lembrar de fluxo migratórios de indivíduos do Norte e Nordeste para outras regiões do país<sup>105</sup> . Sendo assim, recomenda-se:  
_<u>Recomendações práticas:</u>_  
1. Todos os indivíduos infectados pelo HIV-1 devem ser testados para anticorpos antiHTLV-1/2, em especial se apresentarem sintomas clínicos que possam ser relacionados à infecção por este vírus e apresentarem eventos oportunistas com linfócito CD4 elevado.  
2. Os pacientes coinfectados pelo HIV-HTLV-1 podem apresentar dissociação entre a contagem de LT-CD4+ e o estadiamento clínico;  
3. Indivíduos coinfectados pelo HIV-1-HTLV-1 podem apresentar doença neurológica ou oncohematológica relacionada ao HTLV-1.  
As infecções pelo HIV e pelo HTLV-1/2 são contraindicações ao aleitamento materno. Portanto, gestantes com o diagnóstico durante o pré-natal devem ser aconselhadas e referenciadas para serviço que garanta, no momento do parto, inibição da lactação com cabergolina e provimento de fórmula láctea infantil.  
As recomendações para a prevenção da transmissão vertical são:  
- Uso de preservativo em todas as relações sexuais;  
- Oferta de redução de danos para pessoas que usam drogas injetáveis;  
- **Contraindicação à amamentação em mães vivendo com HTLV 1/2** , sendo recomendado o uso de inibidores de lactação e de fórmulas lácteas infantis<sup>48,113</sup>  
Mais informações podem ser encontradas no “Guia para Manejo Clínico da Infecção pelo HTLV”, disponível em: <u>https://www.gov.br/aids/pt-br/centrais-deconteudo/publicacoes/2022/guia_htlv_internet_24-11-21-2_3.pdf/view.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
As leishmanioses são doenças tropicais endêmicas que ocorrem em todo o território brasileiro e atingem as cinco regiões geopolíticas. Devido à expansão das leishmanioses para grandes centros urbanos e à interiorização da epidemia da aids, houve intersecção de áreas de transmissão e surgimento de casos de coinfecção _Leishmania_ -HIV.  
As leishmanioses têm apresentação clínica variada, podendo haver desde comprometimento cutâneo até visceral. Sete espécies de _Leishmania_ estão implicadas no desenvolvimento de doença tegumentar, sendo que _Leishmania (V.) braziliensis, Leishmania (L.) amazonensis_ e _Leishmania (V.) guyanensis_ são as de maior prevalência no Brasil. A leishmaniose visceral é causada, no Brasil, somente pela _Leishmania (L.) infantum_<sup>114,115</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
**Leishmaniose tegumentar:** a doença apresenta espectro clínico variado. As lesões cutâneas vão de pápulas a úlceras, podendo haver lesões únicas ou múltiplas, sendo as úlceras as mais comuns. Em pacientes com a coinfecção _Leishmania_ HIV, as manifestações clínicas são semelhantes às de pacientes sem a presença da coinfecção, no entanto, lesões atípicas caracterizadas por máculas ou pápulas disseminadas podem ser encontradas.  
Em pacientes coinfectados com imunossupressão grave, as lesões podem ser encontradas não apenas em áreas expostas, mas também em outras áreas não expostas, tais como a região genital<sup>116,117</sup> .  
**Leishmaniose visceral:** a doença é caracterizada principalmente pela síndrome de hepatoesplenomegalia febril, associada sobretudo a citopenias. Em pacientes coinfectados,  
observa-se manifestação clínica semelhante à de pacientes sem infecção pelo HIV. Entretanto, manifestações atípicas, com comprometimento de pleura pulmonar, esôfago e intestino também são relatadas. Essas manifestações clínicas da leishmaniose visceral são semelhantes às de muitas doenças oportunistas, o que geralmente dificulta o diagnóstico<sup>114</sup> .  
As condições descritas no **Quadro 17** indicam investigação:  
**Quadro 17:** Condições que indicam necessidade de investigação de leishmaniose (tegumentar e visceral)

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- Qualquer forma clínica em paciente sem história de exposição recente (durante o  
- último ano) a uma área de transmissão de leishmaniose sugere a reativação de uma infecção latente;  
- Forma clássica associada à ausência de anticorpos anti-Leishmania;  
- Achado de formas amastigotas no sangue periférico;  
- Envolvimento de órgãos raramente acometidos na leishmaniose visceral;  
- Falha terapêutica ou recidiva após o uso de antimonial pentavalente;  
- Desenvolvimento de infecções sugestivas de imunodeficiência durante ou após o  
tratamento;  
- Isolamento de espécies de Leishmania dermotrópicas ou não descritas como  
- causadoras de acometimento visceral.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- Qualquer tipo de lesão cutânea ou mucosa com mais de duas semanas de evolução em pessoas expostas à área de transmissão em qualquer época da vida;  
- Hepatomegalia ou esplenomegalia associada ou não a febre e citopenias.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
- <mark>Qualquer forma clínica em paciente sem história de exposição recente (durante o</mark>  
- último ano) a uma área de transmissão de leishmaniose sugere a reativação de uma infecção latente;  
- Forma disseminada com ou sem acometimento mucoso concomitante;  
- Forma mucosa com acometimento fora da cavidade nasal;  
- Forma cutânea ou mucosa com achado de parasitos em vísceras;  
- Forma difusa;  
- Achado de amastigotas no exame direto de material obtido de lesões mucosas;  
- Isolamento em material de pele ou mucosa de espécies de Leishmania viscerotrópicas  
- – L. (L.) chagasi – ou não, descritas como causadoras de lesões tegumentares;  
- Falha terapêutica após tratamento com medicamentos leishmanicidas;  
- Recidiva tardia (Mais de 6 meses após a cura clínica);  
- Lesões <u>cutâneas que aparecem após o diagnóstico de lesão mucosa em atividade.</u>  
Fonte: CGZV/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os métodos utilizados para diagnóstico de leishmanioses em pacientes coinfectados são os mesmos utilizados para pacientes sem infecção pelo HIV.  
Para **forma tegumentar** , é utilizado o exame direto com pesquisa de parasito em material coletado por meio de procedimentos de escarificação, de punção aspirativa ou de biópsia das lesões cutâneas, de linfonodos ou de mucosas. O exame histopatológico convencional com hematoxilina-eosina (HE) também é útil na detecção das formas amastigotas nos tecidos e possui singular importância para descartar ou confirmar outras doenças que fazem parte do diagnóstico diferencial.  
Na **leishmaniose visceral** , recomenda-se a pesquisa do parasito em amostras de aspirado de medula óssea e cultura do parasito, além da realização de teste sorológico, como o teste rápido imunocromatográfico. Em casos com resultados parasitológicos e sorológicos negativos ou inconclusivos, é possível realizar o diagnóstico molecular em laboratórios de referência, utilizando DNA extraído de fragmento de pele, mucosa, sangue periférico, medula óssea ou órgãos do sistema fagocítico-mononuclear.  
O diagnóstico deve seguir as orientações dos documentos a seguir:  
- Manual de vigilância da leishmaniose tegumentar, 2017  
Manual de recomendações para diagnóstico, tratamento e acompanhamento de pacientes com a coinfecção leishmania-HIV, 2015.  
- Guia de vigilância em saúde 5ª edição, 2022

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Em pessoas coinfectadas com Leishmania-HIV, tanto na forma visceral quanto na tegumentar, o medicamento de escolha é a anfotericina B, sendo que na forma visceral deve-se empregar no tratamento, preferencialmente, a formulação lipossomal e na forma tegumentar, deve-se priorizar a anfotericina B formulação desoxicolato.  
Para os quadros de leishmaniose tegumentar caracterizados como falha terapêutica do tratamento, há indicação de miltefosina<sup>91</sup> .  
As doses preconizadas dos medicamentos estão apresentadas no _“_ Manual de Recomendações para Diagnóstico, Tratamento e Acompanhamento de Pacientes com a Coinfecção Leishamania-HIV _”, disponível em:_ <u>https://bvsms.saude.gov.br/bvs/publicacoes/manual_recomendacoes_diagnostico_leishmania_hi v.pdf</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Não há indicação de profilaxia primária para leishmanioses; entretanto, há medidas preventivas para evitar a exposição à picada do inseto vetor, principalmente para viajantes que se  
destinam a áreas de transmissão de leishmanioses. Deve-se evitar exposição ao crepúsculo, usar roupas compridas e claras e aplicar repelentes.  
Recomenda-se a profilaxia secundária para todos os pacientes com contagem de LTCD4+ menor que 350 células/mm<sup>3</sup> por ocasião do diagnóstico de leishmaniose visceral, usandose um dos seguintes esquemas, a cada duas semanas (intervalo mais estudado) ou a cada quatro semanas:  
- Anfotericina B (lipossomal): 3 mg a 5 mg/kg;  
- Anfotericina B (desoxicolato): 1 mg/kg (máximo de 50 mg).  
A escolha do esquema a ser utilizado deve seguir as condições do serviço e as características de tolerabilidade de cada paciente, levando-se em consideração o perfil de toxicidade e as interações com outros medicamentos utilizados pelo paciente. Entretanto, em função da alta toxicidade dos derivados de antimônio, recomenda-se a utilização da anfotericina B lipossomal.  
Não há, no momento, estudos na literatura que embasem a utilização de profilaxia secundária nos casos de indivíduos tratados com sucesso para leishmaniose tegumentar.  
Alguns autores recomendam utilizar a contagem de LT-CD4+ acima de 350 células/mm<sup>3</sup> em pacientes com boa resposta ao tratamento regular com antirretrovirais como parâmetro para a suspensão da profilaxia secundária, baseado na observação da ocorrência de recidiva predominantemente em pacientes com valores abaixo desse limiar. Informações adicionais podem ser obtidas no _“Manual de Recomendações para Diagnóstico, Tratamento e Acompanhamento de Pacientes com a Coinfecção Leishmania-HIV – 2015”_<sup>114</sup> _._

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A vigilância da leishmaniose tegumentar tem como objetivo reduzir a morbidade, as deformidades e os óbitos em pacientes com a doença, com a realização de diagnóstico e tratamento adequados e oportunos, redução do contato entre hospedeiros suscetíveis e o vetor e promoção de ações de educação em saúde e de mobilização social.  
Para leishmaniose visceral, o objetivo da vigilância é reduzir a letalidade e a morbidade por meio do diagnóstico e do tratamento adequados e oportunos dos casos, bem como diminuir os riscos de transmissão mediante o controle da população de reservatórios e do agente transmissor, reduzindo as fontes de infecção para o vetor e promovendo ações de educação em saúde e mobilização social.  
Tanto a leishmaniose visceral como a leishmaniose tegumentar são doenças de notificação compulsória.  
As estratégias de controle das leishmanioses devem ser flexíveis, distintas e adequadas a cada região ou foco em particular. Para se definirem as estratégias e a necessidade das ações de controle para cada área a ser trabalhada, deverão ser considerados os aspectos epidemiológicos, bem como seus determinantes. As medidas de controle devem ser realizadas de forma integrada para que possam ser efetivas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A paracoccidioidomicose (PCM) é a infecção fúngica sistêmica mais prevalente no Brasil, sendo causada por inalação de conídios do gênero _Paracoccidioides sp_ . (ex.: _P. brasiliensis_ e _P. lutzii_ ). A infecção primária é geralmente assintomática e controlada com ativação da resposta imune celular, mas pode deixar focos residuais com leveduras latentes, havendo possibilidade de reativação na vigência de imunossupressão<sup>92,118,119</sup> .  
A PCM é endêmica em todo o Brasil, predominando nos estados do Sudeste, CentroOeste e Sul, com prevalência estimada de até três casos por 100.000 habitantes ao ano, acometendo preferencialmente homens que trabalham ou residem na área rural. A coinfecção PCM-HIV tem sido observada principalmente nas regiões Sudeste e Centro-Oeste do Brasil, podendo atingir cerca de 1,5% dos pacientes com aids entre as PVHA<sup>118,119</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os achados clínicos relacionados à PCM em PVHA são semelhantes aos observados nas formas agudas da PCM endêmica. Não raro, a PCM é a primeira infecção oportunista de pessoas com imunodeficiência avançada pelo HIV, a maioria dos quais com contagem de LT-CD4+ abaixo de 200 células/mm<sup>3</sup> .<sup>118</sup> A infecção pelo HIV e a consequente imunodepressão celular modificam a história natural da PCM. Em comparação à doença em imunocompetentes, os pacientes coinfectados tendem a ser mais jovens e menos envolvidos em atividades agrícolas, predominando as profissões e ambientes urbanos. A PCM oportunista evolui com maior rapidez e com presença de febre e sintomas de inflamação, devendo ser considerada como uma condição definidora de aids<sup>92,118,119</sup> .  
Por vezes, o que se observa é a sobreposição de formas clínicas (pulmonar e do sistema mononuclear fagocítico), o que parece ser provocado pela imunodepressão inicial no paciente coinfectado. Assim, casos que seriam inicialmente classificados como forma crônica (ou do tipo adulto) de PCM assumem também padrão de acometimento agudo/subagudo (ou do tipo juvenil), dificultando o entendimento diagnóstico por parte da equipe de saúde<sup>120,121</sup> .  
Pode haver desenvolvimento de lesões fúngicas disseminadas, em geral consistindo de infiltrado pulmonar retículo-nodular bilateral, linfadenomegalia, lesões cutâneas, hepatoesplenomegalia, ulcerações na mucosa oral e outras lesões viscerais menos frequentes. O diagnóstico diferencial inclui TB e outras micobacterioses, histoplasmose e linfoma.  
A mortalidade para a coinfecção PCM-HIV era maior nos primeiros relatos de casos, mas tem se observado uma tendência de queda nos últimos anos, explicada, principalmente, pela melhoria do diagnóstico e tratamento precoce em associação à TARV. De qualquer forma, ainda é comum haver dificuldades na definição precisa das formas de PCM associadas ao HIV, bem como na compreensão da sua característica oportunista e conhecimento da frequência dessa coinfecção.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O diagnóstico laboratorial em pacientes coinfectados deve ser realizado por **exame micológico direto** , a fim de identificar leveduras típicas de _Paracoccidioides_ sp. em amostra de lesões de pele, mucosa, escarro, aspirado de linfonodos e abscessos subcutâneos.  
A biópsia de lesões cutâneas, de mucosa oral e de linfonodos, com cultivo dos fragmentos de tecido e exame histopatológico, estabelece o diagnóstico de certeza.  
O cultivo micológico dessas amostras apresenta boa chance de isolar _Paracoccidioides sp._ em razão da grande quantidade de leveduras. Sangue e medula óssea dos pacientes podem ser cultivados em frascos de hemocultura convencional ou, preferencialmente, processados pelo sistema lise-centrifugação.  
As provas sorológicas têm valor presuntivo no diagnóstico e no controle pós-terapêutico, devendo incluir a pesquisa de anticorpos que reconheçam antígenos de _P. lutzii_ e do complexo _P. brasiliensis_ , considerando-se a grande variabilidade da constituição antigênica dessas espécies.  
A reação de imunodifusão dupla em gel de ágar foi recomendada como método diagnóstico por ser acessível, de fácil execução, dispensando equipamentos de custo elevado, com sensibilidade maior que 80% e especificidade maior que 90%, sendo ideal uma prova com características similares, mas com maior sensibilidade para diagnóstico da doença em todo o país 92,119.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Quadro **18** descreve o tratamento da PCM.  
**Quadro 18:** Opções terapêuticas para tratamento da PCM  
|**Apresentação**|**Tratamento**|**Duração média**|
|---|---|---|
||1ª opção: Itraconazol 200 mg/dia (2<br>cápsulas de 100 mg em dose única), VO<br>ou 200 mg (2 cápsulas de 100 mg), VO,<br>12/12 horas|9 a 18 meses|
|Leve - moderada|2ª opção: sulfametoxazol+trimetoprima<br>(400 mg+80 mg)<br>Dose: 2 comprimidos de 8/8 horas ou de<br>12/12 horas|18-24 meses<sup>1</sup>|
|Grave|Anfotericina<br>B<br>complexo<br>lipídico<br>Dose: 3a5mg/kg/dia|2 a 4 semanas (até<br>melhoraclínica)<sup>2</sup>|
||1ª opção: Anfotericina B lipossomal<br>Dose: 3mg/kg/dia|Até<br>melhora|
|Neuroparacoccidioidomicose|2ª opção: sulfametoxazol+ trimetoprima<br>80 mg/mL + 16 mg/mL, via IV<sup>3</sup><br>Dose: 2 a 3 ampolas,8/8 horas.|clínica – 2 a 4<br>semanas|  
Fonte: CGHIV/DATHI/SVSA  
1. Avaliação do estado nutricional, quadro respiratório e/ou neurológico, hipotensão, ascite.  
2.Requer tratamento de manutenção com itraconazol ou sulfametoxazol+trimetoprima.  
3. Preferencial para pacientes com quadro de insuficiência respiratória, tratamento empírico para pneumocistose ou Histoplasmose  
A solicitação de anfotericina B lipossomal ou complexo lipídio deve seguir as orientações do **Apêndice BErro! Fonte de referência não encontrada.** .  
Para as formas graves, as formulações lipídicas de anfotericina B (anfotericina B lipossomal e complexo lipídico de anfotericina B) são indicadas como medicamentos de escolha, não só por sua maior eficácia como também devido à redução de efeitos colaterais. Na indisponibilidade das formulações lipídicas, a anfotericina B desoxicolato é a alternativa, na dose de 1 mg/kg/dia (máximo de 50 mg).  
Nos casos de neuroparacoccidioidomicose em que houver contraindicação ou indisponibilidade da anfotericina B e restrição de sulfametoxazol+trimetoprima, poderá ser utilizado 200 mg/dia (2 cápsulas) de fluconazol, em associação a 2.400 mg de sulfametoxazol + 480 mg de trimetoprima (6 comprimidos), por dois meses, seguido de sulfametoxazol 1.600 mg + trimetoprima 320 mg (4 comprimidos), até o fim do tratamento.  
A melhora na condição clínica permite modificar a terapia antifúngica para via oral, indicando-se preferencialmente o itraconazol, em dosagem inicial de 400 mg/dia (4 cápsulas) até a regressão da febre e redução importante das lesões tegumentares e viscerais. A dose então é reduzida para 200 mg/dia (2 cápsulas) ou ser mantida em 400 mg/dia (4 cápsulas) por 12 a 24 meses para consolidação do tratamento. O tempo de tratamento com antifúngicos vai depender da regressão e estabilização das alterações clínicas e de imagem, e sorológica, quando disponível.  
A TARV deve ser instituída tão logo se perceba resposta ao tratamento antifúngico, atenção especial aos casos de acometimento do SNC, para os quais pode haver necessidade de se postergar o início da TARV.  
Há possibilidade de piora do quadro clínico após a introdução dos antirretrovirais, nestes casos, pode-se considerar a hipótese de SIRI e pode-se considerar a administração de corticóides.  
Interações entre antirretrovirais e antifúngicos podem ser avaliadas através do site: <u>https://interacoeshiv.huesped.org.ar/</u>  
Os parâmetros de cura englobam clínica, exames de imagem e sorologia, e devem ser monitorados para decisão sobre a interrupção do tratamento, que pode sofrer alterações no prazo, conforme cada caso.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Ao final do período de tratamento antifúngico, é recomendável manter profilaxia secundária para as pessoas com contagem de LT-CD4+ inferior a 200 células/mm<sup>3</sup> . Podem-se empregar itraconazol (100 a 200 mg/dia; 1 a 2 cápsulas de 100 mg) ou sulfametoxozol+trimetoprima 800 mg +160 mg (2 comprimidos) a cada 12 horas. Este último tem a vantagem de também atuar profilaticamente contra a pneumocistose (PCP). A profilaxia secundária deve ser mantida até a recuperação imunológica do paciente, definida como contagem de LT-CD4+ acima de 200 células/mm<sup>3</sup> pelo menos três meses.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A criptococose é micose invasiva emergente e a principal causa de meningite ou meningoencefalite fúngica em todo mundo<sup>122</sup> . Diante da sua “invisibilidade epidemiológica”, diagnóstico tardio, dificuldade de acesso ao diagnóstico laboratorial e indisponibilidade de medicamentos efetivos, a mortalidade permanece elevada<sup>123–126</sup> .  
A manifestação mais frequente e grave da criptococose em PVHA é a meningite. A maioria das vezes se trata de uma verdadeira meningoencefalite, devido ao acometimento variável do parênquima cerebral, mas na literatura médica se utiliza o termo meningite criptocócica para descrever o espectro de manifestações meningíticas ou meningoencefalíticas.  
Globalmente, as infecções oportunistas causadas por _Cryptococcus neoformans_ constituem grande risco para as PVHA, com letalidade decorrente da meningite criptocócica variando entre 13% a 73%<sup>123</sup> . Já a criptococose primária, sem evidências de fator predisponente do hospedeiro, mostra-se endêmica em áreas tropicais e subtropicais, sendo causada principalmente por _C. gattii._  
Em PVHA, a maior parte do conhecimento adquirido no manejo da criptococose tem sido resultado da experiência da criptococose causada pelo _C. neoformans_ .  
Pessoas aparentemente imunocompetentes tendem a apresentar formas pulmonares localizadas, caracteristicamente, um ou mais nódulos circunscritos<sup>127,128</sup> . Já as pessoas imunossuprimidas tendem a apresentar infiltrados intersticiais ou alveolares, usualmente difusos e acompanhados de meningite ou meningoencefalite criptocócica<sup>129</sup> . Pessoas com criptococose pulmonar grave devem ser tratadas de maneira similar aos pacientes com meningite ou meningoencefalite. Deve ser discutida abordagem cirúrgica na pessoa com criptococoma pulmonar não responsivo ao tratamento antifúngico ou naqueles com lesões pulmonares muito grandes, visando a melhorar a resposta ao tratamento antifúngico.  
A criptococose é a causa mais frequente de meningite oportunista nas PVHA.  
Os pacientes podem apresentar-se com meningite, habitualmente, de curso subagudo. As manifestações clínicas mais comuns são cefaleia, febre, mal-estar geral, náuseas e/ou vômitos, e rebaixamento do nível de consciência. Além disso, o impacto sistêmico é frequente, podendo haver envolvimento pulmonar (por exemplo, consolidação lobar, infiltrados nodulares ou intersticiais) e cutâneo (por exemplo, pápulas umbilicadas semelhantes às lesões de molusco contagioso)<sup>125,130,131</sup> .  
Sinais meníngeos nem sempre estão presentes. Entretanto, na manifestação de hipertensão intracraniana (HIC), pode haver vômitos, diplopia, confusão mental (confundidos com quadros psiquiátricos), coma e papiledema.  
Alguns fatores clínicos e laboratoriais associados a pior prognóstico na meningite criptocócica estão listados no **Quadro 19** .  
**Quadro 19:** Fatores relacionados com pior prognóstico na meningite ou meningoencefalite criptocócica  
1. Contagem de leucócitos menor que 20 células/mm<sup>3</sup> no LCR  
2. Rebaixamento do nível de consciência  
3. Hipertensão intracraniana não controlada  
4. Presença de crise convulsiva  
5. Elevada carga fúngica liquórica (ex.: titulação de aglutinação com látex superior a 1:1024 ou titulação do ensaio de fluxo lateral igual ou superior a 1:160).  
6. Neuroimagens mostrando extensão da meningite ao parênquima cerebral (ex: pseudocistos mucinosos)  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os pacientes com meningite criptocócica apresentam, geralmente, contagem de LTCD4+ abaixo de 100 células/mm<sup>3</sup> .  
O diagnóstico e o tratamento oportunos da doença criptocócica são os principais fatores relacionados à redução de mortalidade. A **punção lombar** (PL) diagnóstica deve ser sempre realizada na suspeita clínica de meningite criptocócica e na ausência de contraindicações ao procedimento.  
Recomenda-se, preferencialmente, o antígeno criptocócico por ensaio de fluxo lateral (LF-CrAg) e, alternativamente, o teste de aglutinação com látex, no líquor. A _performance_ do teste de fluxo lateral (sensibilidade maior que 98%; especificidade maior que 99%) é superior quando comparada à aglutinação do látex<sup>132</sup> .  
O LF-CrAg é um teste imunocromatográfico que permite realizar o diagnóstico de criptococose em aproximadamente 10 minutos, sem necessidade de infraestrutura laboratorial. Evidência recente demonstra valores de concordância elevados entre o ensaio de fluxo lateral realizado no plasma ou soro e aquele realizado em sangue total (polpa digital)<sup>133</sup> .  
A **Figura 1** orienta sobre a coleta do LF-CrAg para rastreio e diagnóstico de criptococose.  
A coloração com tinta da China também confirma a doença, mas apresenta sensibilidade em amostra de LCR entre 60% a 90%, de acordo com a _expertise_ do técnico e da carga fúngica. Por sua vez, a cultura liquórica também confirma o diagnóstico, mas o resultado tarda em torno de sete dias<sup>92</sup> .  
**Além disso, indivíduos com LF-CrAg reagente no soto ou sangue periférico devem ser investigados para meningite com punção lombar, independente da sintomatologia**<sup>134</sup> **.** PVHA com histórico prévio de criptococose podem persistir com teste antigênico positivo, portanto, a presença de manifestações compatíveis com meningite criptocócica deve ser avaliada criteriosamente.  
As PVHA com histórico prévio de criptococose devem ser avaliadas quanto aos sinais e sintomas neurológicos e, se necessário, encaminhadas para realização de punção lombar com avaliação liquórica (exame micológico direto e cultura) e hemocultura para verificar a fungemia.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Após a confirmação diagnóstica, incluindo meningite criptocócica subclínica, o tratamento convencional recomendado deverá ser instituído. O tratamento é dividido em três fases: indução, consolidação e manutenção, conforme **Quadro 20.**  
**Quadro 20:** Esquemas terapêuticos para meningite criptocócica  
|**Fase**<br>**do**<br>**tratamento**|**Esquema para tratamento**|**Duração**|
|---|---|---|
|**Indução**|Anfotericina B lipossomal: 3 mg/kg;dia, IV<br>+<br>Flucitosina: 100 mg/kg/dia, VO, 6/6h|Pelo menos 2 semanas|
||Fluconazol: 400 mg a 800 mg/dia, VO ou IV||
|**Consolidação**|(4 a 8 cápsulas/dia ou 2 a 4 frascos de solução<br>injetável)|Pelo menos 8 semanas|
|**Manutenção**|Fluconazol: 200 mg/dia(2 cápsulas),VO|Pelo menos 6 a 12 meses|  
Na indisponibilidade ou contraindicação dos medicamentos preferenciais, considerar:  
- Se anfotericina B lipossomal não estiver disponível, utilizar o complexo lipídico de anfotericina B: 5 mg/kg/dia, por via intravenosa.  
- Se anfotericina B lipossomal ou complexo lipídico de anfotericina B e flucitosina não estiverem disponíveis, utilizar anfotericina B desoxicolato 1 mg/kg/dia associada a fluconazol 1.200 mg/dia oral (6 cápsulas de 200 mg) ou injetável (6 frascos de solução injetável), conforme disponibilidade (por pelo menos por 2 semanas) e considerar algumas medidas de prevenção e monitoramento da toxicidade associada à anfotericina B desoxicolato **(Apêndice B)**  
- Se houver contraindicação ou indisponibilidade de anfotericina B desoxicolato, anfotericina B lipossomal e complexo lipídico de anfotericina B, deve-se utilizar flucitosina 100 mg/kg/dia, VO, associada a fluconazol 1.200 mg/dia (6 cápsulas de 200 mg) ou injetável (6 frascos de solução injetável), conforme disponibilidade, por pelo menos 2 semanas.  
- Se houver indisponibilidade de formulação lipídica de anfotericina B **e** dificuldade para monitoramento laboratorial de toxicidade medicamentosa: utilizar anfotericina B desoxicolato 1 mg/kg/dia associada a flucitosina 100 mg/kg/dia, durante uma semana, seguidas de fluconazol 1.200 mg/dia oral (6 cápsulas de 200 mg) ou injetável (6 frascos de solução injetável), conforme disponibilidade, durante pelo menos mais uma semana (usar pelo menos por 2 semanas).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O prolongamento da fase de indução deve ser considerado em pacientes comatosos ou com deterioração clínica, HIC persistentemente elevada, cultura liquórica positiva após as duas semanas de terapia e/ou achados neuroradiológicos atribuídos à presença da criptococose no parênquima cerebral (por exemplo, pseudocistos mucinosos).  
A fase de manutenção deve ser mantida até a contagem de LT-CD4 estiver acima de 200 células/mm<sup>3</sup> e a carga viral do HIV indetectável.  
As formulações lipídicas de anfotericina apresentam eficácia micológica similar à anfotericina desoxicolato, porém com menos reações infusionais e menor toxicidade renal, hipocalemia e anemia. Quando disponível, constitui a melhor alternativa terapêutica, particularmente em pacientes com injúria ou insuficiência renal ou risco de apresentá-las.  
O manejo agressivo e adequado da HIC é fundamental. A aferição da pressão de abertura liquórica deve ser sempre realizada, preferencialmente por raquimanometria. Algumas medidas para a abordagem da HIC estão descritas no **Quadro 21** .  
**A HIC não controlada é responsável pela maioria das mortes por meningite ou meningoencefalite criptocócica nas duas primeiras semanas após início do tratamento. Portanto, a pressão de abertura liquórica deve ser sempre avaliada** .  
**Quadro 21:** Manejo da hipertensão intracraniana secundária a meningite ou meningoencefalite criptocócica  
- Se a pressão de abertura liquórica for superior a 25 cmH2O e estiverem presentes sinais de HIC, realizar punção lombar e retirar 20 a 30mL de líquor. Segundo evolução clínica, pode ser necessária mais de uma punção lombar diária.  
- A punção lombar de alívio deve ser repetida diariamente até a estabilização da pressão intracraniana.  
- Na presença de pressão intracraniana normal em duas aferições consecutivas, recomenda-se a punção lombar semanal para monitoramento micológico da resposta terapêutica.  
- Se a pressão intracraniana se mantiver persistentemente elevada após 7 a 10 dias de punção lombar diária, considerar a abordagem neurocirúrgica para derivação liquórica (usualmente, derivação lombar externa ou lombo-peritoneal).  
- Manitol, acetazolamida e corticoides não devem ser utilizados no manejo de HIC secundária a criptococose.  
Fonte: DATHI/SVSA/MS.  
O início imediato da TARV não é recomendado em PVHA com meningite/meningoencefalite criptocócica, pelo risco de SIRI. A TARV deve ser iniciada entre quatro a seis semanas após o início do tratamento antifúngico.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A imunossupressão observada na infecção pelo HIV pode ser dramaticamente melhorada pela TARV. Diferente do observado na maioria de doenças oportunistas, o início precoce da TARV se mostrou deletério na meningite ou meningoencefalite criptocócica.  
Recomenda-se o **início da TARV entre 4 e 6 semanas após o início do tratamento antifúngico** , desde que exista melhora neurológica inequívoca, resolução da hipertensão intracraniana e cultura negativa para fungos no líquor. Dessa forma, o risco de desenvolver SIRI reduz drasticamente<sup>134,135</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A estratégia de rastreio e tratamento preemptivo de doença criptocócica tem como principal objetivo a redução na mortalidade relacionada meningite criptocócica<sup>134,136</sup> .  
PVHA com contagem de LT-CD4 ≤ 200 células/mm<sup>3</sup> e sem histórico prévio de meningite criptocócica tem indicação da coleta do LF-CrAg para rastreio<sup>1</sup> :  
Uma vez excluída doença criptocócica assintomática disseminada (por meio de exames clínicos e encaminhamento para coleta de PL), deve ser instituído tratamento preemptivo:  
Fluconazol 800 mg/dia (8 cápsulas/dia), durante duas semanas, seguido de  
Fluconazol 400 mg/dia (4 cápsulas/dia), durante oito semanas.  
A TARV pode ser iniciada após as duas primeiras semanas de tratamento antifúngico  
(119).  
> 1 Para rastreio da doença criptócica em PVHA assintomáticas, quando disponível e oportuno, optar por amostra de soro.  
<!-- Start of picture text -->
Pessoas vivendo com HIV<br>‘Sem indicacdo<br>para criptococasede rastreiousando o Nao PossuicéluasimL? contagem<br>Le-CrAg de LT-cD4>200<br>| sim<br>Ndo_/ Possuiistorico sim<br>previo de<br>\ meningte?<br>Niaee Possuineuroibgicos?sitomasim‘ Nao —Possulsintomasneuroiogicos?—* sim<br>Realzar LF-CrAg Realzar LF-CrAg eseventeub a Realizar hemocultura<br>(pungéo dita) Sales coe  puncio lombar?<br>oe = es = a= i<br>Iniciar TARV Realzarhemocutura Invstiga otras Realzarhemocutura beccaar inidarotratamventoaa eptococose<br>|  punclo lombart ae © pungao lombar! oportunistas* eal<br>(oem | Cm] mm |<br>: Iniciar<br>breamptvo@hemsem2  eonsemanas TARV IniciarSecRt 0opieciae tratamento investigaroutrasrichesinfecgbes0 ratamento IniciarLaectanir nedteen0 trat a mento<br>meningte eae meningite<br><!-- End of picture text -->  
**Figura 1:** Rastreio e tratamento preemptivo de doença criptocócica em PVHA  
LF-CrAg - teste rápido para detecção do antígeno criptocócico; TARV - Terapia antirretroviral  
- 1 – Hemocultura para verificar fungemia e encaminhar líquor para o laboratório para realização de LF-CrAg, exame micológico direto e cultura. 2 – Manter fluconazol até recuperação da imunidade e observar o desenvolvimento de sinais e sintomas. Caso ocorram, realizar punção lombar e  
- encaminhar o líquor para o laboratório.  
- 3– Hemocultura para verificar fungemia e encaminhar líquor para o laboratório para realização exame micológico direto e cultura 4– Manter fluconazol até recuperação da imunidade

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A reconstituição imune é um dos objetivos do manejo da criptococose em pessoas imunossuprimidas. Contudo, em algumas situações, observa-se um quadro clínico e/ou radiológico de caráter inflamatório exacerbado, chamado de síndrome inflamatória de reconstituição imune (SIRI), associada ao início da TARV em PVHA.  
A SIRI pode se apresentar de duas formas<sup>137</sup> :  
1. Forma “desmascarada” da infecção criptocócica latente, caracterizada pela apresentação da doença criptocócica, semanas ou meses depois do início da TARV.  Esta forma de SIRI é de difícil diferenciação com a doença oportunista propriamente dita, já que a presença de ambas pode ocorrer ainda com contagens de linfócitos T-CD4+ < 200 células/mm<sup>3</sup> .  
2. Forma “paradoxal”, mais frequentemente descrita. Caracteriza-se pela piora ou aparecimento de novos sintomas ou sinais, em pacientes com diagnóstico prévio de doença criptocócica<sup>138,139</sup> .  
Os fatores de risco para a presença de SIRI associada à criptococose em PVHA são as seguintes: carga fúngica inicial elevada (fungemia, títulos elevados do antígeno criptocócico), pobre perfil inflamatório inicial (demonstrada pelos parâmetros do líquor); pobre resposta inicial, mediada por citocinas pro inflamatórias séricas; contagens muito baixos de linfócitos T-CD4+ (<50 células/μl); resposta imunológica e virológica rápida à TARV; e início precoce da TARV (< 2 semanas depois do diagnóstico da meningite criptocócica)<sup>137,138,140,141</sup> .  
As manifestações clínicas de SIRI usualmente se observam entre 1 a 2 meses depois de iniciada a TARV<sup>137,140,141</sup> . Os pacientes podem apresentar meningite com ou sem hipertensão intracraniana e criptococomas são infrequentes<sup>138,140,141</sup> .  
Nos casos de SIRI “paradoxal”, as culturas são consistentemente negativas, situação que permite diferenciar SIRI da recidiva da doença<sup>140,142</sup> . Até receber os resultados das culturas e a depender do status clínico do paciente, pode ser iniciada terapia antifúngica combinada, devendo ser reavaliada a necessidade de mantê-la<sup>142</sup> .  
O tratamento da SIRI associada à meningite criptocócica não está plenamente definido, mas corticoides sistêmicos podem ser usados nos casos sintomáticos. O tipo (por exemplo, prednisona ou dexametasona) e a via de administração (por exemplo, oral ou endovenoso) do corticoide, dependerá da avaliação de cada caso. Nos casos mais graves, recomenda-se um tempo de tratamento mínimo de um mês.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A toxoplasmose é uma zoonose causada pelo protozoário _Toxoplasma gondii_ . O acometimento cerebral se dá, majoritariamente, pela reativação do cisto latente do protozoário, principalmente nas PVHA com comprometimento imunológico importante (LT-CD4 abaixo de 200 células/mm<sup>3</sup> ). A prevalência de anticorpos anti-toxoplasmose positivos e da toxoplasmose em PVHA tem ampla variação entre as regiões geográficas<sup>143,144</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A toxoplasmose é a causa mais comum de lesões expansivas cerebrais em PVHA<sup>145,146</sup>  
A apresentação clínica é variada, de acordo com a topografia das lesões cerebrais, e, habitualmente, tem curso subagudo. As manifestações clínicas mais comuns são cefaleia, sinais focais (hemiparesia, disfasia e outras alterações motoras). Febre, convulsões e alteração do estado mental podem estar presentes<sup>144</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
PVHA com toxoplasmose cerebral apresentam, geralmente, contagem de LT-CD4+ abaixo de 200 células/mm³.  
O diagnóstico definitivo de toxoplasmose cerebral requer confirmação histopatológica.  
Na prática clínica diária, o diagnóstico presuntivo se estabelece com a presença de manifestações clínicas e radiológicas compatíveis, associadas à adequada resposta clínicoradiológica, após 10 a 14 dias de tratamento antiparasitário. De maneira geral, a melhora clínica precede a resposta radiológica. Ressalta-se que o exame de imagem deve ser antecipado se houver deterioração clínica.  
Recomenda-se, portanto, que todas as PVHA que apresentem sinais clínicos compatíveis e exame de imagem sugestivo de toxoplasmose cerebral sejam tratadas empiricamente para essa doença.  
Tipicamente, os pacientes com toxoplasmose cerebral apresentam, na tomografia computadorizada, uma ou mais lesões cerebrais, hipodensas, com realce anelar ou nodular após a injeção do contraste, associadas a edema perilesional. Podem se localizar, preferencialmente, nos gânglios da base, mas qualquer topografia é possível.  
A tomografia computadorizada (TC) de crânio com e sem contraste intravenoso é o exame de imagem preferencial para o diagnóstico de toxoplasmose cerebral, em razão da sua maior disponibilidade na rede.  
Embora menos disponível, a Ressonância Magnética é mais sensível que a TC para identificar lesões pequenas ou localizadas em fossa posterior. Sua utilização para diagnóstico de toxoplasmose cerebral é reservada para casos que apresentem manifestações clínicas de lesões focais, porém com TC de crânio normal<sup>147</sup> .  
Ressalta-se, no entanto, que os exames de imagem, TC ou RM, apesar de serem sensíveis para identificar lesões expansivas cerebrais, apresentam especificidade baixa, sendo difícil diferenciar a toxoplasmose cerebral de outras doenças, como linfoma e tuberculoma.  
O achado de DNA de _Toxoplasma gondii_ mediante técnicas de PCR no LCR apresenta sensibilidade moderada (aproximadamente 50%), especificidade elevada (superior a 95%) e valor preditivo negativo moderado. Portanto, um teste positivo confirma a presença de toxoplasmose, mas um teste negativo não exclui o diagnóstico. Se o PCR estiver disponível e não existirem contraindicações para realizar punção liquórica, o teste pode ser solicitado.  
A sorologia IgG anti- _T. gondii_ é reagente em mais de 90% a 95% dos casos de toxoplasmose cerebral. Uma sorologia IgG anti- _T. gondii_ não reagente torna o diagnóstico menos provável, mas não o exclui, devendo ser mantido o tratamento empírico até definição diagnóstica.  
**A avaliação neurocirúrgica, visando a biópsia cerebral, deve ser solicitada nas seguintes situações:**  
1. Presença de lesão ou lesões expansivas e ausência de melhora clínica e radiológica 10 a 14 dias após o tratamento antiparasitário;  
2. Elevado índice de suspeita de diagnóstico alternativo (ex.: paciente com lesão expansiva única na RM e sorologia IgG anti- _T. gondii_ não reagente; paciente com lesão ou lesões expansivas, contagem elevada de LT-CD4+ e CV-HIV indetectável).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os esquemas de escolha consistem nas associações apresentadas no Quadro 22<sup>145,148–150</sup> .  
**Quadro 22:** Tratamento da toxoplasmose cerebral  
||**Esquemas**||**Tempo de**<br>**tratamento**|
|---|---|---|---|
|**Sulfadiazina,**VO, a<br>cada seis horas, nas<br>seguintes doses:<br>Abaixo de 60 kg: 1.000<br>mg (2 comprimidos de<br>500 mg)|**+** **pirimetamina**200 mg (8<br>comprimidos de 25 mg) VO<br>no primeiro dia, seguida das<br>doses VO:<br>Abaixo de 60 kg: 50 mg/dia (2<br>comprimidos de 25 mg)|**+** **ácido folínico**10<br>mg/dia VO<br>**OU**|6 semanas|
|60 kg ou mais: 1.500<br>mg (3 comprimidos de<br>500 mg)|60 kg ou mais: 75 mg/dia (3<br>comprimidos de 25 mg)|||
|**Sulfametoxazol + trim**<br>por dia, VO ou IV.|**etoprima**: 25 mg/kg de sulfam|etoxazol, duas vezes|6 semanas|  
Fonte: DATHI/SVSA/MS  
A resposta clínica e radiológica, assim como a mortalidade, não apresenta diferenças significantes, quando comparados os esquemas contendo sulfametoxazol + trimetoprima e os esquemas com pirimetamina. Adicionalmente, a descontinuação do tratamento devido à  
toxicidade foi significativamente menor com sulfametoxazol + trimetoprima (7,3%), versus sulfadiazina + pirimetamina + ácido folínico (30,5%) ou clindamicina + pirimetamina + ácido folínico (13,7%).  
Em casos de alergia ou intolerância à sulfa, recomenda-se o uso de clindamicina 600 mg via oral (2 cápsulas de 300 mg), a cada seis horas + pirimetamina + ácido folínico, ambos nas mesmas doses descritas acima, durante seis semanas. Nesse caso, um esquema adicional de profilaxia para PCP deve ser prescrito. Pacientes mais graves e/ou com lesões extensas podem precisar de períodos mais prolongados de tratamento.  
Após o período de seis semanas de tratamento da toxoplasmose cerebral, deve-se ser prescrita a terapia de manutenção, usualmente com a metade da dose de sulfadiazina, sulfametoxazol + trimetoprima, clindamicina e pirimetamina, a depender do esquema escolhido. Neste cenário, o uso de sulfametoxazol + trimetoprima mostra vantagens posológicas com similar eficácia aos esquemas contendo pirimetamina<sup>151</sup> .  
Indica-se o uso de **corticoides** nos casos de edema cerebral difuso e/ou intenso efeito de massa (desvio de linha média, compressão de estruturas adjacentes). Não se indica o uso profilático de anticonvulsivantes.  
A TARV pode ser iniciada nas duas primeiras semanas de tratamento antiparasitário.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A PCP é uma infecção oportunista causada pelo fungo _Pneumocystis jirovecii._ A despeito da redução na incidência, após a introdução da TARV e da profilaxia primária, ainda segue como importante causa de pneumonia, principalmente nas pessoas com comprometimento do sistema imunológico<sup>152–154</sup> .  
A PCP é a causa mais comum de doença pulmonar oportunista em PVHA com contagem de LT-CD4+ abaixo de 200 células/mm³.  
O início dos sintomas é tipicamente insidioso, sendo as manifestações clínicas mais comuns: febre, **tosse seca** e **dispneia progressiva** . Fadiga, desconforto torácico e perda de peso também podem estar presentes. Tosse com expectoração purulenta é uma manifestação rara de PCP e, portanto, sua presença deve levantar suspeita de infecção bacteriana secundária (pneumonia bacteriana)<sup>154,155</sup> .  
Os principais achados ao exame físico incluem taquipneia, taquicardia e ausculta pulmonar normal ou com estertores finos ao final da expiração. Sibilos, sinais de condensação pulmonar ou derrame pleural são raramente encontrados. O exame físico pode ser normal.  
O achado radiográfico mais típico de PCP é o infiltrado intersticial peri-hilar e simétrico. Pneumatoceles e pneumotórax também podem ser observados. Ressalta-se que a radiografia de tórax pode ser normal em até um quarto dos casos de PCP; nessa situação, a TC pode revelar atenuação pulmonar em vidro fosco<sup>156,157</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Não há características clínicas ou imagem radiológica específicas de PCP, sendo seu diagnóstico geralmente presuntivo, baseado em dados clínicos, laboratoriais e de imagem compatíveis. O **Quadro 23** reúne critérios sugestivos de PCP.  
**Quadro 23:** Achados sugestivos de pneumocistose  
1. Contagem de LT-CD4+ abaixo de 200 células/mm<sup>3</sup> ou sinais clínicos de imunodepressão grave, como candidíase oral  
2. Dispneia progressiva aos esforços 3. Presença de febre, taquipneia e/ou taquicardia ao exame físico 4. Radiografia de tórax normal ou infiltrado pulmonar difuso, peri-hilar, simétrico 5. Desidrogenase láctica sérica elevada 6. Hipoxemia em repouso ou após esforço 7. Ausência de uso ou utilização irregular de profilaxia para PCP  
Fonte: DATHI/SVSA/MS.  
O diagnóstico definitivo é realizado pela identificação do agente por meio das colorações de azul de toluidina, Grocott, Giemsa ou técnica de imunofluorescência a partir de espécimes respiratórios. A pesquisa direta do agente oportunista em amostras de escarro espontâneo ou induzido geralmente é pouco sensível para PCP. Amostras biológicas obtidas por broncoscopia com lavado broncoalveolar e biópsia pulmonar transbrônquica elevam a precisão do diagnóstico etiológico.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A escolha do esquema terapêutico é guiada pela gravidade clínica do paciente. Assim, para fins terapêuticos, classifica-se a pneumonia em leve a moderada ou moderada a grave.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Os esquemas indicados incluem medicamentos administrados preferencialmente por VO.  
A primeira escolha é a associação **sulfametoxazol + trimetoprima, (SMX 75 a 100 mg + TMP 15 a 20 mg/kg/dia), IV ou VO, a cada seis ou oito horas, por 21 dias** .  
O esquema alternativo para casos de intolerância à sulfa é clindamicina 300 mg, por via oral, a cada seis horas + primaquina 15 a 30 mg (1 a 2 comprimidos de 15 mg), por via oral uma vez ao dia, por 21 dias.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Recomendam-se esquemas administrados preferencialmente por via IV. A mudança de via de administração de intravenosa para oral deve ser realizada quando ocorrer melhora clínica.  
<mark>O esquema de escolha é a associação</mark> **<mark>sulfametoxazol + trimetoprima (5 mg/kg de</mark> trimetoprima), IV, a cada seis ou oito horas. O tempo total de tratamento é de 21 dias** .  
Clindamicina 600 mg IV a cada seis ou oito horas, conforme disponibilidade local, + primaquina 15 a 30 mg (1 a 2 comprimidos de 15 mg), VO, uma vez ao dia é o principal esquema alternativo em caso de intolerância à sulfa.  
A associação de corticoides ao tratamento de PCP moderada a grave apresentou redução importante na mortalidade.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Indica-se a associação de corticoides ao tratamento de PCP nos casos de **PaO2 < 70 mmHg em ar ambiente ou gradiente alvéolo-capilar > 35 mmHg:** prednisona 40 mg (2 comprimidos de 20 mg), via oral, duas vezes ao dia por cinco dias, reduzida à metade a cada cinco dias, até completar os 21 dias de tratamento. Alternativamente, pode-se utilizar metilprednisolona por via intravenosa equivalente a 75% da dose da prednisona.  
Suporte ventilatório não invasivo (pressão positiva contínua nas vias aéreas - CPAP) ou invasivo por meio de intubação orotraqueal pode ser necessário em casos de insuficiência respiratória. A necessidade de suporte ventilatório está associada a um pior prognóstico, com mortalidade de aproximadamente 60%.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A profilaxia secundária deverá ser instituída após tratamento e deverá ser realizada com **sulfametoxazol+trimetoprima, VO, na dose de 800 mg + 160 mg (2 comprimidos) três vezes por semana ou 400 mg + 80 mg/dia (1 comprimido)** até alcançar LT-CD4+ acima de 200 células/mm³ por pelo menos três meses.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O CMV é um DNA vírus de fita dupla da família dos herpes vírus, permanece em estado latente após a infecção primária. O risco de reativação da doença se eleva em pessoas com avançada imunossupressão (contagem LTCD4+ abaixo de 100 células/mm³). A incidência de casos de CMV teve decréscimo importante após a introdução da TARV<sup>158,159</sup> .  
Doenças em órgãos causadas pelo CMV ocorrem, usualmente em pessoas com LTCD4 < 50 células/mm<sup>3</sup> , que frequentemente não estão em uso de TARV ou estão em falha virológica.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O diagnóstico precoce da infecção pelo HIV e adesão à TARV são importantes fatores para prevenção da reativação da doença citomegálica.  
Os principais sítios de infecção são retina e aparelho digestivo, podendo ser acometidos também pulmões, fígado, vias biliares e SNC (demência, ventriculoencefalite e polirradiculomielite)<sup>160–163</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A retinite por CMV permanece como uma causa importante de morbidade ocular e um dos principais agentes causadores de cegueira em pacientes com aids<sup>164</sup> .  
Os sintomas dependem da localização e grau de comprometimento retiniano. De maneira geral, o comprometimento ocular inicia-se em um dos olhos; porém, sem tratamento sistêmico específico ou reconstituição imune, pode se estender ao olho contralateral. Apresentações clínicas mais comuns incluem escotomas, redução da acuidade visual e, menos frequentemente, perda visual súbita.  
O diagnóstico é clínico e baseia-se no aspecto da lesão retiniana, bem como em dados clínicos e laboratoriais de imunodepressão avançada. Recomenda-se fundoscopia sob dilatação pupilar para a detecção de lesões periféricas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
As manifestações clínicas de citomegalovirose do aparelho digestivo são inespecíficas e podem se assemelhar a outras doenças oportunistas. Os sítios mais comuns são esôfago e cólon. A apresentação clínica depende da topografia da lesão Figura 2.  
<!-- Start of picture text -->
Ulceras orofaringeas dolorosas ae<br>Dor retrostemal au epigéstrica Colite<br>em queimocéo e, roramente, “= bre baixe, mabest<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O diagnóstico é sugerido pelo aspecto endoscópico de ulceração clássica da mucosa, mediante biópsia identificando células com inclusão intranuclear (“olhos de coruja”), bem como dados clínicos e laboratoriais de imunodepressão avançada<sup>165,166</sup> . Testes para detectar viremia (PCR ou antigenemia), quando disponíveis, não são bons preditores de doença ativa ou recorrência em PVHA. Não se recomenda tratar viremia na ausência de evidência de lesão orgânica. Resultados negativos da antigenemia ou PCR plasmático não excluem a doença por CMV em órgãos.  
A presença de anticorpos para CMV não é útil no diagnóstico, embora IgG negativo indique pouca probabilidade de ser o CMV o causador da doença investigada.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O **Quadro 24** descreve as opções terapêuticas preferenciais apontadas pela literatura. A escolha do antiviral depende do sítio<sup>167–171</sup> de acometimento da infecção pelo CMV e, além disso, da disponibilidade e pactuação local.  
**Quadro 24:** Opções terapêuticas para infecções pelo citomegalovírus  
|**SÍTIO DE**<br>**ACOMETIMENTO**|**MEDICAMENTO**|**DOSE/TEMPO DE**<br>**TRATAMENTO**|**OBSERVAÇÕES**|
|---|---|---|---|
|Lesões da retina|Ganciclovir<sup>1</sup>|5 mg/kg a cada doze horas,<br>IV, durante14 a 21dias|Seguir<br>com<br>profilaxia<br>secundária.|
||Ganciclovir<sup>1</sup>|5 mg/kg a cada doze horas,<br>IV, durante 3 a 6 semanas, até<br>resolução dos sintomas||
|Aparelho digestivo|Valganciclovir|900 mg a cada 12 horas, VO,<br>durante 3 a 6 semanas, até<br>resolução dos sintomas|Doença moderada e sem<br>intolerância<br>a<br>medicamentos<br>por<br>via<br>oral.|
|Sistema nervoso<br>central ou periférico<br>**PROFILAXIA SECU**|Ganciclovir<sup>1</sup><br>**NDÁRIA(retinite)**|5 mg/kg a cada doze horas,<br>IV,<br>até<br>resolução<br>dos<br>sintomas|Quando<br>disponível,<br>avaliar PCR DNA-CMV<br>no<br>líquor<br>e<br>manter<br>tratamento<br>até<br>clareamento<br>do<br>líquor<br>(PCR negativo)<sup>2</sup>.<br>|
|Esquema com:|Valganciclovir|900 mg, 1 vez ao dia, VO|Manter até contagem de<br>CD4<br>abaixo<br>de<br>100<br>células/mm<sup>3</sup>e CV-HIV|
||Ganciclovir|5 mg/kg, 1 vez ao dia, 5 vezes<br>na semana,IV|indetectável por período<br>superior a3meses.|  
Fonte: adaptado de EACS, 2022  
1. Atentar para os eventos adversos hematológicos do ganciclovir (neutropenia)  
> 2 Considerando a elevada morbimortalidade desse agravo, orienta-se acompanhamento com especialista,  
O foscarnet é uma opção terapêutica alternativa para o tratamento do CMV com comprometimento do aparelho digestivo ou do sistema nervoso (central ou periférico), porém não possui registro ativo no Brasil.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A candidíase orofaríngea e/ou esofágica é comum entre as PVHA, geralmente, em pessoas com contagem de LT-CD4+ inferior a 200 células/mm³.  
O principal agente da candidíase é a _Candida albicans_ . O sintoma mais comum de **candidíase orofaríngea** é o aparecimento de placas removíveis esbranquiçadas. Pode se apresentar também como queilite angular ou pápulas eritematosas na mucosa<sup>172,173</sup> .  
Os sintomas típicos de **candidíase esofágica** incluem dor retroesternal difusa, disfagia e/ou odinofagia, normalmente sem febre. A candidíase oral está presente na grande maioria dos casos e, geralmente, os pacientes apresentam LT-CD4+ ainda mais baixos (inferiores a 100 células/mm³).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O diagnóstico de candidíase oral e/ou esofágica é clínico, sendo a cultura de material dessas regiões pouco útil em razão da presença do fungo como comensal dessas mucosas.  
A endocospia digestiva alta é indicada para casos que apresentem persistência de sintomas após tratamento antifúngico, para investigação de outras causas de esofagite.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O tratamento de candidíase orofaríngea e esofágica está descrito no **Quadro 25** .  
**Quadro 25** : Tratamento da candidíase orofaríngea e esofágica  
**CANDIDÍASE OROFARÍNGEA**<sup>174,175</sup>  
Formas leves ou moderadas podem ser tratadas com fluconazol 100 mg/dia por 7 a 14 dias.  
Tratamento tópico pode ser realizado como alternativa com 5 mL de nistatina suspensão oral: gargarejar e engolir 4 a 5 vezes ao dia.  
Dá-se preferência ao fluconazol para formas mais acentuadas de candidíase, em razão da menor recidiva.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O tratamento de escolha para candidíase esofágica é fluconazol 200 a 400 mg/dia (2 a 4 cápsulas de 100 mg), VO, ou 400 mg/dia (2 frascos de solução injetável), IV, nos casos de disfagia importante.  
Ressalta-se que a grande maioria dos casos de candidíase esofágica responde clinicamente em 7 a 14 dias de tratamento antifúngico sistêmico.  
Tratamento alternativo, para casos refratários ao fluconazol, pode ser realizado com anidulafungina 200 mg/dia (2 frascos-ampola), IV, em dose única, por 7 a 14 dias<sup>176</sup> , ou complexo lipídico de anfotericina B 5 mg/kg/dia, IV*.  
Na ausência de resposta clínica após esse período, deve-se levantar a suspeita de um diagnóstico alternativo para o sintoma esofágico.  
Fonte: CGHIV/DATHI/SVSA  
*A depender da disponibilidade do medicamento a ser ofertado.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A histoplasmose no Brasil é causada pelo fungo dimórfico _Histoplasma capsulatum_ , cuja infecção se dá por inalação de propágulos (microconídios) do microrganismo presentes no solo, principalmente quando enriquecido com fezes de aves e morcegos<sup>177</sup> .  
A doença pode ocorrer por infecção primária ou reativação endógena e sua apresentação clínica varia de acordo com o grau de comprometimento imunológico e da carga fúngica a que o indivíduo se expôs<sup>178</sup> . Em áreas endêmicas, a incidência anual entre as PVHA é de 25%<sup>179</sup> . Nestes pacientes, a histoplasmose pode se apresentar com manifestações graves, rapidamente progressivas e fatais, com disseminação para qualquer órgão, requerendo agilidade no seu diagnóstico e tratamento<sup>180</sup> .  
É uma doença negligenciada e comumente confundida com tuberculose (TB), não sendo infrequente a ocorrência conjunta dessas patologias (cerca de 20%) sendo pertinente a investigação de ambas as doenças, principalmente em PVHA<sup>181–183</sup> . Histoplasmose disseminada é uma das mais frequentes infecções oportunistas em PVHA nas Américas. É responsável por 5 a 15% das mortes relacionadas a aids anualmente, nesta região<sup>184</sup> . No Brasil, as principais áreas endêmicas são observadas nas regiões Nordeste, Centro-Oeste e Sudeste. Ceará, Goiás, Rio de Janeiro, Rio Grande do Norte e Rio Grande do Sul são os estados com maior frequência de casos reportados na literatura<sup>185–187</sup> .  
A contagem de LT-CD4+ abaixo de 150 células/mm<sup>3</sup> é o principal fator de risco para apresentação de histoplasmose na sua forma disseminada progressiva.  
Os sintomas da histoplasmoses disseminada progressiva, forma clínica mais comum em PVHA, são inespecíficos, entre eles febre alta, associada a adinamia, anorexia e perda de peso, além de tosse, diarreia e vômito, que podem progredir em semanas<sup>188,189</sup> .  
A pneumonia ocorre com frequência, sendo o infiltrado pulmonar retículo-nodular difuso o achado radiológico mais característico<sup>180</sup> . O tropismo do fungo pelas células do sistema fagocítico mononuclear é o responsável pela disfunção de fígado e medula óssea e aumento de baço comumente encontrados na forma disseminada<sup>190</sup> .  
O comprometimento do SNC é menos frequente. Casos de meningoencefalite podem ocorrer em até 10% dos casos, e as alterações citobioquímicas do líquor são similares às alterações encontradas em meningoencefalite por TB<sup>191</sup> .  
Ao exame físico, observa-se palidez, emagrecimento, hepatomegalia e/ou esplenomegalia e lesões cutaneomucosas. As manifestações cutâneas são caracterizadas por rash, úlceras, lesões eritematosas, pápulas, nódulos e o acometimento oral por ulcerações, lesões nodulares e verrucosas. As lesões cutaneomucosas são provavelmente consequência da disseminação fúngica para esses órgãos, e representam, uma expressão tardia da evolução da doença e estão associadas com maior mortalidade<sup>178,180,192</sup> .  
Exames laboratoriais revelam bicitopenia ou pancitopenia, elevação de transaminases (com TGO até 3 vezes maior que a TGP), fosfatase alcalina, gama glutamil-transferase (GGT), desidrogenase láctica (LDH – com níveis superiores a 1.000 UI/L), proteína C reativa e ferritina, que apesar de inespecíficos, num contexto de pouco recursos diagnósticos, são muito sugestivos de histoplasmose disseminada e podem ajudar na tomada de decisão terapêutica<sup>177,186</sup> . A mensuração da LDH pode ser usada como um marcador biológico associado a febre para rastrear PVHA suspeitos de histoplasmose e realizar investigação laboratorial direcionada, permitindo o início precoce do tratamento<sup>188,193</sup> .  
Quadros de grave fungemia, com hipotensão e coagulação intravascular disseminada, insuficiência renal e insuficiência respiratória aguda são mais usuais em pacientes com aids e acometem 10 a 20% dos casos<sup>178</sup> . A histoplasmose, como síndrome de reconstituição imune, pode surgir semanas após o início de TARV, sendo, porém, de ocorrência pouco frequente<sup>184</sup> .  
Recaídas da histoplasmose disseminada podem ocorrer em PVHA e apresentam altas taxa de mortalidade, o principal fator associado às recaídas é a falta de adesão à TARV<sup>182</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Apesar da existência há anos de testes para detecção de antígeno com elevada sensibilidade (95%) para as formas disseminadas dessa micose<sup>183</sup> , o diagnóstico da histoplasmose no Brasil ainda é mais comumente realizado por métodos de baixa sensibilidade, como a pesquisa em lâmina corada (30% de sensibilidade) de aspirado de medula óssea ou creme leucocitário  
Desde 2020, a Organização Mundial da Saúde recomenda a detecção de antígenos polissacarídeos de _H. capsulatum_ como principal método para o diagnóstico da histoplasmose disseminada em PVHA. Estes testes podem ser realizados em amostras de urina ou sangue, através de ELISA<sup>186</sup> , e mais recentemente por meio do teste imunocromatográfico por fluxo lateral (LFA)<sup>181</sup> . São métodos diagnósticos rápidos, pouco invasivos e que permitem uma tomada de decisão precoce quanto ao tratamento. Têm uma alta performance analítica, onde a sensibilidade geral é de 95% e a especificidade de 97%. São testes que reduzem o tempo do diagnóstico, e por conseguinte a mortalidade relacionada a esta micose<sup>184</sup> . Reações cruzadas  
podem ocorrer, principalmente com blastomicose (micose que não existe no Brasil) e paracoccidioidomicose<sup>194</sup> . No Brasil, o teste ainda não está disponível no Sistema Único de Saúde (SUS), uma vez que ainda não foi avaliado pela Conitec.  
A sorologia para a detecção de anticorpos pode ser utilizada para o diagnóstico presuntivo da histoplasmose, pois avalia indiretamente a existência do patógeno no hospedeiro. Entretanto, a detecção de anticorpos em pessoas imunodeficientes, em especial as PVHA, apresenta limitações em relação à sensibilidade dos diferentes testes. Testes sorológicos, como imunodifusão radial dupla, revelam anticorpos anti- _H. capsulatum_ em cerca de 60% dos pacientes. Testes com maior sensibilidade têm sido utilizados, tais como ELISA e Western blot 185,192, com variação de sensibilidade entre 90 a 100%, respectivamente, porém não estão acessíveis universalmente na rotina laboratorial.  
Testes moleculares por meio da detecção do DNA fúngico têm uma alta sensibilidade (95%) e especificidade (99%). Entretanto, a falta de consenso nas técnicas e/ou procedimentos dos testes e a indisponibilidade de _kits_ comerciais dificultam o uso desta ferramenta como método diagnóstico de rotina no Brasil<sup>184</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A escolha do antifúngico para o tratamento da histoplasmose deve ser orientada pela gravidade clínica. Assim, as formas disseminadas são classificadas em: leve a moderada ou moderada a grave a depender de critérios clinico-laboratoriais<sup>184</sup> . A terapia consiste em duas etapas - indução e consolidação – **Quadro 26** .  
**Quadro 26:** Tratamento da histoplasmose  
|**Forma clínica**|**Esquema terapêutico**|
|---|---|
|Histoplasmose<br>pulmonar aguda<sup>1</sup>|**Leve a moderada**: itraconazol 200 mg (2 cápsulas de 100 mg) 3x dia,<br>VO, por 3 dias, seguido de itraconazol 400 mg (4 cápsulas de 100 mg)/dia<br>por 6 a 12 semanas.<br>**Moderada a grave:**Complexo lipídico de anfotericina B 5 mg/kg/dia por<br>2 semanas, seguido de itraconazol 400 mg (4 cápsulas de 100 mg)/dia por<br>6 a 12 semanas.|
|Histoplasmose<br>pulmonar crônica|Itraconazol 200 mg (2 cápsulas de 100 mg)/dia ou de 12/12h, VO, por 12<br>a 24 meses. Manter o medicamento enquanto houver melhora pelo<br>monitoramento deimagensacada6meses.|
||**Moderada:**itraconazol 200 mg (2 cápsulas de 100 mg) 3x dia, VO, por 3<br>dias, seguido de itraconazol 400 mg (4 cápsulas de 100 mg) /dia,VO, por<br>12 meses<sup>2</sup>.|
|Histoplasmose<br>Disseminada|**Grave:**Complexo lipídico de anfotericina B 5 mg/kg/dia, IV, por 1 a 2<br>semanas, seguida de itraconazol 200 mg (2 cápsulas de 100 mg) de 12/12<br>horas, VO, por 12 meses<sup>2</sup>.<br>**Grave com comprometimento do SNC**<sup>**3**</sup>**:**Anfotericina B lipossomal:<br>3 mg/kg/dia IV, por 1 a 2 semanas, seguida de itraconazol 200 mg (2<br>cápsulas de 100 mg)de 12/12 horas,VO, por 12 meses<sup>2</sup>.|  
Fonte: CGTM/SVSA/MS  
1.Forma pulmonar aguda deverá ser sempre tratada e após cura clínica, o paciente deverá ser monitorado, clínica, radiológica e imunologicamente.  
2. A terapia de manutenção pode ser considerada em um tempo menor que 12 meses (3 a 6 meses), principalmente. em pacientes que apresentem interação medicamentosa ou efeitos colaterais importantes, considerando-se o risco de recidiva. Nestes casos, os pacientes devem estar recebendo TARV regularmente, mantendo boa adesão, com supressão da carga viral, recuperação do status imunológico (LT-CD4+ maior que 200 células/mm<sup>3</sup> ), e estarem clinicamente estáveis. 3. Nos casos de meningite confirmada, a dose de anfotericina B lipossomal poderá ser aumentada para 5 mg/kg/dia IV, mediante não resposta da dose preconizada e o tempo de tratamento poderá ser estendido para 4 a 6 semanas.  
Para PVHA com coinfecção tuberculose e histoplasmose, devido às interações medicamentosas, orienta-se substituir o itraconazol nas fases de indução e manutenção pela formulação lipídica de anfotericina B, em esquemas de duas ou três vezes por semana, até a recuperação imunológica.  
Para solicitação da anfotericina B lipossomal ou complexo lipídico e do itraconazol, seguir orientações do **Apêndice B** .  
Define-se como forma moderada a grave:  
Presença de pelo menos um dos seguintes sinais ou sintomas envolvendo órgãos vitais  
184:  
- Insuficiência respiratória ou circulatória,  
- Acometimento do SNC,  
- Insuficiência renal,  
- Alteração da coagulação ou  
- _Status_ de desempenho da OMS ≥ 2, na qual a pessoa fica confinada a uma cama ou cadeira por mais da metade das horas de vigília e é apenas capaz de autocuidado limitado.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A profilaxia primária é recomendada para PVHA residentes em áreas com elevada endemicidade para histoplasmose ou que exerçam atividade ocupacional de risco para o fungo<sup>92</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
O itraconazol deve ser ingerido junto com alimentos, devido à sua variável biodisponibilidade. Deve-se atentar para as interações medicamentosas do itraconazol com medicamentos como antiácidos, antagonistas H2, antirretrovirais, rifampicina, rifabutina, anticonvulsivantes, etc.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A TARV deve ser iniciada assim que possível, quando o paciente estiver clinicamente estável, desde que não haja suspeita de envolvimento do SNC<sup>4</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A SIRI associada à histoplasmose pode ocorrer, porém não é frequente. Em geral, pode acometer PVHA que tenham iniciado a TARV há 60 dias<sup>184</sup> . Nestes casos, deve-se:  
- Manter a TARV;  
- Iniciar tratamento antifúngico conforme as recomendações anteriores;  
- Considerar o uso de corticoide por curto curso, caso haja complicações ameaçadoras da vida, como prednisona (ou equivalente) na dose de 1 a 2 mg/kg por dia, por 1 a 2 semanas, seguido do desmame do medicamento por duas semanas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
A profilaxia de infecções oportunistas proporciona uma importante redução da morbimortalidade em indivíduos com disfunção imune secundária à infecção pelo HIV. Essa prevenção tem dois aspectos principais: a profilaxia primária e a secundária.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
É uma estratégia que visa a evitar o desenvolvimento de infecções oportunistas em pessoas com exposição prévia a essas doenças. O principal parâmetro para orientar a introdução e a suspensão da profilaxia é a contagem de LT-CD4+, uma vez que o risco de infecções oportunistas está diretamente associado ao nível dessas células de defesa.  
Os critérios para início e suspensão das profilaxias, bem como os esquemas recomendados estão sintetizados no  
**Quadro 27** .  
**Quadro 27:** Profilaxia primária das infecções oportunistas (evitar o primeiro episódio de doença)  
|**AGENTE**|**INDICAÇÃO**|**1ª ESCOLHA**|**ALTERNATIVAS**|**CRITÉRIOS**<br>**DE**<br>**SUSPENSÃO**|
|---|---|---|---|---|
|**_Pneumocystis_**<br>**_jiroveci_**|LT-CD4+<br>abaixo<br>de 200 células/mm<sup>3</sup><br>(ou<br><14%)<br>ou<br>presença<br>de<br>candidíase oral ou<br>febre indeterminada<br>com mais de duas<br>semanas de duração<br>ou<br>doença<br>definidora de aids|Sulfametoxazo<br>l<br>+<br>trimetoprima<br>800 mg + 160<br>mg 3x/semana<br>ou<br>diariamente<sup>a</sup>|Dapsona<sup>b</sup>100 mg/dia|Boa resposta à<br>TARV<br>com<br>manutenção de<br>LT-CD4+<br>maior que 200<br>células/mm<sup>3</sup><br>por mais de 3<br>meses<br>Reintroduzir<br>profilaxia<br>se<br>LT-CD4+<br>abaixo de 200<br>células/mm<sup>3</sup>|
|**_Toxoplasma_**<br>**_gondii_**|LT-CD4+<br>abaixo<br>de 100 células/mm<sup>3</sup><br>e IgG anti_T. gondii_<br>reagente|Sulfametoxazo<br>l+<br>trimetoprima<br>800 + 160 mg<br>1x/dia<sup>a</sup>|Dapsona 50 mg/dia<sup>c</sup><br>+ pirimetamina 50<br>mg (2 comprimidos<br>de 25 mg)/semana<br>+ ácido folínico 10<br>mg 3x/semana<br>OU<br>Clindamicina 600 mg<br>(2 comprimidos de<br>clindamicina 300 mg<br>ou 4 comprimidos de<br>clindamicina<br>150<br>mg) 3x/dia<br>+ pirimetamina 25 a<br>50<br>mg<br>(1<br>a<br>2<br>comprimidos de 25<br>mg)/dia<br>+ ácido folínico 10<br>mg3x/semana|Boa resposta à<br>TARV<br>com<br>manutenção de<br>LT-CD4+<br>acima de 200<br>células/mm<sup>3</sup><br>por mais de 3<br>meses<br>Reintroduzir<br>profilaxia<br>se<br>LT-CD4+<br>abaixo de 100<br>células/mm<sup>3</sup>|
|**Micobactéria**<br>**não tuberculosa**|LT-CD4+<br>abaixo<br>de 50 células/mm<sup>3</sup>e<br>que<br>ainda<br>não<br>iniciaram TARV|Azitromicina<br>1.250 a 1.500<br>mg<br>(até<br>3<br>cápsulas<br>de<br>500<br>mg)/semana|Claritromicina<br>500<br>mg (1 comprimido ou<br>cápsula) 2x/dia|Após início da<br>TARV|
|**_Cryptococcus sp._**|Não se indica profila|xia primária para|criptococose||  
|**AGENTE**|**INDICAÇÃO**<br>**1ª ESCOLHA**|**ALTERNATIVAS**|**CRITÉRIOS**<br>**DE**<br>**SUSPENSÃO**|
|---|---|---|---|
||Evitar situações de risco, tais como en<br>pássaros e morcegos|trar em cavernas ou se|expor a fezes de|
|**_Histoplasma_**<br>**_capsulatum_**|LT-CD4+ abaixo de<br>150 células/mm<sup>3</sup>em<br>áreas hiperendêmicas<sup>d</sup><br>Itraconazol 200<br>mg  (2 cápsulas<br>de<br>100<br>mg)<br>1x/dia|<br> <br> <br>Complexo lipídico de<br>anfotericina B 5<br>mg/kg/dia ou, no caso<br>de comprometimento<br>de SNC, anfotericina B<br>lipossomal 3<br>mg/kg/dia.|<br>Boa resposta à<br>TARV<br>com<br>manutenção<br>de<br>LT-CD4+ ≥ 150<br>células/mm<sup>3</sup><br>e<br>CV indetectável<br>por 6 meses|
|**Citomegalovírus**|Não se indica profilaxia primária<br>Recomenda-se diagnóstico precoce d<br>rotineiraem PVHAcom LT-CD4+ aba|e retinopatia por meio<br>ixo de 50 células/mm<sup>3</sup>|de fundoscopia|
|**_Herpes simplex_**|**Não se indica profilaxia primária **|||

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Legenda: Tarv = terapia antirretroviral; SNC = sistema nervoso central.  
a A dose de 800 mg/160 mg pode ser administrada em 2 comprimidos de 400 mg/80 mg ou em 1 comprimido de 800 mg/160 mg a depender da disponibilidade local. b Coleta de G6PD antes da prescrição.  
c Disponível apenas na apresentação de 100 mg. Ajustar dose.  
d Área hiperendêmica: mais de 10 casos/100 pacientes anualmente191,192.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
Essa estratégia tem como objetivo evitar a recidiva de IO anterior que já tenha recebido tratamento completo.  
As recomendações de profilaxias secundárias estão resumidas no  
**Quadro 28** .  
**Quadro 28** : Profilaxia secundária das IO (prevenção de recorrência)  
|**AGENTE**|**1ª ESCOLHA**|**ALTERNATIVAS**|**CRITÉRIO DE**<br>**SUSPENSÃO**|
|---|---|---|---|
|**_Pneumocystis_**<br>**_jiroveci_**|Sulfametoxazol+<br>trimetoprima<br>800<br>mg<br>+<br>160<br>mg<sup>a</sup><br>3x/semana|Dapsona 100 mg/dia<sup>b</sup>|Boa resposta à TARV<br>com manutenção de LT-<br>CD4+ >200 células/mm<sup>3</sup><br>por mais de 3meses|
|**_Toxoplasma_**<br>**_gondii_**|Abaixo de 60 kg:<br>Sulfadiazina 500 mg<br>(1<br>comprimido)<br>4x/dia<br>+ pirimetamina 25<br>mg (1 comprimido)<br>1x/dia<br>+ ácido folínico 10<br>mg1x/dia|Sulfametoxazol<br>+<br>trimetoprima 800+160<br>mg (2 comprimidos)<br>2x/dia<br>OU<br>Clindamicina 600 mg<br>3x/dia (2 comprimidos|Boa resposta à TARV<br>com manutenção de LT-<br>CD4+ acima de 200<br>células/mm<sup>3</sup>por mais de<br>6 meses|
||60 kg ou mais:<br>Sulfadiazina 1.000<br>mg (2 comprimidos<br>de 500 mg)4x/dia|<br>de clindamicina 300<br>mg ou 4 comprimidos<br>de clindamicina 150<br>mg)||  
|**AGENTE**|**1ª ESCOLHA**|**ALTERNATIVAS**|**CRITÉRIO DE**<br>**SUSPENSÃO**|
|---|---|---|---|
||+ pirimetamina 50<br>mg (2 comprimidos<br>de 25 mg) 1x/dia<br>+ ácido folínico 10<br>mg 1x/dia|+ pirimetamina 25 a 50<br>mg<br>(1<br>a<br>2<br>comprimidos) 1x/dia +<br>ácido folínico 10 mg<br>1x/dia<br>(acrescentar<br>cobertura<br>profilática<br>para PCP)||
|**Complexo**<br>**_Mycobacterium_**<br>**_avium_**|Claritromicina 500<br>mg (1 comprimido<br>ou cápsula de 500<br>mg) 2x/dia<br>+<br>etambutol<br>15<br>mg/kg/dia<br>(máx.<br>1.200 mg/dia – 3<br>comprimidos/dia)|Azitromicina 500 mg<br>1x/dia (1 comprimido)<br>+<br>etambutol<br>15<br>mg/kg/dia (máx. 1.200<br>mg/dia<br>–<br>3<br>comprimidos/dia)|Após<br>um<br>ano<br>de<br>tratamento para MAC,<br>na ausência de sintomas<br>e LT-CD4+ acima de<br>100<br>células/mm<sup>3</sup><br>por<br>mais de 6 meses<br>Reintroduzir<br>se<br>LT-<br>CD4+ menor que 100<br>células/mm<sup>3</sup>|
|**_Cryptococcus sp._**|Fluconazol 200 mg<br>(2 cápsulas de 100<br>mg) 1x/dia|Itraconazol 200 mg (2<br>cápsulas de 100 mg)<br>2x/dia|Término do tratamento<br>de<br>indução<br>e<br>consolidação<br>e<br>pelo<br>menos<br>1<br>ano<br>de<br>manutenção,<br>assintomático<br>e<br>LT-<br>CD4+ acima de 200<br>células/mm<sup>3</sup>por mais de<br>6 meses|
|**_Isospora belli_**|Sulfametoxazol+<br>trimetoprima 800 +<br>160<br>mg<br>(2<br>comprimidos)<br>3x/semana|-|Não há recomendação<br>específica. No entanto,<br>indica-se a suspensão da<br>profilaxia<br>com<br>LT-<br>CD4+ acima de 200<br>células/mm<sup>3</sup>por mais de<br>3 meses|
|**Citomegalovírus**<br>**(**apenas<br>para<br>retinite,<br>não<br>indicada<br>rotineiramente<br>para<br>doença<br>gastrointestinal**)**|Ganciclovir IV 5<br>mg/kg/dia<br>5x/semana|-|Boa resposta à TARV<br>com manutenção de LT-<br>CD4+<br>acima<br>de100<br>células/mm<sup>3</sup>por mais de<br>3 a 6 meses|
|**Histoplasmose**<br>**(doença**<br>**disseminada ou**<br>**infecção**<br>**do**<br>**SNC)**|Itraconazol 200 mg<br>(2 cápsulas de 100<br>mg) 1x/dia|-|Manutenção por tempo<br>indeterminado, pois não<br>há evidência suficiente<br>para a recomendação de<br>interrupção<br>do<br>itraconazol<br>Considerar<br>suspensão<br>após período mínimo de<br>um ano de tratamento de<br>manutenção, ausência de<br>sintomas e LT-CD4+<br>acima<br>de150|  
|**AGENTE**|**1ª ESCOLHA**|**ALTERNATIVAS**|**CRITÉRIO D**<br>**SUSPENSÃO**|**E**<br>|
|---|---|---|---|---|
||||células/mm<sup>3</sup>por m<br>6 meses<br>Reintroduzir<br>se<br>CD4+ abaixo de<br>células/mm<sup>3</sup>|ais de<br>LT-<br>150|
|**_Herpes_ ****_simplex_**<br>**Infecção**<br>**recorrente**<br>**(Mais**<br>**que**<br>**6**<br>**episódios/ano)**|Aciclovir 400 mg (2<br>comprimidos de 200<br>mg) 2x/dia||-||
|**Candidíase**<br>**esofágica**|**Não se indica a profil**|**axia secundária para c**|**andidíase esofágica**||  
Fonte: DATHI/SVSA/MS.  
Legenda: Tarv = terapia antirretroviral; SNC = sistema nervoso central.  
a A dose de 800 mg/160 mg pode ser administrada em 2 comprimidos de 400 mg/80 mg ou em 1 comprimido de 800 mg/160 mg a depender da disponibilidade local. b Coleta de G6PD antes da prescrição.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
1. Global Tuberculosis reporT 2022 [Internet]. 2022. Available from: http://apps.who.int/bookorders.  
2. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Boletim Epidemiológico Coinfecção TB-HIV 2022, Número Especial, Fev.2023. Disponível em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/boletinsepidemiologicos/2022/coinfeccao-tb-hiv/boletim_coinfeccao_tb_hiv_2022.pdf/view</u>  
3. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Manual de Recomendações para o Controle da Tuberculose no Brasil / Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância das Doenças Transmissíveis. – Brasília: Ministério da Saúde, 2019. [Internet]. Available from: www.saude.gov.br/  
4. WHO. Consolidated guidelines on HIV prevention, testing, treatment, service delivery and monitoring: recommendations for a public health approach. Geneva: World Health Organization. 2021.  
5. WHO Global TB Programme. Automated real-time nucleic acid amplification technology for rapid and simultaneous detection of tuberculosis and rifampicin resistance : Xpert MTB/RIF assay for the diagnosis of pulmonary and extrapulmonary TB in adults and children. 79 p.  
6. World Health Organization. WHO consolidated guidelines on tuberculosis. Module 3: diagnosis-rapid diagnostics for tuberculosis detection,2021 update. Vol. Module 3, World Health Organization. 2021.  
7. BRASIL. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Relatório de Recomendação nº 591/2021 - Teste lipoarabinomanano de fluxo lateral na urina (LFLAM) para rastreamento e diagnóstico de tuberculose ativa em pessoas suspeitas vivendo com HIV/AIDS.  
8. Benjamin A, Cavalcante SC, Jamal LF, Arakaki-Sanchez D, De Lima JN, Pilotto JH, et al. Accuracy of Determine TB-LAM Ag to detect TB in HIV infected patients associated with diagnostic methods used in Brazilian public health units. PLoS One. 2019;14(9).  
9. Orlando S, Triulzi I, Ciccacci F, Palla I, Palombi L, Marazzi MC, et al. Delayed diagnosis and treatment of tuberculosis in HIV+ patients in Mozambique: A cost-effectiveness analysis of screening protocols based on four symptom screening, smear microscopy, urine LAM test and Xpert MTB/RIF. PLoS One. 2018;13(7).  
10. Akolo C, Adetifa I, Shepperd S, Volmink J. Treatment of latent tuberculosis infection in HIV infected persons. Cochrane Database of Systematic Reviews. 2010;  
11. The TEMPRANO ANRS 12136 Study Group. A Trial of Early Antiretrovirals and Isoniazid Preventive Therapy in Africa. New England Journal of Medicine. 2015;373(9).  
12. Golub JE, Cohn S, Saraceni V, Cavalcante SC, Pacheco AG, Moulton LH, et al. Long-term protection from isoniazid preventive therapy for tuberculosis in HIV-infected patients in a medium-burden tuberculosis setting: The TB-HIV in Rio (THRio) study. Clinical Infectious Diseases. 2015;60(4).  
13. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Relatório de Recomendação nº 526/2020 - Rifapentina + isoniazida para o tratamento da Infecção Latente pelo Mycobacterium Tuberculosis (ILTB). Disponível em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/relatorios/2020/relatorio_rifapentinaisoniazida_iltb_526_2020_final.pdf</u>  
14. Burke RM, Rickman HM, Singh V, Corbett EL, Ayles H, Jahn A, et al. What is the optimum time to start antiretroviral therapy in people with HIV and tuberculosis coinfection? A systematic review and meta-analysis. Vol. 24, Journal of the International AIDS Society. 2021.  
15. De Castro N, Marcy O, Chazallon C, Messou E, Eholié S, N’takpe JB, et al. Standard dose raltegravir or efavirenz-based antiretroviral treatment for patients co-infected with HIV and tuberculosis (ANRS 12 300 Reflate TB 2): an open-label, non-inferiority, randomised, phase 3 trial. Lancet Infect Dis. 2021;21(6).  
16. Grinsztejn B, De Castro N, Arnold V, Veloso VG, Morgado M, Pilotto JH, et al. Raltegravir for the treatment of patients co-infected with HIV and tuberculosis (ANRS 12 180 Reflate TB): A multicentre, phase 2, non-comparative, open-label, randomised trial. Lancet Infect Dis. 2014;14(6).  
17. Müller M, Wandel S, Colebunders R, Attia S, Furrer H, Egger M. Immune reconstitution inflammatory syndrome in patients starting antiretroviral therapy for HIV infection: a systematic review and meta-analysis. Vol. 10, The Lancet Infectious Diseases. 2010.  
18. Burman W, Weis S, Vernon A, Khan A, Benator D, Jones B, et al. Frequency, severity and duration of immune reconstitution events in HIV-related tuberculosis. International Journal of Tuberculosis and Lung Disease. 2007;11(12).  
19. Pepper DJ, Marais S, Maartens G, Rebe K, Morroni C, Rangaka MX, et al. Neurologic manifestations of paradoxical tuberculosis-associated immune reconstitution inflammatory syndrome: A case series. Clinical Infectious Diseases. 2009;48(11).  
20. Lawn SD, Bekker LG, Miller RF. Immune reconstitution disease associated with mycobacterial infections in HIV-infected individuals receiving antiretrovirals. Vol. 5, Lancet Infectious Diseases. 2005.  
21. Walker NF, Stek C, Wasserman S, Wilkinson RJ, Meintjes G. The tuberculosis-associated immune reconstitution inflammatory syndrome: Recent advances in clinical and pathogenesis research. Vol. 13, Current Opinion in HIV and AIDS. 2018.  
22. Meintjes G, Stek C, Blumenthal L, Thienemann F, Schutz C, Buyze J, et al. Prednisone for the Prevention of Paradoxical Tuberculosis-Associated IRIS. New England Journal of Medicine. 2018;379(20).  
23. Wouters E, Stek C, Swartz A, Buyze J, Schutz C, Thienemann F, et al. Prednisone for the prevention of tuberculosis-associated IRIS (randomized controlled trial): Impact on the health-related quality of life. Front Psychol. 2022;13.  
24. Biblioteca Virtual em Saúde do Ministério da Saúde Hepatites Virais | 2022 Secretaria de Vigilância em Saúde | Ministério da Saúde Boletim Epidemiológico.  
25. Salazar-Vizcaya L, Kouyos RD, Metzner KJ, Caraballo Cortes K, Böni J, Shah C, et al. Changing Trends in International Versus Domestic HCV Transmission in HIV-Positive Men Who Have Sex with Men: A Perspective for the Direct-Acting Antiviral Scale-Up Era. Journal of Infectious Diseases. 2019;220(1).  
26. Lambers FAE, Prins M, Thomas X, Molenkamp R, Kwa D, Brinkman K, et al. Alarming incidence of hepatitis C virus re-infection after treatment of sexually acquired acute hepatitis C virus infection in HIV-infected MSM. AIDS. 2011;25(17).  
27. Hagan H, Jordan AE, Neurer J, Cleland CM. Incidence of sexually transmitted hepatitis C virus infection in HIV-positive men who have sex with men. AIDS. 2015;29(17).  
28. Medland NA, Chow EPF, Bradshaw CS, Read THR, Sasadeusz JJ, Fairley CK. Predictors and incidence of sexually transmitted Hepatitis C virus infection in HIV positive men who have sex with men. BMC Infect Dis. 2017;17(1).  
29. World Health Organization. Hepatitis C Fact Sheet. WHO website (online). 2020.  
30. Danta M, Rodger AJ. Transmission of HCV in HIV-positive populations. Vol. 6, Current Opinion in HIV and AIDS. 2011.  
31. Van De Laar TJW, Matthews G V., Prins M, Danta M. Acute hepatitis C in HIV-infected men who have sex with men: An emerging sexually transmitted infection. Vol. 24, AIDS. 2010.  
32. Danta M, Brown D, Bhagani S, Pybus OG, Sabin CA, Nelson M, et al. Recent epidemic of acute hepatitis C virus in HIV-positive men who have sex with men linked to high-risk sexual behaviours. AIDS. 2007;21(8).  
33. Xu Y, Zhang Y, Wang J. Hepatitis C guidance 2019 update: AASLD-IDSA recommendations for testing, managing, and treating hepatitis C virus infection. Chinese Journal of Clinical Infectious Diseases. 2020;13(2).  
34. Dube MP. , Stein JH. AJA. Panel on Antiretroviral Guidelines for Adults and Adolescents. Guidelines for the Use of Antiretroviral Agents in Adults and Adolescents with HIV. Department of Health and Human Services. 2021;40(Build 29393).  
35. Adams DH, Sanchez-Fueyo A, Samuel D, Agnello V, Alves D, Zauli G, et al. Guidelines for the screening, care, and treatment of persons with chronic hepatitis C infection: Updated version April 2016. J Hepatol. 2016;47(April).  
36. WHO guidelines. Guidelines for the care and treatment of persons diagnosed with chronic hepatitis C virus infection. Who. 2018.  
37. Matthews G V., Ali RJ, Avihingsanon A, Amin J, Hammond R, Bowden S, et al. Quantitative HBsAg and HBeAg Predict Hepatitis B Seroconversion after Initiation of HAART in HIV-HBV Coinfected Individuals. PLoS One. 2013;8(4).  
38. Theelen B, Cafarchia C, Gaitanis G, Bassukas ID, Boekhout T, Dawson TL. HIV-Hepatitis B virus co-infection: epidemiology, pathogenesis and treatment. AIDS. 2018;31(March).  
39. Boyd A, Maylin S, Moh R, Mahjoub N, Gabillard D, Eholié SP, et al. Hepatitis B surface antigen quantification as a predictor of seroclearance during treatment in HIV-hepatitis B virus coinfected patients from Sub-Saharan Africa. Journal of Gastroenterology and Hepatology (Australia). 2016;31(3).  
40. Dore GJ, Soriano V, Rockstroh J, Kupfer B, Tedaldi E, Peters L, et al. Frequent hepatitis B virus rebound among HIV-hepatitis B virus-coinfected patients following antiretroviral therapy interruption. AIDS. 2010;24(6).  
41. Núñez M, Soriano V. Hepatotoxicity of antiretrovirals: Incidence, mechanisms and management. Vol. 28, Drug Safety. 2005.  
42. Jones M, Núñez M. Liver toxicity of antiretroviral drugs. In: Seminars in Liver Disease. 2012.  
43. Otto AO, Rivera CG, Zeuli JD, Temesgen Z. Hepatotoxicity of contemporary antiretroviral drugs: A review and evaluation of published clinical data. Vol. 10, Cells. 2021.  
44. Mphahlele MJ, Lukhwareni A, Burnett RJ, Moropeng LM, Ngobeni JM. High risk of occult hepatitis B virus infection in HIV-positive patients from South Africa. Journal of Clinical Virology. 2006;35(1).  
45. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Protocolo Clínico e Diretrizes Terapêuticas de Hepatite B e Coinfecções, 2023. Disponível em: <u>https://www.gov.br/conitec/pt-</u>  
- <u>br/midias/protocolos/20230524_Relatrio_PCDTHepatiteB.pdf</u>  
46. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Boletim Epidemiológico Sífilis 2022, Número Especial, Out.2022. Disponível em: <u>https://www.gov.br/saude/ptbr/centrais-de-conteudo/publicacoes/boletins/epidemiologicos/especiais/2022/boletimepidemiologico-de-sifilis-numero-especial-out-2022</u>  
47. Mayer KH. Old Pathogen, New Challenges: A Narrative Review ofthe Multilevel Drivers of Syphilis Increasing in American Men Who Have Sex with Men. Vol. 45, Sexually Transmitted Diseases. Lippincott Williams and Wilkins; 2018. p. S38–41.  
48. Brasil. Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais. Secretaria de Vigilância em Saúde. 2022.  
49. Cohen CE, Winston A, Asboe D, Boag F, Hawkins DA. Screening for syphilis in HIVpositive men who have sex with men (MSM). Vol. 17, International Journal of STD and AIDS. 2006.  
50. Cohen MS. When people with HIV get syphilis: Triple jeopardy. Vol. 33, Sexually Transmitted Diseases. 2006.  
51. Huang YF, Nelson KE, Lin YT, Yang CH, Chang FY, Lew-Ting CY. Syphilis among men who have sex with men (MSM) in Taiwan: Its association with HIV prevalence, awareness of HIV status, and use of antiretroviral therapy. AIDS Behav. 2013;17(4).  
52. Callegari FM, Pinto-Neto LF, Medeiros CJ, Scopel CB, Page K, Miranda AE. Syphilis and HIV co-infection in patients who attend an AIDS outpatient clinic in Vitoria, Brazil. AIDS Behav. 2014;18(SUPPL. 1).  
53. Lynn WA, Lightman S. Syphilis and HIV: A dangerous combination. Vol. 4, Lancet Infectious Diseases. 2004.  
54. Solomon MM, Mayer KH, Glidden D V., Liu AY, McMahan VM, Guanira J V., et al. Syphilis predicts HIV incidence among men and transgender women who have sex with men in a preexposure prophylaxis trial. Clinical Infectious Diseases. 2014;59(7).  
55. Horváth A. Biology and Natural History of Syphilis. In: Sexually Transmitted Infections and Sexually Transmitted Diseases. 2011.  
56. Branger J, Van Der Meer JTM, Van Ketel RJ, Jurriaans S, Prins JM. High incidence of asymptomatic syphilis in HIV-infected MSM justifies routine screening. Sex Transm Dis. 2009;36(2).  
57. Buchacz K, Patel P, Taylor M, Kerndt, Peter R, Byers, Robert H, Holmberg, Scott D, et al. Syphilis increases HIV viral load and decreases CD4 cell cou... : AIDS. Aids. 2018;18(1).  
58. Lawrence D, Cresswell F, Whetham J, Fisher M. Syphilis treatment in the presence of HIV. Curr Opin Infect Dis. 2015;28(1).  
59. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis.  Manual técnico para o diagnóstico da sífilis [recurso eletrônico] / Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. – Brasília : Ministério da Saúde, 2021. [Internet]. Available from: www.aids.gov.br  
60. Lasso MB, Balcells MM, Fernandez AS, Gaete PG, Serri M V, Perez JG, et al. [Neurosyphilis in the patients with and without HIV infection: description and comparison of two historical cohorts]. Revista Chilena de Infectologia. 2009;26.  
61. Rompalo AM, Lawlor J, Seaman P, Quinn TC, Zenilman JM, Hook EW. Modification of syphilitic genital ulcer manifestations by coexistent HIV infection. Sex Transm Dis. 2001;28(8).  
62. Tucker JD, Shah S, Jarell AD, Tsai KY, Zembowicz A, Kroshinsky D. Lues maligna in early HIV infection case report and review of the literature. Sex Transm Dis. 2009;36(8).  
63. Arando M, Fernandez-Naval C, Mota-Foix M, Martinez D, Armengol P, Barberá MJ, et al. Early syphilis: Risk factors and clinical manifestations focusing on HIV-positive patients. BMC Infect Dis. 2019;19(1).  
64. Ghanem KG, Ram S, Rice PA. The Modern Epidemic of Syphilis. New England Journal of Medicine. 2020 Feb 27;382(9):845–54.  
65. Tuddenham S, Ghanem KG. Neurosyphilis: Knowledge Gaps and Controversies. Vol. 45, Sexually Transmitted Diseases. 2018.  
66. Ropper AH. Neurosyphilis. New England Journal of Medicine [Internet]. 2019 Oct 2;381(14):1358–63. Available from: https://doi.org/10.1056/NEJMra1906228  
67. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Manual técnico para o diagnóstico da sífilis [recurso eletrônico] – Brasília: Ministério da Saúde, 2021. Disponível em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/publicacoes/2021/manualtecnico-para-o-diagnostico-da-sifilis</u>  
68. Davis AP, Stern J, Tantalo L, Sahi S, Holte S, Dunaway S, et al. How Well Do Neurologic Symptoms Identify Individuals with Neurosyphilis? Clinical Infectious Diseases. 2018;66(3).  
69. Marra CM, Maxwell CL, Smith SL, Lukehart SA, Rompalo AM, Eaton M, et al. Cerebrospinal Fluid Abnormalities in Patients with Syphilis: Association with Clinical and Laboratory Features. Journal of Infectious Diseases. 2004;189(3).  
70. Libois A, De Wit S, Poll B, Garcia F, Florence E, Del Rio A, et al. HIV and syphilis: When to perform a lumbar puncture. Sex Transm Dis. 2007;34(3).  
71. Janier M, Unemo M, Dupin N, Tiplica GS, Potočnik M, Patel R. 2020 European guideline on the management of syphilis. Journal of the European Academy of Dermatology and Venereology. 2021;35(3).  
72. Pongdee T, Li JT. Evaluation and Management of Penicillin Allergy. Vol. 93, Mayo Clinic Proceedings. 2018.  
73. Bhattacharya S. The facts about penicillin allergy: A review. Vol. 1, Journal of Advanced Pharmaceutical Technology and Research. 2010.  
74. Brasil M da S. Penicilina benzatina para prevenção da sífilis congênita durante a gravidez. Relatório de recomendação n. 150. CONITEC - Comissão Nacional de Incorporação de Tecnologias no SUS. 2015;  
75. Pound MW, May DB. Proposed mechanisms and preventative options of JarischHerxheimer reactions. Vol. 30, Journal of Clinical Pharmacy and Therapeutics. 2005.  
76. Tsai MS, Yang CJ, Lee NY, Hsieh SM, Lin YH, Sun HY, et al. Jarisch-Herxheimer reaction among HIV-positive patients with early syphilis: Azithromycin versus benzathine penicillin G therapy. J Int AIDS Soc. 2014;17.  
77. Brown ST, Zaidi A, Larsen SA, Reynolds GH. Serological Response to Syphilis Treatment: A New Analysis of Old Data. JAMA: The Journal of the American Medical Association. 1985;253(9).  
78. Peeling RW, Mabey D, Kamb ML, Chen XS, Radolf JD, Benzaken AS. Primer: Syphilis. Nat Rev Dis Primers. 2017 Oct 12;3.  
79. Seña AC, Zhang XH, Li T, Zheng HP, Yang B, Yang LG, et al. A systematic review of syphilis serological treatment outcomes in HIV-infected and HIV-uninfected persons: Rethinking the significance of serological non-responsiveness and the serofast state after therapy. BMC Infect Dis. 2015;15(1).  
80. Marra CM, Maxwell CL, Tantalo LC, Sahi SK, Lukehart SA. Normalization of serum rapid plasma reagin titer predicts normalization of cerebrospinal fluid and clinical abnormalities after treatment of neurosyphilis. Clinical Infectious Diseases. 2008;47(7).  
81. Tong ML, Lin LR, Liu GL, Zhang HL, Zeng YL, Zheng WH, et al. Factors Associated with Serological Cure and the Serofast State of HIV-Negative Patients with Primary, Secondary, Latent, and Tertiary Syphilis. PLoS One. 2013;8(7).  
82. Romanowski B, Sutherland R, Fick GH, Mooney D, Love EJ. Serologic response to treatment of infectious syphilis. Ann Intern Med. 1991;114(12).  
83. BRASIL. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Protocolo Clínico e Diretrizes Terapêuticas Doença de Chagas, 2018. Disponível em: <u>https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/svsa/doenca-de-chagas/protocolo-clinico-e-diretrizes-terapeuticaspara-doenca-de-chagas-_-relatorio-de-recomendacao.pdf/view</u>  
84. Organización Panamericana de la Salud. Factsheet: Chagas Disease in the Americas for Public Health Workers. 2023. Disponível em: <u>https://www.who.int/news-room/factsheets/detail/chagas-disease-(american-trypanosomiasis)</u>  
85. Rassi A, Rassi A, Marin-Neto JA. Chagas disease. The Lancet [Internet]. 2010 Apr 17 [cited 2023 Jun 13];375(9723):1388–402. Available from: http://www.thelancet.com/article/S014067361060061X/fulltext  
86. Hasslocher-Moreno AM, Mediano MFF. A prevalência da coinfecção Trypanosoma cruziHIV varia de acordo com a abordagem metodológica do desenho de estudo. In: In: CONGRESSO DA SBMT, 57. Belém (PA): MEDTROP, 2022. 1 poster.; 2022.  
87. Dias JCP, Ramos Jr. AN, Gontijo ED, Luquetti A, Shikanai-Yasuda MA, Coura JR, et al. II Consenso Brasileiro em Doença de Chagas, 2015. Epidemiologia e Serviços de Saúde [Internet]. 2016 [cited 2023 Jun 13];25(ESP):7–86. Available from: http://scielo.iec.gov.br/scielo.php?script=sci_arttext&pid=S167949742016000500007&lng=pt&nrm=iso&tlng=pt  
88. Bern C. Chagas’ Disease. Longo DL, editor. https://doi.org/101056/NEJMra1410150 [Internet]. 2015 Jul 30 [cited 2023 Jun 13];373(5):456–66. Available from: https://www.nejm.org/doi/full/10.1056/NEJMra1410150  
89. Sartori AMC, Ibrahim KY, Nunes Westphalen E V., Braz LMA, Oliveira OC, Gakiya É, et al. Manifestations of Chagas disease (American trypanosomiasis) in patients with HIV/AIDS. Ann Trop Med Parasitol [Internet]. 2007 [cited 2023 Jun 13];101(1):31–50. Available from: https://pubmed.ncbi.nlm.nih.gov/17244408/  
90. Shikanai-Yasuda MA, Mediano MFF, Novaes CTG, De Sousa AS, Sartori AMC, Santana RC, et al. Clinical profile and mortality in patients with T. Cruzi/HIV co-infection from the multicenter data base of the “network for healthcare and study of trypanosoma cruzi/HIV co-infection and other immunosuppression conditions.” PLoS Negl Trop Dis. 2021;15(9).  
91. Ministério da Saúde. Guia De Vigilância Em Saúde Ministério Da Saúde. Ministério da Saúde. 2022.  
92. Cecchini D, Lespada M, Riarte A, Rodriguez C. Reactivación de la enfermedad de Chagas en el sistema nervioso central de pacientes infectados por el virus de la inmunodeficiencia humana. Actual SIDA. 2009;  
93. Lazo JE, Meneses AC, Rocha A, Frenkel JK, Marquez JO, Chapadeiro E, et al. Toxoplasmic and chagasic meningoencephalitis in patients with human immunodeficiency virus infection: anatomopathologic and tomographic differential diagnosis. Rev Soc Bras Med Trop. 1998;31(2).  
94. Epidemiologia e clínica da coinfecção Trypanosoma cruzi e vírus da imunodeficiência adquirida. Epidemiologia e clínica da coinfecção Trypanosoma cruzi e vírus da imunodeficiência adquirida. 2015.  
95. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde, Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Protocolo Clínico e Diretrizes Terapêuticas da Hanseníase [recurso eletrônico] / Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde, Secretaria de Vigilância em Saúde. – Brasília : Ministério da Saúde, 2022 [Internet]. Available from: https://www.gov.br/saude/pt-br/assuntos/saude-de-a-az/h/hanseniase/publicacoes/protocolo-clinico-e-diretrizes-terapeuticas-da-hanseniase2022  
96. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Indicadores e dados básicos de hanseníase nos municípios brasileiros. [Internet]. [cited 2023 Jun 20]. Available from: http://indicadoreshanseniase.aids.gov.br/  
97. Mouchardid A, Blaizotid R, Graille J, Couppié P, Bertin C. Leprosy as immune reconstitution inflammatory syndrome in patients living with HIV: Description of French Guiana’s cases over 20 years and systematic review of the literature. PLoS Negl Trop Dis. 2022;16(3).  
98. da Silva TP, Bittencourt TL, de Oliveira AL, Prata RB da S, Menezes V, Ferreira H, et al. Macrophage Polarization in Leprosy–HIV Co-infected Patients. Front Immunol. 2020;11.  
99. Massone C, Talhari C, Ribeiro-Rodrigues R, Sindeaux RHM, Mira MT, Talhari S, et al. Leprosy and HIV coinfection: A critical approach. Vol. 9, Expert Review of Anti-Infective Therapy. 2011.  
100. Jardim MR, Vital R, Illarramendi X, Antunes SLG, Nery JAC, Sales AM, et al. Ulnar neuropathy as a first sign of HIV infection: A diagnostic challenge for leprosy endemic countries. Arq Neuropsiquiatr. 2009;67(3 A).  
101. Eusebio-Ponce E, Anguita E, Paulino-Ramirez R, Candel FJ. HTLV-1 infection: An emerging risk. Pathogenesis, epidemiology, diagnosis and associated diseases. Vol. 32, Revista Espanola de Quimioterapia. 2019.  
102. Gonçalves DU, Proietti FA, Ribas JGR, Araújo MG, Pinheiro SR, Guedes AC, et al. Epidemiology, treatment, and prevention of human T-cell leukemia virus type 1-associated diseases. Vol. 23, Clinical Microbiology Reviews. 2010.  
103. Carneiro-Proietti ABF, Catalan-Soares BC, Castro-Costa CM, Murphy EL, Sabino EC, Hisada M, et al. HTLV in the Americas: challenges and perspectives TT  - El virus de la leucemia humana de células T (VLHT) en las Américas: retos y perspectivas. Revista Panamericana de Salud Pública. 2006;19(1).  
104. Gessain A, Cassar O. Epidemiological aspects and world distribution of HTLV-1 infection. Vol. 3, Frontiers in Microbiology. 2012.  
105. GUIA DE MANEJO CLÍNICO DA INFECÇÃO PELO HTLV [Internet]. 2021. Available from: https://aids.gov.br  
106. Souza-Machado A, Cruz ÁA, Galvão TS, Carvalho EM. Imunopatogênese da infecção pelo HTLV-1: influência sobre a resposta imune tipo 2 Immunopathogenesis of HTLV-1 infection: influence upon type 2 immune response. 2003;  
107. Silva MT, de Melo Espíndola O, Bezerra Leite ACC, Araújo A. Neurological aspects of HIV/human T lymphotropic virus coinfection. Vol. 11, AIDS Reviews. 2009.  
108. Silva MTT, Neves ES, Grinsztejn B, De Melo Espíndola O, Schor D, Araújo A. Neurological manifestations of coinfection with HIV and human T-lymphotropic virus type 1. AIDS. 2012;26(4).  
109. Fujino T, Nagata Y. HTLV-I transmission from mother to child. Vol. 47, Journal of Reproductive Immunology. 2000.  
110. Manual de recomendações para diagnóstico, tratamento e acompanhamento de pacientes com a coinfecção leishmania-HIV [Internet]. Available from: http://editora.saude.gov.br  
111. Diretrizes para o tratamento das leishmanioses na Região das Américas. Segunda edição. Diretrizes para o tratamento das leishmanioses na Região das Américas. Segunda edição. 2022.  
112. Lindoso JAL, Barbosa RN, Posada-Vergara MP, Duarte MIS, Oyafuso LK, Amato VS, et al. Unusual manifestations of tegumentary leishmaniasis in AIDS patients from the New World. British Journal of Dermatology. 2009;160(2).  
113. Brasil. Manual de vigilância da leishmaniose tegumentar [recurso eletrônico]. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. 2017.  
114. Arantes DeAlmeida F, Freitas Neves F, Jose Mora D, Albertin DosReis T, Moelas Sotini D, De Melo Ribeiro B, et al. Paracoccidioidomycosis in brazilian patients with and without human immunodeficiency virus infection. American Journal of Tropical Medicine and Hygiene. 2017;96(2).  
115. Shikanai-Yasuda MA, Mendes RP, Colombo AL, de Queiroz-Telles F, Kono ASG, Paniago AMM, et al. Brazilian guidelines for the clinical management of paracoccidioidomycosis. Vol. 50, Revista da Sociedade Brasileira de Medicina Tropical. 2017.  
116. Benard G, Duarte AJS. Paracoccidioidomycosis: A model for evaluation of the effects of human immunodeficiency virus infection on the natural history of endemic tropical diseases. Vol. 31, Clinical Infectious Diseases. 2000.  
117. Falcão EM, de Macedo PM, Freitas DFS, Freitas AD, Grinsztejn B, Veloso VG, et al. Paracoccidioidomycosis in people living with HIV/AIDS: A historical retrospective cohort study in a national reference center for infectious diseases, Rio de Janeiro, Brazil. PLoS Negl Trop Dis. 2022;16(6).  
118. Maziarz EK, Perfect JR. Cryptococcosis. Vol. 30, Infectious Disease Clinics of North America. 2016.  
119. Rajasingham R, Govender NP, Jordan A, Loyse A, Shroufi A, Denning DW, et al. The global burden of HIV-associated cryptococcal infection in adults in 2020: a modelling analysis. Lancet Infect Dis. 2022;22(12).  
120. Jarvis JN, Bicanic T, Loyse A, Namarika D, Jackson A, Nussbaum JC, et al. Determinants of mortality in a combined cohort of 501 patients with HIV-associated cryptococcal meningitis: Implications for improving outcomes. Clinical Infectious Diseases. 2014;58(5).  
121. Firacative C, Lizarazo J, Illnait-Zaragozí MT, Castañeda E, Arechavala A, Córdoba S, et al. The status of cryptococcosis in latin America. Vol. 113, Memorias do Instituto Oswaldo Cruz. 2018.  
122. Medina N, Rodriguez-Tudela JL, Pérez JC, Mercado D, Bonilla O, Arathoon E, et al. Epidemiology and Mortality of Cryptococcal Disease in Guatemala: Two-Year Results of a Cryptococcal Antigen Screening Program. Microorganisms. 2022;10(7).  
123. Beardsley J, Dao A, Keighley C, Garnham K, Halliday C, Chen SCA, et al. What’s New in Cryptococcus gattii: From Bench to Bedside and Beyond. Vol. 9, Journal of Fungi. 2023.  
124. Chen SCA, Meyer W, Sorrell TC. Cryptococcus gattii infections. Clin Microbiol Rev. 2014;27(4).  
125. Setianingrum F, Rautemaa-Richardson R, Denning DW. Pulmonary cryptococcosis: A review of pathobiology and clinical aspects. Vol. 57, Medical Mycology. 2019.  
126. Teekaput C, Yasri S, Chaiwarith R. Cryptococcal Meningitis: Differences between Patients with and without HIV-Infection. Pathogens. 2023 Mar 8;12(3):427.  
127. Williamson PR, Jarvis JN, Panackal AA, Fisher MC, Molloy SF, Loyse A, et al. Cryptococcal meningitis: Epidemiology, immunology, diagnosis and therapy. Vol. 13, Nature Reviews Neurology. Nature Publishing Group; 2016. p. 13–24.  
128. Williams DA, Kiiza T, Kwizera R, Kiggundu R, Velamakanni S, Meya DB, et al. Evaluation of Fingerstick Cryptococcal Antigen Lateral Flow Assay in HIV-Infected Persons: A Diagnostic Accuracy Study. Clinical Infectious Diseases. 2015;61(3).  
129. Boulware DR, Rolfes MA, Rajasingham R, von Hohenberg M, Qin Z, Taseera K, et al. Multisite validation of cryptococcal antigen lateral flow assay and quantification by laser thermal contrast. Emerg Infect Dis. 2014;20(1).  
130. World Health Organization (WHO). Guidelines on the diagnosis, prevention and management of cryptococcal disease in HIV-infected adults, adolescents and children: policy brief. World Health Organization. 2018;  
131. Scriven JE, Rhein J, Hullsiek KH, Von Hohenberg M, Linder G, Rolfes MA, et al. Early ART after cryptococcal meningitis is associated with cerebrospinal fluid pleocytosis and macrophage activation in a multisite randomized trial. Journal of Infectious Diseases. 2015;212(5).  
132. Levin AE, Bangdiwala AS, Nalintya E, Kagimu E, Kasibante J, Rutakingirwa MK, et al. Outpatient Cryptococcal Antigen Screening Is Associated With Favorable Baseline Characteristics and Improved Survival in Persons With Cryptococcal Meningitis in Uganda. Clinical Infectious Diseases. 2023;76(3).  
133. Shelburne SA, Visnegarwala F, Darcourt J, Graviss EA, Giordano TP, White AC, et al. Incidence and risk factors for immune reconstitution inflammatory syndrome during highly active antiretroviral therapy. Vol. 19, AIDS. 2005.  
134. Murdoch DM, Venter WDF, Van Rie A, Feldman C. Immune reconstitution inflammatory syndrome (IRIS): Review of common infectious manifestations and treatment options. Vol. 4, AIDS Research and Therapy. 2007.  
135. Bicanic T, Meintjes G, Wood R, Hayes M, Rebe K, Bekker LG, et al. Fungal burden, early fungicidal activity, and outcome in cryptococcal meningitis in antiretroviral-naive or antiretroviral-experienced patients treated with amphotericin B or fluconazole. Clinical Infectious Diseases. 2007;45(1).  
136. Bicanic T, Brouwer AE, Meintjes G, Rebe K, Limmathurotsakur D, Chierakul W, et al. Relationship of cerebrospinal fluid pressure, fungal burden and outcome in patients with cryptococcal meningitis undergoing serial lumbar punctures. AIDS. 2009;23(6).  
137. da Cunha Colombo ER, Mora DJ, Silva-Vergara ML. Immune reconstitution inflammatory syndrome (IRIS) associated with Cryptococcus neoformans infection in AIDS patients. Mycoses. 2011;54(4).  
138. Longley N, Harrison TS, Jarvis JN. Cryptococcal immune reconstitution inflammatory syndrome. Vol. 26, Current Opinion in Infectious Diseases. 2013.  
139. Rostami A, Taghipour A, Gamble R. Global and Regional Prevalence and Burden of Latent and Acute Toxoplasmosis in People Living With HIV : an Updated Systematic Review and Meta-analysis. Res Sq. 2020;  
140. Wang ZD, Wang SC, Liu HH, Ma HY, Li ZY, Wei F, et al. Prevalence and burden of Toxoplasma gondii infection in HIV-infected people: a systematic review and metaanalysis. Lancet HIV. 2017;4(4).  
141. Vidal JE. HIV-Related Cerebral Toxoplasmosis Revisited: Current Concepts and Controversies of an Old Disease. Vol. 18, Journal of the International Association of Providers of AIDS Care. 2019.  
142. Nissapatorn V, Lee C, Quek KF, Leong CL, Mahmud R, Abdullah KA. Toxoplasmosis in HIV/AIDS patients: A current situation. Jpn J Infect Dis. 2004;57(4).  
143. Robert-Gangneux F, Dardé ML. Epidemiology of and diagnostic strategies for toxoplasmosis. Vol. 25, Clinical Microbiology Reviews. 2012.  
144. Pellegrino D, Gryschek R, de Oliveira ACP, Marcusso R, Correia A, Vidal JE. Efficacy and safety of trimethoprim-sulfamethoxazole in HIV-infected patients with cerebral toxoplasmosis in Brazil: a single-arm open-label clinical trial. Int J STD AIDS. 2019;30(12).  
145. Li Y, Zeng Y, Lu Y, He X, Wu Y, Zhang W, et al. Synergistic sulfonamides plus clindamycin as an alternative therapeutic regimen for HIV-associated Toxoplasma encephalitis: a randomized controlled trial. Chin Med J (Engl). 2022;135(22).  
146. Hernandez A V., Thota P, Pellegrino D, Pasupuleti V, Benites-Zapata VA, Deshpande A, et al. A systematic review and meta-analysis of the relative efficacy and safety of treatment regimens for HIV-associated cerebral toxoplasmosis: is trimethoprim-sulfamethoxazole a real option? HIV Med. 2017;18(2).  
147. Connolly MP, Haitsma G, Hernández A V., Vidal JE. Systematic review and meta-analysis of secondary prophylaxis for prevention of HIV-related toxoplasmic encephalitis relapse using trimethoprim-sulfamethoxazole. Vol. 111, Pathogens and Global Health. 2017.  
148. Buchacz K, Lau B, Jing Y, Bosch R, Abraham AG, Gill MJ, et al. Incidence of AIDSDefining Opportunistic Infections in a Multicohort Analysis of HIV-infected Persons in the United States and Canada, 2000-2010. Journal of Infectious Diseases. 2016;214(6).  
149. Gelaw YM, Guracho YD, Robert-Gangneux F, Alene GD, Gangneux JP. The Burden of Pneumocystis Pneumonia Infection among HIV Patients in Ethiopia: A Systematic Review. Vol. 8, Tropical Medicine and Infectious Disease. 2023.  
150. Shibata S, Kikuchi T. Pneumocystis pneumonia in HIV-1-infected patients. Vol. 57, Respiratory Investigation. 2019.  
151. E.M. C, A.H. L. Update on the diagnosis and treatment of Pneumocystis pneumonia. Ther Adv Respir Dis. 2011;5(1).  
152. Salzer HJF, Schäfer G, Hoenigl M, Günther G, Hoffmann C, Kalsdorf B, et al. Clinical, Diagnostic, and Treatment Disparities between HIV-Infected and Non-HIV-Infected Immunocompromised Patients with Pneumocystis jirovecii Pneumonia. Vol. 96, Respiration. 2018.  
153. Fujii T, Nakamura T, Iwamoto A. Pneumocystis pneumonia in patients with HIV infection: Clinical manifestations, laboratory findings, and radiological features. Vol. 13, Journal of Infection and Chemotherapy. 2007.  
154. Salzberger B, Hartmann P, Hanses F, Uyanik B, Cornely OA, Wöhrmann A, et al. Incidence and prognosis of CMV disease in HIV-infected patients before and after introduction of combination antiretroviral therapy. Infection. 2005;33(5–6).  
155. Casado JL, Arrizabalaga J, Montes M, Martí-Belda P, Tural C, Pinilla J, et al. Incidence and risk factors for developing cytomegalovirus retinitis in HIV-infected patients receiving protease inhibitor therapy. AIDS. 1999;13(12).  
156. Arribas JR, Storch GA, Clifford DB, Tselis AC. Cytomegalovirus Encephalitis. Vol. 125, Annals of Internal Medicine. 1996.  
157. Wohl DA, Kendall MA, Andersen J, Crumpacker C, Spector SA, Feinberg J, et al. Low rate of cmv end-organ disease in hiv-infected patients despite low cd4+ cell counts and cmv viremia: Results of ACTG protocol a5030. HIV Clin Trials. 2009;10(3).  
158. Rodriguez-Barradas MC, Stool E, Musher DM, Gathe J, Goldstein J, Genta RRI, et al. Diagnosing and treating cytomegalovirus pneumonia in patients with AIDS. Clinical Infectious Diseases. 1996;23(1).  
159. Perello R, Vergara A, Monclus E, Jimenez S, Montero M, Saubi N, et al. Cytomegalovirus infection in HIV-infected patients in the era of combination antiretroviral therapy. BMC Infect Dis. 2019;19(1).  
160. Munro M, Yadavalli T, Fonteh C, Arfeen S, Lobo-Chan AM. Cytomegalovirus retinitis in HIV and non-HIV individuals. Vol. 8, Microorganisms. 2020.  
161. Marques S, Carmo J, Pinto D, Bispo M, Ramos S, Chagas C. Cytomegalovirus Disease of the Upper Gastrointestinal Tract: A 10-Year Retrospective Study. GE Port J Gastroenterol. 2017;24(6).  
162. Lin WR, Su MY, Hsu CM, Ho YP, Ngan KW, Chiu CT, et al. Clinical and endoscopic features for alimentary tract cytomegalovirus disease: Report of 20 cases with gastrointestinal cytomegalovirus disease. Vol. 28, Chang Gung Medical Journal. 2005.  
163. Jabs DA, Ahuja A, Van Natta M, Dunn JP, Yeh S. Comparison of treatment regimens for cytomegalovirus retinitis in patients with AIDS in the era of highly active antiretroviral therapy. Ophthalmology. 2013;120(6).  
164. Rekik M, Kammoun S, Kaibi I, Affes S, Ayadi O, Abid I, et al. Cytomegalovirus retinitis treated with intravitreous injection of ganciclovir. Ophthalmologica. 2021;244(SUPPL 1).  
165. Young S, Morlet N, Besen G, Wiley CA, Jones P, Gold J, et al. High-dose (2000-μg) intravitreous ganciclovir in the treatment of cytomegalovirus retinitis. Ophthalmology. 1998;105(8).  
166. Rachlis A, Smaill F, Walker V, Hotchkies L, Jones A. Incremental cost-effectiveness analysis of intravenous ganciclovir versus oral ganciclovir in the maintenance treatment of newly diagnosed cytomegalovirus retinitis in patients with AIDS. Pharmacoeconomics. 1999;16(1).  
167. Drew WL, Ives D, Lalezari JP, Crumpacker C, Follansbee SE, Spector SA, et al. Oral ganciclovir as maintenance treatment for cytomegalovirus retinitis in patients with AIDS. Syntex Cooperative Oral Ganciclovir Study Group [see comments]. N Engl J Med. 1995;333(10).  
168. Sah P, Patel P, Chandrashekar C, Martena S, Ballal M, Hegde M, et al. Oral candidal carriage correlates with CD4+ cell count but not with HIV and highly active antiretroviral therapy status. J Investig Clin Dent. 2019;10(4).  
169. Klein RS, Harris CA, Small CB, Moll B, Lesser M, Friedland GH. Oral Candidiasis in High-Risk Patients as the Initial Manifestation of the Acquired Immunodeficiency Syndrome. New England Journal of Medicine. 1984;311(6).  
170. Vazquez JA, Skiest DJ, Nieto L, Northland R, Sanne I, Gogate J, et al. A multicenter randomized trial evaluating posaconazole versus fluconazole for the treatment of oropharyngeal candidiasis in subjects with HIV/AIDS. Clinical Infectious Diseases. 2006;42(8).  
171. Pappas PG, Kauffman CA, Andes DR, Clancy CJ, Marr KA, Ostrosky-Zeichner L, et al. Clinical Practice Guideline for the Management of Candidiasis: 2016 Update by the Infectious Diseases Society of America. Vol. 62, Clinical Infectious Diseases. 2015.  
172. Linder KA, Kauffman CA. Histoplasmosis: Epidemiology, Diagnosis, and Clinical Manifestations. Vol. 13, Current Fungal Infection Reports. 2019.  
173. Adamian CMC, de Lima Mota MA, Martins AAF, Aragão MC, Carvalho MS, Meneses GC, et al. Progressive disseminated histoplasmosis in HIV-positive patients. Vol. 33, International Journal of STD and AIDS. 2022.  
174. Damasceno LS. Morbidity and survival after the first event of disseminated histoplasmosis in AIDS patients treated in reference units of Fortaleza/Ceará. [Fortaleza]: UFC; 2011.  
175. Couppié P, Herceg K, Bourne-Watrin M, Thomas V, Blanchet D, Alsibai KD, et al. The broad clinical spectrum of disseminated histoplasmosis in hiv-infected patients: A 30 years’ experience in French guiana. Vol. 5, Journal of Fungi. 2019.  
176. Caceres DH, Valdes A. Histoplasmosis and tuberculosis co-occurrence in people with advanced HIV. Journal of Fungi. 2019;5(3).  
177. Damasceno LS, Ramos AN, Alencar CH, Gonçalves MVF, de Mesquita JRL, Soares ATD, et al. Disseminated histoplasmosis in HIV-infected patients: Determinants of relapse and mortality in a north-eastern area of Brazil. Mycoses. 2014;57(7).  
178. Falci DR, Dalla Lana DF, Pasqualotto AC. The era of histoplasmosis in Brazilian endemic mycoses. Vol. 3, The Lancet Regional Health - Americas. 2021.  
179. Guidelines for Diagnosing and Managing Disseminated Histoplasmosis among People Living with HIV. Guidelines for Diagnosing and Managing Disseminated Histoplasmosis among People Living with HIV. 2020.  
180. Almeida MA, Damasceno LS, Pizzini CV, Muniz M de M, Almeida-Paes R, ZancopéOliveira RM. Role of western blot assay for the diagnosis of histoplasmosis in AIDS patients from a National Institute of Infectious Diseases in Rio de Janeiro, Brazil. Mycoses. 2019;62(3).  
181. D.R. F, A.A. M, C.F. BC, T.C.O. M, M.O. X, R.P. B, et al. Histoplasmosis, An Underdiagnosed Disease Affecting People Living with HIV/AIDS in Brazil: Results of a Multicenter Prospective Cohort Study Using Both Classical Mycology Tests and Histoplasma Urine Antigen Detection. Open Forum Infect Dis. 2019;6(4).  
182. Nacher M, Adenis A, Arathoon E, Samayoa B, Lau-Bonilla D, Gomez BL, et al. Disseminated histoplasmosis in Central and South America, the invisible elephant: The lethal blind spot of international health organizations. Vol. 30, AIDS. 2016.  
183. Ramos IC, Soares YC, Damasceno LS, Libório MP, Farias LABG, Heukelbach J, et al. Predictive factors for disseminated histoplasmosis in AIDS patients with fever admitted to a reference hospital in Brazil. Rev Soc Bras Med Trop. 2018;51(4).  
184. Silva TC, Treméa CM, Zara ALSA, Mendonça AF, Godoy CSM, Costa CR, et al. Prevalence and lethality among patients with histoplasmosis and AIDS in the Midwest Region of Brazil. Mycoses. 2017;60(1).  
185. Bongomin F, Kwizera R, Denning DW. Getting histoplasmosis on the map of international recommendations for patients with advanced hiv disease. Journal of Fungi. 2019;5(3).  
186. Riddell J, Joseph Wheat L. Central nervous system infection with histoplasma capsulatum. Vol. 5, Journal of Fungi. 2019.  
187. Damasceno LS, Teixeira M de M, Barker BM, Almeida MA, Muniz M de M, Pizzini CV, et al. Novel clinical and dual infection by Histoplasma capsulatum genotypes in HIV patients from Northeastern, Brazil. Sci Rep. 2019;9(1).  
188. Paixão AG, Almeida MA, Correia RES, Kamiensky BB, Zancopé-Oliveira RM, Lazera M dos S, et al. Histoplasmosis at a Reference Center for Infectious Diseases in Southeast Brazil: Comparison between HIV-Positive and HIV-Negative Individuals. Trop Med Infect Dis. 2023 May 1;8(5).  
189. Azar MM, Hage CA. Laboratory diagnostics for histoplasmosis. Vol. 55, Journal of Clinical Microbiology. 2017.  
190. Wheat LJ, Freifeld AG, Kleiman MB, Baddley JW, McKinsey DS, Loyd JE, et al. Clinical practice guidelines for the management of patients with histoplasmosis: 2007 Update by the Infectious Diseases Society of America. Vol. 45, Clinical Infectious Diseases. 2007.  
191. Nacher M, Le Turnier P, Abboud P, Françoise U, Lucarelli A, Demar M, et al. Primary or secondary prevention of HIV-associated histoplasmosis during the early antiretrovirals for all era. PLoS Negl Trop Dis. 2023;17(2).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
**<u>Quadro A</u>** - Lista de medicamentos <u>preconizados neste Protocolo.</u>  
|**Princípio ativo**|**Apresentação disponível no SUS**|
|---|---|
|Aciclovir|Comprimido de 200 mg|
|Ácido folínico|Comprimido de 15 mg|
|Anfotericina B(complexo lipídico)|Suspensão injetável de 5 mg/mL|
|Anfotericina B(desoxicolato)|Pópara solução injetável de 50 mg|
|Anfotericina B(lipossomal)|Pópara solução injetável de 50 mg|
|Anidulafungina|Pópara solução injetável de 100 mg|
|Azitromicina|Comprimidos de 250 mgou 500 mg<br>|
|Benzilpenicilina benzatina|Pó para suspensão injetável ou suspensão injetável de<br>1.200.000 UI|
|Benzilpenicilinapotássica|Pópara solução injetável de 5.000.000 UI|
|Benznidazol|Comprimidos de 100 mg|
|Ceftriaxona|Pópara solução injetável de 1g|
|Claritromicina|Comprimido de 250 mg<br>Comprimido ou cápsulade 500mg|
|Cloridrato de clindamicina|Cápsulas de 150 mgou 300 mg|
|Cloridrato de doxiciclina|Comprimido de 100 mg|
|Cloridrato de etambutol|Comprimido de400mg|
|Dapsona|Comprimidos de 100 mg|
|Difosfato deprimaquina|Comprimido de 5 mgou 15 mg|
|Fosfato dissódico de dexametasona|Solução injetável de 4 mg/mL|
|Flucitosina|Cápsula de 250 mgou 500 mg|
|Fll|Cápsula de 100 mg|
|uconazo|Solução injetável de 2 mg/mL|
|Isoniazida|Comprimido de 100 mg<br>Comprimido de300 mg|
|Itraconazol|Cápsula de 100 mg|
|Metilprednisolona|Pópara solução injetável 500 mg|
|Miltefosina|Cápsula de 10 mgou 50 mg|
|Nifurtimox|Comprimidos de 120 mg|
|Nistatina|Suspensão oral de 100.000 UI/mL|
|Pirazinamida|Comprimido de 500mg|
|Pirimetamina|Comprimido de 25 mg|
|PQT-U adulto|Rifampicina 150 mg ou 300 mg cápsula<br>Clofazimina 50 mg ou 100 mg cápsula<br>Dapsona 100mg comprimido|
|Prednisona|Comprimido de 5 mgou 20 mg|
|Rifabutina|Cápsula de 150 mg|
|Rifampicina|Cápsulade150mg|
|Rifampicina + isoniazida|Comprimido de 150 mg+ 75 mg<br>Comprimido de 300mg+ 150mg|
|Rifampicina + isoniazida +<br>pirazinamida +cloridrato de etambutol|Comprimido de 150 mg + 75 mg + 400 mg + 275 mg|
|Rifapentina|Comprimido de 150 mg|
|Sulfadiazina|Comprimido de 500 mg<br>|
|Sulfametoxazol+ trimetorima|Solução injetável de 80 mg/mL + 16 mg/mL|
|p|Comprimido de 400 mg+80 mg|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
1. A Instituição solicitante deverá estar cadastrada junto ao Sistema Integrado de Administração de Material (SISMAT). Para isto, enviar por e-mail os dados da Instituição: Nome, CNES, CNPJ, endereço completo com CEP, telefone para contato e nome do responsável pela farmácia/recebimento do medicamento.  
2. Para a liberação de complexo lipídico de anfotericina B, anfotericina B lipossomal, flucitosina e itraconazol é necessário que seja enviado um formulário próprio do Ministério da Saúde de solicitação de medicamentos antifúngicos para pacientes com micoses sistêmicas. Este formulário é individual e deverá estar completamente preenchido. A liberação dos medicamentos obedece às indicações de consensos nacionais e internacionais.  
3. Enviar a ficha de solicitação preenchida para o email: <u>micosessistemicas@saude.gov.br.</u>  
4. Deverão estar anexados no email, além da ficha de solicitação: laudo ou sorologia para o HIV e cópia do laudo(s) **recente(s** ) da infecção fúngica.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Geral -->
<!-- Start of picture text -->
Numero da ficha: / (Para uso do Ministério da Satide)<br>Data da solicitac3o: / I<br>INSTITUICAO SOLICITANTE<br>Hospital ou instituicao:<br>Médico solicitante:<br>CRM: Telefone: ( Celular: (_)<br>Responsavel pelo recebimento:<br>Cargo: Telefone: ( ) Celular: (_)<br>Endereco para entrega:<br>CEP: Cidade: UF:<br>IDENTIFICACAO DO PACIENTE<br>Nome do paciente:<br>Nome da mae:<br>Data de nascimento:. ff Sexo:( )Masculino { )Feminino Peso: ke|<br>Endereco de procedéncia:<br>Municipio de residéncia:, UF:<br><!-- End of picture text -->  
DADOS CLINICOS ATUAIS (Descreva brevemente a histdria clinica do paciente, como internacdes, exames laboratoriais anteriores, entre outros):  
Inicio dos sinais e sintomas:___/__ Co- morbidades: ( )Ausente — (__) Doenga renal (_ ) Doenga cardiaca ( ) Doenca hepatica ( ) Doenca onco-hematolégica ( ) HIV/Aids Especificar: Outras: EXAME MICOLOGICO: MATERIAL, 2) Positivo (_ ) Negativo OUTROS: DIAGNOSTICO: (Especificar e anexar cépia do laudo)  
<!-- Start of picture text -->
EXAMES COMPLEMENTARES ATUAIS<br>Hemacias: x106 Hematécrito: % Hemoglobina: g/DI<br>Plaquetas: mm? Leucécitos: mm? Neutréfilos: mm?<br>AST/TGO: U/L ALT/TGP: U/L Bilirrubina total: me/dL.<br>Bilirrubina D: mg/dL Ativ. de protrombina: % Ureia: mg/dL<br>Creatinina: mg/dL D4. céls/mm*<br>Outros:<br><!-- End of picture text -->  
TRATAMENTO(S )ESPECIFICO(S) REALIZADO(S) (Solicitacdo individual)  
(_) Virgem de tratamento  
(_ ) Anfotericina B Desoxicolato Dose total administrada: (. ) Anfotericina B complexo lipidico: Dose: me/kg/dia Dose total administrada:. ———— (_ ) Anfotericina 8 lipossomal: Dose: ma/ke/dia Dose total administrada: (. )itraconazol: Dose diéria: Tempo de tratamento:. }~———— (_ ) Fluconazol sol.injetével Dose didria: Tempo de tratamento: (_ ) Fluconazol cépsulas Dose didria: Tempo de tratamento: (. )Flucitosina Dose didria: Tempo de tratamento: ( )Voriconazol Dose diéria: Tempo de tratamento:  
ESQUEMA TERAPEUTICO PRESCRITO:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
Dose(s) prescrita(s):  
Tempo previsto de tratamento: Quantitativo(s)  
Medicamento(s):____ Dose(s) prescrita(s):  
Tempo previsto de tratamento: Quantitativo(s)  
NO CASO DE INDICACAO DE FORMULACAO LIPIDICA DE ANFOTERICINA B  
(_) Refratariedade & outro esquema terapéutico  
Especificar:  
(Assinatura e carimbo do médico)

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
- Antes da administração de anfotericina: infusão de um litro de solução salina com uma  
- ampola de cloreto de potássio (KCl) 19,1% em duas a quatro horas.  
- Após administração da anfotericina: dieta rica em potássio e suplementação com KCl <u>oral 8 mEq duas vezes ao dia.</u>  
**MONITORAMENTO**  
- Dosagem de creatinina, ureia, sódio e potássio séricos pré-tratamento e duas vezes por semana durante tratamento.  
- Hemograma pré-tratamento <u>e uma vez por semana durante tratamento.</u>  
- **MANEJO DA ELEVAÇÃO DA Cr**  
- Se houver hipocalemia significativa (potássio menor que 3,3 mmol/L), aumentar a suplementação de potássio para duas ampolas de KCl (40 mmol) ou um a dois comprimidos de KCl (8 mEq) três vezes ao dia. Monitorar diariamente potássio sérico.  
- Se a hipocalemia não for corrigida, dobrar a suplementação oral de magnésio.  
- Se houver aumento >2x do valor basal da Cr, avaliar descontinuação temporária da dose de anfotericina B ou aumento da pré-hidratação para um litro a cada oito horas. Quando os níveis de Cr melhorarem, reiniciar a anfotericina B na dose de 0,7 mg/kg/dia (considerar anfotericina B em dias alternados). Se a Cr permanecer elevada, interromper a anfotericina B e continuar com fluconazol 1.200 mg/dia. Monitorar a Cr diariamente.  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Adultos - Módulo 2: Coinfecções e Infecções Oportunistas contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), o Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI/SVS/MS) constituiu um grupo de trabalho interno para revisão e atualização deste PCDT. Este grupo foi composto por técnicos do DATHI e um comitê assessor. Além disso, outros profissionais de diversas áreas da saúde participaram enquanto colaboradores, conforme elencado a seguir:  
Álisson Bigolin Marcus Vinicius Guimaraes de Lacerda Amílcar Tanuri Maria Adelaide Millington Ana Cristina Garcia Ferreira Maria Clara Gianna Garcia Ribeiro Ana Roberta Pati Pascom Mayara Maia Lima André Bon Fernandes da Costa Mayra Gonçalves Aragón Beatriz Brittes Kamiensky Monica Jacques de Moraes Beatriz Gilda Jegerhorn Grinsztejn Nicole Menezes de Souza Camila Fernanda dos Santos Santana Orlando Marcos Farias de Sousa Celso Ferreira Ramos Filho Pâmela Cristina Gaspar Denize Lotufo Estevam Paula Pezzuto Draurio Barreira Cravo Neto Paulo Abrão Ferreira Érico Antônio Gomes de Arruda Ricardo Sobhie Diaz Estevão Portela Nunes Rodrigo Ramos de Sena Fernanda Dockhorn Costa Romina do Socorro Marques de Oliveira Francisco Álisson Paula de França Ronaldo Campos Hallal Guilherme Alves de Lima Henn Ronaldo Zonta Gustavo Luís Meffe Andreoli Rosalynd Moreira José Ernesto Vidal Bermudez Rosana Del Bianco José Luiz de Andrade Neto Simone de Barros Tenore José Valdez Ramalho Madruga Swamy Lima Palmeira Kathiely Martins dos Santos Tatianna Meireles Dantas de Alencar Leonor Henriette de Lannoy Tayrine Huana de Sousa Nascimento Lilian Nobre de Moura Thiago Cherem Morelli Liliana Romero Veja Valdilea Veloso Lisandra Serra Damasceno Valéria Cavalcanti Rolla Marcelo Yoshito Wada Veruska Maia da Costa Marcia Leite de Sousa Gomes  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT para Manejo da Infecção pelo HIV em Adultos - Módulo 2: Coinfecções e Infecções Oportunistas foi apresentada na 107ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 20 de julho de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Saúde Indígena (SESAI) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). Foram sugeridos alguns ajustes no Apêndice Metodológico e textuais do documento. Também foi solicitada a revisão de referências e inclusão de informações sobre as formas farmacêuticas disponíveis no SUS. O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 121ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
A Consulta Pública nº 34/2023, para atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 2 – Coinfecções e Infecções Oportunistas, foi realizada entre os dias 10/08/2023 e 29/08/2023. Foram recebidas 07 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/CP_CONITEC_034_2023_PCDT_para_Manejo.pdf</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
A atualização do PCDT para Manejo da Infecção pelo HIV em Adultos - Módulo 2: Coinfecções e Infecções Oportunistas contou com a participação do comitê de _experts_ no tratamento da doença. O grupo de especialistas foi composto por representantes da comunidade científica, representante da Sociedade Brasileira de Infectologia, representantes da sociedade civil e especialistas com longa experiência no cuidado e tratamento de pessoas que vivem com HIV e Aids, oriundos de instituições envolvidas com o cuidado às pessoas vivendo com HIV.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia às reuniões de escopo e formulação de recomendações.  
Para a atualização das recomendações do novo documento, elaborou-se uma proposta inicial do escopo de atualização do PCDT, que motivou a primeira reunião on-line com o grupo técnico assessor realizada em novembro de 2022. Nesta reunião, foram estabelecidos os pontos que demandavam atualização, considerando as novas tecnologias em saúde previamente incorporadas, o cenário epidemiológico e as principais estratégias de enfrentamento à epidemia de Aids.  
Diante do exposto, foram realizadas buscas na literatura científica por revisões sistemáticas, ensaios clínicos randomizados, além de protocolos e diretrizes clínicas internacionais sobre os temas específicos de cada uma das seções. Também foram utilizados os  
Relatórios de Recomendação referente às novas tecnologias incorporadas, como o LF-LAM, CrAg, flucitosina, anidulafungina. Também foram consultados os protocolos clínicos e diretrizes terapêuticas e demais publicações do Ministério da Saúde referentes às coinfecções e infecções oportunistas.  
Após a análise das evidências científicas, buscou-se identificar as necessidades de atualização do PCDT publicado em 2017, como subsídio para a nova reunião com o grupo de especialistas, que ocorreu em junho de 2023. O levantamento de evidências resultante das buscas na literatura científica, foi utilizado para elaboração da proposta preliminar.  
Previamente, os especialistas receberam a proposta elaborada pela Coordenação-Geral de Vigilância do HIV/Aids e das Hepatites Virais (CGAHV/DATHI/SVSA/MS) e que elencava os pontos chave para atualização do PCDT. Durante o encontro, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura.  
Os principais temas atualizados foram:  
- a) Inclusão do IGRA para diagnóstico da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) quando LT-CD4 < 350 células.  
- b) Inclusão da rifapentina como esquema preferencial para tratamento da ILTB.  
- c) Inclusão dos testes rápidos Lipoarabinomanano em urina (LF-LAM) e do Antígeno criptocócico (LF-CrAg) como rastreio para PVHA com dano imunológico grave.  
- d) Inclusão da flucitosina para o tratamento de pacientes com meningite criptocócica e demais formas de neurocriptococose.  
- e) Atualização do tempo de início da terapia antirretroviral em pessoas coinfectadas com TB-HIV e no esquema antirretroviral preferencial para esse grupo.  
- f) Proposição do esquema TDF/3TC associado a DTG 50 mg em dose dobrada como esquema preferencial na coinfecção TB-HIV.  
- g) Atualização do esquema terapêutico para hanseníase.  
- h) Inclusão do tenofovir alafenamida (TAF) como opção terapêutica para PVHA com HBV-HIV, quando indicado.  
- i) Atualização dos esquemas terapêuticos para micoses sistêmicas, incluindo como preferencial ou alternativo as anfotericinas nas formulações lipídicas.  
- j) Ampliação da indicação da anfotericina B lipossomal na coinfecção Leishmaniose e HIV.  
Após a reunião, as decisões foram incorporadas ao texto do documento final, o qual foi compartilhado com o grupo de especialistas para a definição da versão final, sendo que as sugestões adicionais foram consolidadas pela equipe da CGAHV/DATHI/SVSA/MS.  
Na sequência, a minuta de texto atualizado foi apresentada à Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS) e, após revisão, foi avaliada pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 2 | secao: Medicamento(s):____ -->
|**Número do**<br>**Relatório da diretriz**||**Tecnologias avaliadaspela**|**Conitec**|
|---|---|---|---|
|<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação**<br>**ou não alteração no**<br>**SUS**|
|Relatório<br>de<br>Recomendação<br>nº<br>854/2023|Desmembramento<br>do<br>texto<br>em<br>módulos;<br>Atualização do texto<br>do<br>documento<br>e<br>inclusão<br>de<br>orientações<br>referentes<br>às<br>tecnologias<br>incorporadas|Incorporação do teste de Liberação de<br>Interferon-gama (IGRA) para detecção de<br>infecção<br>latente<br>pelo<br>_Mycobacterium_<br>_tuberculosis_em pacientes com doenças<br>inflamatórias imunomediadas ou receptores<br>de transplante de órgãos sólidos<br>[Portaria SCTIE/MS nº 50/2020; Relatório<br>de Recomendação nº 573]<br>Incorporação<br>de<br>anidulafungina<br>para<br>tratamento de pacientes com candidemia e<br>outras formas de candidíase invasiva<br>[Portaria SCTIE/MS nº 55/2022; Relatório<br>de Recomendação nº 743]<br>Incorporação do teste diagnóstico, point of<br>care, de_Cryptococcal Antigen Lateral Flow_<br>_Assay_(CRAG-LFA) para detecção de<br>infecção por_Cryptococcus_e diagnóstico de<br>meningite criptocócica em pessoas vivendo<br>com o vírus da imunodeficiência humana<br>(PVHIV)<br>[Portaria SCTIE/MS nº 28/2021; Relatório<br>de Recomendação nº 615]<br>Incorporação<br>de<br>flucitosina<br>para<br>o<br>tratamento de pacientes com meningite<br>criptocócica<br>e<br>demais<br>formas<br>de<br>neurocriptococose<br>[Portaria SCTIE/MS nº 21/2021; Relatório<br>de Recomendação nº 614]<br>Incorporação do teste de fluxo lateral para<br>detecção de lipoarabinomanano em urina<br>(LF-LAM) para rastreamento e diagnóstico<br>de tuberculose ativa em pessoas suspeitas<br>vivendo com HIV/AIDS<br>[Portaria SCTIE/MS nº 02/2022; Relatório<br>de Recomendação nº 591]|-|
|Portaria SCTIE/MS nº<br>52,<br>de<br>23/11/2017<br>[Relatório<br>de<br>Recomendação<br>nº<br>299]|Primeira versão do<br>documento|-|-|

---

