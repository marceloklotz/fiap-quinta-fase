<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: PORTARIA CONJUNTA Nº 13, DE 12 DE AGOSTO DE 2021. -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Linfangioleiomiomatose.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre a linfangioleiomiomatose no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 624/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 629 – Junho de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Linfangioleiomiomatose.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da linfangioleiomiomatose, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de</u> caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da linfangioleiomiomatose.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: SERGIO YOSHIMASA OKANE -->
HÉLIO ANGOTTI NETO

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 1. **INTRODUÇÃO** -->
A linfangioleiomiomatose (LAM) é uma doença sistêmica rara, que afeta principalmente mulheres jovens, ocorrendo esporadicamente ou como parte do complexo de esclerose tuberosa (TSC - _tuberous sclerosis complex_ ). Em ambos os casos, a LAM está associada à inativação mutacional dos genes supressores de tumor TSC1 e TSC2<sup>1</sup> .  
Os genes TSC1 e TSC2 codificam duas proteínas, hamartina e tuberina, que juntas inibem a mTOR ( _Mammalian target of Rapamycin_ ), um importante regulador do crescimento, proliferação e sobrevida celular<sup>2</sup> .  
Dessa forma, acredita-se que a deficiência de tuberina e hamartina gera desregulação na via de sinalização mTOR sendo a causa da proliferação anormal das células LAM<sup>1</sup> .  
A LAM é caracterizada pela proliferação anormal de células do músculo liso (células LAM) que crescem de maneira aberrante nas vias aéreas e linfáticas, espaço parenquimatoso dos pulmões e vasos sanguíneos, gerando lesões pulmonares císticas, cistos contendo fluido linfático, espessamento das paredes vasculares, rompimento linfático e oclusão venosa, levando ao estreitamento das vias aéreas e pneumotórax. A LAM é geralmente agressiva e pode levar a insuficiência respiratória<sup>1</sup> .  
A LAM apresenta-se como de dois tipos:  
- a) LAM esporádica (S-LAM, não hereditária), causada por mutações somáticas do gene TSC2<sup>1</sup> ; e  
b) LAM associada ao complexo da esclerose tuberosa (TSC-LAM, hereditária) é um distúrbio autossômico  
dominante causado por mutações no TSC1 ou TSC2 e caracterizado por retardo mental, autismo, convulsões e lesões  
hamartomatosas no cérebro, coração, pele, rim, olhos, pulmões e fígado<sup>3</sup> .  
Além das manifestações pulmonares, a LAM tem manifestações extrapulmonares, como adenomegalias retroperitoneais, angiomiolipomas renais, linfangiomiomas e derrames quilosos<sup>1</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa estabelecer os critérios diagnósticos e terapêuticos da linfangioleiomiomatose. A metodologia de busca e avaliação das evidências estão descritas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 2. **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
J84.8 – Outras doenças pulmonares intersticiais especificadas.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 3. **DIAGNÓSTICO** -->
O diagnóstico de LAM segue um passo-a-passo, iniciando-se com as intervenções menos invasivas. Modificações com base na avaliação clínica são frequentemente necessárias, e as decisões devem ser individualizadas<sup>4</sup> .  
O diagnóstico tem como base a suspeita clínica e o resultado de tomografia de tórax (TC) com alterações características (ver o sub-item 3.3.)  
Além disso, o paciente deve apresentar, pelo menos, um dos seguintes achados:  
- Presença do complexo de esclerose tuberosa (TSC);  
- presença de angiomiolipomas renais à TC ou ressonância magnética de abdômen;  
- presença de linfangioleiomiomas (ou linfangiomas) à TC ou ressonância magnética de abdômen e pelve;  
- presença de efusões quilosas (quilotórax ou ascite quilosa);  
- exame citopatológico positivo para células LAM em exame de efusões quilosas ou linfonodos; ou  
- exame histopatológico de material obtido por biópsia pulmonar (transbrônquica ou cirúrgica) diagnóstico de LAM  
- – se dado como necessário para o diagnóstico definitivo.  
O fator de crescimento endotelial vascular (VEGF-D) é um marcador relacionado à fisiopatologia da doença e encontra-se elevado em pacientes com LAM, principalmente quando há acometimento do sistema linfático<sup>1,4</sup> . Mas a principal desvantagem desse teste é que está certificado unicamente em poucos centros de referência no mundo<sup>5</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 3.1 **. Suspeita Diagnóstica** -->
Uma vez que é uma população com maior prevalência de LAM, deve-se suspeitar desta doença em caso de mulheres jovens de meia-idade com dispneia progressiva, associada ou não a pneumotórax ou quilotórax<sup>6</sup> .  
A maioria dos pacientes com LAM apresentará um distúrbio obstrutivo nos testes de função pulmonar (TFP). No entanto, alguns pacientes, especialmente no início da doença, podem ser assintomáticos e apresentar TFP normal<sup>4</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 3.2 **. Suspeita de complexo de esclerose tuberosa (TSC)** -->
O TSC é sugerido pela presença de qualquer dos seguintes achados:  
- Fibromas subungueais;  
- angiofibromas faciais;  
- máculas hipomelanóticas;  
- lesões em confete;  
- manchas de Shagreen;  
- histórico familiar positiva de tumor do complexo de esclerose tuberosa; ou  
- histórico de convulsões, comprometimento cognitivo ou presença de displasias corticais, nódulos sub-  
ependimários, associados ou não a astrocitomas sub-ependimários de células gigantes na imagem cerebral.  
Caso haja incerteza quanto ao diagnóstico de TSC, deve-se encaminhar o paciente para um centro especializado<sup>4</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 3.3.1 **. Tomografia computadorizada** -->
Tomografias computadorizadas do tórax, abdômen e pelve devem ser realizadas para detectar cistos pulmonares e anormalidades abdômino-pélvicas, como linfangioleiomiomas e angiomiolipomas renais.  
À TC de tórax, inclusive de alta resolução (TCAR), os achados característicos de LAM incluem a presença de cistos múltiplos, bilaterais, redondos, bem definidos, relativamente uniformes e de paredes finas com uma distribuição difusa, enquanto o parênquima pulmonar entre os cistos geralmente aparece normal.  
Outras características que podem ser observadas na TC em alguns pacientes com TSC-LAM incluem derrame pleural quiloso, pneumotórax, opacidade em vidro fosco sugestivo de congestão quilosa ou múltiplos nódulos minúsculos característicos da hiperplasia multifocal micronodular de pneumócitos.  
O diagnóstico de angiolipoma geralmente pode ser feito radiograficamente com base na presença de gordura nos tumores. O uso rotineiro de contraste não é necessário nem recomendado para o diagnóstico de LMA. O contraste é útil para definir a carga aneurismática e outras características vasculares do tumor, como para avaliar o potencial de hemorragia  
ou planejar uma embolização. Da mesma forma, os linfangioleiomiomas podem ser tipicamente diagnosticados com base na aparência radiográfica característica<sup>4</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 3.3.2 **. Diagnóstico patológico** -->
A decisão de obter confirmação por meios invasivos para exame cito- ou histopatológico deve ser individualizada<sup>4,7</sup> .  
Todas as tentativas devem ser feitas para estabelecer o diagnóstico de LAM com segurança antes do início da terapia  
medicamentosa com inibidor da mTOR.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 4. **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo:  
Pacientes com mais de 18 anos e com diagnóstico de LAM que apresentem pelo menos um dos critérios a seguir:  
- VEF1 inferior a 70% do predito;  
- declínio funcional avaliado com, pelo menos, 3 medidas de VEF1 ao longo de, no mínimo, 6 meses (8); ou  
- presença de acúmulos quilosos sintomáticos antes de considerar tratamentos invasivos como drenagens  
percutâneas intermitentes e inserção de dispositivos de drenagem permanentes.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 5. **CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes menores de 18 anos e aqueles que apresentem intolerância, hipersensibilidade ou contraindicação ao uso do medicamento preconizado.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 6. **CASOS ESPECIAIS** -->
Pacientes que não atendam aos critérios de inclusão deverão ser avaliados por médico com experiência no tratamento da LAM e, preferencialmente, em centro especializado.  
Poderão receber o tratamento medicamentoso, os pacientes que apresentarem VEF1 normal ou ligeiramente reduzido, especialmente aqueles sintomáticos e, com pelo menos, uma das seguintes alterações:  
 Evidência de anormalidade da função pulmonar: volume residual elevado (>120 do predito) ou capacidade de difusão reduzida (<80%);  
 Evidência de anormalidade da troca gasosa: desaturação induzida por exercício (<89%) ou hipoxemia em repouso (PaO2<70 mmHg);  
 Angiolipoma renal > 4 cm de diâmetro em pacientes sem indicação de embolização ou resseção cirúrgica como tratamento preferencial.  
Em mulheres em idade fértil, é necessário usar um método contraceptivo eficaz antes do início, durante e por 12 semanas após a suspensão do tratamento com sirolimo. O medicamento só deve ser utilizado durante a gravidez se o benefício potencial à mãe compensar o risco potencial ao embrião ou ao feto.  
O sirolimo é excretado em quantidades muito pequenas no leite de ratas em fase de amamentação. Não se sabe se o sirolimo é excretado no leite humano. Deve-se escolher entre a descontinuação da amamentação ou da terapia com sirolimo.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7. **TRATAMENTO** -->
A LAM esporádica é geralmente uma doença progressiva caracterizada por deterioração da função pulmonar. Em pacientes com TSC-LAM e doença progressiva, preconiza-se o acompanhamento regular da função pulmonar para detectar e intervir precocemente, quando houver mudança no quadro clínico. Em casos de paciente com TSC-LAM e sintomas mínimos, o risco de LAM grave parece ser menor do que naqueles com LAM esporádica<sup>6</sup> . Assim como outras doenças pulmonares, os pacientes com LAM devem ser incentivados a manter um peso normal e a não fumar.  
Embora não haja estudos específicos que tenham examinado o impacto da reabilitação pulmonar na LAM, evidências de benefício podem ser extrapoladas de outras doenças, incluindo a DPOC<sup>8</sup> . Um quarto dos pacientes responde aos broncodilatadores inalatórios de acordo com critérios objetivos padrão e podem obter algum benefício clínico. Embora a inflamação bronquiolar seja observada em alguns pacientes, a eficácia de corticosteroide inalado na LAM não foi avaliada<sup>6,8</sup> .  
O cuidado do paciente com LAM inclui o controle de complicações, como pneumotórax, quilotórax e ascite quilosa e o tratamento medicamentoso nos casos que tenham indicação. O transplante pulmonar pode ser a única opção para pacientes com LAM avançado ou naqueles com doença refratária ao tratamento com inibidor de mTOR<sup>5</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7.1 **. Tratamento Medicamentoso** -->
A LAM era considerada uma doença fatal em mulheres em idade fértil, uma vez que não havia tratamento eficaz, exceto o transplante de pulmão. A descoberta da relação entre a LAM e a presença das mutações nos genes TSC1 e TSC2 justificou o desenvolvimento de estudos clínicos para a avaliação dos medicamentos da classe dos inibidores de mTOR, já indicada e amplamente usada para a profilaxia da rejeição de transplantes, para o tratamento de LAM<sup>4</sup> .  
O sirolimo, um inibidor de mTOR, foi incorporado no âmbito do SUS para o tratamento de indivíduos adultos com LAM por meio da Portaria SCTIE/MS nº 24, de 04 de agosto de 2020. Esse fármaco é um imunossupressor que inibe a proliferação celular e a produção de anticorpos. Após penetrar a célula, o sirolimo, se liga à proteína FKBP12, formando um complexo fármaco-proteína que inibe uma proteína citoplasmática (mTOR). A mTOR está envolvida na via de sinalização intracelular que coordena os processos de crescimento, metabolismo, proliferação celular, autofagia e angiogênese. A inibição da mTOR promove a redução da síntese de proteínas, bloqueando a proliferação e diferenciação após a ativação celular, inibindo a proliferação celular e a produção de anticorpos<sup>9</sup> .  
É importante considerar a adequada indicação inicial do uso do tratamento medicamentoso para tomar decisões de tratamento porque o medicamento tem toxicidade e a exposição contínua é necessária para um benefício duradouro<sup>5</sup> .  
Espera-se que com uso de sirolimo em pacientes com indicação haja uma progresão mais lenta da doença.<sup>5</sup>

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7.2 **. Fármacos** -->
 Sirolimo: drágeas de 1 mg e 2 mg.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7.3 **. Esquemas de Administração** -->
A dose inicial de sirolimo deve ser de 2 mg/dia. As concentrações de sirolimo no sangue total devem ser medidas em intervalos de 10 a 20 dias, com ajuste de dose para a manutenção das concentrações séricas entre 5 -15 ng/mL. Na maioria dos pacientes, os ajustes de dose podem ser baseados na simples proporção: nova dose de sirolimo = dose atual x (concentração alvo/concentração atual). Frequentes ajustes de dose de sirolimo com base em seus níveis séricos e no estado de não equilíbrio podem levar à superdose ou subdose, já que esse medicamento possui meia-vida longa<sup>10</sup> .  
Uma vez que a dose de manutenção de sirolimo tenha sido ajustada, os pacientes devem continuar na nova dose de  
manutenção por, pelo menos, 7 a 14 dias antes de um novo ajuste de dose com o monitoramento da concentração. Quando a dose estável for alcançada, a monitorização terapêutica deve ser realizada, pelo menos, a cada três meses<sup>10</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7.4 **. Contraindicações e precauções** -->
O uso do medicamento é contraindicado para pacientes com hipersensibilidade conhecida ao sirolimo ou qualquer outro componente da formulação.  
Eventos adversos esperados (que ocorrem em uma frequência ≥ 20%) incluem estomatite, diarreia, dor abdominal, náusea, nasofaringite, acne, dor no peito, fadiga, edema periférico, infecção do trato respiratório superior, tosse, dispneia, dor de cabeça, tontura, mialgia e hipercolesterolemia.  
Devido à imunossupressão, pacientes em uso de sirolimo apresentam maior suscetibilidade a infecções e possível desenvolvimento de linfoma e outros tipos de câncer. Reações de hipersensibilidade, incluindo reações anafiláticas (anafilactoides), angioedema, dermatite esfoliativa e vasculite por hipersensibilidade foram associadas à administração de sirolimo<sup>10</sup> .  
Toxicidades adicionais que são encontradas com inibidores de mTOR incluem formação de cisto ovariano, dismenorreia, proteinúria, testes de função hepática elevados, pneumonite induzida por drogas<sup>11</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 7.5 **. Critérios de interrupção** -->
O uso de sirolimo deve ser suspenso pelo médico especialista que acompanha o paciente, nos casos em que os riscos superem os benefícios do uso ou que o seu uso não tenha mais indicação por refratariedade ao tratamento ou evidência de toxicidade com o uso contínuo.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 8. **MONITORAMENTO** -->
O monitoramento do uso do medicamento deve buscar identificar eventos adversos e potenciais interações medicamentosas. Os pacientes também devem ser monitorados quanto à hiperlipidemia e eventos relacionados com uso de imunossupressores.  
Com o uso do sirolimo é esperada melhora na função pulmonar (medida pelo FEV1 e FVC),  no desempenho funcional e a qualidade de vida em pacientes com LAM. Além disso, espera-se também a redução do volume de angiomiolipomas, linfangioleiomiomas e acúmulos quilosos<sup>11</sup> .

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 9. **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Pacientes com LAM devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no tratamento e acompanhamento.  
Devem ser observados os critérios de inclusão e de exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de sirolimo prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 10. **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se cientificar o paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos  
relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: 11. **REFERÊNCIAS** -->
1. Moir LM. Lymphangioleiomyomatosis: Current understanding and potential treatments. _Pharmacol Ther_ . 2016;158:114-124. doi:10.1016/j.pharmthera.2015.12.008  
2. Zoncu R, Efeyan A, Sabatini DM. mTOR: from growth signal integration to cancer, diabetes and ageing. _Nat Rev Mol Cell Biol_ . 2011;12(1):21-35. doi:10.1038/nrm3025  
3. Randle SC. Tuberous sclerosis complex: A review. _Pediatr Ann_ . 2017;46(4):e166-e171. doi:10.3928/1938235920170320-01  
4. Gupta N, Finlay GA, Kotloff RM, et al. Lymphangioleiomyomatosis Diagnosis and Management: High-Resolution Chest Computed Tomography, Transbronchial Lung Biopsy, and Pleural Disease Management. An Official American Thoracic Society/Japanese Respiratory Society Clinical Practice Guideline. _Am J Respir Crit Care Med_ . 2017;196(10):13371348. doi:10.1164/rccm.201709-1965ST  
5. McCormack FX, Gupta N. Sporadic lymphangioleiomyomatosis: Clinical presentation and diagnostic evaluation. _UpToDate_ . Published online 2020.  
6. Taveira-DaSilva AM, Moss J. Clinical features, epidemiology, and therapy of lymphangioleiomyomatosis. _Clin Epidemiol_ . 2015;7:249-257. doi:10.2147/CLEP.S50780  
7. Harari S, Cassandro R, Torre O. The ATS/JRS Guidelines on Lymphangioleiomyomatosis: Filling in the Gaps. _Am J Respir Crit Care Med_ . 2017;196(5):659-660. doi:10.1164/rccm.201702-0272LE  
8. Johnson SR, Cordier JF, Lazor R, et al. European Respiratory Society guidelines for the diagnosis and management of lymphangioleiomyomatosis. _Eur Respir J_ . 2010;35(1):14-26. doi:10.1183/09031936.00076209  
9. Oliveira NI, Harada KM, Spinelli GA, et al. Eficácia, tolerabilidade e segurança do uso do sirolimo após o transplante renal. _Brazilian J Nephrol_ . 2009;31:258-268. http://www.scielo.br/scielo.php?script=sci_arttext&pid=S010128002009000400004&nrm=iso  
10. Whyet. Rapamune (Bula). Published online 2020:1-35.  
11. McCormack FX, Gupta N, Finlay GR, et al. Official American Thoracic Society/Japanese Respiratory Society Clinical Practice Guidelines: Lymphangioleiomyomatosis Diagnosis and Management. _Am J Respir Crit Care Med_ . 2016;194(6):748761. doi:10.1164/rccm.201607-1384ST  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
SIROLIMO  
Eu,____________________________________________________ (nome do(a) paciente), declaro ter sido informado(a)  
claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **sirolimo,** indicado para o tratamento da **linfangioleimiomatose (LAM)** .  
A LAM é uma doença que se apresenta com maior frequência em mulheres em idade fértil e não há estudos do uso do Sirolimo em mulheres grávidas. Estudos em animais, a toxicidade embrio/fetal manifestou-se como mortalidade e redução do peso do feto. O sirolimo é excretado em quantidades muito pequenas no leite de ratas em fase de amamentação. Não se sabe se o sirolimo é excretado no leite humano.  
O uso do sirolimo pode causar estomatite, diarreia, dor abdominal, náusea, nasofaringite, acne, dor no peito, fadiga, edema periférico, infecção do trato respiratório superior, tosse, dispneia, dor de cabeça, tontura, mialgia e hipercolesterolemia e eventos em saúde descritos com o uso de imunossupressores.  
O seu uso tem sido relacionado também com a formação de cisto ovariano, dismenorreia, proteinúria, testes de função hepática elevados, pneumonite induzida por drogas.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
_______________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) sobre os benefícios, efeitos adversos e contraindicações do medicamento que passo a receber.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.     (   ) Sim     (   ) Não  
|Local:|Data:|
|---|---|
|Nome do paciente:||
|Cartão Nacional do SUS:||
|Nome do responsável legal:||
|Documento de identificação d|o responsável legal:|
|Assinatura do paciente ou do r|esponsável legal|
|Médico:|CRM:                                 RS:|
||______________________________<br>Assinatura e carimbo do médico|
||Data:|  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Linfangioleiomiomatose | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
A proposta inicial do documento era elaborar um protocolo de uso do sirolimo em LAM e foi apresentada aos membros do Plenário da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) à sua 93ª Reunião Ordinária, em 9 de dezembro de 2020, os quais recomendaram favoravelmente ao texto. Durante essa Reunião, verificou-se a necessidade de alteração do formato do documento, tendo em vista, exigências do Departamento de Assistência Farmacêutica do Ministério da Saúde, passando a denominar-se Protocolo Clínico e Diretrizes Terapêuticas de Linfangioleiomiomatose. Portanto, este PCDT visa a estabelecer os critérios para diagnóstico de LAM e o uso do sirolimo no tratamento de pacientes com esta doença. Ressalta-se que, por ter sido inicialmente elaborado como um protocolo de uso, as recomendações baseiam-se nos resultados advindos da busca da literatura feita na plataforma PubMed, incluídos guias de prática clínica sobre o diagnóstico e tratamento da LAM, informações da própria empresa fabricante do sirolimo e das referências identificadas no Relatório de Recomendação nº 539 – Julho de 2020 - Ampliação de uso do sirolimo para tratamento de indivíduos adultos com linfangioleiomiomatose, da Conitec.  
A versão final deste Protocolo foi revisada e aprovada por um médico especialista.

---

