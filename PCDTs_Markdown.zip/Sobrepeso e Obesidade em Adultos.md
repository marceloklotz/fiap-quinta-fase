<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
###### **MINISTÉRIO DA SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS**  
###### **PORTARIA SCTIE/MS Nº 53, DE 11 DE NOVEMBRO DE 2020**  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Sobrepeso e Obesidade em Adultos.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições legais, resolve:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas de Sobrepeso e Obesidade em Adultos.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec) sobre essa tecnologia estará disponível no endereço eletrônico: <u>http://conitec.gov.br/.</u>  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.  
HÉLIO ANGOTTI NETO  
1

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
De acordo com a Organização Mundial da Saúde (OMS), a extensão e a gravidade da crise da obesidade são comparadas apenas à negligência e ao estigma enfrentados pelas pessoas com obesidade. No mundo, sobrepeso e obesidade afetam mais de 2 bilhões de adultos, e a prevalência quase triplicou em 40 anos<sup>1</sup> . Em 2016, mais de 1,9 bilhão de adultos, com 18 anos ou mais, estavam acima do peso. Desses, mais de 650 milhões tinham obesidade. A preocupação com os riscos à saúde associados ao aumento da obesidade tornaram-se quase universais; os estados membros da OMS introduziram uma meta voluntária para interromper o aumento da obesidade até 2025<sup>2–4</sup> .  
De acordo com dados da Vigilância de Fatores de Risco e Proteção para Doenças Crônicas por Inquérito Telefônico de 2019 (VIGITEL), a prevalência da obesidade em adultos no Brasil aumentou 72% nos últimos treze anos, saindo de 11,8% em 2006 para 20,3% em 2018. Mais da metade da população brasileira, 55,4%, tem excesso de peso. Observou-se aumento de 30% quando comparado com percentual de 42,6% no ano de 2006. A prevalência de excesso de peso tende a aumentar com a idade e diminuir com a escolaridade<sup>15,16</sup> . Na população negra, a prevalência de excesso de peso em 2018 era de 56,5% e de obesidade, de 20%<sup>17</sup> .  
A obesidade é uma condição crônica multifatorial que engloba diferentes dimensões: biológica, social, cultural, comportamental, de saúde pública e política<sup>18</sup> . O desenvolvimento da obesidade decorre de interações entre o perfil genético de maior risco, fatores sociais e ambientais, por exemplo, inatividade física, ingesta calórica excessiva<sup>19,20</sup> , ambiente intrauterino, uso de medicamentos obesogênicos e status socioeconômico<sup>20</sup> . Sono insuficiente, disruptores endócrinos e microbiota intestinal também podem estar associados à gênese da obesidade<sup>20</sup> .  
Mudanças ambientais e sociais resultaram na alteração dos padrões alimentares e de atividade física. Apesar da existência de políticas públicas para esses dois fatores de proteção, a constante promoção/incentivo ao consumo de alimentos e bebidas ultraprocessados (calorias líquidas – refrigerantes e sucos de frutas adoçados –, _fast foods_ etc.) prejudicam a prevenção e o controle da obesidade<sup>21,22</sup> . O acesso restrito da população a programas públicos de promoção de atividade física é também outro fator que dificulta o controle da obesidade<sup>23</sup> .  
2  
O Brasil está entre os países com maior prevalência de inatividade física do mundo<sup>24</sup> . Os dados do VIGITEL de 2019 apontaram que 44,8% da população com 18 anos residentes nas capitais brasileiras não atendem ao mínimo de atividade física recomendado pela OMS, sendo que as mulheres (52,2%) e os idosos (69,1%) apresentam as maiores prevalências de inatividade física<sup>16</sup> . No último século, diferentes estudos avaliaram a influência da genética no desenvolvimento da obesidade. Estes estudos incluíram populações em situação de encarceramento, gêmeos, indivíduos adotivos, entre outros. Embora diversos aspectos ainda careçam de elucidação, existem evidências de que a genética influencia no desenvolvimento da obesidade<sup>19</sup> . Apesar de haver um constante apelo às características genéticas como fatores preditores de sobrepeso e obesidade, ainda existem controvérsias quanto ao real impacto da carga genética. Um estudo avaliou a relação entre ter obesidade e ter pais com a condição. Esse estudo mostrou que crianças com obesidade com menos de três anos de idade, sem pais com obesidade, têm baixo risco de terem a condição na idade adulta, mas que, entre as crianças mais velhas, ter obesidade é um preditor cada vez mais importante da obesidade na idade adulta, independentemente de os pais terem a condição. A obesidade dos pais mais do que duplica o risco de obesidade adulta entre crianças com e sem obesidade com menos de 10 anos de idade<sup>25</sup> .  
Diferentes estudos sugerem que indivíduos que têm predisposição genética para obesidade são mais suscetíveis quando expostos a ambientes desfavoráveis, indicando que a adoção de determinado estilo de vida afeta a população geral de modo variado. Fatores como estados crônicos de estresse psicossocial, redução de horas de sono, consumo de bebidas com adição de açúcar, frituras e alimentos utraprocessados e inatividade física podem interagir com genes relacionados à obesidade, afetando os fenótipos de adiposidade e aumentando a associação entre os genes e medidas antropométricas, como o Índice de Massa Corpórea (IMC)<sup>20</sup> . A título de exemplo, um estudo demonstrou que é maior a chance de ganhar de peso comendo frituras, quando variantes genéticas relacionadas à obesidade estão presentes no indivíduo<sup>26</sup> .  
Embora centenas de loci cromossômicos associados à obesidade expliquem somente 5% das variações do IMC, estudos de associação genômica ampla demonstraram que loci associados à obesidade possuem genes expressos no sistema nervoso central envolvidos na regulação do apetite e da saciedade, na secreção e ação da insulina, na adipogênese e no metabolismo energético e de lipídios<sup>27</sup> .  
3  
Independentemente da presença de genótipos que predispõem à obesidade, as intervenções a nível individual para seu controle (alimentação adequada e saudável, atividade física, medicamentos e intervenções cirúrgicas) parecem funcionar de forma semelhante entre os indivíduos. Dessa forma, a triagem para variantes genéticas no cotidiano da prática clínica não é recomendada<sup>28</sup> . Sobrepeso e obesidade têm implicações relevantes à saúde do indivíduo e à sociedade. Valores de IMC acima dos indicativos de eutrofia e aumento de adiposidade estão relacionados a um maior risco para o desenvolvimento de doenças crônicas não transmissíveis (DCNT), como doenças cardiovasculares, diabetes, doenças musculoesqueléticas e alguns tipos de câncer, além de estar associado a maiores índices de mortalidade<sup>21</sup> .  
O tecido adiposo armazena energia e secreta hormônios e citocinas inflamatórias que influenciam na homeostase. Esses produtos participam da regulação do apetite e do gasto energético, interferem na sensibilidade à insulina, na capacidade oxidativa e na absorção de lipídios em outros tecidos e órgãos. Quando há balanço energético positivo, como na obesidade, ocorre hipertrofia e hiperplasia de adipócitos para que o excesso de energia seja armazenado no tecido adiposo sob a forma de triglicerídeo. Isso resulta em alterações da composição celular do tecido, com maior secreção de hormônios e citocinas, além do recrutamento de células inflamatórias, resultando em inflamação e alterações metabólicas. Esses processos precipitam o surgimento de diversas comorbidades e complicações associadas à obesidade<sup>29,30</sup> .  
A manutenção do estoque de gordura corporal é regulada no sistema nervoso central, onde se originam as sensações de fome e saciedade, e onde o tônus do sistema nervoso simpático é modulado, permitindo maior ou menor gasto de energia. Embora essa regulação seja complexa e ainda não totalmente esclarecida, o entendimento dos conhecimentos disponíveis é essencial para se compreender por que, para os pacientes com obesidade, é difícil perder peso e mais difícil ainda manter o peso perdido. Essa compreensão reduz o preconceito, não apenas com o tratamento, mas em todas as esferas da sociedade, onde lamentavelmente estão incluídos os profissionais ligados aos serviços de saúde<sup>31,32</sup> .  
Apesar da riqueza de evidências científicas para demonstrar a complexidade atrelada à prevenção e ao controle da obesidade, o tema é constantemente tratado como trivial. A sociedade é continuamente informada de que ganho e perda de peso são simples. Isso é muitas vezes associado a propagandas sensacionalistas de módulos de atividade física e a dietas e medicamentos milagrosos. Esse discurso propagado para a sociedade gira em torno da mensagem de que as pessoas ganham peso em decorrência de falha moral – por exemplo,  
4  
preguiça e gula – e que a perda de peso pode ser alcançada, rapidamente, ao se comer menos e se mover mais<sup>14,33</sup> . Esse discurso não otimiza o processo de prevenção e auxílio a perda de peso, mas acaba gerando estigmas, rótulos e estimulando a gordofobia<sup>34–36</sup> . Esta se trata de uma aversão à gordura, caracterizada pela repulsa ou desconforto em relação às pessoas com excesso de peso, podendo se manifestar em atitudes que configuram violência física, emocional e assédio moral<sup>37</sup> , além de poder contribuir para a baixa autoestima e valores negativos para a aquisição de hábitos saudáveis<sup>38,39</sup> .  
Esse estigma social se correlaciona negativamente a outras dimensões da vida da pessoa com sobrepeso ou obesidade, incluindo escolaridade, status socioeconômico e estado civil, contribuindo significativamente para piora da qualidade de vida<sup>40,41</sup> . Alguns estudos revelaram que pessoas com sobrepeso e obesidade têm piores condições de trabalho, menores salários e menores chances de serem contratadas, se comparadas com indivíduos com peso considerado normal<sup>42</sup> .  
Profissionais de saúde podem apresentar comportamentos preconceituosos e estigmatizantes, afetando a qualidade do cuidado da pessoa com sobrepeso ou obesidade<sup>43–45</sup> . Muitas vezes, esse comportamento pode ocorrer explícito ou implícito, por meio de falas que culpabilizam apenas o indivíduo pela situação, por atitudes que demonstrem que o profissional não acredita que o tratamento terá resultados, entre outros, resultando em discriminação, injustiças e iatrogenias relacionadas ao tratamento<sup>44–46</sup> .  
O preconceito, o estigma e a discriminação resultam em maior morbimortalidade, com efeitos físicos e psicológicos ao indivíduo alvo desses fatores<sup>44–47</sup> . Ademais, essas crenças e atitudes preconceituosas podem desencorajar a pessoa com sobrepeso ou obesidade a procurar os serviços de saúde, tanto para estas como para outras condições, comprometendo o acesso à saúde como um todo<sup>44,46,48</sup> . Em função disso, é necessário que o profissional de saúde amplie seus conhecimentos a respeito do sobrepeso e da obesidade, avalie suas atitudes quando estão cuidando de pessoas com estas condições e reflitam de que modo elas podem estar influenciando na qualidade do cuidado<sup>44,45,49</sup> .  
A obesidade compromete a qualidade e reduz a expectativa de vida do indivíduo. Além disso, ela impacta a sociedade com aumento dos gastos diretos em saúde, bem como dos custos indiretos, associados à perda de produtividade<sup>50,51</sup> .  
5  
Desta forma, o presente PCDT visa a apresentar diretrizes gerais para a prevenção e promoção à saúde ao discorrer sobre o diagnóstico, a terapêutica e o monitoramento de pessoas adultas com sobrepeso ou obesidade no SUS.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O processo de desenvolvimento deste PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> , que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>52</sup> .  
Foi identificada a evidência disponível na literatura sobre as 12 perguntas de pesquisa definidas no escopo do PCDT. Os estudos selecionados foram sumarizados em tabelas de evidências na plataforma GRADEpro. A partir disso, o grupo desenvolvedor do PCDT, composto por metodologistas e especialistas no tema, elaborou recomendações a favor ou contra cada intervenção. Uma descrição detalhada do método de seleção de evidências e dos resultados obtidos encontra-se no APÊNDICE 1 deste documento (seção “Metodologia de busca e avaliação da literatura”).

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Serão contemplados neste Protocolo de pessoas com sobrepeso e obesidade classificados de acordo com os CID abaixo:  
- E66 Obesidade  
- E66.0 Obesidade devida a excesso de calorias  
- E66.1 Obesidade induzida por drogas  
- E66.2 Obesidade extrema com hipoventilação alveolar  
- E66.8 Outra obesidade  
- E66.9 Obesidade não especificada  
6

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O diagnóstico precoce do sobrepeso e da obesidade tem grande importância no contexto do controle e prevenção das Doenças Crônicas Não Transmissíveis (DCNT), uma vez que essas condições consistem em fatores de risco para outras DCNT e acarretam prejuízos para a saúde dos indivíduos, impactando no aumento da morbimortalidade<sup>22,53,54</sup> .  
O diagnóstico de sobrepeso ou obesidade é clínico, com base na estimativa do IMC, que é dado pela relação entre o peso e a altura do indivíduo, segundo a fórmula<sup>22,55</sup> :  
|IMC =|peso<br>altura²|(kg/ m²)|
|---|---|---|  
Trata-se de um método de fácil aplicação e baixo custo, o qual possibilita tanto a classificação do estado nutricional e definição das medidas terapêuticas indicadas, como a estratificação de risco para desenvolvimento e/ou presença de comorbidades ( **Quadro 1** )<sup>22</sup> .  
**<u>Quadro 1.</u>** Classificação do estado nutricional de adultos e risco de comorbidades, segundo IMC.  
|**Classificação**|**IMC**|**Risco de comorbidades**|
|---|---|---|
|Abaixo do peso|<18,50|Baixo|
|Eutrófico|18,50 – 24,99|Médio|
|Sobrepeso|25,00 – 29,99|Pouco Elevado|
|Obesidade grau I|30,00 – 34,99|Elevado|
|Obesidade grau II|35,00 – 39,99|Muito elevado|
|Obesidade grau III|≥40,00|Muitíssimo elevado|  
Fonte: Adaptado de OMS, 2000<sup>55</sup> , Abeso, 2016<sup>56</sup> ; Legenda: IMC: Índice de Massa Corporal.  
O IMC tem sido utilizado como uma medida substituta de gordura corporal, tanto na prática clínica, quanto nos estudos epidemiológicos e clínicos. O uso do IMC, entretanto, apresenta limitações, visto que ele não é uma medida direta de gordura corporal e nem indica sua distribuição; não leva em consideração a massa muscular; não distingue quanto a sexo e etnia; e é menos acurado em alguns grupos específicos (idosos, etnia asiática, indígena, entre outros). Assim, deve ser feita avaliação criteriosa do significado dessa medida<sup>49</sup> .  
7  
Em adultos jovens, com idade entre 18 e 20 anos incompletos, a classificação do estado nutricional deve seguir o indicador IMC-para-Idade, em escore Z. As curvas para parametrização do estado nutricional para ambos os sexos podem ser acessadas no site da OMS (https://www.who.int/growthref/who2007_bmi_for_age/en/) ou no ANEXO 1 deste Protocolo. Para idosos também existe uma classificação específica, conforme Lipschitz (1994) ( **Quadro 2** ).  
**Quadro 2.** Classificação de estado nutricional de acordo com IMC para idosos e conforme escore Z para adultos jovens (18 anos a 20 anos incompletos).  
|**Classificação**|**IMC**|
|---|---|
|**Jovens com idade entre 1**|**8 e 20 anos incompletos**|
|Magreza Acentuada|< Escore-z -3|
|Magreza|≥ Escore-z -3 e < Escore-z -2|
|Eutrófico|≥ Escore-z -2 e ≤ Escore-z +1|
|Sobrepeso|> Escore-z +1 e ≤ Escore-z +2|
|Obesidade|> Escore-z +2 e ≤ Escore-z +3|
|Obesidade Grave|> Escore-z +3|
|**Populaç  **|**ão Idosa**|
|Abaixo dopeso|≤ 22,00|
|Eutrófico|>22,00 e < 27,00|
|Sobrepeso|≥27,00|  
Fonte: Obesity Canada & Canadian Association of Bariatric Physicians and Surgeons<sup>49</sup> ; Brasil, 2014<sup>22</sup> , Lipschitz D, 1994- Screening for nutritional status in the elderly. Prim Care. 1994;21(1):55–67).  
A medida do perímetro da cintura é um método utilizado para avaliar a distribuição da gordura intra-abdominal, sendo um marcador de maior risco cardiometabólico<sup>55</sup> . A medida é obtida com uso de fita métrica, mensurando-se a região localizada no ponto médio entre a última costela e a crista ilíaca com o indivíduo em expiração. Na impossibilidade de se identificar essa região, a medida é feita a 2 cm acima da cicatriz umbilical. No **Quadro 3** , constam os parâmetros de circunferência que estão relacionados com o risco elevado de morbimortalidade, de acordo com o sexo e etnia<sup>57,58</sup> .  
**Quadro 3.** Parâmetros para risco cardiovascular, segundo perímetro da cintura.  
|**Etnia**|**Risco cardiova**|**scular elevado**|**Risco card**<br>**significativam**|**iovascular**<br>**ente elevado**|
|---|---|---|---|---|
||Mulher|Homem|Mulher|Homem|
|Caucasiana|≥ 80,0 cm|≥94,0 cm|≥ 88,0 cm|≥102,0 cm|
|Latina|≥83,0 cm|≥88,0 cm|≥90,0 cm|≥94,0 cm|  
8  
|Africana|≥71,5 cm|≥76,5 cm|≥81,5 cm|≥80,5 cm|
|---|---|---|---|---|
|Asiática|≥ 80,0 cm|≥85,0 cm|ND|ND|  
Fonte: Obesity Canada & Canadian Association of Bariatric Physicians and Surgeons<sup>49</sup> .  
Assim como o IMC, a aplicabilidade do perímetro da cintura apresenta algumas limitações. É uma medida indireta de gordura visceral, sensível a alterações temporárias como gestação, presença de ascite ou distensão abdominal, entre outros. Essa medida se torna menos sensível com o aumento do IMC e o ponto de corte também varia de acordo com a etnia<sup>49</sup> .  
Independentemente do parâmetro avaliado e da consulta (inicial ou de seguimento), recomenda-se solicitar ao indivíduo permissão para que suas medidas possam ser aferidas e que elas sejam feitas em locais que resguardem sua privacidade para evitar constrangimentos<sup>49</sup> .  
Além de medidas antropométricas, a avaliação do sobrepeso e da obesidade deve buscar identificar suas causas e complicações, bem como potenciais barreiras ao tratamento. Esta avaliação leva em consideração anamnese, com coleta do histórico de saúde completo e de aspectos comportamentais e sociais; exame físico e exames laboratoriais e de imagem, conforme julgamento clínico<sup>22,49</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
- Adultos (idade igual ou superior a 18 anos) com diagnóstico de sobrepeso ou obesidade (IMC igual ou superior a 25 kg/m<sup>2</sup> ) com ou sem comorbidades que buscam atendimento no SUS.  
- Indivíduos adultos submetidos à cirurgia bariátrica, com no mínimo 18 meses após a realização da intervenção e com IMC igual ou superior a 25 kg/m<sup>2</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
- Indivíduos submetidos à cirurgia bariátrica, com período de realização da cirurgia inferior a 18 meses.  
- Indivíduos com idade inferior a 18 anos.  
9

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Na atenção ao indivíduo com sobrepeso ou obesidade é necessária uma contínua ação de Vigilância Alimentar e Nutricional (VAN) para identificação dos casos, estratificação de risco e organização da oferta de cuidado. A VAN pode ser realizada em todos os pontos de atenção da rede, desde a Atenção Primária em Saúde (APS) até a Atenção Hospitalar. Por meio dessa vigilância, são obtidas informações que podem subsidiar a qualificação da atenção integral ao indivíduo, com ações de promoção, proteção e recuperação da saúde, além de permitir atuação precoce no ganho excessivo de peso. Na APS, além das Unidades Básicas de Saúde (UBS), destacam-se outros locais privilegiados para as ações intersetoriais: a escola, por meio do Programa Saúde na Escola, que abrange ações para crianças e adolescentes até dezoito anos e estudantes da Rede Federal de Educação Profissional e Tecnológica e da Educação de Jovens e Adultos (EJA); e as Academias da Saúde<sup>22,59</sup> .  
Visando a uma eficiente captação e acolhimento dessa demanda, os profissionais de saúde devem estar capacitados e sensibilizados para essa temática, podendo identificar e intervir precoce e agilmente, entendendo que o excesso de peso é um agravo à saúde, com grande influência no desenvolvimento de outras doenças crônicas e que a reversão desse quadro pode e deve ser, na maioria das situações, realizada na APS<sup>22</sup> . Contudo, existem evidências limitadas para orientar os profissionais sobre quais programas ou políticas de prevenção da obesidade podem ser mais eficazes<sup>60</sup> . Os agentes comunitários são profissionais-chave para acolhimento da pessoa com sobrepeso e obesidade no âmbito da atenção primária, além de propiciar a formação do vínculo com a Equipe Saúde da Famíia (ESF) e a unidade de saúde. Estes profissionais também podem desenvolver ações de promoção à saúde e prevenção de doenças e agravos em contextos individuais e coletivos, fortalecendo ainda mais as estratégias propostas à comunidade e ao usuário na prevenção e tratamento do sobrepeso e da obesidade<sup>61</sup> .  
As estratégias de prevenção da obesidade que apresentam resultados mais promissores são aquelas projetadas para impactar não apenas o conhecimento, mas também as habilidades e competências (sugerindo uma teoria do comportamento social subjacente). Intervenções multifatoriais que combinam componentes de alimentação, atividade física e mudança de comportamento, incluindo automonitoramento do peso, mensagens gerais ou aconselhamentos personalizados<sup>62</sup> ; e implementação intensiva e de longo prazo, incluindo sessões em grupo e monitoramento da alimentação e/ou atividade física, são recomendadas para prevenção e controle da obesidade<sup>63</sup> .  
10  
Para além do conceito de alimentação saudável, algumas publicações passaram a adotar o conceito de _alimentação adequada e saudável_ , dialogando com a Política Nacional de Segurança Alimentar e Nutricional (PNSAN), que se refere à adequação cultural, social e econômica da alimentação, e não apenas nutricional<sup>60</sup> , e que está em consonância com a Política Nacional de Alimentação e Nutrição (PNAN), instituída em 1999 e atualizada em 2011, que compõe um conjunto de políticas públicas criadas com o intuito de respeitar, proteger, promover e prover os direitos humanos à saúde e à alimentação. Integram essa Política a VAN, as ações de promoção de práticas alimentares e saudáveis, a prevenção e o cuidado integral dos agravos relacionados à alimentação e nutrição<sup>64</sup> . A promoção da alimentação adequada abarca medidas de incentivo, apoio e proteção, que visam a difundir informações, facilitar e proteger a adesão a práticas alimentares saudáveis, como a rotulagem nutricional obrigatória, os guias alimentares e a regulamentação da publicidade de alimentos<sup>60,65</sup> .  
Com relação à importância da atividade física, estudos demonstraram que, além de associação com redução de peso, atividades físicas ainda reduzem risco para diferentes DCNT e de mortalidade por todas as causas e promovem melhorias na qualidade de vida<sup>22,66</sup> . Nesse sentido, o incremento da prática de atividade física regular, associada a hábitos alimentares saudáveis, contribui para controle de peso, visto que promove gasto de energia e equilíbrio energético negativo<sup>22</sup> .  
Por fim, cumpre destacar que as pessoas estão inseridas em ambientes que promovem cada vez mais uma alta ingestão de energia e comportamentos sedentários<sup>67</sup> . Esse tipo de ambiente, que dificulta as escolhas saudáveis e favorecem o comportamento sedentário e hábitos alimentares inadequados, foram conceituados por Egger & Swinburn (1997) como “ambientes obesogênicos”. Esses autores sugerem que a força motriz para o aumento da prevalência desta condição nas populações é o ambiente cada vez mais obesogênico, e não as alterações e mutações genéticas<sup>68</sup> .  
Desse modo, para a prevenção/controle da obesidade, além do apoio aos indivíduos por meio de abordagens educativas/comportamentais, é fundamental a adoção de políticas intersetoriais para reverter a natureza obesogênica dos locais onde eles vivem. Nesse sentido, medidas como a regulação do _marketing_ de alimentos ultraprocessados, melhora da rotulagem dos produtos alimentícios, medidas fiscais para alimentos não saudáveis, além de mudanças na infraestrutura  
11  
urbana para promover transporte ativo e aumentar espaços para recreação têm sido recomendadas<sup>67</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O tratamento da obesidade deve ter por finalidade alcançar uma série de objetivos globais em curto e longo prazo. Em conformidade com esta abordagem, o tratamento do sobrepeso e da obesidade deve buscar os seguintes resultados: diminuição da gordura corporal, preservando ao máximo a massa magra; promoção da manutenção de perda de peso; impedimento de ganho de peso futuro; educação alimentar e nutricional que vise à perda de peso, por meio de escolhas alimentares adequadas e saudáveis; redução de fatores de risco cardiovasculares associados à obesidade (hipertensão arterial, dislipidemia, pré-diabete ou diabete melito); resultar em melhorias de outras comorbidades (apneia do sono, osteoartrite, risco neoplásico, etc.); recuperação da autoestima; aumento da capacidade funcional e da qualidade de vida<sup>69,70</sup> .  
É preciso atentar que o tratamento da obesidade não tem como objetivo atingir um IMC correspondente à eutrofia. O critério para perda de peso bem-sucedida é a manutenção de uma perda ponderal igual ou superior a 10% do peso inicial após 1 ano. Este percentual já é suficiente para melhorias significativas nos parâmetros cardiovasculares e metabólicos<sup>22,71</sup> . No entanto, é extremamente difícil manter essa perda de peso a longo prazo<sup>72</sup> . Reduções de peso entre 5% a 10% do peso habitual podem não resultar em mudanças de classificação quanto ao estado nutricional do indivíduo, ou seja, ele continuará com sobrepeso ou obesidade. Embora modestos, esses limiares de redução de peso podem resultar em melhorias significativas na redução de fatores de risco para doenças crônicas, como diminuição dos níveis pressóricos, glicêmicos e de triglicérides<sup>22,71,73,74</sup> .  
12

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O uso dos medicamentos orlistate e da sibutramina no tratamento de sobrepeso e obesidade foi avaliado de acordo com a metodologia de avaliação de tecnologias em saúde, adotada pela Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), para definição da incorporação de medicamentos e respectivas políticas públicas de acesso a tecnologias no âmbito do SUS. A avaliação desses medicamentos para o tratamento da obesidade recebeu recomendação contrária à incorporação pela Conitec. Dentre os resultados dessa análise, na meta-análise que comparou o medicamento a sibutramina ao placebo em pacientes obesos, observou-se que o tratamento ativo em doses variadas (10, 15 ou 20 mg) resultou em perdas de peso clinicamente não significantes (diferença média = -3,32kg; IC 95%: -5,03; -1,61)<sup>7</sup> . A mesma tendência foi observada em meta-análise que comparou o medicamento orlistate a placebo em pacientes com sobrepeso ou obesidade, em que a diferença média de peso foi ainda inferior, de -2,68 kg (IC 95%: 3,01-2,35)<sup>8</sup> . Ambos os medicamentos, orlistate e sibutramina, apresentaram perfil de eventos adversos com risco considerado moderado a grave<sup>7,8</sup> . O uso de sibutramina pode resultar em elevações de pressão arterial e eventos cardíacos como fibrilação atrial e taquicardia, ansiedade, náusea, boa seca, insônia, entre outros<sup>7</sup> . Já o orlistate pode causar incontinência fecal, flatulência com perdas oleosas, dor e desconforto abdominal, ansiedade, fadiga, entre outros<sup>8</sup> . Ademais, embora não tenham custo unitário elevado, quando se considera a prevalência das condições, seu uso resultaria em impacto orçamentário elevado ao SUS para obtenção de benefícios modestos<sup>7,8</sup> . Assim, por meio das Portarias SCTIE nº 14 e 15, publicadas em 24 de abril de 2020, foi publicada a decisão de não incorporar os medicamentos no SUS.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Reduções de peso corporal após dieta ou prática de exercício físico resultaram em melhorias em diferentes domínios de qualidade de vida em indivíduos com sobrepeso ou obesidade<sup>75,76</sup> .  
A atividade física regular, iniciada durante a fase de perda de peso e mantida durante a fase de estabilização de peso, a manutenção da alimentação adequada e saudável e suporte psicológico são as principais ferramentas para perda e manutenção de peso a longo prazo<sup>77</sup> . Intervenções para mudanças no estilo de vida, com intervalos semanais nos primeiros seis meses, mostramse altamente eficazes na redução do peso<sup>78,79</sup> . É importante destacar que a definição do plano terapêutico deve ser individualizada, considerando as necessidades e preferências da pessoa com sobrepeso ou obesidade, incluindo-a em todas as fases do processo e decisões<sup>49</sup> .  
13

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Indivíduos com sobrepeso ou obesidade devem ser avaliados quanto ao estado nutricional e aos fatores que podem interferir no sucesso e na adesão do usuário ao tratamento. Um dos alicerces para o controle e prevenção do excesso de peso e da obesidade reside na promoção da alimentação adequada e saudável<sup>22,59</sup> .  
O sucesso do tratamento dietético depende da manutenção de mudanças na alimentação por toda a vida. Dietas muito restritivas, artificiais e rígidas não são sustentáveis, e podem representar riscos a populações vulneráveis, na medida em que não consideram as necessidades nutricionais, os hábitos de vida e as características culturais do indivíduo<sup>22,80</sup> . Um planejamento alimentar mais flexível, que objetive mudanças gradativas, geralmente obtém mais sucesso. De maneira geral, os usuários devem ser aconselhados sobre como diminuir estrategicamente a ingestão de determinados alimentos dentro de um padrão alimentar saudável, atrativo e conveniente, de acordo com sua realidade e cultura<sup>22</sup> .  
Quatro grupos de alimentos estão disponíveis para consumo, que se diferenciam com base no seu grau de processamento: **Alimentos** **_in natura_ ou minimamente processados** são obtidos diretamente de vegetais ou animais, sem sofrer qualquer tipo de alteração ou que passaram por processos como limpeza, secagem, congelamento, pasteurização, moagem e não contêm adição de açúcar, sal, óleos, gorduras ou substancias industriais; **ingredientes culinários processados** são produtos utilizados para temperar, misturar e cozinhar alimentos _in natura_ ou minimamente processados e, assim, criar preparações culinárias agradáveis ao paladar; **alimentos processados** são produtos fabricados com a adição de sal, óleo, açúcar ou outros ingredientes culinários a alimentos in natura ou minimamente processados, utilizando métodos de conservação como enlatamento e engarrafamento e, no caso de pães e queijos, fermentação não alcoólicas; **alimentos ultraprocessados** são aqueles que possuem muitos ingredientes, incluindo sal, açúcar, óleos e gorduras e substâncias de uso exclusivamente industrial, como substâncias não usadas em cozinhas domésticas (açúcar invertido, frutose, xarope de milho, glúten, fibra solúvel ou insolúvel, maltodextrina, proteína isolada de soja, óleo interesterificado) e aditivos cosméticos alimentares (corantes, aromatizantes, realçadores de sabor, emulsificantes, espessantes, adoçantes) ( **Figura 1** )<sup>80</sup> .  
14  
###### **Figura 1.** Grupos de alimentos.  
<!-- Start of picture text -->
Alimentos in natura<br>‘ou minimamente<br>processados<br>Alimentos<br>processados<br>Ingredientes<br>culindrios<br>Uso em pequenas<br>Consumo recomendado quantidades para criar Limitar consumo, Evitar consumo<br>preparacées culinarias<br><!-- End of picture text -->  
Fonte: Guia Alimentar para a População Brasileira<sup>80</sup> .  
###### Legenda:  
Alimentos _in natura_ ou minimamente processados são obtidos diretamente de vegetais ou animais, sem sofrer qualquer tipo de alteração ou que passaram por processos como limpeza, secagem, congelamento, pasteurização, moagem e não contêm adição de açúcar, sal óleos, gorduras ou substâncias industriais. Ingredientes culinários: produtos utilizados para temperar, misturar e cozinhar alimentos in natura ou minimamente processados. Alimentos processados: adição de sal ou açúcar (ou outra substância de uso culinário como óleo ou vinagre), ao alimento in natura ou minimamente processado para torná-lo mais durável e saboroso. Alimentos ultraprocessados: são alimentos com muitos ingredientes, incluindo sal, açúcar, óleos e gorduras e substâncias de uso exclusivamente industrial, como substâncias de uso exclusivamente industrial como substâncias não usadas em cozinhas domésticas (açúcar invertido, frutose, xarope de milho, glúten, fibra solúvel ou insolúvel, maltodextrina, proteína isolada de soja, óleo interesterificado) e aditivos cosméticos alimentares (corantes, aromatizantes, realçadores de sabor, emulsificantes, espessantes, adoçantes).  
Segundo o Guia Alimentar da População Brasileira e outras publicações, deve-se incentivar a ingestão de alimentos _in natura_ ou minimamente processados<sup>80,81</sup> . O consumo de alimentos ultraprocessados está associado ao desenvolvimento de DCNT, incluindo obesidade<sup>65</sup> .  
15  
O conceito de alimentação saudável não deve ser baseado somente em nutrientes. Os alimentos que contêm e fornecem os nutrientes, como os alimentos são combinados entre si e preparados, as características do modo de comer e as dimensões culturais e sociais das práticas alimentares influenciam a saúde e o bem-estar. Alimentos ultraprocessados são ricos em gorduras, açúcares, sódio e calorias e pobre em vitaminas, fibras e minerais. Essa composição nutricional desbalanceada favorece a ocorrência de DCNT e obesidade. Outros mecanismos que relacionam o consumo de ultraprocessados com a obesidade vão além do perfil de nutrientes. Os estudos mais recentes mostram que os impactos negativos dos ultraprocessados nos desfechos em saúde são independentes do conteúdo energético e nutricional da dieta<sup>82,83</sup> . Uma maior desconstrução da matriz alimentar original, que ocorre durante o processamento destes produtos, tem sido associada com menor saciedade e maior resposta glicêmica. Outros mecanismos incluem alterações na  microbiota  intestinal,  respostas inflamatórias relacionadas a nutrientes acelulares e aditivos  alimentares  industriais, contaminantes provenientes das embalagens destes  produtos, dentre outros<sup>82–</sup> 84.  
Estudos recentes têm demonstrado que o maior consumo de ultraprocessados está associado com importantes impactos à saúde humana:  
● Em uma investigação que comparou pessoas que consumiram uma dieta composta por alimentos ultraprocessados com aqueles que consumiram uma dieta à base de alimentos não processados (que tinham perfil nutricional semelhantes em termos de calorias, densidade energética, macronutrientes, açúcar, sódio e fibra), os participantes do primeiro grupo comeram, em média, 500 calorias a mais por dia e ganharam, em média, mais de 900 gramas de peso corporal em duas semanas. Foram observadas também alterações significativas em relação aos hormônios envolvidos na regulação da ingestão de alimentos durante o período estudado<sup>85</sup> .  
● O maior consumo de ultraprocessados aumenta o risco de: sobrepeso/obesidade e circunferência da cintura elevada em 39%, níveis baixos de colesterol HDL em 102% e síndrome metabólica em 79%<sup>86</sup> .  
● Quando estudadas as associações entre os níveis de consumo de alimentos ultraprocessados e os resultados de saúde em indivíduos saudáveis,  foi  encontrada associação positiva entre o consumo desses alimentos e pelo menos um resultado adverso à saúde<sup>84</sup> .  
16  
● Dessa forma, observa-se que o alto consumo de alimentos ultraprocessados está associado a um risco aumentado de mortalidade por todas as causas, doenças cardiovasculares gerais, doenças cardíacas coronárias, doenças cerebrovasculares, hipertensão, dislipidemia, síndrome metabólica, sobrepeso e obesidade,  depressão,  síndrome do intestino irritável, câncer geral, câncer de mama pós-menopausa, obesidade gestacional, asma e sibilância na adolescência e fragilidade<sup>87–90</sup> . Nenhum estudo relatou uma associação entre o consumo de alimentos ultraprocessados e resultados benéficos para a saúde.  
Considerando o desequilíbrio nutricional de alimentos processados e a associação entre alimentos ultraprocessados e a ocorrência de desfechos negativos na saúde, os primeiros devem ser consumidos em pequenas quantidades<sup>80</sup> e alimentos ultraprocessados devem ser evitados<sup>80,81</sup> .  
O Guia Alimentar para a População Brasileira propõe dez passos para uma alimentação adequada e saudável, que consiste em ações que vão além da mudança no perfil de consumo de alimentos ( **Figura 2** )<sup>80</sup> . Esses passos contribuem para que o indivíduo tenha mais atenção na alimentação e nas diferentes etapas envolvidas no processo, desde o consumo de informações sobre os alimentos, até o momento da refeição. Ademais, também recomendam que o indivíduo aprecie e desfrute melhor de suas refeições.  
17  
**Figura 2.** Dez Passos Para Uma Alimentação Adequada e Saudável.  
<!-- Start of picture text -->
1. Fazer de alimentos  in natura  ou minimamente processados a base da alimentação.<br>2. Utilizar óleos, gorduras, sal e açúcar em pequenas quantidades ao temperar e cozinhar alimentos e<br>criar preparações culinárias.<br>3. Limitar o consumo de alimentos processados.<br>4. Evitar o consumo de alimentos ultraprocessados.<br>5. Comer com regularidade e atenção, em ambientes apropriados e, sempre que possível, em boa<br>companhia.<br>6. Fazer compras em locais que ofertem variedade de alimentos in natura ou minimamente<br>processados.<br>7. Desenvolver, exercitar e partilhar habilidades culinárias.<br>8. Planejar o uso do tempo para dar à alimentação o espaço que ela merece.<br>9. Dar preferência, quando fora de casa, a locais que sirvam refeições feitas na hora e a preço justo.<br>10. Ser crítico quanto a informações, orientações e mensagens sobre alimentação veiculadas em<br>propagandas comerciais.<br><!-- End of picture text -->  
Fonte: Guia Alimentar para a População Brasileira<sup>80</sup> .  
Não há controvérsias ao fato de que o balanço energético negativo, causado por redução na ingestão calórica, resulta em diminuição da massa corporal. A redução do consumo energético, no entanto, deve ser pautada principalmente por melhorias qualitativas na dieta, principalmente no que tange ao consumo de alimentos ultraprocessados. Quanto à frequência de refeições, estudos clínicos não evidenciaram benefício do fracionamento da dieta (quatro ou mais refeições por dia) comparado a fazer três refeições diárias. Desse modo, recomenda-se realizar pelo menos três refeições por dia ( **Apêndice 5** ), preferencialmente composta por preparações culinárias feitas a partir de alimentos _in natura_ ou minimamente processados, com pequenas quantidades de óleos, gorduras, açúcar e sal<sup>80</sup> .  
Algumas estratégias sugerem, ainda, o controle no consumo de calorias líquidas e a substituição de açúcar por adoçante. A caloria líquida se refere à energia obtida a partir de bebidas com alto teor energético e grandes quantidades de açúcar rapidamente absorvíveis, por exemplo, as bebidas açucaradas e adoçadas e refrigerantes ou sucos de frutas com alto teor calórico. O organismo tem maior dificuldade de reconhecer as calorias líquidas, principalmente quando a  
18  
bebida possui açúcar como seu nutriente único. Além de serem rápido e facilmente ingeridas, essas bebidas não contribuem para a saciedade fazendo com que ocorra maior consumo calórico<sup>91</sup> . Desse modo, recomenda-se substituição das bebidas açucaradas, como refrigerantes, sucos e energéticos, por água ( **Apêndice 3** ).  
Segundo a OMS, o consumo de açúcares livres deve estar limitado a 10% do consumo calórico total como parte de uma alimentação saudável. Para que maiores benefícios à saúde ocorram, recomenda-se que esta redução seja para menos de 5% dos valores energéticos totais<sup>92</sup> . Essa redução pode ser feita gradualmente para torná-la menos perceptível e permitir que o indivíduo se acostume pouco a pouco às quantidades reduzidas de açúcar<sup>93</sup> .  
Adoçantes artificiais são produtos ultraprocessados comercializados como uma alternativa ao açúcar e como uma ferramenta para perda de peso. Entretanto, não há evidências do benefício da substituição de açúcar por adoçante para a perda de peso, seja em forma líquida ou sólida. Alguns estudos sugerem efeitos adversos ao uso dos adoçantes artificiais, como a síndrome metabólica. Diante da incerteza da evidência, qualquer recomendação de substituição de açúcar por adoçante é prematura ( **Apêndice 4** ). Assim, preconiza-se a recomendação de alimentos em sua forma natural, sem a adição de adoçantes, sejam eles naturais ou artificiais<sup>94</sup> .  
Durante a elaboração do plano alimentar, o principal requisito é a restrição dos alimentos ultraprocessados. Em termos quantitativos, a prescrição de uma alimentação com a restrição de 500 a 1.000 kcal/dia do gasto energético estimado se mostrou eficaz na redução do peso corporal em indivíduos com sobrepeso ou obesidade e pode ser recomendada no plano alimentar ( **Apêndice 2** ). Deve-se ressaltar que a elaboração do plano deve ser feita por profissional capacitado, após avaliação nutricional que leve em conta não apenas hábitos alimentares, bem como prefências e valores individuais e potenciais barreiras que possam influenciar na mudança<sup>95</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
A atividade física compreende qualquer movimento corporal com gasto energético acima dos níveis de repouso”. Refere-se ao gasto de energia maior do que ocorre quando se está sentado, deitado descansando, por exemplo. Ou seja, a atividade física é entendida como todos os movimentos intencionais que realizamos no nosso dia-a-dia nos momentos de lazer, para deslocamento, nos afazeres domésticos e no ambiente de trabalho ou estudo<sup>96–98</sup> . São atividades físicas: esportes, brincadeiras, jogos, danças, caminhadas e práticas corporais, por  
19  
exemplo. É considerado exercício físico, a atividade física realizada de maneira planejada, estruturada e repetitiva, que tenha por objetivo a melhoria e a manutenção da aptidão física<sup>96</sup> . O comportamento sedentário pode ser entendido como a realização de atividades de baixo ou nenhum gasto energético<sup>99,100</sup> . Ou seja, atividades na posição sentada ou deitada que geralmente são realizadas em frente a telas de computador, televisão, celulares e tablets.  
A OMS recomenda que adultos e idosos façam 150 minutos semanais de atividade física de intensidade moderada ou 75 minutos de atividade vigorosa por semana<sup>97</sup> . Ainda são recomendadas atividades de fortalecimento muscular com intensidade moderada ou maior, que envolva todos os principais grupos musculares em dois ou mais dias da semana, para benefícios adicionais à saúde<sup>97</sup> . Pessoas que não conseguem acumular os minutos de atividade física recomendados pela OMS são consideradas inativas fisicamente. Benefícios adicionais como diminuição de risco de mortalidade por qualquer causa e diminuição de pressão arterial podem ser adquiridos para tempos semanais maiores quando associados a outras medidas de controle do sobrepeso e da obesidade<sup>66</sup> .  
A obesidade abdominal é altamente sensível aos efeitos da atividade física regular. O tecido adiposo visceral é reduzido significativamente quando cumpridas as recomendações de prática de exercício físico, mesmo que nenhum peso seja perdido ( **Apêndice 6** ).  
A prática de exercícios físicos é uma abordagem recomendada para o manejo da obesidade<sup>101–</sup> 103. De acordo com a OMS, a inatividade física é um dos fatores de risco associada à grande maioria das mortes por doenças crônicas<sup>21</sup> . A prática de exercícios físicos promove benefícios importantes na prevenção e tratamento da doença coronariana, da hipertensão arterial, da síndrome metabólica, das doenças musculoesqueléticas, das doenças respiratórias e da depressão<sup>66,97</sup> . Ademais, contribui significativamente para melhoria na capacidade funcional, bem-estar e qualidade de vida<sup>104</sup> .  
O exercício físico pode ser realizado por meio de exercícios aeróbicos (que são aqueles que envolvem movimentos contínuos de grande parte do corpo, como caminhada, corrida, ciclismo, dança e natação) e exercícios de resistência (que são aqueles que exigem força, como musculação, flexões e agachamentos).  
Na redução de peso corporal, a prática de exercícios aeróbicos mostrou-se melhor quando comparado com exercícios de resistência<sup>101,102</sup> . Porém, destaca-se a importância da prática de exercícios de resistência para ganhos ou manutenção de massa magra ( **Apêndice 7** ). O ganho de  
20  
massa magra é considerado um fator positivo que está associado ao melhor estado geral de saúde e qualidade de vida. Neste sentido, é adequado recomendar que os indivíduos pratiquem uma combinação de exercícios aeróbicos e de resistência. Esta combinação de modalidades ainda apresenta vantagem na diminuição da gordura e perfil lipídico<sup>104</sup> . Similarmente, a OMS também recomenda a realização de exercícios aeróbicos e resistidos tanto para adultos quanto para idosos, além da prática de exercícios para melhora do equilíbrio de idosos. As atividades devem ser compatíveis com o estado de saúde do indivíduo, permitindo que se mantenha tão ativo quanto possível<sup>97</sup> .  
É recomendado que a realização de exercícios físicos, tanto por meio de exercícios de resistência quanto aeróbicos, seja feita em grupos de pessoas. Porém, cabe atenção para que a intensidade e demais variáveis sejam controladas de forma individual. No entanto, deve-se evitar grupos muito grandes<sup>101</sup> .  
Alguns indivíduos podem não conseguir realizar os exercícios físicos de forma contínua por um tempo prolongado, assim, recomenda-se que o tempo diário de atividades seja fracionado em sessões de no mínimo dez minutos progredindo para um tempo maior. Esta estratégia é útil para que indivíduos fisicamente inativos ou que apresentam condições que impossibilitem sessões maiores apresentem uma redução de risco de mortalidade por qualquer causa<sup>97</sup> .  
Recomenda-se que indivíduos com obesidade iniciem a prática de exercícios físicos em intensidade moderada. O aumento da intensidade deve ser avaliado ao longo do programa de treinamento considerando a capacidade física do indivíduo, visto que o exercício físico mais vigoroso está associado a um potencial maior de lesões. Recomenda-se o controle da intensidade através da percepção subjetiva de esforço, considerando uma escala de zero a dez (0 a 10), no qual zero representa o esforço mínimo e dez o esforço máximo, sendo o nível de 5 ou 6 para exercícios moderados e 7 ou 8 para intensidades vigorosas. Deve-se adotar ainda o “teste de fala ou conversação” que consiste em controlar a intensidade através da capacidade do indivíduo sustentar uma fala sem parar para respirar devido ao esforço físico ( **Apêndice 8** ) 101.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Indivíduos com sobrepeso ou obesidade devem ser avaliados quanto a fatores psicológicos ou psiquiátricos que podem interferir no sucesso e na adesão ao tratamento<sup>105</sup> . Sabe-se que  
21  
sobrepeso ou obesidade estão associados a repercussões na saúde mental, embora a natureza desta associação ainda não tenha sido totalmente elucidada. Estudos mostram que o 'excesso de peso' está associado a chances significativamente mais altas de sintomas depressivos e suicídio<sup>106</sup> . Mudanças no peso, associadas à depressão, são um fenômeno complexo e podem ser influenciadas por fatores específicos da doença, como alterações no apetite, na atividade física ou uso de medicamentos antidepressivos<sup>107</sup> . Deste modo, medidas de apoio psicológico podem auxiliar no tratamento do sobrepeso e da obesidade<sup>55</sup> .  
O suporte psicológico, neste caso, tem por objetivo promover apoio e o empoderamento da pessoa ao autocuidado, visando à redução peso por meio da implementação de modificações de longo prazo no comportamento do indivíduo, que colaborem para a prevenção de reganho de peso<sup>55</sup> . As abordagens de suporte psicológico podem ser feitas de modo individual ou em grupo, conforme escolha do usuário, sempre respeitando sua individualidade, visto que as mesmas levam a redução de medidas antropométricas de forma semelhante ( **Apêndice 10** ). Na abordagem psicológica de pessoas com excesso de peso, duas técnicas se destacam: a Entrevista Motivacional (EM) e a Terapia Cognitivo-Comportamental (TCC).  
A EM é um estilo de aconselhamento diretivo e centrado no indivíduo. Através da exploração da ambivalência, busca-se provocar mudanças de comportamento, sendo o objetivo central o aumento da motivação para a mudança, por meio dos seguintes princípios básicos: expressar empatia, desenvolver discrepância, acompanhar a resistência e promover a auto eficácia<sup>108,109</sup> . A TCC parte do pressuposto de que mudanças cognitivas e comportamentais que facilitem o aumento da atividade física e a adesão a um padrão alimentar saudável podem ser úteis no tratamento da obesidade. A TCC é uma terapia breve, caracterizada por sessões semiestruturadas e orientada para metas. Ela envolve um trabalho colaborativo, com participação ativa do profissional da saúde e do usuário no tratamento, e possui um caráter educativo<sup>110–112</sup> .  
Estas abordagens têm se mostrado eficazes para redução de medidas antropométricas (perda de peso, IMC e perímetro da cintura), embora com baixo nível de evidência ( **Apêndice 10** ). Ainda assim, recomenda-se o suporte psicológico baseado na entrevista motivacional e na terapia cognitivo comportamental.  
A abordagem deve ser adequada às necessidades do indivíduo com sobrepeso ou obesidade e condicionada à capacitação das equipes em saúde para a realização adequada dessas  
22  
estratégias. Ademais, os indivíduos devem ser informados sobre a possibilidade de associação com outras modalidades de tratamento, como orientação alimentar e prática de atividade física<sup>22</sup> .  
A sumarização do tratamento não farmacológico do sobrepeso e da obesidade podem ser vistos na **Figura 3** .  
**Figura 3.** Sumarização do tratamento não farmacológico do sobrepeso e da obesidade em adultos.  
###### **Alimentação Saudável**  
- Para alimentação saudável, recomenda-se:  
- Reduzir de ingesta de energia;  
- • Restringir de 500 a 1.000 kcal/dia do gasto energético estimado;  
- Aumentar consumo de alimentos in natura e minimamente processados;  
- • Reduzir no consumo de alimentos processados; • Evitar consumo de alimentos ultraprocessados; • Reduzir consumo de sal e açúcar; • Substituir bebidas com adição de açúcar por água;  
- Dar preferência a preparações culinárias;  
- Utilizar pequenas quantidades de óleo, gorduras, sal e açúcar no preparo ou tempero dos alimentos;  
- Realizar ao menos 3 refeições ao dia.  
###### **Atividade Física**  
- Recomenda-se prática de exercícios físicos combinados (aeróbicos e resistidos);  
- Idosos devem se manter ativos. Exercícios físicos combinados e para melhora do equilíbrio devem ser realizados de acordo com estado de saúde.  
- A prática de atividade física pode ser feita individualmente ou em grupos não muito grandes;  
- Recomenda-se a prática de pelo menos 150 minutos de atividade física por semana.  
- Recomenda-se aos adultos a pratiquem 150 minutos semanais de atividades físicas de intensidades moderadas/vigorosas, por pelo menos 3 dias na semana, como caminhadas em ritmo moderado, corridas, natação, subir escadas. Ou ainda, 30 minutos diários todos os dias da semana.  
- • Para adultos que não realizam nenhuma atividade física metas semanais podem ser propostas para cumprir pelo menos 10 minutos diários de atividades físicas moderadas vigorosas, como caminhar mais rápido, subir escadas, carregar sacolas. A progressão semanal dever ser prevista até atingir a recomendação de 150 minutos de atividades físicas moderadas/vigorosas, por pelo menos 3 dias na semana.  
- • Para benefícios adicionais à saúde os adultos devem realizar duas vezes semanais atividades físicas de fortalecimento muscular, priorizando os grandes grupos musculares.  
###### **Suporte Psicológico**  
- As abordagens psicológicas devem ser adequadas às necessidades do indivíduo e podem ser realizadas individualmente ou em grupo, de acordo com sua preferência;  
- Recomenda-se suporte psicológico baseado em entrevista motivacional e terapia cognitivo-comportamental.  
Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
As Práticas Integrativas e Complementares em Saúde (PICS) se configuram como importantes ferramentas terapêuticas de cuidado, por serem práticas de abordagem integral que consideram todas as dimensões do ser (físico, emocional, mental e social), com recursos que  
23  
ampliam as abordagens e o olhar dos profissionais de saúde sobre o processo saúde-doença, além de instrumentalizar e sensibilizar os usuários para seu autocuidado<sup>113</sup> .  
As PICS são ofertadas no SUS desde 1988, porém, foram instituídas enquanto política pública de saúde em 2006, por meio da Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC). Essa política se constituiu a partir das demandas sociais recorrentes manifestadas nas diversas Conferências Nacionais de Saúde, e das diretrizes e recomendações aos Estados Membros da OMS<sup>113</sup> .  
No tratamento de usuários com obesidade, fortalecer a percepção para o autocuidado é etapa imprescindível para adesão a um estilo e prática de vida mais saudável. Nesse contexto, as PICS são importantes aliadas, contribuindo para a promoção, prevenção e reabilitação da saúde e manejo clínico da obesidade, potencializando o projeto terapêutico singular por meio de seus benefícios.  
Evidências científicas demonstram que algumas PICS, como yoga<sup>*</sup> , auriculoterapia<sup>*</sup> e tai chi chuan<sup>*</sup> , possuem eficácia no tratamento de indivíduos adultos com sobrepeso e obesidade, especialmente para redução do IMC e do peso corporal. A yoga<sup>114,115</sup> e o tai chi chuan<sup>116</sup> mostram efeito positivo para redução do peso e IMC após um ano de realização da prática regularmente. O uso da auriculoterapia<sup>117,118</sup> também auxilia na redução do peso e do IMC. Para potencializar/maximizar este efeito, recomenda-se o tratamento de 12 semanas.  
Além disso, estudos apontam benefícios dessas práticas para redução do estresse, melhora do humor, depressão, ansiedade, insônia, melhora da qualidade de vida e bem-estar físico, que indiretamente contribuem e apoiam o indivíduo com obesidade na adesão ao tratamento e na mudança do comportamento para a adoção de novas práticas, que estejam mais alinhadas à uma alimentação adequada e saudável e a prática de atividades físicas, por exemplo.  
Dessa forma, sempre que disponíveis nos serviços de saúde, as PICS devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos com sobrepeso e obesidade na APS, complementando o tratamento da equipe multiprofissional. Destaca-se ainda que as práticas estão contempladas no rol de procedimentos da Tabela de Procedimentos, Medicamentos,  
> *Os conceitos dessas práticas integrativas estão disponíveis na publicação Glossário Temático de Práticas Integrativas e Complementares em Saúde, pelo link https://portalarquivos2.saude.gov.br/images/pdf/2018/marco/12/glossario-tematico.pdf  
24  
Órteses, Próteses e Materiais Especiais do SUS (SIGTAP) e possuem ressarcimento no Sistema Único de Saúde.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O tratamento cirúrgico da obesidade deverá seguir os critérios dispostos no ANEXO 1 do ANEXO IV da Portaria de Consolidação nº 3, de 28 de setembro de 2017, que dispõe sobre as Diretrizes Gerais para o Tratamento Cirúrgico da Obesidade<sup>119</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
A avaliação do estado nutricional durante a gestação deve ser feita a cada consulta pré-natal, por meio da medida do IMC por semana gestacional. Desse modo, na primeira consulta devem ser determinados, além da semana gestacional, o peso e a altura da gestante. Este cálculo permitirá não apenas a avaliação do estado nutricional atual, como também prever o ganho de peso ao final da gestação<sup>22</sup> .  
Sobrepeso e obesidade pré-gestacional, ganho excessivo de peso durante a gestação e retenção de peso pós-parto também são questões de saúde pública, dada a relação com desfechos negativos como complicações obstétricas ou neonatais, diabetes, obesidade pós-gestação e doenças cardiovasculares<sup>120,121</sup> . Sendo assim, são necessárias ações para o controle do peso materno e a melhoria de desfechos clínicos para o binômio.  
Intervenções combinadas de educação alimentar e nutricional, atividade física e mudança de comportamentos são efetivas para a redução de ganho de peso gestacional, independentemente de faixa de IMC, sem eventos adversos à saúde materna ou do bebê, devendo ser avaliado individualmente cada condição de saúde. A combinação de dietas e atividade física estão associadas à redução de hipertensão, cirurgia cesariana e síndrome do desconforto respiratório neonatal<sup>120</sup> .  
A realização de dietas não assistidas por profissional de saúde, com intuito de perda de peso corporal, não é recomendada durante a gestação, considerando os potenciais malefícios que as restrições e erros alimentares podem causar ao bebê. O Ministério da Saúde disponibiliza  
25  
parâmetros de monitoramento para o ganho de peso durante a gestação<sup>122</sup> . Os valores de acompanhamento, de acordo com o período de gestação, podem ser vistos no **Quadro 4** a seguir.  
**<u>Quadro 4.</u>** Tabela de IMC para gestantes de acordo com período gestacional.  
|**Semana**<br>**gestacional**|**Baixo peso**<br>**(BP) IMC ≤**|**Eutrófico (E) IMC**<br>**entre**|**Sobrepeso (S)**<br>**IMC entre**|**Obesidade (O)**<br>**IMC ≥**|
|---|---|---|---|---|
|6|19,9|20,0 - 24,9|25,0 - 30,0|30,1|
|8|20,1|20,2 - 25,0|25,1 - 30,1|30,2|
|10|20,2|20,3 - 25,2|25,3 - 30,2|30,3|
|11|20,3|20,4 - 25,3|25,4 - 30,3|30,4|
|12|20,4|20,5 - 25,4|25,5 - 30,3|30,4|
|13|20,6|20,7 - 25,6|25,7 - 30,4|30,5|
|14|20,7|20,8 - 25,7|25,8 - 30,5|30,6|
|15|20,8|20,9 - 25,8|25,9 - 30,6|30,7|
|16|21|21,1 - 25,9|26,0 - 30,7|30,8|
|17|21,1|21,2 - 26,0|26,10 - 30,8|30,9|
|18|21,2|21,3 - 26,1|26,2 - 30,9|31|
|19|21,4|21,5 - 26,2|26,3 - 30,9|31|
|20|21,5|21,6 - 26,3|26,4 - 31,0|31,1|
|21|21,7|21,8 - 26,4|26,5 - 31,1|31,2|
|22|21,8|21,9 - 26,6|26,7 - 31,2|31,3|
|23|22|22,1 - 26,8|26,9 - 31,3|31,4|
|24|22,2|22,3 - 26,9|27,0 - 31,5|31,6|
|25|22,4|22,5 - 27,0|27,1 - 31,6|31,7|
|26|22,6|22,7 - 27,2|27,3 - 31,7|31,8|
|27|22,7|22,8 - 27,3|27,4 - 31,8|31,9|
|28|22,9|23,0 - 27,5|27,6 - 31,9|32|
|29|23,1|23,2 - 27,6|27,7 - 32,0|32,1|
|30|23,3|23,4 - 27,8|27,9 - 32,1|32,2|
|31|23,4|23,5 - 27,9|28,0 - 32,2|32,3|
|32|23,6|23,7 - 28,0|28,1 - 32,3|32,4|
|33|23,8|23,9 - 28,1|28,2 - 32,4|32,5|
|34|23,9|24,0 - 28,3|28,4 - 32,5|32,6|
|35|24,1|24,2 - 28,4|28,5 - 32,6|32,7|
|36|24,2|24,3 - 28,5|28,6 - 32,7|32,8|
|37|24,4|24,5 - 28,7|28,8 - 32,8|32,9|
|38|24,5|24,6 - 28,8|28,9 - 32,9|33|
|39|24,7|24,8 - 28,9|29,0 - 33,0|33,1|
|40|24,9|25,0 - 29,1|29,2 - 33,1|33,2|
|41|25|25,1 - 29,2|29,3 - 33,2|33,3|
|42|25|25,1 - 29,2|29,3 - 33,2|33,3|  
Fonte: Vigilância Alimentar e Nutricional – SISVAN<sup>122</sup> .  
26  
Durante a gestação, as mulheres devem ser orientadas quanto à necessidade de manter uma alimentação adequada e saudável e praticar atividade física regularmente, devendo ser avaliada a condição individual de cada gestante. Estas intervenções, quando realizadas conjuntamente, reduzem os riscos de complicações na gestação e durante o parto<sup>123,124</sup> .  
A prática de atividade física de intensidade leve a moderada está associada a redução de ganho de peso gestacional. Quando devidamente orientada, não oferece riscos à gestação ou durante a lactação. A rotina dependerá se a mulher já está habituada à prática de atividade física, podendo ser sugerida sua realização com moderada intensidade<sup>124</sup> , segundo o fluxograma a seguir ( **Figura 4** ):  
**Figura 4.** Fluxograma de prática de exercícios físicos durante a gestação.  
<!-- Start of picture text -->
durante a gestação<br>físico contínuo, 3x/<br>semana<br>Natação  Caminhada<br><!-- End of picture text -->  
Fonte: NICE, 2010<sup>124</sup> ; Farpour-Lambert et al., 2018<sup>120</sup> ; Mottola et al., 2018<sup>125</sup>  
Recomenda-se que a atividade física seja iniciada gradualmente e que a gestante seja orientada a atentar para desconfortos durante à prática. Em alguns casos, pode ser necessária a diminuição ou interrupção da atividade física. O profissional de saúde deverá avaliar a gestante quanto à presença de contraindicações à prática de exercícios aeróbicos ou de sinais de alerta para sua interrupção ( **Quadro 5** )<sup>22</sup> .  
27  
**Quadro 5.** Sinais de alerta e contraindicações à prática de exercícios aeróbicos durante a <u>gestação.</u>  
|**Sinais de alerta para**<br>**interrupção do exercício**<br>**aeróbico**|**Contraindicações relativas à**<br>**prática do exercício aeróbico**|**Contraindicações absolutas à**<br>**prática do exercício aeróbico**|
|---|---|---|
|Sangramento vaginal|Anemia grave|Doença cardíaca|
|Dispneia<br>Tontura|Arritmia cardíaca materna não<br>avaliada|hemodinamicamente<br>significativa|
|Cefaleia<br>Dor torácica|Bronquite crônica<br>Obesidade mórbida|Doença pulmonar restritiva<br>Incompetência cervical|
|Fraqueza muscular|Baixo peso extremo|Gestação múltipla com risco de|
|Dor ou inchaço em panturrilha<br>Parto prematuro|História de sedentarismo<br>extremo|parto<br>Sangramento persistente após|
|Redução do movimento fetal<br>Perda de líquido amniótico|Restrição do crescimento<br>intrauterino<br>Limitações ortopédicas<br>Fumo excessivo<br>Comorbidades descompensadas|2º ou 3º trimestre<br>Placenta prévia após 26<br>semanas de gestação<br>Parto prematuro<br>Ruptura de membranas<br>Síndrome hipertensiva da<br>gravidez|  
Fonte: Estratégias para o cuidado da pessoa com doença crônica – Obesidade<sup>22</sup> .  
Durante o período pós natal, a prática combinada de alimentação adequada e saudável e prática de atividade física, em modalidade individual ou em grupo, foram efetivas para redução de retenção de peso pós-parto. A prescrição caso a caso de atividade física e definição de objetivos realistas para redução de peso também contribui para perda ponderal pós parto<sup>120</sup> .É importante ressaltar que estas estratégias devem ser recomendadas e acompanhadas por profissional da saúde.  
Recomenda-se iniciar a prática de atividade física de 4 a 6 semanas após o parto. Intensidades leves a moderadas podem não ser o suficientes para induzir perda do peso obtido durante a gestação, mas resulta em benefícios cardiovasculares além de reduzir o risco de depressão pósparto<sup>120</sup> .  
Durante o período pós-parto, deve-se estimular alimentação adequada e saudável, evitando o consumo de alimentos ultraprocessados, ricos em gorduras, açúcares, sódio ou e calorias. O aleitamento materno aumenta a demanda energética diária nas mulheres, favorecendo a perda de peso pós-parto, devendo ser estimulada<sup>22</sup> .  
28

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
A bulimia nervosa é um distúrbio psiquiátrico que é cada vez mais diagnosticado em pessoas com obesidade e em indivíduos após tratamento cirúrgico da obesidade. Pode ser decorrente de fatores biológicos (predisposição genética, mecanismo prejudicado de controle da saciedade, distúrbios neuroquímicos, incluindo deficiência de serotonina), comportamentais (transtornos alimentares e alimentação irregular, usando restrições nutricionais), psicológicos (depressão, regulação emocional prejudicada, baixa autoestima com altas expectativas de si mesmo), condições sistêmicas/familiares (relações e comunicação entre os membros da família prejudicadas) e socioculturais (o culto ao corpo e a aspiração de ter um corpo perfeito)<sup>126</sup> .  
Quando não tratada, a bulimia pode afetar significativamente os resultados do tratamento da obesidade e o estado geral de saúde dos usuários. Dessa maneira, o tratamento dessa condição deve ser considerado prioritário em indivíduos com obesidade e bulimia coexistentes, seguido pelo tratamento de excesso de peso corporal<sup>126</sup> .  
A intervenção deve se concentrar inicialmente no diagnóstico e tratamento eficaz dos transtornos alimentares e depois na redução do excesso de peso corporal. O tratamento deve ser abrangente devido à etiologia complexa da bulimia e da obesidade e suas relações mútuas. A terapêutica deve incluir mudanças no comportamento, incluindo hábitos alimentares, bem como melhoria da saúde mental de um indivíduo, pois aumenta as chances de o tratamento ser eficaz. Portanto, é necessária a cooperação entre o usuário e a equipe multiprofissional, incluindo médicos de diferentes especialidades, enfermeiros, psicólogo, psiquiatra e nutricionista<sup>126</sup> .  
A compulsão alimentar é caracterizada pelo consumo recorrente, periódico e descontrolado de excessivas quantidades de alimento sem comportamentos compensatórios (por exemplo, uso de laxantes ou indução de vômito) para controle do peso. Os sintomas desta condição incluem consumo de grandes porções de alimentos, maiores do que as pretendidas ou do que a maioria das pessoas ingeriria em circunstâncias e intervalos de tempos semelhantes; pouco controle sobre a ingestão de alimentos, com manutenção do comportamento apesar dos efeitos negativos; desejos intensos; alterações emocionais; e impulsividade aumentada<sup>127</sup> . Pessoas com compulsão alimentar comem rapidamente até se sentirem desconfortavelmente cheias; comem grandes quantidades de comida mesmo sem estarem com fome; e comem sozinhas devido ao  
29  
embaraço pela quantidade de comida. Ainda, estas pessoas geralmente sentem repulsa por si mesmas, depressão ou culpa excessiva após o episódio compulsivo<sup>128</sup> .  
Existem evidências de que emoções negativas como raiva e frustração, doenças psiquiátricas, como ansiedade e depressão, hora do dia e tipo de refeição podem ser gatilhos para a compulsão alimentar<sup>129</sup> .  
O tratamento da compulsão alimentar tem como foco o comportamento alimentar, a psicopatologia e sintomatologia associadas. Os objetivos do tratamento devem ser realistas e focados no controle do comportamento compulsivo, na interrupção de dietas restritivas e no desenvolvimento de hábitos saudáveis. Apenas posteriormente deve-se instituir medidas para redução de peso corporal<sup>129,130</sup> .

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O acompanhamento de pessoas com obesidade e sobrepeso em tratamento e o monitoramento dos efeitos das medidas terapêuticas instituídas são aspectos importantes, tendo em vista o suporte da equipe de profissionais na perda e manutenção do peso, além do acompanhamento das condições de saúde associadas<sup>55</sup> .  
O sobrepeso e a obesidade são condições complexas e de origem multifatorial que resultam em alterações físicas e mentais. Deste modo, entende-se que o acompanhamento e tratamento destes pacientes deve ser feito por equipe multiprofissional, nos diferentes níveis de atenção à saúde, conforme as necessidades individuais de cada usuário.  
Em todos os usuários, peso e altura devem ser medidos e o IMC calculado. Para indivíduos com peso estável, um intervalo de 1 ano é adequado para a reavaliação do IMC. Para indivíduos com sobrepeso ou obesidade ou aqueles de peso adequado conforme IMC com um histórico de sobrepeso, uma monitorização mais frequente pode ser apropriada<sup>70</sup> . Pacientes que não apresentem perda de peso clinicamente relevante devem ser avaliados não somente quanto às medidas antropométricas, mas também quanto a fatores e barreiras que possam estar influenciando na resposta ao tratamento<sup>49</sup> .  
30  
O automonitoramento do peso corporal, em domicílio, apresenta benefícios que tendem a auxiliar na redução de peso em indivíduos com sobrepeso ou obesidade. Deste modo, os usuários podem verificar seu peso uma vez por semana, caso tenham uma balança disponível e, se assim desejarem, dado que as variações de peso podem gerar mais ansiedade e frustração ( **Apêndice 13** ). Embora estes intervalos de seguimento não sejam baseados em evidências robustas, eles são um compromisso razoável entre a necessidade de identificar o ganho de peso numa fase precoce e a necessidade de limitar tempo, esforço e custo de medidas repetidas<sup>70,78,131</sup> .  
No **Quadro 6** consta a composição de uma equipe multiprofissional que pode estar envolvida no tratamento e acompanhamento dos usuários com sobrepeso e obesidade e exames que podem ser solicitados, de acordo com as necessidades individuais. A APS é a porta de entrada ao sistema bem como todos os profissionais nela envolvidos; isso inclui a ESF e outras equipes de APS. Exames não são recomendados como prática cotidiana. Estes devem ser solicitados por profissional de saúde quando houver necessidade. A frequência de avaliação das pessoas com sobrepeso e obesidade pode ser alterada de acordo com o estado clínico e as necessidades do indivíduo. No entanto, evidências apontam a importância do acompanhamento por aproximadamente 12 meses ou mais e, se possível, com intervalo mensal entre as abordagens<sup>132,133</sup> .  
**Quadro 6.** Equipe multidisciplinar, avaliações e exames complementares.  
|**Avaliação**|
|---|
|Médico endocrinologista|
|Médico de família e comunidade|
|Enfermeiro|
|Profissional de educação física|
|Nutricionista|
|Psicólogo|
|Médico Psiquiatra|
|Fisioterapeuta|
|Fonoaudiólogo|
|Médico Nutrólogo|
|Dentista|
|Cirurugião dentista|
|Assistente social|
|Avaliação Clínica|
|Frequência Cardíaca|
|Pressão Arterial|
|Peso/IMC|
|Perímetro da cintura|
|Exames complementares (se necessário)|
|Glicemia|  
31  
|Hemoglobina glicosilada|
|---|
|Colesterol total e frações|
|Triglicerídeos|
|Exame coprológico funcional|
|Urinálise|  
Fonte: Elaboração própria.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
A organização do cuidado à pessoa com sobrepeso ou obesidade nos serviços de saúde, sobretudo a APS por sua atribuição de proporcionar o primeiro contato das pessoas com o sistema de saúde, deve prever, sempre que possível, a realização do diagnóstico nutricional. Ainda no nível da APS, é possível direcionar indivíduo com sobrepeso ou obesidade a um nutricionista da APS ou à atenção especializada para receber orientações para uma alimentação adequada, saudável e balanceada. Também é possível promover e estimular a prática de atividades físicas nas próprias UBS ou encaminhar a pessoa com sobrepeso ou obesidade para um polo da Academia da Saúde para realização de atividades físicas orientadas e supervisionadas por profissional capacitado. Cabe ressaltar a importância da integração entre os pontos de atenção à saúde, a fim de possibilitar a atenção integral e tratamento adequado a cada situação<sup>22,64,134</sup> .  
Diante da complexidade que envolve a problemática de saúde de sobrepeso e obesidade, é necessário o envolvimento e a articulação dos entes federados na organização dos serviços a fim de ofertar cuidado multidisciplinar adequado, integral e longitudinal, por meio de abordagens individuais e coletivas, tanto com ações direcionadas para o usuário, quanto para a família, o que exige organização do processo de trabalho em cada ponto de atenção, bem como nos diversos serviços da rede de atenção à saúde. Para subsidiar os gestores estaduais e municipais na elaboração de linhas de cuidado às pessoas com sobrepeso e obesidade, inclusive com descrição de responsabilidades para cada ente, recomenda-se consultar as portarias citadas no ANEXO 2, que estão consolidadas na Portaria de Consolidação nº 3, de 28 de setembro de 2017 - Consolidação das normas sobre as redes do Sistema Único de Saúde, em seu Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças. Ressalta-se que não estão contempladas neste anexo as normativas estaduais e municipais relacionadas à temática de sobrepeso e obesidade.  
Outros materiais para auxiliar gestores e profissionais, com orientações para a organização da assistência direcionados às pessoas com sobrepeso e obesidade são as publicações do Ministério  
32  
da Saúde, dentre elas, o Caderno de Atenção Básica nº 38, que contém estratégias para o cuidado da pessoa com doença crônica – obesidade, considerando os ciclos e eventos de vida, incluindo desde a classificação, diagnóstico e manejo da obesidade, com exemplos de estratégias de abordagem, bem como com orientações específicas de tratamento, incluindo ainda ações de promoção da saúde, educação em saúde e prevenção da obesidade<sup>22</sup> .  
Considerando a possibilidade de fatores de riscos cardiovasculares associados à obesidade, foi elaborado e publicado, em consonância com o Guia Alimentar para População Brasileira<sup>80</sup> , o Manual da Alimentação Cardioprotetora, no intuito de subsidiar a orientação nutricional e dietética realizada pelos diferentes profissionais, em especial da Atenção Primária, e facilitar a compreensão dos indivíduos, estimulando sua adesão às orientações<sup>135,136</sup> .  
Com base nestes documentos e na articulação entre os diferentes níveis de atenção à saúde, o atendimento dos indivíduos, visando à prevenção e ao controle de sobrepeso e obesidade no país deve seguir o fluxo constante na **Figura 5** .  
33  
##### **Figura 5.** Fluxo de atendimento ao indivíduo com sobrepeso ou obesidade no SUS.  
<!-- Start of picture text -->
AgGes de Vigilancia Alimentar e Nutricional (VAN); de promogao dasatide<br>fr ede prevengao do sobrepeso e da obesidade; avaliagao do estado<br>nutricional<br>Identificagao das<br>preeeeeeeeenenees BREEEEEEE pessoas<br>eobesidade?<br>Hi com sobrepeso<br>¥v :<br>‘Ages de ViglinciaAlmentar<br>Gone Crstoc O IMC 25 a 39,99 Ke/m2 comorbidades descompasa<br>Gees PCS das ou IMC2 40 Kg/m2<br>sobre promogio de<br>alimentag30 adequada e- : :<br>‘saudivel; e pritica de H :<br>‘aividade’fisica<br>Abordagem inicial, estratégj<br>de sensiblizgo eavalagsoas. ::<br>2q cestratificag3ode comorbi d ates,e risco e<br>f excaminhamento para AE se<br>: Regulagao<br>: Agies de promogio da saide<br>% edeprevengio do sobrepeso<br>rmuliprofisional, com *<br>abordagms _individuais, 5 Sistemas de Apoio e<br>ee eee, 5 Sistemas Logisticas<br>i exames<br>: complementares ao<br>Encaminhamento para<br>cepotadas as possibilidadeAE s e crsimotratamento e<br>Abordagens transversais: suporte psicol6gico, pratica de atividade fisica, PICS, aces intersetoriais para promogao da saiide e<br>prevencdo do sobrepeso e obesidade<br>Legendas:<br>** AE:APS: ComponenteAtencao Primaria Atencioa SaideEspecializada<br>* Abordagens individuais: acompanhamento individual com equipe multiprofissional<br>* Abordagens coletivas: atividades em grupo para manejo da condigao de obesidade<br>* Abordagens transversais: atividades<br>suporte psicolégico, atividades intersetoriais,a serempréticasrealizadasintegrativas simultaneamentee complementares durante todo- PICS)o tratamento e acompanhamento (atividade fisica,<br><!-- End of picture text -->  
Fonte: Elaboração Própria  
34

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
1. BRASIL. PORTARIA No 375, DE 10 DE NOVEMBRO DE 2009. Diário Oficial da União. 2009.  
2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.  
3. Associação Brasileira de Nutrologia, Sociedade Brasileira de Nutrição Parenteral e Enteral. Utilização da Bioimpedância para Avaliação da Massa Corpórea. Associação Médica Brasileira e Conselho Federal de Medicina. 2009.  
4. Wang ZH, Yang ZP, Wang XJ, Dong YH, Ma J. Comparative Analysis of the MultiFrequency Bio-impedance and Dual-energy X-ray Absorptiometry on Body Composition in Obese Subjects. Biomed Environ Sci. 2018 Jan;31(1):72–5.  
5. Leal AAD, Faintuch J, Morais AAC, Noe JAB, Bertollo DM, Morais RC, et al. Bioimpedance analysis: should it be used in morbid obesity? Am J Hum Biol Off J Hum Biol Counc. 2011;23(3):420–2.  
6. Câmara Interministerial de Segurança Alimentar e Nutricional. Estratégia Intersetorial de Prevenção e Controle da Obesidade: recomendações para estados e municípios [Internet]. Brasília: Imprensa Nacional; 2014. Available from:  
http://www.mds.gov.br/webarquivos/publicacao/seguranca_alimentar/estrategia_prevencao _obesidade.pdf  
7. BRASIL. Relatório de Recomendação no 522: Sibutramina para o tratamento dos pacientes com obesidade. Ministério da Saúde. 2020.  
8. BRASIL. Relatório de Recomendação no. 523: Orlistate para a redução de peso em indivíduos com sobrepeso ou obesidade [Internet]. Ministério da Saúde. 2020. Available from: http://conitec.gov.br/images/Relatorios/2020/Relatorio_orlistate_sobrepeso_obesidade_523_ 2020_FINAL.pdf  
9. Nordisk N. Ozempic® (semaglutida) [Internet]. ANVISA. Farm. resp: Luciane M. H. Fernandes – CRF/PR n° 6002; 2020. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351658916201751/?substancia=26316  
10. BRASIL. PORTARIA No 424, DE 19 DE MARÇO DE 2013. Redefine as diretrizes para a organização da prevenção e do tratamento do sobrepeso e obesidade como linha de cuidado prioritária da Rede de Atenção à Saúde das Pessoas com Doenças Crônicas. [Internet]. Diário Oficial da União. 2013. Available from: http://www.in.gov.br/en/web/dou/-/portaria-n-424-de19-de-marco-de-2013-30422469  
35  
11. BRASIL. PORTARIA No 425, DE 19 DE MARÇO DE 2013. Estabelece regulamento técnico, normas e critérios para a Assistência de Alta Complexidade ao Indivíduo com Obesidade. [Internet]. Diário Oficial da União. 2013. Available from: http://pesquisa.in.gov.br/imprensa/jsp/visualiza/index.jsp?jornal=1&pagina=59&data=15/04/ 2013  
12. Arora M, Barquera S, Farpour Lambert NJ, Hassell T, Heymsfield SB, Oldfield B, et al. Stigma and obesity: the crux of the matter. Lancet Public Heal. 2019 Nov;4(11):e549–50.  
13. Ng M, Fleming T, Robinson M, Thomson B, Graetz N, Margono C, et al. Global, regional, and national prevalence of overweight and obesity in children and adults during 1980-2013: a systematic analysis for the Global Burden of Disease Study 2013. Lancet (London, England). 2014 Aug;384(9945):766–81.  
14. Flint SW. The complexity of obesity. lancet Diabetes Endocrinol. 2019 Nov;7(11):833.  
15. Puhl R, Suh Y. Health Consequences of Weight Stigma: Implications for Obesity Prevention and Treatment. Curr Obes Rep. 2015 Jun;4(2):182–90.  
16. Coordenação-Geral de Vigilância de Agravos e Doenças Não Transmissíveis (CGDANT/DASNT/SVS). Vigitel Brasil 2019: principais resultados. In: Boletim Epidemiológico n 16 [Internet]. 51st ed. Secretaria de Vigilância em Saúde/ Ministério da Saúde; 2020. p. 2026. Available from: https://www.saude.gov.br/images/pdf/2020/April/16/Boletim-epidemiologicoSVS-16.pdf  
17. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Vigitel Brasil 2019: Vigilância de Fatores de Risco e Proteção para Doenças Crônicas por Inquérito Telefônico. Brasília, DF.: Ministério da Saúde; 2020.  
18. BRASIL. VIGITEL Brasil 2018 População Negra [Internet]. Brasília: Ministério da Saúde; 2019. Available from: %0A  
19. Trayhurn P. The biology of obesity. Proc Nutr Soc [Internet]. 2007/03/07. 2005;64(1):31–  
8. Available from: https://www.cambridge.org/core/article/biology-ofobesity/456C4E8E8B4A3850DAC6E015BB62F6D8  
20. Jou C. The Biology and Genetics of Obesity — A Century of Inquiries. N Engl J Med [Internet]. 2014 May 14;370(20):1874–7. Available from:  
https://doi.org/10.1056/NEJMp1400613  
21. Goodarzi MO. Genetics of obesity: what genetic association studies have taught us about the biology of obesity and its complications. Lancet Diabetes Endocrinol [Internet]. 2018 Mar 1;6(3):223–36. Available from: https://doi.org/10.1016/S2213-8587(17)30200-0  
22. WHO. Obesity and overweight. WHO. 2020.  
36  
23. BRASIL. Cadernos de Atenção Básica: Estratégias para o cuidado da pessoa com doença crônica - Obesidade [Internet]. Ministério da Saúde. 2014. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_doenca_cronica_obesidade _cab38.pdf  
24. Ferreira RW, Caputo EL, Häfele CA, Jerônimo JS, Florindo AA, Knuth AG, et al. [Access to public physical activity programs in Brazil: National Health Survey, 2013]. Cad Saude Publica. 2019 Feb;35(2):e00008618.  
25. Guthold R, Stevens GA, Riley LM, Bull FC. Worldwide trends in insufficient physical activity from 2001 to 2016: a pooled analysis of 358 population-based surveys with 1·9 million participants. Lancet Glob Heal. 2018 Oct;6(10):e1077–86.  
26. Whitaker RC, Wright JA, Pepe MS, Seidel KD, Dietz WH. Predicting obesity in young adulthood from childhood and parental obesity. N Engl J Med. 1997 Sep;337(13):869–73. 27. Qi Q, Chu AY, Kang JH, Huang J, Rose LM, Jensen MK, et al. Fried food consumption, genetic risk, and body mass index: gene-diet interaction analysis in three US cohort studies. BMJ. 2014 Mar;348:g1610.  
28. Rohde K, Keller M, la Cour Poulsen L, Blüher M, Kovacs P, Böttcher Y. Genetics and epigenetics in obesity. Metabolism. 2019 Mar;92:37–50.  
29. Livingstone KM, Celis-Morales C, Papandonatos GD, Erar B, Florez JC, Jablonski KA, et al. FTO genotype and weight loss: systematic review and meta-analysis of 9563 individual participant data from eight randomised controlled trials. BMJ. 2016 Sep;354:i4707.  
30. Francisqueti F, Nascimento A, Correa C. Obesidade, inflamação e complicações metabólicas. Rev da Soc Bras Aliment e Nutr. 2015 Jan 1;40:81–9.  
31. Ellulu MS, Patimah I, Khaza’ai H, Rahmat A, Abed Y. Obesity and inflammation: the linking mechanism and the complications. Arch Med Sci [Internet]. 2016/03/31. 2017 Jun;13(4):851–63. Available from: https://pubmed.ncbi.nlm.nih.gov/28721154  
32. Schwartz MW, Woods SC, Porte D, Seeley RJ, Baskin DG. Central nervous system control of food intake. Nature [Internet]. 2000;404(6778):661–71. Available from: https://doi.org/10.1038/35007534  
33. Pont SJ, Puhl R, Cook SR, Slusser W. Stigma Experienced by Children and Adolescents With Obesity. Pediatrics [Internet]. 2017 Dec 1;140(6):e20173034. Available from: http://pediatrics.aappublications.org/content/140/6/e20173034.abstract  
34. Prochaska JJ, Prochaska JO. A Review of Multiple Health Behavior Change Interventions for Primary Prevention. Am J Lifestyle Med. 2011 May;5(3).  
35. Robinson BE, Bacon JG, O’Reilly J. Fat phobia: measuring, understanding, and changing anti-fat attitudes. Int J Eat Disord. 1993 Dec;14(4):467–80.  
37  
36. Bacon JG, Scheltema KE, Robinson BE. Fat phobia scale revisited: the short form. Int J Obes Relat Metab Disord. 2001 Feb;25(2):252–7.  
37. Stein J, Luppa M, Ruzanska U, Sikorski C, Konig H-H, Riedel-Heller SG. Measuring negative attitudes towards overweight and obesity in the German population - psychometric properties and reference values for the German short version of the Fat Phobia Scale (FPS). PLoS One. 2014;9(12):e114641.  
38. Paim MB. Os corpos gordos merecem ser vividos . Vol. 27, Revista Estudos Feministas . scielo ; 2019.  
39. Weinberger N-A, Kersting A, Riedel-Heller SG, Luck-Sikorski C. Body Dissatisfaction in Individuals with Obesity Compared to Normal-Weight Individuals: A Systematic Review and Meta-Analysis. Obes Facts. 2016;9(6):424–41.  
40. Chao H-L. Body image change in obese and overweight persons enrolled in weight loss intervention programs: a systematic review and meta-analysis. PLoS One. 2015;10(5):e0124036. 41. Enzi G. Socioeconomic consequences of obesity: the effect of obesity on the individual. Pharmacoeconomics. 1994;5(Suppl 1):54–7.  
42. Wellman NS. Causes and consequences of adult obesity: health, social and economic impacts in the United States. Asia Pac J Clin Nutr. 2003;11(S8):S705–9. 43. Cawley J. An economy of scales: A selective review of obesity’s economic causes, consequences, and solutions. J Health Econ. 2015 Sep;43:244–68. 44. Teachman BA, Brownell KD. Implicit anti-fat bias among health professionals: is anyone immune? Int J Obes [Internet]. 2001;25(10):1525–31. Available from: https://doi.org/10.1038/sj.ijo.0801745  
45. Kirk S, Ramos Salas X, Alberga A, Russell-Mayhew S. Canadian Adult Obesity Clinical Practice Guidelines: Reducing Weight Bias, Stigma and Discrimination in Obesity Management, Practice and Policy. Obesity Canada. 2020.  
46. Tomiyama AJ, Carr D, Granberg EM, Major B, Robinson E, Sutin AR, et al. How and why weight stigma drives the obesity ‘epidemic’ and harms health. BMC Med [Internet]. 2018;16(1):123. Available from: https://doi.org/10.1186/s12916-018-1116-5  
47. Rubino F, Puhl RM, Cummings DE, Eckel RH, Ryan DH, Mechanick JI, et al. Joint international consensus statement for ending stigma of obesity. Nat Med [Internet]. 2020/03/04. 2020 Apr;26(4):485–97. Available from: https://pubmed.ncbi.nlm.nih.gov/32127716 48. Silva B, Cantisani J. INTERFACES ENTRE A GORDOFOBIA E A FORMAÇÃO ACADÊMICA EM NUTRIÇÃO: UM DEBATE NECESSÁRIO. DEMETRA Aliment Nutr Saúde. 2018 Jul 13;13.  
38  
49. Alberga AS, Edache IY, Forhan M, Russell-Mayhew S. Weight bias and health care utilization: a scoping review. Prim Health Care Res Dev [Internet]. 2019 Jul 22;20:e116–e116. Available from: https://pubmed.ncbi.nlm.nih.gov/32800008  
50. Wharton S, Lau DCW, Vallis M, Sharma AM, Biertho L, Campbell-Scherer D, et al. Obesity in adults: a clinical practice guideline. Can Med Assoc J [Internet]. 2020 Aug 4;192(31):E875 LPE891. Available from: http://www.cmaj.ca/content/192/31/E875.abstract  
51. Withrow D, Alter DA. The economic burden of obesity worldwide: a systematic review of the direct costs of obesity. Obes Rev. 2011 Feb;12(2):131–41.  
52. Bahia L, Araújo DV. Impacto econômico da obesidade no Brasil. Rev HUPE. 2014;13(1):13–7.  
53. Schünemann HJ, Wiercioch W, Etxeandia I, Falavigna M, Santesso N, Mustafa R, et al. Guidelines 2.0: Systematic development of a comprehensive checklist for a successful guideline enterprise. CMAJ. 2014;  
54. Wolfenden L, Ezzati M, Larijani B, Dietz W. The challenge for global health systems in preventing and managing obesity. Obes Rev. 2019 Nov;20 Suppl 2:185–93.  
55. Semlitsch T, Stigler FL, Jeitler K, Horvath K, Siebenhofer A. Management of overweight and obesity in primary care-A systematic overview of international evidence-based guidelines. Obes Rev. 2019 Sep;20(9):1218–30.  
56. WHO. Obesity: preventing and managing the global epidemic [Internet]. Report of a WHO Consultation (WHO Technical Report Series 894). 2003. Available from: Report of a WHO Consultation (WHO Technical Report Series 894  
57. ABESO. Diretrizes brasileiras de obesidade 2016 / ABESO - Associação Brasileira para o Estudo da Obesidade e da Síndrome Metabólica. 4a ed. Associação Brasileira para o Estudo da Obesidade e da Síndrome Metabólica. São Paulo; 2016.  
58. Rezende FAC, Rosado LEFPL, Ribeiro R de CL, Vidigal F de C, Vasques ACJ, Bonard IS, et al. Body mass index and waist circumference: association with cardiovascular risk factors. Arq Bras Cardiol. 2006 Dec;87(6):728–34.  
59. BRASIL. Orientações para a coleta e análise de dados antropométricos em serviços de saúde: Norma técnica do Sistema de Vigilância Alimentar e Nutricional - SISVAN. Ministério da Saúde. 2011.  
60. BRASIL. Marco de Referência da Vigilância Alimentar e Nutricional na Atenção Básica [Internet]. Ministério da Saúde. 2015 [cited 2020 Mar 10]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/marco_referencia_vigilancia_alimentar.pdf  
61. Lund TB, Sandoe P, Lassen J. Attitudes to publicly funded obesity treatment and prevention. Obesity (Silver Spring). 2011 Aug;19(8):1580–5.  
39  
62. BRASIL. Política Nacional de Atenção Básica. Brasília: Ministério da Saúde; 2012.  
63. Lombard CB, Deeks AA, Teede HJ. A systematic review of interventions aimed at the prevention of weight gain in adults. Public Health Nutr. 2009 Nov;12(11):2236–46.  
64. Lemmens VEPP, Oenema A, Klepp KI, Henriksen HB, Brug J. A systematic review of the evidence regarding efficacy of obesity prevention interventions among adults. Obes Rev. 2008 Sep;9(5):446–55.  
65. BRASIL. Política Nacional de Alimentação e Nutrição (PNAN) [Internet]. Ministério da Saúde. 2013 [cited 2020 Mar 10]. Available from:  
https://bvsms.saude.gov.br/bvs/publicacoes/politica_nacional_alimentacao_nutricao.pdf  
66. NICE. Obesity: identification, assessment and management. NICE Clinical Guidance. 2014.  
67. Jones PR, Ekelund U. Physical Activity in the Prevention of Weight Gain: the Impact of Measurement and Interpretation of Associations. Curr Obes Rep. 2019 Jun;8(2):66–76.  
68. Swinburn BA, Kraak VI, Allender S, Atkins VJ, Baker PI, Bogard JR, et al. The Global Syndemic of Obesity, Undernutrition, and Climate Change: The Lancet Commission report. Lancet (London, England). 2019 Feb;393(10173):791–846.  
69. Egger G, Swinburn B. An “ecological” approach to the obesity pandemic. BMJ [Internet]. 1997 Aug 23;315(7106):477–80. Available from: https://pubmed.ncbi.nlm.nih.gov/9284671  
70. Gargallo Fernandez Manuel M, Breton Lesmes I, Basulto Marset J, Quiles Izquierdo J, Formiguera Sala X, Salas-Salvado J. Evidence-based nutritional recommendations for the prevention and treatment of overweight and obesity in adults (FESNAD-SEEDO consensus document). The role of diet in obesity treatment (III/III). Nutr Hosp. 2012;27(3):833–64.  
71. Jensen MD, Ryan DH, Apovian CM, Ard JD, Comuzzie AG, Donato KA, et al. 2013 AHA/ACC/TOS guideline for the management of overweight and obesity in adults: a report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines and The Obesity Society. Circulation. 2014 Jun;129(25 Suppl 2):S102-38.  
72. Raynor HA, Champagne CM. Position of the Academy of Nutrition and Dietetics: Interventions for the Treatment of Overweight and Obesity in Adults. J Acad Nutr Diet. 2016 Jan;116(1):129–47.  
73. Franz MJ, VanWormer JJ, Crain AL, Boucher JL, Histon T, Caplan W, et al. Weight-loss outcomes: a systematic review and meta-analysis of weight-loss clinical trials with a minimum 1-year follow-up. J Am Diet Assoc. 2007 Oct;107(10):1755–67.  
74. Blackburn G. Effect of degree of weight loss on health benefits. Obes Res. 1995 Sep;3 Suppl 2:211s-216s.  
75. CDC. Losing Weight. CDC. 2020.  
40  
76. Vallis M. Quality of life and psychological well-being in obesity management: improving the odds of success by managing distress. Int J Clin Pract. 2016 Mar;70(3):196–205.  
77. van Gemert WAM, van der Palen J, Monninkhof EM, Rozeboom A, Peters R, Wittink H, et al. Quality of Life after Diet or Exercise-Induced Weight Loss in Overweight to Obese Postmenopausal Women: The SHAPE-2 Randomised Controlled Trial. PLoS One. 2015;10(6):e0127520.  
78. Noël PH, Pugh JA. Management of overweight and obese adults. BMJ [Internet]. 2002 Oct 5;325(7367):757–61. Available from: https://pubmed.ncbi.nlm.nih.gov/12364306  
79. Knowler WC, Barrett-Connor E, Fowler SE, Hamman RF, Lachin JM, Walker EA, et al. Reduction in the incidence of type 2 diabetes with lifestyle intervention or metformin. N Engl J Med. 2002 Feb;346(6):393–403.  
80. Look AHEAD Research Group. Eight-year weight losses with an intensive lifestyle intervention: the look AHEAD study. Obesity (Silver Spring) [Internet]. 2014 Jan;22(1):5–13. Available from: https://pubmed.ncbi.nlm.nih.gov/24307184  
81. BRASIL. Guia alimentar para a população Brasileira [Internet]. 2a ed. Melo EA, editor. Ministério da Saúde. Ministério da Saúde; 2014. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/guia_alimentar_populacao_brasileira_2ed.pdf 82. Kahan S, Manson JE. Obesity Treatment, Beyond the Guidelines: Practical Suggestions for Clinical Practice. JAMA. 2019 Apr;321(14):1349–50. 83. OPAS. Ultra-processed food and drink products in Latin America: Trends, impact on obesity, policy implications [Internet]. Washington: Organização Pan-Americana da Saúde (OPAS/OMS); 2015. Available from: https://iris.paho.org/bitstream/handle/10665.2/7699/9789275118641_eng.pdf?sequence=5& isAllowed=y  
84. Elizabeth L, Machado P, Zinöcker M, Baker P, Lawrence M. Ultra-Processed Foods and Health Outcomes: A Narrative Review. Nutrients. 2020 Jun;12(7).  
85. Beslay M, Srour B, Méjean C, Allès B, Fiolet T, Debras C, et al. Ultra-processed food intake in association with BMI change and risk of overweight and obesity: A prospective analysis of the French NutriNet-Santé cohort. PLoS Med [Internet]. 2020 Aug 27;17(8):e1003256–e1003256. Available from: https://pubmed.ncbi.nlm.nih.gov/32853224  
86. Costa CDS, Assunção MCF, Loret de Mola C, Cardoso J de S, Matijasevich A, Barros AJD, et al. Role of ultra-processed food in fat mass index between 6 and 11 years of age: a cohort study. Int J Epidemiol. 2020 Sep;  
87. Gombi-Vaca MF, Sichieri R, Verly EJ. Caloric compensation for sugar-sweetened beverages in meals: A population-based study in Brazil. Appetite. 2016 Mar;98:67–73.  
41  
88. WHO. Healthy Diet - WHO FAct Sheet no. 394. WHO Fact Sheet. 2018.  
89. Oliveira D, Galhardo J, Ares G, Cunha LM, Deliza R. Sugar reduction in fruit nectars: Impact on consumers’ sensory and hedonic perception. Food Res Int. 2018 May;107:371–7. 90. Pearlman M, Obert J, Casey L. The Association Between Artificial Sweeteners and Obesity. Curr Gastroenterol Rep. 2017 Nov;19(12):64.  
91. 5. Facilitating Behavior Change and Well-being to Improve Health Outcomes: &lt;em&gt;Standards of Medical Care in Diabetes—2020&lt;/em&gt; Diabetes Care [Internet]. 2020 Jan 1;43(Supplement 1):S48 LP-S65. Available from: http://care.diabetesjournals.org/content/43/Supplement_1/S48.abstract  
92. Caspersen CJ, Powell KE, Christenson GM. Physical activity, exercise, and physical fitness: definitions and distinctions for health-related research. Public Health Rep. 1985;100(2):126–31. 93. WHO. Global Recommendations on Physical Activity for Health. WHO. 2010. 94. Pettee Gabriel KK, Morrow JRJ, Woolsey A-LT. Framework for physical activity as a complex and multidimensional behavior. J Phys Act Health. 2012 Jan;9 Suppl 1:S11-8. 95. World Health Organization. More active people for a healthier world : global action plan on physical activity 2018-2030. 101 p. 96. Tremblay MS, Aubert S, Barnes JD, Saunders TJ, Carson V, Latimer-Cheung AE, et al. Sedentary Behavior Research Network (SBRN) - Terminology Consensus Project process and outcome. Int J Behav Nutr Phys Act. 2017 Jun;14(1):75.  
97. Piercy KL, Troiano RP, Ballard RM, Carlson SA, Fulton JE, Galuska DA, et al. The Physical Activity Guidelines for Americans. JAMA. 2018 Nov;320(19):2020–8. 98. Reis EC dos. Avaliação do componente ambulatorial especializado da linha de cuidado para obesidade grave na cidade do Rio de Janeiro. Fundação Oswaldo Cruz; 2018. 99. WHO. ACTIVE: a technical package for increasing physical activity [Internet]. WHO. 2018 [cited 2019 Nov 15]. Available from: https://apps.who.int/iris/handle/10665/275415 100. Warburton DER, Bredin SSD. Reflections on Physical Activity and Health: What Should We Recommend? Can J Cardiol. 2016 Apr;32(4):495–504. 101. Yumuk V, Tsigos C, Fried M, Schindler K, Busetto L, Micic D, et al. European Guidelines for Obesity Management in Adults. Obes Facts. 2015;8(6):402–24.  
102. Haynes A, Kersbergen I, Sutin A, Daly M, Robinson E. Does perceived overweight increase risk of depressive symptoms and suicidality beyond objective weight status? A systematic review and meta-analysis. Clin Psychol Rev. 2019 Nov;73:101753.  
103. Silva DA, Coutinho E da SF, Ferriani LO, Viana MC. Depression subtypes and obesity in adults: A systematic review and meta-analysis. Obes Rev. 2020 Mar;21(3):e12966.  
42  
104. Miller W, Rollnik S. Talking Oneself Into Change: Motivational Interviewing, Stages of Change, and Therapeutic Process Title. J Cogn Psychother. 2004;18(4):299–308.  
105. Miller WR, Rollnick S. Ten things that motivational interviewing is not. Behav Cogn Psychother. 2009 Mar;37(2):129–40.  
106. BECK AT. THINKING AND DEPRESSION. II. THEORY AND THERAPY. Arch Gen Psychiatry. 1964 Jun;10:561–71.  
107. Wenzel A. Basic Strategies of Cognitive Behavioral Therapy. Psychiatr Clin North Am. 2017 Dec;40(4):597–609.  
108. Cooper Z, Fairburn C, Hawker D. Cognitive-behavioral treatment of obesity: A clinician’s guide. New York: Guilford Press; 2003. 232–xiii p.  
109. BRASIL. Ministério da Saúde. Política nacional de práticas integrativas e complementares no SUS: atitude de ampliação de acesso. 2a. ed. [Internet]. Brasília, DF.: Ministério da Saúde; 2015.  
110. Yang K. A review of yoga programs for four leading risk factors of chronic diseases. Evid Based Complement Alternat Med. 2007 Dec;4(4):487–91.  
111. Lauche R, Langhorst J, Lee MS, Dobos G, Cramer H. A systematic review and metaanalysis on the effects of yoga on weight-related outcomes. Prev Med (Baltim). 2016 Jun;87:213–32.  
112. Zheng G, Huang M, Liu F, Li S, Tao J, Chen L. Tai chi chuan for the primary prevention of stroke in middle-aged and elderly adults: a systematic review. Evid Based Complement Alternat Med. 2015;2015:742152.  
113. Kim S-Y, Shin I-S, Park Y-J. Effect of acupuncture and intervention types on weight loss: a systematic review and meta-analysis. Obes Rev an Off J Int Assoc Study Obes. 2018 Nov;19(11):1585–96.  
114. Huang C-F, Guo S-E, Chou F-H. Auricular acupressure for overweight and obese individuals: A systematic review and meta-analysis. Medicine (Baltimore). 2019 Jun;98(26):e16144.  
115. BRASIL. Portaria de Consolidação no 3, de 28 de setembro de 2017. Consolidação das normas sobre as redes do Sistema Único de Saúde. Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças, Anexo 1 – Diretrizes gerais para o tratamento cirúrgico da obesidade. [Internet]. 2017. Available from: http://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0003_03_10_2017.html  
116. Farpour-Lambert NJ, Ells LJ, Martinez de Tejada B, Scott C. Obesity and Weight Gain in Pregnancy and Postpartum: an Evidence Review of Lifestyle Interventions to Inform Maternal and Child Health Policies. Front Endocrinol (Lausanne). 2018;9:546.  
43  
117. Poston L, Caleyachetty R, Cnattingius S, Corvalan C, Uauy R, Herring S, et al. Preconceptional and maternal obesity: epidemiology and health consequences. lancet Diabetes Endocrinol. 2016 Dec;4(12):1025–36.  
118. BRASIL. Vigilância alimentar e nutricional - Sisvan: orientações básicas para a coleta, processamento, análise de dados e informação em serviços de saúde [Internet]. Brasília; 2004. 120 p. Available from:  
http://189.28.128.100/nutricao/docs/geral/orientacoes_basicas_sisvan.pdf  
119. ANZOS. Australian Obesity Management Algorithm [Internet]. Society ANZO. 2015. Available from: http://anzos.com/assets/Obesity-Management-Algorithm-18.10.2016.pdf 120. NICE. Weight management before, during and after pregnancy [Internet]. NICE. 2010. Available from: https://www.nice.org.uk/guidance/ph27 121. Mottola MF, Davenport MH, Ruchat S-M, Davies GA, Poitras VJ, Gray CE, et al. 2019 Canadian guideline for physical activity throughout pregnancy. Br J Sports Med [Internet]. 2018 Nov 1;52(21):1339 LP – 1346. Available from:  
http://bjsm.bmj.com/content/52/21/1339.abstract  
122. Sekula M, Boniecka I, Pasnik K. Bulimia nervosa in obese patients qualified for bariatric surgery - clinical picture, background and treatment. Wideochirurgia i inne Tech maloinwazyjne = Videosurgery other miniinvasive Tech. 2019 Sep;14(3):408–14. 123. Burrows T, Skinner J, McKenna R, Rollo M. Food Addiction, Binge Eating Disorder, and Obesity: Is There a Relationship? Behav Sci (Basel, Switzerland). 2017 Aug;7(3). 124. Brownley KA, Berkman ND, Peat CM, Lohr KN, Cullen KE, Bann CM, et al. Binge-Eating Disorder in Adults: A Systematic Review and Meta-analysis. Ann Intern Med [Internet]. 2016/06/28. 2016 Sep 20;165(6):409–20. Available from:  
https://pubmed.ncbi.nlm.nih.gov/27367316  
125. de Zwaan M. Binge eating disorder and obesity. Int J Obes Relat Metab Disord. 2001 May;25 Suppl 1:S51-5. 126. Vaidya V, Malik A. Eating disorders related to obesity. Futur Med. 2008;5(1):109–17. 127. Wadden TA, West DS, Delahanty L, Jakicic J, Rejeski J, Williamson D, et al. The Look AHEAD study: a description of the lifestyle intervention and the evidence supporting it. Obesity (Silver Spring). 2006 May;14(5):737–52.  
128. Kahan SI. Practical Strategies for Engaging Individuals With Obesity in Primary Care. Mayo Clin Proc. 2018 Mar;93(3):351–9.  
129. Erlandson M, Ivey LC, Seikel K. Update on Office-Based Strategies for the Management of Obesity. Am Fam Physician. 2016 Sep;94(5):361–8.  
44  
130. Dias PC, Henriques P, Anjos LA dos, Burlandy L. Obesidade e políticas públicas: concepções e estratégias adotadas pelo governo brasileiro. Vol. 33, Cadernos de Saúde Pública. scielo; 2017.  
131. BRASIL. Alimentação Cardioprotetora. Ministério da Saúde. 2018.  
132. BRASIL. Alimentação Cardioprotetora: Manual de orientações para profissionais de  
Saúde da Atenção Básica [Internet]. Ministério da Saúde. 2018. Available from:  
http://189.28.128.100/dab/docs/portaldab/publicacoes/alimentacao_cardioprotetora_orien_ pro_saude_ab.pdf  
45

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
A classificação do estado nutricional de adultos jovens com idade entre 18 e 20 anos incompletos é feita com auxílio das curvas de IMC para idade, em escore Z. Para o diagnóstico do estado nutricional, é necessário marcar, nas curvas, o valor de IMC (eixo y) e a idade (eixo x), cruzar os valores e fazer a interpretação do estado nutricional. A marcação no gráfico ajuda a mostrar para o indivíduo onde se encontra e como evolui a trajetória do seu estado nutricional.  
<!-- Start of picture text -->
BMI-for-age GIRLS Qe<br>"sie teyeas@scors)  SOS*~“—s*~S*~*~*~*~S~S~S Organization<br>oe usecosemessBES BBS BB Se GeesresesesessscesssessCat Soe 20d Gees Geesseassscescesne=sessse= CGSe Pon caescaae sees ~<br>» EEREESBS ARESEE EE AesEEEEEREEead EEECEE EEREEEG EEREE CREE REESEE EEE EEE> cad BBRGhee er EeReguEECaUEESECEEE EERE ECGSEEE EE ~<br>B= eee cbee Snes cone tees caea seee pecs tees tees cece teezeees caee ee<br>HEBER EEE ERE EEREEERE ESR EERE EERE EERE EEEEE CHEECH i<br>Eada GSS Gagebabu  bos sos coecaou dons #eaee=00cata e>><ees200 ues seasees pee:seas seesaes eaeaes/eedeaes feesfnaeie .<br>BRSe Gade cues sees cea eed Gecapees fraeeae sees e=es cece seca<br>on BEERBSS BB GEESESEs Cee eees=eSone SendaE ECEco ee SeesEEE Sees coed Sone CEESary? Sooo  |~<br>¢ * EEEEEEE EEE HEE ae EEHECHT|<br>© ~ BSS EM Gg Fs0a Ged bean Emel Po e~ gees Reed Gea CES GREE CEES IEE ~<br>3», BESS SSS8 Sees acevaca cece cess 2 zoe cae tase cese sees sees =e=5|<br>==Zn4 GassBsaBSSESSN eceaS08ERG582. odes200feeseeea SeendesCeespad  Geed heedSee052: SeGees>cece cad boccoeaeaeee eeeaesSeeOgeeGees SeeGeneboseee: cuse teesenedGeesee 0s Seeoe paesemeeeoeeee peiGeeseae psa:caneGees| ee :~<br>»»erBREE BEES SE => gota Cade Benscee Seq ces EES ESS*2coeposane ESSE ces mm|<br>EESEBSSSE s coes GoaeSeer ese Song Seed Snes Sess aecd Send Seng ne es Sete<br>ve pafepeBBS SESS S052cppSng cand sensepe =e popecaes sens ses! a2cse ems aee Sone ee ©<br>«; BESSHEEE BESSERED ERED 5558 00nE=22cu00n000E=2£552 [Seg S505 be2=caad Senspang gessanee2222 onan esesees saessees esacFees<br>“ GeaapGeguesed S850 G2=2eeecea GneSee=" soag sees eene esase e e e: )fees | “<br>> ESEBEER SBOn SSE F558ee 5355BEE? peunS50 0bG2 eo S2oc—ame pangSOEs Sendfond co50 SESE GeeCESEESSCCSEECaSa Gees  CSE:FES mamE<br>su, ” BSBSu@eu Sens Gees S58 Gees Sens 0Ge5 S555e5ss5s055en0ese505 5<br>Age (completed months and years) 2007 WHO Reference<br><!-- End of picture text -->  
<!-- Start of picture text -->
BMI-for-age BOYS @ weiss<br>5 to 19 years (z-scores)<br>oe cL A lage<br>ss + SEEDS Peoestosstastesteegeneftosteecteed<br>isa eoes onus 62S20==50c=s ness tzes 7<br>_ ? osirnnsensseae Snes cone SEEeanus enuaSSeS GEdd REELEDt f<br>» , " {Age (completedmonths and years) /<br>2007 WHO Retrence<br><!-- End of picture text -->  
Fonte: WHO, 2007. Acesso em https://www.who.int/growthref/who2007_bmi_for_age/en/.  
46

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
**Portarias publicadas no âmbito da Gestão Federal – Ministério da Saúde, relacionadas à Atenção Integral às pessoas com sobrepeso e obesidade no Sistema Único de Saúde** Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Capítulo II - Das diretrizes para a organização da prevenção e do tratamento do sobrepeso e obesidade no âmbito da rede de atenção à saúde das pessoas com doenças crônicas. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/Matriz-3Redes.html</u> Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Anexo 1 - Diretrizes gerais para o tratamento cirúrgico da obesidade. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/comum/37134. html</u> Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Anexo 2 . Roteiro para descrição da linha de cuidado de sobrepeso e obesidade da rede de atenção à saúde das pessoas com doenças crônicas. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/comum/37136. html</u> Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Capítulo II. Seção I. Do regulamento técnico, normas e critérios para o serviço de assistência de alta complexidade ao indivíduo com obesidade. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/Matriz-3Redes.html</u>  
Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Anexo 3. Diretrizes gerais para o tratamento cirúrgico da obesidade e acompanhamento préepós-cirurgia bariátrica. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/comum/37460. html</u> Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Anexo 4. Normas de credenciamento/habilitação para a assistência de alta complexidade ao indivíduo com obesidade. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/comum/37461. html</u> Brasil. Ministério da Saúde. Portaria de Consolidação Nº 3, Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças Crônicas, Anexo 5. Procedimentos para o tratamento cirúrgico da obesidade na tabela de procedimentos, medicamentos e OPM do SUS. Disponível em: <u>https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/MatrizesConsolidacao/comum/37463. html</u>  
47

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
###### **1.Como é feito o diagnóstico de sobrepeso ou obesidade?**  
O diagnóstico de sobrepeso ou obesidade é clínico, com base na estimativa do Índice de Massa Corporal (IMC), igual ou superior a 25 kg/m<sup>2</sup> . Para isso, é preciso ter em mãos as medidas de peso e altura do indivíduo e realizar o cálculo abaixo:  
IMC = Peso (kg)/Altura² (m).  
Exemplo de um indivíduo com 1,75m e 97 kg  
IMC = 90/(1,75)² = 97/3,0625 = 31,67kg/m²  
###### **2. Como é realizada a classificação do estado nutricional segundo o IMC?**  
Classificação do estado nutricional de adultos e risco de comorbidades, segundo IMC.  
|**Classificação**|**IMC**|**Risco de comorbidades**|
|---|---|---|
|Abaixo do peso|<18,50|Baixo|
|Eutrófico|18,50 – 24,99|Médio|
|Sobrepeso|25,00 – 29,99|Aumentado|
|Obesidade grau I|30,00 – 34,99|Moderado|
|Obesidade grau II|35,00 – 39,99|Alto|
|Obesidade grau III|≥ 40,00|Muito alto|  
Fonte: Adaptado de OMS, 2000<sup>55</sup> ; Legenda: IMC: Índice de Massa Corporal.  
###### **3. Quais os parâmetros de perímetro da cintura relacionados com o risco de**  
###### **morbimortalidade?**  
O perímetro da cintura tem correlação com a distribuição da gordura corporal e gordura intra-  
abdominal e, consequentemente, ao maior risco cardiometabólico<sup>55</sup> .  
Parâmetros para diagnóstico nutricional, segundo perímetro da cintura.  
|**Perímetro da Cintura**||
|---|---|
|≥ 88,0 cm|Para Mulheres|
|≥102,0 cm|Para Homens|  
Fonte: OMS, 2008<sup>137</sup> .  
###### **4. Como fazer o acompanhamento/monitoramento do peso?**  
48  
Para todos os indivíduos, peso e altura devem ser medidos e o IMC calculado. Para indivíduos com peso estável, um intervalo de 1 ano é adequado para a reavaliação do IMC. Para indivíduos com sobrepeso ou obesidade, recomenda-se que os usuários verifiquem seu peso uma vez por semana, caso tenham uma balança disponível. Variações com ganho de peso ao longo dos anos é um importante sinal de alerta para o agravamento da obesidade. Indivíduos com ganho de peso excessivo devem ser atendidos o mais precocemente na APS.  
###### **5. Quais exames devem ser solicitados no acompanhamento de pessoas com sobrepeso e obesidade?**  
Exames não são recomendados como prática cotidiana. Estes devem ser solicitados por profissional de saúde quando houver necessidade, isto é, suspeita de comorbidade associada à obesidade.  
###### **6. Como prevenir a obesidade?**  
Para prevenção da obesidade são recomendadas intervenções multicomponentes que combinem alimentação adequada e saudável, prática de atividade física e mudança de comportamento, incluindo automonitoramento do peso, mensagens gerais ou aconselhamento personalizado<sup>62</sup> ; e implementação intensiva e de longo prazo, incluindo sessões em grupo e monitoramento da alimentação e/ou atividade física<sup>63</sup> .  
Também devem ser realizadas medidas de incentivo, baseadas na difusão de informações e ações educativas e motivacionais; medidas de apoio, para facilitar e garantir a adesão às práticas saudáveis; e medidas de proteção, com o objetivo de reduzir a exposição do indivíduo ou do coletivo a fatores de risco e exposição a práticas não saudáveis<sup>22</sup> .  
###### **7. O que é um tratamento bem-sucedido da obesidade?**  
O cuidado de indivíduos com sobrepeso e obesidade consiste em reduzir a massa gorda e reduzir significativamente o perímetro da cintura (ou seja, massa gorda intra-abdominal) para reduzir o excesso de morbidade. O critério para perda de peso bem-sucedida é a manutenção de uma perda de peso igual ou superior a 10% do peso inicial após 1 ano.  
Embora a redução de 5 a 10% do peso inicial muitas vezes não modifique a classificação do estado nutricional (o indivíduo pode não deixar de ter obesidade), essa perda de peso pode  
49  
resultar em melhorias significativas na redução de fatores de risco para doenças crônicas, como diminuição dos níveis pressóricos, glicêmicos e de triglicérides<sup>22,71,73,74</sup> .  
###### **8. Quais as principais metas a serem alcançadas?**  
O tratamento do sobrepeso e da obesidade deve buscar os seguintes resultados:  
- diminuição da gordura corporal, preservando ao máximo a massa magra;  
- promoção da manutenção de perda de peso;  
- impedir ganho de peso futuro;  
- adoção da prática de atividade física regular;  
- adoção de hábitos alimentares saudáveis como aumento no consumo de alimentos _in_  
_natura_ e minimamente processados e redução no consumo de ultraprocessados;  
- mudança de comportamentos sedentários (muito tempo sentado ou deitado em frente à TV, videogame, com celulares ou _tablets_ );  
- mudança de hábitos alimentares inadequados (comer em frente à TV ou outras telas);  
- redução de fatores de risco cardiovasculares associados à obesidade (hipertensão arterial, dislipidemia, pré-diabete ou diabete melito);  
- melhorias de outras comorbidades associadas ao sobrepeso (apneia do sono, osteoartrite, risco neoplásico etc.);  
- indução de melhora psicossomática com recuperação da autoestima; e  
- aumento da capacidade funcional e da qualidade de vida<sup>69,70</sup> .  
###### **9. Como deve ser a alimentação para redução de peso?**  
Deve-se seguir as recomendações do Guia Alimentar da População Brasileira. Ou seja, deve-se incentivar a ingestão de alimentos _in natura_ ou minimamente processados<sup>80,81</sup> . Por conter a adição de sal, açúcar ou óleo, os alimentos processados devem ser consumidos em pequenas quantidades. Já o consumo de alimentos ultraprocessados está associado ao desenvolvimento de Doenças Crônicas Não Transmissíveis (DCNT), incluindo obesidade<sup>65</sup> , portanto esses alimentos devem ser evitados (Figura 1)<sup>80,81</sup> .  
Recomenda-se substituição das bebidas açucaradas, como refrigerantes, sucos e energéticos, por água; e a ingestão máxima de 2000 mg de sódio por dia.  
Planos alimentares individualizados devem prever redução entre 500 kcal a 1.000 kcal/dia em relação ao gasto energético estimado.  
50  
###### **10. Quais as orientações para atividade física?**  
Recomenda-se que o indivíduo acumule ao menos 150 minutos de atividade física de intensidade moderada por semana, em uma combinação de exercícios aeróbicos e de resistência. Esta combinação de modalidades apresenta vantagem na diminuição da gordura e perfil lipídico<sup>104</sup> .  
###### **11. Quais as estratégias de suporte psicológico recomendadas?**  
Recomenda-se o suporte psicológico baseado na entrevista motivacional e na terapia cognitivocomportamental, com o objetivo promover apoio e o empoderamento da pessoa ao autocuidado, visando à redução do peso por meio da implementação de modificações de longo prazo no comportamento do indivíduo, que colaborem para a adesão ao tratamento e prevenção de reganho de peso<sup>55</sup> .  
###### **12. Como manter a perda de peso a longo prazo?**  
A atividade física regular, iniciada durante a fase de perda de peso e mantida durante a fase de estabilização de peso, a manutenção da alimentação adequada e saudável e suporte psicológico são as principais ferramentas para perda e manutenção de peso a longo prazo<sup>77</sup> .  
###### **13. Como avaliar e tratar o ganho de peso excessivo na gestação?**  
A avaliação do estado nutricional durante a gestação deve ser feita a cada consulta pré-natal, por meio da medida do IMC por semana gestacional. O Cartão de Saúde da Gestante é a melhor ferramenta para registro e monitoramento do ganho de peso durante a gestação e intervenção precoce, caso seja identificado ganho de peso excessivo.  
Intervenções combinadas de alimentação adequada e saudável, atividade física e mudança de comportamentos são efetivas para a redução de ganho excessivo de peso durante a gestação, independentemente de faixa de IMC. A atividade física deve ser recomendada de acordo com cada caso, com atenção à presença de contraindicações à prática de exercícios aeróbicos ou de sinais de alerta para sua interrupção.  
###### **14. Como evitar a retenção de peso pós-parto?**  
A redução de retenção de peso pós-parto pode ser obtida pela prática combinada de alimentação adequada e saudável, evitando o consumo de alimentos ultraprocessados, ricos em  
51  
açúcar, sódio e gorduras ou muito calóricos, aleitamento materno e atividade física com início de 4 a 6 semanas após o parto e prescrita de acordo com cada caso.  
###### **15. Como tratar casos de compulsão alimentar?**  
O tratamento da compulsão alimentar tem como foco o comportamento alimentar, a psicopatologia e sintomatologia associadas. Os objetivos do tratamento devem ser realistas e focados no controle do comportamento compulsivo, na interrupção de dietas restritivas e no desenvolvimento de hábitos saudáveis. Apenas posteriormente deve-se instituir medidas para redução de peso corporal<sup>129,130</sup> .  
**16. Como tratar casos de obesidade e bulimia?**  
O tratamento deve primeiramente focar mudanças no comportamento, incluindo hábitos alimentares, bem como melhoria da saúde mental, e depois a redução de peso.  
52

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para obesidade teve início com reunião presencial para delimitação do escopo do PCDT. Esta reunião foi composta por cinco membros do Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), que representa a Secretaria-Executiva da Conitec; quatro membros de áreas técnicas do Ministério da Saúde (Coordenação-Geral de Atenção Especializada e CoordenaçãoGeral de Alimentação e Nutrição, do Departamento de Atenção Especializada e Temática, da Secretaria de Atenção à Saúde do Ministério da Saúde - CGAE-CGAN/DAET/SAS/MS e Departamento de Assistência Farmacêutica do Ministério da Saúde - DAF/MS); e nove membros do grupo elaborador.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do protocolo, embasado no disposto em Portaria N° 375, de 10 de novembro de 2009<sup>1</sup> e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Desse modo, o grupo de especialistas foi orientado a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (Anvisa) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratarem de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.  
53

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
O grupo desenvolvedor deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS). Foi composto por nove membros do grupo elaborador, sendo sete especialistas (duas endocrinologistas, uma médica de família e comunidade, uma nutricionista, um cirurgião bariátrico, uma psicóloga e um educador físico), dois metodologistas e a coordenadora administrativa do Projeto PCDT no Hospital Alemão Oswaldo Cruz. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.  
**Quadro A-** Membros do grupo desenvolvedor do PCDT  
|Titular|Especialidade|
|---|---|
|Claudio Corá Mottin|Cirurgião Bariátrico – Pontifícia Universidade Católica do<br>Rio Grande do Sul(PUC-RS)|
|Juliana D’Augustin|Psicóloga – Piquet Carneiro/ Universidade do Estado do Rio<br>de Janeiro(UERJ)|
|Maria Edna de Melo|Endocrinologista – Universidade de São Paulo (USP)/<br>Sociedade Brasileira de Endocrinologia e Metabologia<br>(SBEM)|
|Phillipe Augusto Ferreira<br>Rodrigues|Profissional de Educação Física – Universidade Federal do<br>Rio de Janeiro(UFRJ)|
|Tarissa Beatrice Zanata<br>Petry|Endocrinologista – Hospital Alemão Oswaldo Cruz (HAOC)|
|Thaís Alessa Leite|Médica de Família e Comunidade – Secretaria de Estado da<br>Saúde do Distrito Federal(SES-DF)|
|Renata Bertazzi Levy|Universidade de São Paulo(USP)|
|Anna Maria Buehler|Metodologista – Unidade de Avaliação de Tecnologias em<br>Saúde – Hospital Alemão Oswaldo Cruz|
|Mariana Michel Barbosa|Metodologista – Unidade de Avaliação de Tecnologias em<br>Saúde – Hospital Alemão Oswaldo Cruz|
|Patrícia do Carmo Silva<br>Parreira|Metodologista – Unidade de Avaliação de Tecnologias em<br>Saúde – Hospital Alemão Oswaldo Cruz|
|Jessica Yumi Matuoka|Metodologista – Unidade de Avaliação de Tecnologias em<br>Saúde – Hospital Alemão Oswaldo Cruz|
|Haliton Alves de Oliveira<br>Junior|Metodologista – Coordenador da Unidade de Avaliação de<br>Tecnologias em Saúde – Hospital Alemão Oswaldo Cruz|
|Jorgiany Souza Emerick<br>Ebeidalla|Tecnologista – Departamento de Gestão e Inorporação de<br>Tecnologias e Inovação em saúde - Ministério da Saúde|
|Joslaine de Oliveira Nunes|Tecnologista – Departamento de Gestão e Inorporação de<br>Tecnologias e Inovação em saúde - Ministério da Saúde|
|Sarah Nascimento Silva|Tecnologista – Departamento de Gestão e Inorporação de<br>Tecnologias e Inovação em saúde - Ministério da Saúde|
|Ana Maria Cavalcante de<br>Lima|Técnica - Coordenação Geral de Alimentação e Nutrição-<br>CGAN/DEPROS/SAPS/MS|  
54  
|Gisele Bortolini|Coodenadora- Coordenação-Geral de Alimentação e|
|---|---|
||Nutrição- CGAN/DEPROS/SAPS/M|  
Todos os membros do grupo declararam seus conflitos de interesse, utilizando a Declaração de Conflito de Interesse para diretrizes clínico-assistenciais. Participantes que possuíssem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da elaboração e redação de questões específicas, sem impedimento de participar da discussão das demais questões, incluindo votação caso não seja obtido consenso.  
##### **<u>Colaboração externa</u>**  
Associação Brasileira para o estudo da obesidade e da Síndrome Metabólica foi convidada a participar do processo de elaboração e revisão do documento nas diversas fases de desenvolvimento.  
##### **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>**  
A versão preliminar do texto foi pautada na 78º Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas. Participaram desta reunião representantes da Secretaria de Atenção Especializada em Saúde, do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE), e do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE), ambos da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Foram realizadas contribuições ao texto do PCDT para melhoria da apresentação das informações e houve manifestação dessa subcomissão de pautar a apreciação do documento na Conitec, após a realização dos ajustes/correções apontadas.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Esta diretriz foi desenvolvida conforme processos preconizados pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO (Figura A). Durante a reunião de escopo deste PCDT, doze questões de pesquisa foram levantadas, referentes à perda de peso corporal em indivíduos  
com sobrepeso e obesidade ( **Quadro A** ):  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO _._  
55  
<!-- Start of picture text -->
População ou condição clínica<br>P<br>Intervenção, no caso de estudos experimentais<br>Fator de exposição, em caso de estudos<br>observacionais<br>I<br>Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>Controle, de acordo com tratamento/níveis de<br>C  exposição do fator/exames disponíveis no SUS<br>Desfechos: sempre que possível, definidos a<br>O priori, de acordo com sua importância<br><!-- End of picture text -->  
**Quadro A.** Questões PICO elencadas para elaboração do PCDT de Sobrepeso e Obesidade _._  
|**PICO**|**Pergunta**|**Apêndice**|
|---|---|---|
|1|Qual a eficácia e a segurança das dietas com restrição calórica entre<br>500-1000 calorias na perda de peso dos pacientes com sobrepeso e<br>obesidade?|2|
|2|Qual o efeito da restrição de caloria líquida na perda de peso corporal<br>empacientes com sobrepeso e obesidade?|3|
|3|A substituição do açúcar pelo adoçante é eficaz na redução de peso<br>empacientes com sobrepeso e obesidade?|4|
|4|O fracionamento da dieta é eficaz na perda de peso corporal peso em<br>pacientes com sobrepeso e obesidade?|5|
|5|A duração de 150 minutos semanais de exercício físico é eficaz na<br>redução de peso e no risco cardiovascular em pacientes com<br>sobrepeso e obesidade?|6|
|6|Qual a eficácia comparativa entre exercícios aeróbicos, resistidos e<br>combinados na perda de peso e no risco cardiovascular em pacientes<br>com sobrepeso e obesidade?|7|
|7|Qual o efeito da intensidade do exercício físico na perda de peso e no<br>risco cardiovascular empacientes com sobrepeso e obesidade?|8|
|8|Quais os efeitos das abordagens individual ou em grupo para a perda<br>depeso empacientes com sobrepeso e obesidade?|9|
|9|Qual o efeito do suporte psicológico na perda de peso em pacientes<br>com sobrepeso e obesidade?|10|
|10|Qual a eficácia e segurança da sibutramina na perda de peso em<br>pacientes com sobrepeso e obesidade?|11|
|11|Qual a eficácia e segurança do orlistate na perda de peso em pacientes<br>com sobrepeso e obesidade?|12|
|12|Qual o efeito da frequência do monitoramento do peso na perda de<br>peso empacientes com sobrepeso e obesidade?|13|  
56  
A equipe de metodologistas envolvida no processo ficaria responsável pela busca e avaliação de evidências, segundo metodologia GRADE. Deste modo, a busca na literatura foi realizada nas bases PubMed e Embase e validadas no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e checada por outro, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto deste Anexo.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel®. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
57  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>138</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>139</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>140</sup> . Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas **(APÊNDICE 2- 13)** as estratégias de busca, síntese e avaliação das evidências para cada uma das 12 questões PICO realizadas para o presente PCDT.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
Em cada pergunta PICO, a qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ )<sup>141</sup> . O conjunto de evidências foi avaliado para cada desfecho considerado neste protocolo, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles. Posteriormente, ainda de acordo com a Metodologia GRADE, foi construída a tabela _Evidence to Decision_ (EtD), que sumariza os principais achados do processo de avaliação da tecnologia segundo aspectos que devem ser levados em consideração no momento de tomada de decisão sobre a incorporação do produto (magnitude do problema, benefícios, danos, balanço entre danos e benefícios, certeza na evidência, aceitabilidade, viabilidade de implementação, uso de recursos, custo-efetividade, equidade, valores e preferências dos pacientes)<sup>142</sup> . Esta última etapa foi realizada em reunião de consenso em agosto de 2019 com a participação do grupo elaborador (metodologistas e especialistas) e por membros do comitê gestor (DGITIS e áreas técnicas).  
A relatoria das seções do PCDT foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática  
58  
clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
59

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
**Questão de pesquisa: “Qual a eficácia e a segurança das dietas com restrição calórica entre 500-1000 calorias na perda de peso dos pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) eram dietas de restrição calórica a partir de déficit de 500 a 1.000 kcal/dia; comparadores (C) eram exercício físico, outros tipos de dietas ou sem intervenção; e desfechos (O) alteração no peso corpóreo, no índice de massa corporal, na medida da circunferência da cintura e na porcentagem de gordura corporal desde a linha de base.  
###### **A. Estratégia de busca**  
###### **<u>Quadro B.</u>** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|((((("Caloric Restriction"[Mesh] OR caloric restriction OR Low Calorie Diet<br>OR calorie restriction OR calorie reduction OR energy deficit OR energy-<br>deficit)) AND (("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight))) AND (("Weight Loss"[Mesh] OR weight loss OR weight<br>reduction)))) AND ((randomized controlled trial[pt] OR controlled clinical<br>trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as<br>topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT<br>humans [mh])))<br>Data da busca: 02/10/2018|2.520|
|**EMBASE**|('caloric restriction'/exp OR 'caloric restriction' OR 'low calory diet'/exp OR<br>'low calory diet' OR 'low calorie diet'/exp OR 'low calorie diet' OR 'calorie<br>restriction'/exp OR 'calorie restriction' OR 'calorie reduction' OR 'energy<br>deficit'/exp OR 'energy deficit' OR 'energy-deficit') AND [embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight loss'/exp OR<br>'weight loss' OR 'weight reduction'/exp OR 'weight reduction') AND<br>[embase]/lim<br>AND<br>('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>random*:ab,ti OR placebo*:de,ab,ti OR ((double NEXT/1 blind*):ab,ti)<br>Data da busca: 02/10/2018|1.730|  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 4.250 referências (2.520 no MEDLINE e 1.730 no EMBASE). Destas, 706 foram excluídas por estarem duplicadas. Um total de três mil quinhentas e quarenta e quatro referências foram triadas por meio da leitura de título e resumos, das quais cento e cinquenta e uma tiveram seus textos completos avaliados para confirmação da elegibilidade ( **Figura 2** ).  
60  
###### **Figura B.** Fluxograma de seleção das evidências.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 4.250<br>PUBMED = 2.520<br>EMBASE= 1.730<br>Publicações excluídas segundo<br>critérios de exclusão: 3.393<br>Publicações após remoção de duplicatas:<br>3.544  Tipo de intervenção: 2.071<br>Tipo de estudo: 1.055<br>Tipo de participante: 249<br>Tipo de desfecho: 18<br>Publicações excluídas segundo<br>critérios de exclusão: 125<br>Publicações selecionadas para leitura<br>completa: 151<br>Tipo de intervenção: 107<br>Tipo de estudo: 08<br>Tipo de desfecho: 07<br>Não recuperado: 02<br>Tipo de participante: 01<br>Estudos incluídos<br>Ensaio clínico randomizado:<br>26 publicações de 20 estudos<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela 1** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela 2** . Resultados de eficácia encontramse na **Tabela 3** . A **Tabela 4** contém a sumarização das evidências, organizadas de acordo com o _layout_ da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
61  
**Tabela A.** Características dos estudos incluídos que avaliaram a eficácia de dietas com restrição calórica entre 500 e 1.000 kcal/dia em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle (s)**|
|---|---|---|---|---|---|
|**Múltiplos comp**|**aradores**|||||
|**Ard et al.,**<br>**2018**<sup>143</sup>|ECR<br>CROSSROADS|Avaliar o efeito de dietas na composição<br>corporal, risco cardiometabólico, funcionalidade<br>e qualidade de vida em idosos (>65 anos)<br>obesos|164|**Dieta + exercício**<br>Déficit de 500 kcal/dia + intervenção<br>idem grupo exercício<br>C: 47%; P: 25%; G: 28%|**Dieta sem RC + exercício**<br>Reeducação alimentar + intervenção idem grupo exercício<br>C: 47%; P: 25%; G: 28%<br>**Exercício**<br>90–150 min/ semana de atividade aeróbica de moderada a alta<br>intensidade|
|**Van Gemert**||Avaliar a eficácia de dietas com restrição|||**Exercício**|
|**et al., 2015 e**<br>**2016**<br>76,144|ECR<br>SHAPE-2|calórica em comparação ao exercício físico<br>entre mulheres pós-menopausa inativas e com<br>sobrepeso|214|**Dieta**<br>Déficit de 500 kcal/dia<br>C: 50-60%; P: 15-20%; G: 20-30%|Déficit de 250 kcal/dia proveniente de dieta e 350 kcal/dia de<br>exercício de intensidade moderada a vigorosa<br>**Sem intervenção**<br>Manter dieta isocalórica e níveis habituais de exercício|
|**Bertz et**al.,<br>**2012**<sup>145</sup>**e**||Avaliar o efeito individual e combinado da dieta<br>e exercício físico no peso e composição corporal||**Dieta**<br>Déficit de 500 kcal/dia|**Exercício**<br>45-min de caminhada rápida 4x/semana a 60–70% da frequência<br>cardíaca máxima|
|**Brekke et al**<br>**2014**<sup>146</sup>|ECR|durante a lactação em mulheres com sobrepeso<br>ou obesas antes da gravidez|68|(2092 kJ/d)<br>C: 50-60%; P: 10-20%; G: <30%|**Dieta + exercício**<br>Idem intervenções grupo exercício + grupo dieta<br>**Sem intervenção**|
|**Nordby et**||Avaliar o efeito do exercício de resistência<br>combinado ou não a dieta na perda de peso e||**Dieta**|**Exercício**<br>Sessões 3-4x/semana de exercício de resistência em moderada<br>intensidade (~65% da frequência cardíaca de reserva) e com|
|**al., 2012**<sup>147</sup>|ECR|melhora de desfechos metabólicos em homens<br>com sobrepeso ou obesos|48|Déficit de 600 kcal/dia|treinamento intervalado de alta intensidade.<br>**Dieta hipercalórica + exercício**<br>Idem intervenção do grupo exercício + dieta hipercalórica<br>**Sem intervenção**|
|**Villareal et**|||||**Exercício**<br>Sessões de 90-min 3x/semana contendo exercício aeróbico (65–85%|
|**al., 2011**<sup>148</sup>**e**||Avaliar o efeito individual e combinado da dieta||**Dieta**|<br>da frequência cardíaca máxima) e de resistência (1-2 sessões a 65%|
|**Bounchouvill**<br>**e et al., 2014**<br>149|ECR|e exercício físico no peso e composição corporal<br>de idosos (>65 anos) obesos|107|Déficit de 500 a 750 kcal/dia<br>~1g P/kg/d|da repetição máxima)<br>**Dieta + exercício**<br>Idem intervenções grupo exercício + grupo dieta<br>**Sem intervenção**|  
61  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle (s)**|
|---|---|---|---|---|---|
|**Ross et al.,**<br>**2004**<sup>150</sup>|ECR|Avaliar o efeito independente da perda de peso<br>induzida por dieta ou atividade física na perda<br>de peso e resistência à insulina em mulheres<br>obesas.|54|**Dieta**<br>Déficit de 500 kcal/dia<br>C: 55-60%; P: 15-20%; G: 20-25%;|**Exercício físico para perda de peso**<br>Exercício físico diário de moderada intensidade (inferior a 80% da<br>frequência cardíaca máxima) com gasto calórico de 500 kcal/dia<br>**Exercício físico**<br>**Sem intervenção**|
|**Ross et al**.,<br>**2000**<sup>151</sup>e<br>**Thong et**<br>**al.,2000**<sup>152</sup>|ECR|Avaliar o efeito independente da perda de peso<br>induzida por dieta ou atividade física na perda<br>de peso e resistência à insulina em homens<br>obesos.|52|**Dieta**<br>Déficit de 700 kcal/dia<br>C: 55-60%; P: 15-20%; G: 20-25%;|**Exercício físico para perda de peso**<br>Exercício físico diário de moderada intensidade (inferior a 80% da<br>frequência cardíaca máxima) com gasto calórico de 700 kcal/dia<br>**Exercício físico**<br>**Sem intervenção**|
|**Dieta ou dieta +**|**exercício físico**|**_versus_sem intervenção**||||
|**Huseinovic et**<br>**al., 2016**<sup>153</sup>|ECR|Avaliar a eficácia de dieta com restrição calórica<br>em comparação ao controle sem intervenção<br>entre mulheres com sobrepeso no pós-parto|110|Déficit de 500 kcal/dia<br>C: 50-60%; P: 10-20%; G: 30%; fibra<br>12,5g/1.000 kcal<br>**Dieta**|**Sem intervenção**<br>Informativo sobre hábitos alimentares saudáveis|
|**Fernandes et**||Avaliar a eficácia de dieta com restrição calórica||**Dieta**|**Sem intervenção**|
|**al., 2015**<sup>154</sup>|ECR|em comparação ao entre pessoas obesas com<br>apneia do sono|29|Déficit de 800 kcal/dia<br>C: 50-60%;P: 15-20%;G: 25-30%;|Manter hábitos alimentares|
|**Vissers et al.,**||Avaliar o efeito da vibração do corpo inteiro<br>combinado com restrição calórica, sobre o peso,||**Dieta**<br>Déficit de 600 kcal/dia a partir de|**Dieta + exercício**<br>Idem intervenção dieta + treinamento intervalado de intensidade<br>entre 70-80% da frequência cardíaca máxima combinado com treino|
|**2010**<br>155|ECR|composição corporal e fatores de risco<br>metabólicos em adultos com sobrepeso e<br>obesidade|79|dieta personalizada calculada como<br>1.3 vezes a taxa metabólica de<br>repouso|de força. Exercício realizado 1 vez por semana no hospital e pacientes<br>encorajados a realizar em casa duas vezes por semana.<br>**Plataforma de vibração + dieta**<br>**Sem intervenção**|
|**Straznicky et**<br>**al., 2010**<br>156|ECR|Avaliar o efeito de dieta e dieta + exercício físico<br>na função do sistema nervoso simpático em<br>adultos com sobrepeso ou obesidade.|59|**Dieta**<br>Déficit de 600 kcal/dia<br>C: 48%; P: 22%; G: 30%|**Dieta + exercício**<br>Dieta conforme grupo intervenção + 40 min de exercício físico<br>aeróbico de moderada intensidade (65% da frequência cardíaca<br>máxima). Exercício realizado 1 vez por semana no hospital e<br>pacientes encorajados a realizar em casa outros dias<br>**Sem intervenção**|
|**Dieta ou dieta +**|**exercício físico**|**_versus_exercício físico**||||
|**Khoo et al.,**<br>**2015**<br>157|ECR|Avaliar os efeitos de perda de peso e de gordura<br>induzidas por exercício físico de moderada<br>intensidade comparado a dieta hipocalórica em<br>homens obesos|80|**Dieta**<br>Déficit de 500 kcal/dia<br>C: 50-55%; P: 20%; G: 25-30%|**Exercício**<br>200-300 min/semana de exercício físico aeróbico de moderada<br>intensidade (60-80% da frequência cardíaca máxima) combinado com<br>exercício de resistência|  
62  
63  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle (s)**|
|---|---|---|---|---|---|
|**Nicklas et al.,**<br>**2015**<sup>158</sup>|ECR|Avaliar o efeito musculoesquelético de associar<br>dieta de restrição calórica ao exercício físico em<br>adultos com sobrepeso ou obesos|126|**Dieta + exercício**<br>Déficit de 600 kcal/dia + exercício<br>físico|**Exercício**<br>Treinamento de resistência 3x/semana|
|**Yassine et**||Avaliar o efeito de exercício físico sozinho ou||**Dieta + exercício**|**Exercício**|
|**al., 2009**<br>159|ECR|associado à dieta de restrição de calorias na<br>redução do risco cardiovascular e metabólico<br>em adultos obesos|24|Déficit de 500 kcal/dia + exercício<br>físico|50 – 60 min/dia, 5 dias/semana de exercício físico de moderada a alta<br>intensidade|
|**Amati et al.,**<br>**2008**<br>160|ECR|Avaliar os efeitos separados e combinados do<br>treinamento físico e dieta na eficiência<br>metabólica em idosos (>65 anos) com<br>sobrepeso|64|**Dieta**<br>Déficit de 500-1.000 kcal/dia e<br>G<30%|**Exercício**<br>45 min de atividade aeróbica de moderada intensidade (<75% do<br>VO2máx) 3 a 5x/semana<br>**Dieta + exercício**<br>Idem intervenções grupo exercício + grupo dieta|
|**O’Leary et**<br>**al., 2007**<sup>161</sup>|ECR|Avaliar o efeito da adiponectina<br>na determinação da sensibilidade à insulina<br>devido ao exercício físico e dieta hipocalórica<br>em idosos obesos|21|**Dieta + exercício**<br>Déficit de 500 kcal/dia + exercício<br>físico|**Exercício**<br>60 min/dia, 5x/semana, de exercíxio aeróbico de alta intensidade<br>(80-85%da frequencia cardíaca máxima)|
|**Comparação en**|**tre dietas**|||||
|**Kittiskulnam**<br>**et al., 2014**<br>162|ECR|Avaliar o efeito da perda de peso na função<br>renal em indivíduos com sobrepeso ou<br>obesidade com proteinuria|26|**Dieta**<br>Déficit 500 kcal/dia<br>C: 55-60%; P: 10-20%; G: 25-30%<br>Proteína (0,6-0,8 g/kg/dia), restrição<br>de sódio(<2g/dia)|**Dieta convencional**<br>Baixo teor de proteína (0,6-0,8 g/kg/dia)<br>e restrição de sódio (<2 g/dia)|
|**Westman et**<br>**al., 2008**<br>163|ECR|Comparar os efeitos de um programa de dieta<br>cetogênica com baixo teor de carboidratos e<br>dieta hipocalórica entre pacientes com<br>sobrepeso e diabetes mellitus tipo II|84|**Dieta**<br>Déficit 500 kcal/dia e C:55%|**Dieta com restrição de carboidratos**<br>C < 20 g/d|
|**Samaha et**||||**Dieta pobre em gordura**|**Dieta com restrição de carboidratos**|
|**al., 2003**<sup>164</sup><br>**Stern et al.,**<br>**2004**<sup>165</sup>|ECR|Avaliar o efeito da dieta com restrição de<br>carboidratos comparado à dieta de restrição<br>calórica e baixo teor de gordura em adultos|6 meses<br>132|Déficit de 500 kcal/dia e G <30%<br>Composição média basal:<br>C: 51%;P: 16%;G:33%|C < 30 g/d<br>Composição média basal:<br>C: 51%;P: 17%;G:32%|
|**Carballo et**<br>**al., 2006**<sup>166</sup>||com sobrepeso e obesidade|36 meses<br>53|Composição média aos 36 meses:<br>C: 47%; P: 20%; G:32%|64<br>Composição média aos 36 meses:<br>C: 39%; P: 19%; G:42%|  
65  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle (s)**|
|---|---|---|---|---|---|
|**Yancy et al.,**<br>**2004**<br>167|ECR|Comparar os efeitos de um programa de dieta<br>cetogênica com baixo teor de carboidratos e<br>dieta hipocalórica e com baixo teor de gordura<br>e baixo colesterol entre pacientes com<br>sobrepeso|120|**Dieta pobre em gordura**<br>Déficit entre 500 e 1.000 kcal/dia e<br>G <30%, GS <10%, Colesterol < 300<br>mg|**Dieta com restrição de carboidratos**<br>C < 20 g/d|  
C: carboidrato, G: Gordura, GS: Gordura saturada, P: Proteína, ECR: ensaio clínico randomizado  
66  
**Tabela B.** Características basais de estudos que avaliaram a eficácia de dietas com restrição calórica entre 500 e 1.000 kcal/dia em indivíduos portadores de sobrepeso ou obesidade  
|**Autores**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção vs.**<br>**Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (%), média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|**Tempo de**<br>**acompanhament**<br>**o**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Múltiplos co**|**mparadores**|||||||||||
|**Ard et al.,**<br>**2018**<sup>143</sup>|Exercício +<br>dieta|Exercício|55|54|70,3 (4,8) vs.<br>69,9 (4,5)|41,8 vs. 31,5||94,1 (2,1) vs. 95,2 (1,7)||||
|CROSSROA|Exercício +|Dieta sem RC +|||70,3 (4,8) vs.||NR||NR|52 semanas|52 semanas|
|DS|dieta|exercício|55|55|70,5(4,8)|41,8 vs. 40,0||94,1 (2,1) vs. 95,1 (1,9)||||
|**Van**<br>**Gemert et**|Dieta|Sem<br>intervenção|97|48|60,5 (4,6) vs.<br>60,0 (4,9)||29,3 (2,5) vs.<br>29,5 (2,6)|80,0 (8,6) vs.<br>80,9 (10,0)||||
|**al., 2015 e**<br>**2016**<br>76,144|Exercício +<br>dieta leve|Sem<br>intervenção|98|48|59,5 (4,9) vs.<br>60,0 (4,9)|Apenas mulheres|29,0 (2,9) vs.<br>29,5 (2,6)|80,4 (9,0) vs.<br>80,9 (10,0)|NR|10-14 semanas|16 semanas|
||Dieta|Exercício +<br>dieta leve<br>|97|98|60,5 (4,6)<br>vs.59,5(4,9)||29,3 (2,5) vs.<br>29,0(2,9)|80,0 (8,6) vs.<br>80,4(9,0)||||
|**Bertz et**|Dieta|Sem<br>intervenção|15|15|33,7 (4,2) vs.<br>32,2 (4,62)||30,0 (2,6) vs.<br>30,2 (3,4)|85,4 (10,0) vs.<br>85,5 (10,3)|94 (7) vs. 98 (10)|||
|**al.,**<br>**2012**<sup>145</sup>e**Br**<br>**ekke et al**|Exercício +<br>dieta|Sem<br>intervenção|16|15|33,9 (4,5)<br>vs. 32,2(4,62)|Apenas mulheres|29,9 (2,2) vs.<br>30,2(3,4)|83,8 (7,3) vs.<br>85,5(10,3)|95 (7) vs. 98 (10)|12 semanas|12 meses|
|**2014**<sup>146</sup>|Exercício +<br>dieta|Exercício|16|16|33,9 (4,5) vs.<br>33,2(3,7)||29,9 (2,2) vs.<br>30,4(3,1)|83,8 (7,3) vs.<br>88,3(11,7)|95 (7) vs. 98 (10)|||
|**Nordby et**<br>**al.,**|Dieta|Sem<br>intervenção|12|12|32 (2) vs. 31 (2)|Apenas homens|28,0 ± 0,4 vs. 28,0 ±<br>0,4|91,2 (1,8) vs. 92,2 (2,7)|101 (1) vs. 98 (1)|12 semanas|12 semanas|
|**2012**<sup>147</sup>|Dieta|Exercício|12|12|32 (2) vs. 28 (1)||28,0 ± 0,4 vs. 28,3 ±<br>0,3|91,2 (1,8) vs. 94,5 (2,3)|101 (1) vs. 98 (1)|||  
67  
|**Villareal**<br>**et al.,**|Dieta|Sem<br>intervenção|26|27|70 (4) vs.<br>69 (4)|35 vs. 33|37,2 (4,5) vs.<br>37,3 (4,7)|104,1 (15,3) vs.<br>101,0 (16,3)|118,2 (11,5) vs.<br>117,5 (12,8)|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**2011**<sup>148</sup>**e**<br>**Bounchou**|Exercício +<br>dieta|Sem<br>intervenção|28|27|70 (4) vs.<br>69(4)|43 vs. 33|37,2 (5,4) vs.<br>37,3(4,7)|99,1 (16,8) vs.<br>101,0(16,3)|116,0 (14,8) vs.<br>117,5(12,8)|12 meses|12 meses|
|**ville et al.,**<br>**2014**<sup>149</sup>|Exercício +<br>dieta|Exercício|28|26|70 (4) vs.|43 vs. 38|37,2 (5,4) vs.<br>36,9(5,4)|99,1 (16,8) vs.<br>99,2(17,4)|114,9 (12,7)<br>116,0 (14,8) vs.|||
||Dieta|Sem|15|10|43,9 (4,9) vs.||31,9 (2,8) vs.|86,6 (10,9) vs.|97,8 (8,0) vs.|||
|**Ross et**<br>**l**||intervenção|||43,7(6,4)|lh|32,4(2,8)|88,1(8,2)|98,1(6,9)|||
|**a., 2004**<br>150|Dit|<sup>Exercício para</sup>|15|17|43,9 (4,9) vs.|Apenas mueres|31,9 (2,8) vs. 32,8|86,6 (10,9) vs.|97,8 (8,0) vs.|14 semanas|14 semanas|
||ea|<br>perda de peso|||43,2 (5,1)||(3,8)|86,8 (10,9)|100,5 (8,2)|||  
68  
|**Autores**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção vs.**<br>**Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (%), média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|<br>**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|**Tempo de**<br>**acompanhament**<br>**o**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Ross et al**.,<br>**2000**<sup>151</sup>e<br>|Dieta|~~Sem~~<br>intervenção|14|8|42,6 (2,6) vs.<br>46,0(3,8)||30,7 (0,5) vs.<br>30,7(0,6)|96,1 (2,4) vs. 96,7 (3,2)|~~109,1 (1,5) vs.~~<br>108,7(1,7)|||
|**Thong et**||||||Apenas homens||||12 semanas|12 semanas|
|**al.,2000**<br>152|Dieta|Exercício para<br>perda de peso|14|16|42,6 (2,6) vs.<br>45,0 (1,9)||30,7 (0,5) vs.<br>32,3 (0,5)|96,1 (2,4) vs.<br>101,5 (2,0)|109,1 (1,5) vs.<br>112,0 (1,2)|||
|**Dieta ou diet**|**a + exercício fís**|**ico****_versus_sem in**|**tervenção**|||||||||
|**Huseinovi**<br>**c et al.,**<br>**2016**<sup>153</sup>|Dieta|Sem<br>intervenção|54|56|31,8 (4,5) vs.<br>32,6 (4,7)|Apenas mulheres|31,8 (4,0) vs.<br>31,6 (3,4)|90,0 (13,7) vs.<br>86,6 (11,5)|98,8 (11,4) vs.<br>96,8 (11,2)|12 semanas|12 meses|
|**Fernandes**<br>**et al.,**<br>**2015**<sup>154</sup>*****|Dieta|Sem<br>intervenção|11|10|39·09 (3·26) vs.<br>44·10 (1·95)|64 vs. 40|34·60 (0,8) vs. 35·92<br>vs. 0·91|100·08 (4,10) vs. 99·73<br>(4,49)|105·50 (2·78) vs. 109·83<br>(2·96)|16 semanas|16 semanas|
|**Vissers et**<br>**al., 2010**|Dieta|Sem<br>intervenção|21|20|45,5 (13,1) vs.<br>44,8(11,4)|NR|32,9 (3,1) vs.<br>30,8(3,4)|92,1 (11,1) vs.<br>88,6(15,9)|102,3 (7,9) vs.<br>99,7(11,1)|6 meses|12 meses|
|155|Exercício +<br>dieta|Sem<br>intervenção|20|20|44,7 (13,0) vs.<br>44,8 (11,4)|NR|33,1 (3,4) vs.<br>30,8 (3,4)|94,5 (11,7) vs.<br>88,6 (15,9)|103,5 (9,4) vs.<br>99,7 (11,1)|||
|**Straznicky**<br>**et al.,**|Dieta|Sem<br>~~intervenção~~|20|19|55 (1) vs.<br>~~55 (1)~~|60 vs. 57|32,2 (0,9) vs.<br>~~33,0 (0,8)~~|94,3 (2,3) vs.<br>~~97,6 (3,6)~~|106,5 (1,9) vs.<br>~~109,4 (2,5)~~|||
|<br>**2010**<br>156|Exercício +<br>dieta|Sem<br>intervenção|20|19|54 (1) vs.<br>55 (1)|60 vs. 57|31,8 (0,8) vs.<br>33,0 (0,8)|92,9 (2,9) vs.<br>97,6 (3,6)|105,1 (2,2) vs.<br>109,4 (2,5)|12 semanas|12 semanas|
|**Khoo et**<br>**al., 2015**<br>157|Dieta|Exercício|40|40|41,8 ± 7,2 vs.<br>43,3 ± 9,0|Apenas homens|32,1 (3,0) vs.<br>32,1 (2,6)|95,7 (9,4) vs.<br>96,2 (10,9)|106,1 (7,2) vs.<br>106,0 (8,5)|24 semanas|24 semanas|
|**Nicklas et**|Exercício +||||69,6 (3,9) vs.||30,4 (2,2) vs.|85,4 (11,7) vs.||||
|**al., 2015**<br>158|dieta|Exercício|63|63|69,4 (3,6)|41 vs. 46|30,7 (2,4)|87,3 (13,1)|NR|5 meses|5 meses|
|**Yassine et**<br>**al., 2009**<br>159|Exercício +<br>dieta|Exercício|12|12|67 (1) vs.<br>64 (2)|NR|33,7 (4,7) vs.<br>35,3 (5,8)|94,9 (16,5) vs.<br>99,7 (15,7)|113,6 (12,7) vs.<br>118,3 (12,7)|12 semanas|12 semanas|
|**Amati et**<br>**al., 2008**<br>160|Dieta<br>Exercício +<br>dieta|Exercício<br>Exercício|11<br>17|36<br>36|68,2 (1,5) vs.<br>67,0 (0,6)<br>66,2 (0,9) vs.<br>67,0(0,6)|45 vs. 36<br>47 vs. 36|31,6 (1,0) vs.<br>29,7 (0,6)<br>32,2 (0,8) vs.<br>29,7(0,6)|NR|NR|<br>16 semanas|69<br>16 semanas|  
<!-- Start of picture text -->
O’Leary et al., 2007  Exercício +  Exercício  11  10  67,4 (1,3) vs.  NR 34,0 (1,4) vs. 34,6  97,1 (4,7) vs. 97,1 (6,1)  NR  12 semanas  12 semanas<br>161  dieta  65,0 (1,4)  (1,9)<br><!-- End of picture text -->  
70  
|**Autores**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção vs.**<br>**Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (%), média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|**Tempo de**<br>**acompanhament**<br>**o**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Comparação**|**entre dietas**|||||||||||
|**Kittiskulna**<br>**m et al.,**<br>**2014**|Dieta déficit<br>500 kcal|Dieta<br>convencional|13|13|45,5 (11,9) vs.<br>45,4 (16,2)|46 vs. 46|28,5 (4,8) vs.<br>28,7 (4,8)|76,8 (1,6) vs.<br>78,0 (1,4)|94,7 (11,1) vs.<br>97,1 (9,8)|6 meses|6 meses|
|**Westman**||||||||||||
|**et al.,**<br>**2008**<br>163|Dieta déficit<br>500 kcal|Dieta<br>C<20g/d|46|38|51,8 (7,8) vs.<br>51,8 (7,3)|19,6 vs. 23,7|38,5 (5,6) vs.<br>37,7 (6,1)|106,3 (20,1) vs.<br>105,5 (19,5)|NR|6 meses|6 meses|
|**Yancy et**|Dieta déficit|Dieta|||45,6 (9,0) vs.||34,0 (5,2) vs.|96,8 (19,2) vs.||||
|**al., 2004**<br>167|500-1,000 kcal<br>e G<30%|C<20g/d|60|59|44,2 (10,1)|22 vs. 25|34,6 (4,9)|97,8 (15,0)|NR|6 meses|6 meses|
|**Samaha et**<br>**al., 2003**<br>164|||68|64|54 (9) vs.<br>53 (9)|85 vs. 80|42,9 (7,7) vs.<br>42,9 (6,6)|131,8±27,3 vs.<br>130,0±22,7||6 meses|6 meses|
|**Stern et**<br>**al., 2004**<br>165|Dieta déficit<br>500 kcal e<br>G<30%|Dieta<br>C<30g/d|43|44|NR|NR|NR|NR|NR|6 meses|12 meses|
|**Carballo**|||||55 (10) vs.||43,2 (7,2) vs.|||||
|**et al.,**<br>**2006**<sup>166</sup>|||26|27|54 (10)|88 vs. 78|43,4 (6,7)|NR||6 meses|36 meses|  
NR: não reportado, N: número da amostra, DP; desvio padrão; AT: amplitude total;  
*apresenta resultados apenas para os que completaram o estudo  
71  
**Tabela C.** Desfechos de eficácia de estudos queavaliaram a eficácia de dietas com restrição calórica entre 500 e 1.000 kcal/dia em indivíduos portadores de sobrepeso ou obesidade, segundo o tipo de comparação.  
|**Autor, ano**|**Intervenção**|**Controle**|**(Kg)**<br>**Alteração do peso corporal**<br>**(DP ou IC95%)**|**de p**<br>**Valor**|**(Kg/m**<sup>**2**</sup>**)**<br>**Alteração no IMC**<br>**(DP ou IC95%)**|**de p**<br>**Valor**|**(DP ou IC95%)**<br><br>**Alteração na**<br>**circunferência da**<br>**cintura**|**Valor**<br>**de p**|**(DP ou IC95%)**<br>**%**<br>**Alteração na %**<br>**de gordura**<br>**corporal**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Múltiplos**<br>**comparadores**|||||||**(cm)**||**()**||
|**Ard et al., 2018**<br>143|exercício<br>Dieta +<br>|Exercício<br>|−3,9 (0,7) vs. -1,3 (0,7)|0,005|NR|NR|NR|NR|−1,6 (0,3) vs. -<br>0,7(0,3)|0, 023|
|CROSSROADS<br>|Dieta +<br>exercício|Dieta sem RC<br>+ exercício|−3,9 (0,7) vs. -0,9 (0,7)|0,001|NR|NR|NR|NR|−1,6 (0,3) vs. –<br>0,3(0,3)|0, 002|
|**~~Van Gemert et~~**<br>||Sem|-4,9 (-5,4;-4,4) vs.||||||-2,5(-3,0; -2,1)||
|76SHAPE-2<br>**al., 2015**|Dieta|intervenção|0,06 (-0,34; -0,46)|<0,001|NR|NR|NR|NR|vs. 0,2 (-0,2;<br>0,6)|<0,001|
|**Van Gemert et**<br>**al., 2016**<br>144<br>SHAPE-2|Exercício +<br>dieta leve|Dieta|DM: -0,63 (-1,23; -0,04)|0,037|NR|NR|NR|NR|-1,56 (-2,14;<br>-0,98)|<0,001|
|**l**|Dieta|intervenção<br>Sem|-10,2 (5,7) vs. -0,9 (6,6)|<0,001|-3,6 (2,0) vs. -0,3 (2,4)|<0,001|-3,9(5,6)<br>-10,7 (5,8) vs.|0,001|NR|NR|
|**Bertz et a.,**<br>**2012**<sup>145</sup>e**Brekke**<br>**et al 2014**<sup>146</sup>|Exercício +<br>dieta<br>|Sem<br>intervenção|-7,3 (6,3) vs. -0,9 (6,6)|NR|-2,6 (2,2) vs. -0,3 (2,4)|NR|9,5 (6,2) vs.<br>-3,9 (5,6)<br>|NR|NR|NR|
||Exercício +<br>|~~Exercício~~|-7,3 (6,3) vs. -2,7 (5,9)|NR|-2,6 (2,2) vs. -0,9 (2,0)|~~NR~~|-9,5 (6,2) vs.<br>|~~NR~~|~~NR~~|~~NR~~|
||dieta||||||-6,0 (9,9)||||
|**Nordby et al.,**|Dieta|Sem<br>intervenção|-5,3 (0,7) vs. -0,12 (0,5)|<0,05|-1,6 (NR) vs. 0,0 (NR)|<0,05|-9 vs. 0|<0,05|-3,3 (NR) vs. 0,2<br>(NR)|<0,05|
|**2012**<sup>147</sup>|Dieta|Exercício|-5,3 (0,7) vs. -5,9 (0,7)|NS|-1,6 (NR) vs. -1,8 (NR)|NS|-9 vs. -7|NS|-3,3 (NR) vs.<br>-6,8(NR)|<0,05|  
72  
|**Autor, ano**|**Intervenção**|**Controle**|**Alteração do peso corporal**<br>**(DP ou IC95%)**<br>**(Kg)**|**Valor**<br>**de p**|**Alteração no IMC**<br>**(DP ou IC95%)**<br>**(Kg/m**<sup>**2**</sup>**)**|**Valor**<br>**de p**|**Alteração na**<br>**circunferência da**<br>**cintura**<br>**(DP ou IC95%)**<br>**(cm)**|**Valor**<br>**de p**|**Alteração na %**<br>**de gordura**<br>**corporal**<br>**(DP ou IC95%)**<br>**(%)**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Villareal et al.,**|Dieta|~~Sem~~<br>intervenção|–9,7 (5,4) vs. –0,1 (3,5)|<0,001|NR|NR|~~- 8,4 (8,6) vs. 1,0~~<br>(6,1)|0,02|NR|NR|
|**2011**<sup>148</sup>**e**<br>**Bounchouville et**|Exercício +<br>dieta|Sem<br>intervenção|–8,6 (3,8)  vs. –0,1 (3,5)|NR|NR|NR|-8,2 (10,3) vs. 1,0<br>(6,1)<br>|NR|NR|NR|
|**al., 2014**<sup>149</sup>|Exercício +||||||−8,2 (10,3) vs.||||
||dieta|Exercício|–8,6 (3,8)  vs. −0,5 (3,6)|NR|NR|NR|−4,0 (9,1)|0,13|NR|NR|
|**Ross et al., 2004**|Dieta|Sem<br>intervenção<br>|- 5,2 (1,2) vs. 0,5 (NR)|< 0,01|-1,7 (NR) vs. 0,3 (NR)|< 0,01|-4,1(2,4) vs. 1,1<br>(NR)<br>|< 0,01|NR|NR|
|150||Exercício para|||||-4,1(2,4) vs.||||
||Dieta|perda de peso|- 5,2 (1,2) vs. -6,1(1,2)|NS|-1,7 (NR) vs. -2,4 (NR)|NS|-6,5 (2,6)|NS|NR|NR|
|**Ross et al**.,<br>**2000**<sup>151</sup>e**Thong**|Dieta|Sem<br>intervenção|-7,4 (0,2) vs. 0,1 (0,3)|<0,05|-2,4 (0,1) vs. -0,03 (0,1)|<0,05|NR|NR|NR|NR|
|**et al.,2000**<sup>152</sup>|Dieta|Exercício para<br>|-7,4 (0,2) vs. -7,6 (0,1)|NS|-2,4 (0,1) vs. -2,4 (0,1)|NS|Exercício – dieta<br>05 [212; 22]|NS|NR|NR|
|**Dieta ou dieta + ex**|**ercício físico****_ve_**|perda depeso<br> <br>**_rsus_sem intervenç**|**ão**||||, , ,<br>||||
|**Huseinovic et**<br>**al., 2016**<sup>153</sup>|Dieta|Sem<br>intervenção|-9,3 (4,8) vs. -5,6 (7,3)|0,004|-3,3 (1,7) vs. -2,0 (2,6)|0,005|-9,9 (5,2) vs. -7,4<br>(5,9)|0,028|-5,7 (3,4) vs.<br>-3,5(4,1)|0,008|
|**Fernandes et al.,**<br>**2015**<sup>154</sup>|Dieta|Sem<br>intervenção<br>|−5,57 (1,81) vs. 0,43 (1,21)|<0·001|−1,87 (0,59) vs. 0,10<br>(0,45)|<0,001|−4,85 (1,57) vs.<br>1,58(0,96)|<0,001|−2,23 (0,82) vs.<br>0,77(0,36)|0·004|
|**Vissers et al.,**<br>|Dieta|Sem<br>intervenção|–4,3 (4,8) vs. 1,3 (3,7)|NR|–1,5 (1,7) vs. 0,4 (1,4)|NR|–3,5 (3,8) vs. 0,5<br>(4,0)|NR|–2,7 (1,9) vs.<br>–0,9(2,7)|NR|
|**2010**<br>155|Exercício +<br>dieta|Sem<br>intervenção<br>|–6,6 (6,4) vs. 1,3 (3,7)|NR|–2,3 (2,1) vs. 0,4 (1,4)|NR|–6,9 (7,4) vs. 0,5<br>(4,0)<br>|NR|–4,0 (4,1) vs.<br>–0,9(2,7)|NR|
|**Straznicky et al.,**<br>|Dieta|Sem<br>intervenção|-7,1 (0,6) vs. 1,0 (0,3)|< 0,01|-2,4 (0,2) vs. +0,4 (0,1)|<0,01|-6,7 (0,7) vs.<br>-0,1(0,5)|<0,01|NR|NR|
|**2010**<br>156|Exercício +<br>dieta|Sem<br>intervenção|-8,4 (1,0) vs. 1,0 (0,3)|< 0,01|-2,8 (0,3) vs. 0,4 (0,1)|<0,01|-9,8 (1,2) vs.<br>-0,1(0,5)|<0,01|NR|NR|
|**Dieta ou dieta + ex**|**ercício físico****_ve_**|**_rsus_exercício**|||||||||
|**Khoo et al., 2015**|Dieta|Exercício|–3,3 (4,6) vs. –3,6 (3,4)|0,83|–1,2 (1,9) vs. –1,3 (1,2)|0,86|–3,4 (4,4) vs.<br>–3,6(3,2)|0,81|–2,1 (4,4) vs.<br>–3,7(3,4)|73<br>0,04|
|**Nicklas et al.,**<br>**2015**<sup>158</sup>|Exercício +<br>dieta|Exercício|-4,9 (3,9) vs. -0,1 (2,2)|<0,001|NR|NR|NR|NR|-2,2 (1,9) vs.<br>-0,6(1,2)|<0,001|
|**Yassine et al.,**<br>**2009**|Exercício +<br>dieta|Exercício|-6,9 (NR) vs. -3,8 (NR)|0,02|-2,4 (NR) vs. -1,3 (NR)|0,01|-6,5 (NR) vs. -5,6<br>(NR)|0,62|NR|NR|  
157  
74  
|159<br>**Autor, ano**|**Intervenção**|**Controle**|**Alteração do peso corporal**<br>**(DP ou IC95%)**<br>**(Kg)**|**Valor**<br>**de p**|**Alteração no IMC**<br>**(DP ou IC95%)**<br>**(Kg/m**<sup>**2**</sup>**)**|**Valor**<br>**de p**|**Alteração na**<br>**circunferência da**<br>**cintura**<br>**(DP ou IC95%)**<br>**(cm)**|**Valor**<br>**de p**|**Alteração na %**<br>**de gordura**<br>**corporal**<br>**(DP ou IC95%)**<br>**(%)**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Amati et al.,**|Dieta|Exercício|NR|NR|−9,3(1,4)vs. −1,3(0,4)|<0,05|NR|NR|NR|NR|
|**2008**<br>160|Dieta +<br>exercício|Exercício|NR|NR|−8,6 (0,8) vs. −1,3 (0,4)|<0,05|NR|NR|NR|NR|
|**O’Leary et al.,**<br>**2007**<sup>161</sup>|Exercício +<br>dieta|Exercício|-7,8 (NR) vs. -3,3 (NR)<br>8,1% vs. 3,4%|<0,001|NR|NR|NR|NR|NR|NR|
|**Comparação entre**|**dietas**||||||||||
|**Kittiskulnam et**<br>**al., 2014**<br>162|Dieta déficit<br>500 kcal|Dieta<br>convencional|-3,9 (2,7) vs. -0,2 (NR)|NS|-1,5 (0,9) vs. -0,2 (NR)|NS|-3,1 (3,2) vs. -0,9<br>(NR)|NS|-3,1 (NR) vs.<br>-0,6 (NR)|NS|
|**Westman et al.,**<br>**2008**<br>163|Dieta déficit<br>500 kcal|Dieta<br>C<20g/d|**Dados observados**<br>-6,9 vs. -11,1|0,01|**Dados observados**<br>-2,7 vs. -3,9|0,10|NR|NR|NR|NR|
|**Yancy et al.,**|Dieta déficit|Dieta|-6,5 (-8,4; -4,6) vs.||||||-2,8 (-3,9;-1,9)||
|**2004**<br>167|500-1,000 kcal<br>e G<30%|C<20g/d|-12,0 (-13,8; -10,2)|0,001|NR|NR|NR|NR|vs.<br>-5,8(- 6,7;-4,8)|NS|
||||**Dados observados**||||||||
|**Samaha et al.,**<br>**2003**<sup>164</sup><br>**Stern et al., 2004**<br>165|Dieta déficit<br>500 kcal e|Dieta<br>C<30g/d|–1,9 (4,2) vs. –5,8 (8,6)<br>**ITT**<br>–1,8(3,9)vs. –5,7(8,6)|0,002<br>0,002|NR|NR|NR|NR|NR|NR|
|**Carballo et al.,**|G<30%||-3,1 (8,4) vs.-5,1 (8,7)|NS|||||||
|<br>**2006**<sup>166</sup>|||**Dados observados**<br>-4,24 (12,1) vs. -4,04 (12,7)|NS|NR|NR|NR|NR|NR|NR|  
ECR: ensaio clínico randomizado; IC 95%: intervalo de confiança; NR: não reportado; NS: Não significativo; IMC: Índice de Massa Corporal  
75  
A descrição da qualidade metodológica e justificativa encontra-se abaixo no **Quadro C** . Embora as medidas de desfecho avaliadas sejam objetivas, considerou-se como alto risco de viés estudos que não cegaram os avaliadores dos desfechos.  
**Quadro C.** Avaliação da qualidade metodológica dos estudos incluídos.  
|**Estudo**|**Risco de viés**|**Justificativa**|
|---|---|---|
|**Amati et al., 2008**<sup>160</sup>|Alto|Incluiu participantes não randomizados em um dos grupos;<br>cegamento dos desfechos incerto|
|**Ard et al., 2018**<sup>143</sup>|Baixo|-|
|**Bertz et al., 2012**<sup>145</sup>e**Brekke et al 2014**<br>146|Incerto|Cegamento dos desfechos incerto|
|**Fernandes et al., 2015**<sup>154</sup>|Incerto|Randomização, sigilo da alocação e cegamento dos desfechos<br>incerto|
|**Huseinovic et al., 2016**<sup>153</sup>|Alto|Estudo abertopara cegamento dos desfechos|
|**Kittiskulnam et al., 2014**<sup>162</sup>|Alto|Randomização e sigilo da alocação incertos; estudo aberto para<br>cegamento dos desfechos|
|**Khoo et al., 2015**<sup>157</sup>|Baixo|-|
|**Nicklas et al., 2015**<sup>158</sup>|Baixo|-|
|**Nordby et al., 2012**<sup>147</sup>|Alto|Randomização e sigilo da alocação incertos; estudo aberto para<br>cegamento dos desfechos; perda diferencial entre grupos e não<br>intenção de tratar|
|**O’Leary et al., 2007**<sup>161</sup>|Incerto|Randomização, sigilo da alocação e cegamento dos desfechos<br>incertos|
|**Ross et al., 2004**<sup>150</sup>|Alto|Cegamento dos desfechos incertos Perda diferencial entre grupos<br>e não usa intenção de tratar|
|**Ross et al**.,**2000**<sup>151</sup>e**Thong et al.,2000**<br>152|Alto|Cegamento dos desfechos incertos Perda diferencial entre grupos<br>e não usa intenção de tratar|
|**Samaha et al., 2003**<sup>164</sup><br>**Stern et al., 2004**<sup>165</sup><br>**Carballo et al., 2006**<sup>166</sup>|Alto|Estudo aberto para cegamento dos desfechos|
|**Straznicky et al., 2010**<sup>156</sup>|Incerto|Randomização, sigilo da alocação e cegamento dos desfechos<br>incerto|
|**Van Gemert et al., 2015**<sup>76144</sup>|Baixo|-|
|**Villareal et al., 2011**<sup>148</sup>e<br>**Bounchouville et al., 2014**<sup>149</sup>|Incerto|Randomização e sigilo da alocação incertos|
|**Vissers et al., 2010**<sup>155</sup>|Alto|Randomização, sigilo da alocação e cegamento dos desfechos<br>incertos; não usa intenção de tratar e não informa perda de<br>seguimentoporgrupo|
|**Yancy et al., 2004**<sup>167</sup>|Incerto|Cegamento dos desfechos incerto|
|**Yassine et al., 2009**<sup>159</sup>|Incerto|Randomização, sigilo da alocação e cegamento dos desfechos<br>incertos|
|**Westman et al., 2008**<sup>163</sup>|Incerto|Cegamento dos desfechos incerto|  
No **Quadro D** , constam os domínios avaliados para embasar as recomendações deste PCDT.  
76  
###### **Quadro D.** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ (EtD) do _webapp_ GRADE Pro).  
|PERGUNTA||
|---|---|
|**Deve-se usar dietas**<br>**sobrepeso ou obes**|**com restrição calórica entre 500 e 1.000 Kcal por dia vs. sem intervenção para perda de peso dos indivíduos com**<br>**idade?**|
|**POPULAÇÃO:**|perda de peso dos indivíduos com sobrepeso ou obesidade|
|**INTERVENÇÃO:**|dietas com restrição calórica entre 500 e 1.000 Kcal por dia|
|**COMPARAÇÃO:**|sem intervenção|
|**DESFECHOS PRINCIPAIS:**|Alteração no peso corpóreo; Alteração no IMC (Índice de Massa Corporal); Alteração na circunferência da cintura ; Alteração na porcentagem de gordura corporal;|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
|Problema|||
|---|---|---|
|O problema é uma prioridade?|||
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não|· A obesidade é u|m problema de saúde pública mundial;|
|○ Provavelmente não<br>○ Provavelmente sim|· A prevalência de|obesidade no Brasil varia entre 9 a 23%, a depender da faixa etária;|
|● Sim|||
|○ Varia|||
|○ Incerto|||  
77  
#### Efeitos Desejáveis  
Quão substanciais são os efeitos desejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Trivial|Apesar da baixa q|ualidade metodológica e variabilidade dos estudos, os resultados se mostraram consistentes entre os estudos. Foi possível verificar que a dieta de restrição|
|○Pequeno<br>● Moderado<br>○ Grande<br>○ Varia<br>○ Incerto|calórica entre 50<br>seus hábitos alim|0 e 1.000 kcal/dia sozinha ou associada à atividade física é eficaz para a redução do peso, avaliados em comparação a controles que foram orientados a manter<br>entares, que receberam informações sobre alimentação saudável ou que mantiveram uma dieta habitual.|
||Dados de desfech|os negativos não foram relatados.|
|Efeitos Indese<br>Quão substanciais são|jáveis<br>os efeitos indesejáveis esp|erados?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Grande<br>○ Moderado<br>○ Pequeno<br>○ Trivial|Apesar da baixa q<br>calórica entre 50<br>seus hábitos alim|ualidade metodológica e variabilidade dos estudos, os resultados se mostraram consistentes entre os estudos. Foi possível verificar que a dieta de restrição<br>0 e 1.000 kcal/dia sozinha ou associada à atividade física é eficaz para a redução do peso, avaliados em comparação a controles que foram orientados a manter<br>entares, que receberam informações sobre alimentação saudável ou que mantiveram uma dieta habitual.|
|○ Varia|||
|● Incerto|||
||Dados de desfech|os negativos não foram relatados.|  
78  
#### Certeza da Evidência  
Qual é a certeza global na evidência?  
<!-- Start of picture text -->
JULGAMENTO  EVIDÊNCIAS DE  CONSIDERAÇÕES ADICIONAIS<br>PESQUISA<br>○ Muito baixa  A qualidade geral da evidência foi baixa para todos os desfechos.<br>● Baixa<br>○ Moderada  Certainty of the evidence<br>Desfechos  Importância<br>○ Alta  (GRADE)<br>○ Sem estudos incluídos<br>Alteração no peso corpóreo  ⨁⨁◯◯<br>BAIXA a<br>Alteração no IMC (Índice de Massa Corporal)  ⨁⨁◯◯<br>BAIXA b<br>Alteração na circunferência da cintura  ⨁⨁◯◯<br>BAIXA c<br>Alteração na porcentagem de gordura corporal  ⨁⨁◯◯<br>BAIXA d<br>a. Dos 10 ECR, apenas um tinha baixo risco de viés.<br>b. Dos 8 ECR, cinco apresentavam alto risco de viés, sendo os demais de risco incerto.<br>c. Dos 8 ECR, quatro apresentavam alto risco de viés e os outros risco incerto.<br>d. Dos 5 ECR, três apresentavam alto risco de viés, um risco incerto e um baixo.<br><!-- End of picture text -->  
79  
|Valores|||
|---|---|---|
|Existe incerteza importante ou|variabilidade dobre|o quanto as pessoas valoram os desfechos principais?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Incerteza ou variabilidade<br>importante<br>○ Possivelmente incerteza ou<br>variabilidade importante<br>● Provavelmente sem<br>incerteza ou variabilidade<br>importante<br>○ Sem incerteza ou<br>variabilidade importante|Acredita-se que o|s pacientes tenham preferência pela não intervenção do que pela dieta com restrição calórica.|
|Balanço dos efeitos<br>O balanço entre os efeitos dese|<br>jáveis e indesejáve|is favorece a intervenção ou a comparação?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Favorece a comparação<br>○ Provavelmente favorece a<br>comparação<br>○ Não favorece nem a<br>interveção nem a<br>comparação<br>● Provavelmente favorece a<br>intervenção<br>○ Favorece a intervenção<br>○ Varia|Apesar da baixa q<br>calórica entre 500<br>que foram orienta|ualidade metodológica e variabilidade dos estudos, os resultados se mostraram consistentes entre os estudos. Foi possível verificar que a dieta de restrição<br>e 1.000 kcal/dia sozinha ou associada à atividade física é eficaz para melhora de todos os desfechos de composição corporal avaliados em comparação a controles<br>dos a manter seus hábitos alimentares, que receberam informações sobre alimentação saudável ou que mantiveram uma dieta isocalórica.|  
80  
|○ Incerto<br>Aceitabilidade<br>A intervenção é aceitavel pa<br>|raos principais atores sociais (_stakeholders_)?<br> <br>|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|Acredita-se que não teriam restrições|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
||||**JU**|**LGAMENTO**|||
|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**|Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|Pequeno|**Moderado**|Grande|Varia|Incerto|  
81  
|||||**JULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|Trivial||Varia|**Incerto**|
|**CERTEZA DA EVIDÊNCIA**|Muito baixa|**Baixa**|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece nem a<br>intervenção e nem a<br>comparação|**Provavelmente**<br>**favorece a intervenção**|Favorece a intervenção|Varia|Incerto|
|**ACEITABILIDADE**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
|Recomendação forte contraa intervenção|Recomendação condicionalcontraa|Não favorece uma ou outra|**Recomendação condicional a favor da**|Recomendação forte a favor da|
|---|---|---|---|---|
||intervenção||**intervenção**|intervenção|
|○|○|○|**●**|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: Geral -->
#### Recomendações  
A evidência avaliada mostrou que a redução do total de consumo calórico entre 500 e 1000 Kcal do gasto energético estimado, promove redução do peso corporal. Recomenda-se, para a pessoa com sobrepeso ou obesidade, a redução do gasto total de calorias, com enfoque na redução do consumo de alimentos ultraprocessados, de acordo com o guia alimentar para a população brasileira.  
82

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 3 - PERGUNTA PICO 2** -->
**Questão de pesquisa: “Qual o efeito da restrição de caloria líquida na perda de peso corporal em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era restrição calorias líquidas; comparadores (C) era consumo irrestrito de calorias líquidas; e desfechos eram (O) alteração no peso corpóreo, no IMC e na medida do perímetro da cintura desde a linha de base.  
###### **A. Estratégia de busca**  
**Quadro E.** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|(((((("Overweight"[Mesh]) OR Overweight) OR "Obesity"[Mesh])<br>OR Obesity)) AND ((((((((((soft drink) OR sweetened beverage) OR<br>"Beverages"[Mesh]) OR "Carbonated Beverages"[Mesh]) OR<br>"Carbonated Beverages"[Mesh]) OR Carbonated Beverages) OR<br>Beverages) OR soda) OR diet beverage) OR low calorie beverage))<br>AND ((("Weight Loss"[Mesh]) OR Weight Loss) OR Weight<br>reduction)|543|
||Data da busca: 21/01/2019||
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'overweight'/exp OR overweight)<br>AND [embase]/lim<br>AND<br>('beverage'/exp OR 'beverage' OR 'sweetened beverage'/exp<br>OR 'sweetened beverage' OR 'carbonated beverage'/exp<br>OR 'carbonated beverage' OR 'soft drink'/exp OR 'soft<br>drink' OR 'soda'/exp OR soda OR 'low calorie beverage' OR 'diet<br>beverage') AND [embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight<br>loss'/exp OR 'weight loss' OR 'weight reduction'/exp OR 'weight<br>reduction') AND [embase]/lim<br>Data da busca: 21/01/2019|925|  
###### **B. Seleção das evidências**  
A busca das evidências retornou 1.468 referências (543 no MEDLINE e 925 no EMBASE). Cento e oitenta e quatro eram duplicatas e foram excluídas. Mil duzentos e oitenta e quatro artigos  
83  
únicos, tiveram seus títulos e resumos avaliados, dos quais 1259 foram excluídos. Após esta etapa, 25 artigos tiveram seus textos completos para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo avaliava participantes portadores de sobrepeso ou obesidade. Caloria líquida compreendeu todos os produtos que apresentam açúcar líquido em sua composição (sucos naturais, sucos artificiais, refrigerantes, entre outros). Para os controles, foram consideradas a substituição por água ou bebidas dietéticas. Foram consideradas ainda modelagens que verificaram o efeito de taxas sobre a comercialização de bebidas açucaradas no consumo e nos índices de sobrepeso e obesidade. Caso estivessem disponíveis vários artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia a alteração no peso corpóreo, IMC, medida da circunferência abdominal desde a linha de base.  
Após a leitura do texto completo dos estudos, 15 estudos foram excluídos: 1) oito por incluírem indivíduos que não atendem aos critérios de elegibilidade: 1.1) quatro revisões sistemáticas com meta-análise que incluíram adultos e crianças e não apresentaram análise estratificada<sup>168–171</sup> ; 1.2) uma revisão sistemática com meta-análise que incluiu indivíduos com IMC normal sem análise estratificada<sup>172</sup> ; 1.3) um ensaio clínico randomizado que incluiu apenas indivíduos com IMC normal e sobrepeso, sem estratificação na apresentação dos dados<sup>173</sup> ; 1.4) uma modelagem econômica que inclui população geral, sem apresentação de análise estratificada<sup>174</sup> ; 2) três por não apresentarem desfechos de interesse: 2.1) duas modelagens que não apresentaram dados antropométricos<sup>175,176</sup> ; 2.2) um ensaio clínico randomizado sem avaliação da associação entre redução do consumo de bebidas açucaradas com redução de medidas antropométricas<sup>177</sup> ; 3) um ensaio clínico randomizado que apresentou resultados de grupos intervenção e controle de modo agrupado<sup>178</sup> ; 4) um ensaio clínico randomizado que avaliou redução no consumo de bebidas açucaradas decorrente do aumento da ingesta de água associado a quatro tipos de dieta<sup>179</sup> ; 5) uma revisão sistemática com meta-análise que avaliou a associação entre consumo de refrigerantes no peso corporal, sem distinguir se houve redução ou aumento no consumo<sup>180</sup> ; 6) um resumo de congresso de ensaio clínico randomizado que apresenta escassez de dados para extração<sup>181</sup> ; 7) um resumo de congresso com texto completo disponível<sup>182</sup> .  
84  
Ao final, dois ensaios clínicos randomizados<sup>183,184</sup> e oito estudos de modelagem<sup>185–192</sup> atenderam aos critérios de seleção e foram incluídos para apreciação dos efeitos da restrição de calorias líquidas na perda de peso corporal em portadores de sobrepeso e obesidade. O processo de seleção dos estudos encontra-se esquematizado na **Figura 3** .  
**Figura C.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.468<br>PUBMED = 543<br>EMBASE = 925<br>Manual = 01<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>1.284  critérios de exclusão: 1.259<br>Publicações excluídas segundo<br>critérios de exclusão: 15<br>Publicações selecionadas para leitura  Tipo de participante: 08<br>completa: 25  Tipo de desfecho: 03<br>Tipo de intervenção: 02<br>Disponibilidade de dados: 02<br>Estudos incluídos: 10 estudos<br>Ensaios clínicos randomizados: 02<br>Modelagens: 08<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se nas **Tabelas E e F** (estudos clínicos e modelagens, respectivamente). A caracterização dos participantes de cada estudo pode ser vista na **Tabela G.** Resultados encontram-se nas **Tabelas H e I** (estudos clínicos e modelagens, respectivamente).  
85  
**Tabela E.** Características dos estudos clínicos incluídos na revisão.  
|.**Ano**|**Autor**|**Desenho de**<br>**estudo**|**Objetivo**|**Grupo Intervenção**<br>**(n)**|**Grupo Controle**<br>**(n)**|**Período de**<br>**Avaliação**|**Tempo de**<br>**Intervenção**|
|---|---|---|---|---|---|---|---|
|2014|Hernandez-Cordero et<br>al.<sup>183</sup>|ECR|Determinar se a substituição de bebidas com<br>adição de açúcar por água pode reduzir níveis<br>plasmáticos de triglicérides, peso e outros riscos<br>metabólicos em mulheres mexicanas com|Água + ação<br>educativa (134)|Ação educativa<br>(134)|basal, 3, 6 e<br>9 meses|9 meses|
||||sobrepeso e obesos|||||
||||Avaliar a substituição de bebidas calóricas por|aconselhamento|aconselhamento|||
|2012|Tate et al.<sup>184</sup>|ECR|água ou bebidas dietéticas como método de<br>perda de peso em até 6 meses em adultos|comportamental +<br>bebida dietética<br>(105) ou água (108)|sobre perda de<br>peso|_baseline_, 3<br>e 6 meses|6 meses|  
**Legenda:** ECR – Ensaio clínico randomizado.  
86  
**Tabela F.** Características das modelagens incluídas na revisão.  
|**Ano**|**Autor**|**Desenho de**<br>**estudo**|**Objetivo**|**Localidade**|**Participantes (n)**|**Horizonte**<br>**Temporal**|**Taxação**|**Redução de**<br>**açúcar**|
|---|---|---|---|---|---|---|---|---|
|2018<sup>B</sup>|<sup>asto Abreu</sup><br>et al.<sup>185</sup>|Modelagem<br>econômica|Estimar a proporção de açúcar que deveria ser<br>reduzida em bebidas com açúcar para redução<br>de consumo da população para 19% do total de<br>calorias, sem considerar mudanças no consumo.|México|3005 homens e mulheres<br>adultos mexicanos com<br>idade > 20 anos|12 anos (a<br>partir de 2020)|20% sobre<br>vendas|Até 50%|
|2017|Barrientos-<br>Guitierrez et<br>al.<sup>186</sup>|Modelagem<br>econômica|Estimar o impacto de taxação sobre bebidas com<br>açúcar no peso corporal e na prevalência de<br>sobrepeso e obesidade no México|México|2735 homes e mulheres<br>mexicanos com idade > 20<br>anos|10 <sup>anos</sup>|1 peso por litro<br>(~10% sobre<br>vendas) / 20%|ND|
|2017<br>|Schwendicke<br>et al.<sup>187</sup>|Modelagem<br>econômica|Avaliar de que modo taxas sobre bebidas com<br>açúcar reduzem risco de sobrepeso e obesidade<br>na Alemanha|Alemanha|ND|ND ("curto")|20% sobre<br>vendas|ND|
|2016|Duffey et<br>al.<sup>188</sup>|Modelagem|Avaliar o potencial impacto da substituição de<br>uma porção de bebida com açúcar por água nos<br>escores de HBI e na prevalência de sobrepeso|Estados<br>Unidos|16429 americanos adultos<br>com idade > 19 anos|ND|NA|ND|
|2016|Ma et al.<sup>189</sup>|Modelagem|Propor estratégia de redução gradual de adição<br>de açúcar em bebidas com açúcar em até 40%<br>em 5 anos sem substituição por adoçantes e<br>avaliar os efeitos sobre consumo de energia,<br>sobrepeso e obesidade|Reino Unido|4156 crianças e adultos (1-5<br>anos, 4-11 anos, 12-18<br>anos, 19-25 anos, 26-35<br>anos, 36-64 anos, ≥ 65<br>anos)|5 anos|NA|Até 40%|  
87  
|2015     Ruff et al.<sup>190</sup>|Modelagem<br>econômica|Determinar os efeitos de taxas sobre bebidas<br>com açúcar sobre em peso e obesidade em|Estados<br>Unidos|9341 americanos adultos<br>com idade > 18 anos|1, 5 e 10 anos|0,014% por<br>-<br>caloria|
|---|---|---|---|---|---|---|  
88  
|**Ano**|**Autor**|**Desenho de**<br>**estudo**|**Objetivo**|**Localidade**|**Participantes (n)**|**Horizonte**<br>**Temporal**|**Taxação**|**Redução de**<br>**açúcar**|
|---|---|---|---|---|---|---|---|---|
||||indivíduos adultos da cidade de Nova Iorque<br>(idade > 18 anos)||||||
|2011<br>|Dharmasena<br>et al.<sup>191</sup>|Modelagem<br>econômica|Delinear o efeito de impostos sobre o consumo<br>de bebidas com açúcar, ingestão calórica e peso<br>(Ainda, estimar as elasticidades relacionadas a<br>bebidas não alcoólicas e as taxas de desvio como<br>auxílio para explicar o movimento de consumo<br>de bebidas não alcoólicas em termos de volume<br>como resposta àpolítica de taxação.|Estados<br>Unidos|ND|ND|20%|ND|
||||Estimar demandas renda-dependentes por<br>bebidas para avaliar se o imposto sobre bebidas||||||
|2011|Lin et al.<sup>192</sup>|Modelagem<br>econômica|com açúcar é regressivo; demonstrar que<br>reduções de peso corporal e na prevalência de<br>obesidade decorrentes da redução do consumo<br>calórico diferem entre dois modelos de predição<br>(estático e dinâmico).|Estados<br>Unidos|7921 crianças (2-19 anos)<br>8322 adultos (>20 anos)|10 anos|20% sobre<br>consumo|ND|  
**Legenda:** HBI – Healthy Beverage Index; ND – não descrito.  
**Tabela G.** Características das amostras dos estudos clínicos incluídos na revisão.  
89  
|**Ano**|**Autor**|**Grupo (n)**|**Idade (anos)**<br>**Média (DP)**|**Sexo**<br>**Média (DP)**|**Peso basal (kg)**<br>**Média (DP)**|**IMC basal**<br>**(kg/m²)**<br>**Média (DP)**|**Circunferência abdominal**<br>**basal (cm)**<br>**Média (DP)**|**Tempo de**<br>**Intervenção**|
|---|---|---|---|---|---|---|---|---|
|2014|Hernandez-<br>Cordero et|134|33,5 (6,7)|100% F|76,9 (0,3)|31,1 (0,1)|98,3 (0,3)|9 meses|
||<br>al.<sup>183</sup>|134|33,3 (6,7)|100% F|76,0 (0,3)|31,0 (0,1)|98,5 (0,3)||
|||Aconselhamento<br>comportamental + água<br>(108)|43,2 (10,6)|88,9% F|98,4<br>IC 95% [95,2, 101,6]|35,8 (5,2)|115,1<br>IC 95% [112,6, 117,6]||
|2012|Tate et al.<sup>184</sup>|aconselhamento<br>comportamental + bebida<br>dietética (105)|41,2 (11,2)|78,1% F|99,0<br>IC 95% [97,1, 104,7]|36,1 (6,2)|115,5,<br>IC 95% [112,5, 118,5]|6 meses|
|||de peso, sem alterações<br>no consumo de bebidas<br>(105)<br>Informações sobre perda|41,56 (10,4)|85,7% F|102,6<br>IC 95% [99,1, 106,1]|36,8 (6,2)|116,5<br>IC95% [113,9, 119,2]||  
**Legenda:** F – Feminino; IC 95% - Intervalo de Confiança 95%.  
**Tabela H.** Desfechos de eficácia da restrição da restrição de calorias líquidas provenientes de estudos clínicos.  
90  
|**Ano**|**Autor**|**Perd**<br>**M**|**a de peso (k**<br>**édia (DP)**|**g)**|**Reduçã**<br>|**o de IMC (kg/**<br>**Média (DP)**|**m²)**|**Redução de ci**<br>**(cm**|**rcunferência**<br>**) - Média (D**|**abdominal**<br>**P)**|**Comentários**|**Período de**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||**valor de**|||||**avaliação**|
|||**Intervenção**|**Controle**|**valor de p**|**Intervenção**|**Controle**|<br>**p**|**Intervenção**|**Controle**|**valor de p**|||
|||∆ = -1,0 (0,2)|∆ = -0,5<br>(0,2)|p=0,06|∆ = -0,4<br>(0,08)|∆ = -0,2<br>(0,08)|p=0,07|∆ = -1,0 (0,3)|∆ = -0,5<br>(0,3)|p=0,10||3 meses|
||Hernandez-||∆ = -0,7||∆ = -0,54|∆ = -0,5|||∆ = -0,6||||
|2014|Cordero et<br>al.<sup>183</sup>|∆ = -1,4 (0,3)|(0,3)|p=0,10|(0,11)|(0,14)|p=0,10|∆ = -1,4 (0,3)|(0,5)|p=0,20|-|6 meses|
|||∆ = -1,2 (0,4)|∆ = -0,8<br>(0,4)|p=0,40|∆ = -0,3<br>(0,14)|∆ = -0,33<br>(0,15)|p=0,40|∆ = -1,0 (0,4)|∆ = -1,0<br>(0,7)|p=0,70||9 meses|
|||Água: ∆= -||||||∆= -0,7,|||||
|||1,31 (0,27) %||ND|ND|ND|ND|IC95% [-0,7, -|∆= -0,3,|ND|||
||||∆= - 1,34|||||0,7] cm|IC95% [-||Participantes do grupo de||
|||Bebida<br>dietética: ∆=<br>- 1,87 (0,32)<br>%|(0,7) %|ND|ND|ND|ND|∆= -2,0,<br>IC95% [-2,1, -<br>1,8] cm|0,2, -0,3]<br>cm|ND|bebidas dietéticas tiveram<br>maior probabilidade de<br>atingir perda de peso de 5%<br>comparado ao controle|3 meses|
|2012|Tate et al.<sup>184</sup>||||||||||(OR=2,29; IC95%:||
|||Água: ∆= -<br>2,03 (0,40) %||p=0,0967|ND|ND|ND|∆= -0,6,<br>IC95% [-0,5, -<br>0,7] cm|∆= -0,6,|p=0,1611|[1,05;5,01], p=0,004).<br>Não houve diferença entre<br>grupo controle e água||
||||∆= - 1,76||||||IC95% [-||(OR=1,87, IC95%: [0,84;|6 meses|
|||Bebida<br>dietética: ∆=<br>- 2,54 (0,45)<br>%|(0,35) %|p=0,3501|ND|ND|ND|∆= -1,9,<br>IC95% [-2,0, -<br>2,1] cm|0,7, -0,5]<br>cm|p=0,2169|4,14], p=0,13||  
91  
###### **Tabela I.** Resultados de efetividade provenientes das modelagens incluídas na revisão.  
92  
|**Ano**|**Autor**|**Perda de peso**<br>**estimada (kg)**<br>**Média (IC95%)**|**IMC basal**<br>**(kg/m²)**<br>**Média**<br>**(IC95%)**|**Redução de IMC**<br>**estimada**<br>**Média (IC95%)**|**Prevalência de**<br>**sobrepeso e**<br>**obesidade basal (%)**<br>**Média (IC95%)**|**Prevalência/ Casos de**<br>**Sobrepeso/ Obesidade evitados**<br>**(%)**<br>**Média (IC95%)**|**Comentários**|
|---|---|---|---|---|---|---|---|
|2018|Basto-Abreu<br>et al.<sup>185</sup>|∆=-1,3 (1,2; 1,4) kg|ND|∆=-0,5 (0,5; 0,6 kg/m²)|Obesidade:<br>30,9 (28,5; 33,3) %<br>Sobrepeso:<br>38,7 (36,1; 41,4) %|3,9 (2,6; 5,1) pontos de<br>porcentagem - menos 3,5<br>milhões de obesos em 2032|Redução gradual dos níveis de açúcar até<br>50% ao longo de 10 anos|
||Barrientos-|||**Imposto de 10%:**∆=-<br>0,15, DP = 0,55 kg/m²/<br>**Imposto de 10% + PE:**<br>∆=-0,29; DP =1,01|Obesidade: 34,05%|**Imposto de 10% e condições**<br>**normais**: Obesidade: - 2,54% e<br>Sobrepeso: + 0,51%/ I**mposto de**<br>**10% + PE:**Obesidade: -6,38% e||
|2017|Guitierrez et<br>al.<sup>186</sup>|NA|28,4|kg/m²/ I**mposto de 20%:**<br>∆=-0,31; DP= 1,08<br>kg/m²;**Imposto de 20%**<br>**+ PE:**∆=-0,57; DP = 2,00<br>kg/m²|Sobrepeso 35,57%|Sobrepeso:+0,42%/ I**mposto de**<br>**20%:**Obesidade: -6,85% e<br>Sobrepeso: +0,67%/I**mposto de**<br>**20% + PE**: Obesidade: -9,57% e<br>Sobrepeso: -1,90%|-|
||Schwendicke|||(disponível apenas||Obesidade: - 4% - 479 mil casos|Maiores benefícios entre indivíduos|
|2017|et al.<sup>187</sup>|ND|ND|estratificado por faixas<br>etárias)|ND|evitados/ Sobrepeso: -3% -<br>1028000 casos evitados|jovens e do sexo masculino|
|||||||**Perda de 0,44kg:**<br>Obesidade: -0,3% e Sobrepeso:||
|2016|Duffey et<br>al.<sup>188</sup>|De -0,44 a 1,99 kg|ND|ND|ND|-0,1%<br>**Perda de 1,99 kg:**<br>Obesidade: -1,4% e Sobrepeso:<br>-0,5 %|-|
|2016|Ma et al.<sup>189</sup>|∆=-1,20<br>(1,12; 1,28) kg|27,48 kg/m²|∆=-0,42 kgm/m² (1,5%)|Obesidade: 27,8%/<br>Sobrepeso: 35,5%|Obesidade: 2,1 (27,8%-25,7%)<br>pontos de porcentagem - menos<br>0,5 milhões com sobrepeso em 5<br>anos<br>Sobrepeso: 1,0 (35,5%; 34,5%)<br>pontos de porcentagem - menos<br>um milhão de obesos em 5 anos|Redução gradual dos níveis de açúcar até<br>atingir 60% em 5 anos|  
93  
94  
|**Ano**|**Autor**|**Perda de peso**<br>**estimada (kg)**<br>**Média (IC95%)**|**IMC basal**<br>**(kg/m²)**<br>**Média**<br>**(IC95%)**|**Redução de IMC**<br>**estimada**<br>**Média (IC95%)**|**Prevalência de**<br>**sobrepeso e**<br>**obesidade basal (%)**<br>**Média (IC95%)**|**Prevalência/ Casos de**<br>**Sobrepeso/ Obesidade evitados**<br>**(%)**<br>**Média (IC95%)**|**Comentários**|
|---|---|---|---|---|---|---|---|
|2015|Ruff et al.<sup>190</sup>|**ME:**<br>1 ano: ∆=-0,77 kg<br>5 anos: ∆=-3,8 kg<br>10 anos: ∆=-7,7 kg<br>**MD:**<br>1 ano: ∆=-0,46<br>(-0,46; -0,45) kg;<br>5 anos: ∆=-0,87<br>(-0,91; -0,83) kg;<br>10 anos: -0,92<br>(-0,99; 0,86) kg|26,8<br>(26,6; 7,0)|1 ano:<br>26,7 (26,5; 26,9) kg<br>5 e 10 anos:<br>26,5 (26,3; 26,7) kg|Obesidade:<br>23,7 (22,3-25,1) %<br>Sobrepeso:<br>32,9 (31,3; 34,4)|Sobrepeso:<br>1, 5 e 10 anos:<br>30,9 (29,4; 32,4) %<br>Obesidade:<br>1 ano:<br>23,0 (21,7; 24,4) %,<br>3<br>e 10 anos:<br>4<br>22,0 (20,7-23,4) %|Compara prevalência de obesidade de<br>acordo com IMC (23,7%, IC95%: [22,3-<br>25,1]) e de acordo com gordura corporal<br>(28,3%, IC95%: [26,9; 30,0]. Os resultados<br>apresentados no artigo estão de acordo<br>com o último valor.|
|2011|Dharmasena<br>et al.<sup>191</sup>|***Efeitos diretos:**<br>Consumo médio<br>per capita: ∆=-0,91<br>kg; Consumo<br>máximo per capita:<br>∆=-1,45 kg<br>**Efeitos diretos +**<br>**indiretos:**Consumo<br>médio per capita:<br>∆=-0,70/ Consumo<br>máximo per capita:|ND|ND|ND|ND|-|  
<u>1,16</u>  
95  
|**Ano**|**Autor**|**Perda de peso**<br>**estimada (kg)**<br>**Média (IC95%)**|**IMC basal**<br>**(kg/m²)**<br>**Média**<br>**(IC95%)**|**Redução de IMC**<br>**estimada**<br>**Média (IC95%)**|**Prevalência de**<br>**sobrepeso e**<br>**obesidade basal (%)**<br>**Média (IC95%)**|**Prevalência/ Casos de**<br>**Sobrepeso/ Obesidade evitados**<br>**(%)**<br>**Média (IC95%)**|**Comentários**|
|---|---|---|---|---|---|---|---|
|2011|Lin et al.<sup>192</sup>|**ME:**<br>Ano 1: ∆=-1,6 kg;<br>Ano 10: ∆=-16 kg<br>**MD:**<br>Ano 1: ∆=-0,97 kg;<br>Ano 5: 1,8 kg.<br>**Retirada total de**<br>**bebida com**<br>**açúcar:**<br>Ano 1: ∆=-4,32 kg,<br>Ano 5: ∆=-7,19 kg;<br>Ano 10: 7,34 kg|ND|ND|Obesidade: 33,5 %/<br>Sobrepeso: 66,9%|**ME (20% taxa):**Ano 1 -<br>Obesidade: 30,77%/ Sobrepeso:<br>62,81%; Ano 10 - Obesidade:<br>21,75%/ Sobrepeso: 45,19%<br>**MD (20% taxa):**Ano 1 -<br>Obesidade: 31,80%/ Sobrepeso:<br>64,34%; Ano 10 - Obesidade:<br>30,04%/ Sobrepeso: 62,23%<br>**Retirada total de bebidas com**<br>**açúcar:**Ano 1 - Obesidade:<br>27,30%/ Sobrepeso: 57,51%;<br>Ano 10 - Obesidade: 23,72%/<br>Sobrepeso: 50,79%|**ME (20% de impostos) - Renda alta:**<br>Baseline: Obesidade: 32,96%/ Sobrepeso:<br>67,62%; Ano 1 - Obesidade: 30,19%/<br>Sobrepeso: 63,45%; Ano 10 - Obesidade:<br>21,93%/ Sobrepeso: 46,33%<br>**ME (20% de impostos) - Baixa renda:**<br>Baseline - Obesidade: 35%/ Sobrepeso:<br>65,14%; Ano 1 - Obesidade: 32,23%/<br>Sobrepeso: 61,17%; Ano 10 - Obesidade:<br>21,28/ Sobrepeso: 42,28%<br>**MD (20% de impostos) - Renda alta:**Ano<br>1 - Obesidade: 31,16%/ Sobrepeso:<br>65,02%; Ano 10 - Obesidade: 21,5%/<br>Sobrepeso: 62,47%<br>**MD (20% de impostos) - Renda baixa:**<br>Ano 1 - Obesidade: 33,42%/ Sobrepeso:<br>62,6%; Ano 10 - Obesidade: 31,42%/<br>Sobrepeso: 60,91%<br>**Retirada total de bebidas com açúcar -**<br>**Renda alta:**Ano 1 - Obesidade: 27,26%/<br>Sobrepeso: 58,82%; Ano 10 - Obesidade:<br>24,11%/ Sobrepeso: 52,37%// Retirada de<br>todas as bebidas com açúcar -**Renda**<br>**baixa:**Ano 1 - Obesidade: 27,43%/<br>Sobrepeso: 54,16%; Ano 10 - Obesidade:<br>22,70%/ Sobrepeso: 46,73%|  
**Legenda:** DP – Desvio Padrão, IMC – Índice de Massa Corpórea, MD – Modelo dinâmico, ME – Modelo estático, ND – não descrito. ***** Efeitos diretos: considera apenas as elasticidades do próprio produto; efeitos indiretos: considerada demanda de um produto x decorrente da mudança de preço de um produto y.  
96  
Na **Figura D** consta a avaliação do risco de viés dos ECR incluídos. No caso das modelagens, diante da inexistência de ferramenta validada para avaliar a qualidade metodológica dos tipos de modelos apresentados, com abordagem essencialmente econométrica, foi realizada a avaliação geral das características dos estudos e discussão em relação às limitações referentes ao modelo.  
Os estudos foram conduzidos considerando-se diferentes países, com contextos socioeconômicos e culturais discrepantes, o que limita as comparações entre eles. As modelagens tiveram seus dados provenientes de censos ou inquéritos locais ou nacionais das localidades de interesse, que são representativos da população de interesse, porém esteve sujeito à qualidade e disponibilidade dos dados coletados. Os horizontes temporais foram suficientemente longos para que os efeitos, ao menos iniciais, pudessem ser detectados (5 a 12 anos).  
Os resultados de redução de peso, IMC e estimativas de prevalência de sobrepeso e obesidade foram obtidos por meio indireto, a partir da estimativa de redução do consumo de bebidas adoçadas com açúcar decorrente do acréscimo de impostos sobre a venda destas bebidas ou da redução gradual da quantidade de açúcares adicionados às bebidas<sup>189</sup> ou de seu consumo<sup>188</sup> , o que poderia sofrer influência de fatores, além de se desconhecer a qualidade dos estudos cujos dados foram extraídos e incluir diversas pressuposições. Com o objetivo de diminuir esses efeitos, alguns estudos consideraram os efeitos da resposta fisiológica à dieta ou aos exercícios físicos (modelo dinâmico)<sup>185,186,189,190,192</sup> , alterações de demanda em resposta à imposição de impostos sobre venda (elasticidade)<sup>187,191,192</sup> e compensações de consumo energético<sup>185,191</sup> .  
97  
**Figura D.** Resumo do risco de viés dos ensaios clínicos randomizados incluídos.  
<!-- Start of picture text -->
e<br>sg<br>a<br>bedfo.<br>e & 8<br>g S—E $s<br>5 eos<br>< g<br>s~ S$ 8 «=<br>£e.a oo a Dz3 &@<br>3 8 € S828<br>25 =6 &@5 =€ Ss25c ao&<br>Ss ££ &§ #8 5<br>Ss os § & &<br>a 2 § @® we £<br>cs Sf 8 & 8<br>5a =2 =2£ 8oC 3o 2a£<br>= 2 26 o@ 2<br>$6 = 2 € E a<br>£ 6 8 6s 8 §£<br>oa9 8 e#22<3 2 =<br>2 € «cS 3 8<br>B Ss 2 6 2<br>BS os £€ £ 2 ® yg<br>£ sS 82peeaetes& 2B @ &<br>8s € € ¢€ #2<br>§ 8s ss£€ —&— sg 22<br>e #< OG Ff HH GD<br>Hemandez-Cordero et al., 2014 OBOBODOO<br>Tate et al., 2012 |e\el/el/e|e|a/e|<br><!-- End of picture text -->  
A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no **Quadro F** . Esta tabela corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O **Quadro G** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
98  
###### **<u>Quadro F.</u>** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ <u>[SoF]) do</u> _webapp_ Grade PRO).  
|||**Qual**|**idade Global da**|**Evidência**|||**I**|**Qualidade**|**Iâi**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|<sup>**Evidência**</sup><br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**mpacto**|**Global**|**mportnca**|
|**Perda d**|**e Peso**|||||||||
|2|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|A substituição de pelo menos uma porção de bebida com<br>adição de açúcar por água ou bebidas dietéticas não<br>resultou em diferenças com significância estatística entre<br>os grupos comparados ao controle (sem substituição) em<br>3, 6 e 9 meses. Observou-se tendência de maior perda de<br>peso entre indivíduos que fizeram a substituição, sendo<br>maior entre aqueles que substituíram por bebidas<br>dietéticas.|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|**Reduçã**|**o de IMC**|||||||||
|1|ensaio clínicos<br>randomizado|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|Embora aos 3 meses de intervenção o grupo intervenção<br>tenha apresentado maior redução de IMC que o controle,<br>não houve diferença com significância estatística. Para 6<br>e 9 meses, os grupos não foram diferentes na redução de<br>IMC.|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|**Reduçã**|**o de Circunfe**|**rência Ab**|**dominal**|||||||
|2|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|A substituição de pelo menos uma porção de bebida com<br>adição de açúcar por água ou bebida dietética não<br>resultou em redução estatisticamente significativa de<br>circunferência abdominal em 3, 6 e 9 meses. No entanto,<br>houve tendência de maior redução entre indivíduos que<br>substituíram por água nos primeiros 3 meses em relação<br>aos controles e dos que substituíram por bebida dietética<br>em relação aos controles e grupo "água" aos 6 meses.|⨁⨁⨁◯<br>MODERADA|CRÍTICO|  
**Legenda:** IMC – Índice de Massa Corpórea;<sup>a</sup> Alto risco de viés pela ferramenta Cochrane.  
99  
###### **Quadro G.** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ do _webapp_ GRADE Pro).  
|PERGUNTA||
|---|---|
|**Deve-se usar**|**Restrição de caloria líquida vs. Consumo irrestrito de caloria líquida para perda de peso corporal?**|
|**POPULAÇÃO:**|Pacientes portadores de sobrepeso ou obesidade (Índice de massa corporal - IMC igual ou superior a 25 kg/m²) com ou sem comorbidades|
|**INTERVENÇÃO:**|Restrição de caloria líquida|
|**COMPARAÇÃO:**|Consumo irrestrito de caloria líquida|
|**PRINCIPAIS**<br>**DESFECHOS:**|Redução de peso corporal, redução de 5-10% do peso corporal, redução de circunferência abdominal e redução de IMC|  
|AVALIAÇÃO||
|---|---|
|Problema<br>O problema é uma priorid|ade?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não|· A obesidade é uma condição epidêmica no mundo;|
|○ Provavelmente Não<br>○ Provavelmente sim|· O número de obesos no mundo quase triplicou desde 1975. Em 2016, mais de 1,9 bilhão de adultos apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos;|
|● Sim<br>○ Varia|· De acordo com dados do VIGITEL Brasil 2017, a frequência de sobrepeso foi de 54,0% e a de obesidade de 18,9%.|
|○ Incerto|· Em evento internacional promovido pela Organização Panamericana da Saúde assumiu compromisso de frear o crescimento da obesidade até 2019 por meio de três medidas<br>principais: deter o crescimento da obesidade na população adulta por meio de políticas de saúde e segurança alimentar e nutricional; reduzir o consumo regular de refrigerante e<br>suco artificial em pelo menos 30% na população adulta; e ampliar em no mínimo 17,8% o percentual de adultos que consomem frutas e hortaliças regularmente[1];.|  
100  
#### Efeitos Desejáveis  
|Quão substanciais são|os efeitos desejáveis?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|● Trivial|· Em estudo clínico que avaliou a substituição de bebidas com adição de açúcar por água associado a ações educativas comparado a ações educativas isoladas, observou-se tendência|
|○ Pequeno|de maior redução de peso corporal em 3, 6 e 9 meses de intervenção, tendência de maior redução de IMC aos 3 meses e tendência de maior redução de circunferência abdominal aos|
|○ Moderado|3 e 6 meses. Em nenhum dos casos foi observou-se diferença com significância estatística entre os grupos (Hernandez Cordero et al., 2014);|
|○ Grande||
|○ Variável<br>○ Incerto|· Em estudo que avaliou os efeitos da substituição de bebidas com adição de açúcar por água ou bebidas dietéticas associado a aconselhamento comportamental comparado ao<br>aconselhamento isolado, observou-se que, nos grupos em que houve substituição, houve tendência a maior perda de peso corporal em 3 e 6 meses, sendo maior no grupo que<br>substituiu as bebidas calóricas por bebidas dietéticas. Para circunferência abdominal, observou-se tendência de redução da medida de circunferência abdominal aos 3 meses para<br>ambos os grupos, também maior no grupo que substituiu por bebidas dietéticas. Aos seis meses, a redução foi comparável entre o grupo que substituiu as bebidas por água e aquele<br>em que não houve substituição. Nenhuma das comparações atingiu significância estatística (Tate et al., 2012);|
||· Em modelagens que avaliaram os efeitos da redução do consumo de bebidas com adição de açúcar sobre o peso corporal, observou-se que houve redução de peso de até 1,99 kg<br>substituindo-se apenas uma porção de bebida com adição de açúcar por dia (Duffey et al., 2016) e de até 1,20 kg reduzindo-se gradualmente a quantidade de açúcar em bebidas em<br>até 40% em cinco anos (Ma et al., 2016). Estas modelagens evidenciaram ainda redução de aproximadamente 0,5 kg/m² de IMC (Duffey et al., 2016, Ma et al., 2016);|
||· Em estudos que avaliaram o aumento de taxas sobre as vendas de produtos com adição de açúcar, observou-se que estas medidas resultaram em redução de peso comporal de até<br>7,7 kg em 10 anos em modelos estáticos; e de até 0,92 kg em 10 anos em modelos dinâmicos (Ruff et al., 2015; Lin et al., 2011). Observou-se redução de IMC de 0,1 a 0,57 kg/m², a<br>depender da taxa adotada (basto-Abreu et al., 2018; Barrientos-Gutierrez 2017, Ruff et al., 2015);|
||· Nos modelos, observou-se que, quanto maior as taxas sobre venda de bebidas com adição de açúcar, maior a redução na prevalência de obesidade.|
||· Apenas um estudo avaliou o perfil de eventos adversos decorrentes do aumento de consumo de água e potencial redução no consumo de bebidas adoçadas com açúcar. Um total de<br>22 pacientes relatou eventos adversos não-graves que incluíram cansaço, náusea, stress ou frequente necessidade de urinar. Nenhum destes pacientes precisou descontinuar a<br>participação (Hernandez-Cordero et al., 2014).|  
101  
#### Efeitos Indesejáveis  
Quão substanciais são os efeitos indesejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|● Trivial|· Em estudo clínico que avaliou a substituição de bebidas com adição de açúcar por água associado a ações educativas comparado a ações educativas isoladas, observou-se tendência|
|○ Pequeno|de maior redução de peso corporal em 3, 6 e 9 meses de intervenção, tendência de maior redução de IMC aos 3 meses e tendência de maior redução de circunferência abdominal aos|
|○ Moderado|3 e 6 meses. Em nenhum dos casos foi observou-se diferença com significância estatística entre os grupos (Hernandez Cordero et al., 2014);|
|○ Grande||
|○ Variável|· Em estudo que avaliou os efeitos da substituição de bebidas com adição de açúcar por água ou bebidas dietéticas associado a aconselhamento comportamental comparado ao|
|○ Incerto|aconselhamento isolado, observou-se que, nos grupos em que houve substituição, houve tendência a maior perda de peso corporal em 3 e 6 meses, sendo maior no grupo que<br>substituiu as bebidas calóricas por bebidas dietéticas. Para circunferência abdominal, observou-se tendência de redução da medida de circunferência abdominal aos 3 meses para<br>ambos os grupos, também maior no grupo que substituiu por bebidas dietéticas. Aos seis meses, a redução foi comparável entre o grupo que substituiu as bebidas por água e aquele<br>em que não houve substituição. Nenhuma das comparações atingiu significância estatística (Tate et al., 2012);|
||· Em modelagens que avaliaram os efeitos da redução do consumo de bebidas com adição de açúcar sobre o peso corporal, observou-se que houve redução de peso de até 1,99 kg<br>substituindo-se apenas uma porção de bebida com adição de açúcar por dia (Duffey et al., 2016) e de até 1,20 kg reduzindo-se gradualmente a quantidade de açúcar em bebidas em<br>até 40% em cinco anos (Ma et al., 2016). Estas modelagens evidenciaram ainda redução de aproximadamente 0,5 kg/m² de IMC (Duffey et al., 2016, Ma et al., 2016);|
||· Em estudos que avaliaram o aumento de taxas sobre as vendas de produtos com adição de açúcar, observou-se que estas medidas resultaram em redução de peso comporal de até<br>7,7 kg em 10 anos em modelos estáticos; e de até 0,92 kg em 10 anos em modelos dinâmicos (Ruff et al., 2015; Lin et al., 2011). Observou-se redução de IMC de 0,1 a 0,57 kg/m², a<br>depender da taxa adotada (basto-Abreu et al., 2018; Barrientos-Gutierrez 2017, Ruff et al., 2015);|
||· Nos modelos, observou-se que, quanto maior as taxas sobre venda de bebidas com adição de açúcar, maior a redução na prevalência de obesidade.|
||· Apenas um estudo avaliou o perfil de eventos adversos decorrentes do aumento de consumo de água e potencial redução no consumo de bebidas adoçadas com açúcar. Um total de<br>22 pacientes relatou eventos adversos não-graves que incluíram cansaço, náusea, stress ou frequente necessidade de urinar. Nenhum destes pacientes precisou descontinuar a<br>participação (Hernandez-Cordero et al., 2014).|  
102  
#### Certainty of evidence  
|What is the overall certaint|y of the evidence of effe|cts?|||
|---|---|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQ|UISA<br>CONSIDERAÇÕES ADICIONAIS|||
|○ Muito Baixa<br>○ Baixa<br>● Moderada|||||
|○ Alta<br>○ Sem estudos incluídos|**Desfechos**|**Impacto**|**№ de**<br>**participantes**<br>**(estudos)**|**Certainty of the**<br>**evidence**<br>**(GRADE)**|
||Perda de Peso|A substituição de pelo menos uma porção de bebida com adição de açúcar por água ou bebidas dietéticas não resultou<br>em diferenças com significância estatística entre os grupos comparados ao controle (sem substituição) em 3, 6 e 9<br>meses. Observou-se tendência de maior perda de peso entre indivíduos que fizeram a substituição, sendo maior entre<br>aqueles que substituíram por bebidas dietéticas.|(2 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>|
||Redução de IMC|Embora aos 3 meses de intervenção o grupo intervenção tenha apresentado maior redução de IMC que o controle,<br>não houve diferença com significância estatística. Para 6 e 9 meses, os grupos não foram diferentes na redução de IMC|(1 ECR)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>|
||Redução de<br>Circunferência<br>Abdominal|A substituição de pelo menos uma porção de bebida com adição de açúcar por água ou bebida dietética não resultou<br>em redução estatisticamente significativa de circunferência abdominal em 3, 6 e 9 meses. No entanto, Houve<br>tendência de maior redução entre indivíduos que substituíram por água nos primeiros 3 meses em relação aos<br>controles e dos que substituíram por bebida dietética em relação aos controles e grupo "água" aos 6 meses|(2 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>|
||a.<br>Alto risc|o de viés pela ferramenta Cochrane|||
||· De acordo com a m<br>[1]GRADE Guideline|etodologia GRADE, a inclusão de modelagens econômicas no perfil de evidências não é recomendada, considerando-se as li<br>s: GRADE Handbook – Economic Model, disponível em:https://gdt.gradepro.org/app/handbook/handbook.html#h.t7qnfm9|mitações deste t<br>29m1g.|ipo de estudo[1],|  
103  
#### Valores  
|Existe importante incerteza o|u variabilidade acerca de qua|nto as pessoas valorizam os resultados primários?|
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Importante incerteza ou<br>variabilidade<br>○ Possível Importante<br>incerteza ou variabilidade<br>● Provavelmente nenhuma<br>Importante incerteza ou<br>variabilidade<br>○ Sem importante<br>incerteza ou variabilidade|Bebidas com adição de açúca<br>inicial;|r são bastante consumidas pela população. Provavelmente, medidas que resultariam na redução no consumo destas bebidas resultariam em insatisfação|
|Balanço dos efeito|s||
|O balanço entre efeitos desej|áveis e indesejáveis favorece|a intervenção ou o comparador?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Favorece o comparador|· A restrição no consumo de c|alorias líquidas resulta em tendência de perda de peso (sem diferença estatísticamente significativa), redução de IMC e circunferência abdominal,|
|○ Provavelmente favorece<br>o comparador<br>○ Não favorece um e nem|quando comparada ao consu<br>· Modelagens econômicas ev|mo irrestrito, avaliada em sensaios clínicos ranomizados;<br>idenciaram redução discreta em peso corporal e IMC e redução na prevalência de sobrepeso e obesidade;|
|o outro<br>○ Provavelmente favorece<br>a intervenção<br>○ Favorece a intervenção<br>○ Variável<br>● Incerto|. O aumento do valor cobrad<br>é menor. No entanto, ressalt<br>· Apenas um estudo avaliou e<br>urinar.|o sobre bebidas adoçadas (impostos/taxações) pode levar à diminuição do consumo de forma desigual, haja vista que o impacto sobre as maiores rendas<br>a-se que a população menos favorecida economicamente é que mais se beneficiará da política (1), pois é onde a prevalência de obesidade é maior (2).<br>ventos adversos da restrição de calorias. Foram observados eventos não graves, que incluíram: cansaço, náusea, stress ou frequente necessidade de|
||1. The Lancet Taskforce on NCD<br>2. FERREIRA, Vanessa Alves an<br>[online]. 2005, vol.21, n.6, pp.1|s and economics 4. Equity impacts of price policies to promote healthy behaviours. April 4, 2018 http://dx.doi.org/10.1016/S0140-736(18)30531-2<br>d MAGALHAES, Rosana. Obesidade e pobreza: o aparente paradoxo. Um estudo com mulheres da Favela da Rocinha, Rio de Janeiro, Brasil. Cad. Saúde Pública<br>792-1800. ISSN 0102-311X. http://dx.doi.org/10.1590/S0102-311X2005000600027.|  
104  
###### Equidade  
|Qual seria o impacto em equ|idade em saúde?||
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Reduzida<br>○ Provavelmente reduzida<br>○ Provavelmente nenhum<br>impacto<br>○ Provavelmente<br>aumentada<br>○ Aumentada<br>● Variável<br>○ Incerto|· A imposição de taxas mais e<br>entanto, ressalta-se que a po<br>· Alimentos e bebidas dietéti<br>economicamente desfavorec<br>1. The Lancet Taskforce on NC<br>2. FERREIRA, Vanessa Alves an<br>[online]. 2005, vol.21, n.6, pp.1|levadas sobre compra e venda de bebidas com adição de açúcar resultaria em menor consumo destas bebidas por indivíduos menos favorecidos. No<br>pulação menos favorecida economicamente é que mais se beneficiará da política (1), pois é onde a prevalência de obesidade é maior (2).<br>cas tendem a ter preço mais elevado do que alimentos comumente utilizados, o que restringe o consumo destes alimentos por indivíduos<br>idos;<br>Ds and economics 4. Equity impacts of price policies to promote healthy behaviours. April 4, 2018 http://dx.doi.org/10.1016/S0140-736(18)30531-2<br>d MAGALHAES, Rosana. Obesidade e pobreza: o aparente paradoxo. Um estudo com mulheres da Favela da Rocinha, Rio de Janeiro, Brasil. Cad. Saúde Pública<br>792-1800. ISSN 0102-311X. http://dx.doi.org/10.1590/S0102-311X2005000600027.|
|Aceitabilidade<br>A intervenção é aceitável pa|ra os principais atores sociais (|_stakeholders_)?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não<br>● Provavelmente sim<br>○ Sim<br>○ Variável<br>○ Incerto|· A redução da quantidade d<br>· A redução no consumo de b<br>nestas bebidas, quanto pelo<br>. Economicamente, a propos<br>· A redução de prevalência d|e açúcar nestas bebidas provavelmente alterariam o sabor, podendo resultar em menor consumo destas bebidas;<br>ebidas com adição de açúcar resultaria em redução na prevalência de sobrepeso e obesidade na população, seja pela redução da quantidade de açúcar<br>aumento nas taxas sobre compra e venda dos produtos;<br>ição de taxas poderia desagradar o empresariado nacional e internacional;<br>e obesidade e sobrepeso potencialmente resultariam em alteração nos perfis de morbimortalidade da população.|  
105  
#### Viabilidade  
|É viável a implementação|da tecnologia?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não|· Para adoção da medida, provavemente seria necessário envolvimento de outras agências, instituindo restrição obrigatória da adição de açúcar em bebidas ou aumento de taxas|
|○ Provavelmente não|sobre a venda destes produtos;|
|● Provavelmente sim<br>○ Sim<br>○ Varia|· Provavelmente seriam necessárias ações de educação e consientização da população acerca da necessidade de redução do consumo de calorias líquidas - quais deveriam ser<br>consumidos com cautela ou de modo restrito, já que nem todas as bebidas, necessariamente, têm adição de açúcar em sua composição.|
|○ Incerto||

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 3 - PERGUNTA PICO 2** -->
|||||**JULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|**Trivial**|Pequeno|Moderado|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|**Trivial**||Varia|Incerto|
|**CERTEZA DA EVIDÊNCIA**|Muito baixa|Baixa|**Moderada**|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece nem a<br>intervenção e nem a<br>comparação|Provavelmente<br>favorece a intervenção|Favorece a intervenção|Varia|**Incerto**|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|Provavelmente sem<br>impacto|Provavelmente<br>aumentada|Aumentada|Varia|Incerto|
|**ACEITABILIDADE**|Não|Provavelmente não|**Provavelmente sim**|Sim||Varia|Incerto|  
106

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 3 - PERGUNTA PICO 2** -->
|**VIABILIDADE**|Não<br>Provavelmente não|**Provavelmente sim**<br>Sim<br>Varia<br>Incerto|
|---|---|---|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 3 - PERGUNTA PICO 2** -->
|Recomendação forte contraa intervenção|Recomendação condicional contra a<br>intervenção|**Não favorece uma ou outra**|Recomendação condicional a favor da<br>intervenção|Recomendação forte a favor da<br>intervenção|
|---|---|---|---|---|
|○|○|**○**|○|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 3 - PERGUNTA PICO 2** -->
#### Recomendação  
Apesar de os estudos não serem conclusivos, por meio da experiência clínica dos painelistas, recomenda-se a substituição de todas as bebidas açucaradas (incluindo sucos de frutas naturais e arificiais) por água.  
107

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 4 - PERGUNTA PICO 3** -->
**Questão de pesquisa: “A substituição do açúcar pelo adoçante é eficaz na redução de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era o adoçante (C) era sacarose (açúcar); e desfechos (O) alteração no peso corpóreo, no IMC e na medida da circunferência da cintura desde a linha de base.  
###### **A. Estratégia de busca**  
**Quadro H.** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|((("Weight Loss"[Mesh] OR weight loss OR weight reduction)) AND<br>("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND ("Sweetening Agents"[Mesh] OR sweetening<br>agent* OR artificial sweetener* OR Sugar Substitute* OR Artificially<br>sweetened beverages OR sugar-free OR artificially sweetened)<br>Data da busca: 09/11/2018|1.129|
|**EMBASE**|('sweetening agent'/exp OR 'sweetening agent' OR 'sweetener'/exp<br>OR 'sweetener' OR 'artificial sweetener'/exp OR 'artificial<br>sweetener' OR 'sugar substitute' OR 'artificially sweetened<br>beverages' OR 'sugar-free' OR 'artificially sweetened') AND<br>[embase]/lim AND ('body weight loss'/exp OR 'body weight loss' OR<br>'weight loss'/exp OR 'weight loss' OR 'weight reduction'/exp OR<br>'weight reduction') AND [embase]/lim AND ('obesity'/exp OR<br>'obesity' OR 'obese' OR 'overweight'/exp OR 'overweight') AND<br>[embase]/lim)<br>Data da busca: 09/11/2018|418|  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 1.547 referências (1.129 no MEDLINE e 418 no EMBASE). Destas, 80 foram excluídas por estarem duplicadas. Um total de mil quinhentos e quarenta e sete referências foram triadas por meio da leitura de título e resumos, das quais 18 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo avaliava participantes portadores de sobrepeso ou obesidade e que usasse como grupo comparador a sacarose. Quando havia disponível vários  
108  
artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia a alteração no peso corpóreo, IMC, medida da circunferência da cintura desde a linha de base.  
Nessa etapa 17 estudos foram excluídos: 1) três pelo delineamento de estudo: 1.1) um _crosssectional_<sup>193</sup> ;1.2) uma avaliação de benefício-risco<sup>194</sup> ; 1.3)uma revisão de escopo<sup>195</sup> ; 2) sete por incluir participantes que não atendem aos critérios de inclusão: 2.1) cinco revisões sistemáticas foram excluídas por incluir estudos com indivíduos não portadores de sobrepeso ou obesidade e não realizarem análise de subgrupos<sup>168,169,171,172,196</sup> ;2.2) dois ensaios clínicos foram excluídos: um por incluir não portadores de sobrepeso ou obesidade<sup>197</sup> e um por incluir participantes com menos de 18 anos de idade<sup>198</sup> ; 3) sete ensaios clínicos por apresentarem outros comparadores que não a sacarose<sup>184,199–204</sup> .  
No final, apenas uma revisão sistemática com meta-análise foi incluída para avaliar a eficácia da substituição do açúcar pelo adoçante em indivíduos portadores de sobrepeso ou obesidade<sup>205</sup> e seus dados se encontram relatados a seguir ( **Figura E** ).  
109  
###### **Figura E.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.550<br>PUBMED = 1.129<br>EMBASE= 418<br>Busca Manual= 03<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>1.470  critérios de exclusão: 1.452<br>Publicações excluídas segundo<br>critérios de exclusão: 17<br>Publicações selecionadas para leitura<br>completa: 18  Tipo de delineamento: 03<br>Tipo de participante: 07<br>Tipo de comparador: 07<br>Estudos incluídos: 01 estudos<br>Revisão Sistemática: 01<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela J.** A caracterização dos participantes de cada estudo pode ser vista na **Tabela K.** Resultados encontram-se na **Tabela L** e na **Figura F.**  
Toews e colaboradores realizaram uma revisão sistemática com meta-análise para avaliar a associação entre o consumo de adoçantes e desfechos de saúde, dentre eles o peso corpóreo 205. Essa revisão incluiu 23 estudos ensaios clínicos, cinco estudos de coortes (concorrentes e não-concorrentes), 15 estudos de caso-controle, cinco estudos transversais, sete estudos em andamento e um estudo aguardando classificação. Dentre os estudos incluídos nesta revisão, apenas quatro atenderam aos critérios de inclusão<sup>206–209</sup> .  
110  
**Tabela J.** Características dos estudos incluídos para avaliar a eficácia da substituição do açúcar pelo adoçante em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**incluídos**<br>**Número de participant**|**e**<br>**s**<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|Raben et al<br>2002<sup>207</sup>|ECR|Comparar o efeito da suplementação de comidas e bebidas<br>contendo sacarose versus adoçantes artificiais no desejo de<br>ingestão de alimentos e nopeso corpóreo.|41|Adoçantes artificiais|Sacarose|
|||Comparar os efeitos na gordura corporal do refrigerante de cola|||Refrigerante cola tradicional|
|2011<sup>206</sup><br>Maersk et al|ECR|tradicional, com o leite desnatado, o refrigerante de cola diet e|22|Refrigerante cola diet (com aspartame)|Água|
|||a água.|||Leite|
|Reid et al<br>2010<sup>208</sup>|ECR|Avaliar o efeito da sacarose na ingestão de macronutrientes,<br>peso corporal e estado de sobrepeso em mulheres.|53|Aspartame|Sacarose|
|Reid et al<br>2014<sup>209</sup>|EC quase-<br>randomizado|Avaliar o efeito da adição de sacarose na dieta de mulheres<br>obesas.|41|Aspartame|Sacarose|  
ECR: ensaio clínico randomizado.  
111  
**Tabela K.** Características basais para os estudos que avaliaram a eficácia da substituição do açúcar pelo adoçante na redução de peso de indivíduos portadores de sobrepeso ou obesidade.  
|**Autores**|**Intervenção**|**Controle**|**N intervenção**|**N**<br>**controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção**<br>**vs. Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|<sup>**IMC (%),**</sup><br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Peso (Kg), Média**<br>**(DP) (Intervenção vs.**<br>**Controle)**|**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Raben et<br>al 2002<sup>207</sup>|Adoçantes<br>artificiais|Sacarose|20|21|37,1 (2,2)<br>vs.<br>33,3(2,0)|14,6 (geral)|27,6 (0,5)<br>vs.<br>28(0,5)|79,2 (2,0)<br>vs.<br>82,5(1,7)|NR|2,5 meses<br>(10<br>semanas)|2,5 meses|
|||Refrigerante cola|||39 (8)||32,8 (3,8)|92,2 (10,9)||||
|||tradicional (com<br>sacarose)||10|vs.<br>39(6)|25 vs. 60|vs.<br>31,3(2,9)|vs.<br>97,8(12,5)|NR|||
|Maersk et|Refrigerante||||39 (8)||32,8 (3,8)|92,2 (10,9)||||
|<br>al 2011<sup>206</sup>|cola diet (com<br>aspartame)|Água|12|13|vs.<br>39(8)|25 vs. 38,5|vs.<br>32,2(4,6)|vs.<br>101,7(22,4)|NR|6 meses|6 meses|
|||Leite desnatado||12|39 (8)<br>vs.<br>38(9)|25 vs. 25|32,8 (3,8)<br>vs.<br>31,9(2,8)|92,2 (10,9)<br>vs.<br>94,7(15,3)|NR|||
|Reid et al<br>2010<sup>208</sup>|Aspartame|Sacarose|29|24|32,93 (8,84) vs.<br>34,46(11,03)|0% vs. 0%|27,83 (1,83) vs.<br>27,18(2,06)|NR|34,39 (2,52) vs. 34,34<br>(3,62)|4 semanas|4 semanas|
|Reid et al<br>2014<sup>209</sup>|Aspartame|Sacarose|21|20|34,6 (8,5) vs.<br>35,1 (9,9)|0% vs. 0%|32,7 (2,2) vs.<br>32,9 (1,8)|89,2 (1,5) vs. 88,4<br>(1,5)|87,8 (2,0) vs. 94,3<br>(1,6)|4 semanas|4 semanas|  
NR: não reportado, N: número da amostra, DP; desvio padrão.  
112  
**Tabela L.** Desfechos de eficácia de estudos que avaliaram o consumo de adoçantes na alteração de peso corporal, no IMC.  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de alteração do peso corporal (Kg)**<br>**Intervenção vs. controle**|**Valor de p**|**Desfechos de alteração no IMC**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**Intervenção vs. controle**|**Valor de p**|
|---|---|---|---|---|---|---|
|Raben et al<br>2002<sup>207</sup>|Adoçantes artificiais (54%<br>aspartame)|Sacarose|-1,0 (0,4) vs. 1,6 (0,4)|< 0,001|0,5 (0,2) vs. -0,4 (0,2)|< 0,001|
|Maersk et al<br>2011<sup>206</sup>|Refrigerante cola diet<br>(com aspartame)|Refrigerante cola tradicional<br>(com sacarose)|0,114 (1,1) vs. 1,28 (1,1)|<0,01|NR|NA|
|Reid et al|Aspartame|Sacarose|*|NA|*|NA|
|2010<sup>~~208~~</sup><br>Reid et al|Aspartame|Sacarose|-0,31 (1,7) vs. 1,71 (2,1)|< 0,005|NR|NA|
|2014<sup>~~209~~</sup>|||||||  
ECR: ensaio clínico randomizado: risco relativo; IC 95%: intervalo de confiança; DM: diferença de médias; NR: não reportado; NA: não se aplica; IMC: Índice de Massa Corporal;DP: desvio padrão. * Estudo apresenta um gráfico de dispersão sobre os resultados de alteração de peso corporal e IMC, não sendo possíveis saber a diferença entre os grupos.  
**Figura F.** Meta-análise comparativa entre o consumo de adoçantes e açúcar na alteração do peso corporal.  
<!-- Start of picture text -->
Study Mean difference Weight Meandifterence<br>Normal (95%CD (95% CD<br>Kuzma weight<br>Maki 2015 —_i-——_ 15.2 0.43 (2.53 to 1.66)<br>Pooled2008estimate H; | - |’ 21536.7 003( .003t000003t000 9)<br>Heterogeneity: 17=0, P=0.67, P=0% H<br>Overweight and obese H<br>Maersk 2012 —- 26 -100(-1.66t0-032<br>Reid 2014 ; 213 -202¢-235t0-169)<br>Raben 2001 u | 213 -280(-311t0-249<br>Pooled estimate om 633 -199(-284to-114)<br>Heterogeneity: t7=0.51, P<0.01, P=93% H<br>Overall effect: 7=2.75, P<0.01,P=99% =—§ ——maiemmee— 1000 -1.29 62.80 00.21)<br>3 92 4 0 1 2 3<br><!-- End of picture text -->  
Fonte: Toews et al., 2019<sup>205</sup> .  
113  
A revisão sistemática incluída apresentou qualidade metodológica criticamente baixa pela ferramenta Amstar-2<sup>138</sup> por apresentar mais de uma falha crítica. Essas falhas críticas foram nos seguintes domínios:  
- Os autores da revisão nãoapresentaram uma lista de estudos excluídos com seus respectivos motivos ou justificativas;  
- Os autores da revisão não conduziram uma investigação do viés de publicação e seus possíveis impactos nos resultados da revisão.  
Os ensaios clínicos incluídos foram avaliados pela ferramenta de risco de viés da Cochrane<sup>139</sup> , sendo todos classificado com baixa qualidade metodológica ( **Figura G** ).  
**Figura G.** Avaliação da qualidade metodológica dos ensaios clínicos incluídos na revisão sistemática.  
<!-- Start of picture text -->
a<br>sz<br>=<br>3<br>s @<br>g Es<br>&S<br>22s<br>© s 3<br>202383eSS 8 282.2&<br>£68s Ss€ Ss 8<br>8 o@ ¢ E 5<br>22 2 6 &8 2<br>oc o so o = =<br>os 2 § ®@ gs =<br>2 2 2 5 8<br>SE ¢e8a 8 8 83<br>2 & & @ eg:<br>gee“ #2€& 5 2<br>2@ese3 6<br>$22e2232 e868<br>ges 53 5 8<br>82 Fes 2<br>es fese2e2<br>e = oOo GF ww 86<br>Maersk 2012 [@|elelejelele|<br>Raben 2001 l@|elelejelele|<br>Reid 2010 le|elelejelele|<br>Reid 2014 |o|e/elejelele|<br><!-- End of picture text -->  
A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no Quadro M. Este quadro corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O Quadro N contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
114  
**<u>Quadro M.</u>** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ <u>[SoF]) do</u> _webapp_ Grade PRO).  
||||**Qualidade Global**|**da evidência**|||**№ de pac**|**ientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**Desfechos de**<br>**alteração média**<br>**do peso**<br>**corporal (Kg)**|**placebo**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**|**Qualidade global**|**Importância**|
|**Alteração d**|**o peso corporal mé**|**dio (Kg)**|||||||||||
|3|Ensaios clínicos<br>randomizados|grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|53|51|-|DM**1.99**<br>**menor**<br>**(2.84 menor**<br>**para 1.14**<br>**menor)**|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|  
**IC:** Intervalo de Confiança; **DM:** Diferença Média; a. Alto risco de viés pela ferramenta da Cochrane; b. Alta heterogeneidade pelo teste de i quadrado; c. Os resultados estão na mesma direção, porém os intervalos de confiança não são sobreponíveis.  
**Quadro N.** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ (EtD) do _webapp_ GRADE PRO).  
|PERGUNTA||
|---|---|
|**Deve-se usar**|**Adoçante****_vs._açúcar para redução de peso de indivíduos portadores de sobrepeso ou obesidade?**|
|**POPULAÇÃO:**|redução de peso de indivíduos portadores de sobrepeso ou obesidade|
|**INTERVENÇÃO:**|Adoçante|
|**COMPARAÇÃO:**|açúcar|
|**PRINCIPAIS**<br>**DESFECHOS:**|Alteração do peso corporal médio (Kg);|  
115

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 4 - PERGUNTA PICO 3** -->
###### Problema  
O problema é uma prioridade?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Não|<br>A obesidade mundial quase triplicou desde 1975.|
|○ Provavelmente Não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.<br><br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais pessoas do que abaixo do peso.<br><br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.<br><br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou obesas em 2016.|
||<br>A obesidade é evitável.|
||Fonte: OMS. Obesity and overweight. Disponível em: https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight. Acesso em: 09/08/2019|  
|Efeitos Desej<br>Quão substanciais sã|áveis<br>o os efeitos desejáveis?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial|A meta-análise realizada pela revisão sistemática, para o subgrupo de participantes portadores de sobrepeso e obesidade, apresentou uma maior probabilidade de redução de peso em|
|● Pequeno<br>○ Moderado|participantes em uso de adoçantes comparado aos que consumiram açúcar. Porém, essa meta-análise apresenta importantes limitações, tais como, alta heterogeneidade, baixa<br>quantidade de estudos e participantes incluídos (três estudos, totalizando 129 participantes) e os estudos incluídos apresentam alto risco de viés. Outro ponto relevante em relação a|
|○ Grande<br>○ Variável|meta-análise para o desfecho de redução de peso, é a divergência dos resultados para participantes com o peso considerado normal (IMC < 25,0) e com sobrepeso ou obesidade, no<br>qual só há diferença estatisticamente significante para este último subgrupo, o que aumenta a incerteza do uso destes resultados para a tomada de decisão, devido, provavelmente, à|
|○ Incerto|presença de algum viés (seleção, atrito, performance e detecção) nos estudos que avaliaram a população com sobrepeso e obesidade. Ressalta-se que alguns estudos discutem o efeito<br>paradoxal dos adoçantes, uma vez que existe a hipótese que os mesmos ocasionem aumento de apetite e vontade de consumo de açúcar. Contudo, esses desfechos não foram objeto<br>de estudo do presente relatório.|  
116  
<!-- Start of picture text -->
‘Study Mean difference Weight Mean difference<br>Normal (5%CD 5% CD<br>MakiKuzma 2015weight —__m—_ 152 0.43 (2.530 1.66)<br>Pooled2008estimate | ’ 21536.7 00 3(-03(0 03t 0009)0009<br>Heterogeneity: 170, P=0.67, P=0% i<br>Maersk 2012 = 20.6 -10061.66t0-032<br>Reid 2014 , 213 -202(-235t0-169<br>Raben 2001 zx: 213 -2806311t0-249<br>Pooled estimate — 633 -199(-284t0-114<br>Heterogeneity: 1720.51, P<0.01, P=93% i<br>Overall effect: 7°=2.75, P<001,P=99% = ——emm—— 1000 -1,2962.80100.21)<br>a2 4 6 1 2 3<br><!-- End of picture text -->  
117  
#### Efeitos Indesejáveis  
Quão substanciais são os efeitos indesejáveis?  
- JULGAMENTO EVIDÊNCIAS DE CONSIDERAÇÕES ADICIONAIS PESQUISA  
- ●Trivial A meta-análise realizada pela revisão sistemática, para o subgrupo de participantes portadores de sobrepeso e obesidade, apresentou uma maior probabilidade de redução de peso em ○ Pequeno participantes em uso de adoçantes comparado aos que consumiram açúcar. Porém, essa meta-análise apresenta importantes limitações, tais como, alta heterogeneidade, baixa ○ Moderado quantidade de estudos e participantes incluídos (três estudos, totalizando 129 participantes) e os estudos incluídos apresentam alto risco de viés. Outro ponto relevante em relação a ○ Grande meta-análise para o desfecho de redução de peso, é a divergência dos resultados para participantes com o peso considerado normal (IMC < 25,0) e com sobrepeso ou obesidade, no ○ Variável qual só há diferença estatisticamente significante para este último subgrupo, o que aumenta a incerteza do uso destes resultados para a tomada de decisão, devido, provavelmente, à ○ Incerto presença de algum viés (seleção, atrito, performance e detecção) nos estudos que avaliaram a população com sobrepeso e obesidade. Ressalta-se que alguns estudos discutem o efeito paradoxal dos adoçantes, uma vez que existe a hipótese que os mesmos ocasionem aumento de apetite e vontade de consumo de açúcar. Contudo, esses desfechos não foram objeto de estudo do presente relatório.  
<!-- Start of picture text -->
Study Mean difference Welght Meanaitienice<br>NormalKuzma weight (95%CD os% cD<br>Maki 2015 —_—@ML 15.2 0.43 62.53 to 1.66)<br>Pooled2008estimate 1{ | - |+ 21536.7 003( -003t0003t0 009)<br>Heterogeneity: T=0, P20.67, P=O% i<br>Overweight and obese i<br>Maersk 2012 Tg 20.6 -1.00¢-1.66t0-032<br>Reid 2014 . a 213 -202(-235to-169<br>Raben 2001 @ | 213 -2806311t0-249<br>Pooled estimate — 633 199628410114<br>Heterogeneity: 1720.51, P<0.01, P=93% i<br>Overalieffect:17=2.75, P<0.01,P=99% = ——mme— 1000 -1,29¢2.80100.21)<br>3 2 4A OG 1 °2 38<br><!-- End of picture text -->  
118  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS||
|---|---|---|---|
|● Muito Baixa<br>○ Baixa|A qualidade geral d|a evidência é muito baixa para o desfecho de alteração do peso corporal médio (Kg).||
|○ Moderada<br>○ Alta<br>○ Sem estudos incluídos||**Desfechos**<br>**Importância**|**Certainty of the evidence**<br>**(GRADE)**|
|||Alteração do peso corporal médio (Kg)<br>CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,b,c</sup>|
||a.<br>Alto ri<br>b.<br>Alta he<br>c.<br>Os res|sco de viés pela ferramenta da Cochrane<br>terogeneidade pelo teste de i quadrado<br>ultados estão na mesma direção, porém os intervalos de confiança não são sobreponíveis||
|Valores<br>Existe importante incerteza|ou variabilidade ace|rca de quanto as pessoas valorizam os resultados primários?||
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS||
|○ Importante incerteza<br>ou variabilidade<br>○ Possível Importante<br>incerteza ou variabilidade<br>● Provavelmente<br>nenhuma Importante<br>incerteza ou variabilidade|<br>Por uma<br><br>Produto<br><br>Do pont<br><br>A substi|questão cultural, acredita-se que o açúcar seja mais aceito;<br>s Light ou dietéticos, normalmente, são mais onerosos para o consumidor;<br>o de vista da redução de calorias os adoçantes são, em geral, bem valorizados.<br>tuição do açúcar pelo adoçante pode ocasionar problemas de adesão.||  
119  
|○ Sem importante<br>incerteza ou variabilidade|||
|---|---|---|
|Balanço dos efei<br>O balanço entre efeitos de|tos<br>sejáveis e indesejáve|is favorece a intervenção ou o comparador?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Favorece o comparador<br>○ Provavelmente<br>favorece o comparador<br>○ Não favorece um e nem<br>o outro<br>○ Provavelmente|Mediante a escasse<br>adoçante é premat|z de estudos, a baixa qualidade metodológica dos mesmos e a incerteza das evidências, acredita-se que qualquer recomendação sobre a substituição do açúcar pelo<br>ura, se fazendo necessário mais estudos sobre o tema.|
|favorece a intervenção<br>○ Favorece a intervenção<br>○ Variável<br>● Incerto|||
|Aceitabilidade|||
|A intervenção é aceitável p|ara os principais ator|es sociais (_stakeholders_)?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não<br>○ Provavelmente sim<br>○ Sim<br>○ Variável<br>● Incerto|<br>Acredita<br><br>O Minist<br>gordura<br>ultrapro<br><br>Várias m<br>BARSIL. Ministério<br>1ª reimpressão. Bra<br>13/08/2019.|-se que os pacientes tenham preferência pelo uso do açucar, assim, a substituição do mesmo pelo adoçante pode ocasionar problemas de adesão.<br>ério da Saúde publicou guia de alimentação para a população brasileira (1), que considera uma alimentação balanceada. Nesse guia é preconizado que óleos,<br>s, sal e açúcar devem ser utilizados em pequenas quantidades ao temperar e cozinhar alimentos e criar preparações culinárias. Da mesma forma, alimentos<br>cessados são ricos em adoçantes e, em alguns casos, adicionados de sódio, devido, exatemente, ao uso de adoçantes.<br>arcas e edulcorantes artificiais estão disponíveis no Brasil. Alguns calóricos outros não. Alguns com sabor residual maior e outros menores.<br>da Saúde. Guia Alimentar para a População Brasileira. 2ª edição<br>sília - DF. Disponível em:http://bvsms.saude.gov.br/bvs/publicacoes/guia_alimentar_populacao_brasileira_2ed.pdf. Acesso em:|  
120  
#### Viabilidade  
|É viável a implementação|da tecnologia?||
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE|CONSIDERAÇÕES ADICIONAIS|
||PESQUISA||
|○ Não|||
|○ Provavelmente não|||
|○ Provavelmente sim|||
|○Sim|||
|○ Variável|||
|○ Incerto|||

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 4 - PERGUNTA PICO 3** -->
|||||**JULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|**Trivial**||Varia|Incerto|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece um ou<br>outro|Provavelmente<br>favorece a intervenção|Favorece a intervenção|Varia|**Incerto**|
|**ACEITABILIDADE**|Não|Provavelmente não|Provavelmente sim|Sim||Varia|**Incerto**|
|**VIABILIDADE**|Não|Provavelmente não|Provavelmente sim|Sim||Varia|Incerto|  
121

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 4 - PERGUNTA PICO 3** -->
|Recomendação forte contraa intervenção|**Recomendação condicional contra a**<br>**intervenção**|Não favorece uma ou outra|Recomendação condicional a favor da<br>intervenção|Recomendação forte a favor da<br>intervenção|
|---|---|---|---|---|
|○|**●**|○|○|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 4 - PERGUNTA PICO 3** -->
#### Recomendação  
Mediante a escassez de estudos, a baixa qualidade metodológica dos mesmos e a incerteza das evidências, acredita-se que qualquer recomendação sobre a substituição do açúcar pelo adoçante é prematura, se fazendo necessário mais estudos sobre o tema.  
122

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 5 - PERGUNTA PICO 4** -->
**Questão de pesquisa: “O fracionamento da dieta é eficaz na perda de peso corporal peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era o fracionamento da dieta (C) eram três refeições ou menos/dia; e desfechos (O) alteração no peso corpóreo, no IMC e na medida da circunferência da cintura desde a linha de base.  
###### **A. Estratégia de busca**  
**QUADRO O.** Estratégias de busca de evidências em base de dados.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**PubMed:**|(((((meal frequency OR food frequency OR diet frequency OR diet<br>fractioning OR diet fractionation OR meal fractioning OR meal<br>fractionation OR food fractioning OR food fractionation OR meal<br>timing OR regular meal OR regular meal time* OR regular meal<br>pattern* OR regular meal plan OR regular meal diet OR meal<br>skipping OR skipping meals)) AND (("Weight Loss"[Mesh] OR<br>weight loss OR weight reduction))) AND (("Obesity"[Mesh] OR<br>"Overweight"[Mesh] OR obesity OR overweight)))) AND<br>((randomized controlled trial[pt] OR controlled clinical trial[pt] OR<br>randomized[tiab] OR placebo[tiab] OR drug therapy[sh] OR<br>randomly[tiab] OR trial[tiab] OR groups[tiab] NOT (animals [mh]<br>NOT humans [mh])))|1.493|
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>('meal frequency'/exp OR 'meal frequency' OR 'food frequency' OR<br>'diet frequency' OR 'diet fractioning' OR 'diet fractionation' OR<br>'meal fractioning' OR 'meal fractionation' OR 'food fractioning' OR<br>'food fractionation' OR 'meal timing' OR 'regular meal' OR 'regular<br>meal time*' OR 'regular meal pattern*' OR 'regular meal plan' OR<br>'regular meal diet' OR 'meal skipping' OR 'skipping meals') AND<br>[embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight loss'/exp<br>OR 'weight loss' OR 'weight reduction'/exp OR 'weight reduction')<br>AND [embase]/lim|340|  
**B. Seleção das evidências**  
123  
A busca das evidências resultou em 1.833 referências (1.493 no MEDLINE e 340 no EMBASE). Destas, 65 foram excluídas por estarem duplicadas. Um total de mil setecentos e sessenta e oito referências foram triadas por meio da leitura de título e resumos, das quais 22 tiveram seus textos completos avaliados para confirmação da elegibilidade. Em busca manual, foram localizadas duas revisões (uma narrativa e uma sistemática com meta-análise) e um estudo primário. As referências da revisão com análise quantitativa de Schoenfeld et al., 2015<sup>210</sup> foram consultadas, sendo selecionados seis títulos para avaliação de elegibilidade. Somando-se as referências selecionadas por meio de busca eletrônica e manual, resultaram 31 artigos para avaliação de elegibilidade pelo texto completo.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo tinha como objetivo avaliar o efeito do fracionamento de dieta (com número de refeições por grupo e consumo calórico pré definidos) na redução de peso em indivíduos portadores de sobrepeso e obesidade. Estudos que incluíram outras intervenções além do fracionamento da dieta que não fossem comuns aos dois grupos foram excluídos. Quando diferentes artigos de um mesmo estudo estivessem disponíveis, optou-se pela publicação mais nova e com maior tempo de seguimento, desde que esta incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia a alteração no peso corpóreo, IMC, medida da circunferência da cintura desde a linha de base.  
Nessa etapa 25 estudos foram excluídos: 1) dois pelo delineamento de estudo: 1.1) um transversal<sup>211</sup> ; 1.2) uma revisão narrativa da literatura<sup>212</sup> ; 2) dois por incluir participantes que não atendem aos critérios de inclusão, sendo dois ensaios clínicos randomizados, que incluíram indivíduos com peso e IMC normais, sem apresentar análise estratificada<sup>210,213</sup> ; 3) um pelo tipo de intervenção, sendo uma revisão sistemática da literatura que não incluiu fracionamento da dieta entre os métodos para redução de medidas antropométricas<sup>214</sup> ; 4) treze estudos pelo tipo comparador: 4.1) nove estudos em que não foram padronizados a quantidade de dietas e ingesta calórica diárias<sup>215–222</sup> ; 4.2) quatro estudos que incluem outras intervenções sem estratificação para fracionamento de dieta<sup>223–226</sup> ; 5) um pelo tipo de desfecho, que não apresentou resultados de medidas antropométricas<sup>227</sup> ; 6) quatro pelo modo de apresentação dos dados: 6.1) um resumo de congresso com texto completo disponível<sup>223</sup> ; 6.2) um resumo de congresso que apresenta apenas descrição qualitativa dos resultados<sup>228</sup> ; 6.3) um resumo de congresso que não apresenta dados relativos aos participantes de cada braço; 6.4) um ensaio clínico randomizado que apresenta resultados individuais de paciente<sup>229</sup> ; 7) Dois por não terem sido localizados na íntegra, mesmo após tentativa de contato com autores<sup>230,231</sup> .  
No final, seis ensaios clínicos randomizados foram incluídos para avaliar os efeitos do fracionamento da dieta para redução de medidas antropométricas em portadores de sobrepeso ou obesidade<sup>232–237</sup> e seus dados se encontram relatados a seguir ( **Figura H** ).  
124  
**Figura H.** Fluxograma de seleção das evidências.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.842<br>PUBMED = 1.493<br>EMBASE= 340<br>Busca Manual= 10<br>Publicações excluídas segundo<br>critérios de exclusão: 1.747<br>Publicações após remoção de duplicatas:<br>1.778<br>Publicações excluídas segundo<br>critérios de exclusão: 25<br>Tipo de delineamento: 02<br>Publicações selecionadas para leitura  Tipo de participante: 02<br>completa: 31  Tipo de intervenção: 01<br>Tipo de comparador: 13<br>Tipo de desfecho: 01<br>Apresentação dos dados: 04<br>Não localizados: 02<br>Estudos incluídos: 05 estudos<br>Manual: 01 estudo<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela M** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela N** . Resultados encontram-se na **Tabela O** e as **Figuras H e I** ilustram a meta-análise dos estudos por desfecho. A avaliação do risco de viés dos estudos incluídos encontra-se na **Figura J.** A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no **Quadro P** . Ele corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O **Quadro Q** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE **.**  
125  
**Tabela M.** Características dos estudos incluídos para avaliar os efeitos do fracionamento de dieta para redução de peso corporal em indivíduos <u>portadores de sobrepeso ou obesidade.</u>  
|**Ano**|**Autor**|**Desenho**|**Objetivo**|**Intervenção (n)**|**Controle (n)**|**Desfechos**|**Tempo de**<br>**intervenção**|
|---|---|---|---|---|---|---|---|
|1981|Garrow et al.<sup>232</sup>|Ensaio Clínico*|Avaliar os efeitos de diferentes<br>concentrações de proteínas e frequência<br>de refeições, separadas ou em conjunto,<br>na perda de peso e no balanço de<br>nitrogênio em 38 participantes<br>portadores de obesidade.|5 refeições diárias<br>(800 kcal/dia)<br>(n=14)|1 refeição diária<br>(800kcal/ dia)<br>(n=14)|perda de peso e balanço<br>de nitrogênio|3 semanas|
|1993|Verboekete van de<br>Venne et al.<sup>233</sup>|ECR|Investigar os efeitos da frequência de<br>dieta na taxa de perda de peso e<br>composição de massa corpórea em<br>pacientes com sobrepeso e obesidade<br>moderada.|2 refeições diárias<br>(1000 kcal/dia)|3-5 refeições diárias<br>(1000 kcal diárias)|perda de peso, taxa<br>metabólica em repouso e<br>termogênese induzida<br>por dieta.|4 semanas|
|2006|Vander Wal et al.<sup>234</sup>|ECR|Avaliar se a adição de um snack pós<br>refeição resultaria em maior perda de<br>peso entre obesos com hábitos de comer<br>noturno participantes de intervenção de<br>substituição parcial de dieta.|Substituição parcial<br>de dieta + snack<br>noturno - 4<br>refeições (n=40)|Substituição parcial<br>de dieta - 3<br>refeições (n=40)|perda de peso, IMC,<br>circunferência abdominal,<br>consumo calórico,<br>hábitos do comer<br>noturno, disforia|8 semanas|
|2010|Cameron et al.<sup>235</sup>|ECR|Avaliar se alta frequência de refeições<br>com snacks pode resultar em maior<br>perda de peso do que baixa frequência<br>de refeições em resposta a dieta de<br>restrição energética|3 refeições<br>completas + 3<br>snacks (n=9)|3 refeições<br>completas (n=9)|Perda de peso, apetite e<br>concentrações de<br>peptídeo YY e grelina|8 semanas|  
126  
|**Ano**|**Autor**|**Desenho**|**Objetivo**|**Intervenção (n)**|**Controle (n)**|**Desfechos**|**Tempo de**<br>**intervenção**|
|---|---|---|---|---|---|---|---|
|2012|Bachman et al.<sup>236</sup>|ECR|Avaliar a associação entre a frequência<br>de refeições e manutenção da perda de<br>peso|ingestão alimentar<br>a cada 2-3 horas<br>(n=26)|3 refeições (n=25)|fome, reforço relativo do<br>valor dos alimentos,<br>consumo energético e<br>perda de peso em 3 e 6<br>meses|ND|
|2014|Hatami-Zargaran et<br>al.<sup>237</sup>|ECR|Avaliar os efeitos do consumo calórico<br>diário em 6 refeições isocalóricas<br>comparado ao modelo tradicional (3<br>refeições e 2 snacks diários) em peso,<br>perfil lipídico, leptina e adiponectina por<br>3 meses|6 refeições<br>isocalóricas por dia<br>(n=45)|dieta tradicional (3<br>refeições + 2<br>snacks) (n=45)|Peso, perfil lipídico,<br>leptina, adiponectina|3 meses|  
**Legenda:** ECR – ensaio clínico randomizado; kcal – quilocalorias; ND – não disponível. *O estudo, apesar de utilizar o termo “experimental”, não fornece detalhamento suficiente quanto à randomização  
127  
**Tabela N** . Características basais para os estudos que avaliaram os efeitos do fracionamento da dieta para redução do peso corporal em indivíduos <u>portadores de sobrepeso ou obesidade.</u>  
|**Ano**|**Autor**|**Participantes (n)**|**Intervenção (n)**|**Controle (n)**|**Idade**<br>**Média (DP)**|**Sexo**|**Tempo de**<br>**intervenção**|
|---|---|---|---|---|---|---|---|
|1981|Garrow et al.<sup>232</sup>|38|4 refeições diárias<br>(800 kcal/dia)<br>(n=14)|1 refeição diária<br>(800kcal/ dia)<br>(n=14)|ND|92,1% F|4 semanas|
|1993|Verboekete van de<br>Venne et al.<sup>233</sup>|14|3-5 refeições completas (n=7)<br>4 refeições (1000 kcal dia)|2 refeições completas<br>(1000 kcal/dia) (n=7)|46,1 (3,3) anos<br>variação: 20-58 anos|100% F|4 semanas|
|2006|Vander Wal et al.<sup>234</sup>|80|3 refeições diárias + snack após<br>jantar (n=40)|3 refeições diárias<br>(n=40)|Intervenção: 44,8 (11,7)<br>anos<br>Controle: 47,5 (10,3) anos|76,2% F|8 semanas|
|2010|Cameron et al.<sup>235</sup>|18|3 refeições + 3 snacks (n=9)|3 refeições (n=9)|Intervenção: 34,6 (9,5)<br>anos<br>Controles: 36,3 (7,4) anos|Intervenção: 50% F<br>Controle: 50%F|8 semanas|
|2012|Bachman et al.<sup>236</sup>|51|(1200-1500 kcal/dia)<br>(n=26)<br>Ingesta de pelo menos 100 kcal<br>a cada 2-3 horas|1500kcal/ dia) (n=25)<br>3 refeições (1200-|Controle: 51,8 (9,1) anos<br>Intervenção: 50,2 (10,8)<br>anos|Controle: 53,8% F<br>Intervenção: 60% F|6 meses|
|2014|Hatami-Zargaran et<br>al.<sup>237</sup>|90|6 refeições isocalóricas (n=45)|3 refeições + 2 snacks<br>(n=45)|ND|Intervenção: 85% F<br>Controle: 78% F|3 meses|  
**Legenda:** F - feminino; kcal – quilocalorias; ND – não disponível.  
128  
**Tabela O.** Desfechos de eficácia de estudos que avaliaram o fracionamento da dieta na redução de peso corporal, IMC e circunferência abdominal.  
|**Ano**|**Autor**|**Tempo de**<br>**intervenção**|**Grupo (n)**|**Peso corporal**<br>**basal**<br>**Média (DP)**|**Peso corporal final**<br>**Média (DP)**|**IMC basal**<br>**Média (DP)**|**IMC final**<br>**Média (DP)**|**Circunferência**<br>**abdominal basal**<br>**Média (DP)**|**Circunferência**<br>**abdominal final**<br>**Média (DP)**|
|---|---|---|---|---|---|---|---|---|---|
||||5 refeições diárias<br>(800 kcal/dia; n=14)|ND|∆= -224 (74) g/dia|ND|ND|ND|ND|
|1981|Garrow et al.<sup>232</sup>|4 semanas|1 refeição diária|||||||
||||(800kcal/ dia; n=14)|ND|∆= -255 (107) g/dia|ND|ND|ND|ND|
||||Comparação|-|p>0,05|-|-|-|-|
||Verboekete van||4 refeições (n=7)|82,2 (EP=4,6) kg|2 semanas: 76,3 (SE=2,7)<br>semanas: 74,3 (SE=2,6)<br>Redução: ∆= -4,7<br>(SE=0,4)|ND|ND|ND|ND|
|1993|de Venne et<br>al.<sup>233</sup>|4 semanas|2 refeições (n=7)|79,0 (EP=2,6) kg|2 semanas: 79,5 (SE=4,5)<br>semanas: 78,1 (SE=4,3)<br>Redução: ∆= -4,1<br>(SE=0,5)|ND|ND|ND|ND|
||||Comparação|-|p>0,05|-|-|-|-|
||||3 refeições + 1 snack<br>(n=29)|109,97 (22,92)<br>kg|∆=-3,71 (3,29) kg<br>(p<0,0001)|38,34 (6,84) kg/m²|∆= -1,31 (1,10)<br>kg/m² (p<0,0001)|11,85 (17,35) cm|∆= - 5,56 (6,01) cm<br>(p<0,0001) -<br>(n=26)|
|2006|Vander Wal et|8 semanas||||||||
||al.<sup>234</sup>||3 refeições (n=32)|106,91 (15,87)<br>kg|∆=-4,71 (3,84) kg<br>(p<0,0001)|37,68 (4,63) kg/m²|∆= -1,63 (1,34)<br>kg/m² (p<0,0001)|114,44 (10,69)<br>cm|∆= - 7,30 (5,89) cm<br>(p<0,0001) -<br>(n=24)|
||||Comparação|t=0,61|t=1,09|t=0,45|t=0,30|t=0,66|t=1,03|  
129  
2010 Cameron et 18 semanas 3 refeições + 3 snacks 114,1 (26,4) kg 109,5 (23,6) kg 37,1 (4,5) kg/m² 35,6 (4,7) kg/m² ND al.<sup>235</sup> (n=8/9) ∆=-5,3 (3,1) kg  
ND  
130  
|**Ano**|**Autor**|**Tempo de**<br>**intervenção**|**Grupo (n)**|**Peso corporal**<br>**basal**<br>**Média (DP)**|**Peso corporal final**<br>**Média (DP)**|**IMC basal**<br>**Média (DP)**|**IMC final**<br>**Média (DP)**|**Circunferência**<br>**abdominal basal**<br>**Média (DP)**|**Circunferência**<br>**abdominal final**<br>**Média (DP)**|
|---|---|---|---|---|---|---|---|---|---|
||||3 refeições (n=8/9)|101,0 (16,6) kg|95,7 (17,4) kg<br>∆= -4,6(2,4) kg|34,8 (4,0) kg/m²|32,9 (4,5) kg/m²|ND|ND|
||||Comparação|-|p>0,05|-|p>0,05|-|-|
||||3 refeições (n=25)|ND|ND|34,9 (4,3) kg/m²|3 meses: 31,5 (4,1)<br>kg/m²<br>6 meses: 29,8 (4,4)<br>kg/m²|ND|ND|
||Bachman et||||||3 meses:32,5 (5,1)|||
|2012|al.<sup>236</sup>|6 meses|Alimentação a cada<br>2-3 horas (n=26)|ND|ND|36,1 (5,2) kg/m²|kg/m²<br>6 meses: 31,3 (5,3)<br>kg/m²|ND|ND|
||||Comparação|-|-|NS|3 meses: p<0,001<br>6 meses: p<0,001|-|-|
||||6 refeições (n=45)|ND|ND|30,9 (5,2) kg/m²|28,9 (4,9) kg/m²<br>∆=-1,9 (0,9) kg/m²|ND|ND|
|2014|Hatami-<br>Zargaran et<br>al.<sup>237</sup>|3 meses|3 refeições + 2 snacks<br>(n=45)|ND|ND|30,3 (4,7) kg/m²|29,5 (4,3) kg/m²<br>∆=-0,7 (1,1)|ND|ND|
||||Comparação|-|-|NS|p <0,001<br>(diferença)|-|-|  
**Legenda:** EP – erro padrão, kcal – quilocalorias, ND – não disponível, NS – não significativo, t – estatística do teste t pareado.  
131  
**Figura I.** Meta-análise comparativa entre fracionamento de dieta e controle na redução de peso corporal.  
|**.** <br>Study orSubgrou<br>1.2.1|<br>Fracionamentodedieta<br>Controle<br>MeanDifference<br>MeanDifference<br>Mean<br>(kg)<br>SD<br>{kg}<br>TotalMean<br>kg}<br>SD<br>{kg}<br>TotalWeightIV,Fixed,95%Cl<br>[ki<br>IV,<sup>Fixed,</sup><br>95%<br>Cl|
|---|---|  
132  
**Figura J.** Meta-análise comparativa entre fracionamento de dieta e controle na redução de IMC.  
<!-- Start of picture text -->
Bachman1.4.1StudyRedugao oF Subgroupet al,de2012 IMC-12 semanasFracionamentoMean325 S125SD de__ dita. Total MeanHSControle41SD Total26 Weight25.0% Mean1:006-1.55,355)_1V, F D i fferencexed,95% Cl IV.Mean Fixed, Difference95% Cl<br>Halami-Zagaran etal,2014 289 49.45.2985 4345 44.0% -060F250, 1.30}<br>‘Subtotal (95% Cl), 70 71 69.5% -0.03 [-1.55, 1.50]<br>TestHeterogeneity:for overall Chi#=efect =0.97,0.03df=(P=1 (P=0.97) 0.32);F= 0%<br>1.4.2 Redugo<br>‘CameronSubtotal (95%etal.Cl)de2009 IMC - 18 semanas36.6 ar 8 329 45 8 8 .00 % 2:70[-127051. 81 ;7.21], 7.21)<br>Heterogeneity Not applicable<br>1.17 (P= 0.24)<br>Test for overall effect. Z=<br>‘Subtotal1.1.3Bachman Redugao (95%etal,Cl),de2012 IMC - 24 semanas3 53 25 298 44 26 22.5% 1.501.50118,[-1.18, 4.18 )]<br>Heterogeneity: Not applicable<br>Test for overall effect Z= 1.10 (P= 0.27)<br>Total (95% ci) 103 105 100.0% 0.53(-0.74, 1.81]<br>TestTestHeterayeneity: or for  overall  subaroup  effetChit= differences: Z=2.88, 0.62df= P= Chi*= 3 (P= 0.41) 1.90,  0.41); df= F= 0% 2 (P= 0.39), F= 0% ta Favorece002 teFracionamento.Fi + Favorece Controle% a<br><!-- End of picture text -->  
133  
**Figura K.** Avaliação da qualidade metodológica dos ensaios clínicos incluídos na revisão sistemática.  
<!-- Start of picture text -->
o<br>&<br>s<br>@<br>8<br>s 2£ -os<br>sg —e<br>2 €s 2os<br>= s 3<br>2 ¢ > 3 8<br>S$ & 3B DB &<br>3S ses<br>£65< 8 =§ Ss< a<br>S 83 8 &€ 2#35<br>Ss ots 8 SE<br>p 2 § 8 gs €<br>co +f 6 &@ 8<br>2os2 5s2 £62& @o F2 &a@<br>< §€ @ € 3<br>gs $8 so €@e26 288 §<br>&’ § €§ 2B 68 8<br>& 8 2 6 9 3<br>65s 2S 3 a 8<br>E2Pepedzs<br>so £ & SL<br>ec << @ o@ £ wv 5<br>Bachman et al, 2012 |e|e\e/ele/e/@|<br>Cameron et al, 2009 |@|e\e\e/e/e/e|<br>Garrow et al., 1981 |@|@|@/e\e/e/@|<br>Hatami-Zagaran et al, 2014 |@|@\e@\e/e/e/e|<br>Vander<br>Wal et al,, 2006 |@|@\e/e|e/e/@|<br>Vorboekete van de Venne & Westerterp, 1993 \elelele|alela|<br><!-- End of picture text -->  
134  
**Quadro P.** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ [SoF]) do _webapp_ GRADE PRO).  
|||**Avali**|**ação da qualida**|**de da evidên**|**cia**||**№ de pacie**|**ntes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||<br>|||||||||**Qualidade**|**Importância**|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|<sup>**Inconsistência**</sup>|<sup>**Evidência**</sup><br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Fracionamento**<br>**de dieta**|**placebo**|**Relativo**<br>**(95% IC)**|**Absoluto**<br>**(95% IC)**|**Global**||
|**IMC**|||||||||||||
|3|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não<br>grave|não grave|nenhum|105|103|-|MD**0.54**<br>**mais alto**<br>(0.73 menor<br>para 1.81<br>mais alto)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|**Peso cor**|**poral**||||||||||||
|3|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não<br>grave|não grave|nenhum|44|47|-|MD**0.15**<br>**menor**<br>(1.11 menor<br>para 0.81<br>mais alto)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|**Circunfer**|**ência abdominal**||||||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não<br>grave|grave<sup>b</sup>|nenhum|29|32|-|MD 1.74**cm**<br>**mais alto**<br>(1.56 menor<br>para 5.04<br>mais alto)|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
**Legenda:** a. alto risco de viés pela ferramenta da Cochrane; b. Intervalo de confiança largo; IC: Intervalo de Confiança; MD: _mean difference_ (diferença média)  
135  
###### **Quadro Q.** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ [EtD] do _webapp_ GRADE Pro).  
|PERGUNTA||
|---|---|
|**Deve-se usar fraciona**<br>**em pacientes com sob**|**mento de dieta em mais que três vezes vs. duas ou três dietas por dia para redução de medidas antropométricas**<br>**repeso ou obesidade?**|
|**POPULAÇÃO:**|Adultos com diagnóstico de sobrepeso ou obesidade (Índice de massa corporal - IMC igual ou superior a 25 kg/m2) com e sem comorbidades (diabetes e hipertensão<br>arterial)|
|**INTERVENÇÃO:**|fracionamento de dieta em mais que três vezes|
|**COMPARAÇÃO:**|duas ou três dietas por dia|
|**PRINCIPAIS DESFECHOS:**|Redução de peso corporal, redução de 5-10% do peso corporal, redução de circunferência abdominal e redução de IMC|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 5 - PERGUNTA PICO 4** -->
|Problema||
|---|---|
|O problema é uma priori|dade?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não|· A obesidade é uma condição epidêmica no mundo;|
|○ Provavelmente Não<br>○ Provavelmente sim|· O número de obesos no mundo quase triplicou desde 1975. Em 2016, mais de 1,9 bilhão de adultos apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos;|
|● Sim<br>○ Varia|· De acordo com dados do VIGITEL Brasil 2017, a frequência de sobrepeso foi de 54,0% e a de obesidade de 18,9%.|
|○ Incerto|Em evento internacional promovido pela Organização Panamericana da Saúde assumiu compromisso de frear o crescimento da obesidade até 2019 por meio de três medidas<br>principais: deter o crescimento da obesidade na população adulta por meio de políticas de saúde e segurança alimentar e nutricional; reduzir o consumo regular de refrigerante<br>e suco artificial em pelo menos 30% na população adulta; e ampliar em no mínimo 17,8% o percentual de adultos que consomem frutas e hortaliças regularmente;|  
136  
#### Efeitos Desejáveis  
Quão substanciais são os efeitos desejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|● Trivial|· A maioria dos estudos não encontrou diferenças com significância estatística entre o grupo que fracionou a dieta comparado àqueles que não fracionaram, para o desfecho de|
|○ Pequeno|perda de peso corporal;|
|○ Moderado<br>○ Grande|· O fracionamento de dieta resultou em redução estatisticamente significante do IMC quando comparado ao grupo que manteve três refeições diárias na maioria dos estudos;|
|○ Variável<br>○ Incerto|· Quanto à redução de circunferência abdominal, não foram observadas diferenças com significância estatística entre os grupos em comparação;|
||Em meta-análise para desfecho de perda de peso corporal, não houve diferença entre os grupos, embora tenha se observado tendência de maior perda ponderal a favor do<br>grupo fracionamento; Para redução de IMC, não foram observadas diferenças estatisticamente significantes, embora tenha sido observada tendência de maior redução a favor<br>do grupo controle.|
||· Nenhum estudo avaliou eventos adversos decorrentes do fracionamento da dieta.|  
#### Efeitos Indesejáveis  
Quão substanciais são os efeitos indesejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|● Trivial|· A maioria dos estudos não encontrou diferenças com significância estatística entre o grupo que fracionou a dieta comparado àqueles que não fracionaram, para o desfecho de|
|○ Pequeno|perda de peso corporal;|
|○ Moderado<br>○ Grande|· O fracionamento de dieta resultou em redução estatisticamente significante do IMC quando comparado ao grupo que manteve três refeições diárias na maioria dos estudos;|
|○ Variável<br>○ Incerto|· Quanto à redução de circunferência abdominal, não foram observadas diferenças com significância estatística entre os grupos em comparação;|
||Em meta-análise para desfecho de perda de peso corporal, não houve diferença entre os grupos, embora tenha se observado tendência de maior perda ponderal a favor do<br>grupo fracionamento; Para redução de IMC, não foram observadas diferenças estatisticamente significantes, embora tenha sido observada tendência de maior redução a favor<br>do grupo controle.|
||· Nenhum estudo avaliou eventos adversos decorrentes do fracionamento da dieta.|  
137  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICION|AIS|||||
|---|---|---|---|---|---|---|---|
|○ Muito Baixa<br>○ Baixa<br>●Moderada|**Desfechos**|**Efeitos absolutos potenciais**<sup>*****</sup>**(95% CI)**||**Efeito**<br>**relativo**|**№ de**<br>**participantes**|**Certainty of the**<br>**evidence**|**Comentários**|
|<br>○ Alta<br>○ Sem estudos incluídos||**Risco com duas ou três dietas por**<br>**dia**|**Risco com fracionamento**<br>**de dieta**|**(95% CI)**|**(estudos)**|**(GRADE)**||
||IMC|A média IMC foi**0**|MD**0.54 mais alto**<br>(0.73 menor para 1.81 mais<br>alto)|-|208<br>(3 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>||
||Peso corporal|A média peso corporal foi**0**|MD**0.15 menor**<br>(1.11 menor para 0.81 mais<br>alto)|-|91<br>(3 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>||
||Redução de circunferência<br>abdominal|A média redução de circunferência<br>abdominal foi**0**|MD**1.74 mais alto**<br>(1.56 menor para 5.04 mais<br>alto)|-|50<br>(1 ECR)|⨁⨁◯◯<br>BAIXA<sup>a,b</sup>||
||a.<br>alto risco de vié<br>b.<br>Intervalo de Co|s pela ferramenta da Cochrane<br>nfiança largo||||||  
138  
#### Valores  
Existe importante incerteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Importante incerteza|· O fracionamento de dieta resulta na necessidade de readequação da rotina dos indivíduos, o que pode não ser compatível com o estilo de vida;|
|ou variabilidade<br>○ Possível Importante<br>incerteza ou variabilidade|· O fracionamento de dieta envolve também a redução da quantidade e na melhoria da qualidade de alimentos ingeridas por refeição, o que pode ser, potencialmente, uma<br>dificuldade para alguns indivíduos.|
|● Provavelmente||
|nenhuma Importante||
|incerteza ou variabilidade||
|○ Sem importante||
|incerteza ou variabilidade||  
#### Balanço dos efeitos  
O balanço entre efeitos desejáveis e indesejáveis favorece a intervenção ou o comparador?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Favorece o comparador|· Conforme observado em efeitos desejáveis e indesejáveis:|
|○ Provavelmente<br>favorece o comparador|· Em meta-análise dos estudos para redução de peso corporal e IMC, não se observou diferença com significância estatística entre os grupos;|
|● Não favorece um e<br>nem o outro<br>○ Provavelmente|· Em estudos individuais, observou-se que apenas para o desfecho de redução de IMC os resultados foram estatisticamente significantes, embora a tendência de favorecer um<br>grupo ou outro tenha sido contraditória entre os estudos.|
|favorece a intervenção||
|○ Favorece a intervenção||
|○ Variável||
|○ Incerto||  
139

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 5 - PERGUNTA PICO 4** -->
|**PROBLEMA**<br>|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|---|---|---|---|---|---|---|---|
|**EFEITOS DESEJÁVEIS**<br>|**Trivial**|Pequena|Moderada|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**<br>|Grande|Moderada|Pequena|**Trivial**||Varia|Incerto|
|**CERTEZA DA EVIDÊNCIA**<br><br>|Muito baixa<br>|Baixa<br><br>|**Moderada**<br>|Alta<br>|||Sem estudos<br>incluídos|
|**VALORES**<br>~~pf~~<br><br>|Incerteza ou<br>variabilidade<br>importante<br><br>|Possivelmente<br>incerteza ou<br>variabilidade<br>importante<br>~~|~~<br>~~|~~<br><br>|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**<br>~~|~~<br>|Sem incerteza ou<br>variabilidade<br>importante<br><br>|~~t~~<br>|||
|**BALANÇO DOS EFEITOS**<br><br><br>|Favorece a<br>comparação<br><br>|Provavelmente<br>favorece a comparação<br><br><br><br>|**Não favorece uma ou**<br>**outra**<br> <br>|Provavelmenre<br>favorece a<br> <br> <br>|Favorece a<br>intervenção<br><br>|Varia<br><br>|Incerto<br>|
|TIPO DE RECOMEN<br> <br>~~—~~<br>~~|~~<br>|<br>DAÇÃO<br> <br> <br><br>|<br> <br>~~|~~<br>~~|~~<br>|<br>~~|~~<br>|intervenção<br> <br> <br>~~|~~<br>|<br> <br><br>|<br><br>|<br><br>|
|Recomendação forte contra<br>intervenção<br>|a<br>Recomenda<br>|ção condicional contra a<br>intervenção<br>|**Não favorece uma ou**<br>|**outra**<br>Recomen<br>|dação condicional a favor da<br>intervenção<br>|Recomen<br>|dação forte a favor da<br>intervenção<br>|
|○<br>||○<br>|**●**<br>||○<br>||○<br>|
|CONCLUSÕES<br>||||||||
|Recomenda-se realizar, no mínim<br>Recomendação<br>|o, três refeições ao d<br>|ia. Não há evidências de que<br>|o maior fracionamento da<br>|alimentação (>3) tenha b<br>|enefícios na perda de peso.<br>|||  
140

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 6 - PERGUNTA PICO 5** -->
**Questão de pesquisa: “A duração de 150 minutos* semanais de exercício físico é eficaz na redução de peso e no risco cardiovascular em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era prática de exercício físico com duração semanal definida ≥150 min (C) era não realização de exercício físico; e desfechos (O) alteração com relação à linha de base no peso corpóreo, no IMC, na medida da circunferência da cintura, gordura corporal, perfil lipídico, pressão arterial, glicose e insulina.  
###### **A. Estratégia de busca**  
###### **<u>Quadro R.</u>** Estratégias de busca de evidências em base de dados.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|(("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND (exercise duration OR duration of exercise OR<br>exercise timing OR exercise schedule)|1.783|
||Data da busca: 28/02/2019||
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>('exercise duration'/exp OR 'exercise duration' OR 'duration of<br>exercise' OR 'exercise timing' OR 'exercise schedule') AND<br>[embase]/lim|226|
||Data da busca: 28/02/2019||  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 2.009 referências (1.783 no MEDLINE e 226 no EMBASE). Destas, 98 foram excluídas por estarem duplicadas. Um total de 1.911 referências foram triadas por meio da leitura de título e resumos, das quais 33 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo avaliava participantes portadores de sobrepeso ou obesidade. Conforme o escopo estabelecido para o PCDT, inicialmente foram selecionados estudos que avaliavam 150 min semanais de exercício físico comparados a nenhuma atividade  
141  
física. Entretanto, durante a triagem das 1.911 referências foi observado que muitos estudos avaliavam tempos semanais de exercício diferentes de 150 min. Com o intuito de avaliar de forma mais ampla o impacto do tempo de exercício sobre a manutenção ou perda de peso, optou-se por incluir estudos que avaliassem programas de exercício físico com tempo semanal das intervenções igual ou superior a 150.  
Não foram incluídos estudos que avaliassem como comparador a modificação da dieta ou modificações comportamentais. Se ambos os grupos, exercício físico e controle, fossem expostos às mesmas modificações de dieta ou de comportamento, o estudo seria considerado para inclusão. Foram considerados para inclusão estudos publicados em inglês, espanhol ou português. Quando havia disponível vários artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia as alterações no peso corpóreo, IMC, medida da circunferência da cintura desde a linha de base. Como desfechos secundários foram considerados as alterações da gordura corporal, pressão arterial, frequência cardíaca, perfil lipídico, e glicose e insulina.  
Dos 33 estudos que foram lidos na íntegra, 26 foram excluídos: 1) 18 por questões relacionadas ao delineamento de estudo: 1.1) um estudo transversal<sup>238</sup> ; 1.2) um estudo qualitativo<sup>239</sup> ; 1.3) um estudo não randomizado<sup>240</sup> ; 1.4) três estudos de coorte<sup>241–243</sup> ; 1.5) uma revisão sistemática sem meta-análise<sup>244</sup> ; 1.6) dois não avaliaram desfecho foco deste relatório<sup>245,246</sup> ; 1.7) quatro não incluíram grupo comparador sem exercício físico<sup>247–250</sup> ; 1.8) dois não descreveram o tempo semanal de exercícios físicos<sup>251,252</sup> ; 1.9) um avaliou a duração global de programas de exercício<sup>253</sup> ; 1.10) um utilizou como controles participantes que não queriam praticar exercícios físicos<sup>254</sup> ; 1.11) um estudo em língua persa<sup>255</sup> ; 2) dois por incluir participantes que não atendem aos critérios de inclusão por incluir pacientes com IMC <25<sup>256,257</sup> ; e 3) 5 por questões relacionadas à intervenção: 3.1) um por avaliar a eficácia da recomendação de exercícios individualizados<sup>258</sup> ; um por avaliar exercícios dentro de um programa de modificação comportamental<sup>259</sup> ; dois por comparar modalidades de exercícios<sup>260,261</sup> ; um por comparar exercício supervisionado a exercício não supervisionado<sup>262</sup> .  
No final, foram incluídos sete ensaios clínicos randomizados que avaliaram a eficácia de exercícios físicos em tempos semanais determinados em indivíduos portadores de sobrepeso ou obesidade ( **Figura L** ) e seus dados se encontram relatados a seguir<sup>263–269</sup> .  
142  
**Figura L.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da<br>pesquisa nas bases de dados: 2.009<br>PUBMED = 1.783<br>EMBASE= 226<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo critérios de<br>1.911  exclusão: 1.878<br>Publicações excluídas segundo critérios de<br>Publicações selecionadas para leitura completa:  exclusão: 26<br>33<br>Tipo de delineamento: 18<br>Tipo de participante: 2<br>Tipo de comparador: 6<br>Estudos incluídos: 7 ensaios clínicos<br>randomizados<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela P** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela Q** . Resultados encontram-se nas **Tabelas R, S e T** e na **Figura M** . A avaliação do risco de viés dos estudos incluídos encontra-se na **Figura J** . A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no Quadro u, que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O Quadro V contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
143  
**Tabela P** . Características dos ensaios clínicos randomizados incluídos para avaliar a eficácia de 150 min ou mais de exercícios físicos semanais em indivíduos <u>portadores de sobrepeso ou obesidade.</u>  
|**Autor**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção(ões)**|**Controle**|**Tempo de intervenção**|**Tempo de avaliação**|
|---|---|---|---|---|---|---|
|Blumenthal et al<br>(2000)<sup>263</sup>|Avaliar um programa de exercícios na redução de<br>peso e controle da pressão arterial alta em homens e<br>mulheres com sobrepeso ou obesos.|78|Exercícios aeróbicos 165-220<br>min/semana|Lista de espera|26 semanas|26 semanas|
|Nieman et al|Avaliar os efeitos de exercícios e mudanças na dieta|||Alongamento e|||
|(2002)<sup>268</sup>|de mulheres moderadamente obesas quanto à<br>composição corporal eperfil lipídico.|43|Caminhada 225 min/semana|aquecimento|12 semanas|12 semanas|
|Donnelly et al<br>(2003)<sup>265</sup>|Avaliar os efeitos de um programa de exercícios na<br>prevenção do ganho de peso ou na perda de peso<br>em indivíduos com sobrepeso ou moderadamente<br>obesos com idade entre 17 e 35 anos.|74|Caminhada 100 min/semana -> 225<br>min/semana**|Sedentário|16 meses|16 meses|
|Irwin et al (2003)<sup>266</sup>|Avaliar um ano de exercício para mulheres na pós-<br>menopausa, com IMC >25 com idade entre 50 e 70<br>anos.|173|Exercícios de intensidade moderada<br>225 min/semana|Alongamento|12 meses|12 meses|
|(2009)<sup>264</sup><br>Davidson et al|doenças e incapacidade em homens e mulheres com<br>Avaliar o efeito de três programas de exercícios na<br>perda de peso e diminuição e fatores de risco para<br>obesidade abdominal.|100|Exercícios aeróbicos 150 min/semana<br>Exercícios de resistência e aeróbicos<br>150 min/semana<br>|Sedentário|6 meses|6 meses|
|Ho et al (2012)<sup>267</sup>|Avaliar o efeito de três programas de exercício na<br>mudança do perfil de risco cardiovascular de<br>indivíduos com sobrepeso ou obeso com idade entre|80|~~Exercícios aeróbicos 150 min/semana~~<br>Exercícios de resistência 150<br>min/semana<br>Exercícios aeróbicos e de resistência|Sedentário em uso<br>de suplemento<br>alimentar placebo|12 semanas|12 semanas|
|Schroeder et al<br>(2019)<sup>269</sup>|~~40 e 66 anos.~~<br>Avaliar o efeito de três programas de exercícios na<br>mudança da pressão arterial e fatores de risco<br>cardiovascular em indivíduos obesos com pressão<br>alta ou hipertensão.|69|150 min/semana<br>~~Exercícios aeróbicos 180 min/semana~~<br>Exercícios de resistência 180<br>min/semana<br>Exercícios aeróbicos e de resistência|Sedentário|8 semanas|8 semanas|  
180 min/semana  
* Esse estudo incluiu grupo de caminhada de 90 min/semana e não relatou quantos participantes foram alocados para cada grupo ** Esse estudo incluiu grupo de exercício associado a dieta e dieta, os quais não foram considerados neste relatório  
144  
**Tabela Q.** Características basais dos participantes dos estudos que avaliaram a eficácia de 150 min ou mais de exercícios semanais na redução de peso de indivíduos portadores de sobrepeso ou obesidade.  
|**Autores**|**Grupos**|**N**|**Idade (anos)**<br>**média (DP)**|**Sexo**<br>**masc, N**<br>|**IMC (%)**<br>**média (DP)**|**Peso (Kg)**<br>**média (DP)**|**Circunferência da cintura**<br>**(cm)**<br>|
|---|---|---|---|---|---|---|---|
|||||**(%)**|||**média(DP)**|
||||**Homens e mulhe**<br>Homens: 24 (4)|**res 17-35 anos**<br>|**de idade**<br>Homens: 290 (30)|Homens: 941 (114)||
|Donnelly et<br>|Controle|33|<br>Mulheres: 21 (4)<br>|15 (45)|, ,<br>Mulheres: 29,3 (2,3)|, ,<br>Mulheres: 79,9 (8,1)|**NR**|
|al<br>(2003)**<sup>265</sup>|Caminhada 225 min/semana|41|Homens: 22 (4)<br>Mulheres: 24 (5)|16 (39)|Homens: 29,7 (2,9)<br>Mulheres: 28,7(3,2)|Homens: 94,0 (12,6)<br>Mulheres: 770 (114)|**NR**|
||||<br>**Homens e mulhe**|**res 45-66 anos**|**de idade**|, ,||
||Controle sedentário|16|52(7,2)|1(6,2)|32,4(5,6)|85,1(16,8)|100,3(14,4)|
|Ho et al|Exercícios aeróbicos 150 min/semana|15|55(4,6)|3(20,0)|32,7(5,0)|91,9(15,9)|103,7(10,1)|
|<br><sup>267</sup>|Exercícios de resistência 150 min/semana|16|52(44)|3(187)|33(52)|893(18)|104(128)|
|(2012)|||,|,|,|,|,|
||Exercícios aeróbicos e de resistência 150<br>i|17|53 (5,4)|3 (17,6)|33,3 (4,9)|90 (16,5)|102,2 (13,2)|
||mn/semana||**Homens e mulhe**<br>|**res 60-80 anos**|**de idade**|||
||Controle sedentário|28|Homens: 67,4 (3,8)<br>Mulheres: 66,7 (3,7)<br>|11 (38)|Homens: 30,5 (2,0)<br>Mulheres: 30,4(3,2)|NR|Homens: 112,8 (5,3)<br>Mulheres: 104,9(7,4)|
|Davidson et<br>al (2009)<sup>264</sup>|Exercícios aeróbicos 150 min/semana|37|Homens: 68,8 (6,0)<br>Mulheres:69,1 (6,5)|17 (46)|Homens: 29,9 (3,0)<br>Mulheres: 29,2(3,7)|NR|Homens: 113,0 (7,9)<br>Mulheres: 104,2(10,4)|
||Exercícios de resistência e aeróbicos 150<br>min/semana|35|Homens: 67,1 (4,5)<br>Mulheres: 66,5(5,3)|14 (40)|Homens: 31,1 (3,1)<br>Mulheres: 29,5(3,0)|NR|Homens: 114,1 (8,3)<br>Mulheres: 102,8(9,6)|
|Nieman et al<br>(2002)<sup>268</sup>|al (2019)<sup>269</sup>|||||||
|Irwin et al<br>(2003)<sup>266</sup>||||||||
|Blumenthal<br>et al (2000)<br>263<br>Schroeder et||||||||  
145  
||**M**||**no**|**s de idade**||||
|---|---|---|---|---|---|---|---|
|Controle|**u**|22|NR|0(0)|32,8(1,0)|90,5(2,4)|NR|
|Caminhada 225 min/|**l**<br><br>semana|21|NR|0(0)|32,3(1,1)|88,4(2,9)|NR|
||**h**||**Mulheres napós-men**|**opausa 50-70**|**anos de idade**|||
|Controle alongam|**~~e~~**<br><br>ento|86|60,6(IC95% 59,1-62,1)|0(0)|30,6(IC95% 29,8-31,4)|81,7(IC95% 79,1-84,3)|111,3(IC95% 109,5-113,0)|
|Exercícios 225 min/s|**~~r~~**<br><br>emana|87|61,0(IC95% 59,6-62,5)|0(0)|30,5(IC95% 29,6-31,4)|81,6(IC95% 78,4-84,7)|111,1(IC95% 109,1-113,1)|
||**~~e~~**<br>|**Home**|**ns e Mulheres ≥ 29 anos de**|**idade compr**|**essão alta ou hipertensão**|||
|Controle|**~~s~~**<br>**~~2~~**|24|47,2(1,8)|13(54)|32,6(5,1)|94,0(17,3)|NR|
|Exercícios aeróbicos 165-22|**5**<br>0 min/semana|54|46,6 (1,2)|25 (46)|32,8 (4,0)|95,4 (14,5)|NR|
||**~~-~~**<br>**7**|**Home**|**ns e mulheres 45-74 anos d**|**e idade com pr**|**essão alta ou hipertensão**|||
|Controle|**5**|17|58 (6)|6 (35,3)|32,4 (3,7)|97,1 (20,7)|106 (10)|
|Exercícios aeróbicos 180|**~~a~~**<br>min/semana|17|58 (7)|7 (41,2)|32,5 (5,9)|95,8 (21,2)|103 (14)|  
146  
|Exercícios de resistência 180 min/semana|17|57 (9)|7 (41,2)|33,1 (5,9)|93,6 (18,9)|106 (17)|
|---|---|---|---|---|---|---|
|min/semana<br>Exercícios aeróbicos e de resistência 180|18|58 (7)|7 (38,9)|31,9 (5,5)|91,4 (16,0)|104 (13)|  
NR: não reportado, N: número da amostra, DP; desvio padrão.  
* Esse estudo incluiu grupo de caminhada de 90 min/semana e não relatou quantos participantes foram alocados para cada grupo.  
** Nesse estudo são fornecidas as características basais apenas dos participantes que completaram o estudo  
**Tabela R.** Resultados de Índica de Massa Corporal (IMC), peso corporal e medidas de cintura e quadril dos estudos incluídos que avaliaram programas de exercício físico de 150 min ou mais por semana para indivíduos com sobrepeso ou obesos.  
|**Autor ano**|**Intervenção**|**n**|**Tempo da**<br>|**Mudança de IMC**<br>**(Kg/m**<sup>**2**</sup>**)**|**Valo**|**Mudança de peso (Kg)**<br>|**Valo**|**Mudança de medida**<br>**de cintura (cm)**|**Valo**|**Mudança de**<br>**medida de quadril**<br>|**Valor**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**,**|||**avaliação**|<br>**Média (DP)**|**r p**|**Média (DP)**|**r p**|<br>**Média (DP)**|**r p**|**(cm)**<br>**Média(DP)**|**p**|
|||||**Homens e mulh**|**eres 17-35**|**anos de idade**||||||
||Controle (Homens)<br>|15||Diferença entre||Diferença entre||NR||NR||
|Donnelly et|Caminhada 225 min/semana<br>(Homens)|16|16 meses|<br>grupos: -0,7|0,02|<br>grupos: -4,8|0,01|NR||NR||
|al (2003)<sup>265</sup>|Controle(Mulheres)<br>|18||Diferença entre||Diferença entre||NR||NR||
||Caminhada 225 min/semana<br>(Mulheres)|25||<br>grupos: -1,5|0,03|<br>grupos: -5,2|0,03|NR||NR||
|||||**Homens e mulh**|**eres 45-66**|**anos de idade**||||||
||Controle sedentário|16||0||0||-1,2||||
||Exercícios aeróbicos 150|15||-0,3|0,04|-0,9|0,04|-2,1|NR|NR||
|Ho et al|min/semana||||2||4|||||
|(2012)<sup>267</sup>|Exercícios de resistência 150|16|12 semanas|0|NS|-0,1|NS|-2,6|NR|NR||
||min/semana|||||||||||
||Exercícios aeróbicos e de resistência<br>150 min/semana|17||-0,5|0,04<br>0|-1,6|0,04<br>4|-2,6|NR|NR||
|||||**Homens e mulh**|**eres 60-80**|**anos de idade**||||||
||Controle sedentário|28||0,10(0,7)||0,28(2,0)||-0,28(2,8)||NR||
|Davidson et<br>l 2009<sup>264</sup>|Exercícios aeróbicos 150<br>min/semana|37|6 meses|-0,96 (0,7)|<0,0<br>5|-2,77 (2,0)|<0,0<br>5|-5,08 (2,8)|<0,0<br>5|NR||
|a ()|Exercícios de resistência e aeróbicos<br>150 min/semana|35||-0,84 (0,7)<br>**Mulheres**|<0,0<br>5<br>**25-75 anos**|-2,31 (1,9)<br>**de idade**|<0,0<br>5|-4,61 (2,8)|<0,0<br>5|NR|147|  
Nieman et Controle alongamento e aquecimento 22 12 semanas -0,3 -0,8 NR NR  
148  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de IMC**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**Média (DP)**|**Valo**<br>**Mudança de peso (Kg)**<br>**r p**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de medida**<br>**de cintura (cm)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de**<br>**medida de quadril**<br>**(cm)**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|
|al(2002)<sup>268</sup>|Exercícios 225 min/semana|21||-0,3|NS<br>-1,0|NS|NR||NR||
|||||**Mulheres napós-men**|**opausa 50-70 anos de idade**||||||
|Irwin et al|Controle alongamento|86|12|0,3 (IC95% 0,0 a 0,6)|0,1 (IC95% -0,6 a 0,8)||0,1 (IC95% -0,8 a<br>0,9)||0,1 (IC95% -0,6 a 0,9)||
|(2003)<sup>266</sup>|Exercícios de intensidade<br>moderada 225 min/semana|87|meses|-0,3 (IC95% -0,6 a -0,1)|0,0<br>04<br>-1,3 (IC95% -2,0 a -0,5)|0,01|-1,0 (IC95% -1,8 a -<br>0,1)|0,04<br>9|-1,5<br>(IC95% -2,3 a -0,7)|0,00<br>3|
||||**Homens**|**e mulheres ≥29 anos de i**|**dade compressão alta ou hiperten**|**são**|||||
|Blumenthal et|Controle|24||0,3(1,1)|0,7(3,3)||NR||NR||
|al (2000)<sup>263</sup>|Exercícios aeróbicos 165-220<br>min/semana|54|26 semanas|-0,6 (0,9)|NR<br>-1,8 (2,8)|NR|NR||NR||
||||**Homens**|**e mulheres 45-74 anos de**|**idade compressão alta ou hiperte**|**nsão**|||||
||||||||0,5 (IC95% -1,2 a||||
||Controle|17||0,0 (IC95% -0,3 a 0,4)|0,1 (IC95% -0,8 a 1,0)||<br>2,1)||NR||
||Exercícios aeróbicos 180|17||-0,3 (IC95% -0,7 a 0,0)|NS<br>-1,0 (IC95% -1,9 a -0,1)|NS|0,4 (IC95% -1,2 a|NS|NR||
|Schroeder et|min/semana||||||2,0)||||
|al  (2019)**<sup>269</sup>|<br>Exercícios de resistência 180||8 semanas||||<br>-1,7 (IC95% -3,3 a -||||
||min/semana|17||-0,1 (IC95% -0,5 a 0,2)|NS<br>-0,2 (IC95% -1,1 a 0,7)|NS|0,1)<br>|NS|NR||
||Exercícios aeróbicos e de<br>resistência 180 min/semana|18||0,2 (IC95% -0,1 a 0,6)|NS<br>0,9 (IC95% 0,0 a 1,8)|NS|<br>0,9 (IC95% -0,7 a<br>2,5)|NS|NR||  
IC95%: intervalo de confiança de 95%; DP: Desvio-padrão; NR: não reportado; NS: não estatisticamente significante  
* Estudo incluiu grupo de caminhada de 90 min/semana e não relatou quantos participantes foram alocados para cada grupo, além disso, não relatou quantos participantes saíram do estudo nem qual estratégia utilizada pelos autores para lidar com dados faltantes.  
** Resultados ajustados por sexo, idade, e valores da linha de base  
149  
**Tabela S.** Resultados de alteração na composição corporal dos estudos incluídos que avaliaram programas de exercício físico de 150 min ou mais por semana para indivíduos com sobrepeso ou obesos.  
|**Autor, ano**|**Intervenção**|**n**|**Tempo**<br>**da**<br>**avaliação**|**Mudança de gordura**<br>**corporal**<br>**Média (DP)**|**Valor p**|**Mudança de gordura**<br>**intra-abdominal**<br>**Média (DP)**|**Valor**<br>**p**|**Mudança de gordura**<br>**abdominal**<br>**subcutânea**<br>|**Valor p**|**Mudança de**<br>**dobras**<br>**cutâneas**<br>|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||**Média(DP)**||**Média(DP)**||
||||**Home**|**ns e mulheres ≥29 anos de id**<br>|**ade com pr**|**essão alta ou hipertensã**|**o**|||||
|Blumentha|Controle|24|26|0,7 (2,0)%||NR||NR||NR||
|l et al<br>(2000)<sup>263</sup>|Exercícios aeróbicos 165-220<br>|54|semanas|-1,6 (4,7)%|NR|NR||NR||NR||
||min/semana|||**Mulheres 25-**|**75 anos de i**|**dade**||||||
|Nieman et|Controle alongamento e aquecimento|22|12|-1,1%||NR||NR||NR||
|al(2002)<sup>268</sup>|Exercícios 225 min/semana|21|semanas|-1,0%|NS|NR||NR||NR||
|||||**Homens e mulh re**|**s 17-35 ano**|**s de idade**||||||
||Controle (Homens)|15||Diferença entre grupos:||Diferença entre||Diferença entre||NR||
|Donnelly et|Caminhada 225 min/semana (Homens)|16||-1,4%|0,02|grupos: -9,9 cm<sup>2</sup>|0,56|grupos: -23,2 cm<sup>2</sup>|0,54|NR||
|<br>al (2003)<sup>265</sup>|Caminhada 225 min/semana<br>Controle(Mulheres)|18|16 meses|Diferença entre grupos:||Diferença entre||Diferença entre||NR||
||<br>(Mulheres)|25||-3,3%|0,02|grupos: -8,6 cm<sup>2</sup>|0,88|grupos: -53,3 cm<sup>2</sup>|0,02|NR||
|||||**Mulheres napós-meno**|**pausa 50-70**|**anos de idade**||||||
|||||-02% (IC95% -06 a 02)||01 /cm<sup>2</sup>||7,6 g/cm<sup>2</sup>||||
|Irwin et al|Controle alongamento|86|12 meses|,  ,  ,<br>-0,1 Kg (IC95% -0,6 a 0,6)||, g<br>(IC95% -6,7 a 6,6)<br>||<br>(IC95% -5,8 a 20,9)<br>||NR||
|(2003)<sup>266</sup>|Exercícios de intensidade moderada<br>225 min/semana|87||-1,2% (IC95% -1,6 a -0,8)<br>-1,4 Kg (IC95%-2,0 a-0,8)|0,001|-8,5 g/cm<sup>2</sup><br>(IC95%-15,1 a-2,0)|0,045|-21,2 g/cm<sup>2</sup><br>(IC95%-34,4 a-7,9)|0,003|NR||
||<br>|||<br>**Homens e mulhere**<br>|**s 60-80 ano**|<br>**s de idade**<br>||<br>||||
|Davidson|Controle sedentário|28||-0,52(2,0)Kg||0,02(0,3)Kg||-0,04(0,4)Kg||NR||
|<br>et al|Exercícios aeróbicos 150 min/semana|37|6 meses|-3,03(2,4)Kg|<0,05|-0,43(0,5)Kg|<0,05|-0,40(0,4)Kg|<0,05|NR||
|(2009)<sup>264</sup>|Exercícios de resistência e aeróbicos<br>150 i/|35||-3,38 (2,0) Kg|<0,05|-0,35 (0,3) Kg|<0,05|-0,40 (0,3) Kg|<0,05|NR||
||mnsemana|||**Homens e mulhere**|**s 45-66 ano**|**s de idade**||||||
||Controle sedentário|16||0,2%;0,2 Kg||NR||NR||NR||
||Exercícios aeróbicos 150 min/semana|15||-0,5%;-0,7 Kg|<0,05|NR||NR||NR||
|Ho et al|Exercícios de resistência 150|16|12|-0,5%; -0,4 Kg|NR|NR||NR||NR||
|(2012)<sup>267</sup>|min/semana||semanas|||||||||
||Exercícios aeróbicos e de resistência<br>150 min/semana|17||-1,0%; -1,6 Kg|<0,05|NR||NR||NR||  
150  
|**~~Homens e mulheres 45-74 anos de~~**<br>**~~idade com pressão alta ou hipertensão~~**|||
|---|---|---|
|Schroeder<br>~~Controle~~<br>~~17~~<br>8<br>0,2% (IC95% -0,4 a 0,8)|~~NR~~|~~NR~~<br>~~NR~~|
|0,2 Kg (IC95% -0,5 a 0,8)||<br>|  
151  
|et al|Exercícios aeróbicos 180 min/semana|17<br>~~se~~|~~manas~~<br>~~-0,5% (IC95% -1,1 a 0,0)~~|<0,05|NR|NR|NR|
|---|---|---|---|---|---|---|---|
|(2019)***<sup>2</sup>|||-0,9 Kg (IC95% -1,5 a -0,2)|(Kg)||||
|69|Exercícios de resistência 180|17|-0,2% (IC95% -0,8 a 0,4)|NS|NR|NR|NR|
||min/semana||-0,3 Kg (IC95%-1,0 a 0,3)|||||
||Exercícios aeróbicos e de resistência<br>180 min/semana|18|-0,5% (IC95% -1,0 a 0,1)<br>-0,1 Kg (IC95% -0,7 a 0,5)|<0,05<br>(%)|NR|NR|NR|  
C95%: Intervalo de confiança de 95%; DP: Desvio-padrão; NR: Não reportado; NS: Não estatisticamente significante  
* Estudo incluiu grupo de caminhada de 90 min/semana e não relatou quantos participantes foram alocados para cada grupo, além disso, não relatou quantos participantes saíram do estudo nem qual estratégia utilizada pelos autores para lidar com dados faltantes.  
**dobras cutâneas de bíceps, antebraço, suprapatelar, panturrilha, peitoral, tríceps, subescapular, axilar, abdominal, supra-ilíaca e coxa.  
*** Resultados ajustados por sexo, idade, e valores da linha de base  
152  
**Tabela T.** Resultados de alteração nos níveis de glicose e insulina dos estudos incluídos que avaliaram programas de exercício físico de 150 min ou mais por semana para indivíduos com sobrepeso ou obesos.  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Glicose jejum**<br>**(µU/mL)**<br>**Média(DP)**|**Valor**<br>**p**|**Insulina (µU/mL)**<br>**Média (DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|
|||**Hom**|**ens e mulheres (4**|**5-66 anos de idade)**||||
||Controle sedentário|16||-0,09||-0,13||
||Exercícios aeróbicos<br>150 min/semana|15||0,05|NS|2,82|NS|
|Ho et al|Exercícios de|||||||
|(2012)<sup>267</sup>|resistência 150|16|12 semanas|-0,04|NS|-0,5|NS|
||min/semana|||||||
||Exercícios aeróbicos e<br>de resistência 150<br>min/semana|17||0,17|NS|0,01|NS|
|||**Hom**|**ens e mulheres 6**|**0-80 anos de idade**||||
||Controle sedentário|28||NR||-0,29 (3,3)||
|Davidson et|Exercícios aeróbicos|37||NR||-1,43 (3,8)|NS|
|al (2009)<sup>264</sup>|150 min/semana||6 meses|||||
||Exercícios de|||||||
||resistência e aeróbicos<br>|35||NR||-1.49 (3,1)|NS|
||150 min/semana|||||||
||||**Mulheres 25-75**|**anos de idade**||||
|Nieman et|Controle|22|12 semanas|0,08||NR||
|al (2002)<sup>268</sup>|Exercícios 225<br>|21||-0,18|NS|NR||
||min/semana<br>**Homens e m**|**ulheres**|**≥29 anos de idad**|<br>**e compressão alta ou**|**hipertens**|**ão**||
|Blumenthal|Controle sedentário|24|26 semanas|4,5(6,7)||2,2(13,5)||
|et al (2000)<br>263|Exercícios aeróbicos<br>165-220 min/semana|54||2,2 (13,5)|NR|-1,0 (14,1)|NR|
||<br>**Homens e mu**|**lheres**|**45-74 anos de ida**|**de compressão alta o**<br>|**u hiperten**|**são**||
||Controle|17||2 mg/dL<br>(IC95%-1 a 5)||NR||
||Exercícios aeróbicos|17||0 mg/dL|NS|NR||
||180 min/semana|||(IC95% 3 a 3)||||
|Schroeder<br>et al<br>(2019)*<sup>269</sup>|Exercícios de<br>resistência 180|17|8 semanas|<br>-1 mg/dL<br>(IC95% -4 a 2)|NS|NR||
||min/semana|||||||
||Exercícios aeróbicos e<br>de resistência 180<br>min/semana|18||-2 mg/dL<br>(IC95% -4 a 1)|NS|NR||  
DP: Desvio-padrão; NR: Não reportado; NS: Não estatisticamente significante  
*Resultados ajustados por sexo, idade, e valores da linha de base  
153  
###### **Figura M.** Gráfico de floresta da meta-análise dos resultados de redução do peso corporal (Kg) dos estudos incluídos*  
|<br>Study<br>orSubgroup<br>1.1.4<br><br>|<br>=150mindeexercicio<br>__Mean___—SD_Tota<br><br>|
|---|---|  
* Os nomes dos subgrupos remetem à população incluída no estudo e ao tempo de duração da intervenção (programas de exercícios).  
Donnelly (2003) A: Homens; Donnelly (2003) B: Mulheres; Davidson (2009) A: Exercícios aeróbicos; Davidson (2009) B: Exercícios aeróbicos e exercícios de resistência; Ho (2012) A: Exercícios aeróbicos; Ho (2012) B: Exercícios de resistência; Ho (2012) C: Exercícios aeróbicos e de resistência; Schroeder (2019) A: Exercícios aeróbicos; Schroeder (2019) B: Exercícios de resistência; Schroeder (2019) C: Exercícios aeróbicos e de resistência  
154  
**Figura N.** Avaliação da qualidade metodológica dos ensaios clínicos incluídos na revisão sistemática.  
<!-- Start of picture text -->
om e<br>& Ss<br>2 2[=<br>= eo 8<br>So8 8 @<br>Ss<br>ao # 5g &fF 82s<br>2ss 88<br>§ 8 £€ € =<br>ese5 3 8 #2<br>o 2 3 328gs =<br>3 6 € 6<br>a 5 2 8 8 &<br>2 @ o +<br>o££2 2e<br>ee®2 s2 6@ 6&58 £ 2z=<br>* £€ 5 € 8 6<br>ge 5Ss 8££ 32 @ ®@a<br>2 3 5 g &<br>8sEe FPeree<br>5s 8 §¢ 6§ €Fs¢<br>§ 8<br>© 2 o£ £8@ = 28<br>ounnesicoo[@[@[@<br>cate cnn| @[@ @[@[2 [0 ][<br>convcor| @[@[@|@ |<br>roan |@|@/@[@/@|@|<br>OOOO<br>contewenn oion|@[@[@[@|@@ | [@[0[@|@| ||<br><!-- End of picture text -->  
155  
**<u>Quadro U.</u>** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ <u>[SoF]) do</u> _webapp_ Grade PRO).  
|||**Qu**|**alidade Global da**|**evidência**|||**№ depa **|**cientes**|**Efei**|**to**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**>=150**<br>**min/semana**<br>**exercício**|**Controle**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**|**global**||
|**Alteraçã**|**o dopeso corporal**|**médio(Kg)**|||||||||||
|7|Ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|375|213|-|DM -1,39<br>Kg (IC95%<br>-2,20 a -<br>0,57)|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|  
DM: Diferença Média; IC: Intervalo de Confiança; a. Alto risco de viés pela ferramenta da Cochrane; b. Alta heterogeneidade pelo teste de I<sup>2</sup> ; c. Intervalo de confiança das estimativas individuais e estimativa da meta-análise considerados grandes.  
**Quadro V.** Resumo dos principais domínios avaliados no GRADE (Tabela _Evidence to Decision_ [EtD]) do _webapp_ GRADE Pro).  
|PERGUNTA||
|---|---|
|**Deve-se usar program**<br>**de peso de indivíduos**|**as de exercício com duração igual ou superior a 150 min semanais vs. não realizar exercícios físicos para redução**<br>**portadores de sobrepeso ou obesidade?**|
|**POPULAÇÃO:**|Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade|
|**INTERVENÇÃO:**|programas de exercício com duração igual ou superior a 150 min semanais|
|**COMPARAÇÃO:**|não realizar exercícios físicos|
|**DESFECHOS PRINCIPAIS:**|Alteração com relação à linha de base no peso corpóreo, no IMC, na medida da circunferência da cintura, gordura corporal, perfil lipídico, pressão arterial, glicose<br>e insulina.|
|**CENÁRIO:**|Todo o Brasil|  
156

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 6 - PERGUNTA PICO 5** -->
###### Problema  
|O problema é uma priorida|de?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente Não<br>○ Provavelmente sim<br>● Sim|· A obesidade é uma condição epidêmica no mundo;<br>· O número de obesos no mundo quase triplicou desde 1975. Em 2016, mais de 1,9 bilhão de adultos apresentavam excesso de peso. Destes, mais de 650 milhões eram<br>obesos;|
|○ Varia<br>○ Incerto|· De acordo com dados do VIGITEL Brasil 2017, a frequência de sobrepeso foi de 54,0% e a de obesidade de 18,9%.<br>· A Organização Mundial da Saúde recomenda que adultos com idade entre 18 e 64 anos façam pelo menos 150 minutos semanais de atividade física aeróbica de<br>intensidade moderada ou pelo menos 75 minutos semanais de atividade física aeróbica de intensidade vigorosa ou uma combinação equivalente de ambos.|
|Efeitos Desejávei<br>Quão substanciais são os e<br>JULGAMENTO|s<br>feitos desejáveis?<br>EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>● Pequeno<br>○ Moderado<br>○ Grande<br>○ Variável|· Estudos individuais apresentaram resultados controversos a respeito da eficácia da prática de exercícios físicos iguais ou superiores a 150 min/semana para perda de<br>peso, redução de IMC e redução de circunferência abdominal e de quadril;<br>· Na meta-análise dos estudos, verificou-se que a diferença das médias calculadas para o desfecho de redução de peso corporal favoreceu o grupo que realizou atividades<br>físicas iguais ou superiores a 150 min/semana. Entretanto, o conjunto de estudos apresentou heterogeneidade estatisticamente significativa;|
|○ Incerto|· A prática de exercícios físicos igual ou superior a 150 min/semana foi favorável à redução de gordura corporal em indivíduos do sexo masculino. Em mulheres, o resultado<br>foi controverso. ·<br>· Observou-se tendência de redução de pressão arterial com a prática de exercícios físicos por período superior a 150 min/ semana. Indivíduos que praticaram exercícios<br>físicos por períodos iguais ou superiores a 225 min/semana apresentaram redução significativa de pressão arterial e frequência cardíaca.<br>· Não foi observada diferença estatisticamente significante entre grupos que praticaram exercícios físicos >150 min/ semana e o grupo se manteve sedentário quanto a<br>alterações no perfil lipídico.<br>· Resultados de estudos individuais foram controversos quanto à eficácia da prática de exercícios físicos > 150 min/ semana sobre glicemia e níveis de insulina.<br>· Resultados de segurança não foram relatados nos estudos.|  
157  
|Efeitos Indesej|áveis|
|---|---|
|Quão substanciais são o|s efeitos indesejáveis?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>○ Pequeno<br>○ Moderado<br>○ Grande<br>○ Variável|· Estudos individuais apresentaram resultados controversos a respeito da eficácia da prática de exercícios físicos iguais ou superiores a 150 min/semana para perda de<br>peso, redução de IMC e redução de circunferência abdominal e de quadril;<br>· Na meta-análise dos estudos, verificou-se que a diferença das médias calculadas para o desfecho de redução de peso corporal favoreceu o grupo que realizou atividades<br>físicas iguais ou superiores a 150 min/semana. Entretanto, o conjunto de estudos apresentou heterogeneidade estatisticamente significativa;|
|● Incerto|· A prática de exercícios físicos igual ou superior a 150 min/semana foi favorável à redução de gordura corporal em indivíduos do sexo masculino. Em mulheres, o resultado<br>foi controverso. ·|
||· Observou-se tendência de redução de pressão arterial com a prática de exercícios físicos por período superior a 150 min/ semana. Indivíduos que praticaram exercícios<br>físicos por períodos iguais ou superiores a 225 min/semana apresentaram redução significativa de pressão arterial e frequência cardíaca.|
||· Não foi observada diferença estatisticamente significante entre grupos que praticaram exercícios físicos >150 min/ semana e o grupo se manteve sedentário quanto a<br>alterações no perfil lipídico.|
||· Resultados de estudos individuais foram controversos quanto à eficácia da prática de exercícios físicos > 150 min/ semana sobre glicemia e níveis de insulina.<br>· Resultados de segurança não foram relatados nos estudos.|  
158  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUI|SA<br>CONSIDERAÇÕE|S ADICIONAIS|||||
|---|---|---|---|---|---|---|---|
|● Muito Baixa<br>○ Baixa<br>○ Moderada<br>○ Alta<br>○ Sem estudos incluídos||||||||
||**Desfechos**|**Efeitos absolutos potenciais**<sup>*****</sup>|**(95% CI)**|**Efeito**<br>**relativo**|**№ de**<br>**participantes**|**Certainty of the**<br>**evidence**|**Comentários**|
|||**Risco com não realizar**<br>**exercícios físicos**|**Risco com programas de exercício com**<br>**duração igual ou superior a 150 min**<br>**semanais**|**(95% CI)**|**(estudos)**|**(GRADE)**||
||a.<br>Alta heter<br>b.<br>Intervalo<br>c.<br>Alto risco<br>Alteração de peso<br>corporal médio (Kg)|ogeneidade estatística pel<br>de confiança das estimativ<br>de viés pela ferramenta da<br>A média alteração de peso<br>corporal médio (Kg) foi**0**Kg|o teste I²<br>as individuais e estimativa da meta-<br>Cochrane<br>MD**1.41 Kg menor**<br>(2.21 menor para 0.61 menor)|análise con<br>-|siderados grand<br>588<br>(7 ECRs)|es<br>⨁◯◯◯<br>MUITO<br>BAIXA<sup>a,b,c</sup>||
|Valores<br>Existe importante incerteza ou<br>JULGAMENTO|variabilidade acerca de q<br>EVIDÊNCIAS DE PESQUI|uanto as pessoas valorizam os re<br>SA<br>CONSIDERAÇÕE|sultados primários?<br>S ADICIONAIS|||||
|○ Importante incerteza ou<br>variabilidade|· A prática de exercício|físico normalmente é bem vista e|aceita pelamaioria da população.|||||
|○ Possível Importante<br>incerteza ou variabilidade|. A prática regular de e|xercícios físicos e por tempos pro|longados (iguais ou superiores a 150 min/sem|ana) podem s|er inviáveis dada a|rotina individual;||  
159  
|● Provavelmente nenhuma<br>Importante incerteza ou|. Para a população geral, existem estudos mostrando que a prática de exercícios físicos intensos em 15 min/dia, reduz a mortalidade por qualquer causa, cardiovascular,<br>por cancer e por outras comorbidades (1). No entanto, não falam sobre obesidade.|
|---|---|
|variabilidade||
|○ Sem importante incerteza<br>ou variabilidade||
||1. Chi Pang Wen*, Jackson Pui Man Wai*, Min Kuang Tsai, Yi Chen Yang, Ting Yuan David Cheng, Meng-Chih Lee, Hui Ting Chan, Chwen Keng Tsao, Shan Pou Tsai, Xifeng Wu. Minimum<br>amount of physical activity for reduced mortality and extended life expectancy: a prospective cohort study. Lancet 2011; 378: 1244–53|  
#### Balanço dos efeitos  
O balanço entre efeitos desejáveis e indesejáveis favorece a intervenção ou o comparador?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Favorece o comparador|· Os resultados sugerem que programas mais longos de exercícios físicos apresentam melhores resultados;|
|○ Provavelmente favorece o<br>comparador|· Foi possível observar benefício do exercício físico para os parâmetros de gordura corporal em cinco estudos;|
|○ Não favorece um e nem o<br>outro<br>○ Provavelmente favorece a|· Em um dos estudos que avaliaram pessoas com pressão alta e hipertensão foi observado benefício de 225 min/semana de exercícios aeróbicos e de 225 min/semana de<br>exercícios aeróbicos e de resistência na diminuição da pressão arterial;|
|intervenção|· Com relação ao perfil lipídico e níveis de glicose e insulina não é possível afirmar que houve efeito da intervenção.|
|○ Favorece a intervenção||
|○ Variável||
|● Incerto||  
###### Equidade  
Qual seria o impacto em equidade em saúde?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Reduzida|· A prática de exercícios físicos regular e por períodos prolongados provavelmente seria possível apenas para indivíduos mais favorecidos economicamente;|
|○ Provavelmente reduzida<br>○ Provavelmente nenhum<br>impacto|. A redução de peso e, consequentemente, a melhoria de comorbidades relacionadas à obesidade, promovem maior inserção do indivíduo obeso na sociedade,<br>acerretando em redução de despesas em saude e maior produtividade.|
|○ Provavelmente aumentada||
|○ Aumentada||
|○ Variável||
|○ Incerto||  
160

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 6 - PERGUNTA PICO 5** -->
||||**J**|**ULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Não sabe|
|**EFEITOS DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande||Varia|Não sabe|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|Trivial||Varia|**Incerto**|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos<br>incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a<br>comparação|Provavelmente<br>favorece a<br>comparação|Não favorece nem a<br>intervenção e nem a<br>comparação|Provavelmente<br>favorece a intervenção|Favorece a<br>intervenção|Varia|**Incerto**|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|Provavelmente sem<br>impacto|Provavelmente<br>aumentada|Aumentada|Varia|Incerto|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 6 - PERGUNTA PICO 5** -->
|Recomendação forte contraa|Recomendação condicionalcontraa|Não favorece uma ou outra|**Recomendação condicional a favor da**|Recomendação forte a favor da|
|---|---|---|---|---|
|intervenção|intervenção||**intervenção**|intervenção|
|○|○|○|**●**|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 6 - PERGUNTA PICO 5** -->
#### Recomendação  
Apesar da baixa qualidade da evidência disponível, baseado na expertise do grupo de painelistas, recomenda-se a prática de exercícios (práticas corporais) combinados de no mínimo 150 minutos semanais com benefícios adicionais para maiores durações.  
161

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
**Questão de pesquisa: “Qual a eficácia comparativa entre exercícios aeróbicos, resistidos e combinados na perda de peso e no risco cardiovascular em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era a prática de exercício físico aeróbico, de resistência ou a combinação dos dois (C) eram um tipo de exercício vs. o outro; e desfechos (O) Alteração com relação à linha de base no peso corpóreo, no IMC, na medida da circunferência da cintura, gordura corporal, massa magra, perfil lipídico, pressão arterial, glicose e insulina.  
###### **A. Estratégia de busca**  
**<u>Quadro W.</u>** Estratégia de busca de evidências em base de dados  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|(((((("Resistance Training"[Mesh] OR resistance training OR<br>resistance exercise OR resistance training exercise OR strength<br>exercise OR strength training OR strength building exercises OR<br>strength building training OR endurance exercise OR endurance<br>training OR weight-lifting strengthening program OR weight lifting<br>strengthening program OR weight lifting exercise program OR<br>weight bearing strengthening program OR weight bearing exercise<br>program OR isometric exercise)) OR ("Exercise"[Mesh] OR aerobic<br>exercise OR aerobic training OR aerobic fitness))) AND<br>("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND ((("Weight Loss"[Mesh] OR weight loss OR<br>weight reduction)) OR (("Risk Factors"[Mesh] OR<br>"Prognosis"[Mesh] OR risk factor* OR prognos*) AND<br>("Cardiovascular System"[Mesh] OR "Cardiovascular<br>Diseases"[Mesh] OR cardiovascular diseases OR cardiovascular))))<br>AND ((randomized controlled trial[pt] OR controlled clinical<br>trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as<br>topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT<br>(animals[mh] NOT humans [mh])))|3.110|
||Data da busca: 26/02/2019||
|**EMBASE**|('resistance training'/exp OR 'resistance training' OR 'resistance<br>exercise'/exp OR 'resistance exercise' OR 'muscle strength'/exp OR<br>'muscle strength' OR 'resistance training exercise' OR 'strength<br>exercise'/exp OR 'strength exercise' OR 'strength training'/exp OR<br>'strength training' OR 'strength building exercises' OR 'strength<br>building training' OR 'endurance exercise'/exp OR 'endurance<br>exercise' OR 'endurance training'/exp OR 'endurance training' OR<br>'weight-lifting strengthening program' OR 'weight lifting<br>strengthening program' OR 'weight lifting exercise program' OR<br>'weight bearing strengthening program' OR 'weight bearing<br>exercise program' OR 'isometric exercise'/exp OR 'isometric<br>exercise') AND [embase]/lim<br>OR|681|  
162  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
||('exercise'/exp OR 'exercise' OR 'aerobic exercise'/exp OR 'aerobic<br>exercise' OR 'aerobic training'/exp OR 'aerobic training' OR<br>'aerobic fitness'/exp OR 'aerobic fitness') AND [embase]/lim<br>AND<br>('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight loss'/exp<br>OR 'weight loss' OR 'weight reduction'/exp OR 'weight reduction')<br>AND [embase]/lim<br>OR<br>('cardiovascular risk factor'/exp OR 'cardiovascular risk factor' OR<br>'cardiovascular risk'/exp OR 'cardiovascular risk') AND<br>[embase]/lim<br>AND<br>((double NEXT/1 blind*):de,ab,ti) OR placebo*:ab,ti OR blind*:ab,ti<br>Data da busca: 26/02/2019||  
###### **B. Seleção da evidência**  
A busca das evidências resultou em 3.791 referências (3.110 no MEDLINE e 681 no EMBASE). Destas, 216 foram excluídas por estarem duplicadas. Um total de 3.575 referências foram triadas por meio da leitura de título e resumos, das quais 20 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo avaliava participantes portadores de sobrepeso ou obesidade. Foram incluídos estudos que abordassem pelo menos duas modalidades de exercícios dentre as avaliadas (exercícios aeróbicos, exercícios de resistência ou exercícios combinados) associados ou não a dieta ou modificação de comportamento. Os pacientes poderiam apresentar, além de sobrepeso ou obesidade, diabetes, hipertensão e/ou síndrome metabólica. Foram considerados para inclusão estudos publicados em inglês, espanhol ou português.  
Não foram incluídos estudos em que uma das modalidades de exercício avaliadas fossem associadas à dieta ou modificação de comportamento e a outra não. Quando havia disponível vários artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia as alterações no peso corpóreo, IMC, medida da circunferência da cintura desde a linha de base. Como desfechos secundários foram considerados as alterações da gordura corporal, pressão arterial, frequência cardíaca, perfil lipídico, e glicose e insulina.  
Dos 20 estudos que foram lidos na íntegra, cinco foram excluídos: um estudo incluiu pacientes com histórico de infarto do miocárdio, intervenção coronariana percutânea, angina estável crônica, cirurgia cardiovascular ou diagnóstico ATP III de síndrome metabólica<sup>270</sup> ; um relato de estudo incluído que não avaliou desfechos analisados neste relatório<sup>271</sup> ; um estudo que avaliou o efeito de exercícios para prevenir o reganho de peso<sup>272</sup> ; um se trata de avaliação de pacientes  
163  
incluídos em dois ensaios clínicos incluídos para comparar homens e mulheres<sup>273,274</sup> ; e um estudo não é descrito como randomizado<sup>275</sup> .  
No final, foram incluídos 12 ensaios clínicos randomizados (15 relatos) que avaliaram a eficácia de modalidades exercícios físicos em indivíduos portadores de sobrepeso ou obesidade ( **Figura O** ) e seus dados se encontram relatados a seguir<sup>240,264,267,269,273,274,276–284</sup> .  
**Figura O.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 3.791<br>PUBMED = 3.110<br>EMBASE= 681<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>3.575  critérios de exclusão: 3.555<br>Publicações excluídas segundo<br>critérios de exclusão: 5<br>Publicações selecionadas para leitura<br>completa: 20  Tipo de delineamento: 04<br>Tipo de participante: 01<br>Estudos incluídos: 12 estudos<br>C. Descrição dos estudos e resultados<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
A descrição sumária dos estudos incluídos encontra-se no **Tabela P.** A caracterização dos participantes de cada estudo pode ser vista na **Tabela Q.** Resultados encontram-se nas **Tabelas R** a **V** . Nas **Figuras P** e **Q** , podem ser vistas as meta-análises realizadas para redução de peso corporal de acordo com a modalidade de exercício físico. A avaliaça6o do risco de viés dos estudos incluídos está ilustrada na **Figura R** . Nos **Quadros X e Y** constam as avaliações da qualidade da evidência, gerada a partir do corpo de evidências. Estas tabelas correspondem à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. A sumarização dos principais domínios avaliados pode ser vista no **Quadro Z** , que corresponde à Tabela _Evidence to Decision_ (EtD), também criada no _webapp_ GRADE Pro GDT.  
164  
**Tabela P** . Características dos ensaios clínicos randomizados incluídos para avaliar a eficácia de exercícios aeróbicos, de resistência ou combinados <u>(aeróbicos e de resistência) em indivíduos com sobrepeso ou obesidade.</u>  
|**Autor**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenções**|**Controle**|**Tempo de**<br>**intervenção**|**Tempo de avaliação**|
|---|---|---|---|---|---|---|
|Ross et al<br>(1996)<sup>273</sup><br>e Rice et al<br>(1999)<sup>281</sup>|Avaliar dois programas de exercícios na redução<br>de peso, composição corporal e perfil glicêmico<br>em homens com obesidade|33/30*|Exercícios aeróbicos + dieta<br>Exercícios de resistência + dieta|Sedentário<br>+ dieta|16 semanas|16 semanas|
|Geliebter et al<br>(1997)<sup>277</sup>|Avaliar dois programas de exercícios de mesmo<br>gasto calórico na perda de peso de homens e<br>mulheres com obesidade.|69|Exercícios aeróbicos + dieta<br>Exercícios de resistência + dieta|Sedentário<br>+ dieta|8 semanas|8 semanas|
|Janssen et al<br>(2002)<sup>274</sup>|Avaliar dois programas de exercícios na redução<br>depeso em mulheres com obesidade|38|Exercícios aeróbicos + dieta<br>Exercícios de resistência + dieta|Sedentário<br>+ dieta|16 semanas|16 semanas|
|Cuff et al (2003)|Avaliar dois programas de exercícios na mudança||Exercícios aeróbicos|Cuidado|||
|276|da composição corporal de mulheres na pós-<br>menopausa com obesidade e diabetes tipo 2|28|Exercícios de resistência e aeróbicos|usual|16 semanas|16 semanas|
|Park et al (2003)<br>240|Avaliar dois programas de exercícios na redução<br>depeso em mulheres de com obesidade|30|Exercícios aeróbicos<br>Exercícios de resistência e aeróbicos|Controle|24 semanas|24 semanas|
||||Exercícios de resistência||||
|Schjerve et al|Avaliar três programas de exercícios na redução||Exercícios aeróbicos contínuos de intensidade||||
|(2008)<sup>282</sup>|do peso corporal em homens e mulheres obesos|40|moderada<br>Exercícios aeróbicos intervalados de alta<br>intensidade|-|12 semanas|12 semanas|
||Avaliar o efeito de três programas de exercícios||Exercícios aeróbicos||||
|Davidson et al<br>(2009)<sup>264</sup>|na perda de peso e diminuição e fatores de risco<br>para doenças e incapacidade em homens e<br>mulheres com obesidade abdominal.|100|Exercícios de resistência<br>Exercícios de resistência e aeróbicos|Sedentário|6 meses|6 meses|
||Avaliar o efeito de dois programas de exercício||||||
|Lucotti et al<br>(2011)<sup>280</sup>|na perda de peso e mudança da composição<br>corporal em homens e mulheres com obesidade<br>grave, diabetes tipo 2 e síndrome metabólica|47|Exercícios aeróbicos + dieta<br>Exercícios de resistência e aeróbicos + dieta|-|21 dias|21 dias|
|STRRIDE AT/RT|Avaliar três programas de exercício na ingestão||Exercícios aeróbicos||||
|284|alimentar e peso corporal em indivíduos com<br>sobrepeso ou obesidade|119/86**|Exercícios de resistência<br>Exercícios aeróbicos e de resistência|-|8 meses|8 meses|
|Ho et al (2012)|Avaliar o efeito de três programas de exercício<br>na mudança do perfil de risco cardiovascular de||Exercícios aeróbicos|Sedentário<br>em uso de|||  
165  
|267,283|indivíduos com sobrepeso ou obeso com idade<br>entre 40 e 66 anos.|80|Exercícios de resistência<br>Exercícios aeróbicos e de resistência|suplemento<br>alimentar<br>placebo|12 semanas|12 semanas|
|---|---|---|---|---|---|---|
|Herring et al|Avaliar o efeito de dois programas de exercícios||Exercícios aeróbicos||||
|(2014)<sup>278</sup>|na mudança de peso corporal e composição<br>corporal em homens e mulheres com obesidade.|27|Exercícios de resistência|Sedentário|12 semanas|12 semanas|  
166  
|**Autor**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenções**|**Controle**|**Tempo de**<br>**intervenção**|**Tempo de avaliação**|
|---|---|---|---|---|---|---|
|Schroeder et al<br>(2019)<sup>269</sup>|Avaliar o efeito de três programas de exercícios<br>na mudança da pressão arterial e fatores de risco<br>cardiovascular em indivíduos obesos com<br>pressão alta ou hipertensão.|69|Exercícios aeróbicos<br>Exercícios de resistência<br>Exercícios aeróbicos e de resistência|Sedentário|8 semanas|8 semanas|  
- Foram incluídos dois relatos desse estudo, um avaliou 33 participantes, e o outro avaliou 30 participantes. Foram excluídos participantes para melhorar a comparabilidade segundo características da linha de base  
** Foram incluídos dois relatos desse estudo, um avaliou pacientes 119 participantes, e o outro avaliou 86 participantes com síndrome metabólica  
###### **Tabela Q.** Características basais dos participantes dos estudos que avaliaram a eficácia de exercícios aeróbicos, de resistência ou combinados <u>(aeróbicos e de resistência) em indivíduos com sobrepeso ou obesidade.</u>  
|**Autores**|**Grupos**|**N**|**Idade (anos)**<br>**média (DP)**|**Sexo**<br>**masc, N**<br>**(%)**|**IMC (%)**<br>**média (DP)**|**Peso (Kg)**<br>**média (DP)**|**Circunferência da cintura**<br>**(cm)**<br>**média(DP)**|
|---|---|---|---|---|---|---|---|
||||**Homens e mul**|**heres 18-70 anos de**<br>|**idade**|||
|STRRIDE|Exercícios aeróbicos|38|52,0(8,9)|17(44,7)|30,6(3,2)|88,0(11,1)|96,1(10,25)|
|<br>AT/RT<sup>284</sup>|Exercícios de resistência|44|50,1(11,6)|18(41,0)|30,5(3,4)|88,7(15,6)|93,6(9,06)|
||Exercícios aeróbicos e de resistência|37|47,0(10,3)|16(43,2)|30,5(3,4)|88,9(11,5)|97,3(8,89)|
||||Homens e mul|heres 19-49 anos de|idade|||
|Geliebter et|Controle sedentário + dieta|22|36(8)|8(36,4)|NR|97,6(19,9)|NR|
|<br>l 1997<sup>277</sup>|Exercícios aeróbicos + dieta|23|36(7)|9(39,1)|NR|96,0(23,0)|NR|
|a ()|Exercícios de resistência + dieta|20|35(6)|8(40,0)|NR|101,0(21,9)|NR|
||||**Homens e m ul**|**heres 24-68 anos de**|**i dade**|||
||Controle sedentário|7|||48,6 (7,8)|134,0 (28,8)|133,8 (14,7)|
|Herring et al<br><sup>278</sup>|Exercícios aeróbicos|10|24 a 68|8 (29,6)|44,4 (4,4)|127,0 (21,3)|124,9 (18,2)|
|(2014)||||||||
||Exercícios de resistência|10|||41,5 (5,2)|120,4 (22,5)|123,7 (16,5)|
||||**Homens e mu**|**lheres ~45 anos de**|<br>**idade**|||
||Exercícios de resistência|13|46,2(EP 2,9)|2(15,4)|34,5(EP 1,4)|98,8(EP 4,5)|NR|
|l 2008<sup>282</sup><br>Schjerve et|Exercícios aeróbicos contínuos de intensidade<br>moderada|13|44,4 (EP 2,1)|3 (23,1)|36,7 (EP 1,4)|104,1 (EP 4,5)|NR|
|a ()|Exercícios aeróbicos intervalados de alta<br>|14|46,9 (EP 2,2)|3 (21,4)|36,6 (EP 1,2)|114,0 (EP 5,7)|NR|
||intensidade||**Homens e mul**|**heres 45-66 anos de**|**idade**|||
|Ho et al|Controle sedentário|16|52(EP 7,2)|1(6,2)|32,4(EP 5,6)|85,1(EP 16,8)|100,3(EP 14,4)|
||Exercícios aeróbicos|15|55 (EP 4,6)|3 (20,0)|32,7 (EP 5,0)|91,9 (EP 15,9)|<br>103,7 (EP 10,1)|
||Exercícios de resistência|16|52(EP 4,4)|3(18,7)|33(EP 5,2)|89,3(EP 18)|~~167~~<br>104(EP 12,8)|  
(2012)<sup>267,283</sup>  
168  
|**Autores**|**Grupos**|**N**|**Idade (anos)**<br>**média (DP)**|**Sexo**<br>**masc, N**<br>**(%)**|**IMC (%)**<br>**média (DP)**|**Peso (Kg)**<br>**média (DP)**|**Circunferência da cintura**<br>**(cm)**<br>**média(DP)**|
|---|---|---|---|---|---|---|---|
||Exercícios aeróbicos e de resistência|17|53 (EP 5,4)|3 (17,6)|33,3 (EP 4,9)|90 (EP 16,5)|102,2 (EP 13,2)|
||||**Homens e mulh**<br>|**eres 60-80 anos d**|**e idade**|||
||Controle sedentário|28|Homens: 67,4 (3,8)<br>Mulheres: 66,7 (3,7)<br>|11 (38)|Homens: 30,5 (2,0)<br>Mulheres: 30,4(3,2)<br>|NR|Homens: 112,8 (5,3)<br>Mulheres: 104,9(7,4)<br>|
|Davidson et|Exercícios aeróbicos|37|Homens: 68,8 (6,0)<br>Mulheres:69,1 (6,5)|17 (46)|Homens: 29,9 (3,0)<br>Mulheres: 29,2(3,7)<br>|NR|Homens: 113,0 (7,9)<br>Mulheres: 104,2(10,4)<br>|
|al (2009)<sup>264</sup>|||<br>Homens: 67,4 (5,7)||~~Homens: 30,1 (2,6)~~||~~Homens: 111,0 (5,4)~~|
||Exercícios de resistência|36|Mulheres: 67,6 (4,2)||Mulheres: 30,0 (3,4)|NR|Mulheres: 104,3 (8,5)|
||Exercícios de resistência e aeróbicos|35|Homens: 67,1 (4,5)<br>Mlh 665 (53)|14 (40)|Homens: 31,1 (3,1)<br>|NR|Homens: 114,1 (8,3)<br>|
||||ueres: , ,||~~Mulheres: 29,5 (3,0)~~||~~Mulheres: 102,8 (9,6)~~|
||||**Mul**|**heres adultas**||||
||Dieta|13|40,1(6,7)|0 (0)|33,7 (4,1)|90,8(14,5)|100,8(12,5)|
|Janssen et al<br>(2002)<sup>274</sup>|Exercícios aeróbicos + dieta|11|37,5 (6,0)|0 (0)|36,0 (7,1)|99,9 (19,9)|101,9 (13,9)|
||Exercícios de resistência + dieta|14|34,8(5,8)|0 (0)|31,6 (4,3)|86,1 (10,5)|95,6 (9,0)|
||||**Mulheres 4**|**0-45 anos de ida**|**de**|||
||Controle|10|43,1 (1,67)|0 (0)|25,5 (0,86)|65,2 (1,87)|NR|
|Park et al<br>(2003)<sup>240</sup>|Exercícios aeróbicos|10|42,2 (1,91)|0 (0)|25,3 (1,74)|63,7 (3,58)|NR|
||Exercícios de resistência e aeróbicos|10|43,4 (1,04)|0 (0)|25,8 (1,43)|67,5 (5,10)|NR|
||||**Hom**|**ens adultos**||||
||Dieta|11|46,8 (7,6)|11 (100)|31,6 (2,7)|NR|110,7 (7,8)|
|Ross et al<br>(1996)<sup>273</sup>|Exercícios aeróbicos + dieta|11|47,6 (6,4)|11 (100)|32,6 (3,6)|NR|114,4 (7,9)|
||Exercícios de resistência + dieta|11|39,0 (12,9)|11 (100)|33,5 (4,1)|NR|117,9 (10,3)|
||Dieta|9|44,4 (6,1)|9 (100)|31,9 (2,8)|99,1 (11,2)|106,9 (7,3)|
|Rice et al<br>(1999)<sup>281</sup>|Exercícios aeróbicos + dieta|10|47,4 (6,7)|10 (100)|32,3 (3,7)|100,9 (12,7)|113,4 (7,7)|
||Exercícios de resistência + dieta|10|39,8 (13,2)|10 (100)|33,8 (4,2)|109,9 (9,2)|118,5 (10,7)|
|||**Hom**|**ens e mulheres 18-70 an**|**os de idade com s**|**índrome metabólica**|||
||Exercícios aeróbicos|30|51,1(9,49)|16(53,3)|30,8(3,20)|89,3(10,8)|104(10,1)|
|STRRIDE<br>AT/RT<sup>284</sup>|Exercícios de resistência|31|51,8(11,0)|16(51,6)|30,3(3,10)|89,2(14,5)|104(9,68)|
||Exercícios combinados(aeróbicos e resistência)|25|45,8(11,8)|21(84,0)|30,4(3,76)|90,1(13,2)|103(11,2)|
|||**Homen**|**s e mulheres 45-74 anos d**|**e idade compre**|**ssão alta ou hipertensão**|||
||Controle|17|58 (6)|6 (35,3)|32,4 (3,7)|97,1 (20,7)|106 (10)|
|Schroeder et|Exercícios aeróbicos|17|58 (7)|7 (41,2)|32,5 (5,9)|95,8 (21,2)|103 (14)|
|al (2019)<sup>269</sup>|Exercícios de resistência|17|57 (9)|7 (41,2)|33,1 (5,9)|93,6 (18,9)|106 (17)|  
169  
Exercícios de resistência aeróbicos e  
58 (7)  
7 (38,9)  
31,9 (5,5)  
91,4 (16,0)  
104 (13)  
18  
170  
|**Autores**|**Grupos**|**N**|**Idade (anos)**<br>**média (DP)**|**Sexo**<br>**masc, N**<br>**(%)**|**IMC (%)**<br>**média (DP)**|**Peso (Kg)**<br>**média (DP)**|**Circunferência da cintura**<br>**(cm)**<br>**média(DP)**|
|---|---|---|---|---|---|---|---|
|||**Homens e mulh**|**eres adultos com obesi**|**dade grave, diabete**|**s tipo 2 e síndrome metabólica**|||
|Lucotti et al|Exercícios aeróbicos + dieta|27|58,1 (9,9)|10 (37)|38,8(4,5)|103,9 (17,7)|114,3(10,4)|
|(2011)<sup>280</sup>|+ dieta<br>Exercícios combinados (aeróbicos e resis|tência)<br>20|61,5 (11,5)|7 (35)|39,9 (7,3)|106,6(20,8)|118,6 (11,6)|
||||**Mulheres na pós-m**|**enopausa com diab**|**etes tipo 2**|||
||Controle|9|60,0 (EP 2,9)|0 (0)|36,7 (EP 2,0)|95,6 (EP 6,5)|119,0 (EP 2,1)|
|Cuff et al<br>(2003)<sup>276</sup>|Exercícios aeróbicos|9|59,4 (EP 1,9)|0 (0)|32,5 (EP 1,4)|81,2 (EP 3,8)|106,1 (EP 2,3)|
||Exercícios aeróbicos e de resistência|10|63,4 (EP 2,2)|0 (0)|33,3 (EP 1,5)|89,5 (EP 3,9)|111,1 (EP 2,1)|  
**Legenda:** EP: Erro padrão, DP: Desvio-padrão; NR: não relata  
**Tabela R.** Resultados de Índice de Massa Corporal (IMC), peso corporal e medidas de cintura e quadril dos estudos incluídos que avaliaram programas de exercício físico aeróbicos, de resistência e combinados (aeróbicos e de resistência) em indivíduos obesos ou com sobrepeso.  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de IMC**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de peso (Kg)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de medida**<br>**de cintura (cm)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de**<br>**medida de quadril**<br>**(cm)**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||**Homens e mulh**|**eres 18-70**|**anos de idade**||||||
||Exercícios aeróbicos|38||NR||-1.76 (3.00)|<0,0<br>5 vs.|-1.01 (2.91)||NR||
|STRRIDE|Exercícios de resistência|44|8 meses|NR||0.83 (2.32)|res.|-0.06 (1.96)||NR||
|AT/RT<sup>284</sup>|Exercícios aeróbicos e de resistência|37||NR<br>**Homens e mulh**|**eres 19-49**|-1.63 (3.17)<br>**anos de idade**|<0,0<br>5 vs.<br>res.|-1.66 (2.65)|<0,0<br>5 vs.<br>res.|NR||
|Geliebter|Exercícios aeróbicos + dieta|23||NR||-9.6(4.5)||NR||NR||
|et al (1997)|||8 semanas||||NS|||||
|277|Exercícios de resistência + dieta|20||NR||-7.8 (3.8)||NR||NR||
|<br>|<br>|<br>||<br>**Homens e mulh**<br>|**eres 24-68**|<br>**anos de idade**<br>||<br>||<br>||
|Herring et|Exercícios aeróbicos|10|12|-1,8|NS|-5,5|NS|-4,3|NS|-5,6|NS|
|al (2014)<sup>278</sup>|Exercícios de resistência|10|semanas|-1,0||-2,9||-3,7||-4,7||
||||||||||||171|  
|||**Homens e mulheres ~45 anos de idade**||
|---|---|---|---|
|Schjerve et<br>Exercícios de resistência|13<br>12 semanas|0<br>NR<br>0|NR<br>NR<br>NR|  
172  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de IMC**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**Média (DP)**<br>**Valo**<br>**r p**|**Mudança de peso (Kg)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de medida**<br>**de cintura (cm)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de**<br>**medida de quadril**<br>**(cm)**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|
|al (2008)<sup>282</sup>|Exercícios aeróbicos contínuos de<br>intensidade moderada|13||-1,1|-3%||NR||NR||
||Exercícios aeróbicos intervalados de<br>alta intensidade|14||-0,6|-2%||NR||NR||
|||||**Homens e mulheres 45-66**|**anos de idade**||||||
||Exercícios aeróbicos|15||-0,3|-0,9||-2,1||NR||
|Ho et al|Exercícios de resistência|16||0|-0,1||-2,6||NR||
|(2012)<sup>267,283</sup>|||12 semanas|<0,0||<0,0||NR|||
||Exercícios aeróbicos e de resistência|17||-0,5<br>5 vs.<br>res.|-1,6|5 vs.<br>res.|-2,6||NR||
|||||**Homens e mulheres 60-80**|**a os de idade**||||||
|||||<0,0||<0,0||<0,0|||
||Exercícios aeróbicos|37||-0,96 (EP 0,7)<br>5 vs.|-2,77 (EP 2,0)|5 vs.|-5,08 (EP 2,8)|5 vs.|NR||
|||||res.||res.||res.|||
|Davidson et<br>al (2009)<sup>264</sup>|Exercícios de resistência|37|6 meses|-0.26(EP 0.12)|-0.64(EP 0.37)||-3.18(EP 0.49)||NR||
|||||<0,0||<0,0|||||
||Exercícios de resistência e aeróbicos|35||-0,84 (EP 0,7)<br>5 vs.|-2,31 (EP 1,9)|5 vs.|-4,61 (EP 2,8)||NR||
|||||res.<br>**Mulheres adul**<br>|**tas**<br>|res.|||||
|Janssen et|Exercícios aeróbicos + dieta|11|16 semana~~s~~|-4.2 (1.2)<br>~~N~~S|-11.1 (4.4)<br>|~~N~~S|-7.3 (5.4)<br>|NS|NR||
|al(2002)<sup>274</sup>|Exercícios de resistência + dieta|14||-3.9(1.0)|-10.0(3.0)||-8.5(2.3)||NR||
|||||**Mulheres 40-45 anos**<br>|**de idade**<br>||||||
|Park et al|Exercícios aeróbicos|10||NR|-4,7||NR||NR||
|(2003)<sup>240</sup>|Exercícios de resistência e aeróbicos|10|24 semanas|NR|-6.4|NS|NR||NR||
|||||<br>**Homens adult**|<br>**os**||||||
|Ross et al|Exercícios aeróbicos + dieta|11|16 semanas|NR|-11.6(3.7)|N~~R~~|-12.9 (4.0)<br>|N~~R~~|-8.0 (4.5)|NR|
|(1996)<sup>273</sup>|Exercícios de resistência + dieta|11||NR|-132(41)||-119(40)||-72(18)||
||<br>|<br>|**Home**<br>|<br>**ns e mulheres 18-70 anos de idad**<br>|..<br>**e com síndrome metabóli**<br>|**ca**<br>|..<br>||..<br>||
||Exercícios aeróbicos|30|8 meses|NR|-1.54(2.59)|NR|-1.12 (3.20)||NR||
|AT/RT<sup>284</sup><br>STRRIDE|Exercícios de resistência|31||NR|0.70(2.36)||0.25 (2.45)||NR||
||Exercícios de resistência e aeróbicos|25||NR|-190(359)||-248(378)||NR||
||||**Homens**|<0,0<br> <br> <br>**e mulheres 45-74 anos de i dade c**|, ,<br>**ompressão alta ou hipert**|<0,0<br> <br>**ensão**|, ,||||
||Exercícios aeróbicos|17||-0,3 (IC95% -0,7 a 0,0)<br>5 vs.<br>com|-1,0 (IC95% -1,9 a -0,1)|5 vs.<br>com|0,4 (IC95% -1,2 a 2,0)||NR||
|Schroeder|||||||||||
|et al|||8 semanas|b.||b.|||||
|<br>(2019)*<sup>269</sup>||||||||<0,0|||
||Exercícios de resistência|17||-0,1 (IC95% -0,5 a 0,2)|-0,2 (IC95% -1,1 a 0,7)||-1,7 (IC95% -3,3 a -0,1)|5 vs.<br>com|NR||  
173  
b. e  
174  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de IMC**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de peso (Kg)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de medida**<br>**de cintura (cm)**<br>**Média (DP)**|**Valo**<br>**r p**|**Mudança de**<br>**medida de quadril**<br>**(cm)**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||vs.<br>aer.|||
||Exercícios aeróbicos e de resistência|18||0,2(IC95% -0,1 a 0,6)||0,9(IC95% 0,0 a 1,8)||0,9(IC95% -0,7 a 2,5)||NR||
||||**Homens**|**e mulheres adultos com**|**diabete**|**s tipo 2 e síndrome metab**|**ólica**|||||
|Lucotti et al|Exercícios aeróbicos + dieta<br>|27||-1,3||-3,4||-8||-2,1||
|<br>(2011)<sup>280</sup>|Exercícios de resistência e aeróbicos<br>+ dieta|20|21 dias|-1,3|NS|-3,4|NS|-6|NS|-3,5|NS|
|||||**Mulheres napós-men**|**opausa c**|**om diabetes tipo 2**||||||
|Cuff et al|Exercícios aeróbicos|9||NR||-1.2 (EP 0.7)||NR||NR||
|(2003) <sup>276</sup>|Exercícios aeróbicos e de resistência|10|<sup>16 semanas</sup>|NR||-2.9 (EP 1.3)|NS|NR||NR||  
**Legenda:** IC95%: intervalo de confiança de 95%; aer: exercícios aeróbicos; comb: exercícios combinados (aeróbicos e de resistência) DP: Desvio-padrão; EP: Erro-padrão; NR: não reportado; NS: não estatisticamente significante; res: exercícios de resistência. * Resultados ajustados por sexo, idade, e valores da linha de base  
**Tabela S.** Resultados de alteração na composição corporal dos estudos incluídos que avaliaram programas de exercício físico aeróbicos, de resistência e combinados (aeróbicos e de resistência) em indivíduos obesos ou com sobrepeso.  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de gordura corporal**<br>**Valor**<br>**Média (DP)**<br>**p**|**Mudança de gordura**<br>**intra-abdominal**<br>**Média(DP)**|**Valor**<br>**p**|**Mudança de gordura**<br>**abdominal subcutânea**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**Ho**|**mens e mulheres 18-70 anos de idade**|||||
||Exercícios aeróbicos|38||-1,66 (2,67) Kg|NR||NR||
|||||-1,01 (1,92)%<br>|||||
||Exercícios de resistência|44||-0,26 (2,16) Kg|NR||NR||
|STRRIDE||||-0,65 (1,70)%|||||
|<br>AT/RT<sup>284</sup>|||8 meses|<0,05|||||
||Exercícios combinados (aeróbicos e<br>resistência)|37||-2,44 (2,97) Kg<br>-2,04 (2,23)%<br>vs,<br>res, e<br>vs,|NR||NR||
|||||aer,|||||
||||**Ho**|**mens e mulheres 19-49 anos de idade**|||||
|Geliebter et|Exercícios aeróbicos + dieta|23||-7,2 (3,0) Kg<br>|NR||NR||
|al(1997) <sup>277</sup>|Exercícios de resistência + dieta|20|8 semanas|6,7 (2,8) Kg<br>NS|NR||NR||
||||**Ho**|**mens e mulheres ~45 anos de idade**|||||  
175  
||Exercícios de resistência|13||0%|NR|NR|
|---|---|---|---|---|---|---|
|Schjerve et|Exercícios aeróbicos contínuos de|13|12|-2,5%|NR|NR|
|al (2008)<sup>282</sup>|intensidade moderada||semanas|NR|||
||Exercícios aeróbicos intervalados de alta<br>intensidade|14||-2,2%|NR|NR|
||||**Homens e**|**mulheres 45-66 anos de idade**|||  
176  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Mudança de gordura corporal**<br>**Média (DP)**|**Valor**<br>**p**|**Mudança de gordura**<br>**intra-abdominal**<br>**Média(DP)**|**Valor**<br>**p**|**Mudança de gordura**<br>**abdominal subcutânea**<br>**Média(DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|
||Exercícios aeróbicos|15||-0,5%;-0,7 Kg||NR||NR||
||Exercícios deresistência|16||-0,5%;-0,4 Kg||NR||NR||
|Ho et al<br>|||12||<0,05|||||
|(2012)<sup>267,283</sup>|Exercícios aeróbicos e de resistência|17|semanas|-1,0%; -1,6 Kg|vs,<br>res|NR||NR||
||||**Ho**|**mens e mulheres 60-80 anos de ida**<br>|,<br>(g)<br>**de**<br><0,05|||||
||Exercícios aeróbicos|37||-3,03 (2,4) Kg|vs,|-0,43 (0,5) Kg||-0,40 (0,4) Kg||
|Davidson et<br>al (2009)<sup>264</sup>|Exercícios de resistência<br>|36|6 meses|-1,56 (0,36) Kg<br>|res,|-0,21 (0,06) Kg|NS|-0,21 (0,07) Kg<br>|NS|
||||||<0,05|||||
||Exercícios de resistência e aeróbicos|35||-3,38 (2,0) Kg|vs,<br>|-0,35 (0,3) Kg||-0,40 (0,3) Kg||
||||||res,|||||
|||||**Mulheres adultas**||||||
|Janssen et al|Exercícios aeróbicos + dieta|11|16|-9,9 (4,6) Kg||-0,61(0,41) Kg||-1,6 (0,8) Kg||
|(2002)<sup>274</sup>|Exercícios de resistência + dieta|14|semanas|-86 (24) Kg|NS|-042 (021) Kg|NS|-17 (07) Kg|NS|
|||||, ,<br>**Mulheres 40-45 anos de idade**||, ,||, ,||
|Park et al|Exercícios aeróbicos|10|24|-9,2||-82,6 cm<sup>3</sup>||-23,1 cm<sup>3</sup>||
|(2003) <sup>240</sup>|Exercícios de resistência e aeróbicos|10|semanas|-10,3|NR|<sup>3</sup>|<0,05|-61,8 cm<sup>3</sup>|<0,05|
|||||**Homens adultos**||~~-93,0 cm~~||||
|Ross et al|Exercícios aeróbicos + dieta|11|16|NR||-1,8 (1,0) L||NR||
|(1996)<sup>273</sup>|Exercícios de resistência + dieta|11|semanas||||NR|||
|||<br>**Home**|<br>**ns e mulheres**|~~NR~~<br>**45-74 anos de idade com pressão**<br>|**alta ou hip**|~~-1,4 (0,7) L~~<br>**ertensão**||~~NR~~||
|Schroeder et|Exercícios aeróbicos|17||-0,5% (IC95% -1,1 a 0,0)<br>-0,9 Kg (IC95%-1,5 a-0,2)||NR||NR||
|al (2019)*<br>269|Exercícios de resistência|17|8 semanas|-0,2% (IC95% -0,8 a 0,4)<br>-0,3 Kg (IC95%-1,0 a 0,3)|NS|NR||NR||
||Exercícios aeróbicos e de resistência|18||-0,5% (IC95% -1,0 a 0,1)<br>-0,1 Kg (IC95% -0,7 a 0,5)||NR||NR||
|||**Homens e mul**|**heres adultos**|**com obesidadegrave, diabetes tip**|**o 2 e sínd**|**rome metabólica**||||
|Lucotti et al|Exercícios aeróbicos + dieta|27||-1,9 Kg||NR||NR||  
177  
|(2011)<sup>280</sup><br>Cuff et al|Exercícios combinados (aeróbicos e<br>resistência) + dieta<br>Exercícios aeróbicos|20<br>9|21 dias<br>**Mulheres nap**<br>16|-2,8 Kg<br>**ós-menopausa com dia**<br>NR|NS<br>**betes tipo 2**|NR<br>-8,8 (EP 5,4) cm<sup>3</sup>|NR<br>-8,2 (EP 9,7) cm<sup>3</sup>|
|---|---|---|---|---|---|---|---|
|(2003) <sup>276</sup>|Exercícios aeróbicos e de resistência|10|semanas|NR||-26,3(EP 7,4)cm<sup>3</sup>|NR<br>~~-22,0 (EP 15,4) cm~~<sup>3</sup><br>NR|  
**Legenda:** IC95%: intervalo de confiança de 95%; aer: exercícios aeróbicos; comb: exercícios combinados (aeróbicos e de resistência) DP: Desvio-padrão; EP: Erro-padrão; NR: não reportado; NS: não estatisticamente significante; res: exercícios de resistência  
* Resultados ajustados por sexo, idade, e valores da linha de base  
178  
**Tabela T.** Resultados de alteração na massa magra dos estudos incluídos que avaliaram programas de exercício físico aeróbicos, de resistência e combinados (aeróbicos e de resistência) em indivíduos obesos ou com sobrepeso.  
|**Autor, ano**|**Intervenção**<br>**n**|**Tempo da**<br>**avaliação**|**Massa magra**<br>**Média(DP)**|**Valor p**|
|---|---|---|---|---|
||**Homens e mulheres 18**|**-70 anos de idade**<br>|||
||Exercícios aeróbicos<br>38||-0,10 (1,22)||
|STRRIDE AT/RT<br>284|Exercícios de resistência<br>44|8 meses|1,09 (1,54)Kg|<0,05 vs,<br>aer,|
||Exercícios aeróbicos e de<br> <br>37||0,81 (1,38)Kg|<0,05 vs,<br>|
||resistência<br>**Homens e mulheres 19**|**-49 anos de idade**||aer,|
|Geliebter et al|Exercícios aeróbicos<br>23|8 semanas|-2,3 (2,4) Kg|<005|
|(1997)<sup>277</sup>|Exercícios de resistência<br>20||-1,1 (2,3) Kg|,|
||**Homens e mulheres 60**<br> <br>|**-80 anos de idade**|||
||Exercícios aeróbicos<br>37||-0,06 (0,19) Kg||
|Davidson et al<br>(2009)<sup>264</sup>|Exercícios de resistência<br>36|6 meses|0,97 (0,20) Kg|<0,05 vs,<br>aer,|
||Exercícios de resistência e<br>aeróbicos<br>35||0,62 (0,15) Kg|<0,05 vs,<br>aer|
||<br>**Mulheres a**|**dultas**||,|
|Janssen et al|Exercícios aeróbicos + dieta<br>11|16 semanas|-0,6 (1,1) Kg|NS|
|(2002)<sup>274</sup>|Exercícios de resistência + dieta<br>14||-0,4(1,1)Kg||
||**Mulheres 40-45 a**|**nos de idade**|||
|Park et al|Exercícios aeróbicos<br>10||0,9 Kg||
|(2003)<sup>240</sup>|Exercícios de resistência e<br>aeróbicos<br>10|24 semanas|5,6 Kg|NR|
||**Homens a**|**dultos**|||
|Ross et al|Exercícios aeróbicos + dieta<br>11||-1,1 (2,5) L||
|(1996)<sup>273</sup>|Exercícios de resistência + dieta<br>11|16 semanas|-1,4 (2,5) L|NR|
||**Homens e mulheres 45-74 anos de idad**|**e compressão alta ou**|<br>**hipertensão**||
||Exercícios aeróbicos<br>17||-0,3 Kg (IC95%-1,0, 0,5)||
|Schroeder et al|Exercícios de resistência<br>17<br>|8|0,1 Kg (IC95%-0,6, 0,9)||
|(2019)*<sup>269</sup>|Exercícios aeróbicos e de|semanas||<0,05 vs,|
||~~itêi~~<br>18||0,8 Kg (IC95% 0,1, 1,5)|aer,|
||~~ressnca~~<br>**Homens e mulheres adultos com diab**|**etes tipo 2 e síndrome**|**metabólica**||
|Lucotti et al|Exercícios aeróbicos + dieta<br>27||-1,9||
|(2011)<sup>280</sup>|Exercícios de resistência e<br>aeróbicos + dieta<br>20|21 dias|-0,3|NS|  
**Legenda:** IC95%: intervalo de confiança de 95%; aer: exercícios aeróbicos; comb: exercícios combinados (aeróbicos e de resistência) DP: Desvio-padrão; EP: Erro-padrão; NR: não reportado; NS: não estatisticamente significante; res: exercícios de resistência  
* Resultados ajustados por sexo, idade, e valores da linha de base  
179  
###### **Tabela U.** Resultados de mudança no perfil lipídico dos estudos que avaliaram programas de exercício físico aeróbicos, de resistência e combinados <u>(aeróbicos e de resistência) em indivíduos obesos ou com sobrepeso.</u>  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Colesterol total**<br>**(mmol/L)**<br>**Média**|**Valor p**|**LDL-C (mmol/L)**<br>**Média**|**Valor**<br>**p**|**Triglicérides**<br>**(mg/dL)**<br>**Média**|**Valor p**|**HDL-C (mg/dL)**<br>**Média**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||**Homens e mulh**<br>|**eres (45-66 a**<br>|**nos de idade)**||||||
||Exercícios aeróbicos|15||-0,27|<0,05|-0,25||0,04||-0,1||
|Ho et al|||||vs, res,|||||||
|(2012)|Exercícios de resistência|16|12 semanas|0,96||0,52|<0,05|0,11||0,1|<0,05 vs, aer,|
|267,283|||||||vs, res,|||||
||Exercícios aeróbicos e de resistência|17||0,04||-0,07|<sup><0,05</sup><br>|0,26||-0,02||
|||||**Mu**|**lheres adulta**|**s**|vs,res,|||||
||Exercícios aeróbicos + dieta|11||-0,42 (0,55)||-0,28 (0,42)||-0,26(0,49)||-0,03 (0,18)||
|Janssen et<br>al (2002)<sup>274</sup>|||16 semanas|mmol/L<br>-0,60 (0,43)<br>mmol/L|NS|mmol/L<br>-0,34 (0,50)<br>mmol/L|NS|mmol/L<br>-0,35 (0,82)<br>mmol/L|NS|mmol/L<br>-0,09 (0,11)<br>mmol/L|NS|
||Exercícios de resistência + dieta|14||||||||||
||<br>|<br>||**Mulheres**<br>|**40-45 anos d**|**e idade**<br>||||||
|Park et al<br>|Exercícios aeróbicos|10|24 semanas|-45,4 mg/dL|NR|-44,8 mg/dL|NR|-44,7 mg/dL|NR|9,2 mg/dL|NR|
|(2003)<sup>240</sup>||||||||||||
||Exercícios de resistência e aeróbicos|10||-63,0 mg/dL||-60,8 mg/dL||-63,0 mg/dL||9,8 mg/dL||
||||**Homens**|<br>**e mulheres 18-70 a**|**nos de idade**|<br>**com síndrome meta**|**bólica**|||||
||Exercícios aeróbicos|30||NR||NR||−21,0 (56,0)||1,03 (4,81)||
|STRRIDE<br>AT/RT<sup>284</sup>|Exercícios de resistência|31|8 meses|NR||NR||−5,25(52,6)|NS|−0,63(4,81)|NS|
||Exercícios de resistência e aeróbicos|25||NR||NR||-30,1 (49,8)||1,55 (5,84)||
||||**Homens e m**|**ulheres 45-74 anos**<br>|**de idade co**|**mpressão alta ou hi**<br>|**pertensão**|<br>||<br>||
|Schroeder|Exercícios aeróbicos|17||(IC95%-12 a 5)<br>-4 mg/dL||(IC95%-9 a 6)<br>-1 mg/dL||(IC95%-32 a 10)<br>-11 mg/dL||(IC95%-2 a 2)<br>0 mg/dL<br>||
|<br>et al<br>(2019)*<sup>269</sup>|Exercícios de resistência|17|8 semanas|-6 m g/dL<br>(IC95%-15 a 2)|NS|-1 mg/dL<br>(IC95%-9 a 7)|NS<br>|-26 mg/dL<br>(IC95%-47 a-5)|NS|0 mg/ <sup>L</sup><br>(IC95%-2 a 3)|NS|
||Exercícios aeróbicos e de resistência|18||-3 mg/dL<br>IC95% 11  5||2 mg/dL<br>IC95% 6  9||3 mg/dL<br>IC95% 17  24||-2 mg/dL<br>IC95% 4  0||
|||**Ho**<br>|**mens e mulhere**|**s adultos com obesi**<br> <br>(- a)|**dade grave, d**|**iabetes tipo 2 e sínd**<br> <br>(- a)|**rome met**|**abólica**<br> <br>(- a)||<br>(- a)||
|Lucotti et al|Exercícios aeróbicos + dieta|27||-26 mg/dL||NR||-60,7 mg/dL||1 mg/dL||
||||21 dias||NS||||NS||NS|
|(2011)<sup>280</sup>|Exercícios combinados (aeróbicos e<br>~~resistência) + dieta~~|20||-23 mg/dL||NR||-47,4 mg/dL||-1,2 mg/dL||  
180  
**Legenda:** IC95%: intervalo de confiança de 95%; aer: exercícios aeróbicos; comb: exercícios combinados (aeróbicos e de resistência) DP: Desvio-padrão; EP: Erro-padrão; NR: não reportado; NS: não estatisticamente significante; res: exercícios de resistência; * Resultados ajustados por sexo, idade, e valores da linha de base  
181  
**Tabela V.** Resultados de alteração nos níveis de glicose e insulina dos estudos incluídos que avaliaram programas de exercício físico aeróbicos, de resistência e combinados (aeróbicos e de resistência) em indivíduos obesos ou com sobrepeso.  
|**Autor, ano**|**Intervenção**|**n**|**Tempo da**<br>**avaliação**|**Glicose jejum**<br>**(µU/mL)**<br>**Média(DP)**|**Valor**<br>**p**|**Insulina (µU/mL)**<br>**Média (DP)**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|
|||**Home**<br>|**ns e mulheres (4**|**5-66 anos de idade)**<br> <br>||||
|H  l|Exercícios aeróbicos<br>|15||0,05||2,82||
|o et a<br>(2012)|Exercícios de<br>resistência|16|12 semanas|-0,04|NS|-0,5|NS|
|267,283|Exercícios aeróbicos e|||||||
||de resistência|17||0,17||0,01||
|||**Hom**|**ens e mulheres 6**|**0-80 anos de idade**||||
||Exercícios aeróbicos|37||NR||-1,43 (3,8)||
|Davidson et|Exercícios de|36|6 meses|NR||-0,97 (0,57)|NS|
|al (2009)<sup>264</sup>|resistência|||||||
||Exercícios de<br>resistência e aeróbicos|35||NR||-1,49 (3,1)||
||||**Mulheres**|**adultas**||||
|Janssen et|Exercícios aeróbicos +<br>dieta|11||-0,1 (0,5) mmol/L||-17,0 (39,0)<br>pmol/L**||
|al (2002)<sup>274</sup>|Exercícios de||16 semanas||NS|-33,0 (38,9)|NS|
||~~resistência + dieta~~|14||-0,1 (0,4) mmol/L||pmol/L**||
||||**Homens**|**adultos**||||
|Rice et al|Exercícios aeróbicos +<br>dieta|10||-0,2 (0,3) mmol/L||-58,6 (46,6)<br>pmol/L**||
|(1999)<sup>281</sup>|Exercícios de||16 semanas||NS|-53,6 (49,3)|NS|
||~~resistência + dieta~~|10||-0,1 (0,7) mmol/L||pmol/L**||
||<br>**Homens e**|**mulher**|**es 18-70 anos de**|**idade com síndrome**|**metabólica**|||
||Exercícios aeróbicos|30||-0,22 (9,54)||NR||
||Exercícios de|31||-0,37 (9,22)||NR||
|STRRIDE<br>AT/RT<sup>284</sup>|resistência<br>Exercícios combinados||8 meses||NS|||
||(aeróbicos e|25||1,86 (7,95)||NR||
||resistência)<br>**Homens e m**|**ulheres 4**|**5-74 anos de ida**|**de compressão alta o**<br>0 m/dL|**u hipertens**|**ão**<br>||
|Schroeder|Exercícios aeróbicos|17||g<br>(IC95% 3 a 3)<br>||NR||
|et al<br>(2019)*<sup>269</sup>|Exercícios de<br>resistência<br>|17|8 semanas|-1 mg/dL<br>(IC95%-4 a 2)|NS|NR||
||Exercícios aeróbicos e|||-2 mg/dL||||
||de resistência|18||<br>(IC95% -4 a 1)||NR||  
**Legenda:** DP: Desvio-padrão; NR: Não reportado; NS: Não estatisticamente significante *Resultados ajustados por sexo, idade, e valores da linha de base **Insulina em jejum  
182  
|**Figura P.**Gráfico de floresta da meta-análise dos resultados de redução do peso corporal (Kg) dos|
|---|
|estudos incluídos para a comparação entre exercícios aeróbicos versus de resistência*.<br><br><br><br> <br> <br>|
|Exercicios aerébicos<br>_Exerciclos<br>deresisténcia<br>MeanDifference<br>MeanDifference<br>Study<br>orSubgroup__Mean__SD_Total_Mean<br>SD<br>Total_Weight_1V,Random,<br>95%Cl<br>IV,Random,<br>95%CL<br>1.1.1|  
* Os nomes dos subgrupos remetem à população incluída no estudo, ao tempo de duração da intervenção (programas de exercícios) e se ambos os grupos utilizaram dieta específica (“+dieta”).  
183  
**Figura Q.** Gráfico de floresta da meta-análise dos resultados de redução do peso corporal (Kg) dos estudos incluídos para a comparação entre exercícios combinados (resistência + aeróbico) versus aeróbico*.  
‘TestforTest for subaroupoverall eect diferences:Z= 2.17 (P=Chit=0.03)5.94, df= 5 (P= 0.20.= 15.0% Favorece ex combinados Favorece ex aerébicos * Os nomes dos subgrupos remetem à população incluída no estudo, ao tempo de duração da intervenção (programas de exercícios) e se ambos os grupos utilizaram dieta específica (“+dieta”).  
**Figura R.** Avaliação da qualidade metodológica dos ensaios clínicos incluídos na revisão sistemática.  
<!-- Start of picture text -->
a$o 9<br>43s # 2 x e838<br>Zs S$ gy FB z 2-2<br>D56mR 2#28& @@ ® 58&@ 8$8 xr «se=5s §&€ &8Sg2<br>> BRB ZBBBBAASA<br>43 6 6686856 6 FG wb Ss Ss<br>3 2s 8B SS 25886 8 8<br>4 £2 2 osc vvest ar ss gs<br>[e|e|2/e/e/e\e/ele/s/a| Random sequence generation (selection blas)<br>|e/e\e|2/e/e/e/s/e/e/a| Allocation concealment (selection bas)<br>DODSooooo0o Bilding of persannel (performance bias)<br>|2|2|2|2/e@/e/e/e/9/a/a| Blinding of outcome assessment (detection blas)<br>|e/e|\e|e\elelelelele/e Incomplete outcome data (attrtion bias)<br>le|e|e/e/e/e/e/e\/e/e/a| Selective reporting (reporting bias)<br><!-- End of picture text -->  
184  
**Quadro X.** Sumarização dos resultados dos estudos incluídos para o desfecho principal (perda de peso em Kg) ( _Summary of Findings_ [SoF]) do _webapp_ Grade PRO) <u>para a comparação entre exercícios aeróbicos e exercícios de resistência</u>  
|||**Q**|**ualidade Global da**|**evidência**|||**№ dep**|**acientes**|**Efe**|**ito**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Exercícios**<br>**aeróbicos**|**Exercícios de**<br>**resistência**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**|**global**||
|**Alteraçã**|**o dopeso corporal**|**médio(Kg)**|||||||||||
|8|Ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|162|168|-|DM -1,57<br>Kg (IC95%<br>-2,34 a -<br>0,80)|MUITO BAIXA|CRÍTICO|  
**Legenda:** DM: Diferença Média; IC: Intervalo de Confiança; a. Alto risco de viés pela ferramenta da Cochrane; b. Intervalo de confiança das estimativas individuais e estimativa da meta-análise considerados grandes.  
**Quadro Y.** Sumarização dos resultados dos estudos incluídos para o desfecho principal (perda de peso em Kg) ( _Summary of Findings_ [SoF]) do _webapp_ Grade PRO) <u>para a comparação entre exercícios combinados (aeróbicos e de resistência) e exercícios de aeróbicos</u>  
|||**Q**|**ualidade Global da**|**evidência**|||**№ depa **|**cientes**|**Efe**|**ito**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Exercícios**<br>**combinados**|**Exercícios**<br>**aeróbicos**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**|**global**||
|**Alteraçã**|**o dopeso corporal**|**médio(Kg)**|||||||||||
|6|Ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|143|137|-|DM 0,79<br>Kg (IC95%<br>0,08 a<br>1,51)|MUITO BAIXA|CRÍTICO|  
**Legenda:** DM: Diferença Média; IC: Intervalo de Confiança; a. Alto risco de viés pela ferramenta da Cochrane; b. Intervalo de confiança das estimativas individuais e estimativa da meta-análise considerados grandes.  
185  
###### **<u>Quadro Z.</u>** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ <u>[EtD]) do</u> _webapp_ GRADE PRO.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
|**Deve-se usar exer**<br>**obesidade?**|**cícios aeróbicos vs. exercícios de resistência para redução de peso corporal em indivíduos portadores de sobrepeso ou**|
|---|---|
|**POPULAÇÃO:**|Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade|
|**INTERVENÇÃO:**|exercícios aeróbicos|
|**COMPARAÇÃO:**|exercícios de resistência|
|**PRINCIPAIS DESFECHOS:**|Alteração com relação à linha de base no peso corpóreo, no IMC, na medida da circunferência da cintura, gordura corporal, massa magra, perfil lipídico, pressão arterial, glicose e<br>insulina.|
|**CENÁRIO:**|Todo o Brasil|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
|Problema<br>O problema é uma priorid|ade?||
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não|· A obesidade é um|a condição epidêmica no mundo;|
|○ Provavelmente Não<br>○ Provavelmente sim|· O número de obes|os no mundo quase triplicou desde 1975. Em 2016, mais de 1,9 bilhão de adultos apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos;|
|● Sim<br>○ Varia|· De acordo com da|dos do VIGITEL Brasil 2017, a frequência de sobrepeso foi de 54,0% e a de obesidade de 18,9%.|
|○ Incerto|· A Organização Mu<br>moderada ou pelo|ndial da Saúde recomenda que adultos com idade entre 18 e 64 anos façam pelo menos 150 minutos semanais de atividade física aeróbica de intensidade<br>menos 75 minutos semanais de atividade física aeróbica de intensidade vigorosa ou uma combinação equivalente de ambos.|  
186  
#### Efeitos Desejáveis  
|Quão substanciais são|os efeitos desejáveis?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>● Pequeno<br>○ Moderado<br>○ Grande|· Os resultados de estudos individuais foram contraditórios quanto à comparação de exercícios aeróbicos vs. de resistência vs. combinados para perda de peso e IMC;<br>· Na meta-análise que comparou exercícios aeróbicos e de resistência para redução de peso corporal, observou-se que a diferença média favoreceu o grupo de exercícios aeróbicos,<br>com diferença média de 1,57 kg;|
|○ Variável<br>○ Incerto|· Na meta-análise que comparou exercícios aeróbicos e combinados para redução de peso corporal, observou-se que a diferença média favoreceu o grupo de exercícios aeróbicos,<br>com diferença média de 0,79 kg;|
||· Desfechos relacionados à composição corporal e importantes para a avaliação de risco para o desenvolvimento de doenças cardiovasculares e diabetes mellitus tipo 2 foram<br>avaliados. No entanto, para a maioria dos desfechos não foi relatado se houve diferença estatisticamente significante entre os grupos de exercícios.<br>· Foi possível observar benefício dos exercícios combinados (aeróbicos e de resistência) com relação a diminuição da gordura corporal em comparação aos exercícios de resistência<br>em três estudos|
||· **A prática de exercícios de resistência pode aumentar o peso corporal global, devido a um aumento na massa magra;**<br>· Dos seis estudos que relataram se houve diferença entre os grupos quanto à massa corporal, quatro revelaram benefício dos exercícios de resistência frente aos exercícios aeróbicos<br>e/ou exercícios combinados. Apenas um estudo relatou diferença entre os grupos, favorecendo os grupos de exercícios aeróbicos e combinados quanto ao perfil lipídico, enquanto<br>que quatro relataram não haver diferenças;|
||· Não foram observadas diferenças entre os grupos de exercício quanto à glicose e insulina em jejum.|  
187  
#### Efeitos Indesejáveis  
|Quão substanciais são|os efeitos indesejáveis?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>● Pequeno<br>○ Moderado<br>○ Grande|· Os resultados de estudos individuais foram contraditórios quanto à comparação de exercícios aeróbicos vs. de resistência vs. combinados para perda de peso e IMC;<br>· Na meta-análise que comparou exercícios aeróbicos e de resistência para redução de peso corporal, observou-se que a diferença média favoreceu o grupo de exercícios aeróbicos,<br>com diferença média de 1,57 kg;|
|○ Variável<br>○ Incerto|· Na meta-análise que comparou exercícios aeróbicos e combinados para redução de peso corporal, observou-se que a diferença média favoreceu o grupo de exercícios aeróbicos,<br>com diferença média de 0,79 kg;|
||· Desfechos relacionados à composição corporal e importantes para a avaliação de risco para o desenvolvimento de doenças cardiovasculares e diabetes mellitus tipo 2 foram<br>avaliados. No entanto, para a maioria dos desfechos não foi relatado se houve diferença estatisticamente significante entre os grupos de exercícios.<br>· Foi possível observar benefício dos exercícios combinados (aeróbicos e de resistência) com relação a diminuição da gordura corporal em comparação aos exercícios de resistência<br>em três estudos|
||· **A prática de exercícios de resistência pode aumentar o peso corporal global, devido a um aumento na massa magra;**<br>· Dos seis estudos que relataram se houve diferença entre os grupos quanto à massa corporal, quatro revelaram benefício dos exercícios de resistência frente aos exercícios aeróbicos<br>e/ou exercícios combinados. Apenas um estudo relatou diferença entre os grupos, favorecendo os grupos de exercícios aeróbicos e combinados quanto ao perfil lipídico, enquanto<br>que quatro relataram não haver diferenças;|
||· Não foram observadas diferenças entre os grupos de exercício quanto à glicose e insulina em jejum.|  
188  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSI|DERAÇÕES ADICIONAIS||||||
|---|---|---|---|---|---|---|---|
|● Muito Baixa<br>○ Baixa<br>○Moderada|**Desfechos**|**Efeitos absolutos potenciais**<sup>*****</sup>**(95% CI)**||**Efeito**<br>**relativo**|**№ de**<br>**participantes**|**Certainty of the**<br>**evidence**|**Comentários**|
|<br>○ Alta<br>○ Sem estudos incluídos||**Risco com exercícios de resistência**|**Risco com exercícios**<br>**aeróbicos**|**(95% CI)**|**(estudos)**|**(GRADE)**||
||Alteração do peso corporal<br>médio|A média alteração do peso corporal<br>médio foi**0**Kg|MD**1.57 Kg menor**<br>(2.34 menor para 0.8<br>menor)|-|330<br>(8 ECRs)|⨁◯◯◯<br>MUITO BAIXA<sup>a,b</sup>||  
- a. Alto risco de viés pela ferramenta da Cochrane  
- b. Intervalo de confiança das estimativas individuais e estimativa da meta-análise considerados grandes  
|**Desfechos**|**Efeitos absolutos potenciais**<sup>*****</sup>**(95% CI)**||**Efeito**<br>**relativo**|**№ de**<br>**participantes**|**Certainty of the**<br>**evidence**|**Comentários**|
|---|---|---|---|---|---|---|
||**Risco com exercícios combinados (aeróbicos e**<br>**de resistência)**|**Risco com exercícios**<br>**aeróbicos**|**(95% CI)**|**(estudos)**|**(GRADE)**||
|Redução de peso<br>corporal|A média redução de peso corporal foi**0**Kg|MD**0.79 Kg mais alto**<br>(0.08 mais alto para 1.51<br>mais alto)|-|280<br>(6 ECRs)|⨁◯◯◯<br>MUITO BAIXA<sup>a,b</sup>||  
- a. Alto risco de viés pela ferramenta da Cochrane  
- b. Intervalo de confiança das estimativas individuais e estimativa da meta-análise considerados grandes  
189  
#### Valores  
Existe importante incerteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|---|---|
|○ Importante incerteza ou<br>variabilidade<br>○ Possível Importante|· Indivíduos menos favorecidos economicamente poderiam ter dificuldades de realizar exercícios físicos frequentemente devido à sua rotina;<br>. Existem academias da cidade ou modelos parecidos em algumas cidades brasileiras;|
|incerteza ou variabilidade<br>● Provavelmente nenhuma<br>Importante incerteza ou<br>variabilidade<br>○ Sem importante incerteza<br>ou variabilidade|. A perda de peso é crucial para o prognóstico do obeso, portanto, espera-se uma valorização dos desfechos corporais pelo indivíduo.|
|Balanço dos efeito<br>O balanço entre efeitos desej<br>JULGAMENTO|s<br>áveis e indesejáveis favorece a intervenção ou o comparador?<br>EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Favorece o comparador<br>○ Provavelmente favorece<br>o comparador<br>○ Não favorece um e nem<br>o outro<br>● Provavelmente favorece<br>a intervenção<br>○ Favorece a intervenção<br>○ Variável<br>○ Incerto|· Os resultados das meta-análises para desfecho de perda de peso favoreceram a prática de exercícios aeróbicos em relação aos exercícios de resistência ou combinados;<br>· Foi possível observar benefício dos exercícios combinados (aeróbicos e de resistência) com relação a diminuição da gordura corporal em comparação aos exercícios de resistência<br>em três estudos;<br>· Dos seis estudos que relataram se houve diferença entre os grupos quanto à massa corporal, quatro revelaram benefício dos exercícios de resistência frente aos exercícios aeróbicos<br>e/ou exercícios combinados. Apenas um estudo relatou diferença entre os grupos, favorecendo os grupos de exercícios aeróbicos e combinados quanto ao perfil lipídico, enquanto<br>que quatro relataram não haver diferenças.<br>· Não foram observadas diferenças entre os grupos de exercício quanto à glicose e insulina em jejum.<br>. O exercício de resistência promove ganho de peso pelo aumento de massa magra, agregando resultados de melhora de comorbidades e redução de gordura.<br>. Aparentemente, uma intervenção não difere da outra, mas é importante ressaltar que existe ganho muscular com a prática de exercícios de resitência.|  
190  
|Equidade<br>Qual seria o impacto em equ|idade em saúde?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Reduzida<br>○ Provavelmente reduzida<br>○ Provavelmente nenhum<br>impacto|· Provavelmente indivíduos menos favorecidos economicamente não poderiam realizar atividades físicas de qualquer natureza;<br>· Indivíduos menos favorecidos economicamente poderiam realizar atividades aeróbicas e de resistência em ambientes mantidos por organizações particulares ou pelas prefeituras,<br>porém de uso público e gratuito.|
|○ Provavelmente<br>aumentada<br>○ Aumentada||
|○ Variável<br>○ Incerto||

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
||||**J**|**ULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|**Pequena**|Moderada|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderada|**Pequena**|Trivial||Varia|Incerto|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possível incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**variabilidade ou**<br>**incerteza importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece uma ou<br>outra|**Provavelmente**<br>**favorece a intervenção**|Favorece a intervenção|Varia|Incerto|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|Provavelmente sem<br>impacto|Provavelmente<br>aumentada|Aumentada|Varia|Incerto|  
191

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
|Recomendação forte contra a intervenção<br>Recomendação condicional contra a|Não favorece uma ou outra|**Recomendação condicional a favor da**|Recomendação forte a favor da|
|---|---|---|---|
|tecnologia||**intervenção**|recomendação|
|○<br>○|○|**●**|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 7- PERGUNTA PICO 6** -->
Recomendação Recomenda-se a prática de exercícios físicos aeróbicos combinados com resistidos.  
192

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 8 - PERGUNTA PICO 7** -->
**Questão de pesquisa: “Qual o efeito da intensidade do exercício físico na perda de peso e no risco cardiovascular em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era qualquer abordagem em grupo para perda de peso (C) era qualquer abordagem individual para perda de peso (O) Perda de peso, redução do perímetro da cintura, redução do IMC.  
###### **A. Estratégia de busca**  
**<u>Quadro A1.</u>** Estratégias de busca de evidências em bases de dados  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|(((("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND ("High-Intensity Interval Training"[Mesh] OR<br>exercise intensity OR exercise intensity level* OR workout intensity<br>OR training intensity OR high-intensity exercise OR moderate-<br>intensity<br>exercise<br>OR<br>low-intensity<br>exercise)))<br>AND<br>((("Cardiovascular<br>System"[Mesh]<br>OR<br>"Cardiovascular<br>Diseases"[Mesh] OR cardiovascular diseases OR cardiovascular)) OR<br>("Weight Loss"[Mesh] OR weight loss OR weight reduction))<br>Data da busca: 08/10/2018|1.173|
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>(('exercise intensity'/exp OR 'exercise intensity' OR 'high intensity<br>interval training'/exp OR 'high intensity interval training' OR<br>'moderate intensity exercise'/exp OR 'moderate intensity exercise'<br>OR 'high intensity exercise'/exp OR 'high intensity exercise' OR 'low<br>intensity exercise'/exp OR 'low intensity exercise') AND 'workout<br>intensity' OR 'high-intensity exercise' OR 'moderate intensity<br>exercise'/exp OR 'moderate intensity exercise' OR 'low intensity<br>exercise'/exp OR 'low intensity exercise' OR 'training intensity')<br>AND [embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight loss'/exp<br>OR 'weight loss' OR 'weight reduction'/exp OR 'weight reduction')<br>AND [embase]/limOR|170|  
193  
('cardiovascular risk factor'/exp OR 'cardiovascular risk factor' OR 'cardiovascular risk'/exp OR 'cardiovascular risk') AND [embase]/lim Data da busca: 08/10/2018  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 1.344 referências (1.173 no MEDLINE e 170 no EMBASE e uma referência por busca manual). Destas, 81 foram excluídas por estarem duplicadas. Um total de mil duzentas e sessenta e três referências foram triadas por meio da leitura de título e resumos, das quais 14 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Foram priorizados, para inclusão neste relatório, estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análise de comparações diretas ou indiretas de ensaios clínicos randomizados e não randomizados que avaliavam explicitamente participantes portadores de sobrepeso ou obesidade, e que incluíssem como grupo comparador exercício físico realizado em moderada intensidade.  
Foram considerados como desfechos primários de eficácia aqueles relacionados à composição corporal, incluindo a alteração no peso corpóreo, no índice de Massa Corporal (IMC), medida da circunferência da cintura e % de gordura corporal desde a linha de base. Adicionalmente foram avaliados os desfechos cardiorrespiratórios de alteração no VO2max, frequência cardíaca de repouso, pressão sistólica e diastólica e desfechos metabólicos de alteração na glicose e insulina em jejum e alteração nos níveis de colesterol e frações.  
Nessa etapa dez estudos foram excluídos: 1) cinco pelo tipo de intervenção, sendo que não avaliavam a intensidade do exercício ou não havia comparação entre diferentes intensidades 285–289 2) quatropelo tipo de participante, sendo que incluíram estudos com indivíduos com sobrepeso/obesidade mas não estratificaram os resultados para esta população ou incluíram crianças<sup>290–293</sup> 3) um pelo tipo de desfecho, sendo que avaliou a prática de exercício físico após realização de cirurgia bariátrica<sup>294</sup> .  
No final, foram incluídas quatro revisões sistemáticas com meta-análise para avaliar a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade<sup>295–</sup> 298 e seus dados se encontram relatados a seguir ( **Figura S** ).  
194  
###### **Figura S** . Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.344<br>PUBMED = 1.173<br>EMBASE= 170<br>Busca Manual= 1<br>Publicações excluídas segundo<br>critérios de exclusão: 1.249<br>Publicações após remoção de duplicatas:<br>1.263  Tipo de estudo: 559<br>Tipo de participante: 294<br>Tipo de intervenção: 357<br>Tipo de desfecho: 39<br>Publicações excluídas segundo<br>critérios de exclusão: 9<br>Publicações selecionadas para leitura<br>completa: 14  Tipo de participante: 4<br>Tipo de intervenção: 5<br>Tipo de desfecho: 1<br>Estudos incluídos<br>Revisão Sistemática com meta-análise: 04<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela W** . A caracterização dos participantes de cada estudo pode ser vista nas **Tabela X** . Resultados encontram-se nas **Tabelas Y** a **A1** . A qualidade metodológica dos estudos incluídos encontra-se no **Quadro B1.** A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista na **Tabela C1** , que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. A **Tabela D1** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
195  
**Tabela W.** Características dos estudos incluídos que avaliaram a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número de estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Qualidade**<br>**metodológica**|
|---|---|---|---|---|---|---|
|Andreato et<br>al., 2019<sup>295</sup>|Revisão Sistemática<br>com meta-análise de<br>comparação indireta|Avaliar a eficácia de HIIT comparado<br>a MICT ou a não praticar exercício<br>físico em medidas antropométricas<br>entre adultos com<br>sobrepeso/obesidade|48 estudos<br>(ECR e EC)<br>1.222 participantes|HIIT<br>Intervenções com intensidade ≥ 80% VO2max,<br>>80% da frequência cardíaca de reserva ou<br>>85% da frequência cardíaca máxima|MICT ou sem exercício*|Baixa|
||Revisão Sistemática|Avaliar a eficácia do HIIT em||HIIT:<br>Intervenções com intensidade ≥ 85% VO2max,|Sem grupo controle. Estudo||
|Batacan et<br>al., 2017<sup>296</sup>|com meta-análise de<br>comparação direta|desfechos de composição corporal,<br>cardiorrespiratória e<br>cardiometabólica em adultos|31 ECR e 6 EC<br>1433 participantes|≥ 85% da frequência cardíaca de reserva ou ≥<br>90% da frequência cardíaca máxima. Duração<br>da sessão ≤ 4 min./ciclo intercalado com<br>intervalo de recuperação|apresenta diferença média de<br>resultados antes e após a<br>intervenção (i.e, intra-grupo)|Criticamente baixa|
|Wewege et<br>al., 2017<sup>297</sup>|Revisão Sistemática<br>com meta-análise de<br>comparação direta|Avaliar a eficácia do HIIT e de MICT<br>na perda de peso e composição<br>corporal em adultos obesos (IMC ><br>30kg/m<sup>2</sup>) ou com sobrepeso (25 <<br>IMC ≤ 30 kg/m<sup>2</sup>)|13 ECR<br>424 participantes|HIIT:<br>Intervalos de até 4 min. com intensidade ≥<br>85% da frequência cardíaca máxima ou 80%<br>do VO2maxou percepção subjetiva do esforço<br>de 17|MICT:<br>Exercício aeróbico contínuo<br>com intensidade entre 60–75%<br>da frequência cardíaca máxima<br>50–65% do VO2maxou percepção<br>subjetiva do esforço de entre<br>12–15|Moderada|
||Revisão Sistemática|Avaliar a eficácia de HIT na<br>capacidade cardiorrespiratória e<br>composição corporal em adultos||HIIT (12 estudos):<br>Intervalos de até 4 min. com intensidade ≥<br>70% da frequência cardíaca máxima ou 90-|Exercício convencional:<br>Baixa intensidade ou níveis||
|Turk et al.,<br>2017<sup>298</sup>|com meta-análise de<br>comparação direta|obesos (IMC ≥ 30 kg/m<sup>2</sup>) em<br>comparação com formas<br>tradicionais de exercício (baixa<br>intensidade, alto volume contínuo)|18 ECR<br>854 participantes|100% do VO2maxou 5-200% da potência<br>mecânica máxima<br>HIT continuo (6 estudos):<br>60-75% do VO2maxou 70-80% da frequência<br>cardíaca máxima|normais de atividade física|Criticamente baixa|  
**Legenda:** ECR: ensaio clínico randomizado; EC: ensaio clínico; IMC: índice de massa corporal; HIT: _High-Intensity Training_ – treinamento de alta intensidade; HIIT: _High-Intensity Interval Training_ - treinamento intervalado de alta intensidade; MICT: _Moderate Intensity Continuous Training_ – treinamento contínuo de moderada intensidade;Min.: minuto; VO2max: capacidade expiratória máxima *Utilizado apenas como fonte de evidência para a comparação indireta  
196  
**Tabela X.** Características basais de estudos que avaliaram a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade.  
|**Autores**|**Intervenção**|**Controle**|**N intervenção**|**N**<br>**controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção**<br>**vs. Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Peso (Kg), Média (DP)**<br>**(Intervenção vs. Controle)**|**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|
|---|---|---|---|---|---|---|---|---|---|---|
|Andreato<br>et al.,<br>2019<sup>295</sup>|HIIT|MICT|678|544|Variação:<br>19,0 (0,8) – 59<br>(4)|NR|Variação:<br>24,3 (2,4) –<br>35,8(2,3)|NR|NR|AT  2 – 24<br>semanas|
|Wewege<br>et al.,<br>2017<sup>297</sup>|HIIT|MICT|216|208|19,3 (0,7) –<br>46,9 (2,2)|50 vs, 50|Variação:<br>25,5 (2,1) –<br>37,4(6,2)|Variação:<br>Entre 64,8 (6,1) - 99,7 (10,9)|NR|10,4 ± 3,1<br>semanas<br>(AT 5-16)|
|Turk et al.,<br>2017<sup>298</sup>|HIT|Exercício<br>convencional|229*|240*|Variação:<br>20,4 (1,5) –<br>59,0(5,5)|Variação:<br>32 - 69|Variação:<br>29,2 (4,2) –<br>38,4(6,5)|NR|NR|AT 2 - 6<br>meses|
|Batacan et|||||Variação:|||||AT 2 - 24|
|al.,<br>2017<sup>§296</sup>|HIIT|NA|621|812|22,7 (5,4) –<br>63,0 (8,0)|NR|NR|NR|NR|semanas|  
**Legenda:** AT: amplitude total; N: número da amostra; NA: Não se aplica;NR: não reportado;DP; desvio padrão; HIT: _High-Intensity Training_ – treinamento de alta intensidade; HIIT: _High-Intensity Interval Training_ - treinamento intervalado de alta intensidade; MICT: _Moderate Intensity Continuous Training_ – treinamento contínuo de moderada intensidade; *para desfecho primário capacidade expiratória (VO2);<sup>**§**</sup> Estudo apresenta diferença média de resultados antes e após a intervenção  
197  
**Tabela Y.** Desfechos de eficácia de estudos queavaliaram a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor, ano**|**Intervenção**|**Controle**|**Alteração do peso corporal**<br>**(IC 95%)**|**Valor**<br>**de**|**Alteração no IMC**<br>**(IC 95%)**|**Valor**<br>**de**|**Alteração na**<br>**circunferência da**<br>**cintura**|**Valor**<br>**de p**|**Alteração na %**<br>**de gordura**<br>**corporal**|**Valor**<br>**de**|
|---|---|---|---|---|---|---|---|---|---|---|
||||**(Kg)**|**p**|**(Kg/m**<sup>**2**</sup>**)**|**p**|**(IC 95%)**<br>**(cm)**||**(IC 95%)**<br>**(%)**|**p**|
|Andreato et|HIIT|MICT|<sup>DM 0,40</sup><br>(0,09; 0,72)|0,01<br>I<sup>2</sup>= 40%|DM 0,12<br>(0,01;0,22)|NR<br>I<sup>2</sup>= 0%|NR<br>(−0,3;1,0)|NR<br>I<sup>2</sup>= 0%|−0,12<br>(−0,44;0,19)|0,44<br>I<sup>2</sup>= 55%|
|<br>al., 2019<sup>295</sup>|||Apenas equalizados|0,04|NR|NR|NR|NR|-0,22|0,14|
||HIIT|MICT|DM -0,41<br>(-0,79;-0,02)|I<sup>2</sup>= 0%|(-0,31; 0,08)|I<sup>2</sup>= 0%|(−1,7; 0,9)|I<sup>2</sup>= 0%|(−0,52; 0,08)|I<sup>2</sup>= 17%|
|Wewege et<br>al., 2017<sup>297</sup>|HIIT|MICT|<sup>DMP 0,09</sup><br>(-0,10; 0,28)|0,36<br>I<sup>2</sup>= 0%|DMP 0,09<br>(-0,15;0,32)|0,46<br>I<sup>2</sup>= 0%|DM -0,05<br>(-1,09;1,00)|0,93<br>I<sup>2</sup>= 0%|NR|NR|
||HIT|Exercício|DM -1,18|0,44|DM 0,20|0,76|DM -1,04|0,56|DM -1,69|0,02|
|Turk et al.,||convencional|(-4,16;1,80)|I<sup>2</sup>= 0%;|(-1,10;1,50)|I<sup>2</sup>= 91%|(-4,54;2,45)|I<sup>2</sup>= 27%|(- 3,10;-0,27)|I<sup>2</sup>=30%|
|2017*<sup>298</sup>||Exercício|DM -0,42|0,87|DM 0,37|0,69|DM -1,63|0,87|DM -2,01|0,02|
||HIIT|convencional|(-5,30; 4,47)|I<sup>2</sup>= 7%;|(-1,44; 2,18)|I<sup>2</sup>= 70%|(-6,37; 3,10)|I<sup>2</sup>= 7%|(-3,73; -0,30)|I<sup>2</sup>=0%|
|Batacan et|ST-HIIT|NA|<sup>DMP −0,04</sup><br>(−0,29; 0,20)|0,72<br>I<sup>2</sup>= 0%|NR|NR|NR|NR|<sup>DMP −0,14</sup><br>(−0,48; 0,20)|0,42<br>I<sup>2</sup>= 0%|
|al., 2017<sup>§296</sup>|LTHIIT|NA|DMP −0,07|0,37|−0,14|0,12|DMP −0,20|< 0,05|DMP −0,40|< 0,05|
||-||(−0,23; 0,08)|I<sup>2</sup>= 0%|(−0,32; 0,04)|I<sup>2</sup>= 0%|(−0,38; −0,01)|I<sup>2</sup>= 0%|(−0,74; −0,06)|I<sup>2</sup>= 24%|  
**Legenda:** DM: diferença de médias; DMP: Diferença média padronizada;HIT: _High-Intensity Training_ – treinamento de alta intensidade; HIIT: _High-Intensity Interval Training_ - treinamento intervalado de alta intensidade; IC 95%: intervalo de confiança; IMC: Índice de Massa Corporal; LT-HIIT: HIIT de longa duração (≥ 12 semanas); MICT: _Moderate Intensity Continuous Training_ – treinamento contínuo de moderada intensidade; NA: Não se aplica; NR: não reportado; ST-HIIT: HIIT de curta duração (< 12 semanas)  
* Estudo apresenta comparação de dados entre grupos no final do acompanhamento, e não a partir da linha de base;<sup>**§**</sup> Estudo apresenta diferença média de resultados antes e após a intervenção  
198  
**Tabela Z.** Desfechos cardiorrespiratórios de estudos que avaliaram a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade.  
199  
|**Autor, ano**|**Intervenção**|**Controle**<br>**M**|**elhora no volume máxim**<br>**expiratório**<br>**(IC 95%)**<br>**(ml/kg/min)**|**o**<br>**Valor**<br>**de p**|**Redução na frequência**<br>**cardíaca de repouso**<br>**(IC 95%)**|**Valor**<br>**de p**|**Redução na pressão**<br>**sistólica**<br>**(IC 95%)**<br>**(mmHg)**|**Valor**<br>**de p**|**Redução na**<br>**pressão**<br>**diastólica**<br>**(IC 95%)**<br>**(mmHg)**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
||HIT<br>(HIIT + HIT<br>contínuo)|Exercício<br>tradicional|DM 1,83<br>(0,70; 2,96)|< 0,005<br>I<sup>2</sup>= 31%|NR|NR|NR|NR|NR|NR|
|Turk et al.,|Subgrupo|Exercício|DM 1,79|0,03|||||||
|2017*<sup>298</sup>|HIIT|tradicional|(0,21; 3,36)|I<sup>2</sup>= 38%|NR|NR|NR|NR|NR|NR|
||Subgrupo<br>HIT contínuo|Exercício<br>tradicional|DM 1,68<br>(0,10;3,27)|0,04<br>I<sup>2</sup>=25%|NR|NR|NR|NR|NR|NR|
||ST-HIIT|NA|DMP 0,74|< 0,001|NR|NR|DMP −0,28|0,12|DMP −0,52|< 0,01|
|Batacan et|||<br>(0,36;1,12)|I<sup>2</sup>= 0%|||(−0,64;0,08)|I<sup>2</sup>= 0%|(−0,89;−0,16)|I<sup>2</sup>= 0%|
|al., 2017<sup>§296</sup>|||DMP 1,20|< 0,001|DMP −0,33|< 0,01|DMP −0,35|< 0,01|DMP −0,38|< 0,01|
||LT-HIIT|NA|(0 57;1 83)|I<sup>2</sup>= 73%|(−0,56; −0,09)|I<sup>2</sup>= 42%|( −0,60; −0,09)|I<sup>2</sup>= 48%|(−0,65; −0,10)|I<sup>2</sup>= 54%|  
**Legenda:** DM: diferença de médias; DMP: Diferença média padronizada; HIT: _High-Intensity Training_ – treinamento de alta intensidade; HIIT: _High-Intensity Interval Training_ - treinamento intervalado de alta intensidade;IC 95%: intervalo de confiança; IMC: Índice de Massa Corporal; LT-HIIT: HIIT de longa duração (≥ 12 semanas); MICT: _Moderate Intensity Continuous Training_ – treinamento contínuo de moderada intensidade;NA: Não se aplica; NR: não reportado; ST-HIIT: HIIT de curta duração (< 12 semanas)  
* Estudo apresenta comparação de dados entre grupos no final do acompanhamento, e não a partir da linha de base;<sup>**§**</sup> Estudo apresenta diferença média de resultados antes e após a intervenção  
200  
**Tabela A1.** Desfechos metabólicos de estudos que avaliaram a eficácia do exercício físico de alta intensidade em indivíduos portadores de sobrepeso ou obesidade.  
||||**Redução da glicose**||**Redução da insulina**||**Melhora nos níveis**|**Valor**|
|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**em jejum**<br>**(IC 95%)**<br>**(mmol/L)**|**Valor**<br>**de P**|**em jejum**<br>**(IC 95%)**<br>**(µUI/ml)**|**Valor**<br>**de p**|**de colesterol**<br>**(IC 95%)**<br>**(mmol/L)**|**de p**|
||ST-HIIT|NA|<sup>DMP −0,35</sup><br>(−0,62;−0,09)|< 0,01<br>I<sup>2</sup>= 0%|DMP −0,05<br>(−0,39;0,29)|0,76<br>I<sup>2</sup>= 0%|NR|NR|
||||||||Colesterol total||
|Batacan et al.,|||||||DMP 0,07 (−0,14 ;0,28)<br>HDL|0,51; I<sup>2</sup>= 0%|
|2017<sup>§296</sup>|LT-HIIT|NA|DMP  −0,15<br>(−0,34; 0,04)|0,11<br>I<sup>2</sup>= 0%|NR|NR|DMP 0,20 (−0,01; 0,40)<br>LDL<br>DMP 0,09 (−0,13; 0,31)<br>Triglicérides<br>(DMP −0,04 (−0,23;0,15)|0,06; I<sup>2</sup>= 6%<br>0,42; I<sup>2</sup>= 0%<br>0,67; I<sup>2</sup>=0%|  
**Legenda:** DM: diferença de médias; IC 95%: intervalo de confiança; DMP: Diferença média padronizada; DM: Diferença média; NR: não reportado; IMC: Índice de Massa Corporal; HIIT: _High-Intensity Interval Training_ - treinamento intervalado de alta intensidade; MICT: _Moderate Intensity Continuous Training_ – treinamento contínuo de moderada intensidade;ST-HIIT: HIIT de curta duração (< 12 semanas); LT-HIIT: HIIT de longa duração (≥ 12 semanas).  
> **§** Estudo apresenta diferença média de resultados antes e após a intervenção  
201  
**Quadro B1.** Avaliação da qualidade metodológica dos estudos incluídos.  
|**Estudo**|**Qualidade**<br>**metodológica**|**Itens que apresentaram falhas**|
|---|---|---|
|Andreato et<br>al., 2019<sup>295</sup>|Baixa|Crítica:<br>Item 12: Não avaliou o impacto do risco de viés dos estudos<br>incluídos na meta-análise<br>Não críticas:<br>Itens 3, 7, 10: Não reportados<br>Item 8: Relato parcial<br>Item 15: Não avaliou o risco de viés de publicação, mas<br>provavelmente baixo devido à busca ampla|
|Batacan et al.,<br>2017<sup>296</sup>|Criticamente baixa|Críticas:<br>Item 1: Não relatou o grupo comparador<br>Itens 12 e 13: Não avaliou o impacto do risco de viés dos<br>estudos incluídos na meta-análise nem discutiu seu impacto<br>nas conclusões do estudo<br>Não críticas:<br>Itens 2, 3, 6, 7, 10: Não reportados|
|Wewege et<br>al., 2017<sup>297</sup>|Moderada|Não críticas:<br>Itens 2, 3, 7, 10: Não reportados|
|Turk et al.,<br>2017<sup>298</sup>|Criticamente baixa|Críticas:<br>Itens 12 e 13: Não avaliou o impacto do risco de viés dos<br>estudos incluídos na meta-análise nem discutiu seu impacto<br>nas conclusões do estudo<br>Não críticas:<br>Itens 2, 3, 6, 10, 15: Não reportados|  
202  
###### **Quadro C1.** Sumarização dos resultados dos estudos incluídos ( _Summary Of Findings_ [SOF] do _webapp_ GRADEpro).  
||||**Avaliação d**|**a certeza**|||**№ de pa**|**cientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**o exercício físico**<br>**de alta intensidade**<br>**(treinamento de**<br>**alta intensidade)**|**exercício físico de**<br>**baixa ou**<br>**moderada**<br>**intensidade**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|**Redução d**|**o IMC (Índice de m**|**assa corporal)**|||||||||||
|9|ensaios<br>clínicos<br>randomizados|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|muito grave<sup>c</sup>|nenhum|143|140|-|MD**0.09**<br>**kg/m2 mais**<br>(0.15 menos<br>para 0.32<br>mais)|⨁◯◯◯<br>MUITO BAIXA|IMPORTANTE|
|**Redução d**|**o Peso de gordura**|**corporal**|||||||||||
|11|ensaios<br>clínicos<br>randomizados|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|muito grave<sup>c</sup>|nenhum|180|178|-|MD**0.03 Kg**<br>**mais**<br>(0.18 menos<br>para 0.24<br>mais)|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|
|**Circunferê**|**ncia da cintura**||||||||||||
|5|ensaios<br>clínicos<br>randomizados|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|muito grave<sup>c</sup>|nenhum|83|80|-|MD**0.05 cm**<br>**menos**<br>(1.09 menos<br>para 1 mais)|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|
|**redução do**|**peso corporal**||||||||||||
|13|ensaios<br>clínicos<br>randomizados|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|210|205|-|MD**0.09 Kg**<br>**mais alto**<br>(0.1 menor<br>para 0.28<br>mais alto)|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|  
**CI:** Confidence interval; **MD:** Mean difference a. A qualidade metodológica dos estudos em geral foi baixa, avaliada pela ferramenta PEDro. b. Mesmo com o i2 baixo, os estudos apresentam tempos de seguimentos diferentes. c. Os resultados estão em direções distintas e os intervalos de confiança não são sobreponíveis.  
203  
###### **<u>Quadro D1.</u>** Resumo dos principais domínios avaliados (tabela Evidence to Decision (EtD) do _webapp_ GRADE PRO).  
|PERGUNTA||
|---|---|
|**Deve-se usar exercí**<br>**para perda de peso**|**cio físico de alta intensidade (treinamento de alta intensidade) vs. exercício físico de baixa ou moderada intensidade**<br>**e risco cardiovascular?**|
|**POPULAÇÃO:**|perda de peso e risco cardiovascular|
|**INTERVENÇÃO:**|o exercício físico de alta intensidade (treinamento de alta intensidade)|
|**COMPARAÇÃO:**|exercício físico de baixa ou moderada intensidade|
|**PRINCIPAIS DESFECHOS:**|Redução do IMC (Índice de massa corporal); Redução do Peso de gordura corporal; Circunferência da cintura; redução do peso corporal;|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 8 - PERGUNTA PICO 7** -->
|Problema<br>O problema é uma prio|ridade|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente|A obesidade mundial quase triplicou desde 1975.|
|Não<br>○ Provavelmente sim<br>● Sim|<br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.|
|○ Varia|<br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais pessoas do que abaixo do peso.|
|○ Incerto|<br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.|
||<br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou obesas em 2016.<br><br>A obesidade é evitável.|
||Fonte: OMS. Obesity and overweight. Disponível em: https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight. Acesso em: 09/08/2019|  
204  
#### Efeitos Desejáveis  
Quão substanciais são os efeitos desejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|● Trivial<br>○ Pequeno<br>○ Moderado<br>○ Grande<br>○ Variável<br>○ Incerto|Todas as 4 revisõ<br>considerar o efei<br>dos estudos para<br>Wewege et al., 2<br>gordura corporal<br>esses desfechos,<br>meta-análises ap<br>destes resultados|es sistemáticas apresentaram qualidade metodológica criticamente baixa, contudo, Andreato et al., 2019 replicou os valores observados nos grupos controles, sem<br>to ponderado para cada intervenção. Batacan et al., 2017 não apresentou comparador, utilizou dados de antes e após os exercícios físicos e Turk et al., repetiu os resultados<br>as intervenções de HIT (_High Intensity Training_) e HIIT (_High Intensity Interval Training_). Dessa forma, a revisão sistemática com menos falhas metodológicas foi a de<br>017. Na revisão de Wewedge et al., 2017 não foram encontradas diferenças estatisticamente significantes para os desfechos de redução de IMC, redução do peso de<br>, circunferência da cintura e redução do peso corporal. Quanto aos resultados cardiorrespiratórios, apenas as revisões de Turk et al., 2017 e Batacan et al., 2017 avaliaram<br>sendo que houve evidência de benefício de treinos em alta intensidade, independentemente do tipo e duração para o aumento do volume expiratório. Entretanto, as<br>resentaram heterogeneidade entre 31 e 73%, além dos demais problemas metodológicos anteriormente citados, o que pode comprometer a capacidade de interpretação<br>.|
|Efeitos Inde<br>Quão substanciais|sejáveis<br>são os efeitos indesejá|veis?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>○ Pequeno<br>○ Moderado<br>○ Grande<br>○ Variável<br>● Incerto|Todas as 4 revisõ<br>considerar o efei<br>dos estudos para<br>Wewege et al., 2<br>gordura corporal<br>esses desfechos,<br>meta-análises ap<br>destes resultados|es sistemáticas apresentaram qualidade metodológica criticamente baixa, contudo, Andreato et al., 2019 replicou os valores observados nos grupos controles, sem<br>to ponderado para cada intervenção. Batacan et al., 2017 não apresentou comparador, utilizou dados de antes e após os exercícios físicos e Turk et al., repetiu os resultados<br>as intervenções de HIT (_High Intensity Training_) e HIIT (_High Intensity Interval Training_). Dessa forma, a revisão sistemática com menos falhas metodológicas foi a de<br>017. Na revisão de Wewedge et al., 2017 não foram encontradas diferenças estatisticamente significantes para os desfechos de redução de IMC, redução do peso de<br>, circunferência da cintura e redução do peso corporal. Quanto aos resultados cardiorrespiratórios, apenas as revisões de Turk et al., 2017 e Batacan et al., 2017 avaliaram<br>sendo que houve evidência de benefício de treinos em alta intensidade, independentemente do tipo e duração para o aumento do volume expiratório. Entretanto, as<br>resentaram heterogeneidade entre 31 e 73%, além dos demais problemas metodológicos anteriormente citados, o que pode comprometer a capacidade de interpretação<br>.|  
205  
#### Certeza da Evidência  
<!-- Start of picture text -->
Qual é a certeza global da evidência dos efeitos?<br>JULGAMENTO  EVIDÊNCIAS DE  CONSIDERAÇÕES ADICIONAIS<br>PESQUISA<br>● Muito baixa  A qualidade geral da evidência foi muito baixa para todos os desfechos.<br>○ Baixa<br>○ Moderada<br>○ Alta<br>○ Sem estudos<br>incluídos<br>Certainty of the evidence<br>Desfechos  Importância<br>(GRADE)<br>Redução do IMC (Índice de massa corporal)  IMPORTANTE  ⨁◯◯◯<br>MUITO BAIXA a,b,c<br>Redução do Peso de gordura corporal  CRÍTICO  ⨁◯◯◯<br>MUITO BAIXA a,b,c<br>Circunferência da cintura  CRÍTICO  ⨁◯◯◯<br>MUITO BAIXA a,b,c<br>redução do peso corporal  CRÍTICO  ⨁◯◯◯<br>MUITO BAIXA a,b,c<br>a. A qualidade metodológica dos estudos em geral foi baixa, avaliada pela ferramenta PEDro.<br>b. Mesmo com o i2 baixo, os estudos apresentam tempos de seguimentos diferentes.<br>c. Os resultados estão em direções distintas e os intervalos de confiança não são sobreponíveis.<br><!-- End of picture text -->  
206  
|Valores||
|---|---|
|Existe importante ince|rteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Importante<br>incerteza ou<br>variabilidade|A preferência do indivíduo pelo tipo da intensidade de exercício pode depender das condições de capacidade física, comorbidades e sua motivação à realização das diferentes modalidades<br>de atividade física.|
|● Possível||
|Importante incerteza||
|ou variabilidade||
|○ Provavelmente||
|nenhuma Importante||
|incerteza ou||
|variabilidade||
|○ Sem importante||
|incerteza ou||
|variabilidade||  
207  
|Balanço dos e<br>O balanço entre efeito|feitos<br>s desejáveis e indesejáveis favorece a intervenção ou o comparador?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Favorece o<br>comparador<br>○ Provavelmente<br>favorece o<br>comparador<br>● Não favorece um e<br>nem o outro<br>○ Provavelmente|Aparentemente, a modalidade de exercício físico de alta intensidade seja equivalente às formas convencionais de exercício físico de moderada intensidade, em pacientes com sobrepeso ou<br>obesidade, para a redução do peso e prevenção do risco cardiovascular. Contudo, mediante a baixa qualidade metodológica dos estudos e a baixa certeza das evidências, não há como<br>recomendar uma modalidade de treino em detrimento da outra.|
|favorece a<br>intervenção<br>○ Favorece a<br>intervenção<br>○ Variável<br>○ Incerto<br>Aceitabilidade<br>A intervenção é aceitá|<br>vel para os principais atores sociais (_stakeholders_)?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não|<br>A preferência do indivíduo pelo tipo da intensidade de exercício pode depender das condições de capacidade física, comorbidades e sua motivação à realização das diferentes<br>modalidades de atividade física;|
|○ Provavelmente sim<br>○ Sim|<br>Em diversas cidades estão disponíveis programas de academia ao livre ou academias da cidade, contudo, a maioria não apresenta educador físico para a orientação dos exercícios<br>físicos.|
|○ Variável<br>○ Incerto||  
208

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 8 - PERGUNTA PICO 7** -->
||||**J**|**ULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|**Trivial**|Pequena|Moderada|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderada|Pequena|Trivial||Varia|**Incerto**|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|**Possível incerteza ou**<br>**variabilidade**<br>**importante**|Provavelmente sem<br>incerteza ou<br>variabilidade<br>importante|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DE EFEITOS**|Favorece a<br>comparação|Provavelmente<br>favorece a comparação|**Não favorece nem um**<br>**nem outro**|Provavelmente<br>favorece a intervenão|Favorece a intervenção|Varia|Incerta|
|**ACEITABILIDADE**|Nãoo|Provavelmente não|Provavelmente sim|Sim||Varia|Incerta|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 8 - PERGUNTA PICO 7** -->
|Recomendação forte contra a intervenção<br>Recomendação condicional contra a|**Não favorece uma outra**|Recomendação condicional a favor da|Recomendação forte a favor da|
|---|---|---|---|
|intervenção||intervenção|inytervenção|
|○<br>○|**●**|○|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 8 - PERGUNTA PICO 7** -->
#### Recomendação  
Aparentemente, a modalidade de exercício físico de alta intensidade seja equivalente às formas convencionais de exercício físico de moderada intensidade, em pacientes com sobrepeso ou obesidade, para a redução do peso e prevenção do risco cardiovascular. Contudo, mediante a baixa qualidade metodológica dos estudos e a baixa certeza das evidências. De acordo com as evidências disponíveis, recomenda-se a prática de exercícios de intensidade moderada. O aumento da intensidade será avaliado ao longo do programa de treinamento.  
209

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
**Questão de pesquisa: “Quais os efeitos das abordagens individual ou em grupo para a perda de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era qualquer abordagem em grupo para perda de peso (C) era qualquer abordagem individual para perda de peso (O) Perda de peso, redução do perímetro da cintura, redução do IMC.  
###### **A. Estratégia de busca**  
**<u>Quadro E1.</u>** Estratégias de busca de evidências em bases de dados.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|MEDLINE via<br>pubmed:|((("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND ("Weight Loss"[Mesh] OR weight loss OR weight<br>reduction)) AND (group versus individual OR individual versus<br>group OR group vs individual OR individual vs group)<br>Data do acesso: 20/12/2018|2527|
|EMBASE|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>('body weight loss'/exp OR 'body weight loss' OR 'weight loss'/exp<br>OR 'weight loss' OR 'weight reduction'/exp OR 'weight reduction')<br>AND [embase]/lim<br>AND<br>('group versus individual' OR 'individual versus group' OR 'group vs<br>individual' OR 'individual vs group') AND [embase]/lim<br>Data do acesso: 20/12/2018|21|  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 2548 referências (2527 no MEDLINE e 21 no EMBASE). Destas, 24 foram excluídas por estarem duplicadas. Duas mil quinhentas e vinte e quatro referências foram triadas por meio da leitura de títulos e resumos, das quais, 13 referências tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Quatro estudos foram excluídos nessa etapa: a revisão sistemática de Paul-Ebhohimhen (2009) 299, pois verificou-se na descrição de estudos incluídos a inclusão de estudos com objetivos e delineamentos divergentes da nossa pergunta. Os seis ensaios clínicos incluídos nesta revisão foram avaliados individualmente. Destes, dois foram excluídos, um por comparar intervenções diferentes, não sendo possível avaliar o efeito de ser em grupo ou individual, e outro pelo fato de o teste estatístico ser para o desfecho quociente de perda de peso, não sendo esse um  
210  
desfecho analisado no presente PTC. Um terceiro ECR já constava nas buscas e estava incluído para leitura completa, os outros três ECR restantes foram então incluídos.  
Por meio de leitura completa, também foi excluída a revisão sistemáticade Abbott et al., 2008 300, pois se tratava de resumo de congresso, no qual não constavam informações essenciais sobre a metodologia empregada. Ainda, o ECR de Minniti et al., 2007<sup>301</sup> foi excluído, uma vez que foram comparadas intervenções diferentes, não sendo possível avaliar o efeito de ser em grupo ou individual, e o ECR de Hakala, 1993, pois não foi possível obter o artigo completo (não disponível para compra e contato com autor sem sucesso).  
Após esse processo, nove referências tiveram sua elegibilidade confirmada por meio da leitura completa do estudo. Somados aos três artigos que estavam presentes na Revisão Sistemática de Paul-Ebhohimhen (2009)<sup>299</sup> , finalizou-se com 12 artigos,dos quais oito eram ECR, Straw, 1983<sup>302</sup> , Jeffery, 1983<sup>303</sup> , Jeffery, 1984<sup>304</sup> , Perri, 1997<sup>305</sup> , Renjilian, 2001<sup>306</sup> , Waleekhachonloet, 2007<sup>307</sup> , Weinstock, 2013<sup>308</sup> , Mantzios, 2014, três eram estudos de intervenção não randomizados, Wright, 1981<sup>310</sup> , Cresci, 2007<sup>311</sup> e Rigsby, 2009<sup>312</sup> e um _pilot trial,_ Befort, 2010<sup>313</sup> . O processo de seleça6o encontra-se na **Figura T.**  
**Figura T.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas por meio da<br>pesquisa nas bases de dados: 2548<br>PUBMED = 2527<br>EMBASE= 21<br>Publicações excluídas segundo<br>Publicações após remoção de duplicatas:  critérios de exclusão:<br>2524<br>Publicações excluídas segundo<br>critérios de exclusão: 04<br>Publicações selecionadas para leitura  Tipo de estudo: 01<br>completa: 13<br>Desfecho analisado: 02<br>Publicações incluídas<br>manualmente a partir da RS<br>excluída: 03<br>Estudos incluídos: 09+ 03 advindos de busca<br>manual nas listas de referências<br>= 12 estudos<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
211  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela B1** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela C1.** Resultados encontram-se na **Tabela D1** . O risco de viés dos estudos incluídos está ilustrado na **Figura U** . Aavaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no Quadro **F1** , que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O **Quadro G1** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
212  
###### **Tabela B1.** Características dos estudos.  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**Risco de Viés***|
|---|---|---|---|---|---|---|---|
|Straw e Terre, 1983<sup>302</sup>|ECR|testar a eficácia da individualização<br>do tratamento e da manutenção<br>comparando três modos de<br>tratamento comportamental|Mulheres obesas: com pelo menos 35%<br>de gordura no peso corporal (conforme<br>determinado pela calibração cutânea<br>usando a equação de quatro locais<br>recomendada por Durnin & Rahaman,<br>1967)|Terapia<br>comportamental|Abordagem da terapia<br>padrão em grupo|Dois grupos:<br>Controle 1: tratamento<br>padrão administrado<br>individualmente.<br>Controle 2: tratamento<br>individualizado<br>administrado<br>individualmente.|**Alto Risco**<br>Não há informações sobre<br>procedimentos de randomização<br>e sigilo de alocação. Estudo<br>aberto, ocorreram perdas de<br>seguimento, entretanto não há<br>relato de tratamento estatístico<br>específico, como análise por<br>intenção de tratar, por exemplo.|
|Jeffery et al, 1983 e||avaliar sistematicamente dois|||Remuneração pelo<br>desempenho do<br>grupo|Remuneração pelo<br>desempenho individual|**Alto Risco**<br>Não há informações sobre<br>procedimentos de randomização<br>e sigilo de alocação. Estudo|
|1984<sup>303,304</sup>|ECR|aspectos de sistemas de incentivo<br>artificial na redução de peso.|120% de peso ideal|Estímulo Financeiro|Intervenção 1: $30<br>Intervenção 2: $150<br>Intervenção 3: $300|Controle 1: $30<br>Controle 2: $150<br>Controle 3: $300|aberto, ocorreram perdas de<br>seguimento, entretanto não há<br>relato de tratamento estatístico<br>específico, como análise por<br>intenção de tratar, por exemplo.|
||Ensaio Clínico|comparar, principalmente por<br>medidas antropométricas, a resposta<br>a um programa estruturado de<br>educação nutricional fornecido por|Pacientes do sexo masculino com excesso<br>de peso, internados na unidade||||**Alto Risco**<br>Apresentou comprometimento<br>nos domínios:|
|Wright, Wood e Hale,<br>1981<sup>310</sup>|(Não-<br>randomizado)|um nutricionista utilizando três níveis<br>diferentes de tempo de envolvimento<br>com os pacientes, educação<br>individual do paciente, educação em<br>grupo e emissão apenas de material<br>escrito|coronariana com diagnóstico de infarto<br>do miocárdio, com menos de 65 anos,<br>que falassem inglês e residissem na<br>região metropolitana|Programa de Educação<br>Nutricional|Orientação nutricional<br>em grupo|Orientação Nutricional<br>Individual|representatividade da amostra,<br>avaliação dos resultados e<br>acompanhamento dos<br>participantes.|
|||investigar a eficácia comparativa do<br>exercício em grupo versus o|Pacientes mulheres com idade entre 40 a<br>60 anos, IMC entre 27 e 45 kg/m<sup>2</sup>, que<br>não realizavam uma rotina regular de|Tratamento<br>comportamental para|||**Risco incerto**<br>Não há informações sobre<br>procedimentos de randomização|
|Perri et al., 1997<sup>305</sup>|ECR|domiciliar em uma amostra de<br>mulheres obesas sedentárias de<br>meia-idade, submetidas a tratamento<br>de perda de peso comportamental|exercícios aeróbicos e tivessem a<br>aprovação de um médico para participar<br>de uma intervenção de dieta mais|exercício físico|perda de peso mais ex<br>gru|ercício individual ou em<br>po|Exercício em grupo<br>Exercício<br>individual|  
213  
|e sigilo de alocação. Estudo<br>aberto, ocorreram perdas de|seguimento e não ficou claro|como os dados foram tratados|na análise.||||
|---|---|---|---|---|---|---|
|Renjilian et al., 2001<sup>306</sup><br>ECR|testar se a correspondência entre<br>pessoas obesas e sua preferência por|Pacientes adultos com idade entre 21 e<br>59 anos, com IMC de 28 a 45 kg/m<sup>2</sup>, que|Sessões de treinamento<br>cognitivo-|Tratamento em grupo<br>Divididos em dois|Tratamento individual<br>Divididos em dois grupos:|**Alto Risco**|  
214  
|**Autor**|**estudo**<br>**Desenho do**|**Objetivo do estudo**|**População**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**Risco de Viés***|
|---|---|---|---|---|---|---|---|
|||tratamento em grupo ou individual<br>melhoraria o resultado da perda de<br>peso|estivesse em boa saúde e apresentassem<br>aprovação de um médico para participar<br>de uma intervenção de dieta mais<br>exercício|comportamental padrão<br>para controle de peso|grupos:<br>Intervenção 1-<br>queriam ser alocados<br>no tratamento em<br>grupo<br>Intervenção 2- não<br>queriam ser alocados<br>no tratamento em<br>grupo|Controle 1- queriam ser<br>alocados no tratamento<br>individual<br>Controle 2- não queriam<br>ser alocados no<br>tratamento individual|Não há informações sobre<br>procedimentos de randomização<br>e sigilo de alocação. Estudo<br>aberto, ocorreram perdas de<br>seguimento, entretanto não há<br>relato de tratamento estatístico<br>específico, como análise por<br>intenção de tratar, por exemplo.|
|Cresci et al., 2007<sup>311</sup>|Ensaio Clínico<br>(Não-<br>randomizado)|em grupo para o tratamento da<br>obesidade, em comparação com um<br>programa semelhante aplicado em<br>ambiente individual<br>avaliar a viabilidade e eficácia de um<br>programa cognitivo-comportamental|obesidade no ambulatório de Doenças do<br>Metabolismo da Universidade de<br>Florença, com IMC >30 kg/m<sup>2</sup>, residência<br>a 40km da clínica e apresentassem<br>consentimento<br>Pacientes do sexo feminino<br>encaminhadas para tratamento de|Programa cognitivo-<br>comportamental|Abordagem em grupo|Abordagem individual|nos domínios:<br>representatividade da amostra,<br>avaliação dos resultados e<br>acompanhamento dos<br>participantes.<br>**Alto Risco**<br>Apresentou comprometimento|
|Waleekhachonloet et<br>al., 2007<sup>307</sup>|ECR<br>Paralelo, aberto,<br>randomizado de<br>não inferioridade|comparar a terapia comportamental<br>em grupo com terapia<br>comportamental individual, para<br>promover a dieta saudável e o<br>controle de peso em mulheres com<br>sobrepeso e obesidade em<br>comunidades rurais|Pacientes mulheres de 20 a 60 anos de<br>idade, com IMC de pelo menos 25kg/m<sup>2</sup>,<br>com intenção de controlar o peso e seguir<br>um protocolo de estudo, com estilo de<br>vida ativo|Terapia<br>comportamental|Abordagem em grupo|Abordagem individual|**Risco incerto**<br>Não há informações sobre<br>procedimentos de randomização<br>e sigilo de alocação. Estudo<br>aberto.|
|Rigsby, Gropper e<br>Gropper, 2009<sup>312</sup>|Intervencional<br>(Não-<br>randomizado)|avaliar um programa de perda de<br>peso no local de trabalho em que<br>algumas mulheres tentaram perder<br>peso como parte de um grupo,<br>enquanto outras participaram<br>individualmente|Pacientes adultos com IMC ≥ 28 kg/m<sup>2</sup>,<br>sem nenhuma desordem alimentar<br>associada|Programa para perda de<br>peso estimulada por<br>competição|Abordagem em grupo|Abordagem individual|**Alto Risco**<br>Apresentou comprometimento<br>nos domínios:<br>representatividade da amostra,<br>avaliação dos resultados e<br>acompanhamento dos<br>participantes.|
|||examinar os efeitos de um programa<br>de perda de peso comportamental<br>entregue a mulheres rurais em dois|Pacientes mulheres com idade entre 22 a<br>65 anos, residentes em área rural, com<br>IMC entre 25 e 44,9 kg/m<sup>2</sup>, que falassem<br>inglês, com peso estável, sem estar ou<br>com intenção de engravidar, sem doença|Terapia<br>comportamental com|||**Baixo Risco**|
|Befort et al., 2010<sup>313</sup>|_pilot trial_|formatos: aconselhamento por<br>telefone individual e orientação por<br>telefone em grupo|cardíaca instável, insuficiência cardíaca<br>congestiva, doença pulmonar grave, em<br>tratamento de câncer, capaz de andar|rapidamente sem<br>ajuda por pelo menos<br>10 min, sem abuso de<br>substâncias, com|aconselhamento por<br>telefone para perda de|peso|215<br>Abordagem em grupo<br>A<br>bordagem individual|  
Estudo aberto.  
216  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**Risco de Viés***|
|---|---|---|---|---|---|---|---|
||||telefone de trabalho ou número de<br>telefone residencial e sem restrições<br>dietéticas|||||
|Weinstock et al.,<br>2013<sup>308</sup>|ECR|comparar uma tradução do Programa<br>de Prevenção de Diabetes (PPD)<br>usando chamadas individuais versus<br>chamadas em conferência feita pela<br>equipe de provedor de cuidados<br>primários no resultado da perda<br>percentual de peso|Pacientes maiores de 18 anos, presença<br>de síndrome metabólica e IMC ≥30 kg/m<sup>2</sup><br>|Intervenção no estilo de<br>vida por telefone|Abordagem em grupo|Abordagem individual|**Risco Incerto**<br>Não há informações sobre<br>procedimentos para sigilo de<br>alocação. Estudo aberto.|
|||avaliar se praticar atenção plena<br>individualmente é tão eficaz quanto<br>nas configurações de grupo para||Meditação Mindfulness|||**Risco Incerto**<br>Não há informações sobre|
|Mantzios e Giannou,<br>2014<sup>309</sup>|ECR|ajudar na perda de peso, bem como<br>explorar os níveis de atenção,<br>capacidade cognitivo-<br>comportamental de evitar alimentos<br>e controlar impulsividade|NR|(Atenção Plena - nome<br>utilizado no Brasil)|Abordagem em grupo|Abordagem individual|procedimentos de randomização<br>e sigilo de alocação. Estudo<br>aberto.|
|**Legenda:**E|CR – Ensaio Clínico|Randomizado. NR – Não relatado||||||  
###### **Tabela C1.** Características da população.  
|**Autor**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade intervenção**<br>**media (DP)**|**Idade controle**<br>**média (DP)**|**N (%) sexo feminin**<br>**(intervenção/**<br>**controle)**|**o**<br>**Tempo de seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||||Dois grupos:|||||||
||||Controle 1: tratamento padrão|||Controle 2: tratamento|individualizado adm|inistrado individualm|ente.|
|Straw e Terre, 1983<sup>302</sup>|Terapia<br>comportamental|Abordagem da terapia<br>padrão em grupo|administrado individualmente.|||||||  
217  
NR NR NR NR NR 52 semanas  
218  
|**Autor**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade intervenção**<br>**media (DP)**|**Idade controle**<br>**média (DP)**|**N (%) sexo feminino**<br>**(intervenção/**<br>**controle)**|**Tempo de seguime**|**nto**|
|---|---|---|---|---|---|---|---|---|---|---|
|||Remuneração pelo<br>desemenho do ruo|Remuneração pelo desempenho<br>individual||||||||
|Jeffery et al, 1983 e<br>1984<sup>303,304</sup>|Estímulo Financeiro|p  gp<br>Intervenção 1: $30|<br>Controle 1: $30|$30 - 17<br>$150 - 14<br>|$30 - 16<br>$150 - 15<br>|$30 – 54,1<br>$150 – 50,5<br>|$30 – 52,0<br>$150 – 53,8<br>|NR|52 semanas||
|||Intervenção 2: $150<br>Intervenção 3: $300|Controle 2: $150<br>Controle 3: $300|$300 - 13|$300 - 14|$300 – 53,8|$300 – 52,4||||
|Wright, Wood e Hale,|Programa de Educação|Orientação nutricional em|||educação<br>individual -<br>13||||||
|1981<sup>310</sup>|Nutricional|grupo|Orientação Nutricional Individual|13|educação<br>com<br>material de<br>leitura - 13|NR|NR|NR|52 semanas||
||Tratamento<br>comportamental para||||||||||
|Perri et al., 1997<sup>305</sup>|perda de peso mais<br>exercício individual ou<br>em grupo|Exercício em grupo|Exercício individual|25|23|48,72(6,18)|48,91(4,97)|NR|12 meses||
|Renjilian et al., 2001<sup>306</sup>|Sessões de treinamento<br>cognitivo-<br>comportamental padrão<br>para controle de peso|Tratamento em grupo<br>Divididos em dois grupos:<br>Intervenção 1- queriam<br>ser alocados no<br>tratamento em grupo<br>Intervenção 2- não<br>queriam ser alocados no<br>tratamento em grupo|Tratamento individual<br>Divididos em dois grupos:<br>Controle 1- queriam ser alocados no<br>tratamento individual<br>Controle 2- não queriam ser<br>alocados no tratamento individual|<br>Prefere em<br>grupo - 20<br>Não prefere em<br>grupo - 20|Prefere<br>individual -<br>19<br>Não prefere<br>individual -<br>16|Prefere em grupo –<br>44,20(9,70)<br>Não prefere em<br>grupo – 47,44(6,30)|Prefere individual<br>– 46,53(9,22)<br>Não prefere<br>individual –<br>45,44(10,85)|<br>Prefere em grupo -<br>18(90)<br>Não prefere em grupo<br>- 17(85)<br>Prefere individual -<br>14(73,7)<br>Não prefere individual<br>- 12(75)|<br>6 meses||
|Cresci et al., 2007<sup>311</sup>|Programa cognitivo-|Abordagem em grupo|Abordagem individual|84|57|NR|NR|NR|36 meses||
|Waleekhachonloet et|comportamental<br>Terapia|Abordagem em grupo|Abordagem individual|65|67|38,28(8,15)|38,60(7,66)|NR|3 meses||
|al., 2007<sup>307</sup><br>Rigsby, Gropper e<br>Gropper 2009<sup>312</sup>|comportamental<br>Programa para perda de<br>peso estimulada por<br>competição|Abordagem em grupo|Abordagem individual|42|30|35,31(10,83)|39,53(9,51)|NR|8 semanas||
|Befort et al., 2010<sup>313</sup>|Terapia<br>comportamental com<br>aconselhamento por|Abordagem em grupo|Abordagem individual|16|18|47,6(12,5)|48,4(10,9)|NR|6 meses|219|  
|**Autor**|**Tipo de Abordagem**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade intervenção**<br>**media (DP)**|**Idade controle**<br>**média (DP)**|**N (%) sexo feminino**<br>**(intervenção/**<br>**controle)**|<br>**Tempo de seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||telefone para perda de<br>peso|||||||||
|Weinstock et al., 2013<sup>308</sup>|vida por telefone<br> <sup>intervenção no estilo de</sup>|Abordagem em grupo|Abordagem individual|128|129|52,7(12,8)|50,7(13,1)|92(71,9)/ 101(78,3)|2 anos|
|Mantzios e Giannou,<br>2014<sup>309</sup>|utilizado no Brasil)<br>Meditação Mindfulness<br>(Atenção Plena - nome|Abordagem em grupo|Abordagem individual|76|76|22,42(4,09)|23,38(4,77)|NR|6 semanas|
||NR – Não relatado|||||||||  
###### **Tabela D1.** Desfechos de eficácia.  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferência**<br>**abdominal**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||||||Pesos médios (DP) em lb<br>1 libra = 0,453592 Kg||||
|Straw e Terre,<br>1983<sup>302</sup>|Abordagem da<br>terapia padrão<br>em grupo|Dois grupos:<br>Controle 1: tratamento<br>padrão administrado<br>individualmente.<br>Controle 2: tratamento<br>individualizado<br>administrado<br>individualmente.|NR|NR|Grupo Intervenção<br>Peso inicial:<br>187,75 (30,79)<br>Perda após o tratamento: -7,25 (6,77)<br>Período de manutenção: -3,42 (6,79)<br>Controle 1 (padrão-individual)<br>Peso inicial: 191,21 (36,41)<br>Perda após o tratamento: -9,32 (6,91)<br>Período de manutenção: +4,58 (13,24)<br>Controle 2 (individualizado-individual)<br>Peso inicial:<br>188,36 (32,32)<br>Perda após o tratamento: -7,82 (7,35)<br>Período de manutenção: -3,25 (7,15)|A diferença entre<br>os grupos de<br>tratamento na<br>fase de<br>manutenção foi p<br><0,05|NR|NR|  
220  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferência**<br>**abdominal**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||||||Peso em lb<br>Grupo Intervenção 1<br>Peso inicial: 205,18<br>Perda após o tratamento: -23,42<br>Pós-tratamento-3 meses: -19,22<br>Pós-tratamento-12 meses: -11,81<br>Peso após 24 meses: 198,3||||
||||||Grupo Intervenção 2<br>Peso inicial: 219,1||||
||||||Perda após o tratamento: -24,87<br>Pós-tratamento-3 meses: -18,51||||
||||Grupo Intervenção 1<br>IMC inicial: 30,5||Pós-tratamento-12 meses: -16,29<br>Peso após 24 meses: 209,3||||
||Remuneração||Grupo Intervenção 2<br>IMC iiil 318||Grupo Intervenção 3<br>Peso inicial: 231,1|o diferencial<br>atribuível a|||
||pelo desempenho||nca: ,||Perda após o tratamento: -32,14|contratos de|||
||do grupo|Remuneração pelo|Grupo Intervenção 3||Pós-tratamento-3 meses: -24,64|grupo versus|||
|||desempenho individual|<br>IMC inicial: 328||Pós-tratamento-12 meses: 13,76|contratos|||
|Jeffery et al, 1983 e|Intervenção 1:||,|NR|Peso após 24 meses: 223,5|individuais|||
|1984<sup>303,304</sup>|$30|Controle 1: $30||||permaneceu|NR|NR|
||Intervenção 2:|Controle 2: $150|Grupo Controle 1<br>||Grupo Controle 1|estatisticamente|||
||$150|Controle 3: $300|IMC inicial: 31,0||Peso inicial: 211,9|significativo|||
||Intervenção 3:||G Ctl 2||Perda após o tratamento: -27,82|durante todo o|||
||$300||rupo onroe<br>||Pós-tratamento-3 meses: -24,75|período analisado|||
||||IMC inicial: 32,3||Pós-tratamento-12 meses: -18,84|p <0,05|||
||||Grupo Controle 3||Peso após 24 meses: 196,9||||
||||IMC inicial: 32,7||Grupo Controle 2||||
||||||Peso inicial: 226,8||||
||||||Perda após o tratamento: -27,82||||
||||||Pós-tratamento-3 meses: -24,75||||
||||||Pós-tratamento-12 meses: -18,84<br>Peso após 24 meses: 210,6||||
||||||Grupo Controle 3||||
||||||Peso inicial: 237,8||||
||||||Perda após o tratamento: -31,77||||
||||||<br>Pós-tratamento-3 meses: -26,27||||
||||||Pós-tratamento-12 meses: -14,56||||
||||||Peso após 24 meses: 223,8||||  
221  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferência**<br>**abdominal**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|Wright, Wood e<br>Hale, 1981<sup>310</sup>|Orientação<br>nutricional em<br>grupo|Orientação Nutricional<br>Individual|NR|NR|Peso corporal em Kg<br>Grupo Intervenção:<br>Média (DP) do peso inicial foi de 86,9 (8,8)<br>Após 12 semanas: 77,8 (6,3)<br>Após 52 semanas: 77,3 (5,0)<br>Em 52 semanas houve uma redução média<br>(DP) de -7,5 (5,1) (p <0,01)<br>Grupo Controle:<br>Média (DP) do peso inicial foi de 82,9 (8,7)<br>Após 12 semanas: 76,3 (8,0)<br>Após 52 semanas: 74,3 (6,9)<br>Em 52 semanas houve uma redução média<br>(DP) de -8,1 (2,0) (P <0,001)|p<0,01 para a<br>variação<br>p<0,001 para a<br>variação|Circunferência<br>Abdominal em cm<br>Grupo Intervenção:<br>Média (DP) inicial foi de<br>100,0 (5,1)<br>Após 12 semanas: 91,1<br>(6,4)<br>Após 52 semanas: 91,9<br>(6,8)<br>Em 52 semanas houve<br>uma redução média<br>(DP) de -7,1 (6,5)<br>Grupo Controle:<br>Média (DP) inicial foi de<br>97,7 (6,5)<br>Após 12 semanas: 90,4<br>(7,5)<br>Após 52 semanas: 90,8<br>(8,2)<br>Em 52 semanas houve<br>uma redução média<br>(DP) de -6,4 (3,9)|NR|
||||Grupo Intervenção:<br>Média (DP) do IMC inicial foi de 34,04<br>(4,54)||Peso corporal em Kg<br>Grupo Intervenção:<br>Média (DP) do peso inicial foi de 89,1<br>(11,71)<br>Variação em 6 meses: média (DP) de -9,35<br>(5,24)<br>Variação em 15 meses: média (DP) de -7,01||||
|Perri et al., 1997<sup>305</sup>|Exercício em<br>grupo|Exercício individual|Grupo Controle:<br>Média (DP) do IMC inicial foi de 33,10<br>(2,85)<br>Variação e IMC final não reportados|NR|(8,23)<br>Grupo Controle:<br>Média (DP) do peso inicial foi de 87,14<br>(6,29)<br>Variação em 6 meses: média (DP) de -10,40<br>(6,29)<br>Variação em 15 meses: média (DP) de -<br>10,65 (8,99)|NR|NR|NR|
|Renjilian et al.,<br>2001<sup>306</sup>|Tratamento em<br>grupo<br>Divididos em dois|Tratamento individual<br>Divididos em dois<br>grupos:|Grupo Intervenção 1:<br>Média (DP) do IMC inicial foi de 37,19<br>(4,11)|NR|Peso corporal em Kg<br>Grupo Intervenção 1:|NR|NR|NR|  
222  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferên**<br>**abdominal**|**cia**<br>**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||grupos:<br>Intervenção 1-<br>queriam ser<br>alocados no|Controle 1- queriam ser<br>alocados no tratamento<br>individual|Média (DP) do IMC final foi de 33,08<br>(4,08)<br>Média (DP) da mudança no IMC -4,11<br>(1.57)||Média (DP) do peso inicial foi de 98,38<br>(11,14)<br>Média (DP) do peso final foi de 87,53<br>(11,26)<br>Média (DP) da mudança no peso: -10,85||||
||tratamento em<br>grupo<br>Intervenção 2-<br>não queriam ser|Controle 2- não queriam<br>ser alocados no<br>tratamento individual|Grupo Intervenção 2:<br>Média (DP) do IMC inicial foi de 36,01<br>(4,36)<br>Média (DP) do IMC final foi de 31,76<br>(4,02)||(4,06)<br>Grupo Intervenção 2:<br>Média (DP) do peso inicial foi de 94,28<br>(13,72)||||
||alocados no||Média (DP) da mudança no IMC -4,25||Média (DP) do peso final foi de 83,11||||
||tratamento em||(2,11)||(12,29)||||
||grupo||Grupo Controle 1:<br>Média (DP) do IMC inicial foi de 35,84<br>(4,52)<br>Média (DP) do IMC final foi de 32,78<br>(4,54)||Média (DP) da mudança no peso: -11,19<br>(5,6)<br>Grupo Controle 1:<br>Média (DP) do peso inicial foi de 98,86<br>(15,73)||||
||||Média (DP) da mudança no IMC -3,06<br>(1,05)<br>Grupo Controle 2:<br>Média (DP) do IMC inicial foi de 35,66<br>(4,12)<br>Média (DP) do IMC final foi de 32,19<br>(4,60)<br>Média (DP) da mudança no IMC -3,47<br>(1,20)||Média (DP) do peso final foi de 90,38<br>(15,09)<br>Média (DP) da mudança no peso: -8,48<br>(3,00)<br>Grupo Controle 2:<br>Média (DP) do peso inicial foi de 96,86<br>(13,98)<br>Média (DP) do peso final foi de 87,24<br>(13,02)<br>Média (DP) da mudança no peso: -9,61<br>(4,17)||||
|Cresci et al., 2007<sup>311</sup>|Abordagem em<br>grupo|Abordagem individual|Abordagem em grupo: O IMC reduziu<br>de 37,0 para 36,7 kg/m2 após 6 meses<br>do início do tratamento.<br>Abordagem individual: O IMC reduziu<br>de 37,6 para 36,9 kg/m2 após 6 meses<br>do início do tratamento.|p<0,05<br>p<0,05|NR|NR|NR|NR|
|Waleekhachonloet<br>et al., 2007<sup>307</sup>|Abordagem em<br>grupo|Abordagem individual|IMC (kg/m 2)<br>Os dados são expressos como médias<br>ajustadas (S.E.)<br>Abordagem em grupo<br>Inicial 28,81 (0,31)|P < 0,01 para a<br>diferença da<br>linha de base<br>dentro do<br>grupo.|Peso em Kg<br>Os dados são expressos como médias<br>ajustadas (S.E.)<br>Abordagem em grupo<br>Inicial 69,73 (0,91)|P < 0,01 para a<br>diferença da linha<br>de base dentro do<br>grupo.|Circunferência<br>abdominal em cm<br>Os dados são expressos<br>como médias ajustadas<br>(S.E.)|P < 0,01 para a<br>diferença da linha de<br>base dentro do grupo.|  
223  
224  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferência**<br>**abdominal**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||||Mês 3: −1,10 (0,16)||Mês 3: −2.68 (0,38)||Abordagem em grupo||
||||Mês 6: −1,71 (0,21)||Mês 6: −4,18 (0,51)||Inicial 95,34 (0,91)||
||||Mês 12: −1,09 (0,24)||Mês 12: −2.67 (0,58)||Mês 3: −5,75 (0,72)||
||||||||Mês 6: −6,80 (0,76)||
||||Abordagem individual||Abordagem individual||Mês 12: −4,57 (0,82)||
||||Inicial 28,93 (0,39)||Inicial 70,13 (0,93)||||
||||Mês 3: −0,98 (0,15)||Mês 3: −2,38 (0,37)||Abordagem individual||
||||Mês 6: −1,58 (0,21)||Mês 6: −3,83 (0,51)||Inicial 94,60 (0,93)||
||||Mês 12: −0,97 (0,24)||Mês 12: −2,36 (0,58)||Mês 3: −5,16 (0,71)||
||||||||Mês 6: −6,33 (0,74)||
||||||Perda de peso (%)<br>Os dados são expressos como médias<br>ajustadas (S.E.)<br>Abordagem em grupo<br>Mês 3: 3,76 (0,53)<br>Mês 6: 5,88 (0,69)<br>Mês 12: 3,70 (0,79)||Mês 12: −3,30 (0,81)||
||||||Abordagem individual<br>Mês 3: 3,37 (0,52)<br>Mês 6: 5,38 (0,68)<br>Mês 12: 3,19 (0,78)||||
|Rigsby, Gropper e<br>Gropper, 2009<sup>312</sup>|Abordagem em<br>grupo|Abordagem individual|Abordagem em grupo Média (DP):<br>Inicial 32,3 (9,8)<br>Final 30,9 (9,8)<br>Redução de -1,3 (1,1)<br>Redução do IMC como porcentagem do<br>IMC inicial (%): 4,3 (3,7)<br>Abordagem individual Média (DP):<br>Inicial 34,6 (8,4)<br>Final 33,8 (8,3)<br>Redução de 0,7 (1,1)<br>Redução do IMC como porcentagem do<br>IMC inicial (%): 2,2 (3,4)|p=0,025<br>comparando os<br>grupos em<br>relação à<br>redução de<br>IMC.<br>p=0,016<br>comparando os<br>grupos em<br>relação à<br>redução<br>percentual do<br>IMC.|Abordagem em grupo Média (DP), peso<br>expresso em lb:<br>Inicial 197,1 (57,0)<br>Final 189,5 (56,8)<br>Redução de -7,6 (1,1)<br>Redução de peso em percentagem do peso<br>inicial (%): 4,0 (3,7)<br>Abordagem individual Média (DP), peso<br>expresso em lb:<br>Inicial 205,2 (50,4)<br>Final 201,2 (50,0)<br>Redução 4,2 (6,4)<br>Redução de peso em percentagem do peso<br>inicial (%): 1,9 (3,4)|p=0,036<br>comparando os<br>grupos em<br>relação à redução<br>do peso.<br>p=0,015<br>comparando os<br>grupos em<br>relação ao<br>percentual de<br>peso perdido.|NR|NR|
||Abordagem em||||Grupo Intervenção<br>Média (DP) da mudança de peso (Kg):|p<0,01 para a<br>diferença após 24|||
|Befort et al., 2010<sup>313</sup>|grupo|Abordagem individual|NR|NR|Após 16 semanas: −13,54 (3,83)<br>Após 24 semanas: −14,91 (4,44) p <0,01|semanas de<br>tratamento|NR|NR|  
225  
226  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfecho do Índice de Massa Corporal**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho da Circunferên**<br>**abdominal**|**cia**<br>**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||||||Grupo Controle<br>Média (DP) da mudança de peso (Kg):<br>Após 16 semanas: −9,24 (3,93)<br>Após 24 semanas: −9,53 (5,20) p <0,01||||
||||||Peso em Kg<br>Grupo Intervenção:||||
||||||Redução percentual média (DP, p-valor) no||Circunferência||
||||Grupo Intervenção:||peso em 6 meses: -4,0% (14,8%, p <0,001)||abdominal em cm:||
||||Redução média no IMC em 12 meses: -<br>1,74||Redução percentual média (DP) no peso em<br>12 meses: - 4,5% (20,3%, p <0,001)||Grupo Intervenção:<br>Redução média (DP) em||
||||Redução média no IMC em 24 meses: -||Redução percentual média (DP) no peso em||12 meses: -4,5 (19,5)|A diminuição média|
|Weinstock et al.,<br>2013<sup>308</sup>|Abordagem em<br>grupo|Abordagem individual|2,1<br>Grupo Controle:|NR|24 meses: -5,6% (26,8%, p <0,001).<br>Grupo Controle:||Redução média (DP) em<br>24 meses: -3,1 (15,5)|da circunferência da<br>cintura não diferiu<br>significativamente|
||||Redução média no IMC em 12 meses: -||Redução percentual média (DP, p-valor) no||Grupo Controle:|entre os dois braços.|
||||1,7||peso em 6 meses: -3,9% (15,2%, p <0,001)||Redução média (DP) em||
||||Redução média no IMC em 24 meses: -||Redução percentual média (DP, p-valor) no||12 meses: -5,0 (19,4)||
||||0,8||peso em 12 meses: - 4,2% (16,9%, p <0,001)||Redução média em 24||
||||||Redução percentual média (DP, p-valor) no<br>peso em 24 meses: -1,8 % (18,6%, p =||meses: -2,4 (15,5)||
||||||0,046)||||
||||Grupo Intervenção||Grupo Intervenção||||
||||Média (DP) do IMC:||Média (DP) de peso (Kg):||||
||||Inicial: 28,54 (1,56)||Inicial: 88,79 (12,72)||||
|Mantzios e|Abordagem em||Após 6 semanas: 27,51 (1,96)||Após 6 semanas: 86,96 (12,29)||||
|<br>Giannou 2014<sup>309</sup>|<br>grupo|Abordagem individual|Grupo Controle<br>Média (DP) do IMC:|NR|Grupo Controle<br>Média (DP) de peso (Kg):|NR|NR|NR|
||||Inicial: 28,94 (1,55)||Inicial: 93,78 (11,51)||||
||||Após 6 semanas: 28,59 (1,94)||Após 6 semanas: 93,26 (11,67)||||  
**Legenda:** ECR – Ensaio Clínico Randomizado. NR – Não relatado. Lb - libras  
**Figura U** . Sumário do risco de viés: julgamento dos revisores sobre cada item do risco de viés para cada ensaio clínico randomizado incluído.  
227  
<!-- Start of picture text -->
=<br>& © <<br>a 8 2 3<br>Bese 2 e238<br>[e/9/e/e/e/e/e/e Random sequence generation (selection bias)<br>|@|e/e/e/e/elele| Allocation concealment (selection bias)<br>|@|e/e/e/e/e/e/e| Blinding of participants and personnel (performance bias)<br>|@|e/e/e/e/elele| Blinding of outcome assessment (detection bias)<br>\e\elele|sielele| Incomplete outcome data (attrition bias)<br>|@|2|2/e/9/a/a/e| Selective reporting (reporting bias)<br><!-- End of picture text -->  
228  
###### **<u>Quadro F1.</u>** Sumarização dos resultados dos estudos incluídos (Summary of Findings (SoF) do _webapp_ Grade PRO).  
||||**Avaliação d**|**a certeza**|||**Imacto**|**Certeza**|**Imortância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**p**||**p**|
|<br>**Redução d**<br>|<br>**e peso (seguiment**<br>|**o: variação 6 sema**<br>|**nas para 52 semana**<br><sup>b</sup>|<br>**s)**<br>||||||
|10|8 ensaios<br>clínicos<br>randomizados<br>2 ensaios<br>clínicos não<br>randomizados|muito grave<sup>a</sup>|grave|não grave|grave<sup>c</sup>|nenhum|Dos estudos incluídos, quatro estudos favorecerem a abordagem individual, seis<br>favoreceram a abordagem em grupo e um estudo não apresentou diferença entre<br>as intervenções. Pôde-se observar que ambas intervenções (em grupo ou individual)<br>reduzem o peso, no entanto não há como avaliar qual das duas é a mais efetiva. O<br>risco de viés em geral dos estudos foi considerado alto risco ou risco incerto. Apesar<br>de a maioria dos estudos serem randomizados, eles não relataram como foi feita a<br>randomização e sigilo de alocação. A maioria dos estudos eram abertos, ocorreram<br>perdas de seguimento, entretanto não há relato de tratamento estatístico<br>específico, como análise por intenção de tratar, por exemplo. Em relação ao<br>domínio cegamento o risco foi incerto em todos os estudos, o cegamento dos<br>pacientes e dos profissionais foi comprometido em todos (eram abertos).<br>Entretanto, considerando as intervenções em questão, o cegamento era algo<br>impossível tecnicamente. Considerando ainda os desfechos avaliados, foi<br>considerado como incerto o risco da ausência de cegamento sobre os resultados. No<br>domínio relato seletivo, tomou-se por padrão conferir os resultados apresentados<br>com o proposto previamente em protocolo publicado. Artigos cujo protocolo não foi<br>identificado foram classificados como “risco incerto”. Entre os estudos avaliados,<br>em alguns, a magnitude do efeito favoreceu a intervenção em grupo, enquanto que<br>em outros estudos foi favorecida a intervenção individual. Assim, não é possível<br>avaliar qual o real efeito da intervenção avaliada (abordagem em grupo). Da mesma<br>forma, muitos estudos avaliaram um número pequeno de participantes. Os estudos<br>foram considerados heterogêneos devido à diferença na população avaliada (alguns<br>estudos avaliaram somente homens, em outros somente mulheres), os tipos de<br>intervenções analisadas também diferiram entre os estudos, apesar de avaliar<br>intervenção em grupo versus individual (terapia cognitivo comportamental,<br>meditação, terapia nutricional, exercício físico), o que pode levar a resultados<br>diferentes. Os tempos de seguimento também foram diferentes entre os estudos.<br>Além disso, cada estudo utilizou critérios de inclusão em relação ao IMC diferentes<br>entre si, o que também pode ter favorecido a heterogeneidade entre eles.|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|
|**Redução d**|**e IMC (seguimento**|**: variação 6 seman**|**as para 2 anos)**|||||||
|6|4 ensaios<br>clínicos<br>randomizados<br>2 ensaios<br>clínicos não<br>randomizados|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>d</sup>|nenhum|Dos seis estudos que avaliaram esse desfecho, quatro favoreceram a abordagem em<br>grupo, um favoreceu a abordagem individual e um não houve diferença entre as<br>abordagens. Apesar dos estudos objetivarem avaliar a diferença entre intervenção<br>em grupo e intervenção individual, o tipo de intervenção variou muito entre os<br>mesmos. Não é possível atribuir o efeito redução do IMC ao fato de ser grupo ou<br>individual, pois a redução pode ter ocorrido em razão do tipo de intervenção<br>utilizada (orientação nutricional versus prática de exercícios, por exemplo. Devido à<br>alta heterogeneidade, não é possível avaliar se a intervenção é mais eficaz na<br>redução do IMC que a abordagem individual.|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|
|**Redução d**|**e circunferência ab**|**dominal (seguime**|**nto: variação 2 ano**|**s para 3 anos)**||||||  
229  
||||**Avaliação d**|**a certeza**|||**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**||||
|3|2 ensaios<br>clínicos<br>randomizados<br>1 ensaio<br>clínico não<br>randomizado|muito grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>d</sup>|nenhum|Dos três estudos, dois favoreceram a abordagem em grupo e um a abordagem<br>individual.<br>Um ECR avaliou o efeito da orientação nutricional e mostrou resultados que<br>favoreceram a abordagem em grupo. Após 12 meses de seguimento, quem<br>participou da intervenção em grupo teve uma redução média (SE) de −4,57cm (0,82)<br>de circunferência abdominal, enquanto quem participou da intervenção individual<br>teve uma perda média (SE) de −3,30 cm (0,81). Um estudo clínico não-randomizado<br>avaliou o efeito do contato telefônico para mudança de estilo de vida e mostrou que<br>os resultados favoreceram a abordagem em grupo. Em 52 semanas quem participou<br>da abordagem em grupo teve uma redução média (DP) de -7,1 cm (6,5) cm na<br>circunferência abdominal, enquanto quem participou da abordagem individual teve<br>uma redução média (DP) de -6,4 cm (3,9) na circunferência abdominal.<br>Um ECR avaliou o efeito da terapia comportamental e mostrou resultados que<br>favoreceram a intervenção individual. Após 12 meses de seguimento, quem<br>participou da intervenção em grupo teve uma redução média (DP) de -4,5 cm (19,5)<br>na circunferência abdominal, enquanto quem participou da intervenção individual, -<br>5,0cm (19,4).<br>Considerando essas diferenças entre os estudos, não é possível afirmar que a<br>redução se deve à intervenção em grupo ou individual ou se a diferença foi em<br>razão do tipo de intervenção realizada por cada estudo em particular.|⨁◯◯◯<br>MUITO BAIXA|CRÍTICO|  
###### EXPLICAÇÕES  
a. Estudos com alto risco ou risco incerto. Não relataram como foi feita a randomização, estudos abertos, ocorreram perdas de seguimento e sem relato de análise por intenção de tratar. Cegamento dos profissionais foi comprometido em todos.  
b. Alta heterogeneidade entre os estudos, diferentes tempos de seguimento e diferentes critérios de inclusão.  
c. Não foi possível avaliar o efeito da intervenção.  
d. Considerada a imprecisão alta devido às diferenças nos resultados.  
###### **Quadro G1.** Sumarização das evidências para tomada de decisão ( _Evidence to Decision table_ (EtD) do _webapp_ GRADE PRO).

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
|**Deve-se usar**|**Abordagem individual vs. abordagem em grupo para perda de peso em Kg?**|
|---|---|
|**POPULAÇÃO**|perda de peso em Kg|  
230  
|**INTERVENÇÃO**|Abordagem individual|
|---|---|
|**COMPARAÇÃO**|abordagem em grupo|
|**DESFECHOS**|Perda de peso (Kg); Redução de IMC (Kg/m2); Redução do perímetro da cintura (cm);|
|**PRINCIPAIS**||
|**CENÁRIO**|Qualquer intervenção em grupo ou individual para a perda de peso, desde que a intervenção fosse a mesma em ambos os grupos e a diferença seja atribuída apenas ao fato de ser em grupo<br>ou individual|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
|Problema<br>O problema é uma|prioridade?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente<br>Não<br>○ Provavelmente<br>sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>A obesidade mundial quase triplicou desde 1975.<br><br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.<br><br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais pessoas do que abaixo do peso.<br><br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.<br><br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou obesas em 2016.<br><br>A obesidade é evitável.|
|Efeitos Des<br>Quão substanciais|ejáveis<br>são os efeitos desejáveis?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>○Pequeno<br>● Moderado<br>○ Grande<br>○ Variável|**IMPORTANTE: Numa análise geral, ambas as abordagens, independente do teste estatístico para diferença entre elas, promovem redução de peso, IMC e circunferência abdominal. Abaixo**<br>**estão detalhadas as comparações quanto a superioridade de uma abordagem em relação à outra.**|  
231  
- Incerto **Desfecho Primário: Perda de peso**  
Terapias psicológicas (individual versus Grupos)  
- A maioria dos estudos avaliados mostrou que, em pelo menos um período de avaliação, geralmente o mais precoce, os tratamentos psicológicos em grupo apresentaram melhores resultados que os tratamentos individuais. Apenas um estudo mostrou superioridade da terapia individual. O restante dos estudos não exibiu diferenças entre as modalidades individual e em grupo. No entanto, cabe destacar que a qualidade geral da evidência é muito baixa, com alto risco de viés.  
Exercício físico (Individual versus Grupos)  
- Maior perda de peso para o grupo que realizou sessões individuais, porém não foi relatada diferença estatisticamente significante.  
Educação nutricional (Individual Versus grupos)  
- Apenas um estudo avaliou essa comparação para o desfecho perda de peso. Os resultados favoreceram a educação nutricional em grupo.  
Múltiplas intervenções combinadas (individual versis Grupos)  
- O único estudo avaliado mostrou que o a abordagem em grupo foi superior.  
###### **Desfecho: IMC**  
Terapias psicológicas (individual versus Grupos)  
- Apenas um dos quatro estudos avaliados mostrou, claramente, a superioridade da abordagem em grupo. Os demais sugerem que ambas as abordagens promovem perda de peso significante, porém não diferenciaram as modalidades.  
Múltiplas intervenções combinadas (Individual versus grupos)  
- O único estudo avaliado mostrou que houve superioridade da abordagem em grupo.  
###### **Desfecho: Redução da circunferência da cintura**  
Terapias psicológicas (individual versus Grupos)  
232  
- Um dos estudos avaliados mostrou superioridade da terapia em grupo em 6 e 12 meses, se comparada à abordagem individual. O outro estudo relatou não haver diferença na redução da circunferência da cintura entre grupos, mas não forneceu resultado de teste estatístico.  
Exercício físico (Individual versus Grupos)  
- Todos os grupos levaram a uma redução da circunferência da cintura, mas não foi relatada a significãncia estatística para a diferença entre as abordagens em grupo e individual.  
#### Efeitos Indesejáveis  
Quão substanciais são os efeitos indesejáveis?  
- JULGAMENTO EVIDÊNCIAS DE PESQUISA CONSIDERAÇÕES ADICIONAIS ○Trivial **IMPORTANTE: Numa análise geral, ambas as abordagens, independente do teste estatístico para diferença entre elas, promovem redução de peso, IMC e circunferência abdominal. Abaixo** ○ Pequeno **estão detalhadas as comparações quanto a superioridade de uma abordagem em relação à outra.** ○ Moderado ○ Grande ○ Variável ● Incerto **Desfecho Primário: Perda de peso** Terapias psicológicas (individual versus Grupos)  
- A maioria dos estudos avaliados mostrou que, em pelo menos um período de avaliação, geralmente o mais precoce, os tratamentos psicológicos em grupo apresentaram melhores resultados que os tratamentos individuais. Apenas um estudo mostrou superioridade da terapia individual. O restante dos estudos não exibiu diferenças entre as modalidades individual e em grupo. No entanto, cabe destacar que a qualidade geral da evidência é muito baixa, com alto risco de viés.  
- Exercício físico (Individual versus Grupos)  
- Maior perda de peso para o grupo que realizou sessões individuais, porém não foi relatada diferença estatisticamente significante.  
Educação nutricional (Individual Versus grupos)  
233  
- Apenas um estudo avaliou essa comparação para o desfecho perda de peso. Os resultados favoreceram a educação nutricional em grupo.  
Múltiplas intervenções combinadas (individual versis Grupos)  
- O único estudo avaliado mostrou que o a abordagem em grupo foi superior.  
###### **Desfecho: IMC**  
Terapias psicológicas (individual versus Grupos)  
- Apenas um dos quatro estudos avaliados mostrou, claramente, a superioridade da abordagem em grupo. Os demais sugerem que ambas as abordagens promovem perda de peso significante, porém não diferenciaram as modalidades.  
Múltiplas intervenções combinadas (Individual versus grupos)  
- O único estudo avaliado mostrou que houve superioridade da abordagem em grupo.  
###### **Desfecho: Redução da circunferência da cintura**  
Terapias psicológicas (individual versus Grupos)  
- Um dos estudos avaliados mostrou superioridade da terapia em grupo em 6 e 12 meses, se comparada à abordagem individual. O outro estudo relatou não haver diferença na redução da circunferência da cintura entre grupos, mas não forneceu resultado de teste estatístico.  
Exercício físico (Individual versus Grupos)  
- Todos os grupos levaram a uma redução da circunferência da cintura, mas não foi relatada a significãncia estatística para a diferença entre as abordagens em grupo e individual.  
234  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|||
|---|---|---|---|
|● Muito Baixa<br>○ Baixa<br>○ Moderada<br>○ Alta<br>○ Sem estudos<br>|A qualidade geral da evidência, independentemente dos desfechos, foi muito baixa. Isso se deve ao<br>seguimento distintos, imprecisão nas estimativas.|alto risco de viés apresentado, à heteroge|neidade das intervenções e populações; tempos de|
|ncuos||||
||**Desfechos**|**Importância**|**Certainty of the evidence**<br>**(GRADE)**|
||Perda de peso (Kg)<br>seguimento: variação 6 semanas para 52 semanas|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,b,c</sup>|
||Redução de IMC (Kg/m2)<br>seguimento: variação 6 semanas para 2 anos|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,c,d</sup>|
||Redução do perímetro da cintura (cm)<br>seguimento: variação 2 anos para 3 anos|CRÍTICO|⨁◯◯◯<br>MUITO BAIXA<sup>a,c,d</sup>|  
- a. Alta heterogeneidade entre os estudos, diferentes tempos de seguimento e diferentes critérios de inclusão.  
- b. Não foi possível avaliar o efeito da intervenção  
- c. Estudos com alto risco ou risco incerto. Não relataram como foi feita a randomização, estudos abertos, ocorreram perdas de seguimento e sem relato de análise por intenção de tratar. Cegamento dos profissionais foi comprometido em todos  
- d. Considerada a imprecisão alta devido às diferenças nos resultados.  
235  
|Valores||
|---|---|
|Existe importante|incerteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Importante<br>incerteza ou<br>variabilidade<br>○ Possível|**Os desfechos foram positivos para perda de peso, independentemente, da abordagem utilizada. Em alguns casos houve superioridade das modalidades em grupo. Como foram avaliadas**<br>**intervenções diferentes, o nível de valor atribribuído pelas pessaos deve levar em conta a disponibilidade da intervenção (nutrição, exercício, terapia pesicológica ou a combinação delas) e**<br>**as possíveis limitações econômicas e físicas que os participantes possam, eventualmente, ter.**|
|Importante||
|incerteza ou||
|variabilidade<br>● Provavelmente|**A vontade do indivíduo em participar em contraste ao resultado**|
|nenhuma||
|Importante||
|incerteza ou||
|variabilidade<br>○ Sem|O individualismo e o coletivismo tornaram-se o principal meio de comparação entre sociedades em psicologia intercultural e outras disciplinas comparadas. Algumas sociedades, em grande<br>parte não asiáticas, concentram-se na natureza coletiva da obrigação social, enquanto a psicologia ocidental tradicional se concentra na primazia do indivíduo (1).|
|importante<br>incerteza ou<br>variabilidade|O coletivismo de nível individual foi significativamente relacionado ao melhor autocontrole comportamental, mas não foram encontrados resultados significativos para a relação entre o<br>individualismo de nível individual e o autocontrole comportamental (2).|
||1. Kim, U., Triandis, H. C., Kâğitçibaşi, Ç., Choi, S.-C., & Yoon, G. (Eds.). (1994)._Cross-cultural research and methodology series, Vol. 18. Individualism and collectivism: Theory, method, and_<br>_applications._Thousand Oaks, CA, US: Sage Publications, Inc.|  
236  
||2. Is individualism-collectivism as|sociated with self-control? Evidence from Chinese and U.S. samples. PLoS One. 2018 Dec 19;13(12).|
|---|---|---|
|Balanço do<br>O balanço entre ef|s efeitos<br>eitos desejáveis e indesejáveis fav|orece a intervenção ou o comparador?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Favorece o<br>comparador<br>○ Provavelmente|Devido ao baixo nível de certeza<br>abordagens (individual e em gru|atribuído à evidência analisada, não possível concluir a favor de uma das abordagens. No entanto, em relação aos valores basais dos defechos analisados, ambas<br>po) propiciam a redução do peso.|
|favorece o|||
|comparador|||
|○ Não favorece|||
|um e nem o<br>outro|||
|● Provavelmente|||
|favorece a|||
|intervenção<br>○ Favorece a|||
|intervenção<br>○ Variável<br>○ Incerto|||
|Equidade|||
|Qual seria o impac|to em equidade em saúde?||
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Reduzida|As carcterísticas populacionais d|evem ser levadas em conta. Uma série de publicações relaciona a pobreza à saúde mental, tendo como co-fatores a obesidade, o nível de estresse, a baixa|
|○ Provavelmente<br>reduzida<br>○ Provavelmente<br>nenhum impacto<br>● Provavelmente<br>aumentada<br>○ Aumentada|prática esportiva/atividades de la<br>discussão do acesso. Para as tera<br>livre/academia da cidade, que po<br>(2).|zer, má alimentação/nutrição por excesso, alto consumo de produtos industrializados (1). Dessa forma, a discussão quanto ao benefíecio em eficácia, permeia a<br>pias psicológicas, por exemplo, o SUS já disponibiliza procedimentos individuais e coletivos de assistência à saúde. Existem os programas de academia ao ar<br>dem ser alvos de estimulo à prática de exercícios individuais e coletivos. Ademais, várias publicações do MS e da OMS relatam práticas de alimentação saudável|
|○ Variável<br>○ Incerto|||  
237  
1. MENTAL HEALTH AS A PUBLIC HEALTH ISSUE: Article List on Interactions Between Poverty and Mental Health. Disponível em: <u>https://pdfs.semanticscholar.org/f377/fef762f1b42cb11146972e783a34c474479a.pdf, acesso em 09/08/2019</u>  
2. Guia alimentar: como te uma alimentação saudável. Ministério da Saúde. 2013. Disponível em:  
<u>http://bvsms.saude.gov.br/bvs/publicacoes/guia_alimentar_alimentacao_saudavel_1edicao.pdf, Acesso em: 09/08/2019</u>  
#### Aceitabilidade  
A intervenção é aceitável para os principais atores sociais ( _stakeholders_ )?  
- JULGAMENTO EVIDÊNCIAS DE PESQUISA CONSIDERAÇÕES ADICIONAIS ○ Não  Intervenções simples, sem eventos adversos relatados; ○ Provavelmente  Traz benefícios de perda de peso, redução de IMC e de circunferência abdominal à população com sobrepeso e obesidade; não  Possibilidade de redução com custos de agravos em saúde, com possibilidade redução de ônus ao sistema;  
- ○Provavelmente sim  Estímulo à maior participação de profissionais da nutrição, ed. física e psicologia; ● Sim  Alguns procedimentos já disponíveis no SUS. ○ Variável ○ Incerto

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
||||**JU**|**LGAMENTO**|||
|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**|Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|Pequeno|**Moderado**|Grande|Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|Trivial|Varia|**Incerto**|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta||Sem estudos incluídos|  
238  
|||||**JULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Provavelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sme**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece nem a<br>intervenção nem a<br>comparação|**Provavelmente**<br>**favorece a intervenção**|Favorece a intervenção|Varia|Incerto|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|Provavelmente sem<br>impacto|**Provavelmente**<br>**aumentada**|Aumentada|Varia|Incerto|
|**ACEITABILIDADE**|Não|Provavelmente não|Provavelmente sim|**Yes**||Varia|Incerto|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
|Recomendação forte contra a intervenção<br>Recomendação condicional contra a|Não favorece nem uma nem outra|**Recomendação condicional a favor da**|Recomendaçõa forte a favor da|
|---|---|---|---|
|intervenção||**intervenção**|intervenção|
|○<br>○|○|**●**|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 9 - PERGUNTA PICO 8** -->
#### Recomendação  
Recomenda-se que a abordagem inicial do indivíduo com obesidade seja realizada em grupos. De acordo com a resposta às terapias propostas, o usuário pode ser direcionado para uma abordagem individual. O tamanho dos grupos deve ser planejado de forma a permitir o maior contato possível entre os indivíduos, evitando-se grupos muito grandes.  
239

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
**Questão de pesquisa: “Qual o efeito do suporte psicológico na perda de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era a suporte psicológico (entrevista motivacional, terapia cognitivocomportamental, terapia cognitiva e terapia comportamental) (C) não fazer nada, cuidado usual, educação em saúde, entrevistas não motivacionais e outros tipos de suporte psicológicos; e desfechos (O) alteração no peso corpóreo, no IMC e na medida da circunferência da cintura desde a linha de base.  
###### **A. Estratégia de busca**  
**<u>Quadro H1.</u>** Estratégias de busca de evidências em base de dados  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|((("Motivational<br>Interviewing"[Mesh]<br>OR<br>"Cognitive<br>Therapy"[Mesh] OR Cognitive Behavioral Therapy OR motivational<br>Therapy OR motivational interviewing OR motivational counseling))<br>AND (("Weight Loss"[Mesh] OR weight loss OR weight reduction)))<br>AND (("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight))<br>Data da busca: 09/11/2018|1.027|
|**EMBASE**|((('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim) AND (('body weight loss'/exp OR<br>'body weight loss' OR 'weight loss'/exp OR 'weight loss' OR 'weight<br>reduction'/exp OR 'weight reduction')) AND embase]/lim AND<br>(('motivational interview'/exp OR 'motivational interview' OR<br>'cognitive behavioral treatment'/exp OR 'cognitive behavioral<br>treatment' OR 'cognitive behavioral therapy'/exp OR 'cognitive<br>behavioral therapy' OR 'motivational therapy' OR 'motivational<br>interviewing'/exp OR 'motivational interviewing' OR 'motivational<br>counseling') AND [embase]/lim))<br>Data da busca: 09/11/2018|454|  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 1.481 referências (1.027 no MEDLINE e 454 no EMBASE). Destas, 191 foram excluídas por estarem duplicadas. Um total de mil duzentas e noventa referências foram triadas por meio da leitura de título e resumos, das quais 58 tiveram seus textos completos avaliados para confirmação da elegibilidade. Nesta última etapa da seleção,  
240  
da leitura completa dos artigos, 37 estudos foram excluídos ( **Quadro 13** ). Assim, um total de 24 estudos (26 artigos) atenderam aos critérios de inclusão ( **Figura 22** ). Ademais, foram realizadas buscas manuais nas referências dos artigos incluídos, visando recuperar o maior número de estudos possíveis. Todos estes 24 estudos incluídos foram analisados quanti e qualitativamente.  
**Figura V.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.481<br>PUBMED = 1.027<br>EMBASE= 454<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>1.290  critérios de exclusão: 1.232<br>Publicações excluídas segundo<br>critérios de exclusão: 37<br>Publicações selecionadas para leitura<br>completa: 58<br>Tipo de delineamento: 6<br>Tipo de participante: 6<br>Tipo de intervenção: 21<br>Tipo de desfecho: 3<br>Tipo de comparador: 1<br>Estudos incluídos: 24 (26 relatos)<br>Seleção: 19 (21 relatos)<br>Busca manual: 5<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**<u>Quadro I1.</u>** Estudos excluídos e seus respectivos motivos.  
|**Autor, ano**|**Critério de exclusão**|**Motivo de exclusão detalhado**|
|---|---|---|
|Duchesne, 2006<sup>314</sup>||Revisão narrativa.|
|Barnes, 2018<sup>315</sup>|Ti d dli|Sem comparador.|
|Simpson, 2015<sup>316</sup>|po e eneamento|Revisão narrativa.|
|Brennan, 2013<sup>317</sup>||Protocolo de RS|  
241  
|Devlin, 2005<sup>318</sup>||ECR fatorial, não sendo possível separar o efeito da TCC do<br>placebo ou da fluoxetina.|
|---|---|---|
|Berk, 2012<sup>319</sup>||Estudo piloto.|
|Barnes, 2015<sup>320</sup>||Revisão sistemática que incluiu estudo de participantes<br>não obesos e não apresentava análise de sub-grupo.|
|Armstrong, 2011<sup>321</sup>||Revisão sistemática que incluiu estudo de participantes<br>não obesos e não apresentava análise de sub-grupo.|
|Khazaal, 2007<sup>322</sup>|Tipo de participante|Indivíduos em uso de psicotrópicos que ganharam peso,<br>não necessariamente portadores de sobrepeso ou<br>obesidade.|
|Lawlor, 2018<sup>323</sup>||Protocolo de revisão sistemática.|
|Grilo, 2005<sup>324</sup>||Pacientes adultos e crianças com 100 a 200% o peso ideal,<br>mas não relata se são portadores de sobrepeso ou<br>obesidadepelo IMC.|
|Klósek, 2018<sup>325</sup>||Crianças|
|Hartmann-Boyce,<br>2017<sup>326</sup>||Avalia estratégias comportamentais e cognitivas e não a<br>terapia.|
|Huber, 2015<sup>327</sup>||_Telecoaching._|
|Palavras, 2017<sup>328</sup>||Revisão sistemática que incluiu estudo de outras<br>intervenções e não apresentava análise de sub-grupo.|
|Palmeira, 2017<sup>329</sup>||Intervenção baseada em base em aceitação, atenção e<br>compaixão.|
|Jacob, 2018<sup>330</sup>||Revisão sistemática que incluiu estudo de outras<br>intervenções e não apresentava análise de sub-grupo.|
|Casagrande, 2010<sup>331</sup>||Perda de peso comportamental.|
|Jiskoot, 2018<sup>332</sup>||Mudança de estilo de vida.|
|Ma, 2015<sup>333</sup>||Programa de mudança no estilo de vida e aumento da<br>atividade física.|
|Annesi, 2015<sup>334</sup>||Associação de tratamentos comportamentais + exercício<br>vs. Educação nutricional.|
|Tyson, 2015<sup>335</sup>||Perda de peso comportamental.|
|Young,<br>2017<sup>336</sup>||Programa de gerenciamento de peso.|
|Booth, 2014<sup>337</sup>|Tipo de intervenção|Revisão sistemática que incluiu estudo de outras<br>intervenções e não apresentava análise de sub-grupo.|
|Eldredge, 1997<sup>338</sup>||Todos receberam cognitivo antes da randomização e<br>depois foram divididos em perda e peso comportamental<br>ouplacebo.|
|Ruffault, 2017<sup>339</sup>||Atenção plena.|
|Prost, 2016<sup>340</sup>||Revisão sistemática que incluiu estudo de outras<br>intervenções e não apresentava análise de sub-grupo.|
|Turner-McGrievy,<br>2009<sup>341</sup>||_Podcast_de perda de peso baseado na teoria cognitiva<br>social.|
|Wilson, 2011<sup>342</sup>||Auto-ajuda guiada baseada na terapia cognitivo-<br>comportamental.|
|Grilo, 2005<sup>343</sup>||Auto-ajuda guiada baseada na terapia cognitivo-<br>comportamental.|
|Grilo, 2013<sup>344</sup>||Auto-ajuda guiada baseada na terapia cognitivo-<br>comportamental.|
|Stahre, 2005<sup>345</sup>||novo programa cognitivo de redução de peso a curto<br>prazo.|
|Rieger, 2017<sup>346</sup>||Congitivo + Suporte pessoal vs. Cognitivo, logo avalia o<br>suportepessoal.|
|Michelini, 2014<sup>347</sup>||Adesão ao tratamento.|
|Grilo, 2012<sup>348</sup>|Tipo de desfecho|Preditores da resposta a TCC.|
|Grilo, 2012<sup>349</sup>||Analisa a rápida resposta na redução de episódios de<br>compulsão alimentar.|
|Majanovic, 2014<sup>350</sup>|Tipo de comparador|Balão gástrico.|  
242  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se no **Tabela E1** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela F1** . Resultados encontram-se na **Tabela G1.** Nas **Figuras W** a **G1** constam as meta-análises realizadas para os desfechos de perda de peso contínua, alteração de IMC e circunferência abdominal e perda de peso clinicamente significante (≥ 10%). O risco de viés dos estudos incluídos encontra-se na **Figura H1** . O **Quadro J1** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
243  
**Tabela E1.** Características dos ensaios clínicos incluídos para avaliar o suporte psicológico (TCC e EM) em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|
|2012<sup>351,352</sup><br>Munsch 2007 e|com compulsão alimentar.<br>Determinar a eficácia da TCC e TPPC em pacientes com sobrepeso e|80|TCC|TPPC|
|West 2007<sup>353</sup>|Determinar se a adição de EM ao TPPC melhora os resultados de perda<br>de peso e controle glicêmico para mulheres com sobrepeso e diabetes<br>tipo 2.|217|EM individual + TPPC|TPPC|
|Linde 2010<sup>354</sup>|Examinar os efeitos da TCC e da TCC + TPPC na perda de peso e|203|TCC +TPPC|TPPC|
|Castelnuovo|sintomas depressivos em mulheres com obesidade e depressão.<br>Comparar a eficácia da TEB e TCC na redução de peso em mulheres|60|TCC|TEB|
|2011<sup>355</sup><br>Grilo 2011<sup>356</sup>|obesas com compulsão alimentar.<br>Comparar a eficácia de TCC, TPPC em pacientes obesos com<br>compulsão alimentar.|120|TCC<br>TCC + TPPC|TPPC|
|Tárraga 2014<sup>357</sup>|efetiva empacientes com sobrepeso e obesidade.<br>Determinar se a adição de entrevista motivacional ao cuidado usual é|696|EM em grupo + Cuidado usual|Cuidado usual|
|Muggia 2014<sup>358</sup>|compulsão alimentar.<br>Avaliar a eficácia da TCC em adição a dieta em pacientes obesos sem|163|TCC + Cuidado usual|Cuidado usual|
|e 2016<sup>359,360</sup><br>Mirkarimi 2015|sobrepeso e obesidade.<br>Investigar o efeito da EM no programa educacional em mulheres com|150|EM emgrupo<br>EM em grupo + educação<br>nutricional|Educação nutricional|
|Zwaan 2015<sup>361</sup>|Determinar se a adição de TCC ao cuidado usual em mulheres obesas|71|TCC + Cuidado usual|Cuidado usual|
|Wagner 2016<sup>362</sup>|com compulsão alimentar.<br>Investigar a eficácia da TCC baseada em internet em adultos com|139|Programa de internet baseado TCC|Lista de espera|
|Barnes 2017<sup>363</sup>|sobrepeso e compulsão alimentar.<br>Avaliar os efeitos da entrevista motivacional e da psicoeducação<br>nutricional com suporte web em adultos com sobrepeso e com ou sem<br>compulsão alimentar.|59|EM Web|Psicoeducação nutricional Web|
|Rodriguez-<br>Cristobal<br>2017<sup>364</sup>|Investigar se EM, juntamente com o cuidado usual é eficiente no<br>tratamento de sobrepeso e obesidade e se essa intervenção reduz os<br>fatores de risco cardiovascular associados.|886|Cuidado usual + EM em grupo|Cuidado usual|
|Mirkarimi|Investigar o efeito da EM em mulheres com sobrepeso e obesidade|60|EM individual|Educação em saúde|
|2017<sup>365</sup><br>Raman 2017<sup>366</sup>|atendidas em centros de saúde urbanos.<br>Testar a eficácia da adição de TRC na TPPC em adultos obesos.|80|TRC + TPPC|TPPC|
|Berk 2018<sup>367</sup>|Determinar a eficácia em 2 anos de acompanhamento de TCC após|158|Cuidado usual + TCC|Cuidado usual|
|Jackson 2018<sup>368</sup>|dieta em adultos obesos com diabetes tipo II<br>Determinar a eficácia da TBE comparada a TCC após um ano de<br>tratamento de duas fases de internação e ambulatorial-telemedicina|60|TCC|TEB|  
244  
em mulheres com sobrepeso e compulsão alimentar.  
245  
|**Autor**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|
|Solbrig 2018<sup>369</sup>|Testar o impacto da TIF comparada a EM na perda de peso de adultos<br>com sobrepeso.|114|EM individual|TIF|
|Mhurchu<br>1998<sup>370</sup>|Comparar a eficácia de dois métodos de educação nutricional e EM em<br>pacientes com sobrepeso e hiperlipidêmicos.|97|Educação nutricional + EM em<br>grupo|Educação nutricional|
||Avaliar a eficácia de intervenção de baixo custo para redução do risco||||
|Greaves2008<sup>371</sup>|de diabetes, perda de peso e atividade física em pacientes da atenção<br>primária com obesidade.|141|Cuidado usual + EM individual|Cuidado usual|
|Dimarco2009<sup>372</sup>|Avaliar a EM aplicada adicionada ao TPPC em adultos com sobrepeso.|39|TPPC + EM individual|TPPC|
|Penn2009<sup>373</sup>|Avaliar a eficácia da EM na redução de peso, aumento da atividade<br>física, consumo de fibras, carboidratos, e gordura em pacientes obesos<br>com intolerância àglicose.|102|EM individual + Cuidado usual|Cuidado usual|
|Wilfley2002<sup>374</sup>|Comparar os efeitos da TCC e PI no tratamento de adultos com<br>sobrepeso e compulsão alimentar.|162|TCC|PI|
|Fitzgibbon<br>2010<sup>375</sup>|Comparar os efeitos da EM e educação em saúde no tratamento de<br>mulheres negras obesas.|213|EM individual|Educação em saúde|
|Stahre2007<sup>376</sup>|Comparar a eficácia da TC com o TPPC em mulheres obesas.|42|TC|TPPC|  
**Legenda:** TCC: Tratamento cognitivo-comportamental; TC: Terapia Cognitiva; TPPC: Tratamento de Perda de Peso Comportamental; EM: Entrevista Motivacional; TEB: Terapia de Estratégia Breve; TRC: Terapia de Remediação Cognitiva; TIF: Teoria de Imagem Funcional; PI: Psicoterapia Interpessoal  
**Tabela F1.** Características basais para os estudos que avaliaram o suporte psicológico (TCC e EM) em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor (es)**|**Intervenção**|**Controle**|**N**<br>**intervenção**|**N controle**|**Idade (anos) média**<br>**(DP) (intervenção**<br>**vs Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|<br>**IMC (%), média**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Circunferência**<br>**da cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervençã**<br>**o**|<sup>**Tempo de**</sup><br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|West 2007<sup>353</sup>|EM individual +<br>TPPC|TPCC|109|108|54 (10) vs. 52 (10)|0% vs. 0%|36,5 (5,4) vs. 36,5<br>(5,4)|97 (17) vs. 97 (15)|NR|18 meses|18 meses|
|Linde 2010<sup>354</sup>|TCC +TPPC|TPPC|101|102|52,3 (6,2) vs. 52,1<br>(6,5)|0% vs. 0%|38,6 (6,8) vs. 39,5<br>(7,7)|103,4 (17,7) vs.<br>106,5(22,3)|NR|12 meses|12 meses|  
246  
|Castelnuovo<br>2011<sup>355</sup>|TCC|TEB|30|30<br>46,2 (10,5)vs. 45,9<br>(10,7)|0% vs. 0%|NR|107,4 (6,8) vs.<br>106,6 (22,3)|NR|6 meses|6 meses|
|---|---|---|---|---|---|---|---|---|---|---|
|Grilo 2011<sup>356</sup>|TCC|TPPC|45|45,2 (8,5) vs. 44,5<br>45|35,6% vs. 55,5% vs.|39,3 (6,1) vs. 39,0|113,4 (23,9) vs.<br>107,6 (19,4) vs.|NR|12 meses|12 meses|
||TCC + TPPC||35|(9,2) vs. 44,6 (10,5)|37,8%|(6,1) vs. 38,0 (5,3)|110,1 (20,8)||||
|Munsch 2007<br>e 2012<sup>351,352</sup>|TCC|TPPC|44|36<br>44,4 (11,5) vs. 47,8<br>(11,8)|9,1% vs. 13,9%|34,1 (4,1) vs. 33,7<br>(3,6)|NR|NR|6 meses|6 anos<br>(72 meses)|  
247  
|**Autor (es)**|**Intervenção**|**Controle**|**N**<br>**intervenção**|**N controle**|**Idade (anos) média**<br>**(DP) (intervenção**<br>**vs Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|<br>**IMC (%), média**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Circunferência**<br>**da cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervençã**<br>**o**|<sup>**Tempo de**</sup><br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Tárraga<br>2014<sup>357</sup>|EM em grupo +<br>Cuidado usual|Cuidado usual|319|377|NR|17,8% vs. 27,4%|~~34,1 (4,8) vs. 34,1~~<br>(4,8)|85,5 (13,9) vs.<br>87,11|NR|8 meses|8 meses|
|Muggia<br>2014<sup>358</sup>|TCC + Cuidado<br>usual|Cuidado usual|80|83|46,2 (11,7) vs. 43,5<br>(3,6)|23,8 vs. 28,9%|31,9 (3,6) vs. 32,5<br>(3,7)|84,4 (13,5) vs. 85,6<br>(12,4)|103,1 (10,1) vs.<br>103,9(10,3)|12 meses|12 meses|
|Zwaan 2015<sup>361</sup>|TCC + Cuidado<br>usual|Cuidado usual|36|35|40,9 (7,7) vs. 37,7<br>(6,5)|NR|36,6 (3,2) vs. 35,7<br>(4,2)|217,3 (24,8) vs.<br>214,9(27,9)|NR|12 meses|12 meses|
||EM em grupo||50|||||||||
|Mirkarimi<br>2015 e<br>2016<sup>359,360</sup>|EM em grupo +<br>educação<br>nutricional|Educação<br>nutricional|50|50|37,9 (8,9) vs. 39,5<br>(10,3) vs. 37,9 (9,1)|0% vs. 0% vs. 0%|28,2 (2,2) vs. 29,0<br>(2,1) vs. 28,8 (1,6)|74,2 (6,95) vs. 77,3<br>(6,9) vs. 75,9 (6,1)|80,4 (6,9) vs.<br>84,5 (9,8) vs.<br>89,0 (10,8)|6 meses|6 meses|
|Wagner|Programa de||||34,9 (10,1) vs. 35,3||31,9 (6,7) vs. 32,8|91,9 (21,0) vs. 95,4||||
|2016<sup>362</sup>|internet baseado<br>TCC|Lista de espera|69|70|(9,7)|5,8% vs. 1,4%|(8,1)|(24,1)|NR|4 meses|12 meses|
|||Psicoeducação|||||34,7 (7,1) vs. 35,1|216,0 (54,3) vs.||||
|Barnes 2017<sup>363</sup>|EM Web|nutricional<br>Web|30|29|NR|NR|(7,5)|219,4 (53,9)|NR|15 meses|15 meses|
|Rodriguez-<br>Cristobal<br>2017<sup>364</sup>|Cuidado usual +<br>EM em grupo|Cuidado usual|400|446|NR|17,8% vs. 27,4%|34,1 (4,8) vs. 34,1<br>(4,8)|85,5 (13,9) vs. 87,1<br>(14,8)|107,6 (10,8) vs.<br>107,7 (11,5)|24 meses|24 meses|
|Mirkarimi<br>2017<sup>365</sup>|EM individual|Educação em<br>saúde|30|30|37,2 (8,1) vs. 39,0<br>(9,3)|0% vs. 0%|28,6 (1,8) vs. 28,5<br>(2,3)|76,1 (7,0) vs. 74,9<br>(7,2)|84,5 (9,2) vs.<br>80,0(7,0)|6 meses|6 meses|
|Raman 2017<sup>366</sup>|TRC + TPPC|TPPC|42|38|40,6 (7,0) vs. 42,2<br>(8,8)|NR|40,3 (7,8) vs. 39,2<br>(7,4)|NR|NR|3 meses|3 meses|
|Berk 2018<sup>367</sup>|Cuidado usual +<br>TCC|Cuidado usual|83|75|52,3 (11,3) vs. 55,2<br>(9,3)|47% vs. 41,3%|36,7 (31,7-39,4) vs.<br>35,7(32,9-40,9)*|105,5 (19,3) vs.<br>106,7(22,5)|119,4 (14,2) vs.<br>120,4(12,9)|2 meses|24 meses|
|Jackson<br>2018<sup>368</sup>|TCC|TEB|30|30|46,2 (10,5) vs. 45,9<br>(10,8)|0% vs. 0%|NR|107,4 (6,8) vs.<br>106,5(7,2)|NR|12 meses|12 meses|
|Solbrig 2018<sup>369</sup>|EM individual|TIF|55|59|42 (20-72) vs. 45||(20-72)|27,3% vs.|37,2%|32,5 (24,5|248<br>-53,3) vs.<br>33,2|  
||(26,0-48,0)*|||||89,7 (59-131) vs.<br>91,5 (62,3-140,5)*||106,8(79-144) vs.<br>106,8 (79-144)*|12 meses<br>12<br>meses|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|Mhurchu<br>1998<sup>370</sup>|EMem grupo<br> <sup>Educação</sup><br>nutricional+|Educação<br>nutricional|47|50|NR|48,9% vs. 52,0%|26,7 (25,6-27,9) vs.<br>27,3 (26,1-28,5)*|NR|NR|3 meses|3 meses|
|Greaves2008<sup>37</sup><br>1|Cuidado usual +<br>EM individual|Cuidado usual|72|69|53,3 (12,3) vs. 54,5<br>(11,5)|36% vs. 36%|NR|91,6 (13,3) vs. 94,4<br>(14,2)|104,2 (11,3) vs.<br>106,4(10,5)|6 meses|6 meses|
|Dimarco2009<sup>37</sup><br>2|TPPC +<br>EMindividual|TPPC|20|19|NR|30% vs. 5,3%|33,1 (3,2) vs. 31,6<br>(2,8)|NR|NR|11<br>semanas|11 semanas|
|Penn2009<sup>373</sup>|EM individual +<br>Cuidado usual|Cuidado usual|51|51|56,8 (40-72) vs.<br>57,4(38-74)*|41,2% vs. 39,2%|34,1 (5,5) vs. 33,5<br>(4,6)|93,4 (16,0) vs. 90,6<br>(12,5)|104,6 (11,3) vs.<br>104,3(9,2)|5 anos|5 anos|  
249  
|**Autor (es)**|**Intervenção**|**Controle**|**N**<br>**intervenção**|**N controle**<br>|<br>**Idade (anos) média**<br>**(DP) (intervenção**<br>**vs Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (%), média**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Circunferência**<br>**da cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervençã**<br>**o**|<sup>**Tempo de**</sup><br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Wilfley2002<sup>374</sup>|TCC|PI|81|81|~~45,6 (9,6) vs. 44,9~~<br>(9,6)|17,3% vs. 17,3%|37,4 (5,3) vs. 37,4<br>(5,1)|NR|NR|12 meses|12 meses|
|Fitzgibbon<br>2010<sup>375</sup>|EM individual|Educação em<br>saúde|107|106|46,4 (8,4) vs. 45,5<br>(8,4)|0% vs. 0%|38,7 (5,5) vs. 39,8<br>(5,8)|103,9 (15,7) vs.<br>105,9(17,4)|NR|6 meses|12 meses|
|Stahre2007<sup>376</sup>|TC|TPPC|16|26|50,1 (7,8) vs. 47,0|0% vs. 0%|35,5 vs. 34,1|95,1 vs. 91,5|NR|18 meses|18 meses|  
(8,2)  
**Legenda:** TCC: Tratamento cognitivo-comportamental; TC: Terapia Cognitiva; TPPC: Tratamento de Perda de Peso Comportamental; EM: Entrevista Motivacional; TEB: Terapia de Estratégia Breve; TRC: Terapia de Remediação Cognitiva; TIF: Teoria de Imagem Funcional; PI: Psicoterapia Interpessoal; NR: Não Reportado; * IC.  
**Tabela G1.** Desfechos de eficácia de estudos que avaliaram a perda de peso significativa (≥10%), alteração no peso corporal, no IMC e na circunferência abdominal.  
|**Autor, ano**|**Intervenção**|**Controle**|**Perda de peso ≥10%**<br>**do peso corporal**<br>**Intervenção vs.**<br>**Controle (%)**|**Valor de**<br>**p**|**Alteração no peso corporal**<br>**(Kg) Intervenção vs.**<br>**Controle**|**Valor de**<br>**p**|**Alteração no IMC ((Kg/m**<sup>**2**</sup>**)**<br>**DP) Intervenção vs.**<br>**Controle Controle**|**Valor**<br>**de p**|**Alteração da**<br>**circunferência da**<br>**cintura**<br>**Intervenção vs.**<br>**Controle Controle**<br>**(cm(DP))**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|West 2007<sup>353</sup>|EM individual +<br>TPPC|TPCC|NR|NA|Após 6 meses:92,3 (17,0) vs.<br>93,9 (15,0)<br>Após 12 meses:92,2 (17,0)<br>vs. 94,3 (15,0)<br>Após 18 meses:93,5 (17,0)<br>vs. 95,3(15,0)|NS|NR|NA|NR|NA|
||||||Após 6 meses:101,6 (17,7)||||||
|Linde 2010<sup>354</sup>|TCC +TPPC|TPPC|NR|NA|vs. 103,8 (22,3)<br>Após 12 meses:101,1 (17,7)<br>vs. 103,5(22,3)|0,55|NR|NA|NR|NA|
|Castelnuovo<br>2011<sup>355</sup>|TCC|TEB|NR|NA|Após 6 meses:94,73 (18,14)<br>vs. 88,40 (5,87)|0,128|NR|NA|NR|NA|
||Grilo<br>2011<sup>356</sup>||TCC||TCC + TPPC|||TPPC|N<br>N|R<br>A|  
250  
<u>Após 6 meses: Ap</u> 111,6 (22,0) <u>ós</u> NS NR NA vs. 105,1 <u>6</u> (20,1) vs. <u>m</u> 105,1 <u>es</u> (23,6) <u>es: Após 12</u> 38 <u>meses:110</u> ,7 ,40 (23,0) (5, vs. 104,3 7) (17,7) vs. vs. 104,60 38 (22,3) ,2 (5, 3) vs. 36 ,6 (6, 8) NS <u>Ap ós 12 meses:38,3</u> (6,0) vs. 38 ,7 (5, 6) vs. 36 ,6 (6, 5)  
251  
||||**Perda de peso ≥10%**<br>||**Alteração no peso corporal**||**Alteração no IMC ((Kg/m**<sup>**2**</sup>**)**||**Alteração da**<br>**circunferência da**||
|---|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**do peso corporal**<br>**Intervenção vs.**<br>**Controle (%)**|**Valor de**<br>**p**|<br>**(Kg) Intervenção vs.**<br>**Controle**|**Valor de**<br>**p**|<br>**DP) Intervenção vs.**<br>**Controle Controle**|**Valor**<br>**de p**|**cintura**<br>**Intervenção vs.**<br>**Controle Controle**<br>**(cm(DP))**|**Valor**<br>**de p**|
|Munsch 2007 e<br>2012<sup>351,352</sup>|TCC|TPPC|Após 6 anos:17,1% vs.<br>18,8%|0,85|NR|NA|Após 12 meses: 32,4 (5,4)<br>vs. 33,6 (4,0)<br>Após 6 anos:31,5 (5,2) vs.<br>33,5(3,8)|0,70<br>>0,05|NR|NA|
|Tárraga 2014<sup>357</sup>|<sup>EM em grupo +</sup><br>Cuidado usual|Cuidado usual|Após 2 anos:8% vs.<br>5%26|NS|NR|NA|Após 2 anos:31,7 (4,8) vs.<br>33,2(4,8)|0,0237|NR|NA|
|Muggia 2014<sup>358</sup>|TCC + Cuidado<br>usual|Cuidado usual|Após 12 meses:14%<br>vs. 16%|0,633|NR|NA|NR|NA|NR|NA|
|Zwaan 2015<sup>361</sup>|TCC + Cuidado<br>usual|Cuidado usual|NR|NA|Após 6 meses:196,8 (35,5)<br>vs. 196,9 (30,8)<br>Após 1 ano:204,9 (31,8) vs.<br>202,7(30,3)|NS|Após 6 meses:32,8 (5,1) vs.<br>32,6 (5,0)<br>Após 1 ano:34,4 (4,3) vs.<br>33,8(4,9)|NS|NR|NA|
||EM em grupo||||Após 2 meses:71,7 (5,6) vs.||Após 2 meses:27,1 (2,2) vs.||||
|Mirkarimi 2015<br>e 2016<sup>359,360</sup>|EM em grupo +<br>educação<br>nutricional|Educação nutricional|NR|NA|74,9 (6,0) vs. 74,6 (6,1)<br>Após 6 meses:70,1 (5,6) vs.<br>73,0 (5,6) vs. 75,1 (6,3)|< 0,03|28,2 (2,5) vs. 28,5 (2,6)<br>Após 6 meses:26,5 (2,2) vs.<br>27,5 (2,5) vs. 28,7 (2,5)|<<br>0,003|NR|NA|
|Wagner|Programa de||||Após 4 meses: 90,6 (21,3)||Após 4 meses: 31,4 (6,9) vs.||||
|2016<sup>362</sup>|internet<br>baseado TCC|Lista de espera|NR|NA|vs. 95,6 (24,7)|0,033|32,8 (8,3)|0,094|NR|NA|
|Barnes 2017<sup>363</sup>|EM Web|Psicoeducação<br>nutricional Web|NR|NA|<sup>Após 12 meses: 219,35</sup><br>(54,27) vs. 216,31 (53,88)|0,056|Após 12 meses:35,12 (7,06)<br>vs. 34,55(7,52)|NS|NR|NA|
|Rodriguez-<br>Cristobal<br>2017<sup>364</sup>|Cuidado usual +<br>EM em grupo|Cuidado usual|Após 1 ano:6,7% vs.<br>4%<br>Após 2 anos:8% vs.<br>5%|0,27|Após 1 ano:83,7 (EP: 0,9)<br>vs. 85,9 (EP: 0,8)<br>Após 2 anos:83,2 (EP: 1,0)<br>vs. 84,9(EP: 0,9)|0,02|NR|NA|NR|NA|
|Mirkarimi|EM individual|Educação em saúde|NR|NA|2017<sup>365</sup>|Apó<br>s 2|meses:73,89 (6,54)<br>vs. 72,98 (6,58)<br>Após 6 meses:72,96|(5,<br>92<br>)|vs. 72,75 (6,53)|252<br>|  
|0,001|||||Após 2 meses:27,75 (1,72)<br>vs. 27,74 (2,21)<br>Após 6 meses:27,52 (1,71)<br>vs. 27,60 (2,11)|0,938|Após 2 meses:82,00 (8,78)<br>vs. 77,82 (6,35)<br>Após 6 meses:77,96<br>(17,10) vs. 77,39<br>(6,36)|0,001|||
|---|---|---|---|---|---|---|---|---|---|---|
|Raman 2017<sup>366</sup>|TRC + TPPC|TPPC|68% vs. 15%|<0,05|Após 3 meses:105,5 (20,7)<br>vs. 109,3(18,9)|NS|Após 3 meses:38,3 (7,6) vs.<br>38,8(8,4)|NS|NR|NA|
||||||Após 1 ano:97,7 (4,3) vs.||||||
|Berk 2018<sup>367</sup>|Cuidado usual +<br>TCC|Cuidado usual|NR|NA|98,5 (4,5)<br>Após 2 anos:100,2 (4,5) vs.<br>101,4 (4,7)|0,951|NR|NA|<sup>Após 2 anos: 115,0</sup><br>(3,1) vs. 116,0 (3,3)|NS|  
253  
|**Autor, ano**|**Intervenção**|**Controle**|**Perda depeso ≥10%**<br>**dopeso corporal**<br>**Intervenção vs.**<br>**Controle (%)**|**Valor de**<br>**p**|**Alteração no peso corporal**<br>**(Kg) Intervenção vs.**<br>**Controle**|**Valor de**<br>**p**|**Alteração no IMC ((Kg/m**<sup>**2**</sup>**)**<br>**DP) Intervenção vs.**<br>**Controle Controle**|**Valor**<br>**dep **|**Alteração da**<br>**circunferência da**<br>**cintura**<br>**Intervenção vs.**<br>**Controle Controle**<br>**(cm(DP))**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|Jackson 2018<sup>368</sup>|TCC|TEB|NR|NA|Após 12 meses: 101,83<br>Após 6 meses: 98,7 (7,75)<br>vs. 87,83 (6,35)<br>(8,27)vs. 87,93(6,62)|< 0,001<br>< 0,001|NR|NA|NR|NA|
|Solbrig 2018<sup>369</sup>|EM individual|TIF|NR|NA|Após 6 meses:88,39 (15,72)<br>vs. 86,37(15,07)<br>Após 12 meses: 88,46<br>(15,34) vs. 84,04 (15,96)|< 0,001|NR|NA|Após 6 meses:<br>102,78 (13,37) vs.<br>99,05 (12,61)<br>Após 12 meses:<br>103,04 (12,45) vs.<br>96,97(12,59)|< 0,001|
|Mhurchu<br>1998<sup>370</sup>|EMemgrupo<br>Educação<br>nutricional+|Educação nutricional|NR|NA|NR|NA|Após 3 meses:26,25 (1,2)<br>vs. 26,86 (1,2)|< 0,05|NR|NA|
|Greaves2008<sup>371</sup>|<sup>Cuidado usual +</sup><br>EM individual|Cuidado usual|NR|NA|Após 6 meses: 91,3 (13,7)<br>vs. 92,6 (15,0)|P<0,05|NR|NA|Após 6 meses:102,6<br>(11,2)vs. 104,1(11,6)|<0,05|
|Dimarco2009<sup>372</sup>|EMindividual<br>TPPC +|TPPC|NR|NA|NR|NA|(3,08)vs. 30,92(3,05)<br>Após 11 semanas:31,58|0,11|NR|NA|
|Penn2009<sup>373</sup>|Cuidado usual<br>EM individual +|Cuidado usual|NR|NA|90,6(12,5)<br>Após 1 ano:91,1 (16,0) vs.|NS|NR|NA|NR|NA|
|Wilfley2002<sup>374</sup>|TCC|PI|NR|NA|NR|NA|36,6(5,3)<br>Após 4 meses:37,4 (5,3) vs.|0,98|NR|NA|
|2010<sup>375</sup><br>Fitzgibbon|EM individual|Educação em saúde|NR|NA|Após 18 meses: 104,6 (15,8)<br>Após 6 meses:104,3 (15,6)<br>vs. 105,8 (17,8)<br>vs. 105,6(18,1)|NS|Após 18 meses: 38,9 (5,5)<br>Após 6 meses:38,8 (5,5) vs.<br>39,6 (5,8)<br>vs. 39,7(5,9)|NS|NR|NA|
|Stahre2007<sup>376</sup>|TC|TPPC|23% vs. 0%|NS|Após 18 meses:89,2 (12,7)|NS|Após 18 meses:33,3 vs.|NR|NR|NA|
||||||vs. 91,8 (14,0)||34,2||||  
**Legenda:** TCC: Tratamento cognitivo-comportamental; TC: Terapia Cognitiva; TPPC: Tratamento de Perda de Peso Comportamental; EM: Entrevista Motivacional; TEB: Terapia de Estratégia Breve; TRC: Terapia de Remediação Cognitiva; TIF: Teoria de Imagem Funcional; PI: Psicoterapia Interpessoal, NR: Não Reportado; NA: Não se aplica; NS: Não Significante; IC: Intervalo de Confiança. * DM entre os grupos intervenção e placebo  
254  
###### **Figura W.** Forest plot da meta-análise do desfecho de perda de peso de estudos que avaliaram TCC e EM.  
<!-- Start of picture text -->
8.1.1Study At6or Subgrou6 meses de acompanhamentoMeanExperimentalSD Total_Mean ControtSD Total Weight _IV,Mean Random, Ditterence95% Cl IV,Mean Random, Difference95% Cl<br>Castelnuovo 2011 9473 1814 30 884 587 30 31% 6.33F0.49,13.15)<br>Fitagibbon 2010 1043 156 100 1058 178 97 42% 1.50 (618,318)<br>Greaves 2008, 913° 137 «72 926 «15694 2% © 1.30 F508, 3.45)<br>Gtilo 2011 1118 22,«45.«*1051 «238 «231.6% 6 605.09, 18.09]<br>tila 2014 1051 20.1 38-1051 236 «231.6% 0.00611.72,11.72)<br>Jackson 2018 97 775 30 8736 © 6.35 30 49% 11,34(7-75,14.93] —_<br>Linde 2010, 1018 177 87 1038 223-73 34% © -2.20(852,4.12)<br>Mirkarimi 2018 e 2016 7298 583 44 7807 628-24 8.2% © -208/5.10.0.92)<br>Mirkarimi 2015 e 2016 701 5.6 44 7507 © 6.2824 8.2% -4.9757.98,-1.96) —_<br>Mirkarimi 2017 7298 892 30 7275 «68330 61% 0.21294, 338)<br>Raman 2017 1055 207 37 1033 189 26 20% -3.80/-1366,<br>906 «21.3 69956 «247 70«-28% -5.00/12.66,<br>Wagner 2016 6.08)<br>West 2007 923 17 109 938 «15 108 45% 1.60 F586, 268 ))<br>Zwaan 2008, 1968 955 28 1958 303 32 0.9% -0.1051693, 16.731<br>Subtotal (95% C) 760 659 487% 0.051.293, 303]<br>TestHeterogeneity,for overallTaur=fect:Z=21.50;0.03 ChP= (P=69.14,0.97) df= 13, < 0.00001);P= 78%<br>8.1.2De7Bames 2017a 12meses de acompanhamento21935 5427 21 71631 53.88 23 «03% 304 -28.95, 35.03]<br>Berk 2018 977433 8BS «4575 80% -080F218,058)<br>tlio 2011 1104 23.45.1088 «= 223-23 1.7% §.80F552,17.12)<br>tila 2014 1043 177 35 1086 «© 223-23 1.8% -0.30411.14,1054)<br>Jackson 2018 10183 827 «30 8793 «662-30 «8% 1390/1011, 17.69] —<br>Penn 2008 S11 18 St 908 «125 $1«3.7% ©0580 8.07,6.07)<br>Rodriguez-Cristobal<br>West 2007 2017 837922 17.84 1 87 393109-98385.9 165501 5 4210 8 55%4.5% © -- 2 12 0 /4.5F63 6,  0124 6 )]<br>Zwaan 2008, 2049 31.8 31-2027 «= 303.31 1.0% 2.20113.26, 17.68)<br>Subtotal (95% C) 798 782 28.2% — 1.96[.2.16, 6.09]<br>TestHeterogeneity.for overallTau=fect Z=24.98;0.93 Chi= (P=$80 36) . 33, df= 8 (P< 0.00001), P= 86%<br>8.1.3 Mais de 12 meses de acompanhamento<br>Berk 2018 100245 «83 1014 «4775 89% © -1.20¢264,0.24)<br>Fitegibbon 2010 1046 158 93 1056 181 97 4.2% © 1.00 5.83,3.83]<br>Rodriguez-Cristobal<br>WestStante202 0 705 2017 935832892 15.5563127«17-109.24213 85384.9«B1413042215. 21010818-2154%45 % © -2.60412.33-1.80-1.70/4.34,0.94)£8.06 , 7.432.48 ]<br>Subtotal (95% CI) 540 506 22.0% -1.35[-2.52, 0.19] a<br>Heterogeneity. Tau*= 0.00; Chi*= 0.24, df= 4 (P= 0.99); F= 0%<br>TestTotal (95%for overallCH efiect:Z= 227 (P= 0.02) 2098 1957 100.0% — 0.22[-1.50, 1.94]<br>Heterogeneity, Tau= 12.41; Chi= 121.34, = 27 (P < 0.00001), P= 78% 49st a<br>Test ff or overasubarounpf ect l diferences:l Z= 0.25Chit= 2.60, = 2 (P= 0.25), P= 28.7%<br>‘Test (P = 0.80) Favorece Suporte psicol6g Favorece Controle<br><!-- End of picture text -->  
255  
**Figura X.** Forest plot da meta-análise do desfecho de perda de peso nos estudos que avaliaram a TCC.  
<!-- Start of picture text -->
‘Study7.1.1 Atéor Subgroup6 meses de acompanhamento_Mean___ExperimentalSD Total MeanControtSD Total Weight_IV,Mean Random, Difference 95%Cl IV,Mean Random, Difference 95%Cl<br>Casteinuovo 2011 «94.73 1814 30 884 587 30 7.5% 6.33 50.49, 13-15]<br>Grilo 2011 1116 22 45 1051 236 23 4.7% 6.50 (5.09, 18.09}<br>Grilo 2011 1051 201 36 1051 236 23 4.6% 0.00611.72,11.72]<br>Jackson 2018 987 7.75 30 87.36 635 30 9.8% 11.3417.75, 14.93] ~<br>Linde 2010 1016 177 87 1038 223 73 7.9%  -220/8.52,4.12]<br>Raman 2017 1055 207 37 1093 189 26 5.6% -3.80[-13.66, 6.06)<br>Wagner 2016 906 213 69 956 247 70 69% -5.00512.66, 266]<br>ZwaanSubtotal2005 (95% Ci) 196.8 355 36128 196.9 303 30732 49.9%2.9% -0.10(16.93,2.08 [-3.50, 7.66]16.73]<br>TestHeterogeneity: Tau= 43.44; Chi*= 27.82, df= 7 (P = 0.0002); P= 75%<br>for overall effect Z= 0.73 P= 0.46)<br>7.4.2 De 7 a 12 meses de acompanhamento<br>Berk 2018 977 43 83 985 45 75 109% -0.80/2.18, 0.58)<br>Grilo 2011 1104 23 45 1046 223 23 4.8% 5.8055.52,17.12]<br>Grilo 2011 1043 177 36 1046 223 23 5.1% -0.30511.14, 10.54)<br>Jackson 2018 10183 8.27 30 8793 662 30 9.7% 13.90[10.11, 17.69} na<br>ZwaanSubtotal2005(95% Cl) 2049 31.8 22431 2027 303 18231 33.6%3.2% 2.20/13.26,4.47 [-4.28, 13.22]17.66]<br>Heterogeneity: Tau*= 78.32; Chit= 51.83, df= 4 (P < 0.00001); = 92%<br>Test<br>for overall effect Z= 1.00 (P = 0.32)<br>7.1.3 Mais de 12 meses de acompanhamento<br>Berk 2018 100.2 45 83 1014 47 75 108% —-1.2052.64,0.24)<br>Stahre 2005 892 127 13 918 14 16 57% -2.60612.33,7.13]<br>Subtotal (95% Cl) 96 91 16.5% 1.23 [-2.65, 0.19]<br>TestHeterogeneity: Tau= 0.00; Chit= 0.08, df= 1 (P= 0.78); P= 0%<br>for overall effect Z= 1.69 (= 0.09)<br>Total (95% Cl) 681 580 100.0% 2.47 [-0.84, 5.78]<br>TestHeterogeneity: Tau= 25.76; Chi*= 100.30, df= 14 (P < 0.00001); F= 86% tots $ ab<br>for subaroup differences: Chi*= 2.75, df= 2 (P= 0.26), F= 27.3%<br>Test for overall effect Z= 1.46 (P = 0.14) Favorece TCC. Favorece controle<br><!-- End of picture text -->  
**Figura Y.** Forest plot da meta-análise do desfecho de perda de peso nos estudos que avaliaram a EM.  
<!-- Start of picture text -->
6.1.1StudyAtéor Subgroup6 meses de acompanhamentoMeanExperimental_$D Total Mean ControlSO Total Weight MeanI, Differ Fix e 95%nced, Cl IV,Mean Fixed, Ditference95% CL<br>FitzgibbonGreaves 20082010 1043913° 156137 10072 1058926 ©17818-6397 5.3%-51% -1.50F6.19,3.19)—-1.30F6.05, 3.45)<br>MirkarimiMirkarimiMicka  20152015  @e 20162016 70173 8688 4475163«44 «7513-24240.2%127% -2:106—-5.00 18.02,27.36, 23.18}1.98) _<br>‘West 20072017 7298923° $9217 10930 7275939 653-30«18 108 11663 % | -1.800.21 [2945.86 , 336]266)<br>Subtotal (95% Cl) 309 362 41.2% -2.09[-3.76, -0.42} °<br>Heterogeneity: ChiF= 5.64, df= 5 (P= 0.32), F=14%<br>Testfor overall fect Z= 2.45 (P= 0.01)<br>6.1.2 De<br>BatesPennRodiiguez-Cristoval 200820177 a12meses de acompanhamento21935311188427 21St 218.31908 6288«125123-01%-37% 3.04050507, ¢2895,607)35.03}<br>West 2007 2017 922°837 17.84 1 87 109393 943859 16.550© 1 5 1042 8 2076.3 % -2—- .1066.36,2.1 ] 2 0(456, 01 6 )<br>Subtotal (95% C) 57a 610 309% 4.84.3.77, 0.10]<br>Heterogeneity: Chi= 0.67, df= 3 (P= 0.83), = 0%<br>Testfor overall effect Z=1.86 (P= 0.06)<br>6.1.3 Mais de 12 meses de acompanhamento<br>Fitzgibbon 2010 1046 15993 1056 18197 5.0% -1.00 583,383)<br>Rodtiguez-Cristoval<br>West 2007 2017 98 3 52 15.556317 109242 9 5349 13047218 108210 1 6 .36 % © -1.801,70F4346.08 , 0.042.45)<br>Subtotal (95% CI) a4 415° 279% 1.60363, 0.44]<br>Heterogenelty:Chi*= 0.07, df= 2 (P= 0.96), P= 0%<br>Testfor overall elect Z=<br>sir 1377 100.0% -1.87[2.95,-0.80] +<br>Total (95% Ci) 1154 (P= 0.12)<br>estfor overall effect: Z= 3.42 (P= 0. 0 06) Favorece Entevista Mot Favorece Controle<br>Testfor subaroup differences: Chi*= 0.14, t= 2 (P= 0.93), = 0%<br><!-- End of picture text -->  
256  
###### **Figura Z.** Forest plot da meta-análise do desfecho de alteração do IMC de estudos que avaliaram TCC e EM.  
<!-- Start of picture text -->
2.2.1‘StudyAtéor Subgroup6 meses de acompanhamento__MeanExperimentalSD Total MeanControlSD Total Weight IV,Mean Random, Difference95% Cl IV,Mean Random, Difference95% Cl<br>DimareaFitagibnon20082010 3158gee 30855 10020 2092296 30558 1997 50%66% -080[238,078)0.80(-1.26,2.66)<br>Grilorilo 20112011 387382 5753 4535 266266 6868 2323 22%21% 21061.14,534]16061.69,4.89)<br>Mhurchu 1998 2625 12 47 2686 12 50 154% -0.61£1.09,-0.13] 7<br>Mirkarimi<br>Mirkarimi 2018 2016 2653 217 44 2868 263 24 9.0% -21513.35,-0.96) —_<br>2752 171 30 276 211 30 10.8%<br>MirkarimiRaman 2017 2017 20152016 27.46383 25876 370 2868388 25384 2426 14% -0.08-0.5014.55,3.55)Not(1.05, estimable0.89)<br>Wagnerwiiney 20022016 314374 6953 6975 328366 8353 7076 33%6.0% -14013.94,1.14]0800.89, 249]<br>Zwaan 2005 328 51 28 326 5 32 32%  0.2062.36,276)<br>Subtotal (95% Ci, 530 494 65.0% 0.37 0.99, 0.26]<br>Heterayenelly: Taut= 0,36; Chi*= 16.82, df= 10 (P= 0.08); P= 41%<br>Testor overall effect Z=1.15 (P= 0.25)<br>8.2.2De 7 a 12 meses de acompanhamento<br>Bames 2017 3612 7.08 21 3486 752 23 1.3% 087 63.74,4.88)<br>Gtilo 2011 387 56 35 366 65 23 22%  2406114,5:34)<br>Gtilo 2011 383 6 45 366 65 23 22% 1,701.48, 4.98)<br>Munsch 20072012 324 54 23 336 «4 «21-28% —-1.203.99, 1.59]<br>wan 2005 344 43° 31 338 49 31 39% —0.6061.69, 2.89)<br>Subtotal (95% Ci) 155 121 124% — 0.63[.0.70, 1.96]<br>TestHeterogenely: Tau= 0,00; Chi*= 2.88, df= 4 (P= 0.56), P= 0%<br>for overall effect Z= 0.93 (P= 0.36)<br>8.2.3FitagibhonMais de201012 meses de389acompanhamento55 97 307 59 G7 64% -0.8062.41,081)<br>StahreMunsch 200520072012 31.5333052 2413: 335«342 38«0 2116 34% -2.00/4.64,0.68)Nat estimable<br>Tarraga 2014 BF 48 319 332 48 377 13.2% -1.60(2.22,-0.78) =<br>Subtotal (95% Cl) 453 511 22.7% 1.42 [-2.05, -0.79] A<br>TestHeteragenelly: Tau= 0,00; Chi?= 0.81, df= 2 (P= 0.67), P= 0%<br>Total (95%for overallCI) effect. Z= 4.38  < 0.000 1 )138 1126 100.0% 0.46 [-0.97, 0.05]<br>Heteragenely: Taut= 0,38; Chi*= 30.25, d=<br>TestTestor or overallsubaroupelectdiferences:Z= 1.79 (P=Chit=0.07)9.90, df=18 2 (P= (P= 0.04), 0.007), P=F= 40% 79.8% Favorece5  suporie+ psicolog $ Favorece controlet ih<br><!-- End of picture text -->  
257  
**Figura A1.** Forest plot da meta-análise do desfecho de alteração do IMC de estudos que avaliaram TCC.  
<!-- Start of picture text -->
Study or Subgroup __MeanExperimentalSD Total MeanControlSD Total Weight MeanIV, Fixed, Difference95% CI MeanIV, Fixed, Difference95% Cl<br>7.2.1 Até 6 meses de acompanhamento<br>Grito 2011 382 53 35 366 68 23 59% 160/1.69,4.89)<br>Grilo 2011 387 57 45 366 68 23 61% 2106114534]<br>Raman 2017 383 76 37 388 84 26 39% -050[4.55,3.55]<br>Wagner 2016 314 69 69 328 83 70 10.0% -14053.94, 1.14]<br>Wilfley 2002 374 53 75 366 53 76 224% 0.8050.89,2.49}<br>Zwaan 2005 328 51 28 326 5 32 97% 0.2062.36,276)<br>Subtotal (95% Cl) 289 250 58.0% 0.45 [-0.60, 1.50]<br>Heterogeneity. Chi*= 3.92, df= 5 (P = 0.56); F= 0%<br>Test for overall effect: Z= 0.84 (P = 0.40)<br>7.22 De 7 a 12 meses de acompanhamento<br>Grito 2011 383 6 «45 366 65 23 6.3% 1.705148, 4.88)<br>Grito 2011 387 56 35 36665 23 61% 2106114,5.34)<br>Munsch 200722012 324 54 23 336 4 21 82% -1.20[3.99, 1.59]<br>Zwaan 2005 344 43° 31 338 49 31 122% 0.6051.69, 2.89}<br>Subtotal (95% Cl) 134 98 32.8% 0.64 [-0.76, 2.04]<br>Heterogeneity. Chi?<br>Test for overall effect= Z= 2.88, 0.90 df= (P 3 = (P 0.37) = 0.41); F= 0%<br>7.2.3 Mais de 12 meses de acompanhamento<br>Munsch 200722012 31.5 62 24 935 38 21 9.2% -200(-4.64,0.64)<br>Stahre 2005 333° «0 «13: «342: 0 16 Not estimable<br>Subtotal (95% Cl) 7 37 9.2% -2.00 [-4.64, 0.64]<br>Heterageneity. Not applicable<br>Test for overall effect: Z= 1.48 (P= 0.14)<br>Total (95% Cl) 460 385 100.0% 0.29 [-0.51, 1.09]<br>TestHeterogeneity: Chi*= 10.02, df= 10 (P= 0.44); F= 0% tot ot<br>Test forfor  subaroupoverall effect:differences: Z= 0.71 (PChi*= = 0.48) 3.22, df= 2 (P= 0.20), F= 38.0% Favorece TCC Favorece Controle<br><!-- End of picture text -->  
**Figura B1.** Forest plot da meta-análise do desfecho de alteração do IMC de estudos que avaliaram EM.  
<!-- Start of picture text -->
‘Study Experimental Control Mean Difference Mean Difference<br>6.2.1 AtSof Subgroup _Mean__SD Total Mean SD Total Weight IV, Random, 95% Cl IV, Random,95% Cl<br>Dimarco 20086 meses de acompanhamento31.58 308 20 3092 305 19 92% 0.66 (1.28,258]<br>Fitzgibbon 2010 388 55 100 396 58 97 106% -080/238,073)<br>Mhurchu 1998 2625 12 47 2886 12 50 148% -261 £309,213] ~<br>Mirkarimi 2018 2016 24.48 254 44 2868 253 24 120% -4.22/5.48,-2.98] _<br>MirkarimiMirkarimi 20172018 2016 26.832752 217171 4430 286827.6 253211 2430 122%13.1% -2.18/-3.36,-0.95]-0.08(-1.05, 0.89] _<br>Subtotal (95% Cl) 285 244 74.9% 1.62 [-2.90, -0.34] ad<br>TestHeterogenelty: Tau?= 2.13; Chit= 42.34, df= § (P < 0.00001);P=88%<br>for overall effect. Z= 2.49 (P= 0.01)<br>6.2.2 De<br>BamesSubtotal20177(95%a 12Cl) meses de acompanhamento35.12 7.08 21a 3455 752 23-35%23 35% 0.570573.74, (3.74, 4.88]4.88)<br>TestHeterogeneity: Not applicable<br>for overall effect. Z= 0.26 (P= 0.80)<br>6.2.3 Mais<br>Fitzgibbon 2010de 12 meses de acompanhamento389 55 97 397 59 97 105% -080/2.41,081]<br>TarragaSubtotal (95%2014 Cl) M7 48 416319 332 48 377474 141%24.6% 1.38-1506222,-073) [-2.04, 0.73] =a4<br>TestforHeterogeneity:overall Taut=effect Z=0.00; 4.15ChP=(P < 0.0001)0.61, df= 1 (P= 0.44);P= 0%<br>Total (95% Cl) 722 741 100.0% 1.46 [-2.38, 0.54] od<br>Heterogeneity: Tau*= 1.44; Chit= 48,02, df= 8 (P < 0.00001);<br>Test P= 83% tr 7) $ ih<br>Testfofo r subover a llrouneffect.differences:Z= 3.11 (PChi*= = 0.002)0.92, df= 2 (P= 0.63), P= 0% Favorece Entrevista Motiv Favorece Controle<br><!-- End of picture text -->  
258  
**Figura C1.** Forest plot da meta-análise do desfecho de alteração na medida do perímetro da cintura de estudos que avaliaram TCC e EM.  
<!-- Start of picture text -->
Study Experimental Control Mean Difference Mean Difference<br>8.4.1 Até or Subgroup 6 meses de acompanhamento Mean SD Total Mean SD Total Weight IV, Random,95% Cl IV, Random,95% Cl<br>GreavesMirkarimi 20172008 102677.98 112171 7230 104177.39 118636 6930 21.4%128% -180[8.27,2.27]057 (8.96, 7.10)<br>Solbrig 2018 102.78 1337 56 99.08 1261 59 17.4% 373[1.05,851]<br>Subtotal (95% C1) 157 158 51.0% — 0691-263, 4.01]<br>Heterogeneity: Tau*= 2.61; Chit= 2.84, df= 2 (P= 0.24), P= 30%<br>Testfor overall effect. Z= 0.41 (P= 0.68)<br>8.4.2 De 7 a 12 meses de acompanhamento<br>Solbrig 2018 103.4 1245 85 96.97 1269 69 18.0% 6.43 (1.83, 11.03] =<br>Subtotal (95% Cl) 55 59 18.0% 6.43 [1.83, 11.03] =><br>TestHeterogeneity: Not applicable<br>8.4.3for Mais  overall de 12 effect. meses  Z= 2.74 de acompanhamento  (P= 0.006)<br>BerkSubtotal2018(95% C1) 18 31 8383 116 33 7575 309%30.9% 1.00-1.00/-2.00,0.00)[-2.00, 0.00]<br>Heterogeneity: Not applicable<br>Testfor overall effect. Z= 1.96 (P= 0.05)<br>Total (95% Cl) 295 292 100.0% — 126[-1.70,4.21]<br>TestTestHeterogeneity: fo rr subover a llroupeffect.Tau*=diferences:Z=7.09; 0.83ChF= (P = 0.40)Chi*=13.06, 10.16, df= of= 4 (P= 2 (P=0.01);0.006),F= 69%F= 80.3% FavoreceShsuporte psicolég Favorece controle<br><!-- End of picture text -->  
**Figura D1.** Forest plot da meta-análise do desfecho de alteração do perímetro da cintura nos estudos que avaliaram a EM.  
<!-- Start of picture text -->
Study Experimental Control Mean Difference Mean Difference<br>6.4.1 At6 or Subgroup 6 meses de __ acompanhamento Mean SD Total Mean SD Total Weight IV, Random,95% Cl IV, Random,95% Cl<br>MirkarimiGreaves  20172008 102677.98 11.2171 7230 104477.39 11.6636 6930 30.2%184% -1.8066.27,2.27]0.87 £6.96, 7.10)<br>Solbrig 2018 102.78 1337 65 99.06 1261 59 25.9%  3.73(-1.05,8.54]<br>Subtotal (95% Cl) 157 158 73.9% 0.69 [-2.63, 4.01]<br>TestHeterogeneity: Tau?= 2.61; Chi2= 2.84, d= 2 (P= 0.24); = 30%<br>for overall effect Z= 0.41 (P = 0.68)<br>6.4.2 De 7 a 12 meses de acompanhamento<br>Solbrig 2018 103.04 1245 55 96.97 1259 59 26.1% 6.07 (1.47, 10.67) ~~<br>Subtotal (95% Cl) 55 59 26.1% — 6.07 [1.47, 10.67] io<br>TestHeterogeneity: Not applicable<br>for overall effect Z= 2.59 (P= 0.010)<br>Total (95% Cl) 212 217 100.0% — 2.18 [-1.48, 5.84]<br>Heterogeneity: Tau*= 7.87; Chit= 7.01, df= 3 (P= 0.07); P= 57% hs<br>Testfor overall effect. 2= 1.17 (P= 0.24) Favorece Entrevista Motiv Favorece Controle<br>Test for subaroun differences: Chi*= 3.46, df=1 (P= 0.06), F= 71.1%<br><!-- End of picture text -->  
259  
**Figura E1.** Forest plot da meta-análise do desfecho de perda de peso significativa (≥10%) de estudos que avaliaram TCC e EM.  
<!-- Start of picture text -->
Experimental Control Risk Difference Risk Difference<br>Study or Subgroup Events Total Events Total Weight M-H, Fixed, 95% Cl MH, Fixed, 95% Cl<br>8.3.1 De 7 a 12 meses de acompanhamento<br>Muggia 2014 11 80) 1383 8.4% -0.02 0.13, 0.09),<br>Rodriguez-CristobalSubtotal (95% CI) 2017 19 283363 «12-302385 30.0%38.4% 0.020.03[-0.02,-0.01, 0.05]0.06),<br>Total events 30 6<br>Heterogeneity: Chi'= 0.73, df= 1 (P= 0.39); P= 0%<br>Test for overall effect Z= 0.91 (P= 0.36)<br>8.3.2 Mais de 12 meses de acompanhamento<br>Munsch 2007<br>e 2012 6 35 6 32 34% -0.02£0.20,0.17]<br>Rodriguez-Cristobal 2017 19 283 «10 199 24.0% 0.02 0.03, 0.06),<br>Stahre 2005 313 0 16 1.5% 0.23£-0.01, 0.47)<br>Taraga 2014 2 99 «19-317 327% 0.02<br>TotalSubtotalevents(95% Cl) 54 650 35 564 61.6% 0.02 [-0.01,0.02, 0.05]0.06),<br>Heterogeneity: Chi#= 3.12, df= 3 (P= 0.37), F= 4%<br>Test<br>for overall effect Z= 1.52 (P= 0.13)<br>Total (95% Cl) 1013, 949 100.0% 0.02 [-0.00, 0.04]<br>Total events 84 60<br>Heterogeneity: Chi*= 3.76, df= 5 (P= 0.58); F= 0% 05-025 i 0.35 05<br>Test Favorece controle Favorece suparte psicolog<br>Test for for subaroun overall effect differences:  Z=1.75 ChP= (P= 0.08) 0.05, df= 1 (P= 0.82), F= 0% le F: f<br><!-- End of picture text -->  
**Figura F1.** Forest plot da meta-análise do desfecho de perda de peso significativa (≥10%) nos estudos que avaliaram a TCC.  
<!-- Start of picture text -->
Experimental Control Risk Ratio Risk Ratio<br>Study or Subgroup __Events__Total_Events Total _Weight_M-H, Random, 95% Cl MH, Random, 95% Cl<br>7.3.1 De 7 a 12 meses de acompanhamento<br>Muggia 2014 11 8013 83. 58.6% 0.88 (0.42, 1.84)<br>Subtotal (95% Cl) 80 83 58.6% 0.88 [0.42, 1.84]<br>Total events W 13<br>Heterogeneity: Not applicable<br>Test for overall effect Z= 0.34 (P = 0.73)<br>7.3.2 Mais de 12 meses de acompanhamento<br>Munsch 2007<br>Stahre 2005 e 2012 63 3513 60 3216 36.0%65% 8.500.91(0.48,(0.33,151.05]2.58]<br>Subtotal (95% Cl) 48 48 41.4% 1.88 (0.23, 15.67]<br>Total events 8 6<br>Heterogeneity: Tau*= 1.46; Chi?= 2.20, df=1 (P = 0.14); F= 55%<br>Test foroverall effect. Z= 0.58 (P= 0.56)<br>Total (95% Cl) 128 131, 100.0% 1.04 [0.51, 2.00]<br>Total events 20 19<br>Heterogeneity: Tau?<br>Test for overall effect.= Z= 0.06;0.02 Chi¥=(P =2.35,0.98) df= 2 (P = 0.31); P= 15% 0.001Favorece orControle 410Favorece TCC 1000<br>Test for subaroup differences: Chi¥= 0.44, df= 1 (P= 0.51), F= 0%<br><!-- End of picture text -->  
260  
**Figura G1.** Forest plot da meta-análise do desfecho de perda de peso significativa (≥10%) nos estudos que avaliaram a EM.  
- ‘Study6.3.1 Deor 7Subgroupa 12 meses de acompanhamento: **E** ventsxperimentalTotal  
**Figura H1.** Avaliação da qualidade metodológica dos ECR.  
<!-- Start of picture text -->
Random sequence generation selection bias) [i<br>Allocation conczaiment (selection bias) [INlia<br>Blinding of participants and personnel (performance bias) i<br>Blinding of outcome assessment (detection bias) iiiI |<br>Incomplete outcome data (atrtion bias) i<br>Selective reporting reporting bias), iTSa]<br>oer bias +<br>0% 28% +80% 4.78% —_100%<br>Low risk of bias [Blunctear risk of bias HB High risk of bias<br><!-- End of picture text -->  
<!-- Start of picture text -->
z<br>Fi = =<br>A 5 a a<br>ew 63B9 <uF gag5 2 34 eZ 2oFz§ 28 2&8 B<br>PERT PES ELE CE SEER EoF<br>Ree ee See ss ee Boe ee €<br>|S SAS BRE SB BOS SB Se 2a S<br>=[e[e|e[e[e|e|s<br>|e [e[0[e[0[@ [=] =[e]s [som .cmsiminsieies<br>[e\ee\e\eS00 S0ele 008@ e/e\ejeleieele|90000000 eaBlinelingof patcjoarts sind personne! (performance bias)<br>OOOOOSS00000S00000000<br> e0 @[0[ 0 0000[6 0 [es000 [6|0 0[ 0 [00000 00000s [ 0 0 eremammaresem<br>s/e[e/e/e|s/e/e/2/#/0/4| s/e\e/2/4/s/e)m<br>NOB N00 eee<br><!-- End of picture text -->  
261  
###### **Quadro J1:** Principais domínios avaliados (tabela _Evidence to Decision_ do GRADE PRO).

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
|**Deve-se usar**|**suporte psicológico vs. tratamento convencional para perda de peso de indivíduos portadores de sobrepeso ou obesidade?**|
|---|---|
|**POPULAÇÃO:**|perda de peso de indivíduos portadores de sobrepeso ou obesidade|
|**INTERVENÇÃO:**|suporte psicológico|
|**COMPARAÇÃO:**|tratamento convencional|
|**DESFECHOS**<br>**PRINCIPAIS:**|Perda de peso significativa (>10%); Alteração no peso corpóreo ; Alteração no IMC (Índice de Massa Corporal) ; Alteração na medida do perímetro da cintura;|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
|Problema<br>O problema é uma prioridade?||
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não|<br>A obesidade mundial quase triplicou desde 1975.|
|○ Provavelmente Não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.<br><br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais pessoas do que abaixo do peso.<br><br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.|
||<br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou obesas em 2016.<br><br>A obesidade é evitável.|
||Fonte: OMS. Obesity and overweight. Disponível em: https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight. Acesso em: 09/08/2019|  
262  
|Efeitos Desejá<br>Quão substanciais são|veis<br>os efeitos desejáveis?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>● Pequeno|Os resultados das meta-análises sugerem que a entrevista motivacional auxilie na redução do peso corporal, IMC e perda significativa de peso (≥10%), enquanto a terapia cognitivo<br>comportamental, não mostrou vantagens estatisticamente significantes em relação ao controle. Na análise de subgrupo, as meta-análises que avaliaram o suporte psicológico,|
|○ Moderado|tanto a TCC quanto a EM, com estudos com mais de 12 messes de acompanhamento, apresentaram diminuição de peso corpóreo e IMC mais expressivo. Dessa forma, acredita-se|
|○ Grande<br>○ Variável|que essas técnicas de suportes psicológicos possam ser adjuvantes promissores na redução de peso corporal em pacientes portadores de sobrepeso e obesidade. Porém, vale<br>destacar que a maioria dos estudos incluídos nestas meta-análises apresentavam qualidade metodológica baixa a moderada e que as especificidades de cada estudo ocasionam|
|○ Incerto|limitações à sumarização dos resultados.|
||O Sistema Único de Saúde já apresenta incorporadas à sua Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais, terapias em grupo e individuais. Assim<br>as técnicas de suporte psicológico poderiam ser utilizadas nessas terapias para pacientes portadores de obesidade e sobrepeso com foco na redução de peso corporal|
|Efeitos Indese<br>Quão substanciais são|jáveis<br>os efeitos indesejáveis?|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>○ Pequeno<br>○ Moderado|Os resultados das meta-análises sugerem que a entrevista motivacional auxilie na redução do peso corporal, IMC e perda significativa de peso (≥10%), enquanto a terapia cognitivo<br>comportamental, não mostrou vantagens estatisticamente significantes em relação ao controle. Na análise de subgrupo, as meta-análises que avaliaram o suporte psicológico,<br>tanto a TCC quanto a EM, com estudos com mais de 12 messes de acompanhamento, apresentaram diminuição de peso corpóreo e IMC mais expressivo. Dessa forma, acredita-se|
|○ Grande|que essas técnicas de suportes psicológicos possam ser adjuvantes promissores na redução de peso corporal em pacientes portadores de sobrepeso e obesidade. Porém, vale|
|○ Variável<br>● Incerto|destacar que a maioria dos estudos incluídos nestas meta-análises apresentavam qualidade metodológica baixa a moderada e que as especificidades de cada estudo ocasionam<br>limitações à sumarização dos resultados.|
||O Sistema Único de Saúde já apresenta incorporadas à sua Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais, terapias em grupo e individuais. Assim<br>as técnicas de suporte psicológico poderiam ser utilizadas nessas terapias para pacientes portadores de obesidade e sobrepeso com foco na redução de peso corporal|  
263  
#### Certeza da Evidência  
<!-- Start of picture text -->
Qual é a certeza global da evidência dos efeitos?<br>JULGAMENTO  EVIDÊNCIAS DE  CONSIDERAÇÕES ADICIONAIS<br>PESQUISA<br>● Muito Baixa  A qualidade geral da evidência é muito baixa para todos ps desfechos.<br>○ Baixa<br>○ Moderada  Certainty of the evidence<br>Desfechos  Importância<br>○ Alta  (GRADE)<br>○ Sem estudos incluídos<br>Perda de peso significativa (>10%)  ⨁◯◯◯<br>MUITO BAIXA a,b,c<br>Alteração no peso corpóreo  ⨁◯◯◯<br>MUITO BAIXA c,d,e<br>Alteração no IMC (Índice de Massa Corporal)  ⨁◯◯◯<br>MUITO BAIXA c,d,e<br>Alteração na medida do perímetro da cintura  ⨁◯◯◯<br>MUITO BAIXA c,e,f<br>a. Dos 5 ECR incluídos, três apresentam baixa qualidade metodológica e os outros dois qualidade moderada.<br>b. Mesmo com o i2=0, os estudos apresentam intervenções distintas (3 ECR sobre TCC e 2 de EM), comparadores distintos e tempos de<br>seguimentos diferentes.<br>c. Os resultados estão em direções distintas e os intervalos de confiança não são sobreponíveis.<br>d. Apenas Jackson et al., (2018) apresentou alta qualidade metodológica. No restante dos estudos, a qualidade metodológica variou de<br>baixa a moderada.<br>e. alta heterogeneidade pelo teste i2, os estudos apresentam intervenções, comparadores e tempos de seguimento distintos<br>f. Dos 4 ECR, três apresentaram qualidade metodológica moderada e um baixa.<br><!-- End of picture text -->  
264  
#### Valores  
|Existe importante incerteza ou|variabilidade acerca de quanto as pessoas valorizam os resultados primários?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Importante incerteza ou<br>variabilidade<br>● Possível Importante|. Não se sabe ao certo qual seria a preferência dos indivíduos;<br>. A depender das limitações físicas e nutricionais, alguns indivíduos poderiam opinar pelo tratamento com dieta e/ou exercício físico em detrimento à terapia;|
|incerteza ou variabilidade<br>○ Provavelmente nenhuma<br>Importante incerteza ou|. Apesar do agrupamento de efeito quantitativo realizado, as comparações foram diferentes e poderia, também, haver um efeito add-on positivo da terapia associada ao<br>tratamento conservador;|
|variabilidade<br>○ Sem importante incerteza<br>ou variabilidade|. Trabalhar com emoções e sentimentos pode não ser confortável para alguns indivíduos.|  
265  
#### Balanço dos efeitos  
O balanço entre efeitos desejáveis e indesejáveis favorece a intervenção ou o comparador?  
|JULGAMENTO|EVIDÊNCIAS DE<br>PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Favorece o comparador<br>○ Provavelmente favorece o<br>comparador<br>○ Não favorece um e nem o<br>outro<br>● Provavelmente favorece a<br>intervenção<br>○ Favorece a intervenção<br>○ Variável<br>○ Incerto|<br>Os res  ́<br>cognit<br>supor<br>expre<br>porta<br>mode<br><br>O Sist<br>indivi<br>de pe<br><br>Devid<br>moda<br><br>texto|ultados das meta-análises sugerem que a entrevista motivacional auxilie na redução do peso corporal, IMC e perda significativa de peso (≥10%), enquanto a terapia<br>ivo comportamental, não mostrou vantagens estatisticamente significantes em relação ao controle. Na análise de subgrupo, as meta-análises que avaliaram o<br>te psicológico, tanto a TCC quanto a EM, com estudos com mais de 12 messes de acompanhamento, apresentaram diminuição de peso corpóreo e IMC mais<br>ssivo. Dessa forma, acredita-se que essas técnicas de suportes psicológicos possam ser adjuvantes promissores na redução de peso corporal em pacientes<br>dores de sobrepeso e obesidade. Porém, vale destacar que a maioria dos estudos incluídos nestas meta-análises apresentavam qualidade metodológica baixa a<br>rada e que as especificidades de cada estudo ocasionam limitações à sumarização dos resultados.<br>ema Único de Saúde já apresenta incorporadas à sua Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais, terapias em grupo e<br>duais. Assim as técnicas de suporte psicológico poderiam ser utilizadas nessas terapias para pacientes portadores de obesidade e sobrepeso com foco na redução<br>so corporal<br>o à característica dos estudos, alta heterogeneidade e baixa qualidade metodológica, é difícil recomendar um tipo de terapia em detrimento da outra. Uma<br>lidade deve ser indicada considerando a possibilidade de associação com tratamento conservador e depende da vontade do indivíduo.<br>deve conter as técnicas de suporte psicológicos que devem ser utilizados.|
|Aceitabilidade<br>A intervenção é aceitável para<br>JULGAMENTO|os principais atore<br>EVIDÊNCIAS DE<br>PESQUISA|s sociais (_stakeholders_)?<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não<br>● Provavelmente sim<br>○ Sim|<br>Algun<br><br>Em re|s indivíduos podem preferir a terapia com educação alimentar e exercício físico ou medicamentos em detrimento à terapia;<br>lação aos demais atores o suporte psicológico já está incorporado no SUS, assim, não ocasionaria nenhuma mudança, além de capacitação dos profissionais.|
|○ Variável<br>○ Incerto|||  
266

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
||||**J**|**ULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|Moderado|Pequeno|Trivial||Varia|**Incerto**|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importente|**Possivelmete**<br>**variabilidade ou**<br>**incerteza importante**|Provavelmente sem<br>incerteza ou<br>variabilidade<br>importante|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a<br>comparação|Provavelmente favorece<br>a comparação|Não favorece nem a<br>comparação nem a<br>intervenção|**Provavelmente**<br>**favorece a intervenção**|Favorece a intervenção|Varia|Incerto|
|**ACEITABILIDADE**|Não|Provavelmente não|**Provavelmente sim**|Sim||Varia|Incerto|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
|Recomendação forte contra a intervenção<br>Recomendação condicional contra a|Não favorece uma ou outra|**Recomendação condicional a favor da**|Recomendação forte a favor da|
|---|---|---|---|
|intervenção||**intervenção**|intervenção|
|○<br>○|○|**●**|○|  
267

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 10 - PERGUNTA PICO 9** -->
#### Recomendação  
Recomenda-se o suporte psicológico baseado em EM e TCC, desde que adequadas às necessidades do paciente com sobrepeso e obesidade e condicionadas ao treinamento e capacitação das equipes em saúde para a realização adequada desses procedimentos. Ademais, é ideal que ao paciente seja fornecida informação e a possibilidade de associação de outras modalidades de tratamento, como readequação alimentar e prática de exercícios físicos. A terapia e o suporte psicológico devem ser avaliados por profissional capacitado e indicados quando aplicável, respeitando a individualidade dos usuários.  
268

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
**Questão da pesquisa: “Qual a eficácia e segurança da sibutramina na perda de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era a sibutramina (C) Placebo ou orlistate; e desfechos (O) perda de peso (contínua e clinicamente significante (> 10% do peso corpóreo)), redução do perímetro da cintura, redução do IMC.  
###### **A. Estratégia de busca**  
**Quadro K1.** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|MEDLINE via<br>Pubmed:|((("Obesity"[Mesh] OR "Overweight"[Mesh] OR obesity OR<br>overweight)) AND ("sibutramine" [Supplementary Concept] OR<br>sibutramine)) AND ((randomized controlled trial[pt] OR controlled<br>clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR drug<br>therapy[sh] OR randomly[tiab] OR trial[tiab] OR groups[tiab] NOT<br>(animals [mh] NOT humans [mh])))<br>Data de busca: 29/10/2018|728|
|EMBASE|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim<br>AND<br>('sibutramine' OR 'sibutramine'/exp) AND [embase]/lim<br>AND<br>'crossover procedure':de OR 'double-blind procedure':de OR<br>'randomized controlled trial':de OR 'single-blind procedure':de OR<br>(random* OR factorial* OR crossover* OR cross NEXT/1 over* OR<br>placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1 blind* OR<br>assign* OR allocat* OR volunteer*):de,ab,ti<br>Data de acesso: 02/10/2018|1.211|  
###### **B. Seleção das evidências**  
A busca pelas evidências resultou em 1.939 referências (728 no MEDLINE e 1.211 no EMBASE). Destas, 341 foram excluídas por estarem duplicadas. Mil quinhentos e noventa e oito referências foram triadas por meio da leitura de títulos e resumos, das quais, 60 referências tiveram seus textos avaliados para confirmação da elegibilidade, por meio de uma análise mais minuciosa. Dessas 60 referências, 40 foram lidas na íntegra. As justificativas de exclusão dos estudos encontram-se no **Quadro L1** .  
269  
**<u>Quadro L1</u>** . Estudos excluídos na fase 3.  
|**Estudo**|**Referência**|**Motivo de exclusão**|
|---|---|---|
|Hauner et al., 2004|377||
|McMahon, 2000|379|Estavam contemplados na RS de Rucker et al.,<br>2007<sup>378</sup>.|
|Padwal et al., 2003|380||
|Gonzalez et al., 2010|381||
|Cuellar et al., 2000|383||
|Fanghanel et al., 2000|384||
|Faria et al., 2002|385||
|Finer et al., 2000|386||
|Fujioka et al., 2000|387||
|Hazenberg et al., 2000|388|Estavam contemplados na RS de Arterburn et al.,<br>2004<sup>382</sup>.|
|Hanotin et al., 1998|389||
|James et al., 2000|390||
|Norris et al., 2004|391||
|Serrano-Rios et al., 2004|392||
|Smith et al, 2001|393||
|Sramek et al., 2002|394||
|Apfelbaum et al., 1999|395|Estava na RS de Rucker et al., 2007<sup>378</sup>e na RS de<br>Arterburn et al.,2004<sup>382</sup>.|
|Bray et al., 1996|396|Não descreveu o número de participantes<br>avaliados|
|Milano et al., 2005|397|Avaliou somente 20 pacientes|
|Wilfley et al., 2008|398|Não preencheu o critério de inclusão de IMC<br>igual ou superior a 25kg/m2|
|James, et al., 2010|399|Não descreveu os resultados de redução de peso<br>(contato com autor sem sucesso)|
|Kim et al., 2003|400|Uma meta-análise que estava incluída na RS de<br>Arterburn et al.,2004<sup>382</sup>|
|Dedov et al., 2018|401||
|Gaciong et al., 2005|402|Não apresentavam o braço comparador|
|Stimac et al., 2004|403||
|Gray et al., 2012|404|Não apresentou meta-análise individual para a<br>sibutramina|
|Neovius et al., 2008|405|Não descreveu a população avaliada no estudo|  
Ao final, foram incluídas três RS (Arterburn et al., 2004<sup>382</sup> , Rucker et al., 2007<sup>378</sup> e Gray et al., 2012<sup>404</sup> ), dez ECR (Appolinario et al., 2003<sup>406</sup> , Erondu et al., 2012<sup>407</sup> , Fanghanel et al., 2003<sup>408</sup> , Di Francesco et al., 2007<sup>409</sup> , Derosa et al., 2004<sup>410</sup> , Halpern et al., 2002<sup>411</sup> , Kaya et al., 2004<sup>412</sup> , Porter et al., 2004<sup>413</sup> , Tankova et al., 2004<sup>414</sup> , Caterson et al., 2012<sup>415</sup> e uma coorte (Douglas et al., 2015<sup>416</sup> ), importante para avaliar a segurança. As descrições e os dados dos referidos estudos encontram-se descritos no item 3.2.O processo de seleção dos estudos está descrito na **Figura I1.**  
270  
###### **Figura I1.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Publicações identificadas por meio da<br>pesquisa nas bases de dados:<br>PUBMED = 728<br>EMBASE= 1.211<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>1598  critérios de exclusão: 1558<br>Publicações excluídas segundo critérios de exclusão:<br>26<br>ECR contemplados nas RS: 13; ECR sem descrição<br>Publicações selecionadas para leitura<br>dos participantes: 01; ECR avaliando somente 20<br>completa: 40<br>participantes: 01; ECR sem preenchimento do<br>critério de inclusão IMC: 01; ECR sem<br>preenchimento do critério de inclusão comparador:<br>01; ECR sem descrição do resultado: 01; Meta-<br>análise incluída na RS: 01; RS por não apresentarem<br>braço comparador: 03; RS que não descrevia a<br>população avaliada: 01; RS mais antiga que as<br>Estudos incluídos: 14  versões incluídas: 02; RS que não apresentava meta-<br>análise: 01<br>3 RS, 10 ECR, 1 coorte<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
###### **C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se no **Tabela H1** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela I1.** Resultados de eficácia encontram-se na **Tabela J1 e** nas **Figura J1** . Desfechos de segurança, na **Tabela K1** . A avaliação do risco de viés dos está ilustrada na **Figura K1** . A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no **Quadro M1** , que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O **Quadro N1** ilustra os principais domínios avaliados para tomada de decisão acerca da recomendação, criada a partir da tabela _Evidence to Decision_ , da metodologia GRADE.  
271  
###### **Tabela H1.** Características dos estudos incluídos.  
|**Autor. Ano**|**Desenho do estudo**|**Objetivo do estudo**|**População**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|
|Appolinario et al.,<br>2003|ECR<br>duplo-cego, paralelo,<br>randomizado,<br>comparando dose<br>fixa de sibutramina<br>com placebo|Avaliar eficácia e tolerabilidade da<br>sibutramina em pacientes obesos com<br>transtorno de compulsão alimentar|Homens e mulheres, com idade entre 18 e 60<br>anos, com IMC entre 30 e 45 kg/m<sup>2</sup>e que<br>apresentavam transtorno de compulsão<br>alimentar|Sibutramina<br>15 mg/dia|Placebo|Baixo|
||ECR|Explorar a relação entre a mudança de|Homens e mulheres com idade ≥ 55 anos, com<br>IMC ≥ 27 kg/m2 e ≤ 45 kg/m2 ou com IMC <||||
|Caterson et al., 2012|Duplo-cego, placebo<br>controlado,<br>multicêntrico|peso durante o primeiro ano de<br>tratamento do estudo SCOUT e seu efeito<br>sobre os desfechos na população geral|27 kg/m2 e com uma circunferência de cintura<br>grande (≥ 102 cm para homens e ≥ 88 cm para<br>mulheres).|Sibutramina<br>10 mg/dia|Placebo|Baixo|
|Douglas et al., 2014|Coorte|Avaliar longitudinalmente os efeitos sobre<br>o peso e o IMC de orlistate e sibutramina<br>na rotina de cuidados primários por meio<br>da análise dos dados do Datalink da<br>Pesquisa de Prática Clínica do Reino Unido<br>durante um período de três anos|A população do estudo foi formada por todos<br>os pacientes registrados no CDPR antes de 31<br>de janeiro de 2013, com pelo menos 12 meses<br>de registro e com um IMC de 30 kg/m<sup>2</sup>.|Sibutramina<br>(não<br>especifica<br>dose)|Orlistate (não<br>especifica dose) ou<br>sem intervenção|Baixo|
||ECR<br>multicêntrico, duplo-|Avaliar os efeitos na perda de peso da<br>substância MK-0557, antagonista seletivo<br>do receptor NPY5R, quando co-|Pacientes obesos, com IMC entre 30 e 43|Sibutramina|Grupo placebo e|Incerto<br>Não há informações suficientes para julgar<br>os domínios randomização, sigilo de|
|Erondu et al., 2007|cego, randomizado,<br>controlado por<br>placebo|administrado com orlistate e sibutramina,<br>além de comparar diretamente a eficácia<br>de orlistate e sibutramina.|kg/m<sup>2</sup>, com idade entre 18 e 65 anos|10 mg/dia|grupo orlistate 120<br>mg|alocação, cegamento e avaliação cega dos<br>desfechos. Ademais, autores não deixaram<br>claro a participação da patrocinadora do<br>estudo.|
|Fanghänel et al., 2003|<br>ECR<br>randomizado, duplo-<br>cego, controlado por<br>placebo|Avaliar eficácia e segurança da<br>sibutramina 10 mg/dia em pacientes<br>hipertensos com sobrepeso (IMC > 27<br>kg/m<sup>2</sup>)|Pacientes com IMC > 27 kg/m<sup>2</sup>, hipertensos,<br>atendidos no Serviço de Endocrinologia do<br>Hospital Geral do México na Cidade do México|Sibutramina<br>10 mg/dia|Placebo|Incerto<br>Não há informações suficientes para julgar<br>o domínio avaliação cega dos desfechos. A<br>Química Knoll do México patrocinou este<br>estudo clínico.|
|Di Francesco et al.,|ECR<br>randomizado,<br>multicêntrico, duplo-|Avaliar o efeito da sibutramina 10 mg<br>combinada com dieta na perda e|Pacientes com IMC ≥30 e ≤ 40kg/m<sup>2</sup>, idade|Sibutramina||Incerto<br>Não há informações suficientes para julgar|
|2007|Halpern et al.,|2002|cego, paralelo, controlado por placebo<br>ECR|dupl|o-cego,|manutenção de peso, além da qualidade de vida<br>em pacientes italianos|  
272  
|Avaliar eficácia,<br>segurança e|entre 18 e 65<br>anos|10 mg/dia|Placebo|os domínios sigilo de alocação,<br>cegamento<br>dos participantes e avaliação cega<br>dos desfechos.|
|---|---|---|---|---|
|tolerabilidade da<br>sibutramina no<br>manejo de<br>pacientes obesos<br>por um período de|Pacientes com<br>idade entre 18 e<br>65 anos, com<br>IMC > 30kg/m<sup>2</sup>,|Sibutramina|Placebo<sup>10 mg/dia</sup>|Alto<br>Não há informações suficientes<br>para julgar os domínios<br>randomização, sigilo de|
|6 meses|com glicose de<br>jejum <<br>130mg/dL,<br>colesterol total <<br>300mg/dL,||||  
273  
|**Autor. Ano**|**Desenho do estudo**|**Objetivo do estudo**|**População**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|
||controlado por<br>placebo||triglicerídeos < 500 mg/dL, ácido úrico < 8,0<br>mg/dL, transaminases < 40 mg/dL, bilirrubina<br>< 2,0 mg/dL, ureia < 40 mg/dL e creatinina <<br>1,5 mg/dL.|||alocação e avalição cega dos desfechos.<br>Não há menção sobre cuidados específicos<br>para lidar com as perdas de seguimento.|
|Kaya et al., 2004|ECR<br>prospectivo,<br>randomizado,<br>aberto, de curto<br>prazo|Comparar as mudanças nas medidas<br>antropométricas (IMC e peso corporal) em<br>pacientes obesos tratados com dieta e<br>exercício ou adicionando sibutramina e/ou<br>orlistate, além de descrever os eventos<br>adversos encontrados|Pacientes com idade entre 18 e 60 anos, IMC<br>≥ 30kg/m<sup>2</sup>, com história de pelo menos uma<br>tentativa frustrada de perder<br>peso por meio de medidas dietéticas no<br>passado|Sibutramina<br>10 mg/dia|Orlistate 120 mg ou<br>terapia combinada<br>(sibutramina 10 mg<br>+ orlistate 120 mg)<br>ou dieta|Alto<br>Não há informações suficientes para julgar<br>os domínios randomização e sigilo de<br>alocação. Estudo aberto, sem cegamento<br>para avaliação dos desfechos.|
|Porter et al., 2004|ECR<br>prospectivo,<br>randomizado e<br>controlado|Avaliar o benefício da sibutramina 5 a 20<br>mg/dia dentro de um programa de<br>controle de peso|Pacientes maiores de 18 anos, com IMC > 30<br>kg/m<sup>2</sup>. Pacientes com IMC entre 27 a 29,9<br>foram elegíveis se tivessem uma ou mais das<br>seguintes comorbidades: diabetes mellitus<br>com ou sem terapia medicamentosa,<br>hipertensão tratada com terapia<br>medicamentosa ou hiperlipidemia tratada<br>com terapia medicamentosa|Sibutramina 5<br>a 20 mg/dia|Nenhum<br>medicamento|Alto<br>Não está claro a garantia do sigilo de<br>alocação. Estudo aberto e não houve<br>cegamento para avaliação dos desfechos.|
|Tankova et al., 2004|ECR<br>aberto, controlado e<br>randomizado|Avaliar o efeito da sibutramina no peso<br>corporal, massa gorda corporal, controle<br>glicêmico, lipídios, secreção e resistência à<br>insulina em pacientes diabéticos obesos<br>tipo 2, bem como em indivíduos obesos<br>não diabéticos, durante três meses|Pacientes com diferentes graus de obesidade,<br>incluindo não diabéticos e diabéticos tipo 2|Sibutramina<br>10 a 15<br>mg/dia|Nenhum<br>medicamento|Alto<br>Não há informações suficientes para julgar<br>os domínios randomização e sigilo de<br>alocação. Estudo aberto, sem cegamento<br>para avaliação dos desfechos. Sem<br>informações sobre tratamento específico<br>para lidar com perdas de seguimento.|
||ECR<br>multicêntrico, duplo-|Avaliar comparativamente a eficácia e a<br>segurança do orlistate 360 mg/dia e da<br>sibutramina 10 mg/dia no tratamento de|Pacientes obesos, de ambos os sexos, maiores|Sibutramina|||
|Derosa et al., 2004|cego, randomizado e<br>controlado|pacientes obesos com diabetes tipo 2,<br>com atenção específica às alterações<br>induzidas pelo padrão metabólico e<br>efeitos cardiovasculares|de 18 anos, com IMC > 30kg/m<sup>2</sup>e diabetes<br>mellitus tipo 2|10 mg/dia|Orlistate 360 mg/dia|Baixo|
|||Avaliar a eficácia do cloridrato de|29 ECR incluídos. Pacientes com mais de 18|Sibutramina||Qualidade criticamente baixa, uma vez que<br>apresenta falha em 3 itens críticos.<br>Apresentou falhas nos seguintes domínios:|
|Arterburn et al., 2004|RS com meta-análise|sibutramina 10 a 20 mg/dia na perda de<br>peso|anos, IMC ≥ 25 kg/m<sup>2</sup>, ECR com duração de<br>oito semanas ou mais.|10 a 20<br>mg/dia|Placebo|ausência de protocolo (item 2), ausência de<br>justificativa para exclusão de estudos<br>individuais (item 7) e não-consideração do<br>risco de viés ao interpretar os resultados da<br>revisão (item 13).|  
274  
|**Autor. Ano**|**Desenho do estudo**|**Objetivo do estudo**|**População**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|
|Gray et al., 2012|RS com meta-análise|Comparar as intervenções anti-obesidade<br>(orlistate, sibutramina e rimonabanto) na<br>perda de peso, alteração de IMC e<br>redução de peso em 5 e 10%|44 ECR com sibutramina incluídos. Pacientes<br>adultos com excesso de peso, obesos ou em<br>risco de doença cardiovascular|Sibutramina<br>10 e 15<br>mg/dia|Placebo<br>Orlistate<br>Rimonabanto<br>Metformina<br>Cuidado padrão|Qualidade criticamente baixa, uma vez que<br>apresenta falha em 1 item crítico e 2 não<br>críticos.<br>Apresentou falhas nos seguintes domínios:<br>não realização da extração de dados em<br>duplicata (item 6), não-consideração do<br>risco de viés ao interpretar os resultados da<br>revisão (item 13), e não discussão da<br>heterogeneidade observada nos estudos<br>(item 14).|
||RS com meta-análise<br>Resumo de uma|Quantificar a eficácia dos efeitos|10 ECR com sibutramina incluídos, com 2.623|Sibutramina||Qualidade criticamente baixa, uma vez que<br>apresenta falha em 4 itens críticos.<br>Apresentou falhas nos seguintes domínios:<br>ausência de protocolo (item 2),|
|Rucker et al., 2007|atualização de uma<br>revisão sistemática<br>Cochrane|associados ao uso prolongado de<br>medicamentos anti-obesidade|participantes. Pacientes adultos, maiores de<br>18 anos, com sobrepeso ou obesidade.|10 a 20<br>mg/dia|Placebo|inadequação das buscas nas bases de<br>dados (item 4), ausência de justificativa<br>para exclusão de estudos individuais (item<br>7) e não-consideração do risco de viés ao<br>interpretar os resultados da revisão (item<br>13).|  
ECR: ensaio clínico randomizado; RS: revisão sistemática; IMC: índice de massa corpórea  
###### **Tabela I1.** Características dos participantes dos estudos incluídos.  
|**Autor**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**média (DP)**<br>**Idade intervenção**|**(DP)**<br>**Idade controle média**|**(intervenção/ controle)**<br>**N (%) sexo feminino**|<br>**seguimento**<br>**Tempo de**|
|---|---|---|---|---|---|---|---|---|
|Appolinario et al., 2003|mg/dia<br>Sibutramina 15|Placebo|30|30|35,2(9,0)|36,6(10,2)|26(87)/27(90)|12 semanas|
|Caterson et al., 2012|mg/dia<br>Sibutramina 10|Placebo|4.906|4.898|63,2(6,1)|63,3(6,2)|2.100(42,8)/2.057(42)|1 ano|
||Sibutramina (não|Orlistate (não especifica dose) ou sem||Orlistate:||Orlistate: 46,2(14,0)|Sibutramina:||
|Douglas et al., 2014|especifica dose)|intervenção|15.355|100.701|43,5(13,1)|sem intervenção:<br>46,4(14,1)|12.560(81,8)<br>Orlistate:76.946(76,4)|Estimativa de 3 anos|  
275  
|**Autor**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade intervenção**<br>**média(DP)**|**Idade controle média**<br>**(DP)**|**N (%) sexo feminino**<br>**(intervenção/ controle)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|
|||||sem intervenção:<br>508.140|||Sem intervenção:<br>380.389(74,9)||
|Erondu et al., 2007|Sibutramina 10<br>mg/dia|Grupo placebo e grupo orlistate 120 mg|100|Grupo placebo -<br>101<br>Grupo orlistate -<br>99|40,9(11,1)|Grupo placebo:<br>42.6(10,8)<br>Grupo orlistate:<br>41,9(9,4)|Grupo sibutramina:<br>85(85,0)<br>Grupo placebo: 83(82,2)<br>Grupo orlistate: 83(83,8)|24 semanas|
|Fanghänel et al., 2003|Sibutramina 10|Placebo|29|28|49,0(5,5)|45,5(6,5)|24(82,8)/21(75,0)|6 meses|
|Di Francesco et al.,|mg/d**i**a<br>Sibutram na 10|Placebo|130|128|41,5(10,8)|42,3(11)|130(84,4)/ 128(82,6)|6 meses|
|2007<br>Halpern et al., 2002|mg/d**i**a<br>Sibutram na 10|Placebo|30|31|38,3|38,3|NR|6 meses|
|Kaya et al., 2004|mg/dia<br>Sibutramina 10<br>mg/dia|Orlistate 120 mg/3x/dia ou terapia combinada<br>(sibutramina 10 mg/dia + orlistate 120<br>mg/3x/dia) ou dieta|22|Orlistate - 25<br>Terapia<br>combinada - 20<br>Dieta - 19|40,3(9,0)|Orlistate:44,0(8,9)<br>Terapia combinada:<br>41,8(8,8)<br>Dieta: 37,5(7,3)|Sibutramina: 17(77,3)<br>Orlistate: 21(84)<br>Terapia combinada:<br>15(75)<br>Dieta: 17(89,5)|12 semanas|
|Porter et al., 2004|Sibutramina 5 a 20|Nenhum medicamento|281|220|47,2(10,7)|49,6(10,4)|222(79,0)/ 187(85,0)|6 meses|
|Tankova et al., 2004|mg/dia<br>Sibutramina 10 a 15<br>mg/dia|Nenhum medicamento|Diabéticos: 44<br>Não<br>diabéticos: 49|Diabéticos: 39<br>Não diabéticos:<br>41|Diabéticos:<br>45,2(5,2)<br>Não diabéticos:<br>41,9(5,7)|Diabéticos: 44,8(6,1)<br>Não diabéticos:<br>44,6(6,0)|Diabéticos: 27(61)/<br>24(62)<br>Não diabéticos:<br>32(65)/27(66)|3 meses|
|Derosa et al., 2004|Sibutramina 10|Orlistate 360 mg/dia|70|71|51 (4,0)|53 (5,0)|36 (50,7%)/ 36 (51,4)|12 meses|
|Arterburn et al., 2004|mg/dia<br> <sup>Sibutramina 10 a 20</sup>|Placebo|Variável|Variável|Variação|de 34 - 54 anos|NR|8-54 semanas|
|Gray et al., 2012|mg/dia<br>Sibutramina 10 e 15<br>mg/dia|Placebo<br> <sup>Orlistate</sup><br>Rimonabanto|Variável|Variável||NR|NR|3-48 meses|
|||Metformina<br>Cuidado padrão|||||||
|Rucker et al., 2007|Sibutramina 10 a 20|Placebo|Variável|Variável|Variação|de 38 - 53 anos|NR|4-54 semanas|  
mg/dia  
276  
###### **Tabela J1.** Desfechos primários de eficácia dos estudos incluídos.  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||Variação estimada do IMC<br>por mês, (IC95%):||Mudança de peso estimada<br>por mês (IC95%):||||
|Douglas et al.,<br>2014|(coorte)|Sibutramina|Controle 1:<br>orlistate<br>Controle 2: sem<br>medicamento|Acompanhamento de 4<br>meses<br>Grupo Intervenção: -0,47 (-<br>0,48 a -0,46)<br>Grupo Controle 1: -0,34 (-<br>0,34 a -0,34)|NR|Acompanhamento de 4 meses<br>Grupo Intervenção: -1,28 (-<br>1,30 a -1,26)<br>Grupo Controle 1: -0,94 (-0,95<br>a -0,93)|NR|NR|NR|
|||||Acompanhamento de 12<br>meses||Acompanhamento de 12<br>meses||||
|||||Grupo Controle 2: 0,01<br>(0,01, 0,01)||Grupo Controle 2: 0,03 (0,03,<br>0,03)||||
|Halpern, 2002|ECR|Sibutramina<br>10 mg/dia|Placebo|Acompanhamento de 6<br>meses<br>Grupo Intervenção: média<br>do IMC Inicial foi de 36,6 e<br>Final de 33,9 Diferença foi<br>de -2,7<br>Grupo controle: Média do<br>IMC inicial foi de 36,9 e<br>Final de 36,1 Diferença foi<br>de -0,8|p < 0,002<br>(valor final_versus_<br>valor inicial no<br>grupo<br>intervenção)<br>Valor de p não<br>reportado para o<br>grupo controle,<br>mas citado como<br>não-significativo|Acompanhamento de 6 meses<br>Grupo Intervenção: média do<br>peso inicial e final reportados<br>em Kg foram,<br>respectivamente, 91,1 e 83,8<br>Diferença foi de -7,3<br>Grupo Controle: média do<br>peso inicial e final reportados<br>em Kg foram,<br>respectivamente, 91,5 e 88,9<br>Diferença foi de -2,6<br>**Redução de < 5% do peso:**<br>~~Intervenção: 12 (40%)~~|Controle: 13<br>(41,9%)|Valores de p não<br>reportados, mas citados<br>como não- significativos|Grupo Intervenção: as<br>médias do perímetro da<br>cintura inicial e final em cm<br>foram, respectivamente,<br>103,5 e 96,2 Diferença foi de<br>- 7,3<br>Grupo Controle: média do<br>perímetro da cintura inicial e<br>final em cm foram,<br>respectivamente, 104,8 e<br>101,5 Diferença<br>foi de -3,3<br>Acompanhamento de 6<br>meses|  
277  
valores de p não reportados para diferenças intra ou entre grupos, mas citados como nãosignificativos  
278  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||**Redução de > 5% - <10%**<br>Intervenção: 4 (13,3%)<br>Controle: 3 (9,7%)<br>**Redução > 10%**<br>Intervenção: 8 (26,7%)<br>Controle: 1 (3,2%)||||
|||||||Acompanhamento de 12<br>semanas||||
|Appolinario et al.,<br>2003|ECR|Sibutramina<br>15 mg/dia|Placebo|NR|NR|Grupo Intervenção: média<br>(DP) do peso Inicial em Kg foi<br>de 102,8 (13,2) e Final de 95,4<br>(12,3) Diferença foi de -7,4<br>Grupo Controle: média (DP) do<br>peso Inicial em Kg foi 98,7<br>(12,9) e Final de 100,1 (13,6)<br>Diferença foi de +1,4|p < 0,001<br>(grupo intervenção<br>_versus_grupo<br>controle)|NR|NR|
|Fanghänel, 2003|ECR|Sibutramina<br>10 mg/dia|Placebo|Acompanhamento de 6<br>meses.<br>Resultados conforme<br>Análise por Intenção de<br>tratar:<br>Grupo Intervenção: a<br>diferença entre a média (IC<br>95%) do IMC inicial e final<br>foi de -2,4 (-3,2 a -1,6).<br>Grupo Controle: A diferença<br>entre a média (IC 95%) do<br>IMC inicial e final foi de –1,5<br>(–2,2 a –0,8).<br>Resultados conforme última<br>observação realizada (LOCF)|Grupo<br>intervenção:<br>valores de p não<br>reportados, mas<br>citados como<br>estatisticamente<br>significantes para<br>as diferenças<br>entre o valor final<br>_versus_o valor<br>inicial em ambas<br>análises.<br>Grupo Controle:<br>valores de p não<br>reportados, mas|citados como|Acompanhamento<br>de 6 meses<br>Resultados<br>conforme Análise<br>por Intenção de<br>tratar<br>Grupo<br>Intervenção: a<br>diferença entre a<br>média (IC 95%) do<br>peso inicial e final,<br>reportada em Kg,<br>foi de –6,0 (–8,0 a<br>–4,0).<br>Grupo Controle: a<br>~~diferença entre a~~|média (IC 95%) do<br>peso inicial e final,<br>reportada em Kg, –3,8<br>(–5,6 a –2,1).<br>Resultados conforme<br>última observação<br>realizada (LOCF)|Grupo intervenção: valores de<br>p não reportados, mas citados<br>como estatisticamente<br>significantes para as diferenças<br>entre o valor final_versus_o<br>valor inicial em ambas<br>análises.<br>Grupo Controle: valores de p<br>não reportados, mas citados<br>como estatisticamente<br>significantes para as diferenças<br>entre o|  
279  
Resultados conforme Análise por Intenção enças entre o valor de tratar: final _versus_ o valor inicial em ambas Acompanhamento de 6 meses Gr análises. up Grupo Intervenção: a diferença entre a o Grupo Controle: média (IC 95%) do perímetro da cintura int valores de p não inicial e final, reportada em cm, foi de erv reportados, mas –6,0 (–8,5 a -3,5). en citados como çã estatisticamente Grupo Controle: a diferença entre a média o: significantes para as (IC 95%) do perímetro da cintura inicial e val diferenças entre o final, reportada em cm, foi de or valor final _versus_ o –2,7 (–4,5 a –1,0). es valor de p nã o re po rta do s, ma s cit ad os co mo est ati sti ca me nt e sig nifi ca nt es pa ra as ~~dif~~ er  
280  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||Grupo Intervenção: a<br>diferença entre a média (IC<br>95%) do IMC inicial e final<br>foi de –2,2 (–2,8 a –1,5).<br>Grupo Controle: a diferença<br>entre a média (IC 95%) do<br>IMC inicial e final foi de –1,3<br>(–2,0 a –0,7).|estatisticamente<br>significantes para<br>as diferenças<br>entre o valor final<br>_versus_o valor<br>inicial em ambas<br>análises.|Grupo Intervenção: a<br>diferença entre a média (IC<br>95%) do peso inicial e final,<br>reportada em Kg, foi de –5,5<br>(–7,1 a –3,8).<br>Grupo Controle: a diferença<br>entre a média (IC 95%) do<br>peso inicial e final, reportada<br>em Kg, –3,4 (–5,0 a –1,9).|valor final_versus_o<br>valor inicial em<br>ambas análises.|Resultados conforme<br>LOCF:<br>Acompanhamento de 6<br>meses<br>Grupo Intervenção: a<br>diferença entre a média<br>(IC 95%) do perímetro<br>da cintura inicial e final,<br>reportada em cm, foi de<br>–5,3 (–7,3 a -3,2).|inicial em ambas<br>análises.|
||||||5,12 (DP 1,40; IC<br>–5,757 a –|||média do peso inicial e final,<br>(DP 4,25; IC –15,605 a –<br>11,|expresso em Kg, foi de – 13,68<br>735).|
|||||||||Grupo Controle 3: a diferenç|a|
|Kaya, 2004|ECR|Sibutramina<br>10 mg/dia|Controle 1:<br>monoterapia<br>com orlistate<br>120 mg;<br>Controle 2:<br>terapia<br>combinada:<br>sibutramina 10<br>mg + orlistate<br>120 mg;Controle<br>3: dieta|Eficácia mensurada por<br>análise de sensibilidade:<br>Acompanhamento de 12<br>semanas.<br>Grupo Intervenção: a<br>diferença entre a média do<br>IMC inicial e final foi de –<br>4,41 (DP 1,13; IC –3,963 a –<br>4,857).<br>Grupo Controle 1: a<br>diferença entre a média do<br>IMC inicial e final foi de –<br>3,64 (DP 0,90; IC –3,982 a –<br>3,298).<br>Grupo Controle 2: a||A comparação das alterações<br>do IMC mostrou que a terapia<br>combinada estava produzindo<br>diferenças estatisticamente<br>significativas em comparação<br>com a dieta ou com<br>monoterapia com orlistate (p<br>< 0,001 para ambos).<br>Além disso, a monoterapia<br>com sibutramina mostrou-se<br>mais eficaz do que a<br>monoterapia com|Acompanhamento<br>de 12 semanas.<br>Grupo Intervenção: a<br>diferença entre a<br>média do peso inicial<br>e final, expresso em<br>Kg, foi de –11,72 (DP<br>3,31; IC –13,178 a –<br>10,242).<br>Grupo Controle 1: a<br>diferença<br>entre<br>a<br>média do peso inicial<br>e final, expresso em<br>Kg, foi de – 9,35 kg<br>(DP 2,62; IC –10,421 a<br>–8,259).|||
|||||diferença entre a média do<br>IMC inicial e final foi de–|||Grupo Controle 2: a<br>diferença<br>entre<br>a|||  
281  
||G|m|2|
|---|---|---|---|
||r|e|,|
||u|t|4|
||p|r|(|
||o|o|–|
||C|d|3|
||o|a|,|
|As médias dos grupos em termos de perda|n|c|9|
|de peso foram significativamente diferentes|t|i|a|
|entre o grupo terapia combinada e os grupos|r|n|–|
|dieta e monoterapia com orlistate,|o|t|0|
|respectivamente (p < 0,001 para ambos).|l|u|,|
||e|r|8|
|No entanto, apesar de produzir uma|:|a|)|
|diferença numérica, não houve significância|a|<br>i|.|
|estatística em termos de perda de peso<br>|<br>d|n||
|entre o grupo de monoterapia com|i|i||
||f|c||
||e|i||
||r|a||
||e|l||
||n|e||
||ç|f||
||a|i||
||e|n||
||n|a||
||t|l|NR|
||r|,||
||e|r|NR|
||a|e||
||m|p||
||é|o||
||d|r||
||i|t||
||a|a||
||(|d||
||I|a||
||C|e||
||9|m||
||5|c||
||%|||
|||m||
||)|,||
||d|f||
||o|o||
||p|i||
||e|d||
||~~r~~<br>í|~~e~~<br>–||  
<u>282</u>  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||4,483).|orlistate (p =|entre a média do peso inicial e|sibutramina e o|||
|||||Grupo Controle 3: a|0,013).|final, expresso em Kg, foi de –<br>6,24 kg (DP 3,44; IC –7,896 a –|grupo de terapia<br>combinada (p =|||
|||||diferença entre a média do|A monoterapia|4,582).|0,067).|||
|||||IMC inicial e final foi de –<br>2,52 (DP 1,13; IC –2,967 a –|com orlistate e o<br>grupo dieta||A monoterapia com|||
|||||2,073).|inferiram||sibutramina produziu|||
||||||significativamente||significativamente|||
||||||em termos de||mais redução de peso|||
||||||diminuição do||do que o orlistate (p|||
||||||IMC (p < 0,001).||= 0,020).|||
||||||Por fim, o grupo<br>dieta mostrou-se||||respectivamente, de|
||||||o menos eficaz<br>em produzir|||||
||||||redução do IMC|||||
||||||<br>com diferenças<br>significativas nas<br>médias em<br>comparação a|||||
||||||todos os grupos|||||
||||||com intervenção<br>farmacológica (p <<br>0.01 para todas|||||
||||||as comparações).|||||
|||||||Acompanhamento de 3 meses.||Acompanhamento de 3<br>meses.||
|||||||Grupo Sibutramina Diabéticos:<br>média (DP) de peso inicial e<br>final, expressa em Kg, foi de,<br>|Grupo Sibutramina<br>Diabéticos: p < 0,001<br>|Grupo Sibutramina<br>Diabéticos: a média (DP)<br>||
|||Sibutramina<br>dose<br>média|Sem|NR<br>Os autores só descrevem o||respectivamente, 95,8 (10,1) e<br>89,0 (8,9). Redução de 7,1%|(intra-grupo; 3<br>meses)|do perímetro da cintura<br>e final, em cm, foram,<br>||
|Tankova, 2004|ECR|<br> <br>diária de 12,8<br>mg (DP = 2,2|<br>medicamento<br>ou placebo|<br>IMC na linha de base. Não é<br>descrito o IMC final e nem a|NR|Grupo Sibutramina de<br>|Grupo Sibutramina<br>|respectivamente, de<br>104,4 (9,6) e 95,0 (10,5).||
|||mg).||variação.||pacientes não-diabéticos:<br>média (DP) de peso inicial e|de pacientes não-<br>diabéticos: p <|Grupo Sibutramina||
|||||||<br>final, expressa em Kg, foi de,|<br>0,0001|<br>NÃO-Diabéticos: a||
|||||||respectivamente, tratado com|(intra-grupo; 3|média (DP) do||
|||||||sibutramina foi de 98,6 (9,9) e|meses)|perímetro da cintura e||
|||||||89,6 (10,4). Redução de 9,1%||final, em cm, foram,||  
283  
Grupo Sibutramina Diabéticos: p < 0,001 (intragrupo; 3 meses)  
Grupo Sibutramina de pacientes nãodiabéticos: p < 0,001 (intragrupo; 3 meses)  
284  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||Grupo controle de pacientes<br>diabéticos: média (DP) de peso<br>inicial e final, expressa em Kg,<br>foi de, respectivamente, 90,4<br>(8,8) e 87,8 (7,9). Redução de<br>2,9%<br>Grupo Controle de pacientes<br>não-diabéticos: média (DP) de<br>peso inicial e final, expressa<br>em Kg, foi de,<br>respectivamente, 95,2 (9,0)<br>92,5 (9,1). Redução de 2,9%|Grupo controle de<br>pacientes diabéticos:<br>p = 0,3<br>(intra-grupo; 3<br>meses)<br>Grupo Controle de<br>pacientes não-<br>diabéticos: p = 0,3<br>(intra-grupo; 3<br>meses)<br>p < 0,001<br>(entre grupos<br>Sibutramina<br>Diabéticos e Controle<br>Diabéticos)|104,2 (11,5) e 92,5<br>(12,8).<br>Grupo Controle<br>Diabéticos: a média (DP)<br>do perímetro da cintura<br>e final, em cm, foram,<br>respectivamente, de<br>104,5 (11,2) e 102,2<br>(12,4).<br>Grupo Controle NÃO-<br>Diabéticos: a média (DP)<br>do perímetro da cintura<br>e final, em cm, foram,<br>respectivamente, de<br>103,8 (12,2) e 100,9<br>(14,7).|Grupo Controle<br>Diabéticos: Valor de p<br>não-reportado, porém<br>descrito como NÃO<br>significativo.<br>Grupo Controle NÃO-<br>Diabéticos: Valor de p<br>não-reportado, porém<br>descrito como NÃO<br>significativo|
||||||||p < 0,0001<br>(entre grupos<br>Sibutramina não-<br>diabéticos e Controle<br>não-diabéticos)|||
||||||inicial e final foi<br>de −1,1|||(5,2)<br>Grupo Controle: perda<br>média de peso,<br>expressa em Kg, foi -<br>3,1 kg (IC 95% -3,8 a -<br>|P < 0,01<br>(entre grupos Sibutramina<br>Diabéticos_versus_Sibutramina<br>não- diabéticos)|
|||||Acompanhamento de 6<br>meses|||Acompanhamento<br>de 6 meses.|~~2,4).~~|A perda do grupo intervenção|
|Porter, 2004|ECR|Sibutramina 5<br>a 20 mg/dia|Sem<br>medicamento<br>ou placebo|Grupo Intervenção: a<br>diferença entre a média<br>(DP) do IMC inicial e final foi<br>de −2,4 (2,0)<br>Grupo Controle: a diferença<br>entre a média (DP) do IMC||A redução do IMC no grupo<br>intervenção foi<br>significantemente maior do<br>que no grupo controle (p<br>< 0,001).|Grupo Intervenção:<br>perda média de<br>peso, expressa em<br>Kg, foi de -6,8 (IC<br>95% -7,4 a -<br>6,1). Redução<br>média (DP) de 6,4||foi significantemente maior do<br>que a perda no grupo controle<br>(p<br>< 0,001).|  
285  
anteme nte maior do que a perda no grupo Acompanhament controle o de 6 meses (p < 0,001). Grupo Intervenção: A A diferença entre a r média (DP) do e perímetro da d cintura inicial e u final, reportada ç em cm, foi de ã −4,3 (7,9). o n Grupo Controle: o A g r u p o i n t e r  
v e n ç ã o f o i s i g n i f  
c  
286  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||(1,7)||Redução média (DP) de 2,9<br>(4,7)||diferença entre a média<br>(DP) do perímetro da<br>cintura inicial e final,<br>reportada em cm, foi de<br>−1,6 (7,4).||
|||||Grupo Intervenção: média<br>(DP) do IMC Inicial foi de<br>33,1 (1,4);<br>3º mês* de 31,4 (1,1).<br>6º mês* de 30,4 (0,9).||||Grupo Intervenção: a<br>média (DP) do<br>perímetro da cintura<br>(cm) Inicial foi de 101<br>(4); de 100 (3) no 3º<br>mês; de 99 (3) no 6º||
|Derosa, 2004|ECR|Sibutramina<br>10 mg/dia|Orlistat 360<br>mg/dia|9º mês** de 30,0 (0,8) no<br>9º mês.<br>12º mês*** de 29,5 (0,5).<br>Grupo Controle: média (DP)<br>do IMC Inicial foi de 33,6<br>(1,6); de 31,8 (1,0) no 3º<br>mês; de 30,9 (0,8)* no 6º<br>mês; de 30,3 (0,7)** no 9º<br>mês; e de 29,7 (0,6)*** no<br>12º mês.<br>|*p < 0,05_versus_<br>linha de base;<br>**p < 0,02_versus_<br>linha de base;<br>***p < 0,01_versus_<br>linha de base.|NR|NR|mês; de 97 (4) no 9º<br>mês; e de 95 (3)* no 12º<br>mês.<br>Grupo Controle: a média<br>(DP) do perímetro da<br>cintura (cm) Inicial foi de<br>102 (5); de 101 (3) no 3º<br>mês; de 100 (4) no 6º<br>mês; de 98 (3) no 9º<br>mês; e de 96 (4)* no 12º<br>mês.|*p < 0,05_versus_linha<br>de base|
|||||Eficácia mensurada por<br>análise de sensibilidade:||Acompanhamento de 6 meses.||||
|||||Acompanhamento de 6||Grupo intervenção: média do||||
|||||meses.||peso em KG Inicial foi de 93,7||||
|Di Francesco,<br>2007|ECR|Sibutramina<br>10 mg/dia|Placebo|Grupo intervenção: média<br>do IMC Inicial foi de 35,1<br>(DP 3) e Final de 32,6.<br>Grupo controle: média do<br>IMC Inicial foi de 35,0 (DP 3)<br>e final de 33,6.|p < 0,001<br>(Sibutramina<br>_versus_Placebo)|(DP 11,6) e final de 85,5.<br>Grupo controle: média do<br>peso em KG Inicial foi de 93,1<br>(DP 12,5) e final de 89,2.|p < 0,01<br>(Sibutramina_versus_<br>Placebo)|Para esse desfecho só<br>são reportados os<br>valores da linha de base.|NR|
||||Grupo Controle|||Acompanhamento de 6 meses.||Acompanhamento de 6||
|Erondu, 2007|ECR|Sibutramina|10 mg/dia|1: Placebo Grupo C<br>Orlistate 360 m|ontrole 2:<br>g/dia|NR|NR|Grupo Intervenção:|287<br>média (DP) de peso inicial e<br>final, expressa em Kg, foi de,|  
meses. Sibutramina vs. Placebo (p <0,001) Grupo Sibutramina Intervenção _versus_ : a Média Placebo (DP) do (<0,001)  
288  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||respectivamente, 98,0 (15,4) e<br>92,2 (15,8).<br>Grupo Controle 1 (Placebo):<br>média (DP) de peso inicial e<br>final, expressa em Kg, foi de,<br>respectivamente, 97,3 (15,2) e<br>95,2 (16,1).<br>Grupo Controle 2 (Orlistate):<br>média (DP) de peso inicial e<br>final, expressa em Kg, foi de,<br>respectivamente, 96,3 (12,3) e<br>91,2 (12,7).|Orlistate vs. Placebo<br>(p <0,001)<br>Sibutramina vs.<br>Orlistate (p = 0,097)|perímetro da cintura<br>inicial e final, expressa<br>em cm, foi de,<br>respectivamente, 107,4<br>(12,4) e 101,0 (13,6).<br>Grupo Controle 1<br>(Placebo): a Média (DP)<br>do perímetro da cintura<br>inicial e final, expressa<br>em cm, foi de,<br>respectivamente, 106,7<br>(11,4) e 104,1 (13,0).<br>Grupo Controle 2<br>(Orlistate): a Média (DP)<br>do perímetro da cintura<br>inicial e final, expressa<br>em cm, foi de,<br>respectivamente, 105,9<br>(10,7) e 100,0 (11,1).|Orlistate_versus_Placebo<br>(p = 0,003)<br>Sibutramina_versus_<br>Orlistate (p = 0,338)|
|||||||Acompanhamento de 6 meses||||
|||||||Resultados conforme última<br>observação realizada (LOCF):<br>Grupo Intervenção: média<br>(DP)<br>−4,12 (4,19) kg<br>Grupo Controle:<br>||||
|Caterson et al.,<br>2012|ECR|Sibutramina<br>10 mg/dia|Placebo|NR|NR|−2,08 (3,84)|NR|NR|NR|
|||||||Acompanhamento de 12<br>meses||||
|||||||Grupo Intervenção: média<br>(DP)<br>−4,18 (4,78)<br>Grupo Controle:|||289|  
290  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**<br>**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
||||||−1,87 (4,43)||||
||||||Estudos de 8 a 12 semanas de<br>duração: a diferença média<br>ponderada na perda de peso<br>foi de -2,78 kg (IC 95%: -3,29 a<br>-2,26), a favor da sibutramina.<br>Não houve heterogeneidade<br>significativa entre os sete<br>estudos incluídos na análise (p<br>= 0,55).||||
|Arterburn et al.,<br>2004|RS com<br>meta-<br>análise|Sibutramina<br>10 a 20<br>mg/dia|Placebo|NR|NR<br>Estudos com 16 a 24 semanas<br>de duração: a diferença média<br>ponderada na perda de peso<br>foi de –5,06 Kg (IC 95%: –6,16<br>a –3,96), a favor da<br>sibutramina. Houve<br>heterogeneidade significativa<br>entre os 12 estudos incluídos<br>na análise (p < 0,001).|NR|NR|NR|
||||||Estudos com 44 a 54 semanas<br>de duração: a diferença média<br>ponderada na perda de peso<br>foi de –4,45Kg (IC 95%: –5,29 a<br>–3,62), a favor da sibutramina.||||
||||||relação a placebo: -2,43 (-||Não houve heterogeneidade<br>estudos incluído<br>= 0,1|significativa entre os cinco<br>s na análise (p<br>4).|
|||||Variação estimada do IMC<br>(ICr 95%):|||Mudança de pes<br>Acompanhamento de 3 mes|o kg (ICr 95%)<br>es Sibutramina 10 mg/ em|
|Gray et al., 2012|RS com<br>meta-<br>análise|Sibutramina<br>10 e 15<br>mg/dia|Placebo<br>Orlistate|Acompanhamento de 3<br>meses<br>Sibutramina 10 mg/ em||NR|relação a placebo: -4,88 (-6,40<br>a -3,4<br>Sibutramina|3)<br>15 mg/ em|  
291  
NR NR  
NR  
292  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||3,33 a -1,54)<br>Sibutramina 15 mg/ em<br>relação a placebo: -2,25**(-<br>2,97 a -1,54)<br>Sibutramina 10 mg/ em<br>relação a orlistate: -0,87 (-<br>1,52 a -0,23)<br>Sibutramina 15 mg/ em<br>relação a orlistate: -0,69* (-<br>1,75 a 0,38)||relação a placebo: -5,37** (-<br>6,59 a -4,10)<br>Sibutramina 10 mg/ em<br>relação a orlistate: -2,23** (-<br>3,52 a -0,99)<br>Sibutramina 15 mg/ em<br>relação a orlistate: -2,73* (-<br>4,36 a -1,07)<br>Acompanhamento de 6 meses||||
|||||Acompanhamento de 6<br>meses||Sibutramina 10 mg/ em<br>relação a placebo: -5,08** (-<br>6,55 a -3,62)||||
|||||Sibutramina 10 mg/ em<br>relação a placebo: -0,95 (-<br>2,89 a 1,02)||Sibutramina 15 mg/ em<br>relação a placebo: -6,11 (-8,11<br>a -4,23)||||
|||||Sibutramina 15 mg/ em<br>relação a placebo: -1,81 (-<br>4,25 a 0,61)||Sibutramina 10 mg/ em<br>relação a orlistate: -2,00 (-3,57<br>a -0,42)||||
|||||Sibutramina 10 mg/ em<br>relação a orlistate: -0,36 (-<br>2,43 a 1,80)||Sibutramina 15 mg/ em<br>relação a orlistate: -3,03 (-5,10<br>a -1,06)||||
|||||Sibutramina 15 mg/ em<br>relação a orlistate: -1,22* (-<br>4,07 a 1,61)||Acompanhamento de 12<br>meses||||
|||||Acompanhamento de 12<br>meses<br>Sibutramina 10 mg/ em<br>relação a placebo: -2,27* (-||Sibutramina 10 mg/ em<br>relação a placebo: -5,42 (-7,36<br>a -3,42)<br>Sibutramina 15 mg/ em||||
|||||5,08 a 0,59)||relação a placebo: -6,35** (-<br>8,06 a -4,63)||||  
293  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||Sibutramina 15 mg/ em<br>relação a placebo: -2,91**<br>(-5,45 a -0,62)<br>Sibutramina 10 mg/ em<br>relação a orlistate: -0,84 (-<br>3,42 a 1,74)<br>Sibutramina 15 mg/ em<br>relação a orlistate: -1,49* (-<br>4,33 a 1,11)||Sibutramina 10 mg/ em<br>relação a orlistate: -1,30 (-3,30<br>a 0,74)<br>Sibutramina 15 mg/ em<br>relação a orlistate: -2,23* (-<br>4,03 a -2,23)<br>**Redução de 5% do peso**||||
|||||||Acompanhamento de 3 meses||||
|||||||Sibutramina 10 mg/ em<br>relação a placebo: 5,87 (1,46 a<br>17,65)||||
|||||||Sibutramina 15 mg/ em<br>relação a placebo: 9,95 (3,10 a<br>32,71)<br>Sibutramina 10 mg/ em<br>relação a orlistate: 32,31*<br>(0,29 a 102,70)||||
|||||||Sibutramina 15 mg/ em<br>relação a orlistate: 35,04*<br>(0,87 a 140,90)||||
|||||||Acompanhamento de 6 meses||||
|||||||Sibutramina 10 mg/ em<br>relação a placebo: 4,25 (2,39 a<br>6,84)<br>Sibutramina 15 mg/ em<br>relação a placebo: 6,90 (3,88 a<br>12,99)||||
|||||||Sibutramina 10 mg/ em<br>relação a orlistate: 1,55* (0,67||||  
294  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||a 3,01)<br>Sibutramina 15 mg/ em<br>relação a orlistate: 2,50 (1,06 a<br>5,35)||||
|||||||Acompanhamento de 12<br>meses||||
|||||||Sibutramina 10 mg/ em<br>relação a placebo: 3,25 (1,56 a<br>6,22)<br>Sibutramina 15 mg/ em<br>relação a placebo: 4,06 (2,51 a<br>6,29)||||
|||||||Sibutramina 10 mg/ em<br>relação a orlistate: 1,14* (0,52<br>a 2,24)||||
|||||||Sibutramina 15 mg/ em<br>relação a orlistate: 1,42 (0,83 a<br>2,92)||||
|||||||**Redução de 10% do peso**||||
|||||||Acompanhamento de 3 meses<br>Sibutramina 10 mg/ em<br>relação a placebo: 16,41 (0,34<br>a 93,23)<br>Sibutramina 15 mg/ em<br>relação a placebo: 14,48 (0,28<br>a 77,41)||||
|||||||Em relação a orlistate: não<br>relatado||||  
295  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||Acompanhamento de 6 meses<br>Sibutramina 10 mg/ em<br>relação a placebo: 6,57 (3,28 a<br>6,14)<br>Sibutramina 15 mg/ em<br>relação a placebo: 18,83 (6,70<br>a 48,10)<br>Sibutramina 10 mg/ em<br>relação a orlistate: 2,40* (0,02<br>a 5,81)<br>Sibutramina 15 mg/ em<br>relação a orlistate: 6,69 (2,01 a<br>17,94)||||
|||||||Acompanhamento de 12<br>meses<br>Sibutramina 10 mg/ em<br>relação a placebo: 3,38 (1,39 a<br>7,13)<br>Sibutramina 15 mg/ em<br>relação a placebo: 5,02 (2,63 a<br>9,12)<br>Sibutramina 10 mg/ em<br>relação a orlistate: 1,44* (0,54<br>a 3,14)<br>Sibutramina 15 mg/ em<br>relação a orlistate: 2,13* (1,00<br>a 4,10)||||
|Rucker et al.,<br>2007|RS com<br>meta-<br>análise|Sibutramina<br>10 a 20<br>mg/dia|Placebo|NR|NR|A diferença média ponderada<br>de peso foi de -4,20Kg (IC 95%<br>-4,77 a -3,64), a favor da<br>Sibutramina. I<sup>2</sup>= 0%; 7 ECR;<br>1536 pacientes.|p <0,001|NR|NR|  
296  
|**Autor, ano**|**Desenho**<br>**do**<br>**Estudo**|<br>**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**|**Valor de p**|**Desfecho do Peso**|**Valor de p**|**Desfecho do perímetro**<br>**da cintura**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||**Redução de 5% do peso**<br>Nº estudos (tamanho da<br>amostra) – Diferença de risco<br>(ativo menos placebo) IC95%<br>7 (1464) 0,32 (0,27 a 0,37)||||
|||||||**Redução de 10% do peso**<br>7 (1464) 0,18 (0,11 a 0,25)||||  
**Legenda:** ECR: ensaio clínico randomizado; NR: não reportado; RS: revisão sistemática; IMC: índice de massa corpórea; * Não há estudos _head to head_ ; **Estimativa MTC não se enquadra no intervalo de confiança na meta-análise por pares. LOCF: _Last Observation Carried Forward_ .  
###### **Tabela K1.** Resultados de segurança dos estudos incluídos.  
||**Halpern,**|**2002**|**Porter, 2**|**004**|**Fanghänel**|**, 2003**||**Erondu, 2007**||**Derosa**|**, 2004**|**Kay**|**a, 2004**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|Sibutramina<br>10 mg/dia<br>(n= 30)|Controle<br>(n = 31)|Sibutramina<br>5 a 20 mg/dia<br>(n= 291)|Controle<br>(n = 280)|Sibutramina<br>10 mg/dia<br>(n= 23)|Controle<br>(n = 24)|Placebo<br>(n = 101)|Sibutramina<br>10 mg/dia<br>(n= 100)|Orlistate<br>(n = 99)|Sibutramina<br>10 mg/dia<br>(n= 9/68)|Orlistate<br>(n = 22/65)|<br>Sibutramina <br>10 mg/dia|<sup>Orlistate 120 mg</sup><br>ou terapia<br>combinada|
|cabeça<br>Dor de|NR|NR|33 (11,3)|1 (0,4)|5 (21,7)|2 (8,3)|NR|NR|NR|4|NR|2 (9,1)|2 (10,0)|
|Dor|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|seca<br>Boca|2 (6,6)|4 (12,9)|85 (29,2)|3 (1,1)|4 (17,4)|2 (8,3)|1 (1,0)|6 (6,0)|1 (1,0)|2|NR|5 (22,7)|4 (20,0)|
|Infecção|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Faringite|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|ção<br>Constipa|2 (6,6)|5 (16,1)|55 (18,9)|1 (0,4)|4 (17,4)|2 (8,3)|4 (4,0)|11 (11,0)|2 (2,0)|1|NR|4 (18,2)|1 (5,0)|
|Gripe|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|costas<br>Dor nas|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Rash|NR|NR|15 (5,2)|1 (0,4)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Sinusite|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
297  
||**Halpern,**|**2002**|**Porter, 2**|**004**|**Fanghäne**|**l, 2003**||**Erondu, 2007**||**Derosa,**|**2004**|**Kay**|**a, 2004**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**||||||||||||||
|<br>**adversos**|Sibutramina|Controle|Sibutramina|Controle|Sibutramina|Controle|Placebo|Sibutramina|Orlistate|Sibutramina|Orlistate|Sibutramina|Orlistate 120 mg|
||10 mg/dia<br>(n= 30)|<br>(n = 31)|5 a 20 mg/dia<br>(n= 291)|<br>(n = 280)|10 mg/dia<br>(n= 23)|<br>(n = 24)|<br>(n = 101)|10 mg/dia<br>(n= 100)|<br>(n = 99)|10 mg/dia<br>(n= 9/68)|<br>(n = 22/65)|10 mg/dia|ou terapia<br>combinada|
|acidental<br>Lesão|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|lgia<br>Epigastra|0|1 (3,2)|NR|NR|NR|NR|NR|NR|NR|NR|5|NR|NR|
|ia<br>Sonolênc|1 (3,3)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|dia<br>Taquicar|NR|NR|61 (20,9)|15 (5,4)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|são<br>Hiperten|NR|NR|51 (17,5)|24 (8,6)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Insônia|NR|NR|50(17.2)|0|1 (4,3)|1 (4,2)|NR|NR|NR|3|NR|NR|NR|
|Aumento<br>de<br>apetite|NR|NR|21 (7,2)|2 (0,7)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Tontura|NR|NR|20 (6,9)|1 (0,4)|1 (4,3)|1 (4,2)|NR|NR|NR|NR|NR|NR|NR|
|Náusea|NR|NR|9 (3,1)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Astenia|NR|NR|8 (2,7)|1 (0,4)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|e<br>Ansiedad|NR|NR|6 (2,1)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|mo<br>Nervosis|NR|NR|6 (2,1)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Suor|NR|NR|6 (2,1)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor no||||||||||||NR|NR|
|peito,<br>não<br>cardíaco|NR|NR|6 (2,1)|2 (0,7)|NR|NR|NR|NR|NR|NR|NR|||
|seca<br>Tosse|NR|NR|NR|NR|2 (8,7)|2 (8,3)|NR|NR|NR|NR|NR|NR|NR|
|terite<br>Gastroen|NR|NR|NR|NR|0|1 (4,2)|NR|NR|NR|NR|NR|NR|NR|  
298  
||**Halpern,**|**2002**|**Porter, 2**|**004**|**Fanghänel**|**, 2003**||**Erondu, 2007**||**Derosa,**|**2004**|**Kay**|**a, 2004**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|Sibutramina|Controle|Sibutramina|Controle|Sibutramina|Controle|Placebo|Sibutramina|Orlistate|Sibutramina|Orlistate|Sibutramina|Orlistate 120 mg|
||10 mg/dia<br>(n= 30)|<br>(n = 31)|5 a 20 mg/dia<br>(n= 291)|<br>(n = 280)|10 mg/dia<br>(n= 23)|<br>(n = 24)|<br>(n = 101)|10 mg/dia<br>(n= 100)|<br>(n = 99)|10 mg/dia<br>(n= 9/68)|<br>(n = 22/65)|10 mg/dia|ou terapia<br>combinada|
|ão<br>Inquietaç|NR|NR|NR|NR|1 (4,3)|0|NR|NR|NR|NR|NR|NR|NR|
|Infecção||||||||||||NR|NR|
|respirató<br>do trato<br>rio|NR|NR|NR|NR|3 (13,0)|8 (33,3)|NR|NR|NR|NR|NR|||
|Dor no<br>ombro<br>direito|NR|NR|NR|NR|0|1 (4,2)|NR|NR|NR|NR|NR|NR|NR|
|o<br>Palpitaçã|NR|NR|NR|NR|NR|NR|0 (0,0)|2 (2,0)|0 (0,0)|NR|NR|NR|NR|
|Bradicar<br>dia<br>sinusial|NR|NR|NR|NR|NR|NR|0(0.0)|0 (0,0)|1 (1,0)|NR|NR|NR|NR|
|Extra-||||||||||||NR|NR|
|ventricul<br>sístoles<br>ares|NR|NR|NR|NR|NR|NR|0(0,0)|1 (1,0)|0 (0,0)|NR|NR|||
|ouvido e<br>Distúrbio<br>s do<br>labirinto|NR|NR|NR|NR|NR|NR|2 (2,0)|2 (2,0)|0 (0,0)|NR|NR|NR|NR|
|Desorde||||||||||||NR|NR|
|endócrin<br>ns<br>as|NR|NR|NR|NR|NR|NR|0 (0,0)|0 (0,0)|1 (1,0)|NR|NR|||
|Desorde<br>ns<br>oculares|NR|NR|NR|NR|NR|NR|1 (1,0)|2 (2,0)|1 (1,0)|NR|NR|NR|NR|
|abdomin<br>Distensã<br>o<br>al|NR|NR|NR|NR|NR|NR|1 (1,0)|1 (1,0)|6 (6,1)|NR|NR|NR|NR|
|Diarreia|NR|NR|NR|NR|NR|NR|3 (3,0)|5 (5,0)|17 (17,2)|NR|NR|NR|5 (25,0)|
|ia<br>Flatulênc|NR|NR|NR|NR|NR|NR|1 (1,0)|2 (2,0)|4 (4,0)|NR|7|NR|5 (25,0)|  
299  
||**Halpern,**|**2002**|**Porter, 2**|**004**|**Fanghänel**|**, 2003**||**Erondu, 2007**||**Derosa,**|**2004**|**Kay**|**a, 2004**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|Sibutramina<br>10 mg/dia<br>(n= 30)|Controle<br>(n = 31)|Sibutramina<br>5 a 20 mg/dia<br>(n= 291)|Controle<br>(n = 280)|Sibutramina<br>10 mg/dia<br>(n= 23)|Controle<br>(n = 24)|Placebo<br>(n = 101)|Sibutramina<br>10 mg/dia<br>(n= 100)|Orlistate<br>(n = 99)|Sibutramina<br>10 mg/dia<br>(n= 9/68)|Orlistate<br>(n = 22/65)|<br>Sibutramina<br>10 mg/dia|Orlistate 120 mg<br>ou terapia<br>combinada|
|Aumento<br>da||||||||||||NR|NR|
|pressão<br>sanguíne<br>a|NR|NR|NR|NR|NR|NR|NR|NR|NR|1|NR|||
|Fezes||||||||||||||
|gorduros<br>as|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|10|NR|5 (25,0)|
|Aumento||||||||||||NR|NR|
|defecaçã<br>o<br>de|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|3|||
|Urgência<br>fecal|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
300  
<!-- Start of picture text -->
Figura J1 . Meta-análise comparativa entre sibutramina e placebo na redução do peso corporal.<br>Study Sibutramina Placebo Mean Difference Mean Difference<br>1.1.1 Doseor Subgroup10 mgidia Mean SD Total Mean SD Total Weight IV,Random,95% CI_Year IV, Random, 95%Cl<br>Apfelaum 52 78 Sf 08 87 78 7.9% -5.70E7.77,-363 1999 ——-——<br>Smith “64 663 153 -16 447 157 106% -4.80/6.08,-354) 2001 —<br>CatersonSanchez Reyes -418-41 1045478 490544-14-187 10.78443 499742 13.2%3.2% -2.316-249,-213]-270(7.19,1.79) 20082012 -<br>‘Subtotal (95% Cl) 5183 5174 34.9% -3.93[-5.94, 1.92] =><br>TestorHeterogeneity.overall Tau?=efect Z=2.16;3.83Chi= = 24.03,0.0001) af=3 @ < 0.0001),F= 88%<br>1.4.2 Dose 15 mgidia<br>MeyKaukua “54-71 10.26495 11168 -02-26 10.284 12184 97%63% -6.201673,-367]-4.5057.14,-1.86) 20032006 =§=———=9—-—<br>Hauner “81 77 176 51 BT 174 97% -3.00/452,-1.48) 2008 _-—<br>‘Subtotal (95% Cl) 353 359 25.7% -4.18 [-5.68, -2.69] =_<br>Heterogeneity. Tau?= 0.88; Chi#= 4.08, df= 2(P= 0.13), P= 51%<br>‘Test for overall effect Z= §.48 (P< 0.00001)<br>1.1.3 Dose 20 mgidia<br>McMahon(a) 44° 51 142 -05 38 69 10.7% -3.90[5.13,-2.67] 2000 _—<br>SubtotalMcMahon(b) (95% Ch “45045 287145 -04 36 14172 11.1%21.8% 4.01-4.10F5.21,-2.99] [-4.83, 3.19] 2002 —><br>Heterogenelty. Tau*= 0.00; Chi#= 0.06, df= 1 (P= 0.81); P= 0%<br>Test for overall effect Z= 9.95 (P < 0.00001)<br>1.4.4 Doses variadas (10.15.20)<br>James “89 81 360 -49 69 114 10.2% -4.00/5.38,-2.62) 2000 —<br>‘SubtotalMathusMiegen(95% CI) 107 «7.5 44494-85 A195.209 17.6%7.4% -3.32[-5.03,-1.61]-2.20F4.43,0.03] 2005 =__<br>TestHeterogeneity: or overall efectTau*=Z=0.73, 3.81Chi*=(P= 0.0001)1.82, df= 1 (P= 0.18); F= 45%<br>Total (95% Cl) 6267 5883 100.0% -3.87 [-4.78, 2.96] ><br>Heterogeneity. Tau*=<br>Test{orTest for overallsubqroupefectdifferences:2=1.63;8.31Chi*= Chi*=® < $8.21,0.00001)0.63, df=df=103 (P (P =« 0.00001); 0.89),F= 0%P= 83% favorda+Sibutramina A favordo placebo<br><!-- End of picture text -->  
**Figura K1.** Sumário do risco de viés: julgamento dos revisores sobre cada item do risco de viés para cada ensaio clínico randomizado incluído individualmente ou a partir da Revisão Sistemática de Rucker  
<!-- Start of picture text -->
3 &<br>[9 [@]o[@] 4 [o] sO] |% [ele] [ee] 4 [eee a |r s2qne senatan condor is<br>\@ e+ 4\4\#\#le\e s\e | S| | © ©] @ | & | riiccaton concewmontsatecton tiaxy<br>OOO OOO OOOO OOOO OO ee<br>ODDO DOSOSDODOOO OOOO Ge<br>\s ee NOOOOOODOOOOOOOOOU tae<br>|[@|@/@|@/ 2 @|@| + |@/@/@/@|0/0) #|0/0/0|+O 0/0!OO)o|#| 0/0]| 4/4)#|#/0/0@/@ |e)| & | @ |seem20:10 pmsorna nine<br><!-- End of picture text -->  
<!-- Start of picture text -->
et al.<br><!-- End of picture text -->  
301  
###### **Quadro M1.** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ [SoF] do _webapp_ GRADEPRO).  
||||Avaliação da ce|rteza|||№ de paci|entes|Efe|ito|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|№ dos<br>estudos|Delineamento do<br>estudo|Risco<br>de viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outras<br>considerações|Sibutramina|placebo|Relativo<br>(95% CI)|Absoluto<br>(95% CI)|Certeza|Importância|  
Perda de peso em Kg  
|11<br>da de pe|ensaios clínicos<br>randomizados<br>so em Kg - Dose 10|grave<sup>a</sup><br>mg/dia|grave<sup>b</sup>|não grave|não grave|viés de<br>publicação<br>altamente<br>suspeito<br>forte associação<sup>c</sup>|6267|5883|-<br>DM 3.87<br>menor<br>(4.78<br>menor<br>para 2.96<br>menor)|⨁`◯◯◯`<br>MUITO BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|4|ensaios clínicos<br>randomizados|grave<sup>d</sup>|grave<sup>b</sup>|não grave|grave<sup>e</sup>|viés de<br>publicação<br>altamente<br>suspeito<br>forte associação<sup>c</sup>|5183|5174|-<br>MD 3.93<br>menor<br>(5.94<br>menor<br>para 1.92<br>menor)|⨁`◯◯◯`<br>MUITO BAIXA|CRÍTICO|  
Perda de peso em Kg - Dose 10 mg/dia  
Perda de peso em Kg - Dose 15 mg/dia  
|3|ensaios clínicos<br>randomizados|grave<sup>d</sup>|não grave<sup>f</sup>|não grave|não grave|viés de<br>publicação<br>altamente<br>suspeito<br>forte associação<sup>c</sup>|353|359|-<br>MD 4.18<br>menor<br>(5.68<br>menor<br>para 2.69<br>menor)|⨁⨁⨁`◯`<br>MODERADA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
Perda de peso em Kg - Dose 20 mg/dia  
302  
||||Avaliação da ce|rteza|||№ de paci|entes|Ef|eito|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|№ dos<br>estudos<br>Deline<br>e|amento do<br>studo|Risco<br>de viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outras<br>considerações|Sibutramina|placebo|Relativo<br>(95% CI)|Absoluto<br>(95% CI)|Certeza|Importância|
|2<br>ensai<br>rand<br>Perda de peso em|os clínicos<br>omizados<br>Kg - Doses v|grave<sup>d</sup><br>ariadas (10-1|não grave<sup>g</sup><br>5-20)|não grave|não grave|viés de<br>publicação<br>altamente<br>suspeito<br>forte associação<sup>c</sup>|287|141|-|MD 4.01<br>menor<br>(4.83<br>menor<br>para 3.19<br>menor)|⨁⨁⨁`◯`<br>MODERADA|CRÍTICO|
|2<br>ensai<br>rand<br>**: INTERVALO DECONF**<br>**OSITIVO NO TRATAMEN**<br>**uadro N1.**Re|os clínicos<br>omizados<br>**IANÇA; DM: D**<br>**TO; D. RISCO I**<br>sumo do|grave<sup>d</sup><br> **IFERENÇA DE**<br>**NCERTO COM LI**<br>s princip|não grave<sup>f</sup><br>**MÉDIA; A. ALTO RISCO**<br>**M ITAÇÕES GRAVES; E **<br>ais domínios|não grave<br>**OU RISCO INCERTO**<br>**. OS RESULTADOS E**<br>avaliados n|não grave<br>**DE VIÉS PELA FER**<br>**STÃO NA MESMA D**<br>o GRADE (T|viés de<br>publicação<br>altamente<br>suspeito<br>forte associação<sup>c</sup><br>**RAMENTA DE VIÉS  DACO**<br>**IREÇÃO, PORÉM OS INTER**<br>abela_Evidence_|444<br>**CHRANE; B. ALTA HE**<br>**VALOS DE CONFIANÇA**<br>_to Decision_(|209<br>**TEROGENEIDAD**<br>**NÃO SÃO SOBR**<br>EtD) do|-<br>**E PELO  TESTE D**<br>**EPONÍVEIS; F. H**<br>_webapp_GR|MD 3.32<br>menor<br>(5.03<br>menor<br>para 1.61<br>menor)<br>**E  I  QUADRADO; C. **<br> **ETEROGENEIDADE**<br>ADE PRO).|⨁⨁⨁`◯`<br>MODERADA<br>**TODOS OS  ESTUDOS**<br>**MODERADA; G. BAIX**<br>|CRÍTICO<br>**MOSTRARAM  EFEIT**<br>**A HETEROGENEIDA**|
|PERGUNTA<br>**Deve-se usa**<br>|<br>**r sibutra**<br>|**mina****_vs_**<br>|**_._placebo p**<br>|**ara perda**<br>|**de peso e**|**m indivíduos a**|**dultos com**|**obesida**|**de?**||||
|**POPULAÇÃO:**|perda d|e peso em in|divíduos adultos|com obesidade|||||||||
|**INTERVENÇÃO:**|sibutra|mina|||||||||||
|**COMPARAÇÃO:**|placebo||||||||||||
|**DESFECHOS**<br>**PRINCIPAIS:**|Perda d|e peso em K|g;||||||||||  
**IC: INTERVALO DE CONFIANÇA; DM: DIFERENÇA DE MÉDIA; A. ALTO RISCO OU RISCO INCERTO DE VIÉS PELA FERRAMENTA DE VIÉS  DA COCHRANE; B. ALTA HETEROGENEIDADE PELO  TESTE DE  I  QUADRADO; C. TODOS OS  ESTUDOS MOSTRARAM  EFEITO POSITIVO NO TRATAMENTO; D. RISCO INCERTO COM LIM ITAÇÕES GRAVES; E. OS RESULTADOS ESTÃO NA MESMA DIREÇÃO, PORÉM OS INTERVALOS DE CONFIANÇA NÃO SÃO SOBREPONÍVEIS; F. HETEROGENEIDADE MODERADA; G. BAIXA HETEROGENEIDADE Quadro N1.** Resumo dos principais domínios avaliados no GRADE (Tabela _Evidence to Decision_ (EtD) do _webapp_ GRADE PRO).

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
303

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
#### Problema  
|O problema é uma prioridade?|||
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>A obesidade mundial quase triplicou desde 1975.<br><br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais<br>de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.<br><br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais<br>pessoas do que abaixo do peso.<br><br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.<br><br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou<br>obesas em 2016.<br><br>A obesidade é evitável.<br><br>Existe mortalidade associada à obesidade com fator de riscom para doenças cardiovasculares, diabetes<br>e outras condições metabólicas e cancer. Está associada com redução da expectativa de vida.||
|Efeitos Desejáveis<br>Quão substanciais são os efeitos d|esejáveis?<br>||
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Trivial<br>● Pequeno<br>○ Moderado<br>○ Grande<br>○ Varia<br>○ Incerto|· Maior redução de peso nos participantes em uso da sibutramina em relação ao placebo;<br>. Estudo de Kaya et al, 2004 mostrou superioridade da sibutramina para a perda de peso e IMC em relação ao<br>orlistate. A RS de Gray et al. 2012 o sibutramina em 15 mg foi superior ao orlistate para a perda de peso.<br>· Em relação aos desfechos redução de IMC, a sibutramina também foi mais eficaz quando comparada ao controle<br>na maioria dos estudos;<br>· Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, dois estudos relataram superioridade<br>da sibutramina em relação placebo.<br>· A sibutramina apresenta maior número de eventos adversos quando comparada ao placebo;<br>. Eventos mais frequentes: boca seca, aumento de pressão arterial,||  
304  
<!-- Start of picture text -->
Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, um dos estudos não encontrou<br>diferença estatisticamente significante entre a sibutramina e o controle.<br>. Estudos com longo seguimento, tem-se um efeito desejável por um prazo e depois mostraram ganho de peso<br>após 2 anos de terapia.<br><!-- End of picture text -->  
<!-- Start of picture text -->
Study ‘Sibutramina Placebo Mean Difference Mean bitference<br>7-1-1 Doseor Subgroup10 mgldia _Mean SD Total Mean SD Total Weight 1V, Random,95% Cl_Year 1, Random,95% Cl<br>apfelbaum 52 78 81 05 57 78 79% -570[7.77,-363] 1999 ——-——<br>Smith “64 663 153-16 447 187 106% -480(6.06,-354) 2001 =<br>Sanchez-Reyes 41 1045 44 14 1078 423.2% -2707.19,1.79) 2004<br>Caterson “418 478 4905 1.87 443 4997 132% -2316249,-213] 2012<br>Subtotal (95% ct) 5183 5174 349% 3.931.594, 4.92) —<br>Heterogeneity:Testfor overall eect:Tau*= 2=3.16; 3.83Chi?=(P= 0.0001)24.63, df= 3 P « 0.0001); P= 88%<br>MeNutty1.4.2 Dose 15 maidia “54 495 68 02 4 64 97% -5.20f673,-367) 2003 =—-—<br>KaukuaHaunerSubtotal (95% c) 7410268177 353111174 81-26 1026G7 121174359 25.7%63%97% -450(7.14,-1.88)-300/4.52,-1.48)-4.185.68, 2.69] 20042004 =—————_—<br>Heterogeneity: Tau*= 0.88; Chit= 4.08, df= 2 (P= 0.13), P= 51%<br>Testfor overall eect Z= 5.48 (P < 0.00001),<br>Mewanonva)1.13 Dose 20 maidia <44 51 142-08 38 69 107% -3901613,-267) 2000 —<br>Mewanont®) “45 45 145-04 36 72 141% -4106821,-299) 2002 —<br>‘Subtotal (95% Cl) 287 141 24.8% 4.01 [-4.83, 3.19] ><br>Heterogeneity:Testfor overall Tau?=efect Z=0,00;9.55Chi?=(P  0.08,< 0.00001) df= 1 (P= 0.81), P= 0%<br>1.4.4 Doses voriadas (10-15-20)<br>James -89 81 350 -49 69 114 10.2% -40046.38,-262) 2000 =<br>Mathus-VliegenSubtotal (95% CH 107-7594aaa 85 BT 209957.4%17.6% -3.3215.03,-1.51]-2.2084.43,0.03] 2005 —<br>Heterogeneity:Testfor Tau*= 0,73; Chi?= 1.62, f= 1 (P= 0.18);P= 45%<br>Total (95%overallCI) eect:Z= 3.81 (P= 0.0001)6267 5883 100.0% -3.87[-4.78,-2.96] ><br>Heterogeneity: Taut= 1.63; Chi*= $8.21, df= 10 (P < 0.00001), P= 83% + t<br>Tostfor overall efect 2= 8.31 (P <0.00001) wor da Siburemina  Afavor do placeb<br>Testfor subaroup diferences: Ch™= 063, f= 3 (P = 0.80). B= 0% Atavor da Sibutramina favordo placebo<br><!-- End of picture text -->  
305  
#### Efeitos Indesejáveis  
|Quão substanciais são osef|eitos indesejáveis esperados?||
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Grande<br>● Moderado<br>○ Pequeno<br>○ Trivial|· Maior redução de peso nos participantes em uso da sibutramina em relação ao placebo;<br>. Estudo de Kaya et al, 2004 mostrou superioridade da sibutramina para a perda de peso e IMC em relação ao<br>orlistate. A RS de Gray et al. 2012 o sibutramina em 15 mg foi superior ao orlistate para a perda de peso.||
|○ Varia<br>○ Incerto|· Em relação aos desfechos redução de IMC, a sibutramina também foi mais eficaz quando comparada ao controle<br>na maioria dos estudos;||
||· Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, dois estudos relataram superioridade<br>da sibutramina em relação placebo.||
||· A sibutramina apresenta maior número de eventos adversos quando comparada ao placebo;<br>. Eventos mais frequentes: boca seca, aumento de pressão arterial,<br>Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, um dos estudos não encontrou<br>diferença estatisticamente significante entre a sibutramina e o controle.<br>. Estudos com longo seguimento, tem-se um efeito desejável por um prazo e depois mostraram ganho de peso<br>após 2 anos de terapia.||  
306  
<!-- Start of picture text -->
Studyor1.1.1 Dose Subgroup_Mean_SO10 miaia SibutraminaTotal MeanPlaceboSD Total Weight IV,MeanRandom,ference05% Cl_Year IV,‘MeanRandom,Diterence95% CL<br>smithAtliaum “92“64 66375 15381 1605 44757 15778 106%79% -570E7.77,-363]-480/6.06,-254) 19992001 ————== —-—<br>SanchezReyes -41 1045-44-14 10,78 42.32% -2704719,1.79) 2004<br>Caterson “418 478 4905-197 443 4907 132% -2314249,-213] 2012 :<br>Subtotal (95% 5183 5174 349% -3.931-5.94,-192] —=<br>Heterogencit, Tau?= 3.16; Cht= 24.63, f= 3 P « 0.0001), F= 88%<br>Testfor overall ofect Z= 3.83 (P= 0.0001)<br>Menaty4.12 Dose 15 moldia “54 495 68 02 4 84 87% -520f673,-367) 2003 =—-—<br>Kaukua “1 1026 111-26 1020 121 63% -4504714,-189) 2008 =§———<br>Hauner “a1 77 174 81 GF 174 97% -300452,-1.49] 2004 _-—<br>‘Subtotal (95% Cl) 353, 359 25.7% -4.18[-5.68, -2.69) _><br>Heterogeneity, Tau?= 0.88; Ch*= 408, df= 2 (P= 013), P= 51%<br>Testfor overall fact Z= 549 (P« 0.00001)<br>Testtoretfahona)Metahon®)SubtotalHeterogeneity4.133 Dose (95%overall20mgldia eectCt)Taut=0.00,Z= 9554445Chi¥= (P<5145 0.0000)008,27142145df=1 (P=-0405 081)3838P= 0%141°6872 107%111%21.8% -4.01[-4.83,-3.19]-3905519,-267)-410(521,-799) 20002002 =—><br>1.14 Doses varadas (10.15.20)<br>James “89 81 360 -49 69 114 10.2% -4005536,-262) 2000 —<br>Matnus-ViegenSubtotalHeterogeneity (95% ChTaut=0.73,Chit=107751.82,audf=94 85 81 20995 17.6%74% -352[5.03,"1.61]-220 (443,003) 2005 cod<br>Testfor 1 (P= 0.16), P= 45%<br>Total (95%overallCD) eect Z= 3.81 (P=0.0001)6267 5883 100.0% -3.87[-4.78, 2.96] ><br>Heterogeneity. Taut= 1.63; Chit= 58.21, df= 10 ( « 0.00001) F= 83% +— tt<br>Testior overall fect 2= 8.31 ( <0.00001) favor da Sibutiamina aver do placebo<br>Testfor suboroup diferences: Ch= 063, df= 3 (P= 0.80), P= 0% Atovorda Shuaming favordo place<br><!-- End of picture text -->  
307  
#### Certeza da Evidência  
<!-- Start of picture text -->
Qual é a Certeza global na evidência?<br>JULGAMENTO  EVIDÊNCIAS DE PESQUISA  CONSIDERAÇÕES ADICIONAIS<br>● Muito baixa  A qualidade geral da evidência foi muito baixa.<br>○ Baixa<br>○ Moderada<br>○ Alta<br>○ Sem estudos incluídos<br>Certainty of the evidence<br>Desfechos  Importância<br>(GRADE)<br>Perda de peso em Kg  CRÍTICO  ⨁◯◯◯<br>MUITO BAIXA a,b<br>a. ALTO RISCO OU RISCO INCERTO DE VIÉS PELA FERRAMENTA DE VIÉS DA<br>COCHRANE<br>b. ALTA HETEROGENEIDADE PELO TESTE DE I QUADRADO<br>Valores<br>Existe incerteza importante ou variabilidade dobre o quanto as pessoas valoram os desfechos principais?<br>JULGAMENTO  EVIDÊNCIAS DE PESQUISA  CONSIDERAÇÕES ADICIONAIS<br>○ Incerteza ou variabilidade  · A sibutramina é um medicamento oral de fácil administração;<br>importante<br>○ Possivelmente incerteza ou  . Medicamentos são valorizados como opção em associação a outras que exigem certa adesão intensa e<br>variabilidade importante  readequação de hábitos (dieta, exercício físico, terapia etc)<br>● Provavelmente sem incerteza ou<br>. Nenhum medicamento disponível no SUS para a perda de peso em pacientes obesos.<br>variabilidade importante<br>○ Sem incerteza ou variabilidade  . Como base na baixa evidência e perfil de eventos adversos é incerto o quanto de valor é atribuído à tecnologia<br>importante  pelos usuários<br><!-- End of picture text -->  
308  
#### Balanço dos efeitos  
O balaço entre os efeitos desejáveis e indesejáveis favorece a intervenção ou a comparação?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Favorece a comparação<br>○ Provavelmente favorece a<br>comparação<br>○ Não favorece nem a interveção<br>nem a comparação<br>● Provavelmente favorece a<br>intervenção<br>○ Favorece a intervenção<br>○ Varia<br>○ Incerto|Conforme observado em efeitos desejáveis e indesejáveis:<br>· Maior redução de peso nos participantes em uso da sibutramina em relação ao placebo;<br>· Em relação aos desfechos redução de IMC, a sibutramina também foi mais eficaz quando comparada ao placebo.<br>· Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, dois estudos relataram superioridade<br>da sibutramina em relação ao seu comparador (placebo, orlistate, nenhum medicamento).<br>. Um ECR e uma RS mostraram superioridade da sibutramina em relação ao orlistate para a perda de peso e<br>redução de IMC.||
||· A sibutramina apresenta maior número de eventos adversos quando comparada ao controle;<br>. Apesar de a perda de peso contínua ter sido significante do ponto de vista estatístico, ela, provavelmente, não é<br>significante do ponto de vista clínico.||
||. Considerando mesmo os 10% de perda do peso inicial, existe bastante dúvida quanto a relevância dessa medida<br>pois, em alguns casos, o indivíduo permance obeso e predisposto à comorbidades cardiovasculares, metabólicas e<br>danos ósseos.<br>.Para o desfecho de redução do perímetro da cintura, avaliado por seis ECR, um dos estudos não encontrou<br>diferença estatisticamente significante entre a sibutramina e o controle||  
309  
#### Recursos necessários  
Quão grandes são os recursos necessários (custos)?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|● Custos altos<br>○ Custos moderados|Avaliação impacto orçamentário -**Valor base: média de preços pagos em compras federais no ano anterior – para**<br>**posologia de 10 mg, valor anual de R$ 505,9440 e para a posologia de 15 mg, valor anual de R$ 738,00**||
|○ Custos e economia<br>negligenciáveis<br>○ Economia moderada|Dois cenários, um no qual todos os pacientes usariam a posologia de 10 mg e o outro com todos os pacientes com<br>posologia de 15 mg.||
|○ Economia grande<br>○ Varia|_Market share_: 30% / 35% / 40% /45%/ 50% (ano 1 ao ano 5)||
|○ Incerto|||
||· Ano 1 – De R$ 3,9 a 5,7 bilhões||
||5 anos: De R$ 26,7 a R$ 39 bilhões||  
#### Custo-Efetividade  
A custo-efetividade favorece a intervenção ou a comparação?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Favorece a comparação<br>● Provavelmente favorece a|· Eficácia da sibutramina na proporção de pacientes que alcançam a perda de peso significante (> 10% do peso<br>corpóreo) é de 0,24, enquanto a do tratamento convencional é de 0,07.||
|comparação<br>○ Não favorece nem a comparação<br>e nem a intervenção|· Custo do tratamento mensal (considerando apenas a tecnologia) por paciente com sibutramina (SIASG): R$ 621,97;||
|○ Provavelmente favorece a<br>intervenção<br>○ Favorecea intervenção|· Custo do tratamento mensal por paciente com tratamento convencional (considerando apenas a ausência de<br>intervenção) (SIGTAP): R$ 0,00;||
|○ Varia<br>○ Sem estudos incluídos|Análise de custo-efetividade: custo incremental de R$ 3.658,65/paciente-ano com a utilização da sibutramina.||  
310  
#### Equidade  
Qual seria o impacto na equidade em saúde?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Reduzida<br>○ Provavelmente reduzida<br>○ Provavelmente sem impacto<br>○ Provavelmente melhorada<br>○ Melhorada<br>○ Varia<br>● Incerto|· Sibutramina está aprovada em bula para tratamento da obesidade;<br>· Provavelmente, população com melhores condições financeiras já têm acesso ao tratamento;<br>. Medicamento que leva risco para populações com doença cardiovascular e diabetes, enquanto que nenhuma<br>outra alternativa farmacológica atualmente é disponibilizada para esse subgrupo com comorbidades.<br>. Nenhum medicamento disponível no SUS para a perda de peso em pacientes obesos.<br>. Custo oportunidade: A inclusão da sibutraina pode gerar o desivenstimento em outras áreas essencias, devido ao<br>grande impacto orçamentário||
|Aceitabilidade<br>A intervenção é aceitavel paraos pr<br>JULGAMENTO|incipais atores sociais (_stakeholders_)?<br>EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>● Provavelmente não<br>○ Provavelmente sim<br>○ Sim<br>○ Varia<br>○ Incerto|Atualmente o SUS não disponibiliza nenhum medicamento para a perda de peso, assim pressupõe-se que o<br>medicamento seja bem aceito por prescritores e usuários.<br>Diante de uma baixa qualidade de evidência, questionável significância clínica produzida pela tecnologia e alto<br>custo agregado, essa é uma tecnologia pouco atrativa ao gestor em saúde.||
|Viabilidade<br>A intervenção é viável de se imple|mentar?||
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>● Provavelmente não<br>○ Provavelmente sim<br>○ Sim|. O medicamento é facilmente disponível em farmácias, por ser de administração oral, assim pode ser entregue<br>diretamente ao paciente para autoadministração, mediante prescrição médica.<br>. Não existem questões mais complexas quanto ao armazenamento||
|○ Varia<br>○ Incerto|. Baixa qualidade da evidência, o que dificulta uma recomendação confiável;||  
311  
. O alto custo inviabiliza a incorporação e essa foi a questão primordial para esse julgamento. . A prescrição é realizada por receituário B2, seguindo a Portaria 344da ANVISA o que agrega certa burocracia.

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
||||**J**|**ULGAMENTO**||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**||Varia|Incerto|
|**EFEITOS DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande||Varia|Incerto|
|**EFEITOS INDESEJÁVEIS**|Grande|**Moderado**|Pequeno|Trivial||Varia|Incerto|
|**CERTEZA DA EVIDÊNCIA**|**Muito baixa**|Baixa|Moderada|Alta|||Sem estudos<br>incluídos|
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente<br>incerteza ou<br>variabilidade<br>importante|**Provavelmente sem**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS EFEITOS**|Favorece a<br>comparação|Provavelmente<br>favorece a comparação|Não favorece nem a<br>intervenção e nem a<br>comparação|**Provavelmente**<br>**favorece a intervenção**|Favorece a<br>intervenção|Varia|Incerto|
|**RECURSOS NECESSÁRIOS**|**Custos altos**|Custos moderados|Custos e economia<br>negligenciáveis|Economia moderada|Grande economia|Varia|Incerto|
|**CUSTO-EFETIVIDADE**|Favorece a<br>comparação|**Provavelmente**<br>**favorece a**<br>**comparação**|Não favorece um ou<br>outro|Provavelmente<br>favorece a intervenção|Favorece a<br>intervenção|Varia|Sem estudos<br>incluídos|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|Provavelmente sem<br>impacto|Provavelmente<br>aumentada|Aumentada|Varia|**Incerto**|
|**ACEITABILIDADE**|Não|**Provavelmente não**|Provavelmente sim|Sim||Varia|Incerto|
|**VIABILIDADE**|Não|**Provavelmente não**|Provavelmente sim|Sim||Varia|Incerto|  
312

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
|Recomendação forte contraa|**Recomendação condicional contra a**|Não favorece uma ou outra|Recomendação condicional a favor da|Recomendação forte a favor da|
|---|---|---|---|---|
|intervenção|**intervenção**||intervenção|intervenção|
|○|**●**|○|○|○|

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 11 - PERGUNTA PICO 10** -->
#### Recommendação  
A evidência analisada mostrou baixa efetividade. Diante alta prevalência da condição na população, o impacto orçamentário não se mostra viável. Dessa forma, com base nos dados de efetividade, segurança e custo disponíveis, a recomendação é contra a utilização de sibutramina. As evidências sugerem que o tratamento com sibutramina promove a redução do peso. No entanto, fatores como a qualidade metodológica baixa dos estudos, tendência de reganho de peso ao longo do tempo e de publicação de resultados positivos, um número considerável de eventos adversos e uma persistência de uso que ainda gera dúvidas, agregam incertezas quanto ao benefício atribuído à sibutramina. Embora disponível no Brasil, a sibutramina não possui mais autorização para comercialização em muitos países  
313

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 12 - PERGUNTA PICO 11** -->
###### **Questão de pesquisa: “Qual a eficácia e segurança do orlistate na perda de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era o Orlistate (C) placebo, sibutramina ou intervenções não-farmacológicas; e desfechos (O) perda de peso, redução do perímetro da cintura, redução do IMC, eventos adversos.  
###### `o` **Estratégia de busca**  
**Quadro O1.** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed**|(((self-weighing OR self weighing OR self-monitoring OR self<br>monitoring OR weight monitoring)) AND ("Weight Loss"[Mesh] OR<br>weight loss OR weight reduction)) AND ("Obesity"[Mesh] OR<br>"Overweight"[Mesh] OR obesity OR overweight)<br>Data da busca: 08/10/2018|1.292|
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim AND ('body weight loss'/exp OR<br>'body weight loss' OR 'weight loss'/exp OR 'weight loss' OR 'weight<br>reduction'/exp OR 'weight reduction') AND [embase]/lim AND<br>('self weighing'/exp OR 'self weighing' OR 'self monitoring'/exp OR<br>'self monitoring' OR 'weight monitoring') AND [embase]/lim<br>Data da busca: 08/10/2018|603|  
###### `o` **Seleção das evidências**  
A busca das evidências resultou em 1895 referências (1.292 no MEDLINE e 603 no EMBASE). Destas, 237 foram excluídas por estarem duplicadas. Um total de 1.658 referências foram triadas por meio da leitura de título e resumos, das quais 45 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados estudos do tipo revisões sistemáticas (RS) de ensaios clínicos randomizados (ECR) com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados com quaisquer tamanhos de população e tempo de duração, comparando orlistate a placebo, sibutramina ou a medidas não-farmacológicas, em população obesa ou com sobrepeso. Em estudos nos quais os participantes foram selecionados com base em outros fatores de risco, como por exemplo, hipertensão, glicemia de jejum alterada, etc.,  
314  
sem critérios de elegibilidade relacionados ao peso e o foco da intervenção foi claramente a perda de peso, foi verificado o IMC da linha de base para se avaliar a inclusão. Estudos que não apresentavam foco primário na redução de peso foram incluídos desde que apresentassem dados secundários para este desfecho. Foram incluídos estudos com intervenções combinadas ou acumuladas ao uso do orlistate, desde que as mesmas estivessem em ambos os braços da comparação, de modo que existisse a possibilidade de se extrair dados da intervenção com orlistate separadamente. O mesmo foi feito com períodos de _lead-in_<sup>2</sup> _._ Com relação a estudos observacionais apenas coortes estavam nos critérios de inclusão. Foram considerados como desfechos primários de eficácia e efetividade a redução do peso, redução do Índice de Massa Corporal (IMC) e redução da circunferência abdominal.  
Nessa etapa, 87 estudos foram excluídos: Vinte e quatro por, inicialmente, apresentarem apenas resultados do orlistate em combinação com outra intervenção sistematizada, de maneira que os dados não se mostraram extraíveis de maneira separada<sup>417–440</sup> . Seis artigos foram excluídos por estarem em outros idiomas, sendo um em árabe<sup>441</sup> , um em húngaro<sup>442</sup> , um em italiano<sup>443</sup> , um em chinês<sup>444</sup> , um em sérvio<sup>445</sup> e um em russo<sup>446</sup> . Quatro artigos foram excluídos por avaliarem apenas manutenção de peso perdido anteriormente, sem a princípio apresentar dados de emagrecimento<sup>442,447–449</sup> . Cinco estudos foram excluídos por apresentarem análises apenas com comparadores não considerados nos critérios de inclusão<sup>450–454</sup> . Um estudo foi excluído pelo desenho do estudo (notificações pós-comercialização)<sup>455</sup> . Uma revisão sistemática foi excluída por já ter sua atualização incluída no estudo<sup>456</sup> e uma por ter incluído apenas um estudo de interesse<sup>457</sup> de forma que o estudo foi incluído de maneira isolada<sup>458</sup> . Foram excluídas sete revisões por não apresentarem meta-análise ou não serem revisões sistemáticas, mesmo que apresentassem meta-análise<sup>459–465</sup> . Foram excluídos dez estudos por não apresentarem inicialmente dados quantitativos dos desfechos de interesse<sup>466–475</sup> . Um estudo foi excluído por apresentar população em peso normal em sua análise<sup>476</sup> e cinco textos completos não estavam disponíveis<sup>410,477–480</sup> . Além disso foram excluídos dezenove estudos por se tratarem de tipos de publicação que não eram de interesse tais como pôsteres, resumos e apresentações de congressos científicos e carta ao editor<sup>481–499</sup> . O estudo de Gotfredsen e colaboradores (2001) 500 foi excluído por ser uma subanálise do estudo de Sjostrom e colaboradores (1998) 501. O estudo de James e colaboradores (1997)<sup>502</sup> foi excluído por ser um relato prévio de um único centro de estudo multicêntrico publicado posteriormente<sup>503</sup> . Já o  
> 2 Período de uso inicial da droga, antes do começo do ensaio clínico randomizado, para avaliar tolerabilidade, abandono e adesão. Pode ser chamado de _run-in._  
315  
estudo de Derosa e colaboradores 2010<sup>504</sup> foi excluído por ser um relato menos complexo, com publicação posterior dos mesmos dados em 2012<sup>505</sup> , apresentando relato com mais análises e os dados do primeiro estudo no estudo posterior.  
Por fim, foram excluídos 33 estudos que já estavam contemplados em revisões sistemáticas incluídas<sup>424,436,501,503,506–534</sup> .  
Ao final, foram incluídas 15 revisões sistemáticas conforme segue:  
Aldekhail e colaboradores (2015)<sup>535</sup> , Gray e colaboradores (2012)<sup>404</sup> , Horvath e  colaboradores (2008)<sup>536</sup> , duas de Khera e colaboradores (2016, 2018)<sup>537,538</sup> , LeBlanc e colaboradores (2018) 539, Neovius e colaboradores (2008) 540, duas de O’Meara e colaboradores (2001, 2004) 541,542, Osei-Assibey  e  colaboradores  (2011)<sup>543</sup> ,   Padwal  e   colaboradores  (2003)<sup>544</sup> ,   Sahebkar e colaboradores (2017)<sup>545</sup> , Siebenhofer e colaboradores (2016)<sup>546</sup> , Wang e colaboradores (2018) 457, Zhou e colaboradores (2012)547, e Hutton & Fergusson (2014) 548.  
Ademais, foram incluídos mais 6 estudos que apresentavam resultados de desfechos de interesse e não estavam contemplados nas revisões selecionadas<sup>458,505,549–552</sup> . O processo de seleção dos estudos encontra-se na **Figura L1** .  
###### `o` **Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela L1.** A caracterização dos participantes de cada estudo primário incluído pode ser vista na **Tabela M1.** Resultados de eficácia encontram-se na **Tabela N1** e na **Figura M1;** e de segurança, na **Tabela O1.** O risco de viés dos estudos está representado na **Figura N1** . A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista no **Quadro P1** , que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. O **Quadro Q1** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
316  
###### **Figura L1.** Fluxograma representativo do processo de seleção da evidência.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.896<br>PUBMED = 1.293<br>EMBASE= 603<br>Publicações após remoção de duplicatas: 1.659  Publicações excluídas segundo<br>critérios de exclusão: 1.614<br>Publicações excluídas segundo<br>critérios de exclusão: 37<br>Publicações selecionadas para leitura completa:<br>45  Tipo de delineamento: 05<br>Tipo de publicação: 04<br>Tipo de desfecho: 23<br>Tipo de participantes: 05<br>Estudos incluídos: 08 estudos<br>Revisão Sistemática: 02<br>ECR: 04<br>Quase-experimental: 01<br>Coorte: 01<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
317  
**Tabela L1** . Características dos estudos incluídos.  
|**Autor (Ano)**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Intervenção**<br>**(de**|**Controle (de**<br>**interesse)**|**Aconselhamento**|
|---|---|---|---|---|---|---|
|||||**interesse)**|||
||||**Ensaios Clínicos Randomizados**||||
|Arzola-Paniagua et<br>al. (2016)|Duplo-cego,<br>paralelo,<br>randomizado<br>monocêntrico|Avaliar a eficácia de uma combinação de<br>orlistate e resveratrol em cápsulas no<br>emagrecimento de pacientes obesos.<br>Apenas dados de intervenção única com<br>o orlistate foram avaliados.|O estudo recrutou paciente homens e<br>mulheres mexicanas, entre 20 e 60<br>anos com IMC maior que 30 e menor<br>ou igual a 39,9, sem comorbidades<br>|Orlistate 120<br>mg TID|Placebo TID  Die|ta défice de 500 kcal dia e 25-35% gordura.|
||Duplo-cego,|Avaliar a eficácia de orlistate no|Homens e mulheres caucasianos com||||
|Derosa et al. (2012)|paralelo,<br>randomizado<br>multicêntrico|emagrecimento e controle da doença de<br>base em pacientes diabéticos<br>descontrolados não complicados.|diabetes mellitus tipo 2<br>descontrolado (HB1Ac > 8,0%), idade<br>igual ou superior a 18 anos, IMC igual<br>ou superior a 30kg/m<sup>2</sup>|Orlistate 120<br>mg TID|Placebo TID|Dieta défice de 600 kcal dia e 30% gordura.<br>Incentivo a exercícios físicos.|
||Duplo-cego,|Avaliar a eficácia de orlistate no|Homens e mulheres com idade de 18||||
|Golay et al. (2005)|paralelo,<br>randomizado<br>multicêntrico|emagrecimento e controle da doença de<br>base em pacientes com transtorno de<br>compulsão alimentar.|a 65 anos, IMC maior ou igual a<br>30kg/m<sup>2</sup>|Orlistate 120<br>mg TID|Placebo TID|Dieta défice de 600 kcal dia e 30% gordura.|
|Jain et al. (2011)|Simples-cego,<br>paralelo,<br>randomizado<br>monocêntrico|Avaliar a eficácia de orlistate no<br>emagrecimento de pacientes obesos.|Homens e mulheres com IMC maior<br>ou igual a 30 Kg/m<sup>2</sup>, com idade entre<br>18 e 60 anos|Orlistate 120<br>mg TID|Placebo TID<sup>A</sup>|<sup>conselhamento acerca de valor nutricional dos</sup><br>alimentos.|
||Duplo-cego,<br>paralelo,|Avaliar a eficácia de orlistate no<br>emagrecimento e controle da doença de|Estar em idade reprodutiva<br>(considerada de 19 a 38 anos neste|Orlistate 120||As pacientes tiveram prescrição de dieta<br>hipocalórica individualizada, com 30% das|
|Moini et al., (2014)|randomizado<br>monocêntrico|base em pacientes portadoras síndrome<br>do ovário policístico.|estudo) e apresentarem IMC maior ou<br>igual a 25Kg/m<sup>2</sup>|mg TID|Placebo TID<sup>c</sup>|<sup>alorias advindas de gordura e ingestão diária de</sup><br>1200 a 1800 Kcal, além de estímulo para a<br>prática de exercícios físicos.|
||Duplo-cego,|Avaliar a eficácia e a segurança de|Incluídos pacientes com IMC maior ou|||As pacientes tiveram prescrição de dieta|
|Trujillo et al. (2010)|paralelo,<br>randomizado<br>monocêntrico|orlistate no emagrecimento de pacientes<br>obesos.|igual a 25 e menor ou igual a 34,9<br>kg/m<sup>2</sup>, com idade de 18 a 60 anos|Orlistate 60<br>mg TID|Placebo TID|hipocalórica individualizada, com 30% das<br>calorias advindas de gordura e estímulo à<br>prática de atividade física.|  
318  
Revisões Sistemáticas  
319  
|**Autor (Ano)**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Intervenção**<br>**(de**<br>**interesse)**|**Controle (de**<br>**interesse)**|**Aconselhamento**|
|---|---|---|---|---|---|---|
|Le Blanc et al.<br>(2018)||Conduzir revisão sistemática sobre<br>benefícios e danos de intervenções<br>farmacológica e comportamental para<br>perda ou manutenção de perda de peso<br>em adultos e fornecer informação à<br>força-tarefa de serviços de prevenção dos<br>EUA.|Indivíduos adultos (≥ 18 anos)<br>candidatos a intervenções para perda<br>ou manutenção de perda peso,<br>selecionados conforme IMC (≥ 25<br>kg/m²) ou outra medida<br>antropométrica, como circunferência<br>abdominal.|Orlistate 120<br>mg TID|Placebo TID|Para estudos de intervenções comportamentais,<br>os controles não deveriam receber intervenções<br>comportamentais, ter intervenção mínima<br>(cuidados usuais ou panfletos informativos) ou<br>serem controles de atenção (formato e<br>intensidade semelhantes, mas com conteúdo<br>diferente)|
|Khera et al. (2016)||Avaliar a eficácia e segurança de orlistate,<br>lorcaserina, naltrexona-bupropiona,<br>fentermina-topiramato e liraglutida no<br>emagrecimento de pacientes obesos ou<br>com sobrepeso. Apenas a intervenção<br>única com orlistate foi avaliada.|População obesa ou com sobrepeso<br>(IMC maior ou igual a 27 kg/m<sup>2</sup>).|Orlistate 120<br>mg TID|Placebo TID|Foram excluídos os estudos com qualquer tipo<br>de aconselhamento nas análises de<br>sensibilidade, mas a direção dos desfechos não<br>foi alterada.|
|||Avaliar a eficácia de orlistate, sibutramina<br>ou rimonabanto no emagrecimento de|Pacientes com sobrepeso e obesos<br>e/ou com risco cardíaco grave, que|Orlistate 120||Foram incluídos estudos com quaisquer tipos de|
|Gray et al. (2012)||pacientes obesos, com sobrepeso e/ou<br>com alto risco cardíaco. Apenas dados<br>acerca do orlistate foram avaliados.|não tenham comorbidades<br>relacionadas a doenças mentais|mg TID|Placebo|aconselhamento, os quais foram divididos entre<br>padrão e intensivo nas análises de sensibilidade|
|Sahebkar et al.<br>(2017)||Avaliar o efeito do orlistate no peso<br>corporal e nas concentrações de lipídios<br>séricos.|Pacientes com sobrepeso ou obesos<br>ou com alto riso cardiovascular|Orlistate 120<br>mg TID ou<br>Orlistate 60<br>mg TID ou<br>Orlistate 30<br>mg TID ou<br>Orlistate 30<br>mg MID|Placebo ou<br>Ezetimiba ou<br>Sibutramina<br>ou<br>Fenofibrato|-|
|Siebenhofer et al.||Avaliar efeitos de longo prazo (mínimo de<br>24 semanas de seguimento) em|Pacientes hipertensos em programas|Orlistate 120||Foram incluídos estudos com quaisquer tipos de|
|(2016)||morbidade, mortalidade e segurança no<br>processo de redução de peso auxiliada<br>por intervenções farmacológicas, em|de emagrecimento que utilizem<br>intervenções farmacológicas|mg TID|Placebo|aconselhamento|  
320  
321  
|**Autor (Ano)**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Intervenção**<br>**(de**<br>**interesse)**|**Controle (de**<br>**interesse)**|**Aconselhamento**|
|---|---|---|---|---|---|---|
|||pacientes com hipertensão arterial<br>sistêmica.|||||  
**Legenda:** ECR: ensaio clínico randomizado; HB1Ac: Hemoglobina Glicada; IMC: índice de massa corpórea; RS: revisão sistemática; TID: três vezes ao dia.  
###### **Tabela M1** . Características dos participantes dos ECR incluídos.  
|**Autor (ano)**|**Intervenção**|**Controle**|**N intervenção**|**N controle**|**Idade intervenção média (DP)**|**Idade controle média (DP)**|**N (%) sexo feminino**<br>**(intervenção/ controle)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|
|Arzola-Paniagua et al.<br>(2016)|Orlistate 120 mg TID,<br>resveratrol 100 mg TID*, orlistate 120 mg +<br>resveratrol 100 mgTID*|Placebo|21 (40 ITT)<br>15 (40 ITT)<br>24(41 ITT)|24 (40 ITT)|39,8 (8,91)<br>33,8 (11,9)<br>41,0(10,0)|38,9 (9,59)|76,2 (orlistate)/<br>87,5 (placebo)|24 semanas|
|Derosa et al. (2012)|Orlistate 120 mg TID|Placebo|113|121|53 (6)|52 (5)|49,5/49,6|12 meses|
|Golay et al. (2005)|Orlistate 120 mg TID|Placebo|44 (ITT)|45 (ITT)|41,2 (6,2)|40,6 (6,1)|91/91|24 semanas|
|Jain et al. (2011)|Orlistate 120 mg TID|Placebo|40|40|-|-|-|24 semanas|
|Moini et al. (2014)|Orlistate 120 mg TID|Placebo|43|43|26,80 (5,16)|27,42 (3,31)|100/100|3 meses|
|Trujillo et al. (2010)|Orlistate 60 mg TID|Placebo|105 (119 ITT)|95 (121 ITT)|33 (12) Feminino<br>32 (10) Masculino|31 (12) Feminino<br>29 (10) Masculino|71,4/80,2|3 meses|  
*Essas comparações não foram consideradas no presente relatório  
**Legenda:** ITT: _intention-to treat analysis_ – análise por intenção de tratar _;_ TID: três vezes ao dia.  
322  
###### **Tabela N1** . Desfechos primários de eficácia.  
|**Autor (ano)**|**Desenho do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**±**V**<br>DP ou EP|**alor de p**|**Desfecho do Peso**<br>± DP ou EP<br>dicotômica|**Valor de p**|**Desfecho do perímetro da cintura**<br>± DP ou EP|<br>**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|**Arzola-Paniagua et**<br>**al. (2016)**|ECR|Orlistate 120 mg<br>TID|Placebo TID|**Análise ITT (24 semanas):**<br>Δ = -1,9±1,6 kg/m<sup>2</sup><br>(orlistate)<br>Δ = -0,9±1,4 kg/m<sup>2</sup><br>(placebo)|0,001|**Análise ITT (24 semanas):**<br>Δ = -4,9±4,0 kg (orlistate)<br>Δ = -2,5±3,7 (placebo)<br>**Análise por-protocolo (24**<br>**semanas):**<br>Δ = -6,0±1,7 kg (orlistate)<br>Δ = -3,5±1,5 kg (placebo)|0,001<br>0,001|**Análise ITT (24 semanas):**<br>Δ = -3,1±3,6cm (orlistate)<br>Δ = -2,1±3,1 cm<br>(placebo)|0,001|
|**Derosa et al. (2012)**|ECR|Orlistate 120 mg<br>TID|Placebo TID|29,8 ± 1,2 kg/m<sup>2</sup>(orlistate)<br>31,6 ± 1,8 kg/m<sup>2</sup>(placebo)|< 0,05|85,1 ± 5,9kg (orlistate)<br>89,1 ± 7,8 kg(placebo)|< 0,05|95,0 ± 3,0 cm (orlistate)<br>99,0 ± 4,0 cm(placebo)|< 0,05|
|**Golay et al. (2005)**|ECR|Orlistate 120 mg<br>TID|Placebo TID|NR<br>|NR|MMQ<br>Δ = -7,4% orlistate<br>Δ = -2,3% placebo|0,005 (para<br>a diferença<br>das MMQ)|MMQ<br>96,5±1,8cm<br>(orlistate) 101,0±1,5 cm (placebo)|<br>0,005 (para<br>a diferença<br>das MMQ)|
|**Jain et al. (2011)**|ECR|Orlistate 120 mg<br>TID|Placebo TID|32,1 ± 3,2 kg/m<sup>2</sup>(orlistate)<br>33,6 ± 4,1 kg/m<sup>2</sup>(placebo)|< 0,05|89,0 ± 7,4 kg (orlistate)<br>92,0 ± 6,4 kg(placebo)|< 0,05|91,2 ± 6,6 cm (orlistate)<br>94,3 ± 8,7 cm(placebo)|< 0,05|
|**Moini et al., (2014)**|ECR|Orlistate 120 mg<br>TID|Placebo TID|27,2 ± 1,9 kg/m<sup>2</sup>(orlistate)<br>28,6 ± 1,9 kg/m<sup>2</sup>(placebo)|< 0,05|76,2 ± 4,3 kg (orlistate)<br>79,1 ± 4,5 kg(placebo)|< 0,01|NR|NR|
|||||**Trujillo et al.**<br>**(2010)**|ECR|Orlistate 60 mg|TID|Placebo TID||  
323  
média ±EP médi a ±EP Δ = -2,5 ± 0,1kg/m<sup>2</sup> NR (orlistate) < 0,05 Δ = - < 0,05 Δ = -1,3 ± 0,1kg/m<sup>2</sup> 6,9 ± NR 0,3 kg (orlist ate) Δ = -3,5 ±0,3 kg (place bo)  
324  
|**Autor (ano)**|**Desenho do**<br>**Estudo**|**Intervenção**|**Controle**|**Desfecho do Índice de**<br>**Massa Corporal (Kg/m2)**±<br>DP ou EP|**Valor de p**|**Desfecho do Peso**<br>± DP ou EP<br>dicotômica|**Valor de p**|**Desfecho do perímetro da cintura**<br>± DP ou EP|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|
|||||(placebo)||Redução de 10% ou mais do peso<br>inicial:<br>Orlistate: 34,3% (36/105)<br>Placebo:<br>8,4% (8/95)||||
||||||||< 0,05|||
|**Le Blanc et al.**<br>**(2018)**|Revisão<br>sistemática|Orlistate 120 mg<br>TID|Placebo|NR|NR|NR|NR|NR|NR|
||||||||< 0,05|||
|**Khera****_et al._2016**|Revisão<br>sistemática|Orlistate 120 mg<br>TID|Placebo|NR|NR|−2,6 (IC 95%: −2,9 a −2,3) kg<br>5% peso:<br>OR = 2,7 (IC 95%: 2,4 a 3,1)<br>10% peso:<br>OR = 2,4 (IC 95%: 2,1 a 2,8)|< 0,05|NR|NR|
||||||||< 0,05|||
|||||||Tempo de seguimento 12 meses||||
|**Gray et al.  (2012)**|<sup>Revisão</sup><br>sistemática|Orlistate 120 mg<br>TID|Placebo|Tempo de seguimento: 12<br>meses<br>Meta-análise direta:<br>-0,98 (-1,35 a -0,61) –<br>Método MTC:<br>-1,43 (-2,67 a -0,18)|<br>< 0,05<br>< 0,05|Meta-análise direta:<br>-2,5 (-2,98 a -2,12)<br>Método MTC:<br>-4,12 (-5,07 a -3,15)<br>**Perda de 5% de peso (RR)**<br>Meta-análise direta:<br>2,81 (2,42 a 3,27)<br>Método MTC:<br>2,89 (2,22 a 3,72)|< 0,05<br><0,05<br>< 0,05|**-**|-|
|||||||**Perda de 10% de peso (RR)**<br>Meta-análise direta:<br>2,30 (1,92 a 2,74)|< 0,05|||  
325  
326  
|||||**Desfecho do Índice de**||**Desfecho do Peso**|**Des**|**fecho do perímetro da ci**|**ntura**|
|---|---|---|---|---|---|---|---|---|---|
|**Autor (ano)**|**Desenho do**<br>**Estudo**|**Intervenção**|**Controle**|**Massa Corporal (Kg/m2**<br>DP ou EP|**)**±**Valor de p**|± DP ou EP<br>dicotômica|**Valor de p**|± DP ou EP|**Valor de p**|
|||||||Método MTC:<br>2,43 (1,72 a 3,39)|< 0,05|||
||||||||< 0,05|||
|**Sahebkar et al.**|Revisão|Orlistate 120 mg<br>TID ou<br>Orlistate 60 mg TID|Placebo ou<br>Ezetimiba ou|||−2.12kg||||
|**(2017)**|sistemática|ou<br>Orlistate 30 mg TID<br>ou|Sibutramina ou<br>Fenofibrato|NR|NR|(IC 95% −2.51 a −1.74) vs placebo|< 0.001|NR|NR|
|||Orlistate 30 mg MID||||||||
|**Siebenhofer et al.**<br>**(2016)**|Revisão<br>sistemática|Orlistate 120 mg<br>TID|Placebo|NR|NR|-3,7kg (IC 95% -4,6 a -2,8)|< 0,0001|NR|NR|  
**Legenda:** DP, desvio-padrão; ECR, ensaio clínico randomizado; EP, Erro-padrão; IMC, índice de massa corpórea; ITT, _intention-to-treat analysis_ – análise por intenção de tratar MMQ, média dos mínimos quadrados; NR, não reportado; OR, _odds ratio_ ; RS, revisão sistemática; TID, três vezes por dia; Δ, Variação.  
327  
**Tabela O1.** Desfechos de segurança do orlistate.  
|**Autor (ano)**|**Desenho do Estudo**|**Intervenção**|**Controle**|**Resultados de segurança**|
|---|---|---|---|---|
|**Arzola-Paniagua et al. (2016)**|ECR|Orlistate 120 mg TID|Placebo TID|Eventos adversos: 1 no grupo orlistate (esteatorreia), 3 no grupo placebo (2 diarreia, 1<br>constipação intestinal).|
|**Derosa et al. (2012)**|ECR|Orlistate 120 mg TID|Placebo TID|Perda de seguimento por evento adverso: 13 no grupo orlistate (3 flatulência, 2<br>constipação, 2 dor abdominal, 3 fezes oleosas, 1 evacuação frequente, 1 urgência fecal,<br>1 mal estar), 5 no grupo placebo (1 flatulência, 1 insônia, 1 fezes oleosas, 1 evacuação<br>frequente, mal estar).|
|**Golay et al. (2005)**|ECR|Orlistate 120 mg TID|Placebo TID|Perda de seguimento por evento adverso: 4 no grupo controle.|
|**Jain et al. (2011)**|ECR|Orlistate 120 mg TID|Placebo TID|fezes moles (28,5%), fezes oleosas/manchas oleosas (25,65%), dor abdominal (31,35%)<br>e urgência fecal (34,2%).<br>Eventos adversos observados em ambos os grupos: náusea, vômito, dispepsia.<br>Eventos adversos que acometeram de forma significativa (p < 0,05) o grupo orlistate*:|
|**Moini et al., (2014)**|ECR|Orlistate 120 mg TID|Placebo TID|Eventos adversos no grupo orlistate: necessidade urgente de ir ao banheiro (54%),<br>manchas oleosas em roupas íntimas (30%), fezes oleosas ou gordurosas (22%) e dores<br>de cabeça (3%).<br>Eventos adversos no grupo placebo: total de 13 pacientes (2 cefaleia, 4 tontura, 7 com<br>diarreia ou constipação).|
|**Trujillo et al. (2010)**|ECR|Orlistate 60 mg TID|Placebo TID|Número de eventos adversos no grupo orlistate (total de 82): 22 esteatorreia, 21<br>diarreia, 11 corrimento gorduroso retal, 8 meteorismo, 3 constipação, 2 vômito, 2<br>aumento da necessidade de defecar, 2 incontinência fecal, 1 flatulência, 1 fatiga, 1 dor<br>hipocólica, 1 cólica, 1 cefaleia, 1 borborigmo, 1 pujo, 1 flatulência com incontinência<br>fecal, 1 irregularidade do ciclo menstrual, 1 náusea, 1 dismenorreia, 0 dispepsia, 0<br>tenesmo, 0 pirose, 0 hipertrigliceridemia, 0 dor epigástrica.<br>Número de eventos adversos no grupo placebo (total de 28): 0 esteatorreia, 8 diarreia,<br>0 corrimento gorduroso retal, 3 meteorismo, 2 constipação, 1 vômito, 0 aumento da<br>necessidade de defecar, 0 incontinência fecal, 0 flatulência, 0 fatiga, 0 dor hipocólica, 1<br>cólica, 1 cefaleia, 1 borborigmo, 0 tenesmo, 0 flatulência com incontinência fecal, 0|  
328  
|**Autor (ano)**|**Desenho do Estudo**|**Intervenção**|**Controle**|**Resultados de segurança**|
|---|---|---|---|---|
|||||irregularidade do ciclo menstrual, 0 náusea, 0 dismenorreia, 7 dispepsia, 1 tenesmo, 1<br>pirose, 1 hipertrigliceridemia, 1 dor epigástrica.|
|**Khera****_et al._2016**|Revisão sistemática|Orlistate 120 mg TID|Placebo|Abandono por evento adverso: OR 1,84 (IC 95%: 1,55 a 2,18)|
|**Le Blanc (2018)**|Revisão sistemática|Orlistate|Placebo|Menção textual (sem informações de sumarização quantitativa).|
|**Siebenhofer et al. (2016)**|Revisão sistemática|Orlistate 120 mg TID|Placebo|Menção textual (sem informações de sumarização quantitativa).|  
**Legenda:** ECR – ensaio clínico randomizado; IC – Intervalo de Confiança; OR - _odds ratio_ , TID – três vezes ao dia; *não especificado se tais proporções se referem ao grupo orlistate ou ao total de indivíduos do estudo.  
329  
**Figura M1.** Meta-análise comparativa entre Orlistate e Placebo na redução do peso corporal (atualização da meta-análise de Khera et al., 2016).  
<!-- Start of picture text -->
Study Ontistate Controle Mean Difference Mean Difference<br>1.1.1 Menosor Subgroupde 12 meses__Mean [kg] _SD [kg] Total Mean [kg] SD [kg] Total Weight _1V, Random,95% Cl [kg] IV, Random,95% Cl {kg}<br>arzola-Paniagua 2016 -4.86 4 40-248 368 40-35% «© -2.40-4.08,-0.72] ——<br>Jain 2011 8901 739 40 ©9204 «6.38 401.2% «= -3.03 8.06, 0.00)<br>Moin! 2014 7625 43 43 7918 «451 43-29% «© -2.90-4.76,-1.04) =<br>Subtotal (95% Cl) 123 123 7.6% -2.68 [-3.84, 1.53] ><br>Heterogeneity: Taut= 0.00; Ch'= 0.21, df= 2 (P= 0.90); P= 0%<br>Test<br>for overall effect Z= 4:56 (P < 0.00001)<br>1.1.2 Mais de 12 meses<br>Astrup 2012 “39 36897 67 “238897 67 59% 1.90 F3.15,-0.68) —<br>Baktis 2002 54 6.4136 267 “27 64198 285 74% — -2703.79,-1.61] —<br>Broom 2002b 58 7.5245 265 -23 75245 266 57% © -3.60 [4.78,-2.22] =<br>Davidson 1999 88 9875 687 58 9875 223 43% — -300[-4.50,-1.50) —<br>Derosa 2012 81 69 113 89178 121 32% «© -4.00F5.76,-2.24) —<br>Finer 2000, “329 85498 110 © -1.31 85498 108 20% “1.98 4.25, 0.28)<br>Hanefeld 2002 “63 61929 189 “34 61929 180 77% 1.90 F2.96,-0.84) =—_<br>Hauptman 2000 “794 8.2276 210 © -414 8.2276 212 40% © -380[8.37,-2.23] —_—<br>Hollander 1998 -62 6.8099 162 -43 68099 189 44% © -1.903.39,-0.41] —_—<br>Kelley 2002 “389 4.4844 286 © -1.27 4.4844 269 126% — -2623.38,-1.86] nal<br>Krempf 2003 63 9.3648 348 “36 9.3548 360 49% — -270(-4.09,-1.31] —<br>Lindgarde 2000 568 48914 190 “43 6.1971 188 7.0% © -1.30£2.43,-0.17] —<br>Miles 2002 “47 47534 250 18 47534 254 112% 290 [3.73,-207] =<br>Rossner 2000 “94 6.5321 242 “64 65321 237 66% © -300F4.17,-1.83] —<br>Swinburn 2006 “47 7.9257 170 -09 37693 169 54% © -3.80(5.12,-2.48] —<br>Subtotal (95% Cl) 3504 3066 92.4% -2.68 [-3.06, 2.31] °<br>Heterogeneity: Taut= 0.16; Chi¥= 19.92, df= 14 (P= 0.13), P= 30%<br>Test<br>for overall effect Z= 13.88 (P < 0.00001)<br>Total (95% Cl) 3627 3189 100.0% -2.68 [-3.01, -2.35] a4<br>Heterogeneity: Taut= 0.08; Chi*= 20.14, df= 17 (P= 0.27); P= 16% t+<br>TestTest  forfor subarounoverall effect diferences:Z= 15.81 Ch"=(P < 0.00001)0.00, df=1 (P= 1.00), = 0% Favorece Oristate Favorece Controle<br><!-- End of picture text -->  
**Figura N1.** Sumário do risco de viés: julgamento dos revisores sobre cada item do risco de viés para cada ensaio clínico randomizado incluído individualmente.  
<!-- Start of picture text -->
Ps<br>FI<br>v<br>Zz. @89 §38<br>5232 8 5<br>esgsesges<br>| @ |B] | @ | @| @ | Alocation conceatment setection bias)<br>[| @ | @ | @ | @ | @ | @ | dincins ot partiipants ana personne! (performance bias)<br>| @[@ [© | @ | @ |B) ining or outcome assessment (detection bias)<br>[@[@[@|<br>| @ | @ | @ | ©  [©| @|[@@ ||rcomsceseteetve reporting ouzome ceporingcatatonia bias)<br>OoOogm oie<br><!-- End of picture text -->  
330  
**Tabela P1.** Sumarização dos resultados dos estudos (Summary of Findings (SoF) do _webapp_ Grade PRO).  
||||**Avaliação da c**|**erteza**<br>|||**№ de pa**|**cientes**|**Efeit**<br>|**o**<br>|**Certeza da**<br>**evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Desfechos**|**placebo**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|||
|**Variação P**|**eso (atualização de Khe**|**ra et al. 2016) (se**|**guimento: 12 meses; a**|**valiado com: dife**|**rença média pondera**|**da)**|||||||
|18|ensaios clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|3627|3189|-|MD**2.68**<br>**menor**<br>(3.01 menor<br>para 2.35<br>menor)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|**Perda 5% d**|**o peso inicial (seguime**|**nto: 12 meses; a**|**valiado com: Risco Rel**|**ativo)**|||||||||
|16|ensaios clínicos<br>randomizados|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|3139/5315 (59.1%)|1694/4862 (34.8%)|**RR 1.69**<br>(1.60 para 1.78)|**240 mais por**<br>**1.000**<br>(de 209 mais<br>para 272<br>mais)|⨁⨁◯◯<br>BAIXA|CRÍTICO|
|**Perda de 1**|**0% do peso inicial (avali**|**ado com: : Risco**|**Relativo)**||||||||||
|14|ensaios clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|1520/4859 (31.3%)|684/4417 (15.5%)|**RR 1.98**<br>(1.78 para 2.18)|**152 mais por**<br>**1.000**<br>(de 121 mais<br>para 183<br>mais)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|  
**CI:** intervalo de confiança; **MD:** diferença de média; **RR:** Risco relativoa. Grandes taxas de abandono. b. alta heterogeneidade estatística.  
331  
###### **Tabela Q1.** Resumo dos principais domínios avaliados no GRADE (Tabela _Evidence to Decision_ <u>(EtD) do</u> _webapp_ GRADE PRO).  
|PERGUNTA||
|---|---|
|Qual o efeito da<br>|frequência de monitoramento do peso na perda de peso?|
|**POPULAÇÃO:**|Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade.|
|**INTERVENÇÃO:**|Frequência de monitoramento de peso.|
|**COMPARAÇÃO:**|Ausência de monitoramento ou outra frequência de monitoramento do peso.|
|**PRINCIPAIS**<br>**RESULTADOS:**|Alteração no peso corpóreo, no IMC e na medida da circunferência da cintura desde a linha de base.|
|AVALIAÇÃO||
|Problema<br>O problema é uma prio|ridade?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não<br>○ Provavelmente Não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>A obesidade é uma condição epidêmica no mundo;<br><br>O número de obesos no mundo quase triplicou desde 1975. Em 2016, mais de 1,9 bilhão de adultos apresentavam excesso de peso. Destes, mais de 650 milhões eram<br>obesos;<br><br>De acordo com dados do VIGITEL Brasil 2017, a frequência de sobrepeso foi de 54,0% e a de obesidade de 18,9%.<br><br>A Organização Panamericana da Saúde assumiu compromisso de frear o crescimento da obesidade até 2019 por meio de três medidas principais: deter o crescimento da<br>obesidade na população adulta por meio de políticas de saúde e segurança alimentar e nutricional; reduzir o consumo regular de refrigerante e suco artificial em pelo<br>menos 30% na população adulta; e ampliar em no mínimo 17,8% o percentual de adultos que consomem frutas e hortaliças regularmente|  
332  
#### Efeitos Desejáveis  
Quão substanciais são os efeitos desejáveis?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|○ Trivial|<br>Redução de peso corporal de 2 a 3 kg com um ano de tratamento com orlistate comparado ao placebo;|
|● Pequeno|<br>O uso do orlistate esteve associado a redução de peso clinicamente significativa quando associada a rotina de exercícios físicos e dieta;|
|○ Moderado<br>○ Grande<br>○ Variável<br>○ Incerto<br>Efeitos Indesej<br>Quão substanciais são o|<br>Observou-se maior redução medidas de IMC e circunferência abdominal em pacientes em uso de orlistate comparado ao placebo;<br><br>Comumente ocorrem efeitos gastrointestinais desagradáveis;<br><br>Além de sintomas gastrointestinais, infecções de vias aéreas superiores, gripe, cefaleia e hipoglicemia são eventos adversos muito comuns, enquanto distúrbios dentais<br>ou gengivais, infecções do trato respiratório inferior, irregularidades menstruais, ansiedade, fadiga, infecção urinária são eventos comuns.<br><br>A ocorrência dos eventos adversos gastrointestinais resultou em abandono de tratamento em alguns estudos.<br>áveis<br>s efeitos indesejáveis?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Trivial|<br>Redução de peso corporal de 2 a 3 kg com um ano de tratamento com orlistate comparado ao placebo;|
|● Pequeno<br>○ Moderado<br>○ Grande<br>○ Variável<br>○ Incerto|<br>O uso do orlistate esteve associado a redução de peso clinicamente significativa quando associada a rotina de exercícios físicos e dieta;<br><br>Observou-se maior redução medidas de IMC e circunferência abdominal em pacientes em uso de orlistate comparado ao placebo;<br><br>Comumente ocorrem efeitos gastrointestinais desagradáveis;<br><br>Além de sintomas gastrointestinais, infecções de vias aéreas superiores, gripe, cefaleia e hipoglicemia são eventos adversos muito comuns, enquanto distúrbios dentais<br>ou gengivais, infecções do trato respiratório inferior, irregularidades menstruais, ansiedade, fadiga, infecção urinária são eventos comuns.<br><br>A ocorrência dos eventos adversos gastrointestinais resultou em abandono de tratamento em alguns estudos.|
|Certeza da Evi<br>Qual é a certeza global<br>JULGAMENTO|dência<br>da evidência dos efeitos?<br>EVIDÊNCIAS DE PESQUISA|
|○ Muito Baixa<br>○ Baixa|A melhor evidência disponível mostra que não há benefício em se utilizar o auto monitoramento de peso como estratégia para a perda de peso significativa do ponto de vista<br>estatístico e clínico.|
|● Moderada<br>○ Alta||  
333  
- Sem estudos incluídos a. Grandes taxas de abandono b. alta heterogeneidade estatística  
|**Desfechos**|**Efeitos absolutos potenciais**<sup>*****</sup>**(95% CI)**||**Efeito**<br>**relativo**|**№ de**<br>**participantes**|**Certainty of the**<br>**evidence**|
|---|---|---|---|---|---|
||**Risco com placebo**|**Risco com orlistate**|**(95% CI)**|**(estudos)**|**(GRADE)**|
|Variação Peso (atualização de<br>Khera et al. 2016)<br>avaliado com: diferença média<br>ponderada<br>seguimento: 12 meses|A média variação Peso (atualização de<br>Khera et al. 2016) foi**0**kg|MD**2.68 kg menor**<br>(3.01 menor para<br>2.35 menor)|-|6816<br>(18 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>|
|Perda 5% do peso inicial<br>|População do estudo||**RR 1.69**<br>|10177<br>|⨁⨁◯◯<br>|
|avaliado com: Risco Relativo<br>seguimento: 12 meses|348 por 1.000|**589 por 1.000**<br>(557 para 620)|(1.60 para<br>1.78)|(16 ECRs)|BAIXA<sup>a,b</sup>|
|Perda de 10% do peso inicial<br>avaliado com: Risco Relativo|População do estudo||**RR 1.98**<br>(1.78 para|9276<br>(14 ECRs)|⨁⨁⨁◯<br>MODERADA<sup>a</sup>|
||155 por 1.000|**307 por 1.000**<br>(276 para 338)|<br>2.18)|||  
#### Valores  
Existe importante incerteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|○ Importante incerteza ou|· Medicamento oral e 3x/dia, junto às refeições. Provável maior comodidade e facilidade de uso;|
|variabilidade|· Frequentemente ocorrem eventos gastrointestinais desagradáveis, que podem resultar em constrangimento por parte do usuário.|
|○ Possível Importante|.Estudos citaram estes eventos como uma das razões para abandono do tratamento|
|incerteza ou variabilidade||
|● Provavelmente nenhuma||
|Importante incerteza ou||
|variabilidade||
|○ Sem importante incerteza||
|ou variabilidade||  
334  
#### Balanço dos efeitos  
O balanço entre efeitos desejáveis e indesejáveis favorece a intervenção ou o comparador?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|○ Favorece o comparador|Conforme observado em efeitos desejáveis e indesejáveis:|
|○ Provavelmente favorece o|· Houve diferença média de emagrecimento de 2-3kg num período de ao menos 6 meses com a utilização de orlistate em relação ao placebo ou a cuidados/aconselhamentos|
|comparador|mínimos;|
|○ Não favorece um e nem o|· Quando associado a dieta e exercícios físicos, verificou-se tendência de perda de peso clinicamente significante (5% - 10%);|
|outro|· As reações adversas do orlistate são, em sua absoluta maioria, de natureza gastrointestinal e relacionadas ao seu próprio efeito farmacológico ao evitar a absorção de parte da|
|● Provavelmente favorece a|gordura ingerida;|
|intervenção|Além das reações gastrointestinais, também foram comumente relatados: cefaleia, infecções de vias aéreas superiores, anemia, infecção urinária e irregularidades menstruais.|
|○ Favorece a intervenção||
|○ Variável||
|○ Incerto||  
335  
#### Recursos financeiros requeridos  
O quão grande são os recursos financeiros necessários?  
|JULGAMENTO|EVIDÊNCIAS D|E PESQUISA|
|---|---|---|
|● Grande custo|||
|○ Moderado custo|a|me soon|
|○ Custos ou economia|||
|desprezíveis|||
|○ Economia moderada|||
|○Gd i|<br>|<br>|
|rane economa<br>○ Variável|[sea2<br>|| tenmaa <br><br>|
|○ Incerto|[seas||  
336  
|Custo-efetividade<br>A custo-efetividade fav|orece a intervenção ou o comparador?|
|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|● Favorece o comparador<br>○ provavelmente favorece o<br>comparador<br>○ não favorece nem um nem|· A diferença de efetividade entre o orlistate associado ao tratamento não farmacológico (acompanhamento nutricional, dieta e rotina de exercícios físicos) e o tratamento não<br>farmacológico isolado é de 0,18 para perdas ponderais clinicamente significantes (≥ 10%);<br>· A diferença no custo entre as abordagens é o custo do orlistate, de R$ 1.512,00;|
|outro<br>○ provavelmente favorece a<br>intervenção<br>○ favorece a intervenção<br>○ Variável<br>○ sem estudos incluídos|· A razão de custo-efetividade incremental foi de R$8.400,00 por paciente adicional com perda ponderal ≥ 10%;|
|Equidade<br>Qual seria o impacto em equida|de em saúde?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Reduzida<br>○ Provavelmente reduzida|· População com melhor condição financeira tem já acesso ao medicamento;<br>· Medicamento não disponível no SUS;|
|○ Provavelmente nenhum<br>impacto<br>○ Provavelmente aumentada<br>○ Aumentada<br>○ Variável<br>● Incerto|· Indisponibilidade de outros medicamentos na rede para perda de peso;<br>. Custo de oportunidade: uma possível inclusão do orlistate pode levar ao desabastecimento ou exclusão de outras tecnologias essenciais.|
|Aceitabilidade||
|A intervenção é aceitável para|os principais atores sociais (_stakeholders_)?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não<br>● Provavelmente não<br>○ Provavelmente sim|<br>·Provavelmente moderada por parte dos pacientes: redução discreta de perda de peso quando utilizado isoladamente, evidência fraca para manutenção do peso após o<br>término do tratamento, eventos adversos desagradáveis, associado a altas taxas de abandono de tratamento.|  
337  
|○ Sim<br>○ Variável|<br>·Provavelmente pouco aceitável para o sistema de saúde, dada a eficácia discreta, a alta possibilidade de abandono de tratamento e ao alto impacto financeiro.|
|---|---|
|○ Incerto||  
#### Viabilidade  
É viável a implementação da tecnologia?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|○ Não|<br>O medicamento é facilmente disponível em farmácias: nenhuma condição especial de armazenamento e logística;|
|● Provavelmente não|<br>Será necessária negociação de preços com a empresa fabricante no intuito de reduzir o impacto do uso do medicamento;|
|○ Provavelmente sim||
|○ Sim||
|○ Variável||
|○ Incerto||  
###### TIPO DE RECOMENDAÇÃO  
|Recomendação forte contra a tecnologia|Recomendação condicional contra a|Não favorece uma ou outra|Recomendação condicional a favor da|Recomendação forte a favor da tecnologia|
|---|---|---|---|---|
||tecnologia||tecnologia||
|○|●|○|○|○|  
###### CONCLUSÃO  
###### Recomendação  
A evidência analisada mostrou baixa efetividade. Diante alta prevalência da condição na população, o impacto orçamentário não se mostra viável. Sendo assim, diante das atuais evidências de efetividade, segurança e custo a recomendação é contra o orlistate. A evidência recuperada revela uma diferença média de emagrecimento de 2-3kg num período de ao menos seis meses com a utilização de orlistate em relação ao placebo ou a cuidados/aconselhamentos mínimos. Essa magnitude de efeito foi estatisticamente significativa em quase todos os estudos, mas a significância clínica da mesma é altamente passível a questionamentos. Indaga-se sobre a relevância de perda de peso de dois ou três quilos para um indivíduo cujo peso é superior a 100 kg. Somado a isso, percebemos um aumento estatisticamente significativo de eventos adversos gastrointestinais e altas taxas de abandono nos estudos avaliados, principalmente devido a estes eventos.  
338

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **APÊNDICE 13 - PERGUNTA PICO 12** -->
###### **Questão de pesquisa: “Qual o efeito da frequência do monitoramento do peso na perda de peso em pacientes com sobrepeso e obesidade?”**  
Nesta pergunta, pacientes (P) Indivíduos ≥ 18 anos portadores de sobrepeso ou obesidade; intervenção (I) era a frequência de monitoramento de peso (C) eram ausência de monitoramento ou outra frequência de monitoramento do peso; e desfechos (O) alteração no peso corpóreo, no IMC e na medida da circunferência da cintura desde a linha de base.  
###### **A. Estratégia de busca**  
**Quadro R1.** Estratégias de busca de evidências em base de dados.  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|**MEDLINE via**<br>**pubmed:**|(((self-weighing OR self weighing OR self-monitoring OR self<br>monitoring OR weight monitoring)) AND ("Weight Loss"[Mesh] OR<br>weight loss OR weight reduction)) AND ("Obesity"[Mesh] OR<br>"Overweight"[Mesh] OR obesity OR overweight)<br>Data da busca: 09/11/2018|1.292|
|**EMBASE**|('obesity'/exp OR 'obesity' OR 'obese' OR 'overweight'/exp OR<br>'overweight') AND [embase]/lim AND ('body weight loss'/exp OR<br>'body weight loss' OR 'weight loss'/exp OR 'weight loss' OR 'weight<br>reduction'/exp OR 'weight reduction') AND [embase]/lim AND<br>('self weighing'/exp OR 'self weighing' OR 'self monitoring'/exp OR<br>'self monitoring' OR 'weight monitoring') AND [embase]/lim<br>Data da busca: 09/11/2018|603|  
###### **B. Seleção das evidências**  
A busca das evidências resultou em 612 referências (79 no Pubmed e 533 no EMBASE). Destas, 77 foram excluídas por estarem duplicadas. Quinhentas e trinta e cinco referências foram triadas por meio da leitura de título e resumos, das quais 60 tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com meta-análises de comparações diretas ou indiretas e ensaios clínicos randomizados que especificassem que o estudo avaliava participantes portadores de sobrepeso ou obesidade e que usassem como comparador a frequência do monitoramento de peso. Quando havia disponível vários artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de  
339  
avaliações anteriores. Foram considerados como desfechos primários de eficácia a alteração no peso corpóreo, IMC e medida da circunferência da cintura desde a linha de base.  
Nessa etapa 37 estudos foram excluídos: 1) cinco pelo delineamento de estudo, 1.1) sendo um do tipo transversal<sup>553</sup> ;1.2) quatro por serem revisões sistemáticas sem meta-análise<sup>554–557</sup> ;2) quatro pelo tipo de publicação não envolver trabalho completo (resumos, pôsteres e apresentação de congresso)<sup>558–561</sup> ; 3) 23 por não disporem de desfechos elegíveis, sendo 3.1) seis por não apresentarem resultados quantitativos extraíveis<sup>326,562–566</sup> ; 3.2) onze por apresentarem apenas resultados combinados do monitoramento<sup>225,539,567–575</sup> ; 3.3) três por avaliarem apenas manutenção de peso já perdido<sup>576–578</sup> , e 3.4) um por apresentar apenas desfechos psicológicos<sup>579</sup> , 3.5) um por apresentar apenas resultados de efeitos adversos do monitoramento<sup>580</sup> , 3.6) um por apresentar como desfecho a manutenção e não a perda de peso<sup>581</sup> ; e 4) cinco que incluíram participantes sem sobrepeso ou obesidade<sup>582–586</sup> .  
No final, foram incluídos oito estudos, sendo: duas revisões sistemáticas com meta-análise<sup>587,588</sup> ; quatro ensaios clínicos randomizados<sup>589–592</sup> ; um estudo quasi-experimental<sup>560</sup> ; e um estudo do tipo coorte<sup>593</sup> . As etapas até a definição dos estudos incluídos estão descritas no fluxograma a seguir ( **Figura O1** ).  
340  
###### **Figura O1.** Fluxograma representativo do processo de seleção da evidência.  
<!-- Start of picture text -->
Publicações identificadas através da pesquisa<br>nas bases de dados: 1.896<br>PUBMED = 1.293<br>EMBASE= 603<br>Publicações após remoção de duplicatas:  Publicações excluídas segundo<br>1.659  critérios de exclusão: 1.614<br>Publicações excluídas segundo<br>critérios de exclusão: 37<br>Publicações selecionadas para leitura<br>completa: 45  Tipo de delineamento: 05<br>Tipo de publicação: 04<br>Tipo de desfecho: 23<br>Tipo de participantes: 05<br>Estudos incluídos: 08 estudos<br>Revisão Sistemática: 02<br>ECR: 04<br>Quase-experimental: 01<br>Coorte: 01<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**C. Descrição dos estudos e resultados**  
A caracterização das revisões sistemáticas incluídas pode ser vista na **Tabela P1** . Já a caracterização os participantes destes estudos podeser vista na **Tabela Q1.** As características dos estudos primários incluídos encontram-se na **Tabela R1** e as características dos participantes, na **Tabela S1** . Resultados de eficácia encontram-se nas **Tabela T1** e **Tabela U1** . Na **Figura P1** , está representada a atualização da meta-análise de Madigan et al., 2015. O risco de viés dos estudos encontra-se na **Figura Q1** . A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista na **Tabela S1** , que à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. A **Tabela T1** contém a sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD), também da metodologia GRADE.  
341  
**Tabela P1.** Características dos estudos incluídos pela revisão de Madigan et al (2015) para avaliar o efeito da frequência do monitoramento de peso em indivíduos portadores de sobrepeso ou obesidade.  
|**Autor/ano**|**Desenho do**<br>**estudo**|**População**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|---|---|
|Madigan et<br>al 2014|ECR|IMC≥30kg/m<sup>2</sup>, idade ≥18<br>anos e não realizando o<br>auto-monitoramento do<br>peso uma ou mais vezes<br>por semana.|Examinar a eficácia da auto-monitoramento<br>diário como uma intervenção para perda de<br>peso|183|Na Atenção Primária, fornecidos escalas e instrução<br>para pesar diariamente e realizar o registro em cartão<br>fornecido. Envio de lembretes semanais (mensagens<br>de texto), 2 consultas individuais de gerenciamento<br>de peso e estratégias gerais para ajudar na perda de<br>peso(meta deperda de 0,5kg/semana).|Mesmo manejo do peso<br>de estratégias gerais que<br>o grupo intervenção.|
|Allen et al||Idade entre 21-65 anos,|Avaliar a viabilidade, aceitabilidade e eficácia<br>preliminar de intervenções comportamentais||Sessões de aconselhamento (com nutricionista,<br>sendo 2 vezes no primeiro mês e mensalmente até o|Mesma intervenção com<br>exceção ao auto-|
|2013|ECR|IMC 28 a 42, possuir um<br>Iphone ou celular Android.|de base teórica fornecidas pela tecnologia de<br>smartphones.|68|sexto mês), meta de 150 minutos de atividade física<br>de moderada ou alta intensidade e auto-<br>monitoramentopelo aplicativo de celular.|monitoramento pelo<br>aplicativo de celular.|
||||Avaliar se a ilustração gráfica das flutuações||Intervenções terapêuticas semanais individuais,|Intervenções terapêuticas|
|Fujimoto et<br>al 1992|ECR|Sem intervenção de dieta<br>anterior.|diárias de peso foi efetiva na redução de peso<br>e sua manutenção.|72|acompanhamento no hospital a cada 6 meses e<br>orientado a realizar auto-pesagem quatro vezes ao<br>dia durante oprograma e depois diariamente.|semanais individuais e<br>acompanhamento no<br>hospital a cada 6 meses.|
|Gokee||Participantes entre 21 e 35<br>anos, com IMC 27-40kg/m<sup>2</sup>,|Determinar a viabilidade de recrutar e manter<br>adultos jovens em uma intervenção de perda<br>de peso comportamental breve adaptada para||Dieta e metas de exercício, modificação de<br>comportamento, encontros semanais em grupo e<br>orientações para realizar diariamente o auto-|Dieta e metas de<br>exercício, modificação de<br>comportamento,|
|LaRose et<br>al 2009|ECR|sem histórico de desordem<br>alimentar ou dependência<br>química.|essa faixa etária e avaliar a eficácia preliminar<br>de uma intervenção que enfatiza a auto-<br>pesagem diária dentro do contexto de um<br>modelo de auto-monitoramento.|40|monitoramento do peso em casa (uso da escala de<br>cores que orientava quanto a necessidade de<br>mudança de comportamento, e estando verde<br>ganhariam pequeno presente).|encontros semanais em<br>grupo e orientação de não<br>realizar auto-<br>monitoramento do peso<br>em casa.|
|Wing et al||Capacidade de usarem<br>website e completar o|Avaliar se a adição de estratégias<br>comportamentais de perda de peso poderia||Programa de perda de peso online, com envio de<br>dados aos participantes a cada 2 semanas; realização<br>diária de auto-monitoramento do peso, dieta e|Mesmo programa de|
|2010|ECR|diário alimentar. Maiores<br>de 18 anos e com IMC<br>maior que 25kg/m<sup>2</sup>.|melhorar os resultados de uma campanha de<br>perda de peso na comunidade.|128|atividade física, com feedback semanal<br>automatizado; e uma sessão em grupo sobre o<br>balanço energético e importância do auto-<br>monitoramento.|perda de peso online que<br>o grupo intervenção.|  
342  
###### ECR: ensaio clínico randomizado.  
**Tabela Q1.** Características basais para os estudos incluídos na revisão de Madigan et al (2015) que avaliaram o efeito da frequência do monitoramento de <u>peso na redução de peso de indivíduos portadores de sobrepeso ou obesidade.</u>  
|**Autores**|**N intervenção**|**N**<br>**controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção vs.**<br>**Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (**kg/m<sup>2</sup>**), média**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Circunferência da cintura (cm), média**<br>**(DP)**<br>**(Intervenção vs. Controle)**|**Duração da**<br>**intervenção**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|Madigan et al|92|91|53,9 (14,9)<br>vs|37 0 vs 36 3|35,8 (4,3)<br>vs|NR|NR|3 meses|3 meses|
||||53,3(14,6)||36,2(4,8)|||||
||18 (IC)||42,5 (12,1)|22,2|34,1 (4,1)|96,0 (17,4)|H 117,3 (15.5); M 106,4 (14.5)|||
|Allen et al|16 (IC + S|P)|45,6 (9,3)|31,2|34,3 (3,9)|100,3 (16,5)|H 119,4 (11,6); M 109,7 (11,4)|6|6|
|2013|17 (INI + S|P)|46,4 (9,6)|23,5|33,5 (3,5)|96,8 (14,8)|H 116,4 (4,6); M 108,7 (8,4)|meses|meses|
||~~17 (SP)~~||~~45,3 (13,2)~~|~~11,8~~|~~35,3 (4,1)~~|~~96,4 (16,9)~~|~~H 113,8 (23,0); M 105,5 (11,1)~~|||
|Fujimoto et al<br>1992|CS: 48<br>PS: 7|CS: 11<br>PS: 6|CS: 42,5 (2,1) vs.<br>44,4 (3,4)<br>PS: 42,2 (2,8) vs.<br>42,0(4,4)|27,3 vs. 0|CS: 33,7 (3,5) vs. 34,0<br>(1,4)<br>PS: 33,3 (2,7) vs. 34,1<br>(1,7)|CS: 80,4 (2,0) vs.<br>83,0 (3,6)<br>PS: 78,7 (3,9) vs.<br>81,2(5,6)|NR<br>NR|7,2 meses|2 anos|
|Gokee LaRose|21|19|29,1 ± 3,9 (total)|15% (total)|33.36 ± 3.4 (total)|82.3 ± 12.6 (total)|NR|10 semanas|20 semanas|
|et al 2009<br>2010<br>Wing et al|82|46|46,9 (9,7) (total)|10,2% (total)|33,9 (5,6) (total)|92,0 (17,8) (total)|NR|12 semanas|12 semanas|  
NR: não reportado, N: número da amostra, DP: desvio padrão, IC: intervenção completa sem SP, SP: auto-monitoramento com smartphone, INI: intervenção não intensiva, H: homens, M: mulheres; CS: completaram o seguimento; PS: perderam o seguimento.  
**Tabela R1.** Características dos estudos incluídos para avaliar o efeito da frequência do monitoramento de peso em indivíduos portadores de sobrepeso ou obesidade.  
343  
|**Autor/ano**|**Dese-**<br>**nho do**<br>**estudo**|**População**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|---|---|
|||Idade ≥18 anos, não estar<br>planejando e nem estar grávida,|Testar o auto-<br>monitoramento diário do<br>peso com feedback visual||Participar de uma sessão que abordou estratégias<br>baseadas em evidências para a perda de peso, e|Participar de uma sessão que abordou<br>estratégias baseadas em evidências para<br>a perda de peso no primeiro ano, e no|
|**Pacanowski et**<br>**al 2015**|ECR|não possuir diabetes, não estar<br>com desordem alimentar e nem<br>ter tal histórico, e apresentar IMC<br>≥27kg/m<sup>2</sup>.|(o Método de Titulação<br>Calórica (CTM)) como uma<br>intervenção para a perda<br>ou manutenção de peso ao<br>longo de 2 anos.|149|receberam uma balança de banheiro assim como<br>orientações para realizar a auto-pesagem<br>diariamente e registrar a informação em um site que<br>gera gráfico com as informações.|segundo ano foram adicionadas<br>orientações para realizar a auto-pesagem<br>diariamente e registrar a informação em<br>um site que gera gráfico com as<br>informações|
|**Jospe et al**<br>**2017**|ECR|> 18 anos, IMC ≥27kg/m<sup>2</sup>, acesso<br>regular à internet, não possuir<br>diabetes ou glicose sanguínea em<br>jejum ≥7 mmol/L, nem hipertensão<br>(seja ela severa, moderada ou<br>medicada), não estar grávida ou<br>amamentando, ou planejando<br>engravidar, ausência de histórico<br>de doença cardiovascular ou<br>outras condições médicas graves,<br>não usar medicamentos que<br>afetam o peso ou a composição<br>corporal; e nem ter outro membro<br>da família já inscrito no estudo.|Determinar a eficácia de<br>várias estratégias de<br>monitoramento sobre a<br>perda de peso, composição<br>corporal, marcadores<br>sanguíneos, exercício e<br>índices psicossociais em<br>adultos com sobrepeso e<br>obesidade após um<br>programa de perda de peso<br>de 12 meses.|250|Realizaram a escolha de um dos três possíveis planos<br>de dieta e um dos dois programas de exercícios que<br>desejavam seguir, receberam orientações relevantes<br>de ambos, com recursos extensos e estratégias<br>comportamentais; e foram convidados a pesar-se na<br>mesma hora todos os dias (geralmente na primeira<br>hora da manhã), enviando via on-line diariamente os<br>dados para os pesquisadores, cuja interface exibia um<br>gráfico com histórico do peso, além de receberem e-<br>mails mensais personalizados.|Realizaram a escolha de um dos três<br>possíveis planos de dieta e um dos dois<br>programas de exercícios que desejavam<br>seguir, receberam orientações relevantes<br>de ambos, com recursos extensos e<br>estratégias comportamentais.|
|**Crane et al**<br>**2018**|ECR|IMC entre 25 e 40kg/m<sup>2</sup>, idade<br>entre 18 e 64 anos, possuir<br>internet wireless em casa, e não<br>possuir condições de saúde<br>relevantes (como sintomas<br>depressivos, transtorno da<br>compulsão alimentar periódica ou<br>história de transtorno alimentar).|Comparar frequência de<br>pesagem autorreferida com<br>medidas objetivas de<br>frequência de pesagem ao<br>longo de 24 meses.|223|Receberam 32 sessões de programa de perda de peso<br>comportamental, 6 meses de sessões semanais em<br>grupo, seguido de 6 meses de sessões quinzenais e<br>depois mensais ao longo de 1 ano, além de<br>recomendações para mudar a dieta e o exercício; e<br>orientado a realizar a auto-pesagem diariamente ou<br>semanalmente.|Receberam 32 sessões de programa de<br>perda de peso comportamental, 6 meses<br>de sessões semanais em grupo, seguido<br>de 6 meses de sessões quinzenais e<br>depois mensais ao longo de 1 ano, além<br>de recomendações para mudar a dieta e<br>o exercício.|
||Quasi-|Pacientes egressos do ECR e do<br>programa_Ligthen up_do sistema de|Avaliar se a estimulação do<br>auto monitoramento||Foi viabilizado o acesso a balanças domiciliares aos<br>pacientes, disponibilizado um cartão para anotação|O grupo controle recebeu apenas a|
|**Madigan et al**<br>**2013**|experim<br>ental|saúde inglês. O mesmos deveriam<br>ter IMC elevado e não ter contra-<br>indicações para participar de<br>programas deperda depeso.|semanal de peso é eficaz na<br>manutenção e eventual<br>perda de peso.|1378|das medidas de peso e material com dicas. Após 3<br>meses foi efetuada uma ligação incentivando os<br>participantes monitorarem o peso.|ligação para comparecer à medição de<br>peso após 12 meses.|  
344  
|**Larose et al**<br>**2016**|Coorte|<sup>Pacientes participantes do estudo</sup><br>SPARK RCV – Adultos jovens (18-25|Avaliar se a frequência de<br>pesagem influência no<br>Aplicação de questionário de frequência de<br>monitoramento de peso.<br>NA<br>52|
|---|---|---|---|  
345  
|**Autor/ano**|**Dese-**<br>**nho do**<br>**estudo**|**População**|**Objetivo**|**Número de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|---|---|
|||anos) com IMC 25-45 kg/m2, sem<br>intenção de engravidar ou|desempenho da perda de<br>peso no âmbito do SPARK||||
|||apresentando condições que|RCV.||||
|||levassem ao emagrecimento<br>involuntário.|||||  
ECR: ensaio clínico randomizado; NA: não aplicável.  
**Tabela S1.** Características basais para os estudos incluídos que avaliaram o efeito da frequência do monitoramento de peso na redução de peso de indivíduos portadores de sobrepeso ou obesidade  
|**Autores**|**N intervenção**|**N**<br>**controle**|**Idade (anos)**<br>**média (DP)**<br>**(intervenção vs.**<br>**Controle)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle)**|**IMC (kg/m**<sup>**2**</sup>**)), média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Peso (Kg), Média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Circunferência da**<br>**cintura (cm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo da**<br>**intervenção**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|Pacanowski<br>et al 2015|81|68|45,3 (9,6) vs.48,2<br>(9,9)|22,2 vs. 13,2|33,4 (5,1) vs.33,7 (5,1)|94,3 (17,0) vs. 93,1<br>(17,9)|NR|2 anos|2 anos|
|Jospe et al<br>2017|51|48|46,1 (11,4) vs.<br>46,7 (11,4)|37,2 vs. 37,5|33,2 (4,8) vs.32,3 (4,3)|96,8 (16,6) vs.<br>91,0 (14,9)|102,7 (12,8) vs.<br>99,8 (11,0)|12 meses|12 meses|
|2018<br>Crane et al|N<br>|A<br>|(total)<br>46,6 (10,2)|36,3 (total)|33,0 (3,6) (total)|NR|NR|12 meses|24 meses|
|Madigan et al<br>2013|ITT: 900<br>Completaram:<br>876|ITT: 478<br>Completaram:<br>297|53,16(14,66) vs<br>51 14(14 3)|14,3 vs 32,2|3,5(6,1) vs 32,2(3,7)|NR|NR|12 meses (3<br>meses de_lead-_<br>_in)_|9 meses|
|2016<br>Larose et al|52|NA|22,3(20)|21%|34,2(5,4)|NR|NR|3 meses|3 meses|  
NR: não reportado, N: número da amostra, DP; desvio padrão; NA: não se aplica (controles do estudo original foram excluídos da análise).  
346  
**Tabela T1.** Desfechos de eficácia de estudos incluídos na revisão de Madigan et al (2015) que avaliaram o efeito da frequência do monitoramento de peso na alteração de peso corporal, no IMC e circunferência da cintura.  
|**Autor, ano**|**Desfechos de perda do peso corporal (Kg)**<br>**Intervenção vs. controle**|**Valor de p em**<br>**relação à linha de**<br>**base**|**Desfechos de alteração no IMC (Kg/m**<sup>**2**</sup>**)**<br>**Intervenção vs. controle**|**Valor de p**<br>**em relação à**<br>**linha de**<br>**base**|**Desfechos de alteração da medida de circ.**<br>**cint. (cm)**<br>**Intervenção vs. controle**|**Valor de p**|
|---|---|---|---|---|---|---|
|Madigan et al<br>2014|-1,7 (IC95% -2,3 a -1,1) vs.<br>-1,2(IC95% -1,7 a -0,7)|< 0,01|NR|NR|NR|NR|
||IC -2,5 (DP 4,1)||IC -0,8 (DP 1,4)||IC: H -3,0 (DP 2,4); M-3,19 (DP 7,4)|0,36|
|Allen et al|IC+SP -5,4 (DP 4,0)|0,89|IC+SP -1,8 (DP 1,3)|0,79|IC+SP: H-7,01 (DP 2,6); M -5,68 (DP 3,7)||
|2013|INI+SP -3,3 (DP 5,9)<br>SP -1,8(DP 3,7)||INI+SP -1,1 (DP 2,0)<br>SP -0,7(DP 1,3)||INI+SP: H-6,5 (DP 0,35); M -3,64 (DP 7,9)<br>SP: H -3,38(DP 8,3);M -0,88(DP 2,9)|0,22|
||CS/FT: 15,2 (DP 1,5) vs. 16,8 (DP 1,9)||NR|NR|NR|NR|
|Fujimoto et al<br>1992|CS/FS: 14,9 (DP 1,9) vs. 7,8 (DP 1,8)<br>PS/FT: 5,2 (DP 1,1) vs. 6,0 (DP 1,8)|< 0,05|NR|NR|NR|NR|
|Gokee LaRose|~~PS/FS: ND~~<br>FT -6,6 (DP 5,5) vs. -5,8 (DP 5,2)|< 0 001|NR|NR|NR|NR|
|et al 2009|FS -6,6 (DP 5,5) vs. -5,8 (DP 5,2)||NR|NR|NR|NR|
|Wing et al|3,1 (DP 3,7) vs. 1,2 (DP 2,5)|< 0,01|NR|NR|NR|NR|
|~~2010~~|~~*3,6 (DP 4,4) vs. 1,4 (DP 3,0)~~|~~< 0,01~~|||||  
IC95%: intervalo de confiança; DM: diferença de médias; NR: não reportado; IMC: Índice de Massa Corporal; DP: desvio padrão; IC: intervenção completa sem SP; SP: auto-monitoramento com smartphone; INI: intervenção não intensiva; H: homens; M: mulheres; FT: final do tratamento; FS: final do seguimento; CS: completaram o seguimento; PS: perderam o seguimento; ND: não detectado; *perda de peso em porcentagem.  
**Tabela U1.** Desfechos de eficácia de estudos incluídos que avaliaram o efeito da frequência do monitoramento de peso na alteração de peso corporal, no IMC e circunferência da cintura.  
|**Autor, ano**|**Desfechos de alteração do peso corporal**<br>**(Kg) Intervenção vs. controle**|**Valor de p**|**Desfechos de alteração no IMC (Kg/m**<sup>**2**</sup>**)**<br>**Intervenção vs. controle**|**Valor de p**<br>**De**|**sfechos de alteração da medida de**<br>**cint. (cm)**<br>**Intervenção vs. controle**|**circ.**<br>**Valor de p**|
|---|---|---|---|---|---|---|
|||||||347|  
Pacanowski et 1º ano: 2,6 (DP 5,9) (n=70) vs. 0,5 (DP 4,4) 0,019 NR NR NR al 2015 (n=65);  
NR  
348  
|**Autor, ano**|**Desfechos de alteração do peso corporal**<br>**(Kg) Intervenção vs. controle**|**Valor de p**|**Desfechos de alteração no IMC (Kg/m**<sup>**2**</sup>**)**<br>**Intervenção vs. controle**|**Valor de p**|**Desfechos de alteração da medida de circ.**<br>**cint. (cm)**<br>**Intervenção vs. controle**|**Valor de p**|
|---|---|---|---|---|---|---|
||1º ano*: 2,1 (DP 5,6) (n=81) vs. 0,4 (DP 4,4)<br>(n=67)<br>2º ano: Intervenção 0,1 (DP 4,8)<br>2º ano: Controle 1,9 (DP 5,7) (n=57)|0,037<br>0,929<br>0,524|||||
|Jospe et al<br>2017|6º mês**: 94,6 (DP 16,5) (n=48) vs. 87,3 (DP<br>14,5) (n=44)<br>12º mês**: 94,8 (DP 18,7) (n=39) vs. 87,3<br>(DP 15,2) (n=36)|NR|6º mês: 32,4 (DP 4,9) (n=48) vs. 30,9 (DP 4,3)<br>(n=44)<br>12º mês: 32,1 (DP 5,5) (n=39) vs. 30,9 (DP 4,6)<br>(n=36)|NR|6º mês: 99,2 (DP 11,5) (n=48) vs. 96,7 (DP<br>10,7) (n=44)<br>12º mês: 100,3 (DP 13,7) (n=39) vs. 96,8 (DP<br>9,9) (n=36)|NR|
||12 meses – auto pesagem: MM (n=10) 0,9<br>(DP 5,0); SE (n=92): −8,3 (DP 8,5); DI (n=84)<br>−9,4 (DP 8,0)<br>12 meses – objetivo: MM (n=17) -1,3 (DP<br>8,3); SE (n=121): −6,8 (DP 7,5); DI (n=59)|0,0002<br><0,0001|||||
|Crane et al<br>2018|−11,7 (DP 8,0)<br>24 meses – auto pesagem: MM (n=42) -1,4<br>(DP 6,0); SE (n=88): −4,4 (DP 7,9); DI (n=45)<br>−7,9 (DP 7,8)<br>24 meses – objetivo: MM (n=92) -2,7 (DP<br>7,5); SE (n=73): −6,6 (DP 7,7); DI (n=12) −10,9<br>(DP 8,9)|<0,0001<br><0,0001|NR|NR|NR|NR|
|Madigan et al|ITT<br>Ajustado: -2,96 (IC95%-3,67 a -2,25)<br>Não-ajustado: -3,21(IC95%-3,87 a -2,55)||||||
|2013|Completaram<br>Ajustado: -1,93 (IC95%-2,79 a -1,08)<br>Não-ajustado: 2,19(IC95%-2,99 a -1,38)|NR|NR|NR|NR|NR|
|Larose et al<br>2016|Aumentaram frequência de pesagem:<br>-4,9 (DP 4,2)<br>Mantiveram frequência de pesagem:<br>-2,3 (DP 3,5)<br>Diminuíram frequência de pesagem:<br>-0,92 (DP 2,2)|0,06|NR|NR|NR|NR|  
349  
IC95%: intervalo de confiança; DM: diferença de médias; NR: não reportado; IMC: Índice de Massa Corporal; DP: desvio padrão; IC: intervenção completa sem SP; SP: auto monitoramento com smartphone; INI: intervenção não intensiva; H: homens; M: mulheres; *aplicação do método última observação transportada (LOCF) para imputar dados faltantes; MM: mensal ou menos; SE: semanal; DI: diária; **média do peso corpóreo individual.  
**Figura P1.** Meta-análise do auto-monitoramento de peso na perda do peso corporal. or Subgroup Mean SD Total Mean SD Total Weight_1V, Random, ‘Study1.1.1 Aufopesagem isolada Autopesagem Controle Mean Difference95% Cl IV,MeanRandom, Difference95% Cl Madigan etal, 2014 “47 34 92 4.2.25 91 435% -0.5041.32,0.32) Subtotal (95% Ci) 92 91 43.5% —-0.50[-1.32, 0.32] Heterayenelly: Not applicable Test for overall eflect Z= 1.20P = 0.23) 1.1.2 Autopesagem associada a programa comportamental de manejo de peso Fujimoto et al, 1992 439 111 66 13.93 17 15% -09066.21,4.41) Gokee LaRose Wing et al,2009 64 «4 «216.245 «19 5.8% —-0.205-2.85, 2.45) 37 42 16 1735 18 59% -200¢462,0.62) Alen<sup>etal,</sup> et al,<sup>2013</sup> 2010 “31 37 82 1.2.25 48 288% -1.90(-2.98,-0.82) ~~ Pacanowskiet al, 2015, 21 56 81 -04 44 67 146% -1.70(3:31,-0.09) Subtotal (95% Cl) 255 167 56.5% | -1.68 [-2.48, 0.88] > TestHeteragenely: for overall Tau?=effect 0.00;Z= 4.13Chit=P< 0.0001)1.50, df= 4 (P= 0,89); P= 0% Total (95% Cl) 347 258 100.0% -1.15[-1.81, -0.50] ad Heteragenely: Tau*= 0.08; Chit= 6.63, df= (P= 0.34), P= 11% ery + $ Testor overall effect Z= 3.48 P = 0.0005) Favorece autopesagem Favorece Testor subaroup diferences: Chit= 4.13, df=1 (P= 0.04), P= 75.8% Fonte: Adaptado de Madigan et al., 2015  
350  
**Figura Q1.** Avaliação da qualidade metodológica dos ensaios clínicos incluídos na revisão sistemática Madigan et al., 2015.  
<!-- Start of picture text -->
eS<br>&<br>a<br>@<br>8<br>BE secs<br>— $<br>zs £ 8<br>a 2 sg<br>< 3 3<br>£ ez 3 @<br>sw 3 o<br>Se EB. 2 &<br>265 8 € Ss 8<br>s§ 3 os ¢@ & 8s<br>= 2 2 5% € 2<br>Sos @ &$ &<br>so 2 § ® gs &<br>2: 9s 8<br>5 =» &© Be<br>&S 2 £ ® a<br>2 &£€ © @2eF<br>82&* 3€$22=ss8228€ €sgs &oa<br>2*€8&2&82 8s<br>®2s 6s 2 & ®<br>sEs aFe Bo22= 38<br>es fi oege<br>et Oo @ £ wH 6<br>rama<br>comer]aa. | @||||||2 [@[@|@|@| [|<br><!-- End of picture text -->  
351  
###### **Tabela S1.** Sumarização dos resultados dos estudos (Summary of Findings (SoF) do _webapp_ Grade PRO.  
||||**Avaliação da**|**qualidade**|||**№ de pa**|**cientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**monitoramento de**<br>**peso**|**monitoramento**<br>**associado a**<br>**programa**<br>**comportamental**|**Relativo**<br>**(95% IC)**|**Absoluto**<br>**(95% IC)**|**Qualidade**|**Importância**|
|**Perda de P**|**eso (Kg) (seguimen**|**to: variação 3 mes**|**es para 2 anos)**||||||||||
|6|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|muito grave<sup>b</sup>|não grave|muito grave<sup>c</sup>|nenhum|347|258|-|MD**1.15 Kg**<br>**menor**<br>(1.81 menor<br>para 0.5<br>menor)|⨁`◯◯◯`<br>MUITO BAIXA|CRÍTICO|
|**Desfechos**|**de perda do peso c**|**orporal (Kg) - Auto**|**pesagem isolada (se**|**guimento: median**|**a 3 meses)**||||||||
|1|ensaios<br>clínicos<br>randomizados|não grave|não grave|não grave|não grave|nenhum|92|91|-|MD**0.5 Kg**<br>**menor**<br>(1.32 menor<br>para 0.5 mais<br>alto)|⨁⨁⨁⨁<br>ALTA|CRÍTICO|
|**Desfechos**|**de perda do peso c**|**orporal (Kg) - Auto**|**pesagem associada**|**a programa comp**|**ortamental de mane**|**jo de peso (seguimento: varia**|**ção 3 meses para 2 an**|**os)**|||||
|5|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|muito grave<sup>b</sup>|não grave|muito grave<sup>c</sup>|nenhum|255|167|-|MD**1.68 Kg**<br>**menor**<br>(2.48 menor<br>para 0.88<br>mais alto)|⨁`◯◯◯`<br>MUITO BAIXA|CRÍTICO|  
**IC:** Intervalo de confiança; **DM:** Diferênça de médias; a. Cegamento dos participantes, perdas de acompanhamento dos mesmos e relato seletivo; b. Tempos de seguimento com grande variação (3 meses a 2 anos). Alta heterogeneidade clínica e estatística (I2 para subgrupos > 75%); c. Estudos muito heterogêneos e estimativas muito imprecisas (largos intervalos de confiança  
352  
###### **Tabela T1.** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ <u>(EtD) do</u> _webapp_ GRADE PRO).  
|PERGUNTA||
|---|---|
|**Deve-se usar**|**monitoramento de peso vs. monitoramento associado a programa comportamental para perda de peso em Kg?**|
|**POPULAÇÃO:**|perda de peso em Kg|
|**INTERVENÇÃO:**|monitoramento de peso|
|**COMPARAÇÃO:**|monitoramento associado a programa comportamental|
|**PRINCIPAIS**<br>**RESULTADOS:**|Perda de Peso (Kg); Desfechos de perda do peso corporal (Kg) - Autopesagem isolada ; Desfechos de perda do peso corporal (Kg) - Autopesagem associada a programa comportamental de<br>manejo de peso|  
|AVALIAÇÃO||
|---|---|
|Problema<br>O problema é uma prioridade?||
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não<br>○ Provavelmente Não<br>○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|<br>A obesidade mundial quase triplicou desde 1975.<br><br>Em 2016, mais de 1,9 bilhão de adultos, 18 anos ou mais, apresentavam excesso de peso. Destes, mais de 650 milhões eram obesos.<br><br>39% dos adultos com 18 anos ou mais estavam acima do peso em 2016 e 13% eram obesos.<br><br>A maioria da população mundial vive em países onde o excesso de peso e a obesidade mata mais pessoas do que abaixo do peso.<br><br>41 milhões de crianças menores de 5 anos estavam acima do peso ou obesas em 2016.<br><br>Mais de 340 milhões de crianças e adolescentes com idade entre 5 e 19 anos estavam acima do peso ou obesas em 2016.<br><br>A obesidade é evitável.|
||Fonte: OMS. Obesity and overweight. Disponível em: https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight. Acesso em: 09/08/2019|  
353  
#### Efeitos Desejáveis  
Quão substanciais são os efeitos desejáveis?  
- JULGAMENTO EVIDÊNCIAS DE PESQUISA ○ Trivial  O único estudo, com baixo risco de viés, e que avaliou a auto pesagem vs. nenhuma intervenção mostrou que houve uma redução não significativa de peso com o uso ●Pequeno da tecnologia. ○ Moderado  Os estudos que compararam a auto pesagem versus outras intervenções evidenciaram efeito substancial da autopesagem. No entanto, devido à alta heterogeneidade, ○ Grande períodos de seguimento variados e imprecisão das estimativas, não podemos agregar alto nível de certeza nessa estimativa. ○ Variável ○ Incerto Efeitos Indesejáveis Quão substanciais são os efeitos indesejáveis? JULGAMENTO EVIDÊNCIAS DE PESQUISA ●Trivial  O único estudo, com baixo risco de viés, e que avaliou a auto pesagem vs. nenhuma intervenção mostrou que houve uma redução não significativa de peso com o uso da ○ Pequeno tecnologia. ○ Moderado  Os estudos que compararam a auto pesagem versus outras intervenções evidenciaram efeito substancial da auto pesagem. No entanto, devido à alta heterogeneidade, ○ Grande períodos de seguimento variados e imprecisão das estimativas, não podemos agregar alto nível de certeza nessa estimativa. ○ Variável ○ Incerto  
#### Certeza da Evidência  
Qual é a certeza global da evidência dos efeitos?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|● Muito Baixa|A melhor evidência disponível mostra que não há benefício em se utilizar o auto monitoramento de peso como estratégia para a perda de peso significativa do ponto de vista|
|○ Baixa|estatístico e clínico.|
|○ Moderada||
|○ Alta||  
- Sem estudos incluídos  
354  
<!-- Start of picture text -->
Certainty of the<br>Desfechos  Importância evidence<br>(GRADE)<br>Perda de Peso (Kg)  CRÍTICO  ⨁ ◯◯◯<br>seguimento: variação 3 meses para 2 ano  MUITO BAIXA c<br>Desfechos de perda do peso corporal (Kg) - Auto pesagem isolada  CRÍTICO  ⨁⨁⨁⨁<br>seguimento: mediana 3 meses  ALTA c<br>Desfechos de perda do peso corporal (Kg) - Auto pesagem associada a programa comportamental de manejo  CRÍTICO  ⨁ ◯◯◯<br>de peso  MUITO BAIXA c<br>seguimento: variação 3 meses para 2 anos<br>c. Cegamento dos participantes, perdas de acompanhamento dos mesmos e relato seletivo<br>d. Tempos de seguimento com grande variação (3 meses a 2 anos). Alta heterogeneidade clínica e estatística (I2 para subgrupos ><br>75%)<br>e. Estudos muito heterogêneos e estimativas muito imprecisas (largos intervalos de confiança)<br>Valores<br>Existe importante incerteza ou variabilidade acerca de quanto as pessoas valorizam os resultados primários?<br>JULGAMENTO  EVIDÊNCIAS DE PESQUISA<br>○ Importante incerteza ou  Auto-pesagem é o monitoramento do resultado (ou seja, peso) ao invés de comportamento e, portanto, mostrando ser util para a redução de peso.<br>variabilidade<br>○ Possível Importante incerteza<br>ou variabilidade<br>● Provavelmente nenhuma<br>Importante incerteza ou<br>variabilidade<br>○ Sem importante incerteza ou<br>variabilidade<br><!-- End of picture text -->  
355  
#### Balanço dos efeitos  
O balanço entre efeitos desejáveis e indesejáveis favorece a intervenção ou o comparador?  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|---|---|
|○ Favorece o comparador<br>○ Provavelmente favorece o<br>comparador<br>○ Não favorece um e nem o<br>outro<br>● Provavelmente favorece a<br>intervenção<br>○ Favorece a intervenção<br>○ Variável<br>○ Incerto|Como uma intervenção para perda de peso, a instrução para pesar-se diariamente é ineficaz. Ao contrário de outros estudos, não houve evidência de que maior frequência de<br>auto-ponderação esteja associada a maior perda de peso (como base na melhor evidência). De qualquer maneira, mesmo com baixa evidência, associada à mudanças<br>comportamentais, a auto-pesagem pode promover a redução de peso. Não gera eventos adversos e é facilmente implementável.|
|Equidade<br>Qual seria o impacto e|m equidade em saúde?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Reduzida<br>○ Provavelmente reduzida<br>○ Provavelmente nenhum<br>impacto<br>● Provavelmente aumentada<br>○ Aumentada<br>○ Variável<br>○ Incerto|Como uma tecnologia que é parte de uma série de etapas que visa a redução e a prevenção de obesidade, ela pode agregar em equidade e integralidade à assistência em saúde à<br>pessoa obesa e com sobrepeso. É uma ação simples e que gera um senso de preocupação, para com a pessoa, vinda do sistema de saúde.|
|Aceitabilidade||
|A intervenção é aceitável para o|s principais atores sociais (_stakeholders_)?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não<br>○ Provavelmente não|<br>Não existem eventos adversos relatados, a implementação é simples;|  
356  
|● Provavelmente sim<br>○ Sim|<br>Acessibilidade geográfica pode ser comprometida a depender da frequência de monitoramento em serviço de saúde;|
|---|---|
|○ Variável||
|○ Incerto||
|Viabilidade||
|É viável a implementação da|tecnologia?|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|
|○ Não|<br>Toda UBS é equipada com balança;|
|○ Provavelmente não|<br>O procedimento de pesagem é simples de ser realizado;|
|○ Provavelmente sim<br>● Sim|<br>A autopesagem, em domícilio, pode ser dificultada, pois nem todas as pessoas podem ter condições econômicas suficentes para arcar com o custo de uma balança;|
|○ Variável||
|○ Incerto||  
###### TIPO DE RECOMENDAÇÃO  
|Recomendação forte contra a tecnologia|Recomendação condicional contra a|Não favorece uma ou outra|**Recomendação condicional a favor da**|Recomendação forte a favor da tecnologia|
|---|---|---|---|---|
||tecnologia||**tecnologia**||
|○|○|○|**●**|○|  
###### CONCLUSÃO  
###### Recomendação  
Recomenda-se o auto monitoramento de peso corporal, pelo menos uma vez na semana, como estratégia adjuvante para a redução de peso.  
357

---

<!-- METADADOS: doenca: Sobrepeso e Obesidade em Adultos | secao: **REFERÊNCIAS** -->
1. BRASIL. PORTARIA N<sup>o</sup> 375, DE 10 DE NOVEMBRO DE 2009. Diário Oficial da União. 2009. 2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.  
3. Associação Brasileira de Nutrologia, Sociedade Brasileira de Nutrição Parenteral e Enteral. Utilização da Bioimpedância para Avaliação da Massa Corpórea. Associação Médica Brasileira e Conselho Federal de Medicina. 2009.  
4. Wang ZH, Yang ZP, Wang XJ, Dong YH, Ma J. Comparative Analysis of the Multi-Frequency Bioimpedance and Dual-energy X-ray Absorptiometry on Body Composition in Obese Subjects. Biomed Environ Sci. 2018 Jan;31(1):72–5.  
5. Leal AAD, Faintuch J, Morais AAC, Noe JAB, Bertollo DM, Morais RC, et al. Bioimpedance analysis: should it be used in morbid obesity? Am J Hum Biol Off J Hum Biol Counc. 2011;23(3):420–2.  
6. Câmara Interministerial de Segurança Alimentar e Nutricional. Estratégia Intersetorial de Prevenção e Controle da Obesidade: recomendações para estados e municípios. Brasília: Imprensa Nacional; 2014.  
7. BRASIL. Relatório de Recomendação no 522: Sibutramina para o tratamento dos pacientes com obesidade. Ministério da Saúde. 2020.  
8. BRASIL. Relatório de Recomendação no. 523: Orlistate para a redução de peso em indivíduos com sobrepeso ou obesidade. Ministério da Saúde. 2020.  
9. Nordisk N. Ozempic® (semaglutida). ANVISA. Farm. resp: Luciane M. H. Fernandes – CRF/PR n° 6002; 2020.  
10. BRASIL. PORTARIA N<sup>o</sup> 425, DE 19 DE MARÇO DE 2013. Estabelece regulamento técnico, normas e critérios para a Assistência de Alta Complexidade ao Indivíduo com Obesidade. Diário Oficial da União. 2013.  
11. Arora M, Barquera S, Farpour Lambert NJ, Hassell T, Heymsfield SB, Oldfield B, et al. Stigma and obesity: the crux of the matter. Lancet Public Heal. 2019 Nov;4(11):e549–50.  
12. Ng M, Fleming T, Robinson M, Thomson B, Graetz N, Margono C, et al. Global, regional, and national prevalence of overweight and obesity in children and adults during 1980-2013: a systematic analysis for the Global Burden of Disease Study 2013. Lancet (London, England). 2014 Aug;384(9945):766–81.  
13. Flint SW. The complexity of obesity. lancet Diabetes Endocrinol. 2019 Nov;7(11):833.  
14. Puhl R, Suh Y. Health Consequences of Weight Stigma: Implications for Obesity Prevention and Treatment. Curr Obes Rep. 2015 Jun;4(2):182–90.  
15. Coordenação-Geral de Vigilância de Agravos e Doenças Não Transmissíveis (CGDANT/DASNT/SVS). Vigitel Brasil 2019: principais resultados. In: Boletim Epidemiológico n 16. 51st ed. Secretaria de Vigilância em Saúde/ Ministério da Saúde; 2020. p. 2026.  
16. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Vigitel Brasil 2019: Vigilância de Fatores de Risco e Proteção para Doenças Crônicas por Inquérito Telefônico. Brasília, DF.: Ministério da Saúde; 2020.  
17. BRASIL. VIGITEL Brasil 2018 População Negra. Brasília: Ministério da Saúde; 2019.  
18. Trayhurn P. The biology of obesity. Proc Nutr Soc. 2007/03/07. 2005;64(1):31–8.  
19. Jou C. The Biology and Genetics of Obesity — A Century of Inquiries. N Engl J Med. 2014 May;370(20):1874–7.  
20. Goodarzi MO. Genetics of obesity: what genetic association studies have taught us about the biology of obesity and its complications. Lancet Diabetes Endocrinol. 2018 Mar;6(3):223–36.  
21. WHO. Obesity and overweight. WHO. 2020.  
22. BRASIL. Cadernos de Atenção Básica: Estratégias para o cuidado da pessoa com doença  
358  
crônica - Obesidade. Ministério da Saúde. 2014.  
23. Ferreira RW, Caputo EL, Häfele CA, Jerônimo JS, Florindo AA, Knuth AG, et al. [Access to public physical activity programs in Brazil: National Health Survey, 2013]. Cad Saude Publica. 2019 Feb;35(2):e00008618.  
24. Guthold R, Stevens GA, Riley LM, Bull FC. Worldwide trends in insufficient physical activity from 2001 to 2016: a pooled analysis of 358 population-based surveys with 1·9 million participants. Lancet Glob Heal. 2018 Oct;6(10):e1077–86.  
25. Whitaker RC, Wright JA, Pepe MS, Seidel KD, Dietz WH. Predicting obesity in young adulthood from childhood and parental obesity. N Engl J Med. 1997 Sep;337(13):869–73.  
26. Qi Q, Chu AY, Kang JH, Huang J, Rose LM, Jensen MK, et al. Fried food consumption, genetic risk, and body mass index: gene-diet interaction analysis in three US cohort studies. BMJ. 2014 Mar;348:g1610.  
27. Rohde K, Keller M, la Cour Poulsen L, Blüher M, Kovacs P, Böttcher Y. Genetics and epigenetics in obesity. Metabolism. 2019 Mar;92:37–50.  
28. Livingstone KM, Celis-Morales C, Papandonatos GD, Erar B, Florez JC, Jablonski KA, et al. FTO genotype and weight loss: systematic review and meta-analysis of 9563 individual participant data from eight randomised controlled trials. BMJ. 2016 Sep;354:i4707.  
29. Francisqueti F, Nascimento A, Correa C. Obesidade, inflamação e complicações metabólicas. Rev da Soc Bras Aliment e Nutr. 2015 Jan;40:81–9.  
30. Ellulu MS, Patimah I, Khaza’ai H, Rahmat A, Abed Y. Obesity and inflammation: the linking mechanism and the complications. Arch Med Sci. 2016/03/31. 2017 Jun;13(4):851–63.  
31. Schwartz MW, Woods SC, Porte D, Seeley RJ, Baskin DG. Central nervous system control of food intake. Nature. 2000;404(6778):661–71.  
32. Pont SJ, Puhl R, Cook SR, Slusser W. Stigma Experienced by Children and Adolescents With Obesity. Pediatrics. 2017 Dec;140(6):e20173034.  
33. Prochaska JJ, Prochaska JO. A Review of Multiple Health Behavior Change Interventions for Primary Prevention. Am J Lifestyle Med. 2011 May;5(3).  
34. Robinson BE, Bacon JG, O’Reilly J. Fat phobia: measuring, understanding, and changing antifat attitudes. Int J Eat Disord. 1993 Dec;14(4):467–80.  
35. Bacon JG, Scheltema KE, Robinson BE. Fat phobia scale revisited: the short form. Int J Obes Relat Metab Disord. 2001 Feb;25(2):252–7.  
36. Stein J, Luppa M, Ruzanska U, Sikorski C, Konig H-H, Riedel-Heller SG. Measuring negative attitudes towards overweight and obesity in the German population - psychometric properties and reference values for the German short version of the Fat Phobia Scale (FPS). PLoS One. 2014;9(12):e114641.  
37. Paim MB. Os corpos gordos merecem ser vividos . Vol. 27, Revista Estudos Feministas . scielo ; 2019.  
38. Weinberger N-A, Kersting A, Riedel-Heller SG, Luck-Sikorski C. Body Dissatisfaction in Individuals with Obesity Compared to Normal-Weight Individuals: A Systematic Review and Meta-Analysis. Obes Facts. 2016;9(6):424–41.  
39. Chao H-L. Body image change in obese and overweight persons enrolled in weight loss intervention programs: a systematic review and meta-analysis. PLoS One. 2015;10(5):e0124036.  
40. Enzi G. Socioeconomic consequences of obesity: the effect of obesity on the individual. Pharmacoeconomics. 1994;5(Suppl 1):54–7.  
41. Wellman NS. Causes and consequences of adult obesity: health, social and economic impacts in the United States. Asia Pac J Clin Nutr. 2003;11(S8):S705–9.  
42. Cawley J. An economy of scales: A selective review of obesity’s economic causes, consequences, and solutions. J Health Econ. 2015 Sep;43:244–68.  
43. Teachman BA, Brownell KD. Implicit anti-fat bias among health professionals: is anyone  
359  
- immune? Int J Obes. 2001;25(10):1525–31.  
44. Kirk S, Ramos Salas X, Alberga A, Russell-Mayhew S. Canadian Adult Obesity Clinical Practice Guidelines: Reducing Weight Bias, Stigma and Discrimination in Obesity Management, Practice and Policy. Obesity Canada. 2020.  
45. Tomiyama AJ, Carr D, Granberg EM, Major B, Robinson E, Sutin AR, et al. How and why weight stigma drives the obesity ‘epidemic’ and harms health. BMC Med. 2018;16(1):123.  
46. Rubino F, Puhl RM, Cummings DE, Eckel RH, Ryan DH, Mechanick JI, et al. Joint international consensus statement for ending stigma of obesity. Nat Med. 2020/03/04. 2020 Apr;26(4):485–97.  
47. Silva B, Cantisani J. INTERFACES ENTRE A GORDOFOBIA E A FORMAÇÃO ACADÊMICA EM NUTRIÇÃO: UM DEBATE NECESSÁRIO. DEMETRA Aliment Nutr Saúde. 2018 Jul;13.  
48. Alberga AS, Edache IY, Forhan M, Russell-Mayhew S. Weight bias and health care utilization: a scoping review. Prim Health Care Res Dev. 2019 Jul;20:e116–e116.  
49. Wharton S, Lau DCW, Vallis M, Sharma AM, Biertho L, Campbell-Scherer D, et al. Obesity in adults: a clinical practice guideline. Can Med Assoc J. 2020 Aug;192(31):E875 LP-E891.  
50. Withrow D, Alter DA. The economic burden of obesity worldwide: a systematic review of the direct costs of obesity. Obes Rev. 2011 Feb;12(2):131–41.  
51. Bahia L, Araújo DV. Impacto econômico da obesidade no Brasil. Rev HUPE. 2014;13(1):13–7.  
52. Schünemann HJ, Wiercioch W, Etxeandia I, Falavigna M, Santesso N, Mustafa R, et al. Guidelines 2.0: Systematic development of a comprehensive checklist for a successful guideline enterprise. CMAJ. 2014;  
53. Wolfenden L, Ezzati M, Larijani B, Dietz W. The challenge for global health systems in preventing and managing obesity. Obes Rev. 2019 Nov;20 Suppl 2:185–93.  
54. Semlitsch T, Stigler FL, Jeitler K, Horvath K, Siebenhofer A. Management of overweight and obesity in primary care-A systematic overview of international evidence-based guidelines. Obes Rev. 2019 Sep;20(9):1218–30.  
55. WHO. Obesity: preventing and managing the global epidemic. Report of a WHO Consultation (WHO Technical Report Series 894). 2003.  
56. ABESO. Diretrizes brasileiras de obesidade 2016 / ABESO - Associação Brasileira para o Estudo da Obesidade e da Síndrome Metabólica. 4a ed. Associação Brasileira para o Estudo da Obesidade e da Síndrome Metabólica. São Paulo; 2016.  
57. Rezende FAC, Rosado LEFPL, Ribeiro R de CL, Vidigal F de C, Vasques ACJ, Bonard IS, et al. Body mass index and waist circumference: association with cardiovascular risk factors. Arq Bras Cardiol. 2006 Dec;87(6):728–34.  
58. BRASIL. Orientações para a coleta e análise de dados antropométricos em serviços de saúde: Norma técnica do Sistema de Vigilância Alimentar e Nutricional - SISVAN. Ministério da Saúde. 2011.  
59. BRASIL. Marco de Referência da Vigilância Alimentar e Nutricional na Atenção Básica. Ministério da Saúde. 2015.  
60. Lund TB, Sandoe P, Lassen J. Attitudes to publicly funded obesity treatment and prevention. Obesity (Silver Spring). 2011 Aug;19(8):1580–5.  
61. BRASIL. Política Nacional de Atenção Básica. Brasília: Ministério da Saúde; 2012.  
62. Lombard CB, Deeks AA, Teede HJ. A systematic review of interventions aimed at the prevention of weight gain in adults. Public Health Nutr. 2009 Nov;12(11):2236–46.  
63. Lemmens VEPP, Oenema A, Klepp KI, Henriksen HB, Brug J. A systematic review of the evidence regarding efficacy of obesity prevention interventions among adults. Obes Rev. 2008 Sep;9(5):446–55.  
64. BRASIL. Política Nacional de Alimentação e Nutrição (PNAN). Ministério da Saúde. 2013.  
65. NICE. Obesity: identification, assessment and management. NICE Clinical Guidance. 2014.  
66. Jones PR, Ekelund U. Physical Activity in the Prevention of Weight Gain: the Impact of  
360  
- Measurement and Interpretation of Associations. Curr Obes Rep. 2019 Jun;8(2):66–76.  
67. Swinburn BA, Kraak VI, Allender S, Atkins VJ, Baker PI, Bogard JR, et al. The Global Syndemic of Obesity, Undernutrition, and Climate Change: The Lancet  Commission report. Lancet (London, England). 2019 Feb;393(10173):791–846.  
68. Egger G, Swinburn B. An “ecological” approach to the obesity pandemic. BMJ. 1997 Aug;315(7106):477–80.  
69. Gargallo Fernandez Manuel M, Breton Lesmes I, Basulto Marset J, Quiles Izquierdo J, Formiguera Sala X, Salas-Salvado J. Evidence-based nutritional recommendations for the prevention and treatment of overweight and obesity in adults (FESNAD-SEEDO consensus document). The role of diet in obesity treatment (III/III). Nutr Hosp. 2012;27(3):833–64.  
70. Jensen MD, Ryan DH, Apovian CM, Ard JD, Comuzzie AG, Donato KA, et al. 2013 AHA/ACC/TOS guideline for the management of overweight and obesity in adults: a report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines and The Obesity Society. Circulation. 2014 Jun;129(25 Suppl 2):S102-38.  
71. Raynor HA, Champagne CM. Position of the Academy of Nutrition and Dietetics: Interventions for the Treatment of Overweight and Obesity in Adults. J Acad Nutr Diet. 2016 Jan;116(1):129–47.  
72. Franz MJ, VanWormer JJ, Crain AL, Boucher JL, Histon T, Caplan W, et al. Weight-loss outcomes: a systematic review and meta-analysis of weight-loss clinical trials with a minimum 1-year follow-up. J Am Diet Assoc. 2007 Oct;107(10):1755–67.  
73. Blackburn G. Effect of degree of weight loss on health benefits. Obes Res. 1995 Sep;3 Suppl 2:211s-216s.  
74. CDC. Losing Weight. CDC. 2020.  
75. Vallis M. Quality of life and psychological well-being in obesity management: improving the odds of success by managing distress. Int J Clin Pract. 2016 Mar;70(3):196–205.  
76. van Gemert WAM, van der Palen J, Monninkhof EM, Rozeboom A, Peters R, Wittink H, et al. Quality of Life after Diet or Exercise-Induced Weight Loss in Overweight to Obese Postmenopausal Women: The SHAPE-2 Randomised Controlled Trial. PLoS One. 2015;10(6):e0127520.  
77. Noël PH, Pugh JA. Management of overweight and obese adults. BMJ. 2002 Oct;325(7367):757–61.  
78. Knowler WC, Barrett-Connor E, Fowler SE, Hamman RF, Lachin JM, Walker EA, et al. Reduction in the incidence of type 2 diabetes with lifestyle intervention or metformin. N Engl J Med. 2002 Feb;346(6):393–403.  
79. Look AHEAD Research Group. Eight-year weight losses with an intensive lifestyle intervention: the look AHEAD study. Obesity (Silver Spring). 2014 Jan;22(1):5–13.  
80. BRASIL. Guia alimentar para a população Brasileira. 2a ed. Melo EA, editor. Ministério da Saúde. Ministério da Saúde; 2014.  
81. Kahan S, Manson JE. Obesity Treatment, Beyond the Guidelines: Practical Suggestions for Clinical Practice. JAMA. 2019 Apr;321(14):1349–50.  
82. Beslay M, Srour B, Méjean C, Allès B, Fiolet T, Debras C, et al. Ultra-processed food intake in association with BMI change and risk of overweight and obesity: A prospective analysis of the French NutriNet-Santé cohort. PLoS Med. 2020 Aug;17(8):e1003256–e1003256.  
83. Costa CDS, Assunção MCF, Loret de Mola C, Cardoso J de S, Matijasevich A, Barros AJD, et al. Role of ultra-processed food in fat mass index between 6 and 11 years of age: a cohort study. Int J Epidemiol. 2020 Sep;  
84. Elizabeth L, Machado P, Zinöcker M, Baker P, Lawrence M. Ultra-Processed Foods and Health Outcomes: A Narrative Review. Nutrients. 2020 Jun;12(7).  
85. Hall KD, Ayuketah A, Brychta R, Cai H, Cassimatis T, Chen KY, et al. Ultra-Processed Diets Cause Excess Calorie Intake and Weight Gain: An Inpatient Randomized Controlled Trial of Ad  
361  
Libitum Food Intake. Cell Metab. 2019 Jul;30(1):67-77.e3.  
86. Pagliai G, Dinu M, Madarena MP, Bonaccio M, Iacoviello L, Sofi F. Consumption of ultraprocessed foods and health status: a systematic review and meta-analysis. Br J Nutr. 2020 Aug;1–11.  
87. Silva Meneguelli T, Viana Hinkelmann J, Hermsdorff HHM, Zulet MÁ, Martínez JA, Bressan J. Food consumption by degree of processing and cardiometabolic risk: a systematic review. Int J Food Sci Nutr. 2020 Sep;71(6):678–92.  
88. Askari M, Heshmati J, Shahinfar H, Tripathi N, Daneshzad E. Ultra-processed food and the risk of overweight and obesity: a systematic review and meta-analysis of observational studies. Int J Obes [Internet]. 2020;44(10):2080–91. Available from: https://doi.org/10.1038/s41366-02000650-z  
89. Santos FS Dos, Dias M da S, Mintem GC, Oliveira IO de, Gigante DP. Food processing and cardiometabolic risk factors: a systematic review. Rev Saude Publica [Internet]. 2020/07/24. 2020;54:70. Available from: https://pubmed.ncbi.nlm.nih.gov/32725096  
90. Chen X, Zhang Z, Yang H, Qiu P, Wang H, Wang F, et al. Consumption of ultra-processed foods and health outcomes: a systematic review of epidemiological studies. Nutr J. 2020 Aug;19(1):86.  
91. Gombi-Vaca MF, Sichieri R, Verly EJ. Caloric compensation for sugar-sweetened beverages in meals: A population-based study in Brazil. Appetite. 2016 Mar;98:67–73.  
92. WHO. Healthy Diet - WHO FAct Sheet no. 394. WHO Fact Sheet. 2018.  
93. Oliveira D, Galhardo J, Ares G, Cunha LM, Deliza R. Sugar reduction in fruit nectars: Impact on consumers’ sensory and hedonic perception. Food Res Int. 2018 May;107:371–7.  
94. Pearlman M, Obert J, Casey L. The Association Between Artificial Sweeteners and Obesity. Curr Gastroenterol Rep. 2017 Nov;19(12):64.  
95. 5. Facilitating Behavior Change and Well-being to Improve Health Outcomes: &lt;em&gt;Standards of Medical Care in Diabetes—2020&lt;/em&gt; Diabetes Care. 2020 Jan;43(Supplement 1):S48 LP-S65.  
96. Caspersen CJ, Powell KE, Christenson GM. Physical activity, exercise, and physical fitness: definitions and distinctions for health-related research. Public Health Rep. 1985;100(2):126– 31.  
97. WHO. Global Recommendations on Physical Activity for Health. WHO. 2010.  
98. Pettee Gabriel KK, Morrow JRJ, Woolsey A-LT. Framework for physical activity as a complex and multidimensional behavior. J Phys Act Health. 2012 Jan;9 Suppl 1:S11-8.  
99. World Health Organization. More active people for a healthier world : global action plan on physical activity 2018-2030. 101 p.  
100. Tremblay MS, Aubert S, Barnes JD, Saunders TJ, Carson V, Latimer-Cheung AE, et al. Sedentary Behavior Research Network (SBRN) - Terminology Consensus Project process and outcome. Int J Behav Nutr Phys Act. 2017 Jun;14(1):75.  
101. Piercy KL, Troiano RP, Ballard RM, Carlson SA, Fulton JE, Galuska DA, et al. The Physical Activity Guidelines for Americans. JAMA. 2018 Nov;320(19):2020–8.  
102. Reis EC dos. Avaliação do componente ambulatorial especializado da linha de cuidado para obesidade grave na cidade do Rio de Janeiro. Fundação Oswaldo Cruz; 2018.  
103. WHO. ACTIVE: a technical package for increasing physical activity. WHO. 2018.  
104. Warburton DER, Bredin SSD. Reflections on Physical Activity and Health: What Should We Recommend? Can J Cardiol. 2016 Apr;32(4):495–504.  
105. Yumuk V, Tsigos C, Fried M, Schindler K, Busetto L, Micic D, et al. European Guidelines for Obesity Management in Adults. Obes Facts. 2015;8(6):402–24.  
106. Haynes A, Kersbergen I, Sutin A, Daly M, Robinson E. Does perceived overweight increase risk of depressive symptoms and suicidality beyond objective weight status? A systematic review and meta-analysis. Clin Psychol Rev. 2019 Nov;73:101753.  
362  
107. Silva DA, Coutinho E da SF, Ferriani LO, Viana MC. Depression subtypes and obesity in adults: A systematic review and meta-analysis. Obes Rev. 2020 Mar;21(3):e12966.  
108. Miller W, Rollnik S. Talking Oneself Into Change: Motivational Interviewing, Stages of Change, and Therapeutic Process Title. J Cogn Psychother. 2004;18(4):299–308.  
109. Miller WR, Rollnick S. Ten things that motivational interviewing is not. Behav Cogn Psychother. 2009 Mar;37(2):129–40.  
110. BECK AT. THINKING AND DEPRESSION. II. THEORY AND THERAPY. Arch Gen Psychiatry. 1964 Jun;10:561–71.  
111. Wenzel A. Basic Strategies of Cognitive Behavioral Therapy. Psychiatr Clin North Am. 2017 Dec;40(4):597–609.  
112. Cooper Z, Fairburn C, Hawker D. Cognitive-behavioral treatment of obesity: A clinician’s guide. New York: Guilford Press; 2003. 232–xiii p.  
113. BRASIL. Ministério da Saúde. Política nacional de práticas integrativas e complementares no SUS: atitude de ampliação de acesso. 2a. ed. [Internet] [Internet]. Brasília, DF.: Ministério da Saúde; 2015 [cited 2020 Mar 27]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/politica_nacional_praticas_integrativas_comple mentares_2ed.pdf  
114. Yang K. A review of yoga programs for four leading risk factors of chronic diseases. Evid Based Complement Alternat Med. 2007 Dec;4(4):487–91.  
115. Lauche R, Langhorst J, Lee MS, Dobos G, Cramer H. A systematic review and meta-analysis on the effects of yoga on weight-related outcomes. Prev Med (Baltim). 2016 Jun;87:213–32.  
116. Zheng G, Huang M, Liu F, Li S, Tao J, Chen L. Tai chi chuan for the primary prevention of stroke in middle-aged and elderly adults: a systematic review. Evid Based Complement Alternat Med. 2015;2015:742152.  
117. Kim S-Y, Shin I-S, Park Y-J. Effect of acupuncture and intervention types on weight loss: a systematic review and meta-analysis. Obes Rev an Off J Int Assoc Study Obes. 2018 Nov;19(11):1585–96.  
118. Huang C-F, Guo S-E, Chou F-H. Auricular acupressure for overweight and obese individuals: A systematic review and meta-analysis. Medicine (Baltimore). 2019 Jun;98(26):e16144.  
119. BRASIL. Portaria de Consolidação n<sup>o</sup> 3, de 28 de setembro de 2017. Consolidação das normas sobre as redes do Sistema Único de Saúde. Anexo IV - Rede de Atenção à Saúde das Pessoas com Doenças, Anexo 1 – Diretrizes gerais para o tratamento cirúrgico da obesidade. 2017.  
120. Farpour-Lambert NJ, Ells LJ, Martinez de Tejada B, Scott C. Obesity and Weight Gain in Pregnancy and Postpartum: an Evidence Review of Lifestyle Interventions to Inform Maternal and Child Health Policies. Front Endocrinol (Lausanne). 2018;9:546.  
121. Poston L, Caleyachetty R, Cnattingius S, Corvalan C, Uauy R, Herring S, et al. Preconceptional and maternal obesity: epidemiology and health consequences. lancet Diabetes Endocrinol. 2016 Dec;4(12):1025–36.  
122. BRASIL. Vigilância alimentar e nutricional - Sisvan: orientações básicas para a coleta, processamento, análise de dados e informação em serviços de saúde. Brasília; 2004. 120 p.  
123. ANZOS. Australian Obesity Management Algorithm. Society ANZO. 2015.  
124. NICE. Weight management before, during and after pregnancy. NICE. 2010.  
125. Mottola MF, Davenport MH, Ruchat S-M, Davies GA, Poitras VJ, Gray CE, et al. 2019 Canadian guideline for physical activity throughout pregnancy. Br J Sports Med. 2018 Nov;52(21):1339 LP – 1346.  
126. Sekula M, Boniecka I, Pasnik K. Bulimia nervosa in obese patients qualified for bariatric surgery - clinical picture, background and treatment. Wideochirurgia i inne Tech maloinwazyjne = Videosurgery other miniinvasive Tech. 2019 Sep;14(3):408–14.  
127. Burrows T, Skinner J, McKenna R, Rollo M. Food Addiction, Binge Eating Disorder, and Obesity: Is There a Relationship? Behav Sci (Basel, Switzerland). 2017 Aug;7(3).  
363  
128. Brownley KA, Berkman ND, Peat CM, Lohr KN, Cullen KE, Bann CM, et al. Binge-Eating Disorder in Adults: A Systematic Review and Meta-analysis. Ann Intern Med. 2016/06/28. 2016 Sep;165(6):409–20.  
129. de Zwaan M. Binge eating disorder and obesity. Int J Obes Relat Metab Disord. 2001 May;25 Suppl 1:S51-5.  
130. Vaidya V, Malik A. Eating disorders related to obesity. Futur Med. 2008;5(1):109–17.  
131. Wadden TA, West DS, Delahanty L, Jakicic J, Rejeski J, Williamson D, et al. The Look AHEAD study: a description of the lifestyle intervention and the evidence supporting it. Obesity (Silver Spring). 2006 May;14(5):737–52.  
132. Kahan SI. Practical Strategies for Engaging Individuals With Obesity in Primary Care. Mayo Clin Proc. 2018 Mar;93(3):351–9.  
133. Erlandson M, Ivey LC, Seikel K. Update on Office-Based Strategies for the Management of Obesity. Am Fam Physician. 2016 Sep;94(5):361–8.  
134. Dias PC, Henriques P, Anjos LA dos, Burlandy L. Obesidade e políticas públicas: concepções e estratégias adotadas pelo governo brasileiro . Vol. 33, Cadernos de Saúde Pública . scielo ; 2017.  
135. BRASIL. Alimentação Cardioprotetora. Ministério da Saúde. 2018.  
136. BRASIL. Alimentação Cardioprotetora: Manual de orientações para profissionais de Saúde da Atenção Básica. Ministério da Saúde. 2018.  
137. WHO. Waist Circumference and Waist-Hip Ratio: Report of a WHO Expert Consultation. WHO. 2008.  
138. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: A critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;  
139. Higgins JPT, Altman DG, Gøtzsche PC, Jüni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. BMJ. 2011 Oct;343:d5928.  
140. Wells GA, Shea B, O’Connell D, Peterson J, Welch V, Losos M et al. The Newcastle-Ottawa Scale (NOS) for assessing the quality if nonrandomized studies in meta-analyses. 2012.  
141. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008 Apr;336(7650):924–6.  
142. Moberg J, Oxman AD, Rosenbaum S, Schunemann HJ, Guyatt G, Flottorp S, et al. The GRADE Evidence to Decision (EtD) framework for health system and public health decisions. Heal Res policy Syst. 2018 May;16(1):45.  
143. Ard JD, Gower B, Hunter G, Ritchie CS, Roth DL, Goss A, et al. Effects of Calorie Restriction in Obese Older Adults: The CROSSROADS Randomized Controlled Trial. 2017;73(1):73–80.  
144. Van Gemert WA, May AM, Schuit AJ, Oosterhof BYM, Peeters PH, Monninkhof EM. Effect of weight loss with or without exercise on inflammatory markers and adipokines in postmenopausal women: The SHAPE-2 Trial, a randomized controlled trial. 2016;25(5):799– 806.  
145. Bertz F, Brekke HK, Ellegard L, Rasmussen KM, Wennergren M, Winkvist A. Diet and exercise weight-loss trial in lactating overweight and obese women. 2012;96(4):698–705.  
146. Brekke HK, Bertz F, Rasmussen KM, Bosaeus I, Ellegård L, Winkvist A. Diet and exercise interventions among overweight and obese lactating women: Randomized trial of effects on cardiovascular risk factors. 2014;9(2).  
147. Nordby P, Auerbach PL, Rosenkilde M, Kristiansen L, Thomasen JR, Rygaard L, et al. Endurance training per se increases metabolic health in young, moderately overweight men. 2012;20(11):2202–12.  
148. Villareal DT, Chode S, Parimi N, Sinacore DR, Hilton T, Armamento-Villareal R, et al. Weight loss, exercise, or both and physical function in obese older adults. 2011;364(13):1218–29.  
364  
149. Bouchonville M, Armamento-Villareal R, Shah K, Napoli N, Sinacore DR, Qualls C, et al. Weight loss, exercise or both and cardiometabolic risk factors in obese older adults: results of a randomized controlled trial. 2014;38(3):423–31.  
150. Ross R, Janssen I, Dawson J, Kungl AM, Kuk JL, Wong SL, et al. Exercise-induced reduction in obesity and insulin resistance in women: a randomized controlled trial. 2004;12(5):789–98.  
151. Ross R, Dagnone D, Jones PJH, Smith H, Paddags A, Hudson R, et al. Reduction in obesity and related comorbid conditions after diet-induced weight loss or exercise-induced weight loss in men: A randomized, controlled trial. 2000;133(2):92–103.  
152. Thong FSL, Hudson R, Ross R, Janssen IAN, Graham TE. Plasma leptin in moderately obese men: Independent effects of weight loss and aerobic exercise. 2000;279(2):E307–13.  
153. Huseinovic E, Bertz F, Leu Agelii M, Hellebo Johansson E, Winkvist A, Brekke HK. Effectiveness of a weight loss intervention in postpartum women: results from a randomized controlled trial in primary health care. 2016;104(2):362–70.  
154. Fernandes JFR, Da Silva Araújo L, Kaiser SE, Sanjuliani AF, Klein MRST. The effects of moderate energy restriction on apnoea severity and CVD risk factors in obese patients with obstructive sleep apnoea. 2015;114(12):2022–31.  
155. Vissers D, Verrijken A, Mertens I, Van Gils C, Van De Sompel A, Truijen S, et al. Effect of longterm whole body vibration training on visceral adipose tissue: A preliminary report. 2010;3(2):93–100.  
156. Straznicky NE, Lambert EA, Nestel PJ, McGrane MT, Dawood T, Schlaich MP, et al. Sympathetic neural adaptation to hypocaloric diet with or without exercise training in obese metabolic syndrome subjects. 2010;59(1):71–9.  
157. Khoo J, Dhamodaran S, Chen DD, Yap SY, Chen RY, Tian RH. Exercise-Induced Weight Loss is More Effective than Dieting for Improving Adipokine Profile, Insulin Resistance, and Inflammation in Obese Men. 2015;25(6):566–75.  
158. Nicklas BJ, Chmelo E, Delbono O, Carr JJ, Lyles MF, Marsh AP. Effects of resistance training with and without caloric restriction on physical function and mobility in overweight and obese older adults: A randomized controlled trial. 2015;101(5):991–9.  
159. Yassine HN, Marchetti CM, Krishnan RK, Vrobel TR, Gonzalez F, Kirwan JP. Effects of exercise and caloric restriction on insulin resistance and cardiometabolic risk factors in older obese adults - A randomized clinical trial. 2009;64(1):90–5.  
160. Amati F, Dube JJ, Shay C, Goodpaster BH. Separate and combined effects of exercise training and weight loss on exercise efficiency and substrate oxidation. 2008;105(3):825–31.  
161. O’Leary VB, Jorett AE, Marchetti CM, Gonzalez F, Phillips SA, Ciaraldi TP, et al. Enhanced adiponectin multimer ratio and skeletal muscle adiponectin receptor expression following exercise training and diet in older insulin-resistant adults. 2007;293(1):E421–7.  
162. Kittiskulnam P, Kanjanabuch T, Tangmanjitjaroen K, Chancharoenthana W, Praditpornsilpa K, Eiam-Ong S. The beneficial effects of weight reduction in overweight patients with chronic proteinuric immunoglobulin a nephropathy: a randomized controlled trial. 2014;24(3):200–7.  
163. Westman EC, Yancy Jr. WS, Mavropoulos JC, Marquart M, McDuffie JR. The effect of a lowcarbohydrate, ketogenic diet versus a low-glycemic index diet on glycemic control in type 2 diabetes mellitus. 2008;5:36.  
164. Samaha FF, Iqbal N, Seshadri P, Chicano KL, Daily DA, McGrory J, et al. A low-carbohydrate as compared with a low-fat diet in severe obesity. 2003;348(21):2074–81.  
165. Stern L, Iqbal N, Seshadri P, Chicano KL, Daily DA, McGrory J, et al. The effects of lowcarbohydrate versus conventional weight loss diets in severely obese adults: one-year followup of a randomized trial. 2004;140(10):778–85.  
166. Cardillo S, Seshadri P, Iqbal N. The effects of low-carbohydrate versus low-fat diet on asdipocytokines in severely obese adult: Three-year follow-up of a randomized trial. 2006;10(3):99–106.  
365  
167. Yancy Jr. WS, Olsen MK, Guyton JR, Bakst RP, Westman EC. A low-carbohydrate, ketogenic diet versus a low-fat diet to treat obesity and hyperlipidemia: a randomized, controlled trial. 2004;140(10):769–77.  
168. Azad MB, Abou-Setta AM, Chauhan BF, Rabbani R, Lys J, Copstein L, et al. Nonnutritive sweeteners and cardiometabolic health: a systematic review and meta-analysis of randomized controlled trials and prospective cohort studies. CMAJ. 2017 Jul;189(28):E929–39.  
169. Miller PE, Perez V. Low-calorie sweeteners and body weight and composition: a meta-analysis of randomized controlled trials and prospective cohort studies. Am J Clin Nutr. 2014 Sep;100(3):765–77.  
170. Kaiser KA, Shikany JM, Keating KD, Allison DB. Will reducing sugar-sweetened beverage consumption reduce obesity? Evidence supporting conjecture is strong, but evidence when testing effect is weak. Obes Rev. 2013 Aug;14(8):620–33.  
171. Mattes RD, Shikany JM, Kaiser KA, Allison DB. Nutritively sweetened beverage consumption and body weight: a systematic review and meta-analysis of randomized experiments. Obes Rev. 2011 May;12(5):346–65.  
172. Rogers PJ, Hogenkamp PS, de Graaf C, Higgs S, Lluch A, Ness AR, et al. Does low-energy sweetener consumption affect energy intake and body weight? A systematic review, including meta-analyses, of the evidence from human and animal studies. Int J Obes (Lond). 2016 Mar;40(3):381–94.  
173. Markey O, Le Jeune J, Lovegrove JA. Energy compensation following consumption of sugarreduced products: a randomized controlled trial. Eur J Nutr. 2016 Sep;55(6):2137–49.  
174. Sharma A, Hauck K, Hollingsworth B, Siciliani L. The effects of taxing sugar-sweetened beverages across different income groups. Health Econ. 2014 Sep;23(9):1159–84.  
175. Briggs ADM, Mytton OT, Kehlbacher A, Tiffin R, Elhussein A, Rayner M, et al. Health impact assessment of the UK soft drinks industry levy: a comparative risk assessment modelling study. Lancet Public Heal. 2017 Jan;2(1):e15–22.  
176. Sanchez-Romero LM, Penko J, Coxson PG, Fernandez A, Mason A, Moran AE, et al. Projected Impact of Mexico’s Sugar-Sweetened Beverage Tax Policy on Diabetes and Cardiovascular Disease: A Modeling Study. PLoS Med. 2016 Nov;13(11):e1002158.  
177. Viester L, Verhagen EALM, Bongers PM, van der Beek AJ. Effectiveness of a Worksite Intervention for Male Construction Workers on Dietary and Physical Activity Behaviors, Body Mass Index, and Health Outcomes: Results of a Randomized Controlled Trial. Am J Health Promot. 2018 Mar;32(3):795–805.  
178. Chen L, Appel LJ, Loria C, Lin P-H, Champagne CM, Elmer PJ, et al. Reduction in consumption of sugar-sweetened beverages is associated with weight loss: the PREMIER trial. Am J Clin Nutr. 2009 May;89(5):1299–306.  
179. Stookey JD, Constant F, Popkin BM, Gardner CD. Drinking water is associated with weight loss in overweight dieting women independent of diet and activity. Obesity (Silver Spring). 2008 Nov;16(11):2481–8.  
180. Vartanian LR, Schwartz MB, Brownell KD. Effects of soft drink consumption on nutrition and health: a systematic review and meta-analysis. Am J Public Health. 2007 Apr;97(4):667–75.  
181. Rosado JL, García OP, Ronquillo D, Hervert D, Rodríguez G, Gutierrez J, et al. The inclusion of milk fortified with micronutrients increases the effectiveness of a calorie restricted diet to reduce obesity in women. FASEB J. 2009;23(S1).  
182. Tate DF, Turner-McGrievy G, Stevens J, Erickson K, Polzien K, Diamond M, et al. Replacing caloric beverages with water or diet beverages for weight loss in adults: Results of a 6-month randomized controlled trial. In: 29th Annual Scientific Meeting of the Obesity-Society. Obesity; 2011. p. S68.  
183. Hernandez-Cordero S, Barquera S, Rodriguez-Ramirez S, Villanueva-Borbolla MA, Gonzalez de Cossio T, Dommarco JR, et al. Substituting water for sugar-sweetened beverages reduces  
366  
circulating triglycerides and the prevalence of metabolic syndrome in obese but not in overweight Mexican women in a randomized controlled trial. J Nutr. 2014 Nov;144(11):1742– 52.  
184. Tate DF, Turner-McGrievy G, Lyons E, Stevens J, Erickson K, Polzien K, et al. Replacing caloric beverages with water or diet beverages for weight loss in adults: main results of the Choose Healthy Options Consciously Everyday (CHOICE) randomized clinical trial. Am J Clin Nutr. 2012 Mar;95(3):555–63.  
185. Basto-Abreu A, Braverman-Bronstein A, Camacho-Garcia-Formenti D, Zepeda-Tello R, Popkin BM, Rivera-Dommarco J, et al. Expected changes in obesity after reformulation to reduce added sugars in beverages: A modeling study. PLoS Med. 2018 Oct;15(10):e1002664.  
186. Barrientos-Gutierrez T, Zepeda-Tello R, Rodrigues ER, Colchero MA, Rojas-Martinez R, Lazcano-Ponce E, et al. Expected population weight and diabetes impact of the 1-peso-perlitre tax to sugar sweetened beverages in Mexico. PLoS One. 2017;12(5):e0176336.  
187. Schwendicke F, Stolpe M. Taxing sugar-sweetened beverages: impact on overweight and obesity in Germany. BMC Public Health. 2017 Jan;17(1):88.  
188. Duffey KJ, Poti J. Modeling the Effect of Replacing Sugar-Sweetened Beverage Consumption with Water on Energy Intake, HBI Score, and Obesity Prevalence. Nutrients. 2016 Jun;8(7).  
189. Ma Y, He FJ, Yin Y, Hashem KM, MacGregor GA. Gradual reduction of sugar in soft drinks without substitution as a strategy to reduce overweight, obesity, and type 2 diabetes: a modelling study. lancet Diabetes Endocrinol. 2016 Feb;4(2):105–14.  
190. Ruff RR, Zhen C. Estimating the effects of a calorie-based sugar-sweetened beverage tax on weight and obesity in New York City adults using dynamic loss models. Ann Epidemiol. 2015 May;25(5):350–7.  
191. Dharmasena S, Capps OJ. Intended and unintended consequences of a proposed national tax on sugar-sweetened beverages to combat the U.S. obesity problem. Health Econ. 2012 Jun;21(6):669–94.  
192. Lin B-H, Smith TA, Lee J-Y, Hall KD. Measuring weight outcomes for obesity intervention strategies: the case of a sugar-sweetened beverage tax. Econ Hum Biol. 2011 Dec;9(4):329– 41.  
193. Mullie P, Aerenhouts D, Clarys P. Demographic, socioeconomic and nutritional determinants of daily versus non-daily sugar-sweetened and artificially sweetened beverage consumption. Eur J Clin Nutr. 2012 Feb;66(2):150–5.  
194. Hendriksen MA, Tijhuis MJ, Fransen HP, Verhagen H, Hoekstra J. Impact of substituting added sugar in carbonated soft drinks by intense sweeteners in young adults in the Netherlands: example of a benefit-risk approach. Eur J Nutr. 2011 Feb;50(1):41–51.  
195. Mosdol A, Vist GE, Svendsen C, Dirven H, Lillegaard ITL, Mathisen GH, et al. Hypotheses and evidence related to intense sweeteners and effects on appetite and body weight changes: A scoping review of reviews. PLoS One. 2018;13(7):e0199558.  
196. De La Hunty A, Gibson S, Ashwell M. A review of the effectiveness of aspartame in helping with weight control. Nutr Bull. 2006 Jun;31(2):115–28.  
197. Han Y, Kwon E-Y, Yu MK, Lee SJ, Kim H-J, Kim S-B, et al. A Preliminary Study for Evaluating the Dose-Dependent Effect of d-Allulose for Fat Mass Reduction in Adult Humans: A Randomized, Double-Blind, Placebo-Controlled Trial. Nutrients. 2018 Jan;10(2).  
198. Knopp RH, Brandt K, Arky RA. Effects of aspartame in young persons during weight reduction. J Toxicol Environ Health. 1976 Nov;2(2):417–28.  
199. Kanders BS, Lavin PT, Kowalchuk MB, Greenberg I, Blackburn GL. An evaluation of the effect of aspartame on weight loss. Appetite. 1988;11 Suppl 1:73–84.  
200. Blackburn GL, Kanders BS, Lavin PT, Keller SD, Whatley J. The effect of aspartame as part of a multidisciplinary weight-control program on short- and long-term control of body weight. Am J Clin Nutr. 1997 Feb;65(2):409–18.  
367  
201. Peters JC, Wyatt HR, Foster GD, Pan Z, Wojtanowski AC, Vander Veur SS, et al. The effects of water and non-nutritive sweetened beverages on weight loss during a 12-week weight loss treatment program. Obesity (Silver Spring). 2014 Jun;22(6):1415–21.  
202. Peters JC, Beck J, Cardel M, Wyatt HR, Foster GD, Pan Z, et al. The effects of water and nonnutritive sweetened beverages on weight loss and weight maintenance: A randomized clinical trial. Obesity (Silver Spring). 2016 Feb;24(2):297–304.  
203. Madjd A, Taylor MA, Delavari A, Malekzadeh R, Macdonald IA, Farshchi HR. Effects on weight loss in adults of replacing diet beverages with water during a hypoenergetic diet: a randomized, 24-wk clinical trial. Am J Clin Nutr. 2015 Dec;102(6):1305–12.  
204. Ballantyne C, Hammersley R, Reid M. Effects of sucrose added blind to the diet over eight weeks on body mass and mood in men. Appetite. 2011;57.  
205. Toews I, Lohner S, Kullenberg de Gaudry D, Sommer H, Meerpohl JJ. Association between intake of non-sugar sweeteners and health outcomes: systematic review and meta-analyses of randomised and non-randomised controlled trials and observational studies. BMJ. 2019 Jan;364:k4718.  
206. Maersk M, Belza A, Stodkilde-Jorgensen H, Ringgaard S, Chabanova E, Thomsen H, et al. Sucrose-sweetened beverages increase fat storage in the liver, muscle, and visceral fat depot: a 6-mo randomized intervention study. Am J Clin Nutr. 2012 Feb;95(2):283–9.  
207. Raben A, Vasilaras TH, Moller AC, Astrup A. Sucrose compared with artificial sweeteners: different effects on ad libitum food intake and body weight after 10 wk of supplementation in overweight subjects. Am J Clin Nutr. 2002 Oct;76(4):721–9.  
208. Reid M, Hammersley R, Duffy M. Effects of sucrose drinks on macronutrient intake, body weight, and mood state in overweight women over 4 weeks. Appetite. 2010 Aug;55(1):130–6.  
209. Reid M, Hammersley R, Duffy M, Ballantyne C. Effects on obese women of the sugar sucrose added to the diet over 28 d: a quasi-randomised, single-blind, controlled trial. Br J Nutr. 2014 Feb;111(3):563–70.  
210. Schoenfeld BJ, Aragon AA, Krieger JW. Effects of meal frequency on weight loss and body composition: a meta-analysis. Nutr Rev. 2015 Feb;73(2):69–82.  
211. Bachman JL, Phelan S, Wing RR, Raynor HA. Eating frequency is higher in weight loss maintainers and normal-weight individuals than in overweight individuals. J Am Diet Assoc. 2011 Nov;111(11):1730–4.  
212. Mattson MP, Allison DB, Fontana L, Harvie M, Longo VD, Malaisse WJ, et al. Meal frequency and timing in health and disease. Proc Natl Acad Sci U S A. 2014 Nov;111(47):16647–53.  
213. Finkelstein B, Fryer BA. Meal frequency and weight reduction of young women. Am J Clin Nutr. 1971 Apr;24(4):465–8.  
214. Norris SL, Zhang X, Avenell A, Gregg E, Brown TJ, Schmid CH, et al. Long-term nonpharmacologic weight loss interventions for adults with type 2 diabetes. Cochrane database Syst Rev. 2005 Apr;(2):CD004095.  
215. Berteus Forslund H, Klingstrom S, Hagberg H, Londahl M, Torgerson JS, Lindroos AK. Should snacks be recommended in obesity treatment? A 1-year randomized clinical trial. Eur J Clin Nutr. 2008 Nov;62(11):1308–17.  
216. de la Iglesia R, Lopez-Legarrea P, Celada P, Sanchez-Muniz FJ, Martinez JA, Zulet MA. Beneficial effects of the RESMENA dietary pattern on oxidative stress in patients suffering from metabolic syndrome with hyperglycemia are associated to dietary TAC and fruit consumption. Int J Mol Sci. 2013 Mar;14(4):6903–19.  
217. Lopez-Legarrea P, de la Iglesia R, Abete I, Bondia-Pons I, Navas-Carretero S, Forga L, et al. Short-term role of the dietary total antioxidant capacity in two hypocaloric regimes on obese with metabolic syndrome symptoms: the RESMENA randomized controlled trial. Nutr Metab (Lond). 2013 Feb;10(1):22.  
218. Megson M, Wing R, Leahey TM. Effects of breakfast eating and eating frequency on body  
368  
mass index and weight loss outcomes in adults enrolled in an obesity treatment program. J Behav Med. 2017 Aug;40(4):595–601.  
219. Zhang L, Cordeiro LS, Liu J, Ma Y. The Association between Breakfast Skipping and Body Weight, Nutrient Intake, and Metabolic Measures among Participants with Metabolic Syndrome. Nutrients. 2017 Apr;9(4).  
220. Arciero PJ, Ormsbee MJ, Gentile CL, Nindl BC, Brestoff JR, Ruby M. Increased protein intake and meal frequency reduces abdominal fat during energy balance and energy deficit. Obesity (Silver Spring). 2013 Jul;21(7):1357–66.  
221. Poston WSC, Haddock CK, Pinkston MM, Pace P, Karakoc ND, Reeves RS, et al. Weight loss with meal replacement and meal replacement plus snacks: a randomized trial. Int J Obes (Lond). 2005 Sep;29(9):1107–14.  
222. Schlundt DG, Hill JO, Sbrocco T, Pope-Cordle J, Sharp T. The role of breakfast in the treatment of obesity: a randomized clinical trial. Am J Clin Nutr. 1992 Mar;55(3):645–51.  
223. Hoddy KK, Kroeger CM, Trepanowski JF, Barnosky A, Bhutani S, Varady KA. Meal timing during alternate day fasting: Impact on body weight and cardiovascular disease risk in obese adults. Obesity (Silver Spring). 2014 Dec;22(12):2524–31.  
224. Kong A, Beresford SAA, Alfano CM, Foster-Schubert KE, Neuhouser ML, Johnson DB, et al. Associations between snacking and weight loss and nutrient intake among postmenopausal overweight to obese women in a dietary weight-loss intervention. J Am Diet Assoc. 2011 Dec;111(12):1898–903.  
225. Kong A, Beresford SAA, Alfano CM, Foster-Schubert KE, Neuhouser ML, Johnson DB, et al. Selfmonitoring and eating-related behaviors are associated with 12-month weight loss in postmenopausal overweight-to-obese women. J Acad Nutr Diet. 2012 Sep;112(9):1428–35.  
226. Lally P, Chipperfield A, Wardle J. Healthy habits: efficacy of simple advice on weight control based on a habit-formation model. Int J Obes (Lond). 2008 Apr;32(4):700–7.  
227. Piya M, Reddy N, Harte A, Campbell A, Hattersley J, Halder L, et al. The impact of high fat meal frequency on metabolic profile and energy expenditure in obese subjects. In: 49th Annual Meeting of the EASD. Spinger; 2013.  
228. Egberts K, Kymmell Q, Brown W, Brennan L, O’Brien P. Effect of meal frequency on weight loss: A systematic review. Obes Res Clin Pract. 2011;5(1):26.  
229. Bortz WM, Wroldsen A, Issekutz BJ, Rodahl K. Weight loss and frequency of feeding. N Engl J Med. 1966 Feb;274(7):376–9.  
230. Antoine JM, Rohr R, Gagey MJ, Bleyer RE, Debry G. Feeding frequency and nitrogen balance in weight-reducing obese women. Hum Nutr Clin Nutr. 1984 Jan;38(1):31–8.  
231. Young CM, Scanlan SS, Topping CM, Simko V, Lutwak L. Frequency of feeding, weight reduction, and body composition. J Am Diet Assoc. 1971 Nov;59(5):466–72.  
232. Garrow JS, Durrant M, Blaza S, Wilkins D, Royston P, Sunkin S. The effect of meal frequency and protein concentration on the composition of the weight lost by obese subjects. Br J Nutr. 1981 Jan;45(1):5–15.  
233. Verboeket-van de Venne WP, Westerterp KR. Frequency of feeding, weight reduction and energy metabolism. Int J Obes Relat Metab Disord. 1993 Jan;17(1):31–6.  
234. Vander Wal JS, Waller SM, Klurfeld DM, McBurney MI, Cho S, Kapila M, et al. Effect of a postdinner snack and partial meal replacement program on weight loss. Int J Food Sci Nutr. 2006;57(1–2):97–106.  
235. Cameron JD, Cyr M-J, Doucet E. Increased meal frequency does not promote greater weight loss in subjects who were prescribed an 8-week equi-energetic energy-restricted diet. Br J Nutr. 2010 Apr;103(8):1098–101.  
236. Bachman JL, Raynor HA. Effects of manipulating eating frequency during a behavioral weight loss intervention: a pilot randomized controlled trial. Obesity (Silver Spring). 2012 May;20(5):985–92.  
369  
237. Hatami Zargaran Z, Salehi M, Heydari ST, Babajafari S. The Effects of 6 Isocaloric Meals on Body Weight, Lipid Profiles, Leptin, and Adiponectin in Overweight Subjects (BMI > 25). Int Cardiovasc Res J. 2014 Apr;8(2):52–6.  
238. Anjana RM, Ranjani H, Unnikrishnan R, Weber MB, Mohan V, Narayan KMV. Exercise patterns and behaviour in Asian Indians: data from the baseline survey of the Diabetes Community Lifestyle Improvement Program (D-CLIP). Diabetes Res Clin Pract. 2015 Jan;107(1):77–84.  
239. Blunt W, Gill DP, Sibbald SL, Riggin B, Pulford RW, Scott R, et al. Optimization of the Hockey Fans in Training (Hockey FIT) weight loss and healthy lifestyle program for male hockey fans. BMC Public Health. 2017 Nov;17(1):916.  
240. Park S-K, Park J-H, Kwon Y-C, Kim H-S, Yoon M-S, Park H-T. The effect of combined aerobic and resistance exercise training on abdominal fat in obese middle-aged women. J Physiol Anthropol Appl Human Sci. 2003 May;22(3):129–35.  
241. Shah R V, Murthy VL, Colangelo LA, Reis J, Venkatesh BA, Sharma R, et al. Association of Fitness in Young Adulthood With Survival and Cardiovascular Risk: The Coronary Artery Risk Development in Young Adults (CARDIA) Study. JAMA Intern Med. 2016 Jan;176(1):87–95.  
242. Catenacci VA, Grunwald GK, Ingebrigtsen JP, Jakicic JM, McDermott MD, Phelan S, et al. Physical activity patterns using accelerometry in the National Weight Control Registry. Obesity (Silver Spring). 2011 Jun;19(6):1163–70.  
243. Gordon-Larsen P, Hou N, Sidney S, Sternfeld B, Lewis CE, Jacobs DRJ, et al. Fifteen-year longitudinal trends in walking patterns and their impact on weight change. Am J Clin Nutr. 2009 Jan;89(1):19–26.  
244. Pouwels S, Wit M, Teijink JAW, Nienhuijs SW. Aspects of Exercise before or after Bariatric Surgery: A Systematic Review. Obes Facts. 2015;8(2):132–46.  
245. Drenowatz C, Hand GA, Shook RP, Jakicic JM, Hebert JR, Burgess S, et al. The association between different types of exercise and energy expenditure in young nonoverweight and overweight adults. Appl Physiol Nutr Metab = Physiol Appl Nutr Metab. 2015 Mar;40(3):211– 7.  
246. Whyte LJ, Ferguson C, Wilson J, Scott RA, Gill JMR. Effects of single bout of very high-intensity exercise on metabolic health biomarkers in overweight/obese sedentary men. Metabolism. 2013 Feb;62(2):212–9.  
247. Joseph RP, Casazza K, Durant NH. The effect of a 3-month moderate-intensity physical activity program on body composition in overweight and obese African American college females. Osteoporos Int. 2014 Oct;25(10):2485–91.  
248. Manthou E, Gill JM, Malkova D. Effect of exercise programs with aerobic exercise sessions of similar intensity but different frequency and duration on health-related measures in overweight women. J Phys Act Health. 2015 Jan;12(1):80–6.  
249. Sukala WR, Page R, Rowlands DS, Krebs J, Lys I, Leikis M, et al. South Pacific Islanders resist type 2 diabetes: comparison of aerobic and resistance training. Eur J Appl Physiol. 2012 Jan;112(1):317–25.  
250. Overgaard K, Nannerup K, Lunen MKB, Maindal HT, Larsen RG. Exercise more or sit less? A randomized trial assessing the feasibility of two advice-based interventions in obese inactive adults. J Sci Med Sport. 2018 Jul;21(7):708–13.  
251. Sakuta H, Suzuki T. Physical activity and selected cardiovascular risk factors in middle-aged male personnel of self-defense forces. Ind Health. 2006 Jan;44(1):184–9.  
252. Smith-Ryan AE, Melvin MN, Wingfield HL. High-intensity interval training: Modulating interval duration in overweight/obese men. Phys Sportsmed. 2015 May;43(2):107–13.  
253. Hansen D, Dendale P, van Loon LJC, Meeusen R. The impact of training modalities on the clinical benefits of exercise intervention in patients with cardiovascular disease risk or type 2 diabetes mellitus. Sports Med. 2010 Nov;40(11):921–40.  
254. Keller C, Trevino RP. Effects of two frequencies of walking on cardiovascular risk factor  
370  
reduction in Mexican American women. Res Nurs Health. 2001 Oct;24(5):390–401.  
255. Nikpour S, Vahidi SH, Hedayati M, Haghani H, AghaAlinejad H, Borim nejad L, et al. The Effect of Rhythmic Endurance Training on Abdominal Obesity Indices Among Working Women in Iran University of Medical Sciences TT  - ی ثأت ورزش ت ماقتسا منظم بر ص خاشیاه ق اچ یمکش زانن غلاش رد اهنشگ اد مولع یکشپز ناریا لاس 87. IJEM. 2010 Mar;11(2):177–83.  
256. Koo BK, Han KA, Ahn HJ, Jung JY, Kim HC, Min KW. The effects of total energy expenditure from all levels of physical activity vs. physical activity energy expenditure from moderate-tovigorous activity on visceral fat and insulin sensitivity in obese Type 2 diabetic women. Diabet Med. 2010 Sep;27(9):1088–92.  
257. Mougios V, Kazaki M, Christoulas K, Ziogas G, Petridou A. Does the intensity of an exercise programme modulate body composition changes? Int J Sports Med. 2006 Mar;27(3):178–81.  
258. Williams DM, Dunsiger S, Miranda RJ, Gwaltney CJ, Emerson JA, Monti PM, et al. Recommending self-paced exercise among overweight and obese adults: a randomized pilot study. Ann Behav Med. 2015 Apr;49(2):280–5.  
259. Annesi JJ. Behaviorally supported exercise predicts weight loss in obese adults through improvements in mood, self-efficacy, and self-regulation, rather than by caloric expenditure. Perm J. 2011;15(1):23–7.  
260. Carnero EA, Amati F, Pinto RS, Valamatos MJ, Mil-Homens P, Sardinha LB. Regional fat mobilization and training type on sedentary, premenopausal overweight and obese women. Obesity (Silver Spring). 2014 Jan;22(1):86–93.  
261. Jakicic JM, Marcus BH, Gallagher KI, Napolitano M, Lang W. Effect of exercise duration and intensity on weight loss in overweight, sedentary women: a randomized trial. JAMA. 2003 Sep;290(10):1323–30.  
262. Lee SH, So J, LOMANTIO D, Lim S, Shabbir A, Kayambu G. Effectiveness Of Weight Loss In Overweight And Obese Singaporean Adults: A Comparative Study Of Non-Supervised Exercise Versus Supervised Exercise Program. Surg Obes Relat Dis. 2016 Aug;12(7):S153.  
263. Blumenthal JA, Sherwood A, Gullette EC, Babyak M, Waugh R, Georgiades A, et al. Exercise and weight loss reduce blood pressure in men and women with mild hypertension: effects on cardiovascular, metabolic, and hemodynamic functioning. Arch Intern Med. 2000 Jul;160(13):1947–58.  
264. Davidson LE, Hudson R, Kilpatrick K, Kuk JL, McMillan K, Janiszewski PM, et al. Effects of exercise modality on insulin resistance and functional limitation in older adults: a randomized controlled trial. Arch Intern Med. 2009 Jan;169(2):122–31.  
265. Donnelly JE, Hill JO, Jacobsen DJ, Potteiger J, Sullivan DK, Johnson SL, et al. Effects of a 16month randomized controlled exercise trial on body weight and composition in young, overweight men and women: the Midwest Exercise Trial. Arch Intern Med. 2003 Jun;163(11):1343–50.  
266. Irwin ML, Yasui Y, Ulrich CM, Bowen D, Rudolph RE, Schwartz RS, et al. Effect of exercise on total and intra-abdominal body fat in postmenopausal women: a randomized controlled trial. JAMA. 2003 Jan;289(3):323–30.  
267. Ho SS, Dhaliwal SS, Hills AP, Pal S. The effect of 12 weeks of aerobic, resistance or combination exercise training on cardiovascular risk factors in the overweight and obese in a randomized trial. BMC Public Health. 2012 Aug;12:704.  
268. Nieman DC, Brock DW, Butterworth D, Utter AC, Nieman CC. Reducing diet and/or exercise training decreases the lipid and lipoprotein risk factors of moderately obese women. J Am Coll Nutr. 2002 Aug;21(4):344–50.  
269. Schroeder EC, Franke WD, Sharp RL, Lee D-C. Comparative effectiveness of aerobic, resistance, and combined training on cardiovascular disease risk factors: A randomized controlled trial. PLoS One. 2019;14(1):e0210292.  
270. Beavers KM, Walkup MP, Weaver AA, Lenchik L, Kritchevsky SB, Nicklas BJ, et al. Effect of  
371  
Exercise Modality During Weight Loss on Bone Health in Older Adults With Obesity and Cardiovascular Disease or Metabolic Syndrome: A Randomized Controlled Trial. J Bone Miner Res. 2018 Dec;33(12):2140–9.  
271. Bales CW, Hawk VH, Granville EO, Rose SB, Shields T, Bateman L, et al. Aerobic and resistance training effects on energy intake: the STRRIDE-AT/RT study. Med Sci Sports Exerc. 2012 Oct;44(10):2033–9.  
272. Hunter GR, Brock DW, Byrne NM, Chandler-Laney PC, Del Corral P, Gower BA. Exercise training prevents regain of visceral fat for 1 year following weight loss. Obesity (Silver Spring). 2010 Apr;18(4):690–5.  
273. Ross R, Rissanen J, Pedwell H, Clifford J, Shragge P. Influence of diet and exercise on skeletal muscle and visceral adipose tissue in men. J Appl Physiol. 1996 Dec;81(6):2445–55.  
274. Janssen I, Fortier A, Hudson R, Ross R. Effects of an energy-restrictive diet with or without exercise on abdominal fat, intermuscular fat, and metabolic risk factors in obese women. Diabetes Care. 2002 Mar;25(3):431–8.  
275. Sartorio A, Lafortuna CL, Massarini M, Galvani C. Effects of different training protocols on exercise performance during a short-term body weight reduction programme in severely obese patients. Eat Weight Disord. 2003 Mar;8(1):36–43.  
276. Cuff DJ, Meneilly GS, Martin A, Ignaszewski A, Tildesley HD, Frohlich JJ. Effective exercise modality to reduce insulin resistance in women with type 2 diabetes. Diabetes Care. 2003 Nov;26(11):2977–82.  
277. Geliebter A, Maher MM, Gerace L, Gutin B, Heymsfield SB, Hashim SA. Effects of strength or aerobic training on body composition, resting metabolic rate, and peak oxygen consumption in obese dieting subjects. Am J Clin Nutr. 1997 Sep;66(3):557–63.  
278. Herring LY, Wagstaff C, Scott A. The efficacy of 12 weeks supervised exercise in obesity management. Clin Obes. 2014 Aug;4(4):220–7.  
279. Bateman LA, Slentz CA, Willis LH, Shields AT, Piner LW, Bales CW, et al. Comparison of aerobic versus resistance exercise training effects on metabolic syndrome (from the Studies of a Targeted Risk Reduction Intervention Through Defined Exercise - STRRIDE-AT/RT). Am J Cardiol. 2011 Sep;108(6):838–44.  
280. Lucotti P, Monti LD, Setola E, Galluccio E, Gatti R, Bosi E, et al. Aerobic and resistance training effects compared to aerobic training alone in obese type 2 diabetic patients on diet treatment. Diabetes Res Clin Pract. 2011 Dec;94(3):395–403.  
281. Rice B, Janssen I, Hudson R, Ross R. Effects of aerobic or resistance exercise and/or diet on glucose tolerance and plasma insulin levels in obese men. Diabetes Care. 1999 May;22(5):684–91.  
282. Schjerve IE, Tyldum GA, Tjonna AE, Stolen T, Loennechen JP, Hansen HEM, et al. Both aerobic endurance and strength training programmes improve cardiovascular health in obese adults. Clin Sci (Lond). 2008 Nov;115(9):283–93.  
283. Ho SS, Radavelli-Bagatini S, Dhaliwal SS, Hills AP, Pal S. Resistance, aerobic, and combination training on vascular function in overweight and obese adults. J Clin Hypertens (Greenwich). 2012 Dec;14(12):848–54.  
284. Willis LH, Slentz CA, Bateman LA, Shields AT, Piner LW, Bales CW, et al. Effects of aerobic and/or resistance training on body mass and fat mass in overweight or obese adults. J Appl Physiol. 2012 Dec;113(12):1831–7.  
285. Kuhle CL, Steffen MW, Anderson PJ, Murad MH. Effect of exercise on anthropometric measures and serum lipids in older individuals: a systematic review and meta-analysis. BMJ Open. 2014 Jun;4(6):e005283.  
286. Romain AJ, Carayol M, Desplan M, Fedou C, Ninot G, Mercier J, et al. Physical Activity Targeted at Maximal Lipid Oxidation: A Meta-Analysis. J Nutr Metab. 2012;2012:1–11.  
287. Wahid A, Manek N, Nichols M, Kelly P, Foster C, Webster P, et al. Quantifying the Association  
372  
Between Physical Activity and Cardiovascular Disease and Diabetes: A Systematic Review and Meta-Analysis. J Am Hear Assoc. 2016/09/16. 2016;5(9).  
288. Clark JE. Diet, exercise or diet with exercise: comparing the effectiveness of treatment options for weight-loss and changes in fitness for adults (18-65 years old) who are overfat, or obese; systematic review and meta-analysis. J Diabetes Metab Disord. 2015;14:31.  
289. Haennel RG, Lemire F. Physical activity to prevent cardiovascular disease. How much is enough? Can Fam Physician. 2002 Jan;48:65–71.  
290. Jelleyman C, Yates T, O’Donovan G, Gray LJ, King JA, Khunti K, et al. The effects of highintensity interval training on glucose regulation and insulin resistance: a meta-analysis. Obes Rev. 2015 Nov;16(11):942–61.  
291. Keating SE, Johnson NA, Mielke GI, Coombes JS. A systematic review and meta-analysis of interval training versus moderate-intensity continuous training on body adiposity. Obes Rev. 2017/05/18. 2017;18(8):943–64.  
292. Maillard F, Pereira B, Boisseau N. Effect of High-Intensity Interval Training on Total, Abdominal and Visceral Fat Mass: A Meta-Analysis. Sport Med. 2017/11/12. 2018;48(2):269–88.  
293. Wormgoor SG, Dalleck LC, Zinn C, Harris NK. Effects of High-Intensity Interval Training on People Living with Type 2 Diabetes: A Narrative Review. Can J Diabetes. 2017/04/04. 2017;41(5):536–47.  
294. Herring LY, Stevinson C, Davies MJ, Biddle SJ, Sutton C, Bowrey D, et al. Changes in physical activity behaviour and physical function after bariatric surgery: a systematic review and metaanalysis. Obes Rev. 2016 Mar;17(3):250–61.  
295. Andreato L V, Esteves J V, Coimbra DR, Moraes AJP, de Carvalho T. The influence of highintensity interval training on anthropometric variables of adults with overweight or obesity: a systematic review and network meta-analysis. Obes Rev. 2019 Jan;20(1):142–55.  
296. Batacan RBJ, Duncan MJ, Dalbo VJ, Tucker PS, Fenning AS. Effects of high-intensity interval training on cardiometabolic health: a systematic review and meta-analysis of intervention studies. Br J Sports Med. 2017 Mar;51(6):494–503.  
297. Wewege M, van den Berg R, Ward RE, Keech A. The effects of high-intensity interval training vs. moderate-intensity continuous training on body composition in overweight and obese adults: a systematic review and meta-analysis. Obes Rev. 2017 Jun;18(6):635–46.  
298. Turk Y, Theel W, Kasteleyn MJ, Franssen FME, Hiemstra PS, Rudolphus A, et al. High intensity training in obesity: a Meta-analysis. Obes Sci Pract. 2017 Sep;3(3):258–71.  
299. Paul-Ebhohimhen, Virginia; Avenwll A. A Systematic Review of the Effectiveness of Group versus Individual Treatments for Adult Obesity. Obes Facts. 2009;17–24.  
300. Abbott, S; Bryant, E; Lycett, D; Tighe, B; Tahrani A. The effectiveness of group versus individual lifestyle interventions for overweight and obese adults : A systematic review and metaanalysis of randomised controlled trials. Obes Facts. 2018;11(0):264–5.  
301. Minniti A, Bissoli L, Francesco V Di, Fantin F, Mandragona R, Olivieri M, et al. Individual versus group therapy for obesity : Comparison of dropout rate and treatment outcome. 2007;12(December):161–7.  
302. Straw, Margret; Terre L. An Evaluation of Individualized Behavioral Obesity Treatment and Maintenance Strategies. Behav Ther. 1983;266:255–66.  
303. Jeffery RW, Gerber WM, Rosenthal BS, Lindquist RA. Monetary Contracts in Weight Control : Effectiveness of Group and Individual Contracts of Varying Size. J Consult Clin Psychol. 1983;51(2):242–8.  
304. Jeffery RW, Bjornson-benson WM, Rosenthal BS, Lindquist RA, Johnson SL. Behavioral treatment of obesity with monetary contracting: Two-year follow-up. Addict Behav. 1984;9:311–3.  
305. Perri MG, Martin AD, Leermakers EA, Sears SF, Notelovitz M, Perri MG, et al. Effects of GroupVersus Home-Based Exercise in the Treatment of Obesity. J Consult Clin Psychol.  
373  
###### 1997;65:278–85.  
306. Renjilian DA, Nezu AM, Perri MG, Mckelvey WF, Shermer RL, Anton SD. Individual Versus Group Therapy for Obesity : Effects of Matching Participants to Their Treatment Preferences. J Consult Clin Psychol. 2001;69(4):717–21.  
307. Waleekhachonloet O, Limwattananon C, Limwattananon S, Gross CR. Group behavior therapy versus individual behavior therapy for healthy dieting and weight control management in overweight and obese. Obes Res. 2007;  
308. Weinstock RS, Trief PM, Cibula D, Morin PC, Delahanty LM. Weight Loss Success in Metabolic Syndrome by Telephone Interventions : Results from the SHINE Study. J Gen Intern Med. 2013;1620–8.  
309. Mantzios M, Giannou K. Group vs . Single Mindfulness Meditation : Exploring Avoidance , Impulsivity , and Weight Management in Two Separate Mindfulness Meditation Settings. Appl Psychol Heal Well Being. 2014;6(2):173–91.  
310. Wright, J1. Wright J, Wood B HGE of GVINE in OP with MI*. 1981;, Wood B, Hale G. Evaluation of Group Versus Individual Nutrition Education in Overweight Patients with Myocardial Infarction *. Aust N Z J Med. 1981;  
311. Cresci B, Tesi F, Ferlita T La, Ricca V, Ravaldi C, Rotella CM, et al. Group versus individual cognitive- behavioral treatment for obesity : Results after 36 months. Eat Weight Disord. 2007;12(December):147–53.  
312. Rigsby A, Gropper DM, Gropper SS. Eating Behaviors Success of women in a worksite weight loss program : Does being part of a group help ? Eat Behav. 2009;10(2):128–30.  
313. Befort CA, Donnelly JE, Sullivan DK, Ellerbeck EF, Perri MG. Group versus individual phonebased obesity treatment for rural women. Eat Behav. 2011;11(1):1–15.  
314. Duchesne M, Appolinário JC, Rangé BP, Freitas S, Papelbaum M, Coutinho W. Evidências sobre a terapia cognitivo-comportamental no tratamento de obesos com transtorno da compulsão alimentar periódica . Vol. 29, Revista de Psiquiatria do Rio Grande do Sul . scielo ; 2007. p. 80– 92.  
315. Barnes RD, Ivezaj V, Martino S, Pittman BP, Paris M, Grilo CM. Examining motivational interviewing plus nutrition psychoeducation for weight loss in primary care. J Psychosom Res. 2018 Jan;104:101–7.  
316. Simpson SA, McNamara R, Shaw C, Kelson M, Moriarty Y, Randell E, et al. A feasibility randomised controlled trial of a motivational interviewing-based intervention for weight loss maintenance in adults. Health Technol Assess. 2015 Jul;19(50):v–vi, xix–xxv, 1–378.  
317. Brennan L, Walkley J, Wilks R, Fraser SF, Greenway K. Physiological and behavioural outcomes of a randomised controlled trial of a cognitive behavioural lifestyle intervention for overweight and obese adolescents. Obes Res Clin Pract. 2013;7(1):e23-41.  
318. Devlin MJ, Goldfein JA, Petkova E, Jiang H, Raizman PS, Wolk S, et al. Cognitive behavioral therapy and fluoxetine as adjuncts to group behavioral therapy for binge eating disorder. Obes Res. 2005 Jun;13(6):1077–88.  
319. Berk KAC, Buijks H, Ozcan B, Van’t Spijker A, Busschbach JJ V, Sijbrands EJG. The Prevention Of WEight Regain in diabetes type 2 (POWER) study: the effectiveness of adding a combined psychological intervention to a very low calorie diet, design and pilot data of a randomized controlled trial. BMC Public Health. 2012 Nov;12:1026.  
320. Barnes RD, Ivezaj V. A systematic review of motivational interviewing for weight loss among adults in primary care. Obes Rev. 2015 Apr;16(4):304–18.  
321. Armstrong MJ, Mottershead TA, Ronksley PE, Sigal RJ, Campbell TS, Hemmelgarn BR. Motivational interviewing to improve weight loss in overweight and/or obese patients: a systematic review and meta-analysis of randomized controlled trials. Obes Rev. 2011 Sep;12(9):709–23.  
322. Khazaal Y, Fresard E, Rabia S, Chatton A, Rothen S, Pomini V, et al. Cognitive behavioural  
374  
- therapy for weight gain associated with antipsychotic drugs. Schizophr Res. 2007 Mar;91(1– 3):169–77.  
323. Lawlor ER, Islam N, Griffin SJ, Hill AJ, Hughes CA, Ahern AL. Third-wave cognitive behaviour therapies for weight management: systematic review and network meta-analysis protocol. BMJ Open. 2018 Aug;8(7):e023425.  
324. Grilo CM, Masheb RM, Wilson GT. Efficacy of cognitive behavioral therapy and fluoxetine for the treatment of binge eating disorder: a randomized double-blind placebo-controlled comparison. Biol Psychiatry. 2005 Feb;57(3):301–9.  
325. Klosek P, Grosicki S, Calyniuk B. Improving the effectiveness of obesity treatment by combining a diet and motivational techniques. Rocz Panstw Zakl Hig. 2018;69(3):299–305.  
326. Hartmann-Boyce J, Boylan A-M, Jebb SA, Fletcher B, Aveyard P. Cognitive and behavioural strategies for self-directed weight loss: systematic review of qualitative studies. Obes Rev. 2017 Mar;18(3):335–49.  
327. Huber JM, Shapiro JS, Wieland ML, Croghan IT, Vickers Douglas KS, Schroeder DR, et al. Telecoaching plus a portion control plate for weight care management: a randomized trial. Trials. 2015 Jul;16:323.  
328. Palavras MA, Hay P, Filho CADS, Claudino A. The Efficacy of Psychological Therapies in Reducing Weight and Binge Eating in People with Bulimia Nervosa and Binge Eating Disorder Who Are Overweight or Obese-A Critical Synthesis and Meta-Analyses. Nutrients. 2017 Mar;9(3).  
329. Palmeira L, Pinto-Gouveia J, Cunha M. Exploring the efficacy of an acceptance, mindfulness & compassionate-based group intervention for women struggling with their weight (Kg-Free): A randomized controlled trial. Appetite. 2017 May;112:107–16.  
330. Jacob A, Moullec G, Lavoie KL, Laurin C, Cowan T, Tisshaw C, et al. Impact of cognitivebehavioral interventions on weight loss and psychological outcomes: A meta-analysis. Health Psychol. 2018 May;37(5):417–32.  
331. Casagrande SS, Jerome GJ, Dalcin AT, Dickerson FB, Anderson CA, Appel LJ, et al. Randomized trial of achieving healthy lifestyles in psychiatric rehabilitation: the ACHIEVE trial. BMC Psychiatry. 2010 Dec;10:108.  
332. Jiskoot G, Beerthuizen A, Timman R, Busschbach J, Laven J. Effects on body weight of a 1-year three-component lifestyle RCT in obese PCOS women. Reprod Sci. 2018;25(1):182A.  
333. Ma J, Strub P, Xiao L, Lavori PW, Camargo CAJ, Wilson SR, et al. Behavioral weight loss and physical activity intervention in obese adults with asthma. A randomized trial. Ann Am Thorac Soc. 2015 Jan;12(1):1–11.  
334. Annesi JJ, Johnson PH. Theory-based psychosocial factors that discriminate between weightloss success and failure over 6 months in women with morbid obesity receiving behavioral treatments. Eat Weight Disord. 2015 Jun;20(2):223–32.  
335. C TC, Pao-Hwa L, C CL, C BB, A GJ, C GS, et al. Abstract P122: Fidelity to Motivational Interviewing and Weight Loss in Young Adults: Cellphone Intervention for You (CITY) Trial. Circulation. 2015 Mar;131(suppl_1):AP122–AP122.  
336. Young A, Cohen A, Niv N, Kreyenbuhl J, Goldberg R. The effectiveness of computerized services and peer coaches to improve weight in patients with serious mental illness. J Gen Intern Med. 2017;32(2):S340.  
337. Booth HP, Prevost TA, Wright AJ, Gulliford MC. Effectiveness of behavioural weight loss interventions delivered in a primary care setting: a systematic review and meta-analysis. Fam Pract. 2014 Dec;31(6):643–53.  
338. Eldredge KL, Stewart Agras W, Arnow B, Telch CF, Bell S, Castonguay L, et al. The effects of extending cognitive-behavioral therapy for binge eating disorder among initial treatment nonresponders. Int J Eat Disord. 1997 May;21(4):347–52.  
339. Ruffault A, Czernichow S, Hagger MS, Ferrand M, Erichot N, Carette C, et al. The effects of  
375  
mindfulness training on weight-loss and health-related behaviours in adults with overweight and obesity: A systematic review and meta-analysis. Obes Res Clin Pract. 2017 Sep;11(5 Suppl 1):90–111.  
340. Prost SG, Ai AL, Ainsworth SE, Ayers J. Mental Health Professionals and Behavioral Interventions for Obesity: A Systematic Literature Review. J evidence-informed Soc Work. 2016;13(3):305–30.  
341. Turner-McGrievy GM, Campbell MK, Tate DF, Truesdale KP, Bowling JM, Crosby L. Pounds Off Digitally study: a randomized podcasting weight-loss intervention. Am J Prev Med. 2009 Oct;37(4):263–9.  
342. Wilson GT. Treatment of binge eating disorder. Psychiatr Clin North Am. 2011 Dec;34(4):773– 83.  
343. Grilo CM, Masheb RM. A randomized controlled comparison of guided self-help cognitive behavioral therapy and behavioral weight loss for binge eating disorder. Behav Res Ther. 2005 Nov;43(11):1509–25.  
344. Grilo CM, White MA, Gueorguieva R, Barnes RD, Masheb RM. Self-help for binge eating disorder in primary care: a randomized controlled trial with ethnically and racially diverse obese patients. Behav Res Ther. 2013 Dec;51(12):855–61.  
345. Stahre L, Hallstrom T. A short-term cognitive group treatment program gives substantial weight reduction up to 18 months from the end of treatment. A randomized controlled trial. Eat Weight Disord. 2005 Mar;10(1):51–8.  
346. Rieger E, Treasure J, Murray K, Caterson I. The use of support people to improve the weightrelated and psychological outcomes of adults with obesity: A randomised controlled trial. Behav Res Ther. 2017 Jul;94:48–59.  
347. Michelini I, Falchi AG, Muggia C, Grecchi I, Montagna E, De Silvestri A, et al. Early dropout predictive factors in obesity treatment. Nutr Res Pract. 2014 Feb;8(1):94–102.  
348. Grilo CM, Masheb RM, Crosby RD. Predictors and moderators of response to cognitive behavioral therapy and medication for the treatment of binge eating disorder. J Consult Clin Psychol. 2012 Oct;80(5):897–906.  
349. Grilo CM, White MA, Wilson GT, Gueorguieva R, Masheb RM. Rapid response predicts 12month post-treatment outcomes in binge-eating disorder: theoretical and clinical implications. Psychol Med. 2012 Apr;42(4):807–17.  
350. Majanovic SK, Ruzic A, Bulian AP, Licul V, Orlic ZC, Stimac D. Comparative Study of Intragastric Balloon and Cognitive-Behavioral Approach for Non-Morbid Obesity. Hepatogastroenterology. 2014 Jun;61(132):937–41.  
351. Munsch S, Biedert E, Meyer A, Michael T, Schlup B, Tuch A, et al. A randomized comparison of cognitive behavioral therapy and behavioral weight loss treatment for overweight individuals with binge eating disorder. Int J Eat Disord. 2007 Mar;40(2):102–13.  
352. Munsch S, Meyer AH, Biedert E. Efficacy and predictors of long-term treatment success for Cognitive-Behavioral Treatment and Behavioral Weight-Loss-Treatment in overweight individuals with binge eating disorder. Behav Res Ther. 2012 Dec;50(12):775–85.  
353. West DS, DiLillo V, Bursac Z, Gore SA, Greene PG. Motivational interviewing improves weight loss in women with type 2 diabetes. Diabetes Care. 2007 May;30(5):1081–7.  
354. Linde JA, Simon GE, Ludman EJ, Ichikawa LE, Operskalski BH, Arterburn D, et al. A randomized controlled trial of behavioral weight loss treatment versus combined weight loss/depression treatment among women with comorbid obesity and depression. Ann Behav Med. 2011 Feb;41(1):119–30.  
355. Castelnuovo G, Manzoni GM, Villa V, Cesa GL, Molinari E. Brief Strategic Therapy vs Cognitive Behavioral Therapy for the Inpatient and Telephone-Based Outpatient Treatment of Binge Eating Disorder: The STRATOB Randomized Controlled Clinical Trial. Clin Pract Epidemiol Ment Health. 2011 Mar;7:29–37.  
376  
356. Grilo CM, Masheb RM, Wilson GT, Gueorguieva R, White MA. Cognitive-behavioral therapy, behavioral weight loss, and sequential treatment for obese patients with binge-eating disorder: a randomized controlled trial. J Consult Clin Psychol. 2011 Oct;79(5):675–85.  
357. Tarraga Marcos ML, Rosich N, Panisello Royo JM, Galvez Casas A, Serrano Selva JP, RodriguezMontes JA, et al. [Efficacy of motivational interventions in the treatment of overweight and obesity]. Nutr Hosp. 2014 Oct;30(4):741–8.  
358. Muggia C, Falchi AG, Michelini I, Montagna E, De Silvestri A, Grecchi I, et al. Brief group cognitive behavioral treatment in addition to prescriptive diet versus standard care in obese and overweight patients. A randomized controlled trial. ESPEN J. 2014;9(1):e26–33.  
359. Mirkarimi K, Mostafavi F, Eshghinia S, Vakili MA, Ozouni-Davaji RB, Aryaie M. Effect of Motivational Interviewing on a Weight Loss Program Based on the Protection Motivation Theory. Iran Red Crescent Med J. 2015 Jun;17(6):e23492.  
360. MIRKARIMI K, MOSTAFAVI F, BERDI OZOUNI DAVAJI R, ESHGHINIA S, VAKILI MALI. THE EFFECT OF WEIGHT LOSS PROGRAM ON OVERWEIGHT AND OBESE FEMALES BASED ON PROTECTION MOTIVATION THEORY: A RANDOMIZED CONTROL TRIAL. Iran RED CRESCENT Med J. 2017;19(1):0.  
361. de Zwaan M, Mitchell JE, Crosby RD, Mussell MP, Raymond NC, Specker SM, et al. Short-term cognitive behavioral treatment does not improve outcome of a comprehensive very-lowcalorie diet program in obese women with binge eating disorder. Behav Ther. 2005;36(1):89– 99.  
362. Wagner B, Nagl M, Dolemeyer R, Klinitzke G, Steinig J, Hilbert A, et al. Randomized Controlled Trial of an Internet-Based Cognitive-Behavioral Treatment Program for Binge-Eating Disorder. Behav Ther. 2016 Jul;47(4):500–14.  
363. Barnes RD, Ivezaj V, Martino S, Pittman BP, Grilo CM. Back to Basics? No Weight Loss from Motivational Interviewing Compared to Nutrition Psychoeducation at One-Year Follow-Up. Obesity (Silver Spring). 2017 Dec;25(12):2074–8.  
364. Rodriguez-Cristobal JJ, Alonso-Villaverde C, Panisello JM, Trave-Mercade P, Rodriguez-Cortes F, Marsal JR, et al. Effectiveness of a motivational intervention on overweight/obese patients in the primary healthcare: a cluster randomized trial. BMC Fam Pract. 2017 Jun;18(1):74.  
365. Mirkarimi K, Eri M, Ghanbari MR, Kabir MJ, Raeisi M, Ozouni-Davaji RB, et al. Modifying attitude and intention toward regular physical activity using protection motivation theory: a randomized controlled trial. East Mediterr Health J. 2017 Oct;23(8):543–50.  
366. Raman J, Hay P, Tchanturia K, Smith E. A randomised controlled trial of manualized cognitive remediation therapy in adult obesity. Appetite. 2018 Apr;123:269–79.  
367. Berk KA, Buijks HIM, Verhoeven AJM, Mulder MT, Ozcan B, van ’t Spijker A, et al. Group cognitive behavioural therapy and weight regain after diet in type 2 diabetes: results from the randomised controlled POWER trial. Diabetologia. 2018 Apr;61(4):790–9.  
368. Jackson JB, Pietrabissa G, Rossi A, Manzoni GM, Castelnuovo G. Brief strategic therapy and cognitive behavioral therapy for women with binge eating disorder and comorbid obesity: A randomized clinical trial one-year follow-up. J Consult Clin Psychol. 2018 Aug;86(8):688–701.  
369. Solbrig L, Whalley B, Kavanagh DJ, May J, Parkin T, Jones R, et al. Functional imagery training versus motivational interviewing for weight loss: a randomised controlled trial of brief individual interventions for overweight and obesity. Int J Obes (Lond). 2019 Apr;43(4):883–94.  
370. Mhurchu CN, Margetts BM, Speller V. Randomized clinical trial comparing the effectiveness of two dietary interventions for patients with hyperlipidaemia. Clin Sci (Lond). 1998 Oct;95(4):479–87.  
371. Greaves CJ, Middlebrooke A, O’Loughlin L, Holland S, Piper J, Steele A, et al. Motivational interviewing for modifying diabetes risk: a randomised controlled trial. Br J Gen Pract. 2008 Aug;58(553):535–40.  
372. DiMarco ID, Klein DA, Clark VL, Wilson GT. The use of motivational interviewing techniques to  
377  
- enhance the efficacy of guided self-help behavioral weight loss treatment. Eat Behav. 2009 Apr;10(2):134–6.  
- 373. Penn L, White M, Oldroyd J, Walker M, Alberti KGMM, Mathers JC. Prevention of type 2 diabetes in adults with impaired glucose tolerance: the European Diabetes Prevention RCT in Newcastle upon Tyne, UK. BMC Public Health. 2009 Sep;9:342.  
374. Wilfley DE, Welch RR, Stein RI, Spurrell EB, Cohen LR, Saelens BE, et al. A randomized comparison of group cognitive-behavioral therapy and group interpersonal psychotherapy for the treatment of overweight individuals with binge-eating disorder. Arch Gen Psychiatry. 2002 Aug;59(8):713–21.  
375. Fitzgibbon ML, Stolley MR, Schiffer L, Sharp LK, Singh V, Dyer A. Obesity reduction black intervention trial (ORBIT): 18-month results. Obesity (Silver Spring). 2010 Dec;18(12):2317–25.  
376. Stahre L, Tarnell B, Hakanson C-E, Hallstrom T. A randomized controlled trial of two weightreducing short-term group treatment programs for obesity with an 18-month follow-up. Int J Behav Med. 2007;14(1):48–55.  
377. Hauner H, Meier M, Wendland G, Kurscheid T, Lauterbach K. Weight reduction by sibutramine in obese subjects in primary care medicine: the SAT Study. Exp Clin Endocrinol Diabetes. 2004 Apr;112(4):201–7.  
378. Rucker D, Padwal R, Li SK, Curioni C, Lau DCW. Long term pharmacotherapy for obesity and overweight: updated meta-analysis. BMJ. 2007 Dec;335(7631):1194–9.  
379. McMahon FG, Fujioka K, Singh BN, Mendel CM, Rowe E, Rolston K, et al. Efficacy and safety of sibutramine in obese white and African American patients with hypertension: a 1-year, double-blind, placebo-controlled, multicenter trial. Arch Intern Med. 2000 Jul;160(14):2185– 91.  
380. Padwal R, Li SK, Lau DCW. Long-term pharmacotherapy for overweight and obesity: a systematic review and meta-analysis of randomized controlled trials. Int J Obes Relat Metab Disord. 2003 Dec;27(12):1437–46.  
381. González LC, Solís RC, Gascón, Montserrat Bacardí; Cruz AJ. Long-term randomized clinical trials of pharmacological treatment of obesity : Systematic review *. Colomb Med. 2010;41:17–25.  
382. Arterburn DE, Crane PK, Veenstra DL. The efficacy and safety of sibutramine for weight loss: a systematic review. Arch Intern Med. 2004 May;164(9):994–1003.  
383. Cuellar GE, Martinez; Ruiz A, Martinez; Monsalve, Maria Cristina R, Berber A. Six-Month Treatment of Obesity with Sibutramine 15 mg ; A Double-Blind , Placebo-Controlled Monocenter Clinical Trial in a Hispanic Population. Obes Res. 2000;8(1):71–82.  
384. G. F, L. C, L. S-R, A. B. A clinical trial of the use of Sibutramine for the treatment of patients suffering essential obesity. Int J Obes. 2000;24(2):144–50.  
385. A. NF, F.F. RF, D.D.G. L, N. K, S.R. GF, M.T. Z. Effects of sibutramine on the treatment of obesity in patients with arterial hypertension. Arq Bras Cardiol. 2002;78(2):172–80.  
386. Finer N, Bloom SR, Frost GS, Banks LM, Griffiths J. Sibutramine is effective for weight loss and diabetic control in obesity with type 2 diabetes: a randomised, double-blind, placebocontrolled study. Diabetes Obes Metab. 2000 Apr;2(2):105–12.  
387. Fujioka K, Seaton TB, Rowe E, Jelinek CA, Raskin P, Lebovitz HE, et al. Weight loss with sibutramine improves glycaemic control and other metabolic parameters in obese patients with type 2 diabetes mellitus. Diabetes Obes Metab. 2000 Jun;2(3):175–87.  
388. Hazenberg BP. Randomized, double-blind, placebo-controlled, multicenter study of sibutramine in obese hypertensive patients. Cardiology. 2000;94(3):152–8.  
389. Hanotin C, Thomas F, Jones SP, Leutenegger E, Drouin P. A comparison of sibutramine and dexfenfluramine in the treatment of obesity. Obes Res. 1998 Jul;6(4):285–91.  
390. James WP, Astrup A, Finer N, Hilsted J, Kopelman P, Rossner S, et al. Effect of sibutramine on weight maintenance after weight loss: a randomised trial. STORM Study Group. Sibutramine  
378  
Trial of Obesity Reduction and Maintenance. Lancet (London, England). 2000 Dec;356(9248):2119–25.  
391. Norris SL, Zhang X, Avenell A, Gregg E, Schmid CH, Lau J. Pharmacotherapy for weight loss in adults with type 2 diabetes mellitus. Cochrane database Syst Rev. 2005 Jan;(1):CD004096.  
392. Serrano-Rios M, Melchionda N, Moreno-Carretero E. Role of sibutramine in the treatment of obese Type 2 diabetic patients receiving sulphonylurea therapy. Diabet Med. 2002 Feb;19(2):119–24.  
393. Smith IG, Goulder MA. Randomized placebo-controlled trial of long-term treatment with sibutramine in mild to moderate obesity. J Fam Pract. 2001 Jun;50(6):505–12.  
394. Sramek JJ, Leibowitz MT, Weinstein SP, Rowe ED, Mendel CM, Levy B. Efficacy and safety of sibutramine for weight loss in obese patients with hypertension well controlled by ␤ - adrenergic blocking agents : a placebo- controlled , double-blind , randomised trial. J Hum Hypertens. 2002;13–9.  
395. Apfelbaum M, Vague P, Ziegler O, Hanotin C, Thomas F, Leutenegger E. Long-term maintenance of weight loss after a very-low-calorie diet: A randomized blinded trial of the efficacy and tolerability of sibutramine. Am J Med. 1999;106(2):179–84.  
396. Bray GA, Ryan DH, Heidingsfeldervi S, George A, Ryan DH, Heidingsfelder S, et al. A DoubleBlind Randomized Placebo- Controlled Trial of Sibutramine. Obes Res. 1996;4(3):263–70.  
397. Milano W, Petrella C, Casella A, Capasso A, Carrino S, Milano L. Use of sibutramine, an inhibitor of the reuptake of serotonin and noradrenaline, in the treatment of binge eating disorder: a placebo-controlled study. Adv Ther. 2005;22(1):25–31.  
398. Wilfley DE, Ph D, Crow SJ, Hudson JI, Sc D, Mitchell JE, et al. Efficacy of Sibutramine for the Treatment of Binge Eating Double-Blind Study. Psychiatry Interpers Biol Process. 2008;(January):51–8.  
399. James WPT, Caterson ID, Coutinho W, Finer N, Van Gaal LF, Maggioni AP, et al. Effect of sibutramine on cardiovascular outcomes in overweight and obese subjects. N Engl J Med. 2010 Sep;363(10):905–17.  
400. Kim SH, Lee YM, Jee SH, Nam CM. Effect of Sibutramine on Weight Loss and Blood Pressure: A Meta-analysis of Controlled Trials. Obes Res. 2003;11(9):1116–23.  
401. Dedov II, Melnichenko GA, Troshina EA, Mazurina NV, Galieva MO. Body Weight Reduction Associated with the Sibutramine Treatment: Overall Results of the PRIMAVERA Primary Health Care Trial. Obes Facts. 2018;11(4):335–43.  
402. Gaciong Z, Placha G. Efficacy and safety of sibutramine in 2225 subjects with cardiovascular risk factors: short-term, open-label, observational study. J Hum Hypertens. 2005 Sep;19(9):737–43.  
403. Stimac D, Ruzic A, Majanovic SK. Croatian experience with sibutramine in the treatment of obesity--multicenter prospective study. Coll Antropol. 2004 Jun;28(1):215–21.  
404. Gray LJ, Cooper N, Dunkley A, Warren FC, Ara R, Abrams K, et al. A systematic review and mixed treatment comparison of pharmacological interventions for the treatment of obesity. Obes Rev. 2012 Jun;13(6):483–98.  
405. Neovius M, Johansson K, Rossner S. Head-to-head studies evaluating efficacy of pharmacotherapy for obesity: a systematic review and meta-analysis. Obes Rev. 2008 Sep;9(5):420–7.  
406. Appolinario JC, Bacaltchuk J, Sichieri R, Claudino AM, Godoy-Matos A, Morgan C, et al. A randomized, double-blind, placebo-controlled study of sibutramine in the treatment of bingeeating disorder. Arch Gen Psychiatry. 2003 Nov;60(11):1109–16.  
407. Erondu N, Addy C, Lu K, Mallick M, Musser B, Gantz I, et al. NPY5R antagonism does not augment the weight loss efficacy of orlistat or sibutramine. Obesity (Silver Spring). 2007 Aug;15(8):2027–42.  
408. Fanghanel G, Cortinas L, Sanchez-Reyes L, Gomez-Santos R, Campos-Franco E, Berber A.  
379  
Safety and efficacy of sibutramine in overweight Hispanic patients with hypertension. Adv Ther. 2003;20(2):101–13.  
409. Di Francesco V, Sacco T, Zamboni M, Bissoli L, Zoico E, Mazzali G, et al. Weight loss and quality of life improvement in obese subjects treated with sibutramine: a double-blind randomized multicenter study. Ann Nutr Metab. 2007;51(1):75–81.  
410. Derosa G, Cicero AFG, Murdolo G, Ciccarelli L, Fogari R. Comparison of metabolic effects of orlistat and sibutramine treatment in Type 2 diabetic obese patients. Diabetes Nutr Metab. 2004 Aug;17(4):222–9.  
411. Halpern A, Leite CC, Herszkowicz N, Barbato A, Costa APA. Evaluation of efficacy, reliability, and tolerability of sibutramine in obese patients, with an echocardiographic study. Rev Hosp Clin Fac Med Sao Paulo. 2002;57(3):98–102.  
412. Kaya A, Aydin N, Topsever P, Filiz M, Ozturk A, Dagar A, et al. Efficacy of sibutramine, orlistat and combination therapy on short-term weight management in obese patients. Biomed Pharmacother. 2004 Dec;58(10):582–7.  
413. Porter JA, Raebel MA, Conner DA, Lanty FA, Vogel EA, Gay EC, et al. The Long-term Outcomes of Sibutramine Effectiveness on Weight (LOSE Weight) study: evaluating the role of drug therapy within a weight management program in a group-model health maintenance organization. Am J Manag Care. 2004 Jun;10(6):369–76.  
414. Tankova T, Dakovska G, Lazarova M, Dakovska L, Kirilov G, Koev D. Sibutramine in the treatment of obesity in type 2 diabetic patients and in nondiabetic subjects. Acta Diabetol. 2004 Dec;41(4):146–53.  
415. Caterson ID, Finer N, Coutinho W, Van Gaal LF, Maggioni AP, Torp-Pedersen C, et al. Maintained intentional weight loss reduces cardiovascular outcomes: results from the Sibutramine Cardiovascular OUTcomes (SCOUT) trial. Diabetes Obes Metab. 2012 Jun;14(6):523–30.  
416. Douglas IJ, Bhaskaran K, Batterham RL, Smeeth L. The effectiveness of pharmaceutical interventions for obesity: weight loss with orlistat and sibutramine in a United Kingdom population-based cohort. Br J Clin Pharmacol. 2015 Jun;79(6):1020–7.  
417. Yancy WSJ, Westman EC, McDuffie JR, Grambow SC, Jeffreys AS, Bolton J, et al. A randomized trial of a low-carbohydrate diet vs orlistat plus a low-fat diet for weight loss. Arch Intern Med. 2010 Jan;170(2):136–45.  
418. Wadden TA, Volger S, Sarwer DB, Vetter ML, Tsai AG, Berkowitz RI, et al. A Two-Year Randomized Trial of Obesity Treatment in Primary Care Practice. N Engl J Med. 2011 Nov;365(21):1969–79.  
419. Turker I, Guvener Demirag N, Tanaci N, Uslu Tutar N, Kirbas I. Effects of orlistat plus diet on postprandial lipemia and brachial artery reactivity in normolipidemic, obese women with normal glucose tolerance: A prospective, randomized, controlled Study. Curr Ther Res. 2006 May;67(3):159–73.  
420. Derosa G, Mugellini A, Ciccarelli L, Rinaldi A, Fogari R. Effects of orlistat, simvastatin, and orlistat + simvastatin in obese patients with hypercholesterolemia: a randomized, open-label trial. Curr Ther Res. 2002 Sep;63(9):621–33.  
421. Florentin M, Kostapanos MS, Nakou ES, Elisaf M, Liberopoulos EN. Efficacy and safety of ezetimibe plus orlistat or rimonabant in statin-intolerant nondiabetic overweight/obese patients with dyslipidemia. J Cardiovasc Pharmacol Ther. 2009 Dec;14(4):274–82.  
422. Kim KK, Suh HS, Hwang IC, Ko KD. Influence of eating behaviors on short-term weight loss by orlistat and anorectic agent. Eat Behav. 2014 Jan;15(1):87–90.  
423. Ryan DH, Johnson WD, Myers VH, Prather TL, McGlone MM, Rood J, et al. Nonsurgical Weight Loss for Extreme Obesity in Primary Care Settings. Arch Intern Med. 2010 Jan;170(2):146.  
424. Smith SR, Stenlof KS, Greenway FL, McHutchison J, Schwartz SM, Dev VB, et al. Orlistat 60 mg reduces visceral adipose tissue: a 24-week randomized, placebo-controlled, multicenter trial.  
380  
- Obesity (Silver Spring). 2011 Sep;19(9):1796–803.  
425. Harrison SA, Fecht W, Brunt EM, Neuschwander-Tetri BA. Orlistat for overweight subjects with nonalcoholic steatohepatitis: A randomized, prospective trial. Hepatology. 2009 Jan;49(1):80–6.  
426. Kumar P, Arora S. Orlistat in polycystic ovarian syndrome reduces weight with improvement in lipid profile and pregnancy rates. J Hum Reprod Sci. 2014;7:255.  
427. Grilo CM, White MA. Orlistat with behavioral weight loss for obesity with versus without binge eating disorder: randomized placebo-controlled trial at a community mental health center serving educationally and economically disadvantaged Latino/as. Behav Res Ther. 2013 Mar;51(3):167–75.  
428. Grilo CM, Masheb RM. Rapid response predicts binge eating and weight loss in binge eating disorder: findings from a controlled trial of orlistat with guided self-help cognitive behavioral therapy. Behav Res Ther. 2007 Nov;45(11):2537–50.  
429. Cadegiani FA, Diniz GC, Alves G. Aggressive clinical approach to obesity improves metabolic and clinical outcomes and can prevent bariatric surgery: a single center experience. BMC Obes. 2017;4:9.  
430. Sultana Munir S, Jabeen S, Alvi N, Khan D, Khan M. Role of Orlistat Combined With Life Style in the Management of Obese Patients with Polycystic Ovarian Syndrome. Vol. 12.  
431. Cocco G, Pandolfi S, Rousson V. Sufficient Weight Reduction Decreases Cardiovascular Complications in Diabetic Patients with the Metabolic Syndrome. Hear Drug. 2005;5(2):68–74.  
432. Diamanti-Kandarakis E, Katsikis I, Piperi C, Alexandraki K, Panidis D. Effect of long-term orlistat treatment on serum levels of advanced glycation end-products in women with polycystic ovary syndrome. Clin Endocrinol (Oxf). 2006 Oct;0(0):061031010617005-???  
433. Harrison SA, Fincke C, Helinski D, Torgerson S, Hayashi P. A pilot study of orlistat treatment in obese, non-alcoholic steatohepatitis patients. Aliment Pharmacol Ther. 2004 Sep;20(6):623–8.  
434. Kalashnikova MF, Uchamprina V, Romantsova TI, Gerasimov AN, Gerasimov AN, Ивановна РТ, et al. Clinical and economic analysis of the modern strategies for treating metabolic syndrome. Diabetes Mellit. 2014 Apr;17(2):116.  
435. Grilo CM, Masheb RM, Salant SL. Cognitive behavioral therapy guided self-help and orlistat for the treatment of binge eating disorder: a randomized, double-blind, placebo-controlled trial. Biol Psychiatry. 2005 May;57(10):1193–201.  
436. Sari R, Balci MK, Cakir M, Altunbas H, Karayalcin U. Comparison of efficacy of sibutramine or orlistat versus their combination in obese women. Endocr Res. 2004 May;30(2):159–67.  
437. Dixon JB, Strauss BJG, Laurie C, O’Brien PE. Changes in body composition with weight loss: obese subjects randomized to surgical and medical programs. Obesity (Silver Spring). 2007 May;15(5):1187–98.  
438. Vosnakis C, Georgopoulos NA, Rousso D, Mavromatidis G, Katsikis I, Roupas ND, et al. Diet, physical exercise and Orlistat administration increase serum anti-Mullerian hormone (AMH) levels in women with polycystic ovary syndrome (PCOS). Gynecol Endocrinol. 2013 Mar;29(3):242–5.  
439. Pinkston MM, Poston WSC, Reeves RS, Haddock CK, Taylor JE, Foreyt JP. Does metabolic syndrome mitigate weight loss in overweight Mexican American women treated for 1-year with orlistat and lifestyle modification? Eat Weight Disord. 2006 Mar;11(1):e35-41.  
440. Filippatos TD, Kiortsis DN, Liberopoulos EN, Georgoula M, Mikhailidis DP, Elisaf MS. Effect of orlistat, micronised fenofibrate and their combination on metabolic parameters in overweight and obese patients with the metabolic syndrome: the FenOrli study. Curr Med Res Opin. 2005 Dec;21(12):1997–2006.  
441. Fatahi S, Kord Varkaneh H, Pezeshki M, Ghahremanian A, Shab-Bidar S. A survey on clinical effectiveness of orlistat compared to sibutramine, lorcaserin, metformin and placebo on weight loss in obese people: a network meta-analysis. Tehran Univ Med J TUMS Publ.  
381  
2018;76(6):403–9.  
442. Audikovszky M, Pados G, Seres I, Harangi M, Fulop P, Katona E, et al. [Changes in lipid profile and paraoxonase activity in obese patients as a result of orlistat treatment]. Orv Hetil. 2001 Dec;142(50):2779–83.  
443. [Efficacy and safety of a short-time orlistat treatment in obese subjects]. Ann Ital di Med interna organo Uff della Soc Ital di Med interna. 2005;20(2):90–6.  
444. GAO L, LIU J, YANG Jun, YANG J, ZHANG Y, CHEN J, et al. Efficacy and safety of Orlistat for obese patients with cardiovascular risk: a meta-analysis. Chinese J Evidence-Based Med . 2018;18(5):476–88.  
445. Hajduković Z, Jovelić A, Zivotić-Vanović M, Raden S. [Influence of orlistat therapy on serum insulin level and morphological and functional parameters of peripheral arterial circulation in obese patients]. Vojnosanit Pregl. 2005 Nov;62(11):803–10.  
446. Sjostrom L, Rissanen A, Andersen T, Boldrin M, Golay A, Koppeschaar H, et al. [Randomized placebo-controlled trial of orlistat for weight loss and prevention of weight regain in obese patients]. Ter Arkh. 2000;72(8):50–4.  
447. Makoundou V, Bobbioni-Harsch E, Gachoud J-P, Habicht F, Pataky Z, Golay A. A 2-year multifactor approach of weight loss maintenance. Eat Weight Disord. 2010;15(1–2):e9-14.  
448. LeCheminant JD, Jacobsen DJ, Hall MA, Donnelly JE. A Comparison of Meal Replacements and Medication in Weight Maintenance after Weight Loss. J Am Coll Nutr. 2005 Oct;24(5):347–53.  
449. Dombrowski SU, Knittle K, Avenell A, Araujo-Soares V, Sniehotta FF. Long term maintenance of weight loss with non-surgical interventions in obese adults: systematic review and metaanalyses of randomised controlled trials. BMJ. 2014 May;348:g2646.  
450. M. S, A. T-N. Monocentric, randomised, double-blind, pilot study using a double-dummy design to compare two treatment methods for the management of overweight and obesity. Obes Rev. 2011;12:278.  
451. Stoll M, Bitterlich N, Cornelli U. Randomised, double-blind, clinical investigation to compare orlistat 60 milligram and a customized polyglucosamine, two treatment methods for the management of overweight and obesity. BMC Obes. 2017;4:4.  
452. Nakou ES, Filippatos TD, Georgoula M, Kiortsis DN, Tselepis AD, Mikhailidis DP, et al. The effect of orlistat and ezetimibe, alone or in combination, on serum LDL and small dense LDL cholesterol levels in overweight and obese patients with hypercholesterolaemia. Curr Med Res Opin. 2008 Jul;24(7):1919–29.  
453. M. M, S. A, T.C. L, W.L. L. An RCT of metformin versus orlistat for the management of obese anovulatory women. Hum Reprod. 2009;24(4):966–75.  
454. S.K. G, F.M. M, P. Z, P.M. S. Effects of orlistat vs. metformin on weight loss-related clinical variables in women with PCOS: Systematic review and meta-Analysis. Int J Clin Pract. 2016;70(6):450–61.  
455. A. W. Reduction of body weight and co-morbidities by orlistat: The XXL - Primary health care trial. Diabetes, Obes Metab. 2005;7(1):21–7.  
456. Leblanc ES, O’Connor E, Whitlock EP, Patnode CD, Kapka T. Effectiveness of primary carerelevant treatments for obesity in adults: a systematic evidence review for the U.S. Preventive Services Task Force. Ann Intern Med. 2011 Oct;155(7):434–47.  
457. F.-F. W, Y. W, Y.-H. Z, T. D, R.L. B, F. Q, et al. Pharmacologic therapy to induce weight loss in women who have obesity/overweight with polycystic ovary syndrome: a systematic review and network meta-analysis. Obes Rev. 2018;19(10):1424–45.  
458. Moini A, Kanani M, Kashani L, Hosseini R, Hosseini L. Effect of orlistat on weight loss, hormonal and metabolic profiles in women with polycystic ovarian syndrome: a randomized double-blind placebo-controlled trial. Vol. 49, Endocrine. United States; 2015. p. 286–9.  
459. Zimbron J, Khandaker GM, Toschi C, Jones PB, Fernandez-Egea E. A systematic review and meta-analysis of randomised controlled trials of treatments for clozapine-induced obesity and  
382  
- metabolic syndrome. Eur Neuropsychopharmacol. 2016 Sep;26(9):1353–65.  
460. Dong Z, Xu L, Liu H, Lv Y, Zheng Q, Li L. Comparative efficacy of five long-term weight loss drugs: quantitative information for medication guidelines. Obes Rev. 2017 Dec;18(12):1377– 85.  
461. Panda SR, Jain M, Jain S, Saxena R, Hota S. Effect of Orlistat Versus Metformin in Various Aspects of Polycystic Ovarian Syndrome: A Systematic Review of Randomized Control Trials. J Obstet Gynaecol India. 2018 Oct;68(5):336–43.  
462. Sharma AM, Golay A. Effect of orlistat-induced weight loss on blood pressure and heart rate in obese patients with hypertension. J Hypertens. 2002 Sep;20(9):1873–8.  
463. Yanovski SZ, Yanovski JA. Long-term Drug Treatment for Obesity. JAMA. 2014 Jan;311(1):74. 464. Castañeda-González L, Camberos-Solís R, Bacardí-Gascón M, Jiménez-Cruz A. Long-term randomized clinical trials of pharmacological treatment of obesity: Systematic review. Colomb Med. 2010;41(1):1–5.  
465. Haddock C, Poston W, Dill P, Foreyt J, Ericsson M. Pharmacotherapy for obesity: a quantitative analysis of four decades of published randomized clinical trials. Int J Obes. 2002 Feb;26(2):262–73.  
466. Robertson C, Avenell A, Stewart F, Archibald D, Douglas F, Hoddinott P, et al. Clinical Effectiveness of Weight Loss and Weight Maintenance Interventions for Men: A Systematic Review of Men-Only Randomized Controlled Trials (The ROMEO Project). Am J Mens Health. 2017 Jul;11(4):1096–123.  
467. Svendsen M, Rissanen A, Richelsen B, Rossner S, Hansson F, Tonstad S. Effect of orlistat on eating behavior among participants in a 3-year weight maintenance trial. Obesity (Silver Spring). 2008 Feb;16(2):327–33.  
468. Sahebkar A, Simental-Mendia LE, Kovanen PT, Pedone C, Simental-Mendia M, Cicero AFG. Effects of orlistat on blood pressure: a systematic review and meta-analysis of 27 randomized controlled clinical trials. J Am Soc Hypertens. 2018 Feb;12(2):80–96.  
469. Derosa G, Maffioli P, Sahebkar A. Improvement of plasma adiponectin, leptin and C-reactive protein concentrations by orlistat: a systematic review and meta-analysis. Br J Clin Pharmacol. 2016 May;81(5):819–34.  
470. Yesilbursa D, Serdar Z, Serdar A, Sarac M, Coskun S, Jale C. Lipid peroxides in obese patients and effects of weight loss with orlistat on lipid peroxides levels. Int J Obes (Lond). 2005 Jan;29(1):142–5.  
471. Padwal R, Kezouh A, Levine M, Etminan M. Long-term persistence with orlistat and sibutramine in a population-based cohort. Int J Obes (Lond). 2007 Oct;31(10):1567–70.  
472. Finkelstein EA, Kruger E. Meta- and cost-effectiveness analysis of commercial weight loss strategies. Obesity (Silver Spring). 2014 Sep;22(9):1942–51.  
473. Hauptman J. Orlistat: Selective Inhibition of Caloric Absorption Can Affect Long-Term Body Weight. Endocrine. 2000 Oct;13(2):201–6.  
474. Robertson C, Avenell A, Boachie C, Stewart F, Archibald D, Douglas F, et al. Should weight loss and maintenance programmes be designed differently for men? A systematic review of longterm randomised controlled trials presenting data for men and women: The ROMEO project. Obes Res Clin Pract. 2016 Jan;10(1):70–84.  
475. O’Meara S, Glenny A, Sheldon T, Melville A, Wilson C. Systematic review of the effectiveness of interventions used in the management of obesity. J Hum Nutr Diet. 1998 Jun;11(3):203–6.  
476. Panidis D, Farmakiotis D, Rousso D, Kourtis A, Katsikis I, Krassas G. Obesity, weight loss, and the polycystic ovary syndrome: effect of treatment with diet and orlistat for 24 weeks on insulin resistance and androgen levels. Fertil Steril. 2008 Apr;89(4):899–906.  
477. Drent ML, Larsson I, William-Olsson T, Quaade F, Czubayko F, von Bergmann K, et al. Orlistat (Ro 18-0647), a lipase inhibitor, in the treatment of human obesity: a multiple dose study. Int J Obes Relat Metab Disord. 1995 Apr;19(4):221–6.  
383  
478. Pathan MF, Latif ZA, Nazneen NE, Mili SU. Orlistat as an adjunct therapy in type 2 obese diabetic patients treated with sulphonylurea: a Bangladesh experience. Bangladesh Med Res Counc Bull. 2004 Apr;30(1):1–8.  
479. Tchoukhine E, Takala P, Hakko H, Raidma M, Putkonen H, Räsänen P, et al. Orlistat in Clozapine- or Olanzapine-Treated Patients With Overweight or Obesity. J Clin Psychiatry. 2011 Mar;72(03):326–30.  
480. Joffe G, Takala P, Tchoukhine E, Hakko H, Raidma M, Putkonen H, et al. Orlistat in clozapineor olanzapine-treated patients with overweight or obesity: a 16-week randomized, doubleblind, placebo-controlled trial. J Clin Psychiatry. 2008 May;69(5):706–11.  
481. Douglas IJ, Bhaskaran K, Smeeth L. Abstracts of the 29th International Conference on Pharmacoepidemiology &amp; Therapeutic Risk Management, August 25–28, 2013, Montréal, Canada - A cohort analysis to measure the effect of orlistat or bariatric surgery on weight and body mass index in a ge. Pharmacoepidemiol Drug Saf. 2013 Oct;22(s1):1–521.  
482. Rehman KA, Khan M, Rehmani A, Taufeeq M, Sheikh MA, Fatima K, et al. A meta-analysis of cardiovascular safety of FDA approved anti-obesity drugs. J Am Coll Cardiol. 2017 Mar;69(11):1668.  
483. Schwartz TL, Jindal S, Simionescu M, Nihalani N, Azhar N, Tirmazi S, et al. Effectiveness of orlistat versus diet and exercise for weight gain associated with antidepressant use: a pilot study. Vol. 24, Journal of clinical psychopharmacology. United States; 2004. p. 555–6.  
484. Strebkova E, Solovyeva I, Sharapova E, Mkrtumyan A, Alekseeva L. Evaluation of treatment efficacy of orlistat in obese women with knee osteoarthritis - World Congress on Osteoporosis, Osteoarthritis and Musculoskeletal Diseases (WCO-IOF-ESCEO 2014): Poster Abstracts. Osteoporos Int. 2014 Apr;25(S2):S353.  
485. C. R, A. A, F. S, D. A, F. D, P. H, et al. Evidence for effective male weight loss programmes. A systematic review of long-term weight loss randomised trials for obese men: The ROMEO project. Obes Facts. 2013;6:196.  
486. Strebkova E, Alekseeva L. SAT0558 Pharmacotherapy of obesity in patients with knee osteoarthritis and metabolic syndrome. In: Saturday, 16 JUNE 2018. BMJ Publishing Group Ltd and European League Against Rheumatism; 2018. p. 1132.3-1133.  
487. K. S, F. G, S.R. S, K. M, J. M, V. A, et al. Significant reduction in body fat assessed by echomri in subjects treated with orlistat 60 mg for 6 months compared with placebo: Relationships between changes in body composition and body weight. Obes Rev. 2010;11:235.  
488. Smith S, Stenlöf K, Greenway F, McHutchison J, Savastano D, Bansal-Dev V, et al. Poster Presentations - The effect of orlistat 60 mg on changes in body composition over a 24 week treatment: a randomized, placebo-controlled, multicenter study. Obes Rev. 2010 Jul;11:72– 472.  
489. Levinson PD, Orlistat Swedish Multimorbidity Study Group. Orlistat with diet was effective and safe for weight loss and coronary risk reduction in obesity. Evid Based Med. 2001 Mar;54(6):54.  
490. Makoundou V, Bobbiono-Harsch E, Gachoud J-P, Pataky Z, Golay A. Multifactorial approach with a new orlistat “on/off” therapeutic schema in a weight loss maintenance programme: 4 Years follow up. 2010 p. 76.  
491. D. P-M, M. K-L, M. S, D. S, K. M, E. S-C, et al. Insulin resistance as a determinant of insulin-like growth factor-1 concentration changes in obese caucasian women treated with Orlistat, Metformin, or diet. J Hypertens. 2017;35:e258.  
492. Saghar S, Pegah V, Nasrin S, Sedigheh H. A two purpose use of Orlistat in obese women with polycystic ovary syndrome: Weight loss and Androgen reduction. IAHR; 2016 p. 1.  
493. K.K. K, I.C. H, K.S. L, H.S. S, S.W. O, K.R. L. Addition of orlistat to sibutramine, compared with sibutramine alone, induce further improvement of serum lipid profiles in 14-week treatment. Obes Rev. 2011;12:214–5.  
384  
494. Khera R, Pandey A, Chandar A, Murad MH, Wang Z, Camilleri M, et al. Abstract 16413: Association of Weight Loss Medications With Cardiometabolic Risk Factors: Systematic Review and Network Meta-Analysis. 2018 Nov p. 815–27.  
495. I Haq;, Verma; R, Farooq; M, Ganghat; I, Davies; M, McNally; P, et al. Clinical care and other categories posters: Audit - Clinical experience with orlistat in real world obese patients with diabetes: P416. Diabet Med. 2009 Mar;26:79–199.  
496. Hankin C, Brunetti L, Knispel J, Troupin B. COMPARATIVE EFFECTIVENESS OF WEIGHT LOSS TREATMENTS: DIET, PHARMACOLOGIC AGENTS, AND BARIATRIC SURGERY PDAM-01 BACKGROUND. 2010.  
497. Khera R, Murad MH, Chandar AK, Dulai PS, Wang Z, Prokop L, et al. 383 Comparative Efficacy and Tolerability of Long-Term Pharmacological Interventions for Obesity: A Systematic Review and Network Meta-Analysis. Gastroenterology. 2016 Apr;150(4):S87.  
498. Suyog J, Milind P, Karuna R. Comparison of efficacy and safety of rimonabant with orlistat in obese and overweight patients. Int J Pharma Bio Sci. 2011;2(1):179–87.  
499. Ye J, Yanqin W, Xuan H, Bihui Z. P1322 Effect of orlistat on total liver fat quantification by novel magnetic resonance imaging in obese patients with non-alcoholic steatohepatitis: Interim analysis of a prospective, randomized, single-center, open-label trial. United Eur Gastroenterol J. 2017;5(5S):A625.  
500. Gotfredsen A, Westergren Hendel H, Andersen T. Influence of orlistat on bone turnover and body composition. Int J Obes Relat Metab Disord. 2001 Aug;25(8):1154–60.  
501. Sjostrom L, Rissanen A, Andersen T, Boldrin M, Golay A, Koppeschaar HP, et al. Randomised placebo-controlled trial of orlistat for weight loss and prevention of weight regain in obese patients. European Multicentre Orlistat Study Group. Lancet (London, England). 1998 Jul;352(9123):167–72.  
502. James WP, Avenell A, Broom J, Whitehead J. A one-year trial to assess the value of orlistat in the management of obesity. Int J Obes Relat Metab Disord. 1997 Jun;21 Suppl 3:S24-30.  
503. Broom I, Wilding J, Stott P, Myers N, UK Multimorbidity Study Group. Randomised trial of the effect of orlistat on body weight and cardiovascular disease risk profile in obese patients: UK Multimorbidity Study. Int J Clin Pract. 2002 Sep;56(7):494–9.  
504. Derosa G, Maffioli P, Salvadeo SAT, Ferrari I, Gravina A, Mereu R, et al. Comparison of orlistat treatment and placebo in obese type 2 diabetic patients. Expert Opin Pharmacother. 2010 Aug;11(12):1971–82.  
505. Derosa G, Cicero A, D’Angelo A, Fogari E, Maffioli P. Effects of 1-year orlistat treatment compared to placebo on insulin resistance parameters in patients with type 2 diabetes. J Clin Pharm Ther. 2012 Apr;37(2):187–95.  
506. Bloch KV, Salles GF, Muxfeldt ES, Da Rocha Nogueira A. Orlistat in hypertensive overweight/obese patients: results of a randomized clinical trial. J Hypertens. 2003 Nov;21(11):2159–65.  
507. de Castro JJ, Dias T, Chambel P, Carvalheiro M, Correia LG, Guerreiro L, et al. A randomized double-blind study comparing the efficacy and safety of orlistat versus placebo in obese patients with mild to moderate hypercholesterolemia. Rev Port Cardiol. 2009 Dec;28(12):1361–74.  
508. Chou K-M, Huang B-Y, Fanchiang J-K, Chen C-H. Comparison of the effects of sibutramine and orlistat on obese, poorly-controlled type 2 diabetic patients. Chang Gung Med J. 2007;30(6):538–46.  
509. Derosa G, Mugellini A, Ciccarelli L, Fogari R. Randomized, double-blind, placebo-controlled comparison of the action of orlistat, fluvastatin, or both an anthropometric measurements, blood pressure, and lipid profile in obese patients with hypercholesterolemia prescribed a standardized diet. Clin Ther. 2003 Apr;25(4):1107–22.  
510. G. D, A.F.G. C, G. M, M.N. P, E. F, G. B, et al. Efficacy and safety comparative evaluation of  
385  
orlistat and sibutramine treatment in hypertensive obese patients. Diabetes, Obes Metab. 2005;7(1):47–55.  
511. Finer N, James WP, Kopelman PG, Lean ME, Williams G. One-year treatment of obesity: a randomized, double-blind, placebo-controlled, multicentre study of orlistat, a gastrointestinal lipase inhibitor. Int J Obes Relat Metab Disord. 2000 Mar;24(3):306–13.  
512. Gokcel A, Gumurdulu Y, Karakose H, Melek Ertorer E, Tanaci N, BascilTutuncu N, et al. Evaluation of the safety and efficacy of sibutramine, orlistat and metformin in the treatment of obesity. Diabetes Obes Metab. 2002 Jan;4(1):49–55.  
513. Gursoy A, Erdogan MF, Cin MO, Cesur M, Baskal N. Comparison of orlistat and sibutramine in an obesity management program: efficacy, compliance, and weight regain after noncompliance. Eat Weight Disord. 2006 Dec;11(4):e127-32.  
514. Guy-Grand B, Drouin P, Eschwege E, Gin H, Joubert J-M, Valensi P. Effects of orlistat on obesity-related diseases - a six-month randomized trial. Diabetes Obes Metab. 2004 Sep;6(5):375–83.  
515. Halpern A, Mancini MC, Suplicy H, Zanella MT, Repetto G, Gross J, et al. Latin-American trial of orlistat for weight loss and improvement in glycaemic profile in obese diabetic patients. Diabetes Obes Metab. 2003 May;5(3):180–8.  
516. Hauptman J, Lucas C, Boldrin MN, Collins H, Segal KR. Orlistat in the long-term treatment of obesity in primary care settings. Arch Fam Med. 2000 Feb;9(2):160–7.  
517. Hollander PA, Elbein SC, Hirsch IB, Kelley D, McGill J, Taylor T, et al. Role of orlistat in the treatment of obese patients with type 2 diabetes. A 1-year randomized double-blind study. Diabetes Care. 1998 Aug;21(8):1288–94.  
518. Kaya A, Aydın N, Topsever P, Filiz M, Öztürk A, Dağar A, et al. Efficacy of sibutramine, orlistat and combination therapy on short-term weight management in obese patients. Biomed Pharmacother. 2004 Dec;58(10):582–7.  
519. Kelley DE, Bray GA, Pi-Sunyer FX, Klein S, Hill J, Miles J, et al. Clinical efficacy of orlistat therapy in overweight and obese patients with insulin-treated type 2 diabetes: A 1-year randomized controlled trial. Diabetes Care. 2002 Jun;25(6):1033–41.  
520. Kuo C-S, Pei D, Yao C-Y, Hsieh M-C, Kuo S-W. Effect of orlistat in overweight poorly controlled Chinese female type 2 diabetic patients: a randomised, double-blind, placebo-controlled study. Int J Clin Pract. 2006 Aug;60(8):906–10.  
521. Miles JM, Leiter L, Hollander P, Wadden T, Anderson JW, Doyle M, et al. Effect of orlistat in overweight and obese patients with type 2 diabetes treated with metformin. Diabetes Care. 2002 Jul;25(7):1123–8.  
522. Poston WSC, Haddock CK, Pinkston MM, Pace P, Reeves RS, Karakoc N, et al. Evaluation of a primary care-oriented brief counselling intervention for obesity with and without orlistat. J Intern Med. 2006 Oct;260(4):388–98.  
523. Reaven G, Segal K, Hauptman J, Boldrin M, Lucas C. Effect of orlistat-assisted weight loss in decreasing coronary heart disease risk in patients with syndrome X. Am J Cardiol. 2001 Apr;87(7):827–31.  
524. B. R, S. T, S. R, S. T, L. N, S. M, et al. Effect of orlistat on weight regain and cardiovascular risk factors following a very-low-energy diet in abdominally obese patients: A 3-year randomized, placebo-controlled study. Diabetes Care. 2007;30(1):27–32.  
525. Shi Y-F, Pan C-Y, Hill J, Gao Y. Orlistat in the treatment of overweight or obese Chinese patients with newly diagnosed Type 2 diabetes. Diabet Med. 2005 Dec;22(12):1737–43.  
526. Smith TJ, Crombie A, Sanders LF, Sigrist LD, Bathalon GP, McGraw S, et al. Efficacy of orlistat 60 mg on weight loss and body fat mass in US Army soldiers. J Acad Nutr Diet. 2012 Apr;112(4):533–40.  
527. B.A. S, D. C, A.P. H, M. H, S. M, J. P, et al. Effect of orlistat on cardiovascular disease risk in obese adults. Diabetes, Obes Metab. 2005;7(3):254–62.  
386  
528. Trouillot TE, Pace DG, McKinley C, Cockey L, Zhi J, Haeussler J, et al. Orlistat maintains biliary lipid composition and hepatobiliary function in obese subjects undergoing moderate weight loss. Am J Gastroenterol. 2001 Jun;96(6):1888–94.  
529. Anderson JW, Schwartz SM, Hauptman J, Boldrin M, Rossi M, Bansal V, et al. Low-dose orlistat effects on body weight of mildly to moderately overweight individuals: a 16 week, doubleblind, placebo-controlled trial. Ann Pharmacother. 2006 Oct;40(10):1717–23.  
530. Audikovszky M, Pados G, Seres I, Harangi M, Fülöp P, Katona E, et al. Orlistat increases serum paraoxonase activity in obese patients. Nutr Metab Cardiovasc Dis. 2007 May;17(4):268–73.  
531. Aydin N, Topsever P, Kaya A, Karasakal M, Duman C, Dagar A. Orlistat, sibutramine, or combination therapy: which performs better on waist circumference in relation with body mass index in obese patients? Tohoku J Exp Med. 2004 Mar;202(3):173–80.  
532. Bakris G, Calhoun D, Egan B, Hellmann C, Dolker M, Kingma I. Orlistat improves blood pressure control in obese subjects with treated but inadequately controlled hypertension. J Hypertens. 2002 Nov;20(11):2257–67.  
533. Beck-da-Silva L, Higginson L, Fraser M, Williams K, Haddad H. Effect of Orlistat in obese patients with heart failure: a pilot study. Congest Heart Fail. 2005;11(3):118–23.  
534. Berne C, Orlistat Swedish Type 2 diabetes Study Group. A randomized study of orlistat in combination with a weight management programme in obese patients with Type 2 diabetes treated with metformin. Diabet Med. 2005 May;22(5):612–8.  
535. Aldekhail NM, Logue J, McLoone P, Morrison DS. Effect of orlistat on glycaemic control in overweight and obese patients with type 2 diabetes mellitus: a systematic review and metaanalysis of randomized controlled trials. Obes Rev. 2015 Dec;16(12):1071–80.  
536. Horvath K, Jeitler K, Siering U, Stich AK, Skipka G, Gratzer TW, et al. Long-term Effects of Weight-Reducing Interventions in Hypertensive Patients&lt;subtitle&gt;Systematic Review and Meta-analysis&lt;/subtitle&gt; Arch Intern Med. 2008 Mar;168(6):571.  
537. Khera R, Pandey A, Chandar AK, Murad MH, Prokop LJ, Neeland IJ, et al. Effects of Weight-Loss Medications on Cardiometabolic Risk Profiles: A Systematic Review and Network Metaanalysis. Gastroenterology. 2018 Apr;154(5):1309-1319.e7.  
538. Khera R, Murad MH, Chandar AK, Dulai PS, Wang Z, Prokop LJ, et al. Association of Pharmacological Treatments for Obesity With Weight Loss and Adverse Events: A Systematic Review and Meta-analysis. JAMA. 2016 Jun;315(22):2424–34.  
539. LeBlanc ES, Patnode CD, Webber EM, Redmond N, Rushkin M, O’Connor EA. Behavioral and Pharmacotherapy Weight Loss Interventions to Prevent Obesity-Related Morbidity and Mortality in Adults. JAMA. 2018 Sep;320(11):1172.  
540. M. N, K. J, S. R. Head-to-head studies evaluating efficacy of pharmaco-therapy for obesity: A systematic review and meta-analysis. Obes Rev. 2008;9(5):420–7.  
541. O’Meara S, Riemsma R, Shirran L, Mather L, ter Riet G. A systematic review of the clinical effectiveness of orlistat used for the management of obesity. Obes Rev. 2004 Feb;5(1):51–68.  
542. S. O, R. R, L. S, L. M, G. TR. A rapid and systematic review of the clinical effectiveness and costeffectiveness of orlistat in the management of obesity. Health Technol Assess (Rockv). 2001;5(18):iii-iv+1-71.  
543. G. O-A, Y. A, I. K, S. K, K. M. Pharmacotherapy for overweight/obesity in ethnic minorities and White Caucasians: A systematic review and meta-analysis. Diabetes, Obes Metab. 2011;13(5):385–93.  
544. R. P, S.K. L, D.C.W. L. Long-term pharmacotherapy for overweight and obesity: A systematic review and meta-analysis of randomized controlled trials. Int J Obes. 2003;27(12):1437–46.  
545. Sahebkar A, Simental-Mendia LE, Reiner Z, Kovanen PT, Simental-Mendia M, Bianconi V, et al. Effect of orlistat on plasma lipids and body weight: A systematic review and meta-analysis of 33 randomized controlled trials. Pharmacol Res. 2017 Aug;122:53–65.  
546. Siebenhofer A, Jeitler K, Horvath K, Berghold A, Posch N, Meschik J, et al. Long-term effects of  
387  
weight-reducing drugs in people with hypertension. Cochrane Database Syst Rev. 2016 Mar;3:CD007654.  
547. Zhou Y-H, Ma X-Q, Wu C, Lu J, Zhang S-S, Guo J, et al. Effect of anti-obesity drug on cardiovascular risk factors: a systematic review and meta-analysis of randomized controlled trials. PLoS One. 2012;7(6):e39062.  
548. Hutton B, Fergusson D. Changes in body weight and serum lipid profile in obese patients treated with orlistat in addition to a hypocaloric diet: a systematic review of randomized clinical trials. Am J Clin Nutr. 2004 Dec;80(6):1461–8.  
549. Arzola-Paniagua MA, García-Salgado López ER, Calvo-Vargas CG, Guevara-Cruz M. Efficacy of an orlistat-resveratrol combination for weight loss in subjects with obesity: A randomized controlled trial. Obesity. 2016 Jul;24(7):1454–63.  
550. Golay A, Laurent-Jaccard A, Habicht F, Gachoud J-P, Chabloz M, Kammer A, et al. Effect of orlistat in obese patients with binge eating disorder. Obes Res. 2005 Oct;13(10):1701–8.  
551. Trujillo RC, Acosta A de L, Parra MG de la, Tapia MGP. Estudio comparativo para evaluar la eficacia y seguridad de orlistat vs placebo en pacientes adultos de la Ciudad de México. Med Interna México. 2010;26(5):437–48.  
552. Jain SS, Ramanand SJ, Ramanand JB, Akat PB, Patwardhan MH, Joshi SR. Evaluation of efficacy and safety of orlistat in obese patients. Indian J Endocrinol Metab. 2011 Apr;15(2):99–104.  
553. Gavin KL, Linde JA, Pacanowski CR, French SA, Jeffery RW, Ho Y-Y. Weighing frequency among working adults: cross-sectional analysis of two community samples. Prev Med reports. 2015;2:44–6.  
554. Burke LE, Wang J, Sevick MA. Self-monitoring in weight loss: a systematic review of the literature. J Am Diet Assoc. 2011 Jan;111(1):92–102.  
555. Shieh C, Knisely MR, Clark D, Carpenter JS. Self-weighing in weight management interventions: A systematic review of literature. Obes Res Clin Pract. 2016 Sep;10(5):493–519.  
556. Ramage S, Farmer A, Eccles KA, McCargar L. Healthy strategies for successful weight loss and weight maintenance: a systematic review. Appl Physiol Nutr Metab = Physiol Appl Nutr Metab. 2014 Jan;39(1):1–20.  
557. Vanwormer JJ, French SA, Pereira MA, Welsh EM. The impact of regular self-weighing on weight management: a systematic literature review. Int J Behav Nutr Phys Act. 2008 Nov;5:54.  
558. Y. Z, S.M. S, L.J. E, C.A. D, M.A. T, C. I, et al. Is self-efficacy associated with patterns of selfweighing behavior? Circulation. 2016;133.  
559. M.L. T, K.M. R, R.R. W. Frequency and variability of self-monitored weight and calories in internet-based weight management program. Diabetes. 2015;64:A215.  
560. Madigan CD, Aveyard P, Jolly K, Denley J, Lewis A, Daley AJ. Regular self-weighing to promote weight maintenance after intentional weight loss: a quasi-randomized controlled trial. J Public Health (Oxf). 2014 Jun;36(2):259–67.  
561. Krukowski RA, Harvey-Berino J, Bursac Z, Ashikaga T, West DS. Patterns of success: online selfmonitoring in a web-based behavioral weight control program. Health Psychol. 2013 Feb;32(2):164–70.  
562. Teixeira PJ, Carraca E V, Marques MM, Rutter H, Oppert J-M, De Bourdeaudhuij I, et al. Successful behavior change in obesity interventions in adults: a systematic review of selfregulation mediators. BMC Med. 2015 Apr;13:84.  
563. Linde JA, Jeffery RW, French SA, Pronk NP, Boyle RG. Self-weighing in weight gain prevention and weight loss trials. Ann Behav Med. 2005 Dec;30(3):210–6.  
564. Zheng Y, Sereika SM, Ewing LJ, Danford CA, Terry MA, Burke LE. Association between SelfWeighing and Percent Weight Change: Mediation Effects of Adherence to Energy Intake and Expenditure Goals. J Acad Nutr Diet. 2016 Apr;116(4):660–6.  
565. Carrard I, Kruseman M. Qualitative analysis of the role of self-weighing as a strategy of weight control for weight-loss maintainers in comparison with a normal, stable weight group.  
388  
Appetite. 2016 Oct;105:604–10.  
566. Linde JA, Jeffery RW, Finch EA, Simon GE, Ludman EJ, Operskalski BH, et al. Relation of body mass index to depression and weighing frequency in overweight women. Prev Med (Baltim). 2007 Jul;45(1):75–9.  
567. Steinberg DM, Bennett GG, Askew S, Tate DF. Weighing every day matters: daily weighing improves weight loss and adoption of weight control behaviors. J Acad Nutr Diet. 2015 Apr;115(4):511–8.  
568. Akers JD, Cornett RA, Savla JS, Davy KP, Davy BM. Daily self-monitoring of body weight, step count, fruit/vegetable intake, and water consumption: a feasible and effective long-term weight loss maintenance approach. J Acad Nutr Diet. 2012 May;112(5):685-692.e2.  
569. M.H. L, S.A. M, M.G. P. The role of self-monitoring in the maintenance of weight loss success. Eat Behav. 2016;21:193–7.  
570. VanWormer JJ, Martinez AM, Martinson BC, Crain AL, Benson GA, Cosentino DL, et al. Selfweighing promotes weight loss for obese adults. Am J Prev Med. 2009 Jan;36(1):70–3.  
571. Welsh EM, Sherwood NE, VanWormer JJ, Hotop AM, Jeffery RW. Is frequent self-weighing associated with poorer body satisfaction? Findings from a phone-based weight loss trial. J Nutr Educ Behav. 2009;41(6):425–8.  
572. Zheng Y, Burke LE, Danford CA, Ewing LJ, Terry MA, Sereika SM. Patterns of self-weighing behavior and weight change in a weight loss trial. Int J Obes (Lond). 2016 Sep;40(9):1392–6.  
573. LaRose JG, Fava JL, Steeves EA, Hecht J, Wing RR, Raynor HA. Daily self-weighing within a lifestyle intervention: impact on disordered eating symptoms. Health Psychol. 2014 Mar;33(3):297–300.  
574. Painter SL, Ahmed R, Hill JO, Kushner RF, Lindquist R, Brunning S, et al. What Matters in Weight Loss? An In-Depth Analysis of Self-Monitoring. J Med Internet Res. 2017 May;19(5):e160.  
575. Steinberg DM, Tate DF, Bennett GG, Ennett S, Samuel-Hodge C, Ward DS. The efficacy of a daily self-weighing weight loss intervention using smart scales and e-mail. Obesity (Silver Spring). 2013 Sep;21(9):1789–97.  
576. Wing RR, Phelan S. Long-term weight loss maintenance. Am J Clin Nutr. 2005 Jul;82(1 Suppl):222S-225S.  
577. Butryn ML, Phelan S, Hill JO, Wing RR. Consistent self-monitoring of weight: a key component of successful weight loss maintenance. Obesity (Silver Spring). 2007 Dec;15(12):3091–6.  
578. Rohde P, Arigo D, Shaw H, Stice E. Relation of self-weighing to future weight gain and onset of disordered eating symptoms. J Consult Clin Psychol. 2018 Aug;86(8):677–87.  
579. Steinberg DM, Tate DF, Bennett GG, Ennett S, Samuel-Hodge C, Ward DS. Daily self-weighing and adverse psychological outcomes: a randomized controlled trial. Am J Prev Med. 2014 Jan;46(1):24–9.  
580. Wing RR, Tate DF, Gorin AA, Raynor HA, Fava JL, Machan J. STOP regain: are there negative effects of daily weighing? J Consult Clin Psychol. 2007 Aug;75(4):652–6.  
581. Wilkinson L, Pacanowski CR, Levitsky D. Three-Year Follow-Up of Participants from a SelfWeighing Randomized Controlled Trial. J Obes. 2017;2017:4956326.  
582. Rosenbaum DL, Espel HM, Butryn ML, Zhang F, Lowe MR. Daily self-weighing and weight gain prevention: a longitudinal study of college-aged women. J Behav Med. 2017 Oct;40(5):846– 53.  
583. Fallahi Khoshknab M, Mazaheri M, Tamizi Z, Khankh HR, Babaei RM, Ghazanfari N, et al. The effect of weight monitoring and recording on control of obesity and overweight. Eat Weight Disord. 2011 Jun;16(2):e137-41.  
584. VanWormer JJ, Linde JA, Harnack LJ, Stovitz SD, Jeffery RW. Self-weighing frequency is associated with weight gain prevention over 2 years among working adults. Int J Behav Med. 2012 Sep;19(3):351–8.  
389  
585. F. B, C.R. P, D.A. L. Frequent self-weighing with electronic graphic feedback to prevent agerelated weight gain in young adults. Obesity. 2015;23(10):2009–14.  
586. Oshima Y, Matsuoka Y, Sakane N. Effect of weight-loss program using self-weighing twice a day and feedback in overweight and obese subject: a randomized controlled trial. Obes Res Clin Pract. 2013;7(5):e361-6.  
587. Zheng Y, Klem M Lou, Sereika SM, Danford CA, Ewing LJ, Burke LE. Self-weighing in weight management: a systematic literature review. Obesity (Silver Spring). 2015 Feb;23(2):256–65.  
588. Madigan CD, Daley AJ, Lewis AL, Aveyard P, Jolly K. Is self-weighing an effective tool for weight loss: a systematic literature review and meta-analysis. Int J Behav Nutr Phys Act. 2015 Aug;12:104.  
589. Crane MM, Gavin K, Wolfson J, Linde JA. How Accurate are Recalls of Self-Weighing Frequency? Data from a 24-Month Randomized Trial. Obesity (Silver Spring). 2018 Aug;26(8):1296–302.  
590. Jospe MR, Roy M, Brown RC, Williams SM, Osborne HR, Meredith-Jones KA, et al. The Effect of Different Types of Monitoring Strategies on Weight Loss: A Randomized Controlled Trial. Obesity (Silver Spring). 2017 Sep;25(9):1490–8.  
591. Madigan CD, Jolly K, Lewis AL, Aveyard P, Daley AJ. A randomised controlled trial of the effectiveness of self-weighing as a weight loss intervention. Int J Behav Nutr Phys Act. 2014 Oct;11:125.  
592. Pacanowski CR, Levitsky DA. Frequent Self-Weighing and Visual Feedback for Weight Loss in Overweight Adults. J Obes. 2015;2015:763680.  
593. J.G. L, A. L, D.F. T, R.R. W. Frequency of self-weighing and weight loss outcomes within a brief lifestyle intervention targeting emerging adults. Obes Sci Pract. 2016;2(1):88–92.  
390

---

