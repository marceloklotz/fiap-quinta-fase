<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: Geral -->
<!-- Start of picture text -->
ay<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: PORTARIA SCTIE/MS Nº 55, DE 1º DE SETEMBRO DE 2026 -->
Torna pública a decisão de aprovar, no âmbito    do Sistema Único de Saúde - SUS, o Protocolo de Uso do Iodeto de Potássio na Emergência Nuclear.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe confere o art. 68 do Decreto n.º 11.798, de 28 de novembro de 2023, e o disposto nos arts. 20, 22 e 23 do Decreto n.º 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo de Uso do Iodeto de Potássio na Emergência Nuclear.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: <u>https://www.gov.br/conitec/pt-br.</u>  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: FERNANDA DE NEGRI -->
1  
ANEXO

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 1. INTRODUÇÃO -->
O desenvolvimento das ações de preparação exerce impacto significativo na efetividade da resposta a emergência nuclear<sup>1</sup> . Tais eventos demandam decisões rápidas, coordenadas e tecnicamente embasadas, sendo essencial a implementação de medidas eficazes de proteção radiológica para salvaguardar a saúde pública, reduzir a mortalidade, prevenir doenças relacionadas à radiação e mitigar impactos adversos de ordem social, ambiental e econômica<sup>2</sup> .  
O Acidente Nuclear de Chernobyl, ocorrido em 1986, é um exemplo de emergência nuclear que causou uma grande liberação de iodo radioativo I-131 e de iodo de baixa meia vida para o meio ambiente<sup>3-4</sup> .  A explosão e o incêndio no reator resultaram na dispersão de material radioativo na atmosfera por meio de uma pluma radioativa, contaminando extensas áreas e resultando na exposição humana direta e indireta à radiação ionizante<sup>3</sup> .  
Os principais efeitos e agravos à saúde humana decorrentes desse tipo de exposição estão associados, sobretudo, à incorporação interna de radionuclídeos, com destaque para o iodo radioativo, que se concentra preferencialmente na glândula tireoide. Essa incorporação ocorre principalmente por meio da inalação de ar e da ingestão de água e/ou alimentos contaminados<sup>5-6</sup> .  
A glândula tireoide utiliza o iodo como elemento essencial para a síntese dos hormônios tireoidianos e não distingue o iodo radioativo do iodo estável. Dessa forma, após a liberação de iodo radioativo no ambiente, sua inalação ou ingestão resulta na captação e concentração desse radionuclídeo pela tireoide, de maneira análoga ao iodo estável<sup>3</sup> .  
Uma das principais medidas protetoras urgentes após a liberação de iodo radioativo é o bloqueio da captação tireoidiana por meio da administração de iodeto de potássio (KI)<sup>7,3</sup> . A administração oral de iodo estável é reconhecida como uma estratégia eficaz para reduzir o risco de câncer de tireoide em indivíduos expostos à liberação acidental de iodo radioativo<sup>8-9</sup> .  
O uso do KI deve ser adotado de forma complementar a outras medidas protetoras, tais como evacuação, abrigamento e restrições ao consumo de água e alimentos contaminados, sendo todas essas ações previstas nos Planos de Emergência Nuclear<sup>3, 10</sup> .  
O uso adequado do KI pode mitigar significativamente os efeitos da exposição à radiação oriunda do iodo radioativo na glândula tireoide, contribuindo para uma resposta rápida, coordenada e baseada em evidências, além de promover segurança e confiança à população e otimizar o uso de recursos em situações críticas.  
Por fim, destaca-se que a articulação e a implementação das medidas previstas neste documento são de responsabilidade das três esferas de gestão do SUS, em conformidade com os princípios e diretrizes estabelecidos na Lei nº 8.080/1990<sup>11</sup> .  
O objetivo deste documento é orientar sobre o uso seguro e eficaz do KI, nas apresentações comprimido e xarope, como medida de bloqueio tireoidiano em situações de exposição ao iodo radioativo (I‑131) durante emergências nucleares.  
2

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 2. METODOLOGIA -->
A elaboração deste Protocolo baseou-se na adaptação dos documentos **_Guidelines for Iodine Prophylaxis following Nuclear Accidents_**<sup>12</sup> e **_Iodine Thyroid Blocking Guidelines for Use in Planning for and Responding to Radiological and Nuclear Emergencies_**<sup>3</sup> , publicados pela Organização Mundial da Saúde, bem como nas informações técnicas constantes na bula do iodeto de potássio, em conformidade com o marco regulatório nacional.  
A adoção dessas diretrizes justifica-se por sua robustez técnico-científica, uma vez que consolidam evidências e estabelecem critérios claros quanto às recomendações e estratégias operacionais para o bloqueio tireoidiano em cenários de liberação de iodo radioativo. Sua utilização assegura alinhamento às melhores práticas internacionais, padronização de condutas e maior segurança na tomada de decisão em emergências radiológicas e nucleares.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- W88- Exposição a radiação ionizante  
- Z29.8 - Outras medidas profiláticas especificadas  
Nota: A administração do KI se caracteriza como medida de caráter preventivo, realizada antes do surgimento de sinais ou sintomas, com o propósito de reduzir a captação de iodo radioativo pela glândula tireoide.

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 4. CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo os indivíduos que apresentem indicação dentro da janela terapêutica **E** atendam a um dos seguintes critérios:  
- <mark>Indivíduos de 0 a 40 anos, em situação de exposição confirmada, suspeita ou iminente ao iodo radioativo*;</mark> **<mark>OU</mark>**  
- <mark>Idade superior a 40 anos em cenários que a dose interna projetada de radiação para a tireoide for superior a 500 cGy (5 Gy)*;</mark> **<mark>OU</mark>**  
- <mark>Trabalhadores de emergência envolvidos em operações de resgate ou remediação devem ser incluídos na profilaxia independentemente da idade, dada a probabilidade de enfrentarem altas doses de radiação.</mark>  
Este Protocolo considera **janela terapêutica** o período compreendido entre 24 horas antes da exposição ou até 2 horas após a exposição ao iodo radioativo, sendo ainda razoável até 8 horas após a exposição.  
**Nota:** * Tais definições para a recomendação de o uso do KI serão emitidas por equipe técnica da Autoridade Nacional de Segurança Nuclear (ANSN), que realizará a devida comunicação aos órgãos competentes, incluindo a autoridade sanitária.  
3

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 5. CRITÉRIOS DE EXCLUSÃO -->
Devem ser excluídos deste Protocolo indivíduos que apresentem alguma das seguintes condições de saúde<sup>13</sup> :  
- Hipersensibilidade comprovada ao Iodeto de Potássio ou ao iodo<sup>13</sup> ;  
- Síndrome de má absorção de glicose-galactose, pois o medicamento possui lactose em sua composição<sup>13</sup> .  
Notas:  
- A presença de metabissulfito de sódio que pode causar reações alérgicas em pessoas susceptíveis<sup>13</sup> .  
- Pessoas portadoras de dermatite herpetiforme e de vasculite hipocomplementêmica apresentam um maior risco de desenvolverem reações severas de hipersensibilidade<sup>13</sup> .  
- Indivíduos com bócio multinodular, tireoidite de Hashimoto, Doença de Graves e outras doenças autoimunes da glândula tireoide devem ser tratados com precaução, especialmente se a terapia necessitar de multidoses<sup>13</sup> .  
**Atenção:** Em cenário de emergência nuclear **,** na impossibilidade de verificação prévia das condições clínicas supracitadas, o KI deve ser administrado como medida de proteção radiológica para bloqueio tireoidiano. Nessa situação, os benefícios da intervenção superam os riscos potenciais de eventos adversos na população exposta, excetuando-se em indivíduos alérgicos ao iodo, com dermatite hipertiforme, vasculite hipocomplementêmica e doença nodular da tireoidite com doença cardíaca, os quais não devem fazer uso de KI<sup>13</sup> .

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 6.1. Tratamento medicamentoso -->
A administração do KI é uma medida de proteção essencial para prevenir efeitos determinísticos, como o hipotireoidismo, e reduzir riscos estocásticos, como o câncer de tireoide e a formação de nódulos benignos<sup>5</sup> . Em situações de exposição prolongada ou repetida onde a evacuação imediata não é viável, pode ser recomendada a administração de doses diárias; no entanto, o uso repetido deve ser evitado em recém-nascidos, gestantes, lactantes e idosos com mais de 60 anos para mitigar riscos de eventos adversos<sup>3, 14</sup> . Caso as autoridades avaliem que a evacuação ou o abrigamento não garantem proteção integral contra a pluma radioativa, o uso do KI deve ser implementado de forma paralela e imediata, integrando uma estratégia de proteção urgente e otimizada<sup>15-16</sup> .  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste Protocolo de Uso para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores  
4  
resultados em saúde, ao incentivar o uso apropriado dos medicamentos indicados, seguros e efetivos, ao estimular a adesão ao tratamento e ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
- 6.1.1. Medicamentos  
- Iodeto de potássio: comprimidos de 130 mg ou xarope de 20 mg/mL.  
- 6.1.2. Preparo e armazenamento  
O KI é disponibilizado pelo SUS nas apresentações de comprimidos de 130 mg e xarope na concentração de 20 mg/mL.  
Cada comprimido de KI contém 130 mg, equivalente a 100 mg de iodo. Apresenta-se como um comprimido branco, de formato circular e plano, sulcado em duas faces, sem sabor e odor específicos. Além do princípio ativo, o comprimido apresenta excipientes como lactose, celulose microcristalina, estearato de magnésio, amidoglicolato de sódio, dióxido de silício e metabissulfito de sódio.  
O xarope apresenta concentração de 20 mg/mL e é acondicionado, com aspecto límpido e vermelho, em frasco de plástico âmbar com volume de 100 mL. Trata-se de um medicamento com notificação simplificada, conforme estabelecido pela Resolução da Diretoria Colegiada nº 576/2021. Possui odor e sabor característico de _tutti-frutti_ , o que contribui para a aceitação e facilita a administração por via oral, especialmente em tratamentos de uso contínuo.  
O medicamento pode ser administrado com alimentos ou leite, visando a reduzir a irritação gástrica. Os comprimidos podem ser triturados e misturados a diversos líquidos quando necessário. Para preparar uma mistura líquida a partir de comprimidos, deve‑se triturar o comprimido em uma tigela até obter um pó fino, sem fragmentos grandes, e adicionar quatro colheres de chá de água, misturando até completa dissolução. Em seguida, essa solução deve ser combinada com quatro colheres de chá de leite desnatado (branco ou achocolatado), suco de laranjaxarope de framboesa ou fórmula infantil. Quando a mistura é preparada utilizando comprimidos de 130 mg, a concentração resultante é de 16,25 mg por colher de chá, correspondendo a doses equivalentes de 65 mg para quatro colheres de chá e 32,5 mg para duas colheres de chá. A preparação deve ser mantida sob refrigeração e permanece estável por até sete dias<sup>17</sup> .  
Para garantir a eficácia do KI, a logística de armazenamento é fundamental, exigindo que os comprimidos sejam mantidos em sua embalagem original hermética para proteção total contra umidade, ar, calor e luz<sup>12,18</sup> . O local de guarda deve ser seco, escuro e absolutamente fora do alcance de crianças<sup>12,19</sup> .  
5

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 6.1.3. Esquemas de administração -->
As recomendações posológicas segundo a faixa etária encontram-se descritas no Quadro abaixo.  
**Quadro 1:** Recomendações de dosagens e formas de apresentação de iodeto de potássio conforme faixa etária dos grupos prioritários segundo OMS<sup>3,12,15</sup> .  
|**Faixa Etária**|**Dose equivalente**<br>**de Iodo (mg)**|**Dose de KI**<br>**(mg)**|**Posologia**|
|---|---|---|---|
|Adultos e adolescentes|||1 comprimido de 130 mg|
|acima<br>de<br>12<br>anos<br>(completos)|100|130|OU<br>6,5mL do xarope 20mg/mL|
||||3,5 mL do xarope de 20 mg/mL|
|Crianças de 3 anos<br>completos a 12 anos<br>incompletos<br>(11 anos, 11 meses e 29<br>dias)|50|65|OU<br>½ de comprimido de 130mg- Pode<br>ser dissolvido 1 comprimido com 8<br>colheres de chá de algum líquido<br>disponível e ser administrar 4<br>colheres de chá destapreparação.|
|Crianças de 1 mês<br>completo a 3 anos<br>incompletos (2 anos, 11<br>meses e 29 dias|25|32|2,0 mL do xarope de 20 mg/mL<br>OU<br>¼ de comprimido de 130mg- Pode<br>ser dissolvido 1 comprimido com 8<br>colheres de chá de algum líquido<br>disponível e ser administrado 2<br>colheres de chá destapreparação.|
||||1,0 mL do xarope 20 mg/mL<br>OU|
|Recém-nascidos (até 1<br>mês)|12,5|16|1/8 de comprimido de 130mg- Pode<br>ser dissolvido 1 comprimido com 8<br>colheres de chá de algum líquido<br>disponível e administrar 1 colher de<br>chá destapreparação|  
**Fonte:** Adaptado _de Guidelines for iodine prophylaxis following nuclear accidents_ . Copenhagen: WHO Regional Office for Europe; 1989; 38. Superseded by 1999 update. World Health Organization- WHO. Iodine thyroid blocking. Guidelines for use in planning and responding to radiological and nuclear emergencies, 2017. International Atomic Energy Agency- IAEA. Medical Management of Persons Internally Contaminated with Radionuclides in a Nuclear or Radiological Emergency, 2018.  
Ressalta-se que as doses do xarope de iodeto de potássio foram alteradas para facilitar sua administração, sem comprometimento de seu efeito.  
6

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 6.1.4. Critérios de interrupção -->
O uso do KI deve ser interrompido com a cessação do risco de exposição ao iodo radioativo, uma vez que sua administração sem exposição contínua aumenta o risco de eventos adversos sem benefício adicional<sup>20</sup> . A profilaxia também não deve ser mantida após 24 horas da exposição inicial, pois o uso tardio pode prolongar a meia-vida biológica do iodo radioativo já incorporado à glândula tireoide<sup>21</sup> .  
Caso haja risco de continuidade de exposição ao iodo radioativo, esta dose deverá ser repetida diariamente até que outras medidas de proteção, como a evacuação, tornem a administração do produto desnecessária.  
Para grupos específicos como recém-nascidos, gestantes, lactantes e idosos com mais de 60 anos, a profilaxia deve ser interrompida preferencialmente após uma única dose, para mitigar o risco de bloqueio da função tireoidiana neonatal ou o desenvolvimento de hipotireoidismo<sup>12, 3,</sup> 22.  
No caso de crianças que apresentem reações cutâneas após a dose inicial, o tratamento deve ser interrompido, não sendo indicado doses subsequentes<sup>12,20</sup> . Embora a duração do tratamento possa ser estendida em situações de liberação prolongada do iodo radioativo, o uso diário para a população pode variar de um a sete dias, dependendo das orientações das autoridades de saúde baseadas na evolução da situação radiológica<sup>18</sup> . Contudo, a duração do tratamento será indicada pelo Centro de Coordenação e Controle de Emergência Nuclear, quando necessário.

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 6.1.5. Efeitos Adversos -->
Os efeitos adversos são situações prejudiciais ou indesejáveis que ocorrem durante ou após o uso de um medicamento, quando há plausibilidade de relação causal com a intervenção terapêutica<sup>15</sup> . Esses eventos são improváveis quando o KI é utilizado nas doses recomendadas e por curto período<sup>12</sup> .  
Os possíveis efeitos adversos do KI são<sup>15</sup> :  
- Alterações na tireoide, como bócio, hipertireoidismo e hipotireoidismo induzido por iodo;  
- Reações cutâneas como surtos de acne, pequenas erupções cutâneas e dermatite;  
- Distúrbios gastrointestinais, como náusea, vômitos, diarreia ou epigastralgia;  
- Sialodenite: inflamação em glândula salivar;  
- Iodismo: intoxicação pelo iodo devido a altas doses ou uso crônico, que pode cursar com gosto metálico, sensação de queimação na boca e garganta, dor em dentes e gengiva, cefaleia, desconforto epigástrico e diarreia;  
- Febre e artralgia;  
- Reações alérgicas, que geralmente são leves e de importância menor como rash cutâneo, e sendo muito rara a reação alérgica grave, como a anafilaxia.  
7  
Em caso de ocorrência de efeitos adversos deve-se interromper imediatamente o uso do medicamento e procurar a assistência médica. A notificação de um evento adverso deve ser feita à Agência Nacional de Vigilância Sanitária (Anvisa) pelo VigiMed, ferramenta online (https://vigiflow-eforms.who-umc.org/br/vigimed).

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 6.1.6. Outras informações importantes -->
Como medida de saúde pública para prevenção da deficiência de iodo, esse micronutriente é adicionado ao sal de consumo humano em diversos países, incluindo o Brasil e os Estados Unidos, não devendo ser considerado um agente alergênico<sup>23</sup> .  
Destaca-se que alergia a frutos do mar não significa alergia ao iodo, pois está associada a proteínas presentes nos frutos do mar<sup>24</sup> . As reações a contraste iodado também não devem ser consideradas evidência de alergia ao iodo, ainda que os alérgenos correspondentes destes contrastes não tenham sido identificados, o iodo não está envolvido. A dermatite de contato alérgica a preparações antibacterianas contendo iodo (Ex: Povidine®) não é considerada evidência de alergia ao iodo e sim ao componente povidona<sup>23</sup> .

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 7. MONITORAMENTO -->
O monitoramento de uso do iodeto de potássio deve ocorrer conforme o grupo ou a situação disposto no **Quadro 2** .  
Quadro 2. Monitoramento de uso do iodeto de potássio conforme o grupo ou a situação.  
|**Grupo/ Situação**|**Conduta de acompanhamento**|
|---|---|
|**População geral**|Avaliação clínica da função tireoidiana, vigilância de efeitos<br>adversos e monitoramento prolongado para identificação<br>precoce de disfunções relacionadas à exposição ao iodo<br>radioativo.|
|**Grupos vulneráveis**<br>(crianças, gestantes,<br>lactantes, recém-nascidos,<br>idosos)|Seguimento rigoroso devido à maior suscetibilidade a efeitos da<br>radiação e potenciais efeitos adversos do KI.|
|**Neonatos e bebês**|Monitorar função tireoidiana (TSH e, se indicado, T4 livre).<br>Avaliação médica cerca de 2 semanas após a administração;<br>instituir reposição hormonal se houver hipotireoidismo.|
|**Crianças < 1 ano e**<br>**lactentes**|Dosagem de TSH e T4 livre cerca de 2 semanas após o uso;<br>considerar tratamento em caso de hipotireoidismo.<br>Em recém-nascidos monitorar T3 total.<br> <br> <br> <br> <br>|
|**Gestantes e fetos (>12ª**<br>**semana)**|Monitoramento<br>da<br>função<br>tireoidiana<br>materna;<br>acompanhamento ultrassonográfico fetal até o parto; avaliação<br>neonatal(TSH e T4 livre).|
|**Lactentes amamentados**<br>**por mãesque usaram KI**|Avaliação da função tireoidiana para detecção precoce de<br>disfunções.|  
8  
|**Grupo/ Situação**|**Conduta de acompanhamento**|
|---|---|
|**Pacientes sintomáticos ou**<br>**de risco**|Dosagem de TSH, T4 livre e T3 total.|
|**Pacientes com reações**<br>**adversas graves**<br>(angioedema, exantema,<br>dor abdominal, entre<br>outros)|Encaminhamento imediato para atenção especializada e realizar<br>exames complementares conforme a clínica apresentada|
|**Trabalhadores de**<br>**emergência**|Seguimento contínuo; exames de pele e hemograma semanal<br>por até 3 meses após o término das operações.|  
Fonte:<sup>12, 25, 26-32, 22, 18.</sup>  
Em cenários de emergência nuclear com o uso de KI, recomenda-se que os serviços de saúde e a equipe responsável pela dispensação adotem a orientação acerca do uso, contemplando data e hora da administração, unidades administradas, identificação do usuário, lote e validade do medicamento<sup>20, 22</sup> . A população deve ser orientada a observar e relatar possíveis eventos adversos e buscar atendimento em caso de sinais importantes ou inesperados. As suspeitas de reações adversas devem ser notificadas ao sistema da Anvisa, conforme orientação no item _Eventos Adversos_ .

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento póstratamento. Pacientes com alterações laboratoriais persistentes, manifestações clínicas graves ou pertencentes a grupos prioritários devem ser atendidas em serviços especializados.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 9. REFERÊNCIAS -->
1. International Atomic Energy Agency. Preparedness and response for a nuclear or radiological emergency. Vienna: IAEA; 2015.  
2. Długosz-Lisiecka M. Public health decision making in the case of the use of a nuclear weapon. Int J Environ Res Public Health. 2022;19(19):12766.  
3. World Health Organization. Iodine thyroid blocking: guidelines for use in planning for and responding to radiological and nuclear emergencies. Geneva: WHO; 2017.  
4. Drozdovitch V. Radiation exposure to the thyroid after the Chernobyl accident. Front Endocrinol (Lausanne). 2021;11.  
9  
5. World Health Organization. The human consequences of the Chernobyl nuclear accident: a strategy for recovery. Geneva: WHO; 2002.  
6. Zaletel K, Mihovec A, Gaberscek S. Characteristics of exposure to radioactive iodine during a nuclear incident. Radiol Oncol. 2024.  
7. Sivintsev YV. Radioactive iodine in the problem of radiation safety. Sov At Energy. 1974;36(4):363–4.  
8. Pochin EE, Barnaby CF. The effect of pharmacological doses of non-radioactive iodide on the course of radioiodine uptake by the thyroid. Health Phys. 1962;7(3):125–6.  
9. Jang M, et al. Age-dependent potassium iodide effect on thyroid irradiation by 131I and 133I in a nuclear emergency. Radiat Prot Dosimetry. 2008;130(4):499–502.  
10. Brasil. Comissão Nacional de Energia Nuclear. Requisitos básicos de radioproteção e segurança radiológica de fontes de radiação: Norma CNEN NN 3.01. Rio de Janeiro: CNEN; 2024.  
11. Brasil. Lei nº 8.080, de 19 de setembro de 1990. Dispõe sobre as condições para a promoção, proteção e recuperação da saúde, a organização e o funcionamento dos serviços correspondentes e dá outras providências. Diário Oficial da União. 1990 set 20.  
12. World Health Organization, et al. Guidelines for iodine prophylaxis following nuclear accidents: update 1999. Geneva: WHO; 1999.  
13. LAQFA – Laboratório Químico-Farmacêutico da Aeronáutica. Iodeto de potássio 130 mg: bula profissional [Internet]. [s.l.]: LAQFA; [s.d.].  
14. Calcaterra V, et al. The iodine rush: over- or under-iodination risk in the prophylactic use of iodine for thyroid blocking in the event of a nuclear disaster. Front Endocrinol (Lausanne). 2022;13:901620.  
15. International Atomic Energy Agency. Medical management of persons internally contaminated with radionuclides in a nuclear or radiological emergency. Vienna: IAEA; 2018.  
16. Brasil. Comissão Nacional de Energia Nuclear. Guia Regulatório GR 3.01-01: elaboração da estratégia de proteção para a resposta a uma emergência nuclear ou radiológica e níveis de intervenção operacionais. Rio de Janeiro: CNEN; 2024.  
17. Potassium iodide. In: Merative Micromedex® DRUGDEX® [Internet]. Greenwood Village (CO): Merative Healthcare Solutions; 2026 [cited 2026 Feb 25].  
18. Benderitter M, et al. Potassium iodide (KI) prophylaxis in the case of a nuclear accident: a new marketing authorization in France. Environ Adv. 2022;9:100293.  
19. Bayrakova A, Kiradjiev G. Iodine prophylaxis in cases of radiation accidents: preparedness in Bulgaria. 1997.  
20. National Research Council. Distribution and administration of potassium iodide in the event of a nuclear incident. Washington (DC): National Academies Press; 2004.  
21. Jaworska A. Jodprofylakse ved strålingsulykker. Tidsskr Nor Laegeforen. 2007.  
22. UK Health Security Agency. Protocol for the administration of potassium iodide tablets. London: UKHSA; 2021.  
23. Bacharel APR. Alérgenos potenciais em excipientes farmacêuticos [monografia]. 2022. 24. United States. Food and Drug Administration. Frequently asked questions on potassium iodide (KI). Silver Spring (MD): FDA; 2015.  
25. Leung AM, et al. American Thyroid Association scientific statement on the use of potassium iodide ingestion in a nuclear emergency. Thyroid. 2017;27(7):865–77.  
26. Da Silva Lopes JP, Barbosa J, Dinis-Oliveira RJ. Clinical and forensic aspects of potassium iodide: suddenly in high demand across Europe due to fears of radiation poisoning from a nuclear attack in Ukraine. Basic Clin Pharmacol Toxicol. 2024;135(3):250–70.  
27. Braverman E, et al. Managing terrorism or accidental nuclear errors: preparing for iodine131 emergencies. Int J Environ Res Public Health. 2014;11(4):4158–200.  
10  
28. Reiners C, Schneider R. Potassium iodide (KI) to block the thyroid from exposure to I-131: current questions and answers to be discussed. Radiat Environ Biophys. 2013;52:189–93.  
29. Sase E, Eddy C, Polivka BJ. Lessons from Fukushima: potassium iodide after a nuclear disaster. Am J Nurs. 2021;121(2):63–7.  
30. Torti JF, Correa R. Potassium iodide. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2025.  
31. United States. Food and Drug Administration. Guidance: potassium iodide as a thyroid blocking agent in radiation emergencies. Silver Spring (MD): FDA; 2001.  
32. Wada K, et al. Emergency response technical work at Fukushima Dai-ichi nuclear power plant: occupational health challenges posed by the nuclear disaster. Occup Environ Med. 2012;69(8):599–602.  
11  
APÊNDICE 1 - METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 1. Escopo e finalidade do Protocolo -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da elaboração do Protocolo de Uso do Iodeto de Potássio (KI) na Emergência Nuclear contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Etapas do processo de elaboração  
A elaboração do Protocolo de Uso do KI na Emergência Nuclear teve início com a reunião de pré-escopo, realizada em abril de 2024, que contou com a participação de representantes da SCTIE, SAES e SVSA.  
Nessa ocasião, foram definidas as prioridades a partir do documento base inicialmente proposto, o escopo preliminar do documento, a população-alvo e os principais objetivos a serem contemplados. Essa discussão inicial também permitiu estabelecer a articulação intersetorial necessária, bem como pactuar responsabilidades e diretrizes gerais para a condução do trabalho.  
Com a definição do escopo, iniciou-se a etapa de busca por documentos técnicos que fundamentassem o conteúdo do Protocolo de Uso. Esses materiais serviram de base para a organização das seções e para a estruturação dos eixos temáticos essenciais, incluindo critérios de indicação, orientações operacionais e recomendações para implementação. A partir dessas informações, foi elaborada a primeira versão do texto, contendo a estrutura inicial e os elementos centrais que seriam posteriormente refinados.  
Com a versão preliminar concluída, iniciou-se uma etapa de consulta aos especialistas da área de emergência nuclear e temas correlatos, tais como Fundação Eletronuclear de Assistência Médica (FEAM), Gabinete de Segurança Institucional da Presidência da República (GSI/PR), Autoridade Nacional de Segurança Nuclear (ANSN), Secretaria Municipal de Saúde de Angra dos Reis (SMS-AR), Secretaria Estadual de Saúde do Rio de Janeiro (SES-RJ) e Ministério da Defesa, a fim de receber contribuições. Essa consulta teve por finalidade qualificar o conteúdo técnico, assegurar a consistência com as melhores práticas internacionais e promover o alinhamento com os demais marcos normativos existentes.  
Posteriormente, outras secretarias do Ministério da Saúde também foram envolvidas, possibilitando ampla revisão intersetorial e garantindo que o Protocolo de Uso estivesse alinhado às políticas públicas e às atribuições das diferentes instâncias envolvidas na resposta a emergências radiológicas e nucleares.  
As sugestões recebidas foram avaliadas quanto à pertinência técnica e operacional, resultando em ajustes, correções e aprimoramentos do texto. Após consolidação das modificações, foi realizada a etapa de validação final, que envolveu revisão editorial, padronização terminológica e validação técnica. O documento final resultante reflete o consenso institucional e técnico das áreas envolvidas, incorporando evidências científicas, recomendações  
12  
normativas e considerações operacionais necessárias para orientar o uso do iodeto de potássio no contexto de emergências nucleares.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do Protocolo de Uso do Iodeto de Potássio na Emergência Nuclear foi apresentada na 134ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 24/03/2026. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 150ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
Consulta pública  
A Consulta Pública nº 36/2026, para a atualização do Protocolo de Uso do Iodeto de Potássio na Emergência Nuclear, foi realizada entre os dias 14/05/2026 e 02/06/2026. Foram recebidas 47 contribuições, que podem ser verificadas em: (https://www.gov.br/pt- <u>br/midias/consultas/relatorios/2026/relatorio-preliminar-pu-emergencia-nuclear-cp-36).</u>

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: 2. Busca da evidência e recomendações -->
A busca de evidências destinada a subsidiar a elaboração deste Protocolo foi realizada em julho de 2025 e teve como objetivo identificar diretrizes técnicas, recomendações operacionais e documentos normativos relacionados ao uso do iodeto de potássio em situações de emergências radiológicas e nucleares. Para isso, foram consultadas a base PubMed e diferentes fontes de literatura cinzenta, permitindo a identificação de materiais provenientes de órgãos reguladores, instituições governamentais, organizações multilaterais e serviços especializados em proteção radiológica.  
A estratégia de busca foi construída com base na combinação de descritores controlados, incluindo termos MeSH e DeCS, associados a termos livres relacionados ao uso de KI, iodoprofilaxia e emergências nucleares. Os termos foram organizados por operadores booleanos de forma a maximizar a sensibilidade e a precisão da recuperação dos documentos. As estratégias utilizadas incluem os seguintes termos: (Guideline OR Practice Guideline OR Protocols OR Disaster Planning) AND (Potassium Iodide OR Iodine OR Iodine Prophylaxis OR KI Prophylaxis OR Potassium Iodine) AND (Nuclear Emergency OR Nuclear Accidents OR Radiation Accident OR Radiation Exposure OR Radiological Emergency).  
A escolha da base PubMed, associada à literatura cinzenta, justificou-se pela amplitude e pela relevância das publicações nelas indexadas, assegurando maior representatividade das evidências disponíveis.  
13  
Os documentos identificados foram inicialmente triados por meio da leitura de títulos e resumos, seguida de avaliação do conteúdo, para determinar sua adequação ao escopo deste Protocolo. Foram priorizados materiais de reconhecida credibilidade institucional, orientações normativas, diretrizes clínicas e operacionais. A partir dessa seleção, foram extraídas informações relativas às indicações de uso do KI, contraindicações, regimes posológicos, preparo e armazenamento, janelas de administração, eventos adversos e monitoramento.  
A síntese das evidências permitiu identificar convergências entre as recomendações internacionais e boas práticas consolidadas, bem como especificidades operacionais relevantes para o contexto brasileiro. Com base nessa análise, foram formuladas as recomendações contidas neste Protocolo, buscando integrar a melhor evidência disponível, a viabilidade operacional no Sistema Único de Saúde e as diretrizes normativas aplicáveis. A formulação das recomendações considerou o equilíbrio entre benefício e risco, a aplicabilidade em diferentes cenários de emergência e a coerência com marcos regulatórios nacionais e internacionais relacionados à proteção radiológica.  
Ressalta-se que o uso do KI na emergência nuclear é respaldado por evidências científicas acumuladas ao longo de eventos nucleares anteriores e por diretrizes técnicas estabelecidas internacionalmente. Contudo, em razão da natureza episódica e imprevisível desses eventos, os estudos primários são limitados, o que restringe análises comparativas mais robustas e a avaliação aprofundada da qualidade metodológica das evidências disponíveis. Ainda assim, as recomendações vigentes fundamentam-se na melhor evidência científica possível, complementada por consenso técnico especializado e princípios consolidados de proteção radiológica.  
3. Equipe de elaboração e partes interessadas  
A elaboração do Protocolo de Uso foi realizada pela Coordenação geral de Preparação para as Emergências em Saúde Pública (CGPRESP/DEMSP/SVSA/MS).  
Colaboração externa  
Os membros do Grupo Elaborador e os participantes das reuniões de elaboração do referido PCDT estão descritos no Quadro A.  
Quadro A. Membros do Grupo Elaborador e participantes das reuniões de elaboração.  
|**Participante**|
|---|
|JulyGrassielyde Oliveira Branco|
|Sabrina Araujo de Melo|
|Taynná Vernalha Rocha Almeida|
|Nara Amanda Laismann|
|Eduarda Souza da Silva|
|Rodrigo Ramos de Sena|  
14  
|**Participante**|
|---|
|Flavia Avelino Goursand|
|Thais Piazza de Melo|
|Davi Christ Fassano Cesar|
|Jair dos Santos Oliveira|
|Raul dos Santos|
|Cristina Freire da Silva|
|Carlos Weizel de Fontoura Barreto Junior|
|Teresa Cristina Sampaio de Barros Leite|
|Romário Gabriel Aquino|
|Samara Carolina Rodrigues|
|Eduardo Barbosa Coelho|

---

<!-- METADADOS: doenca: Protocolo Uso KI Emergência Nuclear | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro B).  
Quadro B. Questionário de conflitos de interesse das diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar fi<br>algum dos benefícios abaixo?|nanceiramente|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>( ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>( ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>( ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>( ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>( ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>( ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma<br>forma ser beneficiada ouprejudicada com as recomendações da diretriz?|(   ) Sim<br>( ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>( ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cu<br>possam ser afetadospela sua atividade na elaboração ou revisão da diretriz?|jos interesses|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>( )Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>( ) Não|  
15  
|d) Partido político|(   ) Sim<br>( ) Não|
|---|---|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>( ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>( ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>( ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos<br>interessespossam ser afetados?|(   ) Sim<br>( ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer<br>oquevocê irá escrever eque deveria ser do conhecimentopúblico?|(   ) Sim<br>( ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja|(   ) Sim|
|relacionado acima, quepossa afetar sua objetividade ou imparcialidade?|( ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?|(   ) Sim<br>( ) Não|  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração está no Quadro C.  
Quadro C. Declaração de conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração.  
|**Participante**|**Conflitos de**|**interesses declarados**|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descriçãogeral**|**tomada**|
|July Grassiely de Oliveira Branco|-|-|Declarar e<br>participar|
|Sabrina Araujo de Melo|-|-|Declarar e<br>participar|
|Taynná Vernalha Rocha Almeida|-|-|Declarar e<br>participar|
|Nara Amanda Laismann|-|-|Declarar e<br>participar|
|Eduarda Souza da Silva|-|-|Declarar e<br>participar|
|Rodrigo Ramos de Sena|-|-|Declarar e<br>participar|
|Flavia Avelino Goursand|-|-|Declarar e<br>participar|
|Thais Piazza de Melo|-|-|Declarar e<br>participar|
|Davi Christ Fassano Cesar|-|-|Declarar e<br>participar|
|Jair dos Santos Oliveira|-|-|Declarar e<br>participar|
|Raul dos Santos|-|-|Declarar e<br>participar|
|Cristina Freire da Silva|-|-|Declarar e<br>participar|  
16  
|**Participante**|**Conflitos de**<br>|**interesses declarados**<br>|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descriçãogeral**|**tomada**|
|Carlos Weizel de Fontoura Barreto<br>Junior|-|-|Declarar e<br>participar|
|Teresa Cristina Sampaio de Barros<br>Leite|-|-|Declarar e<br>participar|
|Romário Gabriel Aquino|-|-|Declarar e<br>participar|
|Samara Carolina Rodrigues|-|-|Declarar e<br>participar|
|Eduardo Barbosa Coelho|-|-|Declarar e<br>participar|  
17  
APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO  
|**Número do**<br>||**Tecnologias av**|**aliadaspela Conitec**|
|---|---|---|---|
|**Relatório da diretriz**<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Não incorporação ou não alteração**<br>**no SUS**|
|Relatório<br>de||||
|Recomendação<br>n°|Primeira|||
|1.129/2026. [Portaria|versão<br>do|-|-|
|SCTIE/MS nº 55, de|Protocolo|||
|01/09/2026].||||  
18

---

