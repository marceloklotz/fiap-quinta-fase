<!-- METADADOS: doenca: Doença de Pompe | secao: Geral -->
<!-- Start of picture text -->
ae<br>Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 12, DE 03 DE AGOSTO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Pompe.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas  atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a doença de Pompe no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação n<sup><u>o</u></sup> 470/2019 e n<sup><u>o</u></sup> 521/2020 e os relatórios de recomendação n<sup><u>o</u></sup> 481 – Outubro de 2019 e n<sup><u>o</u></sup> 529 – Junho de 2020, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença  
de Pompe.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da doença de Pompe, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento doença de Pompe.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença  
em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do Art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: LUIZ OTAVIO FRANCO DUARTE -->
HÉLIO ANGOTTI NETO  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOENÇA DE POMPE

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **1. INTRODUÇÃO** -->
A doença de Pompe (DP), também conhecida como glicogenose tipo II ou deficiência de maltase ácida é uma doença genética rara, de acometimento neuromuscular progressivo e frequentemente fatal nas formas mais graves, causada por variantes patogênicas bialélicas no gene _GAA_ , localizado no cromossomo 17q25.2-q25.3. Em consequência, existe atividade deficiente da alfa glicosidase ácida (sinônimo: maltase ácida), enzima lisossômica que libera glicose a partir do glicogênio, conforme a demanda de energia celular. A deficiência dessa enzima leva a um acúmulo de glicogênio dentro dos lisossomos e do citoplasma de múltiplos tecidos, incluindo a musculatura lisa, esquelética e cardíaca. Esse acúmulo acaba danificando o funcionamento celular e destruindo as células, por hipertrofia e ruptura dos lisossomos<sup>1-6</sup> . Associa-se a esse processo fisiopatológico um acúmulo do material a ser processado pelas vias autofágicas<sup>7</sup> .  
Mais de 600 variantes patogênicas já foram relatadas no gene _GAA_<sup>8</sup> . Como regra, a atividade enzimática correlaciona-se com a idade de início e a taxa de progressão da doença, sendo algumas variantes responsáveis por ausência de atividade enzimática e resultando na DP de início precoce, infantil ou clássica - a forma mais grave da doença. Várias combinações de variantes que resultem em alguma atividade enzimática causam uma doença com início mais tardio e com progressão mais lenta, proporcional à atividade residual da enzima<sup>1</sup> .  
A DP pode ser classificada em grupos A, B, C e D de acordo com a idade do início dos sintomas, acometimento cardíaco e velocidade de progressão da doença. A forma com início dos sintomas antes dos 12 meses de idade - grupo A - possui cardiomiopatia hipertrófica, afetando principalmente a parede ventricular esquerda posterior e o septo interventricular, e inclui pacientes tipicamente classificados como tendo a DP infantil clássica. Foi originalmente descrita por Pompe em 1932, sendo causada pela deficiência completa de alfa glicosidase ácida e tipicamente associada a sintomas mais graves<sup>2</sup> . Pode aparecer muito precocemente, ainda intra-útero ou, mais frequentemente, nos primeiros  
meses de vida, entre 1,6 e 2 meses em média. Caracteriza-se por fraqueza muscular generalizada e cardiomegalia<sup>1</sup> . Na ausência de tratamento, a taxa de mortalidade é alta aos 12 meses de vida<sup>9, 10</sup> .  
Já o grupo B inclui pacientes cujo início dos sintomas ocorre também antes dos 12 meses de idade; no entanto, não têm cardiomiopatia hipertrófica, sendo esses pacientes frequentemente classificados de DP infantil "atípico". Os grupos A e B são também denominados de DP precoce<sup>1</sup> . O grupo C tem início dos sintomas após 12 meses de idade, mas ainda na infância, e mescla-se com os fenótipos que surgem até a adolescência (juvenil). As formas mais tardias de manifestação no adulto caracterizam o grupo D. Os grupos C e D têm evolução mais lenta e têm como características clínicas principais a miopatia, a insuficiência respiratória crônica, ausência de cardiomiopatia hipertrófica e um variado espectro de sinais e sintomas<sup>11</sup> , sendo denominadas como DP tardia. A apresentação mais comum dessa forma é a fraqueza muscular proximal do tipo de cinturas, de membros inferiores e de tronco; apresentações mais raras incluem síndrome da espinha rígida, fraqueza da musculatura respiratória ou facial, ptose palpebral (uni ou bilateral) e oftalmoplegia. Anormalidades eletrocardiográficas são comuns, incluindo bloqueio completo cardíaco, taquiarritmias supraventriculares e ventriculares<sup>10</sup> .  
A DP pode aparecer tão tardiamente quanto na segunda ou até na sétima década de vida, com as mesmas características de fraqueza muscular descritas acima, como se fosse uma distrofia muscular ou polimiosite. Os adultos afetados descrevem, retrospectivamente, sintomas como dificuldade em participar de esportes na infância ou fadiga e dificuldade para levantar, subir escadas ou caminhar, eventualmente podendo não apresentar fraqueza<sup>12</sup> .  
A incidência global da DP é estimada em 1/40.000, sendo de 1/138.000 para os grupos A e B e de 1/57.000 para os grupos C e D. Influência étnica é identificada, pois a incidência da doença é maior entre afro-americanos (1/12.000) e chineses (1/40.000 a 1/50.000)<sup>1, 3</sup> . Dados obtidos a partir de registro internacional de pacientes com DP, independente da forma clínica, mostram que 53/763 (7%) pacientes são acompanhados na América Latina<sup>13</sup> . Atualmente há, no Brasil, em torno de 106 pacientes em tratamento pela terapia de reposição enzimática (TRE) com DP<sup>14</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da doença de Pompe. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- E 74.0 - Doença de depósito de glicogênio

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **3. DIAGNÓSTICO** -->
A confirmação do diagnóstico de DP envolve exames bioquímicos ou genéticos que deverão ser realizados sempre que houver suspeita clínica oulaboratorial dessa doença. É importante ressaltar que o diagnóstico precoce é fundamental e que, no Brasil, ainda ocorre diagnóstico em estágio avançado da doença<sup>15</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 3.1.1. **Suspeita de DP Precoce** -->
A DP precoce deve ser suspeitada em indivíduos que apresentem pelo menos um dos seguintes sinais ou sintomas abaixo relacionados, especialmente se em combinação e iniciados durante o primeiro ano de vida<sup>10, 11, 16</sup> :  
- Hipotonia muscular importante, especialmente fraqueza muscular proximal em membros superiores e inferiores e em tronco;  
- atraso do desenvolvimento motor;  
- insuficiência respiratória grave, avaliada clinicamente;  
- cardiomiopatia hipertrófica;  
- cardiomegalia;  
- disfagia e distúrbios de deglutição;  
- macroglossia;  
- hepatomegalia;  
- irmão de qualquer sexo com DP;  
- níveis elevados de creatinoquinase (CK). A CK está uniformemente elevada na DP Precoce, atingindo até 2000 UI/L;  
- biópsia muscular com presença de vacúolos citoplasmáticos mostrando aumento da atividade lisossomal à reação pela fosfatase ácida e aumento do conteúdo de glicogênio pela coloração de ácido periódico de Schiff (PAS-positivo).

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 3.1.2. **Suspeita de DP Tardia** -->
A DP tardia possui apresentação clínica distinta, devendo ser suspeitada em indivíduos que apresentem pelo menos um dos seguintes sinais ou sintomas abaixo relacionado, especialmente se combinados e iniciados após 12 meses de idade<sup>1, 10, 11, 16, 17</sup> :  
- Fraqueza muscular proximal progressiva, especialmente em tronco e membros inferiores;  
- levantar da posição em decúbito utilizando uma rotação lateral do corpo;  
- sinal de _Gowers_ ;  
- escápula alada, atrofia do músculo paraespinhal;  
- síndrome da espinha rígida;  
- fraqueza facial ou ptose palpebral (uni ou bilateral), oftalmoplegia;  
- alterações eletrocardiográficas como taquiarritimias ventriculares e supraventriculares, síndrome Wolff–Parkinson–White;  
- irmão de qualquer sexo com DP;  
- progressão de sintomas respiratórios para insuficiência respiratória por fraqueza muscular diafragmática e intercostal, desencadeados por infecção, cirurgias ou aspiração;  
- níveis elevados de creatinoquinase (CK): A CK está elevada na forma juvenil (grupo C), podendo estar normal na DP Tardia (grupo D);  
- níveis elevados de transaminases hepáticas [alanina aminotransferase ou transaminase glutâmico pirúvica – (ALT/TGP) e aspartato aminotransferase ou transaminase oxalacética (AST/TGO)] e lactato desidrogenase (LDH), com a gama glutamiltransferase (gama GT) normal;  
- eletromiografia (EMG) com características miopáticas<sup>6,</sup> 17. O EMG deve preferencialmente avaliar a musculatura paraespinhal ou esternocleidomastodeo<sup>11</sup> ;  
- biópsia muscular com presença de vacúolos citoplasmáticos mostrando aumento da atividade lisossomal à reação pela fosfatase ácida e aumento do conteúdo de glicogênio pela coloração de ácido periódico de Schiff (PAS-positivo)<sup>1, 6, 18</sup> ;

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 3.2.1. **Atividade da alfa glicosidade ácida** -->
O diagnóstico da DP pode ser suspeito medindo-se a atividade da alfa glicosidase ácida em papel filtro nos pacientes com quadro clínico compatível<sup>19-21</sup> e valores de referência na população brasileira estão disponíveis<sup>21</sup> ; porém, esse resultado deve ser confirmado por meio da medida da enzima alfa glicosidase ácida em outro tecido, uma vez que a sensibilidade e especificidade do teste em papel filtro dependem, entre outros, do método utilizado e de condições de transporte e armazenamento<sup>1</sup> . É na cultura de fibroblastos de pele que há maior atividade enzimática e é este o tecido considerado “padrão-ouro” para o diagnóstico. Os linfócitos purificados também são utilizados<sup>1</sup> . Devido ao fato de que os ensaios enzimáticos também apresentam limitações para discriminar entre pseudodeficiência, heterozigotos e homozigotos/heterozigotos compostos afetados, a análise genética pode ser indicada para estabelecer o diagnóstico<sup>22</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 3.2.2. **Teste genético** -->
A análise do gene _GAA_ não é sempre necessária, mas está principalmente indicada nas seguintes situações: atividade enzimática próxima ao normal e quadro clínico suspeito; suspeita de pseudodeficiência<sup>22</sup> ; aconselhamento genético; investigação de irmãos de pacientes cujas variantes patogênicas já tenham sido identificadas<sup>23</sup> . Além disso, o genótipo pode auxiliar na predição do quadro clinico associado e na ocorrência de eventos adversos à TRE<sup>24</sup> .  
Entre os pacientes com DP Precoce, por exemplo, o _status_ do material imunológico com reatividade cruzada (CRIM) é um importante preditor de resposta à TRE e de mortalidade e pode ser predito a partir do genótipo do paciente. Nos pacientes identificados como tendo _status_ CRIM negativo (CRIM-), nenhuma proteína GAA é sintetizada. Assim, a alfa-alglicosidase é reconhecida como uma proteína estranha pelo sistema imunológico nesses pacientes, resultando no desenvolvimento de altos títulos de anticorpos neutralizantes que tornam a TRE ineficaz, com maior chance de eventos adversos<sup>10</sup> . Um estudo que analisou as variantes do gene _GAA_ em 243 pacientes com DP precoce mostrou que a maioria dos pacientes CRIM- eram homozigotos ou heterozigotos compostos para variantes sem sentido oucom alteração da fase de leitura, resultando em códons de parada prematuros ou deleções com vários éxons e, consequentemente, em  
5.1.  
falta de produção da proteína. Por outro lado, a maioria dos pacientes CRIM+ apresentou 1 ou 2 variantes de tipo _missense_ ou deleção que não alterava a fase de leitura<sup>10, 25</sup> . A determinação do CRIM é disponível como pesquisa em centros internacionais. Na pratica clínica, usa-se o genótipo para sua predição.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo todos os pacientes com DP precoce (grupos A e B) ou tardia (grupos C e D) que apresentarem pelo menos um dos sinais ou sintomas descritos no item 3.1 (Suspeita Clínica), **E** confirmação do diagnóstico de acordo com um dos critérios abaixo relacionados:  
- Atividade da enzima alfa glicosidase ácida <10% do limite inferior dos valores de referência em fibroblastos ou leucócitos, com atividade da enzima de referência, avaliada na mesma amostra e pelo mesmo método, apresentando valores normais; **OU**  
- Presença de variantes patogênicas em homozigose ou heterozigose composta no gene _GAA_<sup>6</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 4.1. **Critérios de Inclusão para TRE** -->
Poderão fazer uso de alfa-alglicosidase todos os indivíduos com diagnóstico de DP (conforme item 3) do **tipo precoce (início dos sintomas até 12 meses de idade).**

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes sem o diagnóstico confirmatório de  
DP.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Critérios de Exclusão para TRE** -->
Serão excluídos do tratamento específico com alfa-alglicosidase os pacientes que se apresentarem nas seguintes situações:  
- Apresentarem a forma DP tardia;  
- Condição médica irreversível e que implique em sobrevida provavelmente inferior a 6 meses, como resultado da DP ou de outra doença associada, em acordo entre mais de  
um especialista e atestada por laudo médico;  
- Idade acima de 18 anos e que, após serem informados sobre os potenciais riscos e benefícios associados ao tratamento com alfa-alglicosidase, recusarem-se a serem tratados;  
- Histórico de falha de adesão, desde que previamente inseridos, sem sucesso, em ação educativa específica para melhora de adesão, ou seja, pacientes que, mesmo após essa intervenção, não comparecerem a pelo menos 50% do número de consultas ou de avaliações previstas em um ano.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 6.1. **Tratamento de suporte** -->
O tratamento de suporte deve ser oferecido a todo paciente com DP, independente da forma clinica, idade ou estagio da doença.  
O paciente deve ser acompanhado por equipe multidisciplinar experiente já que a doença é multissistêmica<sup>1,11,17</sup> e deve ser dirigido predominantemente para as manifestações respiratórias. As sessões de fisioterapia motora, pela fraqueza muscular, deverão ser igualmente indicadas, e para cirurgia de alterações articulares secundárias ao acometimento muscular, as equipes de ortopedia e fisiatria deverão ser consultadas.  
A fim de diminuir as exacerbações respiratórias, imunização com vacina contra influenza e doença pneumocócica está indicada. Além disso, quando ocorrerem, devem receber tratamento o mais precocemente possível, para, assim, diminuir riscos de complicações. Por fim, comorbidades como asma (tratamento estabelecido em PCDT específico)<sup>26</sup> e cardiopatia também devem ser tratadas adequadamente, com vistas a minimizar seu impacto na doença de base<sup>17</sup> . Por apresentarem dificuldade para tossir, manobras de remoção das secreções, tanto manuais quanto por aspiração, podem ser utilizadas<sup>11</sup> .  
Com vistas a preservar e otimizar a função muscular, prevenindo ou minimizando complicações secundárias e aumentando o benefício da TRE, a reabilitação deve incluir fisioterapia motora e respiratória, além conduta nutricional e de acompanhamento com as demais especialidades acima citadas<sup>11, 17</sup> . Inexistem diretrizes específicas para o fortalecimento muscular ou exercícios terapêuticos para indivíduos com DP.  
Exercício aeróbico submáximo parece melhorar força e função muscular por aumentar o _clearance_ do glicogênio acumulado<sup>17</sup> , devendo sempre ser indicado e  
programado por um profissional de reabilitação com experiencia na prática dessas atividades e na DP. Deve-se iniciar com intensidade leve, permitindo períodos de repouso, com aumento gradual até a intensidade moderada, atingindo níveis aeróbicos até 60%-70% do esforço máximo, 3 a 5 dias por semana<sup>11,17</sup> . Uma vez que exercícios podem levar os pacientes à descompensação pulmonar, uma avaliação prévia por pneumologista é recomendada<sup>17</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Contraturas musculares e deformidades dos membros** -->
Um programa preventivo de alongamentos diários deve ser iniciado precocemente e fazer parte da rotina do paciente, com vistas a prevenir e lentificar o desenvolvimento de contraturas musculares ou deformidades. Quando iniciados antes das alterações iniciarem, são mais efetivos, uma vez que são menos dolorosos<sup>11, 17</sup> . Órteses podem ser utilizadas como dispositivos corretivos complementares, já que o posicionamento correto do paciente tanto em pé quanto na cadeira de rodas auxilia a prevenir dor crônica, assim como lesões de pele e escaras<sup>11, 17</sup> , podendo ainda apresentar impacto positivo sobre a função cardíaca, respiratória e motora dos pacientes quando adequadamente indicada.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Deformidades da coluna** -->
Pacientes com DP podem desenvolver escoliose grave devido à fraqueza e à atrofia muscular. Até o momento, permanece como melhor opção para o tratamento da escoliose o tratamento cirúrgico, similar ao que é empregado em outras doenças neuromusculares. Nestas doenças, o tratamento é indicado para pacientes com ângulo de Cobb entre 30 e 40 graus; recomenda-se que o mesmo critério seja usado em pacientes com DP. É essencial que haja monitoramento da função respiratória, avaliando-se o risco pré-operatório; nos pacientes de maior risco, preconiza-se o uso noturno de suporte ventilatório para minimizar o risco da cirurgia. No pós-operatório, torna-se necessário o uso agressivo de ventilação mecânica, de modo a diminuir a morbidade. Além disso, após a cirurgia, deve-se fazer uso precoce de fisioterapia, mobilização (quando houver estabilidade do quadro clínico), controle da dor e higiene pulmonar. Não há comprovação de que o reparo cirúrgico das deformidades espinhais melhore a função pulmonar; ao invés disso, deve-se ter como o objetivo a melhora da postura sentada, o que permitirá o uso efetivo de cadeira de rodas, beneficiando a qualidade de vida do paciente<sup>17</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Osteopenia e Osteoporose** -->
Devido à presença de redução da densidade mineral óssea, preconiza-se a avaliação sistemática do equilíbrio e do risco de queda desses pacientes, com vistas a reduzir a ocorrência de fraturas. Uso de equipamentos de auxílio da marcha, como bengalas ou andadores também são recomendáveis. Suplementos de vitamina D e carbonato de cálcio devem ser utilizados quando houver alteração na densitometria óssea<sup>11, 17</sup> . O tratamento de osteoporose deve seguir o PCDT da Osteoporose, do Ministério da Saúde<sup>27</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Distúrbios de sono** -->
Durante o sono, pode ser ofertado oxigênio suplementar em casos de hipóxia, porém acompanhamento com com oximetria de pulso está indicado<sup>11, 17</sup> . A avaliação pneumológica é necessária para o adequado controle das complicações associadas.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Insuficiência respiratória** -->
Deve-se evitar intubação orotraqueal temporária para procedimentos sempre que possível, em vistas da dificuldade de reverter necessidade de ventilação mecânica nesses pacientes<sup>1</sup> . Entretanto, suporte ventilatório pode ser necessário, conforme indicação clínica<sup>1</sup> , preferencialmente instalado de forma precoce a fim de prevenir quadro de insuficiência ventilatória crônica, o qual aumenta o risco de morte. Eventualmente, sobretudo em quadros de exacerbação infecciosa aguda, pode também ser necessário o suporte ventilatório invasivo. A ventilação, quando indicada, deve ser realizada por uma equipe com experiência em suporte ventilatório de pacientes com doenças neuromusculares e eles devem ser extubados assim que possível. É importante sempre excluir atelectasias como causa da insuficiência ventilatória, especialmente em crianças<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Disfagia** -->
O acompanhamento com fonoaudiólogo é essencial para avaliar o risco de aspiração, com realização de fluoroscopia conforme indicação médica, podendo ser necessária a gastrostomia em alguns casos graves<sup>1,11,17</sup> . A gastrostomia percutânea endoscópica (GPE) é um procedimento que visa a proporcionar acesso prolongado aos alimentos para pacientes que são incapazes de manter uma ingesta alimentar adequada ou uma energia calórica adequada. A GPE é indicada para pacientes com doença grave, disfagia, risco de aspiração, perda de peso (> 10% em um ano) ou FVC <40%. A gastrostomia envolve, muitas vezes, a anestesia geral, que limita seu uso em pacientes  
com DP (ver Anestesia/Cirurgia) e precisa ser muito bem indicada. A principal indicação de GPE na prática clínica diária é para a nutrição enteral para pacientes com DP e importante disfagia<sup>11</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Anestesia/Cirurgia** -->
A equipe médica deve estar atenta para uma série de recomendações quando indicar uma cirurgia para pacientes com DP, pois o aumento do risco de complicações envolvendo anestesia é reconhecido<sup>1, 11</sup> . Pacientes com doenças neuromusculares em geral devido ao seu metabolismo podem ter um risco maior de eventos adversos a anestésicos, especialmente à combinação de halotano e succinilcolina.  
Considerar os seguintes aspectos para procedimentos cirúrgicos na DP (todos os grupos de pacientes com DP):  
- Realizar procedimentos anestésicos somente quando necessário;  
- combinar todos os procedimentos cirúrgicos de forma simultânea que requeiram anestesia para reduzir o risco de exposição ao anestésico;  
- evitar a intubação traqueal e, se indicado, certifique-se de que é realizado por um profissional experiente;  
- fazer uma supervisão intra-operatória rigorosa;  
- usar agentes inalatórios em pacientes não graves;  
- evitar agentes despolarizantes devido ao risco de hipercalemia;  
- monitorar o volume de fluido circulante;  
- realizar procedimentos cirúrgicos em hospitais com profissionais experientes no tratamento da DP.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Aconselhamento genético** -->
Por se tratar de doença genética, com risco de recorrência aumentado, a família e o paciente devem ser inseridos, assim que possível, em processo de aconselhamento genético a ser coordenado por profissional habilitado, usualmente médicos geneticistas.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Outras condições clínicas** -->
Uma vez que a fraqueza muscular pode levar a dificuldades na fonação, e consequentemente levar a maior esforço respiratório, adequada avaliação e tratamento dessas condições devem fazer parte do cuidado dos pacientes com DP. Além disso,  
desnutrição é uma comorbidade frequentemente presente e também pode contribuir para piora da mobilidade e da fraqueza muscular. Para o suporte nutricional e alimentar, é importante assegurar 30% do aporte calórico total em proteínas, especialmente na forma tardia da doença, e deve ser realizado com o apoio de nutricionista com experiência em doenças metabólicas<sup>1, 10, 11, 17</sup> .

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 6.2. **Tratamento medicamentoso** -->
A prevenção primária das manifestações clínicas e o tratamento das manifestações já estabelecidas na DP são realizados com a TRE para a forma precoce, administrando-se ao paciente uma maltase ácida recombinante humana (alfa-alglicosidase) produzida em células de ovário de hamsters chinês (CHO)<sup>1,</sup> 11. O tratamento é indicado independentemente da necessidade ou não de suporte ventilatório para todos os pacientes que apresentem pelo menos uma das manifestações clínicas encontradas em 3.1 Suspeita Diagnóstica e conforme os critérios de inclusão para TRE (sub-item 4.1).  
Alguns estudos já avaliaram o benefício de associar exercício físico à TRE, ainda sem evidência suficiente para indicar sua associação<sup>28, 29</sup> . O uso de pré-medicação pode ser considerado mesmo na ausência de reações à infusão, especialmente nos casos mais graves<sup>1.</sup>

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 6.2.1. **Fármaco** -->
- Alfa-alglicosidase ácida: frasco-ampola com 50 mg de pó liofilizado  
6.2.2. **Esquema de Administração**  
- Alfa-alglicosidase: 20 mg/kg, via intravenosa, a cada 15 dias.  
Cada frasco deve ser reconstituído com 10,3 mL de água para injeção (concentração final de 5 mg/mL) e, após, diluído em solução de cloreto de sódio 0,9 % até uma concentração final entre 0,5 mg e 4 mg/mL. A administração deve ser lenta, por meio de bomba de infusão IV. Iniciar com uma taxa de infusão de 1 mg/kg/hora e aumentar gradualmente para 2 mg/kg/hora a cada 30 minutos até o máximo de 7 mg/kg/hora<sup>1</sup> .  
Monitorizar a infusão a cada 15 minutos, especialmente em relação ao sistema  
cardiorespiratório, avaliando a ausculta respiratória, as frequências respiratória e cardíaca e a pressão arterial antes e durante a infusão<sup>1</sup> . A infusão deve ser feita em ambiente hospitalar ou ambulatorial. Infusões domiciliares podem ser consideradas após 6 meses de tratamento sem intercorrências.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 6.2.3. **Tempo de Tratamento – Critérios de Interrupção** -->
O tempo de tratamento não é pré-determinado, mas, a princípio, devido às características da doença e à ausência de tratamento específico alternativo, deve ser mantido por toda a vida do paciente. A TRE deve ser interrompida na ocorrência de pelo menos uma das seguintes situações<sup>1, 10, 30, 31</sup> :  
- a) Em pacientes que iniciarão tratamento ou que estão em tratamento há menos de um ano: quando não houver redução da massa do VE após um ano de tratamento em pelo menos 62 g/m² ou de 4 pontos (escore Z) ou que desenvolverem aumento de massa de VE após início do tratamento, quando este não estava presente;  
- b) em pacientes que estão em tratamento há mais de um ano: quando houver aumento de massa de VE em relação ao exame realizado no mês 12 após início do tratamento;  
- c) pacientes que desenvolverem condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como resultado da DP ou de outra doença associada, em acordo entre mais de um especialista e atestada por laudo médico;  
- d) pacientes que não apresentarem pelo menos 50% de adesão ao número de infusões previstas em um ano; ou ao número de consultas previstas em um ano; ou ao número de avaliações previstas em um ano com o médico responsável pelo seguimento do paciente, desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que mesmo após o programa não comparecerem a pelo menos 50% do número de infusões, consultas ou de avaliações previstas em um ano;  
- e) pacientes que apresentarem hipersensibilidade ou reação adversa grave (choque anafilático, risco de óbito) ao uso da alfa-alglicosidase, que não podem ser controlados com segurança utilizando medidas terapêuticas e preventivas apropriadas;  
- f) pacientes com idade > 18 anos e que, após devidamente informados sobre os riscos e benefícios de sua decisão, optarem por não mais se submeterem ao tratamento com TRE com alfa-alglicosidase.  
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, aos pais/paciente ou aos responsáveis quando a TRE estiver sendo considerada e antes de iniciá-la. Durante o acompanhamento clínico do paciente em TRE, os parâmetros de resposta terapêutica à TRE deverão ser avaliados periodicamente e discutidos com os pais/paciente ou responsáveis. No caso de interrupção por falha de adesão, paciente e familiares deverão ser inseridos em programa específico para melhora de adesão, e poderão retornar ao tratamento caso haja comprometimento explícito de seguimento das recomendações e prescrições médicas.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Eventos adversos** -->
A alfa-alglicosidase é segura como TRE em pacientes com DP precoce, uma vez que a maioria dos eventos adversos (EA), apesar de frequente, é leve à moderada, resolvidos com tratamentos sintomáticos ou com redução da velocidade de infusão ou pausa. Os EA mais comuns são urticaria ou rash cutâneo, febre, alterações nos sinais vitais (dessaturação, alterações em pressão arterial ou frequência cardíaca) e broncoespasmo.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: 6.2.4. **Benefícios Esperados** -->
Em pacientes com DP precoce, a TRE reduz a massa de VE, com benefício na cardiomiopatia, e aumenta o tempo para início de ventilação. Além disso, a TRE aumenta a sobrevida dos pacientes em tratamento.  
6.2.5. **Casos Especiais**  
Os pacientes que já estiverem recebendo TRE no momento da implementação deste Protocolo deverão ser reavaliados em relação aos critérios de inclusão ou exclusão, para decisão sobre a continuidade ou suspensão do medicamento.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **7. MONITORAMENTO** -->
Devido à heterogeneidade clínica, alguns pacientes com DP não conseguirão executar todos testes preconizados, sendo estes realizados na medida do possível e conforme indicação para avaliação da gravidade do paciente, assim como padrão motor, respiratório e funcional. Além da avaliação já realizada para auxílio diagnóstico, pode-se  
proceder ainda à avaliação complementar ( **tabelas 1 e 2** )<sup>1</sup> . Para as avaliações cuja periodicidade não está estabelecida nessa Tabela, a periodicidade das avaliações é determinada conforme a avaliação clínica semestral ou indicação específica se houver intercorrências.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da DP deve ser feito por equipe em serviços especializados, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja devidamente qualificado.  
Para a administração de medicamentos biológicos intravenosos, é essencial o atendimento centralizado, para maior racionalidade do seu uso e avaliação da sua efetividade. A infusão deve ser feita em ambiente hospitalar ou ambulatorial. Infusões domiciliares podem ser consideradas após seis meses de tratamento sem verificação de intercorrências.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
<!-- Start of picture text -->
Diagnóstico:  clínico e laboratorial<br>Paciente com diagnóstico de<br>Doença de Pompe<br>Critérios de inclusão:<br>ü Atividade da enzima alfa glicosidade ácida<br><10% do limite inferior dos valores de<br>Início dos tratamentos de<br>referência em fibroblastos ou leucócitos,<br>suporte com atividade da enzima de referência,<br>avaliada na mesma amostra e pelo mesmo<br>método, apresentando valores normais; ou<br>ü Presença de mutações patogênicas em<br>homozigose ou heterozigose composta no<br>Possui critérios de inclusão<br>gene  GAA<br>para uso de TRE? ü  Início dos sintomas até 12 meses de idade<br>Não Sim<br>Critérios de exclusão:<br>üPacientes DP tardia;<br>Exclusão do uso  Possui critérios de<br>Sim üCondição médica<br>de TRE exclusão?<br>irreversível e que implique<br>em sobrevida inferior a 6<br>meses;<br>Não üRecusa de tratamento com<br>TRE;<br>üHistórico de falha de<br>Início da Alfa-alglicosidase  adesão.<br>(TRE)<br>Houve resposta<br>Sim terapêutica*? Não<br>Manter o tratamento e  Interromper tratamento com<br>reavaliar resposta a cada 6  TRE e manter tratamentos de<br>meses. suporte.<br>*1. Redução da massa do VE após um ano de tratamento em pelo menos 62 g/m² ou de 4 pontos (escore Z) ou<br>aumento de massa de VE após início do tratamento, quando esta não estava presente; 2. Desenvolvimento de<br>condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como<br>resultado da DP ou de outra doença associada; 3. Falta de adesão ao tratamento; ou 4. Hipersensibilidade ou reação<br>adversa grave (choque anafilático, risco de óbito) ao uso da TRE.<br><!-- End of picture text -->  
**Figura 1** - Fuxograma de Tratamento da Doença de Pompe  
**Tabela 1 -** Programa mínimo de avaliações para seguimento clínico dos pacientes com DP Precoce, em tratamento específico ou não.<sup>1</sup>  
|**Avaliações**|**Avaliação**<br>**Inicial**|**A cada 6**<br>**meses***|**Anualmente***|
|---|---|---|---|
|Atividade enzimática|X|||
|História médica|X|X||
|Genotipagem|X|||
|Revisão<br>do<br>número<br>de<br>infusões<br>realizadas no período||X||
|Determinação<br>da<br>adesão<br>ao<br>acompanhamento/tratamento|X|X||
|Peso / Altura / Estado nutricional|X|X||
|Pressão Arterial<sup>$</sup>|X|X||
|Exame Neurológico**|X|X||
|Audiometria|X|||
|Avaliação de disfagia|X||X|
|Radiografia de tórax e coluna|X|||
|Ecocardiograma|X||X|
|Eletrocardiograma|X|||
|Polissonografia|X|||
|Avaliação com Pneumologista|X||X|  
*Para pacientes em TRE. As demais avaliações devem ser realizadas em períodos determinados pelo médico assistente.<sup>$</sup> A partir de 3 anos ** A força deve ser avaliada por dinamometria.  
**Tabela 2 -** Programa mínimo de avaliações para seguimento clínico dos pacientes com DP Tardia, em tratamento de suporte.<sup>1</sup>  
|**Avaliações**|**Avaliação**|**A cada 6**<br>**Anualmente**|
|---|---|---|
||**Inicial**|**meses**|
|Atividade enzimática|X||  
|História médica||X|X||
|---|---|---|---|---|
|Genotipagem||X|||
|Determinação<br>da<br>adesão<br>acompanhamento/tratamento|ao|X|X||
|Peso / Altura / Estado nutricional||X|X||
|Pressão Arterial<sup>$</sup>||X|X||
|Exame Neurológico**||X|X||
|Audiometria||X|||
|Avaliação de disfagia||X||X|
|Densitometria óssea***||X|||
|Radiografia de tórax e coluna||X|||
|Ecocardiograma||X|||
|Eletrocardiograma||X||X|
|Espirometria (a partir de 6 anos)||X|||
|Polissonografia||X|||
|Avaliação com pneumologista||X||X|  
As demais avaliações devem ser realizadas em períodos determinados pelo médico assistente.<sup>$</sup> A partir de 3 anos ** A força deve ser avaliada por dinamometria. ***A cada 2 anos para pacientes com mais de 10 anos de idade.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste PCDT, bem como os critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **10. REFERÊNCIAS** -->
1. Llerena JC, Horovitz DM, Marie SK, Porta G, Giugliani R, Rojas MV, et al. The Brazilian consensus on the management of Pompe disease. J Pediatr. 2009;155(4 Suppl):S47-56.  
2. Levine JC, Kishnani PS, Chen YT, Herlong JR, Li JS. Cardiac remodeling after enzyme replacement therapy with acid alpha-glucosidase for infants with Pompe disease. Pediatr Cardiol. 2008;29(6):1033-42.  
3. Slonim AE, Bulone L, Goldberg T, Minikes J, Slonim E, Galanko J, et al. Modification of the natural history of adult-onset acid maltase deficiency by nutrition and exercise therapy. Muscle Nerve. 2007;35(1):70-7.  
4. Geel TM, McLaughlin PM, de Leij LF, Ruiters MH, Niezen-Koning KE. Pompe disease: current state of treatment modalities and animal models. Mol Genet Metab. 2007;92(4):299-307.  
5. Winchester B, Bali D, Bodamer OA, Caillaud C, Christensen E, Cooper A, et al. Methods for a prompt and reliable laboratory diagnosis of Pompe disease: report from an international consensus meeting. Mol Genet Metab. 2008;93(3):275-81.  
6. Bembi B, Cerini E, Danesino C, Donati MA, Gasperini S, Morandi L, et al. Diagnosis of glycogenosis type II. Neurology. 2008;71(23 Suppl 2):S4-11. 7. Nascimbeni AC, Fanin M, Masiero E, Angelini C, Sandri M. The role of autophagy in the pathogenesis of glycogen storage disease type II (GSDII). Cell Death Differ. 2012;19(10):1698-708.  
8. The Human Gene Mutation Database [Available from: <u>http://www.hgmd.cf.ac.uk/ac/index.php.</u>  
9. Kishnani PS, Hwu WL, Mandel H, Nicolino M, Yong F, Corzo D, et al. A retrospective, multinational, multicenter study on the natural history of infantile-onset Pompe disease. J Pediatr. 2006;148(5):671-6.  
10. Tarnopolsky M, Katzberg H, Petrof BJ, Sirrs S, Sarnat HB, Myers K, et al. Pompe Disease: Diagnosis and Management. Evidence-Based Guidelines from a Canadian Expert Panel. Can J Neurol Sci. 2016;43(4):472-85. 11. Llerena Junior JC, Nascimento OJ, Oliveira AS, Dourado Junior ME, Marrone CD, Siqueira HH, et al. Guidelines for the diagnosis, treatment and clinical monitoring of patients with juvenile and adult Pompe disease. Arq Neuropsiquiatr. 2016;74(2):166-76. 12. Marrone CD, Rodrigues T. Late-Onset Pompe Disease (Juvenile-Onset Form) with Elevated CK, Fatigue, and Muscular Pain After Exercise, Without Weakness. J Neuromuscul Dis. 2015;2(s1):S25. 13. Martins AM, Kerstenezky M, Linares A, Politei J, Kohan R, Ospina S, et al. Utility of rare disease registries in latin america. JIMD Rep. 2011;1:111-5. 14. Llerena JC. Comunicação pessoal. 2018. 15. Sixel BS, Silva LD, Cavalcanti NC, Penque GM, Lisboa S, Horovitz DD, et al. Respiratory manifestations in late-onset Pompe disease: a case series conducted in Brazil. J Bras Pneumol. 2017;43(1):54-9.  
16. Bhengu L, Davidson A, du Toit P, Els C, Gerntholtz T, Govendrageloo K, et al. Diagnosis and management of Pompe disease. S Afr Med J. 2014;104(4):273-4.  
17. Cupler EJ, Berger KI, Leshner RT, Wolfe GI, Han JJ, Barohn RJ, et al. Consensus treatment recommendations for late-onset Pompe disease. Muscle Nerve. 2012;45(3):319-33.  
18. Werneck LC, Lorenzoni PJ, Kay CS, Scola RH. Muscle biopsy in Pompe disease. Arq Neuropsiquiatr. 2013;71(5):284-9.  
19. Castilhos CD, Mezzalira J, Goldim MP, Daitx VV, Garcia CaS, Andrade CV, et al. Determination of the lysosomal hydrolase activity in blood collected on filter paper, an alternative to screen high risk populations. Gene. 2014;536(2):344-7.  
20. Brand GD, Matos HC, Cruz GC, Fontes NoC, Buzzi M, Brum JM. Diagnosing lysosomal storage diseases in a Brazilian non-newborn population by tandem mass spectrometry. Clinics (Sao Paulo). 2013;68(11):1469-73. 21. Müller KB, Rodrigues MD, Pereira VG, Martins AM, D'Almeida V. Reference values for lysosomal enzymes activities using dried blood spots samples - a Brazilian experience. Diagn Pathol. 2010;5:65.  
22. Bravo H, Neto EC, Schulte J, Pereira J, Filho CS, Bittencourt F, et al. Investigation of newborns with abnormal results in a newborn screening program for four lysosomal storage diseases in Brazil. Mol Genet Metab Rep. 2017;12:92-7.  
23. Grzesiuk AK, Shinjo SM, da Silva R, Machado M, Galera MF, Marie SK. Homozygotic intronic GAA mutation in three siblings with late-onset Pompe's disease. Arq Neuropsiquiatr. 2010;68(2):194-7.  
24. Kroos M, Pomponio RJ, van Vliet L, Palmer RE, Phipps M, Van der Helm R, et al. Update of the Pompe disease mutation database with 107 sequence variants and a format for severity rating. Hum Mutat. 2008;29(6):E13-26.  
25. Bali DS, Goldstein JL, Banugaria S, Dai J, Mackey J, Rehder C, et al. Predicting cross-reactive immunological material (CRIM) status in Pompe disease using GAA mutations: lessons learned from 10 years of clinical laboratory testing experience. Am J Med Genet C Semin Med Genet. 2012;160C(1):40-9.  
26. Saúde Md. Asma. In: Conitec, editor. <u>http://portalarquivos2.saude.gov.br/images/pdf/2014/julho/22/PT-SAS-N---1317alterado-pela-603-de-21-de-julho-de-2014.pdf2013.</u>  
27. Saúde Md. PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS: OSTEOPOROSE.2014 08/09/2019. Available from: <u>http://portalarquivos.saude.gov.br/images/pdf/2014/abril/02/pcdt-osteoporose-2014.pdf.</u>  
28. Terzis G, Krase A, Papadimas G, Papadopoulos C, Kavouras SA, Manta P. Effects of exercise training during infusion on late-onset Pompe disease patients receiving enzyme replacement therapy. Mol Genet Metab. 2012;107(4):669-73.  
29. Silva RM, Mendes CS, Aranda CC, Curiati MA, Rand MH, Kyosen SO, et al. Effects of Exercise Training on Functional Capacity and Quality of Life in a Patient with Late-Onset Pompe Disease Receiving Enzyme Replacement Therapy. J Neuromuscul Dis. 2015;2(s1):S33.  
30. Giugliani R, Federhen A, Muñoz Rojas MV, Vieira TA, Artigalás O, Pinto LL, et al. [Enzyme replacement therapy for mucopolysaccharidoses I, II and VI: recommendations from a group of Brazilian F experts]. Rev Assoc Med Bras (1992). 2010;56(3):271-7.  
31. van der Ploeg AT, Kruijshaar ME, Toscano A, Laforêt P, Angelini C, Lachmann RH, et al. European consensus for starting and stopping enzyme replacement therapy in adult patients with Pompe disease: a 10-year experience. Eur J Neurol. 2017;24(6):768e31.  
ALFA-ALGLICOSIDASE  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE  
Eu,____________________________________ (nome do(a) paciente ou seu  
responsável), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **alfa-alglicosidase,** indicados para o tratamento da **doença de Pompe precoce** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ______________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que os medicamentos que passo a receber podem trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como tempo para início de ventilação mecânica, cardiomiopatia e sobrevida;  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento classificado na gestação como fator de risco C (estudos em animais não mostraram anormalidades; o medicamento deve ser prescrito com cautela);  
- efeitos adversos da alfa-alglicosidase: aqueles relatados em dois ou mais estudos foram calafrios, hipertermia, sintomas gripais, prurido generalizado, broncoespasmo, reações urticariformes e dessaturação.  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim   ( ) Não  
Local:                                                                                          Data: <u>Nome do paciente:</u> Cartão Nacional do SUS:  
|Nome doresponsável legal:|
|---|
|Documento deidentificação doresponsável legal:|
|Assinatura dopaciente ou do responsável legal:|
|Médico: CRM:RS:|
|______________________________<br>Assinatura e carimbo do médico<br>Data:|  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **1. Escopo e finalidade do Protocolo** -->
Inicialmente, foi realizada uma reunião de escopo com o Comitê Gestor e o Grupo Elaborador dia 12 de dezembro de 2016, no Hospital Alemão Oswaldo Cruz (HAOC), quando foram estabelecidas as perguntas de pesquisa para a elaboração do PCDT de doença de Pompe.  
Essa reunião presencial contou com a presença de seis membros do Grupo Elaborador, sendo um especialista e cinco metodologistas, além de um representante da Sociedade de Genética Médica, três representantes de organização de pacientes, cinco especialistas em genética e neurologia e dois representantes do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base na estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre os integrantes do Grupo Elaborador com o objetivo de revisar as condutas diagnóstico-terapêuticas e identificar as tecnologias que poderiam ser consideradas no Protocolo.  
Foi estabelecido que as condutas diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidade de desinvestimento.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **2. Equipe de elaboração e partes interessadas** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), houve a participação na elaboração deste Protocolo de metodologistas do HAOC e especialistas no tema.  
Todos os participantes do Grupo Elaborador preencheram os respectivos formulários de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados do trabalho.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A versão preliminar do texto foi pautada na 77º Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada no dia 11 de fevereiro de 2020. Participaram desta reunião representantes do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF) e do Departamento de Ciência e Tecnologia (DECIT), da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde, bem como representantes do  Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI), da Secretaria de Vigilância em Saúde. Além das contribuições recebidas durante a reunião, o documento foi revisado por áreas técnicas da Secretaria de Atenção Especializada à Saúde (SAES/MS) e, após a realização dos ajustes e correções apontados pelos membros da Subcomissão Técnica de PCDT, o documento foi encaminhado para a apreciação do Plenário da Conitec.

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **Consulta pública** -->
O PCDT teve apreciação inicial na 86.ª Reunião Ordinária da Conitec, realizada nos dias 04 e 05 de março de 2020, ocasião em que os membros presentes emitiram deliberação favorável à proposta de PCDT e recomendaram que o texto fosse submetido à consulta pública para o recebimento de contribuições da sociedade.  
A Consulta Pública nº 13/2020 foi realizada entre os dias 26 de março e 14 de abril de 2020. Foram recebidas 328 contribuições no total, sendo 319 de pessoa física e nove de pessoa jurídica. Estas contribuições foram analisadas de modo quantitativo e qualitativo, e os resultados apresentados à 88º Reunião da Conitec, no dia 04 de junho de 2020.  
O conteúdo integral da consulta pública se encontra disponível na página da CONITEC em:  
<u>http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_13_2020_P CDT_Pompe.pdf .</u>

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **3. Busca da evidência e recomendações** -->
Com o objetivo de nortear a busca da literatura, foi formulada a pergunta estruturada, de acordo com o acrônimo PICO (População, intervenção, comparador e _outcomes_ - desfechos), conforme a **Tabela A** . Os desfechos foram definidos _a priori_ com base na  
sua importância, de acordo com a opinião dos especialistas participantes na reunião de escopo para a elaboração do PCDT da DP.  
**Pergunta de Pesquisa:** O uso da alfa-alglicosidase é eficaz e seguro como TRE em pacientes com DP?  
**Tabela A -** Pergunta de pesquisa estruturada de acordo com o acrônimo PICO  
|**População**|Pacientes com DP precoce e tardia.|
|---|---|
|**Intervenção**|Alfa-alglicosidase (em monoterapia).|
|**Comparador**|Placebo ou cuidados de suporte.|
|**Desfechos**|**Forma precoce:**Qualidade de vida, sobrevida, tempo para início de<br>ventilação, distúrbio de deglutição, cardiomiopatia, função miocárdica,<br>desenvolvimento neuropsicomotor e segurança.<br>**Forma tardia**: Qualidade de vida, capacidade funcional, sobrevida,<br>tempo em ventilação, avaliação de força em membros superiores,<br>qualidade do sono, distúrbio da deglutição e segurança.|  
Os estudos selecionados e a avaliação das evidências estão descritos no Relatório de Recomendação nº 481 de outubro/2019 (28) e disponível no link <u>http://conitec.gov.br/images/Relatorios/2019/Relatorio_AlfaAlglicosidase_Pompe.pdf .</u>

---

<!-- METADADOS: doenca: Doença de Pompe | secao: **4. Elaboração do PCDT** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da DP. Foi também realizada busca por diretrizes nacionais e internacionais a respeito da doença.  
Não foram encontradas tecnologias disponíveis, já incorporadas ou em avaliação.  
As seguintes bases de diretrizes foram consultadas:  
- NICE _guidelines_ <u>(http://www.nice.org.uk/guidance/published?type=CG);</u>  
- _National Library of Australia_ – http://webarchive.nla.gov.au/gov/;  
- Diretrizes Associação Médica Brasileira (AMB);  
- Pubmed/Medline.  
As diretrizes localizadas foram as seguintes:  
- Llerena JC, Horovitz DM, Marie SK, Porta G, Giugliani R, Rojas MV, et al. The Brazilian consensus on the management of Pompe disease. J Pediatr. 2009;155(4 Suppl):S47-56.  
- van der Ploeg AT, Kruijshaar ME, Toscano A, Laforêt P, Angelini C, Lachmann RH, et al.; European Pompe Consortium. European consensus for starting and stopping enzyme replacement therapy in adult patients with Pompe disease: a 10-year experience. Eur J Neurol. 2017 Jun;24(6):768-e31.  
- Tarnopolsky M, Katzberg H, Petrof BJ, Sirrs S, Sarnat HB, Myers K, et al. Pompe Disease: Diagnosis and Management. Evidence-Based Guidelines from a Canadian Expert Panel. Can J Neurol Sci. 2016 Jul;43(4):472-85.  
- L Bhengu, A Davidson, P du Toit, C Els, T Gerntholtz, K Govendrageloo, et al.; Lysosomal Storage Disease Medical Advisory Board, South Africa. Diagnosis and Management of Pompe Disease. S Afr Med J. 2014 Apr;104(4):273-4.  
Para a elaboração dos critérios diagnósticos, foram utilizados _guidelines_ internacionais elaborados por diferentes grupos de especialistas, que são utilizados como consenso nos diversos centros de referência para DP.  
Para a avaliação de interrupção de tratamento, foi utilizada a seguinte estratégia de busca: “glycogen storage disease type II AND interruption”, sendo apenas um resultado encontrado ( _An individually, modified approach to desensitize infants and young children with Pompe disease, and significant reactions to alglucosidase alfa infusions_ ). A base de dados buscada foi Medline/PubMed, e a referência encontrada não respondia à pergunta definida na reunião de escopo, sendo utilizados os _guidelines_ internacionais acima citados para responder à questão.  
Para a elaboração dos demais itens do PCDT foram utilizadas as buscas, resultados, recomendações e referências constantes no Relatório de Recomendação da Conitec para a TRE com alfaalglicosidase no tratamento da DP, disponível em http://conitec.gov.br/images/Relatorios/2019/Relatorio_AlfaAlglicosidase_Pompe.pdf .

---

