<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: PORTARIA CONJUNTA Nº 19, DE 04 DE DEZEMBRO DE 2019. -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose Tipo IV A.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a mucopolissacaridose tipo IV A no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação ~~n~~<sup><u>o</u></sup> 399/018 e ~~n~~<sup><u>o</u></sup> 485/2019 e os relatórios de recomendação ~~n~~<sup><u>o</u></sup> 411 – Dezembro de 2018 e n<sup><u>o</u></sup> 494 – Outubro de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Mucopolissacaridose Tipo IV A. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da mucopolissacaridose do tipo IV A, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da mucopolissacaridose tipo IV A.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **1. INTRODUÇÃO** -->
A Mucopolissacaridose (MPS) tipo IV A (MPS IV A), ou Síndrome de Morquio A, é uma doença genética rara, de herança autossômica recessiva, causada pela atividade deficiente da enzima N-acetilgalactosamina-6sulfatase (GALNS), responsável pela degradação dos glicosaminoglicanos (GAG) queratan sulfato (QS) e condroitina 6-sulfato (C6S), resultando no acúmulo desses componentes nos lisossomos de múltiplos tecidos do corpo (1). A MPS IV A não deve ser confundida com a síndrome de Morquio B (ou MPS IV B), pois a última, embora tenha denominação semelhante e possa se associar a quadro clínico similar, é causada pela atividade deficiente de outra enzima, a beta-galactosidase; portanto, a MPS IVB não será abordada neste PCDT.  
A MPS IV A é uma doença multissistêmica, heterogênea e progressiva, com velocidade de progressão dos sintomas e gravidade muito variáveis (2). Alterações esqueléticas e articulares, incluindo geno valgo, hipermobilidade articular, subluxação e displasia de quadril, compressão de canal medular, instabilidade atlantoaxial e cifoescoliose toracolombar, são as manifestações clínicas mais prevalentes (2-6).  
A doença valvular cardíaca e as complicações respiratórias diminuem a resistência às diversas atividades diárias e são comuns nesses pacientes (7). O acúmulo de GAGs nas vias aéreas superiores e amígdalas pode causar obstrução e predispõe ao desenvolvimento da apneia obstrutiva do sono. A função respiratória é ainda comprometida por deformidades da parede torácica e deslocamento do diafragma devido à baixa estatura e por hepatoesplenomegalia. A instabilidade atlantoaxial e a compressão da medula espinhal também podem resultar em fraqueza muscular respiratória (1). Essas alterações pulmonares e a instabilidade da medula espinhal são as principais causas de morbidade e mortalidade (2,8,9). Outras manifestações, como acometimento visual (opacificação de córnea) e auditivo, além de dor, sobrepostas aos componentes acima, impactam diretamente na redução da qualidade de vida dos pacientes (2).  
A prevalência da doença é variável, descrita como 1 para 926 mil habitantes na Austrália, 1 para 1.872.000 na Malásia e 1 para 599 mil no Reino Unido (10). Dados brasileiros de prevalência e incidência não estão disponíveis, porém entre 1982 e 2015 houve 153 pacientes diagnosticados com MPS IV A no Brasil (11).  
Inexiste tratamento curativo da MPS IV A. Este PCDT visa a definir critérios de diagnóstico, acompanhamento e tratamento de pacientes com essa doença, incluindo terapia de reposição enzimática (TRE) intravenosa com alfaelosulfase e transplante de células-tronco hematopoéticas (TCTH).  
A identificação da doença em seu estágio inicial, assim como o encaminhamento ágil e adequado para o atendimento especializado, dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este PCDT visa a definir critérios de diagnóstico, acompanhamento e tratamento, incluindo terapia de reposição enzimática intravenosa com alfaelosulfase e o TCTH, de pacientes com MPS IV A. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE**

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **(CID-10)** -->
- E76.2 Outras Mucopolissacaridoses

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **3. DIAGNÓSTICO** -->
A confirmação do diagnóstico de MPS IV A envolve exames bioquímicos ou genéticos que deverão ser realizados sempre que houver suspeita dessa doença.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **3.1 SUSPEITA DIAGNÓSTICA** -->
O diagnóstico de MPS IV A deve ser suspeitado em indivíduos que apresentarem <u>pelo menos um</u> dos sintomas e sinais abaixo relacionados, especialmente naqueles que tiverem a combinação de pelo menos dois deles (6):  
- Baixa estatura desproporcionada (tronco curto);  
- Estudo radiológico sugestivo de displasia espondiloepifisária, pseudoacondroplasia, displasia epifisária  
múltipla, doença de Legg Calvé-Perthers bilateral;  
- Alterações articulares bilaterais (frouxidão, rigidez, dor, contraturas, subluxação);  
- Opacificação bilateral de córnea;  
- Aumento de QS na urina; ou  
- Irmão de qualquer sexo com MPS IV A.  
Como os achados clínicos variam de acordo com a gravidade da doença, os sintomas e sinais, por si só, não são diagnósticos.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **3.2 DIAGNÓSTICO LABORATORIAL** -->
A redução ou ausência de atividade da enzima GALNS em fibroblastos, leucócitos ou sangue impregnado em papel-filtro sugere fortemente o diagnóstico de MPS IV A, mas não é suficiente para confirmá-lo como único teste, devido à possibilidade de ocorrência de Deficiência Múltipla de Sulfatases (outro erro inato do metabolismo). Por isto, a atividade de pelo menos outra sulfatase (arilsulfatase A, arilsulfatase B, heparan N-sulfatase ou iduronato-sulfatase) deve estar normal.  
A medida da atividade enzimática em gotas de sangue impregnadas em papel-filtro tem a vantagem da facilidade de transporte e manipulação, mas deve ser considerada como método de triagem, devido aos casos de falsos-positivos e negativos associados.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **3.3 TESTE GENÉTICO** -->
A presença de duas mutações patogênicas em _trans_ no gene _GALNS_ também confirma o diagnóstico de MPS IV A. Mais de 340 diferentes mutações causadoras de doença já foram descritas nesse gene (12), o qual  
possui 14 éxons (6, 13, 14). A análise do gene _GALNS_ permite, também, a detecção de heterozigotos, facilitando o aconselhamento genético individual e familiar.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT todos os pacientes que apresentarem pelo menos um dos sintomas ou sinais descritos no item 3.1 Suspeita Diagnóstica e tiverem o diagnóstico de MPS IV A confirmado de acordo com um dos critérios abaixo relacionados:  
- atividade da GALNS < 10% do limite inferior dos valores de referência em fibroblastos ou leucócitos **<u>E</u>** atividade de pelo menos uma outra sulfatase (arilsulfatase A, arilsulfatase B, heparan N-sulfatase ou iduronatosulfatase) avaliada na mesma amostra e pelo mesmo método, apresentando valores normais; **<u>OU</u>**  
- atividade da GALNS < 10% do limite inferior dos valores de referência em papel-filtro, fibroblastos ou leucócitos **<u>E</u>** presença de mutações patogênicas em homozigose ou heterozigose composta no gene _GALNS_ .

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: 4.1 **CRITÉRIOS DE INCLUSÃO PARA TRE** -->
Poderão fazer uso de alfaelosulfase todos os indivíduos com diagnóstico de MPS IV A realizado de acordo com o item 3. Diagnóstico deste PCDT.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: 4.2 **CRITÉRIOS DE INCLUSÃO PARA TRANSPLANTE DE CÉLULAS-TRONCO HEMATOPOÉTICAS (TCTH)** -->
Serão elegíveis para o transplante de células-tronco hematopoéticas (TCTH) alogênico (TCTH-AL) aparentado (TCTH-AL-AP) ou não aparentado (TCTH-AL-NAP):  
- Os pacientes com diagnóstico de MPS IV A e com fatores de risco para pior evolução da doença;  
- com doador de células-tronco hematopoéticas (CTH) identificado;  
- em condições clínicas para o transplante; e  
- em idade compatível com o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional  
de Transplantes e as idades mínima e máxima atribuídas as respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
O tipo (aparentado ou não aparentado) e subtipo (mieloablativo ou não mieloablativo) do TCTH dependerão da idade e das condições clínicas do paciente, cabendo à equipe transplantadora defini-los.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **5.1 Critérios de Exclusão de TRE** -->
Serão excluídos do tratamento com alfaelosulfase os pacientes que se enquadrarem em pelo menos uma das  
seguintes situações:  
- Condição médica irreversível e que implique em sobrevida provavelmente < 6 meses como resultado da  
- MPS IV A ou de outra doença associada, em acordo entre mais de um especialista;  
- pacientes com idade > 18 anos que, após serem informados sobre os potenciais riscos e benefícios  
- associados ao tratamento com alfaelosulfase, recusarem-se a serem tratados; ou  
- pacientes com histórico de falha de adesão, desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que, mesmo após o programa, não comparecerem a pelo menos 50% do número de consultas ou de avaliações previstas em um ano.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **5.2 CRITÉRIOS DE EXCLUSÃO PARA TRANSPLANTE DE CÉLULAS-TRONCO HEMATOPOÉTICAS (TCTH)** -->
- Pacientes com diagnóstico de MPS IV A sem condições clínicas para o TCTH-AL;  
- Pacientes em idade incompatível para o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas as respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS; ou  
- Pacientes sem doador de células-tronco hematopéticas (CTH) identificado.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6. TRATAMENTO** -->
O tratamento dos pacientes com MPS IV A envolve equipe multidisciplinar (1,15) e inclui intervenções gerais (como cirurgias para correção das alterações esqueléticas) e outras específicas sobre a proteína mutante (como a TRE intravenosa e o TCTH) (16,17). Outras medidas terapêuticas, como uso de TRE intratecal, chaperonas, inibidores de síntese de substrato e terapia gênica, estão ainda em fase de desenvolvimento para outras MPS e ainda não foram avaliadas para a MPS IV A (16,17).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1 TRATAMENTO GERAL** -->
A MPS IV A é uma doença crônica, progressiva e multissistêmica que requer cuidados de equipe multiprofissional com fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, enfermeiros e diferentes especialidades médicas (6). É crucial que um médico assistente cuide continuamente do paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando o paciente para outros médicos especialistas e coordenando o atendimento como um todo. Idealmente, o acompanhamento deve ser feito em um centro de referência que disponha de uma equipe multidisciplinar integrada de especialistas, assegurando dessa forma a coordenação assistencial abrangente dos pacientes, desde o diagnóstico até o tratamento e seguimento (6).  
Os pacientes com MPS IV A podem desenvolver sintomas e sinais neurológicos secundários à compressão medular (5,18) e, nesses casos, um neurocirurgião deve fazer parte da equipe. (6) Além disso, é importante que os pacientes e as famílias sejam educados sobre a doença e possíveis complicações e riscos, também por meio de um relatório escrito (6).  
As principais manifestações clínicas da MPS IV A e suas opções de tratamentos de suporte e sintomáticos podem ser encontradas na **Tabela 1** . É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e mais intensas nos pacientes com a forma grave da doença. Da mesma forma, nem todos os pacientes necessitarão ser submetidos a todas as formas de tratamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.1. Tratamento ortopédico** -->
Pacientes com MPS IV A têm acometimento ósseo significativo (1) e requerem fisioterapia motora dinâmica, cujo objetivo principal é a prevenção ou estabilização de deformidades osteoarticulares, mantendo a amplitude de movimento (6). Além disso, equipamentos de auxílio da marcha ou cadeira de rodas podem aumentar a mobilidade e aliviar a dor; contudo, esforços com o intuito de postergar ao máximo a utilização desses  
instrumentos devem ser feitos para manter os pacientes móveis por maior tempo possível, uma vez que a sua qualidade de vida se reduz drasticamente ao se tornarem dependentes de cadeira de rodas (6,19).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.2. Tratamento das manifestações respiratórias** -->
As manifestações respiratórias são as principais causas de morbimortalidade e podem ocorrer por causas obstrutivas ou restritivas (2,8). Assim, entre os objetivos do tratamento está o melhor controle das infecções recorrentes de vias aéreas. Frequentemente, solução salina fisiológica é usada para eliminar crostas e secreções. Antibióticos são utilizados para o tratamento de exacerbações respiratórias agudas de origem bacteriana e suas complicações, como otite média aguda ou tonsilite, conforme indicação e a critério médico. Corticoterapia sistêmica por breves períodos pode ajudar a reduzir o edema e facilitar a drenagem de secreções, conforme indicação e a critério médico. Os medicamentos para asma devem ser administrados conforme o PCDT da Asma, do Ministério da Saúde (20). Pacientes podem, ainda, se beneficiar de terapias de suporte, como imunizações regulares contra influenza e pneumococo (8), seguindo o calendário obrigatório de vacinação para população que sofre de doenças crônicas.  
A fisioterapia respiratória visa a melhorar a função pulmonar, ventilação e biomecânica respiratória, e estão indicadas as manobras de higiene brônquica descritas na literatura, como vibrocompressão, drenagem postural, tosse estimulada por manobra de aceleração do fluxo expiratório, nebulização e aspiração nasotraqueal com material estéril e descartável. Orientação para cuidadores e família é de vital relevância, porque a fisioterapia respiratória deve ser realizada diariamente (6).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.3. Tratamento oftalmológico** -->
Opacificação de córnea e alterações de refração (astigmatismo, miopia e hipermetropia) são comuns na MPS IV A, podendo levar à diminuição da acuidade visual e fotossensibilidade (5,21-23). Nesse sentido, lentes corretivas devem ser prescritas para corrigir erros de refração (6,14). O transplante de córnea pode melhorar notavelmente a visão (14,24), embora possa ocorrer opacificação na córnea transplantada (25).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.4. Tratamento auditivo** -->
Uma vez que a perda auditiva sensorioneural ou mista (condutiva e sensorioneural) é comum em pacientes com MPS IV A ainda na primeira década de vida (26,27), devido a deformidades dos ossículos, anormalidades em ouvido interno ou, ainda, por infecções respiratórias de repetição (14,23,26,27), o tratamento destas comorbidades é imprescindível. Assim, audiometria pode ser realizada utilizando técnicas indicadas para crianças e aparelhos auditivos podem estar indicados quando houver perda neurossensorial progressiva (6).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.5. Tratamento odontológico** -->
Avaliações regulares com dentista para acompanhar o desenvolvimento dentário são importantes para prevenir cáries e reduzir o desgaste por atrito (14,23), visto que são diversas as alterações dentárias na MPS IV A, incluindo dentes pequenos e espaçados (28-30).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.1.6. Tratamento cirúrgico** -->
A MPS IV A pode evoluir com complicações neurológicas, como hidrocefalia comunicante e compressão medular (6,31); porém, os sinais clássicos de hipertensão intracraniana geralmente estão ausentes, evoluindo de forma insidiosa, e os sintomas são difíceis de distinguir de danos primários ao cérebro. A maioria dos casos de  
compressão medular apresenta tetraparesia espástica, mas paraparesia espástica ou hemiparesia também podem ocorrer (32). Intervenções para compressão medular incluem descompressão, fusão medular ou a combinação de ambas (18,33).  
Eventualmente, esses pacientes necessitam de cirurgias corretivas em consequência de deformidades ósseas diversas, incluindo a região do quadril e joelhos. Intervenção cirúrgica de coluna tóraco-lombar para correção da cifose também pode ser necessária quando a deformidade progride (34).  
Com relação ao tratamento cirúrgico das manifestações de vias aéreas, os procedimentos mais frequentes incluem adenotonsilectomia, cirurgia de cornetos nasais e traqueostomia (6). Com relação ao tratamento da perda auditiva, quando decorrente de causas condutivas e por infecções respiratórias frequentes, este requer inserção de tubos de ventilação de longa duração, porém o procedimento nem sempre é resolutivo (23).  
A cirurgia das vias aéreas pode ser complicada pela macroglossia, abertura limitada da boca, margem cirúrgica restrita e instabilidade da coluna cervical, dificultando a visualização do campo cirúrgico. A hiperextensão no pescoço nesses pacientes pode causar compressão medular aguda. A traqueostomia deve ser evitada sempre que possível, devido a dificuldades na técnica cirúrgica, endurecimento da traqueia, alterações anatômicas significativas como pescoço curto e possibilidade de complicações pós-operatórias, como traqueíte, pneumonia recorrente e bloqueio da traqueostomia por secreções espessas (6,8).  
As hérnias inguinais, umbilicais e diafragmáticas são comuns entre os pacientes com MPS IV A (5,23), muitas vezes levando à necessidade de correções cirúrgicas. As hérnias umbilicais frequentemente se repetem após o reparo inicial, talvez como resultado de elastogênese comprometida.  
Muitos pacientes com MPS apresentam risco anestésico elevado devido à obstrução das vias aéreas superiores. Portanto, a avaliação pré-operatória para mensuração dos riscos sempre está indicada (6), uma vez que a dificuldade na intubação pode ser fatal (35). Idealmente, os procedimentos cirúrgicos devem ser realizados em centros de referência com experiência em MPS, sendo fundamental a presença de anestesista experiente em intubação difícil para a sua realização, pois a necessidade de acompanhar a intubação com fibroscopia é frequente. As máscaras laríngeas podem ser usadas para o controle das vias aéreas por períodos curtos ou para facilitar a intubação de fibra óptica (35,36). Os tubos endotraqueais podem precisar ser menores do que o previsto para a idade e o tamanho de um paciente com MPS IV A. Esses pacientes geralmente apresentam obstrução pósoperatória das vias aéreas, e as urgências hospitalares durante a noite não são incomuns. Assim sendo, a necessidade de traqueostomia pós-operatória é uma possibilidade que deve ser considerada por todas as partes envolvidas. Quando possível, os procedimentos que exigem anestesia geral devem ser evitados para minimizar o risco.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.1 TRANSPLANTE DE CÉLULAS-TRONCO HEMATOPOÉTICAS (TCTH)** -->
As evidências atualmente disponíveis sugerem que existem benefícios da realização de TCTH alogênico (TCTH-AL) aparentado (TCTH-AL-AP) ou não aparentado (TCTH-AL-NAP) em indivíduos com MPS IV A, especialmente quando em idade precoce (37,38). Como a MPS IV A envolve principalmente complicações esqueléticas e o osso é uma estrutura de difícil acesso à TRE intravenosa, haveria maiores possibilidades de melhora deste desfecho com o TCTH heterólogo aparentado (desde que doador não-heterozigoto) ou não aparentado. Desta forma, indivíduos com MPS IV A até 6 anos de idade deverão ser encaminhados a centros transplantadores a fim de verificar a possibilidade de realização de TCTH, conforme o vigente Regulamento  
Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.2 TERAPIA DE REPOSIÇÃO ENZIMÁTICA (TRE)** -->
A alfaelosulfase, GALNS recombinante, é uma enzima produzida em células de ovário de hamster chinês (células _Chinese hamster ovary_ , CHO) e trata-se do fármaco disponível para o tratamento específico da MPS IV A (6,16). Os pacientes que já estiverem em uso de alfaelosulfase quando da publicação deste PCDT deverão ser reavaliados para verificação dos critérios de inclusão. Caso não preencham os critérios, a reposição da enzima deve ser imediatamente suspensa.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.2.1 Casos especiais** -->
A alfaelosulfase é considerada classe B para uso na gestação e aleitamento. Há relato na literatura de manutenção de uso da alfaelosulfase durante a gestação com desfechos positivos para mãe e recém-nascido (40). Sendo assim, o uso da TRE com alfaelosulfase em mulheres grávidas ou que estejam amamentando é de decisão conjunta da equipe médica e paciente. De forma geral, recomenda-se que o tratamento com TRE não seja iniciado durante a gestação, especialmente durante o primeiro trimestre, e que, se já iniciado, seja mantido durante a gravidez.  
Caso seja feito uso de glicocorticoide ou anti-histamínico, deve ser considerada a interrupção da TRE no primeiro trimestre.  
Quando houver reação à infusão mediada por IgE, deve ser discutida a possibilidade do uso de protocolos que promovam a tolerância à infusão do medicamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.2.2 Fármaco** -->
- Alfaelosulfase: 1 mg/ml solução injetável.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.2.3 Esquema de administração** -->
A dose recomendada para a alfaelosulfase é de 2 mg/kg de peso corporal, administrada uma vez por semana por infusão intravenosa. O uso de anti-histamínico, associado ou não a antipirético, é recomendado de 30 a 60 minutos antes do início da infusão (6). A infusão deve ser feita em ambiente hospitalar.  
O volume total da infusão é determinado pelo peso corporal do paciente e deve ser infundido ao longo de 4 horas. Pacientes com 20 kg ou menos devem receber um volume total de 100 ml. Pacientes com mais de 20 kg devem receber um volume total de 250 mL. Quando diluído em 100 ml de solução fisiológica, a velocidade de infusão inicial deve ser de 3 mL/h e pode ser aumentada, conforme a tolerância, a cada 15 minutos: primeiro, aumentar a velocidade para 6 mL/h, depois, a cada 15 minutos, em incrementos de 6 mL/h até a velocidade máxima de 36 mL/h ser atingida. Quando diluído em 250 mL, a velocidade de infusão inicial deve ser de 6 mL/h e pode ser aumentada, conforme tolerância, a cada 15 minutos: primeiro, aumentar a velocidade para 12 mL/h, depois, a cada 15 minutos, em incrementos de 12 mL/h até a velocidade máxima de 72 mL/h ser atingida (40).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **6.2.2.4 Riscos e benefícios esperados** -->
A alfaelosulfase é considerada um medicamento seguro. Seus principais benefícios são a melhora no teste da caminhada de 6 minutos (TC6M) e redução da excreção de GAGs urinários.  
Os pacientes incluídos no único ensaio clínico randomizado (ECR) disponível (41) tinham todos idade igual ou superior a 5 anos e deambulavam; no período basal, percorriam em média 216,5 m (amplitude: 42,4-321,5 m) no TC6M (grupo com administração semanal). O efeito médio estimado no TC6M da intervenção _versus_ placebo foi de 22,5 metros (IC 95% 4,0 a 40,9; p = 0,017) para o grupo semanal. A taxa de normalização do QS no teste de urina foi significativamente superior nos braços de intervenção (p < 0,001), resultando em uma média de diminuição de 41% (amplitude: 32,4%-49%) (41).  
A alfaelosulfase foi considerada segura, com eventos adversos leves e facilmente tratáveis na maioria dos casos. Os eventos adversos relatados foram dois casos de pneumonia, um episódio de hipersensibilidade, dor no local da infusão, infecção respiratória baixa, otite média, urticária, infecção viral do trato respiratório superior e vômitos, além de reação anafilática. O único estudo controlado por placebo (41) não encontrou diferença significativa na ocorrência de eventos adversos entre os grupos.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **7. TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, ao paciente ou aos pais ou responsáveis quando a TRE estiver sendo considerada e antes de iniciá-la. Durante o acompanhamento do paciente com TRE, os parâmetros de resposta terapêutica deverão ser avaliados periodicamente e discutidos com os pais, paciente ou responsáveis. No caso de interrupção por falha de adesão, o paciente e parentes deverão ser inseridos em programa de incentivo à adesão, e o paciente poderá retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas. O tempo de tratamento não pode ser prédeterminado, devendo ser mantido enquanto indicado e dele o doente se beneficie.  
A TRE deve ser interrompida nas seguintes situações:  
- Pacientes que desenvolverem condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como resultado da MPS IV A ou de outra doença associada, em acordo entre mais de um especialista;  
- pacientes que não apresentarem pelo menos 50% de adesão ao número de infusões previstas em um ano, ao número de consultas previstas em um ano ou ao número de avaliações previstas em um ano com o médico responsável pelo seguimento do paciente, desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que, mesmo após o programa, não comparecerem a pelo menos 50% do número de infusões, consultas ou avaliações previstas em um ano;  
- pacientes que apresentarem hipersensibilidade ou reação adversa grave (choque anafilático, risco de óbito) ao uso da alfaelosulfase, que não podem ser controladas com segurança utilizando medidas terapêuticas e preventivas apropriadas;  
- pacientes com idade > 18 anos que, após serem devidamente informados sobre os riscos e benefícios de sua decisão, optarem por não mais se submeterem ao tratamento com TRE intravenosa com alfaelosulfase; **ou**  
**-** pacientes que <u>não atingirem pelo menos três dos cinco critérios de melhora abaixo descritos após seis</u> meses de tratamento:  
- a. <u>Pacientes que nunca receberam o tratamento:</u>  
- i. melhora no teste de caminhada de 6 minutos (TC6M) em pelo menos 20 metros em relação ao valor no início do tratamento;  
- ii. melhora na CVF ou VEF1, medida por espirometria, em pelo menos 5% com relação ao valor no início do tratamento;  
- iii. redução de GAGs urinários em pelo menos 30% em relação ao valor no início do tratamento;  
- iv. declínio da fração de ejeção em menos de 10% em relação ao valor no início do tratamento, medido por meio de ecocardiograma;  
- v. estabilização na avaliação da qualidade de vida medida por meio da aplicação de pelo menos um de três instrumentos validados (pelo menos um deve estar melhor ou estável): questionário de qualidade de vida (para o paciente ou para o cuidador); instrumento para avaliação da dor (para o paciente); inventário de depressão de Beck (para o paciente).  
b. <u>Pacientes em tratamento por pelo menos seis meses:</u>  
<mark>- Pacientes em tratamento devem ser reavaliados quando da publicação deste PCDT e seis meses depois, por meio de TC6M, espirometria (CVF/VEF1), níveis urinários de GAGs, ecocardiograma e aplicação de questionário de qualidade de vida validado. Pelo menos três dos cinco parâmetros devem mostrar melhora ou manterem-se estáveis no período (a variação aceita para estabilidade é de 5%). Caso haja piora, o tratamento deve ser interrompido.</mark>

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **8. MONITORIZAÇÃO** -->
Os pacientes devem ter a resposta terapêutica e os eventos adversos monitorados. O médico deve realizar anamnese completa em cada visita e coletar dados de altura (em pé ou em decúbito dorsal, e, no caso de restrições nos membros inferiores, por segmento), peso e perímetro cefálico, de preferência usando o mesmo instrumento, devidamente calibrado. O exame físico deve ser completo e incluir sinais vitais (temperatura, frequência cardíaca, frequência respiratória e pressão arterial), bem como medidas para quantificação do tamanho do fígado (por hepatimetria). A avaliação do desenvolvimento sexual deve ser realizada em adolescentes, de acordo com os critérios de Tanner (42,43). Nas visitas, dados sobre todas as avaliações realizadas desde o último agendamento devem ser obtidos, e os testes necessários devem ser solicitados, incluindo avaliação por especialistas em neurologia, otorrinolaringologia, oftalmologia, cardiologia e pneumologia, conforme indicação e a critério do médico assistente.  
A maioria dos pacientes adultos com MPS IV A tem altura abaixo do percentil 3, inferior a 120 cm (5), com tendência de maior IMC (percentil >85) (2). Além disso, a altura pode reduzir com o passar do tempo, por deformidades esqueléticas, como cifoscoliose e geno valgo. A velocidade de crescimento começa a reduzir a partir de um ano de idade, e curvas específicas para MPS IV A estão disponíveis (2).  
Como a obesidade pode exacerbar as alterações em membros inferiores, deve ser feito monitoramento adequado desta comorbidade.  
As avaliações de rotina devem ser realizadas semestralmente pelo médico assistente, com avaliação da necessidade de vacinação, orientação dietética, exames e orientações preventivas (2). Salienta-se que a realização de aconselhamento genético é fundamental.  
O **Apêndice 1** apresenta as avaliações consideradas mínimas para o acompanhamento de pacientes com MPS IV A. São definidos períodos mínimos apenas para as avaliações que têm por objetivo detectar a eficácia e segurança da TRE e do TCTH; para as demais, a periodicidade de avaliações fica a critério do médico assistente. Assim, é recomendada a realização semestral (mês 0, 6 e 12), no primeiro ano de tratamento, de TC6M, dosagem  
urinária de GAGs, ecocardiograma, espirometria e questionários de qualidade de vida como parte da avaliação da resposta ao tratamento. Após o primeiro ano, tais avaliações devem ser anuais, conforme o **Apêndice 2.**  
A análise de GAGs urinários pode ser quantitativa, feita pelo método espectrofotométrico descrito por De Jong _et al_ . (44), ou permitir a identificação, por cromatografia ou eletroforese, do tipo de GAG que está sendo excretado em quantidade aumentada na urina (método qualitativo) (44,45). Na MPS IV A, ocorre aumento da excreção de QS e C6S, mas não de forma tão acentuada como ocorre nas outras MPS, sendo possível, inclusive, não serem encontradas alterações nesses biomarcadores (46). A quantificação de GAGs urinários é utilizada principalmente para monitorização do tratamento específico da MPS IV A, uma vez que ocorre diminuição da excreção dessas moléculas na vigência do tratamento (51).  
Como parte da avaliação do tratamento, os seguintes itens devem ser respeitados:  
- Monitorar os resultados dos transplantes por meio de estudo observacional original.  
− Monitorar o uso, a adesão, a indicação e os resultados da TRE com alfaelosulfase. Por meio desse monitoramento, será possível estabelecer grupos de pacientes que são de fato beneficiados e reavaliar a incorporação do medicamento a médio prazo.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da MPS IV A deve ser feito por equipe em serviços especializados, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, é recomendado, se possível, que o médico responsável tenha experiência e seja treinado nessa atividade.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.  
Para a administração de medicamentos biológico intravenoso e para maior racionalidade do uso e avaliação da efetividade do medicamento, a infusão deve ser feita em ambiente hospitalar ou serviço especializado.  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos (REREME/INCA/MS), e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os resultados de todos os casos MPS IV A submetidos a TCTH mieloablativo alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos um ano da realização do transplante.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste PCDT, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.  
Para o esclarecimento sobre os riscos e benefícios do transplante de células-tronco hematopoéticas  
alogênico, adotam-se as normas preconizadas no âmbito do Sistema Nacional de Transplantes.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **11. REFERÊNCIAS BIBLIOGRÁFICAS** -->
**1.** MJ NE. The Mucopolysaccharidoses.  The Online Metabolic and Molecular Bases of Inherited Disease.  
**2.** Montaño AM, Tomatsu S, Gottesman GS, Smith M, Orii T. International Morquio A Registry: clinical manifestation and natural course of Morquio A disease. J Inherit Metab Dis. 2007; 30(2):165-74.  
**3.** Aslam R, van Bommel ACM, Hendriksz CJ, Jester A. Subjective and Objective Assessment of Hand Function  
in Mucopolysaccharidosis IVa Patients. JIMD Rep. 2013; 9:59-65  
4. Dhawale AA, Church C, Henley J, Holmes L, Thacker MM, Mackenzie WG, et al. Gait pattern and lower extremity alignment in children with Morquio syndrome. J Pediatr Orthop B. 2013; 22(1):59-62.  
5.   Harmatz P, Mengel KE, Giugliani R, Valayannopoulos V, Lin SP, Parini R, et al. The Morquio A Clinical  
Assessment Program: baseline results illustrating progressive, multisystemic clinical impairments in Morquio A  
subjects. Mol Genet Metab. 2013; 109(1):54-61  
**6.** Hendriksz CJ, Berger KI, Giugliani R, Harmatz P, Kampmann C, Mackenzie WG, et al. International guidelines for the management and treatment of Morquio A syndrome. Am J Med Genet A. 2015 Jan; 167A(1):11-25.  
7. Kampmann C, Abu-Tair T, Gökce S, Lampe C, Reinke J, Mengel E, et al. Heart and Cardiovascular Involvement in Patients with Mucopolysaccharidosis Type IVA (Morquio-A Syndrome). PLoS One. 2016 Sep 9; 11(9):e0162612.  
8.  Berger KI, Fagondes SC, Giugliani R, Hardy KA, Lee KS, McArdle C, et al. Respiratory and sleep disorders in mucopolysaccharidosis. J Inherit Metab Dis. 2013 Mar; 36(2):201-10.  
9.   Lavery C, Hendriksz C. Mortality in patients with morquio syndrome a. JIMD Rep. 2015; 15:59-66.  
10. Leadley RM, Lang S, Misso K, Bekkering T, Ross J, Akiyama T, et al. A systematic review of the prevalence of Morquio A syndrome: challenges for study reporting in rare diseases. Orphanet J Rare Dis. 2014 Nov 18; 9:173. 11. Giugliani R, Federhen A, Michelin-Tirelli K, Riegel M, Burin M. Relative frequency and estimated minimal frequency of Lysosomal Storage Diseases in Brazil: Report from a Reference Laboratory. Genet Mol Biol. 2017 Jan-Mar; 40(1):31-9.  
12. The Human Gene Mutation Database [Internet]. 2007-2017 [access 18 oct 2019]. Available from: <u>http://www.hgmd.cf.ac.uk/ac/index.php.</u>  
13. Morrone A, Tylee KL, Al-Sayed M, Brusius-Facchin AC, Caciotti A, Church HJ, et al. Molecular testing of 163 patients with Morquio A (Mucopolysaccharidosis IVA) identifies 39 novel GALNS mutations. Mol Genet Metab. 2014 Jun; 112(2):160-70.  
14. Tomatsu S, Montaño AM, Oikawa H, Smith M, Barrera L, Chinen Y, et al. Mucopolysaccharidosis type IVA (Morquio A disease): clinical review and current treatment. Curr Pharm Biotechnol. 2011 Jun; 12(6):931-45.  
15. Turra GS, Schwartz IV. Evaluation of orofacial motricity in patients with mucopolysaccharidosis: a crosssectional study. J Pediatr (Rio J). 2009 May-Jun; 85(3):254-60.  
16. Schwartz IV, Souza CF, Giugliani R. Treatment of inborn errors of metabolism. J Pediatr (Rio J). 2008 Aug; 84(4 Suppl):S8-19.  
17. Giugliani R, Federhen A, Vairo F, Vanzella C, Pasqualim G, da Silva LM, et al. Emerging drugs for the treatment of mucopolysaccharidoses. Expert Opin Emerg Drugs. 2016; 21(1):9-26.  
18. Solanki GA, Martin KW, Theroux MC, Lampe C, White KK, Shediac R, et al. Spinal involvement in mucopolysaccharidosis IVA (Morquio-Brailsford or Morquio A syndrome): presentation, diagnosis and management. J Inherit Metab Dis. 2013 Mar; 36(2):339-55.  
19. Hendriksz CJ, Lavery C, Coker M, Ucar SK, Jain M, Bell L, et al. Burden of disease in patients with Morquio A syndrome: results from an international patient-reported outcomes survey. Orphanet J Rare Dis. 2014 Mar 7; 9:32.  
20. Saúde Md. Asma. In: Conitec, editor. http://portalarquivos2.saude.gov.br/images/pdf/2014/julho/22/PT-SAS- <u>N---1317-alterado-pela-603-de-21-de-julho-de-2014.pdf2013.</u>  
21. Couprie J, Denis P, Guffon N, Reynes N, Masset H, Beby F. [Ocular manifestations in patients affected by Morquio syndrome (MPS IV)]. J Fr Ophtalmol. 2010 Nov; 33(9):617-22.  
22. Summers CG, Ashworth JL. Ocular manifestations as key features for diagnosing mucopolysaccharidoses. Rheumatology (Oxford). 2011 Dec; 50 Suppl 5:v34-40.  
23. Hendriksz CJ, Al-Jawad M, Berger KI, Hawley SM, Lawrence R, Mc Ardle C, et al. Clinical overview and treatment options for non-skeletal manifestations of mucopolysaccharidosis type IVA. J Inherit Metab Dis. 2013 Mar; 36(2):309-22.  
24. Leslie T, Siddiqui MA, Aitken DA, Kirkness CM, Lee WR, Fern AI. Morquio syndrome: electron microscopic findings. Br J Ophthalmol. 2005 Jul; 89(7):925-6.  
25. Käsmann-Kellner B, Weindler J, Pfau B, Ruprecht KW. Ocular changes in mucopolysaccharidosis IV A (Morquio A syndrome) and long-term results of perforating keratoplasty. Ophthalmologica. 1999; 213(3):200-5. 26. Bredenkamp JK, Smith ME, Dudley JP, Williams JC, Crumley RL, Crockett DM. Otolaryngologic manifestations of the mucopolysaccharidoses. Ann Otol Rhinol Laryngol. 1992 Jun; 101(6):472-8.  
27. Riedner ED, Levin LS. Hearing patterns in Morquio's syndrome (mucopolysaccharidosis IV). Arch Otolaryngol. 1977 Sep; 103(9):518-20.  
28. Kinirons MJ, Nelson J. Dental findings in mucopolysaccharidosis type IV A (Morquio's disease type A). Oral Surg Oral Med Oral Pathol. 1990 Aug; 70(2):176-9.  
29. Rølling I, Clausen N, Nyvad B, Sindet-Pedersen S. Dental findings in three siblings with Morquio's syndrome. Int J Paediatr Dent. 1999 Sep; 9(3):219-24. 30. James A, Hendriksz CJ, Addison O. The oral health needs of children, adolescents and young adults affected by a mucopolysaccharide disorder. JIMD Rep. 2012; 2:51-8.  
31. Reichert R, Campos LG, Vairo F, de Souza CF, Pérez JA, Duarte J, et al. Neuroimaging Findings in Patients with Mucopolysaccharidosis: What You Really Need to Know. Radiographics. 2016 Sep-Oct; 36(5):1448-62. 32. Kachur E, Del Maestro R. Mucopolysaccharidoses and spinal cord compression: case report and review of the literature with implications of bone marrow transplantation. Neurosurgery. 2000 Jul; 47(1):223-8; discussion 2289  
33. Ransford AO, Crockard HA, Stevens JM, Modaghegh S. Occipito-atlanto-axial fusion in Morquio-Brailsford syndrome. A ten-year experience. J Bone Joint Surg Br. 1996 Mar; 78(2):307-13. 34. Williams N, Cundy P, Eastwood D. Surgical Management of Thoracolumbar Kyphosis in Patients with Mucopolysaccharidosis: A Systematic Review. Spine (Phila Pa 1976). 2017 Dec 1; 42(23):1817-25.  
35. Shinhar SY, Zablocki H, Madgy DN. Airway management in mucopolysaccharide storage disorders. Arch Otolaryngol Head Neck Surg. 2004; 130(2):233-7.  
36. Brain AI. The laryngeal mask--a new concept in airway management. Br J Anaesth. 1983; 55(8):801-5.  
37. Hoogerbrugge PM, Brouwer OF, Bordigoni P, Ringden O, Kapaun P, Ortega JJ, et al. Allogeneic bone marrow transplantation for lysosomal storage diseases. The European Group for Bone Marrow Transplantation. Lancet. 1995; 345(8962):1398-402.  
38. Tomatsu S, Sawamoto K, Alméciga-Díaz CJ, Shimada T, Bober MB, Chinen Y, et al. Impact of enzyme replacement therapy and hematopoietic stem cell transplantation in patients with Morquio A syndrome. Drug Des Devel Ther. 2015; 9:1937-53.  
39. Yabe H, Tanaka A, Chinen Y, Kato S, Sawamoto K, Yasuda E, et al. Hematopoietic stem cell transplantation for Morquio A syndrome. Mol Genet Metab. 2016; 117(2):84-94.  
40. Vimizim [Bula de remédio]. São Paulo: Biomarin Brasil Farmacêutica Ltda; 2016  
41. Hendriksz CJ, Burton B, Fleming TR, Harmatz P, Hughes D, Jones SA, et al. Efficacy and safety of enzyme replacement therapy with BMN 110 (elosulfase alfa) for Morquio A syndrome (mucopolysaccharidosis IVA): a phase 3 randomised placebo-controlled study. J Inherit Metab Dis. 2014 Nov; 37(6):979-90.  
42. Marshall WA, Tanner JM. Variations in pattern of pubertal changes in girls. Arch Dis Child. 1969 Jun; 44(235):291-303.  
43. Marshall WA, Tanner JM. Variations in the pattern of pubertal changes in boys. Arch Dis Child. 1970 Feb; 45(239):13-23.  
44. de Jong JG, Hasselman JJ, van Landeghem AA, Vader HL, Wevers RA. The spot test is not a reliable screening procedure for mucopolysaccharidoses. Clin Chem. 1991;37(4):572-5.  
45. Auray-Blais C, Lavoie P, Tomatsu S, Valayannopoulos V, Mitchell JJ, Raiman J, et al. UPLC-MS/MS detection of disaccharides derived from glycosaminoglycans as biomarkers of mucopolysaccharidoses. Anal Chim Acta. 2016 Sep 14; 936:139-48.  
46. Peracha H, Sawamoto K, Averill L, Kecskemethy H, Theroux M, Thacker M, et al. Molecular genetics and metabolism, special edition: Diagnosis, diagnosis and prognosis of Mucopolysaccharidosis IVA. Mol Genet Metab. 2018 Sep; 125(1-2):18-37.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: ALFAELOSULFASE -->
Eu,____________________________________________________ (nome do paciente), declaro ter sido  
informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao  
uso de **alfaelosulfase,** indicada para o tratamento da **mucopolissacaridose tipo IVA** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
_______________________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como melhora do teste da caminhada de 6 minutos e redução dos  
- glicosaminoglicanos (GAG) urinários.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- efeitos adversos muito frequentes da alfaelosulfase incluem reações à infusão, como dor no local da  
- aplicação, dor de cabeça, tontura, falta de ar, náusea, febre, dor de barriga e dor na boca e na garganta;  
- efeitos adversos frequentes incluem dores nos músculos;  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a  
devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu  
tratamento, desde que assegurado o anonimato.      (    ) Sim (     ) Não  
<!-- Start of picture text -->
Local:                                                                                          Data:<br>Nome do paciente:<br>Cartão Nacional do SUS:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>Assinatura do paciente ou do responsável legal<br>Médico:                                                                           CRM:                                 RS:<br>______________________________<br>Assinatura e carimbo do médico<br>Data:<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: SUPORTE E SINTOMÁTICOS -->
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
|**Sistema nervoso**<br>**central**|Hidrocefalia/hipertensão intracraniana|Derivação ventrículo-peritoneal|
|**Sistema nervoso**<br>**periférico**|Compressão medular<br>Síndrome do túnel do carpo|Cirurgia, fisioterapia<br>Cirurgia|
|**Olhos**|Acuidade visual diminuída<br>Opacificação de córnea|Avaliação oftalmológica<br>Transplante de córnea (em casos específicos)|
|**Vias aéreas**|Síndrome da apneia obstrutiva do sono|Amigdalectomia, adenoidectomia,<br>oxigenioterapia|
|||Avaliação da função pulmonar|
||Infecções de repetição, hipersecreção|Farmacoterapia|
||Doença pulmonar restritiva|Fisioterapia|
|**Tecido conjuntivo**|Hérnias|Cirurgia|
|**Articulações**|Dor, contraturas|Fisioterapia, terapia ocupacional<br>Farmacoterapia|
|**Ossos**|Geno valgo, luxação de quadril|Cirurgia|
|**Orelhas**|Hipoacusia|Próteses (em casos específicos)|
||Otites de repetição|Farmacoterapia, cirurgia|
|**Gastrointestinal**|Diarreia<br>Ganho inadequado ou excessivo de peso|Orientação nutricional<br>Orientação nutricional|
||Distúrbio de deglutição|Farmacoterapia, fonoaudiologia<br>Cirurgia (gastrostomia)|
|**Bucomaxilofacial**|Má oclusão, dentição anômala|Cirurgia<br>Aparelho ortodôntico|
|**Cardiovascular**|Valvulopatias, cardiomiopatia, insuficiência<br>cardíaca|Farmacoterapia, cirurgia|  
Fonte: Elaborado a partir de dados de Hendriksz, Berger, Giugliani, Harmatz, Kampmann, Mackenzie, _et al_ (6)

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: PACIENTES COM MPS IVA SOB TERAPIA DE REPOSIÇÃO ENZIMÁTICA OU NÃO -->
|**Avaliações**|**Avaliação**<br>**inicial**|**A cada 6**<br>**meses**|**Anualmente**|
|---|---|---|---|
|**Atividade enzimática**|X|X*||
|**GAGs urinários**|X|X**||
|**Aconselhamento genético**|X|||
|**História médica**|X|X||
|**Revisão do número de infusões realizadas no período*****||X||
|**Determinação da adesão ao**<br>**acompanhamento/tratamento****|X|X||
|**Peso/altura**|X|X||
|**Pressão arterial**|X|X||
|**Hepatimetria (exame físico)**|X|X||
|**Questionário de qualidade de vida validado****|X|X<sup>$</sup>|X|
|**AVALIAÇÃO NEUROLÓGICA**||||
|**- Exame neurológico**|X|X||
|**- RNM da coluna**|X|||
|**- RX de coluna**|X|||
|**AVALIAÇÃO OFTALMOLÓGICA (acuidade visual,**<br>**retina, córnea)**|X|||
|**AUDIOMETRIA**|X|||
|**AVALIAÇÃO FUNCIONAL**||||
|**- Ecocardiograma**|X|X<sup>$</sup>||
|**- Eletrocardiograma**|X|||
|**- CVF/VEF1 (espirometria)**|X|X<sup>$</sup>|X|
|**- Polissonografia**|X|||
|**- TC6M****|X|X||
|**AVALIAÇÃO ORTOPÉDICA**|X|||
|**- Raio X de quadril e membros inferiores**|X|||  
*Para pacientes que fizeram transplante de células-tronco hematopoéticas. **Para pacientes em tratamento específico (transplante de células-tronco hematopoéticas ou terapia de reposição enzimática). ***Para pacientes em terapia de reposição enzimática.<sup>$</sup> Para pacientes em terapia de reposição enzimática, nos primeiros seis meses de monitorização.  
As demais avaliações, incluindo as avaliações indicadas somente no período basal (iniciais), devem ser realizadas em períodos determinados pelo médico assistente.  
GAGs = glicosaminoglicanos; RNM = ressonância magnética; CVF = capacidade vital forçada; VEF1 = volume  
expiratório forçado no primeiro segundo; TC6M = teste da caminhada de 6 minutos.  
Fonte: Elaborado a partir de dados de Hendriksz, Berger, Giugliani, Harmatz, Kampmann, Mackenzie, _et al_ (6)  
**APÊNDICE 3**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **1. POLÍTICA NACIONAL DE ATENÇÃO INTEGRAL ÀS PESSOAS COM DOENÇAS RARAS** -->
A Política Nacional de Atenção Integral às Pessoas com Doenças Raras foi publicada em 12 de fevereiro de 2014 por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014<sup>1</sup> , que, além de instituir a referida política, aprovou as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS) e instituiu incentivos financeiros de custeio.  
Essa Política tem como objetivo reduzir a mortalidade e a incapacidade causadas por essas doenças, bem como contribuir para a melhoria da qualidade de vida das pessoas com doenças raras. Está organizada no conceito das Redes de Atenção à Saúde (RAS), considerando-se todos os pontos de atenção, assim como os sistemas logísticos e de apoio necessários para garantir a oferta de ações de promoção, detecção precoce, diagnóstico, tratamento e cuidados paliativos, de forma oportuna, para as pessoas com doenças raras.  
A política utiliza como definição de doença rara a estabelecida pela Organização Mundial de Saúde: “aquela doença que afeta até 65 pessoas em cada 100.000 indivíduos, ou seja, 1,3 pessoas para cada 2.000 indivíduos”, conforme estabelecido nas diretrizes citadas acima.  
Como não seria possível organizar as diretrizes abordando as doenças raras de forma individual, devido ao grande número de destas, essas diretivas foram organizadas na forma de eixos estruturantes, que permitem classificar as doenças raras de acordo com suas características comuns, com a finalidade de maximizar os benefícios aos usuários.  
Dessa forma, as doenças raras foram classificadas em dois eixos: a) Doenças raras de origem genética, com três grupos: 1 - Anomalias congênitas ou de manifestação tardia, 2 - Deficiência intelectual, 3 - Erros inatos do metabolismo; b) Doenças Raras de origem não genética, com os seguintes grupos de causas: 1 - Infecciosas, 2 - Inflamatórias, 3 - Autoimunes, 4 - Outras doenças raras não genéticas.  
Para a implantação e implementação dessa política foram incorporados, inicialmente, 15 exames na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materias Especiais do SUS, abrangendo biologia molecular, citogenética e imunoensaios, além do aconselhamento genético.  
Os princípios e diretrizes dessa Portaria, expressos no artigo 6º, inciso VI, visam garantir a incorporação e o uso de tecnologias voltadas para a promoção, a prevenção e o cuidado integral na RAS, incluindo tratamento medicamentoso e fórmulas nutricionais, quando indicados no âmbito do SUS, que devem ser resultado das recomendações formuladas por órgãos governamentais a partir do processo de avaliação e aprovação pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e elaboração dos Protocolos Clínicos e Diretrizes Terapêuticas (PCDT).  
Para viabilizar as definições e a implementação da Política, a Coordenação de Média e Alta Complexidade (CGMAC), juntamente com a CONITEC, organizou um encontro com especialistas que atuam em doenças raras em todo o país, abarcando os dois eixos da Política e seus respectivos grupos supracitados. O “Painel de Especialistas”, realizado nos dias 19 e 20 de maio de 2014, objetivou estabelecer critérios e prioridades para a  
> 1 Republicada para consolidar as alterações introduzidas pela Portaria nº 981/GM/MS, de 20 de maio de 2014, publicada no Diário Oficial da União nº 95, de 21 de maio de 2014, Seção 1, página 44.  
elaboração de PCDTs para a implementação da Política Nacional de Atenção Integral às Pessoas com Doenças Raras no SUS. Entre as doenças elencadas para elaboração de PCDT priorizados, está a MPS IV A.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **2. REUNIÃO DE ESCOPO** -->
A fim de dar continuidade ao processo de elaboração do PCDT, foi realizada uma reunião de escopo com o comitê gestor e elaborador deste PCDT, realizada dia 25 de fevereiro de 2019, em Brasília, quando foram estabelecidas as seguintes perguntas de pesquisa para elaboração deste PCDT:  
- A alfaelosulfase é eficaz para o tratamento da MPS IVA?  
- A alfaelosulfase é segura em gestantes e pacientes em aleitamento materno?  
- Quais são os critérios para interrupção de tratamento?

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo IV A | secao: **3. BUSCAS NA LITERATURA** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio da CONITEC para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da MPS IVA. Foi também realizada busca por diretrizes nacionais e internacionais a respeito da doença. Não foram encontradas tecnologias disponíveis, já incorporadas ou em avaliação. As seguintes bases de diretrizes foram consultadas:  
- NICE _guidelines_ – http://www.nice.org.uk/guidance/published?type=CG;  
- _National Library of Australia_ – http://webarchive.nla.gov.au/gov/;  
- PubMed/MEDLINE  
As diretrizes localizadas foram as seguintes:  
_- International guidelines for the management and treatment of Morquio A syndrome._ Hendriksz CJ, Berger KI, Giugliani R, Harmatz P, Kampmann C, Mackenzie WG, Raiman J, Villarreal MS, Savarirayan R, _et al_ . Am J Med Genet Part A. 2015; 167A:11-25.  
- _Mucopolysaccharidosis I, II, and VI: Brief review and guidelines for treatment._ Giugliani R, _et al._ Genet  
- Mol Biol. 2010; 33(4): 589-604.  
Após a reunião de escopo, ficou estabelecido que o PCDT se destina a crianças e adultos com MPS IVA, de ambos os sexos, e tem por objetivo revisar práticas diagnósticas e terapêuticas e incorporar as recomendações referentes ao tratamento, medicamentoso com a TRE com alfaelosulfase e o TCTH.  
Para a elaboração dos critérios diagnósticos e das situações especiais de gestação e aleitamento, foram utilizadas diretrizes internacionais elaboradas por diferentes grupos de especialistas, as quais são utilizadas como consenso nos diversos centros de referência.  
Para avaliação de interrupção de tratamento, foi utilizada a seguinte estratégia de busca: “(mucopolysaccharidosis type iva OR morquio syndrome) AND interruption”, sendo apenas três resultados encontrados, listados abaixo. A base de dados buscada foi MEDLINE/PubMed, e as referências encontradas não respondiam à pergunta definida na reunião de escopo, sendo utilizadas as diretrizes internacionais acima citadas para responder à questão.  
- Safety and clinical activity of elosulfase alfa in pediatric patients with Morquio A syndrome (mucopolysaccharidosis IVA) less than 5 y. Jones SA, _et al_ . Pediatr Res. 2015 Dec;78(6):717-22.  
- Efficacy and safety of enzyme replacement therapy with BMN 110 (elosulfase alfa) for Morquio A syndrome (mucopolysaccharidosis IVA): a phase 3 randomised placebo-controlled study. Hendriksz CJ, _et al_ . J Inherit Metab Dis. 2014 Nov; 37(6):979-90.  
- Fetal akinesia in metatropic dysplasia: The combined phenotype of chondrodysplasia and neuropathy? Unger S, _et al_ . Lausch E, _et al_ . Am J Med Genet A. 2011 Nov; 155A(11):2860-4. Para a elaboração dos demais itens do PCDT, foram utilizadas as buscas, os resultados, as recomendações e as referências constantes no Relatório de Recomendação da alfaelosulfase como terapia de reposição enzimática no tratamento da MPS IVA, disponível em <u>http://conitec.gov.br/images/Relatorios/2018/Relatorio_Alfaelosulfase_MPS_IVa.pdf</u>

---

