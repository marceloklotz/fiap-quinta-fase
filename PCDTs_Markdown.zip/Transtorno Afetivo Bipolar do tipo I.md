<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: Geral -->
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: Geral -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Transtorno Afetivo Bipolar do tipo I.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o transtorno afetivo bipolar do tipo I no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com este transtorno;  
Considerando que os protocolos clínicos e diretrizes terapêuticassão resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando a Portaria SCTIE/MS n<sup>o</sup> 3, de 9 de março de 2015, que incorpora medicamentos para o tratamento do transtorno afetivo bipolar do tipo I, com base no Relatório de Recomendação n<sup>o</sup> 140 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC); e  
Considerando a avaliação técnica da CONITEC, do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS),do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS), do Departamento de Ações Programáticas Estratégicas (DAPES/SAS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º Ficam aprovados, na forma do Anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo Clínico e Diretrizes Terapêuticas - Transtorno Afetivo Bipolar do tipo I.  
Parágrafo único. O Protocolo de que trata este artigo, que contém o conceito geral do transtorno afetivo bipolar do tipo I, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento o transtorno afetivo bipolar do tipo I.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos como transtorno em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
ALBERTO BELTRAME

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS  
TRANSTORNO AFETIVO BIPOLAR DO TIPO I

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A busca foi realizada em 31/08/2014 na base de dados MEDLINE/PubMed com os termos “bipolar disorder” [MeSH] AND “therapeutics” [MeSH], limitada a estudos em humanos, meta-análises e ensaios clínicos randomizados, e resultou em 650 estudos.  
Uma nova busca, restrita apenas a meta-análises, resultou em 52 artigos. Todos foram revisados, excluindo-se aqueles não relacionados a estudos de eficácia ou efetividade do tratamento do transtorno afetivo bipolar (TAB). Foram incluídos neste Protocolo 30 artigos, sendo 11 deles relacionados ao tratamento da mania, 8 ao tratamento da depressão e 6 ao tratamento de manutenção, quatro relacionados a intervenções psicossociais e um relacionado ao tratamento com eletroconvulsoterapia (ECT).  
Foram utilizados os mesmos parâmetros em buscas nas bases de dados Cochrane e Embase. A busca na biblioteca Cochrane resultou em 3 revisões sistemáticas e 34 resumos de revisões sistemáticas com qualidade avaliada. A busca no Embase encontrou 337 estudos, todos duplicados em relação à primeira busca conduzida no MEDLINE/PubMed.  
Além disso, também foram realizadas consultas ao UpToDate, versão 19.3, e utilizados outros artigos selecionados pelos autores para a elaboração deste Protocolo. Todos os ensaios clínicos citados não modificam a evidência já estabelecida por meta-análises, porém reforçam a argumentação das mesmas.  
Uma nova busca foi realizada em 23/09/2015 com os mesmos termos nas mesmas bases, resultando na inclusão de duas novas meta-análises, que, no entanto, apenas complementam a evidência já existente.  
Ressalta-se que, no que se refere a terapias, este Protocolo tem maior enfoque no tratamento medicamentoso, devendo ter sua leitura complementada por outros documentos

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
publicados pelo Ministério da Saúde no que se refere às demais condutas multidisciplinares, integrativas e não medicamentosas no cuidado à pessoa com TAB.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O transtorno afetivo bipolar (TAB) é um transtorno de humor caracterizado pela alternância de episódios de depressão, mania ou hipomania. É uma doença crônica que acarreta grande sofrimento, afetando negativamente a vida dos doentes em diversas áreas, em especial no trabalho, no lazer e nos relacionamentos interpessoais (1). O TAB resulta em prejuízo significativo e impacto negativo na qualidade de vida dos pacientes (2). Indivíduos com TAB também demonstram aumentos significativos na utilização de serviços de saúde ao longo da vida se comparados a pessoas sem outras doenças psiquiátricas (3).  
A síndrome maníaca é um componente fundamental para o diagnóstico do TAB. Suas principais características são: exaltação do humor, aceleração do pensamento com fuga de ideias e aumento da atividade motora. Características associadas a essas são: aumento de energia (com diminuição da necessidade de sono), pressão de fala e taquilalia, irritabilidade, paranoia, hipersexualidade e impulsividade. A intensidade, o tipo e a cronicidade desses sintomas determinam a subdivisão do diagnóstico entre mania ou hipomania (2).  
Na hipomania, as alterações são mais moderadas e podem ou não resultar em sérios problemas para o indivíduo. Em episódios mais intensos, no entanto, elas comprometem profundamente a vida dos pacientes e de suas famílias (2).  
Os episódios depressivos do TAB, em contraste direto com os episódios de mania, são geralmente caracterizados por uma lentificação ou diminuição de quase todos os aspectos de emoção e comportamento: velocidade de pensamento e fala, energia, sexualidade e capacidade de sentir prazer. Assim como nos episódios maníacos, a gravidade pode variar consideravelmente – de uma discreta lentificação física e mental, com quase nenhuma distorção cognitiva ou perceptiva, até quadros graves, com delírios e alucinações. A depressão associada ao TAB em nada se diferencia quanto à sintomatologia em relação a outros quadros depressivos. É a história prévia de um episódio maníaco ou hipomaníaco ao longo da vida que define o quadro depressivo como depressão bipolar (2).  
Enquanto a característica definidora do TAB do tipo I é o episódio maníaco, podendo ou não haver episódios depressivos, o TAB do tipo II é caracterizado por pelo menos um episódio depressivo associado a um episódio de hipomania.  
Uma das razões para a dificuldade em se diagnosticar o TAB é o fato de que a ocorrência de sintomas depressivos é maior do que a de sintomas maníacos ou hipomaníacos durante o curso da doença, que frequentemente tem início com um episódio depressivo. Além disso, os pacientes tendem a buscar tratamento para sintomas depressivos com maior frequência

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
do que para sintomas maníacos ou hipomaníacos, que muitas vezes não são prontamente reconhecidos (2).  
O TAB é a quarta maior causa de prejuízo funcional entre os transtornos neuropsiquiátricos, sendo superado apenas por depressões unipolares, transtornos associados ao uso de álcool e a esquizofrenia (4). É responsável por 7% do total de anos de vida perdidos ajustados por incapacidades relacionadas a doenças neuropsiquiátricas, de acordo com a Organização Mundial da Saúde (5).  
Estimativas de prevalência do TAB são consistentes em diferentes culturas e grupos étnicos, variando entre 0,4% e 1,6% em adultos (6). Estimativas mais recentes, que incluem o espectro mais amplo da doença, sugerem prevalências entre 4% e 5% da população geral, em estudos realizados nos Estados Unidos e nos Países Baixos (7,8). No Brasil, um estudo realizado em São Paulo e publicado em 2005 encontrou uma prevalência ao longo da vida de 0,9% (9). Uma meta-análise publicada em 2015, que inclui 25 estudos de diferentes países, indica uma prevalência ao longo da vida de 1,06% para o TAB do tipo I (10).  
Existe um risco consideravelmente aumentado de suicídio entre pessoas com TAB: é de 15 a 20 vezes maior do que aquele da população geral, sendo que de 25% a 60% dos pacientes tentam suicídio pelo menos uma vez na vida, e de 4% a 19% morrem por suicídio (11,12). O tratamento de manutenção em longo prazo reduz o risco de suicídio nesses pacientes, o que também justifica a importância do tratamento (13,14).  
A idade média de surgimento do TAB encontra-se entre 17 e 21 anos (15), emergindo, portanto, nos anos formativos da vida de um indivíduo, o que causa impacto em seu desenvolvimento cognitivo e emocional e leva a dificuldades interpessoais, educacionais e financeiras, que podem ter repercussões para a vida toda. O foco do tratamento deve, portanto, envolver essas questões e procurar atingir melhorias em curto e longo prazo, a fim de diminuir o impacto da doença (15).  
Diferentemente do que se acreditava décadas atrás, pacientes com TAB apresentam um prejuízo cognitivo não apenas em episódios de mania ou de depressão, mas também durante os períodos de eutimia (humor normal, adequado às circunstâncias ambientais). Devido às características de cronicidade e recorrência, evidências indicam que o TAB está associado a uma progressiva deterioração funcional e cognitiva, sendo possível diferenciar estágios precoces e tardios do transtorno (16). Nesse sentido, fatores relacionados a um prognóstico pior seriam: maior número de estressores vitais (traumas, perdas, estresse grave), maior número de episódios de alterações de humor, maior uso de substâncias psicoativas, atraso do início do tratamento específico, pior adesão ao tratamento e maior número de comorbidades clínicas e psiquiátricas (17).  
<mark>A identificação precoce do transtorno e o encaminhamento ágil e adequado para o atendimento especializado dão à atenção básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.</mark>  
<mark>A Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde (CID-10) não classifica o TAB da mesma forma que o M</mark> anual Diagnóstico e Estatístico de Transtornos Mentais (DSM-5) (18), que é o sistema diagnóstico mais atual e mais utilizado. Apesar das altas prevalências e da relevância clínica do TAB do tipo II e dos demais transtornos relacionados, a evidência clínica específica para o seu tratamento ainda é limitada. Devido à maior disponibilidade de evidência clínica relacionada ao tratamento do TAB do tipo I, o presente Protocolo contempla apenas esse diagnóstico e tratamento.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- F31.1 Transtorno afetivo bipolar, episódio atual maníaco sem sintomas psicóticos  
- F31.2 Transtorno afetivo bipolar, episódio atual maníaco com sintomas psicóticos  
- F31.3 Transtorno afetivo bipolar, episódio atual depressivo leve ou moderado  
- F31.4 Transtorno afetivo bipolar, episódio atual depressivo grave sem sintomas psicóticos  
- F31.5 Transtorno afetivo bipolar, episódio atual depressivo grave com sintomas psicóticos  
- F31.6 Transtorno afetivo bipolar, episódio atual misto  
- F31.7 Transtorno afetivo bipolar, atualmente em remissão

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico do TAB é clínico e baseado nos critérios diagnósticos do DSM-5 (capítulo: “Transtorno Bipolar e Transtornos Relacionados”). Essa classificação descreve critérios gerais para caracterizar os dois principais episódios de humor do TAB, conforme mostrado a seguir:

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico de episódio maníaco é realizado quando são atendidos todos os critérios de A a D citados a seguir:

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A. Um período distinto de humor anormal e persistentemente elevado, expansivo ou irritável, e aumento anormal e persistente da energia ou da atividade dirigida a objetivos, com duração mínima de uma semana e presente na maior parte do dia, quase todos os dias (ou qualquer duração, se a hospitalização for necessária).  
B. Durante o período de perturbação do humor e aumento da energia ou da atividade, pelo menos três dos seguintes sintomas (quatro, se o humor for apenas irritável) estão presentes em grau significativo e representam uma mudança notável no comportamento habitual:  
1. Autoestima inflada ou grandiosidade;  
2. Redução da necessidade de sono (p. ex., sente-se descansado com apenas três horas de sono);  
3. Loquacidade maior que o habitual ou pressão para continuar falando;  
4. Fuga de ideias ou percepção subjetiva de que os pensamentos estão  
acelerados;  
5. Distratibilidade (i.e., a atenção é desviada muito facilmente por estímulos externos insignificantes ou irrelevantes), conforme relatado ou observado;  
6. Aumento da atividade dirigida a objetivos (seja socialmente, no trabalho ou na escola, seja sexualmente) ou da agitação psicomotora (i.e., atividade sem propósito não dirigida a objetivos);  
7. Envolvimento excessivo em atividades com elevado potencial para consequências dolorosas (p. ex., envolvimento em surtos desenfreados de compras, indiscrições sexuais ou investimentos financeiros insensatos).  
C. A perturbação do humor é suficientemente grave para causar prejuízo acentuado no funcionamento social ou profissional ou para necessitar de hospitalização a fim de prevenir dano a si mesmo ou a outras pessoas, ou quando existem características psicóticas.  
D. O episódio não é atribuível aos efeitos fisiológicos de uma substância (p. ex., droga de abuso, medicamento ou outro tratamento) ou a outra condição clínica.  
<u>Nota 1: Um episódio maníaco que surge durante tratamento antidepressivo (p.</u> ex., medicamento ou eletroconvulsoterapia) mas que persiste com um nível de sinais e sintomas além do efeito fisiológico desse tratamento é evidência suficiente para um episódio maníaco e, portanto, para o diagnóstico de TAB do tipo I.  
<u>Nota 2: Os critérios A a D caracterizam um episódio maníaco. A ocorrência de</u> pelo menos um episódio maníaco na vida é necessário para o diagnóstico de TAB do tipo I.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico de episódio depressivo maior é realizado quando são atendidos todos os critérios de A a C citados a seguir:

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A. Cinco (ou mais) dos seguintes sintomas estiveram presentes durante o mesmo período de duas semanas e representam uma mudança em relação ao funcionamento anterior. Além disso, pelo menos um dos sintomas é (1) humor deprimido ou (2) perda de interesse ou prazer.  
<u>Nota: Não incluir sintomas que sejam claramente atribuíveis a outra condição</u>  
clínica.  
1. Humor deprimido na maior parte do dia, quase todos os dias, conforme indicado por relato subjetivo (p. ex., sente-se triste, vazio ou sem esperança) ou por observação feita por outra pessoa (p. ex., parece choroso);  
2. Acentuada diminuição de interesse ou prazer em todas, ou quase todas, as atividades na maior parte do dia, quase todos os dias (conforme indicado por relato subjetivo ou observação feita por outra pessoa);  
3. Perda ou ganho significativo de peso sem fazer dieta (p. ex., variação maior que 5% do peso corporal em um mês) ou redução ou aumento do apetite quase todos os dias;  
4. Insônia ou hipersonia quase diária;  
5. Agitação ou retardo psicomotor quase todos os dias (observável por outras pessoas; não podem ser sensações meramente subjetivas de inquietação ou lentidão);  
6. Fadiga ou perda de energia quase todos os dias;  
7. Sentimentos de inutilidade ou culpa excessiva ou inapropriada (que podem ser delirantes) quase todos os dias (não pode ser meramente autorrecriminação ou culpa por estar doente);  
8. Capacidade diminuída de pensar ou se concentrar, ou indecisão quase todos os dias (por relato subjetivo ou observação feita por outra pessoa);  
9. Pensamentos recorrentes de morte (não somente medo de morrer), ideação suicida recorrente sem um plano específico, tentativa de suicídio ou plano específico para cometer suicídio.  
B. Os sintomas causam sofrimento clinicamente significativo ou prejuízo no funcionamento social ou profissional, ou em outras áreas importantes da vida do indivíduo.  
C. O episódio não é atribuível aos efeitos fisiológicos de uma substância ou a outra condição clínica.  
Os critérios A-C representam um episódio depressivo maior. Esse tipo de episódio é comum no TAB do tipo I, embora sua ocorrência não seja necessária para o diagnóstico desse transtorno.  
Respostas a uma perda significativa (p. ex., luto, ruína financeira, perdas por desastre natural, doença grave ou incapacidade) podem incluir sentimento intenso de tristeza, ruminação acerca da perda, insônia, falta de apetite e perda de peso, sintomas observados no critério A e que podem se assemelhar a um episódio depressivo. Embora tais sintomas possam ser entendidos ou considerados apropriados à perda, a presença de um episódio depressivo maior, além da resposta normal a uma perda significativa, deve ser também cuidadosamente considerada. Essa decisão exige inevitavelmente exercício do juízo clínico, baseado na história do indivíduo e nas normas culturais para a expressão de sofrimento quando de uma perda.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A. Foram atendidos os critérios para pelo menos um episódio maníaco (critérios A-D descritos no sub-item 4.1) em associação ou não a um episódio depressivo maior (sub-item 4.2)  
B. A ocorrência do(s) episódio(s) maníaco(s) e depressivo(s) maior(es) não é mais bem explicada por transtorno esquizoafetivo, esquizofrenia, transtorno esquizofreniforme, transtorno delirante, transtorno do espectro da esquizofrenia ou outro transtorno psicótico com outras especificações ou não especificado.  
<u>Observação: Não há necessidade do diagnóstico de um episódio depressivo</u> maior para o diagnóstico de TAB do tipo I.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O código de diagnóstico para o TAB do tipo I baseia-se no tipo de episódio atual ou mais recente e em sua condição quanto à gravidade atual, presença de características psicóticas e estado de remissão. A gravidade atual e as características psicóticas só são indicadas se todos os critérios estiverem atualmente presentes para episódio maníaco ou depressivo maior. Os especificadores de remissão são indicados somente se todos os critérios não estão atualmente presentes para episódio maníaco, hipomaníaco ou depressivo maior. Para fins deste Protocolo, o registro do diagnóstico deve seguir a CID-10, conforme especificado no item 3.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Pacientes com risco de suicídio agudo, agitação psicomotora, auto- ou heteroagressividade, risco de exposição moral ou sintomas psicóticos devem ser encaminhados para o Serviço de Emergência Psiquiátrica.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão incluídos neste Protocolo os pacientes que apresentarem os critérios de diagnóstico de TAB do tipo I, conforme especificado no item 4.  
No caso de paciente em internação psiquiátrica hospitalar ou com grave prejuízo funcional, que exige institucionalização ou perda da autonomia, é necessária a presença de um familiar ou responsável legal. No caso de paciente cronicamente asilado, é requerida a presença de um funcionário da instituição disponível e capaz de manejar estressores do ambiente de forma contínua.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão excluídos deste Protocolo os pacientes com diagnóstico de TAB e impossibilidade de adesão ao tratamento e acompanhamento contínuo. Também serão excluídos pacientes com diagnóstico de TAB do tipo II e TAB sem outra especificação.  
Devem ser observados as contraindicações e o risco-benefício dos diferentes medicamentos. Cabe ressaltar que as contraindicações absolutas excluem o paciente do uso do medicamento, enquanto as relativas devem ter o risco-benefício avaliado pela equipe assistente.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: insuficiência renal grave, bradicardia sinusal,</u> arritmias ventriculares graves, insuficiência cardíaca congestiva, hipersensibilidade ao fármaco.  
<u>Contraindicações relativas: hipotireoidismo, gravidez.</u>

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: insuficiência hepática grave, hipersensibilidade ao</u> fármaco, doenças do ciclo da ureia, gravidez (é teratogênico).  
<u>Contraindicações relativas: hepatopatia leve.</u>

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: doenças de origem hematopoética, insuficiência</u> hepática, histórico de agranulocitose, histórico de alergia a carbamazepina, mulheres no primeiro trimestre de gravidez, hipersensibilidade ao fármaco.  
<u>Contraindicações relativas: doenças cardiovasculares, glaucoma, retenção</u> urinária.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: hipersensibilidade ao fármaco, indivíduos com</u> prejuízo de função hepática [elevação de aminotransferases/transaminases (AST/TGO e ALT/TGP), história de doença hepática, entre outros].  
<u>Contraindicações relativas: Não há.</u>  
RISPERIDONA  
<u>Contraindicações absolutas:</u> hipersensibilidade ao fármaco, síndrome neuroléptica maligna, discinesia tardia.  
<u>Contraindicações relativas:</u> prolongamento do intervalo QT no eletrocardiograma, doença cardiovascular ou cerebrovascular que predisponham à hipotensão ortostática, hipotermia ou hipertermia, diagnóstico prévio de câncer de mama ou tumor dependente de prolactina, insuficiência renal, insuficiência hepática, doença de Parkinson, história de convulsão ou epilepsia, história de tumor cerebral, gravidez ou situação potencial de gravidez ou lactação, hiperprolactinemia.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: hipersensibilidade ao fármaco.</u>  
<u>Contraindicações relativas: obesidade, cintura maior que 94 cm, hipertensão</u> arterial sistêmica, dislipidemia, diabete mélito ou resistência insulínica (síndrome metabólica), pacientes que têm ou tiveram câncer de mama, doenças cardiovasculares, doenças cerebrovasculares, condições que predisponham à hipotensão (desidratação e hipovolemia), insuficiência hepática ou renal, hipotireoidismo, história de convulsões, catarata, doença de

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Parkinson com falência autonômica periférica.  
OLANZAPINA  
<u>Contraindicações absolutas: hipersensibilidade ao fármaco.</u>  
<u>Contraindicações relativas: obesidade, cintura maior que 94 cm, hipertensão</u> arterial sistêmica, dislipidemia, diabete mélito ou resistência insulínica (síndrome metabólica), pacientes que têm ou tiveram tumor cerebral ou câncer de mama, epilepsia ou condições que diminuam o limiar convulsivante, glaucoma, pacientes que têm ou tiveram íleo paralítico, hiperplasia prostática, doenças cardíacas ou cerebrovasculares, condições que predisponham à hipotensão, risco de pneumonia de aspiração, história de síndrome neuroléptica maligna, gravidez ou situação potencial de gravidez ou lactação, idade inferior a 18 anos.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: leucócitos abaixo de 3.550/mm</u><sup>3</sup> ou neutrófilos abaixo de 2.000/mm<sup>3</sup> , doenças mieloproliferativas ou uso de agentes mielossupressores, história de agranulocitose/granulocitopenia com clozapina, depressão do sistema nervoso central ou estado comatoso de qualquer natureza, íleo paralítico, história de miocardite por clozapina, doenças hepáticas ou cardíacas graves, hipersensibilidade ao medicamento, epilepsia não controlada.  
<u>Contraindicações relativas: diagnóstico prévio de epilepsia, doenças hepáticas</u> ou cardíacas graves; durante a lactação ou em situações em que a gravidez não pode ser adequadamente prevenida, o tratamento deve ser evitado – nesses casos, recomendam-se a avaliação do risco-benefício e a suspensão da lactação se necessário.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: síndrome neuroléptica maligna, discinesia tardia,</u> hipersensibilidade ao fármaco.  
<u>Contraindicações relativas: depressão grave do sistema nervoso central, doença</u> pulmonar obstrutiva crônica, síndrome de Sjögren, transtornos convulsivos, diagnóstico prévio de câncer de mama ou tumor dependente de prolactina, bexiga neurogênica, hipertrofia de próstata, gravidez e amamentação, doença de Parkinson.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Contraindicações absolutas: hipersensibilidade ao fármaco.</u>  
<u>Contraindicações relativas: história prévia de virada maníaca induzida por</u> antidepressivo, em especial em caso de vigência de uso de estabilizador de humor ou antipsicótico.  
<u>Nota: Mulheres em idade fértil devem ser esclarecidas quanto aos riscos para a</u> gestação associados aos medicamentos prescritos e à necessidade de uso regular de métodos contraceptivos. Em caso de dúvida, sugere-se fazer teste de gravidez antes do início do tratamento.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O TAB é uma doença crônica caracterizada por episódios de agudização e períodos de remissão. De forma geral, seu tratamento requer um planejamento de longo prazo. No entanto, antes de se estabelecer uma conduta de longo prazo, o primeiro passo é o tratamento medicamentoso de um episódio agudo (maníaco ou depressivo), com o objetivo de se atingir a remissão dos sintomas de humor. O segundo passo envolve o tratamento de manutenção, com a finalidade de prevenir a recorrência de novos episódios (15).  
A farmacoterapia ainda é a principal modalidade terapêutica. Porém, uma boa aliança terapêutica, com a formação do vínculo equipe de saúde-paciente, é essencial para manter o paciente engajado no tratamento, evitando um dos principais fatores de deterioração, que é o abandono do tratamento. De forma geral, abordagens psicológicas são baseadas na evidência de que estressores psicossociais estão associados com recorrência e piora sintomática (15).  
Existe evidência clínica significativa de eficácia e segurança para o uso da eletroconvulsoterapia (ECT) no tratamento do TAB, porém sem base em estudos comparativos.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Certos princípios gerais devem ser seguidos no tratamento do episódio maníaco. O paciente deve ser imediatamente avaliado quanto ao risco de comportamento agressivo, suicídio, grau de _insight_ (discernimento quanto ao seu transtorno) e capacidade de aderir ao tratamento. Uma avaliação clínica deve ser realizada para analisar a possibilidade de mania

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
secundária a uma condição clínica geral (ex: distúrbio tireoidiano, esclerose múltipla, HIV, lesões corticais e subcorticais ) ou uso de substâncias (drogas ilícitas, medicamentos como L- dopa e corticosteroides). Antidepressivos, assim como outros medicamentos que podem estar precipitando sintomas maníacos, devem ser suspensos (15).  
Considerando-se que o carbonato de lítio é o medicamento mais bem validado no tratamento do TAB, tanto no tratamento de episódios agudos de humor como na prevenção de novos episódios, além de ser o único que demonstra redução de suicidalidade e mortalidade para todas as causas em pacientes com transtornos de humor (19, 20), seu uso é recomendado como primeira escolha entre as opções de estabilizadores de humor.  
A olanzapina, a quetiapina, a risperidona, o aripiprazol e a ziprasidona são efetivos na redução dos sintomas maníacos (21, 22). Entre os demais antipsicóticos, o único que se mostrou eficaz e bem tolerado é o haloperidol (23-25). Uma meta-análise que comparou múltiplas monoterapias no tratamento da mania concluiu que o medicamento com melhor combinação de eficácia e tolerabilidade é a risperidona, seguida por olanzapina, haloperidol e quetiapina (26). Portanto, a risperidona é recomendada como primeira escolha entre as opções de antipsicóticos. Outros antipsicóticos mais recentes que também apresentam evidência de eficácia no tratamento da mania, como o aripiprazol, a ziprasidona, a asenapina e a paliperidona, não foram incluídos neste Protocolo por não terem apresentado superioridade em relação à eficácia (26) e terem custo mais elevado em relação a outros medicamentos até o momento.  
No entanto, a conduta terapêutica medicamentosa mais eficaz para a mania é a associação de um estabilizador de humor [carbonato de lítio, ácido valproico ou carbamazepina (27-30)] com um antipsicótico (31). Essa combinação demonstrou-se mais eficaz do que a monoterapia com um estabilizador de humor (21, 30). Dessa forma, a combinação de carbonato de lítio com risperidona é indicada em nível 1 no tratamento do episódio de mania, devendo-se alterar essa combinação de acordo com a adequação da resposta terapêutica (melhora dos sintomas, conforme avaliação clínica), a tolerabilidade ou a contraindicação ao uso de um determinado fármaco, de acordo com o esquema apresentado no Quadro 1.  
A clozapina é o antipsicótico com melhor evidência de eficácia no tratamento da esquizofrenia refratária, sendo associada à melhora de cognição, funcionalidade e qualidade de vida (32). No transtorno bipolar, no entanto, apenas dois ensaios clínicos randomizados, ambos sem cegamento, mostraram a eficácia desse medicamento. Por outro lado, diferentes revisões concluíram que a clozapina é eficaz e bem tolerada em transtornos de humor graves (33,34,35,36), com reduções significativas de sintomas de humor e taxas de re-hospitalização em estudos observacionais (37-39), sendo, assim, indicada em monoterapia ou em combinação como opção para pacientes com refratariedade a outros medicamentos.  
7.1.1. Diretrizes para o Tratamento do Episódio Maníaco  
- Objetivo primário: remissão de sintomas maníacos.  
- Tempo de tratamento da fase aguda: 8 a 24 semanas.  
- Escolha dos fármacos:  
a) O tratamento do episódio maníaco deve ser feito preferencialmente com a combinação de um estabilizador de humor com um antipsicótico. No entanto, o tratamento em monoterapia tanto com um antipsicótico quanto com um estabilizador pode ser considerado em casos de contraindicações que dificultem essa combinação.  
b) A escolha dos fármacos deve ser feita com base nos níveis de recomendação do Quadro 1; no entanto, deve ser considerado o histórico de resposta prévia aos medicamentos, assim como o perfil de tolerabilidade e as contraindicações de cada fármaco. Dessa forma, os níveis de recomendação não devem ser interpretados como determinação estanque de sequências e combinações de fármacos, mas sim como orientação da preferência de escolha, e sempre deve-se considerar as características clínicas e pessoais de cada paciente. A exceção é a clozapina, que deve ser prescrita apenas após a falha terapêutica de no mínimo duas combinações de estabilizador mais antipsicótico.  
c) Deve-se avaliar a resposta ao tratamento em até 2 semanas, com o tratamento combinado (estabilizador mais antipsicótico) em dose adequada, antes de troca de medicamento. Em caso de ausência de resposta ou intolerância terapêutica, deve ser avaliado qual fármaco que pode ser trocado, sem que necessariamente tenham de ser trocados ambos os fármacos da combinação (por exemplo, em caso de ausência de resposta com a combinação lítio e risperidona, é possível trocar a risperidona pela olanzapina, mantendo o lítio, ou trocar o lítio pelo ácido valproico, mantendo a risperidona, de acordo com o melhor julgamento clínico).  
||Estabilizador|Antipsicótico|
|---|---|---|
|Nível 1|carbonato de lítio|risperidona|
|Nível 2|ácido valproico|olanzapina|
|Nível 3|carbamazepina|haloperidol ouquetiapina|
|Nível 4||clozapina|  
QUADRO 1 - Medicamentos indicados no tratamento do episódio maníaco

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O paciente agudamente maníaco pode apresentar um estado grave de agitação. Antipsicóticos são os medicamentos mais indicados nessa situação. (40,41).A necessidade de controle rápido da agitação e do comportamento agressivo, assim como a capacidade do paciente de cooperar, são fatores que influenciam a escolha do método de administração do medicamento. Sempre que possível, medicamentos por via oral devem ser oferecidos primeiramente, pois evidências sugerem que medicamentos orais podem ser tão eficazes quanto agentes intramusculares (41). Injeções intramusculares oferecem uma alternativa quando a via oral não pode ser utilizada. Deve-se ter cautela no controle da agitação em populações especiais, como em idosos, pacientes em condições clínicas instáveis ou pacientes intoxicados por substâncias. Nesses casos, doses menores, intervalos maiores e monitoração mais rigorosa dos sinais vitais são necessários (40).

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Poucos medicamentos demonstram eficácia e tolerabilidade aceitáveis para os sintomas depressivos do TAB. Apenas o carbonato de lítio, a lamotrigina e a quetiapina são considerados monoterapias de primeira linha (42). Por ser amplamente utilizado na prática clínica e difundido como padrão-ouro para o tratamento do TAB em todas as suas fases (43), o carbonato de lítio é indicado como nível 1 também no tratamento do episódio depressivo bipolar (44,45). O segundo medicamento com melhor nível de evidência é a quetiapina (46,47).  
A lamotrigina é um fármaco antiepilético com comprovada eficácia no tratamento da depressão bipolar e no tratamento de manutenção do TAB (48), e tem sido utilizado no tratamento medicamentoso do TAB para o tratamento da depressão bipolar, da mesma forma que o lítio e a quetiapina (42).  
O uso de antidepressivos – inibidores seletivos de recaptação da serotonina (ISRS), quando em associação a estabilizadores de humor ou antipsicóticos, pode ser efetivo no tratamento da depressão bipolar. No entanto, existem evidências contraditórias, e eles são claramente contraindicados como monoterapia (49). Assim, entre os antidepressivos ISRS, o agente dessa classe recomendado neste Protocolo é a fluoxetina, que deve ser utilizada sempre em combinação com a olanzapina, o carbonato de lítio ou o ácido valproico (49,50).  
7.2.1. Diretrizes para o Tratamento da Depressão Bipolar  
- Objetivo primário: remissão de sintomas depressivos.  
- Tempo de tratamento: 8 a 24 semanas.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
a) O tratamento do episódio depressivo deve ser feito preferencialmente em monoterapia. A associação de fluoxetina com olanzapina, carbonato de lítio ou ácido valproico é preconizada apenas nos casos de refratariedade, contraindicação ou intolerância a lítio, quetiapina e lamotrigina.  
b) A escolha dos fármacos deve ser feita com base nos níveis de recomendação do Quadro 2, mas deve-se considerar a história de resposta prévia aos medicamentos, assim como o perfil de tolerabilidade e as contraindicações de cada fármaco. Dessa forma, os níveis de recomendação não devem ser interpretados como determinação estanque de sequências e combinações de fármacos, mas sim como orientação da preferência de escolha, e sempre devese considerar as características clínicas e pessoais de cada paciente.  
c) A avaliação da resposta clínica, feita pela monitorização da melhora dos sintomas depressivos, deve ser feita em até 4 a 6 semanas, antes da troca por outro fármaco.  
|Nível 1|carbonato de lítio|
|---|---|
|Nível 2|quetiapina|
|Nível 3|lamotrigina|
||olanzapina associada a fluoxetina, carbonato de lítio|
|Nível 4|associado a fluoxetina ou ácido valproico associado a<br>fluoxetina|  
QUADRO 2 - Medicamentos indicados no tratamento do episódio depressivo

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento de manutenção deve ser feito após a melhora dos sintomas dos episódios agudos e é uma continuação direta do tratamento desses episódios. O tempo específico para que o tratamento passe a ser chamado de manutenção varia consideravelmente de paciente para paciente. O objetivo do tratamento de manutenção é a prevenção de novos episódios de humor com o uso de medicamentos em longo prazo. Nessa fase, medicamentos antidepressivos devem ser gradativamente suspensos sempre que possível (51). Idealmente, o tratamento com monoterapia deve ser buscado na manutenção, mas dificilmente é atingido na prática, pois muitos pacientes necessitam de tratamento combinado (43).

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O carbonato de lítio, que permaneceu por mais de duas décadas como o único medicamento aprovado pela _FoodandDrugAdministration_ (FDA) para o tratamento do TAB, ainda é o estabilizador de humor recomendado como primeira escolha no tratamento de manutenção desse transtorno (52,53). No entanto, de forma geral, deve-se manter durante o tratamento de manutenção o medicamento que foi eficaz no tratamento do episódio agudo.  
São medicamentos com comprovada eficácia no tratamento de manutenção: carbonato de lítio (54), ácido valproico (55), lamotrigina, olanzapina (56), quetiapina, risperidona,carbamazepina e clozapina (52,57). Caso o paciente tenha melhorado com o uso de haloperidol, estemedicamento pode ser continuado na fase de manutenção.  
A lamotrigina tem eficácia limitada, pois previne apenas recidivas depressivas, não tendo benefício na prevenção de mania (52); assim, deve sempre estar associada a outro agente com eficácia comprovada na prevenção de episódios maníacos durante o tratamento de manutenção (58,59).  
Assim como no tratamento do episódio maníaco, a clozapina é indicada após a falha terapêutica de no mínimo duas combinações diferentes de estabilizadores de humor e antipsicóticos (36).  
- 7.3.1. Diretrizes para o Tratamento de Manutenção  
- Objetivo primário: prevenção de novos episódios de humor.  
- Tempo de tratamento: não pode ser previamente determinado.  
a) De forma a minimizar efeitos adversos e facilitar a adesão, é prudente reduzir o número de medicamentos sempre que possível na fase de manutenção. No entanto, é importante reconhecer que a monoterapia pode ser insuficiente para a prevenção de novos episódios em muitos pacientes. Na manutenção, a história prévia de estabilidade com o uso de monoterapia com carbonato de lítio ou ácido valproico deve servir como referência na hora de suspender outros medicamentos.  
b) Quanto ao uso de antidepressivos no tratamento de manutenção, exceto no caso de pacientes com história de inúmeras recorrências de episódios depressivos, deve-se sempre procurar reduzir a dose de antidepressivos após 6-8 semanas de remissão dos sintomas e suspender o uso sempre que possível.  
- Escolha dos fármacos: o(s) fármaco(s) utilizado(s) no tratamento de manutenção deve(m) ser o(s) mesmo(s) que apresentou(aram) eficácia no tratamento do episódio agudo. Deve-se ajustar as doses de acordo com a tolerabilidade durante o tratamento de longo prazo.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Após o início do tratamento medicamentoso e da conduta clínica relacionada, o próximo passo envolve reabilitação psicossocial.  A psicoeducação é um aspecto da conduta clínica e da psicoterapia, porém qualquer profissional da saúde pode conduzi-la. Os principais elementos da psicoeducação incluem (60):  
- estimular o paciente a se tornar mais ativo quanto ao seu autocuidado;  
- ensinar aspectos gerais sobre o TAB;  
- discutir sinais precoces de recaída e medidas a serem tomadas nessa situação;  
- melhorar a adesão ao tratamento e mostrar como lidar com efeitos indesejados dos medicamentos; e  
- ensinar técnicas de controle do estresse, incluindo atenção à regulação do sono, e evitar uso de substâncias de abuso.  
O envolvimento da família ou de amigos próximos na psicoeducação pode ser de grande ajuda, particularmente na discussão sobre medidas a serem tomadas em caso de recaída (61).  
Condutas psicoterápicas eficientes em caso de TAB (terapia focada na família, terapia cognitivo-comportamental, terapia interpessoal e terapia de ritmos sociais) devem ser encorajadas não só nos episódios depressivos, mas em todas as fases. Tais intervenções, quando associadas ao tratamento medicamentoso, tendem a melhorar as taxas de remissão do TAB (62).

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Carbonato de lítio: comprimidos de 300 mg.  
Ácido valproico: comprimidos de 250 e 500 mg, xarope e solução oral de 50  
mg/mL.  
Carbamazepina: comprimidos de 200 e 400 mg, suspensão oral de 20 mg/mL.  
Lamotrigina: comprimidos de 25, 50 e 100 mg.  
Risperidona: comprimidos de 1, 2 e 3 mg.  
Olanzapina: comprimidos de 5 e 10 mg.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Haloperidol: comprimidos de 1 e 5 mg, solução injetável de 5 mg/mL e solução  
oral de 2 g/mL.  
Quetiapina: comprimidos de 25, 100, 200 e 300 mg.  
Clozapina: comprimidos de 25 e 100 mg.  
Fluoxetina: comprimidos de 20 mg.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<u>Carbonato de lítio</u>  
- Dose inicial: 300 mg/dia.  
- Faixa de dose: 300-1.800 mg/dia (de acordo com o nível sérico), dose única à  
noite.  
Incremento de 300 mg a cada 2 dias até chegar a 900 mg. Dosar nível sérico.  
- Dose máxima: 1.800 mg/dia, com ajuste de dose de acordo com o nível sérico (nível sérico terapêutico: 0,6-1,2 mEq/L).  
<u>Nota: O nível sérico deve ser dosado com uso contínuo de dose estável do</u> estabilizador por pelo menos 5-7 dias e intervalo de 12 horas da última administração até o horário da coleta de sangue.  
<u>Ácido valproico</u>  
- Dose inicial: 250 mg/dia.  
- Faixa de dose: 250-2.000 mg/dia (de acordo com o nível sérico), dose única à  
noite.  
Incremento de 250 mg a cada 2 dias até chegar a 750 mg. Dosar nível sérico.  
- Dose máxima: 2.000 mg/dia, com ajuste de dose de acordo com o nível sérico (nível sérico terapêutico: 50-125 mcg/mL).  
<u>Nota: O nível sérico deve ser dosado com uso contínuo de dose estável do</u> estabilizador por pelo menos 5-7 dias e intervalo de 12 horas da última administração até o horário da coleta de sangue.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 200 mg/dia.  
- Faixa de dose: 200-1.000 mg/dia (de acordo com o nível sérico), dose única à  
noite.  
Incremento de 200 mg a cada 2 dias até chegar a 600 mg. Dosar nível sérico.  
- Dose máxima: 1.000 mg/dia, com ajuste de dose de acordo com o nível sérico (nível sérico terapêutico: 8-12 mcg/mL).  
<u>Nota: O nível sérico deve ser dosado com uso contínuo de dose estável do</u> estabilizador por pelo menos 5-7 dias e intervalo de 12 horas da última administração até o horário da coleta de sangue.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 25 mg/dia.  
- Faixa de dose: 25-200 mg/dia, dose única à noite.  
Incremento de 25 mg/dia a cada 2 semanas nas primeiras 4 semanas, aumentando para 100 mg/dia na quinta semana. Após, a dose pode ser aumentada em, no máximo, 100 mg/semana até ser atingida a dose-alvo (100-200 mg/dia).  
- Dose máxima: 300 mg/dia.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 1 mg/dia.  
- Faixa de dose: 1-6 mg/dia, dose única à noite.  
Incremento de 1 mg/dia até chegar à dose-alvo.  
- Dose máxima: 8 mg/dia.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 5 mg/dia.  
- Faixa de dose: 5-20 mg/dia, dose única à noite.  
Incremento de 5 mg/dia até chegar à dose-alvo.  
- Dose máxima: 20 mg/dia.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 25 mg/dia.  
- Faixa de dose: na depressão, a dose é de 300-600 mg/dia. Na mania, a dose utilizada é de 600-800 mg/dia. Dose única à noite. Incremento de 25 a 50 mg por dose por dia, com o objetivo de alcançar a dose-alvo. Incrementos maiores são possíveis de acordo com a tolerância individual do paciente.  
- Dose máxima: 800 mg/dia.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Dose inicial: 25 mg/dia.  
- Faixa de dose: 300-400 mg/dia. Dose única à noite – doses acima de 400 mg devem ser fracionadas de 12/12 horas.  
Incremento de 25 mg a cada 1-2 dias até atingir 300-400 mg/dia.  
- Dose máxima: 800 mg/dia.  
<u>Fluoxetina</u>  
- Dose inicial: 20 mg/dia.  
- Faixa de dose: 20-40 mg, dose única pela manhã.  
Incremento de 20 mg a cada 1-2 semanas de acordo com resposta/tolerabilidade.  
- Dose máxima: 80 mg/dia.  
<u>Nota: A dose-alvo é determinada no início do tratamento pelo médico assistente</u> com base no perfil de tolerabilidade e na gravidade dos sintomas de cada paciente.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tempo de tratamento de manutenção do TAB não pode ser previamente determinado, devendo em princípio ser mantido de forma contínua (15).  
De forma a minimizar efeitos adversos e facilitar a adesão ao tratamento, é prudente reduzir o número de medicamentos sempre que possível na fase de manutenção. No entanto, é importante reconhecer que a monoterapia pode ser insuficiente para a prevenção de

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
novos episódios em muitos pacientes. A história prévia de estabilidade com o uso de monoterapia com carbonato de lítio ou ácido valproico deve servir como referência na hora de suspender outros medicamentos (15).  
Quanto ao uso de antidepressivos no tratamento de manutenção, exceto em pacientes com história de inúmeras recorrências de episódios depressivos, deve-se sempre procurar reduzir a dose de antidepressivos após 6-8 semanas de remissão dos sintomas e descontinuar o uso sempre que possível (63).

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Melhora dos sintomas de humor (mania ou depressão) com o tratamento agudo e prevenção de novos episódios de humor com o tratamento de manutenção.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Antes do início do tratamento com qualquer um dos medicamentos, é obrigatória a avaliação médica, com o objetivo de descartar possíveis contraindicações e monitorar potenciais efeitos adversos, dos seguintes aspectos (64):  
- idade, medidas antropométricas (peso, altura, circunferência abdominal e do quadril), três medidas de pressão arterial em datas diferentes, exames sanguíneos de colesterol total e frações, triglicerídeos, glicemia de jejum, hemograma.  
- história familiar ou prévia de síndrome neuroléptica maligna (no caso de antipsicóticos), suicídio, obesidade, hipertensão arterial sistêmica, diabete mélito e outras comorbidades.  
Antes do início do tratamento com carbonato de lítio, também é necessária a avaliação de hormônio tireotrófico (TSH), creatinina e ureia séricos. A conduta em caso de alteração dos exames é determinada pelo médico assistente com base na natureza e no grau da alteração, e deve-se considerar as características individuais de cada caso. Todo medicamento deve ser administrado com cautela em mulheres com potencial de engravidar, e os potenciais riscos gestacionais de cada medicamento devem ser discutidos com a paciente.  
Antes do início do tratamento com ácido valproico, também é necessária a avaliação da função hepática. Antes do início do tratamento com carbamazepina, deve ser feita avaliação da função hepática [ALT/TGP, AST/TGO, creatinina, ureia e eletrólitos (sódio e potássio)]. A conduta em caso de alteração dos exames é determinada com base na natureza e no grau da alteração, e deve-se considerar as características individuais de cada caso  
Para monitorização dos efeitos adversos, devem ser repetidas as medidas

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|antropométr<br>repetidos de<br>ser feita e o<br>relevância cl<br>possibilidad<br>TA<br>|icas e de pressão arterial e<br>acordo com a Tabela 1. E<br>risco-benefício deverá ser<br>ínica da alteração e o bene<br>es de substituição disponív<br>BELA 1 - Frequência de e<br>|m 3, 6 e 12 meses.<br>m caso de alteraçõe<br>discutido com o pac<br>fício clínico obtido c<br>eis.<br>xames laboratoriais<br>|Os exames laborato<br>s, uma avaliação clíni<br>iente, e deve-se consi<br>om o uso do medica<br>|riais devem ser<br>ca geral deverá<br>derar o grau e a<br>mento, além das<br>|
|---|---|---|---|---|
|Medicamento<br>|Mensal<br>|Trimestral<br>|Semestral<br>|Anual<br>|
|Lítio<br>||Creatinina e<br>uréia.<br>|TSH, cálcio sérico,<br>litemia.<br>||
|Ácido valproico<br>||Hemograma,<br>função hepática<br>(ALT/TGP,<br>AST/TGO).<br>|Ácido valproico<br>sérico.<br>||
|Carbamazepina<br>|Hemograma, função<br>hepática (ALT/TGP,<br>AST/TGO) creatinina,<br>ureia e eletrólitos (sódio<br>e potássio) nos 3<br>primeiros meses.<br>||Carbamazepina<br>sérica.<br>|Hemograma, função<br>hepática (ALT/TGP,<br>AST/TGO)<br>creatinina, ureia e<br>eletrólitos (sódio e<br>potássio).<br>|
|Lamotrigina<br>||||Hemograma, função<br>hepática (ALT/TGP,<br>AST/TGO).<br>|
|Antipsicóticos*<br>primeiras se<br>uso do medi|Adaptado de Ng et al.<br>* A clozapina exige<br>manas de tratamento; após,<br>camento.|Glicemia de<br>jejum e perfil<br>lipídico<br>(primeiro ano).<br>Bipolar Disord 2009<br>a realização de h<br>deve ser realizado<br>|(64).<br>emograma semanal<br>hemograma mensal e<br>|Glicemia de jejum,<br>perfil lipídico e<br>eletrocardiograma.<br>Prolactina quando<br>clinicamente<br>indicada.**<br>durante as 18<br>nquanto durar o<br>|  
** A dosagem do nível sérico de prolactina deverá ser solicitada sempre que houver relato de sintomas compatíveis com alterações hormonais, como diminuição da libido, alterações menstruais, impotência e galactorreia.  
Devem ser observados os efeitos adversos de acordo com o medicamento  
utilizado:

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: náusea, vômitos, dor epigástrica, boca seca, gosto metálico, diarreia, ganho de peso, tremores finos, cansaço, cefaleia, hipotireoidismo e exacerbação da psoríase e acne.  
O risco de toxicidade aumenta consideravelmente com nível sérico acima de 1,5 mEq/L. Sintomas de toxicidade do lítio incluem perda de equilíbrio, diarreia profusa, vômitos, anorexia, fraqueza, ataxia, visão borrada, zumbido, poliúria, tremor grosseiro, contrações musculares, irritabilidade e agitação. Sonolência, psicose, desorientação, convulsões, coma e insuficiência renal também podem ocorrer em casos mais graves de intoxicação, sendo que litemia acima de 3,5 mEq/L é potencialmente fatal.  
É importante lembrar que o nível sérico pode ser afetado por outros medicamentos (diuréticos, inibidores da enzima conversora da angiotensina, anti-inflamatórios não esteroidais), devendo-se evitar essas associações, assim como condições que alterem a função renal.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: náusea, vômitos, cólicas abdominais, anorexia, diarreia, indigestão, aumento do apetite, ganho de peso, sedação, tremores, queda de cabelo, trombocitopenia, elevação das ALT/TGP e AST/TGO.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: boca seca, vômitos, anorexia, constipação, dor abdominal, tonturas, cefaleia, ataxia, sonolência, visão borrada, _rash_ cutâneo.  
Efeitos adversos raros: anemia aplástica, agranulocitose, síndrome de secreção inapropriada de hormônio antidiurético, arritmias, hepatite.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Pode afetar outros fármacos metabolizados via citocromo P450 (antidepressivos, anticonvulsivantes, risperidona, haloperidol).  
A carbamazepina reduz o nível sérico da maioria dos antipsicóticos, por isso deve-se atentar para o ajuste de dose quando usada em combinação.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: boca seca, náusea, vômitos, diplopia, tonturas, ataxia, visão borrada, cefaleia, irritabilidade, sonolência, tremores, astenia, insônia, _rash_ maculopapular, artralgia. Para prevenir reações de pele, deve-se iniciar com dose baixa e aumentá-la lentamente.  
Efeitos adversos raros: insuficiência hepática, discrasias sanguíneas, síndrome de Stevens-Johnson.  
A associação de lamotrigina com ácido valproico aumenta muito o risco de _rash_ cutâneo e síndrome de Stevens-Johnson, devendo em princípio ser evitada. No entanto, se a combinação for necessária, após a introdução da lamotrigina, o aumento de dose deve ser realizado de forma mais gradual.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: sonolência, aumento do apetite, fadiga, sialorreia, constipação, xerostomia, tremor, distonia, vertigem, efeitos extrapiramidais (acinesia, acatisia, discinesia, distonia, rigidez muscular, bradicinesia, tremor em repouso e instabilidade postural).

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: tontura, sonolência, boca seca, elevação dos níveis de triglicerídeos séricos, elevação do colesterol total, aumento de peso, constipação, hipotensão.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: aumento de peso, aumento transitório assintomático das ALT/TGP e AST/TGO, sedação, sonolência.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: sialorreia, sonolência, tontura, ganho de peso, taquicardia, constipação intestinal.  
Deve ser realizado hemograma completo a intervalos semanais e a cada aumento de dose nas primeiras 18 semanas de tratamento e a intervalos mensais ao longo de todo o tempo de tratamento.  
Para os pacientes que apresentarem citopenia, caracterizada por leucopenia (leucócitos totais abaixo de 3.000/mm3 ou neutrófilos abaixo de 1.500/mm<sup>3</sup> ) ou por plaquetopenia (contagem de plaquetas inferior a 100.000/mm<sup>3</sup> ), o medicamento deve ser suspenso, e tanto a inclusão no Protocolo quanto a continuidade do tratamento deverão ser avaliadas por um hematologista.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: acatisia, distonias, hipertonia, parkinsonismo, efeitos extrapiramidais, sonolência, tremor.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Efeitos adversos: náusea, cefaleia, diminuição do apetite, dor abdominal, insônia, nervosismo, sudorese excessiva.  
Deve-se sempre monitorar sinas de virada maníaca durante o uso de fluoxetina, que se manifesta por diminuição da necessidade de sono, agitação, irritabilidade e elevação do humor.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tempo de tratamento do TAB não pode ser previamente determinado. É recomendada reavaliação clínica mensal, incluindo avaliação de resposta terapêutica, tolerabilidade e adesão ao tratamento.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento e a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso. Devem também ser observadas as condições de boa adesão e acompanhamento contínuo apresentadas pelo paciente e seu familiar (ou responsável legal).  
Considerando as diretrizes nacionais e internacionais para organização da atenção à saúde mental (WHO, 2010), as desigualdades regionais em termos de disponibilidade de profissionais especializados em saúde mental no Brasil, as diretrizes da Rede de Atenção Psicossocial (RAPS) e a complexidade do acompanhamento terapêutico das pessoas com diagnóstico de TAB, é imprescindível a articulação dos diferentes pontos da Rede de Atenção Psicossocial (RAPS) para o cuidado integral a esses usuários do SUS. Nesse sentido, a responsabilidade pelo acolhimento e acompanhamento contínuo de pessoas com TAB deve ser compartilhada entre as equipes de Atenção Básica, os núcleos de Apoio à Saúde da Família (NASF), os serviços estratégicos em saúde mental (Centros de Atenção Psicossocial – CAPS) e outros serviços da RAPS (serviços hospitalares de referência com leitos de saúde mental), principalmente devido à necessidade de promover aderência ao tratamento e de acompanhamento clínico e psicossocial contínuo, por equipe multiprofissional, às pessoas que sofrem desse transtorno. As especificidades do cuidado às mulheres em idade fértil com TAB constituem um exemplo claro do quanto é imprescindível o matriciamento para ao tendimento desses casos, pois os efeitos teratogênicos de alguns medicamentos indicados para tratamento do transtorno bipolar, além do elevado risco de complicações perinatais (crises, risco de suicídio, etc.), exigem o envolvimento das equipes responsáveis pela atenção ao pré-natal, parto, saúde reprodutiva e saúde mental especializada, para garantia de um acompanhamento cuidadoso e muito próximo dessas usuárias. Diante disso, apesar de os CAPS constituírem serviços de referência para a atenção a transtornos mentais graves, como o TAB, por disporem de equipes especializadas de médicos e outros profissionais de saúde mental, é imprescindível a articulação de todos os serviços da rede de atenção para o cuidado efetivo às pessoas com esse e outros transtornos mentais.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1. Calabrese JR, Hirschfeld RM, Reed M, Davies MA, Frye MA, Keck PE, et al. Impact of bipolar disorder on a U.S. community sample. J Clin Psychiatry. 2003;64(4):425-32.  
2. Phillips ML, Kupfer DJ. Bipolar disorder diagnosis: challenges and future directions. Lancet. 2013;381(9878):1663-71.  
3. Judd LL, Akiskal HS. The prevalence and disability of bipolar spectrum disorders in the US population: re-analysis of the ECA database taking into account subthreshold cases. J Affect Disord. 2003;73(1-2):123-31.  
4. Collins PY, Patel V, Joestl SS, March D, Insel TR, Daar AS, et al. Grand challenges in global mental health. Nature. 2011;475(7354):27-30.  
5. Whiteford HA, Degenhardt L, Rehm J, Baxter AJ, Ferrari AJ, Erskine HE, et al. Global burden of disease attributable to mental and substance use disorders: findings from the Global Burden of Disease Study 2010. Lancet. 2013;382(9904):157586.  
6. Weissman MM, Bland RC, Canino GJ, Faravelli C, Greenwald S, Hwu HG, et al. Cross-national epidemiology of major depression and bipolar disorder. Jama. 1996;276(4):293-9.  
7. Hirschfeld RM, Calabrese JR, Weissman MM, Reed M, Davies MA, Frye MA, et al. Screening for bipolar disorder in the community. J Clin Psychiatry. 2003;64(1):53-9.  
8. Regeer EJ, ten Have M, Rosso ML, Hakkaart-van Roijen L, Vollebergh W, Nolen WA. Prevalence of bipolar disorder in the general population: a Reappraisal Study of the Netherlands Mental Health Survey and Incidence Study. ActaPsychiatr Scand. 2004;110(5):374-82.  
9. Moreno DH, Andrade LH. The lifetime prevalence, health services utilization and risk of suicide of bipolar spectrum subjects, including subthreshold categories in the São Paulo ECA study. J Affect Disord. 2005;87(2-3):231-41.  
10. Clemente AS, Diniz BS, Nicolato R, Kapczinski FP, Soares JC, Firmo JO, et al. Bipolar disorder prevalence: a systematic review and meta-analysis of the literature. RevBras Psiquiatr. 2015;37(2):155-61.  
11. Gonda X, Pompili M, Serafini G, Montebovi F, Campi S, Dome P, et al. Suicidal behavior in bipolar disorder: epidemiology, characteristics and major risk factors. J Affect Disord. 2012;143(1-3):16-26.  
12. Pompili M, Gonda X, Serafini G, Innamorati M, Sher L, Amore M, et al. Epidemiology of suicide in bipolar disorders: a systematic review of the literature. Bipolar Disord. 2013;15(5):457-90.  
13. Goodwin FK, Fireman B, Simon GE, Hunkeler EM, Lee J, Revicki D. Suicide risk in bipolar disorder during treatment with lithium and divalproex. JAMA. 2003;290(11):1467-73.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
14. Baldessarini RJ, Tondo L, Hennen J. Treating the suicidal patient with bipolar disorder. Reducing suicide risk with lithium. Ann N Y Acad Sci. 2001;932:24-38; discussion 39-43.  
15. Yatham LN, Kennedy SH, O'Donovan C, Parikh S, MacQueen G, McIntyre R, et al. Canadian Network for Mood and Anxiety Treatments (CANMAT) guidelines for the management of patients with bipolar disorder: consensus and controversies. Bipolar Disord. 2005;7 Suppl 3:5-69.  
16. Kapczinski F, Dias VV, Kauer-Sant'Anna M, Frey BN, GrassiOliveira R, Colom F, et al. Clinical implications of a staging model for bipolar disorders. Expert Rev Neurother. 2009;9(7):957-66.  
17. Kapczinski F, Vieta E, Andreazza AC, Frey BN, Gomes FA, Tramontina J, et al. Allostatic load in bipolar disorder: implications for pathophysiology and treatment. NeurosciBiobehav Rev. 2008;32(4):675-92.  
18. American PsychiatricAssociation (APA). DSM-5: Manual Diagnóstico e Estatístico de Transtornos Mentais. 5a ed. Porto Alegre: Artmed; 2014.  
19. Cipriani A, Hawton K, Stockton S, Geddes JR. Lithium in the prevention of suicide in mood disorders: updated systematic review and meta-analysis. BMJ. 2013;346:f3646.  
20. Cipriani A, Pretty H, Hawton K, Geddes JR. Lithium in the prevention of suicidal behavior and all-cause mortality in patients with mood disorders: a systematic review of randomized trials. Am J Psychiatry. 2005;162(10):1805-19.  
21. Perlis RH, Welge JA, Vornik LA, Hirschfeld RM, Keck PE Jr. Atypical antipsychotics in the treatment of mania: a meta-analysis of randomized, placebo-controlled trials. J Clin Psychiatry. 2006;67(4):509-16.  
22. Brown R, Taylor MJ, Geddes J. Aripiprazole alone or in combination for acute mania. Cochrane Database Syst Rev. 2013;12:CD005000.  
23. Scherk H, Pajonk FG, Leucht S. Second-generation antipsychotic agents in the treatment of acute mania: a systematic review and meta-analysis of randomized controlled trials. Arch Gen Psychiatry. 2007;64(4):442-55.  
24. Cipriani A, Rendell JM, Geddes JR. Haloperidol alone or in combination for acute mania. The Cochrane Database Syst Rev. 2006(3):CD004362.  
25. Cavazzoni PA, Berg PH, Kryzhanovskaya LA, Briggs SD, Roddy TE, Tohen M, et al. Comparison of treatment-emergent extrapyramidal symptoms in patients with bipolar mania or schizophrenia during olanzapine clinical trials. J Clin Psychiatry. 2006;67(1):107-13.  
26. Cipriani A, Barbui C, Salanti G, Rendell J, Brown R, Stockton S, et al. Comparative efficacy and acceptability of antimanic drugs in acute mania: a multiple-treatments meta-analysis. Lancet. 2011;378(9799):1306-15.  
27. Allen MH, Hirschfeld RM, Wozniak PJ, Baker JD, Bowden CL. Linear relationship of valproate serum concentration to response and optimal serum levels for acute mania. Am J Psychiatry. 2006;163(2):272-5.  
28. Weisler RH, Hirschfeld R, Cutler AJ, Gazda T, Ketter TA, Keck PE, et al. Extended-release carbamazepine capsules as monotherapy in bipolar disorder:  
pooled results from two randomised, double-blind, placebo-controlled trials. CNS Drugs. 2006;20(3):219-31.  
29. Rosa AR, Fountoulakis K, Siamouli M, Gonda X, Vieta E. Is anticonvulsant treatment of mania a class effect? Data from randomized clinical trials. CNS NeurosciTher. 2011;17(3):167-77.  
30. Smith LA, Cornelius V, Warnock A, Tacchi MJ, Taylor D. Acute bipolar mania: a systematic review and meta-analysis of co-therapy vs. monotherapy. ActaPsychiatr Scand. 2007;115(1):12-20.  
31. Rendell JM, Gijsman HJ, Bauer MS, Goodwin GM, Geddes GR. Risperidone alone or in combination for acute mania. Cochrane Database Syst Rev. 2006(1):CD004043.  
32. Meltzer HY. Clozapine: balancing safety with superior antipsychotic efficacy. ClinSchizophrRelat Psychoses. 2012;6(3):134-44.  
33. Zarate CA Jr, Tohen M, Banov MD, Weiss MK, Cole JO. Is clozapine a mood stabilizer? J Clin Psychiatry. 1995;56(3):108-12.  
34. Frye MA, Ketter TA, Altshuler LL, Denicoff K, Dunn RT, Kimbrell TA, et al. Clozapine in bipolar disorder: treatment implications for other atypical antipsychotics. J Affect Disord. 1998;48(2-3):91-104.  
35. Li XB, Tang YL, Wang CY, de Leon J. Clozapine for treatmentresistant bipolar  disorder: a systematic review. Bipolar Disord. 2015;17(3):235-47.  
36. Poon SH, Sim K, Sum MY, Kuswanto CN, Baldessarini RJ. Evidence-based options for treatment-resistant adult bipolar disorder patients. Bipolar Disord. 2012;14(6):573-84.  
37. McElroy SL, Dessain EC, Pope HG Jr, Cole JO, Keck PE Jr, Frankenberg FR, et al. Clozapine in the treatment of psychotic mood disorders, schizoaffective disorder, and schizophrenia. J Clin Psychiatry. 1991;52(10):411-4.  
38. Suppes T, McElroy SL, Gilbert J, Dessain EC, Cole JO. Clozapine in the treatment of dysphoric mania. Biol Psychiatry. 1992;32(3):270-80.  
39. Chang JS, Ha KS, Young Lee K, Sik Kim Y, Min Ahn Y. The effects of long-term clozapine add-on therapy on the rehospitalization rate and the mood polarity patterns in bipolar disorders. J Clin Psychiatry. 2006;67(3):461-7.  
40. Alderfer BS, Allen MH. Treatment of agitation in bipolar disorder across the life cycle. J Clin Psychiatry. 2003;64Suppl 4:3-9.  
41. Hughes DH, Kleespies PM. Treating aggression in the psychiatric emergency service. J Clin Psychiatry. 2003;64Suppl 4:10-5.  
42. Yatham LN, Kennedy SH, Parikh SV, Schaffer A, Beaulieu S, Alda M, et al. Canadian Network for Mood and Anxiety Treatments (CANMAT) and International Society for Bipolar Disorders (ISBD) collaborative update of CANMAT guidelines for the management of patients with bipolar disorder: update 2013. Bipolar Disord. 2013;15(1):1-44.  
43. Malhi GS, Adams D, Berk M. The pharmacological treatment of bipolar disorder in primary care. Med J Aust. 2010;193(4):S24-30.  
44. Van Lieshout RJ, MacQueen GM. Efficacy and acceptability of mood stabilisers in the treatment of acute bipolar depression: systematic review. Br JPsychiatry. 2010;196(4):266-73.  
45. Vieta E, Locklear J, Günther O, Ekman M, Miltenburger C, Chatterton ML, et al. Treatment options for bipolar depression: a systematic review of randomized, controlled trials. J ClinPsychopharmacol. 2010;30(5):579-90.  
46. Chiesa A, Chierzi F, De Ronchi D, Serretti A. Quetiapine for bipolar depression: a systematic review and meta-analysis. IntClinPsychopharmacol. 2012;27(2):76-90.  
47. Cruz N, Sanchez-Moreno J, Torres F, Goikolea JM, Valentí M, Vieta E. Efficacy of modern antipsychotics in placebo-controlled trials in bipolar depression: a meta-analysis. Int J Neuropsychopharmacol. 2010;13(1):5-14.  
48. Calabrese JR, Huffman RF, White RL, Edwards S, Thompson TR, Ascher JA, et al. Lamotrigine in the acute treatment of bipolar depression: results of five double-blind, placebo-controlled clinical trials. Bipolar Disord. 2008;10(2):323-33.  
49. Vázquez GH, Tondo L, Undurraga J, Baldessarini RJ. Overview of antidepressant treatment of bipolar depression. Int J Neuropsychopharmacol. 2013;16(7):1673-85.  
50. Sidor MM, Macqueen GM. Antidepressants for the acute treatment of bipolar depression: a systematic review and meta-analysis. J Clin Psychiatry. 2011;72(2):156-67.  
51. Ghaemi SN, Wingo AP, Filkowski MA, Baldessarini RJ. Long-term antidepressant treatment in bipolar disorder: meta-analyses of benefits and risks. ActaPsychiatr Scand. 2008;118(5):347-56.  
52. Smith LA, Cornelius V, Warnock A, Bell A, Young AH. Effectiveness of mood stabilizers and antipsychotics in the maintenance phase of bipolar disorder: a systematic review of randomized controlled trials. Bipolar Disord. 2007;9(4):394-412.  
53. Geddes JR, Burgess S, Hawton K, Jamison K, Goodwin GM. Longterm lithium therapy for bipolar disorder: systematic review and meta-analysis of randomized controlled trials. Am J Psychiatry. 2004;161(2):217-22.  
54. Young AH, Hammond JM. Lithium in mood disorders: increasing evidence base, declining use? Br J Psychiatry. 2007;191:474-6.  
55. Cipriani A, Reid K, Young AH, Macritchie K, Geddes J. Valproic acid, valproate and divalproex in the maintenance treatment of bipolar disorder. Cochrane Database Syst Rev. 2013;10:CD003196.  
56. Cipriani A, Rendell J, Geddes JR. Olanzapine in the long-term treatment of bipolar disorder: a systematic review and meta-analysis. JPsychopharmacol. 2010;24(12):1729-38.  
57. Geddes JR, Miklowitz DJ. Treatment of bipolar disorder. Lancet. 2013;381(9878):1672-82.  
58. Vieta E, Günther O, Locklear J, Ekman M, Miltenburger C, Chatterton ML, et al. Effectiveness of psychotropic medications in the maintenance  
phase of bipolar disorder: a meta-analysis of randomized controlled trials. Int J Neuropsychopharmacol. 2011;14(8):1029-49.  
59. Popovic D, Reinares M, Amann B, Salamero M, Vieta E. Number needed to treat analyses of drugs used for maintenance treatment of bipolar disorder. Psychopharmacology (Berl). 2011;213(4):657-67.  
60. Stafford N, Colom F. Purpose and effectiveness of psychoeducation in patients with bipolar disorder in a bipolar clinic setting. ActaPsychiatrScand Suppl. 2013(442):11-8.  
61. Colom F. Keeping therapies simple: psychoeducation in the prevention of relapse in affective disorders. Br J Psychiatry. 2011;198(5):338-40.  
62. Miklowitz DJ, Otto MW, Frank E, Reilly-Harrington NA, Wisniewski SR, Kogan JN, et al. Psychosocial treatments for bipolar depression: a 1- year randomized trial from the Systematic Treatment Enhancement Program. Arch Gen Psychiatry. 2007;64(4):419-26.  
63. Pacchiarotti I, Bond DJ, Baldessarini RJ, Nolen WA, Grunze H, Licht RW, et al. The International Society for Bipolar Disorders (ISBD) task force report on antidepressant use in bipolar disorders. Am J Psychiatry. 2013;170(11):1249-62.  
64. Ng F, Mammen OK, Wilting I, Sachs GS, Ferrier IN, Cassidy F, et al. The International Society for Bipolar Disorders (ISBD) consensus guidelines for the safety monitoring of bipolar disorder treatments. Bipolar Disord. 2009;11(6):559-95.

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
LAMOTRIGINA, RISPERIDONA, QUETIAPINA, OLANZAPINA E CLOZAPINA.  
Eu, _______________________________________________ (nome do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de lamotrigina, risperidona, quetiapina, olanzapina e clozapina, indicadas para o tratamento do transtorno afetivo bipolar do tipo I.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico _____________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber pode(m) trazer os seguintes benefícios:  
- redução dos sintomas e da frequência das crises;  
- redução das internações hospitalares.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- clozapina: medicamento classificado na gestação como categoria B (pesquisas em animais não mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê é muito improvável);  
- lamotrigina, risperidona, <u>quetiapina e olanzapina: medicamentos classificados</u> na gestação como categoria C (pesquisas em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- <u>efeitos adversos mais comuns da lamotrigina: reações alérgicas, com</u> aparecimento de lesões de pele ( _rash_ cutâneo) relacionadas com aumento abrupto da dose, diminuição das células brancas, vermelhas e plaquetas do sangue, constipação ou diarreia, secura na boca, indigestão, náusea, vômitos, dor abdominal, inflamação no esôfago, inflamação no pâncreas, tontura, sonolência, dor de cabeça, irritabilidade, depressão, descoordenação, tremores, amnésia, perda de peso, visão turva ou dupla, alterações no ciclo menstrual, febre;  
- efeitos adversos mais comuns da risperidona: agitação, nervosismo, alterações de visão, disfunção sexual, tonturas, alterações na menstruação, tremores, movimentos

---

<!-- METADADOS: doenca: Transtorno Afetivo Bipolar do tipo I | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
involuntários, insônia, distúrbios urinários, agressividade, diminuição da concentração e da memória, vermelhidão e coceira na pele, fraqueza, cansaço, prisão de ventre, tosse, boca seca, diarreia, sonolência, dor de cabeça, má digestão, náusea, ganho de peso;  
- <u>efeitos adversos mais comuns da quetiapina: prisão de ventre, vertigens,</u> sonolência, boca seca, indigestão, aumento de peso, tontura ao levantar;  
- <u>efeitos adversos mais comuns da olanzapina: dor de cabeça, sonolência,</u> insônia, agitação, nervosismo, ansiedade, boca seca, tontura ao levantar, taquicardia, inchaço, amnésia, febre, vermelhidão na pele, inquietação, prisão de ventre, dor abdominal, ganho de peso, aumento do apetite, rigidez na nuca, dores no corpo;  
- efeitos adversos mais comuns da clozapina: aumento da frequência cardíaca, palpitações, tonturas, prisão de ventre, febre, dor de cabeça, cansaço, sonolência, produção aumentada ou diminuída de saliva, aumento de suor, náusea, vômitos, enjoo, visão turva, aumento de peso, alteração das células do sangue (agranulocitose, eosinofilia, granulocitopenia, leucopenia, trombocitopenia). São necessários controles periódicos com hemograma (semanal nas primeiras 18 semanas e mensal após esse período);  
- medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que o(s) medicamento(s) deve(m) ser utilizado(s) somente por mim, comprometendo-me a devolvê-lo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o(s) medicamento(s). Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (    ) Sim  (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) lamotrigina  
- (    ) risperidona  
- (    ) quetiapina  
- (    ) olanzapina  
- (    ) clozapina  
Local:                                                                                 Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal: _____________________________________ Assinatura do paciente ou do responsável legal Médico responsável: CRM: UF: ___________________________ Assinatura e carimbo do médico Data:____________________

---

